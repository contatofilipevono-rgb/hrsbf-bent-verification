import H12CloudChart0Data088

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans22495_22496 : H12AffineEnvironment.transform 9 256 env22495 = env22496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env22495 == env22496) = true)

theorem identity22496 : scanCanonicalize (H12AffineFastState.compose env22496 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound22496 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env22497 : List Nat := [2,4,8,11,0,10,9,256,260,256,10,10,268,10,1,262,1,271,257,0,1,0,10,3,269,10,11,0,10,271,4,1,257,1,10,261]

theorem envBound22497 : H12AffineFastState.Bounded env22497 := by
  intro p hp
  have h : env22497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22496_22497 : H12AffineEnvironment.transform 8 260 env22496 = env22497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env22496 == env22497) = true)

theorem identity22497 : scanCanonicalize (H12AffineFastState.compose env22497 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 10) := by decide +kernel

theorem selectedBound22497 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22498 : List Nat := [2,4,8,11,0,10,9,10,14,10,10,10,6,10,1,12,1,5,11,0,1,0,10,3,7,10,11,0,10,5,4,1,11,1,10,15]

theorem envBound22498 : H12AffineFastState.Bounded env22498 := by
  intro p hp
  have h : env22498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22497_22498 : H12AffineEnvironment.transform 7 10 env22497 = env22498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 10 env22497 == env22498) = true)

theorem identity22498 : scanCanonicalize (H12AffineFastState.compose env22498 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound22498 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22499 : List Nat := [2,4,5,6,0,7,4,7,3,7,7,7,6,7,1,1,1,5,6,0,1,0,7,3,7,7,6,0,7,5,4,1,6,1,7,2]

theorem envBound22499 : H12AffineFastState.Bounded env22499 := by
  intro p hp
  have h : env22499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22498_22499 : H12AffineEnvironment.transform 2 5 env22498 = env22499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env22498 == env22499) = true)

theorem identity22499 : scanCanonicalize (H12AffineFastState.compose env22499 (packedSelected [9] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound22499 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env22500 : List Nat := [1,4,5,5,0,4,4,4,0,4,4,4,5,4,1,1,1,5,5,0,1,0,4,0,4,4,5,0,4,5,4,1,5,1,4,1]

theorem envBound22500 : H12AffineFastState.Bounded env22500 := by
  intro p hp
  have h : env22500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22499_22500 : H12AffineEnvironment.transform 0 1 env22499 = env22500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env22499 == env22500) = true)

def env22501 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,272513,169216,98780,8328,64,64604,163840,17664,283904,168141,412109,257,21793,46212,243482]

theorem envBound22501 : H12AffineFastState.Bounded env22501 := by
  intro p hp
  have h : env22501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22468_22501 : H12AffineEnvironment.transform 21 272513 env22468 = env22501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env22468 == env22501) = true)

theorem identity22501 : scanCanonicalize (H12AffineFastState.compose env22501 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82382) := by decide +kernel

theorem selectedBound22501 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22502 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,115870,272513,120014,98780,8328,64,64604,115150,17664,283904,119043,329731,257,21793,46212,63188]

theorem envBound22502 : H12AffineFastState.Bounded env22502 := by
  intro p hp
  have h : env22502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22501_22502 : H12AffineEnvironment.transform 16 82382 env22501 = env22502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82382 env22501 == env22502) = true)

def env22503 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82334,262144,1025,32769,115870,272513,119966,98700,8328,16,64524,115102,17664,283904,119043,329731,257,21793,46212,63108]

theorem envBound22503 : H12AffineFastState.Bounded env22503 := by
  intro p hp
  have h : env22503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22502_22503 : H12AffineEnvironment.transform 5 16 env22502 = env22503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22502 == env22503) = true)

theorem identity22503 : scanCanonicalize (H12AffineFastState.compose env22503 (packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22503 : packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env22504 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,82199,262144,1025,32769,115735,272392,119831,98565,8193,16,64524,114967,17664,283904,119043,329731,257,21793,46093,62989]

theorem envBound22504 : H12AffineFastState.Bounded env22504 := by
  intro p hp
  have h : env22504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22503_22504 : H12AffineEnvironment.transform 6 9 env22503 = env22504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22503 == env22504) = true)

theorem identity22504 : scanCanonicalize (H12AffineFastState.compose env22504 (packedSelected [5,8,19,24,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound22504 : packedSelected [5,8,19,24,28,31] rootPS < 2^1333 := by decide +kernel

def env22505 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,82199,43048,1025,32769,115735,32800,119831,98565,8193,16,64524,114967,17664,64808,119043,106539,257,21793,46093,62989]

theorem envBound22505 : H12AffineFastState.Bounded env22505 := by
  intro p hp
  have h : env22505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22504_22505 : H12AffineEnvironment.transform 17 43048 env22504 = env22505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env22504 == env22505) = true)

theorem identity22505 : scanCanonicalize (H12AffineFastState.compose env22505 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound22505 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env22506 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,1,65536,82199,10281,1025,0,82966,33,87062,65796,8193,16,31757,82198,17664,32041,86274,73770,257,21793,13324,30220]

theorem envBound22506 : H12AffineFastState.Bounded env22506 := by
  intro p hp
  have h : env22506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22505_22506 : H12AffineEnvironment.transform 14 1 env22505 = env22506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env22505 == env22506) = true)

theorem identity22506 : scanCanonicalize (H12AffineFastState.compose env22506 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound22506 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22507 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,1,65536,79130,10281,1025,0,77851,33,73755,65796,8193,16,2048,79131,12557,2340,75023,73770,257,8492,13324,513]

theorem envBound22507 : H12AffineFastState.Bounded env22507 := by
  intro p hp
  have h : env22507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22506_22507 : H12AffineEnvironment.transform 13 13325 env22506 = env22507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env22506 == env22507) = true)

theorem identity22507 : scanCanonicalize (H12AffineFastState.compose env22507 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound22507 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env22508 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,1,262,13340,10281,1025,0,12573,33,8477,2,8193,16,2048,13341,12557,2340,9225,8492,257,8492,13324,513]

theorem envBound22508 : H12AffineFastState.Bounded env22508 := by
  intro p hp
  have h : env22508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22507_22508 : H12AffineEnvironment.transform 15 262 env22507 = env22508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env22507 == env22508) = true)

theorem identity22508 : scanCanonicalize (H12AffineFastState.compose env22508 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound22508 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22509 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,1,262,5392,2341,1025,0,4113,33,17,2,269,16,2048,5393,4097,2340,1285,32,257,32,5376,513]

theorem envBound22509 : H12AffineFastState.Bounded env22509 := by
  intro p hp
  have h : env22509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22508_22509 : H12AffineEnvironment.transform 12 268 env22508 = env22509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env22508 == env22509) = true)

theorem identity22509 : scanCanonicalize (H12AffineFastState.compose env22509 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound22509 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22510 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1,268,1280,1,262,1297,2341,1025,0,16,33,17,2,269,16,2048,1296,0,2340,1285,32,257,32,1281,513]

theorem envBound22510 : H12AffineFastState.Bounded env22510 := by
  intro p hp
  have h : env22510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22509_22510 : H12AffineEnvironment.transform 11 1 env22509 = env22510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env22509 == env22510) = true)

theorem identity22510 : scanCanonicalize (H12AffineFastState.compose env22510 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 769) := by decide +kernel

theorem selectedBound22510 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22511 : List Nat := [2,4,8,16,32,16,9,256,512,769,2048,1,268,513,1,262,528,2341,768,0,16,33,17,2,269,16,2048,529,0,2340,516,32,257,32,512,513]

theorem envBound22511 : H12AffineFastState.Bounded env22511 := by
  intro p hp
  have h : env22511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22510_22511 : H12AffineEnvironment.transform 9 769 env22510 = env22511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env22510 == env22511) = true)

theorem identity22511 : scanCanonicalize (H12AffineFastState.compose env22511 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound22511 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22512 : List Nat := [2,4,8,16,32,16,9,256,512,769,513,1,268,513,1,262,528,804,768,0,16,33,17,2,269,16,513,529,0,805,516,32,257,32,512,513]

theorem envBound22512 : H12AffineFastState.Bounded env22512 := by
  intro p hp
  have h : env22512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22511_22512 : H12AffineEnvironment.transform 10 513 env22511 = env22512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env22511 == env22512) = true)

theorem identity22512 : scanCanonicalize (H12AffineFastState.compose env22512 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound22512 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env22513 : List Nat := [2,4,8,16,32,16,9,256,1,256,0,1,268,0,1,262,17,293,257,0,16,33,17,2,269,16,0,16,0,292,5,32,257,32,1,0]

theorem envBound22513 : H12AffineFastState.Bounded env22513 := by
  intro p hp
  have h : env22513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22512_22513 : H12AffineEnvironment.transform 8 1 env22512 = env22513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env22512 == env22513) = true)

theorem identity22513 : scanCanonicalize (H12AffineFastState.compose env22513 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound22513 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22514 : List Nat := [2,4,8,16,32,16,9,37,1,37,0,1,41,0,1,35,17,0,36,0,16,33,17,2,40,16,0,16,0,1,5,32,36,32,1,0]

theorem envBound22514 : H12AffineFastState.Bounded env22514 := by
  intro p hp
  have h : env22514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22513_22514 : H12AffineEnvironment.transform 7 37 env22513 = env22514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env22513 == env22514) = true)

theorem identity22514 : scanCanonicalize (H12AffineFastState.compose env22514 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22514 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env22515 : List Nat := [2,4,8,0,32,0,9,37,1,37,0,1,41,0,1,35,1,0,36,0,0,33,1,2,40,0,0,0,0,1,5,32,36,32,1,0]

theorem envBound22515 : H12AffineFastState.Bounded env22515 := by
  intro p hp
  have h : env22515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22514_22515 : H12AffineEnvironment.transform 3 0 env22514 = env22515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22514 == env22515) = true)

theorem identity22515 : scanCanonicalize (H12AffineFastState.compose env22515 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22515 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22516 : List Nat := [2,4,8,0,0,0,9,5,1,5,0,1,9,0,1,3,1,0,4,0,0,1,1,2,8,0,0,0,0,1,5,0,4,0,1,0]

theorem envBound22516 : H12AffineFastState.Bounded env22516 := by
  intro p hp
  have h : env22516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22515_22516 : H12AffineEnvironment.transform 4 0 env22515 = env22516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22515 == env22516) = true)

def env22517 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82335,262144,1025,32769,115870,272513,119967,98701,8328,17,64525,115103,17664,283904,119043,329731,257,21793,46212,63109]

theorem envBound22517 : H12AffineFastState.Bounded env22517 := by
  intro p hp
  have h : env22517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22502_22517 : H12AffineEnvironment.transform 5 17 env22502 = env22517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22502 == env22517) = true)

theorem identity22517 : scanCanonicalize (H12AffineFastState.compose env22517 (packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound22517 : packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env22518 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,29963,13460,262144,1025,32769,45461,272513,41364,62598,8328,17,64525,46228,17664,283904,41992,294152,257,21793,46212,63109]

theorem envBound22518 : H12AffineFastState.Bounded env22518 := by
  intro p hp
  have h : env22518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22517_22518 : H12AffineEnvironment.transform 15 29963 env22517 = env22518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env22517 == env22518) = true)

theorem identity22518 : scanCanonicalize (H12AffineFastState.compose env22518 (packedSelected [0,1,3,9,16,17,18,20,22,23,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound22518 : packedSelected [0,1,3,9,16,17,18,20,22,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env22519 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,29963,13460,2340,1025,32769,45461,8613,41364,62598,8328,17,64525,46228,17664,23588,41992,29740,257,21793,46212,63109]

theorem envBound22519 : H12AffineFastState.Bounded env22519 := by
  intro p hp
  have h : env22519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22518_22519 : H12AffineEnvironment.transform 17 2340 env22518 = env22519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env22518 == env22519) = true)

theorem identity22519 : scanCanonicalize (H12AffineFastState.compose env22519 (packedSelected [0,1,3,4,5,7,8,10,16,17,18,19,20,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 29829) := by decide +kernel

theorem selectedBound22519 : packedSelected [0,1,3,4,5,7,8,10,16,17,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env22520 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,29963,13460,2340,1025,29828,17680,8613,21777,3,8328,17,2184,16401,17664,23588,20621,29740,257,21793,16385,512]

theorem envBound22520 : H12AffineFastState.Bounded env22520 := by
  intro p hp
  have h : env22520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22519_22520 : H12AffineEnvironment.transform 14 29829 env22519 = env22520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29829 env22519 == env22520) = true)

theorem identity22520 : scanCanonicalize (H12AffineFastState.compose env22520 (packedSelected [1,2,3,5,6,8,10,17,19] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound22520 : packedSelected [1,2,3,5,6,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env22521 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,301,16384,21928,21542,5561,2340,1025,21929,17680,136,21777,3,421,17,2184,16401,17664,23588,20621,21761,257,21793,16385,512]

theorem envBound22521 : H12AffineFastState.Bounded env22521 := by
  intro p hp
  have h : env22521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22520_22521 : H12AffineEnvironment.transform 12 301 env22520 = env22521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env22520 == env22521) = true)

theorem identity22521 : scanCanonicalize (H12AffineFastState.compose env22521 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22521 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env22522 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,301,16384,21793,21542,5424,2340,1025,21792,17680,1,21777,3,300,17,2049,16401,17664,23588,20484,21761,257,21793,16385,512]

theorem envBound22522 : H12AffineFastState.Bounded env22522 := by
  intro p hp
  have h : env22522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22521_22522 : H12AffineEnvironment.transform 6 9 env22521 = env22522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22521 == env22522) = true)

theorem identity22522 : scanCanonicalize (H12AffineFastState.compose env22522 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5408) := by decide +kernel

theorem selectedBound22522 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22523 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,301,5408,1,262,5424,2340,1025,0,4144,1,49,3,300,17,2049,5425,4128,2308,1316,33,257,1,5409,512]

theorem envBound22523 : H12AffineFastState.Bounded env22523 := by
  intro p hp
  have h : env22523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22522_22523 : H12AffineEnvironment.transform 13 5408 env22522 = env22523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5408 env22522 == env22523) = true)

theorem identity22523 : scanCanonicalize (H12AffineFastState.compose env22523 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound22523 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env22524 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,8,5125,1,35,5141,2049,1025,0,4144,1,49,3,9,17,2049,5140,4128,2081,1025,33,36,1,5124,512]

theorem envBound22524 : H12AffineFastState.Bounded env22524 := by
  intro p hp
  have h : env22524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22523_22524 : H12AffineEnvironment.transform 7 37 env22523 = env22524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env22523 == env22524) = true)

def env22525 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,4194304,169217,98781,8328,64,4510941,163841,17665,283905,168141,4350285,257,21793,46212,243482]

theorem envBound22525 : H12AffineFastState.Bounded env22525 := by
  intro p hp
  have h : env22525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22467_22525 : H12AffineEnvironment.transform 22 169217 env22467 = env22525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169217 env22467 == env22525) = true)

def env22526 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,272512,169217,98781,8328,64,64605,163841,17665,283905,168141,412109,257,21793,46212,243482]

theorem envBound22526 : H12AffineFastState.Bounded env22526 := by
  intro p hp
  have h : env22526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22525_22526 : H12AffineEnvironment.transform 21 272512 env22525 = env22526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env22525 == env22526) = true)

theorem identity22526 : scanCanonicalize (H12AffineFastState.compose env22526 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound22526 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22527 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,165200,272512,169217,41430,8328,64,64605,163841,17665,283905,168141,412109,257,21793,46212,169745]

theorem envBound22527 : H12AffineFastState.Bounded env22527 := by
  intro p hp
  have h : env22527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22526_22527 : H12AffineEnvironment.transform 15 8203 env22526 = env22527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env22526 == env22527) = true)

def env22528 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,165200,272392,169217,41310,8192,64,64605,163841,17665,283905,168005,411973,257,21793,46092,169745]

theorem envBound22528 : H12AffineFastState.Bounded env22528 := by
  intro p hp
  have h : env22528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22527_22528 : H12AffineEnvironment.transform 6 8 env22527 = env22528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22527 == env22528) = true)

theorem identity22528 : scanCanonicalize (H12AffineFastState.compose env22528 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 138340) := by decide +kernel

theorem selectedBound22528 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env22529 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,138340,1025,32769,165200,144492,169217,41310,8192,64,64605,163841,17665,149861,168005,21793,257,21793,46092,169745]

theorem envBound22529 : H12AffineFastState.Bounded env22529 := by
  intro p hp
  have h : env22529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22528_22529 : H12AffineEnvironment.transform 17 138340 env22528 = env22529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138340 env22528 == env22529) = true)

theorem identity22529 : scanCanonicalize (H12AffineFastState.compose env22529 (packedSelected [0,2,3,7,9,10,11,16,18,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5220) := by decide +kernel

theorem selectedBound22529 : packedSelected [0,2,3,7,9,10,11,16,18,22,24,26] rootPS < 2^1333 := by decide +kernel

def env22530 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,5220,2048,1025,32769,37172,8200,33125,41310,8192,64,64605,37989,17665,23809,33825,21793,257,21793,46092,33653]

theorem envBound22530 : H12AffineFastState.Bounded env22530 := by
  intro p hp
  have h : env22530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22529_22530 : H12AffineEnvironment.transform 16 5220 env22529 = env22530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5220 env22529 == env22530) = true)

theorem identity22530 : scanCanonicalize (H12AffineFastState.compose env22530 (packedSelected [0,2,6,7,11,16,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound22530 : packedSelected [0,2,6,7,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env22531 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,8203,5220,2048,1025,32769,37172,8200,33125,41310,8192,64,34817,37989,12637,10589,33825,8573,257,8573,46092,33653]

theorem envBound22531 : H12AffineFastState.Bounded env22531 := by
  intro p hp
  have h : env22531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22530_22531 : H12AffineEnvironment.transform 13 13404 env22530 = env22531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env22530 == env22531) = true)

theorem identity22531 : scanCanonicalize (H12AffineFastState.compose env22531 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound22531 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env22532 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,373,8203,5220,2048,1025,372,4161,8200,16,8235,8192,64,2420,5392,12637,10589,1364,8573,257,8573,13689,512]

theorem envBound22532 : H12AffineFastState.Bounded env22532 := by
  intro p hp
  have h : env22532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22531_22532 : H12AffineEnvironment.transform 14 373 env22531 = env22532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env22531 == env22532) = true)

theorem identity22532 : scanCanonicalize (H12AffineFastState.compose env22532 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound22532 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22533 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,301,5489,373,294,5220,2048,1025,372,4161,293,16,262,301,64,2420,5392,4208,2160,1364,80,257,80,5204,512]

theorem envBound22533 : H12AffineFastState.Bounded env22533 := by
  intro p hp
  have h : env22533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22532_22533 : H12AffineEnvironment.transform 12 301 env22532 = env22533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env22532 == env22533) = true)

theorem identity22533 : scanCanonicalize (H12AffineFastState.compose env22533 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22533 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env22534 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,268,5456,340,263,5189,2048,1025,341,4161,260,16,262,268,64,2389,5392,4177,2129,1364,80,257,80,5204,512]

theorem envBound22534 : H12AffineFastState.Bounded env22534 := by
  intro p hp
  have h : env22534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22533_22534 : H12AffineEnvironment.transform 4 1 env22533 = env22534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22533 == env22534) = true)

theorem identity22534 : scanCanonicalize (H12AffineFastState.compose env22534 (packedSelected [0,2,3,4,5,7,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 1361) := by decide +kernel

theorem selectedBound22534 : packedSelected [0,2,3,4,5,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env22535 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,1361,268,1,340,263,276,2048,1025,341,1296,260,16,262,268,64,2389,65,1280,2129,1364,80,257,80,261,512]

theorem envBound22535 : H12AffineFastState.Bounded env22535 := by
  intro p hp
  have h : env22535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22534_22535 : H12AffineEnvironment.transform 11 1361 env22534 = env22535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1361 env22534 == env22535) = true)

theorem identity22535 : scanCanonicalize (H12AffineFastState.compose env22535 (packedSelected [10] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound22535 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env22536 : List Nat := [2,4,8,16,1,64,8,256,512,1024,1044,1361,268,1,340,263,276,1044,1025,341,1296,260,16,262,268,64,1345,65,1280,1093,1364,80,257,80,261,512]

theorem envBound22536 : H12AffineFastState.Bounded env22536 := by
  intro p hp
  have h : env22536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22535_22536 : H12AffineEnvironment.transform 10 1044 env22535 = env22536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env22535 == env22536) = true)

theorem identity22536 : scanCanonicalize (H12AffineFastState.compose env22536 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22536 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env22537 : List Nat := [2,4,8,16,1,16,8,256,512,1024,1044,1281,268,1,260,263,276,1044,1025,261,1296,260,16,262,268,16,1297,17,1280,1045,1284,0,257,0,261,512]

theorem envBound22537 : H12AffineFastState.Bounded env22537 := by
  intro p hp
  have h : env22537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22536_22537 : H12AffineEnvironment.transform 5 16 env22536 = env22537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22536 == env22537) = true)

theorem identity22537 : scanCanonicalize (H12AffineFastState.compose env22537 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound22537 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env22538 : List Nat := [2,4,8,16,1,16,8,256,512,273,261,16,268,1,260,263,276,261,272,261,1,260,16,262,268,16,0,17,17,260,21,0,257,0,261,512]

theorem envBound22538 : H12AffineFastState.Bounded env22538 := by
  intro p hp
  have h : env22538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22537_22538 : H12AffineEnvironment.transform 9 273 env22537 = env22538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env22537 == env22538) = true)

theorem identity22538 : scanCanonicalize (H12AffineFastState.compose env22538 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22538 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22539 : List Nat := [2,4,8,16,1,16,8,4,512,21,1,16,8,1,0,3,16,1,20,1,1,0,16,2,8,16,0,17,17,0,21,0,5,0,1,512]

theorem envBound22539 : H12AffineFastState.Bounded env22539 := by
  intro p hp
  have h : env22539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22538_22539 : H12AffineEnvironment.transform 7 4 env22538 = env22539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22538 == env22539) = true)

theorem identity22539 : scanCanonicalize (H12AffineFastState.compose env22539 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound22539 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22540 : List Nat := [2,4,8,16,1,16,8,4,16,21,1,16,8,1,0,3,16,1,20,1,1,0,16,2,8,16,0,17,17,0,21,0,5,0,1,16]

theorem envBound22540 : H12AffineFastState.Bounded env22540 := by
  intro p hp
  have h : env22540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22539_22540 : H12AffineEnvironment.transform 8 16 env22539 = env22540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env22539 == env22540) = true)

theorem identity22540 : scanCanonicalize (H12AffineFastState.compose env22540 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound22540 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22541 : List Nat := [2,4,8,14,1,14,8,4,14,11,1,14,8,1,0,3,14,1,10,1,1,0,14,2,8,14,0,15,15,0,11,0,5,0,1,14]

theorem envBound22541 : H12AffineFastState.Bounded env22541 := by
  intro p hp
  have h : env22541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22540_22541 : H12AffineEnvironment.transform 3 14 env22540 = env22541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env22540 == env22541) = true)

theorem identity22541 : scanCanonicalize (H12AffineFastState.compose env22541 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound22541 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22542 : List Nat := [2,4,7,1,1,1,7,4,1,4,1,1,7,1,0,3,1,1,5,1,1,0,1,2,7,1,0,0,0,0,4,0,5,0,1,1]

theorem envBound22542 : H12AffineFastState.Bounded env22542 := by
  intro p hp
  have h : env22542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22541_22542 : H12AffineEnvironment.transform 2 7 env22541 = env22542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env22541 == env22542) = true)

def env22543 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,165200,272393,169217,41311,8193,64,64605,163841,17665,283905,168004,411972,257,21793,46093,169745]

theorem envBound22543 : H12AffineFastState.Bounded env22543 := by
  intro p hp
  have h : env22543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22527_22543 : H12AffineEnvironment.transform 6 9 env22527 = env22543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22527 == env22543) = true)

theorem identity22543 : scanCanonicalize (H12AffineFastState.compose env22543 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 179512) := by decide +kernel

theorem selectedBound22543 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env22544 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179512,1025,32769,165200,169265,169217,41311,8193,64,64605,163841,17665,190521,168004,62588,257,21793,46093,169745]

theorem envBound22544 : H12AffineFastState.Bounded env22544 := by
  intro p hp
  have h : env22544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22543_22544 : H12AffineEnvironment.transform 17 179512 env22543 = env22544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env22543 == env22544) = true)

def env22545 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,272513,169217,98781,8328,64,64604,163841,17665,283905,168141,412108,257,21793,46212,243482]

theorem envBound22545 : H12AffineFastState.Bounded env22545 := by
  intro p hp
  have h : env22545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22525_22545 : H12AffineEnvironment.transform 21 272513 env22525 = env22545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env22525 == env22545) = true)

theorem identity22545 : scanCanonicalize (H12AffineFastState.compose env22545 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 111899) := by decide +kernel

theorem selectedBound22545 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22546 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111899,262144,1025,32769,77899,272513,73754,98781,8328,64,64604,79130,17665,283905,75222,392407,257,21793,46212,513]

theorem envBound22546 : H12AffineFastState.Bounded env22546 := by
  intro p hp
  have h : env22546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22545_22546 : H12AffineEnvironment.transform 16 111899 env22545 = env22546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111899 env22545 == env22546) = true)

def env22547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,65536,90139,262144,1025,21761,77899,272513,73754,87261,8328,64,10588,79130,17665,283905,75222,338391,257,21793,24964,513]

theorem envBound22547 : H12AffineFastState.Bounded env22547 := by
  intro p hp
  have h : env22547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22546_22547 : H12AffineEnvironment.transform 14 21760 env22546 = env22547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env22546 == env22547) = true)

def env22548 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,65536,90139,262144,1025,21761,77899,272393,73754,87125,8192,64,10588,79130,17665,283905,75102,338271,257,21793,24844,513]

theorem envBound22548 : H12AffineFastState.Bounded env22548 := by
  intro p hp
  have h : env22548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22547_22548 : H12AffineEnvironment.transform 6 8 env22547 = env22548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22547 == env22548) = true)

theorem identity22548 : scanCanonicalize (H12AffineFastState.compose env22548 (packedSelected [0,2,4,6,9,11,17,20,27,32] rootPS)) = affineNative (2^(15+1) ^^^ 1047) := by decide +kernel

theorem selectedBound22548 : packedSelected [0,2,4,6,9,11,17,20,27,32] rootPS < 2^1333 := by decide +kernel

def env22549 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,1047,25612,262144,1025,21761,13404,272393,9229,20546,8192,64,10588,12557,17665,283905,8521,273736,257,21793,24844,513]

theorem envBound22549 : H12AffineFastState.Bounded env22549 := by
  intro p hp
  have h : env22549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22548_22549 : H12AffineEnvironment.transform 15 1047 env22548 = env22549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1047 env22548 == env22549) = true)

theorem identity22549 : scanCanonicalize (H12AffineFastState.compose env22549 (packedSelected [2,3,4,5,6,9,10,12,14,20,38] rootPS)) = affineNative (2^(13+1) ^^^ 12392) := by decide +kernel

theorem selectedBound22549 : packedSelected [2,3,4,5,6,9,10,12,14,20,38] rootPS < 2^1333 := by decide +kernel

def env22550 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12392,9576,1047,5220,262144,1025,9577,13404,272393,9229,8234,8192,64,10588,12557,13673,271721,8521,273736,257,9545,4452,513]

theorem envBound22550 : H12AffineFastState.Bounded env22550 := by
  intro p hp
  have h : env22550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22549_22550 : H12AffineEnvironment.transform 13 12392 env22549 = env22550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12392 env22549 == env22550) = true)

theorem identity22550 : scanCanonicalize (H12AffineFastState.compose env22550 (packedSelected [0,1,3,7,11,12,15,17,20,23,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound22550 : packedSelected [0,1,3,7,11,12,15,17,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env22551 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,5156,292,1047,5220,262144,1025,293,4112,265285,65,1126,1100,64,3344,5441,4389,262437,1285,264452,257,261,4452,513]

theorem envBound22551 : H12AffineFastState.Bounded env22551 := by
  intro p hp
  have h : env22551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22550_22551 : H12AffineEnvironment.transform 12 1100 env22550 = env22551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env22550 == env22551) = true)

theorem identity22551 : scanCanonicalize (H12AffineFastState.compose env22551 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 3392) := by decide +kernel

theorem selectedBound22551 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env22552 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,5156,292,1047,5220,3392,1025,293,4112,261,65,1126,1100,64,3344,5441,4389,3173,1285,1092,257,261,4452,513]

theorem envBound22552 : H12AffineFastState.Bounded env22552 := by
  intro p hp
  have h : env22552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22551_22552 : H12AffineEnvironment.transform 17 3392 env22551 = env22552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3392 env22551 == env22552) = true)

theorem identity22552 : scanCanonicalize (H12AffineFastState.compose env22552 (packedSelected [0,2,4,6,7,9,14,17] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound22552 : packedSelected [0,2,4,6,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env22553 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,1100,5156,80,1047,5220,3124,1025,81,4112,113,65,1126,1100,64,3172,5173,4177,3173,1137,1092,117,113,4112,513]

theorem envBound22553 : H12AffineFastState.Bounded env22553 := by
  intro p hp
  have h : env22553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22552_22553 : H12AffineEnvironment.transform 7 116 env22552 = env22553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env22552 == env22553) = true)

theorem identity22553 : scanCanonicalize (H12AffineFastState.compose env22553 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound22553 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env22554 : List Nat := [2,4,8,16,32,64,8,116,512,101,2048,4096,41,4161,80,114,4097,2129,100,81,4112,113,65,3,41,64,2049,4176,4177,2048,20,33,117,113,4112,513]

theorem envBound22554 : H12AffineFastState.Bounded env22554 := by
  intro p hp
  have h : env22554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22553_22554 : H12AffineEnvironment.transform 9 101 env22553 = env22554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env22553 == env22554) = true)

theorem identity22554 : scanCanonicalize (H12AffineFastState.compose env22554 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22554 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22555 : List Nat := [2,4,8,16,32,17,8,37,512,52,2048,4096,41,4112,1,35,4097,2048,53,0,4112,32,16,3,41,17,2049,4097,4096,2048,20,33,36,32,4112,513]

theorem envBound22555 : H12AffineFastState.Bounded env22555 := by
  intro p hp
  have h : env22555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22554_22555 : H12AffineEnvironment.transform 5 17 env22554 = env22555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22554 == env22555) = true)

theorem identity22555 : scanCanonicalize (H12AffineFastState.compose env22555 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2608) := by decide +kernel

theorem selectedBound22555 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22556 : List Nat := [2,4,8,16,32,17,8,37,512,52,2048,2608,41,2592,1,35,2609,2048,53,0,2592,32,16,3,41,17,2049,2609,2608,2048,20,33,36,32,2592,513]

theorem envBound22556 : H12AffineFastState.Bounded env22556 := by
  intro p hp
  have h : env22556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22555_22556 : H12AffineEnvironment.transform 11 2608 env22555 = env22556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2608 env22555 == env22556) = true)

theorem identity22556 : scanCanonicalize (H12AffineFastState.compose env22556 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22556 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22557 : List Nat := [2,4,8,0,32,1,8,37,512,36,2048,2592,41,2592,1,35,2593,2048,37,0,2592,32,0,3,41,1,2049,2593,2592,2048,4,33,36,32,2592,513]

theorem envBound22557 : H12AffineFastState.Bounded env22557 := by
  intro p hp
  have h : env22557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22556_22557 : H12AffineEnvironment.transform 3 0 env22556 = env22557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22556 == env22557) = true)

def env22558 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,65536,90139,262144,1025,21761,77899,272392,73754,87124,8193,64,10588,79130,17665,283905,75103,338270,257,21793,24845,513]

theorem envBound22558 : H12AffineFastState.Bounded env22558 := by
  intro p hp
  have h : env22558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22547_22558 : H12AffineEnvironment.transform 6 9 env22547 = env22558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22547 == env22558) = true)

theorem identity22558 : scanCanonicalize (H12AffineFastState.compose env22558 (packedSelected [0,2,4,6,9,11,17,20,27,32] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound22558 : packedSelected [0,2,4,6,9,11,17,20,27,32] rootPS < 2^1333 := by decide +kernel

def env22559 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,8202,16401,262144,1025,21761,4161,272392,16,29790,8193,64,10588,5392,17665,283905,1365,264532,257,21793,24845,513]

theorem envBound22559 : H12AffineFastState.Bounded env22559 := by
  intro p hp
  have h : env22559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22558_22559 : H12AffineEnvironment.transform 15 8202 env22558 = env22559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env22558 == env22559) = true)

theorem identity22559 : scanCanonicalize (H12AffineFastState.compose env22559 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound22559 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env22560 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8540,8202,13389,262144,1025,8541,4161,272392,16,2,8193,64,10588,5392,12637,270685,1365,264532,257,8573,5457,513]

theorem envBound22560 : H12AffineFastState.Bounded env22560 := by
  intro p hp
  have h : env22560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22559_22560 : H12AffineEnvironment.transform 13 13404 env22559 = env22560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env22559 == env22560) = true)

theorem identity22560 : scanCanonicalize (H12AffineFastState.compose env22560 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 10508) := by decide +kernel

theorem selectedBound22560 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env22561 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8540,8202,13389,10508,1025,8541,4161,260,16,2,8193,64,10588,5392,12637,2129,1365,8280,257,8573,5457,513]

theorem envBound22561 : H12AffineFastState.Bounded env22561 := by
  intro p hp
  have h : env22561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22560_22561 : H12AffineEnvironment.transform 17 10508 env22560 = env22561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10508 env22560 == env22561) = true)

theorem identity22561 : scanCanonicalize (H12AffineFastState.compose env22561 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound22561 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env22562 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,4112,1296,1094,4097,3392,1025,1297,4161,260,16,2,1101,64,3344,5392,5393,2129,1365,1044,257,1329,5457,513]

theorem envBound22562 : H12AffineFastState.Bounded env22562 := by
  intro p hp
  have h : env22562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22561_22562 : H12AffineEnvironment.transform 12 1100 env22561 = env22562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env22561 == env22562) = true)

theorem identity22562 : scanCanonicalize (H12AffineFastState.compose env22562 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound22562 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22563 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,356,1100,372,1296,1094,357,3392,1025,1297,293,260,16,2,1101,64,3344,1140,1141,2129,1365,1044,257,1329,1077,513]

theorem envBound22563 : H12AffineFastState.Bounded env22563 := by
  intro p hp
  have h : env22563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22562_22563 : H12AffineEnvironment.transform 11 356 env22562 = env22563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env22562 == env22563) = true)

theorem identity22563 : scanCanonicalize (H12AffineFastState.compose env22563 (packedSelected [0,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound22563 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env22564 : List Nat := [2,4,8,16,32,64,9,256,512,1024,80,356,1100,372,1296,1094,357,1296,1025,1297,293,260,16,2,1101,64,1344,1140,1141,1,1365,1044,257,1329,1077,513]

theorem envBound22564 : H12AffineFastState.Bounded env22564 := by
  intro p hp
  have h : env22564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22563_22564 : H12AffineEnvironment.transform 10 80 env22563 = env22564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env22563 == env22564) = true)

theorem identity22564 : scanCanonicalize (H12AffineFastState.compose env22564 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound22564 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env22565 : List Nat := [2,4,8,16,32,64,9,256,512,53,80,356,121,372,293,115,357,293,52,292,293,260,16,2,120,64,373,65,64,1,352,33,257,260,0,513]

theorem envBound22565 : H12AffineFastState.Bounded env22565 := by
  intro p hp
  have h : env22565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22564_22565 : H12AffineEnvironment.transform 9 53 env22564 = env22565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env22564 == env22565) = true)

def env22566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,65536,90138,262144,1025,21760,77899,272513,73754,87260,8328,64,10589,79130,17665,283905,75222,338390,257,21793,24965,513]

theorem envBound22566 : H12AffineFastState.Bounded env22566 := by
  intro p hp
  have h : env22566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22546_22566 : H12AffineEnvironment.transform 14 21761 env22546 = env22566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env22546 == env22566) = true)

theorem identity22566 : scanCanonicalize (H12AffineFastState.compose env22566 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound22566 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env22567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,8203,16401,262144,1025,21760,4160,272513,17,29911,8328,64,10589,5393,17665,283905,1501,264669,257,21793,24965,513]

theorem envBound22567 : H12AffineFastState.Bounded env22567 := by
  intro p hp
  have h : env22567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22566_22567 : H12AffineEnvironment.transform 15 8203 env22566 = env22567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env22566 == env22567) = true)

theorem identity22567 : scanCanonicalize (H12AffineFastState.compose env22567 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 2557) := by decide +kernel

theorem selectedBound22567 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env22568 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,8203,16401,2557,1025,21760,4160,8572,17,29911,8328,64,10589,5393,17665,23804,1501,32,257,21793,24965,513]

theorem envBound22568 : H12AffineFastState.Bounded env22568 := by
  intro p hp
  have h : env22568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22567_22568 : H12AffineEnvironment.transform 17 2557 env22567 = env22568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2557 env22567 == env22568) = true)

theorem identity22568 : scanCanonicalize (H12AffineFastState.compose env22568 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound22568 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22569 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,136,8203,5528,2557,1025,137,4160,8572,17,8542,8328,64,10589,5393,4232,2421,1501,32,257,168,13324,513]

theorem envBound22569 : H12AffineFastState.Bounded env22569 := by
  intro p hp
  have h : env22569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22568_22569 : H12AffineEnvironment.transform 13 5513 env22568 = env22569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env22568 == env22569) = true)

theorem identity22569 : scanCanonicalize (H12AffineFastState.compose env22569 (packedSelected [2,3,5,10,11,12,14,15,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 421) := by decide +kernel

theorem selectedBound22569 : packedSelected [2,3,5,10,11,12,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env22570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,5513,136,430,5528,2557,1025,137,4160,217,17,251,301,64,2296,5393,4232,2421,1501,32,257,168,5545,513]

theorem envBound22570 : H12AffineFastState.Bounded env22570 := by
  intro p hp
  have h : env22570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22569_22570 : H12AffineEnvironment.transform 12 421 env22569 = env22570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 421 env22569 == env22570) = true)

theorem identity22570 : scanCanonicalize (H12AffineFastState.compose env22570 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound22570 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env22571 : List Nat := [2,4,8,16,32,64,121,256,512,1024,2048,4096,348,5488,113,343,5473,2308,1025,112,4160,32,17,2,301,64,2049,5393,4209,2421,1316,32,257,81,5456,513]

theorem envBound22571 : H12AffineFastState.Bounded env22571 := by
  intro p hp
  have h : env22571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22570_22571 : H12AffineEnvironment.transform 6 121 env22570 = env22571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env22570 == env22571) = true)

theorem identity22571 : scanCanonicalize (H12AffineFastState.compose env22571 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound22571 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env22572 : List Nat := [2,4,8,16,32,64,121,36,512,1024,2048,4096,120,5204,113,115,5189,2080,1025,112,4160,32,17,2,9,64,2049,5173,4209,2129,1024,32,37,81,5236,513]

theorem envBound22572 : H12AffineFastState.Bounded env22572 := by
  intro p hp
  have h : env22572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22571_22572 : H12AffineEnvironment.transform 7 36 env22571 = env22572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env22571 == env22572) = true)

theorem identity22572 : scanCanonicalize (H12AffineFastState.compose env22572 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound22572 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env22573 : List Nat := [2,4,8,16,32,59,2,36,512,1024,2048,4096,3,5167,10,8,5182,2080,1025,11,4155,32,17,2,9,59,2049,5173,4106,2090,1024,32,37,42,5135,513]

theorem envBound22573 : H12AffineFastState.Bounded env22573 := by
  intro p hp
  have h : env22573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22572_22573 : H12AffineEnvironment.transform 5 59 env22572 = env22573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env22572 == env22573) = true)

theorem identity22573 : scanCanonicalize (H12AffineFastState.compose env22573 (packedSelected [0,1,2,5,7,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound22573 : packedSelected [0,1,2,5,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env22574 : List Nat := [2,4,8,16,32,59,2,36,512,1024,2048,3108,3,2059,10,8,2074,2080,1025,11,3103,32,17,2,9,59,2049,2065,3118,2090,1024,32,37,42,2091,513]

theorem envBound22574 : H12AffineFastState.Bounded env22574 := by
  intro p hp
  have h : env22574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22573_22574 : H12AffineEnvironment.transform 11 3108 env22573 = env22574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env22573 == env22574) = true)

theorem identity22574 : scanCanonicalize (H12AffineFastState.compose env22574 (packedSelected [4,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 1567) := by decide +kernel

theorem selectedBound22574 : packedSelected [4,7,10] rootPS < 2^1333 := by decide +kernel

def env22575 : List Nat := [2,4,8,16,32,59,2,36,512,1024,1567,571,3,1556,10,8,1541,1599,1025,11,512,32,17,2,9,59,1566,1550,561,1589,1024,32,37,42,1588,513]

theorem envBound22575 : H12AffineFastState.Bounded env22575 := by
  intro p hp
  have h : env22575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22574_22575 : H12AffineEnvironment.transform 10 1567 env22574 = env22575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1567 env22574 == env22575) = true)

theorem identity22575 : scanCanonicalize (H12AffineFastState.compose env22575 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 532) := by decide +kernel

theorem selectedBound22575 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env22576 : List Nat := [2,4,8,16,32,59,2,36,512,532,11,571,3,0,10,8,17,43,533,11,512,32,17,2,9,59,10,26,561,33,532,32,37,42,32,513]

theorem envBound22576 : H12AffineFastState.Bounded env22576 := by
  intro p hp
  have h : env22576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22575_22576 : H12AffineEnvironment.transform 9 532 env22575 = env22576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 532 env22575 == env22576) = true)

theorem identity22576 : scanCanonicalize (H12AffineFastState.compose env22576 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound22576 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env22577 : List Nat := [2,4,8,11,32,32,2,36,512,527,11,544,3,0,10,8,10,43,526,11,512,32,10,2,9,32,10,1,554,33,527,32,37,42,32,513]

theorem envBound22577 : H12AffineFastState.Bounded env22577 := by
  intro p hp
  have h : env22577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22576_22577 : H12AffineEnvironment.transform 3 11 env22576 = env22577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env22576 == env22577) = true)

theorem identity22577 : scanCanonicalize (H12AffineFastState.compose env22577 (packedSelected [0,1,2] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound22577 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env22578 : List Nat := [2,4,8,11,32,32,2,36,7,8,11,39,3,0,10,8,10,43,9,11,7,32,10,2,9,32,10,1,45,33,8,32,37,42,32,6]

theorem envBound22578 : H12AffineFastState.Bounded env22578 := by
  intro p hp
  have h : env22578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22577_22578 : H12AffineEnvironment.transform 8 7 env22577 = env22578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env22577 == env22578) = true)

theorem identity22578 : scanCanonicalize (H12AffineFastState.compose env22578 (packedSelected [0,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound22578 : packedSelected [0,3,7] rootPS < 2^1333 := by decide +kernel

def env22579 : List Nat := [2,4,8,11,15,15,2,11,7,8,11,8,3,0,10,8,10,4,9,11,7,15,10,2,9,15,10,1,2,14,8,15,10,5,15,6]

theorem envBound22579 : H12AffineFastState.Bounded env22579 := by
  intro p hp
  have h : env22579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22578_22579 : H12AffineEnvironment.transform 4 15 env22578 = env22579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env22578 == env22579) = true)

theorem identity22579 : scanCanonicalize (H12AffineFastState.compose env22579 (packedSelected [0,1,3,14] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound22579 : packedSelected [0,1,3,14] rootPS < 2^1333 := by decide +kernel

def env22580 : List Nat := [2,4,1,2,6,6,2,2,7,1,2,1,3,0,3,1,3,4,0,2,7,6,3,2,0,6,3,1,2,7,1,6,3,5,6,6]

theorem envBound22580 : H12AffineFastState.Bounded env22580 := by
  intro p hp
  have h : env22580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22579_22580 : H12AffineEnvironment.transform 2 1 env22579 = env22580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env22579 == env22580) = true)

theorem identity22580 : scanCanonicalize (H12AffineFastState.compose env22580 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound22580 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env22581 : List Nat := [2,1,1,2,3,3,2,2,2,1,2,1,3,0,3,1,3,1,0,2,2,3,3,2,0,3,3,1,2,2,1,3,3,0,3,3]

theorem envBound22581 : H12AffineFastState.Bounded env22581 := by
  intro p hp
  have h : env22581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22580_22581 : H12AffineEnvironment.transform 1 1 env22580 = env22581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env22580 == env22581) = true)

theorem identity22581 : scanCanonicalize (H12AffineFastState.compose env22581 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound22581 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22582 : List Nat := [1,1,1,1,0,0,1,1,1,1,1,1,0,0,0,1,0,1,0,1,1,0,0,1,0,0,0,1,1,1,1,0,0,0,0,0]

theorem envBound22582 : H12AffineFastState.Bounded env22582 := by
  intro p hp
  have h : env22582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22581_22582 : H12AffineEnvironment.transform 0 1 env22581 = env22582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env22581 == env22582) = true)

def env22583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,4194304,8388608,8590557,8328,64,4510940,8393985,8572928,8830976,168140,12645453,257,21792,46213,243483]

theorem envBound22583 : H12AffineFastState.Bounded env22583 := by
  intro p hp
  have h : env22583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22466_22583 : H12AffineEnvironment.transform 23 8590557 env22466 = env22583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8590557 env22466 == env22583) = true)

def env22584 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,4194304,169216,98781,8328,64,4510940,163841,17664,283904,168140,4350285,257,21792,46213,243483]

theorem envBound22584 : H12AffineFastState.Bounded env22584 := by
  intro p hp
  have h : env22584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22583_22584 : H12AffineEnvironment.transform 22 169216 env22583 = env22584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169216 env22583 == env22584) = true)

def env22585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,272512,169216,98781,8328,64,64604,163841,17664,283904,168140,412109,257,21792,46213,243483]

theorem envBound22585 : H12AffineFastState.Bounded env22585 := by
  intro p hp
  have h : env22585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22584_22585 : H12AffineEnvironment.transform 21 272512 env22584 = env22585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env22584 == env22585) = true)

theorem identity22585 : scanCanonicalize (H12AffineFastState.compose env22585 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound22585 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4161,272512,17,98781,8328,64,64604,5392,17664,283904,1501,318684,257,21792,46213,74250]

theorem envBound22586 : H12AffineFastState.Bounded env22586 := by
  intro p hp
  have h : env22586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22585_22586 : H12AffineEnvironment.transform 16 38161 env22585 = env22586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env22585 == env22586) = true)

theorem identity22586 : scanCanonicalize (H12AffineFastState.compose env22586 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound22586 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env22587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38161,262144,1025,32769,4161,272512,17,41430,8328,64,64604,5392,17664,283904,1501,318684,257,21792,46213,513]

theorem envBound22587 : H12AffineFastState.Bounded env22587 := by
  intro p hp
  have h : env22587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22586_22587 : H12AffineEnvironment.transform 15 8203 env22586 = env22587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env22586 == env22587) = true)

def env22588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,272513,169216,98781,8328,64,64605,163841,17664,283904,168140,412108,257,21792,46213,243483]

theorem envBound22588 : H12AffineFastState.Bounded env22588 := by
  intro p hp
  have h : env22588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22584_22588 : H12AffineEnvironment.transform 21 272513 env22584 = env22588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env22584 == env22588) = true)

def env22589 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,272393,169216,98645,8192,64,64605,163841,17664,283904,168004,411972,257,21792,46093,243483]

theorem envBound22589 : H12AffineFastState.Bounded env22589 := by
  intro p hp
  have h : env22589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22588_22589 : H12AffineEnvironment.transform 6 8 env22588 = env22589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22588 == env22589) = true)

theorem identity22589 : scanCanonicalize (H12AffineFastState.compose env22589 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound22589 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env22590 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,50497,272393,54545,98645,8192,64,64605,49168,17664,283904,53333,264533,257,21792,46093,128778]

theorem envBound22590 : H12AffineFastState.Bounded env22590 := by
  intro p hp
  have h : env22590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22589_22590 : H12AffineEnvironment.transform 16 16401 env22589 = env22590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env22589 == env22590) = true)

def env22591 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,65536,16401,262144,1025,21761,4161,272393,17,87125,8192,64,10589,5392,17664,283904,1365,264533,257,21792,24845,74250]

theorem envBound22591 : H12AffineFastState.Bounded env22591 := by
  intro p hp
  have h : env22591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22590_22591 : H12AffineEnvironment.transform 14 21760 env22590 = env22591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env22590 == env22591) = true)

theorem identity22591 : scanCanonicalize (H12AffineFastState.compose env22591 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 97406) := by decide +kernel

theorem selectedBound22591 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22592 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,65536,16401,97406,1025,21761,4161,87159,17,87125,8192,64,10589,5392,17664,76158,1365,95531,257,21792,24845,74250]

theorem envBound22592 : H12AffineFastState.Bounded env22592 := by
  intro p hp
  have h : env22592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22591_22592 : H12AffineEnvironment.transform 17 97406 env22591 = env22592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97406 env22591 == env22592) = true)

theorem identity22592 : scanCanonicalize (H12AffineFastState.compose env22592 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound22592 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env22593 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,8202,16401,23668,1025,21761,4161,29821,17,29791,8192,64,10589,5392,17664,2420,1365,21793,257,21792,24845,512]

theorem envBound22593 : H12AffineFastState.Bounded env22593 := by
  intro p hp
  have h : env22593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22592_22593 : H12AffineEnvironment.transform 15 8202 env22592 = env22593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env22592 == env22593) = true)

theorem identity22593 : scanCanonicalize (H12AffineFastState.compose env22593 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound22593 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env22594 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,16384,21760,115,16401,23668,1025,21761,4161,21508,17,21542,121,64,2340,5392,17664,2420,1365,21793,257,21792,16756,512]

theorem envBound22594 : H12AffineFastState.Bounded env22594 := by
  intro p hp
  have h : env22594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22593_22594 : H12AffineEnvironment.transform 12 121 env22593 = env22594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env22593 == env22594) = true)

theorem identity22594 : scanCanonicalize (H12AffineFastState.compose env22594 (packedSelected [0,2,4,5,6,7,8,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound22594 : packedSelected [0,2,4,5,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env22595 : List Nat := [2,4,8,16,32,64,8,256,512,1024,554,4096,121,16384,21760,115,16401,22110,1025,21761,4161,21508,17,21542,121,64,782,5392,17664,862,1365,21793,257,21792,16756,512]

theorem envBound22595 : H12AffineFastState.Bounded env22595 := by
  intro p hp
  have h : env22595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22594_22595 : H12AffineEnvironment.transform 10 554 env22594 = env22595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env22594 == env22595) = true)

theorem identity22595 : scanCanonicalize (H12AffineFastState.compose env22595 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound22595 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env22596 : List Nat := [2,4,8,16,32,64,8,256,512,1024,554,4096,121,5236,372,115,5221,554,1025,373,4161,112,17,82,121,64,782,5392,4468,862,1365,341,257,340,5376,512]

theorem envBound22596 : H12AffineFastState.Bounded env22596 := by
  intro p hp
  have h : env22596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22595_22596 : H12AffineEnvironment.transform 13 5236 env22595 = env22596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env22595 == env22596) = true)

theorem identity22596 : scanCanonicalize (H12AffineFastState.compose env22596 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound22596 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env22597 : List Nat := [2,4,8,16,32,64,8,116,512,1024,554,4096,121,5236,0,115,5221,554,1025,1,4161,112,17,82,121,64,634,5220,4096,554,1057,33,117,32,5236,512]

theorem envBound22597 : H12AffineFastState.Bounded env22597 := by
  intro p hp
  have h : env22597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22596_22597 : H12AffineEnvironment.transform 7 116 env22596 = env22597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env22596 == env22597) = true)

theorem identity22597 : scanCanonicalize (H12AffineFastState.compose env22597 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 587) := by decide +kernel

theorem selectedBound22597 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env22598 : List Nat := [2,4,8,16,32,64,8,116,512,1024,554,587,121,1599,0,115,1582,554,1025,1,522,112,17,82,121,64,634,1583,587,554,1057,33,117,32,1599,512]

theorem envBound22598 : H12AffineFastState.Bounded env22598 := by
  intro p hp
  have h : env22598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22597_22598 : H12AffineEnvironment.transform 11 587 env22597 = env22598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 587 env22597 == env22598) = true)

theorem identity22598 : scanCanonicalize (H12AffineFastState.compose env22598 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound22598 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22599 : List Nat := [2,4,8,16,32,49,8,5,512,1024,554,570,8,1599,0,2,1582,554,1025,1,522,1,17,35,8,49,523,1583,570,554,1057,33,4,32,1599,512]

theorem envBound22599 : H12AffineFastState.Bounded env22599 := by
  intro p hp
  have h : env22599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22598_22599 : H12AffineEnvironment.transform 5 49 env22598 = env22599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env22598 == env22599) = true)

theorem identity22599 : scanCanonicalize (H12AffineFastState.compose env22599 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 541) := by decide +kernel

theorem selectedBound22599 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env22600 : List Nat := [2,4,8,16,32,49,8,5,512,541,554,570,8,34,0,2,51,554,540,1,522,1,17,35,8,49,523,50,570,554,572,33,4,32,34,512]

theorem envBound22600 : H12AffineFastState.Bounded env22600 := by
  intro p hp
  have h : env22600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22599_22600 : H12AffineEnvironment.transform 9 541 env22599 = env22600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 541 env22599 == env22600) = true)

theorem identity22600 : scanCanonicalize (H12AffineFastState.compose env22600 (packedSelected [0,2,8] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound22600 : packedSelected [0,2,8] rootPS < 2^1333 := by decide +kernel

def env22601 : List Nat := [2,4,8,16,32,49,8,5,8,21,34,50,8,34,0,2,51,34,20,1,2,1,17,35,8,49,3,50,50,34,52,33,4,32,34,8]

theorem envBound22601 : H12AffineFastState.Bounded env22601 := by
  intro p hp
  have h : env22601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22600_22601 : H12AffineEnvironment.transform 8 8 env22600 = env22601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env22600 == env22601) = true)

theorem identity22601 : scanCanonicalize (H12AffineFastState.compose env22601 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22601 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22602 : List Nat := [2,4,8,16,1,16,8,5,8,21,3,19,8,3,0,2,18,3,20,1,2,1,17,2,8,16,3,19,19,3,21,0,4,1,3,8]

theorem envBound22602 : H12AffineFastState.Bounded env22602 := by
  intro p hp
  have h : env22602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22601_22602 : H12AffineEnvironment.transform 4 1 env22601 = env22602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22601 == env22602) = true)

theorem identity22602 : scanCanonicalize (H12AffineFastState.compose env22602 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound22602 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22603 : List Nat := [2,4,8,4,1,4,8,5,8,1,3,7,8,3,0,2,6,3,0,1,2,1,5,2,8,4,3,7,7,3,1,0,4,1,3,8]

theorem envBound22603 : H12AffineFastState.Bounded env22603 := by
  intro p hp
  have h : env22603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22602_22603 : H12AffineEnvironment.transform 3 4 env22602 = env22603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env22602 == env22603) = true)

def env22604 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,65536,16401,262144,1025,21760,4160,272393,16,87124,8192,64,10588,5393,17664,283904,1364,264533,257,21792,24844,74251]

theorem envBound22604 : H12AffineFastState.Bounded env22604 := by
  intro p hp
  have h : env22604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22590_22604 : H12AffineEnvironment.transform 14 21761 env22590 = env22604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env22590 == env22604) = true)

theorem identity22604 : scanCanonicalize (H12AffineFastState.compose env22604 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound22604 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22605 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,21590,16401,262144,1025,21760,4160,272393,16,2,8192,64,10588,5393,17664,283904,1364,264533,257,21792,24844,30301]

theorem envBound22605 : H12AffineFastState.Bounded env22605 := by
  intro p hp
  have h : env22605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22604_22605 : H12AffineEnvironment.transform 15 21590 env22604 = env22605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env22604 == env22605) = true)

theorem identity22605 : scanCanonicalize (H12AffineFastState.compose env22605 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound22605 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env22606 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,21590,16401,2421,1025,21760,4160,8572,16,2,8192,64,10588,5393,17664,23669,1364,32,257,21792,24844,30301]

theorem envBound22606 : H12AffineFastState.Bounded env22606 := by
  intro p hp
  have h : env22606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22605_22606 : H12AffineEnvironment.transform 17 2421 env22605 = env22606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env22605 == env22606) = true)

theorem identity22606 : scanCanonicalize (H12AffineFastState.compose env22606 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound22606 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env22607 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,16384,21541,21590,16401,2129,1025,21540,4160,8280,16,2,8192,64,10360,5173,17444,23669,1136,32,37,21508,24616,30301]

theorem envBound22607 : H12AffineFastState.Bounded env22607 := by
  intro p hp
  have h : env22607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22606_22607 : H12AffineEnvironment.transform 7 36 env22606 = env22607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env22606 == env22607) = true)

theorem identity22607 : scanCanonicalize (H12AffineFastState.compose env22607 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound22607 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env22608 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,13405,8312,8203,13388,2129,1025,8313,4160,8280,16,2,8192,64,10360,5173,12409,10280,1136,32,37,8281,5237,512]

theorem envBound22608 : H12AffineFastState.Bounded env22608 := by
  intro p hp
  have h : env22608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22607_22608 : H12AffineEnvironment.transform 13 13405 env22607 = env22608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env22607 == env22608) = true)

theorem identity22608 : scanCanonicalize (H12AffineFastState.compose env22608 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound22608 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22609 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8,5205,112,3,5188,2129,1025,113,4160,80,16,2,8,64,2160,5173,4209,2080,1136,32,37,81,5237,512]

theorem envBound22609 : H12AffineFastState.Bounded env22609 := by
  intro p hp
  have h : env22609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22608_22609 : H12AffineEnvironment.transform 12 8 env22608 = env22609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env22608 == env22609) = true)

theorem identity22609 : scanCanonicalize (H12AffineFastState.compose env22609 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1604) := by decide +kernel

theorem selectedBound22609 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env22610 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,1604,8,529,112,3,512,2129,1025,113,1540,80,16,2,8,64,2160,625,1589,2080,1136,32,37,81,561,512]

theorem envBound22610 : H12AffineFastState.Bounded env22610 := by
  intro p hp
  have h : env22610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22609_22610 : H12AffineEnvironment.transform 11 1604 env22609 = env22610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1604 env22609 == env22610) = true)

theorem identity22610 : scanCanonicalize (H12AffineFastState.compose env22610 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22610 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env22611 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,1557,8,529,33,3,512,2048,1025,32,1540,1,16,2,8,17,2081,544,1589,2080,1057,32,37,0,561,512]

theorem envBound22611 : H12AffineFastState.Bounded env22611 := by
  intro p hp
  have h : env22611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22610_22611 : H12AffineEnvironment.transform 5 17 env22610 = env22611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22610 == env22611) = true)

theorem identity22611 : scanCanonicalize (H12AffineFastState.compose env22611 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22611 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env22612 : List Nat := [2,4,8,16,1,17,8,5,512,1024,2048,1557,8,529,0,3,512,2048,1025,1,1540,1,16,2,8,17,2048,513,1556,2049,1024,1,4,0,528,512]

theorem envBound22612 : H12AffineFastState.Bounded env22612 := by
  intro p hp
  have h : env22612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22611_22612 : H12AffineEnvironment.transform 4 1 env22611 = env22612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22611 == env22612) = true)

theorem identity22612 : scanCanonicalize (H12AffineFastState.compose env22612 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22612 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22613 : List Nat := [2,4,8,1,1,0,8,5,512,1024,2048,1540,8,512,0,3,512,2048,1025,1,1540,1,1,2,8,0,2048,513,1541,2049,1024,1,4,0,513,512]

theorem envBound22613 : H12AffineFastState.Bounded env22613 := by
  intro p hp
  have h : env22613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22612_22613 : H12AffineEnvironment.transform 3 1 env22612 = env22613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22612 == env22613) = true)

theorem identity22613 : scanCanonicalize (H12AffineFastState.compose env22613 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound22613 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22614 : List Nat := [2,4,8,1,1,0,8,5,512,4,2048,512,8,512,0,3,512,2048,5,1,512,1,1,2,8,0,2048,513,513,2049,4,1,4,0,513,512]

theorem envBound22614 : H12AffineFastState.Bounded env22614 := by
  intro p hp
  have h : env22614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22613_22614 : H12AffineEnvironment.transform 9 4 env22613 = env22614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env22613 == env22614) = true)

theorem identity22614 : scanCanonicalize (H12AffineFastState.compose env22614 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound22614 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22615 : List Nat := [2,4,8,1,1,0,8,5,1,4,2048,1,8,1,0,3,1,2048,5,1,1,1,1,2,8,0,2048,0,0,2049,4,1,4,0,0,1]

theorem envBound22615 : H12AffineFastState.Bounded env22615 := by
  intro p hp
  have h : env22615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22614_22615 : H12AffineEnvironment.transform 8 1 env22614 = env22615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env22614 == env22615) = true)

theorem identity22615 : scanCanonicalize (H12AffineFastState.compose env22615 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound22615 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22616 : List Nat := [2,4,7,1,1,0,7,5,1,4,2048,1,7,1,0,3,1,2048,5,1,1,1,1,2,7,0,2048,0,0,2049,4,1,4,0,0,1]

theorem envBound22616 : H12AffineFastState.Bounded env22616 := by
  intro p hp
  have h : env22616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22615_22616 : H12AffineEnvironment.transform 2 7 env22615 = env22616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env22615 == env22616) = true)

theorem identity22616 : scanCanonicalize (H12AffineFastState.compose env22616 (packedSelected [7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound22616 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env22617 : List Nat := [2,4,7,1,1,0,7,5,1,4,1,1,7,1,0,3,1,1,5,1,1,1,1,2,7,0,1,0,0,0,4,1,4,0,0,1]

theorem envBound22617 : H12AffineFastState.Bounded env22617 := by
  intro p hp
  have h : env22617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22616_22617 : H12AffineEnvironment.transform 10 1 env22616 = env22617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env22616 == env22617) = true)

def env22618 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,272392,169216,98644,8193,64,64605,163841,17664,283904,168005,411973,257,21792,46092,243483]

theorem envBound22618 : H12AffineFastState.Bounded env22618 := by
  intro p hp
  have h : env22618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22588_22618 : H12AffineEnvironment.transform 6 9 env22588 = env22618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22588 == env22618) = true)

theorem identity22618 : scanCanonicalize (H12AffineFastState.compose env22618 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 111898) := by decide +kernel

theorem selectedBound22618 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env22619 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,111898,262144,1025,32769,77898,272392,73754,98644,8193,64,64605,79131,17664,283904,75103,392287,257,21792,46092,513]

theorem envBound22619 : H12AffineFastState.Bounded env22619 := by
  intro p hp
  have h : env22619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22618_22619 : H12AffineEnvironment.transform 16 111898 env22618 = env22619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111898 env22618 == env22619) = true)

theorem identity22619 : scanCanonicalize (H12AffineFastState.compose env22619 (packedSelected [0,2,3,4,6,9,10,11,17,20,24,26,27,32] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound22619 : packedSelected [0,2,3,4,6,9,10,11,17,20,24,26,27,32] rootPS < 2^1333 := by decide +kernel

def env22620 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38160,262144,1025,32769,4160,272392,16,41310,8193,64,64605,5393,17664,283904,1365,318549,257,21792,46092,513]

theorem envBound22620 : H12AffineFastState.Bounded env22620 := by
  intro p hp
  have h : env22620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22619_22620 : H12AffineEnvironment.transform 15 8202 env22619 = env22620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env22619 == env22620) = true)

theorem identity22620 : scanCanonicalize (H12AffineFastState.compose env22620 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound22620 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env22621 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,8202,16401,262144,1025,21760,4160,272392,16,29791,8193,64,10588,5393,17664,283904,1365,264532,257,21792,24845,513]

theorem envBound22621 : H12AffineFastState.Bounded env22621 := by
  intro p hp
  have h : env22621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22620_22621 : H12AffineEnvironment.transform 14 21761 env22620 = env22621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env22620 == env22621) = true)

theorem identity22621 : scanCanonicalize (H12AffineFastState.compose env22621 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound22621 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env22622 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8540,8202,13388,262144,1025,8541,4160,272392,16,2,8193,64,10588,5393,12637,270685,1365,264532,257,8573,5456,513]

theorem envBound22622 : H12AffineFastState.Bounded env22622 := by
  intro p hp
  have h : env22622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22621_22622 : H12AffineEnvironment.transform 13 13405 env22621 = env22622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env22621 == env22622) = true)

theorem identity22622 : scanCanonicalize (H12AffineFastState.compose env22622 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 10508) := by decide +kernel

theorem selectedBound22622 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env22623 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8540,8202,13388,10508,1025,8541,4160,260,16,2,8193,64,10588,5393,12637,2129,1365,8280,257,8573,5456,513]

theorem envBound22623 : H12AffineFastState.Bounded env22623 := by
  intro p hp
  have h : env22623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22622_22623 : H12AffineEnvironment.transform 17 10508 env22622 = env22623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10508 env22622 == env22623) = true)

theorem identity22623 : scanCanonicalize (H12AffineFastState.compose env22623 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound22623 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env22624 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,4113,1296,1094,4096,3392,1025,1297,4160,260,16,2,1101,64,3344,5393,5393,2129,1365,1044,257,1329,5456,513]

theorem envBound22624 : H12AffineFastState.Bounded env22624 := by
  intro p hp
  have h : env22624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22623_22624 : H12AffineEnvironment.transform 12 1100 env22623 = env22624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env22623 == env22624) = true)

theorem identity22624 : scanCanonicalize (H12AffineFastState.compose env22624 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound22624 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22625 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,356,1100,373,1296,1094,356,3392,1025,1297,292,260,16,2,1101,64,3344,1141,1141,2129,1365,1044,257,1329,1076,513]

theorem envBound22625 : H12AffineFastState.Bounded env22625 := by
  intro p hp
  have h : env22625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22624_22625 : H12AffineEnvironment.transform 11 356 env22624 = env22625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env22624 == env22625) = true)

theorem identity22625 : scanCanonicalize (H12AffineFastState.compose env22625 (packedSelected [0,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound22625 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env22626 : List Nat := [2,4,8,16,32,64,9,256,512,1024,80,356,1100,373,1296,1094,356,1296,1025,1297,292,260,16,2,1101,64,1344,1141,1141,1,1365,1044,257,1329,1076,513]

theorem envBound22626 : H12AffineFastState.Bounded env22626 := by
  intro p hp
  have h : env22626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22625_22626 : H12AffineEnvironment.transform 10 80 env22625 = env22626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env22625 == env22626) = true)

theorem identity22626 : scanCanonicalize (H12AffineFastState.compose env22626 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound22626 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env22627 : List Nat := [2,4,8,16,32,64,9,256,512,53,80,356,121,373,293,115,356,293,52,292,292,260,16,2,120,64,373,64,64,1,352,33,257,260,1,513]

theorem envBound22627 : H12AffineFastState.Bounded env22627 := by
  intro p hp
  have h : env22627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22626_22627 : H12AffineEnvironment.transform 9 53 env22626 = env22627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env22626 == env22627) = true)

theorem identity22627 : scanCanonicalize (H12AffineFastState.compose env22627 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound22627 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env22628 : List Nat := [2,4,8,16,32,64,9,37,512,53,80,65,121,80,0,115,65,0,52,1,1,33,16,2,120,64,80,64,64,1,69,33,36,33,1,513]

theorem envBound22628 : H12AffineFastState.Bounded env22628 := by
  intro p hp
  have h : env22628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22627_22628 : H12AffineEnvironment.transform 7 37 env22627 = env22628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env22627 == env22628) = true)

theorem identity22628 : scanCanonicalize (H12AffineFastState.compose env22628 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22628 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22629 : List Nat := [2,4,8,16,32,16,9,37,512,53,0,17,41,0,0,35,17,0,52,1,1,33,16,2,40,16,0,16,16,1,21,33,36,33,1,513]

theorem envBound22629 : H12AffineFastState.Bounded env22629 := by
  intro p hp
  have h : env22629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22628_22629 : H12AffineEnvironment.transform 5 16 env22628 = env22629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22628 == env22629) = true)

theorem identity22629 : scanCanonicalize (H12AffineFastState.compose env22629 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound22629 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22630 : List Nat := [2,4,8,16,32,16,9,37,0,53,0,17,41,0,0,35,17,0,52,1,1,33,16,2,40,16,0,16,16,1,21,33,36,33,1,1]

theorem envBound22630 : H12AffineFastState.Bounded env22630 := by
  intro p hp
  have h : env22630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22629_22630 : H12AffineEnvironment.transform 8 0 env22629 = env22630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env22629 == env22630) = true)

theorem identity22630 : scanCanonicalize (H12AffineFastState.compose env22630 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound22630 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22631 : List Nat := [2,4,2,16,32,16,3,37,0,53,0,17,35,0,0,35,17,0,52,1,1,33,16,2,34,16,0,16,16,1,21,33,36,33,1,1]

theorem envBound22631 : H12AffineFastState.Bounded env22631 := by
  intro p hp
  have h : env22631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22630_22631 : H12AffineEnvironment.transform 2 2 env22630 = env22631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env22630 == env22631) = true)

def env22632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,4194304,169217,98780,8328,64,4510940,163840,17665,283905,168140,4350284,257,21792,46213,243483]

theorem envBound22632 : H12AffineFastState.Bounded env22632 := by
  intro p hp
  have h : env22632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22583_22632 : H12AffineEnvironment.transform 22 169217 env22583 = env22632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169217 env22583 == env22632) = true)

def env22633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,272512,169217,98780,8328,64,64604,163840,17665,283905,168140,412108,257,21792,46213,243483]

theorem envBound22633 : H12AffineFastState.Bounded env22633 := by
  intro p hp
  have h : env22633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22632_22633 : H12AffineEnvironment.transform 21 272512 env22632 = env22633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env22632 == env22633) = true)

theorem identity22633 : scanCanonicalize (H12AffineFastState.compose env22633 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 25028) := by decide +kernel

theorem selectedBound22633 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22634 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,58516,272512,62661,98780,8328,64,64604,57796,17665,283905,61704,272392,257,21792,46213,120543]

theorem envBound22634 : H12AffineFastState.Bounded env22634 := by
  intro p hp
  have h : env22634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22633_22634 : H12AffineEnvironment.transform 16 25028 env22633 = env22634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25028 env22633 == env22634) = true)

def env22635 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,10280,1025,32769,58516,168,62661,98780,8328,64,64604,57796,17665,32041,61704,32,257,21792,46213,120543]

theorem envBound22635 : H12AffineFastState.Bounded env22635 := by
  intro p hp
  have h : env22635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22634_22635 : H12AffineEnvironment.transform 17 10280 env22634 = env22635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env22634 == env22635) = true)

theorem identity22635 : scanCanonicalize (H12AffineFastState.compose env22635 (packedSelected [0,2,4,6,8,9,16,23,27,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 28728) := by decide +kernel

theorem selectedBound22635 : packedSelected [0,2,4,6,8,9,16,23,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env22636 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,28728,65536,25028,10280,1025,28729,5292,168,1277,94692,8328,64,3172,4604,17665,32041,304,32,257,21792,17597,75495]

theorem envBound22636 : H12AffineFastState.Bounded env22636 := by
  intro p hp
  have h : env22636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22635_22636 : H12AffineEnvironment.transform 14 28728 env22635 = env22636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28728 env22635 == env22636) = true)

theorem identity22636 : scanCanonicalize (H12AffineFastState.compose env22636 (packedSelected [0,1,2,4,5,6,9,11,12,15,16,17,18,19,24,26,27,28,31,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound22636 : packedSelected [0,1,2,4,5,6,9,11,12,15,16,17,18,19,24,26,27,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env22637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,1260,65536,5392,10280,1025,1261,5292,168,1277,66864,8328,64,3172,4604,12757,2557,304,32,257,8692,12393,75495]

theorem envBound22637 : H12AffineFastState.Bounded env22637 := by
  intro p hp
  have h : env22637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22636_22637 : H12AffineEnvironment.transform 13 13524 env22636 = env22637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env22636 == env22637) = true)

theorem identity22637 : scanCanonicalize (H12AffineFastState.compose env22637 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound22637 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env22638 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1337,4589,1260,65536,5392,3345,1025,1261,5292,168,1277,66864,1457,64,3172,4604,5356,2557,304,32,257,1229,5456,66526]

theorem envBound22638 : H12AffineFastState.Bounded env22638 := by
  intro p hp
  have h : env22638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22637_22638 : H12AffineEnvironment.transform 12 1337 env22637 = env22638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env22637 == env22638) = true)

theorem identity22638 : scanCanonicalize (H12AffineFastState.compose env22638 (packedSelected [0,3,4,5,7,10,22] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound22638 : packedSelected [0,3,4,5,7,10,22] rootPS < 2^1333 := by decide +kernel

def env22639 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1337,4589,1260,35,5392,3345,1025,1261,5292,168,1277,1299,1457,64,3172,4604,5356,2557,304,32,257,1229,5456,1021]

theorem envBound22639 : H12AffineFastState.Bounded env22639 := by
  intro p hp
  have h : env22639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22638_22639 : H12AffineEnvironment.transform 15 35 env22638 = env22639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env22638 == env22639) = true)

theorem identity22639 : scanCanonicalize (H12AffineFastState.compose env22639 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound22639 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env22640 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,1221,4113,1260,35,5356,3309,1025,1261,5292,168,1277,1263,1101,64,3172,4096,5356,2049,204,32,253,1229,5292,513]

theorem envBound22640 : H12AffineFastState.Bounded env22640 := by
  intro p hp
  have h : env22640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22639_22640 : H12AffineEnvironment.transform 7 252 env22639 = env22640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env22639 == env22640) = true)

theorem identity22640 : scanCanonicalize (H12AffineFastState.compose env22640 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound22640 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22641 : List Nat := [2,4,8,16,32,64,128,252,512,236,2048,4096,41,4113,0,35,4096,2049,237,1,4160,168,17,3,161,64,2184,4096,4096,2049,204,32,253,33,4160,513]

theorem envBound22641 : H12AffineFastState.Bounded env22641 := by
  intro p hp
  have h : env22641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22640_22641 : H12AffineEnvironment.transform 9 236 env22640 = env22641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env22640 == env22641) = true)

theorem identity22641 : scanCanonicalize (H12AffineFastState.compose env22641 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 249) := by decide +kernel

theorem selectedBound22641 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22642 : List Nat := [2,4,8,16,32,64,128,252,512,236,2048,249,41,232,0,35,249,2049,237,1,185,168,17,3,161,64,2184,249,249,2049,204,32,253,33,185,513]

theorem envBound22642 : H12AffineFastState.Bounded env22642 := by
  intro p hp
  have h : env22642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22641_22642 : H12AffineEnvironment.transform 11 249 env22641 = env22642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 249 env22641 == env22642) = true)

theorem identity22642 : scanCanonicalize (H12AffineFastState.compose env22642 (packedSelected [1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 169) := by decide +kernel

theorem selectedBound22642 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env22643 : List Nat := [2,4,8,16,32,64,128,252,169,236,2048,249,41,232,0,35,249,2049,237,1,185,168,17,3,161,64,2184,249,249,2049,204,32,253,33,185,168]

theorem envBound22643 : H12AffineFastState.Bounded env22643 := by
  intro p hp
  have h : env22643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22642_22643 : H12AffineEnvironment.transform 8 169 env22642 = env22643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env22642 == env22643) = true)

theorem identity22643 : scanCanonicalize (H12AffineFastState.compose env22643 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound22643 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22644 : List Nat := [2,4,8,16,32,64,88,36,113,52,2048,33,41,48,0,35,33,2049,53,1,97,112,17,3,121,64,2128,33,33,2049,20,32,37,33,97,112]

theorem envBound22644 : H12AffineFastState.Bounded env22644 := by
  intro p hp
  have h : env22644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22643_22644 : H12AffineEnvironment.transform 6 88 env22643 = env22644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env22643 == env22644) = true)

theorem identity22644 : scanCanonicalize (H12AffineFastState.compose env22644 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound22644 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22645 : List Nat := [2,4,8,16,32,32,56,36,17,52,2048,33,41,48,0,35,33,2049,53,1,1,16,17,3,25,32,2096,33,33,2049,20,32,37,33,1,16]

theorem envBound22645 : H12AffineFastState.Bounded env22645 := by
  intro p hp
  have h : env22645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22644_22645 : H12AffineEnvironment.transform 5 32 env22644 = env22645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env22644 == env22645) = true)

theorem identity22645 : scanCanonicalize (H12AffineFastState.compose env22645 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22645 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22646 : List Nat := [2,4,8,16,1,1,25,5,17,21,2048,0,8,17,0,2,0,2049,20,1,1,16,17,3,25,1,2065,0,0,2049,20,1,4,0,1,16]

theorem envBound22646 : H12AffineFastState.Bounded env22646 := by
  intro p hp
  have h : env22646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22645_22646 : H12AffineEnvironment.transform 4 1 env22645 = env22646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22645 == env22646) = true)

theorem identity22646 : scanCanonicalize (H12AffineFastState.compose env22646 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22646 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env22647 : List Nat := [2,4,8,1,1,1,8,5,0,4,2048,0,8,0,0,2,0,2049,5,1,1,1,0,3,8,1,2048,0,0,2049,5,1,4,0,1,1]

theorem envBound22647 : H12AffineFastState.Bounded env22647 := by
  intro p hp
  have h : env22647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22646_22647 : H12AffineEnvironment.transform 3 1 env22646 = env22647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22646 == env22647) = true)

theorem identity22647 : scanCanonicalize (H12AffineFastState.compose env22647 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound22647 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22648 : List Nat := [2,4,8,1,1,1,8,5,0,4,1,0,8,0,0,2,0,0,5,1,1,1,0,3,8,1,1,0,0,0,5,1,4,0,1,1]

theorem envBound22648 : H12AffineFastState.Bounded env22648 := by
  intro p hp
  have h : env22648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22647_22648 : H12AffineEnvironment.transform 10 1 env22647 = env22648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env22647 == env22648) = true)

def env22649 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,10281,1025,32769,58516,169,62661,98780,8328,64,64604,57796,17665,32040,61704,33,257,21792,46213,120543]

theorem envBound22649 : H12AffineFastState.Bounded env22649 := by
  intro p hp
  have h : env22649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22634_22649 : H12AffineEnvironment.transform 17 10281 env22634 = env22649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env22634 == env22649) = true)

theorem identity22649 : scanCanonicalize (H12AffineFastState.compose env22649 (packedSelected [0,2,4,6,8,9,16,23,27,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound22649 : packedSelected [0,2,4,6,8,9,16,23,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env22650 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,29963,25028,10281,1025,32769,58516,169,62661,62679,8328,64,64604,57796,17665,32040,61704,33,257,21792,46213,41940]

theorem envBound22650 : H12AffineFastState.Bounded env22650 := by
  intro p hp
  have h : env22650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22649_22650 : H12AffineEnvironment.transform 15 29963 env22649 = env22650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env22649 == env22650) = true)

theorem identity22650 : scanCanonicalize (H12AffineFastState.compose env22650 (packedSelected [0,2,3,4,5,6,9,10,11,16,17,18,27] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound22650 : packedSelected [0,2,3,4,5,6,9,10,11,16,17,18,27] rootPS < 2^1333 := by decide +kernel

def env22651 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,29963,25028,10281,1025,8541,17864,169,21913,21899,8328,64,23808,16536,17665,32040,20564,33,257,21792,5593,648]

theorem envBound22651 : H12AffineFastState.Bounded env22651 := by
  intro p hp
  have h : env22651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22650_22651 : H12AffineEnvironment.transform 14 8540 env22650 = env22651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env22650 == env22651) = true)

theorem identity22651 : scanCanonicalize (H12AffineFastState.compose env22651 (packedSelected [0,1,2,3,5,6,7,8,12,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound22651 : packedSelected [0,1,2,3,5,6,7,8,12,16] rootPS < 2^1333 := by decide +kernel

def env22652 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,1,21590,16537,2420,1025,0,17864,169,21913,21899,469,64,23808,16536,17665,23669,20564,33,257,21792,5593,648]

theorem envBound22652 : H12AffineFastState.Bounded env22652 := by
  intro p hp
  have h : env22652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22651_22652 : H12AffineEnvironment.transform 12 349 env22651 = env22652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env22651 == env22652) = true)

theorem identity22652 : scanCanonicalize (H12AffineFastState.compose env22652 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound22652 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env22653 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5457,1,263,5576,2420,1025,0,4249,169,200,218,469,64,2129,5577,4176,2340,1285,33,257,113,5593,648]

theorem envBound22653 : H12AffineFastState.Bounded env22653 := by
  intro p hp
  have h : env22653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22652_22653 : H12AffineEnvironment.transform 13 5457 env22652 = env22653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env22652 == env22653) = true)

def env22654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,272513,169217,98780,8328,64,64605,163840,17665,283905,168140,412109,257,21792,46213,243483]

theorem envBound22654 : H12AffineFastState.Bounded env22654 := by
  intro p hp
  have h : env22654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22632_22654 : H12AffineEnvironment.transform 21 272513 env22632 = env22654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env22632 == env22654) = true)

theorem identity22654 : scanCanonicalize (H12AffineFastState.compose env22654 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound22654 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,160132,272513,156117,95496,8328,64,2185,160980,17665,283905,156696,412109,257,21792,16465,213967]

theorem envBound22655 : H12AffineFastState.Bounded env22655 := by
  intro p hp
  have h : env22655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22654_22655 : H12AffineEnvironment.transform 14 29908 env22654 = env22655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env22654 == env22655) = true)

def env22656 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,160012,272393,155997,95496,8192,64,2049,160860,17665,283905,156696,411973,257,21792,16465,213831]

theorem envBound22656 : H12AffineFastState.Bounded env22656 := by
  intro p hp
  have h : env22656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22655_22656 : H12AffineEnvironment.transform 6 8 env22655 = env22656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22655 == env22656) = true)

theorem identity22656 : scanCanonicalize (H12AffineFastState.compose env22656 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 97406) := by decide +kernel

theorem selectedBound22656 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env22657 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,97406,1025,29789,160012,87159,155997,95496,8192,64,2049,160860,17665,76159,156696,210235,257,21792,16465,213831]

theorem envBound22657 : H12AffineFastState.Bounded env22657 := by
  intro p hp
  have h : env22657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22656_22657 : H12AffineEnvironment.transform 17 97406 env22656 = env22657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97406 env22656 == env22657) = true)

theorem identity22657 : scanCanonicalize (H12AffineFastState.compose env22657 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound22657 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env22658 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,65536,131072,89379,1025,21760,151633,87159,147456,87125,349,64,2049,152833,17665,67618,148805,201830,257,21792,16465,213831]

theorem envBound22658 : H12AffineFastState.Bounded env22658 := by
  intro p hp
  have h : env22658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22657_22658 : H12AffineEnvironment.transform 12 349 env22657 = env22658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env22657 == env22658) = true)

theorem identity22658 : scanCanonicalize (H12AffineFastState.compose env22658 (packedSelected [1,7,8,12,14,15,16,19,27] rootPS)) = affineNative (2^(16+1) ^^^ 82019) := by decide +kernel

theorem selectedBound22658 : packedSelected [1,7,8,12,14,15,16,19,27] rootPS < 2^1333 := by decide +kernel

def env22659 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,65536,82019,89379,1025,21760,69682,87159,65635,87125,349,64,2049,71010,17665,67618,66854,21509,257,21792,16465,804]

theorem envBound22659 : H12AffineFastState.Bounded env22659 := by
  intro p hp
  have h : env22659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22658_22659 : H12AffineEnvironment.transform 16 82019 env22658 = env22659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82019 env22658 == env22659) = true)

theorem identity22659 : scanCanonicalize (H12AffineFastState.compose env22659 (packedSelected [3,5,10,12,15,16,17,18,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound22659 : packedSelected [3,5,10,12,15,16,17,18,20,23] rootPS < 2^1333 := by decide +kernel

def env22660 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5237,372,65536,70678,67926,1025,373,69682,65538,65635,65568,349,64,2049,71010,4468,67618,66854,112,257,341,5156,804]

theorem envBound22660 : H12AffineFastState.Bounded env22660 := by
  intro p hp
  have h : env22660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22659_22660 : H12AffineEnvironment.transform 13 5237 env22659 = env22660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env22659 == env22660) = true)

theorem identity22660 : scanCanonicalize (H12AffineFastState.compose env22660 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound22660 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env22661 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,5237,80,65536,70678,67698,1025,81,69682,65538,65635,65568,121,64,2049,70726,4176,67618,66562,112,37,113,5156,512]

theorem envBound22661 : H12AffineFastState.Bounded env22661 := by
  intro p hp
  have h : env22661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22660_22661 : H12AffineEnvironment.transform 7 36 env22660 = env22661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env22660 == env22661) = true)

theorem identity22661 : scanCanonicalize (H12AffineFastState.compose env22661 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22661 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22662 : List Nat := [2,4,8,16,1,64,8,5,512,1024,2048,4096,88,5204,80,65536,70678,67667,1025,81,69651,65538,65602,65537,88,64,2049,70726,4176,67587,66562,81,4,80,5125,512]

theorem envBound22662 : H12AffineFastState.Bounded env22662 := by
  intro p hp
  have h : env22662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22661_22662 : H12AffineEnvironment.transform 4 1 env22661 = env22662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22661 == env22662) = true)

theorem identity22662 : scanCanonicalize (H12AffineFastState.compose env22662 (packedSelected [3,5,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22662 : packedSelected [3,5,10,11,12] rootPS < 2^1333 := by decide +kernel

def env22663 : List Nat := [2,4,8,16,1,17,8,5,512,1024,2048,4096,9,5125,1,65536,70678,67586,1025,0,69651,65538,65555,65537,9,17,2049,70679,4097,67587,66562,0,4,1,5125,512]

theorem envBound22663 : H12AffineFastState.Bounded env22663 := by
  intro p hp
  have h : env22663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22662_22663 : H12AffineEnvironment.transform 5 17 env22662 = env22663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22662 == env22663) = true)

theorem identity22663 : scanCanonicalize (H12AffineFastState.compose env22663 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound22663 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env22664 : List Nat := [2,4,8,16,1,17,8,5,512,1024,2048,4096,9,5125,1,2,5140,2048,1025,0,4113,0,17,3,9,17,2049,5141,4097,2049,1024,0,4,1,5125,512]

theorem envBound22664 : H12AffineFastState.Bounded env22664 := by
  intro p hp
  have h : env22664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22663_22664 : H12AffineEnvironment.transform 15 2 env22663 = env22664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env22663 == env22664) = true)

theorem identity22664 : scanCanonicalize (H12AffineFastState.compose env22664 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound22664 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22665 : List Nat := [2,4,8,16,1,17,8,5,512,1024,2048,1028,9,1,1,2,16,2048,1025,0,1045,0,17,3,9,17,2049,17,1029,2049,1024,0,4,1,1,512]

theorem envBound22665 : H12AffineFastState.Bounded env22665 := by
  intro p hp
  have h : env22665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22664_22665 : H12AffineEnvironment.transform 11 1028 env22664 = env22665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env22664 == env22665) = true)

theorem identity22665 : scanCanonicalize (H12AffineFastState.compose env22665 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound22665 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22666 : List Nat := [2,4,8,16,1,17,8,5,16,1024,2048,1028,9,1,1,2,16,2048,1025,0,1045,0,17,3,9,17,2049,17,1029,2049,1024,0,4,1,1,16]

theorem envBound22666 : H12AffineFastState.Bounded env22666 := by
  intro p hp
  have h : env22666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22665_22666 : H12AffineEnvironment.transform 8 16 env22665 = env22666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env22665 == env22666) = true)

theorem identity22666 : scanCanonicalize (H12AffineFastState.compose env22666 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound22666 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22667 : List Nat := [2,4,8,16,1,17,8,5,16,20,2048,16,9,1,1,2,16,2048,21,0,1,0,17,3,9,17,2049,17,17,2049,20,0,4,1,1,16]

theorem envBound22667 : H12AffineFastState.Bounded env22667 := by
  intro p hp
  have h : env22667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22666_22667 : H12AffineEnvironment.transform 9 20 env22666 = env22667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env22666 == env22667) = true)

theorem identity22667 : scanCanonicalize (H12AffineFastState.compose env22667 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound22667 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22668 : List Nat := [2,4,8,4,1,5,8,5,4,0,2048,4,9,1,1,2,4,2048,1,0,1,0,5,3,9,5,2049,5,5,2049,0,0,4,1,1,4]

theorem envBound22668 : H12AffineFastState.Bounded env22668 := by
  intro p hp
  have h : env22668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22667_22668 : H12AffineEnvironment.transform 3 4 env22667 = env22668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env22667 == env22668) = true)

theorem identity22668 : scanCanonicalize (H12AffineFastState.compose env22668 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound22668 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22669 : List Nat := [2,0,8,0,1,1,8,1,0,0,2048,0,9,1,1,2,0,2048,1,0,1,0,1,3,9,1,2049,1,1,2049,0,0,0,1,1,0]

theorem envBound22669 : H12AffineFastState.Bounded env22669 := by
  intro p hp
  have h : env22669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22668_22669 : H12AffineEnvironment.transform 1 0 env22668 = env22669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env22668 == env22669) = true)

theorem identity22669 : scanCanonicalize (H12AffineFastState.compose env22669 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound22669 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env22670 : List Nat := [2,0,8,0,1,1,8,1,0,0,1,0,9,1,1,2,0,1,1,0,1,0,1,3,9,1,0,1,1,0,0,0,0,1,1,0]

theorem envBound22670 : H12AffineFastState.Bounded env22670 := by
  intro p hp
  have h : env22670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22669_22670 : H12AffineEnvironment.transform 10 1 env22669 = env22670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env22669 == env22670) = true)

def env22671 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,160013,272392,155996,95496,8193,64,2048,160861,17665,283905,156696,411972,257,21792,16465,213830]

theorem envBound22671 : H12AffineFastState.Bounded env22671 := by
  intro p hp
  have h : env22671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22655_22671 : H12AffineEnvironment.transform 6 9 env22655 = env22671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22655 == env22671) = true)

theorem identity22671 : scanCanonicalize (H12AffineFastState.compose env22671 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound22671 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env22672 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10280,1025,29788,160013,32,155996,95496,8193,64,2048,160861,17665,32041,156696,156012,257,21792,16465,213830]

theorem envBound22672 : H12AffineFastState.Bounded env22672 := by
  intro p hp
  have h : env22672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22671_22672 : H12AffineEnvironment.transform 17 10280 env22671 = env22672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env22671 == env22672) = true)

theorem identity22672 : scanCanonicalize (H12AffineFastState.compose env22672 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound22672 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22673 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,131072,10280,1025,29788,160013,32,155996,21763,8193,64,2048,160861,17665,32041,156696,156012,257,21792,16465,156493]

theorem envBound22673 : H12AffineFastState.Bounded env22673 := by
  intro p hp
  have h : env22673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22672_22673 : H12AffineEnvironment.transform 15 8203 env22672 = env22673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env22672 == env22673) = true)

theorem identity22673 : scanCanonicalize (H12AffineFastState.compose env22673 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 25693) := by decide +kernel

theorem selectedBound22673 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22674 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,25693,10280,1025,29788,5456,32,1281,21763,8193,64,2048,4096,17665,32041,69,1329,257,21792,16465,1808]

theorem envBound22674 : H12AffineFastState.Bounded env22674 := by
  intro p hp
  have h : env22674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22673_22674 : H12AffineEnvironment.transform 16 25693 env22673 = env22674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25693 env22673 == env22674) = true)

theorem identity22674 : scanCanonicalize (H12AffineFastState.compose env22674 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound22674 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env22675 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,8232,8203,12328,10280,1025,8233,5456,32,1281,374,8193,64,2048,4096,4468,10588,69,1329,257,341,5156,1808]

theorem envBound22675 : H12AffineFastState.Bounded env22675 := by
  intro p hp
  have h : env22675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22674_22675 : H12AffineEnvironment.transform 13 5237 env22674 = env22675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env22674 == env22675) = true)

theorem identity22675 : scanCanonicalize (H12AffineFastState.compose env22675 (packedSelected [1,4,8,9,14,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound22675 : packedSelected [1,4,8,9,14,16,19] rootPS < 2^1333 := by decide +kernel

def env22676 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,5237,1125,1094,5221,3173,1025,1124,5456,32,1281,374,1100,64,2048,4096,4468,3345,69,1329,257,341,5156,1808]

theorem envBound22676 : H12AffineFastState.Bounded env22676 := by
  intro p hp
  have h : env22676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22675_22676 : H12AffineEnvironment.transform 12 1101 env22675 = env22676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env22675 == env22676) = true)

theorem identity22676 : scanCanonicalize (H12AffineFastState.compose env22676 (packedSelected [2,6,12,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound22676 : packedSelected [2,6,12,14,15] rootPS < 2^1333 := by decide +kernel

def env22677 : List Nat := [2,4,8,16,32,64,9,100,512,1024,2048,4096,1101,5237,1125,1094,5221,3173,1025,1124,5172,32,1125,18,1100,64,2048,4096,4112,3189,69,1109,101,49,5156,1652]

theorem envBound22677 : H12AffineFastState.Bounded env22677 := by
  intro p hp
  have h : env22677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22676_22677 : H12AffineEnvironment.transform 7 100 env22676 = env22677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env22676 == env22677) = true)

theorem identity22677 : scanCanonicalize (H12AffineFastState.compose env22677 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22677 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env22678 : List Nat := [2,4,8,16,1,64,9,69,512,1024,2048,4096,1101,5204,1092,1094,5188,3140,1025,1093,5141,1,1092,18,1100,64,2048,4096,4112,3156,69,1109,68,16,5125,1621]

theorem envBound22678 : H12AffineFastState.Bounded env22678 := by
  intro p hp
  have h : env22678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22677_22678 : H12AffineEnvironment.transform 4 1 env22677 = env22678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22677 == env22678) = true)

theorem identity22678 : scanCanonicalize (H12AffineFastState.compose env22678 (packedSelected [6,14] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound22678 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env22679 : List Nat := [2,4,8,16,1,64,9,69,512,69,2048,4096,8,4113,1,3,4097,2049,68,0,4176,1,1,18,9,64,2048,4096,4112,2065,69,16,68,16,4160,528]

theorem envBound22679 : H12AffineFastState.Bounded env22679 := by
  intro p hp
  have h : env22679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22678_22679 : H12AffineEnvironment.transform 9 69 env22678 = env22679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env22678 == env22679) = true)

theorem identity22679 : scanCanonicalize (H12AffineFastState.compose env22679 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22679 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22680 : List Nat := [2,4,8,16,1,16,9,21,512,21,2048,4096,8,4113,1,3,4097,2049,20,0,4096,1,1,18,9,16,2048,4096,4112,2065,21,16,20,16,4112,528]

theorem envBound22680 : H12AffineFastState.Bounded env22680 := by
  intro p hp
  have h : env22680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22679_22680 : H12AffineEnvironment.transform 5 16 env22679 = env22680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22679 == env22680) = true)

theorem identity22680 : scanCanonicalize (H12AffineFastState.compose env22680 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound22680 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env22681 : List Nat := [2,4,8,16,1,16,9,21,512,21,2048,513,8,528,1,3,512,2049,20,0,513,1,1,18,9,16,2048,513,529,2065,21,16,20,16,529,528]

theorem envBound22681 : H12AffineFastState.Bounded env22681 := by
  intro p hp
  have h : env22681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22680_22681 : H12AffineEnvironment.transform 11 513 env22680 = env22681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env22680 == env22681) = true)

theorem identity22681 : scanCanonicalize (H12AffineFastState.compose env22681 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound22681 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env22682 : List Nat := [2,4,8,16,1,16,9,21,16,21,2048,17,8,0,1,3,16,2049,20,0,17,1,1,18,9,16,2048,17,1,2065,21,16,20,16,1,0]

theorem envBound22682 : H12AffineFastState.Bounded env22682 := by
  intro p hp
  have h : env22682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22681_22682 : H12AffineEnvironment.transform 8 16 env22681 = env22682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env22681 == env22682) = true)

theorem identity22682 : scanCanonicalize (H12AffineFastState.compose env22682 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound22682 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22683 : List Nat := [2,4,8,16,1,16,9,21,16,21,1,17,8,0,1,3,16,0,20,0,17,1,1,18,9,16,1,17,1,16,21,16,20,16,1,0]

theorem envBound22683 : H12AffineFastState.Bounded env22683 := by
  intro p hp
  have h : env22683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22682_22683 : H12AffineEnvironment.transform 10 1 env22682 = env22683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env22682 == env22683) = true)

def env22684 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507600,9356288,25265169,23160257,525568,27902125,27337992,25733063]

theorem envBound22684 : H12AffineFastState.Bounded env22684 := by
  intro p hp
  have h : env22684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22302_22684 : H12AffineEnvironment.transform 26 30393345 env22302 = env22684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env22302 == env22684) = true)

def env22685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830976,25265169,23160257,256,27378861,27337992,25207751]

theorem envBound22685 : H12AffineFastState.Bounded env22685 := by
  intro p hp
  have h : env22685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22684_22685 : H12AffineEnvironment.transform 18 1024 env22684 = env22685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env22684 == env22685) = true)

theorem identity22685 : scanCanonicalize (H12AffineFastState.compose env22685 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound22685 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env22686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,16777216,8328,64,21479441,18973837,2118976,442384,16876545,23160257,256,18990269,18949400,16819159]

theorem envBound22686 : H12AffineFastState.Bounded env22686 := by
  intro p hp
  have h : env22686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22685_22686 : H12AffineEnvironment.transform 22 16 env22685 = env22686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env22685 == env22686) = true)

def env22687 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,16777216,8192,64,21479441,18973701,2118976,442384,16876545,23160137,256,18990133,18949400,16819039]

theorem envBound22687 : H12AffineFastState.Bounded env22687 := by
  intro p hp
  have h : env22687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22686_22687 : H12AffineEnvironment.transform 6 8 env22686 = env22687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22686 == env22687) = true)

theorem identity22687 : scanCanonicalize (H12AffineFastState.compose env22687 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 2) := by decide +kernel

theorem selectedBound22687 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env22688 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,2,8192,64,4702227,2196487,2118976,442384,99331,6382923,256,2212919,2172186,41821]

theorem envBound22688 : H12AffineFastState.Bounded env22688 := by
  intro p hp
  have h : env22688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22687_22688 : H12AffineEnvironment.transform 23 2 env22687 = env22688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2 env22687 == env22688) = true)

def env22689 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,4194304,16,2,8192,64,4554755,2196487,2118976,294912,99331,6382923,256,2212919,2172186,41821]

theorem envBound22689 : H12AffineFastState.Bounded env22689 := by
  intro p hp
  have h : env22689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22688_22689 : H12AffineEnvironment.transform 16 16400 env22688 = env22689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env22688 == env22689) = true)

theorem identity22689 : scanCanonicalize (H12AffineFastState.compose env22689 (packedSelected [0,1,4,5,7,8,12,15,16,19,20,22,24,26,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 41341) := by decide +kernel

theorem selectedBound22689 : packedSelected [0,1,4,5,7,8,12,15,16,19,20,22,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env22690 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,41341,16,2,8192,64,336254,2196487,2118976,294912,99331,2212918,256,2212919,2172186,41821]

theorem envBound22690 : H12AffineFastState.Bounded env22690 := by
  intro p hp
  have h : env22690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22689_22690 : H12AffineEnvironment.transform 21 41341 env22689 = env22690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41341 env22689 == env22690) = true)

theorem identity22690 : scanCanonicalize (H12AffineFastState.compose env22690 (packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound22690 : packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env22691 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1024,32769,2097152,41341,16,2,8192,64,108554,2196487,2118976,2420,99331,2212918,256,2212919,2172186,41821]

theorem envBound22691 : H12AffineFastState.Bounded env22691 := by
  intro p hp
  have h : env22691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22690_22691 : H12AffineEnvironment.transform 17 35188 env22690 = env22691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env22690 == env22691) = true)

theorem identity22691 : scanCanonicalize (H12AffineFastState.compose env22691 (packedSelected [1,2,3,4,5,6,7,8,10,12,14,15,17,18,19,22,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 54643) := by decide +kernel

theorem selectedBound22691 : packedSelected [1,2,3,4,5,6,7,8,10,12,14,15,17,18,19,22,23,27] rootPS < 2^1333 := by decide +kernel

def env22692 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54643,16400,35188,1024,32769,2097152,41341,16,2,8192,64,32121,2118004,2118976,2420,20848,2101573,256,2101572,2158697,41821]

theorem envBound22692 : H12AffineFastState.Bounded env22692 := by
  intro p hp
  have h : env22692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22691_22692 : H12AffineEnvironment.transform 15 54643 env22691 = env22692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54643 env22691 == env22692) = true)

theorem identity22692 : scanCanonicalize (H12AffineFastState.compose env22692 (packedSelected [2,3,5,6,9,10,14,18,22,23] rootPS)) = affineNative (2^(20+1) ^^^ 50449) := by decide +kernel

theorem selectedBound22692 : packedSelected [2,3,5,6,9,10,14,18,22,23] rootPS < 2^1333 := by decide +kernel

def env22693 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54643,16400,35188,1024,32769,50449,41341,16,2,8192,64,32121,37989,36945,2420,20848,54356,256,54357,13688,41821]

theorem envBound22693 : H12AffineFastState.Bounded env22693 := by
  intro p hp
  have h : env22693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22692_22693 : H12AffineEnvironment.transform 20 50449 env22692 = env22693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50449 env22692 == env22693) = true)

theorem identity22693 : scanCanonicalize (H12AffineFastState.compose env22693 (packedSelected [4,9,10,12,15,19] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound22693 : packedSelected [4,9,10,12,15,19] rootPS < 2^1333 := by decide +kernel

def env22694 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,29742,16400,10281,1024,8540,25676,32,16,2,8192,64,32121,13624,12556,2420,20848,29961,256,29960,13688,512]

theorem envBound22694 : H12AffineFastState.Bounded env22694 := by
  intro p hp
  have h : env22694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22693_22694 : H12AffineEnvironment.transform 14 8541 env22693 = env22694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env22693 == env22694) = true)

theorem identity22694 : scanCanonicalize (H12AffineFastState.compose env22694 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound22694 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env22695 : List Nat := [2,4,8,16,32,64,8,84,512,1024,2048,4096,8192,16384,8201,29742,16400,10281,1024,8200,25676,32,16,2,8192,64,31789,13420,12376,2080,20516,29789,84,29788,13356,512]

theorem envBound22695 : H12AffineFastState.Bounded env22695 := by
  intro p hp
  have h : env22695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22694_22695 : H12AffineEnvironment.transform 7 84 env22694 = env22695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env22694 == env22695) = true)

theorem identity22695 : scanCanonicalize (H12AffineFastState.compose env22695 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound22695 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env22696 : List Nat := [2,4,8,16,32,48,8,36,512,1024,2048,4096,8192,16384,8201,29742,16400,10281,1024,8200,25660,32,16,2,8192,48,31789,13340,12328,2080,20516,29741,36,29740,13356,512]

theorem envBound22696 : H12AffineFastState.Bounded env22696 := by
  intro p hp
  have h : env22696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22695_22696 : H12AffineEnvironment.transform 5 48 env22695 = env22696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env22695 == env22696) = true)

theorem identity22696 : scanCanonicalize (H12AffineFastState.compose env22696 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound22696 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env22697 : List Nat := [2,4,8,16,32,48,8,36,512,1024,2048,4096,40,16384,33,21510,16400,2049,1024,32,17428,32,16,2,40,48,23557,5172,4096,2080,20516,21509,36,21508,5124,512]

theorem envBound22697 : H12AffineFastState.Bounded env22697 := by
  intro p hp
  have h : env22697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22696_22697 : H12AffineEnvironment.transform 12 40 env22696 = env22697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env22696 == env22697) = true)

theorem identity22697 : scanCanonicalize (H12AffineFastState.compose env22697 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound22697 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env22698 : List Nat := [2,4,8,16,32,48,8,36,512,1024,2048,4096,40,5156,33,34,5172,2049,1024,32,4144,32,16,2,40,48,2081,5172,4096,2080,1024,33,36,32,5124,512]

theorem envBound22698 : H12AffineFastState.Bounded env22698 := by
  intro p hp
  have h : env22698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22697_22698 : H12AffineEnvironment.transform 13 5156 env22697 = env22698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env22697 == env22698) = true)

theorem identity22698 : scanCanonicalize (H12AffineFastState.compose env22698 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22698 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env22699 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,4096,8,5124,1,2,5140,2049,1024,0,4112,0,16,2,8,16,2049,5140,4096,2048,1024,1,4,0,5124,512]

theorem envBound22699 : H12AffineFastState.Bounded env22699 := by
  intro p hp
  have h : env22699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22698_22699 : H12AffineEnvironment.transform 4 0 env22698 = env22699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22698 == env22699) = true)

def env22700 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,16,8,1044,1,2,1028,2049,1024,0,0,0,16,2,8,16,2049,1028,16,2048,1024,1,4,0,1044,512]

theorem envBound22700 : H12AffineFastState.Bounded env22700 := by
  intro p hp
  have h : env22700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22699_22700 : H12AffineEnvironment.transform 11 16 env22699 = env22700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env22699 == env22700) = true)

theorem identity22700 : scanCanonicalize (H12AffineFastState.compose env22700 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound22700 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22701 : List Nat := [2,4,8,16,0,16,8,4,512,1024,1045,16,8,1044,1,2,1028,1044,1024,0,0,0,16,2,8,16,1044,1028,16,1045,1024,1,4,0,1044,512]

theorem envBound22701 : H12AffineFastState.Bounded env22701 := by
  intro p hp
  have h : env22701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22700_22701 : H12AffineEnvironment.transform 10 1045 env22700 = env22701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env22700 == env22701) = true)

def env22702 : List Nat := [2,4,8,16,0,16,8,4,512,20,1,16,8,0,1,2,16,0,20,0,0,0,16,2,8,16,0,16,16,1,20,1,4,0,0,512]

theorem envBound22702 : H12AffineFastState.Bounded env22702 := by
  intro p hp
  have h : env22702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22701_22702 : H12AffineEnvironment.transform 9 20 env22701 = env22702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env22701 == env22702) = true)

theorem identity22702 : scanCanonicalize (H12AffineFastState.compose env22702 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound22702 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22703 : List Nat := [2,4,8,4,0,4,8,4,512,0,1,4,8,0,1,2,4,0,0,0,0,0,4,2,8,4,0,4,4,1,0,1,4,0,0,512]

theorem envBound22703 : H12AffineFastState.Bounded env22703 := by
  intro p hp
  have h : env22703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22702_22703 : H12AffineEnvironment.transform 3 4 env22702 = env22703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env22702 == env22703) = true)

def leafEnv22703 : List Nat := [2,4,8,4,0,4,8,4,512,0,1,4,8,0,1,2,4,0,0,0,0,0,4,2,0,8,1,4,0,4,4,1,0,1,4,0,4,2,0,512,1,0,0]

def active22703 : List Nat := [0,1,2,8]

def tree22703 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22703 : H12WitnessSearch.Good tree22703 := H12GlobalWitnessIndex.good

theorem leafIdentity22703 : H12AffineFastState.composeSystem env22703 rootObs = leafEnv22703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22703 rootObs == leafEnv22703) = true)

theorem terminalChecked22703 : H12PackedTerminal.terminalCheckFast leafEnv22703 active22703 tree22703 = true := by decide +kernel

def env22704 : List Nat := [2,4,8,16,0,16,8,4,512,21,0,16,8,1,1,2,17,1,21,0,0,0,16,2,8,16,1,17,16,0,21,1,4,0,1,512]

theorem envBound22704 : H12AffineFastState.Bounded env22704 := by
  intro p hp
  have h : env22704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22701_22704 : H12AffineEnvironment.transform 9 21 env22701 = env22704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env22701 == env22704) = true)

theorem identity22704 : scanCanonicalize (H12AffineFastState.compose env22704 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound22704 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22705 : List Nat := [2,4,8,16,0,16,8,4,31,21,0,16,8,1,1,2,17,1,21,0,0,0,16,2,8,16,1,17,16,0,21,1,4,0,1,31]

theorem envBound22705 : H12AffineFastState.Bounded env22705 := by
  intro p hp
  have h : env22705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22704_22705 : H12AffineEnvironment.transform 8 31 env22704 = env22705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env22704 == env22705) = true)

def leafEnv22705 : List Nat := [2,4,8,16,0,16,8,4,31,21,0,16,8,1,1,2,17,1,21,0,0,0,16,2,21,8,1,16,1,17,16,0,21,1,4,0,4,2,1,31,1,0,0]

def active22705 : List Nat := [0,1,2,3]

def tree22705 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22705 : H12WitnessSearch.Good tree22705 := H12GlobalWitnessIndex.good

theorem leafIdentity22705 : H12AffineFastState.composeSystem env22705 rootObs = leafEnv22705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22705 rootObs == leafEnv22705) = true)

theorem terminalChecked22705 : H12PackedTerminal.terminalCheckFast leafEnv22705 active22705 tree22705 = true := by decide +kernel

def env22706 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,17,8,1045,1,2,1029,2049,1024,0,1,0,16,2,8,16,2049,1029,17,2048,1024,1,4,0,1045,512]

theorem envBound22706 : H12AffineFastState.Bounded env22706 := by
  intro p hp
  have h : env22706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22699_22706 : H12AffineEnvironment.transform 11 17 env22699 = env22706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env22699 == env22706) = true)

theorem identity22706 : scanCanonicalize (H12AffineFastState.compose env22706 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound22706 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22707 : List Nat := [2,4,8,16,0,16,8,4,512,1024,0,17,8,1045,1,2,1029,1,1024,0,1,0,16,2,8,16,1,1029,17,0,1024,1,4,0,1045,512]

theorem envBound22707 : H12AffineFastState.Bounded env22707 := by
  intro p hp
  have h : env22707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22706_22707 : H12AffineEnvironment.transform 10 0 env22706 = env22707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env22706 == env22707) = true)

def env22708 : List Nat := [2,4,8,16,0,16,8,4,512,20,0,17,8,1,1,2,17,1,20,0,1,0,16,2,8,16,1,17,17,0,20,1,4,0,1,512]

theorem envBound22708 : H12AffineFastState.Bounded env22708 := by
  intro p hp
  have h : env22708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22707_22708 : H12AffineEnvironment.transform 9 20 env22707 = env22708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env22707 == env22708) = true)

theorem identity22708 : scanCanonicalize (H12AffineFastState.compose env22708 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound22708 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22709 : List Nat := [2,4,8,4,0,4,8,4,512,0,0,5,8,1,1,2,5,1,0,0,1,0,4,2,8,4,1,5,5,0,0,1,4,0,1,512]

theorem envBound22709 : H12AffineFastState.Bounded env22709 := by
  intro p hp
  have h : env22709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22708_22709 : H12AffineEnvironment.transform 3 4 env22708 = env22709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env22708 == env22709) = true)

def leafEnv22709 : List Nat := [2,4,8,4,0,4,8,4,512,0,0,5,8,1,1,2,5,1,0,0,1,0,4,2,0,8,1,4,1,5,5,0,0,1,4,0,4,2,1,512,1,1,0]

def active22709 : List Nat := [0,1,2,8]

def tree22709 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22709 : H12WitnessSearch.Good tree22709 := H12GlobalWitnessIndex.good

theorem leafIdentity22709 : H12AffineFastState.composeSystem env22709 rootObs = leafEnv22709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22709 rootObs == leafEnv22709) = true)

theorem terminalChecked22709 : H12PackedTerminal.terminalCheckFast leafEnv22709 active22709 tree22709 = true := by decide +kernel

def env22710 : List Nat := [2,4,8,16,0,16,8,4,512,21,0,17,8,0,1,2,16,1,21,0,1,0,16,2,8,16,1,16,17,0,21,1,4,0,0,512]

theorem envBound22710 : H12AffineFastState.Bounded env22710 := by
  intro p hp
  have h : env22710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22707_22710 : H12AffineEnvironment.transform 9 21 env22707 = env22710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env22707 == env22710) = true)

theorem identity22710 : scanCanonicalize (H12AffineFastState.compose env22710 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound22710 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22711 : List Nat := [2,4,8,16,0,16,8,4,31,21,0,17,8,0,1,2,16,1,21,0,1,0,16,2,8,16,1,16,17,0,21,1,4,0,0,31]

theorem envBound22711 : H12AffineFastState.Bounded env22711 := by
  intro p hp
  have h : env22711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22710_22711 : H12AffineEnvironment.transform 8 31 env22710 = env22711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env22710 == env22711) = true)

def leafEnv22711 : List Nat := [2,4,8,16,0,16,8,4,31,21,0,17,8,0,1,2,16,1,21,0,1,0,16,2,21,8,1,16,1,16,17,0,21,1,4,0,4,2,0,31,1,1,0]

def active22711 : List Nat := [0,1,2,3]

def tree22711 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22711 : H12WitnessSearch.Good tree22711 := H12GlobalWitnessIndex.good

theorem leafIdentity22711 : H12AffineFastState.composeSystem env22711 rootObs = leafEnv22711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22711 rootObs == leafEnv22711) = true)

theorem terminalChecked22711 : H12PackedTerminal.terminalCheckFast leafEnv22711 active22711 tree22711 = true := by decide +kernel

def env22712 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,2097152,4194304,16,2,8192,64,4554754,2196487,2118976,294913,99331,6382923,256,2212919,2172186,41821]

theorem envBound22712 : H12AffineFastState.Bounded env22712 := by
  intro p hp
  have h : env22712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22688_22712 : H12AffineEnvironment.transform 16 16401 env22688 = env22712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env22688 == env22712) = true)

theorem identity22712 : scanCanonicalize (H12AffineFastState.compose env22712 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound22712 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env22713 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,262144,1024,8541,2097152,4194304,16,2,8192,64,4530526,2172251,2118976,270685,75103,6382923,256,2188651,2172186,513]

theorem envBound22713 : H12AffineFastState.Bounded env22713 := by
  intro p hp
  have h : env22713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22712_22713 : H12AffineEnvironment.transform 14 8540 env22712 = env22713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env22712 == env22713) = true)

theorem identity22713 : scanCanonicalize (H12AffineFastState.compose env22713 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 5456) := by decide +kernel

theorem selectedBound22713 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env22714 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,262144,1024,8541,5456,4194304,16,2,8192,64,4530526,77835,16400,270685,75103,4288539,256,94267,77898,513]

theorem envBound22714 : H12AffineFastState.Bounded env22714 := by
  intro p hp
  have h : env22714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22713_22714 : H12AffineEnvironment.transform 20 5456 env22713 = env22714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5456 env22713 == env22714) = true)

theorem identity22714 : scanCanonicalize (H12AffineFastState.compose env22714 (packedSelected [9,14,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound22714 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env22715 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16401,262144,1024,8541,5456,4194304,16,2,8192,64,4456788,4097,16400,270685,1365,4214801,256,20529,4160,513]

theorem envBound22715 : H12AffineFastState.Bounded env22715 := by
  intro p hp
  have h : env22715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22714_22715 : H12AffineEnvironment.transform 15 8202 env22714 = env22715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env22714 == env22715) = true)

theorem identity22715 : scanCanonicalize (H12AffineFastState.compose env22715 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 292936) := by decide +kernel

theorem selectedBound22715 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env22716 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16401,262144,1024,8541,5456,292936,16,2,8192,64,31004,4097,16400,270685,1365,272473,256,20529,4160,513]

theorem envBound22716 : H12AffineFastState.Bounded env22716 := by
  intro p hp
  have h : env22716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22715_22716 : H12AffineEnvironment.transform 21 292936 env22715 = env22716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 292936 env22715 == env22716) = true)

theorem identity22716 : scanCanonicalize (H12AffineFastState.compose env22716 (packedSelected [0,1,2,3,4,6,7,8,9,10,14,24] rootPS)) = affineNative (2^(17+1) ^^^ 30776) := by decide +kernel

theorem selectedBound22716 : packedSelected [0,1,2,3,4,6,7,8,9,10,14,24] rootPS < 2^1333 := by decide +kernel

def env22717 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16401,30776,1024,8541,5456,112,16,2,8192,64,31004,4097,16400,22885,1365,20577,256,20529,4160,513]

theorem envBound22717 : H12AffineFastState.Bounded env22717 := by
  intro p hp
  have h : env22717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22716_22717 : H12AffineEnvironment.transform 17 30776 env22716 = env22717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 30776 env22716 == env22717) = true)

theorem identity22717 : scanCanonicalize (H12AffineFastState.compose env22717 (packedSelected [2,6,15,38] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound22717 : packedSelected [2,6,15,38] rootPS < 2^1333 := by decide +kernel

def env22718 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,81,263,16401,22837,1024,80,5456,112,16,2,269,64,22545,4097,16400,22885,1365,20577,256,20529,4160,513]

theorem envBound22718 : H12AffineFastState.Bounded env22718 := by
  intro p hp
  have h : env22718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22717_22718 : H12AffineEnvironment.transform 12 269 env22717 = env22718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env22717 == env22718) = true)

theorem identity22718 : scanCanonicalize (H12AffineFastState.compose env22718 (packedSelected [18,23] rootPS)) = affineNative (2^(13+1) ^^^ 4161) := by decide +kernel

theorem selectedBound22718 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env22719 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,4161,81,263,4176,2420,1024,80,5456,112,16,2,269,64,2128,4097,4177,2340,1365,32,256,112,4160,513]

theorem envBound22719 : H12AffineFastState.Bounded env22719 := by
  intro p hp
  have h : env22719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22718_22719 : H12AffineEnvironment.transform 13 4161 env22718 = env22719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4161 env22718 == env22719) = true)

theorem identity22719 : scanCanonicalize (H12AffineFastState.compose env22719 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound22719 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env22720 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,269,4161,81,263,4176,2420,53,80,4453,112,16,2,269,64,2128,4097,4177,2340,352,32,256,112,4160,513]

theorem envBound22720 : H12AffineFastState.Bounded env22720 := by
  intro p hp
  have h : env22720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22719_22720 : H12AffineEnvironment.transform 9 53 env22719 = env22720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env22719 == env22720) = true)

def env22721 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,16777216,8193,64,21479441,18973700,2118976,442384,16876545,23160136,256,18990132,18949400,16819038]

theorem envBound22721 : H12AffineFastState.Bounded env22721 := by
  intro p hp
  have h : env22721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22686_22721 : H12AffineEnvironment.transform 6 9 env22686 = env22721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22686 == env22721) = true)

theorem identity22721 : scanCanonicalize (H12AffineFastState.compose env22721 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 41311) := by decide +kernel

theorem selectedBound22721 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env22722 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,41311,8193,64,4677966,2172251,2118976,442384,75102,6407191,256,2188651,2196551,513]

theorem envBound22722 : H12AffineFastState.Bounded env22722 := by
  intro p hp
  have h : env22722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22721_22722 : H12AffineEnvironment.transform 23 41311 env22721 = env22722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41311 env22721 == env22722) = true)

def env22723 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41311,8193,64,4677966,115015,45404,442384,75102,4268043,256,98679,90203,513]

theorem envBound22723 : H12AffineFastState.Bounded env22723 := by
  intro p hp
  have h : env22723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22722_22723 : H12AffineEnvironment.transform 20 58396 env22722 = env22723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env22722 == env22723) = true)

theorem identity22723 : scanCanonicalize (H12AffineFastState.compose env22723 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound22723 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22724 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,58396,4194304,16,41311,8193,64,4604228,57677,45404,442384,1364,4194305,256,41341,16465,513]

theorem envBound22724 : H12AffineFastState.Bounded env22724 := by
  intro p hp
  have h : env22724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22723_22724 : H12AffineEnvironment.transform 15 8202 env22723 = env22724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env22723 == env22724) = true)

theorem identity22724 : scanCanonicalize (H12AffineFastState.compose env22724 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 419912) := by decide +kernel

theorem selectedBound22724 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env22725 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,58396,419912,16,41311,8193,64,10508,57677,45404,442384,1364,419913,256,41341,16465,513]

theorem envBound22725 : H12AffineFastState.Bounded env22725 := by
  intro p hp
  have h : env22725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22724_22725 : H12AffineEnvironment.transform 21 419912 env22724 = env22725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 419912 env22724 == env22725) = true)

def env22726 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16448,262144,1024,32769,58396,272392,16,41311,8193,64,10508,57677,45404,294992,1364,272393,256,41341,16465,513]

theorem envBound22726 : H12AffineFastState.Bounded env22726 := by
  intro p hp
  have h : env22726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22725_22726 : H12AffineEnvironment.transform 16 16448 env22725 = env22726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env22725 == env22726) = true)

theorem identity22726 : scanCanonicalize (H12AffineFastState.compose env22726 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound22726 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env22727 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16448,43049,1024,32769,58396,32801,16,41311,8193,64,10508,57677,45404,10361,1364,32800,256,41341,16465,513]

theorem envBound22727 : H12AffineFastState.Bounded env22727 := by
  intro p hp
  have h : env22727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22726_22727 : H12AffineEnvironment.transform 17 43049 env22726 = env22727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env22726 == env22727) = true)

theorem identity22727 : scanCanonicalize (H12AffineFastState.compose env22727 (packedSelected [0,1,2,3,5,6,7,8,10,18,19,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound22727 : packedSelected [0,1,2,3,5,6,7,8,10,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env22728 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,8202,16448,10281,1024,1,25628,33,16,8543,8193,64,10508,24909,12636,10361,1364,32,256,8573,16465,513]

theorem envBound22728 : H12AffineFastState.Bounded env22728 := by
  intro p hp
  have h : env22728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22727_22728 : H12AffineEnvironment.transform 14 0 env22727 = env22728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env22727 == env22728) = true)

theorem identity22728 : scanCanonicalize (H12AffineFastState.compose env22728 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22728 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22729 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,0,8202,16400,10281,1024,1,25628,33,16,8463,8193,16,10508,24861,12556,10281,1284,32,256,8493,16385,513]

theorem envBound22729 : H12AffineFastState.Bounded env22729 := by
  intro p hp
  have h : env22729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22728_22729 : H12AffineEnvironment.transform 5 16 env22728 = env22729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22728 == env22729) = true)

theorem identity22729 : scanCanonicalize (H12AffineFastState.compose env22729 (packedSelected [2,5,8] rootPS)) = affineNative (2^(13+1) ^^^ 11270) := by decide +kernel

theorem selectedBound22729 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env22730 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,11270,0,8202,11286,10281,1024,1,2074,33,16,8463,8193,16,10508,3355,12556,10281,1284,32,256,8493,11271,513]

theorem envBound22730 : H12AffineFastState.Bounded env22730 := by
  intro p hp
  have h : env22730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22729_22730 : H12AffineEnvironment.transform 13 11270 env22729 = env22730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11270 env22729 == env22730) = true)

theorem identity22730 : scanCanonicalize (H12AffineFastState.compose env22730 (packedSelected [0,1,4,5,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2091) := by decide +kernel

theorem selectedBound22730 : packedSelected [0,1,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env22731 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2091,8192,11270,0,8202,11286,10281,1024,1,2074,33,16,8463,8193,16,10508,3355,10535,10281,1284,32,256,8493,11271,513]

theorem envBound22731 : H12AffineFastState.Bounded env22731 := by
  intro p hp
  have h : env22731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22730_22731 : H12AffineEnvironment.transform 11 2091 env22730 = env22731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2091 env22730 == env22731) = true)

theorem identity22731 : scanCanonicalize (H12AffineFastState.compose env22731 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound22731 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22732 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2091,268,3338,0,262,3354,2341,1024,1,2074,33,16,3,269,16,2048,3355,2091,2341,1284,32,256,33,3339,513]

theorem envBound22732 : H12AffineFastState.Bounded env22732 := by
  intro p hp
  have h : env22732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22731_22732 : H12AffineEnvironment.transform 12 268 env22731 = env22732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env22731 == env22732) = true)

theorem identity22732 : scanCanonicalize (H12AffineFastState.compose env22732 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 271) := by decide +kernel

theorem selectedBound22732 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22733 : List Nat := [2,4,8,16,32,16,9,256,512,1024,271,292,268,1029,0,262,1045,42,1024,1,277,33,16,3,269,16,271,1044,292,42,1284,32,256,33,1028,513]

theorem envBound22733 : H12AffineFastState.Bounded env22733 := by
  intro p hp
  have h : env22733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22732_22733 : H12AffineEnvironment.transform 10 271 env22732 = env22733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 271 env22732 == env22733) = true)

theorem identity22733 : scanCanonicalize (H12AffineFastState.compose env22733 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound22733 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22734 : List Nat := [2,4,8,16,32,16,9,37,512,1024,42,1,41,1029,0,35,1045,42,1024,1,48,33,16,3,40,16,42,1044,1,42,1057,32,37,33,1028,513]

theorem envBound22734 : H12AffineFastState.Bounded env22734 := by
  intro p hp
  have h : env22734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22733_22734 : H12AffineEnvironment.transform 7 37 env22733 = env22734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env22733 == env22734) = true)

theorem identity22734 : scanCanonicalize (H12AffineFastState.compose env22734 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound22734 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22735 : List Nat := [2,4,8,16,32,16,9,37,512,21,42,1,41,16,0,35,0,42,21,1,48,33,16,3,40,16,42,1,1,42,52,32,37,33,17,513]

theorem envBound22735 : H12AffineFastState.Bounded env22735 := by
  intro p hp
  have h : env22735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22734_22735 : H12AffineEnvironment.transform 9 21 env22734 = env22735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env22734 == env22735) = true)

def env22736 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16449,262144,1024,32769,58396,272393,16,41311,8193,64,10508,57677,45404,294993,1364,272392,256,41341,16465,513]

theorem envBound22736 : H12AffineFastState.Bounded env22736 := by
  intro p hp
  have h : env22736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22725_22736 : H12AffineEnvironment.transform 16 16449 env22725 = env22736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env22725 == env22736) = true)

theorem identity22736 : scanCanonicalize (H12AffineFastState.compose env22736 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 35109) := by decide +kernel

theorem selectedBound22736 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env22737 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16449,35109,1024,32769,58396,41260,16,41311,8193,64,10508,57677,45404,2420,1364,41261,256,41341,16465,513]

theorem envBound22737 : H12AffineFastState.Bounded env22737 := by
  intro p hp
  have h : env22737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22736_22737 : H12AffineEnvironment.transform 17 35109 env22736 = env22737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35109 env22736 == env22737) = true)

theorem identity22737 : scanCanonicalize (H12AffineFastState.compose env22737 (packedSelected [3,10,19,24] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound22737 : packedSelected [3,10,19,24] rootPS < 2^1333 := by decide +kernel

def env22738 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,343,16449,35109,1024,32769,50497,32881,16,32770,348,64,2129,49168,36865,2420,1364,32880,256,32800,16465,513]

theorem envBound22738 : H12AffineFastState.Bounded env22738 := by
  intro p hp
  have h : env22738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22737_22738 : H12AffineEnvironment.transform 12 349 env22737 = env22738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env22737 == env22738) = true)

theorem identity22738 : scanCanonicalize (H12AffineFastState.compose env22738 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound22738 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22739 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,81,343,16449,2420,1024,80,17680,32,16,83,348,64,2129,16449,4176,2420,1364,33,256,113,16465,513]

theorem envBound22739 : H12AffineFastState.Bounded env22739 := by
  intro p hp
  have h : env22739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22738_22739 : H12AffineEnvironment.transform 14 81 env22738 = env22739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env22738 == env22739) = true)

theorem identity22739 : scanCanonicalize (H12AffineFastState.compose env22739 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22739 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22740 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,1,263,16401,2340,1024,0,17680,32,16,3,268,16,2049,16401,4096,2340,1284,33,256,33,16385,513]

theorem envBound22740 : H12AffineFastState.Bounded env22740 := by
  intro p hp
  have h : env22740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22739_22740 : H12AffineEnvironment.transform 5 16 env22739 = env22740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22739 == env22740) = true)

theorem identity22740 : scanCanonicalize (H12AffineFastState.compose env22740 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22740 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22741 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,4096,269,16384,1,263,16401,2309,1024,0,17680,1,16,3,268,16,2049,16401,4096,2309,1284,0,256,0,16385,513]

theorem envBound22741 : H12AffineFastState.Bounded env22741 := by
  intro p hp
  have h : env22741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22740_22741 : H12AffineEnvironment.transform 4 1 env22740 = env22741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22740 == env22741) = true)

theorem identity22741 : scanCanonicalize (H12AffineFastState.compose env22741 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound22741 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22742 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,17,269,16384,1,263,16401,2309,1024,0,17680,1,16,3,268,16,2049,16401,17,2309,1284,0,256,0,16385,513]

theorem envBound22742 : H12AffineFastState.Bounded env22742 := by
  intro p hp
  have h : env22742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22741_22742 : H12AffineEnvironment.transform 11 17 env22741 = env22742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env22741 == env22742) = true)

theorem identity22742 : scanCanonicalize (H12AffineFastState.compose env22742 (packedSelected [0,4] rootPS)) = affineNative (2^(13+1) ^^^ 1808) := by decide +kernel

theorem selectedBound22742 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22743 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,17,269,1808,1,263,1793,2309,1024,0,512,1,16,3,268,16,2049,1793,17,2309,1284,0,256,0,1809,513]

theorem envBound22743 : H12AffineFastState.Bounded env22743 := by
  intro p hp
  have h : env22743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22742_22743 : H12AffineEnvironment.transform 13 1808 env22742 = env22743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1808 env22742 == env22743) = true)

theorem identity22743 : scanCanonicalize (H12AffineFastState.compose env22743 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound22743 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env22744 : List Nat := [2,4,8,16,1,16,9,256,512,1024,529,17,269,1808,1,263,1793,788,1024,0,512,1,16,3,268,16,528,1793,17,788,1284,0,256,0,1809,513]

theorem envBound22744 : H12AffineFastState.Bounded env22744 := by
  intro p hp
  have h : env22744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22743_22744 : H12AffineEnvironment.transform 10 529 env22743 = env22744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env22743 == env22744) = true)

theorem identity22744 : scanCanonicalize (H12AffineFastState.compose env22744 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound22744 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22745 : List Nat := [2,4,8,16,1,16,9,256,512,257,529,17,269,529,1,263,512,788,257,0,512,1,16,3,268,16,528,512,17,788,5,0,256,0,528,513]

theorem envBound22745 : H12AffineFastState.Bounded env22745 := by
  intro p hp
  have h : env22745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22744_22745 : H12AffineEnvironment.transform 9 257 env22744 = env22745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env22744 == env22745) = true)

theorem identity22745 : scanCanonicalize (H12AffineFastState.compose env22745 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound22745 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env22746 : List Nat := [2,4,8,16,1,16,9,256,261,257,276,17,269,276,1,263,261,17,257,0,261,1,16,3,268,16,277,261,17,17,5,0,256,0,277,260]

theorem envBound22746 : H12AffineFastState.Bounded env22746 := by
  intro p hp
  have h : env22746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22745_22746 : H12AffineEnvironment.transform 8 261 env22745 = env22746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env22745 == env22746) = true)

def env22747 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41311,8193,64,4677966,115014,45405,442384,75102,4268042,256,98678,90202,513]

theorem envBound22747 : H12AffineFastState.Bounded env22747 := by
  intro p hp
  have h : env22747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22722_22747 : H12AffineEnvironment.transform 20 58397 env22722 = env22747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env22722 == env22747) = true)

def env22748 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41231,8193,16,4677918,114966,45325,442384,75022,4268042,256,98598,90122,513]

theorem envBound22748 : H12AffineFastState.Bounded env22748 := by
  intro p hp
  have h : env22748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22747_22748 : H12AffineEnvironment.transform 5 16 env22747 = env22748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22747 == env22748) = true)

def env22749 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58397,4194304,16,41231,8193,16,4409654,114966,45325,190520,75022,4268042,256,98598,90122,513]

theorem envBound22749 : H12AffineFastState.Bounded env22749 := by
  intro p hp
  have h : env22749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22748_22749 : H12AffineEnvironment.transform 17 10280 env22748 = env22749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env22748 == env22749) = true)

end H12CloudChart0