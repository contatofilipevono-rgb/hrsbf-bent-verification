import H12CloudChart0Data037

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound9464 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9465 : List Nat := [2,4,8,16,32,64,128,85,216,84,2048,4096,8192,232,8352,8234,4264,262144,4333,8352,64,266387,4097,34,8329,4096,262281,262322,262171,2081,172,266418,4332,1,4097,112]

theorem envBound9465 : H12AffineFastState.Bounded env9465 := by
  intro p hp
  have h : env9465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9464_9465 : H12AffineEnvironment.transform 7 85 env9464 = env9465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env9464 == env9465) = true)

theorem identity9465 : scanCanonicalize (H12AffineFastState.compose env9465 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound9465 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env9466 : List Nat := [2,4,8,16,32,64,128,85,216,84,2048,65,8192,232,8352,8234,233,262144,172,8352,64,262354,64,34,8329,65,262281,262322,262171,2081,172,262387,173,1,64,112]

theorem envBound9466 : H12AffineFastState.Bounded env9466 := by
  intro p hp
  have h : env9466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9465_9466 : H12AffineEnvironment.transform 11 65 env9465 = env9466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env9465 == env9466) = true)

theorem identity9466 : scanCanonicalize (H12AffineFastState.compose env9466 (packedSelected [5,8,10,12,15,19] rootPS)) = affineNative (2^(17+1) ^^^ 2160) := by decide +kernel

theorem selectedBound9466 : packedSelected [5,8,10,12,15,19] rootPS < 2^1333 := by decide +kernel

def env9467 : List Nat := [2,4,8,16,32,64,128,85,216,84,2048,65,8192,232,8352,8234,233,2160,172,8352,64,2210,64,34,8329,65,2297,2242,2155,2081,172,2179,173,1,64,112]

theorem envBound9467 : H12AffineFastState.Bounded env9467 := by
  intro p hp
  have h : env9467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9466_9467 : H12AffineEnvironment.transform 17 2160 env9466 = env9467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2160 env9466 == env9467) = true)

theorem identity9467 : scanCanonicalize (H12AffineFastState.compose env9467 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound9467 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env9468 : List Nat := [2,4,8,16,32,64,120,85,32,84,2048,65,8192,16,8280,8234,17,2160,84,8280,64,2138,64,34,8305,65,2049,2106,2155,2081,84,2171,85,1,64,112]

theorem envBound9468 : H12AffineFastState.Bounded env9468 := by
  intro p hp
  have h : env9468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9467_9468 : H12AffineEnvironment.transform 6 120 env9467 = env9468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env9467 == env9468) = true)

theorem identity9468 : scanCanonicalize (H12AffineFastState.compose env9468 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound9468 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env9469 : List Nat := [2,4,8,16,32,64,120,85,32,84,65,65,8192,16,8280,8234,17,49,84,8280,64,27,64,34,8305,65,64,123,42,96,84,58,85,1,64,112]

theorem envBound9469 : H12AffineFastState.Bounded env9469 := by
  intro p hp
  have h : env9469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9468_9469 : H12AffineEnvironment.transform 10 65 env9468 = env9469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env9468 == env9469) = true)

theorem identity9469 : scanCanonicalize (H12AffineFastState.compose env9469 (packedSelected [1,2,3,4,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 3) := by decide +kernel

theorem selectedBound9469 : packedSelected [1,2,3,4,7,11] rootPS < 2^1333 := by decide +kernel

def env9470 : List Nat := [2,4,8,16,32,64,120,85,32,84,65,65,3,16,91,41,17,49,84,91,64,27,64,34,114,65,64,123,42,96,84,58,85,1,64,112]

theorem envBound9470 : H12AffineFastState.Bounded env9470 := by
  intro p hp
  have h : env9470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9469_9470 : H12AffineEnvironment.transform 12 3 env9469 = env9470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3 env9469 == env9470) = true)

theorem identity9470 : scanCanonicalize (H12AffineFastState.compose env9470 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound9470 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9471 : List Nat := [2,4,8,1,32,64,105,68,32,69,65,65,3,1,74,41,0,32,69,74,64,10,64,34,99,65,64,106,42,96,69,43,68,1,64,97]

theorem envBound9471 : H12AffineFastState.Bounded env9471 := by
  intro p hp
  have h : env9471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9470_9471 : H12AffineEnvironment.transform 3 1 env9470 = env9471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env9470 == env9471) = true)

theorem identity9471 : scanCanonicalize (H12AffineFastState.compose env9471 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound9471 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9472 : List Nat := [2,4,8,1,11,64,66,68,11,69,65,65,3,1,74,2,0,11,69,74,64,10,64,9,72,65,64,65,1,75,69,0,68,1,64,74]

theorem envBound9472 : H12AffineFastState.Bounded env9472 := by
  intro p hp
  have h : env9472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9471_9472 : H12AffineEnvironment.transform 4 11 env9471 = env9472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env9471 == env9472) = true)

theorem identity9472 : scanCanonicalize (H12AffineFastState.compose env9472 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound9472 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9473 : List Nat := [2,4,8,1,11,11,9,15,11,14,10,10,3,1,1,2,0,11,14,1,11,10,11,9,3,10,11,10,1,0,14,0,15,1,11,1]

theorem envBound9473 : H12AffineFastState.Bounded env9473 := by
  intro p hp
  have h : env9473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9472_9473 : H12AffineEnvironment.transform 5 11 env9472 = env9473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env9472 == env9473) = true)

theorem identity9473 : scanCanonicalize (H12AffineFastState.compose env9473 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9473 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9474 : List Nat := [2,4,2,1,1,1,3,5,1,4,0,0,3,1,1,2,0,1,4,1,1,0,1,3,3,0,1,0,1,0,4,0,5,1,1,1]

theorem envBound9474 : H12AffineFastState.Bounded env9474 := by
  intro p hp
  have h : env9474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9473_9474 : H12AffineEnvironment.transform 2 2 env9473 = env9474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9473 == env9474) = true)

def env9475 : List Nat := [2,4,8,16,32,64,128,256,217,257,2048,4096,8192,233,8693,8235,4605,262144,4537,8693,64,266695,4437,34,8329,4096,262280,262631,262171,2080,505,266418,4536,0,4097,292]

theorem envBound9475 : H12AffineFastState.Bounded env9475 := by
  intro p hp
  have h : env9475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9463_9475 : H12AffineEnvironment.transform 8 217 env9463 = env9475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env9463 == env9475) = true)

theorem identity9475 : scanCanonicalize (H12AffineFastState.compose env9475 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 4123) := by decide +kernel

theorem selectedBound9475 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9476 : List Nat := [2,4,8,16,32,64,128,256,217,257,2048,4096,8192,233,8693,8235,4605,4123,4537,8693,64,476,4437,34,8329,4096,4243,4604,4096,2080,505,169,4536,0,4097,292]

theorem envBound9476 : H12AffineFastState.Bounded env9476 := by
  intro p hp
  have h : env9476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9475_9476 : H12AffineEnvironment.transform 17 4123 env9475 = env9476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4123 env9475 == env9476) = true)

theorem identity9476 : scanCanonicalize (H12AffineFastState.compose env9476 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 444) := by decide +kernel

theorem selectedBound9476 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9477 : List Nat := [2,4,8,16,32,64,128,256,217,257,2048,444,8192,233,8693,8235,65,423,5,8693,64,476,233,34,8329,444,303,64,444,2080,505,169,4,0,445,292]

theorem envBound9477 : H12AffineFastState.Bounded env9477 := by
  intro p hp
  have h : env9477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9476_9477 : H12AffineEnvironment.transform 11 444 env9476 = env9477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 444 env9476 == env9477) = true)

theorem identity9477 : scanCanonicalize (H12AffineFastState.compose env9477 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 211) := by decide +kernel

theorem selectedBound9477 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env9478 : List Nat := [2,4,8,16,32,64,128,256,217,257,211,444,8192,233,8693,8235,65,423,5,8693,64,476,233,34,8329,444,303,64,444,243,505,169,4,0,445,292]

theorem envBound9478 : H12AffineFastState.Bounded env9478 := by
  intro p hp
  have h : env9478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9477_9478 : H12AffineEnvironment.transform 10 211 env9477 = env9478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 211 env9477 == env9478) = true)

theorem identity9478 : scanCanonicalize (H12AffineFastState.compose env9478 (packedSelected [0,7,14,20] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound9478 : packedSelected [0,7,14,20] rootPS < 2^1333 := by decide +kernel

def env9479 : List Nat := [2,4,8,16,32,64,128,84,217,85,211,232,8192,233,8353,8235,65,243,5,8353,64,136,233,34,8329,232,123,64,232,243,173,169,4,0,233,112]

theorem envBound9479 : H12AffineFastState.Bounded env9479 := by
  intro p hp
  have h : env9479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9478_9479 : H12AffineEnvironment.transform 7 84 env9478 = env9479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env9478 == env9479) = true)

theorem identity9479 : scanCanonicalize (H12AffineFastState.compose env9479 (packedSelected [1,3,12] rootPS)) = affineNative (2^(6+1) ^^^ 99) := by decide +kernel

theorem selectedBound9479 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env9480 : List Nat := [2,4,8,16,32,64,99,84,58,85,48,11,8192,10,8258,8235,65,16,5,8258,64,107,10,34,8298,11,123,64,11,16,78,74,4,0,10,112]

theorem envBound9480 : H12AffineFastState.Bounded env9480 := by
  intro p hp
  have h : env9480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9479_9480 : H12AffineEnvironment.transform 6 99 env9479 = env9480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 99 env9479 == env9480) = true)

theorem identity9480 : scanCanonicalize (H12AffineFastState.compose env9480 (packedSelected [0,2,3,4,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound9480 : packedSelected [0,2,3,4,5,10] rootPS < 2^1333 := by decide +kernel

def env9481 : List Nat := [2,4,8,16,32,64,99,84,58,85,48,11,72,10,10,99,65,16,5,10,64,107,10,34,34,11,123,64,11,16,78,74,4,0,10,112]

theorem envBound9481 : H12AffineFastState.Bounded env9481 := by
  intro p hp
  have h : env9481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9480_9481 : H12AffineEnvironment.transform 12 72 env9480 = env9481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env9480 == env9481) = true)

theorem identity9481 : scanCanonicalize (H12AffineFastState.compose env9481 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound9481 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env9482 : List Nat := [2,4,8,16,16,64,83,84,10,85,0,11,72,10,10,83,65,16,5,10,64,91,10,18,18,11,75,64,11,16,78,74,4,0,10,64]

theorem envBound9482 : H12AffineFastState.Bounded env9482 := by
  intro p hp
  have h : env9482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9481_9482 : H12AffineEnvironment.transform 4 16 env9481 = env9482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env9481 == env9482) = true)

theorem identity9482 : scanCanonicalize (H12AffineFastState.compose env9482 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound9482 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env9483 : List Nat := [2,4,8,10,10,64,73,78,10,79,0,11,72,10,10,73,65,10,5,10,64,65,10,8,8,11,75,64,11,10,78,74,4,0,10,64]

theorem envBound9483 : H12AffineFastState.Bounded env9483 := by
  intro p hp
  have h : env9483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9482_9483 : H12AffineEnvironment.transform 3 10 env9482 = env9483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env9482 == env9483) = true)

theorem identity9483 : scanCanonicalize (H12AffineFastState.compose env9483 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9483 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9484 : List Nat := [2,4,2,0,0,64,67,68,0,69,0,1,66,0,0,67,65,0,5,0,64,65,0,2,2,1,65,64,1,0,68,64,4,0,0,64]

theorem envBound9484 : H12AffineFastState.Bounded env9484 := by
  intro p hp
  have h : env9484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9483_9484 : H12AffineEnvironment.transform 2 2 env9483 = env9484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9483 == env9484) = true)

theorem identity9484 : scanCanonicalize (H12AffineFastState.compose env9484 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound9484 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9485 : List Nat := [2,4,2,0,0,1,2,5,0,4,0,1,3,0,0,2,0,0,5,0,1,0,0,2,2,1,0,1,1,0,5,1,4,0,0,1]

theorem envBound9485 : H12AffineFastState.Bounded env9485 := by
  intro p hp
  have h : env9485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9484_9485 : H12AffineEnvironment.transform 5 1 env9484 = env9485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env9484 == env9485) = true)

theorem identity9485 : scanCanonicalize (H12AffineFastState.compose env9485 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound9485 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9486 : List Nat := [2,0,2,0,0,1,2,1,0,0,0,1,3,0,0,2,0,0,1,0,1,0,0,2,2,1,0,1,1,0,1,1,0,0,0,1]

theorem envBound9486 : H12AffineFastState.Bounded env9486 := by
  intro p hp
  have h : env9486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9485_9486 : H12AffineEnvironment.transform 1 0 env9485 = env9486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env9485 == env9486) = true)

def env9487 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,561,8693,8947,4605,262144,4960,8693,64,267039,5004,34,8329,4097,262736,262631,262171,2808,505,266418,4961,728,4096,1021]

theorem envBound9487 : H12AffineFastState.Bounded env9487 := by
  intro p hp
  have h : env9487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9462_9487 : H12AffineEnvironment.transform 13 561 env9462 = env9487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env9462 == env9487) = true)

def env9488 : List Nat := [2,4,8,16,32,64,128,256,216,257,2048,4096,8192,233,8693,8235,4605,262144,4536,8693,64,266695,4436,34,8329,4097,262280,262631,262171,2080,505,266418,4537,0,4096,293]

theorem envBound9488 : H12AffineFastState.Bounded env9488 := by
  intro p hp
  have h : env9488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9487_9488 : H12AffineEnvironment.transform 8 216 env9487 = env9488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env9487 == env9488) = true)

theorem identity9488 : scanCanonicalize (H12AffineFastState.compose env9488 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 4123) := by decide +kernel

theorem selectedBound9488 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9489 : List Nat := [2,4,8,16,32,64,128,256,216,257,2048,4096,8192,233,8693,8235,4605,4123,4536,8693,64,476,4436,34,8329,4097,4243,4604,4096,2080,505,169,4537,0,4096,293]

theorem envBound9489 : H12AffineFastState.Bounded env9489 := by
  intro p hp
  have h : env9489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9488_9489 : H12AffineEnvironment.transform 17 4123 env9488 = env9489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4123 env9488 == env9489) = true)

theorem identity9489 : scanCanonicalize (H12AffineFastState.compose env9489 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 232) := by decide +kernel

theorem selectedBound9489 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9490 : List Nat := [2,4,8,16,32,64,128,256,216,257,2048,232,8192,233,8693,8235,277,243,336,8693,64,476,444,34,8329,233,123,276,232,2080,505,169,337,0,232,293]

theorem envBound9490 : H12AffineFastState.Bounded env9490 := by
  intro p hp
  have h : env9490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9489_9490 : H12AffineEnvironment.transform 11 232 env9489 = env9490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 232 env9489 == env9490) = true)

theorem identity9490 : scanCanonicalize (H12AffineFastState.compose env9490 (packedSelected [0,1,3,7,12,15,20] rootPS)) = affineNative (2^(10+1) ^^^ 122) := by decide +kernel

theorem selectedBound9490 : packedSelected [0,1,3,7,12,15,20] rootPS < 2^1333 := by decide +kernel

def env9491 : List Nat := [2,4,8,16,32,64,128,256,216,257,122,232,8192,233,8693,8235,277,243,336,8693,64,476,444,34,8329,233,123,276,232,90,505,169,337,0,232,293]

theorem envBound9491 : H12AffineFastState.Bounded env9491 := by
  intro p hp
  have h : env9491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9490_9491 : H12AffineEnvironment.transform 10 122 env9490 = env9491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 122 env9490 == env9491) = true)

theorem identity9491 : scanCanonicalize (H12AffineFastState.compose env9491 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound9491 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env9492 : List Nat := [2,4,8,16,32,64,128,172,216,173,122,232,8192,233,8281,8235,185,243,252,8281,64,112,16,34,8329,233,123,184,232,90,85,169,253,0,232,137]

theorem envBound9492 : H12AffineFastState.Bounded env9492 := by
  intro p hp
  have h : env9492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9491_9492 : H12AffineEnvironment.transform 7 172 env9491 = env9492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env9491 == env9492) = true)

theorem identity9492 : scanCanonicalize (H12AffineFastState.compose env9492 (packedSelected [2,5,8,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 98) := by decide +kernel

theorem selectedBound9492 : packedSelected [2,5,8,10,13] rootPS < 2^1333 := by decide +kernel

def env9493 : List Nat := [2,4,8,16,32,64,128,172,216,173,122,232,98,233,59,73,185,243,252,59,64,112,16,34,235,233,123,184,232,90,85,169,253,0,232,137]

theorem envBound9493 : H12AffineFastState.Bounded env9493 := by
  intro p hp
  have h : env9493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9492_9493 : H12AffineEnvironment.transform 12 98 env9492 = env9493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 98 env9492 == env9493) = true)

theorem identity9493 : scanCanonicalize (H12AffineFastState.compose env9493 (packedSelected [0,2,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound9493 : packedSelected [0,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env9494 : List Nat := [2,4,8,16,32,48,128,172,168,173,10,152,18,153,59,57,185,131,140,59,48,0,16,34,155,153,11,184,152,42,37,169,141,0,152,137]

theorem envBound9494 : H12AffineFastState.Bounded env9494 := by
  intro p hp
  have h : env9494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9493_9494 : H12AffineEnvironment.transform 5 48 env9493 = env9494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env9493 == env9494) = true)

theorem identity9494 : scanCanonicalize (H12AffineFastState.compose env9494 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound9494 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env9495 : List Nat := [2,4,8,16,32,48,8,36,32,37,10,16,18,17,59,57,49,11,4,59,48,0,16,34,19,17,11,48,16,42,37,33,5,0,16,1]

theorem envBound9495 : H12AffineFastState.Bounded env9495 := by
  intro p hp
  have h : env9495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9494_9495 : H12AffineEnvironment.transform 6 8 env9494 = env9495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env9494 == env9495) = true)

theorem identity9495 : scanCanonicalize (H12AffineFastState.compose env9495 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound9495 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env9496 : List Nat := [2,4,8,16,1,17,8,5,1,4,10,16,18,17,26,24,16,11,4,26,17,0,16,3,19,17,11,17,16,11,4,0,5,0,16,1]

theorem envBound9496 : H12AffineFastState.Bounded env9496 := by
  intro p hp
  have h : env9496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9495_9496 : H12AffineEnvironment.transform 4 1 env9495 = env9496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9495 == env9496) = true)

theorem identity9496 : scanCanonicalize (H12AffineFastState.compose env9496 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9496 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9497 : List Nat := [2,4,3,16,1,17,3,5,1,4,1,16,18,17,17,19,16,0,4,17,17,0,16,3,19,17,0,17,16,0,4,0,5,0,16,1]

theorem envBound9497 : H12AffineFastState.Bounded env9497 := by
  intro p hp
  have h : env9497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9496_9497 : H12AffineEnvironment.transform 2 3 env9496 = env9497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9496 == env9497) = true)

theorem identity9497 : scanCanonicalize (H12AffineFastState.compose env9497 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound9497 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9498 : List Nat := [2,4,3,1,1,0,3,5,1,4,1,1,3,0,0,2,1,0,4,0,0,0,1,3,2,0,0,0,1,0,4,0,5,0,1,1]

theorem envBound9498 : H12AffineFastState.Bounded env9498 := by
  intro p hp
  have h : env9498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9497_9498 : H12AffineEnvironment.transform 3 1 env9497 = env9498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env9497 == env9498) = true)

def env9499 : List Nat := [2,4,8,16,32,64,128,256,217,257,2048,4096,8192,232,8693,8234,4605,262144,4537,8693,64,266694,4437,34,8329,4097,262281,262631,262171,2081,505,266418,4536,1,4096,292]

theorem envBound9499 : H12AffineFastState.Bounded env9499 := by
  intro p hp
  have h : env9499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9487_9499 : H12AffineEnvironment.transform 8 217 env9487 = env9499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env9487 == env9499) = true)

theorem identity9499 : scanCanonicalize (H12AffineFastState.compose env9499 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound9499 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9500 : List Nat := [2,4,8,16,32,64,128,85,217,84,2048,4096,8192,232,8352,8234,4264,262144,4332,8352,64,266387,4096,34,8329,4097,262281,262322,262171,2081,172,266418,4333,1,4096,113]

theorem envBound9500 : H12AffineFastState.Bounded env9500 := by
  intro p hp
  have h : env9500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9499_9500 : H12AffineEnvironment.transform 7 85 env9499 = env9500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env9499 == env9500) = true)

theorem identity9500 : scanCanonicalize (H12AffineFastState.compose env9500 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(17+1) ^^^ 90) := by decide +kernel

theorem selectedBound9500 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env9501 : List Nat := [2,4,8,16,32,64,128,85,217,84,2048,4096,8192,232,8352,8234,4264,90,4332,8352,64,4297,4096,34,8329,4097,211,232,65,2081,172,4328,4333,1,4096,113]

theorem envBound9501 : H12AffineFastState.Bounded env9501 := by
  intro p hp
  have h : env9501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9500_9501 : H12AffineEnvironment.transform 17 90 env9500 = env9501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 90 env9500 == env9501) = true)

theorem identity9501 : scanCanonicalize (H12AffineFastState.compose env9501 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2242) := by decide +kernel

theorem selectedBound9501 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env9502 : List Nat := [2,4,8,16,32,64,128,85,217,84,2048,2242,8192,232,8352,8234,2154,90,2094,8352,64,2059,2242,34,8329,2243,211,232,65,2081,172,2090,2095,1,2242,113]

theorem envBound9502 : H12AffineFastState.Bounded env9502 := by
  intro p hp
  have h : env9502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9501_9502 : H12AffineEnvironment.transform 11 2242 env9501 = env9502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2242 env9501 == env9502) = true)

theorem identity9502 : scanCanonicalize (H12AffineFastState.compose env9502 (packedSelected [3,7,8,9,10,11,13,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 56) := by decide +kernel

theorem selectedBound9502 : packedSelected [3,7,8,9,10,11,13,14,18] rootPS < 2^1333 := by decide +kernel

def env9503 : List Nat := [2,4,8,16,32,64,128,85,217,84,2048,2242,56,232,152,18,2154,90,2094,152,64,2059,2242,34,177,2243,211,232,65,2081,172,2090,2095,1,2242,113]

theorem envBound9503 : H12AffineFastState.Bounded env9503 := by
  intro p hp
  have h : env9503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9502_9503 : H12AffineEnvironment.transform 12 56 env9502 = env9503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 56 env9502 == env9503) = true)

theorem identity9503 : scanCanonicalize (H12AffineFastState.compose env9503 (packedSelected [0,1,4,7,8,9,12,14,19] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound9503 : packedSelected [0,1,4,7,8,9,12,14,19] rootPS < 2^1333 := by decide +kernel

def env9504 : List Nat := [2,4,8,16,32,64,128,85,217,84,10,200,56,232,152,18,96,90,36,152,64,1,200,34,177,201,211,232,65,43,172,32,37,1,200,113]

theorem envBound9504 : H12AffineFastState.Bounded env9504 := by
  intro p hp
  have h : env9504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9503_9504 : H12AffineEnvironment.transform 10 10 env9503 = env9504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env9503 == env9504) = true)

theorem identity9504 : scanCanonicalize (H12AffineFastState.compose env9504 (packedSelected [0,3,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound9504 : packedSelected [0,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env9505 : List Nat := [2,4,8,16,32,64,2,85,91,84,10,74,56,106,26,18,96,90,36,26,64,1,74,34,51,75,81,106,65,43,46,32,37,1,74,113]

theorem envBound9505 : H12AffineFastState.Bounded env9505 := by
  intro p hp
  have h : env9505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9504_9505 : H12AffineEnvironment.transform 6 2 env9504 = env9505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env9504 == env9505) = true)

theorem identity9505 : scanCanonicalize (H12AffineFastState.compose env9505 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound9505 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env9506 : List Nat := [2,4,8,16,32,17,2,4,10,5,10,27,56,59,26,18,49,11,36,26,17,1,27,34,51,26,0,59,16,43,46,32,37,1,27,32]

theorem envBound9506 : H12AffineFastState.Bounded env9506 := by
  intro p hp
  have h : env9506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9505_9506 : H12AffineEnvironment.transform 5 17 env9505 = env9506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9505 == env9506) = true)

theorem identity9506 : scanCanonicalize (H12AffineFastState.compose env9506 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9506 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9507 : List Nat := [2,4,3,16,32,17,2,4,1,5,1,16,51,48,17,18,49,0,36,17,17,1,16,34,51,17,0,48,16,32,37,32,37,1,16,32]

theorem envBound9507 : H12AffineFastState.Bounded env9507 := by
  intro p hp
  have h : env9507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9506_9507 : H12AffineEnvironment.transform 2 3 env9506 = env9507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9506 == env9507) = true)

def env9508 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,24770,4605,262144,4960,8693,65,4194304,5004,34,8329,21040,278625,4214985,4215093,18633,505,4211100,4961,16617,21040,1021]

theorem envBound9508 : H12AffineFastState.Bounded env9508 := by
  intro p hp
  have h : env9508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9460_9508 : H12AffineEnvironment.transform 20 65 env9460 = env9508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env9460 == env9508) = true)

theorem identity9508 : scanCanonicalize (H12AffineFastState.compose env9508 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 279375) := by decide +kernel

theorem selectedBound9508 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9509 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,24770,4605,262144,4960,8693,65,279375,5004,34,8329,21040,278625,267142,266874,18633,505,262867,4961,16617,21040,1021]

theorem envBound9509 : H12AffineFastState.Bounded env9509 := by
  intro p hp
  have h : env9509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9508_9509 : H12AffineEnvironment.transform 21 279375 env9508 = env9509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 279375 env9508 == env9509) = true)

def env9510 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,560,8693,8946,4605,262144,4960,8693,65,262527,5004,34,8329,4096,262737,267142,266874,2809,505,262867,4961,729,4096,1021]

theorem envBound9510 : H12AffineFastState.Bounded env9510 := by
  intro p hp
  have h : env9510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9509_9510 : H12AffineEnvironment.transform 13 560 env9509 = env9510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env9509 == env9510) = true)

def env9511 : List Nat := [2,4,8,16,32,64,128,256,216,257,2048,4096,8192,232,8693,8234,4605,262144,4536,8693,65,262527,4436,34,8329,4096,262281,266590,266402,2081,505,262155,4537,1,4096,293]

theorem envBound9511 : H12AffineFastState.Bounded env9511 := by
  intro p hp
  have h : env9511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9510_9511 : H12AffineEnvironment.transform 8 216 env9510 = env9511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env9510 == env9511) = true)

theorem identity9511 : scanCanonicalize (H12AffineFastState.compose env9511 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound9511 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9512 : List Nat := [2,4,8,16,32,64,128,84,216,85,2048,4096,8192,232,8353,8234,4265,262144,4332,8353,65,262187,4096,34,8329,4096,262281,266250,266402,2081,173,262155,4333,1,4096,113]

theorem envBound9512 : H12AffineFastState.Bounded env9512 := by
  intro p hp
  have h : env9512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9511_9512 : H12AffineEnvironment.transform 7 84 env9511 = env9512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env9511 == env9512) = true)

theorem identity9512 : scanCanonicalize (H12AffineFastState.compose env9512 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(17+1) ^^^ 90) := by decide +kernel

theorem selectedBound9512 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env9513 : List Nat := [2,4,8,16,32,64,128,84,216,85,2048,4096,8192,232,8353,8234,4265,90,4332,8353,65,113,4096,34,8329,4096,211,4176,4344,2081,173,81,4333,1,4096,113]

theorem envBound9513 : H12AffineFastState.Bounded env9513 := by
  intro p hp
  have h : env9513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9512_9513 : H12AffineEnvironment.transform 17 90 env9512 = env9513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 90 env9512 == env9513) = true)

theorem identity9513 : scanCanonicalize (H12AffineFastState.compose env9513 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound9513 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env9514 : List Nat := [2,4,8,16,32,64,41,84,113,85,2048,4096,8192,65,8200,8234,4096,90,4165,8200,65,113,4096,34,8224,4096,122,4176,4177,2081,4,81,4164,1,4096,113]

theorem envBound9514 : H12AffineFastState.Bounded env9514 := by
  intro p hp
  have h : env9514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9513_9514 : H12AffineEnvironment.transform 6 41 env9513 = env9514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env9513 == env9514) = true)

theorem identity9514 : scanCanonicalize (H12AffineFastState.compose env9514 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 6217) := by decide +kernel

theorem selectedBound9514 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9515 : List Nat := [2,4,8,16,32,64,41,84,113,85,2048,4096,6217,65,6209,6243,4096,90,4165,6209,65,113,4096,34,6249,4096,122,4176,4177,2081,4,81,4164,1,4096,113]

theorem envBound9515 : H12AffineFastState.Bounded env9515 := by
  intro p hp
  have h : env9515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9514_9515 : H12AffineEnvironment.transform 12 6217 env9514 = env9515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6217 env9514 == env9515) = true)

theorem identity9515 : scanCanonicalize (H12AffineFastState.compose env9515 (packedSelected [1,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound9515 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env9516 : List Nat := [2,4,8,16,32,17,41,5,32,4,2048,4096,6168,16,6160,6194,4096,11,4116,6160,16,32,4096,34,6200,4096,43,4097,4096,2081,4,0,4117,1,4096,32]

theorem envBound9516 : H12AffineFastState.Bounded env9516 := by
  intro p hp
  have h : env9516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9515_9516 : H12AffineEnvironment.transform 5 17 env9515 = env9516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9515 == env9516) = true)

theorem identity9516 : scanCanonicalize (H12AffineFastState.compose env9516 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound9516 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9517 : List Nat := [2,4,8,16,17,17,24,5,17,4,2048,4096,6168,16,6160,6147,4096,11,4116,6160,16,17,4096,19,6153,4096,26,4097,4096,2064,4,0,4117,1,4096,17]

theorem envBound9517 : H12AffineFastState.Bounded env9517 := by
  intro p hp
  have h : env9517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9516_9517 : H12AffineEnvironment.transform 4 17 env9516 = env9517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env9516 == env9517) = true)

theorem identity9517 : scanCanonicalize (H12AffineFastState.compose env9517 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound9517 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env9518 : List Nat := [2,4,8,16,17,17,24,5,17,4,26,4096,4098,16,4106,4121,4096,11,4116,4106,16,17,4096,19,4115,4096,26,4097,4096,10,4,0,4117,1,4096,17]

theorem envBound9518 : H12AffineFastState.Bounded env9518 := by
  intro p hp
  have h : env9518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9517_9518 : H12AffineEnvironment.transform 10 26 env9517 = env9518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env9517 == env9518) = true)

theorem identity9518 : scanCanonicalize (H12AffineFastState.compose env9518 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9518 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env9519 : List Nat := [2,4,3,16,17,17,19,5,17,4,17,4096,4098,16,4097,4114,4096,0,4116,4097,16,17,4096,19,4115,4096,17,4097,4096,1,4,0,4117,1,4096,17]

theorem envBound9519 : H12AffineFastState.Bounded env9519 := by
  intro p hp
  have h : env9519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9518_9519 : H12AffineEnvironment.transform 2 3 env9518 = env9519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9518 == env9519) = true)

theorem identity9519 : scanCanonicalize (H12AffineFastState.compose env9519 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound9519 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env9520 : List Nat := [2,4,3,1,0,0,2,5,0,4,0,4096,4098,1,4097,4099,4096,0,4101,4097,1,0,4096,2,4098,4096,0,4097,4096,1,4,0,4100,1,4096,0]

theorem envBound9520 : H12AffineFastState.Bounded env9520 := by
  intro p hp
  have h : env9520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9519_9520 : H12AffineEnvironment.transform 3 1 env9519 = env9520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env9519 == env9520) = true)

theorem identity9520 : scanCanonicalize (H12AffineFastState.compose env9520 (packedSelected [12] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound9520 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env9521 : List Nat := [2,4,3,1,0,0,2,5,0,4,0,1,3,1,0,2,1,0,4,0,1,0,1,2,3,1,0,0,1,1,4,0,5,1,1,0]

theorem envBound9521 : H12AffineFastState.Bounded env9521 := by
  intro p hp
  have h : env9521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9520_9521 : H12AffineEnvironment.transform 11 1 env9520 = env9521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env9520 == env9521) = true)

def leafEnv9521 : List Nat := [2,4,3,1,0,0,2,5,0,4,0,1,3,1,0,2,1,0,4,0,1,0,1,2,4,3,1,1,0,0,1,1,4,0,5,1,4,3,1,0,1,0,0]

def active9521 : List Nat := [0,1]

def tree9521 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9521 : H12WitnessSearch.Good tree9521 := H12GlobalWitnessIndex.good

theorem leafIdentity9521 : H12AffineFastState.composeSystem env9521 rootObs = leafEnv9521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9521 rootObs == leafEnv9521) = true)

theorem terminalChecked9521 : H12PackedTerminal.terminalCheckFast leafEnv9521 active9521 tree9521 = true := by decide +kernel

def env9522 : List Nat := [2,4,8,16,32,64,128,256,217,257,2048,4096,8192,233,8693,8235,4605,262144,4537,8693,65,262527,4437,34,8329,4096,262280,266591,266403,2080,505,262154,4536,0,4096,292]

theorem envBound9522 : H12AffineFastState.Bounded env9522 := by
  intro p hp
  have h : env9522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9510_9522 : H12AffineEnvironment.transform 8 217 env9510 = env9522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env9510 == env9522) = true)

theorem identity9522 : scanCanonicalize (H12AffineFastState.compose env9522 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 162) := by decide +kernel

theorem selectedBound9522 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9523 : List Nat := [2,4,8,16,32,64,128,256,217,257,2048,4096,8192,233,8693,8235,4605,162,4537,8693,65,477,4437,34,8329,4096,42,4605,4097,2080,505,168,4536,0,4096,292]

theorem envBound9523 : H12AffineFastState.Bounded env9523 := by
  intro p hp
  have h : env9523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9522_9523 : H12AffineEnvironment.transform 17 162 env9522 = env9523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 162 env9522 == env9523) = true)

theorem identity9523 : scanCanonicalize (H12AffineFastState.compose env9523 (packedSelected [7,20,27] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound9523 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9524 : List Nat := [2,4,8,16,32,16,128,256,137,257,2048,4096,8192,185,8613,8235,4525,162,4537,8613,17,397,4357,34,8329,4096,42,4525,4097,2080,425,168,4536,0,4096,292]

theorem envBound9524 : H12AffineFastState.Bounded env9524 := by
  intro p hp
  have h : env9524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9523_9524 : H12AffineEnvironment.transform 5 16 env9523 = env9524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9523 == env9524) = true)

theorem identity9524 : scanCanonicalize (H12AffineFastState.compose env9524 (packedSelected [13,14,17] rootPS)) = affineNative (2^(10+1) ^^^ 390) := by decide +kernel

theorem selectedBound9524 : packedSelected [13,14,17] rootPS < 2^1333 := by decide +kernel

def env9525 : List Nat := [2,4,8,16,32,16,128,256,137,257,390,4096,8192,185,8613,8235,4525,162,4537,8613,17,397,4357,34,8329,4096,42,4525,4097,422,425,168,4536,0,4096,292]

theorem envBound9525 : H12AffineFastState.Bounded env9525 := by
  intro p hp
  have h : env9525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9524_9525 : H12AffineEnvironment.transform 10 390 env9524 = env9525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 390 env9524 == env9525) = true)

theorem identity9525 : scanCanonicalize (H12AffineFastState.compose env9525 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound9525 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env9526 : List Nat := [2,4,8,16,32,16,128,256,137,257,390,184,8192,185,8613,8235,277,162,257,8613,17,397,445,34,8329,184,42,277,185,422,425,168,256,0,184,292]

theorem envBound9526 : H12AffineFastState.Bounded env9526 := by
  intro p hp
  have h : env9526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9525_9526 : H12AffineEnvironment.transform 11 184 env9525 = env9526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env9525 == env9526) = true)

theorem identity9526 : scanCanonicalize (H12AffineFastState.compose env9526 (packedSelected [0,4,5,7,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound9526 : packedSelected [0,4,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env9527 : List Nat := [2,4,8,16,32,16,2,256,11,257,260,58,8192,59,8487,8235,277,32,257,8487,17,271,319,34,8203,58,42,277,59,292,299,42,256,0,58,292]

theorem envBound9527 : H12AffineFastState.Bounded env9527 := by
  intro p hp
  have h : env9527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9526_9527 : H12AffineEnvironment.transform 6 2 env9526 = env9527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env9526 == env9527) = true)

theorem identity9527 : scanCanonicalize (H12AffineFastState.compose env9527 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound9527 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env9528 : List Nat := [2,4,8,16,32,16,2,256,11,257,260,58,268,59,43,295,277,32,257,43,17,271,319,34,263,58,42,277,59,292,299,42,256,0,58,292]

theorem envBound9528 : H12AffineFastState.Bounded env9528 := by
  intro p hp
  have h : env9528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9527_9528 : H12AffineEnvironment.transform 12 268 env9527 = env9528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env9527 == env9528) = true)

theorem identity9528 : scanCanonicalize (H12AffineFastState.compose env9528 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound9528 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env9529 : List Nat := [2,4,8,16,16,16,2,256,11,257,260,10,268,11,27,279,277,16,257,27,17,271,271,18,263,10,26,277,11,276,283,26,256,0,10,276]

theorem envBound9529 : H12AffineFastState.Bounded env9529 := by
  intro p hp
  have h : env9529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9528_9529 : H12AffineEnvironment.transform 4 16 env9528 = env9529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env9528 == env9529) = true)

theorem identity9529 : scanCanonicalize (H12AffineFastState.compose env9529 (packedSelected [1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound9529 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env9530 : List Nat := [2,4,8,16,16,16,2,21,11,20,17,10,25,11,27,2,0,16,20,27,17,26,26,18,18,10,26,0,11,1,14,26,21,0,10,1]

theorem envBound9530 : H12AffineFastState.Bounded env9530 := by
  intro p hp
  have h : env9530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9529_9530 : H12AffineEnvironment.transform 7 21 env9529 = env9530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env9529 == env9530) = true)

theorem identity9530 : scanCanonicalize (H12AffineFastState.compose env9530 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9530 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9531 : List Nat := [2,4,2,16,16,16,2,21,1,20,17,0,19,1,17,2,0,16,20,17,17,16,16,18,18,0,16,0,1,1,4,16,21,0,0,1]

theorem envBound9531 : H12AffineFastState.Bounded env9531 := by
  intro p hp
  have h : env9531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9530_9531 : H12AffineEnvironment.transform 2 2 env9530 = env9531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9530 == env9531) = true)

theorem identity9531 : scanCanonicalize (H12AffineFastState.compose env9531 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound9531 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env9532 : List Nat := [2,4,2,1,1,1,2,4,1,5,0,0,2,1,0,2,0,1,5,0,0,1,1,3,3,0,1,0,1,1,4,1,4,0,0,1]

theorem envBound9532 : H12AffineFastState.Bounded env9532 := by
  intro p hp
  have h : env9532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9531_9532 : H12AffineEnvironment.transform 3 1 env9531 = env9532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env9531 == env9532) = true)

def leafEnv9532 : List Nat := [2,4,2,1,1,1,2,4,1,5,0,0,2,1,0,2,0,1,5,0,0,1,1,3,4,3,1,0,1,0,1,1,4,1,4,0,4,2,0,1,1,0,0]

def active9532 : List Nat := [0,1]

def tree9532 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9532 : H12WitnessSearch.Good tree9532 := H12GlobalWitnessIndex.good

theorem leafIdentity9532 : H12AffineFastState.composeSystem env9532 rootObs = leafEnv9532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9532 rootObs == leafEnv9532) = true)

theorem terminalChecked9532 : H12PackedTerminal.terminalCheckFast leafEnv9532 active9532 tree9532 = true := by decide +kernel

def env9533 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,561,8693,8947,4605,262144,4960,8693,65,262526,5004,34,8329,4097,262736,267142,266874,2808,505,262867,4961,728,4097,1021]

theorem envBound9533 : H12AffineFastState.Bounded env9533 := by
  intro p hp
  have h : env9533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9509_9533 : H12AffineEnvironment.transform 13 561 env9509 = env9533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env9509 == env9533) = true)

def env9534 : List Nat := [2,4,8,16,32,64,128,256,216,257,2048,4096,8192,233,8693,8235,4605,262144,4536,8693,65,262526,4436,34,8329,4097,262280,266590,266402,2080,505,262155,4537,0,4097,293]

theorem envBound9534 : H12AffineFastState.Bounded env9534 := by
  intro p hp
  have h : env9534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9533_9534 : H12AffineEnvironment.transform 8 216 env9533 = env9534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env9533 == env9534) = true)

theorem identity9534 : scanCanonicalize (H12AffineFastState.compose env9534 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 163) := by decide +kernel

theorem selectedBound9534 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9535 : List Nat := [2,4,8,16,32,64,128,256,216,257,2048,4096,8192,233,8693,8235,4605,163,4536,8693,65,477,4436,34,8329,4097,43,4605,4097,2080,505,168,4537,0,4097,293]

theorem envBound9535 : H12AffineFastState.Bounded env9535 := by
  intro p hp
  have h : env9535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9534_9535 : H12AffineEnvironment.transform 17 163 env9534 = env9535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 163 env9534 == env9535) = true)

theorem identity9535 : scanCanonicalize (H12AffineFastState.compose env9535 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound9535 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9536 : List Nat := [2,4,8,16,32,64,128,4,216,5,2048,4096,8192,233,8433,8235,4345,163,4284,8433,65,217,4176,34,8329,4097,43,4345,4097,2080,253,168,4285,0,4097,33]

theorem envBound9536 : H12AffineFastState.Bounded env9536 := by
  intro p hp
  have h : env9536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9535_9536 : H12AffineEnvironment.transform 7 4 env9535 = env9536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env9535 == env9536) = true)

theorem identity9536 : scanCanonicalize (H12AffineFastState.compose env9536 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2195) := by decide +kernel

theorem selectedBound9536 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env9537 : List Nat := [2,4,8,16,32,64,128,4,216,5,2048,2195,8192,233,8433,8235,2154,163,2095,8433,65,217,2243,34,8329,2194,43,2154,2194,2080,253,168,2094,0,2194,33]

theorem envBound9537 : H12AffineFastState.Bounded env9537 := by
  intro p hp
  have h : env9537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9536_9537 : H12AffineEnvironment.transform 11 2195 env9536 = env9537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2195 env9536 == env9537) = true)

theorem identity9537 : scanCanonicalize (H12AffineFastState.compose env9537 (packedSelected [0,2,4,7,9,11,13,18] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound9537 : packedSelected [0,2,4,7,9,11,13,18] rootPS < 2^1333 := by decide +kernel

def env9538 : List Nat := [2,4,8,16,32,11,128,4,147,5,2048,2195,8192,162,8378,8235,2081,163,2095,8378,10,146,2184,34,8329,2194,43,2081,2194,2080,182,168,2094,0,2194,33]

theorem envBound9538 : H12AffineFastState.Bounded env9538 := by
  intro p hp
  have h : env9538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9537_9538 : H12AffineEnvironment.transform 5 11 env9537 = env9538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env9537 == env9538) = true)

theorem identity9538 : scanCanonicalize (H12AffineFastState.compose env9538 (packedSelected [1,4,5,9,13,14] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound9538 : packedSelected [1,4,5,9,13,14] rootPS < 2^1333 := by decide +kernel

def env9539 : List Nat := [2,4,8,16,32,11,41,4,58,5,2048,2106,8192,11,8211,8235,2081,10,2095,8211,10,59,2081,34,8224,2107,43,2081,2107,2080,31,1,2094,0,2107,33]

theorem envBound9539 : H12AffineFastState.Bounded env9539 := by
  intro p hp
  have h : env9539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9538_9539 : H12AffineEnvironment.transform 6 41 env9538 = env9539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env9538 == env9539) = true)

theorem identity9539 : scanCanonicalize (H12AffineFastState.compose env9539 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 2105) := by decide +kernel

theorem selectedBound9539 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env9540 : List Nat := [2,4,8,16,32,11,41,4,58,5,2048,2106,2105,11,2090,2066,2081,10,2095,2090,10,59,2081,34,2073,2107,43,2081,2107,2080,31,1,2094,0,2107,33]

theorem envBound9540 : H12AffineFastState.Bounded env9540 := by
  intro p hp
  have h : env9540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9539_9540 : H12AffineEnvironment.transform 12 2105 env9539 = env9540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2105 env9539 == env9540) = true)

theorem identity9540 : scanCanonicalize (H12AffineFastState.compose env9540 (packedSelected [4,7] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound9540 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env9541 : List Nat := [2,4,8,16,32,11,41,4,58,5,27,33,34,11,49,9,58,10,52,49,10,59,58,34,2,32,43,58,32,59,31,1,53,0,32,33]

theorem envBound9541 : H12AffineFastState.Bounded env9541 := by
  intro p hp
  have h : env9541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9540_9541 : H12AffineEnvironment.transform 10 27 env9540 = env9541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env9540 == env9541) = true)

theorem identity9541 : scanCanonicalize (H12AffineFastState.compose env9541 (packedSelected [1,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound9541 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env9542 : List Nat := [2,4,8,1,32,11,41,4,43,5,10,33,34,11,32,9,43,10,37,32,10,42,43,34,2,32,43,43,32,42,14,1,36,0,32,33]

theorem envBound9542 : H12AffineFastState.Bounded env9542 := by
  intro p hp
  have h : env9542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9541_9542 : H12AffineEnvironment.transform 3 1 env9541 = env9542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env9541 == env9542) = true)

theorem identity9542 : scanCanonicalize (H12AffineFastState.compose env9542 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound9542 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env9543 : List Nat := [2,4,8,1,0,11,9,4,11,5,10,1,2,11,0,9,11,10,5,0,10,10,11,2,2,0,11,11,0,10,14,1,4,0,0,1]

theorem envBound9543 : H12AffineFastState.Bounded env9543 := by
  intro p hp
  have h : env9543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9542_9543 : H12AffineEnvironment.transform 4 0 env9542 = env9543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9542 == env9543) = true)

theorem identity9543 : scanCanonicalize (H12AffineFastState.compose env9543 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9543 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9544 : List Nat := [2,4,3,1,0,0,2,4,0,5,1,1,2,0,0,2,0,1,5,0,1,1,0,2,2,0,0,0,0,1,5,1,4,0,0,1]

theorem envBound9544 : H12AffineFastState.Bounded env9544 := by
  intro p hp
  have h : env9544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9543_9544 : H12AffineEnvironment.transform 2 3 env9543 = env9544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9543 == env9544) = true)

theorem identity9544 : scanCanonicalize (H12AffineFastState.compose env9544 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound9544 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9545 : List Nat := [2,1,3,1,0,0,2,1,0,0,1,1,2,0,0,2,0,1,0,0,1,1,0,2,2,0,0,0,0,1,0,1,1,0,0,1]

theorem envBound9545 : H12AffineFastState.Bounded env9545 := by
  intro p hp
  have h : env9545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9544_9545 : H12AffineEnvironment.transform 1 1 env9544 = env9545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env9544 == env9545) = true)

def env9546 : List Nat := [2,4,8,16,32,64,128,256,217,257,2048,4096,8192,232,8693,8234,4605,262144,4537,8693,65,262526,4437,34,8329,4097,262281,266591,266403,2081,505,262154,4536,1,4097,292]

theorem envBound9546 : H12AffineFastState.Bounded env9546 := by
  intro p hp
  have h : env9546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9533_9546 : H12AffineEnvironment.transform 8 217 env9533 = env9546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env9533 == env9546) = true)

theorem identity9546 : scanCanonicalize (H12AffineFastState.compose env9546 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound9546 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9547 : List Nat := [2,4,8,16,32,64,128,84,217,85,2048,4096,8192,232,8353,8234,4265,262144,4333,8353,65,262186,4097,34,8329,4097,262281,266251,266403,2081,173,262154,4332,1,4097,112]

theorem envBound9547 : H12AffineFastState.Bounded env9547 := by
  intro p hp
  have h : env9547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9546_9547 : H12AffineEnvironment.transform 7 84 env9546 = env9547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env9546 == env9547) = true)

theorem identity9547 : scanCanonicalize (H12AffineFastState.compose env9547 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound9547 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env9548 : List Nat := [2,4,8,16,32,64,120,84,33,85,2048,4096,8192,16,8281,8234,4177,262144,4117,8281,65,262186,4097,34,8305,4097,262257,266251,266331,2081,85,262154,4116,1,4097,112]

theorem envBound9548 : H12AffineFastState.Bounded env9548 := by
  intro p hp
  have h : env9548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9547_9548 : H12AffineEnvironment.transform 6 120 env9547 = env9548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env9547 == env9548) = true)

theorem identity9548 : scanCanonicalize (H12AffineFastState.compose env9548 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(17+1) ^^^ 6240) := by decide +kernel

theorem selectedBound9548 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env9549 : List Nat := [2,4,8,16,32,64,120,84,33,85,2048,4096,8192,16,8281,8234,4177,6240,4117,8281,65,6218,4097,34,8305,4097,6161,2155,2107,2081,85,6250,4116,1,4097,112]

theorem envBound9549 : H12AffineFastState.Bounded env9549 := by
  intro p hp
  have h : env9549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9548_9549 : H12AffineEnvironment.transform 17 6240 env9548 = env9549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6240 env9548 == env9549) = true)

theorem identity9549 : scanCanonicalize (H12AffineFastState.compose env9549 (packedSelected [0,1,3,4,7,9,12,13,14,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 2154) := by decide +kernel

theorem selectedBound9549 : packedSelected [0,1,3,4,7,9,12,13,14,15,17] rootPS < 2^1333 := by decide +kernel

def env9550 : List Nat := [2,4,8,16,32,64,120,84,33,85,2048,2154,8192,16,8281,8234,2107,10,2175,8281,65,32,2155,34,8305,2155,123,2155,2107,2081,85,0,2174,1,2155,112]

theorem envBound9550 : H12AffineFastState.Bounded env9550 := by
  intro p hp
  have h : env9550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9549_9550 : H12AffineEnvironment.transform 11 2154 env9549 = env9550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2154 env9549 == env9550) = true)

theorem identity9550 : scanCanonicalize (H12AffineFastState.compose env9550 (packedSelected [1,2,5,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2050) := by decide +kernel

theorem selectedBound9550 : packedSelected [1,2,5,7,9] rootPS < 2^1333 := by decide +kernel

def env9551 : List Nat := [2,4,8,16,32,64,120,84,33,85,2048,2154,2050,16,2139,2088,2107,10,2175,2139,65,32,2155,34,2163,2155,123,2155,2107,2081,85,0,2174,1,2155,112]

theorem envBound9551 : H12AffineFastState.Bounded env9551 := by
  intro p hp
  have h : env9551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9550_9551 : H12AffineEnvironment.transform 12 2050 env9550 = env9551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2050 env9550 == env9551) = true)

theorem identity9551 : scanCanonicalize (H12AffineFastState.compose env9551 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound9551 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env9552 : List Nat := [2,4,8,16,16,64,72,84,17,85,2048,2138,2050,16,2139,2072,2059,10,2127,2139,65,16,2139,18,2115,2139,75,2139,2059,2065,85,0,2126,1,2139,64]

theorem envBound9552 : H12AffineFastState.Bounded env9552 := by
  intro p hp
  have h : env9552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9551_9552 : H12AffineEnvironment.transform 4 16 env9551 = env9552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env9551 == env9552) = true)

theorem identity9552 : scanCanonicalize (H12AffineFastState.compose env9552 (packedSelected [0,2,4,10] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound9552 : packedSelected [0,2,4,10] rootPS < 2^1333 := by decide +kernel

def env9553 : List Nat := [2,4,8,16,16,64,72,84,17,85,16,74,18,16,75,8,27,10,95,75,65,16,75,18,83,75,75,75,27,1,85,0,94,1,75,64]

theorem envBound9553 : H12AffineFastState.Bounded env9553 := by
  intro p hp
  have h : env9553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9552_9553 : H12AffineEnvironment.transform 10 16 env9552 = env9553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env9552 == env9553) = true)

theorem identity9553 : scanCanonicalize (H12AffineFastState.compose env9553 (packedSelected [2,7] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound9553 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env9554 : List Nat := [2,4,8,16,16,0,8,20,17,21,16,10,18,16,11,8,27,10,31,11,1,16,11,18,19,11,11,11,27,1,21,0,30,1,11,0]

theorem envBound9554 : H12AffineFastState.Bounded env9554 := by
  intro p hp
  have h : env9554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9553_9554 : H12AffineEnvironment.transform 5 0 env9553 = env9554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env9553 == env9554) = true)

def env9555 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,262144,4961,8693,2097152,4194304,5005,90336,8329,21040,278624,4214984,4215092,75786,504,4268383,4960,73770,2175666,90943]

theorem envBound9555 : H12AffineFastState.Bounded env9555 := by
  intro p hp
  have h : env9555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9458_9555 : H12AffineEnvironment.transform 18 4961 env9458 = env9555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4961 env9458 == env9555) = true)

theorem identity9555 : scanCanonicalize (H12AffineFastState.compose env9555 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound9555 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9556 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,262144,4764,8200,2097152,4194304,4720,90336,8329,21040,278624,4214984,4214985,75786,5,4268194,4765,73770,2175666,90818]

theorem envBound9556 : H12AffineFastState.Bounded env9556 := by
  intro p hp
  have h : env9556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9555_9556 : H12AffineEnvironment.transform 7 253 env9555 = env9556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env9555 == env9556) = true)

def env9557 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,262144,4764,8200,64,4194304,4720,90336,8329,21040,278624,4214984,4214985,75786,5,4268194,4765,73770,78578,90818]

theorem envBound9557 : H12AffineFastState.Bounded env9557 := by
  intro p hp
  have h : env9557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9556_9557 : H12AffineEnvironment.transform 20 64 env9556 = env9557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env9556 == env9557) = true)

theorem identity9557 : scanCanonicalize (H12AffineFastState.compose env9557 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 20642) := by decide +kernel

theorem selectedBound9557 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9558 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,20642,4764,8200,64,4194304,4720,90336,8329,21040,4290,4214984,4214985,75786,5,4268194,4765,73770,78578,90818]

theorem envBound9558 : H12AffineFastState.Bounded env9558 := by
  intro p hp
  have h : env9558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9557_9558 : H12AffineEnvironment.transform 17 20642 env9557 = env9558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20642 env9557 == env9558) = true)

def env9559 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,20642,4764,8200,64,16960,4720,90336,8329,21040,4290,4744,4745,75786,5,90850,4765,73770,78578,90818]

theorem envBound9559 : H12AffineFastState.Bounded env9559 := by
  intro p hp
  have h : env9559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9558_9559 : H12AffineEnvironment.transform 21 16960 env9558 = env9559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16960 env9558 == env9559) = true)

def env9560 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,560,8200,65536,4096,4754,4764,8200,64,112,4720,74448,8329,4096,4290,4744,4745,75786,5,73938,4765,73770,78578,73970]

theorem envBound9560 : H12AffineFastState.Bounded env9560 := by
  intro p hp
  have h : env9560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9559_9560 : H12AffineEnvironment.transform 13 560 env9559 = env9560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env9559 == env9560) = true)

theorem identity9560 : scanCanonicalize (H12AffineFastState.compose env9560 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 12979) := by decide +kernel

theorem selectedBound9560 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9561 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,560,8200,12979,4096,4754,4764,8200,64,112,4720,4195,8329,4096,4290,4744,4745,6841,5,4705,4765,4761,65,4673]

theorem envBound9561 : H12AffineFastState.Bounded env9561 := by
  intro p hp
  have h : env9561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9560_9561 : H12AffineEnvironment.transform 15 12979 env9560 = env9561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12979 env9560 == env9561) = true)

theorem identity9561 : scanCanonicalize (H12AffineFastState.compose env9561 (packedSelected [14] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound9561 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env9562 : List Nat := [2,4,8,16,32,64,128,253,33,252,2048,4096,8192,17,8200,12434,4096,4275,4285,8200,64,112,4177,4195,8329,4096,4290,4265,4264,6296,5,4160,4284,4280,65,4192]

theorem envBound9562 : H12AffineFastState.Bounded env9562 := by
  intro p hp
  have h : env9562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9561_9562 : H12AffineEnvironment.transform 8 33 env9561 = env9562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env9561 == env9562) = true)

theorem identity9562 : scanCanonicalize (H12AffineFastState.compose env9562 (packedSelected [5,8,10,12,15,19] rootPS)) = affineNative (2^(11+1) ^^^ 2155) := by decide +kernel

theorem selectedBound9562 : packedSelected [5,8,10,12,15,19] rootPS < 2^1333 := by decide +kernel

def env9563 : List Nat := [2,4,8,16,32,64,128,253,33,252,2048,2155,8192,17,8200,10489,2155,2264,2262,8200,64,112,2106,2056,8329,2155,2217,2242,2243,243,5,2091,2263,2259,65,2059]

theorem envBound9563 : H12AffineFastState.Bounded env9563 := by
  intro p hp
  have h : env9563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9562_9563 : H12AffineEnvironment.transform 11 2155 env9562 = env9563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2155 env9562 == env9563) = true)

theorem identity9563 : scanCanonicalize (H12AffineFastState.compose env9563 (packedSelected [0,1,3,7,12,13,15,17,20] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound9563 : packedSelected [0,1,3,7,12,13,15,17,20] rootPS < 2^1333 := by decide +kernel

def env9564 : List Nat := [2,4,8,16,32,64,128,253,33,252,131,232,8192,17,8200,8314,232,91,85,8200,64,112,185,139,8329,232,42,65,64,243,5,168,84,80,65,136]

theorem envBound9564 : H12AffineFastState.Bounded env9564 := by
  intro p hp
  have h : env9564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9563_9564 : H12AffineEnvironment.transform 10 131 env9563 = env9564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env9563 == env9564) = true)

theorem identity9564 : scanCanonicalize (H12AffineFastState.compose env9564 (packedSelected [0,1,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 138) := by decide +kernel

theorem selectedBound9564 : packedSelected [0,1,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env9565 : List Nat := [2,4,8,16,32,64,128,253,33,252,131,232,138,17,130,240,232,91,85,130,64,112,185,139,3,232,42,65,64,243,5,168,84,80,65,136]

theorem envBound9565 : H12AffineFastState.Bounded env9565 := by
  intro p hp
  have h : env9565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9564_9565 : H12AffineEnvironment.transform 12 138 env9564 = env9565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 138 env9564 == env9565) = true)

theorem identity9565 : scanCanonicalize (H12AffineFastState.compose env9565 (packedSelected [0,1,4,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound9565 : packedSelected [0,1,4,8,9] rootPS < 2^1333 := by decide +kernel

def env9566 : List Nat := [2,4,8,16,0,64,128,221,1,220,131,200,138,17,130,208,200,91,85,130,64,80,153,139,3,200,10,65,64,211,5,136,84,80,65,136]

theorem envBound9566 : H12AffineFastState.Bounded env9566 := by
  intro p hp
  have h : env9566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9565_9566 : H12AffineEnvironment.transform 4 0 env9565 = env9566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9565 == env9566) = true)

theorem identity9566 : scanCanonicalize (H12AffineFastState.compose env9566 (packedSelected [1,2,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 73) := by decide +kernel

theorem selectedBound9566 : packedSelected [1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env9567 : List Nat := [2,4,8,16,0,64,73,20,1,21,74,1,67,17,75,25,1,91,85,75,64,80,80,66,3,1,10,65,64,26,5,65,84,80,65,65]

theorem envBound9567 : H12AffineFastState.Bounded env9567 := by
  intro p hp
  have h : env9567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9566_9567 : H12AffineEnvironment.transform 6 73 env9566 = env9567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env9566 == env9567) = true)

theorem identity9567 : scanCanonicalize (H12AffineFastState.compose env9567 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9567 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env9568 : List Nat := [2,4,3,16,0,64,66,20,1,21,65,1,67,17,64,18,1,80,85,64,64,80,80,66,3,1,1,65,64,17,5,65,84,80,65,65]

theorem envBound9568 : H12AffineFastState.Bounded env9568 := by
  intro p hp
  have h : env9568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9567_9568 : H12AffineEnvironment.transform 2 3 env9567 = env9568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9567 == env9568) = true)

def env9569 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,561,8200,65536,4096,4755,4764,8200,64,113,4720,74449,8329,4097,4290,4744,4745,75786,5,73939,4765,73770,78578,73971]

theorem envBound9569 : H12AffineFastState.Bounded env9569 := by
  intro p hp
  have h : env9569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9559_9569 : H12AffineEnvironment.transform 13 561 env9559 = env9569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env9559 == env9569) = true)

theorem identity9569 : scanCanonicalize (H12AffineFastState.compose env9569 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 12874) := by decide +kernel

theorem selectedBound9569 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9570 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,561,8200,12874,4096,4755,4764,8200,64,113,4720,4251,8329,4097,4290,4744,4745,6720,5,4761,4765,4704,184,4793]

theorem envBound9570 : H12AffineFastState.Bounded env9570 := by
  intro p hp
  have h : env9570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9569_9570 : H12AffineEnvironment.transform 15 12874 env9569 = env9570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12874 env9569 == env9570) = true)

theorem identity9570 : scanCanonicalize (H12AffineFastState.compose env9570 (packedSelected [1,3,5,8,10,13,14,17,19] rootPS)) = affineNative (2^(10+1) ^^^ 211) := by decide +kernel

theorem selectedBound9570 : packedSelected [1,3,5,8,10,13,14,17,19] rootPS < 2^1333 := by decide +kernel

def env9571 : List Nat := [2,4,8,16,32,64,128,253,512,252,211,4096,8192,561,8200,12874,4096,4755,4764,8200,64,113,4720,4251,8329,4097,4290,4744,4745,4755,5,4761,4765,4704,184,4793]

theorem envBound9571 : H12AffineFastState.Bounded env9571 := by
  intro p hp
  have h : env9571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9570_9571 : H12AffineEnvironment.transform 10 211 env9570 = env9571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 211 env9570 == env9571) = true)

theorem identity9571 : scanCanonicalize (H12AffineFastState.compose env9571 (packedSelected [0,1,3,4,7,9,12,14,15,17,21] rootPS)) = affineNative (2^(8+1) ^^^ 113) := by decide +kernel

theorem selectedBound9571 : packedSelected [0,1,3,4,7,9,12,14,15,17,21] rootPS < 2^1333 := by decide +kernel

def env9572 : List Nat := [2,4,8,16,32,64,128,253,113,252,211,4096,8192,64,8200,12347,4096,4322,4333,8200,64,113,4097,4251,8329,4097,4290,4345,4344,4322,5,4328,4332,4113,184,4296]

theorem envBound9572 : H12AffineFastState.Bounded env9572 := by
  intro p hp
  have h : env9572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9571_9572 : H12AffineEnvironment.transform 8 113 env9571 = env9572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 113 env9571 == env9572) = true)

theorem identity9572 : scanCanonicalize (H12AffineFastState.compose env9572 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound9572 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env9573 : List Nat := [2,4,8,16,32,16,128,173,33,172,131,4096,8192,16,8200,12347,4096,4274,4285,8200,16,33,4097,4251,8329,4097,4242,4265,4264,4274,5,4280,4284,4113,184,4248]

theorem envBound9573 : H12AffineFastState.Bounded env9573 := by
  intro p hp
  have h : env9573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9572_9573 : H12AffineEnvironment.transform 5 16 env9572 = env9573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9572 == env9573) = true)

theorem identity9573 : scanCanonicalize (H12AffineFastState.compose env9573 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound9573 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env9574 : List Nat := [2,4,8,11,32,11,128,173,33,172,131,4096,8192,11,8200,12320,4096,4265,4262,8200,11,33,4097,4224,8329,4097,4233,4265,4264,4265,5,4259,4263,4106,163,4227]

theorem envBound9574 : H12AffineFastState.Bounded env9574 := by
  intro p hp
  have h : env9574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9573_9574 : H12AffineEnvironment.transform 3 11 env9573 = env9574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env9573 == env9574) = true)

theorem identity9574 : scanCanonicalize (H12AffineFastState.compose env9574 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound9574 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env9575 : List Nat := [2,4,8,11,32,11,128,173,33,172,131,32,8192,11,8200,8192,32,137,134,8200,11,33,33,160,8329,33,169,137,136,137,5,131,135,42,163,163]

theorem envBound9575 : H12AffineFastState.Bounded env9575 := by
  intro p hp
  have h : env9575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9574_9575 : H12AffineEnvironment.transform 11 32 env9574 = env9575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env9574 == env9575) = true)

theorem identity9575 : scanCanonicalize (H12AffineFastState.compose env9575 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound9575 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env9576 : List Nat := [2,4,8,11,32,11,128,173,33,172,131,32,41,11,33,41,32,137,134,33,11,33,33,160,160,33,169,137,136,137,5,131,135,42,163,163]

theorem envBound9576 : H12AffineFastState.Bounded env9576 := by
  intro p hp
  have h : env9576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9575_9576 : H12AffineEnvironment.transform 12 41 env9575 = env9576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env9575 == env9576) = true)

theorem identity9576 : scanCanonicalize (H12AffineFastState.compose env9576 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound9576 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env9577 : List Nat := [2,4,8,11,32,11,8,37,33,36,11,32,41,11,33,41,32,1,14,33,11,33,33,40,40,33,33,1,0,1,5,11,15,42,43,43]

theorem envBound9577 : H12AffineFastState.Bounded env9577 := by
  intro p hp
  have h : env9577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9576_9577 : H12AffineEnvironment.transform 6 8 env9576 = env9577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env9576 == env9577) = true)

def env9578 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,20642,4764,8200,64,16961,4720,90336,8329,21040,4290,4745,4744,75786,5,90851,4765,73770,78578,90818]

theorem envBound9578 : H12AffineFastState.Bounded env9578 := by
  intro p hp
  have h : env9578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9558_9578 : H12AffineEnvironment.transform 21 16961 env9558 = env9578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16961 env9558 == env9578) = true)

def env9579 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,560,8200,65536,4096,4754,4764,8200,64,113,4720,74448,8329,4096,4290,4745,4744,75786,5,73939,4765,73770,78578,73970]

theorem envBound9579 : H12AffineFastState.Bounded env9579 := by
  intro p hp
  have h : env9579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9578_9579 : H12AffineEnvironment.transform 13 560 env9578 = env9579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env9578 == env9579) = true)

theorem identity9579 : scanCanonicalize (H12AffineFastState.compose env9579 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound9579 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9580 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,65,8192,560,8200,65536,65,723,733,8200,64,113,561,74448,8329,65,131,712,713,75786,5,73939,732,73770,74419,73970]

theorem envBound9580 : H12AffineFastState.Bounded env9580 := by
  intro p hp
  have h : env9580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9579_9580 : H12AffineEnvironment.transform 11 65 env9579 = env9580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env9579 == env9580) = true)

theorem identity9580 : scanCanonicalize (H12AffineFastState.compose env9580 (packedSelected [1,3,5,8,10,14,17,19,21] rootPS)) = affineNative (2^(10+1) ^^^ 122) := by decide +kernel

theorem selectedBound9580 : packedSelected [1,3,5,8,10,14,17,19,21] rootPS < 2^1333 := by decide +kernel

def env9581 : List Nat := [2,4,8,16,32,64,128,253,512,252,122,65,8192,560,8200,65536,65,723,733,8200,64,113,561,74448,8329,65,131,712,713,73840,5,73939,732,73770,74419,73970]

theorem envBound9581 : H12AffineFastState.Bounded env9581 := by
  intro p hp
  have h : env9581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9580_9581 : H12AffineEnvironment.transform 10 122 env9580 = env9581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 122 env9580 == env9581) = true)

theorem identity9581 : scanCanonicalize (H12AffineFastState.compose env9581 (packedSelected [1,3,4,9,12,14,15,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound9581 : packedSelected [1,3,4,9,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env9582 : List Nat := [2,4,8,16,32,17,128,172,512,173,43,16,8192,560,8200,65536,16,642,652,8200,17,32,561,74369,8329,16,131,665,664,73761,5,73858,653,73770,74419,73891]

theorem envBound9582 : H12AffineFastState.Bounded env9582 := by
  intro p hp
  have h : env9582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9581_9582 : H12AffineEnvironment.transform 5 17 env9581 = env9582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9581 == env9582) = true)

theorem identity9582 : scanCanonicalize (H12AffineFastState.compose env9582 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 8714) := by decide +kernel

theorem selectedBound9582 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env9583 : List Nat := [2,4,8,16,32,17,128,172,512,173,43,16,8192,560,8200,8714,16,642,652,8200,17,32,561,139,8329,16,131,665,664,555,5,648,653,544,185,681]

theorem envBound9583 : H12AffineFastState.Bounded env9583 := by
  intro p hp
  have h : env9583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9582_9583 : H12AffineEnvironment.transform 15 8714 env9582 = env9583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8714 env9582 == env9583) = true)

theorem identity9583 : scanCanonicalize (H12AffineFastState.compose env9583 (packedSelected [3,7,8,9,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound9583 : packedSelected [3,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env9584 : List Nat := [2,4,8,16,32,17,128,172,512,173,43,16,657,560,665,155,16,642,652,665,17,32,561,139,536,16,131,665,664,555,5,648,653,544,185,681]

theorem envBound9584 : H12AffineFastState.Bounded env9584 := by
  intro p hp
  have h : env9584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9583_9584 : H12AffineEnvironment.transform 12 657 env9583 = env9584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env9583 == env9584) = true)

theorem identity9584 : scanCanonicalize (H12AffineFastState.compose env9584 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound9584 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env9585 : List Nat := [2,4,8,16,32,17,128,172,32,173,43,16,177,16,185,155,16,162,172,185,17,32,17,139,56,16,131,185,184,11,5,168,173,0,185,137]

theorem envBound9585 : H12AffineFastState.Bounded env9585 := by
  intro p hp
  have h : env9585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9584_9585 : H12AffineEnvironment.transform 8 32 env9584 = env9585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env9584 == env9585) = true)

theorem identity9585 : scanCanonicalize (H12AffineFastState.compose env9585 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound9585 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9586 : List Nat := [2,4,8,16,32,17,18,62,32,63,43,16,35,16,43,9,16,48,62,43,17,32,17,25,56,16,17,43,42,11,5,58,63,0,43,27]

theorem envBound9586 : H12AffineFastState.Bounded env9586 := by
  intro p hp
  have h : env9586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9585_9586 : H12AffineEnvironment.transform 6 18 env9585 = env9586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env9585 == env9586) = true)

theorem identity9586 : scanCanonicalize (H12AffineFastState.compose env9586 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound9586 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env9587 : List Nat := [2,4,8,16,17,17,18,15,17,14,26,16,18,16,26,9,16,1,15,26,17,17,17,25,9,16,17,26,27,11,5,11,14,0,26,27]

theorem envBound9587 : H12AffineFastState.Bounded env9587 := by
  intro p hp
  have h : env9587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9586_9587 : H12AffineEnvironment.transform 4 17 env9586 = env9587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env9586 == env9587) = true)

def env9588 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,561,8200,65536,4096,4755,4764,8200,64,112,4720,74449,8329,4097,4290,4745,4744,75786,5,73938,4765,73770,78578,73971]

theorem envBound9588 : H12AffineFastState.Bounded env9588 := by
  intro p hp
  have h : env9588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9578_9588 : H12AffineEnvironment.transform 13 561 env9578 = env9588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env9578 == env9588) = true)

theorem identity9588 : scanCanonicalize (H12AffineFastState.compose env9588 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound9588 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9589 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,184,8192,561,8200,65536,184,555,548,8200,64,112,712,74449,8329,185,122,561,560,75786,5,73938,549,73770,74314,73971]

theorem envBound9589 : H12AffineFastState.Bounded env9589 := by
  intro p hp
  have h : env9589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9588_9589 : H12AffineEnvironment.transform 11 184 env9588 = env9589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env9588 == env9589) = true)

theorem identity9589 : scanCanonicalize (H12AffineFastState.compose env9589 (packedSelected [13,14,21] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound9589 : packedSelected [13,14,21] rootPS < 2^1333 := by decide +kernel

def env9590 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,184,8192,561,8200,8323,184,555,548,8200,64,112,712,594,8329,185,122,561,560,2185,5,81,549,169,713,112]

theorem envBound9590 : H12AffineFastState.Bounded env9590 := by
  intro p hp
  have h : env9590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9589_9590 : H12AffineEnvironment.transform 15 8323 env9589 = env9590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env9589 == env9590) = true)

theorem identity9590 : scanCanonicalize (H12AffineFastState.compose env9590 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound9590 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env9591 : List Nat := [2,4,8,16,32,64,128,253,512,252,131,184,8192,561,8200,8323,184,555,548,8200,64,112,712,594,8329,185,122,561,560,10,5,81,549,169,713,112]

theorem envBound9591 : H12AffineFastState.Bounded env9591 := by
  intro p hp
  have h : env9591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9590_9591 : H12AffineEnvironment.transform 10 131 env9590 = env9591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env9590 == env9591) = true)

theorem identity9591 : scanCanonicalize (H12AffineFastState.compose env9591 (packedSelected [4,5,8,9,11,12,13,18] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound9591 : packedSelected [4,5,8,9,11,12,13,18] rootPS < 2^1333 := by decide +kernel

def env9592 : List Nat := [2,4,8,16,32,64,128,253,163,252,131,184,8192,146,8200,8323,184,136,135,8200,64,112,107,241,8329,185,122,146,147,10,5,81,134,169,106,112]

theorem envBound9592 : H12AffineFastState.Bounded env9592 := by
  intro p hp
  have h : env9592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9591_9592 : H12AffineEnvironment.transform 8 163 env9591 = env9592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env9591 == env9592) = true)

theorem identity9592 : scanCanonicalize (H12AffineFastState.compose env9592 (packedSelected [2,3,4,7,8,11,13,14] rootPS)) = affineNative (2^(12+1) ^^^ 67) := by decide +kernel

theorem selectedBound9592 : packedSelected [2,3,4,7,8,11,13,14] rootPS < 2^1333 := by decide +kernel

def env9593 : List Nat := [2,4,8,16,32,64,128,253,163,252,131,184,67,146,75,192,184,136,135,75,64,112,107,241,202,185,122,146,147,10,5,81,134,169,106,112]

theorem envBound9593 : H12AffineFastState.Bounded env9593 := by
  intro p hp
  have h : env9593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9592_9593 : H12AffineEnvironment.transform 12 67 env9592 = env9593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 67 env9592 == env9593) = true)

theorem identity9593 : scanCanonicalize (H12AffineFastState.compose env9593 (packedSelected [0,1,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound9593 : packedSelected [0,1,8,9] rootPS < 2^1333 := by decide +kernel

def env9594 : List Nat := [2,4,8,16,32,64,34,95,1,94,33,26,67,48,75,98,26,42,37,75,64,112,107,83,104,27,122,48,49,10,5,81,36,11,106,112]

theorem envBound9594 : H12AffineFastState.Bounded env9594 := by
  intro p hp
  have h : env9594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9593_9594 : H12AffineEnvironment.transform 6 34 env9593 = env9594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env9593 == env9594) = true)

theorem identity9594 : scanCanonicalize (H12AffineFastState.compose env9594 (packedSelected [2,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound9594 : packedSelected [2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env9595 : List Nat := [2,4,8,16,1,64,3,95,1,94,0,26,67,17,75,67,26,11,4,75,64,81,74,83,73,27,91,17,16,10,5,81,5,11,75,81]

theorem envBound9595 : H12AffineFastState.Bounded env9595 := by
  intro p hp
  have h : env9595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9594_9595 : H12AffineEnvironment.transform 4 1 env9594 = env9595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9594 == env9595) = true)

theorem identity9595 : scanCanonicalize (H12AffineFastState.compose env9595 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound9595 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env9596 : List Nat := [2,4,8,11,1,64,3,68,1,69,0,1,67,10,75,67,1,11,4,75,64,74,74,72,73,0,64,10,11,10,5,74,5,11,75,74]

theorem envBound9596 : H12AffineFastState.Bounded env9596 := by
  intro p hp
  have h : env9596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9595_9596 : H12AffineEnvironment.transform 3 11 env9595 = env9596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env9595 == env9596) = true)

theorem identity9596 : scanCanonicalize (H12AffineFastState.compose env9596 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound9596 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9597 : List Nat := [2,4,8,11,1,0,3,4,1,5,0,1,3,10,11,3,1,11,4,11,0,10,10,8,9,0,0,10,11,10,5,10,5,11,11,10]

theorem envBound9597 : H12AffineFastState.Bounded env9597 := by
  intro p hp
  have h : env9597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9596_9597 : H12AffineEnvironment.transform 5 0 env9596 = env9597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env9596 == env9597) = true)

theorem identity9597 : scanCanonicalize (H12AffineFastState.compose env9597 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9597 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9598 : List Nat := [2,4,2,1,1,0,3,4,1,5,0,1,3,0,1,3,1,1,4,1,0,0,0,2,3,0,0,0,1,0,5,0,5,1,1,0]

theorem envBound9598 : H12AffineFastState.Bounded env9598 := by
  intro p hp
  have h : env9598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9597_9598 : H12AffineEnvironment.transform 2 2 env9597 = env9598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9597 == env9598) = true)

theorem identity9598 : scanCanonicalize (H12AffineFastState.compose env9598 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound9598 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9599 : List Nat := [2,1,2,1,1,0,3,1,1,0,0,1,3,0,1,3,1,1,1,1,0,0,0,2,3,0,0,0,1,0,0,0,0,1,1,0]

theorem envBound9599 : H12AffineFastState.Bounded env9599 := by
  intro p hp
  have h : env9599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9598_9599 : H12AffineEnvironment.transform 1 1 env9598 = env9599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env9598 == env9599) = true)

def env9600 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,262144,4764,8200,65,4194304,4720,90336,8329,21040,278624,4214984,4214985,75786,5,4268194,4765,73770,78579,90818]

theorem envBound9600 : H12AffineFastState.Bounded env9600 := by
  intro p hp
  have h : env9600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9556_9600 : H12AffineEnvironment.transform 20 65 env9556 = env9600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env9556 == env9600) = true)

theorem identity9600 : scanCanonicalize (H12AffineFastState.compose env9600 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 17090) := by decide +kernel

theorem selectedBound9600 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9601 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,17090,4764,8200,65,4194304,4720,90336,8329,21040,674,4214984,4214985,75786,5,4268194,4765,73770,78579,90818]

theorem envBound9601 : H12AffineFastState.Bounded env9601 := by
  intro p hp
  have h : env9601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9600_9601 : H12AffineEnvironment.transform 17 17090 env9600 = env9601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 17090 env9600 == env9601) = true)

def env9602 : List Nat := [2,4,8,16,32,64,56,69,512,68,2048,4096,8192,16384,8200,65536,4096,17018,4644,8200,65,4194304,4720,90200,8241,21040,538,4214896,4214897,75786,5,4268058,4645,73770,78411,90746]

theorem envBound9602 : H12AffineFastState.Bounded env9602 := by
  intro p hp
  have h : env9602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9601_9602 : H12AffineEnvironment.transform 6 56 env9601 = env9602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env9601 == env9602) = true)

theorem identity9602 : scanCanonicalize (H12AffineFastState.compose env9602 (packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS)) = affineNative (2^(15+1) ^^^ 8730) := by decide +kernel

theorem selectedBound9602 : packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS < 2^1333 := by decide +kernel

def env9603 : List Nat := [2,4,8,16,32,64,56,69,512,68,2048,4096,8192,16384,8200,8730,4096,17018,4644,8200,65,4194304,4720,16962,8241,21040,538,4214896,4214897,2576,5,4194816,4645,560,4177,16480]

theorem envBound9603 : H12AffineFastState.Bounded env9603 := by
  intro p hp
  have h : env9603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9602_9603 : H12AffineEnvironment.transform 15 8730 env9602 = env9603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8730 env9602 == env9603) = true)

theorem identity9603 : scanCanonicalize (H12AffineFastState.compose env9603 (packedSelected [1,8,13,19,21] rootPS)) = affineNative (2^(21+1) ^^^ 48) := by decide +kernel

theorem selectedBound9603 : packedSelected [1,8,13,19,21] rootPS < 2^1333 := by decide +kernel

def env9604 : List Nat := [2,4,8,16,32,64,56,69,512,68,2048,4096,8192,16384,8200,8730,4096,17018,4644,8200,65,48,4720,16962,8241,21040,538,20544,20545,2576,5,560,4645,560,4177,16480]

theorem envBound9604 : H12AffineFastState.Bounded env9604 := by
  intro p hp
  have h : env9604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9603_9604 : H12AffineEnvironment.transform 21 48 env9603 = env9604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 48 env9603 == env9604) = true)

theorem identity9604 : scanCanonicalize (H12AffineFastState.compose env9604 (packedSelected [1,2,8,11,13,14,17,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound9604 : packedSelected [1,2,8,11,13,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env9605 : List Nat := [2,4,8,16,32,64,56,69,97,68,2048,4096,8192,16384,8200,8315,4096,16411,4165,8200,65,48,4113,16419,8241,20561,123,20544,20545,2161,5,81,4164,81,4177,16480]

theorem envBound9605 : H12AffineFastState.Bounded env9605 := by
  intro p hp
  have h : env9605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9604_9605 : H12AffineEnvironment.transform 8 97 env9604 = env9605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env9604 == env9605) = true)

theorem identity9605 : scanCanonicalize (H12AffineFastState.compose env9605 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2155) := by decide +kernel

theorem selectedBound9605 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env9606 : List Nat := [2,4,8,16,32,64,56,69,97,68,2048,2155,8192,16384,8200,8315,2155,16411,2094,8200,65,48,2170,16419,8241,18490,123,18475,18474,2161,5,81,2095,81,2106,16480]

theorem envBound9606 : H12AffineFastState.Bounded env9606 := by
  intro p hp
  have h : env9606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9605_9606 : H12AffineEnvironment.transform 11 2155 env9605 = env9606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2155 env9605 == env9606) = true)

theorem identity9606 : scanCanonicalize (H12AffineFastState.compose env9606 (packedSelected [0,1,2,3,4,7,9,11,14,18,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 0) := by decide +kernel

theorem selectedBound9606 : packedSelected [0,1,2,3,4,7,9,11,14,18,24,28] rootPS < 2^1333 := by decide +kernel

def env9607 : List Nat := [2,4,8,16,32,64,56,69,97,68,2048,2155,8192,0,8200,8315,2155,27,2094,8200,65,48,2170,35,8241,2106,123,2091,2090,2161,5,81,2095,81,2106,96]

theorem envBound9607 : H12AffineFastState.Bounded env9607 := by
  intro p hp
  have h : env9607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9606_9607 : H12AffineEnvironment.transform 13 0 env9606 = env9607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env9606 == env9607) = true)

def env9608 : List Nat := [2,4,8,16,32,64,57,68,512,69,2048,4096,8192,16384,8200,65536,4096,17019,4645,8200,65,4194304,4720,90201,8240,21040,539,4214897,4214896,75786,5,4268059,4644,73770,78410,90747]

theorem envBound9608 : H12AffineFastState.Bounded env9608 := by
  intro p hp
  have h : env9608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9601_9608 : H12AffineEnvironment.transform 6 57 env9601 = env9608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env9601 == env9608) = true)

theorem identity9608 : scanCanonicalize (H12AffineFastState.compose env9608 (packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 16976) := by decide +kernel

theorem selectedBound9608 : packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS < 2^1333 := by decide +kernel

def env9609 : List Nat := [2,4,8,16,32,64,57,68,512,69,2048,4096,8192,16384,8200,65536,4096,17019,4645,8200,65,16976,4720,90201,8240,21040,539,4641,4640,75786,5,90699,4644,73770,78410,90747]

theorem envBound9609 : H12AffineFastState.Bounded env9609 := by
  intro p hp
  have h : env9609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9608_9609 : H12AffineEnvironment.transform 21 16976 env9608 = env9609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16976 env9608 == env9609) = true)

theorem identity9609 : scanCanonicalize (H12AffineFastState.compose env9609 (packedSelected [0,1,7,8,13,19,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 8730) := by decide +kernel

theorem selectedBound9609 : packedSelected [0,1,7,8,13,19,20,21] rootPS < 2^1333 := by decide +kernel

def env9610 : List Nat := [2,4,8,16,32,64,57,68,512,69,2048,4096,8192,16384,8200,8730,4096,17019,4645,8200,65,16976,4720,16963,8240,21040,539,4641,4640,2576,5,16465,4644,560,4176,16481]

theorem envBound9610 : H12AffineFastState.Bounded env9610 := by
  intro p hp
  have h : env9610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9609_9610 : H12AffineEnvironment.transform 15 8730 env9609 = env9610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8730 env9609 == env9610) = true)

theorem identity9610 : scanCanonicalize (H12AffineFastState.compose env9610 (packedSelected [1,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 625) := by decide +kernel

theorem selectedBound9610 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env9611 : List Nat := [2,4,8,16,32,64,57,68,512,69,2048,4096,8192,625,8200,8730,4096,10,4645,8200,65,33,4720,50,8240,4161,539,4641,4640,2576,5,544,4644,560,4176,528]

theorem envBound9611 : H12AffineFastState.Bounded env9611 := by
  intro p hp
  have h : env9611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9610_9611 : H12AffineEnvironment.transform 13 625 env9610 = env9611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 625 env9610 == env9611) = true)

theorem identity9611 : scanCanonicalize (H12AffineFastState.compose env9611 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 587) := by decide +kernel

theorem selectedBound9611 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env9612 : List Nat := [2,4,8,16,32,64,57,68,512,69,587,4096,8192,625,8200,8730,4096,10,4645,8200,65,33,4720,50,8240,4161,539,4641,4640,91,5,544,4644,560,4176,528]

theorem envBound9612 : H12AffineFastState.Bounded env9612 := by
  intro p hp
  have h : env9612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9611_9612 : H12AffineEnvironment.transform 10 587 env9611 = env9612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 587 env9611 == env9612) = true)

theorem identity9612 : scanCanonicalize (H12AffineFastState.compose env9612 (packedSelected [0,7,20] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9612 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9613 : List Nat := [2,4,8,0,32,64,41,68,512,69,587,4096,8192,609,8200,8714,4096,10,4645,8200,65,33,4704,34,8224,4161,523,4641,4640,75,5,544,4644,544,4160,512]

theorem envBound9613 : H12AffineFastState.Bounded env9613 := by
  intro p hp
  have h : env9613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9612_9613 : H12AffineEnvironment.transform 3 0 env9612 = env9613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9612 == env9613) = true)

theorem identity9613 : scanCanonicalize (H12AffineFastState.compose env9613 (packedSelected [3,4,5,7,8,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 4681) := by decide +kernel

theorem selectedBound9613 : packedSelected [3,4,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env9614 : List Nat := [2,4,8,0,32,64,41,68,512,69,587,4096,4681,609,4673,4163,4096,10,4645,4673,65,33,4704,34,4713,4161,523,4641,4640,75,5,544,4644,544,4160,512]

theorem envBound9614 : H12AffineFastState.Bounded env9614 := by
  intro p hp
  have h : env9614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9613_9614 : H12AffineEnvironment.transform 12 4681 env9613 = env9614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4681 env9613 == env9614) = true)

theorem identity9614 : scanCanonicalize (H12AffineFastState.compose env9614 (packedSelected [0,2,3,5,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 608) := by decide +kernel

theorem selectedBound9614 : packedSelected [0,2,3,5,8,9] rootPS < 2^1333 := by decide +kernel

def env9615 : List Nat := [2,4,8,0,32,64,41,68,512,69,587,608,41,609,33,547,608,10,69,33,65,33,0,34,9,545,523,65,64,75,5,544,68,544,544,512]

theorem envBound9615 : H12AffineFastState.Bounded env9615 := by
  intro p hp
  have h : env9615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9614_9615 : H12AffineEnvironment.transform 11 608 env9614 = env9615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 608 env9614 == env9615) = true)

def env9616 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,4194304,524524,90337,8329,21041,807681,4735913,4735573,605034,529049,4796991,524289,602954,2695634,90942]

theorem envBound9616 : H12AffineFastState.Bounded env9616 := by
  intro p hp
  have h : env9616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9457_9616 : H12AffineEnvironment.transform 23 90337 env9457 = env9616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90337 env9457 == env9616) = true)

def env9617 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,262144,4960,8693,2097152,4194304,5004,90337,8329,21041,278625,4214985,4215093,75786,505,4268383,4961,73770,2175666,90942]

theorem envBound9617 : H12AffineFastState.Bounded env9617 := by
  intro p hp
  have h : env9617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9616_9617 : H12AffineEnvironment.transform 18 4960 env9616 = env9617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4960 env9616 == env9617) = true)

theorem identity9617 : scanCanonicalize (H12AffineFastState.compose env9617 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound9617 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9618 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,262144,4765,8200,2097152,4194304,4721,90337,8329,21041,278625,4214985,4214984,75786,4,4268194,4764,73770,2175666,90819]

theorem envBound9618 : H12AffineFastState.Bounded env9618 := by
  intro p hp
  have h : env9618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9617_9618 : H12AffineEnvironment.transform 7 253 env9617 = env9618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env9617 == env9618) = true)

def env9619 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,262144,4765,8200,64,4194304,4721,90337,8329,21041,278625,4214985,4214984,75786,4,4268194,4764,73770,78578,90819]

theorem envBound9619 : H12AffineFastState.Bounded env9619 := by
  intro p hp
  have h : env9619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9618_9619 : H12AffineEnvironment.transform 20 64 env9618 = env9619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env9618 == env9619) = true)

theorem identity9619 : scanCanonicalize (H12AffineFastState.compose env9619 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 279115) := by decide +kernel

theorem selectedBound9619 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9620 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,262144,4765,8200,64,279115,4721,90337,8329,21041,278625,266882,266883,75786,4,353001,4764,73770,78578,90819]

theorem envBound9620 : H12AffineFastState.Bounded env9620 := by
  intro p hp
  have h : env9620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9619_9620 : H12AffineEnvironment.transform 21 279115 env9619 = env9620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 279115 env9619 == env9620) = true)

def env9621 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,74240,4765,8200,64,90187,4721,90337,8329,21041,90721,77954,77955,75786,4,16617,4764,73770,78578,90819]

theorem envBound9621 : H12AffineFastState.Bounded env9621 := by
  intro p hp
  have h : env9621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9620_9621 : H12AffineEnvironment.transform 17 74240 env9620 = env9621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 74240 env9620 == env9621) = true)

theorem identity9621 : scanCanonicalize (H12AffineFastState.compose env9621 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 24771) := by decide +kernel

theorem selectedBound9621 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9622 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,24771,4096,17091,4765,8200,64,136,4721,34,8329,21041,674,20545,20544,18633,4,16617,4764,16617,21041,512]

theorem envBound9622 : H12AffineFastState.Bounded env9622 := by
  intro p hp
  have h : env9622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9621_9622 : H12AffineEnvironment.transform 15 24771 env9621 = env9622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24771 env9621 == env9622) = true)

theorem identity9622 : scanCanonicalize (H12AffineFastState.compose env9622 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound9622 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9623 : List Nat := [2,4,8,16,32,64,40,85,512,84,2048,4096,8192,16384,8200,24683,4096,17003,4661,8200,64,32,4721,34,8225,21041,522,20545,20544,18529,4,16449,4660,16449,21041,512]

theorem envBound9623 : H12AffineFastState.Bounded env9623 := by
  intro p hp
  have h : env9623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9622_9623 : H12AffineEnvironment.transform 6 40 env9622 = env9623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env9622 == env9623) = true)

theorem identity9623 : scanCanonicalize (H12AffineFastState.compose env9623 (packedSelected [0,1,3,4,7,9,12,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 2107) := by decide +kernel

theorem selectedBound9623 : packedSelected [0,1,3,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env9624 : List Nat := [2,4,8,16,32,64,40,85,512,84,2048,2107,8192,16384,8200,24683,2107,17003,2574,8200,64,32,2634,34,8225,18954,522,18554,18555,18529,4,16449,2575,16449,18954,512]

theorem envBound9624 : H12AffineFastState.Bounded env9624 := by
  intro p hp
  have h : env9624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9623_9624 : H12AffineEnvironment.transform 11 2107 env9623 = env9624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2107 env9623 == env9624) = true)

theorem identity9624 : scanCanonicalize (H12AffineFastState.compose env9624 (packedSelected [0,1,2,3,4,8,11] rootPS)) = affineNative (2^(13+1) ^^^ 8707) := by decide +kernel

theorem selectedBound9624 : packedSelected [0,1,2,3,4,8,11] rootPS < 2^1333 := by decide +kernel

def env9625 : List Nat := [2,4,8,16,32,64,40,85,512,84,2048,2107,8192,8707,8200,616,2107,8296,2574,8200,64,32,2634,34,8225,10249,522,10873,10872,10850,4,8770,2575,8770,10249,512]

theorem envBound9625 : H12AffineFastState.Bounded env9625 := by
  intro p hp
  have h : env9625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9624_9625 : H12AffineEnvironment.transform 13 8707 env9624 = env9625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8707 env9624 == env9625) = true)

theorem identity9625 : scanCanonicalize (H12AffineFastState.compose env9625 (packedSelected [0,1,2,3,4,8,12,13] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound9625 : packedSelected [0,1,2,3,4,8,12,13] rootPS < 2^1333 := by decide +kernel

def env9626 : List Nat := [2,4,8,16,16,64,24,85,512,84,2048,2059,8192,8707,8200,600,2059,8280,2574,8200,64,16,2634,18,8209,10249,522,10825,10824,10834,4,8770,2575,8770,10249,512]

theorem envBound9626 : H12AffineFastState.Bounded env9626 := by
  intro p hp
  have h : env9626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9625_9626 : H12AffineEnvironment.transform 4 16 env9625 = env9626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env9625 == env9626) = true)

theorem identity9626 : scanCanonicalize (H12AffineFastState.compose env9626 (packedSelected [0,2,3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 26) := by decide +kernel

theorem selectedBound9626 : packedSelected [0,2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env9627 : List Nat := [2,4,8,16,16,26,24,15,512,14,2048,2059,8192,8707,8200,514,2059,8194,2574,8200,26,16,2576,18,8209,10249,522,10771,10770,10760,4,8728,2575,8728,10249,512]

theorem envBound9627 : H12AffineFastState.Bounded env9627 := by
  intro p hp
  have h : env9627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9626_9627 : H12AffineEnvironment.transform 5 26 env9626 = env9627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 26 env9626 == env9627) = true)

theorem identity9627 : scanCanonicalize (H12AffineFastState.compose env9627 (packedSelected [3,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound9627 : packedSelected [3,4,8] rootPS < 2^1333 := by decide +kernel

def env9628 : List Nat := [2,4,8,16,16,26,24,15,16,14,2048,2059,8192,8211,8200,18,2059,8194,2078,8200,26,16,2048,18,8209,10249,26,10243,10242,10264,4,8200,2079,8200,10249,16]

theorem envBound9628 : H12AffineFastState.Bounded env9628 := by
  intro p hp
  have h : env9628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9627_9628 : H12AffineEnvironment.transform 8 16 env9627 = env9628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env9627 == env9628) = true)

theorem identity9628 : scanCanonicalize (H12AffineFastState.compose env9628 (packedSelected [1,2,3,4,5,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9628 : packedSelected [1,2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env9629 : List Nat := [2,4,8,0,0,10,8,15,0,14,2048,2059,8192,8195,8200,2,2059,8194,2062,8200,10,0,2048,2,8193,10249,10,10243,10242,10248,4,8200,2063,8200,10249,0]

theorem envBound9629 : H12AffineFastState.Bounded env9629 := by
  intro p hp
  have h : env9629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9628_9629 : H12AffineEnvironment.transform 3 0 env9628 = env9629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9628 == env9629) = true)

theorem identity9629 : scanCanonicalize (H12AffineFastState.compose env9629 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9629 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env9630 : List Nat := [2,4,3,0,0,1,3,4,0,5,2048,2048,8192,8195,8195,2,2048,8194,2053,8195,1,0,2048,2,8193,10242,1,10243,10242,10243,4,8195,2052,8195,10242,0]

theorem envBound9630 : H12AffineFastState.Bounded env9630 := by
  intro p hp
  have h : env9630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9629_9630 : H12AffineEnvironment.transform 2 3 env9629 = env9630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9629 == env9630) = true)

def env9631 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,74241,4765,8200,64,90186,4721,90337,8329,21041,90720,77955,77954,75786,4,16616,4764,73770,78578,90819]

theorem envBound9631 : H12AffineFastState.Bounded env9631 := by
  intro p hp
  have h : env9631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9620_9631 : H12AffineEnvironment.transform 17 74241 env9620 = env9631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 74241 env9620 == env9631) = true)

theorem identity9631 : scanCanonicalize (H12AffineFastState.compose env9631 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound9631 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env9632 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,8323,4096,642,4765,8200,64,16585,4721,16482,8329,21041,17123,4096,4097,2185,4,16616,4764,169,4721,16960]

theorem envBound9632 : H12AffineFastState.Bounded env9632 := by
  intro p hp
  have h : env9632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9631_9632 : H12AffineEnvironment.transform 15 8323 env9631 = env9632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env9631 == env9632) = true)

theorem identity9632 : scanCanonicalize (H12AffineFastState.compose env9632 (packedSelected [0,2,11,13,14,17,18,27] rootPS)) = affineNative (2^(13+1) ^^^ 609) := by decide +kernel

theorem selectedBound9632 : packedSelected [0,2,11,13,14,17,18,27] rootPS < 2^1333 := by decide +kernel

def env9633 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,609,8200,8323,4096,642,4765,8200,64,680,4721,515,8329,4176,130,4096,4097,2185,4,649,4764,169,4721,33]

theorem envBound9633 : H12AffineFastState.Bounded env9633 := by
  intro p hp
  have h : env9633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9632_9633 : H12AffineEnvironment.transform 13 609 env9632 = env9633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 609 env9632 == env9633) = true)

theorem identity9633 : scanCanonicalize (H12AffineFastState.compose env9633 (packedSelected [2,14,23,32] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound9633 : packedSelected [2,14,23,32] rootPS < 2^1333 := by decide +kernel

def env9634 : List Nat := [2,4,8,16,32,64,128,253,217,252,2048,4096,8192,184,8200,8323,4096,91,4164,8200,64,113,4264,218,8329,4176,130,4096,4097,2185,4,80,4165,169,4264,33]

theorem envBound9634 : H12AffineFastState.Bounded env9634 := by
  intro p hp
  have h : env9634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9633_9634 : H12AffineEnvironment.transform 8 217 env9633 = env9634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env9633 == env9634) = true)

theorem identity9634 : scanCanonicalize (H12AffineFastState.compose env9634 (packedSelected [2,11,13,14,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound9634 : packedSelected [2,11,13,14,17,18] rootPS < 2^1333 := by decide +kernel

def env9635 : List Nat := [2,4,8,16,32,64,121,4,32,5,2048,4096,8192,65,8200,8314,4096,91,4164,8200,64,113,4177,35,8304,4176,123,4096,4097,2160,4,80,4165,80,4177,33]

theorem envBound9635 : H12AffineFastState.Bounded env9635 := by
  intro p hp
  have h : env9635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9634_9635 : H12AffineEnvironment.transform 6 121 env9634 = env9635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env9634 == env9635) = true)

theorem identity9635 : scanCanonicalize (H12AffineFastState.compose env9635 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 2154) := by decide +kernel

theorem selectedBound9635 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env9636 : List Nat := [2,4,8,16,32,64,121,4,32,5,2048,2154,8192,65,8200,8314,2154,91,2094,8200,64,113,2107,35,8304,2106,123,2154,2155,2160,4,80,2095,80,2107,33]

theorem envBound9636 : H12AffineFastState.Bounded env9636 := by
  intro p hp
  have h : env9636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9635_9636 : H12AffineEnvironment.transform 11 2154 env9635 = env9636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2154 env9635 == env9636) = true)

theorem identity9636 : scanCanonicalize (H12AffineFastState.compose env9636 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound9636 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env9637 : List Nat := [2,4,8,16,32,64,121,4,32,5,64,42,8192,65,8200,8314,42,91,110,8200,64,113,123,35,8304,122,123,42,43,48,4,80,111,80,123,33]

theorem envBound9637 : H12AffineFastState.Bounded env9637 := by
  intro p hp
  have h : env9637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9636_9637 : H12AffineEnvironment.transform 10 64 env9636 = env9637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env9636 == env9637) = true)

theorem identity9637 : scanCanonicalize (H12AffineFastState.compose env9637 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound9637 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env9638 : List Nat := [2,4,8,16,1,64,88,4,1,5,64,11,8192,65,8200,8283,11,91,79,8200,64,80,90,2,8273,91,90,11,10,17,4,80,78,80,90,0]

theorem envBound9638 : H12AffineFastState.Bounded env9638 := by
  intro p hp
  have h : env9638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9637_9638 : H12AffineEnvironment.transform 4 1 env9637 = env9638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9637 == env9638) = true)

theorem identity9638 : scanCanonicalize (H12AffineFastState.compose env9638 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound9638 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9639 : List Nat := [2,4,8,16,1,64,88,4,1,5,64,11,24,65,16,67,11,91,79,16,64,80,90,2,73,91,90,11,10,17,4,80,78,80,90,0]

theorem envBound9639 : H12AffineFastState.Bounded env9639 := by
  intro p hp
  have h : env9639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9638_9639 : H12AffineEnvironment.transform 12 24 env9638 = env9639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env9638 == env9639) = true)

theorem identity9639 : scanCanonicalize (H12AffineFastState.compose env9639 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 20) := by decide +kernel

theorem selectedBound9639 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9640 : List Nat := [2,4,8,16,1,20,12,4,1,5,20,11,24,21,16,23,11,15,27,16,20,4,14,2,29,15,14,11,10,17,4,4,26,4,14,0]

theorem envBound9640 : H12AffineFastState.Bounded env9640 := by
  intro p hp
  have h : env9640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9639_9640 : H12AffineEnvironment.transform 5 20 env9639 = env9640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 20 env9639 == env9640) = true)

theorem identity9640 : scanCanonicalize (H12AffineFastState.compose env9640 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound9640 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9641 : List Nat := [2,0,8,16,1,16,8,0,1,1,16,11,24,17,16,19,11,11,27,16,16,0,10,2,25,11,10,11,10,17,0,0,26,0,10,0]

theorem envBound9641 : H12AffineFastState.Bounded env9641 := by
  intro p hp
  have h : env9641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9640_9641 : H12AffineEnvironment.transform 1 0 env9640 = env9641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env9640 == env9641) = true)

theorem identity9641 : scanCanonicalize (H12AffineFastState.compose env9641 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound9641 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env9642 : List Nat := [2,0,8,1,1,1,8,0,1,1,1,11,9,0,1,2,11,11,10,1,1,0,10,2,8,11,10,11,10,0,0,0,11,0,10,0]

theorem envBound9642 : H12AffineFastState.Bounded env9642 := by
  intro p hp
  have h : env9642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9641_9642 : H12AffineEnvironment.transform 3 1 env9641 = env9642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env9641 == env9642) = true)

theorem identity9642 : scanCanonicalize (H12AffineFastState.compose env9642 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9642 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9643 : List Nat := [2,0,2,1,1,1,2,0,1,1,1,1,3,0,1,2,1,1,0,1,1,0,0,2,2,1,0,1,0,0,0,0,1,0,0,0]

theorem envBound9643 : H12AffineFastState.Bounded env9643 := by
  intro p hp
  have h : env9643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9642_9643 : H12AffineEnvironment.transform 2 2 env9642 = env9643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9642 == env9643) = true)

def env9644 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,262144,4765,8200,65,4194304,4721,90337,8329,21041,278625,4214985,4214984,75786,4,4268194,4764,73770,78579,90819]

theorem envBound9644 : H12AffineFastState.Bounded env9644 := by
  intro p hp
  have h : env9644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9618_9644 : H12AffineEnvironment.transform 20 65 env9618 = env9644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env9618 == env9644) = true)

theorem identity9644 : scanCanonicalize (H12AffineFastState.compose env9644 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 282666) := by decide +kernel

theorem selectedBound9644 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9645 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,262144,4765,8200,65,282666,4721,90337,8329,21041,278625,262371,262370,75786,4,356488,4764,73770,78579,90819]

theorem envBound9645 : H12AffineFastState.Bounded env9645 := by
  intro p hp
  have h : env9645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9644_9645 : H12AffineEnvironment.transform 21 282666 env9644 = env9645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 282666 env9644 == env9645) = true)

def env9646 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,77976,4765,8200,65,90290,4721,90337,8329,21041,94457,77947,77946,75786,4,16400,4764,73770,78579,90819]

theorem envBound9646 : H12AffineFastState.Bounded env9646 := by
  intro p hp
  have h : env9646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9645_9646 : H12AffineEnvironment.transform 17 77976 env9645 = env9646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 77976 env9645 == env9646) = true)

def env9647 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,560,8200,65536,4096,77976,4765,8200,65,74370,4721,74449,8329,4097,78537,77947,77946,75786,4,544,4764,73770,78579,73971]

theorem envBound9647 : H12AffineFastState.Bounded env9647 := by
  intro p hp
  have h : env9647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9646_9647 : H12AffineEnvironment.transform 13 560 env9646 = env9647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env9646 == env9647) = true)

theorem identity9647 : scanCanonicalize (H12AffineFastState.compose env9647 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound9647 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9648 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,65,8192,560,8200,65536,65,73945,732,8200,65,74370,560,74449,8329,64,74376,73786,73787,75786,4,544,733,73770,74418,73971]

theorem envBound9648 : H12AffineFastState.Bounded env9648 := by
  intro p hp
  have h : env9648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9647_9648 : H12AffineEnvironment.transform 11 65 env9647 = env9648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env9647 == env9648) = true)

theorem identity9648 : scanCanonicalize (H12AffineFastState.compose env9648 (packedSelected [14,17,21] rootPS)) = affineNative (2^(15+1) ^^^ 10785) := by decide +kernel

theorem selectedBound9648 : packedSelected [14,17,21] rootPS < 2^1333 := by decide +kernel

def env9649 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,65,8192,560,8200,10785,65,2808,732,8200,65,2211,560,2288,8329,64,2217,2587,2586,555,4,544,733,2571,2195,2770]

theorem envBound9649 : H12AffineFastState.Bounded env9649 := by
  intro p hp
  have h : env9649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9648_9649 : H12AffineEnvironment.transform 15 10785 env9648 = env9649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10785 env9648 == env9649) = true)

theorem identity9649 : scanCanonicalize (H12AffineFastState.compose env9649 (packedSelected [1,3,4,5,8,9,10,14,18,19,20,23] rootPS)) = affineNative (2^(10+1) ^^^ 211) := by decide +kernel

theorem selectedBound9649 : packedSelected [1,3,4,5,8,9,10,14,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env9650 : List Nat := [2,4,8,16,32,64,128,253,512,252,211,65,8192,560,8200,8946,65,555,732,8200,65,112,560,35,8329,64,122,712,713,555,4,544,733,728,64,513]

theorem envBound9650 : H12AffineFastState.Bounded env9650 := by
  intro p hp
  have h : env9650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9649_9650 : H12AffineEnvironment.transform 10 211 env9649 = env9650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 211 env9649 == env9650) = true)

theorem identity9650 : scanCanonicalize (H12AffineFastState.compose env9650 (packedSelected [14] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound9650 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env9651 : List Nat := [2,4,8,16,32,64,128,253,33,252,211,65,8192,17,8200,8403,65,10,253,8200,65,112,17,35,8329,64,122,233,232,10,4,1,252,249,64,32]

theorem envBound9651 : H12AffineFastState.Bounded env9651 := by
  intro p hp
  have h : env9651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9650_9651 : H12AffineEnvironment.transform 8 33 env9650 = env9651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env9650 == env9651) = true)

theorem identity9651 : scanCanonicalize (H12AffineFastState.compose env9651 (packedSelected [0,1,3,4,7,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 93) := by decide +kernel

theorem selectedBound9651 : packedSelected [0,1,3,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env9652 : List Nat := [2,4,8,16,32,64,128,253,33,252,211,65,93,17,85,142,65,10,253,85,65,112,17,35,212,64,122,233,232,10,4,1,252,249,64,32]

theorem envBound9652 : H12AffineFastState.Bounded env9652 := by
  intro p hp
  have h : env9652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9651_9652 : H12AffineEnvironment.transform 12 93 env9651 = env9652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 93 env9651 == env9652) = true)

theorem identity9652 : scanCanonicalize (H12AffineFastState.compose env9652 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9652 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9653 : List Nat := [2,4,8,0,32,64,128,237,33,236,195,65,77,1,69,142,65,10,237,69,65,96,1,35,196,64,106,233,232,10,4,1,236,233,64,32]

theorem envBound9653 : H12AffineFastState.Bounded env9653 := by
  intro p hp
  have h : env9653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9652_9653 : H12AffineEnvironment.transform 3 0 env9652 = env9653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9652 == env9653) = true)

theorem identity9653 : scanCanonicalize (H12AffineFastState.compose env9653 (packedSelected [0,1,2,3,7,8,11] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound9653 : packedSelected [0,1,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env9654 : List Nat := [2,4,8,0,14,64,128,195,15,194,195,65,77,1,69,142,65,10,195,69,65,78,1,13,196,64,68,199,198,10,4,1,194,199,64,14]

theorem envBound9654 : H12AffineFastState.Bounded env9654 := by
  intro p hp
  have h : env9654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9653_9654 : H12AffineEnvironment.transform 4 14 env9653 = env9654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env9653 == env9654) = true)

theorem identity9654 : scanCanonicalize (H12AffineFastState.compose env9654 (packedSelected [3,4] rootPS)) = affineNative (2^(5+1) ^^^ 14) := by decide +kernel

theorem selectedBound9654 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env9655 : List Nat := [2,4,8,0,14,14,128,141,15,140,141,15,3,1,11,142,15,10,141,11,15,0,1,13,138,14,10,137,136,10,4,1,140,137,14,14]

theorem envBound9655 : H12AffineFastState.Bounded env9655 := by
  intro p hp
  have h : env9655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9654_9655 : H12AffineEnvironment.transform 5 14 env9654 = env9655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 14 env9654 == env9655) = true)

theorem identity9655 : scanCanonicalize (H12AffineFastState.compose env9655 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 13) := by decide +kernel

theorem selectedBound9655 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env9656 : List Nat := [2,4,8,0,14,14,13,0,15,1,0,15,3,1,11,3,15,10,0,11,15,0,1,13,7,14,10,4,5,10,4,1,1,4,14,14]

theorem envBound9656 : H12AffineFastState.Bounded env9656 := by
  intro p hp
  have h : env9656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9655_9656 : H12AffineEnvironment.transform 6 13 env9655 = env9656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 13 env9655 == env9656) = true)

theorem identity9656 : scanCanonicalize (H12AffineFastState.compose env9656 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9656 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9657 : List Nat := [2,4,3,0,5,5,6,0,4,1,0,4,3,1,0,3,4,1,0,0,4,0,1,6,7,5,1,4,5,1,4,1,1,4,5,5]

theorem envBound9657 : H12AffineFastState.Bounded env9657 := by
  intro p hp
  have h : env9657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9656_9657 : H12AffineEnvironment.transform 2 3 env9656 = env9657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9656 == env9657) = true)

theorem identity9657 : scanCanonicalize (H12AffineFastState.compose env9657 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound9657 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9658 : List Nat := [2,0,3,0,1,1,2,0,0,1,0,0,3,1,0,3,0,1,0,0,0,0,1,2,3,1,1,0,1,1,0,1,1,0,1,1]

theorem envBound9658 : H12AffineFastState.Bounded env9658 := by
  intro p hp
  have h : env9658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9657_9658 : H12AffineEnvironment.transform 1 0 env9657 = env9658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env9657 == env9658) = true)

def env9659 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,561,8200,65536,4096,77976,4765,8200,65,74371,4721,74448,8329,4096,78536,77947,77946,75786,4,545,4764,73770,78579,73970]

theorem envBound9659 : H12AffineFastState.Bounded env9659 := by
  intro p hp
  have h : env9659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9646_9659 : H12AffineEnvironment.transform 13 561 env9646 = env9659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env9646 == env9659) = true)

theorem identity9659 : scanCanonicalize (H12AffineFastState.compose env9659 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound9659 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9660 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,185,8192,561,8200,65536,185,73761,548,8200,65,74371,712,74448,8329,185,74353,73922,73923,75786,4,545,549,73770,74314,73970]

theorem envBound9660 : H12AffineFastState.Bounded env9660 := by
  intro p hp
  have h : env9660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9659_9660 : H12AffineEnvironment.transform 11 185 env9659 = env9660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env9659 == env9660) = true)

theorem identity9660 : scanCanonicalize (H12AffineFastState.compose env9660 (packedSelected [0,7,13,14,17,20] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound9660 : packedSelected [0,7,13,14,17,20] rootPS < 2^1333 := by decide +kernel

def env9661 : List Nat := [2,4,8,16,32,64,128,253,512,252,131,185,8192,561,8200,65536,185,73761,548,8200,65,74371,712,74448,8329,185,74353,73922,73923,73865,4,545,549,73770,74314,73970]

theorem envBound9661 : H12AffineFastState.Bounded env9661 := by
  intro p hp
  have h : env9661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9660_9661 : H12AffineEnvironment.transform 10 131 env9660 = env9661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env9660 == env9661) = true)

theorem identity9661 : scanCanonicalize (H12AffineFastState.compose env9661 (packedSelected [0,4,5,7,8,9,10,12,14,15,17,19,21] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound9661 : packedSelected [0,4,5,7,8,9,10,12,14,15,17,19,21] rootPS < 2^1333 := by decide +kernel

def env9662 : List Nat := [2,4,8,16,32,64,121,4,512,5,122,64,8192,561,8200,65536,64,73761,548,8200,65,74362,561,74281,8304,64,74353,73787,73786,73840,4,545,549,73770,74314,73739]

theorem envBound9662 : H12AffineFastState.Bounded env9662 := by
  intro p hp
  have h : env9662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9661_9662 : H12AffineEnvironment.transform 6 121 env9661 = env9662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env9661 == env9662) = true)

theorem identity9662 : scanCanonicalize (H12AffineFastState.compose env9662 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 552) := by decide +kernel

theorem selectedBound9662 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env9663 : List Nat := [2,4,8,16,32,64,121,4,512,5,122,64,552,561,544,65536,64,66057,548,544,65,65618,561,65537,600,64,65625,66067,66066,66136,4,545,549,66050,65634,66083]

theorem envBound9663 : H12AffineFastState.Bounded env9663 := by
  intro p hp
  have h : env9663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9662_9663 : H12AffineEnvironment.transform 12 552 env9662 = env9663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 552 env9662 == env9663) = true)

theorem identity9663 : scanCanonicalize (H12AffineFastState.compose env9663 (packedSelected [13,14,17] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound9663 : packedSelected [13,14,17] rootPS < 2^1333 := by decide +kernel

def env9664 : List Nat := [2,4,8,16,32,64,121,4,512,5,122,64,552,561,544,35,64,554,548,544,65,113,561,34,600,64,122,560,561,635,4,545,549,545,65,512]

theorem envBound9664 : H12AffineFastState.Bounded env9664 := by
  intro p hp
  have h : env9664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9663_9664 : H12AffineEnvironment.transform 15 35 env9663 = env9664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env9663 == env9664) = true)

theorem identity9664 : scanCanonicalize (H12AffineFastState.compose env9664 (packedSelected [0,1,3,4,7,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound9664 : packedSelected [0,1,3,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env9665 : List Nat := [2,4,8,16,32,64,121,4,27,5,122,64,51,42,59,35,64,49,63,59,65,113,42,34,67,64,122,43,42,96,4,58,62,58,65,27]

theorem envBound9665 : H12AffineFastState.Bounded env9665 := by
  intro p hp
  have h : env9665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9664_9665 : H12AffineEnvironment.transform 8 27 env9664 = env9665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env9664 == env9665) = true)

theorem identity9665 : scanCanonicalize (H12AffineFastState.compose env9665 (packedSelected [1,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound9665 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env9666 : List Nat := [2,4,8,16,32,33,24,4,27,5,27,33,51,42,59,35,33,49,63,59,32,16,42,34,34,33,27,43,42,1,4,58,62,58,32,27]

theorem envBound9666 : H12AffineFastState.Bounded env9666 := by
  intro p hp
  have h : env9666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9665_9666 : H12AffineEnvironment.transform 5 33 env9665 = env9666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env9665 == env9666) = true)

theorem identity9666 : scanCanonicalize (H12AffineFastState.compose env9666 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound9666 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9667 : List Nat := [2,4,8,16,1,0,24,4,27,5,27,0,18,11,26,2,0,16,30,26,1,16,11,3,3,0,27,10,11,1,4,27,31,27,1,27]

theorem envBound9667 : H12AffineFastState.Bounded env9667 := by
  intro p hp
  have h : env9667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9666_9667 : H12AffineEnvironment.transform 4 1 env9666 = env9667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9666 == env9667) = true)

theorem identity9667 : scanCanonicalize (H12AffineFastState.compose env9667 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound9667 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env9668 : List Nat := [2,4,8,10,1,0,2,4,1,5,1,0,8,11,0,2,0,10,4,0,1,10,11,3,3,0,1,10,11,1,4,1,5,1,1,1]

theorem envBound9668 : H12AffineFastState.Bounded env9668 := by
  intro p hp
  have h : env9668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9667_9668 : H12AffineEnvironment.transform 3 10 env9667 = env9668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env9667 == env9668) = true)

theorem identity9668 : scanCanonicalize (H12AffineFastState.compose env9668 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9668 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env9669 : List Nat := [2,4,3,1,1,0,2,4,1,5,1,0,3,0,0,2,0,1,4,0,1,1,0,3,3,0,1,1,0,1,4,1,5,1,1,1]

theorem envBound9669 : H12AffineFastState.Bounded env9669 := by
  intro p hp
  have h : env9669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9668_9669 : H12AffineEnvironment.transform 2 3 env9668 = env9669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9668 == env9669) = true)

def env9670 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,77977,4765,8200,65,90291,4721,90337,8329,21041,94456,77946,77947,75786,4,16401,4764,73770,78579,90819]

theorem envBound9670 : H12AffineFastState.Bounded env9670 := by
  intro p hp
  have h : env9670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9645_9670 : H12AffineEnvironment.transform 17 77977 env9645 = env9670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 77977 env9645 == env9670) = true)

def env9671 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,560,8200,65536,4096,77977,4765,8200,65,74371,4721,74449,8329,4097,78536,77946,77947,75786,4,545,4764,73770,78579,73971]

theorem envBound9671 : H12AffineFastState.Bounded env9671 := by
  intro p hp
  have h : env9671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9670_9671 : H12AffineEnvironment.transform 13 560 env9670 = env9671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env9670 == env9671) = true)

theorem identity9671 : scanCanonicalize (H12AffineFastState.compose env9671 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 12978) := by decide +kernel

theorem selectedBound9671 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9672 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,560,8200,12978,4096,555,4765,8200,65,4145,4721,4195,8329,4097,122,712,713,6840,4,545,4764,4760,65,4673]

theorem envBound9672 : H12AffineFastState.Bounded env9672 := by
  intro p hp
  have h : env9672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9671_9672 : H12AffineEnvironment.transform 15 12978 env9671 = env9672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12978 env9671 == env9672) = true)

theorem identity9672 : scanCanonicalize (H12AffineFastState.compose env9672 (packedSelected [14] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound9672 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env9673 : List Nat := [2,4,8,16,32,64,121,4,512,5,2048,4096,8192,560,8200,12875,4096,555,4708,8200,65,4145,4721,4195,8304,4097,122,561,560,6721,4,545,4709,4705,65,4673]

theorem envBound9673 : H12AffineFastState.Bounded env9673 := by
  intro p hp
  have h : env9673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9672_9673 : H12AffineEnvironment.transform 6 121 env9672 = env9673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env9672 == env9673) = true)

theorem identity9673 : scanCanonicalize (H12AffineFastState.compose env9673 (packedSelected [1,2,3,5,8,10,11,13,17,18,19] rootPS)) = affineNative (2^(11+1) ^^^ 561) := by decide +kernel

theorem selectedBound9673 : packedSelected [1,2,3,5,8,10,11,13,17,18,19] rootPS < 2^1333 := by decide +kernel

def env9674 : List Nat := [2,4,8,16,32,64,121,4,512,5,2048,561,8192,560,8200,8314,561,555,85,8200,65,512,64,594,8304,560,122,561,560,2160,4,545,84,80,65,112]

theorem envBound9674 : H12AffineFastState.Bounded env9674 := by
  intro p hp
  have h : env9674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9673_9674 : H12AffineEnvironment.transform 11 561 env9673 = env9674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 561 env9673 == env9674) = true)

theorem identity9674 : scanCanonicalize (H12AffineFastState.compose env9674 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 113) := by decide +kernel

theorem selectedBound9674 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env9675 : List Nat := [2,4,8,16,32,64,121,4,113,5,2048,64,8192,65,8200,8314,64,90,85,8200,65,113,64,35,8304,65,122,64,65,2160,4,80,84,80,65,112]

theorem envBound9675 : H12AffineFastState.Bounded env9675 := by
  intro p hp
  have h : env9675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9674_9675 : H12AffineEnvironment.transform 8 113 env9674 = env9675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 113 env9674 == env9675) = true)

theorem identity9675 : scanCanonicalize (H12AffineFastState.compose env9675 (packedSelected [2,8] rootPS)) = affineNative (2^(10+1) ^^^ 37) := by decide +kernel

theorem selectedBound9675 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env9676 : List Nat := [2,4,8,16,32,64,121,4,113,5,37,64,8192,65,8200,8314,64,90,85,8200,65,113,64,35,8304,65,122,64,65,85,4,80,84,80,65,112]

theorem envBound9676 : H12AffineFastState.Bounded env9676 := by
  intro p hp
  have h : env9676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9675_9676 : H12AffineEnvironment.transform 10 37 env9675 = env9676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 37 env9675 == env9676) = true)

theorem identity9676 : scanCanonicalize (H12AffineFastState.compose env9676 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound9676 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env9677 : List Nat := [2,4,8,1,32,64,104,4,96,5,37,64,8192,65,8200,8299,64,75,68,8200,65,96,64,35,8289,65,107,64,65,68,4,65,69,65,65,97]

theorem envBound9677 : H12AffineFastState.Bounded env9677 := by
  intro p hp
  have h : env9677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9676_9677 : H12AffineEnvironment.transform 3 1 env9676 = env9677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env9676 == env9677) = true)

theorem identity9677 : scanCanonicalize (H12AffineFastState.compose env9677 (packedSelected [0,2,4,7,9,12] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9677 : packedSelected [0,2,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env9678 : List Nat := [2,4,3,1,32,64,99,4,96,5,37,64,8192,65,8195,8288,64,64,68,8195,65,96,64,35,8289,65,96,64,65,68,4,65,69,65,65,97]

theorem envBound9678 : H12AffineFastState.Bounded env9678 := by
  intro p hp
  have h : env9678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9677_9678 : H12AffineEnvironment.transform 2 3 env9677 = env9678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9677 == env9678) = true)

def env9679 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,561,8200,65536,4096,77977,4765,8200,65,74370,4721,74448,8329,4096,78537,77946,77947,75786,4,544,4764,73770,78579,73970]

theorem envBound9679 : H12AffineFastState.Bounded env9679 := by
  intro p hp
  have h : env9679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9670_9679 : H12AffineEnvironment.transform 13 561 env9670 = env9679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env9670 == env9679) = true)

theorem identity9679 : scanCanonicalize (H12AffineFastState.compose env9679 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 12874) := by decide +kernel

theorem selectedBound9679 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9680 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,561,8200,12874,4096,723,4765,8200,65,4296,4721,4250,8329,4096,131,560,561,6720,4,544,4764,4704,185,4792]

theorem envBound9680 : H12AffineFastState.Bounded env9680 := by
  intro p hp
  have h : env9680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9679_9680 : H12AffineEnvironment.transform 15 12874 env9679 = env9680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12874 env9679 == env9680) = true)

theorem identity9680 : scanCanonicalize (H12AffineFastState.compose env9680 (packedSelected [0,7,13,14,20,21] rootPS)) = affineNative (2^(11+1) ^^^ 232) := by decide +kernel

theorem selectedBound9680 : packedSelected [0,7,13,14,20,21] rootPS < 2^1333 := by decide +kernel

def env9681 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,232,8192,561,8200,8866,232,723,629,8200,65,32,665,114,8329,232,131,560,561,2728,4,544,628,648,185,592]

theorem envBound9681 : H12AffineFastState.Bounded env9681 := by
  intro p hp
  have h : env9681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9680_9681 : H12AffineEnvironment.transform 11 232 env9680 = env9681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 232 env9680 == env9681) = true)

theorem identity9681 : scanCanonicalize (H12AffineFastState.compose env9681 (packedSelected [5,8,10,12,14,15,19] rootPS)) = affineNative (2^(10+1) ^^^ 602) := by decide +kernel

theorem selectedBound9681 : packedSelected [5,8,10,12,14,15,19] rootPS < 2^1333 := by decide +kernel

def env9682 : List Nat := [2,4,8,16,32,64,128,253,512,252,602,232,8192,561,8200,8866,232,723,629,8200,65,32,665,114,8329,232,131,560,561,242,4,544,628,648,185,592]

theorem envBound9682 : H12AffineFastState.Bounded env9682 := by
  intro p hp
  have h : env9682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9681_9682 : H12AffineEnvironment.transform 10 602 env9681 = env9682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 602 env9681 == env9682) = true)

theorem identity9682 : scanCanonicalize (H12AffineFastState.compose env9682 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound9682 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env9683 : List Nat := [2,4,8,16,32,17,128,172,512,173,523,185,8192,561,8200,8866,185,642,548,8200,16,32,665,35,8329,185,131,560,561,163,4,544,549,648,185,513]

theorem envBound9683 : H12AffineFastState.Bounded env9683 := by
  intro p hp
  have h : env9683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9682_9683 : H12AffineEnvironment.transform 5 17 env9682 = env9683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9682 == env9683) = true)

theorem identity9683 : scanCanonicalize (H12AffineFastState.compose env9683 (packedSelected [0,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 683) := by decide +kernel

theorem selectedBound9683 : packedSelected [0,5,8,9] rootPS < 2^1333 := by decide +kernel

def env9684 : List Nat := [2,4,8,16,32,17,128,172,512,173,523,185,683,561,675,9,185,642,548,675,16,32,665,35,546,185,131,560,561,163,4,544,549,648,185,513]

theorem envBound9684 : H12AffineFastState.Bounded env9684 := by
  intro p hp
  have h : env9684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9683_9684 : H12AffineEnvironment.transform 12 683 env9683 = env9684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 683 env9683 == env9684) = true)

theorem identity9684 : scanCanonicalize (H12AffineFastState.compose env9684 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound9684 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9685 : List Nat := [2,4,8,16,32,17,19,63,512,62,523,42,568,561,560,9,42,529,548,560,16,32,522,35,546,42,16,560,561,48,4,544,549,539,42,513]

theorem envBound9685 : H12AffineFastState.Bounded env9685 := by
  intro p hp
  have h : env9685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9684_9685 : H12AffineEnvironment.transform 6 19 env9684 = env9685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env9684 == env9685) = true)

theorem identity9685 : scanCanonicalize (H12AffineFastState.compose env9685 (packedSelected [0,1,5] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound9685 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env9686 : List Nat := [2,4,8,16,32,17,19,63,27,62,16,42,35,42,43,9,42,10,63,43,16,32,17,35,57,42,16,43,42,48,4,59,62,0,42,26]

theorem envBound9686 : H12AffineFastState.Bounded env9686 := by
  intro p hp
  have h : env9686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9685_9686 : H12AffineEnvironment.transform 8 27 env9685 = env9686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env9685 == env9686) = true)

theorem identity9686 : scanCanonicalize (H12AffineFastState.compose env9686 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound9686 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env9687 : List Nat := [2,1,8,16,32,17,19,58,27,59,16,42,35,42,43,9,42,10,58,43,16,32,17,35,57,42,16,43,42,48,1,59,59,0,42,26]

theorem envBound9687 : H12AffineFastState.Bounded env9687 := by
  intro p hp
  have h : env9687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9686_9687 : H12AffineEnvironment.transform 1 1 env9686 = env9687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env9686 == env9687) = true)

theorem identity9687 : scanCanonicalize (H12AffineFastState.compose env9687 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound9687 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env9688 : List Nat := [2,1,8,16,16,17,19,10,27,11,16,26,19,26,27,9,26,10,10,27,16,16,17,19,9,26,16,27,26,0,1,11,11,0,26,26]

theorem envBound9688 : H12AffineFastState.Bounded env9688 := by
  intro p hp
  have h : env9688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9687_9688 : H12AffineEnvironment.transform 4 16 env9687 = env9688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env9687 == env9688) = true)

theorem identity9688 : scanCanonicalize (H12AffineFastState.compose env9688 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9688 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env9689 : List Nat := [2,1,2,16,16,17,19,0,17,1,16,16,19,16,17,3,16,0,0,17,16,16,17,19,3,16,16,17,16,0,1,1,1,0,16,16]

theorem envBound9689 : H12AffineFastState.Bounded env9689 := by
  intro p hp
  have h : env9689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9688_9689 : H12AffineEnvironment.transform 2 2 env9688 = env9689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9688 == env9689) = true)

def env9690 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,262144,4961,8693,2097152,4194304,5005,90337,8329,21041,278624,4214984,4215092,75787,504,4268382,4960,73771,2175667,90942]

theorem envBound9690 : H12AffineFastState.Bounded env9690 := by
  intro p hp
  have h : env9690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9616_9690 : H12AffineEnvironment.transform 18 4961 env9616 = env9690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4961 env9616 == env9690) = true)

theorem identity9690 : scanCanonicalize (H12AffineFastState.compose env9690 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 24771) := by decide +kernel

theorem selectedBound9690 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9691 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,24771,4605,262144,4961,8693,2097152,4194304,5005,34,8329,21041,278624,4214984,4215092,18632,504,4211101,4960,16616,2118256,1021]

theorem envBound9691 : H12AffineFastState.Bounded env9691 := by
  intro p hp
  have h : env9691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9690_9691 : H12AffineEnvironment.transform 15 24771 env9690 = env9691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24771 env9690 == env9691) = true)

def env9692 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,24771,4605,262144,4961,8693,64,4194304,5005,34,8329,21041,278624,4214984,4215092,18632,504,4211101,4960,16616,21040,1021]

theorem envBound9692 : H12AffineFastState.Bounded env9692 := by
  intro p hp
  have h : env9692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9691_9692 : H12AffineEnvironment.transform 20 64 env9691 = env9692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env9691 == env9692) = true)

theorem identity9692 : scanCanonicalize (H12AffineFastState.compose env9692 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 17351) := by decide +kernel

theorem selectedBound9692 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9693 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,24771,4605,17351,4961,8693,64,4194304,5005,34,8329,21041,935,4214984,4215092,18632,504,4211101,4960,16616,21040,1021]

theorem envBound9693 : H12AffineFastState.Bounded env9693 := by
  intro p hp
  have h : env9693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9692_9693 : H12AffineEnvironment.transform 17 17351 env9692 = env9693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 17351 env9692 == env9693) = true)

def env9694 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,232,8693,8235,4605,815,4961,8693,64,4194304,5005,34,8329,4825,935,4198432,4198876,2080,504,4194677,4960,0,4824,1021]

theorem envBound9694 : H12AffineFastState.Bounded env9694 := by
  intro p hp
  have h : env9694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9693_9694 : H12AffineEnvironment.transform 13 232 env9693 = env9694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 232 env9693 == env9694) = true)

theorem identity9694 : scanCanonicalize (H12AffineFastState.compose env9694 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(21+1) ^^^ 476) := by decide +kernel

theorem selectedBound9694 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9695 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,232,8693,8235,4605,815,4961,8693,64,476,5005,34,8329,4825,935,4604,4096,2080,504,169,4960,0,4824,1021]

theorem envBound9695 : H12AffineFastState.Bounded env9695 := by
  intro p hp
  have h : env9695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9694_9695 : H12AffineEnvironment.transform 21 476 env9694 = env9695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 476 env9694 == env9695) = true)

theorem identity9695 : scanCanonicalize (H12AffineFastState.compose env9695 (packedSelected [1,3,4,7,9,12,14,18,23,27,38] rootPS)) = affineNative (2^(11+1) ^^^ 2155) := by decide +kernel

theorem selectedBound9695 : packedSelected [1,3,4,7,9,12,14,18,23,27,38] rootPS < 2^1333 := by decide +kernel

def env9696 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,2155,8192,232,8693,8235,2454,815,2826,8693,64,476,3046,34,8329,2738,935,2455,2155,2080,504,169,2827,0,2739,1021]

theorem envBound9696 : H12AffineFastState.Bounded env9696 := by
  intro p hp
  have h : env9696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9695_9696 : H12AffineEnvironment.transform 11 2155 env9695 = env9696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2155 env9695 == env9696) = true)

theorem identity9696 : scanCanonicalize (H12AffineFastState.compose env9696 (packedSelected [0,4,7,9,14,18,23] rootPS)) = affineNative (2^(10+1) ^^^ 934) := by decide +kernel

theorem selectedBound9696 : packedSelected [0,4,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env9697 : List Nat := [2,4,8,16,32,64,128,256,512,257,934,973,8192,232,8693,8235,560,815,172,8693,64,476,64,34,8329,276,935,561,973,902,504,169,173,0,277,1021]

theorem envBound9697 : H12AffineFastState.Bounded env9697 := by
  intro p hp
  have h : env9697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9696_9697 : H12AffineEnvironment.transform 10 934 env9696 = env9697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 934 env9696 == env9697) = true)

theorem identity9697 : scanCanonicalize (H12AffineFastState.compose env9697 (packedSelected [1,3,4,9,12,13,15,17,20] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound9697 : packedSelected [1,3,4,9,12,13,15,17,20] rootPS < 2^1333 := by decide +kernel

def env9698 : List Nat := [2,4,8,16,32,64,128,4,512,5,674,713,8192,232,8433,8235,560,555,172,8433,64,216,64,34,8329,16,675,561,713,642,252,169,173,0,17,761]

theorem envBound9698 : H12AffineFastState.Bounded env9698 := by
  intro p hp
  have h : env9698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9697_9698 : H12AffineEnvironment.transform 7 4 env9697 = env9698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env9697 == env9698) = true)

theorem identity9698 : scanCanonicalize (H12AffineFastState.compose env9698 (packedSelected [1,2,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 138) := by decide +kernel

theorem selectedBound9698 : packedSelected [1,2,8,11] rootPS < 2^1333 := by decide +kernel

def env9699 : List Nat := [2,4,8,16,32,64,128,4,512,5,674,713,138,232,123,161,560,555,172,123,64,216,64,34,3,16,675,561,713,642,252,169,173,0,17,761]

theorem envBound9699 : H12AffineFastState.Bounded env9699 := by
  intro p hp
  have h : env9699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9698_9699 : H12AffineEnvironment.transform 12 138 env9698 = env9699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 138 env9698 == env9699) = true)

theorem identity9699 : scanCanonicalize (H12AffineFastState.compose env9699 (packedSelected [0,1,5,7,10,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 179) := by decide +kernel

theorem selectedBound9699 : packedSelected [0,1,5,7,10,12,13] rootPS < 2^1333 := by decide +kernel

def env9700 : List Nat := [2,4,8,16,32,64,128,4,179,5,17,122,138,232,123,161,131,152,172,123,64,216,64,34,3,16,16,130,122,49,252,169,173,0,17,74]

theorem envBound9700 : H12AffineFastState.Bounded env9700 := by
  intro p hp
  have h : env9700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9699_9700 : H12AffineEnvironment.transform 8 179 env9699 = env9700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 179 env9699 == env9700) = true)

theorem identity9700 : scanCanonicalize (H12AffineFastState.compose env9700 (packedSelected [1,3,4,7,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound9700 : packedSelected [1,3,4,7,10] rootPS < 2^1333 := by decide +kernel

def env9701 : List Nat := [2,4,8,16,32,17,128,4,179,5,17,43,138,185,42,161,131,152,172,42,17,137,17,34,3,16,16,130,43,49,173,169,173,0,17,27]

theorem envBound9701 : H12AffineFastState.Bounded env9701 := by
  intro p hp
  have h : env9701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9700_9701 : H12AffineEnvironment.transform 5 17 env9700 = env9701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9700 == env9701) = true)

theorem identity9701 : scanCanonicalize (H12AffineFastState.compose env9701 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound9701 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env9702 : List Nat := [2,4,8,16,32,17,41,4,26,5,17,43,35,16,42,8,42,49,5,42,17,32,17,34,3,16,16,43,43,49,4,0,4,0,17,27]

theorem envBound9702 : H12AffineFastState.Bounded env9702 := by
  intro p hp
  have h : env9702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9701_9702 : H12AffineEnvironment.transform 6 41 env9701 = env9702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env9701 == env9702) = true)

theorem identity9702 : scanCanonicalize (H12AffineFastState.compose env9702 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 20) := by decide +kernel

theorem selectedBound9702 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9703 : List Nat := [2,4,8,16,20,17,29,4,26,5,17,31,23,16,30,8,30,5,5,30,17,20,17,22,3,16,16,31,31,5,4,0,4,0,17,27]

theorem envBound9703 : H12AffineFastState.Bounded env9703 := by
  intro p hp
  have h : env9703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9702_9703 : H12AffineEnvironment.transform 4 20 env9702 = env9703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 20 env9702 == env9703) = true)

theorem identity9703 : scanCanonicalize (H12AffineFastState.compose env9703 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound9703 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env9704 : List Nat := [2,1,8,16,17,17,24,1,26,0,17,26,18,16,27,8,27,0,0,27,17,17,17,19,3,16,16,26,26,0,1,0,1,0,17,27]

theorem envBound9704 : H12AffineFastState.Bounded env9704 := by
  intro p hp
  have h : env9704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9703_9704 : H12AffineEnvironment.transform 1 1 env9703 = env9704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env9703 == env9704) = true)

theorem identity9704 : scanCanonicalize (H12AffineFastState.compose env9704 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9704 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env9705 : List Nat := [2,1,8,0,1,1,8,1,10,0,1,10,2,0,11,8,11,0,0,11,1,1,1,3,3,0,0,10,10,0,1,0,1,0,1,11]

theorem envBound9705 : H12AffineFastState.Bounded env9705 := by
  intro p hp
  have h : env9705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9704_9705 : H12AffineEnvironment.transform 3 0 env9704 = env9705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9704 == env9705) = true)

theorem identity9705 : scanCanonicalize (H12AffineFastState.compose env9705 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9705 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9706 : List Nat := [2,1,3,0,1,1,3,1,1,0,1,1,2,0,0,3,0,0,0,0,1,1,1,3,3,0,0,1,1,0,1,0,1,0,1,0]

theorem envBound9706 : H12AffineFastState.Bounded env9706 := by
  intro p hp
  have h : env9706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9705_9706 : H12AffineEnvironment.transform 2 3 env9705 = env9706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9705 == env9706) = true)

def env9707 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,233,8693,8234,4605,814,4961,8693,64,4194304,5005,34,8329,4824,935,4198433,4198877,2081,504,4194676,4960,1,4825,1021]

theorem envBound9707 : H12AffineFastState.Bounded env9707 := by
  intro p hp
  have h : env9707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9693_9707 : H12AffineEnvironment.transform 13 233 env9693 = env9707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 233 env9693 == env9707) = true)

theorem identity9707 : scanCanonicalize (H12AffineFastState.compose env9707 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound9707 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9708 : List Nat := [2,4,8,16,32,64,128,85,512,84,2048,4096,8192,233,8352,8234,4264,635,4660,8352,64,4194304,4824,34,8329,4824,754,4198433,4198536,2081,173,4194337,4661,1,4825,680]

theorem envBound9708 : H12AffineFastState.Bounded env9708 := by
  intro p hp
  have h : env9708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9707_9708 : H12AffineEnvironment.transform 7 85 env9707 = env9708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env9707 == env9708) = true)

theorem identity9708 : scanCanonicalize (H12AffineFastState.compose env9708 (packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS)) = affineNative (2^(11+1) ^^^ 2243) := by decide +kernel

theorem selectedBound9708 : packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env9709 : List Nat := [2,4,8,16,32,64,128,85,512,84,2048,2243,8192,233,8352,8234,2155,635,2807,8352,64,4194304,2587,34,8329,2587,754,4196578,4196427,2081,173,4194337,2806,1,2586,680]

theorem envBound9709 : H12AffineFastState.Bounded env9709 := by
  intro p hp
  have h : env9709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9708_9709 : H12AffineEnvironment.transform 11 2243 env9708 = env9709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2243 env9708 == env9709) = true)

theorem identity9709 : scanCanonicalize (H12AffineFastState.compose env9709 (packedSelected [1,3,4,7,9,12,14,15,27] rootPS)) = affineNative (2^(21+1) ^^^ 136) := by decide +kernel

theorem selectedBound9709 : packedSelected [1,3,4,7,9,12,14,15,27] rootPS < 2^1333 := by decide +kernel

def env9710 : List Nat := [2,4,8,16,32,64,128,85,512,84,2048,2243,8192,233,8352,8234,2155,635,2807,8352,64,136,2587,34,8329,2587,754,2154,2243,2081,173,169,2806,1,2586,680]

theorem envBound9710 : H12AffineFastState.Bounded env9710 := by
  intro p hp
  have h : env9710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9709_9710 : H12AffineEnvironment.transform 21 136 env9709 = env9710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136 env9709 == env9710) = true)

theorem identity9710 : scanCanonicalize (H12AffineFastState.compose env9710 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound9710 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env9711 : List Nat := [2,4,8,16,32,64,128,85,216,84,2048,2243,8192,233,8352,8234,2155,163,2095,8352,64,136,2243,34,8329,2243,42,2154,2243,2081,173,169,2094,1,2242,112]

theorem envBound9711 : H12AffineFastState.Bounded env9711 := by
  intro p hp
  have h : env9711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9710_9711 : H12AffineEnvironment.transform 8 216 env9710 = env9711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env9710 == env9711) = true)

theorem identity9711 : scanCanonicalize (H12AffineFastState.compose env9711 (packedSelected [0,1,3,4,7,9,12,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound9711 : packedSelected [0,1,3,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env9712 : List Nat := [2,4,8,16,32,64,120,85,32,84,2048,2107,8192,17,8280,8234,2155,91,2095,8280,64,112,2107,34,8305,2107,42,2154,2107,2081,85,81,2094,1,2106,112]

theorem envBound9712 : H12AffineFastState.Bounded env9712 := by
  intro p hp
  have h : env9712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9711_9712 : H12AffineEnvironment.transform 6 120 env9711 = env9712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env9711 == env9712) = true)

theorem identity9712 : scanCanonicalize (H12AffineFastState.compose env9712 (packedSelected [0,2,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 83) := by decide +kernel

theorem selectedBound9712 : packedSelected [0,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env9713 : List Nat := [2,4,8,16,32,64,120,85,32,84,2048,2107,83,17,11,121,2155,91,2095,11,64,112,2107,34,34,2107,42,2154,2107,2081,85,81,2094,1,2106,112]

theorem envBound9713 : H12AffineFastState.Bounded env9713 := by
  intro p hp
  have h : env9713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9712_9713 : H12AffineEnvironment.transform 12 83 env9712 = env9713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 83 env9712 == env9713) = true)

theorem identity9713 : scanCanonicalize (H12AffineFastState.compose env9713 (packedSelected [0,1,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound9713 : packedSelected [0,1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env9714 : List Nat := [2,4,8,16,32,1,57,20,32,21,2048,2107,18,17,11,56,2090,26,2095,11,1,49,2107,34,34,2107,42,2091,2107,2081,20,16,2094,1,2106,49]

theorem envBound9714 : H12AffineFastState.Bounded env9714 := by
  intro p hp
  have h : env9714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9713_9714 : H12AffineEnvironment.transform 5 1 env9713 = env9714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env9713 == env9714) = true)

theorem identity9714 : scanCanonicalize (H12AffineFastState.compose env9714 (packedSelected [1,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound9714 : packedSelected [1,5,9] rootPS < 2^1333 := by decide +kernel

def env9715 : List Nat := [2,4,8,16,32,1,57,20,32,21,43,16,18,17,11,56,1,26,4,11,1,49,16,34,34,16,42,0,16,10,20,16,5,1,17,49]

theorem envBound9715 : H12AffineFastState.Bounded env9715 := by
  intro p hp
  have h : env9715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9714_9715 : H12AffineEnvironment.transform 10 43 env9714 = env9715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env9714 == env9715) = true)

theorem identity9715 : scanCanonicalize (H12AffineFastState.compose env9715 (packedSelected [0,1,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound9715 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env9716 : List Nat := [2,4,8,1,32,1,40,5,32,4,43,1,3,0,11,41,1,11,4,11,1,32,1,34,34,1,42,0,1,10,5,1,5,1,0,32]

theorem envBound9716 : H12AffineFastState.Bounded env9716 := by
  intro p hp
  have h : env9716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9715_9716 : H12AffineEnvironment.transform 3 1 env9715 = env9716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env9715 == env9716) = true)

def env9717 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,24771,4605,262144,4961,8693,65,4194304,5005,34,8329,21041,278624,4214984,4215092,18632,504,4211101,4960,16616,21041,1021]

theorem envBound9717 : H12AffineFastState.Bounded env9717 := by
  intro p hp
  have h : env9717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9691_9717 : H12AffineEnvironment.transform 20 65 env9691 = env9717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env9691 == env9717) = true)

theorem identity9717 : scanCanonicalize (H12AffineFastState.compose env9717 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 20903) := by decide +kernel

theorem selectedBound9717 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0