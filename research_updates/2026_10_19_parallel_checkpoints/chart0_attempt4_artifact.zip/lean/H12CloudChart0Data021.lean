import H12CloudChart0Data020

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound5191 : H12AffineFastState.Bounded env5191 := by
  intro p hp
  have h : env5191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5190_5191 : H12AffineEnvironment.transform 7 188 env5190 = env5191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env5190 == env5191) = true)

theorem identity5191 : scanCanonicalize (H12AffineFastState.compose env5191 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 13492) := by decide +kernel

theorem selectedBound5191 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5192 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,16384,13492,65536,4112,262144,1025,13492,4097,4194304,4194353,5278,8329,4194352,279604,16385,16400,22560,74795,17413,189,20481,4195380,4194864]

theorem envBound5192 : H12AffineFastState.Bounded env5192 := by
  intro p hp
  have h : env5192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5191_5192 : H12AffineEnvironment.transform 14 13492 env5191 = env5192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13492 env5191 == env5192) = true)

def env5193 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,16384,13476,65536,4096,262144,1025,13476,4097,4194304,4194337,5262,8329,4194336,279588,16385,16384,22560,74795,17413,173,20481,4195364,4194848]

theorem envBound5193 : H12AffineFastState.Bounded env5193 := by
  intro p hp
  have h : env5193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5192_5193 : H12AffineEnvironment.transform 3 0 env5192 = env5193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5192 == env5193) = true)

theorem identity5193 : scanCanonicalize (H12AffineFastState.compose env5193 (packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 25734) := by decide +kernel

theorem selectedBound5193 : packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env5194 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,16384,13476,25734,4096,262144,1025,13476,4097,4194304,4194337,5262,8329,4194336,279588,16385,16384,22560,16557,17413,173,20481,4195364,4194848]

theorem envBound5194 : H12AffineFastState.Bounded env5194 := by
  intro p hp
  have h : env5194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5193_5194 : H12AffineEnvironment.transform 15 25734 env5193 = env5194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25734 env5193 == env5194) = true)

theorem identity5194 : scanCanonicalize (H12AffineFastState.compose env5194 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 19596) := by decide +kernel

theorem selectedBound5194 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env5195 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,16384,13476,25734,4096,19596,1025,13476,4097,4194304,4194337,5262,8329,4194336,2216,16385,16384,22560,16557,17413,173,20481,4195364,4194848]

theorem envBound5195 : H12AffineFastState.Bounded env5195 := by
  intro p hp
  have h : env5195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5194_5195 : H12AffineEnvironment.transform 17 19596 env5194 = env5195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19596 env5194 == env5195) = true)

theorem identity5195 : scanCanonicalize (H12AffineFastState.compose env5195 (packedSelected [0,3,5,7,10,18,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 1572) := by decide +kernel

theorem selectedBound5195 : packedSelected [0,3,5,7,10,18,20,23] rootPS < 2^1333 := by decide +kernel

def env5196 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,1572,13476,8866,4096,2728,1025,13476,4097,4194304,4194337,5262,8329,4194336,2216,1573,1572,7684,1673,545,173,5669,4195364,4194848]

theorem envBound5196 : H12AffineFastState.Bounded env5196 := by
  intro p hp
  have h : env5196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5195_5196 : H12AffineEnvironment.transform 13 1572 env5195 = env5196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1572 env5195 == env5196) = true)

theorem identity5196 : scanCanonicalize (H12AffineFastState.compose env5196 (packedSelected [0,1,2,3,4,7,11,12,15,18,22] rootPS)) = affineNative (2^(21+1) ^^^ 136) := by decide +kernel

theorem selectedBound5196 : packedSelected [0,1,2,3,4,7,11,12,15,18,22] rootPS < 2^1333 := by decide +kernel

def env5197 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,1572,13476,8866,4096,2728,1025,13476,4097,136,169,5262,8329,168,2216,1573,1572,7684,1673,545,173,5669,1196,680]

theorem envBound5197 : H12AffineFastState.Bounded env5197 := by
  intro p hp
  have h : env5197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5196_5197 : H12AffineEnvironment.transform 21 136 env5196 = env5197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136 env5196 == env5197) = true)

theorem identity5197 : scanCanonicalize (H12AffineFastState.compose env5197 (packedSelected [0,1,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound5197 : packedSelected [0,1,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env5198 : List Nat := [2,4,8,0,32,1,128,172,137,1024,2048,4096,8192,1197,13476,8235,4096,2081,1025,13476,4097,136,169,5262,8329,168,2216,1196,1197,7309,1024,168,173,5292,1196,33]

theorem envBound5198 : H12AffineFastState.Bounded env5198 := by
  intro p hp
  have h : env5198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5197_5198 : H12AffineEnvironment.transform 8 137 env5197 = env5198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env5197 == env5198) = true)

theorem identity5198 : scanCanonicalize (H12AffineFastState.compose env5198 (packedSelected [0,1,4,7,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 5133) := by decide +kernel

theorem selectedBound5198 : packedSelected [0,1,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env5199 : List Nat := [2,4,8,0,32,1,128,172,137,1024,2048,4096,5133,1197,169,5158,4096,2081,1025,169,4097,136,169,5262,5252,168,2216,1196,1197,7309,1024,168,173,5292,1196,33]

theorem envBound5199 : H12AffineFastState.Bounded env5199 := by
  intro p hp
  have h : env5199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5198_5199 : H12AffineEnvironment.transform 12 5133 env5198 = env5199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5133 env5198 == env5199) = true)

theorem identity5199 : scanCanonicalize (H12AffineFastState.compose env5199 (packedSelected [1,2,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound5199 : packedSelected [1,2,6,8] rootPS < 2^1333 := by decide +kernel

def env5200 : List Nat := [2,4,8,0,32,1,128,172,137,14,2048,4096,4099,163,169,4136,4096,2081,15,169,4097,136,169,4224,4234,168,2216,162,163,6275,14,168,173,4258,162,33]

theorem envBound5200 : H12AffineFastState.Bounded env5200 := by
  intro p hp
  have h : env5200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5199_5200 : H12AffineEnvironment.transform 9 14 env5199 = env5200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env5199 == env5200) = true)

def env5201 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,4096,8192,16384,13477,65536,4097,262144,1025,13477,4097,4194304,4194336,5263,8329,4194337,279589,16385,16385,22560,74795,17413,172,20481,4195365,4194849]

theorem envBound5201 : H12AffineFastState.Bounded env5201 := by
  intro p hp
  have h : env5201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5192_5201 : H12AffineEnvironment.transform 3 1 env5192 = env5201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5192 == env5201) = true)

theorem identity5201 : scanCanonicalize (H12AffineFastState.compose env5201 (packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS)) = affineNative (2^(11+1) ^^^ 1197) := by decide +kernel

theorem selectedBound5201 : packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env5202 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1197,8192,16384,8200,65536,1196,262144,1025,8200,1196,4194304,4194336,34,8329,4194337,279589,16385,16385,19597,74795,17413,172,17580,4195365,4194849]

theorem envBound5202 : H12AffineFastState.Bounded env5202 := by
  intro p hp
  have h : env5202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5201_5202 : H12AffineEnvironment.transform 11 1197 env5201 = env5202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1197 env5201 == env5202) = true)

theorem identity5202 : scanCanonicalize (H12AffineFastState.compose env5202 (packedSelected [0,3,5,7,9,10,13,20,21,22] rootPS)) = affineNative (2^(21+1) ^^^ 73891) := by decide +kernel

theorem selectedBound5202 : packedSelected [0,3,5,7,9,10,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env5203 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1197,8192,16384,8200,65536,1196,262144,1025,8200,1196,73891,73859,34,8329,73858,279589,16385,16385,19597,74795,17413,172,17580,74886,74370]

theorem envBound5203 : H12AffineFastState.Bounded env5203 := by
  intro p hp
  have h : env5203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5202_5203 : H12AffineEnvironment.transform 21 73891 env5202 = env5203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73891 env5202 == env5203) = true)

theorem identity5203 : scanCanonicalize (H12AffineFastState.compose env5203 (packedSelected [0,2,7,11,13,18,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 20141) := by decide +kernel

theorem selectedBound5203 : packedSelected [0,2,7,11,13,18,20,21] rootPS < 2^1333 := by decide +kernel

def env5204 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1197,8192,16384,8200,65536,1196,20141,1025,8200,1196,73891,73859,34,8329,73858,2696,16385,16385,19597,74795,17413,172,17580,74886,74370]

theorem envBound5204 : H12AffineFastState.Bounded env5204 := by
  intro p hp
  have h : env5204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5203_5204 : H12AffineEnvironment.transform 17 20141 env5203 = env5204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20141 env5203 == env5204) = true)

theorem identity5204 : scanCanonicalize (H12AffineFastState.compose env5204 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 8715) := by decide +kernel

theorem selectedBound5204 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env5205 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1197,8192,16384,8200,8715,1196,20141,1025,8200,1196,680,648,34,8329,649,2696,16385,16385,19597,1568,17413,172,17580,1677,137]

theorem envBound5205 : H12AffineFastState.Bounded env5205 := by
  intro p hp
  have h : env5205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5204_5205 : H12AffineEnvironment.transform 15 8715 env5204 = env5205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8715 env5204 == env5205) = true)

theorem identity5205 : scanCanonicalize (H12AffineFastState.compose env5205 (packedSelected [0,2,4,12,18] rootPS)) = affineNative (2^(13+1) ^^^ 11782) := by decide +kernel

theorem selectedBound5205 : packedSelected [0,2,4,12,18] rootPS < 2^1333 := by decide +kernel

def env5206 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1197,8192,11782,8200,8715,1196,8363,1025,8200,1196,680,648,34,8329,649,2696,11783,11783,8843,1568,10755,172,10922,1677,137]

theorem envBound5206 : H12AffineFastState.Bounded env5206 := by
  intro p hp
  have h : env5206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5205_5206 : H12AffineEnvironment.transform 13 11782 env5205 = env5206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11782 env5205 == env5206) = true)

theorem identity5206 : scanCanonicalize (H12AffineFastState.compose env5206 (packedSelected [0,3,5,6,7,11,13,17,20] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound5206 : packedSelected [0,3,5,6,7,11,13,17,20] rootPS < 2^1333 := by decide +kernel

def env5207 : List Nat := [2,4,8,1,32,0,128,173,512,1024,1541,1197,8192,8195,8200,8715,1196,8363,1025,8200,1196,680,648,34,8329,649,1165,8194,8194,8843,1568,9222,172,9391,1677,137]

theorem envBound5207 : H12AffineFastState.Bounded env5207 := by
  intro p hp
  have h : env5207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5206_5207 : H12AffineEnvironment.transform 10 1541 env5206 = env5207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env5206 == env5207) = true)

theorem identity5207 : scanCanonicalize (H12AffineFastState.compose env5207 (packedSelected [0,2,4] rootPS)) = affineNative (2^(12+1) ^^^ 1678) := by decide +kernel

theorem selectedBound5207 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env5208 : List Nat := [2,4,8,1,32,0,128,173,512,1024,1541,1197,1678,1677,1670,1157,1196,1573,1025,1670,1196,680,648,34,1543,649,1165,1676,1676,1029,1568,648,172,545,1677,137]

theorem envBound5208 : H12AffineFastState.Bounded env5208 := by
  intro p hp
  have h : env5208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5207_5208 : H12AffineEnvironment.transform 12 1678 env5207 = env5208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1678 env5207 == env5208) = true)

theorem identity5208 : scanCanonicalize (H12AffineFastState.compose env5208 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 130) := by decide +kernel

theorem selectedBound5208 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env5209 : List Nat := [2,4,8,1,32,0,128,173,130,1024,1159,1197,1036,1039,1028,1157,1196,1191,1025,1028,1196,42,10,34,1157,11,1165,1038,1038,1029,1186,10,172,163,1039,137]

theorem envBound5209 : H12AffineFastState.Bounded env5209 := by
  intro p hp
  have h : env5209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5208_5209 : H12AffineEnvironment.transform 8 130 env5208 = env5209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 130 env5208 == env5209) = true)

def env5210 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,16384,32768,65536,4113,262144,1025,32768,4097,4194304,4240517,41002,8329,4240516,323712,16385,16401,22560,74795,17412,188,20481,4239488,4241029]

theorem envBound5210 : H12AffineFastState.Bounded env5210 := by
  intro p hp
  have h : env5210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5190_5210 : H12AffineEnvironment.transform 7 189 env5190 = env5210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env5190 == env5210) = true)

theorem identity5210 : scanCanonicalize (H12AffineFastState.compose env5210 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 53402) := by decide +kernel

theorem selectedBound5210 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5211 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,16384,32768,53402,4113,262144,1025,32768,4097,4194304,4240517,41002,8329,4240516,323712,16385,16401,22560,62641,17412,188,20481,4239488,4241029]

theorem envBound5211 : H12AffineFastState.Bounded env5211 := by
  intro p hp
  have h : env5211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5210_5211 : H12AffineEnvironment.transform 15 53402 env5210 = env5211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53402 env5210 == env5211) = true)

def env5212 : List Nat := [2,4,8,0,32,1,128,173,512,1024,2048,4096,8192,16384,32768,53386,4097,262144,1025,32768,4097,4194304,4240517,41002,8329,4240516,323712,16385,16385,22560,62625,17412,172,20481,4239488,4241029]

theorem envBound5212 : H12AffineFastState.Bounded env5212 := by
  intro p hp
  have h : env5212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5211_5212 : H12AffineEnvironment.transform 3 0 env5211 = env5212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5211 == env5212) = true)

theorem identity5212 : scanCanonicalize (H12AffineFastState.compose env5212 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound5212 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env5213 : List Nat := [2,4,8,0,32,1,128,173,512,1024,2048,1029,8192,16384,32768,50319,1028,262144,1025,32768,1028,4194304,4235392,41002,8329,4235393,320645,16385,16385,19493,57508,17412,172,17412,4236421,4235904]

theorem envBound5213 : H12AffineFastState.Bounded env5213 := by
  intro p hp
  have h : env5213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5212_5213 : H12AffineEnvironment.transform 11 1029 env5212 = env5213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env5212 == env5213) = true)

theorem identity5213 : scanCanonicalize (H12AffineFastState.compose env5213 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound5213 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5214 : List Nat := [2,4,8,0,32,1,40,5,512,1024,2048,1029,8192,16384,32768,50215,1028,262144,1025,32768,1028,4194304,4235304,41002,8225,4235305,320557,16385,16385,19493,57356,17412,4,17412,4236333,4235816]

theorem envBound5214 : H12AffineFastState.Bounded env5214 := by
  intro p hp
  have h : env5214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5213_5214 : H12AffineEnvironment.transform 6 40 env5213 = env5214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5213 == env5214) = true)

theorem identity5214 : scanCanonicalize (H12AffineFastState.compose env5214 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound5214 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5215 : List Nat := [2,4,8,0,32,1,40,5,512,1024,2048,1029,8192,16384,8200,25647,1028,262144,1025,8200,1028,4194304,4194336,34,8225,4194337,279589,16385,16385,19493,16388,17412,4,17412,4195365,4194848]

theorem envBound5215 : H12AffineFastState.Bounded env5215 := by
  intro p hp
  have h : env5215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5214_5215 : H12AffineEnvironment.transform 14 8200 env5214 = env5215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env5214 == env5215) = true)

theorem identity5215 : scanCanonicalize (H12AffineFastState.compose env5215 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 8712) := by decide +kernel

theorem selectedBound5215 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env5216 : List Nat := [2,4,8,0,32,1,40,5,512,1024,2048,1029,8192,16384,8200,25647,1028,8712,1025,8200,1028,4194304,4194336,34,8225,4194337,26157,16385,16385,19493,16388,17412,4,17412,4195365,4194848]

theorem envBound5216 : H12AffineFastState.Bounded env5216 := by
  intro p hp
  have h : env5216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5215_5216 : H12AffineEnvironment.transform 17 8712 env5215 = env5216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8712 env5215 == env5216) = true)

theorem identity5216 : scanCanonicalize (H12AffineFastState.compose env5216 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 20015) := by decide +kernel

theorem selectedBound5216 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env5217 : List Nat := [2,4,8,0,32,1,40,5,512,1024,2048,1029,8192,16384,8200,25647,1028,8712,1025,8200,1028,20015,19983,34,8225,19982,26157,16385,16385,19493,16388,17412,4,17412,18954,19471]

theorem envBound5217 : H12AffineFastState.Bounded env5217 := by
  intro p hp
  have h : env5217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5216_5217 : H12AffineEnvironment.transform 21 20015 env5216 = env5217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 20015 env5216 == env5217) = true)

theorem identity5217 : scanCanonicalize (H12AffineFastState.compose env5217 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound5217 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env5218 : List Nat := [2,4,8,0,32,1,40,5,512,1024,523,1029,8192,16384,8200,25647,1028,8712,1025,8200,1028,17444,17412,34,8225,17413,26157,16385,16385,17966,16388,17412,4,17412,16385,17924]

theorem envBound5218 : H12AffineFastState.Bounded env5218 := by
  intro p hp
  have h : env5218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5217_5218 : H12AffineEnvironment.transform 10 523 env5217 = env5218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env5217 == env5218) = true)

theorem identity5218 : scanCanonicalize (H12AffineFastState.compose env5218 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 554) := by decide +kernel

theorem selectedBound5218 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5219 : List Nat := [2,4,8,0,32,1,40,5,512,1024,523,1029,8192,554,8200,9733,1028,8712,1025,8200,1028,1550,1582,34,8225,1583,9223,555,555,1028,558,1582,4,1582,555,1070]

theorem envBound5219 : H12AffineFastState.Bounded env5219 := by
  intro p hp
  have h : env5219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5218_5219 : H12AffineEnvironment.transform 13 554 env5218 = env5219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 554 env5218 == env5219) = true)

theorem identity5219 : scanCanonicalize (H12AffineFastState.compose env5219 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 1069) := by decide +kernel

theorem selectedBound5219 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5220 : List Nat := [2,4,8,0,32,1,40,5,512,1024,523,1029,1069,554,1061,552,1028,1573,1025,1061,1028,1550,1582,34,1036,1583,42,555,555,1028,558,1582,4,1582,555,1070]

theorem envBound5220 : H12AffineFastState.Bounded env5220 := by
  intro p hp
  have h : env5220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5219_5220 : H12AffineEnvironment.transform 12 1069 env5219 = env5220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1069 env5219 == env5220) = true)

theorem identity5220 : scanCanonicalize (H12AffineFastState.compose env5220 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound5220 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env5221 : List Nat := [2,4,8,0,32,1,40,5,512,37,523,32,8,554,0,552,33,512,36,0,33,555,523,34,41,522,42,555,555,33,558,523,4,523,555,11]

theorem envBound5221 : H12AffineFastState.Bounded env5221 := by
  intro p hp
  have h : env5221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5220_5221 : H12AffineEnvironment.transform 9 37 env5220 = env5221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env5220 == env5221) = true)

theorem identity5221 : scanCanonicalize (H12AffineFastState.compose env5221 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound5221 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env5222 : List Nat := [2,4,8,0,32,1,40,5,10,37,1,32,8,32,0,34,33,10,36,0,33,33,1,34,41,0,42,33,33,33,36,1,4,1,33,11]

theorem envBound5222 : H12AffineFastState.Bounded env5222 := by
  intro p hp
  have h : env5222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5221_5222 : H12AffineEnvironment.transform 8 10 env5221 = env5222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env5221 == env5222) = true)

theorem identity5222 : scanCanonicalize (H12AffineFastState.compose env5222 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound5222 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5223 : List Nat := [2,4,8,0,11,1,3,5,10,14,1,11,8,11,0,9,10,10,15,0,10,10,1,9,2,0,1,10,10,10,15,1,4,1,10,11]

theorem envBound5223 : H12AffineFastState.Bounded env5223 := by
  intro p hp
  have h : env5223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5222_5223 : H12AffineEnvironment.transform 4 11 env5222 = env5223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env5222 == env5223) = true)

theorem identity5223 : scanCanonicalize (H12AffineFastState.compose env5223 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound5223 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5224 : List Nat := [2,4,6,0,5,1,3,5,4,0,1,5,6,5,0,7,4,4,1,0,4,4,1,7,2,0,1,4,4,4,1,1,4,1,4,5]

theorem envBound5224 : H12AffineFastState.Bounded env5224 := by
  intro p hp
  have h : env5224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5223_5224 : H12AffineEnvironment.transform 2 6 env5223 = env5224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env5223 == env5224) = true)

theorem identity5224 : scanCanonicalize (H12AffineFastState.compose env5224 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound5224 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env5225 : List Nat := [2,0,2,0,1,1,3,1,0,0,1,1,2,1,0,3,0,0,1,0,0,0,1,3,2,0,1,0,0,0,1,1,0,1,0,1]

theorem envBound5225 : H12AffineFastState.Bounded env5225 := by
  intro p hp
  have h : env5225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5224_5225 : H12AffineEnvironment.transform 1 0 env5224 = env5225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env5224 == env5225) = true)

def env5226 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,32768,53387,4096,262144,1025,32768,4097,4194304,4240517,41002,8329,4240516,323712,16385,16384,22560,62624,17412,173,20481,4239488,4241029]

theorem envBound5226 : H12AffineFastState.Bounded env5226 := by
  intro p hp
  have h : env5226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5211_5226 : H12AffineEnvironment.transform 3 1 env5211 = env5226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5211 == env5226) = true)

def env5227 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,32768,53387,4096,262144,1025,32768,4097,41088,5125,41002,8329,5124,323712,16385,16384,22560,62624,17412,173,20481,4096,5637]

theorem envBound5227 : H12AffineFastState.Bounded env5227 := by
  intro p hp
  have h : env5227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5226_5227 : H12AffineEnvironment.transform 21 41088 env5226 = env5227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env5226 == env5227) = true)

theorem identity5227 : scanCanonicalize (H12AffineFastState.compose env5227 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 43528) := by decide +kernel

theorem selectedBound5227 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env5228 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,32768,53387,4096,43528,1025,32768,4097,41088,5125,41002,8329,5124,23176,16385,16384,22560,62624,17412,173,20481,4096,5637]

theorem envBound5228 : H12AffineFastState.Bounded env5228 := by
  intro p hp
  have h : env5228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5227_5228 : H12AffineEnvironment.transform 17 43528 env5227 = env5228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43528 env5227 == env5228) = true)

theorem identity5228 : scanCanonicalize (H12AffineFastState.compose env5228 (packedSelected [9,13,17,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5228 : packedSelected [9,13,17,22] rootPS < 2^1333 := by decide +kernel

def env5229 : List Nat := [2,4,8,1,32,0,41,5,512,1024,2048,4096,8192,16384,32768,53282,4096,43528,1025,32768,4097,41001,5125,41002,8224,5124,23073,16385,16384,22560,62473,17412,4,20481,4096,5637]

theorem envBound5229 : H12AffineFastState.Bounded env5229 := by
  intro p hp
  have h : env5229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5228_5229 : H12AffineEnvironment.transform 6 41 env5228 = env5229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5228 == env5229) = true)

theorem identity5229 : scanCanonicalize (H12AffineFastState.compose env5229 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(13+1) ^^^ 1573) := by decide +kernel

theorem selectedBound5229 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env5230 : List Nat := [2,4,8,1,32,0,41,5,512,1024,2048,4096,8192,1573,32768,38407,4096,43528,1025,32768,4097,41001,5125,41002,8224,5124,7172,1572,1573,7685,45612,545,4,5668,4096,5637]

theorem envBound5230 : H12AffineFastState.Bounded env5230 := by
  intro p hp
  have h : env5230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5229_5230 : H12AffineEnvironment.transform 13 1573 env5229 = env5230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1573 env5229 == env5230) = true)

def env5231 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,32768,53387,4096,262144,1025,32768,4097,41089,5124,41002,8329,5125,323712,16385,16384,22560,62624,17412,173,20481,4097,5636]

theorem envBound5231 : H12AffineFastState.Bounded env5231 := by
  intro p hp
  have h : env5231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5226_5231 : H12AffineEnvironment.transform 21 41089 env5226 = env5231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env5226 == env5231) = true)

theorem identity5231 : scanCanonicalize (H12AffineFastState.compose env5231 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 61093) := by decide +kernel

theorem selectedBound5231 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env5232 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,32768,53387,4096,61093,1025,32768,4097,41089,5124,41002,8329,5125,7717,16385,16384,22560,62624,17412,173,20481,4097,5636]

theorem envBound5232 : H12AffineFastState.Bounded env5232 := by
  intro p hp
  have h : env5232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5231_5232 : H12AffineEnvironment.transform 17 61093 env5231 = env5232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 61093 env5231 == env5232) = true)

theorem identity5232 : scanCanonicalize (H12AffineFastState.compose env5232 (packedSelected [9,13,17,22] rootPS)) = affineNative (2^(11+1) ^^^ 1196) := by decide +kernel

theorem selectedBound5232 : packedSelected [9,13,17,22] rootPS < 2^1333 := by decide +kernel

def env5233 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1196,8192,16384,32768,50215,1196,61093,1025,32768,1197,41089,168,41002,8329,169,2697,16385,16384,19596,57356,17412,173,17581,1197,680]

theorem envBound5233 : H12AffineFastState.Bounded env5233 := by
  intro p hp
  have h : env5233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5232_5233 : H12AffineEnvironment.transform 11 1196 env5232 = env5233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1196 env5232 == env5233) = true)

theorem identity5233 : scanCanonicalize (H12AffineFastState.compose env5233 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound5233 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5234 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1196,8192,16384,8201,25646,1196,20140,1025,8201,1197,136,168,35,8329,169,2697,16385,16384,19596,16389,17412,173,17581,1197,680]

theorem envBound5234 : H12AffineFastState.Bounded env5234 := by
  intro p hp
  have h : env5234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5233_5234 : H12AffineEnvironment.transform 14 8201 env5233 = env5234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env5233 == env5234) = true)

theorem identity5234 : scanCanonicalize (H12AffineFastState.compose env5234 (packedSelected [6,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 2090) := by decide +kernel

theorem selectedBound5234 : packedSelected [6,13,17] rootPS < 2^1333 := by decide +kernel

def env5235 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1196,8192,2090,8201,11268,1196,1670,1025,8201,1197,136,168,35,8329,169,2697,2091,2090,1190,2095,3118,173,3207,1197,680]

theorem envBound5235 : H12AffineFastState.Bounded env5235 := by
  intro p hp
  have h : env5235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5234_5235 : H12AffineEnvironment.transform 13 2090 env5234 = env5235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2090 env5234 == env5235) = true)

def env5236 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41002,8329,67108864,77914241,76039248,76039596,77613089,75572347,73983341,525568,77611008,82355408,8914925]

theorem envBound5236 : H12AffineFastState.Bounded env5236 := by
  intro p hp
  have h : env5236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4828_5236 : H12AffineEnvironment.transform 26 77914241 env4828 = env5236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 77914241 env4828 == env5236) = true)

def env5237 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41002,8329,8914000,2942161,16384,16892,2641009,598059,14737725,525568,2638928,6332544,8914925]

theorem envBound5237 : H12AffineFastState.Bounded env5237 := by
  intro p hp
  have h : env5237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5236_5237 : H12AffineEnvironment.transform 25 8914000 env5236 = env5237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914000 env5236 == env5237) = true)

def env5238 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4096,4194304,8388608,41002,8329,8914000,849105,16384,16892,547953,598059,12644669,525568,545872,4239488,8914925]

theorem envBound5238 : H12AffineFastState.Bounded env5238 := by
  intro p hp
  have h : env5238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5237_5238 : H12AffineEnvironment.transform 20 4096 env5237 = env5238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env5237 == env5238) = true)

def env5239 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4096,4194304,8388608,41002,8329,8388688,323793,16384,16892,22641,74795,12644669,256,20560,4239488,8389613]

theorem envBound5239 : H12AffineFastState.Bounded env5239 := by
  intro p hp
  have h : env5239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5238_5239 : H12AffineEnvironment.transform 18 1024 env5238 = env5239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env5238 == env5239) = true)

theorem identity5239 : scanCanonicalize (H12AffineFastState.compose env5239 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 5456) := by decide +kernel

theorem selectedBound5239 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5240 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4096,4194304,5456,41002,8329,5376,323793,16384,16892,22641,74795,4252781,256,20560,4239488,5821]

theorem envBound5240 : H12AffineFastState.Bounded env5240 := by
  intro p hp
  have h : env5240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5239_5240 : H12AffineEnvironment.transform 22 5456 env5239 = env5240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5456 env5239 == env5240) = true)

def env5241 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,4194304,5376,41002,8329,5376,323713,16384,16812,22561,74795,4252733,256,20480,4239488,5821]

theorem envBound5241 : H12AffineFastState.Bounded env5241 := by
  intro p hp
  have h : env5241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5240_5241 : H12AffineEnvironment.transform 5 16 env5240 = env5241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5240 == env5241) = true)

theorem identity5241 : scanCanonicalize (H12AffineFastState.compose env5241 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound5241 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5242 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,16384,32768,65536,1296,262144,1024,32768,1213,4194304,445,41002,8329,445,320572,16384,16812,19612,74795,4252733,256,17597,4236349,512]

theorem envBound5242 : H12AffineFastState.Bounded env5242 := by
  intro p hp
  have h : env5242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5241_5242 : H12AffineEnvironment.transform 11 1213 env5241 = env5242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env5241 == env5242) = true)

theorem identity5242 : scanCanonicalize (H12AffineFastState.compose env5242 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound5242 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5243 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,16384,32768,65536,1296,262144,1024,32768,1213,41348,445,41002,8329,445,320572,16384,16812,19612,74795,17849,256,17597,1465,512]

theorem envBound5243 : H12AffineFastState.Bounded env5243 := by
  intro p hp
  have h : env5243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5242_5243 : H12AffineEnvironment.transform 21 41348 env5242 = env5243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env5242 == env5243) = true)

theorem identity5243 : scanCanonicalize (H12AffineFastState.compose env5243 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26261) := by decide +kernel

theorem selectedBound5243 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5244 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,16384,26261,65536,1296,262144,1024,26261,1213,18193,445,18111,8329,445,262825,16384,16812,19612,74795,17849,256,17597,1465,512]

theorem envBound5244 : H12AffineFastState.Bounded env5244 := by
  intro p hp
  have h : env5244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5243_5244 : H12AffineEnvironment.transform 14 26261 env5243 = env5244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26261 env5243 == env5244) = true)

theorem identity5244 : scanCanonicalize (H12AffineFastState.compose env5244 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 25662) := by decide +kernel

theorem selectedBound5244 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5245 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,16384,26261,25662,1296,262144,1024,26261,1213,18193,445,18111,8329,445,262825,16384,16812,19612,16405,17849,256,17597,1465,512]

theorem envBound5245 : H12AffineFastState.Bounded env5245 := by
  intro p hp
  have h : env5245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5244_5245 : H12AffineEnvironment.transform 15 25662 env5244 = env5245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25662 env5244 == env5245) = true)

theorem identity5245 : scanCanonicalize (H12AffineFastState.compose env5245 (packedSelected [11,12,15,18,23,24,28,32] rootPS)) = affineNative (2^(13+1) ^^^ 1841) := by decide +kernel

theorem selectedBound5245 : packedSelected [11,12,15,18,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env5246 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,1841,8612,8975,1296,262144,1024,8612,1213,32,445,398,8329,445,262825,1841,1693,2989,1828,648,256,908,1465,512]

theorem envBound5246 : H12AffineFastState.Bounded env5246 := by
  intro p hp
  have h : env5246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5245_5246 : H12AffineEnvironment.transform 13 1841 env5245 = env5246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1841 env5245 == env5246) = true)

theorem identity5246 : scanCanonicalize (H12AffineFastState.compose env5246 (packedSelected [1,3,8,10,18,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound5246 : packedSelected [1,3,8,10,18,23,24] rootPS < 2^1333 := by decide +kernel

def env5247 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1213,8192,1692,8201,8866,1213,262144,1024,8201,1213,32,16,35,8329,16,262825,1692,1693,2560,1673,648,173,545,1044,512]

theorem envBound5247 : H12AffineFastState.Bounded env5247 := by
  intro p hp
  have h : env5247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5246_5247 : H12AffineEnvironment.transform 7 173 env5246 = env5247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env5246 == env5247) = true)

theorem identity5247 : scanCanonicalize (H12AffineFastState.compose env5247 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 1583) := by decide +kernel

theorem selectedBound5247 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5248 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1213,8192,1692,8201,8866,1213,1583,1024,8201,1213,32,16,35,8329,16,1158,1692,1693,2560,1673,648,173,545,1044,512]

theorem envBound5248 : H12AffineFastState.Bounded env5248 := by
  intro p hp
  have h : env5248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5247_5248 : H12AffineEnvironment.transform 17 1583 env5247 = env5248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1583 env5247 == env5248) = true)

def env5249 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,4194304,5377,41002,8329,5376,323712,16384,16813,22560,74795,4252732,256,20481,4239488,5821]

theorem envBound5249 : H12AffineFastState.Bounded env5249 := by
  intro p hp
  have h : env5249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5240_5249 : H12AffineEnvironment.transform 5 17 env5240 = env5249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5240 == env5249) = true)

def env5250 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,41260,5377,41002,8329,5376,323712,16384,16813,22560,74795,17680,256,20481,4524,5821]

theorem envBound5250 : H12AffineFastState.Bounded env5250 := by
  intro p hp
  have h : env5250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5249_5250 : H12AffineEnvironment.transform 21 41260 env5249 = env5250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41260 env5249 == env5250) = true)

theorem identity5250 : scanCanonicalize (H12AffineFastState.compose env5250 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5250 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env5251 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,8192,16384,32768,65536,4357,262144,1024,32768,4096,41260,5377,41002,8224,5376,323625,16384,16644,22560,74795,17680,256,20481,4357,5652]

theorem envBound5251 : H12AffineFastState.Bounded env5251 := by
  intro p hp
  have h : env5251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5250_5251 : H12AffineEnvironment.transform 6 41 env5250 = env5251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5250 == env5251) = true)

def env5252 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1296,8192,16384,32768,65536,1045,262144,1024,32768,1296,41260,17,41002,8224,16,320825,16384,16644,19760,74795,17680,256,17681,1045,772]

theorem envBound5252 : H12AffineFastState.Bounded env5252 := by
  intro p hp
  have h : env5252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5251_5252 : H12AffineEnvironment.transform 11 1296 env5251 = env5252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env5251 == env5252) = true)

def env5253 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1297,8192,16384,32768,65536,1044,262144,1024,32768,1297,41260,16,41002,8224,17,320824,16384,16644,19761,74795,17680,256,17680,1044,773]

theorem envBound5253 : H12AffineFastState.Bounded env5253 := by
  intro p hp
  have h : env5253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5251_5253 : H12AffineEnvironment.transform 11 1297 env5251 = env5253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env5251 == env5253) = true)

theorem identity5253 : scanCanonicalize (H12AffineFastState.compose env5253 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound5253 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5254 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,1045,8192,16384,32768,65536,1044,262144,1024,32768,1045,41000,16,41002,8224,17,320572,16384,16384,19509,74795,17428,4,17428,1044,513]

theorem envBound5254 : H12AffineFastState.Bounded env5254 := by
  intro p hp
  have h : env5254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5253_5254 : H12AffineEnvironment.transform 7 4 env5253 = env5254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env5253 == env5254) = true)

theorem identity5254 : scanCanonicalize (H12AffineFastState.compose env5254 (packedSelected [0,7,20] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound5254 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5255 : List Nat := [2,4,8,16,32,17,41,4,32,1024,2048,1045,8192,16384,32768,65536,1044,262144,1024,32768,1045,41000,16,41002,8224,17,320572,16384,16384,19509,74795,17428,4,17428,1044,33]

theorem envBound5255 : H12AffineFastState.Bounded env5255 := by
  intro p hp
  have h : env5255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5254_5255 : H12AffineEnvironment.transform 8 32 env5254 = env5255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env5254 == env5255) = true)

theorem identity5255 : scanCanonicalize (H12AffineFastState.compose env5255 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 25647) := by decide +kernel

theorem selectedBound5255 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5256 : List Nat := [2,4,8,16,32,17,41,4,32,1024,2048,1045,8192,16384,32768,25647,1044,262144,1024,32768,1045,41000,16,41002,8224,17,320572,16384,16384,19509,16388,17428,4,17428,1044,33]

theorem envBound5256 : H12AffineFastState.Bounded env5256 := by
  intro p hp
  have h : env5256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5255_5256 : H12AffineEnvironment.transform 15 25647 env5255 = env5256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25647 env5255 == env5256) = true)

theorem identity5256 : scanCanonicalize (H12AffineFastState.compose env5256 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8217) := by decide +kernel

theorem selectedBound5256 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env5257 : List Nat := [2,4,8,16,32,17,41,4,32,1024,2048,1045,8192,16384,8217,25647,1044,262144,1024,8217,1045,49,16,51,8224,17,279589,16384,16384,19509,16388,17428,4,17428,1044,33]

theorem envBound5257 : H12AffineFastState.Bounded env5257 := by
  intro p hp
  have h : env5257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5256_5257 : H12AffineEnvironment.transform 14 8217 env5256 = env5257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8217 env5256 == env5257) = true)

theorem identity5257 : scanCanonicalize (H12AffineFastState.compose env5257 (packedSelected [2,6,8,10,12] rootPS)) = affineNative (2^(17+1) ^^^ 46) := by decide +kernel

theorem selectedBound5257 : packedSelected [2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env5258 : List Nat := [2,4,8,16,32,17,41,4,32,1024,2048,1045,8192,16384,8217,25647,1044,46,1024,8217,1045,49,16,51,8224,17,17419,16384,16384,19509,16388,17428,4,17428,1044,33]

theorem envBound5258 : H12AffineFastState.Bounded env5258 := by
  intro p hp
  have h : env5258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5257_5258 : H12AffineEnvironment.transform 17 46 env5257 = env5258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 46 env5257 == env5258) = true)

theorem identity5258 : scanCanonicalize (H12AffineFastState.compose env5258 (packedSelected [13,17] rootPS)) = affineNative (2^(10+1) ^^^ 14) := by decide +kernel

theorem selectedBound5258 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env5259 : List Nat := [2,4,8,16,32,17,41,4,32,1024,14,1045,8192,16384,8217,25647,1044,46,1024,8217,1045,49,16,51,8224,17,17419,16384,16384,17467,16388,17428,4,17428,1044,33]

theorem envBound5259 : H12AffineFastState.Bounded env5259 := by
  intro p hp
  have h : env5259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5258_5259 : H12AffineEnvironment.transform 10 14 env5258 = env5259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 14 env5258 == env5259) = true)

theorem identity5259 : scanCanonicalize (H12AffineFastState.compose env5259 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 17) := by decide +kernel

theorem selectedBound5259 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env5260 : List Nat := [2,4,8,16,32,17,41,4,32,17,14,4,8192,16384,8217,24638,5,46,17,8217,4,49,16,51,8224,17,16410,16384,16384,16426,16388,16389,4,16389,5,33]

theorem envBound5260 : H12AffineFastState.Bounded env5260 := by
  intro p hp
  have h : env5260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5259_5260 : H12AffineEnvironment.transform 9 17 env5259 = env5260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 17 env5259 == env5260) = true)

theorem identity5260 : scanCanonicalize (H12AffineFastState.compose env5260 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound5260 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5261 : List Nat := [2,4,8,1,32,0,41,4,32,0,14,4,8192,16384,8200,24623,5,46,0,8200,4,32,1,34,8224,0,16395,16384,16384,16426,16388,16389,4,16389,5,33]

theorem envBound5261 : H12AffineFastState.Bounded env5261 := by
  intro p hp
  have h : env5261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5260_5261 : H12AffineEnvironment.transform 3 1 env5260 = env5261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5260 == env5261) = true)

theorem identity5261 : scanCanonicalize (H12AffineFastState.compose env5261 (packedSelected [0,1,4] rootPS)) = affineNative (2^(13+1) ^^^ 8195) := by decide +kernel

theorem selectedBound5261 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env5262 : List Nat := [2,4,8,1,32,0,41,4,32,0,14,4,8192,8195,8200,44,5,46,0,8200,4,32,1,34,8224,0,8200,8195,8195,8233,8199,8198,4,8198,5,33]

theorem envBound5262 : H12AffineFastState.Bounded env5262 := by
  intro p hp
  have h : env5262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5261_5262 : H12AffineEnvironment.transform 13 8195 env5261 = env5262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8195 env5261 == env5262) = true)

theorem identity5262 : scanCanonicalize (H12AffineFastState.compose env5262 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound5262 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5263 : List Nat := [2,4,8,1,32,0,41,4,32,0,14,4,8,11,0,44,5,46,0,0,4,32,1,34,40,0,0,11,11,33,15,14,4,14,5,33]

theorem envBound5263 : H12AffineFastState.Bounded env5263 := by
  intro p hp
  have h : env5263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5262_5263 : H12AffineEnvironment.transform 12 8 env5262 = env5263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env5262 == env5263) = true)

theorem identity5263 : scanCanonicalize (H12AffineFastState.compose env5263 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound5263 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5264 : List Nat := [2,4,3,1,32,0,34,4,32,0,5,4,3,0,0,39,5,37,0,0,4,32,1,34,35,0,0,0,0,33,4,5,4,5,5,33]

theorem envBound5264 : H12AffineFastState.Bounded env5264 := by
  intro p hp
  have h : env5264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5263_5264 : H12AffineEnvironment.transform 2 3 env5263 = env5264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env5263 == env5264) = true)

theorem identity5264 : scanCanonicalize (H12AffineFastState.compose env5264 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound5264 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env5265 : List Nat := [2,4,3,1,4,0,6,4,4,0,5,4,3,0,0,3,5,1,0,0,4,4,1,6,7,0,0,0,0,5,4,5,4,5,5,5]

theorem envBound5265 : H12AffineFastState.Bounded env5265 := by
  intro p hp
  have h : env5265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5264_5265 : H12AffineEnvironment.transform 4 4 env5264 = env5265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env5264 == env5265) = true)

def leafEnv5265 : List Nat := [2,4,3,1,4,0,6,4,4,0,5,4,3,0,0,3,5,1,0,0,4,4,1,6,5,7,1,0,0,0,0,5,4,5,4,5,5,6,5,5,1,0,0]

def active5265 : List Nat := [0,1]

def tree5265 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5265 : H12WitnessSearch.Good tree5265 := H12GlobalWitnessIndex.good

theorem leafIdentity5265 : H12AffineFastState.composeSystem env5265 rootObs = leafEnv5265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5265 rootObs == leafEnv5265) = true)

theorem terminalChecked5265 : H12PackedTerminal.terminalCheckFast leafEnv5265 active5265 tree5265 = true := by decide +kernel

def env5266 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,41261,5377,41002,8329,5376,323712,16384,16813,22560,74795,17681,256,20481,4525,5821]

theorem envBound5266 : H12AffineFastState.Bounded env5266 := by
  intro p hp
  have h : env5266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5249_5266 : H12AffineEnvironment.transform 21 41261 env5249 = env5266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41261 env5249 == env5266) = true)

theorem identity5266 : scanCanonicalize (H12AffineFastState.compose env5266 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 26002) := by decide +kernel

theorem selectedBound5266 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env5267 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,26002,4524,262144,1024,32768,4096,41261,5377,41002,8329,5376,323712,16384,16813,22560,16825,17681,256,20481,4525,5821]

theorem envBound5267 : H12AffineFastState.Bounded env5267 := by
  intro p hp
  have h : env5267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5266_5267 : H12AffineEnvironment.transform 15 26002 env5266 = env5267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26002 env5266 == env5267) = true)

def env5268 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,16384,32768,26002,1212,262144,1024,32768,1296,41261,17,41002,8329,16,320912,16384,16813,19760,16825,17681,256,17681,1213,941]

theorem envBound5268 : H12AffineFastState.Bounded env5268 := by
  intro p hp
  have h : env5268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5267_5268 : H12AffineEnvironment.transform 11 1296 env5267 = env5268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env5267 == env5268) = true)

theorem identity5268 : scanCanonicalize (H12AffineFastState.compose env5268 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound5268 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5269 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,1044,8192,16384,32768,25750,1212,262144,1024,32768,1044,41001,17,41002,8329,16,320660,16384,16553,19508,16573,17429,4,17429,1213,681]

theorem envBound5269 : H12AffineFastState.Bounded env5269 := by
  intro p hp
  have h : env5269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5268_5269 : H12AffineEnvironment.transform 7 4 env5268 = env5269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env5268 == env5269) = true)

theorem identity5269 : scanCanonicalize (H12AffineFastState.compose env5269 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 1588) := by decide +kernel

theorem selectedBound5269 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env5270 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,1044,8192,1588,32768,8866,1212,262144,1024,32768,1044,41001,17,41002,8329,16,303776,1588,1693,2560,1673,545,4,545,1213,681]

theorem envBound5270 : H12AffineFastState.Bounded env5270 := by
  intro p hp
  have h : env5270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5269_5270 : H12AffineEnvironment.transform 13 1588 env5269 = env5270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1588 env5269 == env5270) = true)

theorem identity5270 : scanCanonicalize (H12AffineFastState.compose env5270 (packedSelected [2,3,5,10,11,17,18,21] rootPS)) = affineNative (2^(14+1) ^^^ 8352) := by decide +kernel

theorem selectedBound5270 : packedSelected [2,3,5,10,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env5271 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,1044,8192,1588,8352,8866,1212,262144,1024,8352,1044,137,17,138,8329,16,262656,1588,1693,2560,1673,545,4,545,1213,681]

theorem envBound5271 : H12AffineFastState.Bounded env5271 := by
  intro p hp
  have h : env5271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5270_5271 : H12AffineEnvironment.transform 14 8352 env5270 = env5271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env5270 == env5271) = true)

theorem identity5271 : scanCanonicalize (H12AffineFastState.compose env5271 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 2561) := by decide +kernel

theorem selectedBound5271 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5272 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,1044,8192,1588,8352,8866,1212,2561,1024,8352,1044,137,17,138,8329,16,2049,1588,1693,2560,1673,545,4,545,1213,681]

theorem envBound5272 : H12AffineFastState.Bounded env5272 := by
  intro p hp
  have h : env5272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5271_5272 : H12AffineEnvironment.transform 17 2561 env5271 = env5272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2561 env5271 == env5272) = true)

theorem identity5272 : scanCanonicalize (H12AffineFastState.compose env5272 (packedSelected [0,2,7,13] rootPS)) = affineNative (2^(9+1) ^^^ 700) := by decide +kernel

theorem selectedBound5272 : packedSelected [0,2,7,13] rootPS < 2^1333 := by decide +kernel

def env5273 : List Nat := [2,4,8,16,32,17,128,4,512,700,2048,680,8192,136,8352,8866,512,2561,700,8352,680,137,17,138,8329,16,2049,136,33,2560,53,545,4,545,513,681]

theorem envBound5273 : H12AffineFastState.Bounded env5273 := by
  intro p hp
  have h : env5273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5272_5273 : H12AffineEnvironment.transform 9 700 env5272 = env5273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 700 env5272 == env5273) = true)

theorem identity5273 : scanCanonicalize (H12AffineFastState.compose env5273 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 552) := by decide +kernel

theorem selectedBound5273 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env5274 : List Nat := [2,4,8,16,32,17,128,4,512,700,2048,680,552,136,648,138,512,2561,700,648,680,137,17,138,673,16,2049,136,33,2560,53,545,4,545,513,681]

theorem envBound5274 : H12AffineFastState.Bounded env5274 := by
  intro p hp
  have h : env5274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5273_5274 : H12AffineEnvironment.transform 12 552 env5273 = env5274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 552 env5273 == env5274) = true)

def env5275 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,16384,32768,26002,1213,262144,1024,32768,1297,41261,16,41002,8329,17,320913,16384,16813,19761,16825,17681,256,17680,1212,940]

theorem envBound5275 : H12AffineFastState.Bounded env5275 := by
  intro p hp
  have h : env5275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5267_5275 : H12AffineEnvironment.transform 11 1297 env5267 = env5275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env5267 == env5275) = true)

theorem identity5275 : scanCanonicalize (H12AffineFastState.compose env5275 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5275 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5276 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1297,8192,16384,32768,25915,1044,262144,1024,32768,1297,41261,16,41002,8224,17,320824,16384,16644,19761,16656,17681,256,17680,1045,773]

theorem envBound5276 : H12AffineFastState.Bounded env5276 := by
  intro p hp
  have h : env5276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5275_5276 : H12AffineEnvironment.transform 6 41 env5275 = env5276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5275 == env5276) = true)

theorem identity5276 : scanCanonicalize (H12AffineFastState.compose env5276 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 57623) := by decide +kernel

theorem selectedBound5276 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5277 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1297,8192,16384,32768,25915,1044,57623,1024,32768,1297,41261,16,41002,8224,17,1071,16384,16644,19761,16656,17681,256,17680,1045,773]

theorem envBound5277 : H12AffineFastState.Bounded env5277 := by
  intro p hp
  have h : env5277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5276_5277 : H12AffineEnvironment.transform 17 57623 env5276 = env5277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 57623 env5276 == env5277) = true)

theorem identity5277 : scanCanonicalize (H12AffineFastState.compose env5277 (packedSelected [1,5,13,15] rootPS)) = affineNative (2^(13+1) ^^^ 8210) := by decide +kernel

theorem selectedBound5277 : packedSelected [1,5,13,15] rootPS < 2^1333 := by decide +kernel

def env5278 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1297,8192,8210,32768,1321,1044,33029,1024,32768,1297,41261,16,41002,8224,17,1071,8210,8470,11555,8450,9475,256,9474,1045,773]

theorem envBound5278 : H12AffineFastState.Bounded env5278 := by
  intro p hp
  have h : env5278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5277_5278 : H12AffineEnvironment.transform 13 8210 env5277 = env5278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8210 env5277 == env5278) = true)

theorem identity5278 : scanCanonicalize (H12AffineFastState.compose env5278 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound5278 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env5279 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,1044,8192,8210,32768,1068,1044,32768,1024,32768,1044,41000,16,41002,8224,17,1071,8210,8211,11302,8199,9222,5,9223,1045,512]

theorem envBound5279 : H12AffineFastState.Bounded env5279 := by
  intro p hp
  have h : env5279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5278_5279 : H12AffineEnvironment.transform 7 5 env5278 = env5279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env5278 == env5279) = true)

theorem identity5279 : scanCanonicalize (H12AffineFastState.compose env5279 (packedSelected [3,8,12,17] rootPS)) = affineNative (2^(14+1) ^^^ 1070) := by decide +kernel

theorem selectedBound5279 : packedSelected [3,8,12,17] rootPS < 2^1333 := by decide +kernel

def env5280 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,1044,8192,8210,1070,1068,1044,1070,1024,1070,1044,9222,16,9220,8224,17,1071,8210,8211,11302,8199,9222,5,9223,1045,512]

theorem envBound5280 : H12AffineFastState.Bounded env5280 := by
  intro p hp
  have h : env5280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5279_5280 : H12AffineEnvironment.transform 14 1070 env5279 = env5280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1070 env5279 == env5280) = true)

theorem identity5280 : scanCanonicalize (H12AffineFastState.compose env5280 (packedSelected [2,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound5280 : packedSelected [2,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env5281 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,1044,2088,2106,1070,1068,1044,1070,1024,1070,1044,3118,16,3116,2056,17,1071,2106,2107,1038,2095,3118,5,3119,1045,512]

theorem envBound5281 : H12AffineFastState.Bounded env5281 := by
  intro p hp
  have h : env5281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5280_5281 : H12AffineEnvironment.transform 12 2088 env5280 = env5281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env5280 == env5281) = true)

theorem identity5281 : scanCanonicalize (H12AffineFastState.compose env5281 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound5281 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env5282 : List Nat := [2,4,8,16,32,17,41,5,512,21,2048,1,2088,2106,59,57,1,59,21,59,1,2107,16,2105,2056,17,58,2106,2107,27,2095,2107,5,2106,0,512]

theorem envBound5282 : H12AffineFastState.Bounded env5282 := by
  intro p hp
  have h : env5282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5281_5282 : H12AffineEnvironment.transform 9 21 env5281 = env5282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env5281 == env5282) = true)

theorem identity5282 : scanCanonicalize (H12AffineFastState.compose env5282 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound5282 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env5283 : List Nat := [2,4,8,10,32,11,41,5,512,15,2048,1,2088,2080,33,35,1,33,15,33,1,2081,10,2083,2056,11,32,2080,2081,1,2095,2081,5,2080,0,512]

theorem envBound5283 : H12AffineFastState.Bounded env5283 := by
  intro p hp
  have h : env5283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5282_5283 : H12AffineEnvironment.transform 3 10 env5282 = env5283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env5282 == env5283) = true)

theorem identity5283 : scanCanonicalize (H12AffineFastState.compose env5283 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound5283 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5284 : List Nat := [2,4,8,10,32,11,41,5,512,15,0,1,40,32,33,35,1,33,15,33,1,33,10,35,8,11,32,32,33,1,47,33,5,32,0,512]

theorem envBound5284 : H12AffineFastState.Bounded env5284 := by
  intro p hp
  have h : env5284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5283_5284 : H12AffineEnvironment.transform 10 0 env5283 = env5284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env5283 == env5284) = true)

theorem identity5284 : scanCanonicalize (H12AffineFastState.compose env5284 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound5284 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5285 : List Nat := [2,4,8,10,0,11,9,5,512,15,0,1,8,0,1,3,1,1,15,1,1,1,10,3,8,11,0,0,1,1,15,1,5,0,0,512]

theorem envBound5285 : H12AffineFastState.Bounded env5285 := by
  intro p hp
  have h : env5285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5284_5285 : H12AffineEnvironment.transform 4 0 env5284 = env5285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env5284 == env5285) = true)

def env5286 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4096,4194304,8388608,41002,8329,8388689,323792,16384,16892,22640,74794,12644669,257,20561,4239488,8389612]

theorem envBound5286 : H12AffineFastState.Bounded env5286 := by
  intro p hp
  have h : env5286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5238_5286 : H12AffineEnvironment.transform 18 1025 env5238 = env5286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env5238 == env5286) = true)

theorem identity5286 : scanCanonicalize (H12AffineFastState.compose env5286 (packedSelected [14] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound5286 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5287 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,4605,262144,1025,32768,4096,4194304,8388608,41002,8329,8388689,303232,4176,4524,2080,74794,12624237,257,1,4239488,8389612]

theorem envBound5287 : H12AffineFastState.Bounded env5287 := by
  intro p hp
  have h : env5287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5286_5287 : H12AffineEnvironment.transform 13 4176 env5286 = env5287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env5286 == env5287) = true)

def env5288 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,4525,262144,1025,32768,4096,4194304,8388608,41002,8329,8388609,303232,4096,4524,2080,74794,12624189,257,1,4239488,8389564]

theorem envBound5288 : H12AffineFastState.Bounded env5288 := by
  intro p hp
  have h : env5288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5287_5288 : H12AffineEnvironment.transform 5 16 env5287 = env5288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5287 == env5288) = true)

def env5289 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,4525,43136,1025,32768,4096,4194304,8388608,41002,8329,8388609,2048,4096,4524,2080,74794,12624189,257,1,4239488,8389564]

theorem envBound5289 : H12AffineFastState.Bounded env5289 := by
  intro p hp
  have h : env5289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5288_5289 : H12AffineEnvironment.transform 17 43136 env5288 = env5289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43136 env5288 == env5289) = true)

theorem identity5289 : scanCanonicalize (H12AffineFastState.compose env5289 (packedSelected [0,1,4,5,8,13,17,18,20,22,23,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound5289 : packedSelected [0,1,4,5,8,13,17,18,20,22,23,24,27] rootPS < 2^1333 := by decide +kernel

def env5290 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,8323,4525,43136,1025,32768,4096,4194304,8388608,41002,8329,8388609,2048,4096,4524,2080,1193,12624189,257,1,4239488,8389564]

theorem envBound5290 : H12AffineFastState.Bounded env5290 := by
  intro p hp
  have h : env5290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5289_5290 : H12AffineEnvironment.transform 15 8323 env5289 = env5290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env5289 == env5290) = true)

theorem identity5290 : scanCanonicalize (H12AffineFastState.compose env5290 (packedSelected [0,1,4,5,7,8,9,18,23,24] rootPS)) = affineNative (2^(21+1) ^^^ 46873) := by decide +kernel

theorem selectedBound5290 : packedSelected [0,1,4,5,7,8,9,18,23,24] rootPS < 2^1333 := by decide +kernel

def env5291 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,8323,4525,43136,1025,32768,4096,46873,8388608,41002,8329,8388609,2048,4096,4524,2080,1193,8394276,257,1,1945,8389564]

theorem envBound5291 : H12AffineFastState.Bounded env5291 := by
  intro p hp
  have h : env5291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5290_5291 : H12AffineEnvironment.transform 21 46873 env5290 = env5291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46873 env5290 == env5291) = true)

theorem identity5291 : scanCanonicalize (H12AffineFastState.compose env5291 (packedSelected [3,4,5,8,20,22,28] rootPS)) = affineNative (2^(11+1) ^^^ 1840) := by decide +kernel

theorem selectedBound5291 : packedSelected [3,4,5,8,20,22,28] rootPS < 2^1333 := by decide +kernel

def env5292 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1840,8192,1840,32768,8323,1693,43136,1025,32768,1840,41001,8388608,41002,8329,8388609,2048,1840,1692,2080,1193,8388884,257,1,1945,8389564]

theorem envBound5292 : H12AffineFastState.Bounded env5292 := by
  intro p hp
  have h : env5292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5291_5292 : H12AffineEnvironment.transform 11 1840 env5291 = env5292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1840 env5291 == env5292) = true)

theorem identity5292 : scanCanonicalize (H12AffineFastState.compose env5292 (packedSelected [0,4,7,9,17,21] rootPS)) = affineNative (2^(22+1) ^^^ 276) := by decide +kernel

theorem selectedBound5292 : packedSelected [0,4,7,9,17,21] rootPS < 2^1333 := by decide +kernel

def env5293 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1840,8192,1840,32768,8323,1693,43136,1025,32768,1840,41001,276,41002,8329,277,2048,1840,1692,2080,1193,0,257,1,1945,680]

theorem envBound5293 : H12AffineFastState.Bounded env5293 := by
  intro p hp
  have h : env5293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5292_5293 : H12AffineEnvironment.transform 22 276 env5292 = env5293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 276 env5292 == env5293) = true)

theorem identity5293 : scanCanonicalize (H12AffineFastState.compose env5293 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound5293 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5294 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1589,8192,1589,32768,8323,1693,43136,1025,32768,1589,41001,17,41002,8329,16,2048,1589,1692,2080,1193,0,4,1,1692,680]

theorem envBound5294 : H12AffineFastState.Bounded env5294 := by
  intro p hp
  have h : env5294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5293_5294 : H12AffineEnvironment.transform 7 5 env5293 = env5294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env5293 == env5294) = true)

theorem identity5294 : scanCanonicalize (H12AffineFastState.compose env5294 (packedSelected [3,8,10,15] rootPS)) = affineNative (2^(14+1) ^^^ 32) := by decide +kernel

theorem selectedBound5294 : packedSelected [3,8,10,15] rootPS < 2^1333 := by decide +kernel

def env5295 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1589,8192,1589,32,8323,1693,10400,1025,32,1589,8201,17,8202,8329,16,2048,1589,1692,2080,1193,0,4,1,1692,680]

theorem envBound5295 : H12AffineFastState.Bounded env5295 := by
  intro p hp
  have h : env5295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5294_5295 : H12AffineEnvironment.transform 14 32 env5294 = env5295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 32 env5294 == env5295) = true)

theorem identity5295 : scanCanonicalize (H12AffineFastState.compose env5295 (packedSelected [2,6,11,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 3591) := by decide +kernel

theorem selectedBound5295 : packedSelected [2,6,11,12,13] rootPS < 2^1333 := by decide +kernel

def env5296 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1589,3591,1589,32,3716,1693,1703,1025,32,1589,3598,17,3597,3726,16,2048,1589,1692,2080,1193,0,4,1,1692,680]

theorem envBound5296 : H12AffineFastState.Bounded env5296 := by
  intro p hp
  have h : env5296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5295_5296 : H12AffineEnvironment.transform 12 3591 env5295 = env5296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3591 env5295 == env5296) = true)

theorem identity5296 : scanCanonicalize (H12AffineFastState.compose env5296 (packedSelected [2,5,6,8,12,17] rootPS)) = affineNative (2^(10+1) ^^^ 1692) := by decide +kernel

theorem selectedBound5296 : packedSelected [2,5,6,8,12,17] rootPS < 2^1333 := by decide +kernel

def env5297 : List Nat := [2,4,8,16,32,16,128,5,512,1024,1692,1589,155,1589,32,24,1693,1703,1025,32,1589,146,17,145,18,16,1692,1589,1692,1724,1193,0,4,1,1692,680]

theorem envBound5297 : H12AffineFastState.Bounded env5297 := by
  intro p hp
  have h : env5297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5296_5297 : H12AffineEnvironment.transform 10 1692 env5296 = env5297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1692 env5296 == env5297) = true)

theorem identity5297 : scanCanonicalize (H12AffineFastState.compose env5297 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound5297 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env5298 : List Nat := [2,4,8,10,32,10,128,5,512,1024,1670,1583,129,1583,32,2,1671,1703,1025,32,1583,136,11,139,8,10,1670,1583,1670,1702,1193,0,4,1,1670,680]

theorem envBound5298 : H12AffineFastState.Bounded env5298 := by
  intro p hp
  have h : env5298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5297_5298 : H12AffineEnvironment.transform 3 10 env5297 = env5298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env5297 == env5298) = true)

theorem identity5298 : scanCanonicalize (H12AffineFastState.compose env5298 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound5298 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env5299 : List Nat := [2,4,8,10,32,10,128,5,33,1024,1191,1038,129,1038,32,2,1190,1158,1025,32,1038,136,11,139,8,10,1191,1038,1191,1159,1193,0,4,1,1191,137]

theorem envBound5299 : H12AffineFastState.Bounded env5299 := by
  intro p hp
  have h : env5299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5298_5299 : H12AffineEnvironment.transform 8 33 env5298 = env5299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env5298 == env5299) = true)

theorem identity5299 : scanCanonicalize (H12AffineFastState.compose env5299 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound5299 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env5300 : List Nat := [2,4,8,10,32,10,128,5,33,14,169,0,129,0,32,2,168,136,15,32,0,136,11,139,8,10,169,0,169,137,167,0,4,1,169,137]

theorem envBound5300 : H12AffineFastState.Bounded env5300 := by
  intro p hp
  have h : env5300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5299_5300 : H12AffineEnvironment.transform 9 14 env5299 = env5300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env5299 == env5300) = true)

theorem identity5300 : scanCanonicalize (H12AffineFastState.compose env5300 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound5300 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env5301 : List Nat := [2,4,8,10,32,10,3,5,33,14,42,0,2,0,32,2,43,11,15,32,0,11,11,8,8,10,42,0,42,10,36,0,4,1,42,10]

theorem envBound5301 : H12AffineFastState.Bounded env5301 := by
  intro p hp
  have h : env5301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5300_5301 : H12AffineEnvironment.transform 6 3 env5300 = env5301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env5300 == env5301) = true)

theorem identity5301 : scanCanonicalize (H12AffineFastState.compose env5301 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound5301 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5302 : List Nat := [2,4,8,10,1,10,3,5,0,14,11,0,2,0,1,2,10,11,15,1,0,11,11,8,8,10,11,0,11,10,5,0,4,1,11,10]

theorem envBound5302 : H12AffineFastState.Bounded env5302 := by
  intro p hp
  have h : env5302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5301_5302 : H12AffineEnvironment.transform 4 1 env5301 = env5302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env5301 == env5302) = true)

theorem identity5302 : scanCanonicalize (H12AffineFastState.compose env5302 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound5302 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env5303 : List Nat := [2,4,3,1,1,1,3,5,0,5,0,0,2,0,1,2,1,0,4,1,0,0,0,3,3,1,0,0,0,1,5,0,4,1,0,1]

theorem envBound5303 : H12AffineFastState.Bounded env5303 := by
  intro p hp
  have h : env5303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5302_5303 : H12AffineEnvironment.transform 2 3 env5302 = env5303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env5302 == env5303) = true)

theorem identity5303 : scanCanonicalize (H12AffineFastState.compose env5303 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound5303 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5304 : List Nat := [2,1,3,1,1,1,3,0,0,0,0,0,2,0,1,2,1,0,1,1,0,0,0,3,3,1,0,0,0,1,0,0,1,1,0,1]

theorem envBound5304 : H12AffineFastState.Bounded env5304 := by
  intro p hp
  have h : env5304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5303_5304 : H12AffineEnvironment.transform 1 1 env5303 = env5304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env5303 == env5304) = true)

def env5305 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,4525,43137,1025,32768,4096,4194304,8388608,41002,8329,8388609,2049,4096,4524,2080,74794,12624189,257,1,4239488,8389564]

theorem envBound5305 : H12AffineFastState.Bounded env5305 := by
  intro p hp
  have h : env5305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5288_5305 : H12AffineEnvironment.transform 17 43137 env5288 = env5305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43137 env5288 == env5305) = true)

theorem identity5305 : scanCanonicalize (H12AffineFastState.compose env5305 (packedSelected [0,1,4,5,8,13,17,18,20,22,23,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 8352) := by decide +kernel

theorem selectedBound5305 : packedSelected [0,1,4,5,8,13,17,18,20,22,23,24,27] rootPS < 2^1333 := by decide +kernel

def env5306 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,8352,65536,4525,2081,1025,8352,4096,4194304,8388608,138,8329,8388609,2049,4096,4524,2080,74794,12583325,257,1,4198432,8389564]

theorem envBound5306 : H12AffineFastState.Bounded env5306 := by
  intro p hp
  have h : env5306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5305_5306 : H12AffineEnvironment.transform 14 8352 env5305 = env5306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env5305 == env5306) = true)

theorem identity5306 : scanCanonicalize (H12AffineFastState.compose env5306 (packedSelected [0,1,5,7,8,9,10,20,22,24,31] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound5306 : packedSelected [0,1,5,7,8,9,10,20,22,24,31] rootPS < 2^1333 := by decide +kernel

def env5307 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,8352,8235,4525,2081,1025,8352,4096,4194304,8388608,138,8329,8388609,2049,4096,4524,2080,1025,12583325,257,1,4198432,8389564]

theorem envBound5307 : H12AffineFastState.Bounded env5307 := by
  intro p hp
  have h : env5307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5306_5307 : H12AffineEnvironment.transform 15 8235 env5306 = env5307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env5306 == env5307) = true)

theorem identity5307 : scanCanonicalize (H12AffineFastState.compose env5307 (packedSelected [17,21] rootPS)) = affineNative (2^(22+1) ^^^ 4194457) := by decide +kernel

theorem selectedBound5307 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env5308 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,8352,8235,4525,2081,1025,8352,4096,4194304,4194457,138,8329,4194456,2049,4096,4524,2080,1025,260,257,1,4198432,4195109]

theorem envBound5308 : H12AffineFastState.Bounded env5308 := by
  intro p hp
  have h : env5308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5307_5308 : H12AffineEnvironment.transform 22 4194457 env5307 = env5308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4194457 env5307 == env5308) = true)

theorem identity5308 : scanCanonicalize (H12AffineFastState.compose env5308 (packedSelected [2,3,4,5,6,9,10,13,20] rootPS)) = affineNative (2^(11+1) ^^^ 2367) := by decide +kernel

theorem selectedBound5308 : packedSelected [2,3,4,5,6,9,10,13,20] rootPS < 2^1333 := by decide +kernel

def env5309 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2367,8192,2367,8352,8235,2194,2081,1025,8352,2367,4194304,4194457,138,8329,4194456,2049,2367,2195,2080,1025,260,257,1,4196639,4195109]

theorem envBound5309 : H12AffineFastState.Bounded env5309 := by
  intro p hp
  have h : env5309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5308_5309 : H12AffineEnvironment.transform 11 2367 env5308 = env5309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2367 env5308 == env5309) = true)

theorem identity5309 : scanCanonicalize (H12AffineFastState.compose env5309 (packedSelected [0,1,7,8,10,12,13,17,23] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound5309 : packedSelected [0,1,7,8,10,12,13,17,23] rootPS < 2^1333 := by decide +kernel

def env5310 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,2106,8192,2106,8352,8235,2194,2081,1025,8352,2106,4194304,4194457,138,8329,4194456,2049,2106,2195,2080,1025,1,4,1,4196378,4194848]

theorem envBound5310 : H12AffineFastState.Bounded env5310 := by
  intro p hp
  have h : env5310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5309_5310 : H12AffineEnvironment.transform 7 5 env5309 = env5310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env5309 == env5310) = true)

theorem identity5310 : scanCanonicalize (H12AffineFastState.compose env5310 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5310 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env5311 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,2106,8192,2106,8201,8235,2107,2081,1025,8201,2106,4194304,4194352,35,8224,4194353,2049,2106,2106,2080,1025,1,4,1,4196378,4194848]

theorem envBound5311 : H12AffineFastState.Bounded env5311 := by
  intro p hp
  have h : env5311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5310_5311 : H12AffineEnvironment.transform 6 41 env5310 = env5311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5310 == env5311) = true)

theorem identity5311 : scanCanonicalize (H12AffineFastState.compose env5311 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 2600) := by decide +kernel

theorem selectedBound5311 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env5312 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,2106,2600,2106,2593,2563,2107,2081,1025,2593,2106,4194304,4194352,35,2568,4194353,2049,2106,2106,2080,1025,1,4,1,4196378,4194848]

theorem envBound5312 : H12AffineFastState.Bounded env5312 := by
  intro p hp
  have h : env5312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5311_5312 : H12AffineEnvironment.transform 12 2600 env5311 = env5312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2600 env5311 == env5312) = true)

theorem identity5312 : scanCanonicalize (H12AffineFastState.compose env5312 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 1551) := by decide +kernel

theorem selectedBound5312 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env5313 : List Nat := [2,4,8,16,32,16,41,5,512,1024,1551,1589,1063,1589,1070,1036,1588,1582,1025,1070,1589,4194304,4194352,35,1031,4194353,1550,1589,1589,1583,1025,1,4,1,4195861,4194848]

theorem envBound5313 : H12AffineFastState.Bounded env5313 := by
  intro p hp
  have h : env5313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5312_5313 : H12AffineEnvironment.transform 10 1551 env5312 = env5313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1551 env5312 == env5313) = true)

theorem identity5313 : scanCanonicalize (H12AffineFastState.compose env5313 (packedSelected [2,11] rootPS)) = affineNative (2^(21+1) ^^^ 545) := by decide +kernel

theorem selectedBound5313 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env5314 : List Nat := [2,4,8,16,32,16,41,5,512,1024,1551,1589,1063,1589,1070,1036,1588,1582,1025,1070,1589,545,529,35,1031,528,1550,1589,1589,1583,1025,1,4,1,1076,1]

theorem envBound5314 : H12AffineFastState.Bounded env5314 := by
  intro p hp
  have h : env5314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5313_5314 : H12AffineEnvironment.transform 21 545 env5313 = env5314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 545 env5313 == env5314) = true)

theorem identity5314 : scanCanonicalize (H12AffineFastState.compose env5314 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound5314 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5315 : List Nat := [2,4,8,16,32,16,41,5,512,52,571,513,19,513,26,56,512,538,53,26,513,545,529,35,51,528,570,513,513,539,53,1,4,1,0,1]

theorem envBound5315 : H12AffineFastState.Bounded env5315 := by
  intro p hp
  have h : env5315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5314_5315 : H12AffineEnvironment.transform 9 52 env5314 = env5315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env5314 == env5315) = true)

def env5316 : List Nat := [2,4,8,16,32,16,41,5,0,52,59,1,19,1,26,56,0,26,53,26,1,33,17,35,51,16,58,1,1,27,53,1,4,1,0,1]

theorem envBound5316 : H12AffineFastState.Bounded env5316 := by
  intro p hp
  have h : env5316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5315_5316 : H12AffineEnvironment.transform 8 0 env5315 = env5316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env5315 == env5316) = true)

theorem identity5316 : scanCanonicalize (H12AffineFastState.compose env5316 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound5316 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5317 : List Nat := [2,4,7,16,32,16,38,5,0,52,52,1,19,1,21,55,0,21,53,21,1,33,17,35,51,16,53,1,1,20,53,1,4,1,0,1]

theorem envBound5317 : H12AffineFastState.Bounded env5317 := by
  intro p hp
  have h : env5317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5316_5317 : H12AffineEnvironment.transform 2 7 env5316 = env5317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env5316 == env5317) = true)

theorem identity5317 : scanCanonicalize (H12AffineFastState.compose env5317 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound5317 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5318 : List Nat := [2,4,7,5,32,5,38,5,0,33,33,1,6,1,0,34,0,0,32,0,1,33,4,35,38,5,32,1,1,1,32,1,4,1,0,1]

theorem envBound5318 : H12AffineFastState.Bounded env5318 := by
  intro p hp
  have h : env5318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5317_5318 : H12AffineEnvironment.transform 3 5 env5317 = env5318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env5317 == env5318) = true)

theorem identity5318 : scanCanonicalize (H12AffineFastState.compose env5318 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound5318 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env5319 : List Nat := [2,1,2,0,32,0,35,0,0,33,33,1,3,1,0,34,0,0,32,0,1,33,1,35,35,0,32,1,1,1,32,1,1,1,0,1]

theorem envBound5319 : H12AffineFastState.Bounded env5319 := by
  intro p hp
  have h : env5319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5318_5319 : H12AffineEnvironment.transform 1 1 env5318 = env5319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env5318 == env5319) = true)

def leafEnv5319 : List Nat := [2,1,2,0,32,0,35,0,0,33,33,1,3,1,0,34,0,0,32,0,1,33,1,35,33,35,1,0,32,1,1,1,32,1,1,1,0,2,0,1,1,0,0]

def active5319 : List Nat := [0,4]

def tree5319 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5319 : H12WitnessSearch.Good tree5319 := H12GlobalWitnessIndex.good

theorem leafIdentity5319 : H12AffineFastState.composeSystem env5319 rootObs = leafEnv5319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5319 rootObs == leafEnv5319) = true)

theorem terminalChecked5319 : H12PackedTerminal.terminalCheckFast leafEnv5319 active5319 tree5319 = true := by decide +kernel

def env5320 : List Nat := [2,4,8,16,32,16,41,5,1,52,58,0,19,0,26,56,1,27,53,26,0,32,16,35,51,17,59,0,0,26,53,1,4,1,0,1]

theorem envBound5320 : H12AffineFastState.Bounded env5320 := by
  intro p hp
  have h : env5320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5315_5320 : H12AffineEnvironment.transform 8 1 env5315 = env5320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env5315 == env5320) = true)

theorem identity5320 : scanCanonicalize (H12AffineFastState.compose env5320 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound5320 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5321 : List Nat := [2,4,8,16,27,16,18,5,1,15,1,0,19,0,26,3,1,27,14,26,0,27,16,24,8,17,0,0,0,26,14,1,4,1,0,1]

theorem envBound5321 : H12AffineFastState.Bounded env5321 := by
  intro p hp
  have h : env5321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5320_5321 : H12AffineEnvironment.transform 4 27 env5320 = env5321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env5320 == env5321) = true)

def env5322 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,4524,262144,1025,32768,4096,4194304,8388608,41002,8329,8388608,303232,4097,4524,2080,74794,12624188,257,1,4239488,8389565]

theorem envBound5322 : H12AffineFastState.Bounded env5322 := by
  intro p hp
  have h : env5322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5287_5322 : H12AffineEnvironment.transform 5 17 env5287 = env5322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5287 == env5322) = true)

theorem identity5322 : scanCanonicalize (H12AffineFastState.compose env5322 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound5322 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5323 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,4524,262144,1025,32768,4096,4194304,445,41002,8329,445,303232,4097,4524,2080,74794,4235393,257,1,4239488,512]

theorem envBound5323 : H12AffineFastState.Bounded env5323 := by
  intro p hp
  have h : env5323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5322_5323 : H12AffineEnvironment.transform 22 445 env5322 = env5323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env5322 == env5323) = true)

theorem identity5323 : scanCanonicalize (H12AffineFastState.compose env5323 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound5323 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5324 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,4524,262144,1025,32768,4096,41349,445,41002,8329,445,303232,4097,4524,2080,74794,260,257,1,4357,512]

theorem envBound5324 : H12AffineFastState.Bounded env5324 := by
  intro p hp
  have h : env5324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5323_5324 : H12AffineEnvironment.transform 21 41349 env5323 = env5324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env5323 == env5324) = true)

theorem identity5324 : scanCanonicalize (H12AffineFastState.compose env5324 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13973) := by decide +kernel

theorem selectedBound5324 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5325 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,13973,65536,4524,262144,1025,13973,4096,5904,445,5823,8329,445,267797,4097,4524,2080,74794,260,257,1,4357,512]

theorem envBound5325 : H12AffineFastState.Bounded env5325 := by
  intro p hp
  have h : env5325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5324_5325 : H12AffineEnvironment.transform 14 13973 env5324 = env5325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13973 env5324 == env5325) = true)

theorem identity5325 : scanCanonicalize (H12AffineFastState.compose env5325 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound5325 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5326 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,13973,8322,4524,262144,1025,13973,4096,5904,445,5823,8329,445,267797,4097,4524,2080,1192,260,257,1,4357,512]

theorem envBound5326 : H12AffineFastState.Bounded env5326 := by
  intro p hp
  have h : env5326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5325_5326 : H12AffineEnvironment.transform 15 8322 env5325 = env5326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env5325 == env5326) = true)

def env5327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4097,4194304,8388608,41002,8329,8914000,849104,16384,16892,547952,598059,12644668,525568,545873,4239489,8914925]

theorem envBound5327 : H12AffineFastState.Bounded env5327 := by
  intro p hp
  have h : env5327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5237_5327 : H12AffineEnvironment.transform 20 4097 env5237 = env5327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env5237 == env5327) = true)

def env5328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,4194304,8388608,41002,8329,8388688,323792,16384,16892,22640,74795,12644668,256,20561,4239489,8389613]

theorem envBound5328 : H12AffineFastState.Bounded env5328 := by
  intro p hp
  have h : env5328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5327_5328 : H12AffineEnvironment.transform 18 1024 env5327 = env5328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env5327 == env5328) = true)

theorem identity5328 : scanCanonicalize (H12AffineFastState.compose env5328 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 46529) := by decide +kernel

theorem selectedBound5328 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,46529,8388608,41002,8329,8388688,323792,16384,16892,22640,74795,8406269,256,20561,1344,8389613]

theorem envBound5329 : H12AffineFastState.Bounded env5329 := by
  intro p hp
  have h : env5329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5328_5329 : H12AffineEnvironment.transform 21 46529 env5328 = env5329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46529 env5328 == env5329) = true)

def env5330 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,46481,8388608,41002,8329,8388608,323712,16384,16812,22560,74795,8406189,256,20481,1296,8389565]

theorem envBound5330 : H12AffineFastState.Bounded env5330 := by
  intro p hp
  have h : env5330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5329_5330 : H12AffineEnvironment.transform 5 16 env5329 = env5330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5329 == env5330) = true)

def env5331 : List Nat := [2,4,8,16,32,16,128,188,512,1024,2048,4096,8192,16384,32768,65536,4113,262144,1024,32768,4097,46125,8388608,41002,8329,8388608,323712,16384,16400,22560,74795,8406189,188,20481,1196,8389121]

theorem envBound5331 : H12AffineFastState.Bounded env5331 := by
  intro p hp
  have h : env5331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5330_5331 : H12AffineEnvironment.transform 7 188 env5330 = env5331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env5330 == env5331) = true)

theorem identity5331 : scanCanonicalize (H12AffineFastState.compose env5331 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 53402) := by decide +kernel

theorem selectedBound5331 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5332 : List Nat := [2,4,8,16,32,16,128,188,512,1024,2048,4096,8192,16384,32768,53402,4113,262144,1024,32768,4097,46125,8388608,41002,8329,8388608,323712,16384,16400,22560,62641,8406189,188,20481,1196,8389121]

theorem envBound5332 : H12AffineFastState.Bounded env5332 := by
  intro p hp
  have h : env5332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5331_5332 : H12AffineEnvironment.transform 15 53402 env5331 = env5332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53402 env5331 == env5332) = true)

def env5333 : List Nat := [2,4,8,0,32,0,128,172,512,1024,2048,4096,8192,16384,32768,53386,4097,262144,1024,32768,4097,46125,8388608,41002,8329,8388608,323712,16384,16384,22560,62625,8406189,172,20481,1196,8389121]

theorem envBound5333 : H12AffineFastState.Bounded env5333 := by
  intro p hp
  have h : env5333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5332_5333 : H12AffineEnvironment.transform 3 0 env5332 = env5333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5332 == env5333) = true)

theorem identity5333 : scanCanonicalize (H12AffineFastState.compose env5333 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(22+1) ^^^ 5292) := by decide +kernel

theorem selectedBound5333 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env5334 : List Nat := [2,4,8,0,32,0,128,172,512,1024,2048,4096,8192,16384,32768,53386,4097,262144,1024,32768,4097,46125,5292,41002,8329,5292,323712,16384,16384,22560,62625,20481,172,20481,1196,5805]

theorem envBound5334 : H12AffineFastState.Bounded env5334 := by
  intro p hp
  have h : env5334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5333_5334 : H12AffineEnvironment.transform 22 5292 env5333 = env5334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5292 env5333 == env5334) = true)

theorem identity5334 : scanCanonicalize (H12AffineFastState.compose env5334 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5334 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5335 : List Nat := [2,4,8,0,32,0,41,5,512,1024,2048,4096,8192,16384,32768,53283,4097,262144,1024,32768,4097,46125,5125,41002,8224,5125,323625,16384,16384,22560,62472,20481,5,20481,1029,5636]

theorem envBound5335 : H12AffineFastState.Bounded env5335 := by
  intro p hp
  have h : env5335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5334_5335 : H12AffineEnvironment.transform 6 41 env5334 = env5335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5334 == env5335) = true)

theorem identity5335 : scanCanonicalize (H12AffineFastState.compose env5335 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound5335 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5336 : List Nat := [2,4,8,0,32,0,41,5,512,1024,2048,4096,8192,16384,8201,28714,4097,262144,1024,8201,4097,5156,5125,35,8224,5125,282656,16384,16384,22560,21505,20481,5,20481,1029,5636]

theorem envBound5336 : H12AffineFastState.Bounded env5336 := by
  intro p hp
  have h : env5336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5335_5336 : H12AffineEnvironment.transform 14 8201 env5335 = env5336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env5335 == env5336) = true)

theorem identity5336 : scanCanonicalize (H12AffineFastState.compose env5336 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 8713) := by decide +kernel

theorem selectedBound5336 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env5337 : List Nat := [2,4,8,0,32,0,41,5,512,1024,2048,4096,8192,16384,8201,28714,4097,8713,1024,8201,4097,5156,5125,35,8224,5125,29225,16384,16384,22560,21505,20481,5,20481,1029,5636]

theorem envBound5337 : H12AffineFastState.Bounded env5337 := by
  intro p hp
  have h : env5337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5336_5337 : H12AffineEnvironment.transform 17 8713 env5336 = env5337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8713 env5336 == env5337) = true)

theorem identity5337 : scanCanonicalize (H12AffineFastState.compose env5337 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 3599) := by decide +kernel

theorem selectedBound5337 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env5338 : List Nat := [2,4,8,0,32,0,41,5,512,1024,2048,4096,8192,3599,8201,15909,4097,8713,1024,8201,4097,5156,5125,35,8224,5125,15398,3599,3599,5679,6670,7694,5,7694,1029,5636]

theorem envBound5338 : H12AffineFastState.Bounded env5338 := by
  intro p hp
  have h : env5338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5337_5338 : H12AffineEnvironment.transform 13 3599 env5337 = env5338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3599 env5337 == env5338) = true)

theorem identity5338 : scanCanonicalize (H12AffineFastState.compose env5338 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound5338 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env5339 : List Nat := [2,4,8,0,32,0,41,5,512,1024,523,4096,8192,1028,8201,13358,4097,8713,1024,8201,4097,5156,5125,35,8224,5125,13869,1028,1028,5679,4101,5125,5,5125,1029,5636]

theorem envBound5339 : H12AffineFastState.Bounded env5339 := by
  intro p hp
  have h : env5339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5338_5339 : H12AffineEnvironment.transform 10 523 env5338 = env5339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env5338 == env5339) = true)

theorem identity5339 : scanCanonicalize (H12AffineFastState.compose env5339 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 559) := by decide +kernel

theorem selectedBound5339 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5340 : List Nat := [2,4,8,0,32,0,41,5,512,559,523,4096,8192,555,8201,12801,4097,8713,559,8201,4097,4619,4650,35,8224,4650,12290,555,555,4096,4101,4650,5,4650,554,4139]

theorem envBound5340 : H12AffineFastState.Bounded env5340 := by
  intro p hp
  have h : env5340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5339_5340 : H12AffineEnvironment.transform 9 559 env5339 = env5340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 559 env5339 == env5340) = true)

theorem identity5340 : scanCanonicalize (H12AffineFastState.compose env5340 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 4137) := by decide +kernel

theorem selectedBound5340 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5341 : List Nat := [2,4,8,0,32,0,41,5,512,559,523,4096,4137,555,4128,552,4097,4640,559,4128,4097,4619,4650,35,4105,4650,43,555,555,4096,4101,4650,5,4650,554,4139]

theorem envBound5341 : H12AffineFastState.Bounded env5341 := by
  intro p hp
  have h : env5341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5340_5341 : H12AffineEnvironment.transform 12 4137 env5340 = env5341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4137 env5340 == env5341) = true)

theorem identity5341 : scanCanonicalize (H12AffineFastState.compose env5341 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound5341 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env5342 : List Nat := [2,4,8,0,32,0,41,5,512,559,523,512,553,555,544,552,513,32,559,544,513,11,42,35,521,42,43,555,555,512,517,42,5,42,554,555]

theorem envBound5342 : H12AffineFastState.Bounded env5342 := by
  intro p hp
  have h : env5342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5341_5342 : H12AffineEnvironment.transform 11 512 env5341 = env5342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env5341 == env5342) = true)

def env5343 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,4096,8192,16384,32768,53387,4096,262144,1024,32768,4097,46125,8388608,41002,8329,8388608,323712,16384,16385,22560,62624,8406189,173,20481,1196,8389121]

theorem envBound5343 : H12AffineFastState.Bounded env5343 := by
  intro p hp
  have h : env5343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5332_5343 : H12AffineEnvironment.transform 3 1 env5332 = env5343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5332 == env5343) = true)

def env5344 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,4096,8192,16384,8352,28715,4096,262144,1024,8352,4097,5261,8388608,138,8329,8388608,282656,16384,16385,22560,21504,8406189,173,20481,1196,8389121]

theorem envBound5344 : H12AffineFastState.Bounded env5344 := by
  intro p hp
  have h : env5344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5343_5344 : H12AffineEnvironment.transform 14 8352 env5343 = env5344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env5343 == env5344) = true)

theorem identity5344 : scanCanonicalize (H12AffineFastState.compose env5344 (packedSelected [17,21] rootPS)) = affineNative (2^(22+1) ^^^ 284704) := by decide +kernel

theorem selectedBound5344 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env5345 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,4096,8192,16384,8352,28715,4096,262144,1024,8352,4097,5261,284704,138,8329,284704,282656,16384,16385,22560,21504,269453,173,20481,1196,285217]

theorem envBound5345 : H12AffineFastState.Bounded env5345 := by
  intro p hp
  have h : env5345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5344_5345 : H12AffineEnvironment.transform 22 284704 env5344 = env5345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 284704 env5344 == env5345) = true)

theorem identity5345 : scanCanonicalize (H12AffineFastState.compose env5345 (packedSelected [0,2,3,4,5,7,9,10,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 18977) := by decide +kernel

theorem selectedBound5345 : packedSelected [0,2,3,4,5,7,9,10,17,20] rootPS < 2^1333 := by decide +kernel

def env5346 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,4096,8192,16384,8352,28715,4096,18977,1024,8352,4097,5261,4609,138,8329,4609,6657,16384,16385,22560,21504,22188,173,20481,1196,4096]

theorem envBound5346 : H12AffineFastState.Bounded env5346 := by
  intro p hp
  have h : env5346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5345_5346 : H12AffineEnvironment.transform 17 18977 env5345 = env5346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 18977 env5345 == env5346) = true)

theorem identity5346 : scanCanonicalize (H12AffineFastState.compose env5346 (packedSelected [6,11,13,23] rootPS)) = affineNative (2^(13+1) ^^^ 15878) := by decide +kernel

theorem selectedBound5346 : packedSelected [6,11,13,23] rootPS < 2^1333 := by decide +kernel

def env5347 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,4096,8192,15878,8352,3629,4096,13351,1024,8352,4097,5261,4609,138,8329,4609,6657,15878,15879,9766,10758,10410,173,11783,1196,4096]

theorem envBound5347 : H12AffineFastState.Bounded env5347 := by
  intro p hp
  have h : env5347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5346_5347 : H12AffineEnvironment.transform 13 15878 env5346 = env5347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15878 env5346 == env5347) = true)

theorem identity5347 : scanCanonicalize (H12AffineFastState.compose env5347 (packedSelected [1,2,3,4,8,10,13,22,24] rootPS)) = affineNative (2^(12+1) ^^^ 7343) := by decide +kernel

theorem selectedBound5347 : packedSelected [1,2,3,4,8,10,13,22,24] rootPS < 2^1333 := by decide +kernel

def env5348 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,4096,7343,681,7183,3629,4096,2184,1024,7183,4097,5261,4609,138,7206,4609,6657,681,680,6793,5801,5125,173,4776,1196,4096]

theorem envBound5348 : H12AffineFastState.Bounded env5348 := by
  intro p hp
  have h : env5348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5347_5348 : H12AffineEnvironment.transform 12 7343 env5347 = env5348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7343 env5347 == env5348) = true)

theorem identity5348 : scanCanonicalize (H12AffineFastState.compose env5348 (packedSelected [3,4,5,6,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound5348 : packedSelected [3,4,5,6,9,10] rootPS < 2^1333 := by decide +kernel

def env5349 : List Nat := [2,4,8,1,32,1,128,173,512,37,2048,4096,6282,681,6186,2568,4096,2184,37,6186,4097,4264,4609,138,6147,4609,6657,681,680,6793,4748,4128,173,4776,137,4096]

theorem envBound5349 : H12AffineFastState.Bounded env5349 := by
  intro p hp
  have h : env5349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5348_5349 : H12AffineEnvironment.transform 9 37 env5348 = env5349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env5348 == env5349) = true)

theorem identity5349 : scanCanonicalize (H12AffineFastState.compose env5349 (packedSelected [1,3,4,5,6,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2603) := by decide +kernel

theorem selectedBound5349 : packedSelected [1,3,4,5,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env5350 : List Nat := [2,4,8,1,32,1,128,173,512,37,2048,2603,673,681,513,2568,2603,2184,37,513,2602,2691,2090,138,552,2090,42,681,680,162,2215,2571,173,2179,137,2603]

theorem envBound5350 : H12AffineFastState.Bounded env5350 := by
  intro p hp
  have h : env5350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5349_5350 : H12AffineEnvironment.transform 11 2603 env5349 = env5350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2603 env5349 == env5350) = true)

theorem identity5350 : scanCanonicalize (H12AffineFastState.compose env5350 (packedSelected [1,2,3,4,6,9] rootPS)) = affineNative (2^(10+1) ^^^ 643) := by decide +kernel

theorem selectedBound5350 : packedSelected [1,2,3,4,6,9] rootPS < 2^1333 := by decide +kernel

def env5351 : List Nat := [2,4,8,1,32,1,128,173,512,37,643,168,673,681,513,139,168,523,37,513,169,0,681,138,552,681,42,681,680,162,548,136,173,512,137,168]

theorem envBound5351 : H12AffineFastState.Bounded env5351 := by
  intro p hp
  have h : env5351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5350_5351 : H12AffineEnvironment.transform 10 643 env5350 = env5351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 643 env5350 == env5351) = true)

theorem identity5351 : scanCanonicalize (H12AffineFastState.compose env5351 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound5351 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env5352 : List Nat := [2,4,8,1,32,1,35,14,512,37,544,11,514,522,513,40,11,523,37,513,10,0,522,41,552,522,42,522,523,1,548,43,14,512,42,11]

theorem envBound5352 : H12AffineFastState.Bounded env5352 := by
  intro p hp
  have h : env5352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5351_5352 : H12AffineEnvironment.transform 6 35 env5351 = env5352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env5351 == env5352) = true)

theorem identity5352 : scanCanonicalize (H12AffineFastState.compose env5352 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound5352 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env5353 : List Nat := [2,4,8,1,0,1,3,14,512,5,512,11,514,522,513,8,11,523,5,513,10,0,522,9,520,522,10,522,523,1,516,11,14,512,10,11]

theorem envBound5353 : H12AffineFastState.Bounded env5353 := by
  intro p hp
  have h : env5353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5352_5353 : H12AffineEnvironment.transform 4 0 env5352 = env5353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env5352 == env5353) = true)

theorem identity5353 : scanCanonicalize (H12AffineFastState.compose env5353 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound5353 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env5354 : List Nat := [2,4,8,1,0,1,3,14,0,5,0,11,2,10,1,8,11,11,5,1,10,0,10,9,8,10,10,10,11,1,4,11,14,0,10,11]

theorem envBound5354 : H12AffineFastState.Bounded env5354 := by
  intro p hp
  have h : env5354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5353_5354 : H12AffineEnvironment.transform 8 0 env5353 = env5354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env5353 == env5354) = true)

def env5355 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,4096,8192,16384,8353,28714,4096,262144,1024,8353,4097,5260,8388608,139,8329,8388608,282657,16384,16385,22560,21505,8406189,173,20481,1196,8389121]

theorem envBound5355 : H12AffineFastState.Bounded env5355 := by
  intro p hp
  have h : env5355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5343_5355 : H12AffineEnvironment.transform 14 8353 env5343 = env5355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env5343 == env5355) = true)

theorem identity5355 : scanCanonicalize (H12AffineFastState.compose env5355 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 7204) := by decide +kernel

theorem selectedBound5355 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env5356 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,4096,8192,16384,8353,28714,4096,7204,1024,8353,4097,5260,8388608,139,8329,8388608,19461,16384,16385,22560,21505,8406189,173,20481,1196,8389121]

theorem envBound5356 : H12AffineFastState.Bounded env5356 := by
  intro p hp
  have h : env5356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5355_5356 : H12AffineEnvironment.transform 17 7204 env5355 = env5356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7204 env5355 == env5356) = true)

theorem identity5356 : scanCanonicalize (H12AffineFastState.compose env5356 (packedSelected [6,11,13,23] rootPS)) = affineNative (2^(22+1) ^^^ 6307) := by decide +kernel

theorem selectedBound5356 : packedSelected [6,11,13,23] rootPS < 2^1333 := by decide +kernel

def env5357 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,4096,8192,16384,8353,28714,4096,7204,1024,8353,4097,5260,6307,139,8329,6307,19461,16384,16385,22560,21505,23566,173,20481,1196,6818]

theorem envBound5357 : H12AffineFastState.Bounded env5357 := by
  intro p hp
  have h : env5357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5356_5357 : H12AffineEnvironment.transform 22 6307 env5356 = env5357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6307 env5356 == env5357) = true)

theorem identity5357 : scanCanonicalize (H12AffineFastState.compose env5357 (packedSelected [1,3,4,8,10,20,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 7815) := by decide +kernel

theorem selectedBound5357 : packedSelected [1,3,4,8,10,20,22,24] rootPS < 2^1333 := by decide +kernel

def env5358 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,4096,8192,7815,8353,11949,4096,7204,1024,8353,4097,5260,6307,139,8329,6307,4738,7815,7814,1703,2694,649,173,3718,1196,6818]

theorem envBound5358 : H12AffineFastState.Bounded env5358 := by
  intro p hp
  have h : env5358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5357_5358 : H12AffineEnvironment.transform 13 7815 env5357 = env5358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7815 env5357 == env5358) = true)

theorem identity5358 : scanCanonicalize (H12AffineFastState.compose env5358 (packedSelected [1,2,4,5,6,10,12,13,15,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 1197) := by decide +kernel

theorem selectedBound5358 : packedSelected [1,2,4,5,6,10,12,13,15,20,22] rootPS < 2^1333 := by decide +kernel

def env5359 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,1197,8192,2602,8353,11949,1197,2185,1024,8353,1196,33,3086,139,8329,3086,1583,2602,2603,1703,2694,649,173,3718,1196,3599]

theorem envBound5359 : H12AffineFastState.Bounded env5359 := by
  intro p hp
  have h : env5359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5358_5359 : H12AffineEnvironment.transform 11 1197 env5358 = env5359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1197 env5358 == env5359) = true)

theorem identity5359 : scanCanonicalize (H12AffineFastState.compose env5359 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 1190) := by decide +kernel

theorem selectedBound5359 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env5360 : List Nat := [2,4,8,1,32,1,128,173,512,1024,1190,1197,8192,1676,8353,8715,1197,1071,1024,8353,1196,33,168,139,8329,168,1583,1676,1677,1703,1568,649,173,544,1196,681]

theorem envBound5360 : H12AffineFastState.Bounded env5360 := by
  intro p hp
  have h : env5360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5359_5360 : H12AffineEnvironment.transform 10 1190 env5359 = env5360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1190 env5359 == env5360) = true)

theorem identity5360 : scanCanonicalize (H12AffineFastState.compose env5360 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound5360 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5361 : List Nat := [2,4,8,1,32,1,128,173,136,1024,1190,1197,8192,1028,8353,8323,1197,1071,1024,8353,1196,33,168,139,8329,168,1191,1028,1029,1071,1192,1,173,168,1196,33]

theorem envBound5361 : H12AffineFastState.Bounded env5361 := by
  intro p hp
  have h : env5361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5360_5361 : H12AffineEnvironment.transform 8 136 env5360 = env5361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env5360 == env5361) = true)

theorem identity5361 : scanCanonicalize (H12AffineFastState.compose env5361 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 1063) := by decide +kernel

theorem selectedBound5361 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env5362 : List Nat := [2,4,8,1,32,1,128,173,136,1024,1190,1197,1063,1028,1158,1188,1197,1071,1024,1158,1196,33,168,139,1198,168,1191,1028,1029,1071,1192,1,173,168,1196,33]

theorem envBound5362 : H12AffineFastState.Bounded env5362 := by
  intro p hp
  have h : env5362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5361_5362 : H12AffineEnvironment.transform 12 1063 env5361 = env5362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1063 env5361 == env5362) = true)

theorem identity5362 : scanCanonicalize (H12AffineFastState.compose env5362 (packedSelected [1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound5362 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env5363 : List Nat := [2,4,8,1,32,1,128,173,136,4,162,169,35,0,130,160,169,43,4,130,168,33,168,139,170,168,163,0,1,43,172,1,173,168,168,33]

theorem envBound5363 : H12AffineFastState.Bounded env5363 := by
  intro p hp
  have h : env5363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5362_5363 : H12AffineEnvironment.transform 9 4 env5362 = env5363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env5362 == env5363) = true)

theorem identity5363 : scanCanonicalize (H12AffineFastState.compose env5363 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound5363 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5364 : List Nat := [2,4,8,1,1,1,128,140,136,4,131,136,2,0,130,129,136,10,4,130,137,0,137,139,139,137,130,0,1,10,141,1,140,137,137,0]

theorem envBound5364 : H12AffineFastState.Bounded env5364 := by
  intro p hp
  have h : env5364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5363_5364 : H12AffineEnvironment.transform 4 1 env5363 = env5364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env5363 == env5364) = true)

theorem identity5364 : scanCanonicalize (H12AffineFastState.compose env5364 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound5364 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5365 : List Nat := [2,4,3,1,1,1,128,135,131,4,131,131,2,0,130,129,131,1,4,130,130,0,130,128,128,130,130,0,1,1,134,1,135,130,130,0]

theorem envBound5365 : H12AffineFastState.Bounded env5365 := by
  intro p hp
  have h : env5365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5364_5365 : H12AffineEnvironment.transform 2 3 env5364 = env5365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env5364 == env5365) = true)

theorem identity5365 : scanCanonicalize (H12AffineFastState.compose env5365 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound5365 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env5366 : List Nat := [2,4,3,1,1,1,3,4,0,4,0,0,2,0,1,2,0,1,4,1,1,0,1,3,3,1,1,0,1,1,5,1,4,1,1,0]

theorem envBound5366 : H12AffineFastState.Bounded env5366 := by
  intro p hp
  have h : env5366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5365_5366 : H12AffineEnvironment.transform 6 3 env5365 = env5366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env5365 == env5366) = true)

def env5367 : List Nat := [2,4,8,16,32,16,128,189,512,1024,2048,4096,8192,16384,32768,65536,4112,262144,1024,32768,4097,46124,8388608,41002,8329,8388608,323712,16384,16401,22560,74795,8406189,189,20481,1197,8389120]

theorem envBound5367 : H12AffineFastState.Bounded env5367 := by
  intro p hp
  have h : env5367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5330_5367 : H12AffineEnvironment.transform 7 189 env5330 = env5367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env5330 == env5367) = true)

theorem identity5367 : scanCanonicalize (H12AffineFastState.compose env5367 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(22+1) ^^^ 46108) := by decide +kernel

theorem selectedBound5367 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5368 : List Nat := [2,4,8,16,32,16,128,189,512,1024,2048,4096,8192,16384,32768,65536,4112,262144,1024,32768,4097,46124,46108,41002,8329,46108,323712,16384,16401,22560,74795,61617,189,20481,1197,46620]

theorem envBound5368 : H12AffineFastState.Bounded env5368 := by
  intro p hp
  have h : env5368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5367_5368 : H12AffineEnvironment.transform 22 46108 env5367 = env5368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 46108 env5367 == env5368) = true)

def env5369 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,4096,8192,16384,32768,65536,4096,262144,1024,32768,4097,46124,46092,41002,8329,46092,323712,16384,16385,22560,74795,61601,173,20481,1197,46604]

theorem envBound5369 : H12AffineFastState.Bounded env5369 := by
  intro p hp
  have h : env5369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5368_5369 : H12AffineEnvironment.transform 3 0 env5368 = env5369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5368 == env5369) = true)

theorem identity5369 : scanCanonicalize (H12AffineFastState.compose env5369 (packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound5369 : packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env5370 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,4096,8192,16384,32768,53283,4096,262144,1024,32768,4097,46124,46092,41002,8329,46092,323712,16384,16385,22560,62472,61601,173,20481,1197,46604]

theorem envBound5370 : H12AffineFastState.Bounded env5370 := by
  intro p hp
  have h : env5370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5369_5370 : H12AffineEnvironment.transform 15 53283 env5369 = env5370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env5369 == env5370) = true)

theorem identity5370 : scanCanonicalize (H12AffineFastState.compose env5370 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 63529) := by decide +kernel

theorem selectedBound5370 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env5371 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,4096,8192,16384,32768,53283,4096,63529,1024,32768,4097,46124,46092,41002,8329,46092,2217,16384,16385,22560,62472,61601,173,20481,1197,46604]

theorem envBound5371 : H12AffineFastState.Bounded env5371 := by
  intro p hp
  have h : env5371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5370_5371 : H12AffineEnvironment.transform 17 63529 env5370 = env5371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 63529 env5370 == env5371) = true)

theorem identity5371 : scanCanonicalize (H12AffineFastState.compose env5371 (packedSelected [0,3,5,7,10,18,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 29225) := by decide +kernel

theorem selectedBound5371 : packedSelected [0,3,5,7,10,18,20,23] rootPS < 2^1333 := by decide +kernel

def env5372 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,4096,8192,16384,29225,8714,4096,2560,1024,29225,4097,17925,17957,20995,8329,17957,2217,16384,16385,22560,1569,648,173,20481,1197,17445]

theorem envBound5372 : H12AffineFastState.Bounded env5372 := by
  intro p hp
  have h : env5372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5371_5372 : H12AffineEnvironment.transform 14 29225 env5371 = env5372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29225 env5371 == env5372) = true)

theorem identity5372 : scanCanonicalize (H12AffineFastState.compose env5372 (packedSelected [1,3,4,9,12,13,15,17,20] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound5372 : packedSelected [1,3,4,9,12,13,15,17,20] rootPS < 2^1333 := by decide +kernel

def env5373 : List Nat := [2,4,8,0,32,0,128,173,33,1024,2048,4096,8192,16384,28680,8235,4096,2081,1024,28680,4097,17444,17412,20514,8329,17412,2217,16384,16385,22560,1024,169,173,20481,1197,17445]

theorem envBound5373 : H12AffineFastState.Bounded env5373 := by
  intro p hp
  have h : env5373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5372_5373 : H12AffineEnvironment.transform 8 33 env5372 = env5373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env5372 == env5373) = true)

theorem identity5373 : scanCanonicalize (H12AffineFastState.compose env5373 (packedSelected [0,1,6,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 1191) := by decide +kernel

theorem selectedBound5373 : packedSelected [0,1,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env5374 : List Nat := [2,4,8,0,32,0,128,173,33,1024,1191,4096,8192,16384,28680,8235,4096,1158,1024,28680,4097,17444,17412,20514,8329,17412,1038,16384,16385,21639,1024,169,173,20481,1197,17445]

theorem envBound5374 : H12AffineFastState.Bounded env5374 := by
  intro p hp
  have h : env5374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5373_5374 : H12AffineEnvironment.transform 10 1191 env5373 = env5374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1191 env5373 == env5374) = true)

theorem identity5374 : scanCanonicalize (H12AffineFastState.compose env5374 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 4096) := by decide +kernel

theorem selectedBound5374 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env5375 : List Nat := [2,4,8,0,32,0,128,173,33,1024,1191,4096,8192,4096,8200,8235,4096,1158,1024,8200,4097,5156,5124,34,8329,5124,1038,4096,4097,1159,1024,169,173,1,1197,5157]

theorem envBound5375 : H12AffineFastState.Bounded env5375 := by
  intro p hp
  have h : env5375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5374_5375 : H12AffineEnvironment.transform 13 4096 env5374 = env5375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env5374 == env5375) = true)

def env5376 : List Nat := [2,4,8,1,32,1,128,172,512,1024,2048,4096,8192,16384,32768,65536,4097,262144,1024,32768,4097,46124,46093,41002,8329,46093,323712,16384,16384,22560,74795,61600,172,20481,1197,46605]

theorem envBound5376 : H12AffineFastState.Bounded env5376 := by
  intro p hp
  have h : env5376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5368_5376 : H12AffineEnvironment.transform 3 1 env5368 = env5376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5368 == env5376) = true)

theorem identity5376 : scanCanonicalize (H12AffineFastState.compose env5376 (packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound5376 : packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env5377 : List Nat := [2,4,8,1,32,1,128,172,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,1024,8201,4097,5157,5124,35,8329,5124,282761,16384,16384,22560,74795,20649,172,20481,1197,5636]

theorem envBound5377 : H12AffineFastState.Bounded env5377 := by
  intro p hp
  have h : env5377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5376_5377 : H12AffineEnvironment.transform 14 8201 env5376 = env5377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env5376 == env5377) = true)

theorem identity5377 : scanCanonicalize (H12AffineFastState.compose env5377 (packedSelected [0,3,5,7,9,10,13,20,21,22] rootPS)) = affineNative (2^(15+1) ^^^ 13446) := by decide +kernel

theorem selectedBound5377 : packedSelected [0,3,5,7,9,10,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env5378 : List Nat := [2,4,8,1,32,1,128,172,512,1024,2048,4096,8192,16384,8201,13446,4097,262144,1024,8201,4097,5157,5124,35,8329,5124,282761,16384,16384,22560,4269,20649,172,20481,1197,5636]

theorem envBound5378 : H12AffineFastState.Bounded env5378 := by
  intro p hp
  have h : env5378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5377_5378 : H12AffineEnvironment.transform 15 13446 env5377 = env5378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13446 env5377 == env5378) = true)

theorem identity5378 : scanCanonicalize (H12AffineFastState.compose env5378 (packedSelected [0,2,7,11,13,18,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 23208) := by decide +kernel

theorem selectedBound5378 : packedSelected [0,2,7,11,13,18,20,21] rootPS < 2^1333 := by decide +kernel

def env5379 : List Nat := [2,4,8,1,32,1,128,172,512,1024,2048,4096,8192,16384,8201,13446,4097,23208,1024,8201,4097,5157,5124,35,8329,5124,2593,16384,16384,22560,4269,20649,172,20481,1197,5636]

theorem envBound5379 : H12AffineFastState.Bounded env5379 := by
  intro p hp
  have h : env5379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5378_5379 : H12AffineEnvironment.transform 17 23208 env5378 = env5379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23208 env5378 == env5379) = true)

theorem identity5379 : scanCanonicalize (H12AffineFastState.compose env5379 (packedSelected [0,1,3,7,12,13,15,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 1028) := by decide +kernel

theorem selectedBound5379 : packedSelected [0,1,3,7,12,13,15,17,20] rootPS < 2^1333 := by decide +kernel

def env5380 : List Nat := [2,4,8,1,32,1,128,172,512,1024,2048,4096,8192,1028,8201,13446,4097,7852,1024,8201,4097,5157,5124,35,8329,5124,2593,1028,1028,7204,4269,5293,172,5125,1197,5636]

theorem envBound5380 : H12AffineFastState.Bounded env5380 := by
  intro p hp
  have h : env5380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5379_5380 : H12AffineEnvironment.transform 13 1028 env5379 = env5380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1028 env5379 == env5380) = true)

theorem identity5380 : scanCanonicalize (H12AffineFastState.compose env5380 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 3750) := by decide +kernel

theorem selectedBound5380 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5381 : List Nat := [2,4,8,1,32,1,128,172,512,1024,2048,3750,8192,1028,8201,10784,3751,10,1024,8201,3751,2691,2722,35,8329,2722,2593,1028,1028,642,3595,2571,172,2723,1197,2210]

theorem envBound5381 : H12AffineFastState.Bounded env5381 := by
  intro p hp
  have h : env5381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5380_5381 : H12AffineEnvironment.transform 11 3750 env5380 = env5381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3750 env5380 == env5381) = true)

theorem identity5381 : scanCanonicalize (H12AffineFastState.compose env5381 (packedSelected [12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 640) := by decide +kernel

theorem selectedBound5381 : packedSelected [12,13,15] rootPS < 2^1333 := by decide +kernel

def env5382 : List Nat := [2,4,8,1,32,1,128,172,512,1024,2048,3750,640,1028,649,2208,3751,10,1024,649,3751,2691,2722,35,521,2722,2593,1028,1028,642,3595,2571,172,2723,1197,2210]

theorem envBound5382 : H12AffineFastState.Bounded env5382 := by
  intro p hp
  have h : env5382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5381_5382 : H12AffineEnvironment.transform 12 640 env5381 = env5382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 640 env5381 == env5382) = true)

theorem identity5382 : scanCanonicalize (H12AffineFastState.compose env5382 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 1061) := by decide +kernel

theorem selectedBound5382 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5383 : List Nat := [2,4,8,1,32,1,128,172,512,1024,1061,643,640,1028,649,1157,642,10,1024,649,642,1702,1671,35,521,1671,1540,1028,1028,642,558,1582,172,1670,1197,1159]

theorem envBound5383 : H12AffineFastState.Bounded env5383 := by
  intro p hp
  have h : env5383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5382_5383 : H12AffineEnvironment.transform 10 1061 env5382 = env5383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1061 env5382 == env5383) = true)

theorem identity5383 : scanCanonicalize (H12AffineFastState.compose env5383 (packedSelected [0,1,3,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound5383 : packedSelected [0,1,3,7,11] rootPS < 2^1333 := by decide +kernel

def env5384 : List Nat := [2,4,8,1,32,1,40,4,512,1024,1061,555,552,1028,545,1069,554,10,1024,545,554,1550,1583,35,521,1583,1540,1028,1028,554,558,1582,4,1582,1029,1071]

theorem envBound5384 : H12AffineFastState.Bounded env5384 := by
  intro p hp
  have h : env5384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5383_5384 : H12AffineEnvironment.transform 6 40 env5383 = env5384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5383 == env5384) = true)

theorem identity5384 : scanCanonicalize (H12AffineFastState.compose env5384 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound5384 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5385 : List Nat := [2,4,8,1,32,1,40,4,512,15,42,555,552,11,545,34,554,10,15,545,554,513,544,35,521,544,523,11,11,554,558,545,4,545,10,32]

theorem envBound5385 : H12AffineFastState.Bounded env5385 := by
  intro p hp
  have h : env5385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5384_5385 : H12AffineEnvironment.transform 9 15 env5384 = env5385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env5384 == env5385) = true)

theorem identity5385 : scanCanonicalize (H12AffineFastState.compose env5385 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound5385 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env5386 : List Nat := [2,4,8,1,32,1,40,4,11,15,42,32,35,11,42,34,33,10,15,42,33,10,43,35,2,43,0,11,11,33,37,42,4,42,10,32]

theorem envBound5386 : H12AffineFastState.Bounded env5386 := by
  intro p hp
  have h : env5386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5385_5386 : H12AffineEnvironment.transform 8 11 env5385 = env5386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env5385 == env5386) = true)

theorem identity5386 : scanCanonicalize (H12AffineFastState.compose env5386 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound5386 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5387 : List Nat := [2,4,8,1,0,1,8,4,11,15,10,0,3,11,10,2,1,10,15,10,1,10,11,3,2,11,0,11,11,1,5,10,4,10,10,0]

theorem envBound5387 : H12AffineFastState.Bounded env5387 := by
  intro p hp
  have h : env5387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5386_5387 : H12AffineEnvironment.transform 4 0 env5386 = env5387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env5386 == env5387) = true)

theorem identity5387 : scanCanonicalize (H12AffineFastState.compose env5387 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound5387 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env5388 : List Nat := [2,4,2,1,0,1,2,4,1,5,0,0,3,1,0,2,1,0,5,0,1,0,1,3,2,1,0,1,1,1,5,0,4,0,0,0]

theorem envBound5388 : H12AffineFastState.Bounded env5388 := by
  intro p hp
  have h : env5388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5387_5388 : H12AffineEnvironment.transform 2 2 env5387 = env5388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env5387 == env5388) = true)

theorem identity5388 : scanCanonicalize (H12AffineFastState.compose env5388 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound5388 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5389 : List Nat := [2,0,2,1,0,1,2,0,1,1,0,0,3,1,0,2,1,0,1,0,1,0,1,3,2,1,0,1,1,1,1,0,0,0,0,0]

theorem envBound5389 : H12AffineFastState.Bounded env5389 := by
  intro p hp
  have h : env5389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5388_5389 : H12AffineEnvironment.transform 1 0 env5388 = env5389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env5388 == env5389) = true)

def env5390 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,46480,8388608,41002,8329,8388609,323713,16384,16813,22561,74795,8406188,256,20480,1297,8389564]

theorem envBound5390 : H12AffineFastState.Bounded env5390 := by
  intro p hp
  have h : env5390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5329_5390 : H12AffineEnvironment.transform 5 17 env5329 = env5390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5329 == env5390) = true)

theorem identity5390 : scanCanonicalize (H12AffineFastState.compose env5390 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound5390 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5391 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,46480,444,41002,8329,445,323713,16384,16813,22561,74795,17680,256,20480,1297,512]

theorem envBound5391 : H12AffineFastState.Bounded env5391 := by
  intro p hp
  have h : env5391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5390_5391 : H12AffineEnvironment.transform 22 444 env5390 = env5391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env5390 == env5391) = true)

theorem identity5391 : scanCanonicalize (H12AffineFastState.compose env5391 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound5391 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5392 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,32768,65536,1465,262144,1024,32768,1044,41349,444,41002,8329,445,320660,16384,16813,19508,74795,17680,256,17429,1297,512]

theorem envBound5392 : H12AffineFastState.Bounded env5392 := by
  intro p hp
  have h : env5392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5391_5392 : H12AffineEnvironment.transform 11 1045 env5391 = env5392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env5391 == env5392) = true)

theorem identity5392 : scanCanonicalize (H12AffineFastState.compose env5392 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26260) := by decide +kernel

theorem selectedBound5392 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5393 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,26260,65536,1465,262144,1024,26260,1044,18193,444,18110,8329,445,262656,16384,16813,19508,74795,17680,256,17429,1297,512]

theorem envBound5393 : H12AffineFastState.Bounded env5393 := by
  intro p hp
  have h : env5393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5392_5393 : H12AffineEnvironment.transform 14 26260 env5392 = env5393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26260 env5392 == env5393) = true)

theorem identity5393 : scanCanonicalize (H12AffineFastState.compose env5393 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 25750) := by decide +kernel

theorem selectedBound5393 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5394 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,26260,25750,1465,262144,1024,26260,1044,18193,444,18110,8329,445,262656,16384,16813,19508,16573,17680,256,17429,1297,512]

theorem envBound5394 : H12AffineFastState.Bounded env5394 := by
  intro p hp
  have h : env5394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5393_5394 : H12AffineEnvironment.transform 15 25750 env5393 = env5394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25750 env5393 == env5394) = true)

theorem identity5394 : scanCanonicalize (H12AffineFastState.compose env5394 (packedSelected [0,1,3,8,10,12,13,15,17,18,23,27,28] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound5394 : packedSelected [0,1,3,8,10,12,13,15,17,18,23,27,28] rootPS < 2^1333 := by decide +kernel

def env5395 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,1045,8192,16384,26172,25662,1297,262144,1024,26172,1044,18193,276,17942,8225,277,262656,16384,16645,19508,16405,17680,256,17429,1297,512]

theorem envBound5395 : H12AffineFastState.Bounded env5395 := by
  intro p hp
  have h : env5395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5394_5395 : H12AffineEnvironment.transform 6 40 env5394 = env5395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5394 == env5395) = true)

def env5396 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,4194304,8388608,41002,8329,8388689,323793,16384,16892,22641,74794,12644668,257,20560,4239489,8389612]

theorem envBound5396 : H12AffineFastState.Bounded env5396 := by
  intro p hp
  have h : env5396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5327_5396 : H12AffineEnvironment.transform 18 1025 env5327 = env5396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env5327 == env5396) = true)

theorem identity5396 : scanCanonicalize (H12AffineFastState.compose env5396 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4255936) := by decide +kernel

theorem selectedBound5396 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5397 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,4194304,4255936,41002,8329,4255889,323793,16384,16892,22641,74794,508,257,20560,4239489,4256556]

theorem envBound5397 : H12AffineFastState.Bounded env5397 := by
  intro p hp
  have h : env5397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5396_5397 : H12AffineEnvironment.transform 22 4255936 env5396 = env5397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4255936 env5396 == env5397) = true)

def env5398 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,4194304,4255888,41002,8329,4255889,323713,16384,16812,22561,74794,428,257,20480,4239489,4256556]

theorem envBound5398 : H12AffineFastState.Bounded env5398 := by
  intro p hp
  have h : env5398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5397_5398 : H12AffineEnvironment.transform 5 16 env5397 = env5398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5397 == env5398) = true)

theorem identity5398 : scanCanonicalize (H12AffineFastState.compose env5398 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 61740) := by decide +kernel

theorem selectedBound5398 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5399 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,61740,444,41002,8329,445,323713,16384,16812,22561,74794,428,257,20480,16813,512]

theorem envBound5399 : H12AffineFastState.Bounded env5399 := by
  intro p hp
  have h : env5399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5398_5399 : H12AffineEnvironment.transform 21 61740 env5398 = env5399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 61740 env5398 == env5399) = true)

theorem identity5399 : scanCanonicalize (H12AffineFastState.compose env5399 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4264) := by decide +kernel

theorem selectedBound5399 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5400 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,32768,65536,4525,262144,1025,32768,4097,41348,444,41002,8329,445,303145,4264,4356,2185,74794,428,257,168,4357,512]

theorem envBound5400 : H12AffineFastState.Bounded env5400 := by
  intro p hp
  have h : env5400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5399_5400 : H12AffineEnvironment.transform 13 4264 env5399 = env5400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4264 env5399 == env5400) = true)

theorem identity5400 : scanCanonicalize (H12AffineFastState.compose env5400 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13885) := by decide +kernel

theorem selectedBound5400 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5401 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,13885,65536,4525,262144,1025,13885,4097,6073,444,5655,8329,445,267796,4264,4356,2185,74794,428,257,168,4357,512]

theorem envBound5401 : H12AffineFastState.Bounded env5401 := by
  intro p hp
  have h : env5401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5400_5401 : H12AffineEnvironment.transform 14 13885 env5400 = env5401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13885 env5400 == env5401) = true)

theorem identity5401 : scanCanonicalize (H12AffineFastState.compose env5401 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound5401 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5402 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,13885,8235,4525,262144,1025,13885,4097,6073,444,5655,8329,445,267796,4264,4356,2185,1025,428,257,168,4357,512]

theorem envBound5402 : H12AffineFastState.Bounded env5402 := by
  intro p hp
  have h : env5402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5401_5402 : H12AffineEnvironment.transform 15 8235 env5401 = env5402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env5401 == env5402) = true)

theorem identity5402 : scanCanonicalize (H12AffineFastState.compose env5402 (packedSelected [0,1,5,8,18,23,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound5402 : packedSelected [0,1,5,8,18,23,24,27] rootPS < 2^1333 := by decide +kernel

def env5403 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,13885,8235,4525,2080,1025,13885,4097,6073,444,5655,8329,445,7732,4264,4356,2185,1025,428,257,168,4357,512]

theorem envBound5403 : H12AffineFastState.Bounded env5403 := by
  intro p hp
  have h : env5403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5402_5403 : H12AffineEnvironment.transform 17 2080 env5402 = env5403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env5402 == env5403) = true)

theorem identity5403 : scanCanonicalize (H12AffineFastState.compose env5403 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 1803) := by decide +kernel

theorem selectedBound5403 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env5404 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1803,8192,1955,8502,8235,1702,2080,1025,8502,1802,178,444,284,8329,445,2367,1955,1551,2185,1025,428,257,168,1550,512]

theorem envBound5404 : H12AffineFastState.Bounded env5404 := by
  intro p hp
  have h : env5404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5403_5404 : H12AffineEnvironment.transform 11 1803 env5403 = env5404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1803 env5403 == env5404) = true)

theorem identity5404 : scanCanonicalize (H12AffineFastState.compose env5404 (packedSelected [0,4,7,9,13,17,18,23] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5404 : packedSelected [0,4,7,9,13,17,18,23] rootPS < 2^1333 := by decide +kernel

def env5405 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1803,8192,1802,8502,8235,1551,2080,1025,8502,1802,27,277,284,8224,276,2367,1802,1551,2080,1025,261,257,1,1550,512]

theorem envBound5405 : H12AffineFastState.Bounded env5405 := by
  intro p hp
  have h : env5405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5404_5405 : H12AffineEnvironment.transform 6 41 env5404 = env5405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5404 == env5405) = true)

theorem identity5405 : scanCanonicalize (H12AffineFastState.compose env5405 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound5405 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5406 : List Nat := [2,4,8,16,32,16,41,62,512,1024,2048,1589,8192,1588,8200,8235,1551,2080,1025,8200,1588,27,43,34,8224,42,2049,1588,1551,2080,1025,59,63,1,1550,512]

theorem envBound5406 : H12AffineFastState.Bounded env5406 := by
  intro p hp
  have h : env5406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5405_5406 : H12AffineEnvironment.transform 7 62 env5405 = env5406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env5405 == env5406) = true)

theorem identity5406 : scanCanonicalize (H12AffineFastState.compose env5406 (packedSelected [0,1,2,4,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 51) := by decide +kernel

theorem selectedBound5406 : packedSelected [0,1,2,4,5,6] rootPS < 2^1333 := by decide +kernel

def env5407 : List Nat := [2,4,8,16,32,16,41,62,512,1024,2048,1589,51,1588,59,24,1551,2080,1025,59,1588,27,43,34,19,42,2049,1588,1551,2080,1025,59,63,1,1550,512]

theorem envBound5407 : H12AffineFastState.Bounded env5407 := by
  intro p hp
  have h : env5407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5406_5407 : H12AffineEnvironment.transform 12 51 env5406 = env5407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 51 env5406 == env5407) = true)

theorem identity5407 : scanCanonicalize (H12AffineFastState.compose env5407 (packedSelected [4,7] rootPS)) = affineNative (2^(10+1) ^^^ 570) := by decide +kernel

theorem selectedBound5407 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env5408 : List Nat := [2,4,8,16,32,16,41,62,512,1024,570,1589,51,1588,59,24,1551,538,1025,59,1588,27,43,34,19,42,571,1588,1551,538,1025,59,63,1,1550,512]

theorem envBound5408 : H12AffineFastState.Bounded env5408 := by
  intro p hp
  have h : env5408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5407_5408 : H12AffineEnvironment.transform 10 570 env5407 = env5408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 570 env5407 == env5408) = true)

theorem identity5408 : scanCanonicalize (H12AffineFastState.compose env5408 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound5408 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env5409 : List Nat := [2,4,8,16,27,16,18,5,512,1024,513,1550,8,1551,0,24,1551,538,1025,0,1551,27,16,25,19,17,512,1551,1551,538,1025,0,4,1,1550,512]

theorem envBound5409 : H12AffineFastState.Bounded env5409 := by
  intro p hp
  have h : env5409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5408_5409 : H12AffineEnvironment.transform 4 27 env5408 = env5409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env5408 == env5409) = true)

theorem identity5409 : scanCanonicalize (H12AffineFastState.compose env5409 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound5409 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env5410 : List Nat := [2,4,2,16,17,16,18,5,512,1024,513,1540,2,1541,0,18,1541,528,1025,0,1541,17,16,19,19,17,512,1541,1541,528,1025,0,4,1,1540,512]

theorem envBound5410 : H12AffineFastState.Bounded env5410 := by
  intro p hp
  have h : env5410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5409_5410 : H12AffineEnvironment.transform 2 2 env5409 = env5410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env5409 == env5410) = true)

theorem identity5410 : scanCanonicalize (H12AffineFastState.compose env5410 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound5410 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env5411 : List Nat := [2,4,2,0,1,0,2,5,512,1024,513,1540,2,1541,0,2,1541,512,1025,0,1541,1,0,3,3,1,512,1541,1541,512,1025,0,4,1,1540,512]

theorem envBound5411 : H12AffineFastState.Bounded env5411 := by
  intro p hp
  have h : env5411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5410_5411 : H12AffineEnvironment.transform 3 0 env5410 = env5411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5410 == env5411) = true)

theorem identity5411 : scanCanonicalize (H12AffineFastState.compose env5411 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound5411 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5412 : List Nat := [2,4,2,0,1,0,2,5,1,1024,0,1029,2,1028,0,2,1028,1,1025,0,1028,1,0,3,3,1,1,1028,1028,1,1025,0,4,1,1029,1]

theorem envBound5412 : H12AffineFastState.Bounded env5412 := by
  intro p hp
  have h : env5412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5411_5412 : H12AffineEnvironment.transform 8 1 env5411 = env5412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env5411 == env5412) = true)

def leafEnv5412 : List Nat := [2,4,2,0,1,0,2,5,1,1024,0,1029,2,1028,0,2,1028,1,1025,0,1028,1,0,3,1024,3,1,1,1,1028,1028,1,1025,0,4,1,5,2,1029,1,1,1028,0]

def active5412 : List Nat := [0,1,9]

def tree5412 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5412 : H12WitnessSearch.Good tree5412 := H12GlobalWitnessIndex.good

theorem leafIdentity5412 : H12AffineFastState.composeSystem env5412 rootObs = leafEnv5412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5412 rootObs == leafEnv5412) = true)

theorem terminalChecked5412 : H12PackedTerminal.terminalCheckFast leafEnv5412 active5412 tree5412 = true := by decide +kernel

def env5413 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,4194304,4255889,41002,8329,4255889,323712,16384,16813,22560,74794,429,257,20481,4239489,4256556]

theorem envBound5413 : H12AffineFastState.Bounded env5413 := by
  intro p hp
  have h : env5413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5397_5413 : H12AffineEnvironment.transform 5 17 env5397 = env5413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5397 == env5413) = true)

def env5414 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,16384,32768,65536,4112,262144,1025,32768,4097,4194304,4255889,41002,8329,4255889,323712,16384,16401,22560,74794,17,189,20481,4239489,4256400]

theorem envBound5414 : H12AffineFastState.Bounded env5414 := by
  intro p hp
  have h : env5414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5413_5414 : H12AffineEnvironment.transform 7 188 env5413 = env5414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env5413 == env5414) = true)

theorem identity5414 : scanCanonicalize (H12AffineFastState.compose env5414 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 53402) := by decide +kernel

theorem selectedBound5414 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5415 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,16384,32768,53402,4112,262144,1025,32768,4097,4194304,4255889,41002,8329,4255889,323712,16384,16401,22560,62640,17,189,20481,4239489,4256400]

theorem envBound5415 : H12AffineFastState.Bounded env5415 := by
  intro p hp
  have h : env5415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5414_5415 : H12AffineEnvironment.transform 15 53402 env5414 = env5415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53402 env5414 == env5415) = true)

def env5416 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,4096,32768,32922,4112,262144,1025,32768,4097,4194304,4235409,41002,8329,4235409,303232,4096,4113,2080,42160,17,189,1,4239489,4235920]

theorem envBound5416 : H12AffineFastState.Bounded env5416 := by
  intro p hp
  have h : env5416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5415_5416 : H12AffineEnvironment.transform 13 4096 env5415 = env5416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env5415 == env5416) = true)

theorem identity5416 : scanCanonicalize (H12AffineFastState.compose env5416 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound5416 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env5417 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,4096,32768,32906,4096,262144,1025,32768,4097,4194304,4235393,41002,8329,4235393,303232,4096,4097,2080,42144,1,173,1,4239489,4235904]

theorem envBound5417 : H12AffineFastState.Bounded env5417 := by
  intro p hp
  have h : env5417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5416_5417 : H12AffineEnvironment.transform 3 0 env5416 = env5417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5416 == env5417) = true)

theorem identity5417 : scanCanonicalize (H12AffineFastState.compose env5417 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(21+1) ^^^ 305312) := by decide +kernel

theorem selectedBound5417 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env5418 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,4096,32768,32906,4096,262144,1025,32768,4097,305312,264225,41002,8329,264225,303232,4096,4097,2080,42144,1,173,1,268321,264736]

theorem envBound5418 : H12AffineFastState.Bounded env5418 := by
  intro p hp
  have h : env5418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5417_5418 : H12AffineEnvironment.transform 21 305312 env5417 = env5418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 305312 env5417 == env5418) = true)

theorem identity5418 : scanCanonicalize (H12AffineFastState.compose env5418 (packedSelected [4,9,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound5418 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env5419 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,4096,32768,32906,4096,2185,1025,32768,4097,41001,168,41002,8329,168,43017,4096,4097,2080,42144,1,173,1,4264,681]

theorem envBound5419 : H12AffineFastState.Bounded env5419 := by
  intro p hp
  have h : env5419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5418_5419 : H12AffineEnvironment.transform 17 2185 env5418 = env5419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env5418 == env5419) = true)

theorem identity5419 : scanCanonicalize (H12AffineFastState.compose env5419 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 13868) := by decide +kernel

theorem selectedBound5419 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env5420 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,4096,13868,13990,4096,2185,1025,13868,4097,5637,168,5638,8329,168,7717,4096,4097,2080,4748,1,173,1,4264,681]

theorem envBound5420 : H12AffineFastState.Bounded env5420 := by
  intro p hp
  have h : env5420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5419_5420 : H12AffineEnvironment.transform 14 13868 env5419 = env5420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13868 env5419 == env5420) = true)

theorem identity5420 : scanCanonicalize (H12AffineFastState.compose env5420 (packedSelected [1,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 1548) := by decide +kernel

theorem selectedBound5420 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env5421 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,1548,4096,4128,4266,4096,2185,1025,4128,4097,5637,168,5638,1669,168,7717,4096,4097,2080,4748,1,173,1,4264,681]

theorem envBound5421 : H12AffineFastState.Bounded env5421 := by
  intro p hp
  have h : env5421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5420_5421 : H12AffineEnvironment.transform 12 1548 env5420 = env5421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1548 env5420 == env5421) = true)

theorem identity5421 : scanCanonicalize (H12AffineFastState.compose env5421 (packedSelected [4,6,7,12] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound5421 : packedSelected [4,6,7,12] rootPS < 2^1333 := by decide +kernel

def env5422 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,513,1548,513,545,683,513,2185,1025,545,512,1028,168,1031,1669,168,3108,513,512,2080,141,1,173,1,681,681]

theorem envBound5422 : H12AffineFastState.Bounded env5422 := by
  intro p hp
  have h : env5422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5421_5422 : H12AffineEnvironment.transform 11 513 env5421 = env5422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env5421 == env5422) = true)

theorem identity5422 : scanCanonicalize (H12AffineFastState.compose env5422 (packedSelected [5,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound5422 : packedSelected [5,8,11] rootPS < 2^1333 := by decide +kernel

def env5423 : List Nat := [2,4,8,0,32,1,128,172,512,37,2048,513,553,513,545,683,513,2185,36,545,512,33,168,34,672,168,2049,513,512,2080,141,1,173,1,681,681]

theorem envBound5423 : H12AffineFastState.Bounded env5423 := by
  intro p hp
  have h : env5423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5422_5423 : H12AffineEnvironment.transform 9 37 env5422 = env5423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env5422 == env5423) = true)

theorem identity5423 : scanCanonicalize (H12AffineFastState.compose env5423 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound5423 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env5424 : List Nat := [2,4,8,0,32,1,128,172,163,37,2048,162,138,162,130,8,162,2185,36,130,163,33,168,34,3,168,2049,162,163,2080,141,1,173,1,10,10]

theorem envBound5424 : H12AffineFastState.Bounded env5424 := by
  intro p hp
  have h : env5424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5423_5424 : H12AffineEnvironment.transform 8 163 env5423 = env5424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env5423 == env5424) = true)

theorem identity5424 : scanCanonicalize (H12AffineFastState.compose env5424 (packedSelected [0,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound5424 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env5425 : List Nat := [2,4,8,0,32,1,128,172,163,37,43,162,138,162,130,8,162,162,36,130,163,33,168,34,3,168,42,162,163,11,141,1,173,1,10,10]

theorem envBound5425 : H12AffineFastState.Bounded env5425 := by
  intro p hp
  have h : env5425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5424_5425 : H12AffineEnvironment.transform 10 43 env5424 = env5425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env5424 == env5425) = true)

theorem identity5425 : scanCanonicalize (H12AffineFastState.compose env5425 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound5425 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env5426 : List Nat := [2,4,8,0,32,1,2,46,33,37,43,32,8,32,0,8,32,32,36,0,33,33,42,34,3,42,42,32,33,11,15,1,47,1,10,10]

theorem envBound5426 : H12AffineFastState.Bounded env5426 := by
  intro p hp
  have h : env5426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5425_5426 : H12AffineEnvironment.transform 6 2 env5425 = env5426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env5425 == env5426) = true)

theorem identity5426 : scanCanonicalize (H12AffineFastState.compose env5426 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound5426 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5427 : List Nat := [2,4,3,0,32,1,2,37,33,37,32,32,3,32,0,3,32,32,36,0,33,33,33,34,3,33,33,32,33,0,4,1,36,1,1,1]

theorem envBound5427 : H12AffineFastState.Bounded env5427 := by
  intro p hp
  have h : env5427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5426_5427 : H12AffineEnvironment.transform 2 3 env5426 = env5427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env5426 == env5427) = true)

theorem identity5427 : scanCanonicalize (H12AffineFastState.compose env5427 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound5427 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env5428 : List Nat := [2,4,3,0,1,1,2,4,0,4,1,1,3,1,0,3,1,1,5,0,0,0,0,3,3,0,0,1,0,0,4,1,5,1,1,1]

theorem envBound5428 : H12AffineFastState.Bounded env5428 := by
  intro p hp
  have h : env5428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5427_5428 : H12AffineEnvironment.transform 4 1 env5427 = env5428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env5427 == env5428) = true)

theorem identity5428 : scanCanonicalize (H12AffineFastState.compose env5428 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound5428 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5429 : List Nat := [2,1,3,0,1,1,2,1,0,1,1,1,3,1,0,3,1,1,0,0,0,0,0,3,3,0,0,1,0,0,1,1,0,1,1,1]

theorem envBound5429 : H12AffineFastState.Bounded env5429 := by
  intro p hp
  have h : env5429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5428_5429 : H12AffineEnvironment.transform 1 1 env5428 = env5429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env5428 == env5429) = true)

def env5430 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,4097,32768,32923,4112,262144,1025,32768,4097,4194304,4235408,41002,8329,4235408,303233,4097,4112,2081,42161,17,189,0,4239489,4235921]

theorem envBound5430 : H12AffineFastState.Bounded env5430 := by
  intro p hp
  have h : env5430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5415_5430 : H12AffineEnvironment.transform 13 4097 env5415 = env5430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env5415 == env5430) = true)

theorem identity5430 : scanCanonicalize (H12AffineFastState.compose env5430 (packedSelected [0,3,5,9,10,22,27] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound5430 : packedSelected [0,3,5,9,10,22,27] rootPS < 2^1333 := by decide +kernel

def env5431 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,4097,32768,32907,4096,262144,1025,32768,4097,4194304,4235392,41002,8329,4235392,303233,4097,4096,2081,42145,1,173,0,4239489,4235905]

theorem envBound5431 : H12AffineFastState.Bounded env5431 := by
  intro p hp
  have h : env5431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5430_5431 : H12AffineEnvironment.transform 3 0 env5430 = env5431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5430 == env5431) = true)

theorem identity5431 : scanCanonicalize (H12AffineFastState.compose env5431 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 43137) := by decide +kernel

theorem selectedBound5431 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env5432 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,4097,32768,32907,4096,43137,1025,32768,4097,4194304,4235392,41002,8329,4235392,2048,4097,4096,2081,42145,1,173,0,4239489,4235905]

theorem envBound5432 : H12AffineFastState.Bounded env5432 := by
  intro p hp
  have h : env5432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5431_5432 : H12AffineEnvironment.transform 17 43137 env5431 = env5432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43137 env5431 == env5432) = true)

theorem identity5432 : scanCanonicalize (H12AffineFastState.compose env5432 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5432 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env5433 : List Nat := [2,4,8,0,32,1,41,5,512,1024,2048,4096,8192,4097,32768,32802,4096,43048,1025,32768,4097,4194304,4235305,41002,8224,4235305,2048,4097,4096,2081,41992,1,4,0,4239400,4235816]

theorem envBound5433 : H12AffineFastState.Bounded env5433 := by
  intro p hp
  have h : env5433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5432_5433 : H12AffineEnvironment.transform 6 41 env5432 = env5433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5432 == env5433) = true)

theorem identity5433 : scanCanonicalize (H12AffineFastState.compose env5433 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(21+1) ^^^ 46605) := by decide +kernel

theorem selectedBound5433 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env5434 : List Nat := [2,4,8,0,32,1,41,5,512,1024,2048,4096,8192,4097,32768,32802,4096,43048,1025,32768,4097,46605,5668,41002,8224,5668,2048,4097,4096,2081,41992,1,4,0,1573,5157]

theorem envBound5434 : H12AffineFastState.Bounded env5434 := by
  intro p hp
  have h : env5434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5433_5434 : H12AffineEnvironment.transform 21 46605 env5433 = env5434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46605 env5433 == env5434) = true)

theorem identity5434 : scanCanonicalize (H12AffineFastState.compose env5434 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 13837) := by decide +kernel

theorem selectedBound5434 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env5435 : List Nat := [2,4,8,0,32,1,41,5,512,1024,2048,4096,8192,4097,13837,13871,4096,7717,1025,13837,4097,0,5668,5671,8224,5668,2048,4097,4096,2081,4613,1,4,0,1573,5157]

theorem envBound5435 : H12AffineFastState.Bounded env5435 := by
  intro p hp
  have h : env5435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5434_5435 : H12AffineEnvironment.transform 14 13837 env5434 = env5435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13837 env5434 == env5435) = true)

theorem identity5435 : scanCanonicalize (H12AffineFastState.compose env5435 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 1030) := by decide +kernel

theorem selectedBound5435 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env5436 : List Nat := [2,4,8,0,32,1,41,5,512,1024,2048,4096,1030,4097,4619,4649,4096,7717,1025,4619,4097,0,5668,5671,1062,5668,2048,4097,4096,2081,4613,1,4,0,1573,5157]

theorem envBound5436 : H12AffineFastState.Bounded env5436 := by
  intro p hp
  have h : env5436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5435_5436 : H12AffineEnvironment.transform 12 1030 env5435 = env5436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1030 env5435 == env5436) = true)

theorem identity5436 : scanCanonicalize (H12AffineFastState.compose env5436 (packedSelected [1,3,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound5436 : packedSelected [1,3,11,12] rootPS < 2^1333 := by decide +kernel

def env5437 : List Nat := [2,4,8,0,32,1,41,5,512,1024,1541,4096,1030,4097,4619,4649,4096,4128,1025,4619,4097,0,5668,5671,1062,5668,1541,4097,4096,1572,4613,1,4,0,1573,5157]

theorem envBound5437 : H12AffineFastState.Bounded env5437 := by
  intro p hp
  have h : env5437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5436_5437 : H12AffineEnvironment.transform 10 1541 env5436 = env5437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env5436 == env5437) = true)

theorem identity5437 : scanCanonicalize (H12AffineFastState.compose env5437 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1583) := by decide +kernel

theorem selectedBound5437 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env5438 : List Nat := [2,4,8,0,32,1,41,5,512,1024,1541,1583,1030,1582,1060,1030,1583,1551,1025,1060,1582,0,11,8,1062,11,1541,1582,1583,1572,1066,1,4,0,1573,522]

theorem envBound5438 : H12AffineFastState.Bounded env5438 := by
  intro p hp
  have h : env5438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5437_5438 : H12AffineEnvironment.transform 11 1583 env5437 = env5438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1583 env5437 == env5438) = true)

theorem identity5438 : scanCanonicalize (H12AffineFastState.compose env5438 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound5438 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env5439 : List Nat := [2,4,2,0,32,1,35,5,512,1024,1541,1573,1030,1572,1060,1030,1573,1541,1025,1060,1572,0,1,2,1062,1,1541,1572,1573,1572,1056,1,4,0,1573,512]

theorem envBound5439 : H12AffineFastState.Bounded env5439 := by
  intro p hp
  have h : env5439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5438_5439 : H12AffineEnvironment.transform 2 2 env5438 = env5439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env5438 == env5439) = true)

theorem identity5439 : scanCanonicalize (H12AffineFastState.compose env5439 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound5439 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5440 : List Nat := [2,4,2,0,1,1,2,5,512,1024,1541,1540,1030,1541,1029,1030,1540,1541,1025,1029,1541,0,1,2,1031,1,1541,1541,1540,1541,1025,1,4,0,1540,512]

theorem envBound5440 : H12AffineFastState.Bounded env5440 := by
  intro p hp
  have h : env5440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5439_5440 : H12AffineEnvironment.transform 4 1 env5439 = env5440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env5439 == env5440) = true)

theorem identity5440 : scanCanonicalize (H12AffineFastState.compose env5440 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound5440 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5441 : List Nat := [2,4,2,0,1,1,2,5,512,4,513,512,2,513,1,2,512,513,5,1,513,0,1,2,3,1,513,513,512,513,5,1,4,0,512,512]

theorem envBound5441 : H12AffineFastState.Bounded env5441 := by
  intro p hp
  have h : env5441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5440_5441 : H12AffineEnvironment.transform 9 4 env5440 = env5441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env5440 == env5441) = true)

theorem identity5441 : scanCanonicalize (H12AffineFastState.compose env5441 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound5441 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5442 : List Nat := [2,4,2,0,1,1,2,5,1,4,0,1,2,0,1,2,1,0,5,1,0,0,1,2,3,1,0,0,1,0,5,1,4,0,1,1]

theorem envBound5442 : H12AffineFastState.Bounded env5442 := by
  intro p hp
  have h : env5442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5441_5442 : H12AffineEnvironment.transform 8 1 env5441 = env5442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env5441 == env5442) = true)

def env5443 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,16384,32768,65536,4113,262144,1025,32768,4097,4194304,4255889,41002,8329,4255889,323712,16384,16400,22560,74794,16,188,20481,4239489,4256401]

theorem envBound5443 : H12AffineFastState.Bounded env5443 := by
  intro p hp
  have h : env5443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5413_5443 : H12AffineEnvironment.transform 7 189 env5413 = env5443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env5413 == env5443) = true)

theorem identity5443 : scanCanonicalize (H12AffineFastState.compose env5443 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 28833) := by decide +kernel

theorem selectedBound5443 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5444 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,16384,28833,65536,4113,262144,1025,28833,4097,4194304,4194352,20619,8329,4194352,262177,16384,16400,22560,74794,16,188,20481,4210720,4194864]

theorem envBound5444 : H12AffineFastState.Bounded env5444 := by
  intro p hp
  have h : env5444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5443_5444 : H12AffineEnvironment.transform 14 28833 env5443 = env5444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28833 env5443 == env5444) = true)

def env5445 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,4096,8353,65536,4113,262144,1025,8353,4097,4194304,4194352,139,8329,4194352,262177,4096,4112,2080,74794,16,188,1,4198432,4194864]

theorem envBound5445 : H12AffineFastState.Bounded env5445 := by
  intro p hp
  have h : env5445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5444_5445 : H12AffineEnvironment.transform 13 4096 env5444 = env5445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env5444 == env5445) = true)

theorem identity5445 : scanCanonicalize (H12AffineFastState.compose env5445 (packedSelected [2,3,4,5,9,10,11,17,18,20,21] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound5445 : packedSelected [2,3,4,5,9,10,11,17,18,20,21] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0