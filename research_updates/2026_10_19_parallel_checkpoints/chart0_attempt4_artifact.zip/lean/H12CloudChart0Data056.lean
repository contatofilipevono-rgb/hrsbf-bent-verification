import H12CloudChart0Data055

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity14057 : scanCanonicalize (H12AffineFastState.compose env14057 (packedSelected [11,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound14057 : packedSelected [11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env14058 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,46157,10281,1024,32769,45341,32,16,3,8193,64,10589,5392,45405,2420,41993,41340,256,32,46093,41821]

theorem envBound14058 : H12AffineFastState.Bounded env14058 := by
  intro p hp
  have h : env14058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14057_14058 : H12AffineEnvironment.transform 17 10281 env14057 = env14058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env14057 == env14058) = true)

theorem identity14058 : scanCanonicalize (H12AffineFastState.compose env14058 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound14058 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env14059 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5376,32768,114,37940,2128,1024,32769,37220,32,16,3,120,64,2340,5392,37156,2420,33904,33029,256,32,38004,33572]

theorem envBound14059 : H12AffineFastState.Bounded env14059 := by
  intro p hp
  have h : env14059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14058_14059 : H12AffineEnvironment.transform 12 121 env14058 = env14059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env14058 == env14059) = true)

theorem identity14059 : scanCanonicalize (H12AffineFastState.compose env14059 (packedSelected [2,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound14059 : packedSelected [2,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env14060 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,121,5237,32768,114,37940,2128,1024,32769,36881,32,16,3,120,64,2129,5221,36945,2049,33904,32880,117,32,38004,33361]

theorem envBound14060 : H12AffineFastState.Bounded env14060 := by
  intro p hp
  have h : env14060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14059_14060 : H12AffineEnvironment.transform 7 117 env14059 = env14060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env14059 == env14060) = true)

theorem identity14060 : scanCanonicalize (H12AffineFastState.compose env14060 (packedSelected [1,2,3] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound14060 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env14061 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,121,5237,81,114,5221,2128,1024,80,4160,32,16,3,120,64,2129,5221,4096,2049,1057,33,117,32,5157,512]

theorem envBound14061 : H12AffineFastState.Bounded env14061 := by
  intro p hp
  have h : env14061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14060_14061 : H12AffineEnvironment.transform 14 81 env14060 = env14061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env14060 == env14061) = true)

theorem identity14061 : scanCanonicalize (H12AffineFastState.compose env14061 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14061 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env14062 : List Nat := [2,4,8,16,0,64,9,85,512,1024,2048,4096,89,5205,81,82,5189,2128,1024,80,4160,0,16,3,88,64,2129,5189,4096,2049,1025,1,85,0,5125,512]

theorem envBound14062 : H12AffineFastState.Bounded env14062 := by
  intro p hp
  have h : env14062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14061_14062 : H12AffineEnvironment.transform 4 0 env14061 = env14062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14061 == env14062) = true)

theorem identity14062 : scanCanonicalize (H12AffineFastState.compose env14062 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14062 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14063 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,4096,9,5125,1,2,5141,2048,1024,0,4112,0,16,3,8,16,2049,5141,4096,2049,1025,1,5,0,5125,512]

theorem envBound14063 : H12AffineFastState.Bounded env14063 := by
  intro p hp
  have h : env14063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14062_14063 : H12AffineEnvironment.transform 5 16 env14062 = env14063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14062 == env14063) = true)

def env14064 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,32,17,73736,8193,64,439608,79131,102743,431377,41992,98679,256,73770,103431,99159]

theorem envBound14064 : H12AffineFastState.Bounded env14064 := by
  intro p hp
  have h : env14064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14054_14064 : H12AffineEnvironment.transform 22 17 env14054 = env14064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env14054 == env14064) = true)

theorem identity14064 : scanCanonicalize (H12AffineFastState.compose env14064 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound14064 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14065 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,67618,1024,32769,102678,32,17,73736,8193,64,245018,79131,102743,236851,41992,98679,256,73770,103431,99159]

theorem envBound14065 : H12AffineFastState.Bounded env14065 := by
  intro p hp
  have h : env14065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14064_14065 : H12AffineEnvironment.transform 17 67618 env14064 = env14065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env14064 == env14065) = true)

theorem identity14065 : scanCanonicalize (H12AffineFastState.compose env14065 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound14065 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env14066 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,79130,67618,1024,32769,102678,32,17,73736,8193,64,34816,79131,102743,43049,41992,98679,256,73770,103431,99159]

theorem envBound14066 : H12AffineFastState.Bounded env14066 := by
  intro p hp
  have h : env14066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14065_14066 : H12AffineEnvironment.transform 16 79130 env14065 = env14066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env14065 == env14066) = true)

theorem identity14066 : scanCanonicalize (H12AffineFastState.compose env14066 (packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound14066 : packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS < 2^1333 := by decide +kernel

def env14067 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8574,5220,10588,1024,32769,45160,32,17,374,8193,64,34816,5221,45097,43049,41992,40969,256,340,46457,41513]

theorem envBound14067 : H12AffineFastState.Bounded env14067 := by
  intro p hp
  have h : env14067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14066_14067 : H12AffineEnvironment.transform 15 8574 env14066 = env14067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env14066 == env14067) = true)

theorem identity14067 : scanCanonicalize (H12AffineFastState.compose env14067 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound14067 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env14068 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8232,8574,5220,10588,1024,8233,4160,32,17,374,8193,64,10280,5221,4097,2049,1056,33,256,340,5457,513]

theorem envBound14068 : H12AffineFastState.Bounded env14068 := by
  intro p hp
  have h : env14068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14067_14068 : H12AffineEnvironment.transform 14 8232 env14067 = env14068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env14067 == env14068) = true)

theorem identity14068 : scanCanonicalize (H12AffineFastState.compose env14068 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound14068 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env14069 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5376,80,262,5220,2340,1024,81,4160,32,17,374,121,64,2128,5221,4097,2049,1056,33,256,340,5457,513]

theorem envBound14069 : H12AffineFastState.Bounded env14069 := by
  intro p hp
  have h : env14069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14068_14069 : H12AffineEnvironment.transform 12 120 env14068 = env14069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env14068 == env14069) = true)

theorem identity14069 : scanCanonicalize (H12AffineFastState.compose env14069 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound14069 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env14070 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2357,120,3125,80,262,3409,2340,1024,81,2421,32,17,374,121,64,2128,3408,2356,2049,1056,33,256,340,3172,513]

theorem envBound14070 : H12AffineFastState.Bounded env14070 := by
  intro p hp
  have h : env14070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14069_14070 : H12AffineEnvironment.transform 11 2357 env14069 = env14070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env14069 == env14070) = true)

theorem identity14070 : scanCanonicalize (H12AffineFastState.compose env14070 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound14070 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14071 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,2113,120,3125,80,114,3109,2128,1024,81,2049,32,17,2,121,64,2128,3108,2112,2049,1056,33,116,32,3172,513]

theorem envBound14071 : H12AffineFastState.Bounded env14071 := by
  intro p hp
  have h : env14071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14070_14071 : H12AffineEnvironment.transform 7 116 env14070 = env14071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env14070 == env14071) = true)

theorem identity14071 : scanCanonicalize (H12AffineFastState.compose env14071 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14071 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env14072 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,2065,40,3125,0,34,3109,2048,1024,1,2049,32,17,2,41,16,2048,3108,2064,2049,1056,33,36,32,3124,513]

theorem envBound14072 : H12AffineFastState.Bounded env14072 := by
  intro p hp
  have h : env14072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14071_14072 : H12AffineEnvironment.transform 5 16 env14071 = env14072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14071 == env14072) = true)

theorem identity14072 : scanCanonicalize (H12AffineFastState.compose env14072 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound14072 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14073 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1077,1060,40,0,0,34,16,1077,1024,1,1076,32,17,2,41,16,1077,17,1061,1076,1056,33,36,32,1,513]

theorem envBound14073 : H12AffineFastState.Bounded env14073 := by
  intro p hp
  have h : env14073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14072_14073 : H12AffineEnvironment.transform 10 1077 env14072 = env14073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env14072 == env14073) = true)

theorem identity14073 : scanCanonicalize (H12AffineFastState.compose env14073 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound14073 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14074 : List Nat := [2,4,8,16,32,16,9,36,512,53,0,17,40,0,0,34,16,0,53,1,1,32,17,2,41,16,0,17,16,1,21,33,36,32,1,513]

theorem envBound14074 : H12AffineFastState.Bounded env14074 := by
  intro p hp
  have h : env14074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14073_14074 : H12AffineEnvironment.transform 9 53 env14073 = env14074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env14073 == env14074) = true)

theorem identity14074 : scanCanonicalize (H12AffineFastState.compose env14074 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound14074 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14075 : List Nat := [2,4,8,16,32,16,9,36,32,53,0,17,40,0,0,34,16,0,53,1,1,32,17,2,41,16,0,17,16,1,21,33,36,32,1,33]

theorem envBound14075 : H12AffineFastState.Bounded env14075 := by
  intro p hp
  have h : env14075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14074_14075 : H12AffineEnvironment.transform 8 32 env14074 = env14075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env14074 == env14075) = true)

def env14076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,33,8388608,73857,8328,64,8828321,79131,8491334,8819968,8430736,98678,256,8462395,8492191,8487750]

theorem envBound14076 : H12AffineFastState.Bounded env14076 := by
  intro p hp
  have h : env14076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14038_14076 : H12AffineEnvironment.transform 21 33 env14038 = env14076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env14038 == env14076) = true)

theorem identity14076 : scanCanonicalize (H12AffineFastState.compose env14076 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound14076 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,33,16,73857,8328,64,439729,79131,102742,431376,42112,98678,256,73771,103567,99158]

theorem envBound14077 : H12AffineFastState.Bounded env14077 := by
  intro p hp
  have h : env14077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14076_14077 : H12AffineEnvironment.transform 22 16 env14076 = env14077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env14076 == env14077) = true)

def env14078 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,33,16,73737,8192,64,439609,79131,102742,431376,41992,98678,256,73771,103431,99158]

theorem envBound14078 : H12AffineFastState.Bounded env14078 := by
  intro p hp
  have h : env14078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14077_14078 : H12AffineEnvironment.transform 6 8 env14077 = env14078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14077 == env14078) = true)

theorem identity14078 : scanCanonicalize (H12AffineFastState.compose env14078 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound14078 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14079 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,131072,262144,1024,32769,4161,33,16,41310,8192,64,439609,46156,4097,431376,41992,33,256,41340,5456,513]

theorem envBound14079 : H12AffineFastState.Bounded env14079 := by
  intro p hp
  have h : env14079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14078_14079 : H12AffineEnvironment.transform 15 33111 env14078 = env14079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env14078 == env14079) = true)

theorem identity14079 : scanCanonicalize (H12AffineFastState.compose env14079 (packedSelected [0,14,18,23,27] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound14079 : packedSelected [0,14,18,23,27] rootPS < 2^1333 := by decide +kernel

def env14080 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,32768,33111,131072,262144,1024,32769,4161,33,16,32771,349,64,431204,38161,4097,431376,34133,33,256,32801,5456,513]

theorem envBound14080 : H12AffineFastState.Bounded env14080 := by
  intro p hp
  have h : env14080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14079_14080 : H12AffineEnvironment.transform 12 349 env14079 = env14080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env14079 == env14080) = true)

theorem identity14080 : scanCanonicalize (H12AffineFastState.compose env14080 (packedSelected [0,1,3,4,5,7,8,9,10,14,19] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound14080 : packedSelected [0,1,3,4,5,7,8,9,10,14,19] rootPS < 2^1333 := by decide +kernel

def env14081 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,32768,33111,131072,2420,1024,32769,4161,33,16,32771,349,64,171280,38161,4097,171108,34133,33,256,32801,5456,513]

theorem envBound14081 : H12AffineFastState.Bounded env14081 := by
  intro p hp
  have h : env14081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14080_14081 : H12AffineEnvironment.transform 17 2420 env14080 = env14081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env14080 == env14081) = true)

theorem identity14081 : scanCanonicalize (H12AffineFastState.compose env14081 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound14081 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14082 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,32768,33111,38160,2420,1024,32769,4161,33,16,32771,349,64,2048,38161,4097,2420,34133,33,256,32801,5456,513]

theorem envBound14082 : H12AffineFastState.Bounded env14082 := by
  intro p hp
  have h : env14082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14081_14082 : H12AffineEnvironment.transform 16 38160 env14081 = env14082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env14081 == env14082) = true)

theorem identity14082 : scanCanonicalize (H12AffineFastState.compose env14082 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound14082 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env14083 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,1,342,5393,2420,1024,0,4161,33,16,2,349,64,2048,5392,4097,2420,1364,33,256,32,5456,513]

theorem envBound14083 : H12AffineFastState.Bounded env14083 := by
  intro p hp
  have h : env14083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14082_14083 : H12AffineEnvironment.transform 14 1 env14082 = env14083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env14082 == env14083) = true)

theorem identity14083 : scanCanonicalize (H12AffineFastState.compose env14083 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound14083 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14084 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5237,1,35,5220,2049,1024,0,4161,33,16,2,40,64,2048,5221,4097,2049,1057,33,117,32,5157,513]

theorem envBound14084 : H12AffineFastState.Bounded env14084 := by
  intro p hp
  have h : env14084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14083_14084 : H12AffineEnvironment.transform 7 117 env14083 = env14084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env14083 == env14084) = true)

theorem identity14084 : scanCanonicalize (H12AffineFastState.compose env14084 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14084 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14085 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,40,5156,1,35,5173,2049,1024,0,4112,33,16,2,40,17,2048,5172,4097,2049,1057,33,36,32,5157,513]

theorem envBound14085 : H12AffineFastState.Bounded env14085 := by
  intro p hp
  have h : env14085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14084_14085 : H12AffineEnvironment.transform 5 17 env14084 = env14085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14084 == env14085) = true)

def env14086 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,33,16,73736,8193,64,439608,79131,102742,431376,41993,98678,256,73771,103430,99158]

theorem envBound14086 : H12AffineFastState.Bounded env14086 := by
  intro p hp
  have h : env14086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14077_14086 : H12AffineEnvironment.transform 6 9 env14077 = env14086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14077 == env14086) = true)

theorem identity14086 : scanCanonicalize (H12AffineFastState.compose env14086 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound14086 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14087 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,45341,33,16,3,8193,64,439608,5392,45405,431376,41993,41341,256,32,46093,41821]

theorem envBound14087 : H12AffineFastState.Bounded env14087 := by
  intro p hp
  have h : env14087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14086_14087 : H12AffineEnvironment.transform 15 8203 env14086 = env14087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env14086 == env14087) = true)

theorem identity14087 : scanCanonicalize (H12AffineFastState.compose env14087 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound14087 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env14088 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8203,131072,262144,1024,8541,4161,33,16,3,8193,64,398436,5392,4097,406604,1365,33,256,32,5457,513]

theorem envBound14088 : H12AffineFastState.Bounded env14088 := by
  intro p hp
  have h : env14088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14087_14088 : H12AffineEnvironment.transform 14 8540 env14087 = env14088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env14087 == env14088) = true)

theorem identity14088 : scanCanonicalize (H12AffineFastState.compose env14088 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 146792) := by decide +kernel

theorem selectedBound14088 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14089 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8203,131072,146792,1024,8541,4161,33,16,3,8193,64,10508,5392,4097,2340,1365,33,256,32,5457,513]

theorem envBound14089 : H12AffineFastState.Bounded env14089 := by
  intro p hp
  have h : env14089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14088_14089 : H12AffineEnvironment.transform 17 146792 env14088 = env14089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146792 env14088 == env14089) = true)

theorem identity14089 : scanCanonicalize (H12AffineFastState.compose env14089 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound14089 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env14090 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,4112,8540,8203,131072,145528,272,8541,4161,33,16,3,8193,64,10508,4096,4097,2340,69,33,256,32,4161,513]

theorem envBound14090 : H12AffineFastState.Bounded env14090 := by
  intro p hp
  have h : env14090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14089_14090 : H12AffineEnvironment.transform 9 272 env14089 = env14090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env14089 == env14090) = true)

theorem identity14090 : scanCanonicalize (H12AffineFastState.compose env14090 (packedSelected [12,15] rootPS)) = affineNative (2^(16+1) ^^^ 12408) := by decide +kernel

theorem selectedBound14090 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env14091 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,4112,8540,8203,12408,2048,272,8541,4161,33,16,3,8193,64,10508,4096,4097,2340,69,33,256,32,4161,513]

theorem envBound14091 : H12AffineFastState.Bounded env14091 := by
  intro p hp
  have h : env14091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14090_14091 : H12AffineEnvironment.transform 16 12408 env14090 = env14091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12408 env14090 == env14091) = true)

theorem identity14091 : scanCanonicalize (H12AffineFastState.compose env14091 (packedSelected [0,4,7,9,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound14091 : packedSelected [0,4,7,9,11,14] rootPS < 2^1333 := by decide +kernel

def env14092 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2404,8192,2420,8540,8203,10524,2048,272,8541,2341,33,16,3,8193,64,10508,2404,2405,2340,69,33,256,32,2341,513]

theorem envBound14092 : H12AffineFastState.Bounded env14092 := by
  intro p hp
  have h : env14092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14091_14092 : H12AffineEnvironment.transform 11 2404 env14091 = env14092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env14091 == env14092) = true)

theorem identity14092 : scanCanonicalize (H12AffineFastState.compose env14092 (packedSelected [1,4,8,9,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound14092 : packedSelected [1,4,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env14093 : List Nat := [2,4,8,16,32,64,9,36,512,52,2048,2112,8192,2128,8312,8203,10296,2048,52,8313,2049,33,16,3,8193,64,10280,2112,2113,2048,69,33,36,32,2049,513]

theorem envBound14093 : H12AffineFastState.Bounded env14093 := by
  intro p hp
  have h : env14093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14092_14093 : H12AffineEnvironment.transform 7 36 env14092 = env14093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env14092 == env14093) = true)

theorem identity14093 : scanCanonicalize (H12AffineFastState.compose env14093 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14093 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14094 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,2064,8192,2048,8232,8203,10296,2048,52,8233,2049,33,16,3,8193,16,10280,2064,2065,2048,21,33,36,32,2049,513]

theorem envBound14094 : H12AffineFastState.Bounded env14094 := by
  intro p hp
  have h : env14094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14093_14094 : H12AffineEnvironment.transform 5 16 env14093 = env14094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14093 == env14094) = true)

theorem identity14094 : scanCanonicalize (H12AffineFastState.compose env14094 (packedSelected [2,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 2073) := by decide +kernel

theorem selectedBound14094 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env14095 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,2064,2073,2048,2097,2066,33,2048,52,2096,2049,33,16,3,2072,16,49,2064,2065,2048,21,33,36,32,2049,513]

theorem envBound14095 : H12AffineFastState.Bounded env14095 := by
  intro p hp
  have h : env14095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14094_14095 : H12AffineEnvironment.transform 12 2073 env14094 = env14095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2073 env14094 == env14095) = true)

theorem identity14095 : scanCanonicalize (H12AffineFastState.compose env14095 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound14095 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14096 : List Nat := [2,4,8,16,32,16,9,36,512,52,17,1,8,17,32,3,33,17,52,33,16,33,16,3,9,16,49,1,0,17,21,33,36,32,16,513]

theorem envBound14096 : H12AffineFastState.Bounded env14096 := by
  intro p hp
  have h : env14096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14095_14096 : H12AffineEnvironment.transform 10 17 env14095 = env14096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env14095 == env14096) = true)

def env14097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,4194304,8388608,73856,8328,64,13022592,79131,8491334,8819969,8430737,4292950,256,8462394,8492191,8487751]

theorem envBound14097 : H12AffineFastState.Bounded env14097 := by
  intro p hp
  have h : env14097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14037_14097 : H12AffineEnvironment.transform 13 5377 env14037 = env14097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env14037 == env14097) = true)

def env14098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,32,8388608,73856,8328,64,8828320,79131,8491334,8819969,8430737,98678,256,8462394,8492191,8487751]

theorem envBound14098 : H12AffineFastState.Bounded env14098 := by
  intro p hp
  have h : env14098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14097_14098 : H12AffineEnvironment.transform 21 32 env14097 = env14098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env14097 == env14098) = true)

theorem identity14098 : scanCanonicalize (H12AffineFastState.compose env14098 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14098 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14099 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,32,8388608,73736,8192,64,8828200,79131,8491334,8819969,8430617,98678,256,8462394,8492055,8487751]

theorem envBound14099 : H12AffineFastState.Bounded env14099 := by
  intro p hp
  have h : env14099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14098_14099 : H12AffineEnvironment.transform 6 8 env14098 = env14099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14098 == env14099) = true)

def env14100 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,32,16,73736,8192,64,439608,79131,102742,431377,41993,98678,256,73770,103431,99159]

theorem envBound14100 : H12AffineFastState.Bounded env14100 := by
  intro p hp
  have h : env14100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14099_14100 : H12AffineEnvironment.transform 22 16 env14099 = env14100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env14099 == env14100) = true)

theorem identity14100 : scanCanonicalize (H12AffineFastState.compose env14100 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound14100 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14101 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,131072,262144,1024,32769,4161,32,16,41310,8192,64,439608,46157,4096,431377,41993,32,256,41340,5457,513]

theorem envBound14101 : H12AffineFastState.Bounded env14101 := by
  intro p hp
  have h : env14101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14100_14101 : H12AffineEnvironment.transform 15 33110 env14100 = env14101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env14100 == env14101) = true)

theorem identity14101 : scanCanonicalize (H12AffineFastState.compose env14101 (packedSelected [0,14,18,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound14101 : packedSelected [0,14,18,23,27] rootPS < 2^1333 := by decide +kernel

def env14102 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,13389,262144,1024,32769,4161,32,16,41310,8192,64,295285,46157,4096,303452,41993,32,256,41340,5457,513]

theorem envBound14102 : H12AffineFastState.Bounded env14102 := by
  intro p hp
  have h : env14102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14101_14102 : H12AffineEnvironment.transform 16 13389 env14101 = env14102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env14101 == env14102) = true)

theorem identity14102 : scanCanonicalize (H12AffineFastState.compose env14102 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound14102 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env14103 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,32768,33110,5392,262144,1024,32769,4161,32,16,32771,349,64,295285,38160,4096,294913,34132,32,256,32801,5457,513]

theorem envBound14103 : H12AffineFastState.Bounded env14103 := by
  intro p hp
  have h : env14103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14102_14103 : H12AffineEnvironment.transform 12 349 env14102 = env14103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env14102 == env14103) = true)

theorem identity14103 : scanCanonicalize (H12AffineFastState.compose env14103 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound14103 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env14104 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,0,342,5392,262144,1024,1,4161,32,16,3,349,64,262517,5392,4096,262145,1364,32,256,33,5457,513]

theorem envBound14104 : H12AffineFastState.Bounded env14104 := by
  intro p hp
  have h : env14104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14103_14104 : H12AffineEnvironment.transform 14 0 env14103 = env14104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env14103 == env14104) = true)

theorem identity14104 : scanCanonicalize (H12AffineFastState.compose env14104 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14104 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14105 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5377,0,262,5392,262144,1024,1,4113,32,16,3,269,16,262437,5392,4096,262145,1284,32,256,33,5377,513]

theorem envBound14105 : H12AffineFastState.Bounded env14105 := by
  intro p hp
  have h : env14105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14104_14105 : H12AffineEnvironment.transform 5 16 env14104 = env14105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14104 == env14105) = true)

theorem identity14105 : scanCanonicalize (H12AffineFastState.compose env14105 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound14105 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env14106 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,269,4113,0,262,4096,262144,272,1,4113,32,16,3,269,16,262437,4096,4096,262145,20,32,256,33,4113,513]

theorem envBound14106 : H12AffineFastState.Bounded env14106 := by
  intro p hp
  have h : env14106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14105_14106 : H12AffineEnvironment.transform 9 272 env14105 = env14106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env14105 == env14106) = true)

theorem identity14106 : scanCanonicalize (H12AffineFastState.compose env14106 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound14106 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env14107 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,269,4113,0,262,4096,2048,272,1,4113,32,16,3,269,16,2341,4096,4096,2049,20,32,256,33,4113,513]

theorem envBound14107 : H12AffineFastState.Bounded env14107 := by
  intro p hp
  have h : env14107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14106_14107 : H12AffineEnvironment.transform 17 2048 env14106 = env14107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env14106 == env14107) = true)

theorem identity14107 : scanCanonicalize (H12AffineFastState.compose env14107 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound14107 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14108 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,1,269,16,0,262,1,2048,272,1,16,32,16,3,269,16,2341,1,1,2049,20,32,256,33,16,513]

theorem envBound14108 : H12AffineFastState.Bounded env14108 := by
  intro p hp
  have h : env14108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14107_14108 : H12AffineEnvironment.transform 11 1 env14107 = env14108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env14107 == env14108) = true)

theorem identity14108 : scanCanonicalize (H12AffineFastState.compose env14108 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound14108 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14109 : List Nat := [2,4,8,16,32,16,8,256,512,272,48,1,269,16,0,262,1,48,272,1,16,32,16,3,269,16,277,1,1,49,20,32,256,33,16,513]

theorem envBound14109 : H12AffineFastState.Bounded env14109 := by
  intro p hp
  have h : env14109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14108_14109 : H12AffineEnvironment.transform 10 48 env14108 = env14109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env14108 == env14109) = true)

theorem identity14109 : scanCanonicalize (H12AffineFastState.compose env14109 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound14109 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env14110 : List Nat := [2,4,8,16,32,16,8,53,512,37,48,1,56,16,0,51,1,48,37,1,16,32,16,3,56,16,32,1,1,49,20,32,53,33,16,513]

theorem envBound14110 : H12AffineFastState.Bounded env14110 := by
  intro p hp
  have h : env14110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14109_14110 : H12AffineEnvironment.transform 7 53 env14109 = env14110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env14109 == env14110) = true)

theorem identity14110 : scanCanonicalize (H12AffineFastState.compose env14110 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound14110 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env14111 : List Nat := [2,4,8,16,17,16,8,4,512,20,1,1,9,16,0,2,1,1,20,1,16,17,16,3,9,16,17,1,1,0,20,17,4,16,16,513]

theorem envBound14111 : H12AffineFastState.Bounded env14111 := by
  intro p hp
  have h : env14111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14110_14111 : H12AffineEnvironment.transform 4 17 env14110 = env14111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env14110 == env14111) = true)

theorem identity14111 : scanCanonicalize (H12AffineFastState.compose env14111 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound14111 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14112 : List Nat := [2,4,8,0,1,0,8,4,512,4,1,1,9,0,0,2,1,1,4,1,0,1,0,3,9,0,1,1,1,0,4,1,4,0,0,513]

theorem envBound14112 : H12AffineFastState.Bounded env14112 := by
  intro p hp
  have h : env14112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14111_14112 : H12AffineEnvironment.transform 3 0 env14111 = env14112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14111 == env14112) = true)

def env14113 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,32,17,73736,8192,64,439609,79131,102743,431376,41992,98678,256,73771,103430,99158]

theorem envBound14113 : H12AffineFastState.Bounded env14113 := by
  intro p hp
  have h : env14113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14099_14113 : H12AffineEnvironment.transform 22 17 env14099 = env14113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env14099 == env14113) = true)

theorem identity14113 : scanCanonicalize (H12AffineFastState.compose env14113 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 108926) := by decide +kernel

theorem selectedBound14113 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14114 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,108926,1024,32769,102679,32,17,73736,8192,64,203847,79131,102743,212078,41992,98678,256,73771,103430,99158]

theorem envBound14114 : H12AffineFastState.Bounded env14114 := by
  intro p hp
  have h : env14114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14113_14114 : H12AffineEnvironment.transform 17 108926 env14113 = env14114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108926 env14113 == env14114) = true)

theorem identity14114 : scanCanonicalize (H12AffineFastState.compose env14114 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound14114 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env14115 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,46156,108926,1024,32769,102679,32,17,73736,8192,64,108555,79131,102743,100386,41992,98678,256,73771,103430,99158]

theorem envBound14115 : H12AffineFastState.Bounded env14115 := by
  intro p hp
  have h : env14115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14114_14115 : H12AffineEnvironment.transform 16 46156 env14114 = env14115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env14114 == env14115) = true)

theorem identity14115 : scanCanonicalize (H12AffineFastState.compose env14115 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound14115 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env14116 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,80,65536,13340,76078,1024,81,69959,32,17,73736,8192,64,75867,79131,69895,67698,9304,65830,256,73771,70742,66310]

theorem envBound14116 : H12AffineFastState.Bounded env14116 := by
  intro p hp
  have h : env14116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14115_14116 : H12AffineEnvironment.transform 14 80 env14115 = env14116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env14115 == env14116) = true)

theorem identity14116 : scanCanonicalize (H12AffineFastState.compose env14116 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,12,14,15,19] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound14116 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,12,14,15,19] rootPS < 2^1333 := by decide +kernel

def env14117 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,80,8282,13340,2420,1024,81,12573,32,17,82,8192,64,2049,5441,12637,10280,9304,8572,256,113,13324,9052]

theorem envBound14117 : H12AffineFastState.Bounded env14117 := by
  intro p hp
  have h : env14117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14116_14117 : H12AffineEnvironment.transform 15 8282 env14116 = env14117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env14116 == env14117) = true)

theorem identity14117 : scanCanonicalize (H12AffineFastState.compose env14117 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound14117 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env14118 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,80,343,5393,2420,1024,81,4112,32,17,82,269,64,2049,5441,4176,2341,1365,113,256,113,5377,593]

theorem envBound14118 : H12AffineFastState.Bounded env14118 := by
  intro p hp
  have h : env14118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14117_14118 : H12AffineEnvironment.transform 12 269 env14117 = env14118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env14117 == env14118) = true)

theorem identity14118 : scanCanonicalize (H12AffineFastState.compose env14118 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound14118 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env14119 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,4096,269,5377,80,343,5393,80,1024,81,4112,32,17,82,269,64,293,5441,4176,1,1365,113,256,113,5377,593]

theorem envBound14119 : H12AffineFastState.Bounded env14119 := by
  intro p hp
  have h : env14119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14118_14119 : H12AffineEnvironment.transform 10 292 env14118 = env14119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env14118 == env14119) = true)

theorem identity14119 : scanCanonicalize (H12AffineFastState.compose env14119 (packedSelected [1,2,3,4,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound14119 : packedSelected [1,2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env14120 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,1060,269,293,80,343,309,80,1024,81,1076,32,17,82,269,64,293,357,1140,1,1365,113,256,113,293,593]

theorem envBound14120 : H12AffineFastState.Bounded env14120 := by
  intro p hp
  have h : env14120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14119_14120 : H12AffineEnvironment.transform 11 1060 env14119 = env14120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env14119 == env14120) = true)

theorem identity14120 : scanCanonicalize (H12AffineFastState.compose env14120 (packedSelected [2,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound14120 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env14121 : List Nat := [2,4,8,16,32,64,8,256,512,53,292,17,269,293,80,343,309,80,53,81,1,32,17,82,269,64,293,357,65,1,352,113,256,113,293,593]

theorem envBound14121 : H12AffineFastState.Bounded env14121 := by
  intro p hp
  have h : env14121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14120_14121 : H12AffineEnvironment.transform 9 53 env14120 = env14121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env14120 == env14121) = true)

theorem identity14121 : scanCanonicalize (H12AffineFastState.compose env14121 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound14121 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env14122 : List Nat := [2,4,8,16,32,64,8,116,512,53,80,17,121,81,80,35,65,80,53,81,1,32,17,82,121,64,81,17,65,1,20,113,116,113,81,593]

theorem envBound14122 : H12AffineFastState.Bounded env14122 := by
  intro p hp
  have h : env14122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14121_14122 : H12AffineEnvironment.transform 7 116 env14121 = env14122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env14121 == env14122) = true)

theorem identity14122 : scanCanonicalize (H12AffineFastState.compose env14122 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound14122 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14123 : List Nat := [2,4,8,16,32,64,8,116,64,53,80,17,121,81,80,35,65,80,53,81,1,32,17,82,121,64,81,17,65,1,20,113,116,113,81,17]

theorem envBound14123 : H12AffineFastState.Bounded env14123 := by
  intro p hp
  have h : env14123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14122_14123 : H12AffineEnvironment.transform 8 64 env14122 = env14123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env14122 == env14123) = true)

theorem identity14123 : scanCanonicalize (H12AffineFastState.compose env14123 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14123 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env14124 : List Nat := [2,4,8,16,32,16,8,36,16,53,0,17,41,1,0,35,17,0,53,1,1,32,17,2,41,16,1,17,17,1,20,33,36,33,1,17]

theorem envBound14124 : H12AffineFastState.Bounded env14124 := by
  intro p hp
  have h : env14124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14123_14124 : H12AffineEnvironment.transform 5 16 env14123 = env14124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14123 == env14124) = true)

theorem identity14124 : scanCanonicalize (H12AffineFastState.compose env14124 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound14124 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14125 : List Nat := [2,4,8,11,32,11,8,36,11,46,0,10,41,1,0,35,10,0,46,1,1,32,10,2,41,11,1,10,10,1,15,33,36,33,1,10]

theorem envBound14125 : H12AffineFastState.Bounded env14125 := by
  intro p hp
  have h : env14125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14124_14125 : H12AffineEnvironment.transform 3 11 env14124 = env14125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env14124 == env14125) = true)

def env14126 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,33,8388608,73856,8328,64,8828321,79131,8491334,8819969,8430737,98679,256,8462394,8492191,8487751]

theorem envBound14126 : H12AffineFastState.Bounded env14126 := by
  intro p hp
  have h : env14126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14097_14126 : H12AffineEnvironment.transform 21 33 env14097 = env14126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env14097 == env14126) = true)

theorem identity14126 : scanCanonicalize (H12AffineFastState.compose env14126 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 152) := by decide +kernel

theorem selectedBound14126 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14127 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,33,152,73856,8328,64,439609,79131,102878,431513,41993,98679,256,73890,103431,99295]

theorem envBound14127 : H12AffineFastState.Bounded env14127 := by
  intro p hp
  have h : env14127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14126_14127 : H12AffineEnvironment.transform 22 152 env14126 = env14127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 152 env14126 == env14127) = true)

def env14128 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,33,16,73736,8192,64,439609,79131,102742,431377,41993,98679,256,73770,103431,99159]

theorem envBound14128 : H12AffineFastState.Bounded env14128 := by
  intro p hp
  have h : env14128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14127_14128 : H12AffineEnvironment.transform 6 8 env14127 = env14128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14127 == env14128) = true)

theorem identity14128 : scanCanonicalize (H12AffineFastState.compose env14128 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound14128 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14129 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,131072,262144,1024,32769,4161,33,16,41310,8192,64,439609,46157,4096,431377,41993,33,256,41340,5457,513]

theorem envBound14129 : H12AffineFastState.Bounded env14129 := by
  intro p hp
  have h : env14129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14128_14129 : H12AffineEnvironment.transform 15 33110 env14128 = env14129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env14128 == env14129) = true)

theorem identity14129 : scanCanonicalize (H12AffineFastState.compose env14129 (packedSelected [0,14,18,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound14129 : packedSelected [0,14,18,23,27] rootPS < 2^1333 := by decide +kernel

def env14130 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8202,131072,262144,1024,8541,4161,33,16,2,8192,64,398437,5393,4096,406605,1365,33,256,32,5457,513]

theorem envBound14130 : H12AffineFastState.Bounded env14130 := by
  intro p hp
  have h : env14130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14129_14130 : H12AffineEnvironment.transform 14 8540 env14129 = env14130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env14129 == env14130) = true)

def env14131 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,33,17,73737,8193,64,439609,79131,102743,431376,41993,98679,256,73771,103431,99158]

theorem envBound14131 : H12AffineFastState.Bounded env14131 := by
  intro p hp
  have h : env14131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14127_14131 : H12AffineEnvironment.transform 6 9 env14127 = env14131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14127 == env14131) = true)

theorem identity14131 : scanCanonicalize (H12AffineFastState.compose env14131 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound14131 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14132 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,67619,1024,32769,102679,33,17,73737,8193,64,245018,79131,102743,236851,41993,98679,256,73771,103431,99158]

theorem envBound14132 : H12AffineFastState.Bounded env14132 := by
  intro p hp
  have h : env14132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14131_14132 : H12AffineEnvironment.transform 17 67619 env14131 = env14132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env14131 == env14132) = true)

theorem identity14132 : scanCanonicalize (H12AffineFastState.compose env14132 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound14132 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env14133 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,79131,67619,1024,32769,102679,33,17,73737,8193,64,34817,79131,102743,43048,41993,98679,256,73771,103431,99158]

theorem envBound14133 : H12AffineFastState.Bounded env14133 := by
  intro p hp
  have h : env14133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14132_14133 : H12AffineEnvironment.transform 16 79131 env14132 = env14133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env14132 == env14133) = true)

theorem identity14133 : scanCanonicalize (H12AffineFastState.compose env14133 (packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound14133 : packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS < 2^1333 := by decide +kernel

def env14134 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,5237,32768,65536,78959,67619,1024,32769,102499,33,17,73737,8193,64,34817,78959,102435,43048,41993,98307,116,73771,103431,98850]

theorem envBound14134 : H12AffineFastState.Bounded env14134 := by
  intro p hp
  have h : env14134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14133_14134 : H12AffineEnvironment.transform 7 116 env14133 = env14134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env14133 == env14134) = true)

def env14135 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830977,25265169,23160256,257,27378861,27337992,25207750]

theorem envBound14135 : H12AffineFastState.Bounded env14135 := by
  intro p hp
  have h : env14135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13954_14135 : H12AffineEnvironment.transform 18 1025 env13954 = env14135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env13954 == env14135) = true)

theorem identity14135 : scanCanonicalize (H12AffineFastState.compose env14135 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10626198) := by decide +kernel

theorem selectedBound14135 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env14136 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10626198,8328,64,6677654,8626203,10507600,8830977,2334855,12796246,257,254011,197022,2262864]

theorem envBound14136 : H12AffineFastState.Bounded env14136 := by
  intro p hp
  have h : env14136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14135_14136 : H12AffineEnvironment.transform 23 10626198 env14135 = env14136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10626198 env14135 == env14136) = true)

def env14137 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,156116,2114882,8328,64,6677654,115151,2241668,303573,2334855,4268162,257,254011,197022,2262864]

theorem envBound14137 : H12AffineFastState.Bounded env14137 := by
  intro p hp
  have h : env14137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14136_14137 : H12AffineEnvironment.transform 22 156116 env14136 = env14137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 156116 env14136 == env14137) = true)

def env14138 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2534864,156116,2114882,8328,64,215366,115151,2241668,303573,2334855,2592082,257,254011,197022,2262864]

theorem envBound14138 : H12AffineFastState.Bounded env14138 := by
  intro p hp
  have h : env14138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14137_14138 : H12AffineEnvironment.transform 21 2534864 env14137 = env14138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2534864 env14137 == env14138) = true)

def env14139 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441744,156116,21762,8328,64,215366,115151,140484,303573,241863,498962,257,254011,197022,169744]

theorem envBound14139 : H12AffineFastState.Bounded env14139 := by
  intro p hp
  have h : env14139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14138_14139 : H12AffineEnvironment.transform 20 4160 env14138 = env14139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env14138 == env14139) = true)

def env14140 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4160,169400,156116,21762,8328,64,215366,115151,140484,35325,241863,243002,257,254011,197022,169744]

theorem envBound14140 : H12AffineFastState.Bounded env14140 := by
  intro p hp
  have h : env14140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14139_14140 : H12AffineEnvironment.transform 17 10280 env14139 = env14140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env14139 == env14140) = true)

def env14141 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1025,32769,4160,21928,41412,21762,8328,64,100694,115151,58580,35325,94423,95530,257,73771,115086,22272]

theorem envBound14141 : H12AffineFastState.Bounded env14141 := by
  intro p hp
  have h : env14141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14140_14141 : H12AffineEnvironment.transform 16 49168 env14140 = env14141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env14140 == env14141) = true)

theorem identity14141 : scanCanonicalize (H12AffineFastState.compose env14141 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound14141 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,13388,10280,1025,29789,4160,21928,21912,21762,8328,64,97546,79251,4232,32161,94423,95530,257,73771,79314,22272]

theorem envBound14142 : H12AffineFastState.Bounded env14142 := by
  intro p hp
  have h : env14142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14141_14142 : H12AffineEnvironment.transform 14 29788 env14141 = env14142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env14141 == env14142) = true)

theorem identity14142 : scanCanonicalize (H12AffineFastState.compose env14142 (packedSelected [0,1,4,7,8,19,22] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound14142 : packedSelected [0,1,4,7,8,19,22] rootPS < 2^1333 := by decide +kernel

def env14143 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,16384,29005,65536,12637,10280,272,29004,4160,20665,20617,20499,8328,64,96283,77954,4232,30896,94423,94267,257,73771,78019,21009]

theorem envBound14143 : H12AffineFastState.Bounded env14143 := by
  intro p hp
  have h : env14143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14142_14143 : H12AffineEnvironment.transform 9 273 env14142 = env14143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env14142 == env14143) = true)

theorem identity14143 : scanCanonicalize (H12AffineFastState.compose env14143 (packedSelected [1,4,7,8,9,11,19,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 8615) := by decide +kernel

theorem selectedBound14143 : packedSelected [1,4,7,8,9,11,19,23,27] rootPS < 2^1333 := by decide +kernel

def env14144 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,16384,29005,8615,12637,10280,272,29004,4160,20665,20617,20499,8328,64,22972,4389,4232,30896,20848,20892,257,396,4452,21009]

theorem envBound14144 : H12AffineFastState.Bounded env14144 := by
  intro p hp
  have h : env14144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14143_14144 : H12AffineEnvironment.transform 15 8615 env14143 = env14144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8615 env14143 == env14144) = true)

theorem identity14144 : scanCanonicalize (H12AffineFastState.compose env14144 (packedSelected [1,4,8,9,11,14,18,20,26] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound14144 : packedSelected [1,4,8,9,11,14,18,20,26] rootPS < 2^1333 := by decide +kernel

def env14145 : List Nat := [2,4,8,16,32,64,128,116,512,101,2048,4096,8192,16384,28729,8403,12329,10280,100,28728,4160,20665,20617,20499,8328,64,22728,4177,4232,30896,20484,20712,117,248,4112,21009]

theorem envBound14145 : H12AffineFastState.Bounded env14145 := by
  intro p hp
  have h : env14145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14144_14145 : H12AffineEnvironment.transform 7 116 env14144 = env14145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env14144 == env14145) = true)

theorem identity14145 : scanCanonicalize (H12AffineFastState.compose env14145 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14145 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env14146 : List Nat := [2,4,8,16,32,17,128,37,512,52,2048,4096,8192,16384,28729,8322,12329,10280,53,28728,4113,20665,20617,20499,8328,17,22681,4096,4232,30896,20484,20665,36,169,4112,21009]

theorem envBound14146 : H12AffineFastState.Bounded env14146 := by
  intro p hp
  have h : env14146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14145_14146 : H12AffineEnvironment.transform 5 17 env14145 = env14146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14145 == env14146) = true)

theorem identity14146 : scanCanonicalize (H12AffineFastState.compose env14146 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound14146 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14147 : List Nat := [2,4,8,16,32,17,128,37,512,52,2048,4096,8192,4112,8233,8322,12329,10280,53,8232,4113,169,153,3,8328,17,2185,4096,4232,10400,20,169,36,169,4112,513]

theorem envBound14147 : H12AffineFastState.Bounded env14147 := by
  intro p hp
  have h : env14147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14146_14147 : H12AffineEnvironment.transform 13 4112 env14146 = env14147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env14146 == env14147) = true)

theorem identity14147 : scanCanonicalize (H12AffineFastState.compose env14147 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 152) := by decide +kernel

theorem selectedBound14147 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env14148 : List Nat := [2,4,8,16,32,17,128,37,512,52,2048,152,8192,136,8233,8322,8369,10280,53,8232,137,169,153,3,8328,17,2185,152,16,10400,20,169,36,169,136,513]

theorem envBound14148 : H12AffineFastState.Bounded env14148 := by
  intro p hp
  have h : env14148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14147_14148 : H12AffineEnvironment.transform 11 152 env14147 = env14148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 152 env14147 == env14148) = true)

theorem identity14148 : scanCanonicalize (H12AffineFastState.compose env14148 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound14148 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env14149 : List Nat := [2,4,8,16,32,17,128,37,512,52,2048,152,2088,136,2049,2218,2201,0,53,2048,137,169,153,3,2208,17,2185,152,16,136,20,169,36,169,136,513]

theorem envBound14149 : H12AffineFastState.Bounded env14149 := by
  intro p hp
  have h : env14149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14148_14149 : H12AffineEnvironment.transform 12 2088 env14148 = env14149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env14148 == env14149) = true)

theorem identity14149 : scanCanonicalize (H12AffineFastState.compose env14149 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound14149 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env14150 : List Nat := [2,4,8,16,32,17,128,37,512,52,1,152,41,136,0,171,152,0,53,1,137,169,153,3,161,17,136,152,16,136,20,169,36,169,136,513]

theorem envBound14150 : H12AffineFastState.Bounded env14150 := by
  intro p hp
  have h : env14150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14149_14150 : H12AffineEnvironment.transform 10 1 env14149 = env14150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env14149 == env14150) = true)

theorem identity14150 : scanCanonicalize (H12AffineFastState.compose env14150 (packedSelected [2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound14150 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env14151 : List Nat := [2,4,8,1,32,0,128,37,512,37,1,137,41,136,0,171,137,0,36,1,137,169,136,3,161,0,136,137,1,136,5,169,36,169,136,513]

theorem envBound14151 : H12AffineFastState.Bounded env14151 := by
  intro p hp
  have h : env14151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14150_14151 : H12AffineEnvironment.transform 3 1 env14150 = env14151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env14150 == env14151) = true)

theorem identity14151 : scanCanonicalize (H12AffineFastState.compose env14151 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14151 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14152 : List Nat := [2,4,8,1,32,0,9,37,512,37,1,0,41,1,0,34,0,0,36,1,0,32,1,3,40,0,1,0,1,1,5,32,36,32,1,513]

theorem envBound14152 : H12AffineFastState.Bounded env14152 := by
  intro p hp
  have h : env14152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14151_14152 : H12AffineEnvironment.transform 6 9 env14151 = env14152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14151 == env14152) = true)

theorem identity14152 : scanCanonicalize (H12AffineFastState.compose env14152 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound14152 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14153 : List Nat := [2,0,8,1,32,0,9,33,512,33,1,0,41,1,0,34,0,0,32,1,0,32,1,3,40,0,1,0,1,1,1,32,32,32,1,513]

theorem envBound14153 : H12AffineFastState.Bounded env14153 := by
  intro p hp
  have h : env14153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14152_14153 : H12AffineEnvironment.transform 1 0 env14152 = env14153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env14152 == env14153) = true)

theorem identity14153 : scanCanonicalize (H12AffineFastState.compose env14153 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 34) := by decide +kernel

theorem selectedBound14153 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14154 : List Nat := [2,0,8,1,32,0,9,33,34,33,1,0,41,1,0,34,0,0,32,1,0,32,1,3,40,0,1,0,1,1,1,32,32,32,1,35]

theorem envBound14154 : H12AffineFastState.Bounded env14154 := by
  intro p hp
  have h : env14154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14153_14154 : H12AffineEnvironment.transform 8 34 env14153 = env14154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 34 env14153 == env14154) = true)

theorem identity14154 : scanCanonicalize (H12AffineFastState.compose env14154 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14154 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14155 : List Nat := [2,0,8,1,1,0,9,0,3,0,1,0,8,1,0,3,0,0,1,1,0,1,1,3,9,0,1,0,1,1,1,1,1,1,1,2]

theorem envBound14155 : H12AffineFastState.Bounded env14155 := by
  intro p hp
  have h : env14155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14154_14155 : H12AffineEnvironment.transform 4 1 env14154 = env14155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14154 == env14155) = true)

theorem identity14155 : scanCanonicalize (H12AffineFastState.compose env14155 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound14155 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env14156 : List Nat := [2,0,0,1,1,0,1,0,3,0,1,0,0,1,0,3,0,0,1,1,0,1,1,3,1,0,1,0,1,1,1,1,1,1,1,2]

theorem envBound14156 : H12AffineFastState.Bounded env14156 := by
  intro p hp
  have h : env14156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14155_14156 : H12AffineEnvironment.transform 2 0 env14155 = env14156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env14155 == env14156) = true)

theorem identity14156 : scanCanonicalize (H12AffineFastState.compose env14156 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound14156 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14157 : List Nat := [1,0,0,1,1,0,1,0,0,0,1,0,0,1,0,0,0,0,1,1,0,1,1,0,1,0,1,0,1,1,1,1,1,1,1,1]

theorem envBound14157 : H12AffineFastState.Bounded env14157 := by
  intro p hp
  have h : env14157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14156_14157 : H12AffineEnvironment.transform 0 1 env14156 = env14157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env14156 == env14157) = true)

def env14158 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1025,32769,4160,21929,41413,21762,8328,64,100695,115151,58581,35325,94422,95531,257,73770,115087,22273]

theorem envBound14158 : H12AffineFastState.Bounded env14158 := by
  intro p hp
  have h : env14158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14140_14158 : H12AffineEnvironment.transform 16 49169 env14140 = env14158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env14140 == env14158) = true)

theorem identity14158 : scanCanonicalize (H12AffineFastState.compose env14158 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound14158 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14159 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,13508,10280,1025,29908,4160,21929,21776,21762,8328,64,97666,79130,4096,32040,94422,95531,257,73770,79194,22273]

theorem envBound14159 : H12AffineFastState.Bounded env14159 := by
  intro p hp
  have h : env14159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14158_14159 : H12AffineEnvironment.transform 14 29909 env14158 = env14159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env14158 == env14159) = true)

theorem identity14159 : scanCanonicalize (H12AffineFastState.compose env14159 (packedSelected [0,1,2,4,5,6,8,9,11,18,20,24,27] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound14159 : packedSelected [0,1,2,4,5,6,8,9,11,18,20,24,27] rootPS < 2^1333 := by decide +kernel

def env14160 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,29909,65536,13508,10280,1025,29908,4160,21725,21604,21622,8328,64,97526,78958,4096,31836,94422,95327,117,73770,78894,22133]

theorem envBound14160 : H12AffineFastState.Bounded env14160 := by
  intro p hp
  have h : env14160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14159_14160 : H12AffineEnvironment.transform 7 116 env14159 = env14160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env14159 == env14160) = true)

theorem identity14160 : scanCanonicalize (H12AffineFastState.compose env14160 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound14160 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env14161 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,29909,21591,13508,10280,1025,29908,4160,21725,21604,21622,8328,64,10401,24633,4096,31836,9345,8200,117,29821,24697,22133]

theorem envBound14161 : H12AffineFastState.Bounded env14161 := by
  intro p hp
  have h : env14161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14160_14161 : H12AffineEnvironment.transform 15 21591 env14160 = env14161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env14160 == env14161) = true)

theorem identity14161 : scanCanonicalize (H12AffineFastState.compose env14161 (packedSelected [3,4,5,9,10,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound14161 : packedSelected [3,4,5,9,10,14,16] rootPS < 2^1333 := by decide +kernel

def env14162 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,1101,16384,20632,21591,4233,3173,1025,20633,4160,21725,21604,21622,1221,64,3308,17524,4096,22545,204,1093,117,20528,17460,22133]

theorem envBound14162 : H12AffineFastState.Bounded env14162 := by
  intro p hp
  have h : env14162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14161_14162 : H12AffineEnvironment.transform 12 1101 env14161 = env14162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env14161 == env14162) = true)

theorem identity14162 : scanCanonicalize (H12AffineFastState.compose env14162 (packedSelected [0,3,4,5,7,10,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14162 : packedSelected [0,3,4,5,7,10,22] rootPS < 2^1333 := by decide +kernel

def env14163 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,1101,16384,20497,21591,4096,3173,1025,20496,4160,21588,21604,21622,1100,64,3173,17524,4096,22545,69,1093,117,20528,17460,22133]

theorem envBound14163 : H12AffineFastState.Bounded env14163 := by
  intro p hp
  have h : env14163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14162_14163 : H12AffineEnvironment.transform 6 9 env14162 = env14163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14162 == env14163) = true)

theorem identity14163 : scanCanonicalize (H12AffineFastState.compose env14163 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound14163 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14164 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,1101,5236,1125,35,4096,3173,1025,1124,4160,32,16,2,1100,64,3173,4096,4096,3173,69,1093,117,1092,4160,513]

theorem envBound14164 : H12AffineFastState.Bounded env14164 := by
  intro p hp
  have h : env14164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14163_14164 : H12AffineEnvironment.transform 13 5236 env14163 = env14164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env14163 == env14164) = true)

theorem identity14164 : scanCanonicalize (H12AffineFastState.compose env14164 (packedSelected [0,1,2,3,4,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2576) := by decide +kernel

theorem selectedBound14164 : packedSelected [0,1,2,3,4,6,7] rootPS < 2^1333 := by decide +kernel

def env14165 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,2576,1101,3684,1125,35,2576,3173,1025,1124,2640,32,16,2,1100,64,3173,2576,2576,3173,69,1093,117,1092,2640,513]

theorem envBound14165 : H12AffineFastState.Bounded env14165 := by
  intro p hp
  have h : env14165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14164_14165 : H12AffineEnvironment.transform 11 2576 env14164 = env14165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2576 env14164 == env14165) = true)

theorem identity14165 : scanCanonicalize (H12AffineFastState.compose env14165 (packedSelected [1,3,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 591) := by decide +kernel

theorem selectedBound14165 : packedSelected [1,3,5,6] rootPS < 2^1333 := by decide +kernel

def env14166 : List Nat := [2,4,8,16,32,64,9,116,512,591,2048,2576,514,2091,554,35,2576,2602,590,555,2640,32,16,2,515,64,2602,2576,2576,2602,69,522,117,523,2640,513]

theorem envBound14166 : H12AffineFastState.Bounded env14166 := by
  intro p hp
  have h : env14166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14165_14166 : H12AffineEnvironment.transform 9 591 env14165 = env14166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 591 env14165 == env14166) = true)

theorem identity14166 : scanCanonicalize (H12AffineFastState.compose env14166 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound14166 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env14167 : List Nat := [2,4,8,16,32,64,9,116,80,31,2048,2112,82,2091,122,35,2112,2170,30,123,2048,32,16,2,83,64,2170,2112,2112,2170,69,90,117,91,2048,81]

theorem envBound14167 : H12AffineFastState.Bounded env14167 := by
  intro p hp
  have h : env14167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14166_14167 : H12AffineEnvironment.transform 8 80 env14166 = env14167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env14166 == env14167) = true)

theorem identity14167 : scanCanonicalize (H12AffineFastState.compose env14167 (packedSelected [0,1,2] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound14167 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env14168 : List Nat := [2,4,8,16,32,64,9,116,80,31,43,107,82,0,122,35,107,81,30,123,43,32,16,2,83,64,81,107,107,81,69,90,117,91,43,81]

theorem envBound14168 : H12AffineFastState.Bounded env14168 := by
  intro p hp
  have h : env14168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14167_14168 : H12AffineEnvironment.transform 10 43 env14167 = env14168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env14167 == env14168) = true)

theorem identity14168 : scanCanonicalize (H12AffineFastState.compose env14168 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound14168 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14169 : List Nat := [2,4,8,16,10,64,9,94,80,31,1,65,82,0,80,9,65,81,30,81,1,10,16,2,83,64,81,65,65,81,69,90,95,91,1,81]

theorem envBound14169 : H12AffineFastState.Bounded env14169 := by
  intro p hp
  have h : env14169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14168_14169 : H12AffineEnvironment.transform 4 10 env14168 = env14169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env14168 == env14169) = true)

def env14170 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4160,169401,156116,21762,8328,64,215366,115151,140484,35324,241863,243003,257,254011,197022,169744]

theorem envBound14170 : H12AffineFastState.Bounded env14170 := by
  intro p hp
  have h : env14170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14139_14170 : H12AffineEnvironment.transform 17 10281 env14139 = env14170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env14139 == env14170) = true)

def env14171 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1025,32769,4160,21929,41412,21762,8328,64,100694,115151,58580,35324,94423,95531,257,73771,115086,22272]

theorem envBound14171 : H12AffineFastState.Bounded env14171 := by
  intro p hp
  have h : env14171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14170_14171 : H12AffineEnvironment.transform 16 49168 env14170 = env14171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env14170 == env14171) = true)

theorem identity14171 : scanCanonicalize (H12AffineFastState.compose env14171 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound14171 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14172 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,38296,10281,1025,32769,4160,33,41412,138,8328,64,100694,103495,45404,35324,75103,73891,257,73771,103430,648]

theorem envBound14172 : H12AffineFastState.Bounded env14172 := by
  intro p hp
  have h : env14172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14171_14172 : H12AffineEnvironment.transform 13 5512 env14171 = env14172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env14171 == env14172) = true)

theorem identity14172 : scanCanonicalize (H12AffineFastState.compose env14172 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14172 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env14173 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,38161,10281,1025,32769,4160,33,41293,3,8193,64,100694,103495,45404,35189,75103,73770,257,73771,103430,513]

theorem envBound14173 : H12AffineFastState.Bounded env14173 := by
  intro p hp
  have h : env14173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14172_14173 : H12AffineEnvironment.transform 6 9 env14172 = env14173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14172 == env14173) = true)

theorem identity14173 : scanCanonicalize (H12AffineFastState.compose env14173 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound14173 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env14174 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8282,38161,10281,1025,32769,4160,33,41293,3,8193,64,43276,46109,45404,35189,1285,112,257,113,46172,513]

theorem envBound14174 : H12AffineFastState.Bounded env14174 := by
  intro p hp
  have h : env14174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14173_14174 : H12AffineEnvironment.transform 15 8282 env14173 = env14174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env14173 == env14174) = true)

theorem identity14174 : scanCanonicalize (H12AffineFastState.compose env14174 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound14174 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env14175 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,0,8282,5393,10281,1025,1,4160,33,8525,3,8193,64,10508,13341,12636,2421,1285,112,257,113,13404,513]

theorem envBound14175 : H12AffineFastState.Bounded env14175 := by
  intro p hp
  have h : env14175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14174_14175 : H12AffineEnvironment.transform 14 0 env14174 = env14175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env14174 == env14175) = true)

theorem identity14175 : scanCanonicalize (H12AffineFastState.compose env14175 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound14175 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env14176 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,0,343,5393,2340,1025,1,4160,33,64,3,268,64,2049,5392,4177,2421,1285,112,257,113,5457,513]

theorem envBound14176 : H12AffineFastState.Bounded env14176 := by
  intro p hp
  have h : env14176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14175_14176 : H12AffineEnvironment.transform 12 269 env14175 = env14176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env14175 == env14176) = true)

theorem identity14176 : scanCanonicalize (H12AffineFastState.compose env14176 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14176 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14177 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,0,262,5393,2340,1025,1,4113,33,17,3,268,17,2049,5392,4096,2340,1285,33,257,32,5376,513]

theorem envBound14177 : H12AffineFastState.Bounded env14177 := by
  intro p hp
  have h : env14177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14176_14177 : H12AffineEnvironment.transform 5 17 env14176 = env14177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14176 == env14177) = true)

theorem identity14177 : scanCanonicalize (H12AffineFastState.compose env14177 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound14177 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14178 : List Nat := [2,4,8,16,32,17,9,20,512,1024,2048,4096,25,5141,0,18,5125,2096,1025,1,4113,33,17,3,24,17,2049,5124,4096,2096,1041,33,21,32,5140,513]

theorem envBound14178 : H12AffineFastState.Bounded env14178 := by
  intro p hp
  have h : env14178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14177_14178 : H12AffineEnvironment.transform 7 20 env14177 = env14178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env14177 == env14178) = true)

theorem identity14178 : scanCanonicalize (H12AffineFastState.compose env14178 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3119) := by decide +kernel

theorem selectedBound14178 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14179 : List Nat := [2,4,8,16,32,17,9,20,512,1024,2048,3119,25,2106,0,18,2090,2096,1025,1,3134,33,17,3,24,17,2049,2091,3119,2096,1041,33,21,32,2107,513]

theorem envBound14179 : H12AffineFastState.Bounded env14179 := by
  intro p hp
  have h : env14179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14178_14179 : H12AffineEnvironment.transform 11 3119 env14178 = env14179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3119 env14178 == env14179) = true)

theorem identity14179 : scanCanonicalize (H12AffineFastState.compose env14179 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound14179 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14180 : List Nat := [2,4,8,16,32,17,9,20,17,1024,2048,3119,25,2106,0,18,2090,2096,1025,1,3134,33,17,3,24,17,2049,2091,3119,2096,1041,33,21,32,2107,16]

theorem envBound14180 : H12AffineFastState.Bounded env14180 := by
  intro p hp
  have h : env14180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14179_14180 : H12AffineEnvironment.transform 8 17 env14179 = env14180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env14179 == env14180) = true)

theorem identity14180 : scanCanonicalize (H12AffineFastState.compose env14180 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1029) := by decide +kernel

theorem selectedBound14180 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env14181 : List Nat := [2,4,8,16,32,17,9,20,17,1024,1029,42,25,1087,0,18,1071,1077,1025,1,59,33,17,3,24,17,1028,1070,42,1077,1041,33,21,32,1086,16]

theorem envBound14181 : H12AffineFastState.Bounded env14181 := by
  intro p hp
  have h : env14181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14180_14181 : H12AffineEnvironment.transform 10 1029 env14180 = env14181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1029 env14180 == env14181) = true)

theorem identity14181 : scanCanonicalize (H12AffineFastState.compose env14181 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound14181 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14182 : List Nat := [2,4,8,16,10,17,9,20,17,1024,1029,0,25,1045,0,18,1029,1055,1025,1,17,11,17,3,24,17,1028,1028,0,1055,1041,11,21,10,1044,16]

theorem envBound14182 : H12AffineFastState.Bounded env14182 := by
  intro p hp
  have h : env14182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14181_14182 : H12AffineEnvironment.transform 4 10 env14181 = env14182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env14181 == env14182) = true)

theorem identity14182 : scanCanonicalize (H12AffineFastState.compose env14182 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound14182 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env14183 : List Nat := [2,4,8,16,10,17,9,20,17,14,11,0,25,27,0,18,11,17,15,1,17,11,17,3,24,17,10,10,0,17,31,11,21,10,26,16]

theorem envBound14183 : H12AffineFastState.Bounded env14183 := by
  intro p hp
  have h : env14183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14182_14183 : H12AffineEnvironment.transform 9 14 env14182 = env14183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env14182 == env14183) = true)

theorem identity14183 : scanCanonicalize (H12AffineFastState.compose env14183 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound14183 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14184 : List Nat := [2,4,8,14,10,15,9,10,15,14,11,0,7,5,0,12,11,15,15,1,15,11,15,3,6,15,10,10,0,15,1,11,11,10,4,14]

theorem envBound14184 : H12AffineFastState.Bounded env14184 := by
  intro p hp
  have h : env14184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14183_14184 : H12AffineEnvironment.transform 3 14 env14183 = env14184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env14183 == env14184) = true)

theorem identity14184 : scanCanonicalize (H12AffineFastState.compose env14184 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound14184 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14185 : List Nat := [0,4,8,12,8,13,9,8,13,12,9,0,5,5,0,12,9,13,13,1,13,9,13,1,4,13,8,8,0,13,1,9,9,8,4,12]

theorem envBound14185 : H12AffineFastState.Bounded env14185 := by
  intro p hp
  have h : env14185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14184_14185 : H12AffineEnvironment.transform 0 0 env14184 = env14185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env14184 == env14185) = true)

theorem identity14185 : scanCanonicalize (H12AffineFastState.compose env14185 (packedSelected [9] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound14185 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env14186 : List Nat := [0,4,0,4,0,5,1,0,5,4,1,0,5,5,0,4,1,5,5,1,5,1,5,1,4,5,0,0,0,5,1,1,1,0,4,4]

theorem envBound14186 : H12AffineFastState.Bounded env14186 := by
  intro p hp
  have h : env14186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14185_14186 : H12AffineEnvironment.transform 2 0 env14185 = env14186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env14185 == env14186) = true)

def env14187 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1025,32769,4160,21928,41413,21762,8328,64,100695,115151,58581,35324,94422,95530,257,73770,115087,22273]

theorem envBound14187 : H12AffineFastState.Bounded env14187 := by
  intro p hp
  have h : env14187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14170_14187 : H12AffineEnvironment.transform 16 49169 env14170 = env14187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env14170 == env14187) = true)

theorem identity14187 : scanCanonicalize (H12AffineFastState.compose env14187 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound14187 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14188 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,38161,10281,1025,32769,4160,168,41413,2,8328,64,100695,103631,45525,35324,75222,73770,257,73770,103567,513]

theorem envBound14188 : H12AffineFastState.Bounded env14188 := by
  intro p hp
  have h : env14188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14187_14188 : H12AffineEnvironment.transform 13 5376 env14187 = env14188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env14187 == env14188) = true)

theorem identity14188 : scanCanonicalize (H12AffineFastState.compose env14188 (packedSelected [0,1,5,7,8,11,16,18,24] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound14188 : packedSelected [0,1,5,7,8,11,16,18,24] rootPS < 2^1333 := by decide +kernel

def env14189 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,398,38161,10281,1025,32769,4160,168,41413,2,8328,64,35033,38209,45525,35324,9304,8612,257,8612,38145,513]

theorem envBound14189 : H12AffineFastState.Bounded env14189 := by
  intro p hp
  have h : env14189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14188_14189 : H12AffineEnvironment.transform 15 398 env14188 = env14189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env14188 == env14189) = true)

theorem identity14189 : scanCanonicalize (H12AffineFastState.compose env14189 (packedSelected [1,2,3,5,6,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound14189 : packedSelected [1,2,3,5,6,8,10,19] rootPS < 2^1333 := by decide +kernel

def env14190 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,81,398,5440,10281,1025,80,4160,168,8596,2,8328,64,2184,5392,12676,2477,9304,8612,257,8612,5456,513]

theorem envBound14190 : H12AffineFastState.Bounded env14190 := by
  intro p hp
  have h : env14190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14189_14190 : H12AffineEnvironment.transform 14 81 env14189 = env14190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env14189 == env14190) = true)

theorem identity14190 : scanCanonicalize (H12AffineFastState.compose env14190 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound14190 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env14191 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,81,398,5440,2557,1025,80,4160,168,64,2,348,64,2184,5392,4176,2477,1420,112,257,112,5456,513]

theorem envBound14191 : H12AffineFastState.Bounded env14191 := by
  intro p hp
  have h : env14191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14190_14191 : H12AffineEnvironment.transform 12 468 env14190 = env14191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env14190 == env14191) = true)

theorem identity14191 : scanCanonicalize (H12AffineFastState.compose env14191 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14191 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env14192 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5376,1,398,5392,2477,1025,0,4112,168,16,2,268,16,2184,5392,4096,2477,1420,32,257,32,5376,513]

theorem envBound14192 : H12AffineFastState.Bounded env14192 := by
  intro p hp
  have h : env14192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14191_14192 : H12AffineEnvironment.transform 5 16 env14191 = env14192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14191 == env14192) = true)

theorem identity14192 : scanCanonicalize (H12AffineFastState.compose env14192 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound14192 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env14193 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,388,4113,1,398,4097,2477,272,0,4112,168,16,2,268,16,2184,4097,4096,2477,157,32,257,32,4113,513]

theorem envBound14193 : H12AffineFastState.Bounded env14193 := by
  intro p hp
  have h : env14193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14192_14193 : H12AffineEnvironment.transform 9 273 env14192 = env14193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env14192 == env14193) = true)

theorem identity14193 : scanCanonicalize (H12AffineFastState.compose env14193 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14193 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14194 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,269,4113,1,263,4097,2340,272,0,4112,33,16,2,268,16,2049,4097,4096,2340,20,32,257,32,4113,513]

theorem envBound14194 : H12AffineFastState.Bounded env14194 := by
  intro p hp
  have h : env14194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14193_14194 : H12AffineEnvironment.transform 6 9 env14193 = env14194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14193 == env14194) = true)

theorem identity14194 : scanCanonicalize (H12AffineFastState.compose env14194 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound14194 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14195 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,16,269,1,1,263,17,2340,272,0,0,33,16,2,268,16,2049,17,16,2340,20,32,257,32,1,513]

theorem envBound14195 : H12AffineFastState.Bounded env14195 := by
  intro p hp
  have h : env14195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14194_14195 : H12AffineEnvironment.transform 11 16 env14194 = env14195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env14194 == env14195) = true)

def env14196 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441745,156116,21763,8328,64,215366,115151,140485,303573,241862,498963,257,254011,197022,169745]

theorem envBound14196 : H12AffineFastState.Bounded env14196 := by
  intro p hp
  have h : env14196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14138_14196 : H12AffineEnvironment.transform 20 4161 env14138 = env14196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env14138 == env14196) = true)

theorem identity14196 : scanCanonicalize (H12AffineFastState.compose env14196 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound14196 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4161,272513,62660,21763,8328,64,121942,115151,45525,303573,75222,329731,257,95531,103566,513]

theorem envBound14197 : H12AffineFastState.Bounded env14197 := by
  intro p hp
  have h : env14197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14196_14197 : H12AffineEnvironment.transform 16 38160 env14196 = env14197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env14196 == env14197) = true)

def env14198 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1025,32769,4161,169,62660,21763,8328,64,121942,115151,45525,35325,75222,73771,257,95531,103566,513]

theorem envBound14198 : H12AffineFastState.Bounded env14198 := by
  intro p hp
  have h : env14198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14197_14198 : H12AffineEnvironment.transform 17 10280 env14197 = env14198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env14197 == env14198) = true)

theorem identity14198 : scanCanonicalize (H12AffineFastState.compose env14198 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound14198 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env14199 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62730,38160,10280,1025,32769,4161,169,62660,21763,8328,64,10588,13509,45525,35325,53468,54561,257,32801,24964,513]

theorem envBound14199 : H12AffineFastState.Bounded env14199 := by
  intro p hp
  have h : env14199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14198_14199 : H12AffineEnvironment.transform 15 62730 env14198 = env14199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env14198 == env14199) = true)

theorem identity14199 : scanCanonicalize (H12AffineFastState.compose env14199 (packedSelected [2,4,6,7,8,9,10,11,17,27,28,32] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound14199 : packedSelected [2,4,6,7,8,9,10,11,17,27,28,32] rootPS < 2^1333 := by decide +kernel

def env14200 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,16384,32768,61515,36945,10280,320,32769,4161,169,61829,20546,8328,64,10588,12676,45525,35325,53468,53344,257,32801,24964,513]

theorem envBound14200 : H12AffineFastState.Bounded env14200 := by
  intro p hp
  have h : env14200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14199_14200 : H12AffineEnvironment.transform 9 321 env14199 = env14200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env14199 == env14200) = true)

theorem identity14200 : scanCanonicalize (H12AffineFastState.compose env14200 (packedSelected [7,8,10,11,14,18,20,27,28] rootPS)) = affineNative (2^(13+1) ^^^ 4541) := by decide +kernel

theorem selectedBound14200 : packedSelected [7,8,10,11,14,18,20,27,28] rootPS < 2^1333 := by decide +kernel

def env14201 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,4541,32768,41462,36945,10280,320,32769,4161,169,41016,511,8328,64,10588,12676,45525,35325,33121,33245,257,32801,12345,513]

theorem envBound14201 : H12AffineFastState.Bounded env14201 := by
  intro p hp
  have h : env14201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14200_14201 : H12AffineEnvironment.transform 13 4541 env14200 = env14201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4541 env14200 == env14201) = true)

theorem identity14201 : scanCanonicalize (H12AffineFastState.compose env14201 (packedSelected [0,1,5,7,8,11,12,15,17,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 216) := by decide +kernel

theorem selectedBound14201 : packedSelected [0,1,5,7,8,11,12,15,17,20,23,24] rootPS < 2^1333 := by decide +kernel

def env14202 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,4541,216,8494,4233,10280,320,217,4161,169,8416,511,8328,64,10588,12676,12557,2341,441,261,257,249,12345,513]

theorem envBound14202 : H12AffineFastState.Bounded env14202 := by
  intro p hp
  have h : env14202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14201_14202 : H12AffineEnvironment.transform 14 216 env14201 = env14202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 216 env14201 == env14202) = true)

theorem identity14202 : scanCanonicalize (H12AffineFastState.compose env14202 (packedSelected [4,9,12,14,15,20] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound14202 : packedSelected [4,9,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env14203 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,469,4541,216,251,4233,2557,320,217,4161,169,309,511,349,64,2185,4177,4312,2341,441,261,257,249,4588,513]

theorem envBound14203 : H12AffineFastState.Bounded env14203 := by
  intro p hp
  have h : env14203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14202_14203 : H12AffineEnvironment.transform 12 469 env14202 = env14203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env14202 == env14203) = true)

theorem identity14203 : scanCanonicalize (H12AffineFastState.compose env14203 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14203 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env14204 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,348,4404,81,114,4096,2420,320,80,4161,32,309,374,349,64,2048,4177,4177,2341,304,261,257,112,4453,513]

theorem envBound14204 : H12AffineFastState.Bounded env14204 := by
  intro p hp
  have h : env14204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14203_14204 : H12AffineEnvironment.transform 6 9 env14203 = env14204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14203 == env14204) = true)

theorem identity14204 : scanCanonicalize (H12AffineFastState.compose env14204 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound14204 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env14205 : List Nat := [2,4,8,16,32,64,9,36,512,101,2048,4096,120,4112,81,114,4096,2128,100,80,4161,32,17,82,121,64,2048,4177,4177,2049,20,33,37,112,4161,513]

theorem envBound14205 : H12AffineFastState.Bounded env14205 := by
  intro p hp
  have h : env14205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14204_14205 : H12AffineEnvironment.transform 7 36 env14204 = env14205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env14204 == env14205) = true)

theorem identity14205 : scanCanonicalize (H12AffineFastState.compose env14205 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound14205 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14206 : List Nat := [2,4,8,16,32,64,9,36,512,101,2048,81,120,65,81,114,81,2128,100,80,16,32,17,82,121,64,2048,0,0,2049,20,33,37,112,16,513]

theorem envBound14206 : H12AffineFastState.Bounded env14206 := by
  intro p hp
  have h : env14206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14205_14206 : H12AffineEnvironment.transform 11 81 env14205 = env14206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env14205 == env14206) = true)

theorem identity14206 : scanCanonicalize (H12AffineFastState.compose env14206 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound14206 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env14207 : List Nat := [2,4,8,16,32,64,9,36,0,101,2048,81,120,65,81,114,81,2128,100,80,16,32,17,82,121,64,2048,0,0,2049,20,33,37,112,16,1]

theorem envBound14207 : H12AffineFastState.Bounded env14207 := by
  intro p hp
  have h : env14207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14206_14207 : H12AffineEnvironment.transform 8 0 env14206 = env14207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env14206 == env14207) = true)

theorem identity14207 : scanCanonicalize (H12AffineFastState.compose env14207 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound14207 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env14208 : List Nat := [2,4,8,16,17,64,9,21,0,84,2048,81,73,65,81,67,81,2128,85,80,16,17,17,82,72,64,2048,0,0,2049,20,16,20,65,16,1]

theorem envBound14208 : H12AffineFastState.Bounded env14208 := by
  intro p hp
  have h : env14208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14207_14208 : H12AffineEnvironment.transform 4 17 env14207 = env14208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env14207 == env14208) = true)

theorem identity14208 : scanCanonicalize (H12AffineFastState.compose env14208 (packedSelected [1,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound14208 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env14209 : List Nat := [2,4,8,1,0,64,9,4,0,69,2048,64,73,65,64,67,64,2113,68,65,1,0,0,67,72,64,2048,0,0,2049,5,1,5,65,1,1]

theorem envBound14209 : H12AffineFastState.Bounded env14209 := by
  intro p hp
  have h : env14209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14208_14209 : H12AffineEnvironment.transform 3 1 env14208 = env14209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env14208 == env14209) = true)

theorem identity14209 : scanCanonicalize (H12AffineFastState.compose env14209 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound14209 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14210 : List Nat := [2,4,8,1,0,0,9,4,0,5,2048,0,9,1,0,3,0,2049,4,1,1,0,0,3,8,0,2048,0,0,2049,5,1,5,1,1,1]

theorem envBound14210 : H12AffineFastState.Bounded env14210 := by
  intro p hp
  have h : env14210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14209_14210 : H12AffineEnvironment.transform 5 0 env14209 = env14210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env14209 == env14210) = true)

def env14211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1025,32769,4161,168,62660,21763,8328,64,121942,115151,45525,35324,75222,73770,257,95531,103566,513]

theorem envBound14211 : H12AffineFastState.Bounded env14211 := by
  intro p hp
  have h : env14211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14197_14211 : H12AffineEnvironment.transform 17 10281 env14197 = env14211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env14197 == env14211) = true)

theorem identity14211 : scanCanonicalize (H12AffineFastState.compose env14211 (packedSelected [0,1,2,3,4,5,6,11,14,17,19,20,22,27,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 41171) := by decide +kernel

theorem selectedBound14211 : packedSelected [0,1,2,3,4,5,6,11,14,17,19,20,22,27,28,32] rootPS < 2^1333 := by decide +kernel

def env14212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,41171,38160,10281,1025,32769,4161,168,62660,21763,8328,64,31877,24860,45525,35324,34053,33017,257,54776,13405,513]

theorem envBound14212 : H12AffineFastState.Bounded env14212 := by
  intro p hp
  have h : env14212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14211_14212 : H12AffineEnvironment.transform 15 41171 env14211 = env14212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41171 env14211 == env14212) = true)

theorem identity14212 : scanCanonicalize (H12AffineFastState.compose env14212 (packedSelected [1,3,4,8,10,11,17,20,22,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound14212 : packedSelected [1,3,4,8,10,11,17,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env14213 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13325,32768,41171,38160,10281,1025,32769,4161,168,32969,8462,8328,64,2184,5393,45525,35324,34053,33017,257,41461,13405,513]

theorem envBound14213 : H12AffineFastState.Bounded env14213 := by
  intro p hp
  have h : env14213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14212_14213 : H12AffineEnvironment.transform 13 13325 env14212 = env14213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env14212 == env14213) = true)

theorem identity14213 : scanCanonicalize (H12AffineFastState.compose env14213 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound14213 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env14214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5593,32768,33031,38160,2557,1025,32769,4161,168,32969,218,348,64,2184,5393,36865,35324,34053,33017,257,32801,5513,513]

theorem envBound14214 : H12AffineFastState.Bounded env14214 := by
  intro p hp
  have h : env14214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14213_14214 : H12AffineEnvironment.transform 12 468 env14213 = env14214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env14213 == env14214) = true)

theorem identity14214 : scanCanonicalize (H12AffineFastState.compose env14214 (packedSelected [0,3,4,5,7,9,10,11,14,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound14214 : packedSelected [0,3,4,5,7,9,10,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env14215 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5593,1,262,5393,2557,1025,0,4161,168,200,218,348,64,2184,5393,4096,2557,1284,248,257,32,5513,513]

theorem envBound14215 : H12AffineFastState.Bounded env14215 := by
  intro p hp
  have h : env14215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14214_14215 : H12AffineEnvironment.transform 14 1 env14214 = env14215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env14214 == env14215) = true)

def env14216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2534865,156116,2114882,8328,64,215367,115151,2241668,303573,2334855,2592083,257,254011,197022,2262864]

theorem envBound14216 : H12AffineFastState.Bounded env14216 := by
  intro p hp
  have h : env14216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14137_14216 : H12AffineEnvironment.transform 21 2534865 env14137 = env14216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2534865 env14137 == env14216) = true)

def env14217 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441745,156116,21762,8328,64,215367,115151,140484,303573,241863,498963,257,254011,197022,169744]

theorem envBound14217 : H12AffineFastState.Bounded env14217 := by
  intro p hp
  have h : env14217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14216_14217 : H12AffineEnvironment.transform 20 4160 env14216 = env14217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env14216 == env14217) = true)

theorem identity14217 : scanCanonicalize (H12AffineFastState.compose env14217 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 25029) := by decide +kernel

theorem selectedBound14217 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14218 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,4160,318548,17,21762,8328,64,75906,115151,17665,303573,119042,392406,257,98814,90203,63189]

theorem envBound14218 : H12AffineFastState.Bounded env14218 := by
  intro p hp
  have h : env14218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14217_14218 : H12AffineEnvironment.transform 16 25029 env14217 = env14218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env14217 == env14218) = true)

def env14219 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4160,318548,17,21762,8192,64,75786,115015,17665,303453,119042,392286,257,98678,90203,63069]

theorem envBound14219 : H12AffineFastState.Bounded env14219 := by
  intro p hp
  have h : env14219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14218_14219 : H12AffineEnvironment.transform 6 8 env14218 = env14219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14218 == env14219) = true)

theorem identity14219 : scanCanonicalize (H12AffineFastState.compose env14219 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound14219 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14220 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,32041,1025,32769,4160,41341,17,21762,8192,64,75786,115015,17665,56436,119042,98679,257,98678,90203,63069]

theorem envBound14220 : H12AffineFastState.Bounded env14220 := by
  intro p hp
  have h : env14220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14219_14220 : H12AffineEnvironment.transform 17 32041 env14219 = env14220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env14219 == env14220) = true)

theorem identity14220 : scanCanonicalize (H12AffineFastState.compose env14220 (packedSelected [1,3,4,8,9,10,11,12,14,15,16,19,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 30073) := by decide +kernel

theorem selectedBound14220 : packedSelected [1,3,4,8,9,10,11,12,14,15,16,19,24,26,32] rootPS < 2^1333 := by decide +kernel

def env14221 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,30073,65536,24909,32041,1025,30072,4160,21508,17,21762,8192,64,75786,78910,17665,10509,74875,95246,257,95247,90203,804]

theorem envBound14221 : H12AffineFastState.Bounded env14221 := by
  intro p hp
  have h : env14221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14220_14221 : H12AffineEnvironment.transform 14 30073 env14220 = env14221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30073 env14220 == env14221) = true)

theorem identity14221 : scanCanonicalize (H12AffineFastState.compose env14221 (packedSelected [0,2,4,6,7,9,11,14,16,19,20,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound14221 : packedSelected [0,2,4,6,7,9,11,14,16,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env14222 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,30073,29962,24909,32041,1025,30072,4160,21508,17,21762,8192,64,23808,16692,17665,10509,20849,260,257,261,5457,804]

theorem envBound14222 : H12AffineFastState.Bounded env14222 := by
  intro p hp
  have h : env14222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14221_14222 : H12AffineEnvironment.transform 15 29962 env14221 = env14222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env14221 == env14222) = true)

def env14223 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4160,318548,17,21762,8193,64,75787,115014,17665,303452,119042,392287,257,98679,90203,63068]

theorem envBound14223 : H12AffineFastState.Bounded env14223 := by
  intro p hp
  have h : env14223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14218_14223 : H12AffineEnvironment.transform 6 9 env14218 = env14223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14218 == env14223) = true)

theorem identity14223 : scanCanonicalize (H12AffineFastState.compose env14223 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound14223 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14224 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,56436,1025,32769,4160,32,17,21762,8193,64,75787,115014,17665,32040,119042,73771,257,98679,90203,63068]

theorem envBound14224 : H12AffineFastState.Bounded env14224 := by
  intro p hp
  have h : env14224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14223_14224 : H12AffineEnvironment.transform 17 56436 env14223 = env14224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env14223 == env14224) = true)

theorem identity14224 : scanCanonicalize (H12AffineFastState.compose env14224 (packedSelected [0,3,7,11,12,14,16,20,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14224 : packedSelected [0,3,7,11,12,14,16,20,24] rootPS < 2^1333 := by decide +kernel

def env14225 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,24860,56356,1025,32769,4112,32,17,21762,8193,16,75787,114966,17665,32040,119042,73771,257,98599,90123,62988]

theorem envBound14225 : H12AffineFastState.Bounded env14225 := by
  intro p hp
  have h : env14225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14224_14225 : H12AffineEnvironment.transform 5 16 env14224 = env14225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14224 == env14225) = true)

theorem identity14225 : scanCanonicalize (H12AffineFastState.compose env14225 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound14225 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env14226 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,21760,65536,24860,2340,1025,21761,4112,32,17,21762,8193,16,75787,70678,17665,32040,66562,73771,257,87079,90123,8972]

theorem envBound14226 : H12AffineFastState.Bounded env14226 := by
  intro p hp
  have h : env14226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14225_14226 : H12AffineEnvironment.transform 14 21760 env14225 = env14226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env14225 == env14226) = true)

theorem identity14226 : scanCanonicalize (H12AffineFastState.compose env14226 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound14226 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env14227 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,21760,29963,24860,2340,1025,21761,4112,32,17,21762,8193,16,23808,24861,17665,32040,28937,21792,257,8492,5376,8972]

theorem envBound14227 : H12AffineFastState.Bounded env14227 := by
  intro p hp
  have h : env14227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14226_14227 : H12AffineEnvironment.transform 15 29963 env14226 = env14227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env14226 == env14227) = true)

theorem identity14227 : scanCanonicalize (H12AffineFastState.compose env14227 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound14227 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env14228 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,8461,262,5393,2340,1025,8460,4112,32,17,8463,8193,16,10509,5392,12556,2341,1284,8493,257,8492,5376,8972]

theorem envBound14228 : H12AffineFastState.Bounded env14228 := by
  intro p hp
  have h : env14228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14227_14228 : H12AffineEnvironment.transform 13 13325 env14227 = env14228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env14227 == env14228) = true)

theorem identity14228 : scanCanonicalize (H12AffineFastState.compose env14228 (packedSelected [4,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound14228 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env14229 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,4096,8192,12344,8461,262,4388,2340,52,8460,4112,32,17,8463,8193,16,10509,4389,12556,2341,305,8493,257,8492,4405,8972]

theorem envBound14229 : H12AffineFastState.Bounded env14229 := by
  intro p hp
  have h : env14229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14228_14229 : H12AffineEnvironment.transform 9 53 env14228 = env14229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env14228 == env14229) = true)

theorem identity14229 : scanCanonicalize (H12AffineFastState.compose env14229 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound14229 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env14230 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,8192,12344,8232,35,4097,2049,52,8233,4112,32,17,8234,8193,16,10280,4096,12329,2048,20,8200,36,8201,4112,8745]

theorem envBound14230 : H12AffineFastState.Bounded env14230 := by
  intro p hp
  have h : env14230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14229_14230 : H12AffineEnvironment.transform 7 37 env14229 = env14230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env14229 == env14230) = true)

theorem identity14230 : scanCanonicalize (H12AffineFastState.compose env14230 (packedSelected [1,2,8] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound14230 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env14231 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,40,4112,0,35,4097,2049,52,1,4112,32,17,2,41,16,2048,4096,4097,2048,20,32,36,33,4112,513]

theorem envBound14231 : H12AffineFastState.Bounded env14231 := by
  intro p hp
  have h : env14231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14230_14231 : H12AffineEnvironment.transform 12 40 env14230 = env14231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env14230 == env14231) = true)

theorem identity14231 : scanCanonicalize (H12AffineFastState.compose env14231 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound14231 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14232 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,2048,40,2064,0,35,2049,2049,52,1,2064,32,17,2,41,16,2048,2048,2049,2048,20,32,36,33,2064,513]

theorem envBound14232 : H12AffineFastState.Bounded env14232 := by
  intro p hp
  have h : env14232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14231_14232 : H12AffineEnvironment.transform 11 2048 env14231 = env14232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env14231 == env14232) = true)

theorem identity14232 : scanCanonicalize (H12AffineFastState.compose env14232 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound14232 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14233 : List Nat := [2,4,8,16,27,16,9,30,512,14,2048,2048,19,2064,0,24,2049,2049,15,1,2064,27,17,2,18,16,2048,2048,2049,2048,20,27,31,26,2064,513]

theorem envBound14233 : H12AffineFastState.Bounded env14233 := by
  intro p hp
  have h : env14233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14232_14233 : H12AffineEnvironment.transform 4 27 env14232 = env14233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env14232 == env14233) = true)

theorem identity14233 : scanCanonicalize (H12AffineFastState.compose env14233 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound14233 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14234 : List Nat := [2,4,8,16,27,16,9,30,512,14,17,17,19,1,0,24,16,16,15,1,1,27,17,2,18,16,17,17,16,17,20,27,31,26,1,513]

theorem envBound14234 : H12AffineFastState.Bounded env14234 := by
  intro p hp
  have h : env14234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14233_14234 : H12AffineEnvironment.transform 10 17 env14233 = env14234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env14233 == env14234) = true)

theorem identity14234 : scanCanonicalize (H12AffineFastState.compose env14234 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound14234 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14235 : List Nat := [2,4,8,1,10,1,9,15,512,14,0,0,2,1,0,9,1,1,15,1,1,10,0,2,3,1,0,0,1,0,5,10,14,11,1,513]

theorem envBound14235 : H12AffineFastState.Bounded env14235 := by
  intro p hp
  have h : env14235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14234_14235 : H12AffineEnvironment.transform 3 1 env14234 = env14235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env14234 == env14235) = true)

def env14236 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441744,156116,21763,8328,64,215367,115151,140485,303573,241862,498962,257,254011,197022,169745]

theorem envBound14236 : H12AffineFastState.Bounded env14236 := by
  intro p hp
  have h : env14236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14216_14236 : H12AffineEnvironment.transform 20 4161 env14216 = env14236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env14216 == env14236) = true)

theorem identity14236 : scanCanonicalize (H12AffineFastState.compose env14236 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound14236 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14237 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,4161,411973,156116,21763,8328,64,215367,79130,140485,283904,214035,485831,257,201966,197022,156612]

theorem envBound14237 : H12AffineFastState.Bounded env14237 := by
  intro p hp
  have h : env14237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14236_14237 : H12AffineEnvironment.transform 14 29909 env14236 = env14237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env14236 == env14237) = true)

def env14238 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,262144,1025,29828,4113,411925,156036,21763,8328,16,215319,79130,140437,283904,214035,485783,257,201918,197022,156564]

theorem envBound14238 : H12AffineFastState.Bounded env14238 := by
  intro p hp
  have h : env14238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14237_14238 : H12AffineEnvironment.transform 5 16 env14237 = env14238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14237 == env14238) = true)

theorem identity14238 : scanCanonicalize (H12AffineFastState.compose env14238 (packedSelected [1,3,12,17,24,28,41] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound14238 : packedSelected [1,3,12,17,24,28,41] rootPS < 2^1333 := by decide +kernel

def env14239 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,24860,262144,1025,29828,4113,272393,152,21763,8328,16,75787,79130,17801,283904,75023,329867,257,95650,90242,648]

theorem envBound14239 : H12AffineFastState.Bounded env14239 := by
  intro p hp
  have h : env14239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14238_14239 : H12AffineEnvironment.transform 16 24860 env14238 = env14239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env14238 == env14239) = true)

theorem identity14239 : scanCanonicalize (H12AffineFastState.compose env14239 (packedSelected [16,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound14239 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env14240 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,29963,24860,262144,1025,29828,4113,272393,152,21763,8328,16,23808,16401,17801,283904,20484,294272,257,169,5513,648]

theorem envBound14240 : H12AffineFastState.Bounded env14240 := by
  intro p hp
  have h : env14240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14239_14240 : H12AffineEnvironment.transform 15 29963 env14239 = env14240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env14239 == env14240) = true)

theorem identity14240 : scanCanonicalize (H12AffineFastState.compose env14240 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound14240 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env14241 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,29963,24860,10281,1025,29828,4113,32,152,21763,8328,16,23808,16401,17801,32041,20484,21929,257,169,5513,648]

theorem envBound14241 : H12AffineFastState.Bounded env14241 := by
  intro p hp
  have h : env14241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14240_14241 : H12AffineEnvironment.transform 17 10281 env14240 = env14241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env14240 == env14241) = true)

theorem identity14241 : scanCanonicalize (H12AffineFastState.compose env14241 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 13444) := by decide +kernel

theorem selectedBound14241 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env14242 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13444,1,399,5528,10281,1025,0,4113,32,152,8583,8328,16,10628,13461,12557,2477,9344,8493,257,169,5513,648]

theorem envBound14242 : H12AffineFastState.Bounded env14242 := by
  intro p hp
  have h : env14242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14241_14242 : H12AffineEnvironment.transform 13 13444 env14241 = env14242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13444 env14241 == env14242) = true)

theorem identity14242 : scanCanonicalize (H12AffineFastState.compose env14242 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound14242 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14243 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5377,1,399,5528,2476,1025,0,4113,32,152,2,269,16,2049,5392,4232,2477,1285,168,257,169,5513,648]

theorem envBound14243 : H12AffineFastState.Bounded env14243 := by
  intro p hp
  have h : env14243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14242_14243 : H12AffineEnvironment.transform 12 389 env14242 = env14243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env14242 == env14243) = true)

theorem identity14243 : scanCanonicalize (H12AffineFastState.compose env14243 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound14243 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env14244 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,300,5377,1,294,5425,2309,1025,0,4113,32,49,2,269,16,2049,5392,4129,2308,1285,1,257,0,5408,545]

theorem envBound14244 : H12AffineFastState.Bounded env14244 := by
  intro p hp
  have h : env14244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14243_14244 : H12AffineEnvironment.transform 6 41 env14243 = env14244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env14243 == env14244) = true)

theorem identity14244 : scanCanonicalize (H12AffineFastState.compose env14244 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14244 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14245 : List Nat := [2,4,8,16,1,16,8,256,512,1024,2048,4096,269,5377,1,263,5392,2309,1025,0,4113,1,16,2,269,16,2049,5392,4096,2308,1285,1,257,0,5377,512]

theorem envBound14245 : H12AffineFastState.Bounded env14245 := by
  intro p hp
  have h : env14245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14244_14245 : H12AffineEnvironment.transform 4 1 env14244 = env14245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14244 == env14245) = true)

theorem identity14245 : scanCanonicalize (H12AffineFastState.compose env14245 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14245 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14246 : List Nat := [2,4,8,16,1,16,8,5,512,1024,2048,4096,8,5124,1,2,5141,2048,1025,0,4113,1,16,2,8,16,2049,5141,4096,2049,1024,1,4,0,5124,512]

theorem envBound14246 : H12AffineFastState.Bounded env14246 := by
  intro p hp
  have h : env14246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14245_14246 : H12AffineEnvironment.transform 7 5 env14245 = env14246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14245 == env14246) = true)

def env14247 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,262144,1025,29829,4112,411924,156037,21763,8328,17,215318,79130,140436,283904,214035,485782,257,201919,197022,156565]

theorem envBound14247 : H12AffineFastState.Bounded env14247 := by
  intro p hp
  have h : env14247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14237_14247 : H12AffineEnvironment.transform 5 17 env14237 = env14247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14237 == env14247) = true)

theorem identity14247 : scanCanonicalize (H12AffineFastState.compose env14247 (packedSelected [1,3,12,17,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 149812) := by decide +kernel

theorem selectedBound14247 : packedSelected [1,3,12,17,24,28,41] rootPS < 2^1333 := by decide +kernel

def env14248 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,149812,1025,29829,4112,32,156037,21763,8328,17,215318,79130,140436,138292,214035,73890,257,201919,197022,156565]

theorem envBound14248 : H12AffineFastState.Bounded env14248 := by
  intro p hp
  have h : env14248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14247_14248 : H12AffineEnvironment.transform 17 149812 env14247 = env14248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149812 env14247 == env14248) = true)

theorem identity14248 : scanCanonicalize (H12AffineFastState.compose env14248 (packedSelected [0,3,4,5,7,9,12,16,17,18,19] rootPS)) = affineNative (2^(16+1) ^^^ 82199) := by decide +kernel

theorem selectedBound14248 : packedSelected [0,3,4,5,7,9,12,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env14249 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,82199,67619,1025,29829,4112,32,73874,21763,8328,17,2049,79130,91523,89379,1284,73890,257,21928,16521,74370]

theorem envBound14249 : H12AffineFastState.Bounded env14249 := by
  intro p hp
  have h : env14249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14248_14249 : H12AffineEnvironment.transform 16 82199 env14248 = env14249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82199 env14248 == env14249) = true)

theorem identity14249 : scanCanonicalize (H12AffineFastState.compose env14249 (packedSelected [0,1,2,3,5,6,7,8,9,12,17,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound14249 : packedSelected [0,1,2,3,5,6,7,8,9,12,17,18,22] rootPS < 2^1333 := by decide +kernel

def env14250 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,16384,21760,65536,82199,67619,1025,21761,4112,32,65814,21763,268,17,2049,70814,82951,89379,1284,65830,257,21928,16521,66310]

theorem envBound14250 : H12AffineFastState.Bounded env14250 := by
  intro p hp
  have h : env14250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14249_14250 : H12AffineEnvironment.transform 12 388 env14249 = env14250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env14249 == env14250) = true)

theorem identity14250 : scanCanonicalize (H12AffineFastState.compose env14250 (packedSelected [0,2,3,5,6,7,10,16,17] rootPS)) = affineNative (2^(15+1) ^^^ 21647) := by decide +kernel

theorem selectedBound14250 : packedSelected [0,2,3,5,6,7,10,16,17] rootPS < 2^1333 := by decide +kernel

def env14251 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,16384,21760,21647,5528,23724,1025,21761,4112,32,21913,21763,268,17,2049,16401,4232,2476,1284,21929,257,21928,16521,22409]

theorem envBound14251 : H12AffineFastState.Bounded env14251 := by
  intro p hp
  have h : env14251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14250_14251 : H12AffineEnvironment.transform 15 21647 env14250 = env14251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21647 env14250 == env14251) = true)

theorem identity14251 : scanCanonicalize (H12AffineFastState.compose env14251 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound14251 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env14252 : List Nat := [2,4,8,16,32,17,128,256,512,188,2048,4096,388,16384,20924,20531,4388,22544,189,20925,4112,32,20773,20927,268,17,2049,16401,4232,2476,440,20757,257,20756,16521,21301]

theorem envBound14252 : H12AffineFastState.Bounded env14252 := by
  intro p hp
  have h : env14252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14251_14252 : H12AffineEnvironment.transform 9 188 env14251 = env14252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env14251 == env14252) = true)

theorem identity14252 : scanCanonicalize (H12AffineFastState.compose env14252 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound14252 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env14253 : List Nat := [2,4,8,16,32,17,128,256,512,188,2048,4096,388,4404,136,263,4388,2340,189,137,4112,32,17,139,268,17,2049,4389,4232,2476,440,33,257,32,4541,513]

theorem envBound14253 : H12AffineFastState.Bounded env14253 := by
  intro p hp
  have h : env14253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14252_14253 : H12AffineEnvironment.transform 13 4404 env14252 = env14253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env14252 == env14253) = true)

theorem identity14253 : scanCanonicalize (H12AffineFastState.compose env14253 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14253 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env14254 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,4096,269,4404,1,263,4388,2340,52,0,4112,32,17,2,268,17,2049,4389,4097,2341,305,33,257,32,4404,513]

theorem envBound14254 : H12AffineFastState.Bounded env14254 := by
  intro p hp
  have h : env14254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14253_14254 : H12AffineEnvironment.transform 6 9 env14253 = env14254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14253 == env14254) = true)

theorem identity14254 : scanCanonicalize (H12AffineFastState.compose env14254 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound14254 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14255 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,32,269,276,1,263,260,2340,52,0,48,32,17,2,268,17,2049,261,33,2341,305,33,257,32,276,513]

theorem envBound14255 : H12AffineFastState.Bounded env14255 := by
  intro p hp
  have h : env14255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14254_14255 : H12AffineEnvironment.transform 11 32 env14254 = env14255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env14254 == env14255) = true)

theorem identity14255 : scanCanonicalize (H12AffineFastState.compose env14255 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound14255 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14256 : List Nat := [2,4,8,16,32,17,9,256,292,53,2048,32,269,276,1,263,260,2340,52,0,48,32,17,2,268,17,2049,261,33,2341,305,33,257,32,276,293]

theorem envBound14256 : H12AffineFastState.Bounded env14256 := by
  intro p hp
  have h : env14256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14255_14256 : H12AffineEnvironment.transform 8 292 env14255 = env14256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env14255 == env14256) = true)

theorem identity14256 : scanCanonicalize (H12AffineFastState.compose env14256 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound14256 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14257 : List Nat := [2,4,8,16,32,17,9,256,292,53,1,32,269,276,1,263,260,293,52,0,48,32,17,2,268,17,0,261,33,292,305,33,257,32,276,293]

theorem envBound14257 : H12AffineFastState.Bounded env14257 := by
  intro p hp
  have h : env14257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14256_14257 : H12AffineEnvironment.transform 10 1 env14256 = env14257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env14256 == env14257) = true)

theorem identity14257 : scanCanonicalize (H12AffineFastState.compose env14257 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound14257 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env14258 : List Nat := [2,4,8,1,32,0,9,256,292,36,1,32,269,261,1,263,260,293,37,0,33,32,0,2,268,0,0,261,33,292,288,33,257,32,261,293]

theorem envBound14258 : H12AffineFastState.Bounded env14258 := by
  intro p hp
  have h : env14258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14257_14258 : H12AffineEnvironment.transform 3 1 env14257 = env14258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env14257 == env14258) = true)

theorem identity14258 : scanCanonicalize (H12AffineFastState.compose env14258 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14258 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14259 : List Nat := [2,4,8,1,0,0,9,256,260,4,1,0,269,261,1,263,260,261,5,0,1,0,0,2,268,0,0,261,1,260,256,1,257,0,261,261]

theorem envBound14259 : H12AffineFastState.Bounded env14259 := by
  intro p hp
  have h : env14259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14258_14259 : H12AffineEnvironment.transform 4 0 env14258 = env14259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14258 == env14259) = true)

def env14260 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,156117,2114883,8328,64,6677654,115150,2241669,303572,2334855,4268163,257,254011,197022,2262864]

theorem envBound14260 : H12AffineFastState.Bounded env14260 := by
  intro p hp
  have h : env14260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14136_14260 : H12AffineEnvironment.transform 22 156117 env14136 = env14260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 156117 env14136 == env14260) = true)

def env14261 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2534864,156117,2114883,8328,64,215366,115150,2241669,303572,2334855,2592083,257,254011,197022,2262864]

theorem envBound14261 : H12AffineFastState.Bounded env14261 := by
  intro p hp
  have h : env14261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14260_14261 : H12AffineEnvironment.transform 21 2534864 env14260 = env14261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2534864 env14260 == env14261) = true)

def env14262 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441744,156117,21763,8328,64,215366,115150,140485,303572,241863,498963,257,254011,197022,169744]

theorem envBound14262 : H12AffineFastState.Bounded env14262 := by
  intro p hp
  have h : env14262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14261_14262 : H12AffineEnvironment.transform 20 4160 env14261 = env14262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env14261 == env14262) = true)

theorem identity14262 : scanCanonicalize (H12AffineFastState.compose env14262 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound14262 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,4160,441744,156117,21763,8328,64,171416,5392,140485,303572,156697,412109,257,144613,185664,169744]

theorem envBound14263 : H12AffineFastState.Bounded env14263 := by
  intro p hp
  have h : env14263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14262_14263 : H12AffineEnvironment.transform 15 54494 env14262 = env14263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env14262 == env14263) = true)

def env14264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,10280,1025,32769,4160,169400,156117,21763,8328,64,171416,5392,140485,35324,156697,156133,257,144613,185664,169744]

theorem envBound14264 : H12AffineFastState.Bounded env14264 := by
  intro p hp
  have h : env14264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14263_14264 : H12AffineEnvironment.transform 17 10280 env14263 = env14264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env14263 == env14264) = true)

theorem identity14264 : scanCanonicalize (H12AffineFastState.compose env14264 (packedSelected [0,1,2,3,5,6,7,10,11,14,16,17,18,19,28,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 37237) := by decide +kernel

theorem selectedBound14264 : packedSelected [0,1,2,3,5,6,7,10,11,14,16,17,18,19,28,31,35] rootPS < 2^1333 := by decide +kernel

def env14265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,37237,10280,1025,32769,4160,1229,61600,21763,8328,64,3309,5392,46512,35324,62828,61584,257,42384,17461,1637]

theorem envBound14265 : H12AffineFastState.Bounded env14265 := by
  intro p hp
  have h : env14265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14264_14265 : H12AffineEnvironment.transform 16 37237 env14264 = env14265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 37237 env14264 == env14265) = true)

theorem identity14265 : scanCanonicalize (H12AffineFastState.compose env14265 (packedSelected [3,5,8,15,16,17,19,20,26,28,38] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound14265 : packedSelected [3,5,8,15,16,17,19,20,26,28,38] rootPS < 2^1333 := by decide +kernel

def env14266 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8461,30163,12408,10280,1025,8460,4160,1229,20909,21763,8328,64,3309,5392,5309,10481,21601,20893,257,1181,17461,1637]

theorem envBound14266 : H12AffineFastState.Bounded env14266 := by
  intro p hp
  have h : env14266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14265_14266 : H12AffineEnvironment.transform 14 8461 env14265 = env14266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env14265 == env14266) = true)

theorem identity14266 : scanCanonicalize (H12AffineFastState.compose env14266 (packedSelected [0,2,3,6,7,10,11,18,19,20,24] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound14266 : packedSelected [0,2,3,6,7,10,11,18,19,20,24] rootPS < 2^1333 := by decide +kernel

def env14267 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,8192,16384,8461,28746,12408,10280,408,8460,4160,340,20909,20634,8328,64,2420,4233,4388,10481,20984,20893,257,260,16812,1020]

theorem envBound14267 : H12AffineFastState.Bounded env14267 := by
  intro p hp
  have h : env14267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14266_14267 : H12AffineEnvironment.transform 9 409 env14266 = env14267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env14266 == env14267) = true)

theorem identity14267 : scanCanonicalize (H12AffineFastState.compose env14267 (packedSelected [3,4,5,9,10,11,14,19,20,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 4161) := by decide +kernel

theorem selectedBound14267 : packedSelected [3,4,5,9,10,11,14,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env14268 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,8192,4161,8461,8203,12408,10280,408,8460,4160,340,492,219,8328,64,2420,4233,4388,10481,441,476,257,260,4589,1020]

theorem envBound14268 : H12AffineFastState.Bounded env14268 := by
  intro p hp
  have h : env14268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14267_14268 : H12AffineEnvironment.transform 13 4161 env14267 = env14268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4161 env14267 == env14268) = true)

theorem identity14268 : scanCanonicalize (H12AffineFastState.compose env14268 (packedSelected [0,2,4,7,9,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound14268 : packedSelected [0,2,4,7,9,11,18] rootPS < 2^1333 := by decide +kernel

def env14269 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,8,4161,261,3,4208,2080,408,260,4160,340,492,219,128,64,2420,4233,4388,2297,441,476,257,260,4589,1020]

theorem envBound14269 : H12AffineFastState.Bounded env14269 := by
  intro p hp
  have h : env14269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14268_14269 : H12AffineEnvironment.transform 12 8 env14268 = env14269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env14268 == env14269) = true)

theorem identity14269 : scanCanonicalize (H12AffineFastState.compose env14269 (packedSelected [0,4,7,9,12,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14269 : packedSelected [0,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env14270 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8,4161,261,3,4208,2080,272,260,4160,340,356,83,8,64,2420,4097,4388,2161,305,340,257,260,4453,884]

theorem envBound14270 : H12AffineFastState.Bounded env14270 := by
  intro p hp
  have h : env14270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14269_14270 : H12AffineEnvironment.transform 6 8 env14269 = env14270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14269 == env14270) = true)

theorem identity14270 : scanCanonicalize (H12AffineFastState.compose env14270 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14270 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env14271 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,4096,8,4113,261,3,4128,2080,272,260,4112,260,308,3,8,16,2340,4097,4388,2081,305,260,257,260,4405,804]

theorem envBound14271 : H12AffineFastState.Bounded env14271 := by
  intro p hp
  have h : env14271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14270_14271 : H12AffineEnvironment.transform 5 16 env14270 = env14271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14270 == env14271) = true)

theorem identity14271 : scanCanonicalize (H12AffineFastState.compose env14271 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14271 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14272 : List Nat := [2,4,8,16,1,16,8,256,512,273,2048,4096,8,4113,261,3,4097,2049,272,260,4112,260,277,3,8,16,2309,4097,4357,2048,272,260,257,260,4372,773]

theorem envBound14272 : H12AffineFastState.Bounded env14272 := by
  intro p hp
  have h : env14272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14271_14272 : H12AffineEnvironment.transform 4 1 env14271 = env14272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14271 == env14272) = true)

theorem identity14272 : scanCanonicalize (H12AffineFastState.compose env14272 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound14272 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14273 : List Nat := [2,4,8,16,1,16,8,20,512,5,2048,4096,8,4113,17,3,4097,2049,4,16,4112,16,1,3,8,16,2065,4097,4113,2048,4,16,21,16,4096,529]

theorem envBound14273 : H12AffineFastState.Bounded env14273 := by
  intro p hp
  have h : env14273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14272_14273 : H12AffineEnvironment.transform 7 20 env14272 = env14273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env14272 == env14273) = true)

def env14274 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,10281,1025,32769,4160,169401,156117,21763,8328,64,171416,5392,140485,35325,156697,156132,257,144613,185664,169744]

theorem envBound14274 : H12AffineFastState.Bounded env14274 := by
  intro p hp
  have h : env14274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14263_14274 : H12AffineEnvironment.transform 17 10281 env14263 = env14274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env14263 == env14274) = true)

theorem identity14274 : scanCanonicalize (H12AffineFastState.compose env14274 (packedSelected [0,1,2,3,5,6,7,10,11,14,16,17,18,19,28,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound14274 : packedSelected [0,1,2,3,5,6,7,10,11,14,16,17,18,19,28,31,35] rootPS < 2^1333 := by decide +kernel

def env14275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,478,131072,10281,1025,21761,4160,147641,156117,21763,8328,64,149656,5392,140485,23805,156697,156132,257,144613,131136,147984]

theorem envBound14275 : H12AffineFastState.Bounded env14275 := by
  intro p hp
  have h : env14275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14274_14275 : H12AffineEnvironment.transform 14 21760 env14274 = env14275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env14274 == env14275) = true)

theorem identity14275 : scanCanonicalize (H12AffineFastState.compose env14275 (packedSelected [0,2,4,5,6,9,11,17,18,20,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound14275 : packedSelected [0,2,4,5,6,9,11,17,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env14276 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,478,16401,10281,1025,21761,4160,168,8644,21763,8328,64,2185,5392,25812,23805,9224,8693,257,29940,16465,513]

theorem envBound14276 : H12AffineFastState.Bounded env14276 := by
  intro p hp
  have h : env14276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14275_14276 : H12AffineEnvironment.transform 16 16401 env14275 = env14276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env14275 == env14276) = true)

theorem identity14276 : scanCanonicalize (H12AffineFastState.compose env14276 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14276 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14277 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,342,16401,10281,1025,21761,4160,32,8524,21763,8192,64,2049,5392,25692,23669,9224,8573,257,29820,16465,513]

theorem envBound14277 : H12AffineFastState.Bounded env14277 := by
  intro p hp
  have h : env14277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14276_14277 : H12AffineEnvironment.transform 6 8 env14276 = env14277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14276 == env14277) = true)

theorem identity14277 : scanCanonicalize (H12AffineFastState.compose env14277 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 12621) := by decide +kernel

theorem selectedBound14277 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env14278 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12621,9293,342,12636,10281,1025,9292,4160,32,8524,9294,8192,64,2049,5392,5393,11576,9224,8573,257,1329,12572,513]

theorem envBound14278 : H12AffineFastState.Bounded env14278 := by
  intro p hp
  have h : env14278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14277_14278 : H12AffineEnvironment.transform 13 12621 env14277 = env14278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12621 env14277 == env14278) = true)

theorem identity14278 : scanCanonicalize (H12AffineFastState.compose env14278 (packedSelected [1,4,8,9,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound14278 : packedSelected [1,4,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env14279 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,8192,10589,9293,342,10572,10281,1025,9292,2128,32,8524,9294,8192,64,2049,3328,3329,11576,9224,8573,257,1329,10508,513]

theorem envBound14279 : H12AffineFastState.Bounded env14279 := by
  intro p hp
  have h : env14279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14278_14279 : H12AffineEnvironment.transform 11 2064 env14278 = env14279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env14278 == env14279) = true)

theorem identity14279 : scanCanonicalize (H12AffineFastState.compose env14279 (packedSelected [0,7,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound14279 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env14280 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,349,2048,1296,342,2065,2420,1025,1297,2128,32,17,1299,349,64,2049,3328,3329,3173,1365,32,257,1329,2129,513]

theorem envBound14280 : H12AffineFastState.Bounded env14280 := by
  intro p hp
  have h : env14280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14279_14280 : H12AffineEnvironment.transform 12 349 env14279 = env14280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env14279 == env14280) = true)

theorem identity14280 : scanCanonicalize (H12AffineFastState.compose env14280 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 608) := by decide +kernel

theorem selectedBound14280 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env14281 : List Nat := [2,4,8,16,32,64,8,256,512,1024,608,624,349,608,1296,342,625,788,1025,1297,560,32,17,1299,349,64,609,1888,1889,1541,1365,32,257,1329,561,513]

theorem envBound14281 : H12AffineFastState.Bounded env14281 := by
  intro p hp
  have h : env14281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14280_14281 : H12AffineEnvironment.transform 10 608 env14280 = env14281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 608 env14280 == env14281) = true)

theorem identity14281 : scanCanonicalize (H12AffineFastState.compose env14281 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 629) := by decide +kernel

theorem selectedBound14281 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env14282 : List Nat := [2,4,8,16,32,64,8,256,512,629,608,624,349,608,869,342,625,788,628,868,560,32,17,870,349,64,609,277,276,112,800,32,257,836,561,513]

theorem envBound14282 : H12AffineFastState.Bounded env14282 := by
  intro p hp
  have h : env14282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14281_14282 : H12AffineEnvironment.transform 9 629 env14281 = env14282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 629 env14281 == env14282) = true)

theorem identity14282 : scanCanonicalize (H12AffineFastState.compose env14282 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound14282 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env14283 : List Nat := [2,4,8,16,32,64,8,256,277,352,373,357,349,373,112,342,356,1,353,113,293,32,17,115,349,64,372,277,276,112,53,32,257,81,292,276]

theorem envBound14283 : H12AffineFastState.Bounded env14283 := by
  intro p hp
  have h : env14283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14282_14283 : H12AffineEnvironment.transform 8 277 env14282 = env14283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env14282 == env14283) = true)

theorem identity14283 : scanCanonicalize (H12AffineFastState.compose env14283 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 47) := by decide +kernel

theorem selectedBound14283 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env14284 : List Nat := [2,4,8,16,32,64,8,47,58,79,90,74,114,90,112,121,75,1,78,113,10,32,17,115,114,64,91,58,59,112,53,32,46,81,11,59]

theorem envBound14284 : H12AffineFastState.Bounded env14284 := by
  intro p hp
  have h : env14284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14283_14284 : H12AffineEnvironment.transform 7 47 env14283 = env14284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 47 env14283 == env14284) = true)

theorem identity14284 : scanCanonicalize (H12AffineFastState.compose env14284 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14284 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env14285 : List Nat := [2,4,8,16,0,64,8,15,26,79,90,74,82,90,80,89,75,1,78,81,10,0,17,83,82,64,91,26,27,80,21,0,14,81,11,27]

theorem envBound14285 : H12AffineFastState.Bounded env14285 := by
  intro p hp
  have h : env14285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14284_14285 : H12AffineEnvironment.transform 4 0 env14284 = env14285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14284 == env14285) = true)

theorem identity14285 : scanCanonicalize (H12AffineFastState.compose env14285 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound14285 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env14286 : List Nat := [2,4,8,0,0,64,8,15,10,79,74,74,66,74,64,73,75,1,78,65,10,0,1,67,66,64,75,10,11,64,5,0,14,65,11,11]

theorem envBound14286 : H12AffineFastState.Bounded env14286 := by
  intro p hp
  have h : env14286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14285_14286 : H12AffineEnvironment.transform 3 0 env14285 = env14286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14285 == env14286) = true)

theorem identity14286 : scanCanonicalize (H12AffineFastState.compose env14286 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound14286 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env14287 : List Nat := [2,4,8,0,0,0,8,15,10,15,10,10,2,10,0,9,11,1,14,1,10,0,1,3,2,0,11,10,11,0,5,0,14,1,11,11]

theorem envBound14287 : H12AffineFastState.Bounded env14287 := by
  intro p hp
  have h : env14287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14286_14287 : H12AffineEnvironment.transform 5 0 env14286 = env14287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env14286 == env14287) = true)

def env14288 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441745,156117,21762,8328,64,215366,115150,140484,303572,241862,498962,257,254011,197022,169745]

theorem envBound14288 : H12AffineFastState.Bounded env14288 := by
  intro p hp
  have h : env14288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14261_14288 : H12AffineEnvironment.transform 20 4161 env14261 = env14288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env14261 == env14288) = true)

theorem identity14288 : scanCanonicalize (H12AffineFastState.compose env14288 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82383) := by decide +kernel

theorem selectedBound14288 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14289 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,4161,392286,73754,21762,8328,64,2185,115150,91403,303572,61705,318685,257,41460,16465,120542]

theorem envBound14289 : H12AffineFastState.Bounded env14289 := by
  intro p hp
  have h : env14289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14288_14289 : H12AffineEnvironment.transform 16 82383 env14288 = env14289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82383 env14288 == env14289) = true)

def env14290 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82335,262144,1025,32769,4113,392206,73754,21762,8328,16,2185,115102,91403,303492,61705,318605,257,41380,16385,120462]

theorem envBound14290 : H12AffineFastState.Bounded env14290 := by
  intro p hp
  have h : env14290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14289_14290 : H12AffineEnvironment.transform 5 16 env14289 = env14290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14289 == env14290) = true)

theorem identity14290 : scanCanonicalize (H12AffineFastState.compose env14290 (packedSelected [1,3,4,5,7,8,9,11,15,16,19,20,27,31,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound14290 : packedSelected [1,3,4,5,7,8,9,11,15,16,19,20,27,31,32,38] rootPS < 2^1333 := by decide +kernel

def env14291 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82335,2341,1025,32769,4113,128299,73754,21762,8328,16,2185,115102,91403,43169,61705,54696,257,41380,16385,120462]

theorem envBound14291 : H12AffineFastState.Bounded env14291 := by
  intro p hp
  have h : env14291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14290_14291 : H12AffineEnvironment.transform 17 2341 env14290 = env14291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env14290 == env14291) = true)

theorem identity14291 : scanCanonicalize (H12AffineFastState.compose env14291 (packedSelected [3,4,7,9,10,16,17,19,20,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound14291 : packedSelected [3,4,7,9,10,16,17,19,20,24,27] rootPS < 2^1333 := by decide +kernel

def env14292 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8581,65536,82335,2341,1025,8580,4113,87214,73754,21762,8328,16,2185,90139,91403,2340,20620,29741,257,33,16385,96011]

theorem envBound14292 : H12AffineFastState.Bounded env14292 := by
  intro p hp
  have h : env14292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14291_14292 : H12AffineEnvironment.transform 14 8581 env14291 = env14292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env14291 == env14292) = true)

theorem identity14292 : scanCanonicalize (H12AffineFastState.compose env14292 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 21647) := by decide +kernel

theorem selectedBound14292 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env14293 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8581,21647,5392,2341,1025,8580,4113,33,29845,21762,8328,16,2185,13460,12676,2340,20620,29741,257,33,16385,9092]

theorem envBound14293 : H12AffineFastState.Bounded env14293 := by
  intro p hp
  have h : env14293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14292_14293 : H12AffineEnvironment.transform 15 21647 env14292 = env14293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21647 env14292 == env14293) = true)

theorem identity14293 : scanCanonicalize (H12AffineFastState.compose env14293 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14293 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env14294 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8460,21510,5392,2341,1025,8461,4113,33,29724,21762,8193,16,2048,13341,12557,2340,20485,29741,257,33,16385,8973]

theorem envBound14294 : H12AffineFastState.Bounded env14294 := by
  intro p hp
  have h : env14294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14293_14294 : H12AffineEnvironment.transform 6 9 env14293 = env14294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14293 == env14294) = true)

theorem identity14294 : scanCanonicalize (H12AffineFastState.compose env14294 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound14294 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env14295 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,1,21510,5392,2341,1025,0,4113,33,21777,21762,268,16,2048,5392,4096,2340,20485,21792,257,33,16385,512]

theorem envBound14295 : H12AffineFastState.Bounded env14295 := by
  intro p hp
  have h : env14295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14294_14295 : H12AffineEnvironment.transform 12 269 env14294 = env14295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env14294 == env14295) = true)

theorem identity14295 : scanCanonicalize (H12AffineFastState.compose env14295 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14295 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14296 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,4096,269,16384,1,21510,5392,2308,1025,0,4113,0,21777,21762,268,16,2048,5392,4096,2309,20485,21761,257,0,16385,512]

theorem envBound14296 : H12AffineFastState.Bounded env14296 := by
  intro p hp
  have h : env14296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14295_14296 : H12AffineEnvironment.transform 4 1 env14295 = env14296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14295 == env14296) = true)

theorem identity14296 : scanCanonicalize (H12AffineFastState.compose env14296 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound14296 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env14297 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,3329,269,16384,1,18695,2065,2308,1025,0,3344,0,18448,18435,268,16,2048,2065,3329,2309,19716,18432,257,0,16385,512]

theorem envBound14297 : H12AffineFastState.Bounded env14297 := by
  intro p hp
  have h : env14297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14296_14297 : H12AffineEnvironment.transform 11 3329 env14296 = env14297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env14296 == env14297) = true)

theorem identity14297 : scanCanonicalize (H12AffineFastState.compose env14297 (packedSelected [2,5,8] rootPS)) = affineNative (2^(13+1) ^^^ 2049) := by decide +kernel

theorem selectedBound14297 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env14298 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,3329,269,2049,1,262,2065,2308,1025,0,3344,0,17,2,268,16,2048,2065,3329,2309,1285,1,257,0,2048,512]

theorem envBound14298 : H12AffineFastState.Bounded env14298 := by
  intro p hp
  have h : env14298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14297_14298 : H12AffineEnvironment.transform 13 2049 env14297 = env14298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2049 env14297 == env14298) = true)

theorem identity14298 : scanCanonicalize (H12AffineFastState.compose env14298 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound14298 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14299 : List Nat := [2,4,8,16,1,16,9,256,512,1024,1045,276,269,1044,1,262,1028,1297,1025,0,261,0,17,2,268,16,1045,1028,276,1296,1285,1,257,0,1045,512]

theorem envBound14299 : H12AffineFastState.Bounded env14299 := by
  intro p hp
  have h : env14299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14298_14299 : H12AffineEnvironment.transform 10 1045 env14298 = env14299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env14298 == env14299) = true)

theorem identity14299 : scanCanonicalize (H12AffineFastState.compose env14299 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound14299 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14300 : List Nat := [2,4,8,16,1,16,9,4,512,1024,1045,16,9,1044,1,2,1028,1045,1025,0,1,0,17,2,8,16,1045,1028,16,1044,1025,1,5,0,1045,512]

theorem envBound14300 : H12AffineFastState.Bounded env14300 := by
  intro p hp
  have h : env14300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14299_14300 : H12AffineEnvironment.transform 7 4 env14299 = env14300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env14299 == env14300) = true)

theorem identity14300 : scanCanonicalize (H12AffineFastState.compose env14300 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound14300 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14301 : List Nat := [2,4,8,16,1,16,9,4,1,1024,1045,16,9,1044,1,2,1028,1045,1025,0,1,0,17,2,8,16,1045,1028,16,1044,1025,1,5,0,1045,1]

theorem envBound14301 : H12AffineFastState.Bounded env14301 := by
  intro p hp
  have h : env14301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14300_14301 : H12AffineEnvironment.transform 8 1 env14300 = env14301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env14300 == env14301) = true)

theorem identity14301 : scanCanonicalize (H12AffineFastState.compose env14301 (packedSelected [10] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound14301 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env14302 : List Nat := [2,4,8,16,1,16,9,4,1,21,0,16,9,1,1,2,17,0,20,0,1,0,17,2,8,16,0,17,16,1,20,1,5,0,0,1]

theorem envBound14302 : H12AffineFastState.Bounded env14302 := by
  intro p hp
  have h : env14302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14301_14302 : H12AffineEnvironment.transform 9 21 env14301 = env14302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env14301 == env14302) = true)

theorem identity14302 : scanCanonicalize (H12AffineFastState.compose env14302 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound14302 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14303 : List Nat := [2,4,8,15,1,15,9,4,1,10,0,15,9,1,1,2,14,0,11,0,1,0,14,2,8,15,0,14,15,1,11,1,5,0,0,1]

theorem envBound14303 : H12AffineFastState.Bounded env14303 := by
  intro p hp
  have h : env14303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14302_14303 : H12AffineEnvironment.transform 3 15 env14302 = env14303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env14302 == env14303) = true)

def env14304 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82334,262144,1025,32769,4112,392207,73754,21762,8328,17,2185,115103,91403,303493,61705,318604,257,41381,16384,120463]

theorem envBound14304 : H12AffineFastState.Bounded env14304 := by
  intro p hp
  have h : env14304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14289_14304 : H12AffineEnvironment.transform 5 17 env14289 = env14304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14289 == env14304) = true)

theorem identity14304 : scanCanonicalize (H12AffineFastState.compose env14304 (packedSelected [1,3,4,5,7,8,9,11,15,16,19,20,27,31,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound14304 : packedSelected [1,3,4,5,7,8,9,11,15,16,19,20,27,31,32,38] rootPS < 2^1333 := by decide +kernel

def env14305 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,1,65536,82334,262144,1025,0,4112,359438,73754,21762,8328,17,2185,82334,91403,270724,28936,285837,257,8612,16384,87694]

theorem envBound14305 : H12AffineFastState.Bounded env14305 := by
  intro p hp
  have h : env14305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14304_14305 : H12AffineEnvironment.transform 14 1 env14304 = env14305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env14304 == env14305) = true)

theorem identity14305 : scanCanonicalize (H12AffineFastState.compose env14305 (packedSelected [0,1,3,5,8,9,16,18,20,22,23,26,27,31] rootPS)) = affineNative (2^(17+1) ^^^ 97327) := by decide +kernel

theorem selectedBound14305 : packedSelected [0,1,3,5,8,9,16,18,20,22,23,26,27,31] rootPS < 2^1333 := by decide +kernel

def env14306 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,1,65536,82334,97327,1025,0,4112,33,73754,21762,8328,17,2185,82334,91403,89515,28936,73890,257,8612,16384,87694]

theorem envBound14306 : H12AffineFastState.Bounded env14306 := by
  intro p hp
  have h : env14306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14305_14306 : H12AffineEnvironment.transform 17 97327 env14305 = env14306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97327 env14305 == env14306) = true)

theorem identity14306 : scanCanonicalize (H12AffineFastState.compose env14306 (packedSelected [0,1,4,7,8,9,10,12,17,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound14306 : packedSelected [0,1,4,7,8,9,10,12,17,18,20] rootPS < 2^1333 := by decide +kernel

def env14307 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,16384,1,65536,82334,89515,1025,0,4112,33,65950,21762,268,17,2185,82334,83087,89515,20620,65830,257,32,16384,87694]

theorem envBound14307 : H12AffineFastState.Bounded env14307 := by
  intro p hp
  have h : env14307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14306_14307 : H12AffineEnvironment.transform 12 388 env14306 = env14307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env14306 == env14307) = true)

theorem identity14307 : scanCanonicalize (H12AffineFastState.compose env14307 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 21646) := by decide +kernel

theorem selectedBound14307 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env14308 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,16384,1,21646,5392,2341,1025,0,4112,33,21776,21762,268,17,2185,5392,4097,2341,20620,21928,257,32,16384,512]

theorem envBound14308 : H12AffineFastState.Bounded env14308 := by
  intro p hp
  have h : env14308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14307_14308 : H12AffineEnvironment.transform 15 21646 env14307 = env14308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21646 env14307 == env14308) = true)

theorem identity14308 : scanCanonicalize (H12AffineFastState.compose env14308 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound14308 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env14309 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5156,1,170,5392,2341,1025,0,4112,33,308,294,268,17,2185,5392,4097,2341,1192,396,257,32,5156,512]

theorem envBound14309 : H12AffineFastState.Bounded env14309 := by
  intro p hp
  have h : env14309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14308_14309 : H12AffineEnvironment.transform 13 5156 env14308 = env14309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env14308 == env14309) = true)

theorem identity14309 : scanCanonicalize (H12AffineFastState.compose env14309 (packedSelected [0,1,2,4,5,6,7,9,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 418) := by decide +kernel

theorem selectedBound14309 : packedSelected [0,1,2,4,5,6,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env14310 : List Nat := [2,4,8,16,32,17,128,256,512,418,2048,4096,388,4486,1,170,4274,2341,419,0,4112,33,308,294,268,17,2185,4274,4097,2341,266,396,257,32,4486,512]

theorem envBound14310 : H12AffineFastState.Bounded env14310 := by
  intro p hp
  have h : env14310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14309_14310 : H12AffineEnvironment.transform 9 418 env14309 = env14310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 418 env14309 == env14310) = true)

theorem identity14310 : scanCanonicalize (H12AffineFastState.compose env14310 (packedSelected [0,5,7,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14310 : packedSelected [0,5,7,8,12] rootPS < 2^1333 := by decide +kernel

def env14311 : List Nat := [2,4,8,16,32,17,9,256,512,299,2048,4096,269,4367,1,35,4155,2341,298,0,4112,33,308,294,268,17,2048,4155,4097,2341,266,261,257,32,4367,512]

theorem envBound14311 : H12AffineFastState.Bounded env14311 := by
  intro p hp
  have h : env14311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14310_14311 : H12AffineEnvironment.transform 6 9 env14310 = env14311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14310 == env14311) = true)

theorem identity14311 : scanCanonicalize (H12AffineFastState.compose env14311 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14311 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14312 : List Nat := [2,4,8,16,32,17,9,5,512,46,2048,4096,8,4106,1,35,4155,2080,47,0,4112,33,49,35,9,17,2048,4155,4097,2080,15,0,4,32,4106,512]

theorem envBound14312 : H12AffineFastState.Bounded env14312 := by
  intro p hp
  have h : env14312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14311_14312 : H12AffineEnvironment.transform 7 5 env14311 = env14312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14311 == env14312) = true)

theorem identity14312 : scanCanonicalize (H12AffineFastState.compose env14312 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound14312 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env14313 : List Nat := [2,4,8,16,32,17,9,5,512,46,2048,2064,8,2074,1,35,2091,2080,47,0,2048,33,49,35,9,17,2048,2091,2065,2080,15,0,4,32,2074,512]

end H12CloudChart0