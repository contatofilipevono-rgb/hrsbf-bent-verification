import H12CloudChart0Data097

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env24800 : List Nat := [2,4,8,16,32,16,8,37,512,52,11,512,41,528,1,35,512,11,52,0,529,33,17,2,41,17,10,512,512,10,21,33,37,32,529,513]

theorem envBound24800 : H12AffineFastState.Bounded env24800 := by
  intro p hp
  have h : env24800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24799_24800 : H12AffineEnvironment.transform 10 11 env24799 = env24800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env24799 == env24800) = true)

theorem identity24800 : scanCanonicalize (H12AffineFastState.compose env24800 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound24800 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env24801 : List Nat := [2,4,8,16,32,16,8,37,27,52,11,27,41,11,1,35,27,11,52,0,10,33,17,2,41,17,10,27,27,10,21,33,37,32,10,26]

theorem envBound24801 : H12AffineFastState.Bounded env24801 := by
  intro p hp
  have h : env24801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24800_24801 : H12AffineEnvironment.transform 8 27 env24800 = env24801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env24800 == env24801) = true)

def env24802 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2534761,474341,8328,65,6705549,2537576,456760,2125160,2102684,6707493,256,21792,46212,2175563]

theorem envBound24802 : H12AffineFastState.Bounded env24802 := by
  intro p hp
  have h : env24802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24715_24802 : H12AffineEnvironment.transform 23 474341 env24715 = env24802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 474341 env24715 == env24802) = true)

def env24803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,2097152,4194304,2101329,98781,8328,65,6352053,2098512,17664,2125160,2102684,6349853,256,21792,46212,2175563]

theorem envBound24803 : H12AffineFastState.Bounded env24803 := by
  intro p hp
  have h : env24803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24802_24803 : H12AffineEnvironment.transform 17 179512 env24802 = env24803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env24802 == env24803) = true)

def env24804 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,4194304,17,98781,8328,65,4259061,5392,17664,32040,1500,4256861,256,21792,46212,74251]

theorem envBound24804 : H12AffineFastState.Bounded env24804 := by
  intro p hp
  have h : env24804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24803_24804 : H12AffineEnvironment.transform 20 4160 env24803 = env24804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env24803 == env24804) = true)

theorem identity24804 : scanCanonicalize (H12AffineFastState.compose env24804 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 243122) := by decide +kernel

theorem selectedBound24804 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,243122,17,98781,8328,65,215367,5392,17664,32040,1500,213487,256,21792,46212,74251]

theorem envBound24805 : H12AffineFastState.Bounded env24805 := by
  intro p hp
  have h : env24805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24804_24805 : H12AffineEnvironment.transform 21 243122 env24804 = env24805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 243122 env24804 == env24805) = true)

def env24806 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,243002,17,98645,8192,65,215367,5392,17664,32040,1364,213351,256,21792,46092,74251]

theorem envBound24806 : H12AffineFastState.Bounded env24806 := by
  intro p hp
  have h : env24806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24805_24806 : H12AffineEnvironment.transform 6 8 env24805 = env24806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24805 == env24806) = true)

theorem identity24806 : scanCanonicalize (H12AffineFastState.compose env24806 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound24806 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24807 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,131072,179512,1024,32769,4160,144493,17,2,8192,65,182288,5392,17664,32040,1364,180272,256,21792,46092,41820]

theorem envBound24807 : H12AffineFastState.Bounded env24807 := by
  intro p hp
  have h : env24807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24806_24807 : H12AffineEnvironment.transform 15 33111 env24806 = env24807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env24806 == env24807) = true)

theorem identity24807 : scanCanonicalize (H12AffineFastState.compose env24807 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound24807 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env24808 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,5392,43048,1024,32769,4160,8573,17,2,8192,65,56576,5392,17664,32040,1364,54560,256,21792,46092,41820]

theorem envBound24808 : H12AffineFastState.Bounded env24808 := by
  intro p hp
  have h : env24808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24807_24808 : H12AffineEnvironment.transform 16 5392 env24807 = env24808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env24807 == env24808) = true)

theorem identity24808 : scanCanonicalize (H12AffineFastState.compose env24808 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound24808 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env24809 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,29962,5392,23669,1024,29788,4160,8573,17,2,8192,65,10589,5392,17664,32040,1364,8573,256,21792,16465,22273]

theorem envBound24809 : H12AffineFastState.Bounded env24809 := by
  intro p hp
  have h : env24809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24808_24809 : H12AffineEnvironment.transform 14 29789 env24808 = env24809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env24808 == env24809) = true)

theorem identity24809 : scanCanonicalize (H12AffineFastState.compose env24809 (packedSelected [0,4,7,9,11,14,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound24809 : packedSelected [0,4,7,9,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env24810 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,373,34,5392,10589,1024,372,4160,8573,17,2,8192,65,10589,5392,12328,2048,1364,8573,256,8200,13689,8745]

theorem envBound24810 : H12AffineFastState.Bounded env24810 := by
  intro p hp
  have h : env24810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24809_24810 : H12AffineEnvironment.transform 13 13608 env24809 = env24810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env24809 == env24810) = true)

theorem identity24810 : scanCanonicalize (H12AffineFastState.compose env24810 (packedSelected [0,1,2,3,5,7,8,10,14,19] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound24810 : packedSelected [0,1,2,3,5,7,8,10,14,19] rootPS < 2^1333 := by decide +kernel

def env24811 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5376,373,34,5392,2421,1024,372,4160,341,17,2,40,65,2421,5392,4096,2048,1364,341,256,32,5457,513]

theorem envBound24811 : H12AffineFastState.Bounded env24811 := by
  intro p hp
  have h : env24811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24810_24811 : H12AffineEnvironment.transform 12 40 env24810 = env24811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env24810 == env24811) = true)

theorem identity24811 : scanCanonicalize (H12AffineFastState.compose env24811 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound24811 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24812 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,5236,1,34,5220,2049,1024,0,4160,33,17,2,40,65,2049,5220,4096,2048,1056,33,116,32,5157,513]

theorem envBound24812 : H12AffineFastState.Bounded env24812 := by
  intro p hp
  have h : env24812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24811_24812 : H12AffineEnvironment.transform 7 116 env24811 = env24812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env24811 == env24812) = true)

theorem identity24812 : scanCanonicalize (H12AffineFastState.compose env24812 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24812 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24813 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5156,1,34,5172,2049,1024,0,4112,33,17,2,40,17,2049,5172,4096,2048,1056,33,36,32,5157,513]

theorem envBound24813 : H12AffineFastState.Bounded env24813 := by
  intro p hp
  have h : env24813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24812_24813 : H12AffineEnvironment.transform 5 16 env24812 = env24813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24812 == env24813) = true)

theorem identity24813 : scanCanonicalize (H12AffineFastState.compose env24813 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound24813 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24814 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,3108,40,2048,1,34,2064,2049,1024,0,3124,33,17,2,40,17,2049,2064,3108,2048,1056,33,36,32,2049,513]

theorem envBound24814 : H12AffineFastState.Bounded env24814 := by
  intro p hp
  have h : env24814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24813_24814 : H12AffineEnvironment.transform 11 3108 env24813 = env24814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env24813 == env24814) = true)

theorem identity24814 : scanCanonicalize (H12AffineFastState.compose env24814 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound24814 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24815 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,2064,40,2048,1,34,2064,2049,52,0,2048,33,17,2,40,17,2049,2064,2064,2048,20,33,36,32,2049,513]

theorem envBound24815 : H12AffineFastState.Bounded env24815 := by
  intro p hp
  have h : env24815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24814_24815 : H12AffineEnvironment.transform 9 52 env24814 = env24815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env24814 == env24815) = true)

def env24816 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,243003,17,98644,8193,65,215367,5392,17664,32040,1365,213350,256,21792,46093,74251]

theorem envBound24816 : H12AffineFastState.Bounded env24816 := by
  intro p hp
  have h : env24816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24805_24816 : H12AffineEnvironment.transform 6 9 env24805 = env24816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24805 == env24816) = true)

theorem identity24816 : scanCanonicalize (H12AffineFastState.compose env24816 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound24816 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24817 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179512,1024,32769,4160,169265,17,41310,8193,65,158029,5392,17664,32040,1365,156012,256,21792,46093,513]

theorem envBound24817 : H12AffineFastState.Bounded env24817 := by
  intro p hp
  have h : env24817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24816_24817 : H12AffineEnvironment.transform 15 8202 env24816 = env24817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env24816 == env24817) = true)

theorem identity24817 : scanCanonicalize (H12AffineFastState.compose env24817 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound24817 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env24818 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,64808,1024,32769,4160,54561,17,41310,8193,65,10589,5392,17664,32040,1365,8572,256,21792,46093,513]

theorem envBound24818 : H12AffineFastState.Bounded env24818 := by
  intro p hp
  have h : env24818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24817_24818 : H12AffineEnvironment.transform 16 16400 env24817 = env24818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env24817 == env24818) = true)

theorem identity24818 : scanCanonicalize (H12AffineFastState.compose env24818 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound24818 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env24819 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,16400,23668,1024,8541,4160,29821,17,2,8193,65,10589,5392,17664,32040,1365,8572,256,21792,5457,513]

theorem envBound24819 : H12AffineFastState.Bounded env24819 := by
  intro p hp
  have h : env24819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24818_24819 : H12AffineEnvironment.transform 14 8540 env24818 = env24819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env24818 == env24819) = true)

theorem identity24819 : scanCanonicalize (H12AffineFastState.compose env24819 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound24819 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env24820 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13688,8540,8202,13672,10508,1024,8541,4160,261,17,2,8193,65,10589,5392,12408,2128,1365,8572,256,8280,5457,513]

theorem envBound24820 : H12AffineFastState.Bounded env24820 := by
  intro p hp
  have h : env24820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24819_24820 : H12AffineEnvironment.transform 13 13688 env24819 = env24820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env24819 == env24820) = true)

theorem identity24820 : scanCanonicalize (H12AffineFastState.compose env24820 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound24820 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env24821 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1385,4113,1077,1379,4097,3173,1024,1076,4160,261,17,2,1384,65,3124,5392,5393,2128,1365,1045,256,1329,5457,513]

theorem envBound24821 : H12AffineFastState.Bounded env24821 := by
  intro p hp
  have h : env24821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24820_24821 : H12AffineEnvironment.transform 12 1385 env24820 = env24821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env24820 == env24821) = true)

theorem identity24821 : scanCanonicalize (H12AffineFastState.compose env24821 (packedSelected [0,1,3,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound24821 : packedSelected [0,1,3,6,7] rootPS < 2^1333 := by decide +kernel

def env24822 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2112,1385,2129,1077,1379,2113,3173,1024,1076,2048,261,17,2,1384,65,3124,3408,3409,2128,1365,1045,256,1329,3345,513]

theorem envBound24822 : H12AffineFastState.Bounded env24822 := by
  intro p hp
  have h : env24822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24821_24822 : H12AffineEnvironment.transform 11 2112 env24821 = env24822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env24821 == env24822) = true)

theorem identity24822 : scanCanonicalize (H12AffineFastState.compose env24822 (packedSelected [0,1,2,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound24822 : packedSelected [0,1,2,4,5,6] rootPS < 2^1333 := by decide +kernel

def env24823 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,2112,1053,2129,1077,1047,2113,3173,1024,1076,2048,113,17,2,1052,65,3124,3108,3109,2128,1057,1045,116,1093,3173,513]

theorem envBound24823 : H12AffineFastState.Bounded env24823 := by
  intro p hp
  have h : env24823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24822_24823 : H12AffineEnvironment.transform 7 116 env24822 = env24823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env24822 == env24823) = true)

theorem identity24823 : scanCanonicalize (H12AffineFastState.compose env24823 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound24823 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24824 : List Nat := [2,4,8,16,32,64,9,116,512,53,2048,2112,40,2129,0,34,2113,2128,53,1,2048,113,17,2,41,65,2049,2065,2064,2128,20,32,116,112,2128,513]

theorem envBound24824 : H12AffineFastState.Bounded env24824 := by
  intro p hp
  have h : env24824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24823_24824 : H12AffineEnvironment.transform 9 53 env24823 = env24824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env24823 == env24824) = true)

theorem identity24824 : scanCanonicalize (H12AffineFastState.compose env24824 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound24824 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24825 : List Nat := [2,4,8,16,32,64,9,116,512,53,0,64,40,81,0,34,65,80,53,1,0,113,17,2,41,65,1,17,16,80,20,32,116,112,80,513]

theorem envBound24825 : H12AffineFastState.Bounded env24825 := by
  intro p hp
  have h : env24825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24824_24825 : H12AffineEnvironment.transform 10 0 env24824 = env24825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env24824 == env24825) = true)

def env24826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,4194304,16,98781,8328,65,4259060,5393,17664,32041,1501,4256860,256,21792,46212,74250]

theorem envBound24826 : H12AffineFastState.Bounded env24826 := by
  intro p hp
  have h : env24826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24803_24826 : H12AffineEnvironment.transform 20 4161 env24803 = env24826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env24803 == env24826) = true)

theorem identity24826 : scanCanonicalize (H12AffineFastState.compose env24826 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound24826 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179512,1024,32769,4161,4194304,16,41430,8328,65,4259060,5393,17664,32041,1501,4256860,256,21792,46212,513]

theorem envBound24827 : H12AffineFastState.Bounded env24827 := by
  intro p hp
  have h : env24827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24826_24827 : H12AffineEnvironment.transform 15 8203 env24826 = env24827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env24826 == env24827) = true)

theorem identity24827 : scanCanonicalize (H12AffineFastState.compose env24827 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 169400) := by decide +kernel

theorem selectedBound24827 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env24828 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179512,1024,32769,4161,169400,16,41430,8328,65,158028,5393,17664,32041,1501,156132,256,21792,46212,513]

theorem envBound24828 : H12AffineFastState.Bounded env24828 := by
  intro p hp
  have h : env24828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24827_24828 : H12AffineEnvironment.transform 21 169400 env24827 = env24828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169400 env24827 == env24828) = true)

theorem identity24828 : scanCanonicalize (H12AffineFastState.compose env24828 (packedSelected [12,15,17,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound24828 : packedSelected [12,15,17,38,41] rootPS < 2^1333 := by decide +kernel

def env24829 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179512,1024,32769,4161,169265,16,41311,8193,65,158028,5393,17664,32041,1364,156013,256,21792,46093,513]

theorem envBound24829 : H12AffineFastState.Bounded env24829 := by
  intro p hp
  have h : env24829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24828_24829 : H12AffineEnvironment.transform 6 9 env24828 = env24829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24828 == env24829) = true)

theorem identity24829 : scanCanonicalize (H12AffineFastState.compose env24829 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound24829 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24830 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,38160,10280,1024,32769,4161,33,16,41311,8193,65,64604,5393,17664,32041,1364,62589,256,21792,46093,513]

theorem envBound24830 : H12AffineFastState.Bounded env24830 := by
  intro p hp
  have h : env24830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24829_24830 : H12AffineEnvironment.transform 16 38160 env24829 = env24830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env24829 == env24830) = true)

theorem identity24830 : scanCanonicalize (H12AffineFastState.compose env24830 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound24830 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env24831 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,8203,5392,10280,1024,1,4161,33,16,8543,8193,65,31836,5393,17664,32041,1364,29821,256,21792,13325,513]

theorem envBound24831 : H12AffineFastState.Bounded env24831 := by
  intro p hp
  have h : env24831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24830_24831 : H12AffineEnvironment.transform 14 0 env24830 = env24831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env24830 == env24831) = true)

theorem identity24831 : scanCanonicalize (H12AffineFastState.compose env24831 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound24831 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24832 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,0,8203,5392,10280,1024,1,4161,33,16,8543,8193,65,2048,5393,12636,2421,1364,33,256,8572,13325,513]

theorem envBound24832 : H12AffineFastState.Bounded env24832 := by
  intro p hp
  have h : env24832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24831_24832 : H12AffineEnvironment.transform 13 13404 env24831 = env24832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env24831 == env24832) = true)

theorem identity24832 : scanCanonicalize (H12AffineFastState.compose env24832 (packedSelected [1,8,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound24832 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env24833 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,342,5392,2421,1024,1,4161,33,16,2,348,65,2048,5393,4097,2421,1364,33,256,33,5456,513]

theorem envBound24833 : H12AffineFastState.Bounded env24833 := by
  intro p hp
  have h : env24833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24832_24833 : H12AffineEnvironment.transform 12 349 env24832 = env24833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env24832 == env24833) = true)

theorem identity24833 : scanCanonicalize (H12AffineFastState.compose env24833 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound24833 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24834 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,349,4113,0,342,4096,2421,272,1,4161,33,16,2,348,65,2048,4097,4097,2421,68,33,256,33,4160,513]

theorem envBound24834 : H12AffineFastState.Bounded env24834 := by
  intro p hp
  have h : env24834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24833_24834 : H12AffineEnvironment.transform 9 272 env24833 = env24834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env24833 == env24834) = true)

theorem identity24834 : scanCanonicalize (H12AffineFastState.compose env24834 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound24834 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24835 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,49,349,32,0,342,49,2421,272,1,112,33,16,2,348,65,2048,48,48,2421,68,33,256,33,113,513]

theorem envBound24835 : H12AffineFastState.Bounded env24835 := by
  intro p hp
  have h : env24835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24834_24835 : H12AffineEnvironment.transform 11 49 env24834 = env24835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env24834 == env24835) = true)

theorem identity24835 : scanCanonicalize (H12AffineFastState.compose env24835 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound24835 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24836 : List Nat := [2,4,8,16,32,64,9,116,512,100,2048,49,41,32,0,34,49,2049,100,1,112,33,16,2,40,65,2048,48,48,2049,68,33,116,33,113,513]

theorem envBound24836 : H12AffineFastState.Bounded env24836 := by
  intro p hp
  have h : env24836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24835_24836 : H12AffineEnvironment.transform 7 116 env24835 = env24836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env24835 == env24836) = true)

theorem identity24836 : scanCanonicalize (H12AffineFastState.compose env24836 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound24836 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env24837 : List Nat := [2,4,8,16,32,64,9,116,1,100,2048,49,41,32,0,34,49,2049,100,1,112,33,16,2,40,65,2048,48,48,2049,68,33,116,33,113,0]

theorem envBound24837 : H12AffineFastState.Bounded env24837 := by
  intro p hp
  have h : env24837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24836_24837 : H12AffineEnvironment.transform 8 1 env24836 = env24837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env24836 == env24837) = true)

theorem identity24837 : scanCanonicalize (H12AffineFastState.compose env24837 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound24837 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24838 : List Nat := [2,4,8,16,0,64,9,84,1,68,2048,17,9,0,0,2,17,2049,68,1,80,1,16,2,8,65,2048,16,16,2049,68,1,84,1,81,0]

theorem envBound24838 : H12AffineFastState.Bounded env24838 := by
  intro p hp
  have h : env24838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24837_24838 : H12AffineEnvironment.transform 4 0 env24837 = env24838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24837 == env24838) = true)

theorem identity24838 : scanCanonicalize (H12AffineFastState.compose env24838 (packedSelected [8] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound24838 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env24839 : List Nat := [2,4,8,16,0,64,9,84,1,68,81,17,9,0,0,2,17,80,68,1,80,1,16,2,8,65,81,16,16,80,68,1,84,1,81,0]

theorem envBound24839 : H12AffineFastState.Bounded env24839 := by
  intro p hp
  have h : env24839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24838_24839 : H12AffineEnvironment.transform 10 81 env24838 = env24839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env24838 == env24839) = true)

theorem identity24839 : scanCanonicalize (H12AffineFastState.compose env24839 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound24839 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24840 : List Nat := [2,4,8,1,0,64,9,69,1,68,64,0,9,0,0,2,0,65,68,1,65,1,1,2,8,65,64,1,1,65,68,1,69,1,64,0]

theorem envBound24840 : H12AffineFastState.Bounded env24840 := by
  intro p hp
  have h : env24840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24839_24840 : H12AffineEnvironment.transform 3 1 env24839 = env24840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env24839 == env24840) = true)

def env24841 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,2097152,4194304,2101328,98780,8328,65,6352052,2098513,17665,2125160,2102684,6349852,256,21792,46212,2175563]

theorem envBound24841 : H12AffineFastState.Bounded env24841 := by
  intro p hp
  have h : env24841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24802_24841 : H12AffineEnvironment.transform 17 179513 env24802 = env24841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env24802 == env24841) = true)

def env24842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,4194304,16,98780,8328,65,4259060,5393,17665,32040,1500,4256860,256,21792,46212,74251]

theorem envBound24842 : H12AffineFastState.Bounded env24842 := by
  intro p hp
  have h : env24842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24841_24842 : H12AffineEnvironment.transform 20 4160 env24841 = env24842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env24841 == env24842) = true)

theorem identity24842 : scanCanonicalize (H12AffineFastState.compose env24842 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound24842 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24843 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,179513,1024,32769,4160,4194304,16,21762,8328,65,4259060,5393,17665,32040,1500,4256860,256,21792,46212,63189]

theorem envBound24843 : H12AffineFastState.Bounded env24843 := by
  intro p hp
  have h : env24843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24842_24843 : H12AffineEnvironment.transform 15 54494 env24842 = env24843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env24842 == env24843) = true)

def env24844 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,179513,1024,32769,4160,4194304,16,21762,8192,65,4258940,5393,17665,32040,1364,4256860,256,21792,46092,63069]

theorem envBound24844 : H12AffineFastState.Bounded env24844 := by
  intro p hp
  have h : env24844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24843_24844 : H12AffineEnvironment.transform 6 8 env24843 = env24844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24843 == env24844) = true)

theorem identity24844 : scanCanonicalize (H12AffineFastState.compose env24844 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound24844 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24845 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49169,32040,1024,32769,4160,4194304,16,21762,8192,65,4258940,5393,17665,32040,1364,4256860,256,21792,46092,63069]

theorem envBound24845 : H12AffineFastState.Bounded env24845 := by
  intro p hp
  have h : env24845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24844_24845 : H12AffineEnvironment.transform 16 49169 env24844 = env24845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env24844 == env24845) = true)

theorem identity24845 : scanCanonicalize (H12AffineFastState.compose env24845 (packedSelected [18,23] rootPS)) = affineNative (2^(21+1) ^^^ 32801) := by decide +kernel

theorem selectedBound24845 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env24846 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49169,32040,1024,32769,4160,32801,16,21762,8192,65,31837,5393,17665,32040,1364,29821,256,21792,46092,63069]

theorem envBound24846 : H12AffineFastState.Bounded env24846 := by
  intro p hp
  have h : env24846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24845_24846 : H12AffineEnvironment.transform 21 32801 env24845 = env24846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32801 env24845 == env24846) = true)

theorem identity24846 : scanCanonicalize (H12AffineFastState.compose env24846 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound24846 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env24847 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,342,5393,32040,1024,21761,4160,21793,16,21762,8192,65,31837,5393,17665,32040,1364,29821,256,21792,24844,9053]

theorem envBound24847 : H12AffineFastState.Bounded env24847 := by
  intro p hp
  have h : env24847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24846_24847 : H12AffineEnvironment.transform 14 21760 env24846 = env24847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env24846 == env24847) = true)

theorem identity24847 : scanCanonicalize (H12AffineFastState.compose env24847 (packedSelected [3,4,5,6,9,10,11,12,15,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound24847 : packedSelected [3,4,5,6,9,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env24848 : List Nat := [2,4,8,16,32,64,8,84,512,1024,2048,4096,8192,16384,21588,2,5189,31868,1024,21589,4160,21621,16,21590,8192,65,31837,5189,17493,31868,1024,29821,84,21620,24664,8713]

theorem envBound24848 : H12AffineFastState.Bounded env24848 := by
  intro p hp
  have h : env24848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24847_24848 : H12AffineEnvironment.transform 7 84 env24847 = env24848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env24847 == env24848) = true)

theorem identity24848 : scanCanonicalize (H12AffineFastState.compose env24848 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13437) := by decide +kernel

theorem selectedBound24848 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env24849 : List Nat := [2,4,8,16,32,64,8,84,512,1024,2048,4096,8192,13437,8233,2,5189,2049,1024,8232,4160,8200,16,8235,8192,65,2080,5189,12328,2049,1024,0,84,8201,5157,8713]

theorem envBound24849 : H12AffineFastState.Bounded env24849 := by
  intro p hp
  have h : env24849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24848_24849 : H12AffineEnvironment.transform 13 13437 env24848 = env24849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13437 env24848 == env24849) = true)

theorem identity24849 : scanCanonicalize (H12AffineFastState.compose env24849 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound24849 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env24850 : List Nat := [2,4,8,16,32,64,8,84,512,1024,2048,4096,9,5236,32,2,5189,2049,1024,33,4160,1,16,34,9,65,2080,5189,4129,2049,1024,0,84,0,5157,512]

theorem envBound24850 : H12AffineFastState.Bounded env24850 := by
  intro p hp
  have h : env24850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24849_24850 : H12AffineEnvironment.transform 12 9 env24849 = env24850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env24849 == env24850) = true)

theorem identity24850 : scanCanonicalize (H12AffineFastState.compose env24850 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24850 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24851 : List Nat := [2,4,8,16,1,64,8,84,512,1024,2048,4096,9,5205,1,2,5189,2049,1024,0,4160,1,16,3,9,65,2049,5189,4096,2049,1024,0,84,0,5124,512]

theorem envBound24851 : H12AffineFastState.Bounded env24851 := by
  intro p hp
  have h : env24851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24850_24851 : H12AffineEnvironment.transform 4 1 env24850 = env24851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24850 == env24851) = true)

theorem identity24851 : scanCanonicalize (H12AffineFastState.compose env24851 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound24851 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24852 : List Nat := [2,4,8,16,1,64,8,84,512,1024,2048,16,9,1093,1,2,1109,2049,1024,0,80,1,16,3,9,65,2049,1109,16,2049,1024,0,84,0,1044,512]

theorem envBound24852 : H12AffineFastState.Bounded env24852 := by
  intro p hp
  have h : env24852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24851_24852 : H12AffineEnvironment.transform 11 16 env24851 = env24852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env24851 == env24852) = true)

theorem identity24852 : scanCanonicalize (H12AffineFastState.compose env24852 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound24852 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env24853 : List Nat := [2,4,8,16,1,64,8,84,512,5,2048,16,9,64,1,2,80,2049,5,0,80,1,16,3,9,65,2049,80,16,2049,5,0,84,0,17,512]

theorem envBound24853 : H12AffineFastState.Bounded env24853 := by
  intro p hp
  have h : env24853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24852_24853 : H12AffineEnvironment.transform 9 5 env24852 = env24853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env24852 == env24853) = true)

theorem identity24853 : scanCanonicalize (H12AffineFastState.compose env24853 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound24853 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env24854 : List Nat := [2,4,8,16,1,64,8,84,512,5,64,16,9,64,1,2,80,65,5,0,80,1,16,3,9,65,65,80,16,65,5,0,84,0,17,512]

theorem envBound24854 : H12AffineFastState.Bounded env24854 := by
  intro p hp
  have h : env24854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24853_24854 : H12AffineEnvironment.transform 10 64 env24853 = env24854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env24853 == env24854) = true)

theorem identity24854 : scanCanonicalize (H12AffineFastState.compose env24854 (packedSelected [0,1,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24854 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env24855 : List Nat := [2,4,8,16,1,16,8,4,512,5,16,16,9,16,1,2,0,17,5,0,0,1,16,3,9,17,17,0,16,17,5,0,4,0,17,512]

theorem envBound24855 : H12AffineFastState.Bounded env24855 := by
  intro p hp
  have h : env24855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24854_24855 : H12AffineEnvironment.transform 5 16 env24854 = env24855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24854 == env24855) = true)

theorem identity24855 : scanCanonicalize (H12AffineFastState.compose env24855 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound24855 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env24856 : List Nat := [2,4,8,1,1,1,8,4,512,5,1,1,9,1,1,2,0,0,5,0,0,1,1,3,9,0,0,0,1,0,5,0,4,0,0,512]

theorem envBound24856 : H12AffineFastState.Bounded env24856 := by
  intro p hp
  have h : env24856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24855_24856 : H12AffineEnvironment.transform 3 1 env24855 = env24856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env24855 == env24856) = true)

theorem identity24856 : scanCanonicalize (H12AffineFastState.compose env24856 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound24856 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24857 : List Nat := [2,4,8,1,1,1,8,4,15,5,1,1,9,1,1,2,0,0,5,0,0,1,1,3,9,0,0,0,1,0,5,0,4,0,0,15]

theorem envBound24857 : H12AffineFastState.Bounded env24857 := by
  intro p hp
  have h : env24857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24856_24857 : H12AffineEnvironment.transform 8 15 env24856 = env24857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env24856 == env24857) = true)

def env24858 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,179513,1024,32769,4160,4194304,16,21762,8193,65,4258941,5393,17665,32040,1365,4256860,256,21792,46093,63068]

theorem envBound24858 : H12AffineFastState.Bounded env24858 := by
  intro p hp
  have h : env24858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24843_24858 : H12AffineEnvironment.transform 6 9 env24843 = env24858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24843 == env24858) = true)

theorem identity24858 : scanCanonicalize (H12AffineFastState.compose env24858 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound24858 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24859 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,24908,56437,1024,32769,4160,4194304,16,21762,8193,65,4258941,5393,17665,32040,1365,4256860,256,21792,46093,63068]

theorem envBound24859 : H12AffineFastState.Bounded env24859 := by
  intro p hp
  have h : env24859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24858_24859 : H12AffineEnvironment.transform 16 24908 env24858 = env24859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env24858 == env24859) = true)

theorem identity24859 : scanCanonicalize (H12AffineFastState.compose env24859 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound24859 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env24860 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,24908,10280,1024,29788,4160,4194304,16,21762,8193,65,4196384,5393,17665,32040,1365,4194305,256,21792,16464,513]

theorem envBound24860 : H12AffineFastState.Bounded env24860 := by
  intro p hp
  have h : env24860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24859_24860 : H12AffineEnvironment.transform 14 29789 env24859 = env24860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env24859 == env24860) = true)

theorem identity24860 : scanCanonicalize (H12AffineFastState.compose env24860 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound24860 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24861 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,24908,10280,1024,29788,4160,8493,16,21762,8193,65,10509,5393,17665,32040,1365,8492,256,21792,16464,513]

theorem envBound24861 : H12AffineFastState.Bounded env24861 := by
  intro p hp
  have h : env24861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24860_24861 : H12AffineEnvironment.transform 21 8493 env24860 = env24861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env24860 == env24861) = true)

def env24862 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,4194304,17,98780,8328,65,4259061,5392,17665,32041,1501,4256861,256,21792,46212,74250]

theorem envBound24862 : H12AffineFastState.Bounded env24862 := by
  intro p hp
  have h : env24862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24841_24862 : H12AffineEnvironment.transform 20 4161 env24841 = env24862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env24841 == env24862) = true)

theorem identity24862 : scanCanonicalize (H12AffineFastState.compose env24862 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 213350) := by decide +kernel

theorem selectedBound24862 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,213350,17,98780,8328,65,245139,5392,17665,32041,1501,243003,256,21792,46212,74250]

theorem envBound24863 : H12AffineFastState.Bounded env24863 := by
  intro p hp
  have h : env24863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24862_24863 : H12AffineEnvironment.transform 21 213350 env24862 = env24863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 213350 env24862 == env24863) = true)

def env24864 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,213350,17,98644,8192,65,245019,5392,17665,32041,1365,243003,256,21792,46092,74250]

theorem envBound24864 : H12AffineFastState.Bounded env24864 := by
  intro p hp
  have h : env24864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24863_24864 : H12AffineEnvironment.transform 6 8 env24863 = env24864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24863 == env24864) = true)

theorem identity24864 : scanCanonicalize (H12AffineFastState.compose env24864 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound24864 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24865 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,131072,179513,1024,32769,4161,180272,17,2,8192,65,146509,5392,17665,32041,1365,144493,256,21792,46092,41820]

theorem envBound24865 : H12AffineFastState.Bounded env24865 := by
  intro p hp
  have h : env24865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24864_24865 : H12AffineEnvironment.transform 15 33110 env24864 = env24865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env24864 == env24865) = true)

theorem identity24865 : scanCanonicalize (H12AffineFastState.compose env24865 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound24865 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env24866 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,33110,131072,171060,1024,32769,4161,180272,17,2,269,65,138560,5392,17665,23588,1365,136544,256,21792,38145,33361]

theorem envBound24866 : H12AffineFastState.Bounded env24866 := by
  intro p hp
  have h : env24866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24865_24866 : H12AffineEnvironment.transform 12 269 env24865 = env24866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env24865 == env24866) = true)

theorem identity24866 : scanCanonicalize (H12AffineFastState.compose env24866 (packedSelected [4,5,9,12,14,15,16,18,23,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound24866 : packedSelected [4,5,9,12,14,15,16,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env24867 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,41,16384,32768,32882,131072,171060,1024,32769,4161,180272,17,2,41,65,138340,5172,17445,23588,1137,136260,36,21508,37925,33361]

theorem envBound24867 : H12AffineFastState.Bounded env24867 := by
  intro p hp
  have h : env24867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24866_24867 : H12AffineEnvironment.transform 7 36 env24866 = env24867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env24866 == env24867) = true)

theorem identity24867 : scanCanonicalize (H12AffineFastState.compose env24867 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound24867 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env24868 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,41,16384,32768,32882,16401,56357,1024,32769,4161,32801,17,2,41,65,23669,5172,17445,23588,1137,21589,36,21508,37925,33361]

theorem envBound24868 : H12AffineFastState.Bounded env24868 := by
  intro p hp
  have h : env24868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24867_24868 : H12AffineEnvironment.transform 16 16401 env24867 = env24868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env24867 == env24868) = true)

theorem identity24868 : scanCanonicalize (H12AffineFastState.compose env24868 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 21540) := by decide +kernel

theorem selectedBound24868 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env24869 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,41,16384,21540,21590,16401,2049,1024,21541,4161,21509,17,2,41,65,23669,5172,17445,23588,1137,21589,36,21508,16385,22133]

theorem envBound24869 : H12AffineFastState.Bounded env24869 := by
  intro p hp
  have h : env24869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24868_24869 : H12AffineEnvironment.transform 14 21540 env24868 = env24869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21540 env24868 == env24869) = true)

theorem identity24869 : scanCanonicalize (H12AffineFastState.compose env24869 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24869 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24870 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,16384,21540,21511,16401,2049,1024,21541,4112,21509,17,2,41,16,23588,5172,17445,23588,1056,21508,36,21508,16385,22052]

theorem envBound24870 : H12AffineFastState.Bounded env24870 := by
  intro p hp
  have h : env24870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24869_24870 : H12AffineEnvironment.transform 5 17 env24869 = env24870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24869 == env24870) = true)

theorem identity24870 : scanCanonicalize (H12AffineFastState.compose env24870 (packedSelected [1,8] rootPS)) = affineNative (2^(13+1) ^^^ 3109) := by decide +kernel

theorem selectedBound24870 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env24871 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,3109,6145,6178,3124,2049,1024,6144,4112,6176,17,2,41,16,4097,5172,2048,4097,1056,6177,36,6177,3108,6657]

theorem envBound24871 : H12AffineFastState.Bounded env24871 := by
  intro p hp
  have h : env24871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24870_24871 : H12AffineEnvironment.transform 13 3109 env24870 = env24871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3109 env24870 == env24871) = true)

theorem identity24871 : scanCanonicalize (H12AffineFastState.compose env24871 (packedSelected [2,3,4,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1588) := by decide +kernel

theorem selectedBound24871 : packedSelected [2,3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env24872 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1588,4096,41,529,5685,5654,512,1589,1024,5684,4112,5652,17,2,41,16,4097,5172,1588,4097,1056,5653,36,5653,528,5173]

theorem envBound24872 : H12AffineFastState.Bounded env24872 := by
  intro p hp
  have h : env24872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24871_24872 : H12AffineEnvironment.transform 10 1588 env24871 = env24872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1588 env24871 == env24872) = true)

theorem identity24872 : scanCanonicalize (H12AffineFastState.compose env24872 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1573) := by decide +kernel

theorem selectedBound24872 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env24873 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1588,1573,41,529,16,51,512,1589,1024,17,1589,49,17,2,41,16,1572,529,1588,1572,1056,48,36,48,528,528]

theorem envBound24873 : H12AffineFastState.Bounded env24873 := by
  intro p hp
  have h : env24873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24872_24873 : H12AffineEnvironment.transform 11 1573 env24872 = env24873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1573 env24872 == env24873) = true)

theorem identity24873 : scanCanonicalize (H12AffineFastState.compose env24873 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound24873 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24874 : List Nat := [2,4,8,16,32,17,8,36,512,20,544,561,41,529,16,51,512,545,20,17,545,49,17,2,41,16,560,529,544,560,52,48,36,48,528,528]

theorem envBound24874 : H12AffineFastState.Bounded env24874 := by
  intro p hp
  have h : env24874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24873_24874 : H12AffineEnvironment.transform 9 20 env24873 = env24874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env24873 == env24874) = true)

theorem identity24874 : scanCanonicalize (H12AffineFastState.compose env24874 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound24874 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24875 : List Nat := [2,4,8,16,17,17,8,21,512,20,529,512,24,529,16,2,512,528,20,17,528,0,17,2,24,16,513,529,529,513,5,1,21,1,528,528]

theorem envBound24875 : H12AffineFastState.Bounded env24875 := by
  intro p hp
  have h : env24875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24874_24875 : H12AffineEnvironment.transform 4 17 env24874 = env24875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env24874 == env24875) = true)

theorem identity24875 : scanCanonicalize (H12AffineFastState.compose env24875 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound24875 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24876 : List Nat := [2,4,8,1,0,0,8,4,512,5,512,512,9,512,1,2,512,513,5,0,513,0,0,2,9,1,513,512,512,513,5,1,4,1,513,513]

theorem envBound24876 : H12AffineFastState.Bounded env24876 := by
  intro p hp
  have h : env24876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24875_24876 : H12AffineEnvironment.transform 3 1 env24875 = env24876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env24875 == env24876) = true)

theorem identity24876 : scanCanonicalize (H12AffineFastState.compose env24876 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound24876 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24877 : List Nat := [2,4,8,1,0,0,8,4,1,5,1,1,9,1,1,2,1,0,5,0,0,0,0,2,9,1,0,1,1,0,5,1,4,1,0,0]

theorem envBound24877 : H12AffineFastState.Bounded env24877 := by
  intro p hp
  have h : env24877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24876_24877 : H12AffineEnvironment.transform 8 1 env24876 = env24877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env24876 == env24877) = true)

theorem identity24877 : scanCanonicalize (H12AffineFastState.compose env24877 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound24877 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24878 : List Nat := [2,4,2,1,0,0,2,4,1,5,1,1,3,1,1,2,1,0,5,0,0,0,0,2,3,1,0,1,1,0,5,1,4,1,0,0]

theorem envBound24878 : H12AffineFastState.Bounded env24878 := by
  intro p hp
  have h : env24878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24877_24878 : H12AffineEnvironment.transform 2 2 env24877 = env24878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env24877 == env24878) = true)

def env24879 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,213350,17,98645,8193,65,245018,5392,17665,32041,1364,243003,256,21792,46093,74250]

theorem envBound24879 : H12AffineFastState.Bounded env24879 := by
  intro p hp
  have h : env24879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24863_24879 : H12AffineEnvironment.transform 6 9 env24863 = env24879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24863 == env24879) = true)

theorem identity24879 : scanCanonicalize (H12AffineFastState.compose env24879 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound24879 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24880 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179513,1024,32769,4161,156013,17,41310,8193,65,171281,5392,17665,32041,1364,169264,256,21792,46093,513]

theorem envBound24880 : H12AffineFastState.Bounded env24880 := by
  intro p hp
  have h : env24880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24879_24880 : H12AffineEnvironment.transform 15 8203 env24879 = env24880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env24879 == env24880) = true)

theorem identity24880 : scanCanonicalize (H12AffineFastState.compose env24880 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound24880 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env24881 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16401,64808,1024,32769,4161,8572,17,41310,8193,65,56576,5392,17665,32041,1364,54561,256,21792,46093,513]

theorem envBound24881 : H12AffineFastState.Bounded env24881 := by
  intro p hp
  have h : env24881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24880_24881 : H12AffineEnvironment.transform 16 16401 env24880 = env24881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env24880 == env24881) = true)

theorem identity24881 : scanCanonicalize (H12AffineFastState.compose env24881 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound24881 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env24882 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16401,23669,1024,8540,4161,8572,17,3,8193,65,31837,5392,17665,32041,1364,29820,256,21792,5456,513]

theorem envBound24882 : H12AffineFastState.Bounded env24882 := by
  intro p hp
  have h : env24882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24881_24882 : H12AffineEnvironment.transform 14 8541 env24881 = env24882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env24881 == env24882) = true)

theorem identity24882 : scanCanonicalize (H12AffineFastState.compose env24882 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24882 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24883 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,8203,16401,23588,1024,8461,4112,8493,17,3,8193,16,31756,5392,17665,32041,1285,29741,256,21792,5377,513]

theorem envBound24883 : H12AffineFastState.Bounded env24883 := by
  intro p hp
  have h : env24883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24882_24883 : H12AffineEnvironment.transform 5 17 env24882 = env24883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24882 == env24883) = true)

theorem identity24883 : scanCanonicalize (H12AffineFastState.compose env24883 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 15132) := by decide +kernel

theorem selectedBound24883 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env24884 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,15132,8460,8203,15117,10040,1024,8461,4112,8493,17,3,8193,16,1808,5392,15901,1589,1285,3889,256,11836,5377,513]

theorem envBound24884 : H12AffineFastState.Bounded env24884 := by
  intro p hp
  have h : env24884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24883_24884 : H12AffineEnvironment.transform 13 15132 env24883 = env24884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15132 env24883 == env24884) = true)

theorem identity24884 : scanCanonicalize (H12AffineFastState.compose env24884 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1809) := by decide +kernel

theorem selectedBound24884 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env24885 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1809,4096,8192,13325,8460,8203,13340,10040,1024,8461,4112,8493,17,3,8193,16,1808,5392,12556,1589,1285,32,256,8493,5377,513]

theorem envBound24885 : H12AffineFastState.Bounded env24885 := by
  intro p hp
  have h : env24885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24884_24885 : H12AffineEnvironment.transform 10 1809 env24884 = env24885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1809 env24884 == env24885) = true)

theorem identity24885 : scanCanonicalize (H12AffineFastState.compose env24885 (packedSelected [1,3,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound24885 : packedSelected [1,3,7,9] rootPS < 2^1333 := by decide +kernel

def env24886 : List Nat := [2,4,8,16,32,17,9,256,512,36,821,4096,8192,12329,8460,8203,12344,8988,36,8461,4112,8493,17,3,8193,16,820,4404,12556,529,289,32,256,8493,4389,513]

theorem envBound24886 : H12AffineFastState.Bounded env24886 := by
  intro p hp
  have h : env24886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24885_24886 : H12AffineEnvironment.transform 9 36 env24885 = env24886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env24885 == env24886) = true)

theorem identity24886 : scanCanonicalize (H12AffineFastState.compose env24886 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound24886 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24887 : List Nat := [2,4,8,16,32,17,9,52,512,36,513,4096,8192,12329,8248,8203,12344,8744,36,8249,4112,8217,17,3,8193,16,512,4096,12344,529,21,32,52,8217,4113,513]

theorem envBound24887 : H12AffineFastState.Bounded env24887 := by
  intro p hp
  have h : env24887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24886_24887 : H12AffineEnvironment.transform 7 52 env24886 = env24887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env24886 == env24887) = true)

theorem identity24887 : scanCanonicalize (H12AffineFastState.compose env24887 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(12+1) ^^^ 57) := by decide +kernel

theorem selectedBound24887 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env24888 : List Nat := [2,4,8,16,32,17,9,52,512,36,513,4096,57,4112,1,50,4097,529,36,0,4112,32,17,3,56,16,512,4096,4097,529,21,32,52,32,4113,513]

theorem envBound24888 : H12AffineFastState.Bounded env24888 := by
  intro p hp
  have h : env24888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24887_24888 : H12AffineEnvironment.transform 12 57 env24887 = env24888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 57 env24887 == env24888) = true)

theorem identity24888 : scanCanonicalize (H12AffineFastState.compose env24888 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound24888 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24889 : List Nat := [2,4,8,16,32,17,9,52,33,36,32,4096,57,4112,1,50,4097,48,36,0,4112,32,17,3,56,16,33,4096,4097,48,21,32,52,32,4113,32]

theorem envBound24889 : H12AffineFastState.Bounded env24889 := by
  intro p hp
  have h : env24889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24888_24889 : H12AffineEnvironment.transform 8 33 env24888 = env24889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env24888 == env24889) = true)

theorem identity24889 : scanCanonicalize (H12AffineFastState.compose env24889 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound24889 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24890 : List Nat := [2,4,8,16,17,17,9,5,16,21,17,4096,8,4112,1,3,4097,1,21,0,4112,17,17,3,9,16,16,4096,4097,1,21,17,5,17,4113,17]

theorem envBound24890 : H12AffineFastState.Bounded env24890 := by
  intro p hp
  have h : env24890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24889_24890 : H12AffineEnvironment.transform 4 17 env24889 = env24890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env24889 == env24890) = true)

theorem identity24890 : scanCanonicalize (H12AffineFastState.compose env24890 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound24890 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24891 : List Nat := [2,4,8,0,1,1,9,5,0,5,1,4096,8,4096,1,3,4097,1,5,0,4096,1,1,3,9,0,0,4096,4097,1,5,1,5,1,4097,1]

theorem envBound24891 : H12AffineFastState.Bounded env24891 := by
  intro p hp
  have h : env24891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24890_24891 : H12AffineEnvironment.transform 3 0 env24890 = env24891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env24890 == env24891) = true)

theorem identity24891 : scanCanonicalize (H12AffineFastState.compose env24891 (packedSelected [3] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound24891 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env24892 : List Nat := [2,4,8,0,1,1,9,5,0,5,1,0,8,0,1,3,1,1,5,0,0,1,1,3,9,0,0,0,1,1,5,1,5,1,1,1]

theorem envBound24892 : H12AffineFastState.Bounded env24892 := by
  intro p hp
  have h : env24892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24891_24892 : H12AffineEnvironment.transform 11 0 env24891 = env24892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env24891 == env24892) = true)

def env24893 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830976,25265168,23160256,257,27378861,27337992,25207750]

theorem envBound24893 : H12AffineFastState.Bounded env24893 := by
  intro p hp
  have h : env24893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24713_24893 : H12AffineEnvironment.transform 18 1025 env24713 = env24893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env24713 == env24893) = true)

theorem identity24893 : scanCanonicalize (H12AffineFastState.compose env24893 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2444776) := by decide +kernel

theorem selectedBound24893 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env24894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2444776,8328,65,14847464,313700,10507601,8830976,10799608,4466728,257,8685893,8677600,10874414]

theorem envBound24894 : H12AffineFastState.Bounded env24894 := by
  intro p hp
  have h : env24894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24893_24894 : H12AffineEnvironment.transform 23 2444776 env24893 = env24894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2444776 env24893 == env24894) = true)

def env24895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318564,2444776,8328,65,6705548,313700,2394421,138340,2102684,4466728,257,21793,46212,2175562]

theorem envBound24895 : H12AffineFastState.Bounded env24895 := by
  intro p hp
  have h : env24895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24894_24895 : H12AffineEnvironment.transform 22 318564 env24894 = env24895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 318564 env24894 == env24895) = true)

def env24896 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318564,2444640,8192,65,6705412,313700,2394421,138340,2102548,4466728,257,21793,46092,2175562]

theorem envBound24896 : H12AffineFastState.Bounded env24896 := by
  intro p hp
  have h : env24896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24895_24896 : H12AffineEnvironment.transform 6 8 env24895 = env24896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24895 == env24896) = true)

theorem identity24896 : scanCanonicalize (H12AffineFastState.compose env24896 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound24896 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env24897 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,77899,4194304,318564,294187,8192,65,4677967,313700,375166,138340,75103,4466728,257,21793,46092,513]

theorem envBound24897 : H12AffineFastState.Bounded env24897 := by
  intro p hp
  have h : env24897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24896_24897 : H12AffineEnvironment.transform 20 77899 env24896 = env24897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env24896 == env24897) = true)

def env24898 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,77899,4194304,62540,21763,8192,65,4409703,57676,102742,138340,75103,4194304,257,21793,46092,513]

theorem envBound24898 : H12AffineFastState.Bounded env24898 := by
  intro p hp
  have h : env24898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24897_24898 : H12AffineEnvironment.transform 17 10280 env24897 = env24898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env24897 == env24898) = true)

def env24899 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10280,1025,29789,77899,4194304,16,21763,8192,65,4409703,5392,91402,138340,75103,4194304,257,21793,16464,513]

theorem envBound24899 : H12AffineFastState.Bounded env24899 := by
  intro p hp
  have h : env24899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24898_24899 : H12AffineEnvironment.transform 14 29788 env24898 = env24899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env24898 == env24899) = true)

theorem identity24899 : scanCanonicalize (H12AffineFastState.compose env24899 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound24899 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env24900 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90138,10280,1025,29789,77899,4194304,16,21763,8192,65,4204925,5392,91402,97406,75103,4194304,257,21793,16464,513]

theorem envBound24900 : H12AffineFastState.Bounded env24900 := by
  intro p hp
  have h : env24900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24899_24900 : H12AffineEnvironment.transform 16 90138 env24899 = env24900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env24899 == env24900) = true)

theorem identity24900 : scanCanonicalize (H12AffineFastState.compose env24900 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 73771) := by decide +kernel

theorem selectedBound24900 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24901 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90138,10280,1025,29789,77899,73771,16,21763,8192,65,67926,5392,91402,97406,75103,73771,257,21793,16464,513]

theorem envBound24901 : H12AffineFastState.Bounded env24901 := by
  intro p hp
  have h : env24901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24900_24901 : H12AffineEnvironment.transform 21 73771 env24900 = env24901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73771 env24900 == env24901) = true)

theorem identity24901 : scanCanonicalize (H12AffineFastState.compose env24901 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound24901 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env24902 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,16400,10280,1025,29789,4161,33,16,21763,8192,65,10588,5392,17664,23668,1365,33,257,21793,16464,513]

theorem envBound24902 : H12AffineFastState.Bounded env24902 := by
  intro p hp
  have h : env24902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24901_24902 : H12AffineEnvironment.transform 15 8202 env24901 = env24902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env24901 == env24902) = true)

theorem identity24902 : scanCanonicalize (H12AffineFastState.compose env24902 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound24902 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24903 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8461,8202,5441,10280,1025,8460,4161,33,16,82,8192,65,10588,5392,4177,2341,1365,33,257,112,5377,513]

theorem envBound24903 : H12AffineFastState.Bounded env24903 := by
  intro p hp
  have h : env24903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24902_24903 : H12AffineEnvironment.transform 13 5457 env24902 = env24903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env24902 == env24903) = true)

theorem identity24903 : scanCanonicalize (H12AffineFastState.compose env24903 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound24903 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env24904 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1061,8192,372,8461,8202,356,10280,1025,8460,1124,33,16,82,8192,65,10588,309,1140,2341,1365,33,257,112,292,513]

theorem envBound24904 : H12AffineFastState.Bounded env24904 := by
  intro p hp
  have h : env24904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24903_24904 : H12AffineEnvironment.transform 11 1061 env24903 = env24904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env24903 == env24904) = true)

theorem identity24904 : scanCanonicalize (H12AffineFastState.compose env24904 (packedSelected [0,2,3,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1108) := by decide +kernel

theorem selectedBound24904 : packedSelected [0,2,3,7,8] rootPS < 2^1333 := by decide +kernel

def env24905 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1108,1061,8192,372,8461,8202,356,9340,1025,8460,1124,33,16,82,8192,65,9480,309,1140,1393,1365,33,257,112,292,513]

theorem envBound24905 : H12AffineFastState.Bounded env24905 := by
  intro p hp
  have h : env24905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24904_24905 : H12AffineEnvironment.transform 10 1108 env24904 = env24905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1108 env24904 == env24905) = true)

theorem identity24905 : scanCanonicalize (H12AffineFastState.compose env24905 (packedSelected [0,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24905 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env24906 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1029,1061,8192,293,8461,8202,309,9261,1025,8460,1077,33,16,3,8192,16,9480,309,1061,1312,1284,33,257,33,292,513]

theorem envBound24906 : H12AffineFastState.Bounded env24906 := by
  intro p hp
  have h : env24906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24905_24906 : H12AffineEnvironment.transform 5 17 env24905 = env24906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24905 == env24906) = true)

theorem identity24906 : scanCanonicalize (H12AffineFastState.compose env24906 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound24906 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24907 : List Nat := [2,4,8,16,32,17,8,5,512,1024,1029,1061,8192,32,8200,8202,48,9261,1025,8201,1077,33,16,3,8192,16,9229,48,1061,1061,1025,33,4,33,33,513]

theorem envBound24907 : H12AffineFastState.Bounded env24907 := by
  intro p hp
  have h : env24907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24906_24907 : H12AffineEnvironment.transform 7 5 env24906 = env24907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env24906 == env24907) = true)

theorem identity24907 : scanCanonicalize (H12AffineFastState.compose env24907 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound24907 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24908 : List Nat := [2,4,8,16,32,17,8,5,512,1024,1029,1061,8,32,0,2,48,1061,1025,1,1077,33,16,3,8,16,1029,48,1061,1061,1025,33,4,33,33,513]

theorem envBound24908 : H12AffineFastState.Bounded env24908 := by
  intro p hp
  have h : env24908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24907_24908 : H12AffineEnvironment.transform 12 8 env24907 = env24908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env24907 == env24908) = true)

theorem identity24908 : scanCanonicalize (H12AffineFastState.compose env24908 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound24908 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24909 : List Nat := [2,4,8,16,32,17,8,5,512,53,48,16,8,32,0,2,48,16,52,1,0,33,16,3,8,16,48,48,16,16,52,33,4,33,33,513]

theorem envBound24909 : H12AffineFastState.Bounded env24909 := by
  intro p hp
  have h : env24909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24908_24909 : H12AffineEnvironment.transform 9 53 env24908 = env24909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env24908 == env24909) = true)

theorem identity24909 : scanCanonicalize (H12AffineFastState.compose env24909 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound24909 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24910 : List Nat := [2,4,8,16,32,17,8,5,33,53,48,16,8,32,0,2,48,16,52,1,0,33,16,3,8,16,48,48,16,16,52,33,4,33,33,32]

theorem envBound24910 : H12AffineFastState.Bounded env24910 := by
  intro p hp
  have h : env24910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24909_24910 : H12AffineEnvironment.transform 8 33 env24909 = env24910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env24909 == env24910) = true)

theorem identity24910 : scanCanonicalize (H12AffineFastState.compose env24910 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound24910 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env24911 : List Nat := [2,4,8,1,32,0,8,5,33,36,33,1,8,32,0,2,33,1,37,1,0,33,1,3,8,1,33,33,1,1,37,33,4,33,33,32]

theorem envBound24911 : H12AffineFastState.Bounded env24911 := by
  intro p hp
  have h : env24911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24910_24911 : H12AffineEnvironment.transform 3 1 env24910 = env24911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env24910 == env24911) = true)

theorem identity24911 : scanCanonicalize (H12AffineFastState.compose env24911 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24911 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24912 : List Nat := [2,4,8,1,1,0,8,5,0,5,0,1,8,1,0,2,0,1,4,1,0,0,1,3,8,1,0,0,1,1,4,0,4,0,0,1]

theorem envBound24912 : H12AffineFastState.Bounded env24912 := by
  intro p hp
  have h : env24912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24911_24912 : H12AffineEnvironment.transform 4 1 env24911 = env24912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24911 == env24912) = true)

def env24913 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10280,1025,29788,77899,4194304,17,21763,8192,65,4409703,5393,91403,138340,75103,4194304,257,21793,16465,513]

theorem envBound24913 : H12AffineFastState.Bounded env24913 := by
  intro p hp
  have h : env24913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24898_24913 : H12AffineEnvironment.transform 14 29789 env24898 = env24913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env24898 == env24913) = true)

def env24914 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10280,1025,29788,77899,21792,17,21763,8192,65,203847,5393,91403,138340,75103,21792,257,21793,16465,513]

theorem envBound24914 : H12AffineFastState.Bounded env24914 := by
  intro p hp
  have h : env24914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24913_24914 : H12AffineEnvironment.transform 21 21792 env24913 = env24914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env24913 == env24914) = true)

theorem identity24914 : scanCanonicalize (H12AffineFastState.compose env24914 (packedSelected [0,7,11,12,15,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound24914 : packedSelected [0,7,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env24915 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,81,65536,131072,10280,1025,80,77899,8492,17,8463,8192,65,203847,5393,69895,138340,75103,8492,257,8493,13405,513]

theorem envBound24915 : H12AffineFastState.Bounded env24915 := by
  intro p hp
  have h : env24915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24914_24915 : H12AffineEnvironment.transform 13 13324 env24914 = env24915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env24914 == env24915) = true)

theorem identity24915 : scanCanonicalize (H12AffineFastState.compose env24915 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24915 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env24916 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13324,0,65536,131072,10280,1025,1,77850,8492,17,8463,8192,16,203798,5393,69895,138293,75022,8492,257,8493,13324,513]

theorem envBound24916 : H12AffineFastState.Bounded env24916 := by
  intro p hp
  have h : env24916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24915_24916 : H12AffineEnvironment.transform 5 17 env24915 = env24916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24915 == env24916) = true)

theorem identity24916 : scanCanonicalize (H12AffineFastState.compose env24916 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound24916 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env24917 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,0,65536,131072,2340,1025,1,69910,32,17,3,268,16,203798,5393,69895,138293,66562,32,257,33,5376,513]

theorem envBound24917 : H12AffineFastState.Bounded env24917 := by
  intro p hp
  have h : env24917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24916_24917 : H12AffineEnvironment.transform 12 268 env24916 = env24917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env24916 == env24917) = true)

theorem identity24917 : scanCanonicalize (H12AffineFastState.compose env24917 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 70678) := by decide +kernel

theorem selectedBound24917 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24918 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,0,65536,70678,2340,1025,1,69910,32,17,3,268,16,2048,5393,69895,67619,66562,32,257,33,5376,513]

theorem envBound24918 : H12AffineFastState.Bounded env24918 := by
  intro p hp
  have h : env24918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24917_24918 : H12AffineEnvironment.transform 16 70678 env24917 = env24918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70678 env24917 == env24918) = true)

theorem identity24918 : scanCanonicalize (H12AffineFastState.compose env24918 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(15+1) ^^^ 5426) := by decide +kernel

theorem selectedBound24918 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env24919 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,0,5426,292,2340,1025,1,1060,32,17,3,268,16,2048,5393,1077,7441,4400,32,257,33,5376,513]

theorem envBound24919 : H12AffineFastState.Bounded env24919 := by
  intro p hp
  have h : env24919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24918_24919 : H12AffineEnvironment.transform 15 5426 env24918 = env24919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5426 env24918 == env24919) = true)

theorem identity24919 : scanCanonicalize (H12AffineFastState.compose env24919 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound24919 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env24920 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,513,268,1793,0,1843,292,2340,1025,1,1060,32,17,3,268,16,2048,1808,1077,3856,817,32,257,33,1793,513]

theorem envBound24920 : H12AffineFastState.Bounded env24920 := by
  intro p hp
  have h : env24920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24919_24920 : H12AffineEnvironment.transform 11 513 env24919 = env24920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env24919 == env24920) = true)

theorem identity24920 : scanCanonicalize (H12AffineFastState.compose env24920 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound24920 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env24921 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,513,268,528,0,546,292,2340,272,1,309,32,17,3,268,16,2048,513,292,2561,817,32,257,33,528,513]

theorem envBound24921 : H12AffineFastState.Bounded env24921 := by
  intro p hp
  have h : env24921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24920_24921 : H12AffineEnvironment.transform 9 273 env24920 = env24921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env24920 == env24921) = true)

theorem identity24921 : scanCanonicalize (H12AffineFastState.compose env24921 (packedSelected [0,1,4,5,14] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound24921 : packedSelected [0,1,4,5,14] rootPS < 2^1333 := by decide +kernel

def env24922 : List Nat := [2,4,8,16,32,17,8,256,292,273,2048,293,268,308,0,262,292,2340,272,1,309,32,17,3,268,16,2048,293,292,2341,21,32,257,33,308,293]

theorem envBound24922 : H12AffineFastState.Bounded env24922 := by
  intro p hp
  have h : env24922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24921_24922 : H12AffineEnvironment.transform 8 292 env24921 = env24922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env24921 == env24922) = true)

theorem identity24922 : scanCanonicalize (H12AffineFastState.compose env24922 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound24922 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24923 : List Nat := [2,4,8,16,32,17,8,53,17,36,2048,16,57,1,0,51,17,2065,37,1,0,32,17,3,57,16,2048,16,17,2064,21,32,52,33,1,16]

theorem envBound24923 : H12AffineFastState.Bounded env24923 := by
  intro p hp
  have h : env24923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24922_24923 : H12AffineEnvironment.transform 7 53 env24922 = env24923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env24922 == env24923) = true)

theorem identity24923 : scanCanonicalize (H12AffineFastState.compose env24923 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound24923 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24924 : List Nat := [2,4,8,16,26,17,8,15,17,30,2048,16,3,1,0,9,17,2065,31,1,0,26,17,3,3,16,2048,16,17,2064,21,26,14,27,1,16]

theorem envBound24924 : H12AffineFastState.Bounded env24924 := by
  intro p hp
  have h : env24924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24923_24924 : H12AffineEnvironment.transform 4 26 env24923 = env24924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env24923 == env24924) = true)

def env24925 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10280,1025,29788,77899,21793,17,21763,8192,65,203846,5393,91403,138340,75103,21793,257,21793,16465,513]

theorem envBound24925 : H12AffineFastState.Bounded env24925 := by
  intro p hp
  have h : env24925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24913_24925 : H12AffineEnvironment.transform 21 21793 env24913 = env24925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env24913 == env24925) = true)

theorem identity24925 : scanCanonicalize (H12AffineFastState.compose env24925 (packedSelected [0,7,11,12,15,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound24925 : packedSelected [0,7,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env24926 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,1,65536,131072,10280,1025,0,77899,8573,17,8543,8192,65,203846,5393,69975,138340,75103,8573,257,8573,13325,513]

theorem envBound24926 : H12AffineFastState.Bounded env24926 := by
  intro p hp
  have h : env24926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24925_24926 : H12AffineEnvironment.transform 13 13404 env24925 = env24926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env24925 == env24926) = true)

theorem identity24926 : scanCanonicalize (H12AffineFastState.compose env24926 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound24926 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env24927 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5456,1,65536,131072,2340,1025,0,69959,113,17,83,268,65,203846,5393,69975,138340,66643,113,257,113,5377,513]

theorem envBound24927 : H12AffineFastState.Bounded env24927 := by
  intro p hp
  have h : env24927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24926_24927 : H12AffineEnvironment.transform 12 268 env24926 = env24927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env24926 == env24927) = true)

theorem identity24927 : scanCanonicalize (H12AffineFastState.compose env24927 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound24927 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env24928 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5456,1,65536,5392,2340,1025,0,69959,113,17,83,268,65,67926,5393,69975,2420,66643,113,257,113,5377,513]

theorem envBound24928 : H12AffineFastState.Bounded env24928 := by
  intro p hp
  have h : env24928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24927_24928 : H12AffineEnvironment.transform 16 5392 env24927 = env24928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env24927 == env24928) = true)

theorem identity24928 : scanCanonicalize (H12AffineFastState.compose env24928 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound24928 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24929 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5456,1,343,5392,2340,1025,0,4112,113,17,83,268,65,2049,5393,4096,2420,1284,113,257,113,5377,513]

theorem envBound24929 : H12AffineFastState.Bounded env24929 := by
  intro p hp
  have h : env24929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24928_24929 : H12AffineEnvironment.transform 15 343 env24928 = env24929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env24928 == env24929) = true)

theorem identity24929 : scanCanonicalize (H12AffineFastState.compose env24929 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound24929 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env24930 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2113,268,3345,1,343,3409,2340,1025,0,2129,113,17,83,268,65,2049,3408,2113,2420,1284,113,257,113,3392,513]

theorem envBound24930 : H12AffineFastState.Bounded env24930 := by
  intro p hp
  have h : env24930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24929_24930 : H12AffineEnvironment.transform 11 2113 env24929 = env24930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env24929 == env24930) = true)

theorem identity24930 : scanCanonicalize (H12AffineFastState.compose env24930 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1345) := by decide +kernel

theorem selectedBound24930 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env24931 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1345,1280,268,80,1,343,16,1125,1025,0,1296,113,17,83,268,65,1344,17,1280,1077,1284,113,257,113,1,513]

theorem envBound24931 : H12AffineFastState.Bounded env24931 := by
  intro p hp
  have h : env24931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24930_24931 : H12AffineEnvironment.transform 10 1345 env24930 = env24931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env24930 == env24931) = true)

theorem identity24931 : scanCanonicalize (H12AffineFastState.compose env24931 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound24931 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env24932 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1076,1141,121,80,1,34,16,1125,1025,0,1125,113,17,83,121,65,1077,17,1141,1077,1137,113,116,113,1,513]

theorem envBound24932 : H12AffineFastState.Bounded env24932 := by
  intro p hp
  have h : env24932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24931_24932 : H12AffineEnvironment.transform 7 117 env24931 = env24932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env24931 == env24932) = true)

theorem identity24932 : scanCanonicalize (H12AffineFastState.compose env24932 (packedSelected [0,4,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24932 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env24933 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1076,1061,41,0,1,34,16,1077,1025,0,1077,33,17,3,41,17,1077,17,1061,1077,1057,33,36,33,1,513]

theorem envBound24933 : H12AffineFastState.Bounded env24933 := by
  intro p hp
  have h : env24933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24932_24933 : H12AffineEnvironment.transform 5 16 env24932 = env24933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24932 == env24933) = true)

theorem identity24933 : scanCanonicalize (H12AffineFastState.compose env24933 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound24933 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24934 : List Nat := [2,4,8,0,32,0,8,37,512,1024,1060,1061,41,0,1,34,0,1061,1025,0,1061,33,1,3,41,1,1061,1,1061,1061,1057,33,36,33,1,513]

theorem envBound24934 : H12AffineFastState.Bounded env24934 := by
  intro p hp
  have h : env24934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24933_24934 : H12AffineEnvironment.transform 3 0 env24933 = env24934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env24933 == env24934) = true)

theorem identity24934 : scanCanonicalize (H12AffineFastState.compose env24934 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound24934 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24935 : List Nat := [2,4,3,0,32,0,3,37,512,1024,1060,1061,34,0,1,34,0,1061,1025,0,1061,33,1,3,34,1,1061,1,1061,1061,1057,33,36,33,1,513]

theorem envBound24935 : H12AffineFastState.Bounded env24935 := by
  intro p hp
  have h : env24935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24934_24935 : H12AffineEnvironment.transform 2 3 env24934 = env24935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env24934 == env24935) = true)

theorem identity24935 : scanCanonicalize (H12AffineFastState.compose env24935 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24935 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24936 : List Nat := [2,4,3,0,1,0,3,4,512,1024,1029,1028,3,0,1,3,0,1028,1025,0,1028,0,1,3,3,1,1028,1,1028,1028,1024,0,5,0,1,513]

theorem envBound24936 : H12AffineFastState.Bounded env24936 := by
  intro p hp
  have h : env24936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24935_24936 : H12AffineEnvironment.transform 4 1 env24935 = env24936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24935 == env24936) = true)

theorem identity24936 : scanCanonicalize (H12AffineFastState.compose env24936 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 0) := by decide +kernel

theorem selectedBound24936 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24937 : List Nat := [2,4,3,0,1,0,3,4,512,0,5,4,3,0,1,3,0,4,1,0,4,0,1,3,3,1,4,1,4,4,0,0,5,0,1,513]

theorem envBound24937 : H12AffineFastState.Bounded env24937 := by
  intro p hp
  have h : env24937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24936_24937 : H12AffineEnvironment.transform 9 0 env24936 = env24937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env24936 == env24937) = true)

def env24938 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,77899,4194304,62541,21762,8192,65,4409702,57677,102743,138340,75103,4194305,257,21793,46092,513]

theorem envBound24938 : H12AffineFastState.Bounded env24938 := by
  intro p hp
  have h : env24938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24897_24938 : H12AffineEnvironment.transform 17 10281 env24897 = env24938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env24897 == env24938) = true)

theorem identity24938 : scanCanonicalize (H12AffineFastState.compose env24938 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound24938 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env24939 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10281,1025,29789,77899,4194304,17,21762,8192,65,4409702,5393,91403,138340,75103,4194305,257,21793,16464,513]

theorem envBound24939 : H12AffineFastState.Bounded env24939 := by
  intro p hp
  have h : env24939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24938_24939 : H12AffineEnvironment.transform 14 29788 env24938 = env24939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env24938 == env24939) = true)

theorem identity24939 : scanCanonicalize (H12AffineFastState.compose env24939 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound24939 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24940 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,131072,10281,1025,29789,4160,4194304,17,21762,8192,65,4352365,5393,17664,138340,1364,4194305,257,21793,16464,513]

theorem envBound24940 : H12AffineFastState.Bounded env24940 := by
  intro p hp
  have h : env24940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24939_24940 : H12AffineEnvironment.transform 15 8203 env24939 = env24940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env24939 == env24940) = true)

theorem identity24940 : scanCanonicalize (H12AffineFastState.compose env24940 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 29741) := by decide +kernel

theorem selectedBound24940 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env24941 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,131072,10281,1025,29789,4160,29741,17,21762,8192,65,138560,5393,17664,138340,1364,29740,257,21793,16464,513]

theorem envBound24941 : H12AffineFastState.Bounded env24941 := by
  intro p hp
  have h : env24941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24940_24941 : H12AffineEnvironment.transform 21 29741 env24940 = env24941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29741 env24940 == env24941) = true)

theorem identity24941 : scanCanonicalize (H12AffineFastState.compose env24941 (packedSelected [1,4,8,9,10,12,18] rootPS)) = affineNative (2^(16+1) ^^^ 10296) := by decide +kernel

theorem selectedBound24941 : packedSelected [1,4,8,9,10,12,18] rootPS < 2^1333 := by decide +kernel

def env24942 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,10296,10281,1025,29789,4160,29741,17,21762,8192,65,13688,5393,17664,13404,1364,29740,257,21793,16464,513]

theorem envBound24942 : H12AffineFastState.Bounded env24942 := by
  intro p hp
  have h : env24942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24941_24942 : H12AffineEnvironment.transform 16 10296 env24941 = env24942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 10296 env24941 == env24942) = true)

theorem identity24942 : scanCanonicalize (H12AffineFastState.compose env24942 (packedSelected [0,4,7,9,11,20] rootPS)) = affineNative (2^(13+1) ^^^ 15453) := by decide +kernel

theorem selectedBound24942 : packedSelected [0,4,7,9,11,20] rootPS < 2^1333 := by decide +kernel

def env24943 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,15453,2049,8203,10296,10281,1025,2048,4160,2160,17,10591,8192,65,13688,5393,14685,13404,1364,2161,257,10620,15373,513]

theorem envBound24943 : H12AffineFastState.Bounded env24943 := by
  intro p hp
  have h : env24943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24942_24943 : H12AffineEnvironment.transform 13 15453 env24942 = env24943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15453 env24942 == env24943) = true)

theorem identity24943 : scanCanonicalize (H12AffineFastState.compose env24943 (packedSelected [1,2,5,6,8,12,15,24] rootPS)) = affineNative (2^(12+1) ^^^ 3149) := by decide +kernel

theorem selectedBound24943 : packedSelected [1,2,5,6,8,12,15,24] rootPS < 2^1333 := by decide +kernel

def env24944 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3149,4112,2049,3142,1141,1124,1025,2048,4160,2160,17,1298,3149,65,6453,5393,5392,6161,1364,2161,257,1329,4160,513]

theorem envBound24944 : H12AffineFastState.Bounded env24944 := by
  intro p hp
  have h : env24944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24943_24944 : H12AffineEnvironment.transform 12 3149 env24943 = env24944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3149 env24943 == env24944) = true)

theorem identity24944 : scanCanonicalize (H12AffineFastState.compose env24944 (packedSelected [1,2,3,5,6,8,10,12,15,26] rootPS)) = affineNative (2^(11+1) ^^^ 1140) := by decide +kernel

theorem selectedBound24944 : packedSelected [1,2,3,5,6,8,10,12,15,26] rootPS < 2^1333 := by decide +kernel

def env24945 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1140,3149,1124,2049,3142,1141,1124,1025,2048,1076,2160,17,1298,3149,65,3393,357,356,3173,1364,2161,257,1329,1076,513]

theorem envBound24945 : H12AffineFastState.Bounded env24945 := by
  intro p hp
  have h : env24945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24944_24945 : H12AffineEnvironment.transform 11 1140 env24944 = env24945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1140 env24944 == env24945) = true)

theorem identity24945 : scanCanonicalize (H12AffineFastState.compose env24945 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound24945 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24946 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,357,2396,373,2049,2391,356,373,272,2048,293,2160,17,3,2396,65,2128,357,356,2420,69,2161,257,32,293,513]

theorem envBound24946 : H12AffineFastState.Bounded env24946 := by
  intro p hp
  have h : env24946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24945_24946 : H12AffineEnvironment.transform 9 273 env24945 = env24946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env24945 == env24946) = true)

theorem identity24946 : scanCanonicalize (H12AffineFastState.compose env24946 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound24946 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24947 : List Nat := [2,4,8,16,32,64,8,256,512,273,80,357,268,373,81,263,356,373,272,80,293,32,17,3,268,65,0,357,356,292,69,33,257,32,293,513]

theorem envBound24947 : H12AffineFastState.Bounded env24947 := by
  intro p hp
  have h : env24947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24946_24947 : H12AffineEnvironment.transform 10 80 env24946 = env24947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env24946 == env24947) = true)

def env24948 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318564,2444641,8193,65,6705413,313700,2394421,138340,2102549,4466728,257,21793,46093,2175562]

theorem envBound24948 : H12AffineFastState.Bounded env24948 := by
  intro p hp
  have h : env24948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24895_24948 : H12AffineEnvironment.transform 6 9 env24895 = env24948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24895 == env24948) = true)

def env24949 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2373704,318564,2444641,8193,65,158029,313700,2394421,138340,2102549,2101344,257,21793,46093,2175562]

theorem envBound24949 : H12AffineFastState.Bounded env24949 := by
  intro p hp
  have h : env24949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24948_24949 : H12AffineEnvironment.transform 21 2373704 env24948 = env24949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2373704 env24948 == env24949) = true)

theorem identity24949 : scanCanonicalize (H12AffineFastState.compose env24949 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound24949 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env24950 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,77899,329731,318564,294186,8193,65,158029,313700,375166,138340,75102,73771,257,21793,46093,513]

theorem envBound24950 : H12AffineFastState.Bounded env24950 := by
  intro p hp
  have h : env24950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24949_24950 : H12AffineEnvironment.transform 20 77899 env24949 = env24950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env24949 == env24950) = true)

theorem identity24950 : scanCanonicalize (H12AffineFastState.compose env24950 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound24950 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env24951 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1025,32769,77899,329731,318564,294186,8193,65,67927,313700,375166,97406,75102,73771,257,21793,46093,513]

theorem envBound24951 : H12AffineFastState.Bounded env24951 := by
  intro p hp
  have h : env24951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24950_24951 : H12AffineEnvironment.transform 16 90138 env24950 = env24951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env24950 == env24951) = true)

theorem identity24951 : scanCanonicalize (H12AffineFastState.compose env24951 (packedSelected [12,15,17,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 130174) := by decide +kernel

theorem selectedBound24951 : packedSelected [12,15,17,38,41] rootPS < 2^1333 := by decide +kernel

def env24952 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,130174,1025,32769,77899,62589,73754,98644,8193,65,67927,79130,17664,97406,75102,73771,257,21793,46093,513]

theorem envBound24952 : H12AffineFastState.Bounded env24952 := by
  intro p hp
  have h : env24952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24951_24952 : H12AffineEnvironment.transform 17 130174 env24951 = env24952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130174 env24951 == env24952) = true)

theorem identity24952 : scanCanonicalize (H12AffineFastState.compose env24952 (packedSelected [2,4,6,9,11,14,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound24952 : packedSelected [2,4,6,9,11,14,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env24953 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,263,24861,64889,1025,32769,12620,62589,8477,32851,8193,65,2128,13341,17664,32121,9305,8492,257,21793,46093,513]

theorem envBound24953 : H12AffineFastState.Bounded env24953 := by
  intro p hp
  have h : env24953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24952_24953 : H12AffineEnvironment.transform 15 263 env24952 = env24953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env24952 == env24953) = true)

theorem identity24953 : scanCanonicalize (H12AffineFastState.compose env24953 (packedSelected [2,3,4,5,6,9,10,12,14,15,18,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound24953 : packedSelected [2,3,4,5,6,9,10,12,14,15,18,20,23] rootPS < 2^1333 := by decide +kernel

def env24954 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,32768,263,16741,56577,1025,32769,4404,54277,357,32851,121,65,2128,5221,17664,23809,1057,340,257,21793,38005,513]

theorem envBound24954 : H12AffineFastState.Bounded env24954 := by
  intro p hp
  have h : env24954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24953_24954 : H12AffineEnvironment.transform 12 120 env24953 = env24954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env24953 == env24954) = true)

theorem identity24954 : scanCanonicalize (H12AffineFastState.compose env24954 (packedSelected [0,2,7,11,14,17,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 4452) := by decide +kernel

theorem selectedBound24954 : packedSelected [0,2,7,11,14,17,18,20] rootPS < 2^1333 := by decide +kernel

def env24955 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,4452,32768,263,4097,35941,1025,32769,4404,34145,357,32851,121,65,2128,5221,5220,3173,1057,340,257,1093,38005,513]

theorem envBound24955 : H12AffineFastState.Bounded env24955 := by
  intro p hp
  have h : env24955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24954_24955 : H12AffineEnvironment.transform 13 4452 env24954 = env24955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4452 env24954 == env24955) = true)

theorem identity24955 : scanCanonicalize (H12AffineFastState.compose env24955 (packedSelected [1,2,3,5,7,8,9,10,11,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound24955 : packedSelected [1,2,3,5,7,8,9,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env24956 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2357,120,2129,32768,263,2356,35941,1025,32769,2049,34145,357,32851,121,65,2128,3408,3409,3173,1057,340,257,1093,36160,513]

theorem envBound24956 : H12AffineFastState.Bounded env24956 := by
  intro p hp
  have h : env24956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24955_24956 : H12AffineEnvironment.transform 11 2357 env24955 = env24956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env24955 == env24956) = true)

theorem identity24956 : scanCanonicalize (H12AffineFastState.compose env24956 (packedSelected [0,2,3,8,9] rootPS)) = affineNative (2^(14+1) ^^^ 1345) := by decide +kernel

theorem selectedBound24956 : packedSelected [0,2,3,8,9] rootPS < 2^1333 := by decide +kernel

def env24957 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2357,120,2129,1345,263,2356,2340,1025,1344,2049,32,357,1298,121,65,2128,3408,3409,3173,1057,340,257,1093,2049,513]

theorem envBound24957 : H12AffineFastState.Bounded env24957 := by
  intro p hp
  have h : env24957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24956_24957 : H12AffineEnvironment.transform 14 1345 env24956 = env24957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1345 env24956 == env24957) = true)

theorem identity24957 : scanCanonicalize (H12AffineFastState.compose env24957 (packedSelected [3,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24957 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env24958 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2357,40,2049,1297,263,2356,2340,1025,1296,2049,32,309,1298,41,17,2048,3328,3329,3125,1057,260,257,1045,2049,513]

theorem envBound24958 : H12AffineFastState.Bounded env24958 := by
  intro p hp
  have h : env24958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24957_24958 : H12AffineEnvironment.transform 5 16 env24957 = env24958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24957 == env24958) = true)

theorem identity24958 : scanCanonicalize (H12AffineFastState.compose env24958 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound24958 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env24959 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,2064,40,2049,1076,34,2065,2049,1025,1077,2049,32,16,1079,41,17,2048,3109,3108,3125,1057,33,36,1045,2049,513]

theorem envBound24959 : H12AffineFastState.Bounded env24959 := by
  intro p hp
  have h : env24959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24958_24959 : H12AffineEnvironment.transform 7 37 env24958 = env24959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env24958 == env24959) = true)

theorem identity24959 : scanCanonicalize (H12AffineFastState.compose env24959 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound24959 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24960 : List Nat := [2,4,8,16,32,16,9,37,512,1024,1076,1060,40,1077,1076,34,1061,1077,1025,1077,1077,32,16,1079,41,17,1076,17,16,1,1057,33,36,1045,1077,513]

theorem envBound24960 : H12AffineFastState.Bounded env24960 := by
  intro p hp
  have h : env24960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24959_24960 : H12AffineEnvironment.transform 10 1076 env24959 = env24960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env24959 == env24960) = true)

def env24961 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2373705,318564,2444641,8193,65,158028,313700,2394421,138340,2102549,2101345,257,21793,46093,2175562]

theorem envBound24961 : H12AffineFastState.Bounded env24961 := by
  intro p hp
  have h : env24961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24948_24961 : H12AffineEnvironment.transform 21 2373705 env24948 = env24961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2373705 env24948 == env24961) = true)

def env24962 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,272393,318564,351521,8193,65,158028,313700,301429,138340,1365,33,257,21793,46093,74250]

theorem envBound24962 : H12AffineFastState.Bounded env24962 := by
  intro p hp
  have h : env24962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24961_24962 : H12AffineEnvironment.transform 20 4160 env24961 = env24962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env24961 == env24962) = true)

theorem identity24962 : scanCanonicalize (H12AffineFastState.compose env24962 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound24962 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24963 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,21792,41293,73736,8193,65,158028,46157,58460,138340,1365,33,257,21793,46093,74250]

theorem envBound24963 : H12AffineFastState.Bounded env24963 := by
  intro p hp
  have h : env24963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24962_24963 : H12AffineEnvironment.transform 17 32041 env24962 = env24963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env24962 == env24963) = true)

theorem identity24963 : scanCanonicalize (H12AffineFastState.compose env24963 (packedSelected [1,5,8,16,19,20,21,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound24963 : packedSelected [1,5,8,16,19,20,21,24,26] rootPS < 2^1333 := by decide +kernel

def env24964 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,79131,32041,1025,32769,4160,21792,41293,73736,8193,65,89175,46157,58460,76159,1365,33,257,21793,46093,74250]

theorem envBound24964 : H12AffineFastState.Bounded env24964 := by
  intro p hp
  have h : env24964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24963_24964 : H12AffineEnvironment.transform 16 79131 env24963 = env24964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env24963 == env24964) = true)

theorem identity24964 : scanCanonicalize (H12AffineFastState.compose env24964 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound24964 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env24965 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,79131,10280,1025,32769,4160,33,41293,73736,8193,65,67926,46157,45405,76159,1365,33,257,32,46093,74250]

theorem envBound24965 : H12AffineFastState.Bounded env24965 := by
  intro p hp
  have h : env24965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24964_24965 : H12AffineEnvironment.transform 13 5377 env24964 = env24965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env24964 == env24965) = true)

theorem identity24965 : scanCanonicalize (H12AffineFastState.compose env24965 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound24965 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24966 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8203,5392,10280,1025,32769,4160,33,41293,3,8193,65,10589,46157,45405,2420,1365,33,257,32,46093,513]

theorem envBound24966 : H12AffineFastState.Bounded env24966 := by
  intro p hp
  have h : env24966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24965_24966 : H12AffineEnvironment.transform 15 8203 env24965 = env24966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env24965 == env24966) = true)

theorem identity24966 : scanCanonicalize (H12AffineFastState.compose env24966 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 113) := by decide +kernel

theorem selectedBound24966 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env24967 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,113,8203,5392,10280,1025,112,4160,33,8508,3,8193,65,10589,13372,12588,2420,1365,33,257,32,13436,513]

theorem envBound24967 : H12AffineFastState.Bounded env24967 := by
  intro p hp
  have h : env24967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24966_24967 : H12AffineEnvironment.transform 14 113 env24966 = env24967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 113 env24966 == env24967) = true)

theorem identity24967 : scanCanonicalize (H12AffineFastState.compose env24967 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound24967 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24968 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,301,5377,113,294,5392,2309,1025,112,4160,33,17,3,300,65,2160,5393,4097,2420,1365,33,257,32,5457,513]

theorem envBound24968 : H12AffineFastState.Bounded env24968 := by
  intro p hp
  have h : env24968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24967_24968 : H12AffineEnvironment.transform 12 301 env24967 = env24968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env24967 == env24968) = true)

theorem identity24968 : scanCanonicalize (H12AffineFastState.compose env24968 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24968 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24969 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,301,5377,33,294,5392,2309,1025,32,4112,33,17,3,300,17,2080,5393,4097,2340,1285,33,257,32,5377,513]

theorem envBound24969 : H12AffineFastState.Bounded env24969 := by
  intro p hp
  have h : env24969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24968_24969 : H12AffineEnvironment.transform 5 16 env24968 = env24969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24968 == env24969) = true)

theorem identity24969 : scanCanonicalize (H12AffineFastState.compose env24969 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound24969 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24970 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,4096,301,4404,33,294,4389,2309,52,32,4112,33,17,3,300,17,2080,4388,4097,2340,304,33,257,32,4404,513]

theorem envBound24970 : H12AffineFastState.Bounded env24970 := by
  intro p hp
  have h : env24970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24969_24970 : H12AffineEnvironment.transform 9 53 env24969 = env24970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env24969 == env24970) = true)

theorem identity24970 : scanCanonicalize (H12AffineFastState.compose env24970 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound24970 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env24971 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,2356,301,2048,33,294,2065,2309,52,32,2340,33,17,3,300,17,2080,2064,2357,2340,304,33,257,32,2048,513]

theorem envBound24971 : H12AffineFastState.Bounded env24971 := by
  intro p hp
  have h : env24971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24970_24971 : H12AffineEnvironment.transform 11 2356 env24970 = env24971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env24970 == env24971) = true)

theorem identity24971 : scanCanonicalize (H12AffineFastState.compose env24971 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound24971 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env24972 : List Nat := [2,4,8,16,32,16,9,256,277,53,2048,2356,301,2048,33,294,2065,2309,52,32,2340,33,17,3,300,17,2080,2064,2357,2340,304,33,257,32,2048,276]

theorem envBound24972 : H12AffineFastState.Bounded env24972 := by
  intro p hp
  have h : env24972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24971_24972 : H12AffineEnvironment.transform 8 277 env24971 = env24972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env24971 == env24972) = true)

theorem identity24972 : scanCanonicalize (H12AffineFastState.compose env24972 (packedSelected [1,3,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound24972 : packedSelected [1,3,11] rootPS < 2^1333 := by decide +kernel

def env24973 : List Nat := [2,4,8,16,32,16,9,256,277,53,1,309,301,1,33,294,16,260,52,32,293,33,17,3,300,17,33,17,308,293,304,33,257,32,1,276]

theorem envBound24973 : H12AffineFastState.Bounded env24973 := by
  intro p hp
  have h : env24973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24972_24973 : H12AffineEnvironment.transform 10 1 env24972 = env24973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env24972 == env24973) = true)

theorem identity24973 : scanCanonicalize (H12AffineFastState.compose env24973 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound24973 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24974 : List Nat := [2,4,8,16,32,16,9,20,1,53,1,33,57,1,33,50,16,16,52,32,49,33,17,3,56,17,33,17,32,49,36,33,21,32,1,0]

theorem envBound24974 : H12AffineFastState.Bounded env24974 := by
  intro p hp
  have h : env24974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24973_24974 : H12AffineEnvironment.transform 7 20 env24973 = env24974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env24973 == env24974) = true)

theorem identity24974 : scanCanonicalize (H12AffineFastState.compose env24974 (packedSelected [1,3,12] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound24974 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env24975 : List Nat := [2,4,8,16,17,16,9,20,1,4,1,16,8,1,16,3,16,16,5,17,0,16,17,3,9,17,16,17,17,0,21,16,21,17,1,0]

theorem envBound24975 : H12AffineFastState.Bounded env24975 := by
  intro p hp
  have h : env24975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24974_24975 : H12AffineEnvironment.transform 4 17 env24974 = env24975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env24974 == env24975) = true)

theorem identity24975 : scanCanonicalize (H12AffineFastState.compose env24975 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound24975 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env24976 : List Nat := [2,4,8,0,1,0,9,4,1,4,1,0,8,1,0,3,0,0,5,1,0,0,1,3,9,1,0,1,1,0,5,0,5,1,1,0]

theorem envBound24976 : H12AffineFastState.Bounded env24976 := by
  intro p hp
  have h : env24976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24975_24976 : H12AffineEnvironment.transform 3 0 env24975 = env24976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env24975 == env24976) = true)

def env24977 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,272392,318564,351520,8193,65,158028,313700,301428,138340,1364,32,257,21793,46093,74251]

theorem envBound24977 : H12AffineFastState.Bounded env24977 := by
  intro p hp
  have h : env24977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24961_24977 : H12AffineEnvironment.transform 20 4161 env24961 = env24977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env24961 == env24977) = true)

theorem identity24977 : scanCanonicalize (H12AffineFastState.compose env24977 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound24977 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24978 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1025,32769,4161,272392,297316,329760,8193,65,146508,302180,301428,138340,1364,32,257,33,46093,74251]

theorem envBound24978 : H12AffineFastState.Bounded env24978 := by
  intro p hp
  have h : env24978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24977_24978 : H12AffineEnvironment.transform 13 5376 env24977 = env24978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env24977 == env24978) = true)

theorem identity24978 : scanCanonicalize (H12AffineFastState.compose env24978 (packedSelected [11,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound24978 : packedSelected [11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env24979 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,67619,1025,32769,4161,73771,98631,3,8193,65,146508,103495,102743,138340,1364,32,257,33,46093,74251]

theorem envBound24979 : H12AffineFastState.Bounded env24979 := by
  intro p hp
  have h : env24979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24978_24979 : H12AffineEnvironment.transform 17 67619 env24978 = env24979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env24978 == env24979) = true)

theorem identity24979 : scanCanonicalize (H12AffineFastState.compose env24979 (packedSelected [0,1,6,7,8,10,15,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 33) := by decide +kernel

theorem selectedBound24979 : packedSelected [0,1,6,7,8,10,15,21,23] rootPS < 2^1333 := by decide +kernel

def env24980 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,33,65536,131072,67619,1025,32,4161,73771,65894,3,8193,65,146508,70758,70006,138340,1364,32,257,33,13356,74251]

theorem envBound24980 : H12AffineFastState.Bounded env24980 := by
  intro p hp
  have h : env24980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24979_24980 : H12AffineEnvironment.transform 14 33 env24979 = env24980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 33 env24979 == env24980) = true)

theorem identity24980 : scanCanonicalize (H12AffineFastState.compose env24980 (packedSelected [1,2,3,4,5,8,9,10,11,18,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound24980 : packedSelected [1,2,3,4,5,8,9,10,11,18,19,20] rootPS < 2^1333 := by decide +kernel

def env24981 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,33,65536,131072,67619,1025,32,4161,65910,65894,3,348,65,138513,70758,70006,138340,1364,32,257,33,5489,66390]

theorem envBound24981 : H12AffineFastState.Bounded env24981 := by
  intro p hp
  have h : env24981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24980_24981 : H12AffineEnvironment.transform 12 349 env24980 = env24981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env24980 == env24981) = true)

theorem identity24981 : scanCanonicalize (H12AffineFastState.compose env24981 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound24981 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env24982 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,5237,33,65536,131072,67619,1025,32,4161,65539,65555,3,41,65,138340,70758,69635,138340,1057,32,116,33,5124,66083]

theorem envBound24982 : H12AffineFastState.Bounded env24982 := by
  intro p hp
  have h : env24982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24981_24982 : H12AffineEnvironment.transform 7 117 env24981 = env24982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env24981 == env24982) = true)

theorem identity24982 : scanCanonicalize (H12AffineFastState.compose env24982 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24982 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env24983 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5157,33,65536,131072,67619,1025,32,4113,65539,65555,3,41,17,138292,70710,69635,138292,1057,32,36,33,5124,66083]

theorem envBound24983 : H12AffineFastState.Bounded env24983 := by
  intro p hp
  have h : env24983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24982_24983 : H12AffineEnvironment.transform 5 16 env24982 = env24983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24982 == env24983) = true)

theorem identity24983 : scanCanonicalize (H12AffineFastState.compose env24983 (packedSelected [0,2,3,4,5,7,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound24983 : packedSelected [0,2,3,4,5,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env24984 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5157,33,35,131072,2048,1025,32,4113,32,48,3,41,17,138292,5141,4128,138292,1057,32,36,33,5124,512]

theorem envBound24984 : H12AffineFastState.Bounded env24984 := by
  intro p hp
  have h : env24984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24983_24984 : H12AffineEnvironment.transform 15 35 env24983 = env24984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env24983 == env24984) = true)

theorem identity24984 : scanCanonicalize (H12AffineFastState.compose env24984 (packedSelected [0,2,7] rootPS)) = affineNative (2^(16+1) ^^^ 5140) := by decide +kernel

theorem selectedBound24984 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env24985 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5157,33,35,5140,2048,1025,32,4113,32,48,3,41,17,2080,5141,4128,2080,1057,32,36,33,5124,512]

theorem envBound24985 : H12AffineFastState.Bounded env24985 := by
  intro p hp
  have h : env24985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24984_24985 : H12AffineEnvironment.transform 16 5140 env24984 = env24985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5140 env24984 == env24985) = true)

theorem identity24985 : scanCanonicalize (H12AffineFastState.compose env24985 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24985 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24986 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,4096,9,5124,0,2,5140,2048,1025,1,4113,1,17,3,8,17,2049,5141,4097,2049,1024,1,5,0,5124,512]

theorem envBound24986 : H12AffineFastState.Bounded env24986 := by
  intro p hp
  have h : env24986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24985_24986 : H12AffineEnvironment.transform 4 1 env24985 = env24986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24985 == env24986) = true)

def env24987 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,16,9,1044,0,2,1028,2048,1025,1,1,1,17,3,8,17,2049,1029,17,2049,1024,1,5,0,1044,512]

theorem envBound24987 : H12AffineFastState.Bounded env24987 := by
  intro p hp
  have h : env24987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24986_24987 : H12AffineEnvironment.transform 11 16 env24986 = env24987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env24986 == env24987) = true)

theorem identity24987 : scanCanonicalize (H12AffineFastState.compose env24987 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound24987 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24988 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,16,9,1,0,2,17,2048,20,1,1,1,17,3,8,17,2049,16,17,2049,21,1,5,0,1,512]

theorem envBound24988 : H12AffineFastState.Bounded env24988 := by
  intro p hp
  have h : env24988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24987_24988 : H12AffineEnvironment.transform 9 21 env24987 = env24988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env24987 == env24988) = true)

theorem identity24988 : scanCanonicalize (H12AffineFastState.compose env24988 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 543) := by decide +kernel

theorem selectedBound24988 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24989 : List Nat := [2,4,8,16,1,16,9,4,512,21,543,16,9,1,0,2,17,543,20,1,1,1,17,3,8,17,542,16,17,542,21,1,5,0,1,512]

theorem envBound24989 : H12AffineFastState.Bounded env24989 := by
  intro p hp
  have h : env24989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24988_24989 : H12AffineEnvironment.transform 10 543 env24988 = env24989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 543 env24988 == env24989) = true)

def leafEnv24989 : List Nat := [2,4,8,16,1,16,9,4,512,21,543,16,9,1,0,2,17,543,20,1,1,1,17,3,20,8,1,17,542,16,17,542,21,1,5,0,5,3,1,512,1,1,0]

def active24989 : List Nat := [0,1,2,3,8]

def tree24989 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24989 : H12WitnessSearch.Good tree24989 := H12GlobalWitnessIndex.good

theorem leafIdentity24989 : H12AffineFastState.composeSystem env24989 rootObs = leafEnv24989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24989 rootObs == leafEnv24989) = true)

theorem terminalChecked24989 : H12PackedTerminal.terminalCheckFast leafEnv24989 active24989 tree24989 = true := by decide +kernel

def env24990 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,17,9,1045,0,2,1029,2048,1025,1,0,1,17,3,8,17,2049,1028,16,2049,1024,1,5,0,1045,512]

theorem envBound24990 : H12AffineFastState.Bounded env24990 := by
  intro p hp
  have h : env24990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24986_24990 : H12AffineEnvironment.transform 11 17 env24986 = env24990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env24986 == env24990) = true)

def env24991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318565,2444776,8328,65,6705549,313700,2394420,138341,2102685,4466728,257,21792,46213,2175563]

theorem envBound24991 : H12AffineFastState.Bounded env24991 := by
  intro p hp
  have h : env24991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24894_24991 : H12AffineEnvironment.transform 22 318565 env24894 = env24991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 318565 env24894 == env24991) = true)

def env24992 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318565,2444640,8192,65,6705413,313700,2394420,138341,2102549,4466728,257,21792,46093,2175563]

theorem envBound24992 : H12AffineFastState.Bounded env24992 := by
  intro p hp
  have h : env24992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24991_24992 : H12AffineEnvironment.transform 6 8 env24991 = env24992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24991 == env24992) = true)

def env24993 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2373704,318565,2444640,8192,65,158029,313700,2394420,138341,2102549,2101344,257,21792,46093,2175563]

theorem envBound24993 : H12AffineFastState.Bounded env24993 := by
  intro p hp
  have h : env24993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24992_24993 : H12AffineEnvironment.transform 21 2373704 env24992 = env24993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2373704 env24992 == env24993) = true)

theorem identity24993 : scanCanonicalize (H12AffineFastState.compose env24993 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound24993 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env24994 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,77898,329730,318565,294186,8192,65,158029,313700,375166,138341,75103,73770,257,21792,46093,513]

theorem envBound24994 : H12AffineFastState.Bounded env24994 := by
  intro p hp
  have h : env24994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24993_24994 : H12AffineEnvironment.transform 20 77898 env24993 = env24994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env24993 == env24994) = true)

def env24995 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,77898,73770,62541,21762,8192,65,158029,57676,102742,138341,75103,73770,257,21792,46093,513]

theorem envBound24995 : H12AffineFastState.Bounded env24995 := by
  intro p hp
  have h : env24995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24994_24995 : H12AffineEnvironment.transform 17 10280 env24994 = env24995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env24994 == env24995) = true)

def env24996 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,77850,73770,62493,21762,8192,17,157981,57628,102662,138293,75023,73770,257,21792,46093,513]

theorem envBound24996 : H12AffineFastState.Bounded env24996 := by
  intro p hp
  have h : env24996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24995_24996 : H12AffineEnvironment.transform 5 16 env24995 = env24996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24995 == env24996) = true)

theorem identity24996 : scanCanonicalize (H12AffineFastState.compose env24996 (packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 103447) := by decide +kernel

theorem selectedBound24996 : packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env24997 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,103447,10280,1025,32769,77850,73770,62493,21762,8192,17,130314,57628,102662,100386,75023,73770,257,21792,46093,513]

theorem envBound24997 : H12AffineFastState.Bounded env24997 := by
  intro p hp
  have h : env24997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24996_24997 : H12AffineEnvironment.transform 16 103447 env24996 = env24997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103447 env24996 == env24997) = true)

theorem identity24997 : scanCanonicalize (H12AffineFastState.compose env24997 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound24997 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env24998 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,1,65536,70678,10280,1025,0,77850,73770,29724,21762,8192,17,97547,24861,69895,67619,75023,73770,257,21792,13324,513]

theorem envBound24998 : H12AffineFastState.Bounded env24998 := by
  intro p hp
  have h : env24998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24997_24998 : H12AffineEnvironment.transform 14 1 env24997 = env24998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env24997 == env24998) = true)

theorem identity24998 : scanCanonicalize (H12AffineFastState.compose env24998 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound24998 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env24999 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,1,263,5393,10280,1025,0,12573,8493,29724,21762,8192,17,31756,24861,4096,2340,9224,8493,257,21792,13324,513]

theorem envBound24999 : H12AffineFastState.Bounded env24999 := by
  intro p hp
  have h : env24999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24998_24999 : H12AffineEnvironment.transform 15 263 env24998 = env24999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env24998 == env24999) = true)

theorem identity24999 : scanCanonicalize (H12AffineFastState.compose env24999 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound24999 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env25000 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,1,263,5393,2340,1025,0,4113,33,21776,21762,268,17,23808,16401,4096,2340,1284,33,257,21792,5376,513]

theorem envBound25000 : H12AffineFastState.Bounded env25000 := by
  intro p hp
  have h : env25000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24999_25000 : H12AffineEnvironment.transform 12 268 env24999 = env25000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env24999 == env25000) = true)

theorem identity25000 : scanCanonicalize (H12AffineFastState.compose env25000 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound25000 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25001 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,1,263,5393,2340,1025,0,4113,33,17,3,268,17,2049,5392,4096,2340,1284,33,257,33,5376,513]

theorem envBound25001 : H12AffineFastState.Bounded env25001 := by
  intro p hp
  have h : env25001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25000_25001 : H12AffineEnvironment.transform 13 5377 env25000 = env25001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env25000 == env25001) = true)

theorem identity25001 : scanCanonicalize (H12AffineFastState.compose env25001 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound25001 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25002 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1296,268,17,1,263,1,2340,1025,0,1281,33,17,3,268,17,2049,0,1296,2340,1284,33,257,33,16,513]

theorem envBound25002 : H12AffineFastState.Bounded env25002 := by
  intro p hp
  have h : env25002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25001_25002 : H12AffineEnvironment.transform 11 1296 env25001 = env25002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env25001 == env25002) = true)

theorem identity25002 : scanCanonicalize (H12AffineFastState.compose env25002 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1290) := by decide +kernel

theorem selectedBound25002 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25003 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1290,1296,268,17,1,263,1,1070,1025,0,1281,33,17,3,268,17,1291,0,1296,1070,1284,33,257,33,16,513]

theorem envBound25003 : H12AffineFastState.Bounded env25003 := by
  intro p hp
  have h : env25003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25002_25003 : H12AffineEnvironment.transform 10 1290 env25002 = env25003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1290 env25002 == env25003) = true)

theorem identity25003 : scanCanonicalize (H12AffineFastState.compose env25003 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound25003 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25004 : List Nat := [2,4,8,16,32,16,8,5,512,1024,1039,1045,9,17,1,2,1,1070,1025,0,1028,33,17,3,9,17,1038,0,1045,1070,1025,33,4,33,16,513]

theorem envBound25004 : H12AffineFastState.Bounded env25004 := by
  intro p hp
  have h : env25004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25003_25004 : H12AffineEnvironment.transform 7 5 env25003 = env25004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env25003 == env25004) = true)

theorem identity25004 : scanCanonicalize (H12AffineFastState.compose env25004 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound25004 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env25005 : List Nat := [2,4,8,1,32,1,8,5,512,1024,1039,1028,9,0,1,2,1,1070,1025,0,1028,33,0,3,9,0,1038,0,1028,1070,1025,33,4,33,1,513]

theorem envBound25005 : H12AffineFastState.Bounded env25005 := by
  intro p hp
  have h : env25005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25004_25005 : H12AffineEnvironment.transform 3 1 env25004 = env25005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env25004 == env25005) = true)

theorem identity25005 : scanCanonicalize (H12AffineFastState.compose env25005 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound25005 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env25006 : List Nat := [2,4,3,1,32,1,3,5,512,1024,1028,1028,2,0,1,2,1,1061,1025,0,1028,33,0,3,2,0,1029,0,1028,1061,1025,33,4,33,1,513]

theorem envBound25006 : H12AffineFastState.Bounded env25006 := by
  intro p hp
  have h : env25006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25005_25006 : H12AffineEnvironment.transform 2 3 env25005 = env25006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env25005 == env25006) = true)

theorem identity25006 : scanCanonicalize (H12AffineFastState.compose env25006 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound25006 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env25007 : List Nat := [2,4,3,1,1,1,3,5,512,1024,1028,1028,2,0,1,2,1,1028,1025,0,1028,0,0,3,2,0,1029,0,1028,1028,1025,0,4,0,1,513]

theorem envBound25007 : H12AffineFastState.Bounded env25007 := by
  intro p hp
  have h : env25007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25006_25007 : H12AffineEnvironment.transform 4 1 env25006 = env25007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25006 == env25007) = true)

theorem identity25007 : scanCanonicalize (H12AffineFastState.compose env25007 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 513) := by decide +kernel

theorem selectedBound25007 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25008 : List Nat := [2,4,3,1,1,1,3,5,512,513,517,517,2,0,1,2,1,517,512,0,517,0,0,3,2,0,516,0,517,517,512,0,4,0,1,513]

theorem envBound25008 : H12AffineFastState.Bounded env25008 := by
  intro p hp
  have h : env25008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25007_25008 : H12AffineEnvironment.transform 9 513 env25007 = env25008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 513 env25007 == env25008) = true)

def env25009 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,77851,73770,62492,21762,8192,16,157980,57629,102663,138292,75022,73770,257,21792,46093,513]

theorem envBound25009 : H12AffineFastState.Bounded env25009 := by
  intro p hp
  have h : env25009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24995_25009 : H12AffineEnvironment.transform 5 17 env24995 = env25009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24995 == env25009) = true)

theorem identity25009 : scanCanonicalize (H12AffineFastState.compose env25009 (packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound25009 : packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env25010 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13325,32768,65536,131072,10280,1025,32769,77851,73770,32785,8463,8192,16,138513,38160,102663,138292,75022,73770,257,8493,46093,513]

theorem envBound25010 : H12AffineFastState.Bounded env25010 := by
  intro p hp
  have h : env25010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25009_25010 : H12AffineEnvironment.transform 13 13325 env25009 = env25010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env25009 == env25010) = true)

theorem identity25010 : scanCanonicalize (H12AffineFastState.compose env25010 (packedSelected [2,4,6,9,11,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound25010 : packedSelected [2,4,6,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env25011 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,32768,65536,131072,2340,1025,32769,69911,65830,32785,3,268,16,138513,38160,102663,138292,66562,65830,257,33,38145,513]

theorem envBound25011 : H12AffineFastState.Bounded env25011 := by
  intro p hp
  have h : env25011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25010_25011 : H12AffineEnvironment.transform 12 268 env25010 = env25011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env25010 == env25011) = true)

theorem identity25011 : scanCanonicalize (H12AffineFastState.compose env25011 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 103447) := by decide +kernel

theorem selectedBound25011 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25012 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,32768,65536,103447,2340,1025,32769,69911,65830,32785,3,268,16,100614,38160,102663,100387,66562,65830,257,33,38145,513]

theorem envBound25012 : H12AffineFastState.Bounded env25012 := by
  intro p hp
  have h : env25012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25011_25012 : H12AffineEnvironment.transform 16 103447 env25011 = env25012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103447 env25011 == env25012) = true)

theorem identity25012 : scanCanonicalize (H12AffineFastState.compose env25012 (packedSelected [4,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound25012 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env25013 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,32768,262,38161,2340,1025,32769,4113,32,32785,3,268,16,34816,38160,36865,35109,1284,32,257,33,38145,513]

theorem envBound25013 : H12AffineFastState.Bounded env25013 := by
  intro p hp
  have h : env25013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25012_25013 : H12AffineEnvironment.transform 15 262 env25012 = env25013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env25012 == env25013) = true)

theorem identity25013 : scanCanonicalize (H12AffineFastState.compose env25013 (packedSelected [2] rootPS)) = affineNative (2^(14+1) ^^^ 1061) := by decide +kernel

theorem selectedBound25013 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25014 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,1061,262,4404,2340,1025,1060,4113,32,1076,3,268,16,3109,4405,5156,3328,1284,32,257,33,4388,513]

theorem envBound25014 : H12AffineFastState.Bounded env25014 := by
  intro p hp
  have h : env25014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25013_25014 : H12AffineEnvironment.transform 14 1061 env25013 = env25014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1061 env25013 == env25014) = true)

theorem identity25014 : scanCanonicalize (H12AffineFastState.compose env25014 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound25014 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env25015 : List Nat := [2,4,8,16,32,17,8,256,512,36,2048,4096,268,4389,1,262,4404,2340,37,0,4113,32,16,3,268,16,2049,4405,4096,2340,288,32,257,33,4388,513]

theorem envBound25015 : H12AffineFastState.Bounded env25015 := by
  intro p hp
  have h : env25015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25014_25015 : H12AffineEnvironment.transform 9 36 env25014 = env25015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env25014 == env25015) = true)

theorem identity25015 : scanCanonicalize (H12AffineFastState.compose env25015 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2059) := by decide +kernel

theorem selectedBound25015 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25016 : List Nat := [2,4,8,16,32,17,8,256,512,36,2048,2059,268,2350,1,262,2367,2340,37,0,2074,32,16,3,268,16,2049,2366,2059,2340,288,32,257,33,2351,513]

theorem envBound25016 : H12AffineFastState.Bounded env25016 := by
  intro p hp
  have h : env25016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25015_25016 : H12AffineEnvironment.transform 11 2059 env25015 = env25016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2059 env25015 == env25016) = true)

theorem identity25016 : scanCanonicalize (H12AffineFastState.compose env25016 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound25016 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25017 : List Nat := [2,4,8,16,17,17,8,256,512,21,2048,2059,268,2335,1,262,2318,2325,20,0,2074,17,16,3,268,16,2049,2319,2059,2325,273,17,257,16,2334,513]

theorem envBound25017 : H12AffineFastState.Bounded env25017 := by
  intro p hp
  have h : env25017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25016_25017 : H12AffineEnvironment.transform 4 17 env25016 = env25017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env25016 == env25017) = true)

theorem identity25017 : scanCanonicalize (H12AffineFastState.compose env25017 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound25017 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env25018 : List Nat := [2,4,8,16,17,17,8,31,512,21,2048,2059,19,2048,1,25,2065,2058,20,0,2074,17,16,3,19,16,2049,2064,2059,2058,14,17,30,16,2049,513]

theorem envBound25018 : H12AffineFastState.Bounded env25018 := by
  intro p hp
  have h : env25018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25017_25018 : H12AffineEnvironment.transform 7 31 env25017 = env25018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env25017 == env25018) = true)

theorem identity25018 : scanCanonicalize (H12AffineFastState.compose env25018 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound25018 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env25019 : List Nat := [2,4,3,16,17,17,3,20,512,21,2048,2048,19,2048,1,18,2065,2049,20,0,2065,17,16,3,19,16,2049,2064,2048,2049,5,17,21,16,2049,513]

theorem envBound25019 : H12AffineFastState.Bounded env25019 := by
  intro p hp
  have h : env25019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25018_25019 : H12AffineEnvironment.transform 2 3 env25018 = env25019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env25018 == env25019) = true)

def env25020 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,77898,73771,62540,21763,8192,65,158029,57677,102743,138341,75103,73770,257,21792,46093,513]

theorem envBound25020 : H12AffineFastState.Bounded env25020 := by
  intro p hp
  have h : env25020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24994_25020 : H12AffineEnvironment.transform 17 10281 env24994 = env25020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env24994 == env25020) = true)

theorem identity25020 : scanCanonicalize (H12AffineFastState.compose env25020 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound25020 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25021 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10281,1025,32769,4161,32,62540,21763,8192,65,158029,57677,45404,138341,1364,33,257,21792,46093,513]

theorem envBound25021 : H12AffineFastState.Bounded env25021 := by
  intro p hp
  have h : env25021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25020_25021 : H12AffineEnvironment.transform 15 8203 env25020 = env25021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env25020 == env25021) = true)

theorem identity25021 : scanCanonicalize (H12AffineFastState.compose env25021 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 30073) := by decide +kernel

theorem selectedBound25021 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env25022 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,30073,8203,131072,10281,1025,30072,4161,32,309,21763,8192,65,158029,5172,17445,138341,1364,33,257,21792,16756,513]

theorem envBound25022 : H12AffineFastState.Bounded env25022 := by
  intro p hp
  have h : env25022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25021_25022 : H12AffineEnvironment.transform 14 30073 env25021 = env25022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30073 env25021 == env25022) = true)

theorem identity25022 : scanCanonicalize (H12AffineFastState.compose env25022 (packedSelected [4,6,9,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 2169) := by decide +kernel

theorem selectedBound25022 : packedSelected [4,6,9,14,18] rootPS < 2^1333 := by decide +kernel

def env25023 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,2169,16384,23808,2162,131072,80,1025,23809,4161,32,309,21763,2169,65,147764,5172,17445,138341,1364,33,257,21792,16756,513]

theorem envBound25023 : H12AffineFastState.Bounded env25023 := by
  intro p hp
  have h : env25023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25022_25023 : H12AffineEnvironment.transform 12 2169 env25022 = env25023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2169 env25022 == env25023) = true)

theorem identity25023 : scanCanonicalize (H12AffineFastState.compose env25023 (packedSelected [21] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound25023 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25024 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,2169,16384,23588,2162,131072,80,1025,23589,4161,32,17,21543,2169,65,147472,5172,17445,138341,1136,33,37,21508,16464,513]

theorem envBound25024 : H12AffineFastState.Bounded env25024 := by
  intro p hp
  have h : env25024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25023_25024 : H12AffineEnvironment.transform 7 36 env25023 = env25024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env25023 == env25024) = true)

theorem identity25024 : scanCanonicalize (H12AffineFastState.compose env25024 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(16+1) ^^^ 2064) := by decide +kernel

theorem selectedBound25024 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env25025 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,2169,16384,23588,2162,2064,80,1025,23589,4161,32,17,21543,2169,65,18432,5172,17445,5237,1136,33,37,21508,16464,513]

theorem envBound25025 : H12AffineFastState.Bounded env25025 := by
  intro p hp
  have h : env25025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25024_25025 : H12AffineEnvironment.transform 16 2064 env25024 = env25025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2064 env25024 == env25025) = true)

theorem identity25025 : scanCanonicalize (H12AffineFastState.compose env25025 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound25025 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env25026 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,1141,2169,16384,18513,2162,2064,80,1025,18512,1076,32,17,16466,2169,65,18432,65,17445,0,1136,33,37,16497,16464,513]

theorem envBound25026 : H12AffineFastState.Bounded env25026 := by
  intro p hp
  have h : env25026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25025_25026 : H12AffineEnvironment.transform 11 1141 env25025 = env25026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env25025 == env25026) = true)

theorem identity25026 : scanCanonicalize (H12AffineFastState.compose env25026 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 3125) := by decide +kernel

theorem selectedBound25026 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env25027 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,1141,2169,3125,1124,2162,2064,80,1025,1125,1076,32,17,3175,2169,65,1077,65,2064,0,1136,33,37,3140,3173,513]

theorem envBound25027 : H12AffineFastState.Bounded env25027 := by
  intro p hp
  have h : env25027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25026_25027 : H12AffineEnvironment.transform 13 3125 env25026 = env25027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3125 env25026 == env25027) = true)

theorem identity25027 : scanCanonicalize (H12AffineFastState.compose env25027 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound25027 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env25028 : List Nat := [2,4,8,16,32,64,8,36,512,1024,1125,1141,1052,80,1124,1047,1141,80,1025,1125,1076,32,17,2,1052,65,1077,65,1141,0,1136,33,37,33,0,513]

theorem envBound25028 : H12AffineFastState.Bounded env25028 := by
  intro p hp
  have h : env25028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25027_25028 : H12AffineEnvironment.transform 10 1125 env25027 = env25028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env25027 == env25028) = true)

theorem identity25028 : scanCanonicalize (H12AffineFastState.compose env25028 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25028 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env25029 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1077,1061,1052,0,1076,1047,1061,0,1025,1077,1076,32,17,2,1052,17,1077,17,1061,0,1056,33,37,33,0,513]

theorem envBound25029 : H12AffineFastState.Bounded env25029 := by
  intro p hp
  have h : env25029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25028_25029 : H12AffineEnvironment.transform 5 16 env25028 = env25029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25028 == env25029) = true)

theorem identity25029 : scanCanonicalize (H12AffineFastState.compose env25029 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound25029 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env25030 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,17,40,0,0,35,17,0,53,1,0,32,17,2,40,17,1,17,17,0,20,33,37,33,0,513]

theorem envBound25030 : H12AffineFastState.Bounded env25030 := by
  intro p hp
  have h : env25030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25029_25030 : H12AffineEnvironment.transform 9 52 env25029 = env25030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env25029 == env25030) = true)

theorem identity25030 : scanCanonicalize (H12AffineFastState.compose env25030 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound25030 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25031 : List Nat := [2,4,8,16,32,16,8,36,33,52,1,17,40,0,0,35,17,0,53,1,0,32,17,2,40,17,1,17,17,0,20,33,37,33,0,32]

theorem envBound25031 : H12AffineFastState.Bounded env25031 := by
  intro p hp
  have h : env25031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25030_25031 : H12AffineEnvironment.transform 8 33 env25030 = env25031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env25030 == env25031) = true)

theorem identity25031 : scanCanonicalize (H12AffineFastState.compose env25031 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound25031 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25032 : List Nat := [2,4,8,16,17,16,8,21,16,5,1,17,25,0,0,18,17,0,4,1,0,17,17,2,25,17,1,17,17,0,20,16,20,16,0,17]

theorem envBound25032 : H12AffineFastState.Bounded env25032 := by
  intro p hp
  have h : env25032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25031_25032 : H12AffineEnvironment.transform 4 17 env25031 = env25032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env25031 == env25032) = true)

def env25033 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2373705,318565,2444640,8192,65,158028,313700,2394420,138341,2102549,2101345,257,21792,46093,2175563]

theorem envBound25033 : H12AffineFastState.Bounded env25033 := by
  intro p hp
  have h : env25033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24992_25033 : H12AffineEnvironment.transform 21 2373705 env24992 = env25033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2373705 env24992 == env25033) = true)

def env25034 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,272393,318565,351520,8192,65,158028,313700,301428,138341,1365,33,257,21792,46093,74251]

theorem envBound25034 : H12AffineFastState.Bounded env25034 := by
  intro p hp
  have h : env25034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25033_25034 : H12AffineEnvironment.transform 20 4160 env25033 = env25034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env25033 == env25034) = true)

theorem identity25034 : scanCanonicalize (H12AffineFastState.compose env25034 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound25034 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25035 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,4160,272393,318565,297334,8192,65,158028,313700,301428,138341,1365,33,257,21792,46093,63069]

theorem envBound25035 : H12AffineFastState.Bounded env25035 := by
  intro p hp
  have h : env25035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25034_25035 : H12AffineEnvironment.transform 15 54358 env25034 = env25035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env25034 == env25035) = true)

theorem identity25035 : scanCanonicalize (H12AffineFastState.compose env25035 (packedSelected [1,3,5,8,10,12,15,19,21,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound25035 : packedSelected [1,3,5,8,10,12,15,19,21,38,41] rootPS < 2^1333 := by decide +kernel

def env25036 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,131072,262144,1025,29789,4160,272393,272441,294186,8192,65,158028,277816,290088,138341,1365,33,257,21792,16465,513]

theorem envBound25036 : H12AffineFastState.Bounded env25036 := by
  intro p hp
  have h : env25036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25035_25036 : H12AffineEnvironment.transform 14 29788 env25035 = env25036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env25035 == env25036) = true)

theorem identity25036 : scanCanonicalize (H12AffineFastState.compose env25036 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound25036 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25037 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,131072,10280,1025,29789,4160,33,17,21762,8192,65,158028,5392,17664,138341,1365,33,257,21792,16465,513]

theorem envBound25037 : H12AffineFastState.Bounded env25037 := by
  intro p hp
  have h : env25037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25036_25037 : H12AffineEnvironment.transform 17 10280 env25036 = env25037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env25036 == env25037) = true)

theorem identity25037 : scanCanonicalize (H12AffineFastState.compose env25037 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound25037 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env25038 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,80,8202,131072,10280,1025,81,4160,33,17,8462,8192,65,138560,5392,12556,138341,1365,33,257,8492,13405,513]

theorem envBound25038 : H12AffineFastState.Bounded env25038 := by
  intro p hp
  have h : env25038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25037_25038 : H12AffineEnvironment.transform 13 13324 env25037 = env25038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env25037 == env25038) = true)

def env25039 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,272392,318565,351521,8192,65,158028,313700,301429,138341,1364,32,257,21792,46093,74250]

theorem envBound25039 : H12AffineFastState.Bounded env25039 := by
  intro p hp
  have h : env25039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25033_25039 : H12AffineEnvironment.transform 20 4161 env25033 = env25039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env25033 == env25039) = true)

theorem identity25039 : scanCanonicalize (H12AffineFastState.compose env25039 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130175) := by decide +kernel

theorem selectedBound25039 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25040 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,130175,1025,32769,4161,119927,73754,41310,8192,65,158028,79131,91402,138341,1364,32,257,21792,46093,74250]

theorem envBound25040 : H12AffineFastState.Bounded env25040 := by
  intro p hp
  have h : env25040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25039_25040 : H12AffineEnvironment.transform 17 130175 env25039 = env25040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130175 env25039 == env25040) = true)

def env25041 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,67619,1025,29789,4161,73771,73754,21762,8192,65,158028,79131,91402,138341,1364,32,257,21792,16465,74250]

theorem envBound25041 : H12AffineFastState.Bounded env25041 := by
  intro p hp
  have h : env25041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25040_25041 : H12AffineEnvironment.transform 14 29788 env25040 = env25041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env25040 == env25041) = true)

theorem identity25041 : scanCanonicalize (H12AffineFastState.compose env25041 (packedSelected [0,2,3,6,10,11,14,16,20,23,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound25041 : packedSelected [0,2,3,6,10,11,14,16,20,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env25042 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,13340,67619,1025,29789,4161,73771,73754,21762,8192,65,23888,79131,91402,10361,1364,32,257,21792,16465,74250]

theorem envBound25042 : H12AffineFastState.Bounded env25042 := by
  intro p hp
  have h : env25042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25041_25042 : H12AffineEnvironment.transform 16 13340 env25041 = env25042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env25041 == env25042) = true)

theorem identity25042 : scanCanonicalize (H12AffineFastState.compose env25042 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,16,18,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound25042 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env25043 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,13340,10280,1025,29789,4161,32,17,21762,8192,65,23888,5392,17665,10361,1364,32,257,21792,16465,513]

theorem envBound25043 : H12AffineFastState.Bounded env25043 := by
  intro p hp
  have h : env25043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25042_25043 : H12AffineEnvironment.transform 15 8203 env25042 = env25043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env25042 == env25043) = true)

theorem identity25043 : scanCanonicalize (H12AffineFastState.compose env25043 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound25043 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env25044 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29709,8203,13340,10280,1025,29708,4112,32,17,21762,8192,16,23809,5392,17665,10280,1285,32,257,21792,16384,513]

theorem envBound25044 : H12AffineFastState.Bounded env25044 := by
  intro p hp
  have h : env25044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25043_25044 : H12AffineEnvironment.transform 5 17 env25043 = env25044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25043 == env25044) = true)

theorem identity25044 : scanCanonicalize (H12AffineFastState.compose env25044 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound25044 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env25045 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8460,8203,13340,10280,1025,8461,4112,32,17,3,8192,16,2048,5392,4096,10280,1285,32,257,33,5377,513]

theorem envBound25045 : H12AffineFastState.Bounded env25045 := by
  intro p hp
  have h : env25045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25044_25045 : H12AffineEnvironment.transform 13 5377 env25044 = env25045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env25044 == env25045) = true)

theorem identity25045 : scanCanonicalize (H12AffineFastState.compose env25045 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound25045 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env25046 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,300,5377,32,295,5424,2308,1025,33,4112,32,17,3,300,16,2048,5392,4096,2308,1285,32,257,33,5377,513]

theorem envBound25046 : H12AffineFastState.Bounded env25046 := by
  intro p hp
  have h : env25046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25045_25046 : H12AffineEnvironment.transform 12 300 env25045 = env25046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env25045 == env25046) = true)

theorem identity25046 : scanCanonicalize (H12AffineFastState.compose env25046 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound25046 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env25047 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,300,4145,32,295,4096,2308,305,33,4112,32,17,3,300,16,2048,4128,4096,2308,53,32,257,33,4145,513]

theorem envBound25047 : H12AffineFastState.Bounded env25047 := by
  intro p hp
  have h : env25047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25046_25047 : H12AffineEnvironment.transform 9 304 env25046 = env25047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env25046 == env25047) = true)

theorem identity25047 : scanCanonicalize (H12AffineFastState.compose env25047 (packedSelected [4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound25047 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env25048 : List Nat := [2,4,8,16,0,17,8,256,512,272,2048,4096,268,4113,0,263,4096,2308,273,1,4112,0,17,3,268,16,2048,4096,4096,2308,21,0,257,1,4113,513]

theorem envBound25048 : H12AffineFastState.Bounded env25048 := by
  intro p hp
  have h : env25048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25047_25048 : H12AffineEnvironment.transform 4 0 env25047 = env25048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25047 == env25048) = true)

theorem identity25048 : scanCanonicalize (H12AffineFastState.compose env25048 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound25048 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25049 : List Nat := [2,4,8,16,0,17,8,4,512,20,2048,4096,8,4113,0,3,4096,2048,21,1,4112,0,17,3,8,16,2048,4096,4096,2048,21,0,5,1,4113,513]

theorem envBound25049 : H12AffineFastState.Bounded env25049 := by
  intro p hp
  have h : env25049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25048_25049 : H12AffineEnvironment.transform 7 4 env25048 = env25049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env25048 == env25049) = true)

theorem identity25049 : scanCanonicalize (H12AffineFastState.compose env25049 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound25049 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25050 : List Nat := [2,4,8,16,0,17,8,4,512,20,1,4096,8,4113,0,3,4096,1,21,1,4112,0,17,3,8,16,1,4096,4096,1,21,0,5,1,4113,513]

theorem envBound25050 : H12AffineFastState.Bounded env25050 := by
  intro p hp
  have h : env25050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25049_25050 : H12AffineEnvironment.transform 10 1 env25049 = env25050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env25049 == env25050) = true)

theorem identity25050 : scanCanonicalize (H12AffineFastState.compose env25050 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound25050 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env25051 : List Nat := [2,4,8,16,0,17,8,4,0,20,1,4096,8,4113,0,3,4096,1,21,1,4112,0,17,3,8,16,1,4096,4096,1,21,0,5,1,4113,1]

theorem envBound25051 : H12AffineFastState.Bounded env25051 := by
  intro p hp
  have h : env25051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25050_25051 : H12AffineEnvironment.transform 8 0 env25050 = env25051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env25050 == env25051) = true)

theorem identity25051 : scanCanonicalize (H12AffineFastState.compose env25051 (packedSelected [5] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound25051 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env25052 : List Nat := [2,4,8,16,0,17,8,4,0,20,1,1,8,16,0,3,1,1,21,1,17,0,17,3,8,16,1,1,1,1,21,0,5,1,16,1]

theorem envBound25052 : H12AffineFastState.Bounded env25052 := by
  intro p hp
  have h : env25052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25051_25052 : H12AffineEnvironment.transform 11 1 env25051 = env25052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env25051 == env25052) = true)

def env25053 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,67618,1025,29788,4161,73770,73754,21763,8192,65,158028,79131,91402,138341,1364,32,257,21792,16464,74250]

theorem envBound25053 : H12AffineFastState.Bounded env25053 := by
  intro p hp
  have h : env25053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25040_25053 : H12AffineEnvironment.transform 14 29789 env25040 = env25053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env25040 == env25053) = true)

theorem identity25053 : scanCanonicalize (H12AffineFastState.compose env25053 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound25053 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25054 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,131072,10281,1025,29788,4161,33,17,21763,8192,65,158028,5392,17665,138341,1364,32,257,21792,16464,513]

theorem envBound25054 : H12AffineFastState.Bounded env25054 := by
  intro p hp
  have h : env25054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25053_25054 : H12AffineEnvironment.transform 15 8203 env25053 = env25054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env25053 == env25054) = true)

theorem identity25054 : scanCanonicalize (H12AffineFastState.compose env25054 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 8461) := by decide +kernel

theorem selectedBound25054 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env25055 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,8461,5456,8203,131072,10281,1025,5457,4161,33,17,13326,8192,65,133185,5392,9228,138341,1364,32,257,13357,8541,513]

end H12CloudChart0