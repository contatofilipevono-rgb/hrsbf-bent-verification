import H12CloudChart0Data166

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans42317_42318 : H12AffineEnvironment.transform 11 48 env42317 = env42318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env42317 == env42318) = true)

theorem identity42318 : scanCanonicalize (H12AffineFastState.compose env42318 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound42318 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42319 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1044,48,40,1045,0,35,1028,1044,1025,1,32,33,17,2,40,16,1044,1028,48,1044,1056,33,36,32,1045,513]

theorem envBound42319 : H12AffineFastState.Bounded env42319 := by
  intro p hp
  have h : env42319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42318_42319 : H12AffineEnvironment.transform 10 1044 env42318 = env42319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env42318 == env42319) = true)

def env42320 : List Nat := [2,4,8,16,32,17,8,37,512,52,32,48,40,33,0,35,48,32,53,1,32,33,17,2,40,16,32,48,48,32,20,33,36,32,33,513]

theorem envBound42320 : H12AffineFastState.Bounded env42320 := by
  intro p hp
  have h : env42320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42319_42320 : H12AffineEnvironment.transform 9 52 env42319 = env42320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env42319 == env42320) = true)

theorem identity42320 : scanCanonicalize (H12AffineFastState.compose env42320 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound42320 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42321 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,16,8,1,0,3,16,0,21,1,0,1,17,2,8,16,0,16,16,0,20,1,4,0,1,513]

theorem envBound42321 : H12AffineFastState.Bounded env42321 := by
  intro p hp
  have h : env42321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42320_42321 : H12AffineEnvironment.transform 4 0 env42320 = env42321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42320 == env42321) = true)

def leafEnv42321 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,16,8,1,0,3,16,0,21,1,0,1,17,2,21,8,1,16,0,16,16,0,20,1,4,0,5,3,1,513,1,0,0]

def active42321 : List Nat := [0,1,2,3,8]

def tree42321 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42321 : H12WitnessSearch.Good tree42321 := H12GlobalWitnessIndex.good

theorem leafIdentity42321 : H12AffineFastState.composeSystem env42321 rootObs = leafEnv42321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42321 rootObs == leafEnv42321) = true)

theorem terminalChecked42321 : H12PackedTerminal.terminalCheckFast leafEnv42321 active42321 tree42321 = true := by decide +kernel

def env42322 : List Nat := [2,4,8,16,32,17,8,37,512,53,33,48,40,32,0,35,49,33,52,1,32,33,17,2,40,16,33,49,48,33,21,33,36,32,32,513]

theorem envBound42322 : H12AffineFastState.Bounded env42322 := by
  intro p hp
  have h : env42322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42319_42322 : H12AffineEnvironment.transform 9 53 env42319 = env42322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env42319 == env42322) = true)

theorem identity42322 : scanCanonicalize (H12AffineFastState.compose env42322 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound42322 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42323 : List Nat := [2,4,8,16,32,17,8,37,10,53,33,48,40,32,0,35,49,33,52,1,32,33,17,2,40,16,33,49,48,33,21,33,36,32,32,11]

theorem envBound42323 : H12AffineFastState.Bounded env42323 := by
  intro p hp
  have h : env42323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42322_42323 : H12AffineEnvironment.transform 8 10 env42322 = env42323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env42322 == env42323) = true)

def leafEnv42323 : List Nat := [2,4,8,16,32,17,8,37,10,53,33,48,40,32,0,35,49,33,52,1,32,33,17,2,20,40,1,16,33,49,48,33,21,33,36,32,5,35,32,11,1,32,0]

def active42323 : List Nat := [0,1,2,3,4]

def tree42323 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42323 : H12WitnessSearch.Good tree42323 := H12GlobalWitnessIndex.good

theorem leafIdentity42323 : H12AffineFastState.composeSystem env42323 rootObs = leafEnv42323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42323 rootObs == leafEnv42323) = true)

theorem terminalChecked42323 : H12PackedTerminal.terminalCheckFast leafEnv42323 active42323 tree42323 = true := by decide +kernel

def env42324 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,49,40,1044,0,35,1029,2048,1025,1,33,33,17,2,40,16,2048,1029,49,2048,1056,33,36,32,1044,513]

theorem envBound42324 : H12AffineFastState.Bounded env42324 := by
  intro p hp
  have h : env42324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42317_42324 : H12AffineEnvironment.transform 11 49 env42317 = env42324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env42317 == env42324) = true)

theorem identity42324 : scanCanonicalize (H12AffineFastState.compose env42324 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound42324 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42325 : List Nat := [2,4,8,16,32,17,8,37,512,1024,32,49,40,1044,0,35,1029,32,1025,1,33,33,17,2,40,16,32,1029,49,32,1056,33,36,32,1044,513]

theorem envBound42325 : H12AffineFastState.Bounded env42325 := by
  intro p hp
  have h : env42325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42324_42325 : H12AffineEnvironment.transform 10 32 env42324 = env42325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env42324 == env42325) = true)

def env42326 : List Nat := [2,4,8,16,32,17,8,37,512,52,32,49,40,32,0,35,49,32,53,1,33,33,17,2,40,16,32,49,49,32,20,33,36,32,32,513]

theorem envBound42326 : H12AffineFastState.Bounded env42326 := by
  intro p hp
  have h : env42326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42325_42326 : H12AffineEnvironment.transform 9 52 env42325 = env42326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env42325 == env42326) = true)

theorem identity42326 : scanCanonicalize (H12AffineFastState.compose env42326 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound42326 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42327 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,17,8,0,0,3,17,0,21,1,1,1,17,2,8,16,0,17,17,0,20,1,4,0,0,513]

theorem envBound42327 : H12AffineFastState.Bounded env42327 := by
  intro p hp
  have h : env42327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42326_42327 : H12AffineEnvironment.transform 4 0 env42326 = env42327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42326 == env42327) = true)

def leafEnv42327 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,17,8,0,0,3,17,0,21,1,1,1,17,2,21,8,1,16,0,17,17,0,20,1,4,0,5,3,0,513,1,1,0]

def active42327 : List Nat := [0,1,2,3,8]

def tree42327 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42327 : H12WitnessSearch.Good tree42327 := H12GlobalWitnessIndex.good

theorem leafIdentity42327 : H12AffineFastState.composeSystem env42327 rootObs = leafEnv42327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42327 rootObs == leafEnv42327) = true)

theorem terminalChecked42327 : H12PackedTerminal.terminalCheckFast leafEnv42327 active42327 tree42327 = true := by decide +kernel

def env42328 : List Nat := [2,4,8,16,32,17,8,37,512,53,32,49,40,33,0,35,48,32,52,1,33,33,17,2,40,16,32,48,49,32,21,33,36,32,33,513]

theorem envBound42328 : H12AffineFastState.Bounded env42328 := by
  intro p hp
  have h : env42328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42325_42328 : H12AffineEnvironment.transform 9 53 env42325 = env42328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env42325 == env42328) = true)

theorem identity42328 : scanCanonicalize (H12AffineFastState.compose env42328 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound42328 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42329 : List Nat := [2,4,8,16,32,17,8,37,11,53,32,49,40,33,0,35,48,32,52,1,33,33,17,2,40,16,32,48,49,32,21,33,36,32,33,10]

theorem envBound42329 : H12AffineFastState.Bounded env42329 := by
  intro p hp
  have h : env42329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42328_42329 : H12AffineEnvironment.transform 8 11 env42328 = env42329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env42328 == env42329) = true)

def leafEnv42329 : List Nat := [2,4,8,16,32,17,8,37,11,53,32,49,40,33,0,35,48,32,52,1,33,33,17,2,20,40,1,16,32,48,49,32,21,33,36,32,5,35,33,10,1,33,0]

def active42329 : List Nat := [0,1,2,3,4]

def tree42329 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42329 : H12WitnessSearch.Good tree42329 := H12GlobalWitnessIndex.good

theorem leafIdentity42329 : H12AffineFastState.composeSystem env42329 rootObs = leafEnv42329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42329 rootObs == leafEnv42329) = true)

theorem terminalChecked42329 : H12PackedTerminal.terminalCheckFast leafEnv42329 active42329 tree42329 = true := by decide +kernel

def env42330 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155701,2485295,16777216,8328,65,16959642,18973837,375167,2305071,19163199,16875893,257,17049730,17090855,19222505]

theorem envBound42330 : H12AffineFastState.Bounded env42330 := by
  intro p hp
  have h : env42330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42262_42330 : H12AffineEnvironment.transform 21 2155701 env42262 = env42330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2155701 env42262 == env42330) = true)

def env42331 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155701,2485295,2559344,8328,65,2475498,428541,375167,2305071,222543,2526213,257,2303474,2344023,148121]

theorem envBound42331 : H12AffineFastState.Bounded env42331 := by
  intro p hp
  have h : env42331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42330_42331 : H12AffineEnvironment.transform 23 2559344 env42330 = env42331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2559344 env42330 == env42331) = true)

theorem identity42331 : scanCanonicalize (H12AffineFastState.compose env42331 (packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound42331 : packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS < 2^1333 := by decide +kernel

def env42332 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155581,2485295,2559344,8192,65,2475362,428405,375167,2305071,222543,2526213,257,2303354,2344023,147985]

theorem envBound42332 : H12AffineFastState.Bounded env42332 := by
  intro p hp
  have h : env42332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42331_42332 : H12AffineEnvironment.transform 6 8 env42331 = env42332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42331 == env42332) = true)

theorem identity42332 : scanCanonicalize (H12AffineFastState.compose env42332 (packedSelected [1,17,19,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound42332 : packedSelected [1,17,19,28,31] rootPS < 2^1333 := by decide +kernel

def env42333 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,2155581,2212871,2303320,8192,65,2223434,172381,102743,2305071,222543,2270253,257,2303354,2344023,147985]

theorem envBound42333 : H12AffineFastState.Bounded env42333 := by
  intro p hp
  have h : env42333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42332_42333 : H12AffineEnvironment.transform 17 10280 env42332 = env42333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env42332 == env42333) = true)

def env42334 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4160,62589,119879,210200,8192,65,130314,172381,102743,212079,222543,177261,257,210234,250903,147985]

theorem envBound42334 : H12AffineFastState.Bounded env42334 := by
  intro p hp
  have h : env42334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42333_42334 : H12AffineEnvironment.transform 20 4160 env42333 = env42334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env42333 == env42334) = true)

theorem identity42334 : scanCanonicalize (H12AffineFastState.compose env42334 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound42334 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42335 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,4160,62589,119879,95496,8192,65,130314,57677,102743,97407,75103,62589,257,95530,103431,513]

theorem envBound42335 : H12AffineFastState.Bounded env42335 := by
  intro p hp
  have h : env42335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42334_42335 : H12AffineEnvironment.transform 16 16400 env42334 = env42335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env42334 == env42335) = true)

theorem identity42335 : scanCanonicalize (H12AffineFastState.compose env42335 (packedSelected [0,3,4,5,7,9,10,11,12,15,18,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound42335 : packedSelected [0,3,4,5,7,9,10,11,12,15,18,20,23] rootPS < 2^1333 := by decide +kernel

def env42336 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,16400,10280,1025,32769,4160,62589,41293,2,8192,65,34816,57677,58461,2421,20565,62589,257,32,57613,513]

theorem envBound42336 : H12AffineFastState.Bounded env42336 := by
  intro p hp
  have h : env42336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42335_42336 : H12AffineEnvironment.transform 15 29962 env42335 = env42336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env42335 == env42336) = true)

theorem identity42336 : scanCanonicalize (H12AffineFastState.compose env42336 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound42336 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env42337 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29709,29962,16400,10280,1025,29708,4160,112,21824,2,8192,65,31757,5440,4176,2421,20565,112,257,32,5376,513]

theorem envBound42337 : H12AffineFastState.Bounded env42337 := by
  intro p hp
  have h : env42337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42336_42337 : H12AffineEnvironment.transform 14 29709 env42336 = env42337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env42336 == env42337) = true)

theorem identity42337 : scanCanonicalize (H12AffineFastState.compose env42337 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound42337 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42338 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8461,8202,5392,10280,1025,8460,4160,112,64,2,8192,65,10509,5440,4176,2421,1365,112,257,32,5376,513]

theorem envBound42338 : H12AffineFastState.Bounded env42338 := by
  intro p hp
  have h : env42338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42337_42338 : H12AffineEnvironment.transform 13 5376 env42337 = env42338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env42337 == env42338) = true)

theorem identity42338 : scanCanonicalize (H12AffineFastState.compose env42338 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42338 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42339 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8461,8202,5392,10280,1025,8460,4113,33,17,2,8192,16,10509,5393,4097,2340,1284,33,257,32,5376,513]

theorem envBound42339 : H12AffineFastState.Bounded env42339 := by
  intro p hp
  have h : env42339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42338_42339 : H12AffineEnvironment.transform 5 17 env42338 = env42339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42338 == env42339) = true)

theorem identity42339 : scanCanonicalize (H12AffineFastState.compose env42339 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 1289) := by decide +kernel

theorem selectedBound42339 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42340 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,1289,5376,1028,1283,5392,3361,1025,1029,4113,33,17,2,1289,16,3076,5393,4097,2340,1284,33,257,32,5376,513]

theorem envBound42340 : H12AffineFastState.Bounded env42340 := by
  intro p hp
  have h : env42340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42339_42340 : H12AffineEnvironment.transform 12 1289 env42339 = env42340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env42339 == env42340) = true)

theorem identity42340 : scanCanonicalize (H12AffineFastState.compose env42340 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound42340 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env42341 : List Nat := [2,4,8,16,32,17,8,256,512,1024,560,4096,1289,5376,1028,1283,5392,1809,1025,1029,4113,33,17,2,1289,16,1588,5393,4097,788,1284,33,257,32,5376,513]

theorem envBound42341 : H12AffineFastState.Bounded env42341 := by
  intro p hp
  have h : env42341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42340_42341 : H12AffineEnvironment.transform 10 560 env42340 = env42341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env42340 == env42341) = true)

theorem identity42341 : scanCanonicalize (H12AffineFastState.compose env42341 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound42341 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env42342 : List Nat := [2,4,8,16,32,17,8,256,512,36,560,4096,301,4388,32,295,4404,821,37,33,4113,33,17,2,301,16,528,4405,4097,788,288,33,257,32,4388,513]

theorem envBound42342 : H12AffineFastState.Bounded env42342 := by
  intro p hp
  have h : env42342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42341_42342 : H12AffineEnvironment.transform 9 36 env42341 = env42342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env42341 == env42342) = true)

theorem identity42342 : scanCanonicalize (H12AffineFastState.compose env42342 (packedSelected [1,3,12] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42342 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env42343 : List Nat := [2,4,8,16,1,17,8,256,512,5,529,4096,268,4357,1,262,4373,788,4,0,4113,0,17,2,268,16,528,4372,4097,788,257,0,257,1,4357,513]

theorem envBound42343 : H12AffineFastState.Bounded env42343 := by
  intro p hp
  have h : env42343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42342_42343 : H12AffineEnvironment.transform 4 1 env42342 = env42343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42342 == env42343) = true)

theorem identity42343 : scanCanonicalize (H12AffineFastState.compose env42343 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound42343 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42344 : List Nat := [2,4,8,16,1,17,8,256,512,5,529,512,268,773,1,262,789,788,4,0,529,0,17,2,268,16,528,788,513,788,257,0,257,1,773,513]

theorem envBound42344 : H12AffineFastState.Bounded env42344 := by
  intro p hp
  have h : env42344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42343_42344 : H12AffineEnvironment.transform 11 512 env42343 = env42344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env42343 == env42344) = true)

theorem identity42344 : scanCanonicalize (H12AffineFastState.compose env42344 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound42344 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42345 : List Nat := [2,4,8,16,1,17,8,256,277,5,260,277,268,16,1,262,0,1,4,0,260,0,17,2,268,16,261,1,276,1,257,0,257,1,16,276]

theorem envBound42345 : H12AffineFastState.Bounded env42345 := by
  intro p hp
  have h : env42345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42344_42345 : H12AffineEnvironment.transform 8 277 env42344 = env42345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env42344 == env42345) = true)

def env42346 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4161,62588,119878,210201,8192,65,130315,172381,102743,212078,222543,177260,257,210235,250902,147985]

theorem envBound42346 : H12AffineFastState.Bounded env42346 := by
  intro p hp
  have h : env42346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42333_42346 : H12AffineEnvironment.transform 20 4161 env42333 = env42346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env42333 == env42346) = true)

def env42347 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,4161,62588,119878,95497,8192,65,130315,57677,102743,97406,75103,62588,257,95531,103430,513]

theorem envBound42347 : H12AffineFastState.Bounded env42347 := by
  intro p hp
  have h : env42347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42346_42347 : H12AffineEnvironment.transform 16 16400 env42346 = env42347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env42346 == env42347) = true)

theorem identity42347 : scanCanonicalize (H12AffineFastState.compose env42347 (packedSelected [0,3,4,5,7,9,10,11,12,15,18,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound42347 : packedSelected [0,3,4,5,7,9,10,11,12,15,18,20,23] rootPS < 2^1333 := by decide +kernel

def env42348 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,16400,10280,1025,32769,4161,62588,41293,2,8192,65,34816,57677,58460,2421,20564,62588,257,32,57613,513]

theorem envBound42348 : H12AffineFastState.Bounded env42348 := by
  intro p hp
  have h : env42348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42347_42348 : H12AffineEnvironment.transform 15 29963 env42347 = env42348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env42347 == env42348) = true)

theorem identity42348 : scanCanonicalize (H12AffineFastState.compose env42348 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound42348 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env42349 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29708,29963,16400,10280,1025,29709,4161,112,21825,2,8192,65,31756,5441,4176,2421,20564,112,257,32,5377,513]

theorem envBound42349 : H12AffineFastState.Bounded env42349 := by
  intro p hp
  have h : env42349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42348_42349 : H12AffineEnvironment.transform 14 29708 env42348 = env42349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env42348 == env42349) = true)

theorem identity42349 : scanCanonicalize (H12AffineFastState.compose env42349 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound42349 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42350 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8461,8202,5393,10280,1025,8460,4161,112,64,2,8192,65,10509,5441,4176,2421,1365,112,257,32,5377,513]

theorem envBound42350 : H12AffineFastState.Bounded env42350 := by
  intro p hp
  have h : env42350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42349_42350 : H12AffineEnvironment.transform 13 5377 env42349 = env42350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env42349 == env42350) = true)

theorem identity42350 : scanCanonicalize (H12AffineFastState.compose env42350 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42350 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42351 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8461,8202,5393,10280,1025,8460,4112,33,17,2,8192,16,10509,5392,4097,2340,1284,33,257,32,5377,513]

theorem envBound42351 : H12AffineFastState.Bounded env42351 := by
  intro p hp
  have h : env42351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42350_42351 : H12AffineEnvironment.transform 5 17 env42350 = env42351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42350 == env42351) = true)

theorem identity42351 : scanCanonicalize (H12AffineFastState.compose env42351 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 1288) := by decide +kernel

theorem selectedBound42351 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42352 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,1288,5377,1029,1282,5393,3360,1025,1028,4112,33,17,2,1288,16,3077,5392,4097,2340,1284,33,257,32,5377,513]

theorem envBound42352 : H12AffineFastState.Bounded env42352 := by
  intro p hp
  have h : env42352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42351_42352 : H12AffineEnvironment.transform 12 1288 env42351 = env42352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env42351 == env42352) = true)

theorem identity42352 : scanCanonicalize (H12AffineFastState.compose env42352 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound42352 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env42353 : List Nat := [2,4,8,16,32,17,8,256,512,1024,561,4096,1288,5377,1029,1282,5393,1809,1025,1028,4112,33,17,2,1288,16,1588,5392,4097,789,1284,33,257,32,5377,513]

theorem envBound42353 : H12AffineFastState.Bounded env42353 := by
  intro p hp
  have h : env42353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42352_42353 : H12AffineEnvironment.transform 10 561 env42352 = env42353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env42352 == env42353) = true)

theorem identity42353 : scanCanonicalize (H12AffineFastState.compose env42353 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound42353 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env42354 : List Nat := [2,4,8,16,32,17,8,256,512,36,561,4096,300,4389,33,294,4405,821,37,32,4112,33,17,2,300,16,528,4404,4097,789,288,33,257,32,4389,513]

theorem envBound42354 : H12AffineFastState.Bounded env42354 := by
  intro p hp
  have h : env42354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42353_42354 : H12AffineEnvironment.transform 9 36 env42353 = env42354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env42353 == env42354) = true)

theorem identity42354 : scanCanonicalize (H12AffineFastState.compose env42354 (packedSelected [1,3,12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound42354 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env42355 : List Nat := [2,4,8,16,0,17,8,256,512,4,529,4096,268,4357,1,262,4373,789,5,0,4112,1,17,2,268,16,528,4372,4097,789,256,1,257,0,4357,513]

theorem envBound42355 : H12AffineFastState.Bounded env42355 := by
  intro p hp
  have h : env42355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42354_42355 : H12AffineEnvironment.transform 4 0 env42354 = env42355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42354 == env42355) = true)

theorem identity42355 : scanCanonicalize (H12AffineFastState.compose env42355 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound42355 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42356 : List Nat := [2,4,8,16,0,17,8,256,512,4,529,513,268,772,1,262,788,789,5,0,529,1,17,2,268,16,528,789,512,789,256,1,257,0,772,513]

theorem envBound42356 : H12AffineFastState.Bounded env42356 := by
  intro p hp
  have h : env42356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42355_42356 : H12AffineEnvironment.transform 11 513 env42355 = env42356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env42355 == env42356) = true)

theorem identity42356 : scanCanonicalize (H12AffineFastState.compose env42356 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound42356 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42357 : List Nat := [2,4,8,16,0,17,8,256,277,4,260,276,268,17,1,262,1,0,5,0,260,1,17,2,268,16,261,0,277,0,256,1,257,0,17,276]

theorem envBound42357 : H12AffineFastState.Bounded env42357 := by
  intro p hp
  have h : env42357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42356_42357 : H12AffineEnvironment.transform 8 277 env42356 = env42357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env42356 == env42357) = true)

theorem identity42357 : scanCanonicalize (H12AffineFastState.compose env42357 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound42357 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env42358 : List Nat := [2,4,8,1,0,0,8,256,260,4,260,261,268,0,1,262,1,0,5,0,260,1,0,2,268,1,261,0,260,0,256,1,257,0,0,261]

theorem envBound42358 : H12AffineFastState.Bounded env42358 := by
  intro p hp
  have h : env42358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42357_42358 : H12AffineEnvironment.transform 3 1 env42357 = env42358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42357 == env42358) = true)

def env42359 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,4161,62588,119878,95496,8192,65,130315,57676,102743,97407,75102,62589,257,95530,103431,512]

theorem envBound42359 : H12AffineFastState.Bounded env42359 := by
  intro p hp
  have h : env42359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42346_42359 : H12AffineEnvironment.transform 16 16401 env42346 = env42359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env42346 == env42359) = true)

theorem identity42359 : scanCanonicalize (H12AffineFastState.compose env42359 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound42359 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42360 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,16401,10280,1025,32769,4161,62588,41292,2,8192,65,34817,57676,58461,2421,20564,62589,257,32,57613,512]

theorem envBound42360 : H12AffineFastState.Bounded env42360 := by
  intro p hp
  have h : env42360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42359_42360 : H12AffineEnvironment.transform 15 29962 env42359 = env42360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env42359 == env42360) = true)

theorem identity42360 : scanCanonicalize (H12AffineFastState.compose env42360 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 8461) := by decide +kernel

theorem selectedBound42360 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env42361 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,8461,32768,5127,8476,10280,1025,32769,4161,38257,41292,2,8192,65,34817,32833,34128,2421,12633,38256,257,32,32768,512]

theorem envBound42361 : H12AffineFastState.Bounded env42361 := by
  intro p hp
  have h : env42361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42360_42361 : H12AffineEnvironment.transform 13 8461 env42360 = env42361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8461 env42360 == env42361) = true)

theorem identity42361 : scanCanonicalize (H12AffineFastState.compose env42361 (packedSelected [0,1,2,4,6,7,8,9,10,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 14620) := by decide +kernel

theorem selectedBound42361 : packedSelected [0,1,2,4,6,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env42362 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,8461,14620,5127,8476,10280,1025,14621,4161,11373,6224,2,8192,65,12573,14685,15436,2421,12633,11372,257,32,14620,512]

theorem envBound42362 : H12AffineFastState.Bounded env42362 := by
  intro p hp
  have h : env42362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42361_42362 : H12AffineEnvironment.transform 14 14620 env42361 = env42362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14620 env42361 == env42362) = true)

theorem identity42362 : scanCanonicalize (H12AffineFastState.compose env42362 (packedSelected [0,1,3,4,5,7,8,9,15,16,18] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound42362 : packedSelected [0,1,3,4,5,7,8,9,15,16,18] rootPS < 2^1333 := by decide +kernel

def env42363 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3328,8192,8461,9244,2311,8476,10280,1025,9245,3393,11373,1360,2,8192,65,11293,9309,8524,2421,11353,11372,257,32,9244,512]

theorem envBound42363 : H12AffineFastState.Bounded env42363 := by
  intro p hp
  have h : env42363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42362_42363 : H12AffineEnvironment.transform 11 3328 env42362 = env42363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env42362 == env42363) = true)

theorem identity42363 : scanCanonicalize (H12AffineFastState.compose env42363 (packedSelected [1,2,6,8,10,12,16,20] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound42363 : packedSelected [1,2,6,8,10,12,16,20] rootPS < 2^1333 := by decide +kernel

def env42364 : List Nat := [2,4,8,16,32,64,8,4,512,1024,2048,3076,8192,8201,9244,2051,8216,10280,1025,9245,3141,11373,1108,2,8192,65,11293,9309,8264,2161,11353,11372,5,32,9244,512]

theorem envBound42364 : H12AffineFastState.Bounded env42364 := by
  intro p hp
  have h : env42364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42363_42364 : H12AffineEnvironment.transform 7 4 env42363 = env42364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env42363 == env42364) = true)

theorem identity42364 : scanCanonicalize (H12AffineFastState.compose env42364 (packedSelected [0,1,2,4,6,7,8,10,12,22] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound42364 : packedSelected [0,1,2,4,6,7,8,10,12,22] rootPS < 2^1333 := by decide +kernel

def env42365 : List Nat := [2,4,8,16,32,64,8,4,512,68,2048,2112,8192,8201,8280,2051,8216,10280,69,8281,2049,10281,16,2,8192,65,10329,8217,8264,2161,10269,10280,5,32,8280,512]

theorem envBound42365 : H12AffineFastState.Bounded env42365 := by
  intro p hp
  have h : env42365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42364_42365 : H12AffineEnvironment.transform 9 68 env42364 = env42365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env42364 == env42365) = true)

theorem identity42365 : scanCanonicalize (H12AffineFastState.compose env42365 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound42365 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env42366 : List Nat := [2,4,8,16,32,49,8,4,512,53,2048,2097,8192,8201,8233,2051,8216,10280,52,8232,2049,10281,16,2,8192,48,10280,8217,8249,2048,10269,10280,5,32,8233,512]

theorem envBound42366 : H12AffineFastState.Bounded env42366 := by
  intro p hp
  have h : env42366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42365_42366 : H12AffineEnvironment.transform 5 49 env42365 = env42366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env42365 == env42366) = true)

theorem identity42366 : scanCanonicalize (H12AffineFastState.compose env42366 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound42366 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env42367 : List Nat := [2,4,8,16,32,49,8,4,512,53,2048,2097,40,33,1,2051,48,2048,52,0,2049,2049,16,2,40,48,2048,49,17,2048,2101,2048,5,32,1,512]

theorem envBound42367 : H12AffineFastState.Bounded env42367 := by
  intro p hp
  have h : env42367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42366_42367 : H12AffineEnvironment.transform 12 40 env42366 = env42367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env42366 == env42367) = true)

theorem identity42367 : scanCanonicalize (H12AffineFastState.compose env42367 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound42367 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42368 : List Nat := [2,4,8,16,0,17,8,4,512,21,2048,2065,8,1,1,2051,16,2048,20,0,2049,2049,16,2,8,16,2048,17,17,2048,2069,2048,5,0,1,512]

theorem envBound42368 : H12AffineFastState.Bounded env42368 := by
  intro p hp
  have h : env42368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42367_42368 : H12AffineEnvironment.transform 4 0 env42367 = env42368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42367 == env42368) = true)

def env42369 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155701,2485295,2559345,8328,65,2475499,428540,375167,2305071,222542,2526212,257,2303475,2344022,148120]

theorem envBound42369 : H12AffineFastState.Bounded env42369 := by
  intro p hp
  have h : env42369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42330_42369 : H12AffineEnvironment.transform 23 2559345 env42330 = env42369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2559345 env42330 == env42369) = true)

def env42370 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155581,2485295,2559345,8192,65,2475363,428404,375167,2305071,222542,2526212,257,2303355,2344022,147984]

theorem envBound42370 : H12AffineFastState.Bounded env42370 := by
  intro p hp
  have h : env42370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42369_42370 : H12AffineEnvironment.transform 6 8 env42369 = env42370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42369 == env42370) = true)

theorem identity42370 : scanCanonicalize (H12AffineFastState.compose env42370 (packedSelected [3,4,7,9,10,14,16,17,20,24,26,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound42370 : packedSelected [3,4,7,9,10,14,16,17,20,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env42371 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,2155581,2485295,2444640,8192,65,2475363,313701,375167,2190398,75103,2411541,257,2188650,2196551,513]

theorem envBound42371 : H12AffineFastState.Bounded env42371 := by
  intro p hp
  have h : env42371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42370_42371 : H12AffineEnvironment.transform 16 16401 env42370 = env42371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env42370 == env42371) = true)

def env42372 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,2155581,2212871,2188616,8192,65,2223435,57677,102743,2190398,75103,2155581,257,2188650,2196551,513]

theorem envBound42372 : H12AffineFastState.Bounded env42372 := by
  intro p hp
  have h : env42372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42371_42372 : H12AffineEnvironment.transform 17 10280 env42371 = env42372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env42371 == env42372) = true)

theorem identity42372 : scanCanonicalize (H12AffineFastState.compose env42372 (packedSelected [0,3,4,5,7,9,10,11,12,15,18,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound42372 : packedSelected [0,3,4,5,7,9,10,11,12,15,18,20,23] rootPS < 2^1333 := by decide +kernel

def env42373 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40971,16401,10280,1025,32769,2097152,2155581,2122764,2147651,8192,65,2116928,57677,12636,2149429,34132,2155581,257,2147681,2106444,513]

theorem envBound42373 : H12AffineFastState.Bounded env42373 := by
  intro p hp
  have h : env42373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42372_42373 : H12AffineEnvironment.transform 15 40971 env42372 = env42373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env42372 == env42373) = true)

theorem identity42373 : scanCanonicalize (H12AffineFastState.compose env42373 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound42373 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env42374 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,81,8282,16401,10280,1025,80,2097152,2122860,2122764,2114834,8192,65,2116928,24860,12636,2116708,1285,2122860,257,2114864,2106444,513]

theorem envBound42374 : H12AffineFastState.Bounded env42374 := by
  intro p hp
  have h : env42374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42373_42374 : H12AffineEnvironment.transform 14 81 env42373 = env42374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env42373 == env42374) = true)

theorem identity42374 : scanCanonicalize (H12AffineFastState.compose env42374 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound42374 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env42375 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,81,342,16401,2340,1025,80,2097152,2114912,2114816,2114834,268,65,2116928,16400,4176,2116708,1285,2114912,257,2114864,2098496,513]

theorem envBound42375 : H12AffineFastState.Bounded env42375 := by
  intro p hp
  have h : env42375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42374_42375 : H12AffineEnvironment.transform 12 268 env42374 = env42375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env42374 == env42375) = true)

theorem identity42375 : scanCanonicalize (H12AffineFastState.compose env42375 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 17680) := by decide +kernel

theorem selectedBound42375 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42376 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,81,342,16401,2340,1025,80,17680,112,16,2,268,65,2128,16400,4176,2420,1285,112,257,32,16464,513]

theorem envBound42376 : H12AffineFastState.Bounded env42376 := by
  intro p hp
  have h : env42376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42375_42376 : H12AffineEnvironment.transform 20 17680 env42375 = env42376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17680 env42375 == env42376) = true)

theorem identity42376 : scanCanonicalize (H12AffineFastState.compose env42376 (packedSelected [2,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 1361) := by decide +kernel

theorem selectedBound42376 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env42377 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,1361,81,342,1344,2340,1025,80,65,112,16,2,268,65,2128,1345,4176,2420,1285,112,257,32,1281,513]

theorem envBound42377 : H12AffineFastState.Bounded env42377 := by
  intro p hp
  have h : env42377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42376_42377 : H12AffineEnvironment.transform 13 1361 env42376 = env42377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1361 env42376 == env42377) = true)

def env42378 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,2097152,2155581,2212870,2188617,8192,65,2223434,57676,102742,2190398,75103,2155580,257,2188650,2196551,513]

theorem envBound42378 : H12AffineFastState.Bounded env42378 := by
  intro p hp
  have h : env42378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42371_42378 : H12AffineEnvironment.transform 17 10281 env42371 = env42378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env42371 == env42378) = true)

theorem identity42378 : scanCanonicalize (H12AffineFastState.compose env42378 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound42378 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42379 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,10281,1025,32769,2097152,2155581,2155533,2114882,8192,65,2149697,57676,45405,2116661,1364,2155580,257,2114913,2139212,513]

theorem envBound42379 : H12AffineFastState.Bounded env42379 := by
  intro p hp
  have h : env42379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42378_42379 : H12AffineEnvironment.transform 15 8203 env42378 = env42379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env42378 == env42379) = true)

theorem identity42379 : scanCanonicalize (H12AffineFastState.compose env42379 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 29004) := by decide +kernel

theorem selectedBound42379 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42380 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29004,8203,16401,10281,1025,29005,2097152,2102641,2102593,2114882,8192,65,2112525,4096,16401,2116661,1364,2102640,257,2114913,2118912,513]

theorem envBound42380 : H12AffineFastState.Bounded env42380 := by
  intro p hp
  have h : env42380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42379_42380 : H12AffineEnvironment.transform 14 29004 env42379 = env42380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29004 env42379 == env42380) = true)

theorem identity42380 : scanCanonicalize (H12AffineFastState.compose env42380 (packedSelected [0,1,3,5,7,8,14,15,18] rootPS)) = affineNative (2^(20+1) ^^^ 11625) := by decide +kernel

theorem selectedBound42380 : packedSelected [0,1,3,5,7,8,14,15,18] rootPS < 2^1333 := by decide +kernel

def env42381 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29004,8203,16401,10281,1025,29005,11625,14360,14376,26667,8192,65,4452,4096,16401,24924,1364,14361,257,26632,30825,513]

theorem envBound42381 : H12AffineFastState.Bounded env42381 := by
  intro p hp
  have h : env42381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42380_42381 : H12AffineEnvironment.transform 20 11625 env42380 = env42381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 11625 env42380 == env42381) = true)

theorem identity42381 : scanCanonicalize (H12AffineFastState.compose env42381 (packedSelected [11,12,14,15,20] rootPS)) = affineNative (2^(12+1) ^^^ 3148) := by decide +kernel

theorem selectedBound42381 : packedSelected [11,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env42382 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3148,16384,23808,3143,16401,1125,1025,23809,293,5204,5220,17511,3148,65,4452,4096,16401,19728,1364,5205,257,17476,21541,513]

theorem envBound42382 : H12AffineFastState.Bounded env42382 := by
  intro p hp
  have h : env42382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42381_42382 : H12AffineEnvironment.transform 12 3148 env42381 = env42382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3148 env42381 == env42382) = true)

theorem identity42382 : scanCanonicalize (H12AffineFastState.compose env42382 (packedSelected [21] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound42382 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42383 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1141,3148,16384,18805,3143,16401,1125,1025,18804,293,33,17,17511,3148,65,1297,1141,16401,19728,1364,32,257,17476,16464,513]

theorem envBound42383 : H12AffineFastState.Bounded env42383 := by
  intro p hp
  have h : env42383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42382_42383 : H12AffineEnvironment.transform 11 1141 env42382 = env42383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env42382 == env42383) = true)

theorem identity42383 : scanCanonicalize (H12AffineFastState.compose env42383 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 2128) := by decide +kernel

theorem selectedBound42383 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env42384 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1141,3148,2128,293,3143,2113,1125,1025,292,293,33,17,3127,3148,65,1297,1141,2113,1344,1364,32,257,3092,2048,513]

theorem envBound42384 : H12AffineFastState.Bounded env42384 := by
  intro p hp
  have h : env42384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42383_42384 : H12AffineEnvironment.transform 13 2128 env42383 = env42384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2128 env42383 == env42384) = true)

theorem identity42384 : scanCanonicalize (H12AffineFastState.compose env42384 (packedSelected [1,4,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 788) := by decide +kernel

theorem selectedBound42384 : packedSelected [1,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env42385 : List Nat := [2,4,8,16,32,64,8,256,512,1024,788,1141,1880,836,293,1875,853,1125,1025,292,293,33,17,1827,1880,65,1297,1141,853,1344,1364,32,257,1792,788,513]

theorem envBound42385 : H12AffineFastState.Bounded env42385 := by
  intro p hp
  have h : env42385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42384_42385 : H12AffineEnvironment.transform 10 788 env42384 = env42385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 788 env42384 == env42385) = true)

theorem identity42385 : scanCanonicalize (H12AffineFastState.compose env42385 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound42385 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env42386 : List Nat := [2,4,8,16,32,64,8,256,32,1024,308,1141,1400,356,293,1395,373,1125,1025,292,293,33,17,1283,1400,65,1297,1141,373,1344,1364,32,257,1312,308,33]

theorem envBound42386 : H12AffineFastState.Bounded env42386 := by
  intro p hp
  have h : env42386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42385_42386 : H12AffineEnvironment.transform 8 32 env42385 = env42386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env42385 == env42386) = true)

theorem identity42386 : scanCanonicalize (H12AffineFastState.compose env42386 (packedSelected [0,1,3,4,5,6,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound42386 : packedSelected [0,1,3,4,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env42387 : List Nat := [2,4,8,16,32,64,8,256,32,37,308,80,349,356,293,342,373,64,36,292,293,33,17,294,349,65,308,80,373,357,369,32,257,261,308,33]

theorem envBound42387 : H12AffineFastState.Bounded env42387 := by
  intro p hp
  have h : env42387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42386_42387 : H12AffineEnvironment.transform 9 37 env42386 = env42387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env42386 == env42387) = true)

theorem identity42387 : scanCanonicalize (H12AffineFastState.compose env42387 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42387 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42388 : List Nat := [2,4,8,16,32,16,8,256,32,37,308,0,269,308,293,262,293,16,36,292,293,33,17,294,269,17,308,0,293,309,289,32,257,261,308,33]

theorem envBound42388 : H12AffineFastState.Bounded env42388 := by
  intro p hp
  have h : env42388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42387_42388 : H12AffineEnvironment.transform 5 16 env42387 = env42388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42387 == env42388) = true)

theorem identity42388 : scanCanonicalize (H12AffineFastState.compose env42388 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound42388 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42389 : List Nat := [2,4,8,16,32,16,8,53,32,37,1,0,56,1,16,51,16,16,36,17,16,33,17,19,56,17,1,0,16,0,20,32,52,48,1,33]

theorem envBound42389 : H12AffineFastState.Bounded env42389 := by
  intro p hp
  have h : env42389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42388_42389 : H12AffineEnvironment.transform 7 53 env42388 = env42389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env42388 == env42389) = true)

theorem identity42389 : scanCanonicalize (H12AffineFastState.compose env42389 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound42389 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42390 : List Nat := [2,4,8,16,16,16,8,5,16,21,1,0,8,1,16,3,16,16,20,17,16,17,17,19,8,17,1,0,16,0,20,16,4,0,1,17]

theorem envBound42390 : H12AffineFastState.Bounded env42390 := by
  intro p hp
  have h : env42390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42389_42390 : H12AffineEnvironment.transform 4 16 env42389 = env42390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env42389 == env42390) = true)

theorem identity42390 : scanCanonicalize (H12AffineFastState.compose env42390 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound42390 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42391 : List Nat := [2,4,8,1,1,1,8,5,1,4,1,0,8,1,1,3,1,1,5,0,1,0,0,2,8,0,1,0,1,0,5,1,4,0,1,0]

theorem envBound42391 : H12AffineFastState.Bounded env42391 := by
  intro p hp
  have h : env42391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42390_42391 : H12AffineEnvironment.transform 3 1 env42390 = env42391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42390 == env42391) = true)

theorem identity42391 : scanCanonicalize (H12AffineFastState.compose env42391 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound42391 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42392 : List Nat := [2,4,2,1,1,1,2,5,1,4,1,0,2,1,1,3,1,1,5,0,1,0,0,2,2,0,1,0,1,0,5,1,4,0,1,0]

theorem envBound42392 : H12AffineFastState.Bounded env42392 := by
  intro p hp
  have h : env42392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42391_42392 : H12AffineEnvironment.transform 2 2 env42391 = env42392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env42391 == env42392) = true)

def env42393 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155580,2485295,2559345,8193,65,2475362,428405,375167,2305071,222542,2526212,257,2303354,2344022,147985]

theorem envBound42393 : H12AffineFastState.Bounded env42393 := by
  intro p hp
  have h : env42393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42369_42393 : H12AffineEnvironment.transform 6 9 env42369 = env42393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42369 == env42393) = true)

theorem identity42393 : scanCanonicalize (H12AffineFastState.compose env42393 (packedSelected [1,17,19,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound42393 : packedSelected [1,17,19,28,31] rootPS < 2^1333 := by decide +kernel

def env42394 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,2155580,2188634,2327556,8193,65,2182167,131072,77834,2305071,222542,2229617,257,2303354,2344022,147985]

theorem envBound42394 : H12AffineFastState.Bounded env42394 := by
  intro p hp
  have h : env42394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42393_42394 : H12AffineEnvironment.transform 17 35189 env42393 = env42394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env42393 == env42394) = true)

theorem identity42394 : scanCanonicalize (H12AffineFastState.compose env42394 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound42394 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env42395 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,35189,1025,32769,2097152,2155580,2114896,2270222,8193,65,2124829,131072,4096,2231333,148804,2229617,257,2229616,2286684,147985]

theorem envBound42395 : H12AffineFastState.Bounded env42395 := by
  intro p hp
  have h : env42395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42394_42395 : H12AffineEnvironment.transform 15 8202 env42394 = env42395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env42394 == env42395) = true)

def env42396 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616401,155254785,92374097,145662401,525568,140903597,27337992,25733063]

theorem envBound42396 : H12AffineFastState.Bounded env42396 := by
  intro p hp
  have h : env42396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41011_42396 : H12AffineEnvironment.transform 29 155254785 env41011 = env42396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env41011 == env42396) = true)

def env42397 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507601,155254785,25265169,145662401,525568,140903597,27337992,25733063]

theorem envBound42397 : H12AffineFastState.Bounded env42397 := by
  intro p hp
  have h : env42397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42396_42397 : H12AffineEnvironment.transform 25 64 env42396 = env42397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env42396 == env42397) = true)

def env42398 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507601,9356289,25265169,23160257,525568,27902125,27337992,25733063]

theorem envBound42398 : H12AffineFastState.Bounded env42398 := by
  intro p hp
  have h : env42398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42397_42398 : H12AffineEnvironment.transform 26 30393344 env42397 = env42398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env42397 == env42398) = true)

def env42399 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830977,25265169,23160257,256,27378861,27337992,25207751]

theorem envBound42399 : H12AffineFastState.Bounded env42399 := by
  intro p hp
  have h : env42399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42398_42399 : H12AffineEnvironment.transform 18 1024 env42398 = env42399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env42398 == env42399) = true)

theorem identity42399 : scanCanonicalize (H12AffineFastState.compose env42399 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 41310) := by decide +kernel

theorem selectedBound42399 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env42400 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,41310,8328,64,13066590,2172370,10507601,8830977,8463695,6407327,256,10577395,10585174,8389273]

theorem envBound42400 : H12AffineFastState.Bounded env42400 := by
  intro p hp
  have h : env42400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42399_42400 : H12AffineEnvironment.transform 23 41310 env42399 = env42400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41310 env42399 == env42400) = true)

def env42401 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,41310,8192,64,13066590,2172250,10507601,8830977,8463695,6407191,256,10577275,10585174,8389137]

theorem envBound42401 : H12AffineFastState.Bounded env42401 := by
  intro p hp
  have h : env42401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42400_42401 : H12AffineEnvironment.transform 6 8 env42400 = env42401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42400 == env42401) = true)

def env42402 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,41310,8192,64,4677966,2172250,2118977,442385,75103,6407191,256,2188651,2196550,513]

theorem envBound42402 : H12AffineFastState.Bounded env42402 := by
  intro p hp
  have h : env42402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42401_42402 : H12AffineEnvironment.transform 22 16 env42401 = env42402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env42401 == env42402) = true)

def env42403 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41310,8192,64,4677966,115014,45405,442385,75103,4268043,256,98679,90202,513]

theorem envBound42403 : H12AffineFastState.Bounded env42403 := by
  intro p hp
  have h : env42403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42402_42403 : H12AffineEnvironment.transform 20 58396 env42402 = env42403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env42402 == env42403) = true)

theorem identity42403 : scanCanonicalize (H12AffineFastState.compose env42403 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound42403 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42404 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,58396,4194304,16,41310,8192,64,4604229,57677,45405,442385,1364,4194304,256,41340,16465,513]

theorem envBound42404 : H12AffineFastState.Bounded env42404 := by
  intro p hp
  have h : env42404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42403_42404 : H12AffineEnvironment.transform 15 8203 env42403 = env42404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env42403 == env42404) = true)

theorem identity42404 : scanCanonicalize (H12AffineFastState.compose env42404 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 419913) := by decide +kernel

theorem selectedBound42404 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env42405 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,58396,419913,16,41310,8192,64,10508,57677,45405,442385,1364,419913,256,41340,16465,513]

theorem envBound42405 : H12AffineFastState.Bounded env42405 := by
  intro p hp
  have h : env42405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42404_42405 : H12AffineEnvironment.transform 21 419913 env42404 = env42405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 419913 env42404 == env42405) = true)

def env42406 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16448,262144,1024,32769,58396,272393,16,41310,8192,64,10508,57677,45405,294993,1364,272393,256,41340,16465,513]

theorem envBound42406 : H12AffineFastState.Bounded env42406 := by
  intro p hp
  have h : env42406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42405_42406 : H12AffineEnvironment.transform 16 16448 env42405 = env42406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env42405 == env42406) = true)

theorem identity42406 : scanCanonicalize (H12AffineFastState.compose env42406 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound42406 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env42407 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8203,16448,262144,1024,8540,17729,272393,16,3,8192,64,10508,16400,4096,270604,1364,272393,256,33,16465,513]

theorem envBound42407 : H12AffineFastState.Bounded env42407 := by
  intro p hp
  have h : env42407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42406_42407 : H12AffineEnvironment.transform 14 8541 env42406 = env42407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env42406 == env42407) = true)

theorem identity42407 : scanCanonicalize (H12AffineFastState.compose env42407 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound42407 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42408 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8203,16448,2420,1024,8540,17729,8573,16,3,8192,64,10508,16400,4096,10360,1364,8573,256,33,16465,513]

theorem envBound42408 : H12AffineFastState.Bounded env42408 := by
  intro p hp
  have h : env42408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42407_42408 : H12AffineEnvironment.transform 17 2420 env42407 = env42408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env42407 == env42408) = true)

theorem identity42408 : scanCanonicalize (H12AffineFastState.compose env42408 (packedSelected [4,9,10,11,12,15,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound42408 : packedSelected [4,9,10,11,12,15,18,19] rootPS < 2^1333 := by decide +kernel

def env42409 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8541,8203,4176,2420,1024,8540,5457,8573,16,3,8192,64,10508,4096,4096,10360,1364,8573,256,33,4161,513]

theorem envBound42409 : H12AffineFastState.Bounded env42409 := by
  intro p hp
  have h : env42409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42408_42409 : H12AffineEnvironment.transform 13 4112 env42408 = env42409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env42408 == env42409) = true)

theorem identity42409 : scanCanonicalize (H12AffineFastState.compose env42409 (packedSelected [1,4,8,9,10,11,12,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42409 : packedSelected [1,4,8,9,10,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env42410 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,4112,8461,8203,4096,2340,1024,8460,5377,8493,16,3,8192,16,10508,4096,4096,10280,1284,8493,256,33,4113,513]

theorem envBound42410 : H12AffineFastState.Bounded env42410 := by
  intro p hp
  have h : env42410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42409_42410 : H12AffineEnvironment.transform 5 16 env42409 = env42410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42409 == env42410) = true)

theorem identity42410 : scanCanonicalize (H12AffineFastState.compose env42410 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound42410 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42411 : List Nat := [2,4,8,16,32,16,8,5,512,1024,2048,4096,8192,4112,8200,8203,4096,2081,1024,8201,5124,8232,16,3,8192,16,10249,4096,4096,10280,1025,8232,5,33,4113,513]

theorem envBound42411 : H12AffineFastState.Bounded env42411 := by
  intro p hp
  have h : env42411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42410_42411 : H12AffineEnvironment.transform 7 5 env42410 = env42411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env42410 == env42411) = true)

theorem identity42411 : scanCanonicalize (H12AffineFastState.compose env42411 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 1084) := by decide +kernel

theorem selectedBound42411 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env42412 : List Nat := [2,4,8,16,32,16,8,5,512,1024,2048,4096,1084,4112,1076,1079,4096,2081,1024,1077,5124,1044,16,3,1084,16,3125,4096,4096,3092,1025,1044,5,33,4113,513]

theorem envBound42412 : H12AffineFastState.Bounded env42412 := by
  intro p hp
  have h : env42412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42411_42412 : H12AffineEnvironment.transform 12 1084 env42411 = env42412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1084 env42411 == env42412) = true)

theorem identity42412 : scanCanonicalize (H12AffineFastState.compose env42412 (packedSelected [0,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound42412 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env42413 : List Nat := [2,4,8,16,32,16,8,5,16,1024,2048,4096,1084,4112,1076,1079,4096,2081,1024,1077,5124,1044,16,3,1084,16,3125,4096,4096,3092,1025,1044,5,33,4113,17]

theorem envBound42413 : H12AffineFastState.Bounded env42413 := by
  intro p hp
  have h : env42413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42412_42413 : H12AffineEnvironment.transform 8 16 env42412 = env42413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env42412 == env42413) = true)

def env42414 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16449,262144,1024,32769,58396,272392,16,41310,8192,64,10508,57677,45405,294992,1364,272392,256,41340,16465,513]

theorem envBound42414 : H12AffineFastState.Bounded env42414 := by
  intro p hp
  have h : env42414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42405_42414 : H12AffineEnvironment.transform 16 16449 env42405 = env42414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env42405 == env42414) = true)

theorem identity42414 : scanCanonicalize (H12AffineFastState.compose env42414 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound42414 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env42415 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,80,8203,16449,262144,1024,81,25676,272392,16,8462,8192,64,10508,24861,12557,262144,1364,272392,256,8492,16465,513]

theorem envBound42415 : H12AffineFastState.Bounded env42415 := by
  intro p hp
  have h : env42415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42414_42415 : H12AffineEnvironment.transform 14 80 env42414 = env42415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env42414 == env42415) = true)

theorem identity42415 : scanCanonicalize (H12AffineFastState.compose env42415 (packedSelected [0,2,6,7,20] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound42415 : packedSelected [0,2,6,7,20] rootPS < 2^1333 := by decide +kernel

def env42416 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,80,8203,16449,2420,1024,81,25676,8572,16,8462,8192,64,10508,24861,12557,2420,1364,8572,256,8492,16465,513]

theorem envBound42416 : H12AffineFastState.Bounded env42416 := by
  intro p hp
  have h : env42416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42415_42416 : H12AffineEnvironment.transform 17 2420 env42415 = env42416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env42415 == env42416) = true)

theorem identity42416 : scanCanonicalize (H12AffineFastState.compose env42416 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound42416 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env42417 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,80,342,16449,2420,1024,81,17681,33,16,83,349,64,2129,16448,4176,2420,1364,33,256,113,16465,513]

theorem envBound42417 : H12AffineFastState.Bounded env42417 := by
  intro p hp
  have h : env42417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42416_42417 : H12AffineEnvironment.transform 12 349 env42416 = env42417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env42416 == env42417) = true)

theorem identity42417 : scanCanonicalize (H12AffineFastState.compose env42417 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42417 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42418 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,1,263,16400,2341,1024,0,17681,33,16,2,268,17,2048,16401,4097,2341,1285,33,256,32,16384,513]

theorem envBound42418 : H12AffineFastState.Bounded env42418 := by
  intro p hp
  have h : env42418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42417_42418 : H12AffineEnvironment.transform 5 17 env42417 = env42418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42417 == env42418) = true)

theorem identity42418 : scanCanonicalize (H12AffineFastState.compose env42418 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound42418 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42419 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5156,1,263,5172,2341,1024,0,4405,33,16,2,268,17,2048,5173,4097,2341,1285,33,256,32,5156,513]

theorem envBound42419 : H12AffineFastState.Bounded env42419 := by
  intro p hp
  have h : env42419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42418_42419 : H12AffineEnvironment.transform 13 5156 env42418 = env42419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env42418 == env42419) = true)

def env42420 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3888,268,2836,1,263,2820,2341,1024,0,3589,33,16,2,268,17,2048,2821,3889,2341,1285,33,256,32,2836,513]

theorem envBound42420 : H12AffineFastState.Bounded env42420 := by
  intro p hp
  have h : env42420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42419_42420 : H12AffineEnvironment.transform 11 3888 env42419 = env42420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env42419 == env42420) = true)

def env42421 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,48,268,1044,1,263,1028,1573,1024,0,261,33,16,2,268,17,1792,1029,49,1573,1285,33,256,32,1044,513]

theorem envBound42421 : H12AffineFastState.Bounded env42421 := by
  intro p hp
  have h : env42421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42420_42421 : H12AffineEnvironment.transform 10 1792 env42420 = env42421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env42420 == env42421) = true)

theorem identity42421 : scanCanonicalize (H12AffineFastState.compose env42421 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound42421 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42422 : List Nat := [2,4,8,16,32,17,8,256,16,1024,1296,48,268,1044,1,263,1028,1077,1024,0,261,33,16,2,268,17,1296,1029,49,1077,1285,33,256,32,1044,17]

theorem envBound42422 : H12AffineFastState.Bounded env42422 := by
  intro p hp
  have h : env42422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42421_42422 : H12AffineEnvironment.transform 8 16 env42421 = env42422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env42421 == env42422) = true)

def env42423 : List Nat := [2,4,8,16,32,17,8,256,16,52,292,48,268,32,1,263,48,1,52,0,261,33,16,2,268,17,292,49,49,1,305,33,256,32,32,17]

theorem envBound42423 : H12AffineFastState.Bounded env42423 := by
  intro p hp
  have h : env42423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42422_42423 : H12AffineEnvironment.transform 9 52 env42422 = env42423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env42422 == env42423) = true)

theorem identity42423 : scanCanonicalize (H12AffineFastState.compose env42423 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound42423 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42424 : List Nat := [2,4,8,16,32,17,8,4,16,52,32,48,8,32,1,3,48,1,52,0,1,33,16,2,8,17,32,49,49,1,53,33,4,32,32,17]

theorem envBound42424 : H12AffineFastState.Bounded env42424 := by
  intro p hp
  have h : env42424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42423_42424 : H12AffineEnvironment.transform 7 4 env42423 = env42424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env42423 == env42424) = true)

def leafEnv42424 : List Nat := [2,4,8,16,32,17,8,4,16,52,32,48,8,32,1,3,48,1,52,0,1,33,16,2,53,8,1,17,32,49,49,1,53,33,4,32,4,3,32,17,1,1,0]

def active42424 : List Nat := [0,1,2,3,4]

def tree42424 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42424 : H12WitnessSearch.Good tree42424 := H12GlobalWitnessIndex.good

theorem leafIdentity42424 : H12AffineFastState.composeSystem env42424 rootObs = leafEnv42424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42424 rootObs == leafEnv42424) = true)

theorem terminalChecked42424 : H12PackedTerminal.terminalCheckFast leafEnv42424 active42424 tree42424 = true := by decide +kernel

def env42425 : List Nat := [2,4,8,16,32,17,8,256,16,53,293,48,268,33,1,263,49,0,53,0,261,33,16,2,268,17,293,48,49,0,304,33,256,32,33,17]

theorem envBound42425 : H12AffineFastState.Bounded env42425 := by
  intro p hp
  have h : env42425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42422_42425 : H12AffineEnvironment.transform 9 53 env42422 = env42425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env42422 == env42425) = true)

theorem identity42425 : scanCanonicalize (H12AffineFastState.compose env42425 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound42425 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42426 : List Nat := [2,4,8,10,32,11,8,256,10,47,293,42,268,33,1,263,43,0,47,0,261,33,10,2,268,11,293,42,43,0,298,33,256,32,33,11]

theorem envBound42426 : H12AffineFastState.Bounded env42426 := by
  intro p hp
  have h : env42426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42425_42426 : H12AffineEnvironment.transform 3 10 env42425 = env42426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env42425 == env42426) = true)

def leafEnv42426 : List Nat := [2,4,8,10,32,11,8,256,10,47,293,42,268,33,1,263,43,0,47,0,261,33,10,2,298,268,1,11,293,42,43,0,298,33,256,32,4,263,33,11,1,261,0]

def active42426 : List Nat := [0,1,2,4,7]

def tree42426 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42426 : H12WitnessSearch.Good tree42426 := H12GlobalWitnessIndex.good

theorem leafIdentity42426 : H12AffineFastState.composeSystem env42426 rootObs = leafEnv42426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42426 rootObs == leafEnv42426) = true)

theorem terminalChecked42426 : H12PackedTerminal.terminalCheckFast leafEnv42426 active42426 tree42426 = true := by decide +kernel

def env42427 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,49,268,1045,1,263,1029,1572,1024,0,260,33,16,2,268,17,1793,1028,48,1572,1285,33,256,32,1045,513]

theorem envBound42427 : H12AffineFastState.Bounded env42427 := by
  intro p hp
  have h : env42427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42420_42427 : H12AffineEnvironment.transform 10 1793 env42420 = env42427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env42420 == env42427) = true)

theorem identity42427 : scanCanonicalize (H12AffineFastState.compose env42427 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 769) := by decide +kernel

theorem selectedBound42427 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42428 : List Nat := [2,4,8,16,32,17,8,256,512,769,0,49,268,788,1,263,772,293,769,0,260,33,16,2,268,17,0,773,48,293,516,33,256,32,788,513]

theorem envBound42428 : H12AffineFastState.Bounded env42428 := by
  intro p hp
  have h : env42428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42427_42428 : H12AffineEnvironment.transform 9 769 env42427 = env42428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env42427 == env42428) = true)

def env42429 : List Nat := [2,4,8,16,32,17,8,256,308,53,0,49,268,32,1,263,48,293,53,0,260,33,16,2,268,17,0,49,48,293,304,33,256,32,32,309]

theorem envBound42429 : H12AffineFastState.Bounded env42429 := by
  intro p hp
  have h : env42429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42428_42429 : H12AffineEnvironment.transform 8 308 env42428 = env42429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env42428 == env42429) = true)

theorem identity42429 : scanCanonicalize (H12AffineFastState.compose env42429 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound42429 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42430 : List Nat := [2,4,8,11,32,10,8,256,303,46,0,42,268,32,1,263,43,293,46,0,260,33,11,2,268,10,0,42,43,293,299,33,256,32,32,302]

theorem envBound42430 : H12AffineFastState.Bounded env42430 := by
  intro p hp
  have h : env42430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42429_42430 : H12AffineEnvironment.transform 3 11 env42429 = env42430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env42429 == env42430) = true)

def leafEnv42430 : List Nat := [2,4,8,11,32,10,8,256,303,46,0,42,268,32,1,263,43,293,46,0,260,33,11,2,299,268,1,10,0,42,43,293,299,33,256,32,4,263,32,302,1,260,0]

def active42430 : List Nat := [0,1,2,4,7]

def tree42430 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42430 : H12WitnessSearch.Good tree42430 := H12GlobalWitnessIndex.good

theorem leafIdentity42430 : H12AffineFastState.composeSystem env42430 rootObs = leafEnv42430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42430 rootObs == leafEnv42430) = true)

theorem terminalChecked42430 : H12PackedTerminal.terminalCheckFast leafEnv42430 active42430 tree42430 = true := by decide +kernel

def env42431 : List Nat := [2,4,8,16,32,17,8,256,309,52,0,49,268,33,1,263,49,293,52,0,260,33,16,2,268,17,0,48,48,293,305,33,256,32,33,308]

theorem envBound42431 : H12AffineFastState.Bounded env42431 := by
  intro p hp
  have h : env42431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42428_42431 : H12AffineEnvironment.transform 8 309 env42428 = env42431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env42428 == env42431) = true)

theorem identity42431 : scanCanonicalize (H12AffineFastState.compose env42431 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42431 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42432 : List Nat := [2,4,8,16,1,17,8,256,276,21,0,16,268,0,1,263,16,260,21,0,260,0,16,2,268,17,0,17,17,260,272,0,256,1,0,277]

theorem envBound42432 : H12AffineFastState.Bounded env42432 := by
  intro p hp
  have h : env42432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42431_42432 : H12AffineEnvironment.transform 4 1 env42431 = env42432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42431 == env42432) = true)

def leafEnv42432 : List Nat := [2,4,8,16,1,17,8,256,276,21,0,16,268,0,1,263,16,260,21,0,260,0,16,2,272,268,1,17,0,17,17,260,272,0,256,1,4,263,0,277,1,260,0]

def active42432 : List Nat := [0,1,2,3,7]

def tree42432 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42432 : H12WitnessSearch.Good tree42432 := H12GlobalWitnessIndex.good

theorem leafIdentity42432 : H12AffineFastState.composeSystem env42432 rootObs = leafEnv42432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42432 rootObs == leafEnv42432) = true)

theorem terminalChecked42432 : H12PackedTerminal.terminalCheckFast leafEnv42432 active42432 tree42432 = true := by decide +kernel

def env42433 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3889,268,2837,1,263,2821,2341,1024,0,3588,33,16,2,268,17,2048,2820,3888,2341,1285,33,256,32,2837,513]

theorem envBound42433 : H12AffineFastState.Bounded env42433 := by
  intro p hp
  have h : env42433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42419_42433 : H12AffineEnvironment.transform 11 3889 env42419 = env42433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env42419 == env42433) = true)

def env42434 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,49,268,1045,1,263,1029,1573,1024,0,260,33,16,2,268,17,1792,1028,48,1573,1285,33,256,32,1045,513]

theorem envBound42434 : H12AffineFastState.Bounded env42434 := by
  intro p hp
  have h : env42434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42433_42434 : H12AffineEnvironment.transform 10 1792 env42433 = env42434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env42433 == env42434) = true)

theorem identity42434 : scanCanonicalize (H12AffineFastState.compose env42434 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound42434 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42435 : List Nat := [2,4,8,16,32,17,8,256,512,549,293,49,268,560,1,263,544,0,549,0,260,33,16,2,268,17,293,545,48,0,800,33,256,32,560,513]

theorem envBound42435 : H12AffineFastState.Bounded env42435 := by
  intro p hp
  have h : env42435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42434_42435 : H12AffineEnvironment.transform 9 549 env42434 = env42435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env42434 == env42435) = true)

def env42436 : List Nat := [2,4,8,16,32,17,8,256,16,53,293,49,268,32,1,263,48,0,53,0,260,33,16,2,268,17,293,49,48,0,304,33,256,32,32,17]

theorem envBound42436 : H12AffineFastState.Bounded env42436 := by
  intro p hp
  have h : env42436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42435_42436 : H12AffineEnvironment.transform 8 16 env42435 = env42436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env42435 == env42436) = true)

theorem identity42436 : scanCanonicalize (H12AffineFastState.compose env42436 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound42436 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42437 : List Nat := [2,4,8,10,32,11,8,256,10,47,293,43,268,32,1,263,42,0,47,0,260,33,10,2,268,11,293,43,42,0,298,33,256,32,32,11]

theorem envBound42437 : H12AffineFastState.Bounded env42437 := by
  intro p hp
  have h : env42437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42436_42437 : H12AffineEnvironment.transform 3 10 env42436 = env42437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env42436 == env42437) = true)

def leafEnv42437 : List Nat := [2,4,8,10,32,11,8,256,10,47,293,43,268,32,1,263,42,0,47,0,260,33,10,2,298,268,1,11,293,43,42,0,298,33,256,32,4,263,32,11,1,260,0]

def active42437 : List Nat := [0,1,2,4,7]

def tree42437 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42437 : H12WitnessSearch.Good tree42437 := H12GlobalWitnessIndex.good

theorem leafIdentity42437 : H12AffineFastState.composeSystem env42437 rootObs = leafEnv42437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42437 rootObs == leafEnv42437) = true)

theorem terminalChecked42437 : H12PackedTerminal.terminalCheckFast leafEnv42437 active42437 tree42437 = true := by decide +kernel

def env42438 : List Nat := [2,4,8,16,32,17,8,256,17,52,293,49,268,33,1,263,49,0,52,0,260,33,16,2,268,17,293,48,48,0,305,33,256,32,33,16]

theorem envBound42438 : H12AffineFastState.Bounded env42438 := by
  intro p hp
  have h : env42438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42435_42438 : H12AffineEnvironment.transform 8 17 env42435 = env42438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env42435 == env42438) = true)

theorem identity42438 : scanCanonicalize (H12AffineFastState.compose env42438 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound42438 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42439 : List Nat := [2,4,8,16,32,17,8,4,17,52,33,49,8,33,1,3,49,0,52,0,0,33,16,2,8,17,33,48,48,0,53,33,4,32,33,16]

theorem envBound42439 : H12AffineFastState.Bounded env42439 := by
  intro p hp
  have h : env42439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42438_42439 : H12AffineEnvironment.transform 7 4 env42438 = env42439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env42438 == env42439) = true)

def leafEnv42439 : List Nat := [2,4,8,16,32,17,8,4,17,52,33,49,8,33,1,3,49,0,52,0,0,33,16,2,53,8,1,17,33,48,48,0,53,33,4,32,4,3,33,16,1,0,0]

def active42439 : List Nat := [0,1,2,3,4]

def tree42439 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42439 : H12WitnessSearch.Good tree42439 := H12GlobalWitnessIndex.good

theorem leafIdentity42439 : H12AffineFastState.composeSystem env42439 rootObs = leafEnv42439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42439 rootObs == leafEnv42439) = true)

theorem terminalChecked42439 : H12PackedTerminal.terminalCheckFast leafEnv42439 active42439 tree42439 = true := by decide +kernel

def env42440 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,48,268,1044,1,263,1028,1572,1024,0,261,33,16,2,268,17,1793,1029,49,1572,1285,33,256,32,1044,513]

theorem envBound42440 : H12AffineFastState.Bounded env42440 := by
  intro p hp
  have h : env42440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42433_42440 : H12AffineEnvironment.transform 10 1793 env42433 = env42440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env42433 == env42440) = true)

theorem identity42440 : scanCanonicalize (H12AffineFastState.compose env42440 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound42440 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42441 : List Nat := [2,4,8,16,32,17,8,256,308,1024,1077,48,268,1044,1,263,1028,1296,1024,0,261,33,16,2,268,17,1077,1029,49,1296,1285,33,256,32,1044,309]

theorem envBound42441 : H12AffineFastState.Bounded env42441 := by
  intro p hp
  have h : env42441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42440_42441 : H12AffineEnvironment.transform 8 308 env42440 = env42441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env42440 == env42441) = true)

def env42442 : List Nat := [2,4,8,16,32,17,8,256,308,52,1,48,268,32,1,263,48,292,52,0,261,33,16,2,268,17,1,49,49,292,305,33,256,32,32,309]

theorem envBound42442 : H12AffineFastState.Bounded env42442 := by
  intro p hp
  have h : env42442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42441_42442 : H12AffineEnvironment.transform 9 52 env42441 = env42442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env42441 == env42442) = true)

theorem identity42442 : scanCanonicalize (H12AffineFastState.compose env42442 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42442 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42443 : List Nat := [2,4,8,16,1,17,8,256,277,21,1,17,268,1,1,263,17,261,21,0,261,0,16,2,268,17,1,16,16,261,272,0,256,1,1,276]

theorem envBound42443 : H12AffineFastState.Bounded env42443 := by
  intro p hp
  have h : env42443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42442_42443 : H12AffineEnvironment.transform 4 1 env42442 = env42443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42442 == env42443) = true)

def leafEnv42443 : List Nat := [2,4,8,16,1,17,8,256,277,21,1,17,268,1,1,263,17,261,21,0,261,0,16,2,272,268,1,17,1,16,16,261,272,0,256,1,4,263,1,276,1,261,0]

def active42443 : List Nat := [0,1,2,3,7]

def tree42443 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42443 : H12WitnessSearch.Good tree42443 := H12GlobalWitnessIndex.good

theorem leafIdentity42443 : H12AffineFastState.composeSystem env42443 rootObs = leafEnv42443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42443 rootObs == leafEnv42443) = true)

theorem terminalChecked42443 : H12PackedTerminal.terminalCheckFast leafEnv42443 active42443 tree42443 = true := by decide +kernel

def env42444 : List Nat := [2,4,8,16,32,17,8,256,308,53,0,48,268,33,1,263,49,293,53,0,261,33,16,2,268,17,0,48,49,293,304,33,256,32,33,309]

theorem envBound42444 : H12AffineFastState.Bounded env42444 := by
  intro p hp
  have h : env42444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42441_42444 : H12AffineEnvironment.transform 9 53 env42441 = env42444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env42441 == env42444) = true)

theorem identity42444 : scanCanonicalize (H12AffineFastState.compose env42444 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound42444 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42445 : List Nat := [2,4,8,11,32,10,8,256,303,46,0,43,268,33,1,263,42,293,46,0,261,33,11,2,268,10,0,43,42,293,299,33,256,32,33,302]

theorem envBound42445 : H12AffineFastState.Bounded env42445 := by
  intro p hp
  have h : env42445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42444_42445 : H12AffineEnvironment.transform 3 11 env42444 = env42445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env42444 == env42445) = true)

def leafEnv42445 : List Nat := [2,4,8,11,32,10,8,256,303,46,0,43,268,33,1,263,42,293,46,0,261,33,11,2,299,268,1,10,0,43,42,293,299,33,256,32,4,263,33,302,1,261,0]

def active42445 : List Nat := [0,1,2,4,7]

def tree42445 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42445 : H12WitnessSearch.Good tree42445 := H12GlobalWitnessIndex.good

theorem leafIdentity42445 : H12AffineFastState.composeSystem env42445 rootObs = leafEnv42445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42445 rootObs == leafEnv42445) = true)

theorem terminalChecked42445 : H12PackedTerminal.terminalCheckFast leafEnv42445 active42445 tree42445 = true := by decide +kernel

def env42446 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41310,8192,64,4677966,115015,45404,442385,75103,4268042,256,98678,90203,513]

theorem envBound42446 : H12AffineFastState.Bounded env42446 := by
  intro p hp
  have h : env42446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42402_42446 : H12AffineEnvironment.transform 20 58397 env42402 = env42446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env42402 == env42446) = true)

def env42447 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41230,8192,16,4677918,114967,45324,442385,75023,4268042,256,98598,90123,513]

theorem envBound42447 : H12AffineFastState.Bounded env42447 := by
  intro p hp
  have h : env42447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42446_42447 : H12AffineEnvironment.transform 5 16 env42446 = env42447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42446 == env42447) = true)

def env42448 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58397,4194304,16,41230,8192,16,4409654,114967,45324,190521,75023,4268042,256,98598,90123,513]

theorem envBound42448 : H12AffineFastState.Bounded env42448 := by
  intro p hp
  have h : env42448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42447_42448 : H12AffineEnvironment.transform 17 10280 env42447 = env42448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env42447 == env42448) = true)

theorem identity42448 : scanCanonicalize (H12AffineFastState.compose env42448 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 118035) := by decide +kernel

theorem selectedBound42448 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env42449 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58397,118035,16,41230,8192,16,164901,114967,45324,190521,75023,60697,256,98598,90123,513]

theorem envBound42449 : H12AffineFastState.Bounded env42449 := by
  intro p hp
  have h : env42449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42448_42449 : H12AffineEnvironment.transform 21 118035 env42448 = env42449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 118035 env42448 == env42449) = true)

theorem identity42449 : scanCanonicalize (H12AffineFastState.compose env42449 (packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound42449 : packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS < 2^1333 := by decide +kernel

def env42450 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,58397,118035,16,41230,8192,16,123966,114967,45324,100386,75023,60697,256,98598,90123,513]

theorem envBound42450 : H12AffineFastState.Bounded env42450 := by
  intro p hp
  have h : env42450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42449_42450 : H12AffineEnvironment.transform 16 90139 env42449 = env42450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env42449 == env42450) = true)

theorem identity42450 : scanCanonicalize (H12AffineFastState.compose env42450 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 292) := by decide +kernel

theorem selectedBound42450 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env42451 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,292,32768,65536,74047,10280,1024,32769,42297,101431,16,41230,8192,16,107802,98355,45324,100386,75023,44093,256,98598,74031,513]

theorem envBound42451 : H12AffineFastState.Bounded env42451 := by
  intro p hp
  have h : env42451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42450_42451 : H12AffineEnvironment.transform 13 292 env42450 = env42451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 292 env42450 == env42451) = true)

theorem identity42451 : scanCanonicalize (H12AffineFastState.compose env42451 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound42451 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env42452 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,292,32768,8202,309,10280,1024,32769,42297,44093,16,41230,8192,16,34064,41017,45324,43048,1285,44093,256,41260,293,513]

theorem envBound42452 : H12AffineFastState.Bounded env42452 := by
  intro p hp
  have h : env42452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42451_42452 : H12AffineEnvironment.transform 15 8202 env42451 = env42452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env42451 == env42452) = true)

theorem identity42452 : scanCanonicalize (H12AffineFastState.compose env42452 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound42452 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42453 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,309,8192,292,32768,8202,309,10280,1024,32769,42297,44093,16,41230,8192,16,34064,41017,41017,43048,1285,44093,256,41260,293,513]

theorem envBound42453 : H12AffineFastState.Bounded env42453 := by
  intro p hp
  have h : env42453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42452_42453 : H12AffineEnvironment.transform 11 309 env42452 = env42453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env42452 == env42453) = true)

theorem identity42453 : scanCanonicalize (H12AffineFastState.compose env42453 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound42453 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env42454 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,309,1052,292,32768,1046,309,3124,1024,32769,33061,34849,16,34066,1052,16,34064,33829,33829,35892,1285,34849,256,34096,293,513]

theorem envBound42454 : H12AffineFastState.Bounded env42454 := by
  intro p hp
  have h : env42454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42453_42454 : H12AffineEnvironment.transform 12 1052 env42453 = env42454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env42453 == env42454) = true)

theorem identity42454 : scanCanonicalize (H12AffineFastState.compose env42454 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 1076) := by decide +kernel

theorem selectedBound42454 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env42455 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,309,1052,292,1076,1046,309,3124,1024,1077,1297,3093,16,294,1052,16,292,17,17,2048,1285,3093,256,260,293,513]

theorem envBound42455 : H12AffineFastState.Bounded env42455 := by
  intro p hp
  have h : env42455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42454_42455 : H12AffineEnvironment.transform 14 1076 env42454 = env42455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1076 env42454 == env42455) = true)

theorem identity42455 : scanCanonicalize (H12AffineFastState.compose env42455 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound42455 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env42456 : List Nat := [2,4,8,16,32,16,8,256,512,1024,17,309,1052,292,1076,1046,309,1061,1024,1077,1297,1028,16,294,1052,16,292,17,17,17,1285,1028,256,260,293,513]

theorem envBound42456 : H12AffineFastState.Bounded env42456 := by
  intro p hp
  have h : env42456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42455_42456 : H12AffineEnvironment.transform 10 17 env42455 = env42456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env42455 == env42456) = true)

theorem identity42456 : scanCanonicalize (H12AffineFastState.compose env42456 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound42456 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42457 : List Nat := [2,4,8,16,32,16,8,256,308,1024,17,309,1052,292,1076,1046,309,1061,1024,1077,1297,1028,16,294,1052,16,292,17,17,17,1285,1028,256,260,293,309]

theorem envBound42457 : H12AffineFastState.Bounded env42457 := by
  intro p hp
  have h : env42457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42456_42457 : H12AffineEnvironment.transform 8 308 env42456 = env42457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env42456 == env42457) = true)

theorem identity42457 : scanCanonicalize (H12AffineFastState.compose env42457 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound42457 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42458 : List Nat := [2,4,8,16,32,16,8,53,1,1024,17,0,1052,17,1076,1046,0,1061,1024,1077,1060,1028,16,19,1052,16,17,17,17,17,1072,1028,53,49,16,0]

theorem envBound42458 : H12AffineFastState.Bounded env42458 := by
  intro p hp
  have h : env42458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42457_42458 : H12AffineEnvironment.transform 7 53 env42457 = env42458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env42457 == env42458) = true)

theorem identity42458 : scanCanonicalize (H12AffineFastState.compose env42458 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound42458 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42459 : List Nat := [2,4,8,16,17,16,8,4,1,1024,17,0,1052,17,1029,1046,0,1044,1024,1028,1045,1028,16,19,1052,16,17,17,17,17,1025,1028,4,0,16,0]

theorem envBound42459 : H12AffineFastState.Bounded env42459 := by
  intro p hp
  have h : env42459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42458_42459 : H12AffineEnvironment.transform 4 17 env42458 = env42459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env42458 == env42459) = true)

theorem identity42459 : scanCanonicalize (H12AffineFastState.compose env42459 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound42459 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42460 : List Nat := [2,4,8,16,17,16,8,4,1,4,17,0,24,17,1,18,0,16,4,0,17,0,16,19,24,16,17,17,17,17,5,0,4,0,16,0]

theorem envBound42460 : H12AffineFastState.Bounded env42460 := by
  intro p hp
  have h : env42460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42459_42460 : H12AffineEnvironment.transform 9 4 env42459 = env42460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env42459 == env42460) = true)

theorem identity42460 : scanCanonicalize (H12AffineFastState.compose env42460 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound42460 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42461 : List Nat := [2,4,8,0,1,0,8,4,1,4,1,0,8,1,1,2,0,0,4,0,1,0,0,3,8,0,1,1,1,1,5,0,4,0,0,0]

theorem envBound42461 : H12AffineFastState.Bounded env42461 := by
  intro p hp
  have h : env42461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42460_42461 : H12AffineEnvironment.transform 3 0 env42460 = env42461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42460 == env42461) = true)

def env42462 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58397,4194304,16,41230,8192,16,4409655,114967,45324,190520,75023,4268042,256,98598,90123,513]

theorem envBound42462 : H12AffineFastState.Bounded env42462 := by
  intro p hp
  have h : env42462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42447_42462 : H12AffineEnvironment.transform 17 10281 env42447 = env42462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env42447 == env42462) = true)

theorem identity42462 : scanCanonicalize (H12AffineFastState.compose env42462 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 246070) := by decide +kernel

theorem selectedBound42462 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env42463 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58397,246070,16,41230,8192,16,34817,114967,45324,190520,75023,188732,256,98598,90123,513]

theorem envBound42463 : H12AffineFastState.Bounded env42463 := by
  intro p hp
  have h : env42463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42462_42463 : H12AffineEnvironment.transform 21 246070 env42462 = env42463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 246070 env42462 == env42463) = true)

theorem identity42463 : scanCanonicalize (H12AffineFastState.compose env42463 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound42463 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env42464 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,0,65536,131072,10281,1024,1,25629,213302,16,8462,8192,16,2049,82199,12556,157752,75023,155964,256,65830,90123,513]

theorem envBound42464 : H12AffineFastState.Bounded env42464 := by
  intro p hp
  have h : env42464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42463_42464 : H12AffineEnvironment.transform 14 0 env42463 = env42464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env42463 == env42464) = true)

theorem identity42464 : scanCanonicalize (H12AffineFastState.compose env42464 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound42464 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env42465 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,0,263,131072,10281,1024,1,25629,147505,16,8462,8192,16,2049,16400,12556,157752,9224,155964,256,33,24844,513]

theorem envBound42465 : H12AffineFastState.Bounded env42465 := by
  intro p hp
  have h : env42465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42464_42465 : H12AffineEnvironment.transform 15 263 env42464 = env42465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env42464 == env42465) = true)

theorem identity42465 : scanCanonicalize (H12AffineFastState.compose env42465 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound42465 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env42466 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,0,263,16401,10281,1024,1,25629,32,16,8462,8192,16,2049,16400,12556,10281,9224,8493,256,33,24844,513]

theorem envBound42466 : H12AffineFastState.Bounded env42466 := by
  intro p hp
  have h : env42466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42465_42466 : H12AffineEnvironment.transform 16 16401 env42465 = env42466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env42465 == env42466) = true)

theorem identity42466 : scanCanonicalize (H12AffineFastState.compose env42466 (packedSelected [1,8,19] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound42466 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env42467 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,0,263,16401,2340,1024,1,17680,32,16,3,269,16,2049,16400,4097,2340,1285,32,256,33,16385,513]

theorem envBound42467 : H12AffineFastState.Bounded env42467 := by
  intro p hp
  have h : env42467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42466_42467 : H12AffineEnvironment.transform 12 269 env42466 = env42467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env42466 == env42467) = true)

theorem identity42467 : scanCanonicalize (H12AffineFastState.compose env42467 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4388) := by decide +kernel

theorem selectedBound42467 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42468 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,4388,0,263,4405,2340,1024,1,5172,32,16,3,269,16,2049,4404,4097,2340,1285,32,256,33,4389,513]

theorem envBound42468 : H12AffineFastState.Bounded env42468 := by
  intro p hp
  have h : env42468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42467_42468 : H12AffineEnvironment.transform 13 4388 env42467 = env42468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4388 env42467 == env42468) = true)

theorem identity42468 : scanCanonicalize (H12AffineFastState.compose env42468 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound42468 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42469 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,513,269,805,0,263,820,2340,1024,1,1589,32,16,3,269,16,2049,821,512,2340,1285,32,256,33,804,513]

theorem envBound42469 : H12AffineFastState.Bounded env42469 := by
  intro p hp
  have h : env42469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42468_42469 : H12AffineEnvironment.transform 11 513 env42468 = env42469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env42468 == env42469) = true)

theorem identity42469 : scanCanonicalize (H12AffineFastState.compose env42469 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 768) := by decide +kernel

theorem selectedBound42469 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42470 : List Nat := [2,4,8,16,32,16,8,256,512,768,2048,513,269,805,0,263,820,2340,768,1,309,32,16,3,269,16,2049,821,512,2340,517,32,256,33,804,513]

theorem envBound42470 : H12AffineFastState.Bounded env42470 := by
  intro p hp
  have h : env42470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42469_42470 : H12AffineEnvironment.transform 9 768 env42469 = env42470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env42469 == env42470) = true)

theorem identity42470 : scanCanonicalize (H12AffineFastState.compose env42470 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound42470 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42471 : List Nat := [2,4,8,16,32,16,8,53,512,565,2048,513,56,528,0,50,513,2065,565,1,0,32,16,3,56,16,2049,512,512,2065,517,32,53,33,529,513]

theorem envBound42471 : H12AffineFastState.Bounded env42471 := by
  intro p hp
  have h : env42471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42470_42471 : H12AffineEnvironment.transform 7 53 env42470 = env42471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env42470 == env42471) = true)

theorem identity42471 : scanCanonicalize (H12AffineFastState.compose env42471 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound42471 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env42472 : List Nat := [2,4,8,16,32,16,8,53,512,565,17,513,56,528,0,50,513,0,565,1,0,32,16,3,56,16,16,512,512,0,517,32,53,33,529,513]

theorem envBound42472 : H12AffineFastState.Bounded env42472 := by
  intro p hp
  have h : env42472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42471_42472 : H12AffineEnvironment.transform 10 17 env42471 = env42472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env42471 == env42472) = true)

theorem identity42472 : scanCanonicalize (H12AffineFastState.compose env42472 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound42472 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42473 : List Nat := [2,4,8,16,0,16,8,21,512,533,17,513,24,528,0,18,513,0,533,1,0,0,16,3,24,16,16,512,512,0,517,0,21,1,529,513]

theorem envBound42473 : H12AffineFastState.Bounded env42473 := by
  intro p hp
  have h : env42473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42472_42473 : H12AffineEnvironment.transform 4 0 env42472 = env42473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42472 == env42473) = true)

theorem identity42473 : scanCanonicalize (H12AffineFastState.compose env42473 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound42473 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42474 : List Nat := [2,4,8,16,0,16,8,21,1,20,17,0,24,17,0,18,0,0,20,1,0,0,16,3,24,16,16,1,1,0,4,0,21,1,16,0]

theorem envBound42474 : H12AffineFastState.Bounded env42474 := by
  intro p hp
  have h : env42474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42473_42474 : H12AffineEnvironment.transform 8 1 env42473 = env42474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env42473 == env42474) = true)

def env42475 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41231,8192,17,4677919,114966,45325,442385,75022,4268042,256,98599,90122,513]

theorem envBound42475 : H12AffineFastState.Bounded env42475 := by
  intro p hp
  have h : env42475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42446_42475 : H12AffineEnvironment.transform 5 17 env42446 = env42475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42446 == env42475) = true)

theorem identity42475 : scanCanonicalize (H12AffineFastState.compose env42475 (packedSelected [1,3,12,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound42475 : packedSelected [1,3,12,24,28,41] rootPS < 2^1333 := by decide +kernel

def env42476 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58397,4194304,16,41231,8192,17,4409654,114966,45325,190520,75022,4268042,256,98599,90122,513]

theorem envBound42476 : H12AffineFastState.Bounded env42476 := by
  intro p hp
  have h : env42476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42475_42476 : H12AffineEnvironment.transform 17 10281 env42475 = env42476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env42475 == env42476) = true)

theorem identity42476 : scanCanonicalize (H12AffineFastState.compose env42476 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound42476 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env42477 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,40971,131072,10281,1024,32769,58397,4194304,16,41231,8192,17,4385085,24861,45325,190520,34053,4227073,256,8492,49153,513]

theorem envBound42477 : H12AffineFastState.Bounded env42477 := by
  intro p hp
  have h : env42477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42476_42477 : H12AffineEnvironment.transform 15 40971 env42476 = env42477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env42476 == env42477) = true)

theorem identity42477 : scanCanonicalize (H12AffineFastState.compose env42477 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 155964) := by decide +kernel

theorem selectedBound42477 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env42478 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,40971,131072,10281,1024,32769,58397,155964,16,41231,8192,17,34817,24861,45325,190520,34053,188733,256,8492,49153,513]

theorem envBound42478 : H12AffineFastState.Bounded env42478 := by
  intro p hp
  have h : env42478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42477_42478 : H12AffineEnvironment.transform 21 155964 env42477 = env42478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 155964 env42477 == env42478) = true)

theorem identity42478 : scanCanonicalize (H12AffineFastState.compose env42478 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound42478 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env42479 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,40971,16401,10281,1024,32769,58397,8493,16,41231,8192,17,34817,24861,45325,43049,34053,41260,256,8492,49153,513]

theorem envBound42479 : H12AffineFastState.Bounded env42479 := by
  intro p hp
  have h : env42479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42478_42479 : H12AffineEnvironment.transform 16 16401 env42478 = env42479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env42478 == env42479) = true)

def env42480 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,17,41310,8192,64,4677967,2172250,2118976,442384,75102,6407191,256,2188650,2196551,512]

theorem envBound42480 : H12AffineFastState.Bounded env42480 := by
  intro p hp
  have h : env42480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42401_42480 : H12AffineEnvironment.transform 22 17 env42401 = env42480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env42401 == env42480) = true)

theorem identity42480 : scanCanonicalize (H12AffineFastState.compose env42480 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 314688) := by decide +kernel

theorem selectedBound42480 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env42481 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,314688,4194304,17,41310,8192,64,4677967,387098,301056,442384,75102,4524375,256,370730,346375,512]

theorem envBound42481 : H12AffineFastState.Bounded env42481 := by
  intro p hp
  have h : env42481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42480_42481 : H12AffineEnvironment.transform 20 314688 env42480 = env42481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 314688 env42480 == env42481) = true)

theorem identity42481 : scanCanonicalize (H12AffineFastState.compose env42481 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound42481 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env42482 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58729,4194304,17,41310,8192,64,4409702,114739,45097,190521,75102,4268414,256,98307,90414,512]

theorem envBound42482 : H12AffineFastState.Bounded env42482 := by
  intro p hp
  have h : env42482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42481_42482 : H12AffineEnvironment.transform 17 10281 env42481 = env42482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env42481 == env42482) = true)

theorem identity42482 : scanCanonicalize (H12AffineFastState.compose env42482 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 246118) := by decide +kernel

theorem selectedBound42482 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env42483 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58729,246118,17,41310,8192,64,34816,114739,45097,190521,75102,188440,256,98307,90414,512]

theorem envBound42483 : H12AffineFastState.Bounded env42483 := by
  intro p hp
  have h : env42483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42482_42483 : H12AffineEnvironment.transform 21 246118 env42482 = env42483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 246118 env42482 == env42483) = true)

theorem identity42483 : scanCanonicalize (H12AffineFastState.compose env42483 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound42483 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env42484 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10281,1024,32769,58729,73770,17,41310,8192,64,34816,114739,45097,2421,75102,340,256,98307,90414,512]

theorem envBound42484 : H12AffineFastState.Bounded env42484 := by
  intro p hp
  have h : env42484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42483_42484 : H12AffineEnvironment.transform 16 57676 env42483 = env42484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env42483 == env42484) = true)

theorem identity42484 : scanCanonicalize (H12AffineFastState.compose env42484 (packedSelected [0,3,5,6,7,10,12,15,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 9276) := by decide +kernel

theorem selectedBound42484 : packedSelected [0,3,5,6,7,10,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env42485 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,9276,32768,65536,34160,10281,1024,32769,33109,73770,17,41310,8192,64,34816,107535,45097,2421,75102,340,256,98307,66834,512]

theorem envBound42485 : H12AffineFastState.Bounded env42485 := by
  intro p hp
  have h : env42485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42484_42485 : H12AffineEnvironment.transform 13 9276 env42484 = env42485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9276 env42484 == env42485) = true)

theorem identity42485 : scanCanonicalize (H12AffineFastState.compose env42485 (packedSelected [0,1,2,6,7,8,11,12,14,15,19] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound42485 : packedSelected [0,1,2,6,7,8,11,12,14,15,19] rootPS < 2^1333 := by decide +kernel

def env42486 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,9276,32768,8574,34160,10281,1024,32769,33109,340,17,41310,8192,64,34816,34161,45097,2421,1056,340,256,41341,9324,512]

theorem envBound42486 : H12AffineFastState.Bounded env42486 := by
  intro p hp
  have h : env42486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42485_42486 : H12AffineEnvironment.transform 15 8574 env42485 = env42486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env42485 == env42486) = true)

theorem identity42486 : scanCanonicalize (H12AffineFastState.compose env42486 (packedSelected [0,1,4,6,7,8,9,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 14361) := by decide +kernel

theorem selectedBound42486 : packedSelected [0,1,4,6,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env42487 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,9276,14361,8574,15721,10281,1024,14360,14668,340,17,6471,8192,64,12313,15720,2096,2421,1056,340,256,6500,9324,512]

theorem envBound42487 : H12AffineFastState.Bounded env42487 := by
  intro p hp
  have h : env42487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42486_42487 : H12AffineEnvironment.transform 14 14361 env42486 = env42487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14361 env42486 == env42487) = true)

theorem identity42487 : scanCanonicalize (H12AffineFastState.compose env42487 (packedSelected [1,2,3,4,5,8,9,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 2168) := by decide +kernel

theorem selectedBound42487 : packedSelected [1,2,3,4,5,8,9,11,14,15] rootPS < 2^1333 := by decide +kernel

def env42488 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,2168,3140,4193,2310,5393,81,1024,4192,4404,340,17,6471,2168,64,6241,5392,2096,2421,1056,340,256,6500,3092,512]

theorem envBound42488 : H12AffineFastState.Bounded env42488 := by
  intro p hp
  have h : env42488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42487_42488 : H12AffineEnvironment.transform 12 2168 env42487 = env42488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2168 env42487 == env42488) = true)

theorem identity42488 : scanCanonicalize (H12AffineFastState.compose env42488 (packedSelected [2,4,9,20] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound42488 : packedSelected [2,4,9,20] rootPS < 2^1333 := by decide +kernel

def env42489 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1297,4096,1385,341,4193,1047,5393,81,1024,4192,4404,340,17,5206,1385,64,5488,5392,1313,1124,1056,340,256,5237,261,512]

theorem envBound42489 : H12AffineFastState.Bounded env42489 := by
  intro p hp
  have h : env42489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42488_42489 : H12AffineEnvironment.transform 10 1297 env42488 = env42489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env42488 == env42489) = true)

theorem identity42489 : scanCanonicalize (H12AffineFastState.compose env42489 (packedSelected [0,2,4,6,7,9,11,14,23] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound42489 : packedSelected [0,2,4,6,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env42490 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1297,1029,1385,341,1124,1047,276,81,1024,1125,1329,340,17,83,1385,64,373,277,1313,1124,1056,340,256,112,261,512]

theorem envBound42490 : H12AffineFastState.Bounded env42490 := by
  intro p hp
  have h : env42490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42489_42490 : H12AffineEnvironment.transform 11 1029 env42489 = env42490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env42489 == env42490) = true)

theorem identity42490 : scanCanonicalize (H12AffineFastState.compose env42490 (packedSelected [1,3,5,6,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound42490 : packedSelected [1,3,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env42491 : List Nat := [2,4,8,16,32,64,8,256,512,101,372,96,268,341,1,114,276,81,101,0,340,340,17,83,268,64,373,277,324,1,69,340,256,112,261,512]

theorem envBound42491 : H12AffineFastState.Bounded env42491 := by
  intro p hp
  have h : env42491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42490_42491 : H12AffineEnvironment.transform 9 101 env42490 = env42491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env42490 == env42491) = true)

theorem identity42491 : scanCanonicalize (H12AffineFastState.compose env42491 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound42491 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42492 : List Nat := [2,4,8,16,0,64,8,256,512,69,340,64,268,341,1,82,276,81,69,0,340,340,17,83,268,64,341,277,324,1,69,340,256,80,261,512]

theorem envBound42492 : H12AffineFastState.Bounded env42492 := by
  intro p hp
  have h : env42492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42491_42492 : H12AffineEnvironment.transform 4 0 env42491 = env42492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42491 == env42492) = true)

theorem identity42492 : scanCanonicalize (H12AffineFastState.compose env42492 (packedSelected [0,2,7] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound42492 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env42493 : List Nat := [2,4,8,16,0,64,8,84,512,69,0,64,88,1,1,82,64,81,69,0,0,0,17,83,88,64,1,65,16,1,69,0,84,80,81,512]

theorem envBound42493 : H12AffineFastState.Bounded env42493 := by
  intro p hp
  have h : env42493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42492_42493 : H12AffineEnvironment.transform 7 84 env42492 = env42493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env42492 == env42493) = true)

theorem identity42493 : scanCanonicalize (H12AffineFastState.compose env42493 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42493 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42494 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,17,9,1,1,3,17,0,20,0,0,0,17,2,9,17,1,16,16,1,20,0,5,1,0,512]

theorem envBound42494 : H12AffineFastState.Bounded env42494 := by
  intro p hp
  have h : env42494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42493_42494 : H12AffineEnvironment.transform 5 17 env42493 = env42494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42493 == env42494) = true)

theorem identity42494 : scanCanonicalize (H12AffineFastState.compose env42494 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound42494 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42495 : List Nat := [2,4,8,16,0,17,8,5,1,20,0,17,9,1,1,3,17,0,20,0,0,0,17,2,9,17,1,16,16,1,20,0,5,1,0,1]

theorem envBound42495 : H12AffineFastState.Bounded env42495 := by
  intro p hp
  have h : env42495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42494_42495 : H12AffineEnvironment.transform 8 1 env42494 = env42495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env42494 == env42495) = true)

theorem identity42495 : scanCanonicalize (H12AffineFastState.compose env42495 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound42495 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42496 : List Nat := [2,4,6,16,0,17,6,5,1,20,0,17,7,1,1,3,17,0,20,0,0,0,17,2,7,17,1,16,16,1,20,0,5,1,0,1]

theorem envBound42496 : H12AffineFastState.Bounded env42496 := by
  intro p hp
  have h : env42496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42495_42496 : H12AffineEnvironment.transform 2 6 env42495 = env42496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env42495 == env42496) = true)

def env42497 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,41310,8193,64,13066590,2172251,10507601,8830977,8463695,6407190,256,10577274,10585174,8389136]

theorem envBound42497 : H12AffineFastState.Bounded env42497 := by
  intro p hp
  have h : env42497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42400_42497 : H12AffineEnvironment.transform 6 9 env42400 = env42497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42400 == env42497) = true)

def env42498 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,41310,8193,64,4677966,2172251,2118977,442385,75103,6407190,256,2188650,2196550,512]

theorem envBound42498 : H12AffineFastState.Bounded env42498 := by
  intro p hp
  have h : env42498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42497_42498 : H12AffineEnvironment.transform 22 16 env42497 = env42498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env42497 == env42498) = true)

theorem identity42498 : scanCanonicalize (H12AffineFastState.compose env42498 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 503131) := by decide +kernel

theorem selectedBound42498 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env42499 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,503131,4194304,16,41310,8193,64,4677966,428032,522266,442385,75103,4614477,256,444465,403741,512]

theorem envBound42499 : H12AffineFastState.Bounded env42499 := by
  intro p hp
  have h : env42499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42498_42499 : H12AffineEnvironment.transform 20 503131 env42498 = env42499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 503131 env42498 == env42499) = true)

theorem identity42499 : scanCanonicalize (H12AffineFastState.compose env42499 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound42499 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env42500 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,1024,8541,461831,4194304,16,2,8193,64,4677966,403804,481606,418125,75103,4614477,256,420205,403741,512]

theorem envBound42500 : H12AffineFastState.Bounded env42500 := by
  intro p hp
  have h : env42500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42499_42500 : H12AffineEnvironment.transform 14 8540 env42499 = env42500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env42499 == env42500) = true)

theorem identity42500 : scanCanonicalize (H12AffineFastState.compose env42500 (packedSelected [0,7,20] rootPS)) = affineNative (2^(21+1) ^^^ 330070) := by decide +kernel

theorem selectedBound42500 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env42501 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,1024,8541,461831,330070,16,2,8193,64,157720,403804,481606,418125,75103,221211,256,420205,403741,512]

theorem envBound42501 : H12AffineFastState.Bounded env42501 := by
  intro p hp
  have h : env42501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42500_42501 : H12AffineEnvironment.transform 21 330070 env42500 = env42501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 330070 env42500 == env42501) = true)

theorem identity42501 : scanCanonicalize (H12AffineFastState.compose env42501 (packedSelected [9,14,22] rootPS)) = affineNative (2^(17+1) ^^^ 67959) := by decide +kernel

theorem selectedBound42501 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env42502 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,67959,1024,8541,132464,33,16,2,8193,64,157720,204843,151601,223290,75103,221211,256,221210,204906,512]

theorem envBound42502 : H12AffineFastState.Bounded env42502 := by
  intro p hp
  have h : env42502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42501_42502 : H12AffineEnvironment.transform 17 67959 env42501 = env42502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67959 env42501 == env42502) = true)

theorem identity42502 : scanCanonicalize (H12AffineFastState.compose env42502 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound42502 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env42503 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16401,67959,1024,8541,17761,33,16,2,8193,64,10249,90170,4128,75819,75103,73738,256,73739,90235,512]

theorem envBound42503 : H12AffineFastState.Bounded env42503 := by
  intro p hp
  have h : env42503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42502_42503 : H12AffineEnvironment.transform 16 16401 env42502 = env42503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env42502 == env42503) = true)

theorem identity42503 : scanCanonicalize (H12AffineFastState.compose env42503 (packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound42503 : packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS < 2^1333 := by decide +kernel

def env42504 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,21590,16401,23841,1024,8541,17761,33,16,2,8193,64,10249,13420,4128,31869,28937,29788,256,29789,13357,512]

theorem envBound42504 : H12AffineFastState.Bounded env42504 := by
  intro p hp
  have h : env42504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42503_42504 : H12AffineEnvironment.transform 15 21590 env42503 = env42504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env42503 == env42504) = true)

theorem identity42504 : scanCanonicalize (H12AffineFastState.compose env42504 (packedSelected [3,5,6,10,12,14,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound42504 : packedSelected [3,5,6,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env42505 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,16384,8312,21590,16401,23557,1024,8313,17477,33,16,2,8193,64,10249,13420,4128,31869,28717,29788,36,29789,13357,512]

theorem envBound42505 : H12AffineFastState.Bounded env42505 := by
  intro p hp
  have h : env42505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42504_42505 : H12AffineEnvironment.transform 7 36 env42504 = env42505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env42504 == env42505) = true)

theorem identity42505 : scanCanonicalize (H12AffineFastState.compose env42505 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound42505 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42506 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,9,16384,113,21590,16401,23557,1024,112,17477,33,16,2,8,64,2048,5221,4128,23668,20516,21589,36,21588,5156,512]

theorem envBound42506 : H12AffineFastState.Bounded env42506 := by
  intro p hp
  have h : env42506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42505_42506 : H12AffineEnvironment.transform 12 9 env42505 = env42506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env42505 == env42506) = true)

theorem identity42506 : scanCanonicalize (H12AffineFastState.compose env42506 (packedSelected [11,12] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound42506 : packedSelected [11,12] rootPS < 2^1333 := by decide +kernel

def env42507 : List Nat := [2,4,8,16,32,64,9,36,512,100,2048,4096,9,16384,113,20530,16401,22625,100,112,16417,33,16,2,8,64,2048,4097,4128,22544,20516,20529,36,20528,4160,512]

theorem envBound42507 : H12AffineFastState.Bounded env42507 := by
  intro p hp
  have h : env42507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42506_42507 : H12AffineEnvironment.transform 9 100 env42506 = env42507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env42506 == env42507) = true)

theorem identity42507 : scanCanonicalize (H12AffineFastState.compose env42507 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4160) := by decide +kernel

theorem selectedBound42507 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env42508 : List Nat := [2,4,8,16,32,64,9,36,512,100,2048,4096,9,4160,113,114,4177,2081,100,112,4193,33,16,2,8,64,2048,4097,4128,2128,100,113,36,112,4160,512]

theorem envBound42508 : H12AffineFastState.Bounded env42508 := by
  intro p hp
  have h : env42508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42507_42508 : H12AffineEnvironment.transform 13 4160 env42507 = env42508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4160 env42507 == env42508) = true)

theorem identity42508 : scanCanonicalize (H12AffineFastState.compose env42508 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound42508 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env42509 : List Nat := [2,4,8,16,32,64,9,36,512,100,2048,2065,9,2129,113,114,2112,2081,100,112,2160,33,16,2,8,64,2048,2064,2097,2128,100,113,36,112,2129,512]

theorem envBound42509 : H12AffineFastState.Bounded env42509 := by
  intro p hp
  have h : env42509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42508_42509 : H12AffineEnvironment.transform 11 2065 env42508 = env42509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env42508 == env42509) = true)

theorem identity42509 : scanCanonicalize (H12AffineFastState.compose env42509 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound42509 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env42510 : List Nat := [2,4,8,16,32,64,9,36,512,100,33,48,9,112,113,114,97,0,100,112,81,33,16,2,8,64,33,49,16,113,100,113,36,112,112,512]

theorem envBound42510 : H12AffineFastState.Bounded env42510 := by
  intro p hp
  have h : env42510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42509_42510 : H12AffineEnvironment.transform 10 33 env42509 = env42510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env42509 == env42510) = true)

theorem identity42510 : scanCanonicalize (H12AffineFastState.compose env42510 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound42510 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42511 : List Nat := [2,4,8,16,0,64,9,4,512,68,1,16,9,80,81,82,65,0,68,80,81,1,16,2,8,64,1,17,16,81,68,81,4,80,80,512]

theorem envBound42511 : H12AffineFastState.Bounded env42511 := by
  intro p hp
  have h : env42511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42510_42511 : H12AffineEnvironment.transform 4 0 env42510 = env42511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42510 == env42511) = true)

theorem identity42511 : scanCanonicalize (H12AffineFastState.compose env42511 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42511 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42512 : List Nat := [2,4,8,16,0,16,9,4,512,20,1,16,9,0,1,2,17,0,20,0,1,1,16,2,8,16,1,17,16,1,20,1,4,0,0,512]

theorem envBound42512 : H12AffineFastState.Bounded env42512 := by
  intro p hp
  have h : env42512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42511_42512 : H12AffineEnvironment.transform 5 16 env42511 = env42512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42511 == env42512) = true)

def env42513 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,17,41310,8193,64,4677967,2172251,2118976,442384,75102,6407190,256,2188651,2196551,513]

theorem envBound42513 : H12AffineFastState.Bounded env42513 := by
  intro p hp
  have h : env42513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42497_42513 : H12AffineEnvironment.transform 22 17 env42497 = env42513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env42497 == env42513) = true)

theorem identity42513 : scanCanonicalize (H12AffineFastState.compose env42513 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound42513 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env42514 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1024,32769,2097152,4194304,17,41310,8193,64,4456788,2172251,2118976,368651,75102,6407190,256,2188651,2196551,513]

theorem envBound42514 : H12AffineFastState.Bounded env42514 := by
  intro p hp
  have h : env42514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42513_42514 : H12AffineEnvironment.transform 16 90139 env42513 = env42514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env42513 == env42514) = true)

theorem identity42514 : scanCanonicalize (H12AffineFastState.compose env42514 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29005) := by decide +kernel

theorem selectedBound42514 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env42515 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,65536,90139,262144,1024,29004,2097152,4194304,17,20499,8193,64,4456788,2172251,2118976,348486,75102,6370651,256,2188651,2192650,513]

theorem envBound42515 : H12AffineFastState.Bounded env42515 := by
  intro p hp
  have h : env42515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42514_42515 : H12AffineEnvironment.transform 14 29005 env42514 = env42515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29005 env42514 == env42515) = true)

theorem identity42515 : scanCanonicalize (H12AffineFastState.compose env42515 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 30777) := by decide +kernel

theorem selectedBound42515 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env42516 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,65536,90139,30777,1024,29004,2097152,4194304,17,20499,8193,64,4225389,2172251,2118976,76159,75102,6370651,256,2188651,2192650,513]

theorem envBound42516 : H12AffineFastState.Bounded env42516 := by
  intro p hp
  have h : env42516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42515_42516 : H12AffineEnvironment.transform 17 30777 env42515 = env42516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 30777 env42515 == env42516) = true)

def env42517 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,65536,90139,30777,1024,29004,5456,4194304,17,20499,8193,64,4225389,77835,16400,76159,75102,4268043,256,94267,90202,513]

theorem envBound42517 : H12AffineFastState.Bounded env42517 := by
  intro p hp
  have h : env42517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42516_42517 : H12AffineEnvironment.transform 20 5456 env42516 = env42517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5456 env42516 == env42517) = true)

theorem identity42517 : scanCanonicalize (H12AffineFastState.compose env42517 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound42517 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42518 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,65536,90139,30777,1024,29004,5456,32,17,20499,8193,64,31053,77835,16400,76159,75102,73771,256,94267,90202,513]

theorem envBound42518 : H12AffineFastState.Bounded env42518 := by
  intro p hp
  have h : env42518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42517_42518 : H12AffineEnvironment.transform 21 32 env42517 = env42518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env42517 == env42518) = true)

theorem identity42518 : scanCanonicalize (H12AffineFastState.compose env42518 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound42518 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42519 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,8540,65536,77834,10280,1024,8541,5456,32,17,2,8193,64,10588,77835,4097,76159,75102,73771,256,73770,77899,513]

theorem envBound42519 : H12AffineFastState.Bounded env42519 := by
  intro p hp
  have h : env42519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42518_42519 : H12AffineEnvironment.transform 13 4113 env42518 = env42519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env42518 == env42519) = true)

theorem identity42519 : scanCanonicalize (H12AffineFastState.compose env42519 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 7465) := by decide +kernel

theorem selectedBound42519 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env42520 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7465,4113,7285,65536,68899,5377,1024,7284,5456,32,17,2,7464,64,5237,68898,4097,70742,71799,72962,256,72963,68962,513]

theorem envBound42520 : H12AffineFastState.Bounded env42520 := by
  intro p hp
  have h : env42520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42519_42520 : H12AffineEnvironment.transform 12 7465 env42519 = env42520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7465 env42519 == env42520) = true)

theorem identity42520 : scanCanonicalize (H12AffineFastState.compose env42520 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound42520 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env42521 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3108,269,3125,81,65536,68899,2341,1024,80,2420,32,17,2,268,64,2129,68898,3109,67698,66643,65830,256,65831,68962,513]

theorem envBound42521 : H12AffineFastState.Bounded env42521 := by
  intro p hp
  have h : env42521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42520_42521 : H12AffineEnvironment.transform 11 3108 env42520 = env42521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env42520 == env42521) = true)

theorem identity42521 : scanCanonicalize (H12AffineFastState.compose env42521 (packedSelected [4,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound42521 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env42522 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,2112,269,2129,81,65536,67911,2341,100,80,2420,32,17,2,268,64,2129,67910,2113,67698,65591,65830,256,65831,67846,513]

theorem envBound42522 : H12AffineFastState.Bounded env42522 := by
  intro p hp
  have h : env42522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42521_42522 : H12AffineEnvironment.transform 9 100 env42521 = env42522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env42521 == env42522) = true)

theorem identity42522 : scanCanonicalize (H12AffineFastState.compose env42522 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound42522 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env42523 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,2112,269,2129,81,343,2064,2341,100,80,2420,32,17,2,268,64,2129,2065,2113,2341,352,113,256,112,2129,513]

theorem envBound42523 : H12AffineFastState.Bounded env42523 := by
  intro p hp
  have h : env42523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42522_42523 : H12AffineEnvironment.transform 15 343 env42522 = env42523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env42522 == env42523) = true)

def env42524 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,65536,90139,30777,1024,29004,5457,4194304,17,20499,8193,64,4225389,77834,16401,76159,75102,4268042,256,94266,90203,513]

theorem envBound42524 : H12AffineFastState.Bounded env42524 := by
  intro p hp
  have h : env42524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42516_42524 : H12AffineEnvironment.transform 20 5457 env42516 = env42524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5457 env42516 == env42524) = true)

theorem identity42524 : scanCanonicalize (H12AffineFastState.compose env42524 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 20529) := by decide +kernel

theorem selectedBound42524 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42525 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,65536,90139,30777,1024,29004,5457,20529,17,20499,8193,64,10588,77834,16401,76159,75102,94267,256,94266,90203,513]

theorem envBound42525 : H12AffineFastState.Bounded env42525 := by
  intro p hp
  have h : env42525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42524_42525 : H12AffineEnvironment.transform 21 20529 env42524 = env42525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 20529 env42524 == env42525) = true)

theorem identity42525 : scanCanonicalize (H12AffineFastState.compose env42525 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound42525 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42526 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,8202,16401,30777,1024,29004,5457,20529,17,20499,8193,64,10588,4096,16401,2421,1364,20529,256,20528,16465,513]

theorem envBound42526 : H12AffineFastState.Bounded env42526 := by
  intro p hp
  have h : env42526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42525_42526 : H12AffineEnvironment.transform 15 8202 env42525 = env42526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env42525 == env42526) = true)

theorem identity42526 : scanCanonicalize (H12AffineFastState.compose env42526 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 12572) := by decide +kernel

theorem selectedBound42526 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env42527 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12572,81,8202,12557,2341,1024,80,5457,8493,17,8463,8193,64,10588,4096,12557,2421,1364,8493,256,8492,12621,513]

theorem envBound42527 : H12AffineFastState.Bounded env42527 := by
  intro p hp
  have h : env42527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42526_42527 : H12AffineEnvironment.transform 13 12572 env42526 = env42527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12572 env42526 == env42527) = true)

theorem identity42527 : scanCanonicalize (H12AffineFastState.compose env42527 (packedSelected [1,2,5,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42527 : packedSelected [1,2,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env42528 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,12572,0,8202,12557,2341,1024,1,5376,8493,17,8463,8193,17,10509,4096,12557,2340,1285,8493,256,8492,12572,513]

theorem envBound42528 : H12AffineFastState.Bounded env42528 := by
  intro p hp
  have h : env42528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42527_42528 : H12AffineEnvironment.transform 5 17 env42527 = env42528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42527 == env42528) = true)

theorem identity42528 : scanCanonicalize (H12AffineFastState.compose env42528 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound42528 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42529 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2065,8192,10509,0,8202,10524,2341,1024,1,3345,8493,17,8463,8193,17,10509,2065,10524,2340,1285,8493,256,8492,10509,513]

theorem envBound42529 : H12AffineFastState.Bounded env42529 := by
  intro p hp
  have h : env42529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42528_42529 : H12AffineEnvironment.transform 11 2065 env42528 = env42529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env42528 == env42529) = true)

theorem identity42529 : scanCanonicalize (H12AffineFastState.compose env42529 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound42529 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42530 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2065,268,2049,0,262,2064,2341,1024,1,3345,33,17,3,269,17,2049,2065,2064,2340,1285,33,256,32,2049,513]

theorem envBound42530 : H12AffineFastState.Bounded env42530 := by
  intro p hp
  have h : env42530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42529_42530 : H12AffineEnvironment.transform 12 268 env42529 = env42530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env42529 == env42530) = true)

theorem identity42530 : scanCanonicalize (H12AffineFastState.compose env42530 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound42530 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42531 : List Nat := [2,4,8,16,32,17,9,256,512,1024,292,309,268,293,0,262,308,1,1024,1,1077,33,17,3,269,17,293,309,308,0,1285,33,256,32,293,513]

theorem envBound42531 : H12AffineFastState.Bounded env42531 := by
  intro p hp
  have h : env42531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42530_42531 : H12AffineEnvironment.transform 10 292 env42530 = env42531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env42530 == env42531) = true)

def env42532 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830976,25265169,23160257,257,27378860,27337992,25207750]

theorem envBound42532 : H12AffineFastState.Bounded env42532 := by
  intro p hp
  have h : env42532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42398_42532 : H12AffineEnvironment.transform 18 1025 env42398 = env42532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env42398 == env42532) = true)

theorem identity42532 : scanCanonicalize (H12AffineFastState.compose env42532 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 213471) := by decide +kernel

theorem selectedBound42532 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env42533 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,213471,16777216,8328,64,21266910,18973837,2299022,360927,16958926,23160257,257,19039603,19031255,17031705]

theorem envBound42533 : H12AffineFastState.Bounded env42533 := by
  intro p hp
  have h : env42533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42532_42533 : H12AffineEnvironment.transform 22 213471 env42532 = env42533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 213471 env42532 == env42533) = true)

def env42534 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,411972,213471,16777216,8328,64,16959642,18973837,2299022,360927,16958926,19344517,257,19039603,19031255,17031705]

theorem envBound42534 : H12AffineFastState.Bounded env42534 := by
  intro p hp
  have h : env42534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42533_42534 : H12AffineEnvironment.transform 21 411972 env42533 = env42534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 411972 env42533 == env42534) = true)

def env42535 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,411972,213471,16777216,8328,64,16959642,16974301,102878,360927,16958926,17148373,257,16777251,16834951,17031705]

theorem envBound42535 : H12AffineFastState.Bounded env42535 := by
  intro p hp
  have h : env42535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42534_42535 : H12AffineEnvironment.transform 20 165200 env42534 = env42535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165200 env42534 == env42535) = true)

theorem identity42535 : scanCanonicalize (H12AffineFastState.compose env42535 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188870) := by decide +kernel

theorem selectedBound42535 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env42536 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,411972,213471,188870,8328,64,10588,122907,102878,360927,9224,477203,257,188901,131137,66527]

theorem envBound42536 : H12AffineFastState.Bounded env42536 := by
  intro p hp
  have h : env42536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42535_42536 : H12AffineEnvironment.transform 23 188870 env42535 = env42536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188870 env42535 == env42536) = true)

def env42537 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4160,318548,120015,29910,8328,64,10588,122907,102878,360927,9224,384259,257,29941,38225,66527]

theorem envBound42537 : H12AffineFastState.Bounded env42537 := by
  intro p hp
  have h : env42537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42536_42537 : H12AffineEnvironment.transform 16 38160 env42536 = env42537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env42536 == env42537) = true)

theorem identity42537 : scanCanonicalize (H12AffineFastState.compose env42537 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound42537 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42538 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62731,38160,262144,1025,32769,4160,318548,8644,29910,8328,64,10588,5392,25813,292052,9224,272392,257,29941,38225,63188]

theorem envBound42538 : H12AffineFastState.Bounded env42538 := by
  intro p hp
  have h : env42538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42537_42538 : H12AffineEnvironment.transform 15 62731 env42537 = env42538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env42537 == env42538) = true)

def env42539 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62731,38160,262144,1025,32769,4160,318548,8524,29790,8192,64,10588,5392,25693,291932,9224,272392,257,29821,38225,63068]

theorem envBound42539 : H12AffineFastState.Bounded env42539 := by
  intro p hp
  have h : env42539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42538_42539 : H12AffineEnvironment.transform 6 8 env42538 = env42539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42538 == env42539) = true)

theorem identity42539 : scanCanonicalize (H12AffineFastState.compose env42539 (packedSelected [1,10,14,19,28,35] rootPS)) = affineNative (2^(17+1) ^^^ 35109) := by decide +kernel

theorem selectedBound42539 : packedSelected [1,10,14,19,28,35] rootPS < 2^1333 := by decide +kernel

def env42540 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62731,38160,35109,1025,32769,4160,21873,8524,29790,8192,64,10588,5392,25693,64889,9224,41261,257,29821,38225,63068]

theorem envBound42540 : H12AffineFastState.Bounded env42540 := by
  intro p hp
  have h : env42540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42539_42540 : H12AffineEnvironment.transform 17 35109 env42539 = env42540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35109 env42539 == env42540) = true)

theorem identity42540 : scanCanonicalize (H12AffineFastState.compose env42540 (packedSelected [4,5,9,12,14,15,17,18,19,20,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound42540 : packedSelected [4,5,9,12,14,15,17,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env42541 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5157,32768,41262,38160,35109,1025,32769,4160,340,8524,8315,8192,64,10588,5392,12408,43356,9224,41261,257,8280,38225,41593]

theorem envBound42541 : H12AffineFastState.Bounded env42541 := by
  intro p hp
  have h : env42541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42540_42541 : H12AffineEnvironment.transform 13 5157 env42540 = env42541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env42540 == env42541) = true)

theorem identity42541 : scanCanonicalize (H12AffineFastState.compose env42541 (packedSelected [0,2,4,6,7,9,11,14,17,23] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound42541 : packedSelected [0,2,4,6,7,9,11,14,17,23] rootPS < 2^1333 := by decide +kernel

def env42542 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5157,32768,41051,37989,34896,1025,32769,4160,33,8249,8315,8192,64,10281,5221,12408,43049,9224,41048,116,8280,37924,41593]

theorem envBound42542 : H12AffineFastState.Bounded env42542 := by
  intro p hp
  have h : env42542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42541_42542 : H12AffineEnvironment.transform 7 117 env42541 = env42542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env42541 == env42542) = true)

theorem identity42542 : scanCanonicalize (H12AffineFastState.compose env42542 (packedSelected [0,1,3,5,7,8,11,12,14,17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42542 : packedSelected [0,1,3,5,7,8,11,12,14,17] rootPS < 2^1333 := by decide +kernel

def env42543 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,5157,32768,40970,37940,34817,1025,32769,4113,33,8249,8234,8192,17,10281,5172,12329,43049,9224,40969,37,8201,37924,41512]

theorem envBound42543 : H12AffineFastState.Bounded env42543 := by
  intro p hp
  have h : env42543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42542_42543 : H12AffineEnvironment.transform 5 17 env42542 = env42543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42542 == env42543) = true)

theorem identity42543 : scanCanonicalize (H12AffineFastState.compose env42543 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound42543 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env42544 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,5157,8232,34,13340,10281,1025,8233,4113,33,8249,8234,8192,17,10281,5172,12329,2049,9224,33,37,8201,13324,512]

theorem envBound42544 : H12AffineFastState.Bounded env42544 := by
  intro p hp
  have h : env42544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42543_42544 : H12AffineEnvironment.transform 14 8232 env42543 = env42544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env42543 == env42544) = true)

theorem identity42544 : scanCanonicalize (H12AffineFastState.compose env42544 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3598) := by decide +kernel

theorem selectedBound42544 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42545 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,3598,8192,2603,8232,34,10770,10281,1025,8233,3615,33,8249,8234,8192,17,10281,2618,11815,2049,9224,33,37,8201,10754,512]

theorem envBound42545 : H12AffineFastState.Bounded env42545 := by
  intro p hp
  have h : env42545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42544_42545 : H12AffineEnvironment.transform 11 3598 env42544 = env42545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3598 env42544 == env42545) = true)

theorem identity42545 : scanCanonicalize (H12AffineFastState.compose env42545 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound42545 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42546 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,3598,9,2603,33,34,2587,2080,1025,32,3615,33,48,35,9,17,2080,2618,3630,2049,1025,33,37,0,2571,512]

theorem envBound42546 : H12AffineFastState.Bounded env42546 := by
  intro p hp
  have h : env42546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42545_42546 : H12AffineEnvironment.transform 12 9 env42545 = env42546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env42545 == env42546) = true)

theorem identity42546 : scanCanonicalize (H12AffineFastState.compose env42546 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound42546 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env42547 : List Nat := [2,4,8,16,0,17,8,4,512,1024,2048,3598,9,2571,1,2,2587,2048,1025,0,3615,1,16,3,9,17,2048,2586,3598,2049,1025,1,5,0,2571,512]

theorem envBound42547 : H12AffineFastState.Bounded env42547 := by
  intro p hp
  have h : env42547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42546_42547 : H12AffineEnvironment.transform 4 0 env42546 = env42547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42546 == env42547) = true)

theorem identity42547 : scanCanonicalize (H12AffineFastState.compose env42547 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound42547 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42548 : List Nat := [2,4,8,16,0,17,8,4,512,1024,523,1029,9,0,1,2,16,523,1025,0,1044,1,16,3,9,17,523,17,1029,522,1025,1,5,0,0,512]

theorem envBound42548 : H12AffineFastState.Bounded env42548 := by
  intro p hp
  have h : env42548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42547_42548 : H12AffineEnvironment.transform 10 523 env42547 = env42548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env42547 == env42548) = true)

theorem identity42548 : scanCanonicalize (H12AffineFastState.compose env42548 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 17) := by decide +kernel

theorem selectedBound42548 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42549 : List Nat := [2,4,8,16,0,17,8,4,512,17,523,20,9,0,1,2,16,523,16,0,5,1,16,3,9,17,523,17,20,522,16,1,5,0,0,512]

theorem envBound42549 : H12AffineFastState.Bounded env42549 := by
  intro p hp
  have h : env42549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42548_42549 : H12AffineEnvironment.transform 9 17 env42548 = env42549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 17 env42548 == env42549) = true)

theorem identity42549 : scanCanonicalize (H12AffineFastState.compose env42549 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound42549 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env42550 : List Nat := [2,1,8,16,0,17,8,1,512,17,523,17,9,0,1,2,16,523,16,0,0,1,16,3,9,17,523,17,17,522,16,1,0,0,0,512]

theorem envBound42550 : H12AffineFastState.Bounded env42550 := by
  intro p hp
  have h : env42550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42549_42550 : H12AffineEnvironment.transform 1 1 env42549 = env42550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env42549 == env42550) = true)

theorem identity42550 : scanCanonicalize (H12AffineFastState.compose env42550 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 19) := by decide +kernel

theorem selectedBound42550 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42551 : List Nat := [2,1,8,16,0,17,8,1,19,17,24,17,9,0,1,2,16,24,16,0,0,1,16,3,9,17,24,17,17,25,16,1,0,0,0,19]

theorem envBound42551 : H12AffineFastState.Bounded env42551 := by
  intro p hp
  have h : env42551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42550_42551 : H12AffineEnvironment.transform 8 19 env42550 = env42551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 19 env42550 == env42551) = true)

def env42552 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,38160,262144,1025,32769,4160,318548,8525,29791,8193,64,10588,5392,25692,291933,9224,272392,257,29820,38225,63069]

theorem envBound42552 : H12AffineFastState.Bounded env42552 := by
  intro p hp
  have h : env42552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42538_42552 : H12AffineEnvironment.transform 6 9 env42538 = env42552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42538 == env42552) = true)

theorem identity42552 : scanCanonicalize (H12AffineFastState.compose env42552 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound42552 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env42553 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,343,24908,262144,1025,29789,4160,272392,8525,29791,8193,64,10588,5392,25692,291933,9224,272392,257,29820,24845,513]

theorem envBound42553 : H12AffineFastState.Bounded env42553 := by
  intro p hp
  have h : env42553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42552_42553 : H12AffineEnvironment.transform 14 29788 env42552 = env42553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env42552 == env42553) = true)

theorem identity42553 : scanCanonicalize (H12AffineFastState.compose env42553 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound42553 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env42554 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,343,24908,32040,1025,29789,4160,21792,8525,29791,8193,64,10588,5392,25692,2421,9224,21792,257,29820,24845,513]

theorem envBound42554 : H12AffineFastState.Bounded env42554 := by
  intro p hp
  have h : env42554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42553_42554 : H12AffineEnvironment.transform 17 32040 env42553 = env42554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env42553 == env42554) = true)

theorem identity42554 : scanCanonicalize (H12AffineFastState.compose env42554 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound42554 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env42555 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,343,13388,10280,1025,8541,4160,32,8525,8543,8193,64,10588,5392,12636,2421,9224,32,257,8572,13325,513]

theorem envBound42555 : H12AffineFastState.Bounded env42555 := by
  intro p hp
  have h : env42555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42554_42555 : H12AffineEnvironment.transform 13 5376 env42554 = env42555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env42554 == env42555) = true)

theorem identity42555 : scanCanonicalize (H12AffineFastState.compose env42555 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound42555 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42556 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,5376,1297,343,4097,3173,1025,1296,4160,32,1280,1298,1100,64,3345,5392,5393,2421,69,32,257,1329,4160,513]

theorem envBound42556 : H12AffineFastState.Bounded env42556 := by
  intro p hp
  have h : env42556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42555_42556 : H12AffineEnvironment.transform 12 1101 env42555 = env42556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env42555 == env42556) = true)

theorem identity42556 : scanCanonicalize (H12AffineFastState.compose env42556 (packedSelected [1,3,4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound42556 : packedSelected [1,3,4,9,11] rootPS < 2^1333 := by decide +kernel

def env42557 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3108,1101,2340,1297,343,3109,3173,1025,1296,3172,32,1280,1298,1100,64,3345,2356,2357,2421,69,32,257,1329,3172,513]

theorem envBound42557 : H12AffineFastState.Bounded env42557 := by
  intro p hp
  have h : env42557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42556_42557 : H12AffineEnvironment.transform 11 3108 env42556 = env42557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env42556 == env42557) = true)

theorem identity42557 : scanCanonicalize (H12AffineFastState.compose env42557 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound42557 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env42558 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1076,16,1101,1296,1297,343,17,81,1025,1296,80,32,1280,1298,1100,64,293,1280,1281,1345,69,32,257,1329,80,513]

theorem envBound42558 : H12AffineFastState.Bounded env42558 := by
  intro p hp
  have h : env42558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42557_42558 : H12AffineEnvironment.transform 10 1076 env42557 = env42558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env42557 == env42558) = true)

theorem identity42558 : scanCanonicalize (H12AffineFastState.compose env42558 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42558 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env42559 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1076,16,1052,1296,1297,262,17,0,1025,1296,1,32,1280,1298,1053,17,293,1280,1281,1296,20,32,257,1329,1,513]

theorem envBound42559 : H12AffineFastState.Bounded env42559 := by
  intro p hp
  have h : env42559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42558_42559 : H12AffineEnvironment.transform 5 17 env42558 = env42559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42558 == env42559) = true)

theorem identity42559 : scanCanonicalize (H12AffineFastState.compose env42559 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound42559 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42560 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1076,16,1052,1077,1076,35,17,0,1025,1077,1,32,1061,1079,1053,17,0,1061,1060,1077,20,32,36,1044,1,513]

theorem envBound42560 : H12AffineFastState.Bounded env42560 := by
  intro p hp
  have h : env42560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42559_42560 : H12AffineEnvironment.transform 7 37 env42559 = env42560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env42559 == env42560) = true)

theorem identity42560 : scanCanonicalize (H12AffineFastState.compose env42560 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound42560 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env42561 : List Nat := [2,4,8,16,32,17,9,37,33,1024,1076,16,1052,1077,1076,35,17,0,1025,1077,1,32,1061,1079,1053,17,0,1061,1060,1077,20,32,36,1044,1,32]

theorem envBound42561 : H12AffineFastState.Bounded env42561 := by
  intro p hp
  have h : env42561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42560_42561 : H12AffineEnvironment.transform 8 33 env42560 = env42561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env42560 == env42561) = true)

def env42562 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4161,318549,120014,29911,8328,64,10588,122907,102878,360927,9224,384258,257,29940,38224,66527]

theorem envBound42562 : H12AffineFastState.Bounded env42562 := by
  intro p hp
  have h : env42562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42536_42562 : H12AffineEnvironment.transform 16 38161 env42536 = env42562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env42536 == env42562) = true)

theorem identity42562 : scanCanonicalize (H12AffineFastState.compose env42562 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound42562 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42563 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,25029,262144,1025,29909,4161,272513,73754,29911,8328,64,10588,70863,91402,357643,9224,338390,257,29940,24964,66527]

theorem envBound42563 : H12AffineFastState.Bounded env42563 := by
  intro p hp
  have h : env42563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42562_42563 : H12AffineEnvironment.transform 14 29908 env42562 = env42563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env42562 == env42563) = true)

def env42564 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,24981,262144,1025,29829,4113,272513,73754,29831,8328,16,10508,70815,91402,357643,9224,338310,257,29860,24964,66447]

theorem envBound42564 : H12AffineFastState.Bounded env42564 := by
  intro p hp
  have h : env42564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42563_42564 : H12AffineEnvironment.transform 5 16 env42563 = env42564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42563 == env42564) = true)

theorem identity42564 : scanCanonicalize (H12AffineFastState.compose env42564 (packedSelected [0,1,3,5,8,9,10,12,15,17,19,22,27,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound42564 : packedSelected [0,1,3,5,8,9,10,12,15,17,19,22,27,38,41] rootPS < 2^1333 := by decide +kernel

def env42565 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,65536,24860,262144,1025,29708,4113,272392,73754,29710,8193,16,10508,70678,91402,357643,9224,338191,257,29741,24845,66310]

theorem envBound42565 : H12AffineFastState.Bounded env42565 := by
  intro p hp
  have h : env42565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42564_42565 : H12AffineEnvironment.transform 6 9 env42564 = env42565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42564 == env42565) = true)

theorem identity42565 : scanCanonicalize (H12AffineFastState.compose env42565 (packedSelected [3,10,16,19,20,24] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound42565 : packedSelected [3,10,16,19,20,24] rootPS < 2^1333 := by decide +kernel

def env42566 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,65536,24860,10280,1025,29708,4113,32,73754,29710,8193,16,10508,70678,91402,89379,9224,65831,257,29741,24845,66310]

theorem envBound42566 : H12AffineFastState.Bounded env42566 := by
  intro p hp
  have h : env42566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42565_42566 : H12AffineEnvironment.transform 17 10280 env42565 = env42566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env42565 == env42566) = true)

theorem identity42566 : scanCanonicalize (H12AffineFastState.compose env42566 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound42566 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42567 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,1052,16384,20497,65536,17664,3124,1025,20496,4113,32,66566,20498,1053,16,3344,70678,82198,89379,20,65831,257,20529,17681,66310]

end H12CloudChart0