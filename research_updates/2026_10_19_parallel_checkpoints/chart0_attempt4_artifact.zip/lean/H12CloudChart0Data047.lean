import H12CloudChart0Data046

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans11759_11760 : H12AffineEnvironment.transform 17 67755 env11759 = env11760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67755 env11759 == env11760) = true)

theorem identity11760 : scanCanonicalize (H12AffineFastState.compose env11760 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 2185) := by decide +kernel

theorem selectedBound11760 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env11761 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,2185,7560,65536,2201,67755,1025,7561,4112,65966,65950,7563,268,16,2184,70814,68615,5292,1420,169,257,7592,2185,66447]

theorem envBound11761 : H12AffineFastState.Bounded env11761 := by
  intro p hp
  have h : env11761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11760_11761 : H12AffineEnvironment.transform 13 2185 env11760 = env11761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2185 env11760 == env11761) = true)

theorem identity11761 : scanCanonicalize (H12AffineFastState.compose env11761 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound11761 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env11762 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,2185,7560,1331,2201,3480,1025,7561,4112,1181,1197,7563,268,16,2184,4525,2356,5292,1420,169,257,7592,2185,1724]

theorem envBound11762 : H12AffineFastState.Bounded env11762 := by
  intro p hp
  have h : env11762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11761_11762 : H12AffineEnvironment.transform 15 1331 env11761 = env11762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env11761 == env11762) = true)

theorem identity11762 : scanCanonicalize (H12AffineFastState.compose env11762 (packedSelected [1,5,6,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1197) := by decide +kernel

theorem selectedBound11762 : packedSelected [1,5,6,10,12] rootPS < 2^1333 := by decide +kernel

def env11763 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1197,388,2185,2341,1331,2201,3480,1025,2340,1213,1181,1197,2342,268,16,2184,1280,2356,1,1420,169,257,2309,2185,1724]

theorem envBound11763 : H12AffineFastState.Bounded env11763 := by
  intro p hp
  have h : env11763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11762_11763 : H12AffineEnvironment.transform 11 1197 env11762 = env11763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1197 env11762 == env11763) = true)

theorem identity11763 : scanCanonicalize (H12AffineFastState.compose env11763 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound11763 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env11764 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1077,1197,388,1212,1296,1331,1196,429,1025,1297,1213,1181,1197,1299,268,16,1213,1280,1281,1,1420,169,257,1328,1212,1724]

theorem envBound11764 : H12AffineFastState.Bounded env11764 := by
  intro p hp
  have h : env11764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11763_11764 : H12AffineEnvironment.transform 10 1077 env11763 = env11764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env11763 == env11764) = true)

theorem identity11764 : scanCanonicalize (H12AffineFastState.compose env11764 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11764 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env11765 : List Nat := [2,4,8,16,32,16,128,36,512,1024,1077,1197,160,1212,1076,1047,1196,137,1025,1077,1213,1181,1197,1079,40,16,1213,1060,1061,1,1192,169,37,1044,1212,1724]

theorem envBound11765 : H12AffineFastState.Bounded env11765 := by
  intro p hp
  have h : env11765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11764_11765 : H12AffineEnvironment.transform 7 36 env11764 = env11765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11764 == env11765) = true)

theorem identity11765 : scanCanonicalize (H12AffineFastState.compose env11765 (packedSelected [1,3,6] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound11765 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env11766 : List Nat := [2,4,8,16,32,16,128,36,512,188,137,17,160,0,136,171,16,137,189,137,1,33,17,139,40,16,1,152,153,1,20,169,37,168,0,512]

theorem envBound11766 : H12AffineFastState.Bounded env11766 := by
  intro p hp
  have h : env11766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11765_11766 : H12AffineEnvironment.transform 9 188 env11765 = env11766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env11765 == env11766) = true)

theorem identity11766 : scanCanonicalize (H12AffineFastState.compose env11766 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 63) := by decide +kernel

theorem selectedBound11766 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env11767 : List Nat := [2,4,8,16,32,16,128,36,63,188,137,17,160,0,136,171,16,137,189,137,1,33,17,139,40,16,1,152,153,1,20,169,37,168,0,63]

theorem envBound11767 : H12AffineFastState.Bounded env11767 := by
  intro p hp
  have h : env11767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11766_11767 : H12AffineEnvironment.transform 8 63 env11766 = env11767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 63 env11766 == env11767) = true)

theorem identity11767 : scanCanonicalize (H12AffineFastState.compose env11767 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound11767 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11768 : List Nat := [2,4,8,16,32,16,8,36,63,52,1,17,40,0,0,35,16,1,53,1,1,33,17,3,40,16,1,16,17,1,20,33,37,32,0,63]

theorem envBound11768 : H12AffineFastState.Bounded env11768 := by
  intro p hp
  have h : env11768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11767_11768 : H12AffineEnvironment.transform 6 8 env11767 = env11768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11767 == env11768) = true)

theorem identity11768 : scanCanonicalize (H12AffineFastState.compose env11768 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound11768 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11769 : List Nat := [2,4,8,1,32,1,8,36,46,37,1,0,40,0,0,35,1,1,36,1,1,33,0,3,40,1,1,1,0,1,5,33,37,32,0,46]

theorem envBound11769 : H12AffineFastState.Bounded env11769 := by
  intro p hp
  have h : env11769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11768_11769 : H12AffineEnvironment.transform 3 1 env11768 = env11769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env11768 == env11769) = true)

theorem identity11769 : scanCanonicalize (H12AffineFastState.compose env11769 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11769 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11770 : List Nat := [2,4,8,1,0,1,8,4,14,5,1,0,8,0,0,3,1,1,4,1,1,1,0,3,8,1,1,1,0,1,5,1,5,0,0,14]

theorem envBound11770 : H12AffineFastState.Bounded env11770 := by
  intro p hp
  have h : env11770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11769_11770 : H12AffineEnvironment.transform 4 0 env11769 = env11770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11769 == env11770) = true)

theorem identity11770 : scanCanonicalize (H12AffineFastState.compose env11770 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound11770 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env11771 : List Nat := [2,4,6,1,0,1,6,4,0,5,1,0,6,0,0,3,1,1,4,1,1,1,0,3,6,1,1,1,0,1,5,1,5,0,0,0]

theorem envBound11771 : H12AffineFastState.Bounded env11771 := by
  intro p hp
  have h : env11771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11770_11771 : H12AffineEnvironment.transform 2 6 env11770 = env11771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env11770 == env11771) = true)

def env11772 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,24981,262144,1025,29829,4113,272513,73754,29831,8328,17,10509,70815,91402,357642,9224,338311,257,29860,24964,66446]

theorem envBound11772 : H12AffineFastState.Bounded env11772 := by
  intro p hp
  have h : env11772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11757_11772 : H12AffineEnvironment.transform 5 17 env11757 = env11772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11757 == env11772) = true)

theorem identity11772 : scanCanonicalize (H12AffineFastState.compose env11772 (packedSelected [0,3,5,8,9,11,14,16,17,20,22,27,28,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound11772 : packedSelected [0,3,5,8,9,11,14,16,17,20,22,27,28,32,35] rootPS < 2^1333 := by decide +kernel

def env11773 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,8202,24981,262144,1025,29829,4113,272513,16,29831,8328,17,10509,13461,17664,283904,9224,264589,257,29860,24964,9092]

theorem envBound11773 : H12AffineFastState.Bounded env11773 := by
  intro p hp
  have h : env11773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11772_11773 : H12AffineEnvironment.transform 15 8202 env11772 = env11773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env11772 == env11773) = true)

theorem identity11773 : scanCanonicalize (H12AffineFastState.compose env11773 (packedSelected [1,3,6,9,10,14,16,19,20,22] rootPS)) = affineNative (2^(17+1) ^^^ 23809) := by decide +kernel

theorem selectedBound11773 : packedSelected [1,3,6,9,10,14,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env11774 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,8202,24981,23809,1025,29829,4113,30080,16,29831,8328,17,10509,13461,17664,2049,9224,21644,257,29860,24964,9092]

theorem envBound11774 : H12AffineFastState.Bounded env11774 := by
  intro p hp
  have h : env11774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11773_11774 : H12AffineEnvironment.transform 17 23809 env11773 = env11774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23809 env11773 == env11774) = true)

theorem identity11774 : scanCanonicalize (H12AffineFastState.compose env11774 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound11774 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env11775 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,41,16384,21677,35,16828,23809,1025,21676,4113,21929,16,21678,161,17,2340,5308,17664,2049,1057,21644,257,21645,16813,941]

theorem envBound11775 : H12AffineFastState.Bounded env11775 := by
  intro p hp
  have h : env11775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11774_11775 : H12AffineEnvironment.transform 12 41 env11774 = env11775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env11774 == env11775) = true)

theorem identity11775 : scanCanonicalize (H12AffineFastState.compose env11775 (packedSelected [0,2,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound11775 : packedSelected [0,2,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env11776 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,41,5156,137,35,5528,2341,1025,136,4113,397,16,138,161,17,2340,5308,4388,2049,1057,168,257,169,5513,941]

theorem envBound11776 : H12AffineFastState.Bounded env11776 := by
  intro p hp
  have h : env11776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11775_11776 : H12AffineEnvironment.transform 13 5156 env11775 = env11776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env11775 == env11776) = true)

theorem identity11776 : scanCanonicalize (H12AffineFastState.compose env11776 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound11776 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env11777 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,41,5156,137,35,5173,2184,1025,136,4113,32,16,138,161,17,2185,5308,4233,2049,1057,168,172,169,5156,512]

theorem envBound11777 : H12AffineFastState.Bounded env11777 := by
  intro p hp
  have h : env11777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11776_11777 : H12AffineEnvironment.transform 7 173 env11776 = env11777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env11776 == env11777) = true)

theorem identity11777 : scanCanonicalize (H12AffineFastState.compose env11777 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11777 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11778 : List Nat := [2,4,8,16,0,17,128,141,512,1024,2048,4096,9,5124,137,3,5141,2184,1025,136,4113,0,16,138,129,17,2185,5276,4233,2049,1025,136,140,137,5124,512]

theorem envBound11778 : H12AffineFastState.Bounded env11778 := by
  intro p hp
  have h : env11778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11777_11778 : H12AffineEnvironment.transform 4 0 env11777 = env11778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11777 == env11778) = true)

theorem identity11778 : scanCanonicalize (H12AffineFastState.compose env11778 (packedSelected [4,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound11778 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env11779 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,4096,9,5124,1,3,5141,2048,1025,0,4113,0,16,2,9,17,2049,5140,4097,2049,1025,0,4,1,5124,512]

theorem envBound11779 : H12AffineFastState.Bounded env11779 := by
  intro p hp
  have h : env11779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11778_11779 : H12AffineEnvironment.transform 6 8 env11778 = env11779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11778 == env11779) = true)

def env11780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507601,155254785,25265168,145662400,525568,140903596,27337992,25733063]

theorem envBound11780 : H12AffineFastState.Bounded env11780 := by
  intro p hp
  have h : env11780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11048_11780 : H12AffineEnvironment.transform 25 65 env11048 = env11780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env11048 == env11780) = true)

def env11781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507601,9356289,25265168,23160256,525568,27902124,27337992,25733063]

theorem envBound11781 : H12AffineFastState.Bounded env11781 := by
  intro p hp
  have h : env11781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11780_11781 : H12AffineEnvironment.transform 26 30393344 env11780 = env11781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env11780 == env11781) = true)

def env11782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830977,25265168,23160256,256,27378860,27337992,25207751]

theorem envBound11782 : H12AffineFastState.Bounded env11782 := by
  intro p hp
  have h : env11782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11781_11782 : H12AffineEnvironment.transform 18 1024 env11781 = env11782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env11781 == env11782) = true)

theorem identity11782 : scanCanonicalize (H12AffineFastState.compose env11782 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10882239) := by decide +kernel

theorem selectedBound11782 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env11783 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10882239,8328,65,6409407,8882227,10507601,8830977,2590895,13068671,256,509971,469431,2535288]

theorem envBound11783 : H12AffineFastState.Bounded env11783 := by
  intro p hp
  have h : env11783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11782_11783 : H12AffineEnvironment.transform 23 10882239 env11782 = env11783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10882239 env11782 == env11783) = true)

def env11784 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,412156,2114883,8328,65,6409407,115151,2497709,35325,2590895,4268163,256,509971,469431,2535288]

theorem envBound11784 : H12AffineFastState.Bounded env11784 := by
  intro p hp
  have h : env11784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11783_11784 : H12AffineEnvironment.transform 22 412156 env11783 = env11784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 412156 env11783 == env11784) = true)

def env11785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262520,412156,2114883,8328,65,215367,115151,2497709,35325,2590895,2336123,256,509971,469431,2535288]

theorem envBound11785 : H12AffineFastState.Bounded env11785 := by
  intro p hp
  have h : env11785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11784_11785 : H12AffineEnvironment.transform 21 2262520 env11784 = env11785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262520 env11784 == env11785) = true)

def env11786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169400,412156,21763,8328,65,215367,115151,396525,35325,497903,243003,256,509971,469431,442168]

theorem envBound11786 : H12AffineFastState.Bounded env11786 := by
  intro p hp
  have h : env11786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11785_11786 : H12AffineEnvironment.transform 20 4160 env11785 = env11786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env11785 == env11786) = true)

theorem identity11786 : scanCanonicalize (H12AffineFastState.compose env11786 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223719) := by decide +kernel

theorem selectedBound11786 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,4160,169400,73755,21763,8328,65,215367,115151,91402,35325,61704,243003,256,41460,16464,120543]

theorem envBound11787 : H12AffineFastState.Bounded env11787 := by
  intro p hp
  have h : env11787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11786_11787 : H12AffineEnvironment.transform 17 223719 env11786 = env11787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223719 env11786 == env11787) = true)

def env11788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,67755,1024,32769,4160,62708,73755,21763,8328,65,75787,115151,91402,35325,61704,119927,256,41460,16464,120543]

theorem envBound11788 : H12AffineFastState.Bounded env11788 := by
  intro p hp
  have h : env11788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11787_11788 : H12AffineEnvironment.transform 16 24908 env11787 = env11788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env11787 == env11788) = true)

theorem identity11788 : scanCanonicalize (H12AffineFastState.compose env11788 (packedSelected [4,7,9,11,14,17,18,23,27,32,35] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound11788 : packedSelected [4,7,9,11,14,17,18,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env11789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,137,65536,24908,67755,1024,136,4160,29821,73755,21763,8328,65,75787,82246,91402,2420,29057,87294,256,8573,16464,87638]

theorem envBound11789 : H12AffineFastState.Bounded env11789 := by
  intro p hp
  have h : env11789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11788_11789 : H12AffineEnvironment.transform 14 137 env11788 = env11789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env11788 == env11789) = true)

theorem identity11789 : scanCanonicalize (H12AffineFastState.compose env11789 (packedSelected [3,10,16,20,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound11789 : packedSelected [3,10,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env11790 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,65536,24908,67618,1024,1,4160,29821,73755,21763,8193,65,75787,82246,91402,2420,28936,87159,256,8573,16464,87638]

theorem envBound11790 : H12AffineFastState.Bounded env11790 := by
  intro p hp
  have h : env11790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11789_11790 : H12AffineEnvironment.transform 6 9 env11789 = env11790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11789 == env11790) = true)

theorem identity11790 : scanCanonicalize (H12AffineFastState.compose env11790 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound11790 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11791 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,21591,24908,23669,1024,1,4160,29821,29772,21763,8193,65,31836,5393,12637,2420,28936,32,256,8573,16464,513]

theorem envBound11791 : H12AffineFastState.Bounded env11791 := by
  intro p hp
  have h : env11791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11790_11791 : H12AffineEnvironment.transform 15 21591 env11790 = env11791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env11790 == env11791) = true)

def env11792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,67754,1024,32769,4160,62709,73755,21763,8328,65,75786,115151,91402,35325,61704,119926,256,41460,16464,120543]

theorem envBound11792 : H12AffineFastState.Bounded env11792 := by
  intro p hp
  have h : env11792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11787_11792 : H12AffineEnvironment.transform 16 24909 env11787 = env11792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env11787 == env11792) = true)

theorem identity11792 : scanCanonicalize (H12AffineFastState.compose env11792 (packedSelected [4,7,9,11,14,17,18,23,27,32,35] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound11792 : packedSelected [4,7,9,11,14,17,18,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env11793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,65536,5393,67754,1024,32769,4160,32937,73755,8543,8328,65,75786,112019,69974,35325,34132,106538,256,41460,13324,107139]

theorem envBound11793 : H12AffineFastState.Bounded env11793 := by
  intro p hp
  have h : env11793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11792_11793 : H12AffineEnvironment.transform 13 13404 env11792 = env11793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env11792 == env11793) = true)

theorem identity11793 : scanCanonicalize (H12AffineFastState.compose env11793 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound11793 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env11794 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,33111,5393,35325,1024,32769,4160,32937,41292,8543,8328,65,43357,13508,36865,35325,34132,8573,256,41460,13324,9172]

theorem envBound11794 : H12AffineFastState.Bounded env11794 := by
  intro p hp
  have h : env11794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11793_11794 : H12AffineEnvironment.transform 15 33111 env11793 = env11794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env11793 == env11794) = true)

theorem identity11794 : scanCanonicalize (H12AffineFastState.compose env11794 (packedSelected [16,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound11794 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env11795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,136,479,5393,2421,1024,137,4160,33,8644,8543,8328,65,10709,13508,4233,2421,1500,8573,256,8572,13324,9172]

theorem envBound11795 : H12AffineFastState.Bounded env11795 := by
  intro p hp
  have h : env11795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11794_11795 : H12AffineEnvironment.transform 14 136 env11794 = env11795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env11794 == env11795) = true)

theorem identity11795 : scanCanonicalize (H12AffineFastState.compose env11795 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound11795 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env11796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,136,479,5393,2421,1024,137,4160,33,16,139,348,65,2049,5392,4233,2421,1500,169,256,168,5592,512]

theorem envBound11796 : H12AffineFastState.Bounded env11796 := by
  intro p hp
  have h : env11796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11795_11796 : H12AffineEnvironment.transform 12 468 env11795 = env11796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env11795 == env11796) = true)

theorem identity11796 : scanCanonicalize (H12AffineFastState.compose env11796 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound11796 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11797 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,380,5408,32,375,5393,2421,1024,33,4160,33,16,35,348,65,2049,5392,4129,2421,1396,1,256,0,5488,512]

theorem envBound11797 : H12AffineFastState.Bounded env11797 := by
  intro p hp
  have h : env11797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11796_11797 : H12AffineEnvironment.transform 6 40 env11796 = env11797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env11796 == env11797) = true)

theorem identity11797 : scanCanonicalize (H12AffineFastState.compose env11797 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound11797 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env11798 : List Nat := [2,4,8,16,32,64,40,117,512,1024,2048,4096,9,5205,32,2,5220,2048,1024,33,4160,33,16,35,41,65,2049,5221,4129,2048,1025,1,117,0,5125,512]

theorem envBound11798 : H12AffineFastState.Bounded env11798 := by
  intro p hp
  have h : env11798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11797_11798 : H12AffineEnvironment.transform 7 117 env11797 = env11798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env11797 == env11798) = true)

theorem identity11798 : scanCanonicalize (H12AffineFastState.compose env11798 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound11798 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env11799 : List Nat := [2,4,8,16,32,64,40,117,512,1024,2048,2064,9,3141,32,2,3188,2048,1024,33,2128,33,16,35,41,65,2049,3189,2097,2048,1025,1,117,0,3093,512]

theorem envBound11799 : H12AffineFastState.Bounded env11799 := by
  intro p hp
  have h : env11799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11798_11799 : H12AffineEnvironment.transform 11 2064 env11798 = env11799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env11798 == env11799) = true)

def env11800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169401,412156,21762,8328,65,215367,115151,396524,35325,497902,243002,256,509971,469431,442169]

theorem envBound11800 : H12AffineFastState.Bounded env11800 := by
  intro p hp
  have h : env11800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11785_11800 : H12AffineEnvironment.transform 20 4161 env11785 = env11800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env11785 == env11800) = true)

theorem identity11800 : scanCanonicalize (H12AffineFastState.compose env11800 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound11800 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11801 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,4161,169401,412156,21762,8328,65,171416,5392,396524,35325,412721,156133,256,400588,458088,442169]

theorem envBound11801 : H12AffineFastState.Bounded env11801 := by
  intro p hp
  have h : env11801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11800_11801 : H12AffineEnvironment.transform 15 54495 env11800 = env11801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env11800 == env11801) = true)

def env11802 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,262144,1024,32769,4113,169401,412076,21762,8328,17,171416,5392,396476,35245,412721,156085,256,400540,458040,442169]

theorem envBound11802 : H12AffineFastState.Bounded env11802 := by
  intro p hp
  have h : env11802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11801_11802 : H12AffineEnvironment.transform 5 16 env11801 = env11802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11801 == env11802) = true)

theorem identity11802 : scanCanonicalize (H12AffineFastState.compose env11802 (packedSelected [1,4,7,9,12,15,16,17,18,20,23,26,27,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 43169) := by decide +kernel

theorem selectedBound11802 : packedSelected [1,4,7,9,12,15,16,17,18,20,23,26,27,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env11803 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,43169,1024,32769,4113,169401,188685,21762,8328,17,171416,5392,173085,35245,189584,156085,256,177213,152985,137112]

theorem envBound11803 : H12AffineFastState.Bounded env11803 := by
  intro p hp
  have h : env11803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11802_11803 : H12AffineEnvironment.transform 17 43169 env11802 = env11803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43169 env11802 == env11803) = true)

theorem identity11803 : scanCanonicalize (H12AffineFastState.compose env11803 (packedSelected [3,4,5,7,8,9,17,18,23,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 57749) := by decide +kernel

theorem selectedBound11803 : packedSelected [3,4,5,7,8,9,17,18,23,27,28] rootPS < 2^1333 := by decide +kernel

def env11804 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,57749,43169,1024,32769,4113,29740,152,21762,8328,17,31757,5392,17800,35245,1285,32800,256,21928,46092,62989]

theorem envBound11804 : H12AffineFastState.Bounded env11804 := by
  intro p hp
  have h : env11804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11803_11804 : H12AffineEnvironment.transform 16 57749 env11803 = env11804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57749 env11803 == env11804) = true)

theorem identity11804 : scanCanonicalize (H12AffineFastState.compose env11804 (packedSelected [0,1,3,4,5,7,8,10,17,22,26] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound11804 : packedSelected [0,1,3,4,5,7,8,10,17,22,26] rootPS < 2^1333 := by decide +kernel

def env11805 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29708,8323,5529,23725,1024,29709,4113,29740,152,21762,8328,17,31757,5392,17800,32161,1285,29740,256,21928,16384,513]

theorem envBound11805 : H12AffineFastState.Bounded env11805 := by
  intro p hp
  have h : env11805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11804_11805 : H12AffineEnvironment.transform 14 29708 env11804 = env11805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env11804 == env11805) = true)

theorem identity11805 : scanCanonicalize (H12AffineFastState.compose env11805 (packedSelected [1,2,3,5,6,8,10,17,19] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound11805 : packedSelected [1,2,3,5,6,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env11806 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,21761,398,5529,23725,1024,21760,4113,21793,152,21762,389,17,23808,5392,17800,23724,1285,21793,256,21928,16384,513]

theorem envBound11806 : H12AffineFastState.Bounded env11806 := by
  intro p hp
  have h : env11806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11805_11806 : H12AffineEnvironment.transform 12 269 env11805 = env11806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env11805 == env11806) = true)

theorem identity11806 : scanCanonicalize (H12AffineFastState.compose env11806 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound11806 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11807 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5512,137,398,5529,2341,1024,136,4113,169,152,138,389,17,2184,5392,4096,2340,1285,169,256,32,5512,513]

theorem envBound11807 : H12AffineFastState.Bounded env11807 := by
  intro p hp
  have h : env11807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11806_11807 : H12AffineEnvironment.transform 13 5512 env11806 = env11807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env11806 == env11807) = true)

theorem identity11807 : scanCanonicalize (H12AffineFastState.compose env11807 (packedSelected [1,2,4,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound11807 : packedSelected [1,2,4,8,9] rootPS < 2^1333 := by decide +kernel

def env11808 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,17,269,1433,137,398,1416,2341,1024,136,0,169,152,138,389,17,2184,1281,17,2340,1285,169,256,32,1433,513]

theorem envBound11808 : H12AffineFastState.Bounded env11808 := by
  intro p hp
  have h : env11808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11807_11808 : H12AffineEnvironment.transform 11 17 env11807 = env11808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env11807 == env11808) = true)

theorem identity11808 : scanCanonicalize (H12AffineFastState.compose env11808 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound11808 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11809 : List Nat := [2,4,8,16,32,16,128,256,512,409,2048,17,269,0,137,398,17,2341,409,136,0,169,152,138,389,17,2184,152,17,2340,156,169,256,32,0,513]

theorem envBound11809 : H12AffineFastState.Bounded env11809 := by
  intro p hp
  have h : env11809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11808_11809 : H12AffineEnvironment.transform 9 409 env11808 = env11809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env11808 == env11809) = true)

theorem identity11809 : scanCanonicalize (H12AffineFastState.compose env11809 (packedSelected [1,2,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound11809 : packedSelected [1,2,8,11] rootPS < 2^1333 := by decide +kernel

def env11810 : List Nat := [2,4,8,16,32,16,128,256,512,409,137,17,269,0,137,398,17,428,409,136,0,169,152,138,389,17,1,152,17,429,156,169,256,32,0,513]

theorem envBound11810 : H12AffineFastState.Bounded env11810 := by
  intro p hp
  have h : env11810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11809_11810 : H12AffineEnvironment.transform 10 137 env11809 = env11810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env11809 == env11810) = true)

def env11811 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,262144,1024,32769,4112,169401,412077,21762,8328,16,171416,5392,396477,35244,412721,156084,256,400541,458041,442169]

theorem envBound11811 : H12AffineFastState.Bounded env11811 := by
  intro p hp
  have h : env11811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11801_11811 : H12AffineEnvironment.transform 5 17 env11801 = env11811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11801 == env11811) = true)

theorem identity11811 : scanCanonicalize (H12AffineFastState.compose env11811 (packedSelected [1,4,7,9,12,15,16,17,18,20,23,26,27,28,31,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound11811 : packedSelected [1,4,7,9,12,15,16,17,18,20,23,26,27,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env11812 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,16384,32768,54414,131072,262144,1024,32769,4112,169401,412077,21762,268,16,171416,5392,396477,35244,412721,147504,256,400541,449725,433853]

theorem envBound11812 : H12AffineFastState.Bounded env11812 := by
  intro p hp
  have h : env11812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11811_11812 : H12AffineEnvironment.transform 12 388 env11811 = env11812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env11811 == env11812) = true)

theorem identity11812 : scanCanonicalize (H12AffineFastState.compose env11812 (packedSelected [0,1,5,8,9,10,16,18,20,22,23,24,27,31] rootPS)) = affineNative (2^(17+1) ^^^ 35109) := by decide +kernel

theorem selectedBound11812 : packedSelected [0,1,5,8,9,10,16,18,20,22,23,24,27,31] rootPS < 2^1333 := by decide +kernel

def env11813 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,16384,32768,54414,131072,35109,1024,32769,4112,169401,180360,21762,268,16,171416,5392,165272,35244,181524,147504,256,169400,152984,137112]

theorem envBound11813 : H12AffineFastState.Bounded env11813 := by
  intro p hp
  have h : env11813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11812_11813 : H12AffineEnvironment.transform 17 35109 env11812 = env11813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35109 env11812 == env11813) = true)

theorem identity11813 : scanCanonicalize (H12AffineFastState.compose env11813 (packedSelected [0,1,3,4,5,7,8,10,22,26] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound11813 : packedSelected [0,1,3,4,5,7,8,10,22,26] rootPS < 2^1333 := by decide +kernel

def env11814 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,16384,32768,54414,5529,35109,1024,32769,4112,32800,54545,21762,268,16,34817,5392,36865,35244,53389,21929,256,32801,16385,513]

theorem envBound11814 : H12AffineFastState.Bounded env11814 := by
  intro p hp
  have h : env11814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11813_11814 : H12AffineEnvironment.transform 16 5529 env11813 = env11814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env11813 == env11814) = true)

theorem identity11814 : scanCanonicalize (H12AffineFastState.compose env11814 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound11814 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env11815 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,16384,136,21510,5529,2477,1024,137,4112,168,21913,21762,268,16,2185,5392,4233,2340,20485,21929,256,169,16385,513]

theorem envBound11815 : H12AffineFastState.Bounded env11815 := by
  intro p hp
  have h : env11815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11814_11815 : H12AffineEnvironment.transform 14 136 env11814 = env11815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env11814 == env11815) = true)

theorem identity11815 : scanCanonicalize (H12AffineFastState.compose env11815 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound11815 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11816 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5513,136,399,5529,2477,1024,137,4112,168,16,139,268,16,2185,5392,4233,2340,1420,32,256,169,5512,513]

theorem envBound11816 : H12AffineFastState.Bounded env11816 := by
  intro p hp
  have h : env11816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11815_11816 : H12AffineEnvironment.transform 13 5513 env11815 = env11816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env11815 == env11816) = true)

theorem identity11816 : scanCanonicalize (H12AffineFastState.compose env11816 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 412) := by decide +kernel

theorem selectedBound11816 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env11817 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,412,388,1045,136,399,1029,2477,1024,137,396,168,16,139,268,16,2185,1164,277,2340,1420,32,256,169,1044,513]

theorem envBound11817 : H12AffineFastState.Bounded env11817 := by
  intro p hp
  have h : env11817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11816_11817 : H12AffineEnvironment.transform 11 412 env11816 = env11817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 412 env11816 == env11817) = true)

def env11818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262521,412156,2114883,8328,65,215366,115151,2497709,35325,2590895,2336122,256,509971,469431,2535288]

theorem envBound11818 : H12AffineFastState.Bounded env11818 := by
  intro p hp
  have h : env11818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11784_11818 : H12AffineEnvironment.transform 21 2262521 env11784 = env11818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262521 env11784 == env11818) = true)

def env11819 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169401,412156,21763,8328,65,215366,115151,396525,35325,497903,243002,256,509971,469431,442168]

theorem envBound11819 : H12AffineFastState.Bounded env11819 := by
  intro p hp
  have h : env11819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11818_11819 : H12AffineEnvironment.transform 20 4160 env11818 = env11819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env11818 == env11819) = true)

theorem identity11819 : scanCanonicalize (H12AffineFastState.compose env11819 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound11819 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,4160,169401,412156,21763,8328,65,158029,57796,396525,35325,440548,169265,256,452632,395708,442168]

theorem envBound11820 : H12AffineFastState.Bounded env11820 := by
  intro p hp
  have h : env11820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11819_11820 : H12AffineEnvironment.transform 15 8203 env11819 = env11820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env11819 == env11820) = true)

theorem identity11820 : scanCanonicalize (H12AffineFastState.compose env11820 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 179513) := by decide +kernel

theorem selectedBound11820 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env11821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179513,1024,32769,4160,169401,62661,21763,8328,65,158029,57796,45524,35325,1501,169265,256,21793,46213,513]

theorem envBound11821 : H12AffineFastState.Bounded env11821 := by
  intro p hp
  have h : env11821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11820_11821 : H12AffineEnvironment.transform 17 179513 env11820 = env11821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env11820 == env11821) = true)

theorem identity11821 : scanCanonicalize (H12AffineFastState.compose env11821 (packedSelected [11,12,15,16,18,20,23,32,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound11821 : packedSelected [11,12,15,16,18,20,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env11822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,342,131072,171108,1024,32769,4160,169401,54680,21763,469,65,149520,49305,37001,35325,1501,169265,256,21793,38360,513]

theorem envBound11822 : H12AffineFastState.Bounded env11822 := by
  intro p hp
  have h : env11822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11821_11822 : H12AffineEnvironment.transform 12 349 env11821 = env11822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env11821 == env11822) = true)

theorem identity11822 : scanCanonicalize (H12AffineFastState.compose env11822 (packedSelected [1,2,4,5,6,7,8,9,15,17,18,23,24,27,38] rootPS)) = affineNative (2^(16+1) ^^^ 16585) := by decide +kernel

theorem selectedBound11822 : packedSelected [1,2,4,5,6,7,8,9,15,17,18,23,24,27,38] rootPS < 2^1333 := by decide +kernel

def env11823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,342,16585,56493,1024,32769,4160,54640,54680,21763,469,65,2265,49305,37001,35325,1501,54776,256,21793,38360,513]

theorem envBound11823 : H12AffineFastState.Bounded env11823 := by
  intro p hp
  have h : env11823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11822_11823 : H12AffineEnvironment.transform 16 16585 env11822 = env11823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16585 env11822 == env11823) = true)

theorem identity11823 : scanCanonicalize (H12AffineFastState.compose env11823 (packedSelected [3,4,9,10,14,19,20,24] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound11823 : packedSelected [3,4,9,10,14,19,20,24] rootPS < 2^1333 := by decide +kernel

def env11824 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,16384,32768,342,16401,56437,1024,32769,4160,54640,54592,21763,269,65,2049,49217,36945,35109,1285,54560,256,21793,38144,513]

theorem envBound11824 : H12AffineFastState.Bounded env11824 := by
  intro p hp
  have h : env11824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11823_11824 : H12AffineEnvironment.transform 6 88 env11823 = env11824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env11823 == env11824) = true)

theorem identity11824 : scanCanonicalize (H12AffineFastState.compose env11824 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound11824 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env11825 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,16384,21840,342,16401,2341,1024,21841,4160,32,16,21763,269,65,2049,5393,17665,23669,1285,112,256,21793,16464,513]

theorem envBound11825 : H12AffineFastState.Bounded env11825 := by
  intro p hp
  have h : env11825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11824_11825 : H12AffineEnvironment.transform 14 21840 env11824 = env11825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env11824 == env11825) = true)

theorem identity11825 : scanCanonicalize (H12AffineFastState.compose env11825 (packedSelected [2,5,7,8,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 5167) := by decide +kernel

theorem selectedBound11825 : packedSelected [2,5,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env11826 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,5167,383,342,5182,2341,1024,382,4160,32,16,300,269,65,2049,5393,4398,2138,1285,112,256,270,5247,513]

theorem envBound11826 : H12AffineFastState.Bounded env11826 := by
  intro p hp
  have h : env11826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11825_11826 : H12AffineEnvironment.transform 13 5167 env11825 = env11826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5167 env11825 == env11826) = true)

theorem identity11826 : scanCanonicalize (H12AffineFastState.compose env11826 (packedSelected [1,2,4,6,7,8,12] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound11826 : packedSelected [1,2,4,6,7,8,12] rootPS < 2^1333 := by decide +kernel

def env11827 : List Nat := [2,4,8,16,32,64,88,256,512,47,2048,4096,349,4096,383,342,4113,2341,47,382,4160,32,16,300,269,65,2049,4414,4398,2138,298,112,256,270,4176,513]

theorem envBound11827 : H12AffineFastState.Bounded env11827 := by
  intro p hp
  have h : env11827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11826_11827 : H12AffineEnvironment.transform 9 47 env11826 = env11827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env11826 == env11827) = true)

theorem identity11827 : scanCanonicalize (H12AffineFastState.compose env11827 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 127) := by decide +kernel

theorem selectedBound11827 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env11828 : List Nat := [2,4,8,16,32,64,88,127,512,47,2048,4096,34,4096,0,41,4113,2138,47,1,4160,32,16,83,114,65,2049,4161,4177,2138,85,112,127,113,4176,513]

theorem envBound11828 : H12AffineFastState.Bounded env11828 := by
  intro p hp
  have h : env11828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11827_11828 : H12AffineEnvironment.transform 7 127 env11827 = env11828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 127 env11827 == env11828) = true)

theorem identity11828 : scanCanonicalize (H12AffineFastState.compose env11828 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 2059) := by decide +kernel

theorem selectedBound11828 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env11829 : List Nat := [2,4,8,16,32,64,88,127,512,47,2048,2059,34,2059,0,41,2074,2138,47,1,2123,32,16,83,114,65,2049,2122,2138,2138,85,112,127,113,2139,513]

theorem envBound11829 : H12AffineFastState.Bounded env11829 := by
  intro p hp
  have h : env11829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11828_11829 : H12AffineEnvironment.transform 11 2059 env11828 = env11829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2059 env11828 == env11829) = true)

def env11830 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169400,412156,21762,8328,65,215366,115151,396524,35325,497902,243003,256,509971,469431,442169]

theorem envBound11830 : H12AffineFastState.Bounded env11830 := by
  intro p hp
  have h : env11830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11818_11830 : H12AffineEnvironment.transform 20 4161 env11818 = env11830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env11818 == env11830) = true)

theorem identity11830 : scanCanonicalize (H12AffineFastState.compose env11830 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236851) := by decide +kernel

theorem selectedBound11830 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236851,1024,32769,4161,169400,120015,21762,8328,65,215366,115151,102879,35325,1501,243003,256,21792,46212,74250]

theorem envBound11831 : H12AffineFastState.Bounded env11831 := by
  intro p hp
  have h : env11831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11830_11831 : H12AffineEnvironment.transform 17 236851 env11830 = env11831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236851 env11830 == env11831) = true)

def env11832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,130175,1024,32769,4161,62708,120015,21762,8328,65,75786,115151,102879,35325,1501,119927,256,21792,46212,74250]

theorem envBound11832 : H12AffineFastState.Bounded env11832 := by
  intro p hp
  have h : env11832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11831_11832 : H12AffineEnvironment.transform 16 24908 env11831 = env11832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env11831 == env11832) = true)

def env11833 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,130175,1024,32769,4161,62588,119879,21762,8192,65,75786,115015,102743,35189,1365,119927,256,21792,46092,74250]

theorem envBound11833 : H12AffineFastState.Bounded env11833 := by
  intro p hp
  have h : env11833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11832_11833 : H12AffineEnvironment.transform 6 8 env11832 = env11833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11832 == env11833) = true)

theorem identity11833 : scanCanonicalize (H12AffineFastState.compose env11833 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound11833 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11834 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,24908,32041,1024,32769,4161,62588,21777,21762,8192,65,43356,16401,4097,35189,1365,21793,256,21792,46092,41820]

theorem envBound11834 : H12AffineFastState.Bounded env11834 := by
  intro p hp
  have h : env11834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11833_11834 : H12AffineEnvironment.transform 15 33110 env11833 = env11834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env11833 == env11834) = true)

theorem identity11834 : scanCanonicalize (H12AffineFastState.compose env11834 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound11834 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env11835 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,13389,10280,1024,32769,4161,41341,16,3,8192,65,43356,5392,4097,35189,1365,32,256,33,46092,41820]

theorem envBound11835 : H12AffineFastState.Bounded env11835 := by
  intro p hp
  have h : env11835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11834_11835 : H12AffineEnvironment.transform 13 5377 env11834 = env11835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env11834 == env11835) = true)

theorem identity11835 : scanCanonicalize (H12AffineFastState.compose env11835 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound11835 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11836 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,5377,32768,33110,4096,3173,1024,32769,4161,34096,16,3,1101,65,36113,5392,4097,35189,1365,32,256,33,36929,34577]

theorem envBound11836 : H12AffineFastState.Bounded env11836 := by
  intro p hp
  have h : env11836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11835_11836 : H12AffineEnvironment.transform 12 1101 env11835 = env11836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env11835 == env11836) = true)

theorem identity11836 : scanCanonicalize (H12AffineFastState.compose env11836 (packedSelected [2,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound11836 : packedSelected [2,12,14,15] rootPS < 2^1333 := by decide +kernel

def env11837 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,349,4113,32768,33110,4096,2421,272,32769,4161,32800,16,3,349,65,34817,4096,4097,35189,69,32,256,33,36929,33281]

theorem envBound11837 : H12AffineFastState.Bounded env11837 := by
  intro p hp
  have h : env11837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11836_11837 : H12AffineEnvironment.transform 9 272 env11836 = env11837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env11836 == env11837) = true)

theorem identity11837 : scanCanonicalize (H12AffineFastState.compose env11837 (packedSelected [2,4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound11837 : packedSelected [2,4,9,16] rootPS < 2^1333 := by decide +kernel

def env11838 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,349,4113,372,34,4096,2421,272,373,4161,340,16,3,349,65,2421,4096,4097,2049,69,32,256,33,4405,885]

theorem envBound11838 : H12AffineFastState.Bounded env11838 := by
  intro p hp
  have h : env11838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11837_11838 : H12AffineEnvironment.transform 14 372 env11837 = env11838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env11837 == env11838) = true)

theorem identity11838 : scanCanonicalize (H12AffineFastState.compose env11838 (packedSelected [0,2,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 2400) := by decide +kernel

theorem selectedBound11838 : packedSelected [0,2,4,7] rootPS < 2^1333 := by decide +kernel

def env11839 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2400,349,2417,372,34,2400,2421,272,373,2337,340,16,3,349,65,2421,2400,2401,2049,69,32,256,33,2133,885]

theorem envBound11839 : H12AffineFastState.Bounded env11839 := by
  intro p hp
  have h : env11839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11838_11839 : H12AffineEnvironment.transform 11 2400 env11838 = env11839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2400 env11838 == env11839) = true)

theorem identity11839 : scanCanonicalize (H12AffineFastState.compose env11839 (packedSelected [4,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 605) := by decide +kernel

theorem selectedBound11839 : packedSelected [4,6,8] rootPS < 2^1333 := by decide +kernel

def env11840 : List Nat := [2,4,8,16,32,64,8,256,512,272,605,829,349,812,372,34,829,808,272,373,892,340,16,3,349,65,808,829,828,604,69,32,256,33,520,885]

theorem envBound11840 : H12AffineFastState.Bounded env11840 := by
  intro p hp
  have h : env11840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11839_11840 : H12AffineEnvironment.transform 10 605 env11839 = env11840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 605 env11839 == env11840) = true)

theorem identity11840 : scanCanonicalize (H12AffineFastState.compose env11840 (packedSelected [12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11840 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env11841 : List Nat := [2,4,8,16,32,64,8,37,512,53,605,536,120,521,81,34,536,525,53,80,601,113,16,3,120,65,525,536,537,604,69,32,37,33,520,592]

theorem envBound11841 : H12AffineFastState.Bounded env11841 := by
  intro p hp
  have h : env11841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11840_11841 : H12AffineEnvironment.transform 7 37 env11840 = env11841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11840 == env11841) = true)

theorem identity11841 : scanCanonicalize (H12AffineFastState.compose env11841 (packedSelected [1,4,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound11841 : packedSelected [1,4,6] rootPS < 2^1333 := by decide +kernel

def env11842 : List Nat := [2,4,8,16,32,48,8,37,512,53,557,536,8,521,33,34,536,525,53,32,553,1,16,3,8,49,525,536,537,556,53,32,37,33,520,544]

theorem envBound11842 : H12AffineFastState.Bounded env11842 := by
  intro p hp
  have h : env11842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11841_11842 : H12AffineEnvironment.transform 5 48 env11841 = env11842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env11841 == env11842) = true)

def env11843 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,130175,1024,32769,4161,62589,119878,21762,8193,65,75786,115014,102742,35188,1364,119927,256,21792,46093,74250]

theorem envBound11843 : H12AffineFastState.Bounded env11843 := by
  intro p hp
  have h : env11843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11832_11843 : H12AffineEnvironment.transform 6 9 env11832 = env11843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11832 == env11843) = true)

theorem identity11843 : scanCanonicalize (H12AffineFastState.compose env11843 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound11843 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11844 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,24908,56436,1024,32769,4161,62589,62541,21762,8193,65,2049,57677,45405,35188,1364,62588,256,21792,46093,513]

theorem envBound11844 : H12AffineFastState.Bounded env11844 := by
  intro p hp
  have h : env11844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11843_11844 : H12AffineEnvironment.transform 15 8203 env11843 = env11844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env11843 == env11844) = true)

def env11845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,130174,1024,32769,4161,62709,120015,21762,8328,65,75787,115151,102879,35325,1501,119926,256,21792,46212,74250]

theorem envBound11845 : H12AffineFastState.Bounded env11845 := by
  intro p hp
  have h : env11845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11831_11845 : H12AffineEnvironment.transform 16 24909 env11831 = env11845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env11831 == env11845) = true)

def env11846 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,130174,1024,32769,4161,62589,119879,21762,8192,65,75787,115015,102743,35189,1365,119926,256,21792,46092,74250]

theorem envBound11846 : H12AffineFastState.Bounded env11846 := by
  intro p hp
  have h : env11846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11845_11846 : H12AffineEnvironment.transform 6 8 env11845 = env11846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11845 == env11846) = true)

theorem identity11846 : scanCanonicalize (H12AffineFastState.compose env11846 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound11846 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11847 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,13389,108926,1024,32769,4161,41341,98631,2,8192,65,75787,103495,102743,35189,1365,98678,256,32,46092,74250]

theorem envBound11847 : H12AffineFastState.Bounded env11847 := by
  intro p hp
  have h : env11847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11846_11847 : H12AffineEnvironment.transform 13 5376 env11846 = env11847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env11846 == env11847) = true)

theorem identity11847 : scanCanonicalize (H12AffineFastState.compose env11847 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound11847 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env11848 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,40971,13389,2421,1024,32769,4161,41341,8524,2,8192,65,34816,13388,12636,35189,1365,8573,256,32,46092,33281]

theorem envBound11848 : H12AffineFastState.Bounded env11848 := by
  intro p hp
  have h : env11848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11847_11848 : H12AffineEnvironment.transform 15 40971 env11847 = env11848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env11847 == env11848) = true)

theorem identity11848 : scanCanonicalize (H12AffineFastState.compose env11848 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound11848 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env11849 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,342,13389,2421,1024,8540,4161,32,8524,2,8192,65,10589,13388,12636,10280,1365,8573,256,32,5457,9052]

theorem envBound11849 : H12AffineFastState.Bounded env11849 := by
  intro p hp
  have h : env11849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11848_11849 : H12AffineEnvironment.transform 14 8541 env11848 = env11849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env11848 == env11849) = true)

theorem identity11849 : scanCanonicalize (H12AffineFastState.compose env11849 (packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound11849 : packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env11850 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5376,373,342,5221,2421,1024,372,4161,32,356,2,40,65,2421,5220,4468,2048,1365,341,256,32,5457,884]

theorem envBound11850 : H12AffineFastState.Bounded env11850 := by
  intro p hp
  have h : env11850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11849_11850 : H12AffineEnvironment.transform 12 40 env11849 = env11850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env11849 == env11850) = true)

theorem identity11850 : scanCanonicalize (H12AffineFastState.compose env11850 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11850 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env11851 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,40,5376,293,262,5173,2341,1024,292,4113,32,308,2,40,17,2341,5172,4388,2048,1285,261,256,32,5377,804]

theorem envBound11851 : H12AffineFastState.Bounded env11851 := by
  intro p hp
  have h : env11851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11850_11851 : H12AffineEnvironment.transform 5 16 env11850 = env11851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11850 == env11851) = true)

theorem identity11851 : scanCanonicalize (H12AffineFastState.compose env11851 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11851 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env11852 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5156,1,34,5173,2049,1024,0,4113,32,16,2,40,17,2049,5172,4096,2048,1057,33,36,32,5157,512]

theorem envBound11852 : H12AffineFastState.Bounded env11852 := by
  intro p hp
  have h : env11852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11851_11852 : H12AffineEnvironment.transform 7 36 env11851 = env11852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11851 == env11852) = true)

theorem identity11852 : scanCanonicalize (H12AffineFastState.compose env11852 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11852 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11853 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,4096,8,5124,1,2,5141,2049,1024,0,4113,0,16,2,8,17,2049,5140,4096,2048,1025,1,4,0,5125,512]

theorem envBound11853 : H12AffineFastState.Bounded env11853 := by
  intro p hp
  have h : env11853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11852_11853 : H12AffineEnvironment.transform 4 0 env11852 = env11853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11852 == env11853) = true)

theorem identity11853 : scanCanonicalize (H12AffineFastState.compose env11853 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound11853 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11854 : List Nat := [2,4,8,16,0,16,8,4,512,1024,523,4096,8,5124,1,2,5141,522,1024,0,4113,0,16,2,8,17,522,5140,4096,523,1025,1,4,0,5125,512]

theorem envBound11854 : H12AffineFastState.Bounded env11854 := by
  intro p hp
  have h : env11854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11853_11854 : H12AffineEnvironment.transform 10 523 env11853 = env11854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env11853 == env11854) = true)

def env11855 : List Nat := [2,4,8,16,0,16,8,4,512,1024,523,16,8,1044,1,2,1029,522,1024,0,1,0,16,2,8,17,522,1028,16,523,1025,1,4,0,1045,512]

theorem envBound11855 : H12AffineFastState.Bounded env11855 := by
  intro p hp
  have h : env11855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11854_11855 : H12AffineEnvironment.transform 11 16 env11854 = env11855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env11854 == env11855) = true)

theorem identity11855 : scanCanonicalize (H12AffineFastState.compose env11855 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound11855 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11856 : List Nat := [2,4,8,16,0,16,8,4,30,1024,21,16,8,1044,1,2,1029,20,1024,0,1,0,16,2,8,17,20,1028,16,21,1025,1,4,0,1045,30]

theorem envBound11856 : H12AffineFastState.Bounded env11856 := by
  intro p hp
  have h : env11856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11855_11856 : H12AffineEnvironment.transform 8 30 env11855 = env11856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env11855 == env11856) = true)

def env11857 : List Nat := [2,4,8,16,0,16,8,4,30,0,21,16,8,20,1,2,5,20,0,0,1,0,16,2,8,17,20,4,16,21,1,1,4,0,21,30]

theorem envBound11857 : H12AffineFastState.Bounded env11857 := by
  intro p hp
  have h : env11857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11856_11857 : H12AffineEnvironment.transform 9 0 env11856 = env11857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env11856 == env11857) = true)

theorem identity11857 : scanCanonicalize (H12AffineFastState.compose env11857 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound11857 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11858 : List Nat := [2,4,8,6,0,6,8,4,8,0,3,6,8,2,1,2,5,2,0,0,1,0,6,2,8,7,2,4,6,3,1,1,4,0,3,8]

theorem envBound11858 : H12AffineFastState.Bounded env11858 := by
  intro p hp
  have h : env11858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11857_11858 : H12AffineEnvironment.transform 3 6 env11857 = env11858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env11857 == env11858) = true)

def leafEnv11858 : List Nat := [2,4,8,6,0,6,8,4,8,0,3,6,8,2,1,2,5,2,0,0,1,0,6,2,0,8,1,7,2,4,6,3,1,1,4,0,5,2,3,8,1,0,0]

def active11858 : List Nat := [0,1,2]

def tree11858 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11858 : H12WitnessSearch.Good tree11858 := H12GlobalWitnessIndex.good

theorem leafIdentity11858 : H12AffineFastState.composeSystem env11858 rootObs = leafEnv11858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11858 rootObs == leafEnv11858) = true)

theorem terminalChecked11858 : H12PackedTerminal.terminalCheckFast leafEnv11858 active11858 tree11858 = true := by decide +kernel

def env11859 : List Nat := [2,4,8,16,0,16,8,4,30,1,21,16,8,21,1,2,4,20,1,0,1,0,16,2,8,17,20,5,16,21,0,1,4,0,20,30]

theorem envBound11859 : H12AffineFastState.Bounded env11859 := by
  intro p hp
  have h : env11859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11856_11859 : H12AffineEnvironment.transform 9 1 env11856 = env11859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env11856 == env11859) = true)

theorem identity11859 : scanCanonicalize (H12AffineFastState.compose env11859 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound11859 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11860 : List Nat := [1,4,8,16,0,16,8,4,29,1,21,16,8,21,1,1,4,20,1,0,1,0,16,1,8,17,20,5,16,21,0,1,4,0,20,29]

theorem envBound11860 : H12AffineFastState.Bounded env11860 := by
  intro p hp
  have h : env11860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11859_11860 : H12AffineEnvironment.transform 0 1 env11859 = env11860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env11859 == env11860) = true)

def leafEnv11860 : List Nat := [1,4,8,16,0,16,8,4,29,1,21,16,8,21,1,1,4,20,1,0,1,0,16,1,1,8,1,17,20,5,16,21,0,1,4,0,5,1,20,29,1,0,0]

def active11860 : List Nat := [1,2,3]

def tree11860 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11860 : H12WitnessSearch.Good tree11860 := H12GlobalWitnessIndex.good

theorem leafIdentity11860 : H12AffineFastState.composeSystem env11860 rootObs = leafEnv11860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11860 rootObs == leafEnv11860) = true)

theorem terminalChecked11860 : H12PackedTerminal.terminalCheckFast leafEnv11860 active11860 tree11860 = true := by decide +kernel

def env11861 : List Nat := [2,4,8,16,0,16,8,4,512,1024,523,17,8,1045,1,2,1028,522,1024,0,0,0,16,2,8,17,522,1029,17,523,1025,1,4,0,1044,512]

theorem envBound11861 : H12AffineFastState.Bounded env11861 := by
  intro p hp
  have h : env11861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11854_11861 : H12AffineEnvironment.transform 11 17 env11854 = env11861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env11854 == env11861) = true)

theorem identity11861 : scanCanonicalize (H12AffineFastState.compose env11861 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 523) := by decide +kernel

theorem selectedBound11861 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11862 : List Nat := [2,4,8,16,0,16,8,4,512,523,523,17,8,542,1,2,527,522,523,0,0,0,16,2,8,17,522,526,17,523,522,1,4,0,543,512]

theorem envBound11862 : H12AffineFastState.Bounded env11862 := by
  intro p hp
  have h : env11862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11861_11862 : H12AffineEnvironment.transform 9 523 env11861 = env11862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 523 env11861 == env11862) = true)

def env11863 : List Nat := [2,4,8,4,0,4,8,4,512,523,523,5,8,522,1,2,527,522,523,0,0,0,4,2,8,5,522,526,5,523,522,1,4,0,523,512]

theorem envBound11863 : H12AffineFastState.Bounded env11863 := by
  intro p hp
  have h : env11863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11862_11863 : H12AffineEnvironment.transform 3 4 env11862 = env11863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env11862 == env11863) = true)

theorem identity11863 : scanCanonicalize (H12AffineFastState.compose env11863 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound11863 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11864 : List Nat := [2,4,8,4,0,4,8,4,9,2,2,5,8,3,1,2,6,3,2,0,0,0,4,2,8,5,3,7,5,2,3,1,4,0,2,9]

theorem envBound11864 : H12AffineFastState.Bounded env11864 := by
  intro p hp
  have h : env11864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11863_11864 : H12AffineEnvironment.transform 8 9 env11863 = env11864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env11863 == env11864) = true)

def leafEnv11864 : List Nat := [2,4,8,4,0,4,8,4,9,2,2,5,8,3,1,2,6,3,2,0,0,0,4,2,2,8,1,5,3,7,5,2,3,1,4,0,5,2,2,9,1,1,0]

def active11864 : List Nat := [0,1,2]

def tree11864 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11864 : H12WitnessSearch.Good tree11864 := H12GlobalWitnessIndex.good

theorem leafIdentity11864 : H12AffineFastState.composeSystem env11864 rootObs = leafEnv11864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11864 rootObs == leafEnv11864) = true)

theorem terminalChecked11864 : H12PackedTerminal.terminalCheckFast leafEnv11864 active11864 tree11864 = true := by decide +kernel

def env11865 : List Nat := [2,4,8,5,0,5,8,4,512,523,523,4,8,523,1,2,527,522,523,0,0,0,5,2,8,4,522,526,4,523,522,1,4,0,522,512]

theorem envBound11865 : H12AffineFastState.Bounded env11865 := by
  intro p hp
  have h : env11865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11862_11865 : H12AffineEnvironment.transform 3 5 env11862 = env11865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env11862 == env11865) = true)

theorem identity11865 : scanCanonicalize (H12AffineFastState.compose env11865 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound11865 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11866 : List Nat := [1,4,8,5,0,5,8,4,512,520,520,4,8,520,1,1,524,521,520,0,0,0,5,1,8,4,521,525,4,520,521,1,4,0,521,512]

theorem envBound11866 : H12AffineFastState.Bounded env11866 := by
  intro p hp
  have h : env11866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11865_11866 : H12AffineEnvironment.transform 0 1 env11865 = env11866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env11865 == env11866) = true)

def leafEnv11866 : List Nat := [1,4,8,5,0,5,8,4,512,520,520,4,8,520,1,1,524,521,520,0,0,0,5,1,520,8,1,4,521,525,4,520,521,1,4,0,5,1,521,512,1,1,0]

def active11866 : List Nat := [1,2,8]

def tree11866 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11866 : H12WitnessSearch.Good tree11866 := H12GlobalWitnessIndex.good

theorem leafIdentity11866 : H12AffineFastState.composeSystem env11866 rootObs = leafEnv11866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11866 rootObs == leafEnv11866) = true)

theorem terminalChecked11866 : H12PackedTerminal.terminalCheckFast leafEnv11866 active11866 tree11866 = true := by decide +kernel

def env11867 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,130174,1024,32769,4161,62588,119878,21762,8193,65,75787,115014,102742,35188,1364,119926,256,21792,46093,74250]

theorem envBound11867 : H12AffineFastState.Bounded env11867 := by
  intro p hp
  have h : env11867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11845_11867 : H12AffineEnvironment.transform 6 9 env11845 = env11867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11845 == env11867) = true)

theorem identity11867 : scanCanonicalize (H12AffineFastState.compose env11867 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound11867 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11868 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,24909,67618,1024,29789,4161,32,73754,21762,8193,65,75787,79130,91402,32040,1364,73770,256,21792,16465,74250]

theorem envBound11868 : H12AffineFastState.Bounded env11868 := by
  intro p hp
  have h : env11868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11867_11868 : H12AffineEnvironment.transform 14 29788 env11867 = env11868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env11867 == env11868) = true)

theorem identity11868 : scanCanonicalize (H12AffineFastState.compose env11868 (packedSelected [0,1,2,6,7,8,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound11868 : packedSelected [0,1,2,6,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env11869 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8283,24909,10361,1024,29789,4161,32,65,21762,8193,65,2128,5441,17745,32040,1364,113,256,21792,16465,593]

theorem envBound11869 : H12AffineFastState.Bounded env11869 := by
  intro p hp
  have h : env11869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11868_11869 : H12AffineEnvironment.transform 15 8283 env11868 = env11869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env11868 == env11869) = true)

theorem identity11869 : scanCanonicalize (H12AffineFastState.compose env11869 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound11869 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env11870 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,80,8283,5441,10361,1024,81,4161,32,65,8462,8193,65,2128,5441,12637,2340,1364,113,256,8492,13405,593]

theorem envBound11870 : H12AffineFastState.Bounded env11870 := by
  intro p hp
  have h : env11870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11869_11870 : H12AffineEnvironment.transform 13 13324 env11869 = env11870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env11869 == env11870) = true)

theorem identity11870 : scanCanonicalize (H12AffineFastState.compose env11870 (packedSelected [2,3,4,5,6,7,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound11870 : packedSelected [2,3,4,5,6,7,11,12,14] rootPS < 2^1333 := by decide +kernel

def env11871 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2356,8192,11576,80,8283,3189,10361,1024,81,2421,32,65,8462,8193,65,2128,3189,10345,2340,1364,113,256,8492,11625,593]

theorem envBound11871 : H12AffineFastState.Bounded env11871 := by
  intro p hp
  have h : env11871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11870_11871 : H12AffineEnvironment.transform 11 2356 env11870 = env11871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env11870 == env11871) = true)

theorem identity11871 : scanCanonicalize (H12AffineFastState.compose env11871 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound11871 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env11872 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2356,41,3345,80,114,3189,2128,1024,81,2421,32,65,295,40,65,2128,3189,2112,2340,1364,113,256,261,3392,593]

theorem envBound11872 : H12AffineFastState.Bounded env11872 := by
  intro p hp
  have h : env11872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11871_11872 : H12AffineEnvironment.transform 12 41 env11871 = env11872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env11871 == env11872) = true)

theorem identity11872 : scanCanonicalize (H12AffineFastState.compose env11872 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11872 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env11873 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2356,41,3345,0,34,3109,2048,1024,1,2341,32,17,295,40,17,2048,3109,2064,2340,1284,33,256,261,3344,513]

theorem envBound11873 : H12AffineFastState.Bounded env11873 := by
  intro p hp
  have h : env11873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11872_11873 : H12AffineEnvironment.transform 5 16 env11872 = env11873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11872 == env11873) = true)

def env11874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,412157,2114882,8328,65,6409407,115150,2497708,35324,2590895,4268162,256,509971,469431,2535288]

theorem envBound11874 : H12AffineFastState.Bounded env11874 := by
  intro p hp
  have h : env11874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11783_11874 : H12AffineEnvironment.transform 22 412157 env11783 = env11874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 412157 env11783 == env11874) = true)

def env11875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262520,412157,2114882,8328,65,215367,115150,2497708,35324,2590895,2336122,256,509971,469431,2535288]

theorem envBound11875 : H12AffineFastState.Bounded env11875 := by
  intro p hp
  have h : env11875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11874_11875 : H12AffineEnvironment.transform 21 2262520 env11874 = env11875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262520 env11874 == env11875) = true)

def env11876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169400,412157,21762,8328,65,215367,115150,396524,35324,497903,243002,256,509971,469431,442168]

theorem envBound11876 : H12AffineFastState.Bounded env11876 := by
  intro p hp
  have h : env11876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11875_11876 : H12AffineEnvironment.transform 20 4160 env11875 = env11876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env11875 == env11876) = true)

theorem identity11876 : scanCanonicalize (H12AffineFastState.compose env11876 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179513) := by decide +kernel

theorem selectedBound11876 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,169400,62660,21762,8328,65,215367,115150,45525,35324,75222,243002,256,95530,103566,513]

theorem envBound11877 : H12AffineFastState.Bounded env11877 := by
  intro p hp
  have h : env11877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11876_11877 : H12AffineEnvironment.transform 17 179513 env11876 = env11877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env11876 == env11877) = true)

def env11878 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,169264,62540,21762,8192,65,215367,115014,45405,35188,75102,243002,256,95530,103430,513]

theorem envBound11878 : H12AffineFastState.Bounded env11878 := by
  intro p hp
  have h : env11878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11877_11878 : H12AffineEnvironment.transform 6 8 env11877 = env11878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11877 == env11878) = true)

theorem identity11878 : scanCanonicalize (H12AffineFastState.compose env11878 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound11878 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env11879 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,122146,1024,32769,4160,128299,62540,21762,8192,65,10588,115014,45405,35188,75102,54561,256,95530,103430,513]

theorem envBound11879 : H12AffineFastState.Bounded env11879 := by
  intro p hp
  have h : env11879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11878_11879 : H12AffineEnvironment.transform 16 90139 env11878 = env11879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env11878 == env11879) = true)

theorem identity11879 : scanCanonicalize (H12AffineFastState.compose env11879 (packedSelected [0,3,5,10,12,14,18,23,27,38] rootPS)) = affineNative (2^(14+1) ^^^ 20788) := by decide +kernel

theorem selectedBound11879 : packedSelected [0,3,5,10,12,14,18,23,27,38] rootPS < 2^1333 := by decide +kernel

def env11880 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,20788,65536,90139,68630,1024,20789,4160,74783,9592,21762,8192,65,10588,69746,24681,22592,75102,1045,256,95530,83250,513]

theorem envBound11880 : H12AffineFastState.Bounded env11880 := by
  intro p hp
  have h : env11880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11879_11880 : H12AffineEnvironment.transform 14 20788 env11879 = env11880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20788 env11879 == env11880) = true)

theorem identity11880 : scanCanonicalize (H12AffineFastState.compose env11880 (packedSelected [7,8,10,14,17,20,23,27,28,32] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound11880 : packedSelected [7,8,10,14,17,20,23,27,28,32] rootPS < 2^1333 := by decide +kernel

def env11881 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,16384,20788,65536,90139,67847,273,20789,4160,73998,8297,20499,8192,65,10588,69746,24681,22592,73807,260,256,94267,81955,513]

theorem envBound11881 : H12AffineFastState.Bounded env11881 := by
  intro p hp
  have h : env11881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11880_11881 : H12AffineEnvironment.transform 9 273 env11880 = env11881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env11880 == env11881) = true)

theorem identity11881 : scanCanonicalize (H12AffineFastState.compose env11881 (packedSelected [1,2,3,4,6,9,11,12,14,20,23,24,28,41] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound11881 : packedSelected [1,2,3,4,6,9,11,12,14,20,23,24,28,41] rootPS < 2^1333 := by decide +kernel

def env11882 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,40,16384,20788,65536,81971,67847,273,20789,4160,65830,65,20499,40,65,2420,69746,16449,22592,65639,260,256,86035,81955,513]

theorem envBound11882 : H12AffineFastState.Bounded env11882 := by
  intro p hp
  have h : env11882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11881_11882 : H12AffineEnvironment.transform 12 40 env11881 = env11882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env11881 == env11882) = true)

theorem identity11882 : scanCanonicalize (H12AffineFastState.compose env11882 (packedSelected [2,3,5,6,10,17] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound11882 : packedSelected [2,3,5,6,10,17] rootPS < 2^1333 := by decide +kernel

def env11883 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,40,16384,20788,114,16449,2421,273,20789,4160,340,65,20499,40,65,2420,4096,16449,22592,21,260,256,20577,16465,513]

theorem envBound11883 : H12AffineFastState.Bounded env11883 := by
  intro p hp
  have h : env11883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11882_11883 : H12AffineEnvironment.transform 15 114 env11882 = env11883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env11882 == env11883) = true)

theorem identity11883 : scanCanonicalize (H12AffineFastState.compose env11883 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11883 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11884 : List Nat := [2,4,8,16,32,64,8,37,512,52,2048,4096,40,16384,20497,114,16449,2128,52,20496,4160,113,65,20499,40,65,2129,4096,16449,22592,21,33,37,20577,16465,513]

theorem envBound11884 : H12AffineFastState.Bounded env11884 := by
  intro p hp
  have h : env11884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11883_11884 : H12AffineEnvironment.transform 7 37 env11883 = env11884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11883 == env11884) = true)

theorem identity11884 : scanCanonicalize (H12AffineFastState.compose env11884 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11884 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11885 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,4096,40,16384,20497,34,16401,2048,52,20496,4112,33,17,20499,40,17,2049,4096,16401,22544,21,33,37,20529,16385,513]

theorem envBound11885 : H12AffineFastState.Bounded env11885 := by
  intro p hp
  have h : env11885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11884_11885 : H12AffineEnvironment.transform 5 16 env11884 = env11885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11884 == env11885) = true)

theorem identity11885 : scanCanonicalize (H12AffineFastState.compose env11885 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound11885 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11886 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,4096,40,4113,0,34,4096,2048,52,1,4112,33,17,2,40,17,2049,4096,4096,2049,21,33,37,32,4112,513]

theorem envBound11886 : H12AffineFastState.Bounded env11886 := by
  intro p hp
  have h : env11886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11885_11886 : H12AffineEnvironment.transform 13 4113 env11885 = env11886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env11885 == env11886) = true)

theorem identity11886 : scanCanonicalize (H12AffineFastState.compose env11886 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound11886 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11887 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,513,40,528,0,34,513,2048,52,1,529,33,17,2,40,17,2049,513,513,2049,21,33,37,32,529,513]

theorem envBound11887 : H12AffineFastState.Bounded env11887 := by
  intro p hp
  have h : env11887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11886_11887 : H12AffineEnvironment.transform 11 513 env11886 = env11887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env11886 == env11887) = true)

theorem identity11887 : scanCanonicalize (H12AffineFastState.compose env11887 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound11887 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11888 : List Nat := [2,4,8,16,32,16,8,37,512,52,10,513,40,528,0,34,513,10,52,1,529,33,17,2,40,17,11,513,513,11,21,33,37,32,529,513]

theorem envBound11888 : H12AffineFastState.Bounded env11888 := by
  intro p hp
  have h : env11888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11887_11888 : H12AffineEnvironment.transform 10 10 env11887 = env11888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env11887 == env11888) = true)

theorem identity11888 : scanCanonicalize (H12AffineFastState.compose env11888 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound11888 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env11889 : List Nat := [2,4,8,16,32,16,8,37,27,52,10,26,40,11,0,34,26,10,52,1,10,33,17,2,40,17,11,26,26,11,21,33,37,32,10,26]

theorem envBound11889 : H12AffineFastState.Bounded env11889 := by
  intro p hp
  have h : env11889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11888_11889 : H12AffineEnvironment.transform 8 27 env11888 = env11889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env11888 == env11889) = true)

def env11890 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,169265,62541,21762,8193,65,215367,115015,45404,35189,75103,243002,256,95530,103431,513]

theorem envBound11890 : H12AffineFastState.Bounded env11890 := by
  intro p hp
  have h : env11890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11877_11890 : H12AffineEnvironment.transform 6 9 env11877 = env11890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11877 == env11890) = true)

theorem identity11890 : scanCanonicalize (H12AffineFastState.compose env11890 (packedSelected [4,7,9,11,12,15,17,27,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound11890 : packedSelected [4,7,9,11,12,15,17,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env11891 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1024,32769,4160,33,62541,21762,8193,65,121943,115015,45404,35189,75103,73770,256,95530,103431,513]

theorem envBound11891 : H12AffineFastState.Bounded env11891 := by
  intro p hp
  have h : env11891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11890_11891 : H12AffineEnvironment.transform 16 38160 env11890 = env11891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env11890 == env11891) = true)

theorem identity11891 : scanCanonicalize (H12AffineFastState.compose env11891 (packedSelected [1,2,3,4,5,6,8,9,11,12,14,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound11891 : packedSelected [1,2,3,4,5,6,8,9,11,12,14,18,20] rootPS < 2^1333 := by decide +kernel

def env11892 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,80,65536,5440,10281,1024,81,4160,33,29725,21762,8193,65,89095,82199,12556,2341,75103,73770,256,95530,70743,513]

theorem envBound11892 : H12AffineFastState.Bounded env11892 := by
  intro p hp
  have h : env11892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11891_11892 : H12AffineEnvironment.transform 14 80 env11891 = env11892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env11891 == env11892) = true)

theorem identity11892 : scanCanonicalize (H12AffineFastState.compose env11892 (packedSelected [1,2,3,4,5,6,8,9,12,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound11892 : packedSelected [1,2,3,4,5,6,8,9,12,14,16] rootPS < 2^1333 := by decide +kernel

def env11893 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,80,21510,5440,10281,1024,81,4160,33,29725,21762,8193,65,2049,5393,12556,2341,29017,29740,256,8492,16465,513]

theorem envBound11893 : H12AffineFastState.Bounded env11893 := by
  intro p hp
  have h : env11893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11892_11893 : H12AffineEnvironment.transform 15 21510 env11892 = env11893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env11892 == env11893) = true)

theorem identity11893 : scanCanonicalize (H12AffineFastState.compose env11893 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11893 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env11894 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,0,21510,5392,10281,1024,1,4112,33,29725,21762,8193,17,2049,5393,12556,2341,28937,29740,256,8492,16385,513]

theorem envBound11894 : H12AffineFastState.Bounded env11894 := by
  intro p hp
  have h : env11894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11893_11894 : H12AffineEnvironment.transform 5 16 env11893 = env11894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11893 == env11894) = true)

theorem identity11894 : scanCanonicalize (H12AffineFastState.compose env11894 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound11894 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env11895 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,0,8203,5392,10281,1024,1,4112,33,16,8463,8193,17,2049,5393,12556,2341,1284,33,256,8492,13324,513]

theorem envBound11895 : H12AffineFastState.Bounded env11895 := by
  intro p hp
  have h : env11895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11894_11895 : H12AffineEnvironment.transform 13 13325 env11894 = env11895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env11894 == env11895) = true)

theorem identity11895 : scanCanonicalize (H12AffineFastState.compose env11895 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound11895 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env11896 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1589,8192,8760,0,8203,805,10281,1024,1,1573,33,16,8463,8193,17,2049,804,10041,2341,1284,33,256,8492,8761,513]

theorem envBound11896 : H12AffineFastState.Bounded env11896 := by
  intro p hp
  have h : env11896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11895_11896 : H12AffineEnvironment.transform 11 1589 env11895 = env11896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env11895 == env11896) = true)

theorem identity11896 : scanCanonicalize (H12AffineFastState.compose env11896 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound11896 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11897 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1589,268,820,0,263,805,2341,1024,1,1573,33,16,3,269,17,2049,804,1589,2341,1284,33,256,32,821,513]

theorem envBound11897 : H12AffineFastState.Bounded env11897 := by
  intro p hp
  have h : env11897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11896_11897 : H12AffineEnvironment.transform 12 268 env11896 = env11897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env11896 == env11897) = true)

theorem identity11897 : scanCanonicalize (H12AffineFastState.compose env11897 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound11897 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11898 : List Nat := [2,4,8,16,32,16,9,20,512,1024,2048,1589,24,544,0,19,561,2097,1024,1,1573,33,16,3,25,17,2049,560,1589,2097,1040,33,20,32,545,513]

theorem envBound11898 : H12AffineFastState.Bounded env11898 := by
  intro p hp
  have h : env11898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11897_11898 : H12AffineEnvironment.transform 7 20 env11897 = env11898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env11897 == env11898) = true)

theorem identity11898 : scanCanonicalize (H12AffineFastState.compose env11898 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound11898 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11899 : List Nat := [2,4,8,16,32,16,9,20,512,1024,538,1589,24,544,0,19,561,555,1024,1,1573,33,16,3,25,17,539,560,1589,555,1040,33,20,32,545,513]

theorem envBound11899 : H12AffineFastState.Bounded env11899 := by
  intro p hp
  have h : env11899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11898_11899 : H12AffineEnvironment.transform 10 538 env11898 = env11899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env11898 == env11899) = true)

theorem identity11899 : scanCanonicalize (H12AffineFastState.compose env11899 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound11899 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11900 : List Nat := [2,4,8,16,32,16,9,20,16,1024,10,1061,24,48,0,19,33,59,1024,1,1077,33,16,3,25,17,11,32,1061,59,1040,33,20,32,49,17]

theorem envBound11900 : H12AffineFastState.Bounded env11900 := by
  intro p hp
  have h : env11900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11899_11900 : H12AffineEnvironment.transform 8 16 env11899 = env11900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env11899 == env11900) = true)

theorem identity11900 : scanCanonicalize (H12AffineFastState.compose env11900 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound11900 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env11901 : List Nat := [2,4,8,16,32,16,9,20,16,14,10,43,24,48,0,19,33,59,14,1,59,33,16,3,25,17,11,32,43,59,30,33,20,32,49,17]

theorem envBound11901 : H12AffineFastState.Bounded env11901 := by
  intro p hp
  have h : env11901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11900_11901 : H12AffineEnvironment.transform 9 14 env11900 = env11901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env11900 == env11901) = true)

theorem identity11901 : scanCanonicalize (H12AffineFastState.compose env11901 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound11901 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11902 : List Nat := [2,4,8,16,10,16,9,20,16,14,10,1,24,26,0,19,11,17,14,1,17,11,16,3,25,17,11,10,1,17,30,11,20,10,27,17]

theorem envBound11902 : H12AffineFastState.Bounded env11902 := by
  intro p hp
  have h : env11902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11901_11902 : H12AffineEnvironment.transform 4 10 env11901 = env11902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env11901 == env11902) = true)

theorem identity11902 : scanCanonicalize (H12AffineFastState.compose env11902 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound11902 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11903 : List Nat := [2,4,6,16,4,16,7,20,16,0,4,1,22,20,0,19,5,17,0,1,17,5,16,3,23,17,5,4,1,17,16,5,20,4,21,17]

theorem envBound11903 : H12AffineFastState.Bounded env11903 := by
  intro p hp
  have h : env11903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11902_11903 : H12AffineEnvironment.transform 2 6 env11902 = env11903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env11902 == env11903) = true)

theorem identity11903 : scanCanonicalize (H12AffineFastState.compose env11903 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound11903 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11904 : List Nat := [2,4,6,7,4,7,7,3,7,0,4,1,1,3,0,4,5,6,0,1,6,5,7,3,0,6,5,4,1,6,7,5,3,4,2,6]

theorem envBound11904 : H12AffineFastState.Bounded env11904 := by
  intro p hp
  have h : env11904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11903_11904 : H12AffineEnvironment.transform 3 7 env11903 = env11904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env11903 == env11904) = true)

theorem identity11904 : scanCanonicalize (H12AffineFastState.compose env11904 (packedSelected [9] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound11904 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env11905 : List Nat := [2,0,2,3,0,3,3,3,3,0,0,1,1,3,0,0,1,2,0,1,2,1,3,3,0,2,1,0,1,2,3,1,3,0,2,2]

theorem envBound11905 : H12AffineFastState.Bounded env11905 := by
  intro p hp
  have h : env11905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11904_11905 : H12AffineEnvironment.transform 1 0 env11904 = env11905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env11904 == env11905) = true)

def env11906 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169401,412157,21763,8328,65,215367,115150,396525,35324,497902,243003,256,509971,469431,442169]

theorem envBound11906 : H12AffineFastState.Bounded env11906 := by
  intro p hp
  have h : env11906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11875_11906 : H12AffineEnvironment.transform 20 4161 env11875 = env11906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env11875 == env11906) = true)

def env11907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,169401,156117,21763,8328,65,215367,115150,140485,35324,241862,243003,256,254011,197023,169745]

theorem envBound11907 : H12AffineFastState.Bounded env11907 := by
  intro p hp
  have h : env11907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11906_11907 : H12AffineEnvironment.transform 17 10280 env11906 = env11907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env11906 == env11907) = true)

def env11908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,4161,21929,41413,21763,8328,65,100695,115150,58581,35324,94422,95531,256,73771,115087,22273]

theorem envBound11908 : H12AffineFastState.Bounded env11908 := by
  intro p hp
  have h : env11908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11907_11908 : H12AffineEnvironment.transform 16 49168 env11907 = env11908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env11907 == env11908) = true)

theorem identity11908 : scanCanonicalize (H12AffineFastState.compose env11908 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound11908 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,13389,10280,1024,29788,4161,21929,21912,21763,8328,65,97546,79251,4232,32161,94422,95531,256,73771,79314,22273]

theorem envBound11909 : H12AffineFastState.Bounded env11909 := by
  intro p hp
  have h : env11909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11908_11909 : H12AffineEnvironment.transform 14 29789 env11908 = env11909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env11908 == env11909) = true)

theorem identity11909 : scanCanonicalize (H12AffineFastState.compose env11909 (packedSelected [0,1,4,7,8,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 1221) := by decide +kernel

theorem selectedBound11909 : packedSelected [0,1,4,7,8,19,22] rootPS < 2^1333 := by decide +kernel

def env11910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1221,16384,20632,65536,4232,3309,1024,20633,4161,21929,21912,21763,1101,65,88527,69974,4232,22884,87059,86510,256,66798,69911,22273]

theorem envBound11910 : H12AffineFastState.Bounded env11910 := by
  intro p hp
  have h : env11910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11909_11910 : H12AffineEnvironment.transform 12 1221 env11909 = env11910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1221 env11909 == env11910) = true)

theorem identity11910 : scanCanonicalize (H12AffineFastState.compose env11910 (packedSelected [1,3,4,5,7,9,19,27,28] rootPS)) = affineNative (2^(9+1) ^^^ 456) := by decide +kernel

theorem selectedBound11910 : packedSelected [1,3,4,5,7,9,19,27,28] rootPS < 2^1333 := by decide +kernel

def env11911 : List Nat := [2,4,8,16,32,64,128,256,512,456,2048,4096,269,16384,20632,65536,4232,2341,456,20633,4161,20577,20560,20683,389,65,88527,69974,4232,22884,86491,86510,256,65830,69911,21193]

theorem envBound11911 : H12AffineFastState.Bounded env11911 := by
  intro p hp
  have h : env11911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11910_11911 : H12AffineEnvironment.transform 9 456 env11910 = env11911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 456 env11910 == env11911) = true)

theorem identity11911 : scanCanonicalize (H12AffineFastState.compose env11911 (packedSelected [0,1,2,3,6,7,8,10,16,24] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound11911 : packedSelected [0,1,2,3,6,7,8,10,16,24] rootPS < 2^1333 := by decide +kernel

def env11912 : List Nat := [2,4,8,16,32,64,128,256,512,456,2048,4096,269,16384,20632,398,4232,2341,456,20633,4161,20577,20560,20683,389,65,22593,4312,4232,22884,20565,20576,256,168,4249,21193]

theorem envBound11912 : H12AffineFastState.Bounded env11912 := by
  intro p hp
  have h : env11912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11911_11912 : H12AffineEnvironment.transform 15 398 env11911 = env11912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env11911 == env11912) = true)

theorem identity11912 : scanCanonicalize (H12AffineFastState.compose env11912 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11912 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11913 : List Nat := [2,4,8,16,32,16,128,256,512,408,2048,4096,269,16384,20632,398,4232,2341,408,20633,4113,20529,20480,20635,389,17,22545,4232,4232,22836,20485,20528,256,168,4249,21145]

theorem envBound11913 : H12AffineFastState.Bounded env11913 := by
  intro p hp
  have h : env11913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11912_11913 : H12AffineEnvironment.transform 5 16 env11912 = env11913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11912 == env11913) = true)

theorem identity11913 : scanCanonicalize (H12AffineFastState.compose env11913 (packedSelected [2,3,5,12] rootPS)) = affineNative (2^(13+1) ^^^ 4264) := by decide +kernel

theorem selectedBound11913 : packedSelected [2,3,5,12] rootPS < 2^1333 := by decide +kernel

def env11914 : List Nat := [2,4,8,16,32,16,128,256,512,408,2048,4096,269,4264,48,398,4232,2341,408,49,4113,153,168,51,389,17,2233,4232,4232,2460,173,152,256,168,4249,561]

theorem envBound11914 : H12AffineFastState.Bounded env11914 := by
  intro p hp
  have h : env11914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11913_11914 : H12AffineEnvironment.transform 13 4264 env11913 = env11914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4264 env11913 == env11914) = true)

theorem identity11914 : scanCanonicalize (H12AffineFastState.compose env11914 (packedSelected [0,2,3,4,5,6,7,9,11,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 2460) := by decide +kernel

theorem selectedBound11914 : packedSelected [0,2,3,4,5,6,7,9,11,14,15] rootPS < 2^1333 := by decide +kernel

def env11915 : List Nat := [2,4,8,16,32,16,128,256,512,408,2048,2460,269,2356,48,398,2324,2341,408,49,2445,153,168,51,389,17,2233,2324,2324,2460,173,152,256,168,2309,561]

theorem envBound11915 : H12AffineFastState.Bounded env11915 := by
  intro p hp
  have h : env11915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11914_11915 : H12AffineEnvironment.transform 11 2460 env11914 = env11915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2460 env11914 == env11915) = true)

theorem identity11915 : scanCanonicalize (H12AffineFastState.compose env11915 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound11915 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env11916 : List Nat := [2,4,8,16,32,16,128,157,512,5,2048,2049,144,2217,48,19,2185,2232,5,49,2064,153,168,51,24,17,2233,2185,2185,2049,173,152,157,168,2200,561]

theorem envBound11916 : H12AffineFastState.Bounded env11916 := by
  intro p hp
  have h : env11916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11915_11916 : H12AffineEnvironment.transform 7 157 env11915 = env11916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env11915 == env11916) = true)

theorem identity11916 : scanCanonicalize (H12AffineFastState.compose env11916 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound11916 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env11917 : List Nat := [2,4,8,16,32,16,24,5,512,5,2048,2049,8,2097,48,19,2065,2080,5,49,2064,1,48,51,24,17,2081,2065,2065,2049,53,0,5,48,2048,561]

theorem envBound11917 : H12AffineFastState.Bounded env11917 := by
  intro p hp
  have h : env11917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11916_11917 : H12AffineEnvironment.transform 6 24 env11916 = env11917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env11916 == env11917) = true)

theorem identity11917 : scanCanonicalize (H12AffineFastState.compose env11917 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11917 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env11918 : List Nat := [2,4,8,16,1,16,24,5,512,5,2048,2049,8,2064,17,19,2065,2049,5,16,2064,1,17,18,24,17,2048,2065,2065,2049,20,0,5,17,2048,528]

theorem envBound11918 : H12AffineFastState.Bounded env11918 := by
  intro p hp
  have h : env11918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11917_11918 : H12AffineEnvironment.transform 4 1 env11917 = env11918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11917 == env11918) = true)

theorem identity11918 : scanCanonicalize (H12AffineFastState.compose env11918 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound11918 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env11919 : List Nat := [2,4,8,16,1,16,24,5,512,5,0,1,8,16,17,19,17,1,5,16,16,1,17,18,24,17,0,17,17,1,20,0,5,17,0,528]

theorem envBound11919 : H12AffineFastState.Bounded env11919 := by
  intro p hp
  have h : env11919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11918_11919 : H12AffineEnvironment.transform 10 0 env11918 = env11919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env11918 == env11919) = true)

theorem identity11919 : scanCanonicalize (H12AffineFastState.compose env11919 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound11919 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env11920 : List Nat := [2,4,8,1,1,1,9,5,512,5,0,1,8,1,0,2,0,1,5,1,1,1,0,3,9,0,0,0,0,1,5,0,5,0,0,513]

theorem envBound11920 : H12AffineFastState.Bounded env11920 := by
  intro p hp
  have h : env11920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11919_11920 : H12AffineEnvironment.transform 3 1 env11919 = env11920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env11919 == env11920) = true)

theorem identity11920 : scanCanonicalize (H12AffineFastState.compose env11920 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound11920 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11921 : List Nat := [2,0,8,1,1,1,9,1,512,1,0,1,8,1,0,2,0,1,1,1,1,1,0,3,9,0,0,0,0,1,1,0,1,0,0,513]

theorem envBound11921 : H12AffineFastState.Bounded env11921 := by
  intro p hp
  have h : env11921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11920_11921 : H12AffineEnvironment.transform 1 0 env11920 = env11921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env11920 == env11921) = true)

theorem identity11921 : scanCanonicalize (H12AffineFastState.compose env11921 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound11921 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11922 : List Nat := [2,0,8,1,1,1,9,1,8,1,0,1,8,1,0,2,0,1,1,1,1,1,0,3,9,0,0,0,0,1,1,0,1,0,0,9]

theorem envBound11922 : H12AffineFastState.Bounded env11922 := by
  intro p hp
  have h : env11922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11921_11922 : H12AffineEnvironment.transform 8 8 env11921 = env11922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env11921 == env11922) = true)

theorem identity11922 : scanCanonicalize (H12AffineFastState.compose env11922 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound11922 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11923 : List Nat := [2,0,2,1,1,1,3,1,2,1,0,1,2,1,0,2,0,1,1,1,1,1,0,3,3,0,0,0,0,1,1,0,1,0,0,3]

theorem envBound11923 : H12AffineFastState.Bounded env11923 := by
  intro p hp
  have h : env11923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11922_11923 : H12AffineEnvironment.transform 2 2 env11922 = env11923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env11922 == env11923) = true)

def env11924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,4161,21928,41412,21763,8328,65,100694,115150,58580,35324,94423,95530,256,73770,115086,22272]

theorem envBound11924 : H12AffineFastState.Bounded env11924 := by
  intro p hp
  have h : env11924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11907_11924 : H12AffineEnvironment.transform 16 49169 env11907 = env11924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env11907 == env11924) = true)

theorem identity11924 : scanCanonicalize (H12AffineFastState.compose env11924 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound11924 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,13509,10280,1024,29909,4161,21928,21776,21763,8328,65,97666,79130,4096,32040,94423,95530,256,73770,79194,22272]

theorem envBound11925 : H12AffineFastState.Bounded env11925 := by
  intro p hp
  have h : env11925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11924_11925 : H12AffineEnvironment.transform 14 29908 env11924 = env11925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env11924 == env11925) = true)

theorem identity11925 : scanCanonicalize (H12AffineFastState.compose env11925 (packedSelected [0,1,2,4,5,6,8,9,11,18,20,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound11925 : packedSelected [0,1,2,4,5,6,8,9,11,18,20,24,27] rootPS < 2^1333 := by decide +kernel

def env11926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,121,16384,21677,65536,5308,2129,1024,21676,4161,21928,21776,21763,241,65,89595,71011,4096,23889,86190,87379,256,65619,70947,22272]

theorem envBound11926 : H12AffineFastState.Bounded env11926 := by
  intro p hp
  have h : env11926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11925_11926 : H12AffineEnvironment.transform 12 121 env11925 = env11926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env11925 == env11926) = true)

theorem identity11926 : scanCanonicalize (H12AffineFastState.compose env11926 (packedSelected [1,2,3,6,8,9,10,11,12,14,15,18,19,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound11926 : packedSelected [1,2,3,6,8,9,10,11,12,14,15,18,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env11927 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,121,5377,428,65536,5308,2129,1024,429,4161,169,17,2,241,65,67834,71011,4096,2128,66991,65618,256,65619,70947,513]

theorem envBound11927 : H12AffineFastState.Bounded env11927 := by
  intro p hp
  have h : env11927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11926_11927 : H12AffineEnvironment.transform 13 5377 env11926 = env11927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env11926 == env11927) = true)

theorem identity11927 : scanCanonicalize (H12AffineFastState.compose env11927 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound11927 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env11928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,121,5377,428,479,5308,2129,1024,429,4161,169,17,2,241,65,2341,5308,4096,2128,1136,397,256,396,5372,513]

theorem envBound11928 : H12AffineFastState.Bounded env11928 := by
  intro p hp
  have h : env11928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11927_11928 : H12AffineEnvironment.transform 15 479 env11927 = env11928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env11927 == env11928) = true)

theorem identity11928 : scanCanonicalize (H12AffineFastState.compose env11928 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound11928 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env11929 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,5377,292,343,5172,2129,1024,293,4161,33,17,2,121,65,2341,5172,4096,2128,1136,261,256,260,5236,513]

theorem envBound11929 : H12AffineFastState.Bounded env11929 := by
  intro p hp
  have h : env11929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11928_11929 : H12AffineEnvironment.transform 6 8 env11928 = env11929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11928 == env11929) = true)

theorem identity11929 : scanCanonicalize (H12AffineFastState.compose env11929 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound11929 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11930 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,121,4113,292,343,4388,2129,272,293,4161,33,17,2,121,65,2341,4388,4096,2128,352,261,256,260,4452,513]

theorem envBound11930 : H12AffineFastState.Bounded env11930 := by
  intro p hp
  have h : env11930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11929_11930 : H12AffineEnvironment.transform 9 272 env11929 = env11930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env11929 == env11930) = true)

theorem identity11930 : scanCanonicalize (H12AffineFastState.compose env11930 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11930 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env11931 : List Nat := [2,4,8,16,32,64,8,36,512,52,2048,4096,121,4113,0,115,4096,2129,52,1,4161,33,17,2,121,65,2049,4096,4096,2128,68,33,36,32,4160,513]

theorem envBound11931 : H12AffineFastState.Bounded env11931 := by
  intro p hp
  have h : env11931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11930_11931 : H12AffineEnvironment.transform 7 36 env11930 = env11931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11930 == env11931) = true)

theorem identity11931 : scanCanonicalize (H12AffineFastState.compose env11931 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11931 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11932 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,4096,41,4113,0,35,4096,2049,52,1,4113,33,17,2,41,17,2049,4096,4096,2048,20,33,36,32,4112,513]

theorem envBound11932 : H12AffineFastState.Bounded env11932 := by
  intro p hp
  have h : env11932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11931_11932 : H12AffineEnvironment.transform 5 16 env11931 = env11932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11931 == env11932) = true)

theorem identity11932 : scanCanonicalize (H12AffineFastState.compose env11932 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound11932 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11933 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,2064,41,2049,0,35,2064,2049,52,1,2049,33,17,2,41,17,2049,2064,2064,2048,20,33,36,32,2048,513]

theorem envBound11933 : H12AffineFastState.Bounded env11933 := by
  intro p hp
  have h : env11933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11932_11933 : H12AffineEnvironment.transform 11 2064 env11932 = env11933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env11932 == env11933) = true)

theorem identity11933 : scanCanonicalize (H12AffineFastState.compose env11933 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound11933 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11934 : List Nat := [2,4,8,16,32,16,8,36,26,52,2048,2064,41,2049,0,35,2064,2049,52,1,2049,33,17,2,41,17,2049,2064,2064,2048,20,33,36,32,2048,27]

theorem envBound11934 : H12AffineFastState.Bounded env11934 := by
  intro p hp
  have h : env11934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11933_11934 : H12AffineEnvironment.transform 8 26 env11933 = env11934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env11933 == env11934) = true)

def env11935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,169401,156116,21763,8328,65,215367,115150,140484,35324,241863,243003,256,254010,197022,169744]

theorem envBound11935 : H12AffineFastState.Bounded env11935 := by
  intro p hp
  have h : env11935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11906_11935 : H12AffineEnvironment.transform 17 10281 env11906 = env11935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env11906 == env11935) = true)

def env11936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1024,32769,4161,21929,41412,21763,8328,65,100695,115150,58580,35324,94423,95531,256,73770,115086,22272]

theorem envBound11936 : H12AffineFastState.Bounded env11936 := by
  intro p hp
  have h : env11936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11935_11936 : H12AffineEnvironment.transform 16 49168 env11935 = env11936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env11935 == env11936) = true)

theorem identity11936 : scanCanonicalize (H12AffineFastState.compose env11936 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound11936 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,38161,10281,1024,32769,4161,168,41412,2,8328,65,100695,103631,45525,35324,75222,73770,256,73770,103567,513]

theorem envBound11937 : H12AffineFastState.Bounded env11937 := by
  intro p hp
  have h : env11937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11936_11937 : H12AffineEnvironment.transform 13 5377 env11936 = env11937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env11936 == env11937) = true)

theorem identity11937 : scanCanonicalize (H12AffineFastState.compose env11937 (packedSelected [0,1,5,7,8,11,16,18,24] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound11937 : packedSelected [0,1,5,7,8,11,16,18,24] rootPS < 2^1333 := by decide +kernel

def env11938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,262,38161,10281,1024,32769,4161,168,41412,2,8328,65,34897,38345,45525,35324,9424,8492,256,8492,38281,513]

theorem envBound11938 : H12AffineFastState.Bounded env11938 := by
  intro p hp
  have h : env11938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11937_11938 : H12AffineEnvironment.transform 15 262 env11937 = env11938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env11937 == env11938) = true)

theorem identity11938 : scanCanonicalize (H12AffineFastState.compose env11938 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,16,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound11938 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,16,18,20] rootPS < 2^1333 := by decide +kernel

def env11939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,262,13508,10281,1024,8660,4161,168,17,2,8328,65,10628,13340,4096,10281,9424,8492,256,8492,13404,513]

theorem envBound11939 : H12AffineFastState.Bounded env11939 := by
  intro p hp
  have h : env11939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11938_11939 : H12AffineEnvironment.transform 14 8661 env11938 = env11939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env11938 == env11939) = true)

theorem identity11939 : scanCanonicalize (H12AffineFastState.compose env11939 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound11939 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env11940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,137,262,5528,2421,1024,136,4161,168,17,2,468,65,2264,5440,4096,2421,1420,112,256,112,5376,513]

theorem envBound11940 : H12AffineFastState.Bounded env11940 := by
  intro p hp
  have h : env11940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11939_11940 : H12AffineEnvironment.transform 12 348 env11939 = env11940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env11939 == env11940) = true)

theorem identity11940 : scanCanonicalize (H12AffineFastState.compose env11940 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound11940 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11941 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,348,5377,80,262,5441,2421,1024,81,4161,113,17,2,269,65,2049,5440,4096,2421,1365,112,256,112,5376,513]

theorem envBound11941 : H12AffineFastState.Bounded env11941 := by
  intro p hp
  have h : env11941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11940_11941 : H12AffineEnvironment.transform 6 89 env11940 = env11941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env11940 == env11941) = true)

theorem identity11941 : scanCanonicalize (H12AffineFastState.compose env11941 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound11941 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env11942 : List Nat := [2,4,8,16,32,64,89,110,512,1024,2048,4096,50,5231,80,104,5167,2075,1024,81,4161,113,17,2,99,65,2049,5166,4096,2075,1083,112,110,112,5230,513]

theorem envBound11942 : H12AffineFastState.Bounded env11942 := by
  intro p hp
  have h : env11942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11941_11942 : H12AffineEnvironment.transform 7 110 env11941 = env11942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env11941 == env11942) = true)

theorem identity11942 : scanCanonicalize (H12AffineFastState.compose env11942 (packedSelected [11] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound11942 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env11943 : List Nat := [2,4,8,16,32,64,89,110,512,1024,1125,4096,50,5231,80,104,5167,1150,1024,81,4161,113,17,2,99,65,1124,5166,4096,1150,1083,112,110,112,5230,513]

theorem envBound11943 : H12AffineFastState.Bounded env11943 := by
  intro p hp
  have h : env11943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11942_11943 : H12AffineEnvironment.transform 10 1125 env11942 = env11943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env11942 == env11943) = true)

theorem identity11943 : scanCanonicalize (H12AffineFastState.compose env11943 (packedSelected [0,3,5,7,12] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound11943 : packedSelected [0,3,5,7,12] rootPS < 2^1333 := by decide +kernel

def env11944 : List Nat := [2,4,8,16,32,64,89,110,512,1024,1125,1044,50,123,80,104,59,1150,1024,81,1109,113,17,2,99,65,1124,58,1044,1150,1083,112,110,112,122,513]

theorem envBound11944 : H12AffineFastState.Bounded env11944 := by
  intro p hp
  have h : env11944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11943_11944 : H12AffineEnvironment.transform 11 1044 env11943 = env11944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env11943 == env11944) = true)

theorem identity11944 : scanCanonicalize (H12AffineFastState.compose env11944 (packedSelected [1,2,5,7,9] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound11944 : packedSelected [1,2,5,7,9] rootPS < 2^1333 := by decide +kernel

def env11945 : List Nat := [2,4,3,16,32,64,82,101,512,1024,1125,1044,50,112,80,99,48,1141,1024,81,1109,113,17,2,99,65,1124,49,1044,1141,1072,112,101,112,113,513]

theorem envBound11945 : H12AffineFastState.Bounded env11945 := by
  intro p hp
  have h : env11945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11944_11945 : H12AffineEnvironment.transform 2 3 env11944 = env11945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env11944 == env11945) = true)

theorem identity11945 : scanCanonicalize (H12AffineFastState.compose env11945 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound11945 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env11946 : List Nat := [2,4,3,16,32,0,18,37,512,1024,1061,1044,50,48,16,35,48,1077,1024,17,1045,49,17,2,35,1,1060,49,1044,1077,1072,48,37,48,49,513]

theorem envBound11946 : H12AffineFastState.Bounded env11946 := by
  intro p hp
  have h : env11946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11945_11946 : H12AffineEnvironment.transform 5 0 env11945 = env11946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env11945 == env11946) = true)

theorem identity11946 : scanCanonicalize (H12AffineFastState.compose env11946 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 16) := by decide +kernel

theorem selectedBound11946 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env11947 : List Nat := [2,4,3,16,32,0,18,37,512,16,53,4,50,48,16,35,48,37,16,17,5,49,17,2,35,1,52,49,4,37,32,48,37,48,49,513]

theorem envBound11947 : H12AffineFastState.Bounded env11947 := by
  intro p hp
  have h : env11947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11946_11947 : H12AffineEnvironment.transform 9 16 env11946 = env11947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 16 env11946 == env11947) = true)

theorem identity11947 : scanCanonicalize (H12AffineFastState.compose env11947 (packedSelected [1,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound11947 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env11948 : List Nat := [2,4,3,16,16,0,18,21,512,16,5,4,2,0,16,19,0,21,16,17,5,1,17,2,19,1,4,1,4,21,16,0,21,0,1,513]

theorem envBound11948 : H12AffineFastState.Bounded env11948 := by
  intro p hp
  have h : env11948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11947_11948 : H12AffineEnvironment.transform 4 16 env11947 = env11948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env11947 == env11948) = true)

theorem identity11948 : scanCanonicalize (H12AffineFastState.compose env11948 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound11948 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11949 : List Nat := [2,4,3,1,1,0,3,4,512,1,5,4,2,0,1,2,0,4,1,0,5,1,0,2,2,1,4,1,4,4,1,0,4,0,1,513]

theorem envBound11949 : H12AffineFastState.Bounded env11949 := by
  intro p hp
  have h : env11949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11948_11949 : H12AffineEnvironment.transform 3 1 env11948 = env11949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env11948 == env11949) = true)

theorem identity11949 : scanCanonicalize (H12AffineFastState.compose env11949 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound11949 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11950 : List Nat := [2,4,3,1,1,0,3,4,1,1,5,4,2,0,1,2,0,4,1,0,5,1,0,2,2,1,4,1,4,4,1,0,4,0,1,0]

theorem envBound11950 : H12AffineFastState.Bounded env11950 := by
  intro p hp
  have h : env11950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11949_11950 : H12AffineEnvironment.transform 8 1 env11949 = env11950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env11949 == env11950) = true)

theorem identity11950 : scanCanonicalize (H12AffineFastState.compose env11950 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound11950 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11951 : List Nat := [1,4,0,1,1,0,0,4,1,1,5,4,1,0,1,1,0,4,1,0,5,1,0,1,1,1,4,1,4,4,1,0,4,0,1,0]

theorem envBound11951 : H12AffineFastState.Bounded env11951 := by
  intro p hp
  have h : env11951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11950_11951 : H12AffineEnvironment.transform 0 1 env11950 = env11951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env11950 == env11951) = true)

theorem identity11951 : scanCanonicalize (H12AffineFastState.compose env11951 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound11951 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env11952 : List Nat := [1,0,0,1,1,0,0,0,1,1,1,0,1,0,1,1,0,0,1,0,1,1,0,1,1,1,0,1,0,0,1,0,0,0,1,0]

theorem envBound11952 : H12AffineFastState.Bounded env11952 := by
  intro p hp
  have h : env11952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11951_11952 : H12AffineEnvironment.transform 1 0 env11951 = env11952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env11951 == env11952) = true)

def env11953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1024,32769,4161,21928,41413,21763,8328,65,100694,115150,58581,35324,94422,95530,256,73771,115087,22273]

theorem envBound11953 : H12AffineFastState.Bounded env11953 := by
  intro p hp
  have h : env11953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11935_11953 : H12AffineEnvironment.transform 16 49169 env11935 = env11953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env11935 == env11953) = true)

theorem identity11953 : scanCanonicalize (H12AffineFastState.compose env11953 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound11953 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,38296,10281,1024,32769,4161,33,41413,138,8328,65,100694,103495,45404,35324,75103,73891,256,73771,103430,648]

theorem envBound11954 : H12AffineFastState.Bounded env11954 := by
  intro p hp
  have h : env11954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11953_11954 : H12AffineEnvironment.transform 13 5513 env11953 = env11954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env11953 == env11954) = true)

theorem identity11954 : scanCanonicalize (H12AffineFastState.compose env11954 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound11954 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env11955 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,38161,10281,1024,32769,4161,33,41292,3,8193,65,100694,103495,45404,35189,75103,73770,256,73771,103430,513]

theorem envBound11955 : H12AffineFastState.Bounded env11955 := by
  intro p hp
  have h : env11955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11954_11955 : H12AffineEnvironment.transform 6 9 env11954 = env11955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11954 == env11955) = true)

theorem identity11955 : scanCanonicalize (H12AffineFastState.compose env11955 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound11955 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env11956 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8283,38161,10281,1024,32769,4161,33,41292,3,8193,65,43277,46108,45404,35189,1284,113,256,112,46173,513]

theorem envBound11956 : H12AffineFastState.Bounded env11956 := by
  intro p hp
  have h : env11956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11955_11956 : H12AffineEnvironment.transform 15 8283 env11955 = env11956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env11955 == env11956) = true)

theorem identity11956 : scanCanonicalize (H12AffineFastState.compose env11956 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound11956 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env11957 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,0,8283,5393,10281,1024,1,4161,33,8524,3,8193,65,10509,13340,12636,2421,1284,113,256,112,13405,513]

theorem envBound11957 : H12AffineFastState.Bounded env11957 := by
  intro p hp
  have h : env11957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11956_11957 : H12AffineEnvironment.transform 14 0 env11956 = env11957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env11956 == env11957) = true)

theorem identity11957 : scanCanonicalize (H12AffineFastState.compose env11957 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound11957 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env11958 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,0,343,5393,2341,1024,1,4161,33,64,3,269,65,2049,5392,4176,2421,1284,113,256,112,5457,513]

theorem envBound11958 : H12AffineFastState.Bounded env11958 := by
  intro p hp
  have h : env11958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11957_11958 : H12AffineEnvironment.transform 12 268 env11957 = env11958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env11957 == env11958) = true)

theorem identity11958 : scanCanonicalize (H12AffineFastState.compose env11958 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11958 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11959 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,0,263,5393,2341,1024,1,4113,33,16,3,269,17,2049,5392,4096,2341,1284,33,256,32,5377,513]

theorem envBound11959 : H12AffineFastState.Bounded env11959 := by
  intro p hp
  have h : env11959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11958_11959 : H12AffineEnvironment.transform 5 16 env11958 = env11959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11958 == env11959) = true)

theorem identity11959 : scanCanonicalize (H12AffineFastState.compose env11959 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound11959 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11960 : List Nat := [2,4,8,16,32,16,9,21,512,1024,2048,4096,25,5141,0,18,5124,2096,1024,1,4113,33,16,3,24,17,2049,5125,4096,2096,1041,33,21,32,5140,513]

theorem envBound11960 : H12AffineFastState.Bounded env11960 := by
  intro p hp
  have h : env11960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11959_11960 : H12AffineEnvironment.transform 7 21 env11959 = env11960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env11959 == env11960) = true)

theorem identity11960 : scanCanonicalize (H12AffineFastState.compose env11960 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3118) := by decide +kernel

theorem selectedBound11960 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11961 : List Nat := [2,4,8,16,32,16,9,21,512,1024,2048,3118,25,2107,0,18,2090,2096,1024,1,3135,33,16,3,24,17,2049,2091,3118,2096,1041,33,21,32,2106,513]

theorem envBound11961 : H12AffineFastState.Bounded env11961 := by
  intro p hp
  have h : env11961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11960_11961 : H12AffineEnvironment.transform 11 3118 env11960 = env11961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3118 env11960 == env11961) = true)

theorem identity11961 : scanCanonicalize (H12AffineFastState.compose env11961 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound11961 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11962 : List Nat := [2,4,8,16,32,16,9,21,16,1024,2048,3118,25,2107,0,18,2090,2096,1024,1,3135,33,16,3,24,17,2049,2091,3118,2096,1041,33,21,32,2106,17]

theorem envBound11962 : H12AffineFastState.Bounded env11962 := by
  intro p hp
  have h : env11962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11961_11962 : H12AffineEnvironment.transform 8 16 env11961 = env11962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env11961 == env11962) = true)

theorem identity11962 : scanCanonicalize (H12AffineFastState.compose env11962 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1028) := by decide +kernel

theorem selectedBound11962 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env11963 : List Nat := [2,4,8,16,32,16,9,21,16,1024,1028,42,25,1087,0,18,1070,1076,1024,1,59,33,16,3,24,17,1029,1071,42,1076,1041,33,21,32,1086,17]

theorem envBound11963 : H12AffineFastState.Bounded env11963 := by
  intro p hp
  have h : env11963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11962_11963 : H12AffineEnvironment.transform 10 1028 env11962 = env11963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1028 env11962 == env11963) = true)

theorem identity11963 : scanCanonicalize (H12AffineFastState.compose env11963 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound11963 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11964 : List Nat := [2,4,8,16,11,16,9,21,16,1024,1028,1,25,1044,0,18,1029,1055,1024,1,16,10,16,3,24,17,1029,1028,1,1055,1041,10,21,11,1045,17]

theorem envBound11964 : H12AffineFastState.Bounded env11964 := by
  intro p hp
  have h : env11964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11963_11964 : H12AffineEnvironment.transform 4 11 env11963 = env11964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env11963 == env11964) = true)

theorem identity11964 : scanCanonicalize (H12AffineFastState.compose env11964 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound11964 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env11965 : List Nat := [2,4,8,16,11,16,9,21,16,15,11,1,25,27,0,18,10,16,15,1,16,10,16,3,24,17,10,11,1,16,30,10,21,11,26,17]

theorem envBound11965 : H12AffineFastState.Bounded env11965 := by
  intro p hp
  have h : env11965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11964_11965 : H12AffineEnvironment.transform 9 15 env11964 = env11965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env11964 == env11965) = true)

theorem identity11965 : scanCanonicalize (H12AffineFastState.compose env11965 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound11965 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11966 : List Nat := [2,4,7,16,4,16,6,21,16,0,4,1,22,20,0,18,5,16,0,1,16,5,16,3,23,17,5,4,1,16,17,5,21,4,21,17]

theorem envBound11966 : H12AffineFastState.Bounded env11966 := by
  intro p hp
  have h : env11966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11965_11966 : H12AffineEnvironment.transform 2 7 env11965 = env11966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env11965 == env11966) = true)

theorem identity11966 : scanCanonicalize (H12AffineFastState.compose env11966 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound11966 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11967 : List Nat := [2,4,7,6,4,6,6,3,6,0,4,1,0,2,0,4,5,6,0,1,6,5,6,3,1,7,5,4,1,6,7,5,3,4,3,7]

theorem envBound11967 : H12AffineFastState.Bounded env11967 := by
  intro p hp
  have h : env11967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11966_11967 : H12AffineEnvironment.transform 3 6 env11966 = env11967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env11966 == env11967) = true)

theorem identity11967 : scanCanonicalize (H12AffineFastState.compose env11967 (packedSelected [9] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound11967 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env11968 : List Nat := [2,0,3,2,0,2,2,3,2,0,0,1,0,2,0,0,1,2,0,1,2,1,2,3,1,3,1,0,1,2,3,1,3,0,3,3]

theorem envBound11968 : H12AffineFastState.Bounded env11968 := by
  intro p hp
  have h : env11968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11967_11968 : H12AffineEnvironment.transform 1 0 env11967 = env11968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env11967 == env11968) = true)

def env11969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262521,412157,2114882,8328,65,215366,115150,2497708,35324,2590895,2336123,256,509971,469431,2535288]

theorem envBound11969 : H12AffineFastState.Bounded env11969 := by
  intro p hp
  have h : env11969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11874_11969 : H12AffineEnvironment.transform 21 2262521 env11874 = env11969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262521 env11874 == env11969) = true)

def env11970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169401,412157,21762,8328,65,215366,115150,396524,35324,497903,243003,256,509971,469431,442168]

theorem envBound11970 : H12AffineFastState.Bounded env11970 := by
  intro p hp
  have h : env11970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11969_11970 : H12AffineEnvironment.transform 20 4160 env11969 = env11970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env11969 == env11970) = true)

theorem identity11970 : scanCanonicalize (H12AffineFastState.compose env11970 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound11970 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,4160,156013,412157,21762,8328,65,215366,79130,396524,32040,486459,213487,256,474311,469431,412652]

theorem envBound11971 : H12AffineFastState.Bounded env11971 := by
  intro p hp
  have h : env11971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11970_11971 : H12AffineEnvironment.transform 14 29908 env11970 = env11971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env11970 == env11971) = true)

def env11972 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,262144,1024,29829,4112,155965,412077,21762,8328,17,215318,79130,396476,32040,486459,213439,256,474263,469431,412604]

theorem envBound11972 : H12AffineFastState.Bounded env11972 := by
  intro p hp
  have h : env11972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11971_11972 : H12AffineEnvironment.transform 5 16 env11971 = env11972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11971 == env11972) = true)

theorem identity11972 : scanCanonicalize (H12AffineFastState.compose env11972 (packedSelected [10,12,14,31,35,41] rootPS)) = affineNative (2^(17+1) ^^^ 157752) := by decide +kernel

theorem selectedBound11972 : packedSelected [10,12,14,31,35,41] rootPS < 2^1333 := by decide +kernel

def env11973 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,157752,1024,29829,4112,155965,8597,21762,8328,17,215318,79130,25732,32040,66563,213439,256,87215,82319,9092]

theorem envBound11973 : H12AffineFastState.Bounded env11973 := by
  intro p hp
  have h : env11973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11972_11973 : H12AffineEnvironment.transform 17 157752 env11972 = env11973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157752 env11972 == env11973) = true)

theorem identity11973 : scanCanonicalize (H12AffineFastState.compose env11973 (packedSelected [0,1,9,10,16,18,20,22,23,26,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound11973 : packedSelected [0,1,9,10,16,18,20,22,23,26,27,28] rootPS < 2^1333 := by decide +kernel

def env11974 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,262,131072,157752,1024,29829,4112,155965,8597,21762,8328,17,149520,13340,25732,32040,1285,147641,256,21929,16521,9092]

theorem envBound11974 : H12AffineFastState.Bounded env11974 := by
  intro p hp
  have h : env11974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11973_11974 : H12AffineEnvironment.transform 15 262 env11973 = env11974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env11973 == env11974) = true)

theorem identity11974 : scanCanonicalize (H12AffineFastState.compose env11974 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound11974 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env11975 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8581,262,131072,146745,1024,8580,4112,144444,8597,3,8328,17,138513,13340,12677,10281,1285,136632,256,168,5512,9092]

theorem envBound11975 : H12AffineFastState.Bounded env11975 := by
  intro p hp
  have h : env11975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11974_11975 : H12AffineEnvironment.transform 13 5377 env11974 = env11975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env11974 == env11975) = true)

theorem identity11975 : scanCanonicalize (H12AffineFastState.compose env11975 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound11975 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env11976 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8581,262,13341,2340,1024,8580,4112,33,8597,3,8328,17,10508,13340,12677,10281,1285,8613,256,168,5512,9092]

theorem envBound11976 : H12AffineFastState.Bounded env11976 := by
  intro p hp
  have h : env11976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11975_11976 : H12AffineEnvironment.transform 16 13341 env11975 = env11976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env11975 == env11976) = true)

theorem identity11976 : scanCanonicalize (H12AffineFastState.compose env11976 (packedSelected [1,2,6,8,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 5253) := by decide +kernel

theorem selectedBound11976 : packedSelected [1,2,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env11977 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5253,5377,5376,262,152,2340,1024,5377,4112,33,5392,3,5133,17,7561,153,1280,7340,1285,5408,256,168,5512,5889]

theorem envBound11977 : H12AffineFastState.Bounded env11977 := by
  intro p hp
  have h : env11977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11976_11977 : H12AffineEnvironment.transform 12 5253 env11976 = env11977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5253 env11976 == env11977) = true)

theorem identity11977 : scanCanonicalize (H12AffineFastState.compose env11977 (packedSelected [0,2,4,6,7,9,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound11977 : packedSelected [0,2,4,6,7,9,12,14] rootPS < 2^1333 := by decide +kernel

def env11978 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,16,1173,1297,1296,262,152,2340,1024,1297,0,33,1280,3,1053,17,3481,153,1280,3260,1285,1328,256,168,1432,1809]

theorem envBound11978 : H12AffineFastState.Bounded env11978 := by
  intro p hp
  have h : env11978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11977_11978 : H12AffineEnvironment.transform 11 16 env11977 = env11978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env11977 == env11978) = true)

theorem identity11978 : scanCanonicalize (H12AffineFastState.compose env11978 (packedSelected [4,9,15] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound11978 : packedSelected [4,9,15] rootPS < 2^1333 := by decide +kernel

def env11979 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,16,1173,1297,1296,262,152,293,1024,1297,0,33,1280,3,1053,17,1432,153,1280,1213,1285,1328,256,168,1432,1809]

theorem envBound11979 : H12AffineFastState.Bounded env11979 := by
  intro p hp
  have h : env11979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11978_11979 : H12AffineEnvironment.transform 10 1 env11978 = env11979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env11978 == env11979) = true)

theorem identity11979 : scanCanonicalize (H12AffineFastState.compose env11979 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound11979 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env11980 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1,16,1053,1297,1296,262,16,293,1024,1297,0,33,1280,3,1053,17,1296,17,1280,1077,1285,1328,256,32,1296,1809]

theorem envBound11980 : H12AffineFastState.Bounded env11980 := by
  intro p hp
  have h : env11980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11979_11980 : H12AffineEnvironment.transform 6 8 env11979 = env11980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11979 == env11980) = true)

theorem identity11980 : scanCanonicalize (H12AffineFastState.compose env11980 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound11980 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11981 : List Nat := [2,4,8,16,32,16,8,256,512,20,1,16,9,261,260,262,16,293,20,261,0,33,276,3,9,17,260,17,276,33,273,292,256,32,260,773]

theorem envBound11981 : H12AffineFastState.Bounded env11981 := by
  intro p hp
  have h : env11981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11980_11981 : H12AffineEnvironment.transform 9 20 env11980 = env11981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env11980 == env11981) = true)

theorem identity11981 : scanCanonicalize (H12AffineFastState.compose env11981 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11981 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env11982 : List Nat := [2,4,8,16,0,16,8,256,512,20,1,16,9,261,260,262,16,261,20,261,0,1,276,3,9,17,260,17,276,1,273,260,256,0,260,773]

theorem envBound11982 : H12AffineFastState.Bounded env11982 := by
  intro p hp
  have h : env11982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11981_11982 : H12AffineEnvironment.transform 4 0 env11981 = env11982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11981 == env11982) = true)

theorem identity11982 : scanCanonicalize (H12AffineFastState.compose env11982 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound11982 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11983 : List Nat := [2,4,8,16,0,16,8,5,512,20,1,16,9,0,1,3,16,0,20,0,0,1,17,3,9,17,1,17,17,1,20,1,5,0,1,512]

theorem envBound11983 : H12AffineFastState.Bounded env11983 := by
  intro p hp
  have h : env11983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11982_11983 : H12AffineEnvironment.transform 7 5 env11982 = env11983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env11982 == env11983) = true)

theorem identity11983 : scanCanonicalize (H12AffineFastState.compose env11983 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound11983 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11984 : List Nat := [2,4,8,16,0,16,8,5,16,20,1,16,9,0,1,3,16,0,20,0,0,1,17,3,9,17,1,17,17,1,20,1,5,0,1,16]

theorem envBound11984 : H12AffineFastState.Bounded env11984 := by
  intro p hp
  have h : env11984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11983_11984 : H12AffineEnvironment.transform 8 16 env11983 = env11984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env11983 == env11984) = true)

theorem identity11984 : scanCanonicalize (H12AffineFastState.compose env11984 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound11984 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11985 : List Nat := [2,4,6,16,0,16,6,5,16,20,1,16,7,0,1,3,16,0,20,0,0,1,17,3,7,17,1,17,17,1,20,1,5,0,1,16]

theorem envBound11985 : H12AffineFastState.Bounded env11985 := by
  intro p hp
  have h : env11985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11984_11985 : H12AffineEnvironment.transform 2 6 env11984 = env11985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env11984 == env11985) = true)

def env11986 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,262144,1024,29828,4113,155964,412076,21762,8328,16,215319,79130,396477,32040,486459,213438,256,474262,469431,412605]

theorem envBound11986 : H12AffineFastState.Bounded env11986 := by
  intro p hp
  have h : env11986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11971_11986 : H12AffineEnvironment.transform 5 17 env11971 = env11986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11971 == env11986) = true)

theorem identity11986 : scanCanonicalize (H12AffineFastState.compose env11986 (packedSelected [10,12,14,31,35,41] rootPS)) = affineNative (2^(15+1) ^^^ 21646) := by decide +kernel

theorem selectedBound11986 : packedSelected [10,12,14,31,35,41] rootPS < 2^1333 := by decide +kernel

def env11987 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,21646,131072,262144,1024,29828,4113,155964,412076,21762,8328,16,138649,24980,396477,32040,407733,136496,256,419864,425273,412605]

theorem envBound11987 : H12AffineFastState.Bounded env11987 := by
  intro p hp
  have h : env11987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11986_11987 : H12AffineEnvironment.transform 15 21646 env11986 = env11987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21646 env11986 == env11987) = true)

theorem identity11987 : scanCanonicalize (H12AffineFastState.compose env11987 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 138293) := by decide +kernel

theorem selectedBound11987 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env11988 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,21646,131072,138293,1024,29828,4113,155964,21913,21762,8328,16,138649,24980,4232,32040,9344,136496,256,29741,24844,22408]

theorem envBound11988 : H12AffineFastState.Bounded env11988 := by
  intro p hp
  have h : env11988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11987_11988 : H12AffineEnvironment.transform 17 138293 env11987 = env11988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138293 env11987 == env11988) = true)

theorem identity11988 : scanCanonicalize (H12AffineFastState.compose env11988 (packedSelected [0,7,9,10,11,12,15,16,18,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound11988 : packedSelected [0,7,9,10,11,12,15,16,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env11989 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,16384,21897,21646,131072,138293,1024,21896,4113,147504,21913,21762,388,16,138649,16536,4232,23588,1420,136496,256,21793,16384,22408]

theorem envBound11989 : H12AffineFastState.Bounded env11989 := by
  intro p hp
  have h : env11989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11988_11989 : H12AffineEnvironment.transform 12 268 env11988 = env11989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env11988 == env11989) = true)

theorem identity11989 : scanCanonicalize (H12AffineFastState.compose env11989 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound11989 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env11990 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,16384,21897,21646,5528,2477,1024,21896,4113,21928,21913,21762,388,16,2049,16536,4232,23588,1420,168,256,21793,16384,22408]

theorem envBound11990 : H12AffineFastState.Bounded env11990 := by
  intro p hp
  have h : env11990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11989_11990 : H12AffineEnvironment.transform 16 5528 env11989 = env11990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env11989 == env11990) = true)

theorem identity11990 : scanCanonicalize (H12AffineFastState.compose env11990 (packedSelected [1,3,5,6,8,11,12,14] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound11990 : packedSelected [1,3,5,6,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env11991 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,161,16384,21540,21646,5173,2048,1024,21541,4113,21509,21556,21679,41,16,2049,16536,4232,23588,1057,168,173,21644,16384,22053]

theorem envBound11991 : H12AffineFastState.Bounded env11991 := by
  intro p hp
  have h : env11991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11990_11991 : H12AffineEnvironment.transform 7 173 env11990 = env11991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env11990 == env11991) = true)

theorem identity11991 : scanCanonicalize (H12AffineFastState.compose env11991 (packedSelected [0,2,4,6,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound11991 : packedSelected [0,2,4,6,10] rootPS < 2^1333 := by decide +kernel

def env11992 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,16384,21540,21510,5173,2048,1024,21541,4113,21509,21556,21543,41,16,2049,16400,4096,23588,1057,32,37,21508,16384,22053]

theorem envBound11992 : H12AffineFastState.Bounded env11992 := by
  intro p hp
  have h : env11992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11991_11992 : H12AffineEnvironment.transform 6 8 env11991 = env11992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11991 == env11992) = true)

theorem identity11992 : scanCanonicalize (H12AffineFastState.compose env11992 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound11992 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env11993 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5157,1,35,5173,2048,1024,0,4113,32,17,2,41,16,2049,5173,4096,2049,1057,32,37,33,5157,512]

theorem envBound11993 : H12AffineFastState.Bounded env11993 := by
  intro p hp
  have h : env11993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11992_11993 : H12AffineEnvironment.transform 13 5157 env11992 = env11993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env11992 == env11993) = true)

theorem identity11993 : scanCanonicalize (H12AffineFastState.compose env11993 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11993 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11994 : List Nat := [2,4,8,16,1,17,8,4,512,1024,2048,4096,8,5124,1,2,5140,2048,1024,0,4113,1,17,2,8,16,2049,5140,4096,2049,1024,1,4,0,5124,512]

theorem envBound11994 : H12AffineFastState.Bounded env11994 := by
  intro p hp
  have h : env11994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11993_11994 : H12AffineEnvironment.transform 4 1 env11993 = env11994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11993 == env11994) = true)

def env11995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169400,412157,21763,8328,65,215366,115150,396525,35324,497902,243002,256,509971,469431,442169]

theorem envBound11995 : H12AffineFastState.Bounded env11995 := by
  intro p hp
  have h : env11995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11969_11995 : H12AffineEnvironment.transform 20 4161 env11969 = env11995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env11969 == env11995) = true)

theorem identity11995 : scanCanonicalize (H12AffineFastState.compose env11995 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149997) := by decide +kernel

theorem selectedBound11995 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4161,169400,16,21763,8328,65,215366,115150,17664,35324,119043,243002,256,98814,90202,63188]

theorem envBound11996 : H12AffineFastState.Bounded env11996 := by
  intro p hp
  have h : env11996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11995_11996 : H12AffineEnvironment.transform 17 149997 env11995 = env11996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149997 env11995 == env11996) = true)

def env11997 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,169264,16,21763,8192,65,215366,115014,17664,35188,119043,243002,256,98678,90202,63068]

theorem envBound11997 : H12AffineFastState.Bounded env11997 := by
  intro p hp
  have h : env11997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11996_11997 : H12AffineEnvironment.transform 6 8 env11996 = env11997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11996 == env11997) = true)

theorem identity11997 : scanCanonicalize (H12AffineFastState.compose env11997 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound11997 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11998 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13389,32040,1024,32769,4161,41341,16,21763,8192,65,97547,115014,17664,35188,119043,98679,256,98678,90202,63068]

theorem envBound11998 : H12AffineFastState.Bounded env11998 := by
  intro p hp
  have h : env11998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11997_11998 : H12AffineEnvironment.transform 16 13389 env11997 = env11998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env11997 == env11998) = true)

theorem identity11998 : scanCanonicalize (H12AffineFastState.compose env11998 (packedSelected [0,3,5,7,9,10,12,14,15,18,20,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound11998 : packedSelected [0,3,5,7,9,10,12,14,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env11999 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,293,65536,13389,32040,1024,292,4161,8280,16,21763,8192,65,97547,82019,17664,2129,86054,65618,256,65619,90202,30585]

theorem envBound11999 : H12AffineFastState.Bounded env11999 := by
  intro p hp
  have h : env11999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11998_11999 : H12AffineEnvironment.transform 14 293 env11998 = env11999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env11998 == env11999) = true)

theorem identity11999 : scanCanonicalize (H12AffineFastState.compose env11999 (packedSelected [0,4,7,19,22,26] rootPS)) = affineNative (2^(15+1) ^^^ 8575) := by decide +kernel

theorem selectedBound11999 : packedSelected [0,4,7,19,22,26] rootPS < 2^1333 := by decide +kernel

def env12000 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,293,8575,13389,32040,1024,292,4161,8280,16,21763,8192,65,23668,24860,17664,2129,29017,8493,256,8492,16677,30585]

theorem envBound12000 : H12AffineFastState.Bounded env12000 := by
  intro p hp
  have h : env12000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11999_12000 : H12AffineEnvironment.transform 15 8575 env11999 = env12000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8575 env11999 == env12000) = true)

theorem identity12000 : scanCanonicalize (H12AffineFastState.compose env12000 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound12000 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env12001 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,293,8575,13389,2340,1024,292,4161,8280,16,8463,8192,65,10360,5392,12556,2129,1365,8493,256,8492,13609,885]

theorem envBound12001 : H12AffineFastState.Bounded env12001 := by
  intro p hp
  have h : env12001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12000_12001 : H12AffineEnvironment.transform 13 13324 env12000 = env12001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env12000 == env12001) = true)

theorem identity12001 : scanCanonicalize (H12AffineFastState.compose env12001 (packedSelected [15] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound12001 : packedSelected [15] rootPS < 2^1333 := by decide +kernel

def env12002 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1052,4112,293,1379,4177,2340,1024,292,4161,1092,16,1299,1052,65,3172,5392,5392,2129,1365,1329,256,1328,4405,885]

theorem envBound12002 : H12AffineFastState.Bounded env12002 := by
  intro p hp
  have h : env12002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12001_12002 : H12AffineEnvironment.transform 12 1052 env12001 = env12002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env12001 == env12002) = true)

theorem identity12002 : scanCanonicalize (H12AffineFastState.compose env12002 (packedSelected [0,2,3,4,5,7,9,10,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound12002 : packedSelected [0,2,3,4,5,7,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env12003 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,41,4112,293,342,4177,2340,53,292,4161,113,16,294,41,65,2129,4389,4389,2129,352,260,256,261,4405,885]

theorem envBound12003 : H12AffineFastState.Bounded env12003 := by
  intro p hp
  have h : env12003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12002_12003 : H12AffineEnvironment.transform 9 53 env12002 = env12003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env12002 == env12003) = true)

theorem identity12003 : scanCanonicalize (H12AffineFastState.compose env12003 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound12003 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env12004 : List Nat := [2,4,8,16,32,64,8,116,512,53,2048,4096,41,4112,81,34,4177,2128,53,80,4161,113,16,82,41,65,2129,4177,4177,2129,20,112,116,113,4161,513]

theorem envBound12004 : H12AffineFastState.Bounded env12004 := by
  intro p hp
  have h : env12004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12003_12004 : H12AffineEnvironment.transform 7 116 env12003 = env12004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env12003 == env12004) = true)

theorem identity12004 : scanCanonicalize (H12AffineFastState.compose env12004 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12004 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12005 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,4096,41,4112,0,34,4096,2049,53,1,4112,32,16,3,41,16,2048,4096,4096,2048,20,33,37,32,4112,513]

theorem envBound12005 : H12AffineFastState.Bounded env12005 := by
  intro p hp
  have h : env12005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12004_12005 : H12AffineEnvironment.transform 5 17 env12004 = env12005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12004 == env12005) = true)

theorem identity12005 : scanCanonicalize (H12AffineFastState.compose env12005 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2609) := by decide +kernel

theorem selectedBound12005 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12006 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,2609,41,2593,0,34,2609,2049,53,1,2593,32,16,3,41,16,2048,2609,2609,2048,20,33,37,32,2593,513]

theorem envBound12006 : H12AffineFastState.Bounded env12006 := by
  intro p hp
  have h : env12006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12005_12006 : H12AffineEnvironment.transform 11 2609 env12005 = env12006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2609 env12005 == env12006) = true)

theorem identity12006 : scanCanonicalize (H12AffineFastState.compose env12006 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound12006 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12007 : List Nat := [2,4,8,16,32,17,8,37,512,53,33,528,41,512,0,34,528,32,53,1,512,32,16,3,41,16,33,528,528,33,20,33,37,32,512,513]

theorem envBound12007 : H12AffineFastState.Bounded env12007 := by
  intro p hp
  have h : env12007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12006_12007 : H12AffineEnvironment.transform 10 33 env12006 = env12007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env12006 == env12007) = true)

theorem identity12007 : scanCanonicalize (H12AffineFastState.compose env12007 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound12007 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12008 : List Nat := [2,4,8,16,32,17,8,37,1,53,33,17,41,1,0,34,17,32,53,1,1,32,16,3,41,16,33,17,17,33,20,33,37,32,1,0]

theorem envBound12008 : H12AffineFastState.Bounded env12008 := by
  intro p hp
  have h : env12008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12007_12008 : H12AffineEnvironment.transform 8 1 env12007 = env12008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env12007 == env12008) = true)

theorem identity12008 : scanCanonicalize (H12AffineFastState.compose env12008 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12008 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env12009 : List Nat := [2,4,8,16,1,17,8,4,1,20,0,17,8,1,0,3,17,1,20,1,1,1,16,3,8,16,0,17,17,0,20,0,4,1,1,0]

theorem envBound12009 : H12AffineFastState.Bounded env12009 := by
  intro p hp
  have h : env12009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12008_12009 : H12AffineEnvironment.transform 4 1 env12008 = env12009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12008 == env12009) = true)

def env12010 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,169265,16,21763,8193,65,215366,115015,17664,35189,119043,243002,256,98679,90202,63069]

theorem envBound12010 : H12AffineFastState.Bounded env12010 := by
  intro p hp
  have h : env12010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11996_12010 : H12AffineEnvironment.transform 6 9 env11996 = env12010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11996 == env12010) = true)

theorem identity12010 : scanCanonicalize (H12AffineFastState.compose env12010 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound12010 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12011 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,56437,1024,32769,4161,32,16,21763,8193,65,121943,115015,17664,35189,119043,73771,256,98679,90202,63069]

theorem envBound12011 : H12AffineFastState.Bounded env12011 := by
  intro p hp
  have h : env12011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12010_12011 : H12AffineEnvironment.transform 16 38161 env12010 = env12011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env12010 == env12011) = true)

theorem identity12011 : scanCanonicalize (H12AffineFastState.compose env12011 (packedSelected [1,2,3,4,5,6,8,9,12,16,19,20,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound12011 : packedSelected [1,2,3,4,5,6,8,9,12,16,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env12012 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,30043,38161,56437,1024,32769,4161,32,16,21763,8193,65,43276,46108,17664,35189,42072,21872,256,62508,5377,63069]

theorem envBound12012 : H12AffineFastState.Bounded env12012 := by
  intro p hp
  have h : env12012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12011_12012 : H12AffineEnvironment.transform 15 30043 env12011 = env12012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env12011 == env12012) = true)

theorem identity12012 : scanCanonicalize (H12AffineFastState.compose env12012 (packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound12012 : packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS < 2^1333 := by decide +kernel

def env12013 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,30043,5392,23668,1024,0,4161,32,16,21763,8193,65,10509,13341,17664,2420,9305,21872,256,29741,5377,30300]

theorem envBound12013 : H12AffineFastState.Bounded env12013 := by
  intro p hp
  have h : env12013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12012_12013 : H12AffineEnvironment.transform 14 1 env12012 = env12013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env12012 == env12013) = true)

theorem identity12013 : scanCanonicalize (H12AffineFastState.compose env12013 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound12013 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0