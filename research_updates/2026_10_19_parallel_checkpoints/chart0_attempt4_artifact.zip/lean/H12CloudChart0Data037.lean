import H12CloudChart0Data036

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans9209_9210 : H12AffineEnvironment.transform 2 2 env9209 = env9210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9209 == env9210) = true)

theorem identity9210 : scanCanonicalize (H12AffineFastState.compose env9210 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9210 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9211 : List Nat := [2,4,2,0,1,0,2,4,0,5,1,0,3,0,1,3,0,1,5,1,1,1,0,3,2,1,0,1,0,1,4,0,4,1,0,0]

theorem envBound9211 : H12AffineFastState.Bounded env9211 := by
  intro p hp
  have h : env9211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9210_9211 : H12AffineEnvironment.transform 3 0 env9210 = env9211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9210 == env9211) = true)

def env9212 : List Nat := [2,4,8,16,32,64,128,253,217,252,2048,4096,8192,232,8200,65536,4096,73945,4164,8200,65,73818,4264,73736,8329,4097,73809,77946,77947,75786,4,248,4165,73770,77866,73971]

theorem envBound9212 : H12AffineFastState.Bounded env9212 := by
  intro p hp
  have h : env9212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9201_9212 : H12AffineEnvironment.transform 8 217 env9201 = env9212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env9201 == env9212) = true)

theorem identity9212 : scanCanonicalize (H12AffineFastState.compose env9212 (packedSelected [14] rootPS)) = affineNative (2^(15+1) ^^^ 12435) := by decide +kernel

theorem selectedBound9212 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env9213 : List Nat := [2,4,8,16,32,64,128,253,217,252,2048,4096,8192,232,8200,12435,4096,4170,4164,8200,65,4297,4264,4251,8329,4097,4290,233,232,6297,4,248,4165,4281,185,4192]

theorem envBound9213 : H12AffineFastState.Bounded env9213 := by
  intro p hp
  have h : env9213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9212_9213 : H12AffineEnvironment.transform 15 12435 env9212 = env9213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12435 env9212 == env9213) = true)

theorem identity9213 : scanCanonicalize (H12AffineFastState.compose env9213 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 232) := by decide +kernel

theorem selectedBound9213 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env9214 : List Nat := [2,4,8,16,32,64,128,253,217,252,2048,232,8192,232,8200,8315,232,162,172,8200,65,33,64,115,8329,233,42,233,232,2161,4,248,173,81,185,136]

theorem envBound9214 : H12AffineFastState.Bounded env9214 := by
  intro p hp
  have h : env9214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9213_9214 : H12AffineEnvironment.transform 11 232 env9213 = env9214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 232 env9213 == env9214) = true)

theorem identity9214 : scanCanonicalize (H12AffineFastState.compose env9214 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound9214 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env9215 : List Nat := [2,4,8,16,32,17,128,172,136,173,2048,185,8192,185,8200,8234,185,162,172,8200,16,33,17,34,8329,184,42,184,185,2080,4,169,173,0,185,136]

theorem envBound9215 : H12AffineFastState.Bounded env9215 := by
  intro p hp
  have h : env9215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9214_9215 : H12AffineEnvironment.transform 5 17 env9214 = env9215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9214 == env9215) = true)

theorem identity9215 : scanCanonicalize (H12AffineFastState.compose env9215 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound9215 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9216 : List Nat := [2,4,8,16,32,17,40,4,32,5,2048,17,8192,17,8200,8234,17,10,4,8200,16,33,17,34,8225,16,42,16,17,2080,4,1,5,0,17,32]

theorem envBound9216 : H12AffineFastState.Bounded env9216 := by
  intro p hp
  have h : env9216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9215_9216 : H12AffineEnvironment.transform 6 40 env9215 = env9216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env9215 == env9216) = true)

theorem identity9216 : scanCanonicalize (H12AffineFastState.compose env9216 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound9216 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9217 : List Nat := [2,4,8,16,32,17,40,4,32,5,32,17,8192,17,8200,8234,17,10,4,8200,16,33,17,34,8225,16,42,16,17,0,4,1,5,0,17,32]

theorem envBound9217 : H12AffineFastState.Bounded env9217 := by
  intro p hp
  have h : env9217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9216_9217 : H12AffineEnvironment.transform 10 32 env9216 = env9217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env9216 == env9217) = true)

theorem identity9217 : scanCanonicalize (H12AffineFastState.compose env9217 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 19) := by decide +kernel

theorem selectedBound9217 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9218 : List Nat := [2,4,8,16,32,17,40,4,32,5,32,17,19,17,27,57,17,10,4,27,16,33,17,34,50,16,42,16,17,0,4,1,5,0,17,32]

theorem envBound9218 : H12AffineFastState.Bounded env9218 := by
  intro p hp
  have h : env9218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9217_9218 : H12AffineEnvironment.transform 12 19 env9217 = env9218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 19 env9217 == env9218) = true)

theorem identity9218 : scanCanonicalize (H12AffineFastState.compose env9218 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound9218 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env9219 : List Nat := [2,4,8,1,32,0,40,4,32,5,32,0,2,0,10,40,0,10,4,10,1,33,0,34,35,1,42,1,0,0,4,1,5,0,0,32]

theorem envBound9219 : H12AffineFastState.Bounded env9219 := by
  intro p hp
  have h : env9219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9218_9219 : H12AffineEnvironment.transform 3 1 env9218 = env9219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env9218 == env9219) = true)

def env9220 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,90857,4765,8200,65,90291,4721,90336,8329,21040,74377,77947,77946,75786,4,16401,4764,73770,78579,90818]

theorem envBound9220 : H12AffineFastState.Bounded env9220 := by
  intro p hp
  have h : env9220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9188_9220 : H12AffineEnvironment.transform 17 90857 env9188 = env9220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 90857 env9188 == env9220) = true)

def env9221 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,560,8200,65536,4096,73945,4765,8200,65,74371,4721,74448,8329,4096,74377,77947,77946,75786,4,545,4764,73770,78579,73970]

theorem envBound9221 : H12AffineFastState.Bounded env9221 := by
  intro p hp
  have h : env9221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9220_9221 : H12AffineEnvironment.transform 13 560 env9220 = env9221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env9220 == env9221) = true)

theorem identity9221 : scanCanonicalize (H12AffineFastState.compose env9221 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8715) := by decide +kernel

theorem selectedBound9221 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9222 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,560,8200,8715,4096,722,4765,8200,65,136,4721,219,8329,4096,130,4720,4721,2561,4,545,4764,545,4344,761]

theorem envBound9222 : H12AffineFastState.Bounded env9222 := by
  intro p hp
  have h : env9222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9221_9222 : H12AffineEnvironment.transform 15 8715 env9221 = env9222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8715 env9221 == env9222) = true)

theorem identity9222 : scanCanonicalize (H12AffineFastState.compose env9222 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2242) := by decide +kernel

theorem selectedBound9222 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env9223 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,2242,8192,560,8200,8715,2242,722,2655,8200,65,136,2739,219,8329,2242,130,2738,2739,2561,4,545,2654,545,2106,761]

theorem envBound9223 : H12AffineFastState.Bounded env9223 := by
  intro p hp
  have h : env9223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9222_9223 : H12AffineEnvironment.transform 11 2242 env9222 = env9223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2242 env9222 == env9223) = true)

theorem identity9223 : scanCanonicalize (H12AffineFastState.compose env9223 (packedSelected [1,2,8,11,14,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound9223 : packedSelected [1,2,8,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env9224 : List Nat := [2,4,8,16,32,64,128,253,97,252,2048,2242,8192,81,8200,8298,2242,179,2110,8200,65,136,2258,219,8329,2242,130,2259,2258,2144,4,64,2111,64,2106,152]

theorem envBound9224 : H12AffineFastState.Bounded env9224 := by
  intro p hp
  have h : env9224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9223_9224 : H12AffineEnvironment.transform 8 97 env9223 = env9224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env9223 == env9224) = true)

theorem identity9224 : scanCanonicalize (H12AffineFastState.compose env9224 (packedSelected [0,1,2,3,4,7,9,11,12,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound9224 : packedSelected [0,1,2,3,4,7,9,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env9225 : List Nat := [2,4,8,16,32,0,128,189,33,188,2048,2178,8192,17,8200,8234,2178,179,2110,8200,1,136,2194,155,8329,2178,130,2195,2194,2080,4,0,2111,0,2106,152]

theorem envBound9225 : H12AffineFastState.Bounded env9225 := by
  intro p hp
  have h : env9225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9224_9225 : H12AffineEnvironment.transform 5 0 env9224 = env9225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env9224 == env9225) = true)

theorem identity9225 : scanCanonicalize (H12AffineFastState.compose env9225 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound9225 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9226 : List Nat := [2,4,8,16,32,0,40,21,33,20,2048,2090,8192,17,8200,8234,2090,27,2110,8200,1,32,2106,51,8225,2090,42,2107,2106,2080,4,0,2111,0,2106,48]

theorem envBound9226 : H12AffineFastState.Bounded env9226 := by
  intro p hp
  have h : env9226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9225_9226 : H12AffineEnvironment.transform 6 40 env9225 = env9226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env9225 == env9226) = true)

theorem identity9226 : scanCanonicalize (H12AffineFastState.compose env9226 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9226 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env9227 : List Nat := [2,4,8,0,32,0,40,5,33,4,2048,2090,8192,1,8200,8234,2090,11,2094,8200,1,32,2090,35,8225,2090,42,2091,2090,2080,4,0,2095,0,2090,32]

theorem envBound9227 : H12AffineFastState.Bounded env9227 := by
  intro p hp
  have h : env9227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9226_9227 : H12AffineEnvironment.transform 3 0 env9226 = env9227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9226 == env9227) = true)

theorem identity9227 : scanCanonicalize (H12AffineFastState.compose env9227 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 35) := by decide +kernel

theorem selectedBound9227 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9228 : List Nat := [2,4,8,0,32,0,40,5,33,4,2048,2090,35,1,43,9,2090,11,2094,43,1,32,2090,35,2,2090,42,2091,2090,2080,4,0,2095,0,2090,32]

theorem envBound9228 : H12AffineFastState.Bounded env9228 := by
  intro p hp
  have h : env9228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9227_9228 : H12AffineEnvironment.transform 12 35 env9227 = env9228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 35 env9227 == env9228) = true)

theorem identity9228 : scanCanonicalize (H12AffineFastState.compose env9228 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound9228 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env9229 : List Nat := [2,4,8,0,4,0,12,5,5,4,2048,2062,7,1,15,9,2062,11,2058,15,1,4,2062,7,2,2062,14,2063,2062,2052,4,0,2059,0,2062,4]

theorem envBound9229 : H12AffineFastState.Bounded env9229 := by
  intro p hp
  have h : env9229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9228_9229 : H12AffineEnvironment.transform 4 4 env9228 = env9229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env9228 == env9229) = true)

theorem identity9229 : scanCanonicalize (H12AffineFastState.compose env9229 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound9229 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env9230 : List Nat := [2,4,8,0,4,0,12,5,5,4,0,14,7,1,15,9,14,11,10,15,1,4,14,7,2,14,14,15,14,4,4,0,11,0,14,4]

theorem envBound9230 : H12AffineFastState.Bounded env9230 := by
  intro p hp
  have h : env9230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9229_9230 : H12AffineEnvironment.transform 10 0 env9229 = env9230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env9229 == env9230) = true)

theorem identity9230 : scanCanonicalize (H12AffineFastState.compose env9230 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound9230 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9231 : List Nat := [2,1,8,0,1,0,9,0,0,1,0,11,2,1,10,9,11,11,10,10,1,1,11,2,2,11,11,10,11,1,1,0,11,0,11,1]

theorem envBound9231 : H12AffineFastState.Bounded env9231 := by
  intro p hp
  have h : env9231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9230_9231 : H12AffineEnvironment.transform 1 1 env9230 = env9231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env9230 == env9231) = true)

theorem identity9231 : scanCanonicalize (H12AffineFastState.compose env9231 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9231 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9232 : List Nat := [2,1,3,0,1,0,2,0,0,1,0,0,2,1,1,2,0,0,1,1,1,1,0,2,2,0,0,1,0,1,1,0,0,0,0,1]

theorem envBound9232 : H12AffineFastState.Bounded env9232 := by
  intro p hp
  have h : env9232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9231_9232 : H12AffineEnvironment.transform 2 3 env9231 = env9232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9231 == env9232) = true)

def env9233 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,561,8200,65536,4096,73944,4765,8200,65,74370,4721,74449,8329,4097,74377,77947,77946,75786,4,544,4764,73770,78579,73971]

theorem envBound9233 : H12AffineFastState.Bounded env9233 := by
  intro p hp
  have h : env9233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9220_9233 : H12AffineEnvironment.transform 13 561 env9220 = env9233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env9220 == env9233) = true)

theorem identity9233 : scanCanonicalize (H12AffineFastState.compose env9233 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8947) := by decide +kernel

theorem selectedBound9233 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9234 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,561,8200,8947,4096,555,4765,8200,65,113,4721,34,8329,4097,122,4744,4745,2809,4,544,4764,729,4096,512]

theorem envBound9234 : H12AffineFastState.Bounded env9234 := by
  intro p hp
  have h : env9234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9233_9234 : H12AffineEnvironment.transform 15 8947 env9233 = env9234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8947 env9233 == env9234) = true)

theorem identity9234 : scanCanonicalize (H12AffineFastState.compose env9234 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2195) := by decide +kernel

theorem selectedBound9234 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env9235 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,2195,8192,561,8200,8947,2195,555,2574,8200,65,113,2786,34,8329,2194,122,2587,2586,2809,4,544,2575,729,2195,512]

theorem envBound9235 : H12AffineFastState.Bounded env9235 := by
  intro p hp
  have h : env9235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9234_9235 : H12AffineEnvironment.transform 11 2195 env9234 = env9235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2195 env9234 == env9235) = true)

theorem identity9235 : scanCanonicalize (H12AffineFastState.compose env9235 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound9235 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env9236 : List Nat := [2,4,8,16,32,64,121,4,512,5,2048,2154,8192,561,8200,8714,2154,555,2574,8200,65,113,2587,34,8304,2155,122,2587,2586,2560,4,544,2575,544,2154,512]

theorem envBound9236 : H12AffineFastState.Bounded env9236 := by
  intro p hp
  have h : env9236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9235_9236 : H12AffineEnvironment.transform 6 121 env9235 = env9236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env9235 == env9236) = true)

theorem identity9236 : scanCanonicalize (H12AffineFastState.compose env9236 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound9236 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9237 : List Nat := [2,4,8,16,32,17,40,4,512,5,2048,2107,8192,561,8200,8714,2107,555,2574,8200,16,32,2587,34,8225,2106,43,2587,2586,2560,4,544,2575,544,2107,512]

theorem envBound9237 : H12AffineFastState.Bounded env9237 := by
  intro p hp
  have h : env9237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9236_9237 : H12AffineEnvironment.transform 5 17 env9236 = env9237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9236 == env9237) = true)

theorem identity9237 : scanCanonicalize (H12AffineFastState.compose env9237 (packedSelected [3,4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 2099) := by decide +kernel

theorem selectedBound9237 : packedSelected [3,4,9,11] rootPS < 2^1333 := by decide +kernel

def env9238 : List Nat := [2,4,8,16,32,17,40,4,512,5,2048,2107,2099,561,2107,2617,2107,555,2574,2107,16,32,2587,34,2066,2106,43,2587,2586,2560,4,544,2575,544,2107,512]

theorem envBound9238 : H12AffineFastState.Bounded env9238 := by
  intro p hp
  have h : env9238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9237_9238 : H12AffineEnvironment.transform 12 2099 env9237 = env9238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2099 env9237 == env9238) = true)

theorem identity9238 : scanCanonicalize (H12AffineFastState.compose env9238 (packedSelected [0,2,3,5,7,8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9238 : packedSelected [0,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env9239 : List Nat := [2,4,3,16,32,17,35,4,512,5,2048,2096,2099,561,2096,2610,2096,544,2565,2096,16,32,2576,34,2066,2097,32,2576,2577,2560,4,544,2564,544,2096,512]

theorem envBound9239 : H12AffineFastState.Bounded env9239 := by
  intro p hp
  have h : env9239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9238_9239 : H12AffineEnvironment.transform 2 3 env9238 = env9239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9238 == env9239) = true)

theorem identity9239 : scanCanonicalize (H12AffineFastState.compose env9239 (packedSelected [2,3] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound9239 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env9240 : List Nat := [2,4,3,16,32,17,35,4,512,5,17,33,34,561,33,547,33,544,532,33,16,32,513,34,3,32,32,513,512,529,4,544,533,544,33,512]

theorem envBound9240 : H12AffineFastState.Bounded env9240 := by
  intro p hp
  have h : env9240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9239_9240 : H12AffineEnvironment.transform 10 17 env9239 = env9240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env9239 == env9240) = true)

theorem identity9240 : scanCanonicalize (H12AffineFastState.compose env9240 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound9240 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9241 : List Nat := [2,4,3,16,32,17,35,4,48,5,17,33,34,1,33,19,33,16,36,33,16,32,49,34,3,32,32,49,48,33,4,16,37,16,33,48]

theorem envBound9241 : H12AffineFastState.Bounded env9241 := by
  intro p hp
  have h : env9241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9240_9241 : H12AffineEnvironment.transform 8 48 env9240 = env9241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env9240 == env9241) = true)

theorem identity9241 : scanCanonicalize (H12AffineFastState.compose env9241 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound9241 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9242 : List Nat := [2,4,3,1,32,0,35,4,33,5,0,33,34,1,33,2,33,1,36,33,1,32,32,34,3,32,32,32,33,33,4,1,37,1,33,33]

theorem envBound9242 : H12AffineFastState.Bounded env9242 := by
  intro p hp
  have h : env9242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9241_9242 : H12AffineEnvironment.transform 3 1 env9241 = env9242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env9241 == env9242) = true)

theorem identity9242 : scanCanonicalize (H12AffineFastState.compose env9242 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound9242 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env9243 : List Nat := [2,4,3,1,0,0,3,4,1,5,0,1,2,1,1,2,1,1,4,1,1,0,0,2,3,0,0,0,1,1,4,1,5,1,1,1]

theorem envBound9243 : H12AffineFastState.Bounded env9243 := by
  intro p hp
  have h : env9243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9242_9243 : H12AffineEnvironment.transform 4 0 env9242 = env9243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9242 == env9243) = true)

def env9244 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,262144,4961,8693,2097152,4194304,5005,90336,8329,21040,278625,4214985,4215093,75787,504,4268382,4960,73771,2175667,90943]

theorem envBound9244 : H12AffineFastState.Bounded env9244 := by
  intro p hp
  have h : env9244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9160_9244 : H12AffineEnvironment.transform 18 4961 env9160 = env9244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4961 env9160 == env9244) = true)

theorem identity9244 : scanCanonicalize (H12AffineFastState.compose env9244 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 24770) := by decide +kernel

theorem selectedBound9244 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9245 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,24770,4605,262144,4961,8693,2097152,4194304,5005,34,8329,21040,278625,4214985,4215093,18633,504,4211100,4960,16617,2118257,1021]

theorem envBound9245 : H12AffineFastState.Bounded env9245 := by
  intro p hp
  have h : env9245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9244_9245 : H12AffineEnvironment.transform 15 24770 env9244 = env9245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24770 env9244 == env9245) = true)

def env9246 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,24770,4605,262144,4961,8693,64,4194304,5005,34,8329,21040,278625,4214985,4215093,18633,504,4211100,4960,16617,21041,1021]

theorem envBound9246 : H12AffineFastState.Bounded env9246 := by
  intro p hp
  have h : env9246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9245_9246 : H12AffineEnvironment.transform 20 64 env9245 = env9246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env9245 == env9246) = true)

theorem identity9246 : scanCanonicalize (H12AffineFastState.compose env9246 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 4170) := by decide +kernel

theorem selectedBound9246 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9247 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,24770,4605,4170,4961,8693,64,4194304,5005,34,8329,21040,20523,4214985,4215093,18633,504,4211100,4960,16617,21041,1021]

theorem envBound9247 : H12AffineFastState.Bounded env9247 := by
  intro p hp
  have h : env9247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9246_9247 : H12AffineEnvironment.transform 17 4170 env9246 = env9247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4170 env9246 == env9247) = true)

def env9248 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,232,8693,8234,4605,4170,4961,8693,64,4194304,5005,34,8329,4824,4291,4198433,4198877,2081,504,4194676,4960,1,4825,1021]

theorem envBound9248 : H12AffineFastState.Bounded env9248 := by
  intro p hp
  have h : env9248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9247_9248 : H12AffineEnvironment.transform 13 232 env9247 = env9248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 232 env9247 == env9248) = true)

theorem identity9248 : scanCanonicalize (H12AffineFastState.compose env9248 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound9248 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9249 : List Nat := [2,4,8,16,32,64,128,84,512,85,2048,4096,8192,232,8353,8234,4265,4170,4661,8353,64,4194304,4825,34,8329,4824,4291,4198433,4198537,2081,172,4194336,4660,1,4825,681]

theorem envBound9249 : H12AffineFastState.Bounded env9249 := by
  intro p hp
  have h : env9249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9248_9249 : H12AffineEnvironment.transform 7 84 env9248 = env9249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env9248 == env9249) = true)

theorem identity9249 : scanCanonicalize (H12AffineFastState.compose env9249 (packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound9249 : packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env9250 : List Nat := [2,4,8,16,32,64,128,84,512,85,674,4096,8192,232,8353,8234,4265,4170,4661,8353,64,4194304,4825,34,8329,4824,4291,4198433,4198537,643,172,4194336,4660,1,4825,681]

theorem envBound9250 : H12AffineFastState.Bounded env9250 := by
  intro p hp
  have h : env9250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9249_9250 : H12AffineEnvironment.transform 10 674 env9249 = env9250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env9249 == env9250) = true)

theorem identity9250 : scanCanonicalize (H12AffineFastState.compose env9250 (packedSelected [3,4,7,9,10,18,19,23,24,27] rootPS)) = affineNative (2^(11+1) ^^^ 712) := by decide +kernel

theorem selectedBound9250 : packedSelected [3,4,7,9,10,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env9251 : List Nat := [2,4,8,16,32,64,128,84,512,85,674,712,8192,232,8353,8234,609,642,253,8353,64,4194304,17,34,8329,16,523,4195049,4194881,643,172,4194336,252,1,17,681]

theorem envBound9251 : H12AffineFastState.Bounded env9251 := by
  intro p hp
  have h : env9251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9250_9251 : H12AffineEnvironment.transform 11 712 env9250 = env9251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 712 env9250 == env9251) = true)

theorem identity9251 : scanCanonicalize (H12AffineFastState.compose env9251 (packedSelected [0,3,4,7,9,10,12,15,19,28] rootPS)) = affineNative (2^(21+1) ^^^ 217) := by decide +kernel

theorem selectedBound9251 : packedSelected [0,3,4,7,9,10,12,15,19,28] rootPS < 2^1333 := by decide +kernel

def env9252 : List Nat := [2,4,8,16,32,64,128,84,512,85,674,712,8192,232,8353,8234,609,642,253,8353,64,217,17,34,8329,16,523,560,664,643,172,249,252,1,17,681]

theorem envBound9252 : H12AffineFastState.Bounded env9252 := by
  intro p hp
  have h : env9252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9251_9252 : H12AffineEnvironment.transform 21 217 env9251 = env9252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 217 env9251 == env9252) = true)

theorem identity9252 : scanCanonicalize (H12AffineFastState.compose env9252 (packedSelected [10,11,12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 730) := by decide +kernel

theorem selectedBound9252 : packedSelected [10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env9253 : List Nat := [2,4,8,16,32,64,128,84,512,85,674,712,730,232,635,752,609,642,253,635,64,217,17,34,595,16,523,560,664,643,172,249,252,1,17,681]

theorem envBound9253 : H12AffineFastState.Bounded env9253 := by
  intro p hp
  have h : env9253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9252_9253 : H12AffineEnvironment.transform 12 730 env9252 = env9253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 730 env9252 == env9253) = true)

theorem identity9253 : scanCanonicalize (H12AffineFastState.compose env9253 (packedSelected [2,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound9253 : packedSelected [2,9,11] rootPS < 2^1333 := by decide +kernel

def env9254 : List Nat := [2,4,8,16,32,58,128,46,512,47,674,690,672,146,513,650,539,642,135,513,58,163,17,34,553,16,523,560,664,643,172,131,134,1,17,681]

theorem envBound9254 : H12AffineFastState.Bounded env9254 := by
  intro p hp
  have h : env9254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9253_9254 : H12AffineEnvironment.transform 5 58 env9253 = env9254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env9253 == env9254) = true)

theorem identity9254 : scanCanonicalize (H12AffineFastState.compose env9254 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound9254 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env9255 : List Nat := [2,4,8,16,32,58,128,46,1,47,163,179,161,146,0,139,26,131,135,0,58,163,17,34,40,16,10,49,153,130,172,131,134,1,17,168]

theorem envBound9255 : H12AffineFastState.Bounded env9255 := by
  intro p hp
  have h : env9255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9254_9255 : H12AffineEnvironment.transform 8 1 env9254 = env9255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env9254 == env9255) = true)

theorem identity9255 : scanCanonicalize (H12AffineFastState.compose env9255 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound9255 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9256 : List Nat := [2,4,8,16,32,58,41,46,1,47,10,26,8,59,0,34,26,42,46,0,58,10,17,34,40,16,10,49,48,43,5,42,47,1,17,1]

theorem envBound9256 : H12AffineFastState.Bounded env9256 := by
  intro p hp
  have h : env9256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9255_9256 : H12AffineEnvironment.transform 6 41 env9255 = env9256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env9255 == env9256) = true)

theorem identity9256 : scanCanonicalize (H12AffineFastState.compose env9256 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound9256 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env9257 : List Nat := [2,4,8,16,10,16,3,4,1,5,10,26,8,17,0,8,26,0,4,0,16,10,17,8,2,16,10,27,26,1,5,0,5,1,17,1]

theorem envBound9257 : H12AffineFastState.Bounded env9257 := by
  intro p hp
  have h : env9257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9256_9257 : H12AffineEnvironment.transform 4 10 env9256 = env9257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env9256 == env9257) = true)

theorem identity9257 : scanCanonicalize (H12AffineFastState.compose env9257 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound9257 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9258 : List Nat := [2,4,8,11,10,11,3,4,1,5,10,1,8,10,0,8,1,0,4,0,11,10,10,8,2,11,10,0,1,1,5,0,5,1,10,1]

theorem envBound9258 : H12AffineFastState.Bounded env9258 := by
  intro p hp
  have h : env9258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9257_9258 : H12AffineEnvironment.transform 3 11 env9257 = env9258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env9257 == env9258) = true)

theorem identity9258 : scanCanonicalize (H12AffineFastState.compose env9258 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9258 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env9259 : List Nat := [2,4,3,0,1,0,3,4,1,5,1,1,3,1,0,3,1,0,4,0,0,1,1,3,2,0,1,0,1,1,5,0,5,1,1,1]

theorem envBound9259 : H12AffineFastState.Bounded env9259 := by
  intro p hp
  have h : env9259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9258_9259 : H12AffineEnvironment.transform 2 3 env9258 = env9259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9258 == env9259) = true)

def leafEnv9259 : List Nat := [2,4,3,0,1,0,3,4,1,5,1,1,3,1,0,3,1,0,4,0,0,1,1,3,4,2,1,0,1,0,1,1,5,0,5,1,5,3,1,1,1,1,0]

def active9259 : List Nat := [0,1]

def tree9259 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9259 : H12WitnessSearch.Good tree9259 := H12GlobalWitnessIndex.good

theorem leafIdentity9259 : H12AffineFastState.composeSystem env9259 rootObs = leafEnv9259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9259 rootObs == leafEnv9259) = true)

theorem terminalChecked9259 : H12PackedTerminal.terminalCheckFast leafEnv9259 active9259 tree9259 = true := by decide +kernel

def env9260 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,233,8693,8235,4605,4170,4961,8693,64,4194304,5005,34,8329,4825,4290,4198432,4198876,2080,504,4194677,4960,0,4824,1021]

theorem envBound9260 : H12AffineFastState.Bounded env9260 := by
  intro p hp
  have h : env9260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9247_9260 : H12AffineEnvironment.transform 13 233 env9247 = env9260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 233 env9247 == env9260) = true)

theorem identity9260 : scanCanonicalize (H12AffineFastState.compose env9260 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(21+1) ^^^ 477) := by decide +kernel

theorem selectedBound9260 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9261 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,233,8693,8235,4605,4170,4961,8693,64,477,5005,34,8329,4825,4290,4605,4097,2080,504,168,4960,0,4824,1021]

theorem envBound9261 : H12AffineFastState.Bounded env9261 := by
  intro p hp
  have h : env9261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9260_9261 : H12AffineEnvironment.transform 21 477 env9260 = env9261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 477 env9260 == env9261) = true)

theorem identity9261 : scanCanonicalize (H12AffineFastState.compose env9261 (packedSelected [1,3,4,7,9,12,14,18,23,27,38] rootPS)) = affineNative (2^(10+1) ^^^ 935) := by decide +kernel

theorem selectedBound9261 : packedSelected [1,3,4,7,9,12,14,18,23,27,38] rootPS < 2^1333 := by decide +kernel

def env9262 : List Nat := [2,4,8,16,32,64,128,256,512,257,935,4096,8192,233,8693,8235,4605,4170,4961,8693,64,477,5005,34,8329,4825,4290,4605,4097,903,504,168,4960,0,4824,1021]

theorem envBound9262 : H12AffineFastState.Bounded env9262 := by
  intro p hp
  have h : env9262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9261_9262 : H12AffineEnvironment.transform 10 935 env9261 = env9262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 935 env9261 == env9262) = true)

theorem identity9262 : scanCanonicalize (H12AffineFastState.compose env9262 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound9262 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env9263 : List Nat := [2,4,8,16,32,64,128,253,512,252,602,4096,8192,233,8200,8235,4096,4170,4764,8200,64,32,4720,34,8329,4825,4290,4096,4097,634,5,168,4765,0,4824,512]

theorem envBound9263 : H12AffineFastState.Bounded env9263 := by
  intro p hp
  have h : env9263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9262_9263 : H12AffineEnvironment.transform 7 253 env9262 = env9263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env9262 == env9263) = true)

theorem identity9263 : scanCanonicalize (H12AffineFastState.compose env9263 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound9263 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9264 : List Nat := [2,4,8,16,32,64,41,84,512,85,602,4096,8192,64,8200,8235,4096,4170,4661,8200,64,32,4720,34,8224,4720,4203,4096,4097,634,5,1,4660,0,4721,512]

theorem envBound9264 : H12AffineFastState.Bounded env9264 := by
  intro p hp
  have h : env9264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9263_9264 : H12AffineEnvironment.transform 6 41 env9263 = env9264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env9263 == env9264) = true)

theorem identity9264 : scanCanonicalize (H12AffineFastState.compose env9264 (packedSelected [0,1,2,3,4,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 544) := by decide +kernel

theorem selectedBound9264 : packedSelected [0,1,2,3,4,8,11] rootPS < 2^1333 := by decide +kernel

def env9265 : List Nat := [2,4,8,16,32,64,41,84,512,85,602,544,8192,64,8200,8235,544,618,21,8200,64,32,80,34,8224,80,587,544,545,634,5,1,20,0,81,512]

theorem envBound9265 : H12AffineFastState.Bounded env9265 := by
  intro p hp
  have h : env9265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9264_9265 : H12AffineEnvironment.transform 11 544 env9264 = env9265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env9264 == env9265) = true)

theorem identity9265 : scanCanonicalize (H12AffineFastState.compose env9265 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 50) := by decide +kernel

theorem selectedBound9265 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env9266 : List Nat := [2,4,8,16,32,64,41,84,512,85,602,544,50,64,58,25,544,618,21,58,64,32,80,34,18,80,587,544,545,634,5,1,20,0,81,512]

theorem envBound9266 : H12AffineFastState.Bounded env9266 := by
  intro p hp
  have h : env9266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9265_9266 : H12AffineEnvironment.transform 12 50 env9265 = env9266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 50 env9265 == env9266) = true)

theorem identity9266 : scanCanonicalize (H12AffineFastState.compose env9266 (packedSelected [0,2,4,8,12] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound9266 : packedSelected [0,2,4,8,12] rootPS < 2^1333 := by decide +kernel

def env9267 : List Nat := [2,4,8,16,32,64,41,84,65,85,27,97,50,64,58,25,97,43,21,58,64,32,80,34,18,80,10,97,96,59,5,1,20,0,81,65]

theorem envBound9267 : H12AffineFastState.Bounded env9267 := by
  intro p hp
  have h : env9267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9266_9267 : H12AffineEnvironment.transform 8 65 env9266 = env9267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env9266 == env9267) = true)

theorem identity9267 : scanCanonicalize (H12AffineFastState.compose env9267 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound9267 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env9268 : List Nat := [2,4,8,10,32,64,41,78,65,79,1,97,40,64,32,3,97,43,15,32,64,32,74,34,8,74,10,97,96,33,5,1,14,0,75,65]

theorem envBound9268 : H12AffineFastState.Bounded env9268 := by
  intro p hp
  have h : env9268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9267_9268 : H12AffineEnvironment.transform 3 10 env9267 = env9268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env9267 == env9268) = true)

theorem identity9268 : scanCanonicalize (H12AffineFastState.compose env9268 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound9268 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9269 : List Nat := [2,4,8,10,32,1,41,15,0,14,1,32,40,1,32,3,32,43,15,32,1,32,11,34,8,11,10,32,33,33,5,1,14,0,10,0]

theorem envBound9269 : H12AffineFastState.Bounded env9269 := by
  intro p hp
  have h : env9269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9268_9269 : H12AffineEnvironment.transform 5 1 env9268 = env9269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env9268 == env9269) = true)

theorem identity9269 : scanCanonicalize (H12AffineFastState.compose env9269 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9269 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9270 : List Nat := [2,4,2,0,32,1,35,5,0,4,1,32,34,1,32,3,32,33,5,32,1,32,1,34,2,1,0,32,33,33,5,1,4,0,0,0]

theorem envBound9270 : H12AffineFastState.Bounded env9270 := by
  intro p hp
  have h : env9270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9269_9270 : H12AffineEnvironment.transform 2 2 env9269 = env9270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9269 == env9270) = true)

theorem identity9270 : scanCanonicalize (H12AffineFastState.compose env9270 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound9270 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env9271 : List Nat := [2,4,2,0,0,1,3,5,0,4,1,0,2,1,0,3,0,1,5,0,1,0,1,2,2,1,0,0,1,1,5,1,4,0,0,0]

theorem envBound9271 : H12AffineFastState.Bounded env9271 := by
  intro p hp
  have h : env9271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9270_9271 : H12AffineEnvironment.transform 4 0 env9270 = env9271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9270 == env9271) = true)

def leafEnv9271 : List Nat := [2,4,2,0,0,1,3,5,0,4,1,0,2,1,0,3,0,1,5,0,1,0,1,2,4,2,1,1,0,0,1,1,5,1,4,0,5,2,0,0,1,1,0]

def active9271 : List Nat := [0,1]

def tree9271 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9271 : H12WitnessSearch.Good tree9271 := H12GlobalWitnessIndex.good

theorem leafIdentity9271 : H12AffineFastState.composeSystem env9271 rootObs = leafEnv9271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9271 rootObs == leafEnv9271) = true)

theorem terminalChecked9271 : H12PackedTerminal.terminalCheckFast leafEnv9271 active9271 tree9271 = true := by decide +kernel

def env9272 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,24770,4605,262144,4961,8693,65,4194304,5005,34,8329,21040,278625,4214985,4215093,18633,504,4211100,4960,16617,21040,1021]

theorem envBound9272 : H12AffineFastState.Bounded env9272 := by
  intro p hp
  have h : env9272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9245_9272 : H12AffineEnvironment.transform 20 65 env9245 = env9272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env9245 == env9272) = true)

theorem identity9272 : scanCanonicalize (H12AffineFastState.compose env9272 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 554) := by decide +kernel

theorem selectedBound9272 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9273 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,24770,4605,554,4961,8693,65,4194304,5005,34,8329,21040,16971,4214985,4215093,18633,504,4211100,4960,16617,21040,1021]

theorem envBound9273 : H12AffineFastState.Bounded env9273 := by
  intro p hp
  have h : env9273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9272_9273 : H12AffineEnvironment.transform 17 554 env9272 = env9273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 554 env9272 == env9273) = true)

def env9274 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,232,8693,8234,4605,554,4961,8693,65,4194304,5005,34,8329,4824,675,4198433,4198877,2081,504,4194676,4960,1,4824,1021]

theorem envBound9274 : H12AffineFastState.Bounded env9274 := by
  intro p hp
  have h : env9274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9273_9274 : H12AffineEnvironment.transform 13 232 env9273 = env9274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 232 env9273 == env9274) = true)

theorem identity9274 : scanCanonicalize (H12AffineFastState.compose env9274 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound9274 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9275 : List Nat := [2,4,8,16,32,64,128,85,512,84,2048,4096,8192,232,8352,8234,4264,554,4660,8352,65,4194304,4824,34,8329,4824,675,4198433,4198536,2081,173,4194337,4661,1,4824,680]

theorem envBound9275 : H12AffineFastState.Bounded env9275 := by
  intro p hp
  have h : env9275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9274_9275 : H12AffineEnvironment.transform 7 85 env9274 = env9275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env9274 == env9275) = true)

theorem identity9275 : scanCanonicalize (H12AffineFastState.compose env9275 (packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS)) = affineNative (2^(11+1) ^^^ 2194) := by decide +kernel

theorem selectedBound9275 : packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env9276 : List Nat := [2,4,8,16,32,64,128,85,512,84,2048,2194,8192,232,8352,8234,2106,554,2726,8352,65,4194304,2634,34,8329,2634,675,4196531,4196378,2081,173,4194337,2727,1,2634,680]

theorem envBound9276 : H12AffineFastState.Bounded env9276 := by
  intro p hp
  have h : env9276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9275_9276 : H12AffineEnvironment.transform 11 2194 env9275 = env9276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2194 env9275 == env9276) = true)

theorem identity9276 : scanCanonicalize (H12AffineFastState.compose env9276 (packedSelected [1,3,4,7,9,12,14,15,27] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound9276 : packedSelected [1,3,4,7,9,12,14,15,27] rootPS < 2^1333 := by decide +kernel

def env9277 : List Nat := [2,4,8,16,32,64,121,85,512,84,2048,2155,8192,17,8281,8234,2106,554,2655,8281,65,4194304,2634,34,8304,2634,602,4196426,4196378,2081,84,4194337,2654,1,2634,593]

theorem envBound9277 : H12AffineFastState.Bounded env9277 := by
  intro p hp
  have h : env9277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9276_9277 : H12AffineEnvironment.transform 6 121 env9276 = env9277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env9276 == env9277) = true)

theorem identity9277 : scanCanonicalize (H12AffineFastState.compose env9277 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound9277 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env9278 : List Nat := [2,4,8,16,32,64,121,85,512,84,2048,2155,8192,17,8281,8234,2106,554,2655,8281,65,113,2634,34,8304,2634,602,2107,2155,2081,84,80,2654,1,2634,593]

theorem envBound9278 : H12AffineFastState.Bounded env9278 := by
  intro p hp
  have h : env9278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9277_9278 : H12AffineEnvironment.transform 21 113 env9277 = env9278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env9277 == env9278) = true)

theorem identity9278 : scanCanonicalize (H12AffineFastState.compose env9278 (packedSelected [0,2,5,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 112) := by decide +kernel

theorem selectedBound9278 : packedSelected [0,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env9279 : List Nat := [2,4,8,16,32,64,121,85,112,84,2048,2155,8192,17,8281,8234,2106,90,2095,8281,65,113,2106,34,8304,2106,42,2107,2155,2081,84,80,2094,1,2106,33]

theorem envBound9279 : H12AffineFastState.Bounded env9279 := by
  intro p hp
  have h : env9279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9278_9279 : H12AffineEnvironment.transform 8 112 env9278 = env9279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 112 env9278 == env9279) = true)

def env9280 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,233,8693,8235,4605,554,4961,8693,65,4194304,5005,34,8329,4825,674,4198432,4198876,2080,504,4194677,4960,0,4825,1021]

theorem envBound9280 : H12AffineFastState.Bounded env9280 := by
  intro p hp
  have h : env9280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9273_9280 : H12AffineEnvironment.transform 13 233 env9273 = env9280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 233 env9273 == env9280) = true)

theorem identity9280 : scanCanonicalize (H12AffineFastState.compose env9280 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(21+1) ^^^ 476) := by decide +kernel

theorem selectedBound9280 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9281 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,233,8693,8235,4605,554,4961,8693,65,476,5005,34,8329,4825,674,4604,4096,2080,504,169,4960,0,4825,1021]

theorem envBound9281 : H12AffineFastState.Bounded env9281 := by
  intro p hp
  have h : env9281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9280_9281 : H12AffineEnvironment.transform 21 476 env9280 = env9281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 476 env9280 == env9281) = true)

theorem identity9281 : scanCanonicalize (H12AffineFastState.compose env9281 (packedSelected [1,3,4,7,9,12,14,18,23,27,38] rootPS)) = affineNative (2^(11+1) ^^^ 2455) := by decide +kernel

theorem selectedBound9281 : packedSelected [1,3,4,7,9,12,14,18,23,27,38] rootPS < 2^1333 := by decide +kernel

def env9282 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,2455,8192,233,8693,8235,2154,554,2806,8693,65,476,2586,34,8329,2894,674,2155,2455,2080,504,169,2807,0,2894,1021]

theorem envBound9282 : H12AffineFastState.Bounded env9282 := by
  intro p hp
  have h : env9282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9281_9282 : H12AffineEnvironment.transform 11 2455 env9281 = env9282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2455 env9281 == env9282) = true)

theorem identity9282 : scanCanonicalize (H12AffineFastState.compose env9282 (packedSelected [0,3,4,5,7,8,9,12,13,15,17,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound9282 : packedSelected [0,3,4,5,7,8,9,12,13,15,17,24] rootPS < 2^1333 := by decide +kernel

def env9283 : List Nat := [2,4,8,16,32,64,128,173,512,172,2048,2106,8192,233,8280,8235,2154,554,2806,8280,65,113,2586,34,8329,2787,674,2155,2106,2080,85,169,2807,0,2787,592]

theorem envBound9283 : H12AffineFastState.Bounded env9283 := by
  intro p hp
  have h : env9283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9282_9283 : H12AffineEnvironment.transform 7 173 env9282 = env9283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env9282 == env9283) = true)

theorem identity9283 : scanCanonicalize (H12AffineFastState.compose env9283 (packedSelected [0,1,3,4,10,11,12,13,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 2721) := by decide +kernel

theorem selectedBound9283 : packedSelected [0,1,3,4,10,11,12,13,14,15,18] rootPS < 2^1333 := by decide +kernel

def env9284 : List Nat := [2,4,8,16,32,64,128,173,512,172,2048,2106,2721,233,2809,2698,2154,554,2806,2809,65,113,2586,34,2600,2787,674,2155,2106,2080,85,169,2807,0,2787,592]

theorem envBound9284 : H12AffineFastState.Bounded env9284 := by
  intro p hp
  have h : env9284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9283_9284 : H12AffineEnvironment.transform 12 2721 env9283 = env9284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2721 env9283 == env9284) = true)

theorem identity9284 : scanCanonicalize (H12AffineFastState.compose env9284 (packedSelected [2,3,4,7,8,14] rootPS)) = affineNative (2^(10+1) ^^^ 754) := by decide +kernel

theorem selectedBound9284 : packedSelected [2,3,4,7,8,14] rootPS < 2^1333 := by decide +kernel

def env9285 : List Nat := [2,4,8,16,32,64,128,173,512,172,754,712,83,233,11,120,664,554,4,11,65,113,232,34,218,17,674,665,712,722,85,169,5,0,17,592]

theorem envBound9285 : H12AffineFastState.Bounded env9285 := by
  intro p hp
  have h : env9285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9284_9285 : H12AffineEnvironment.transform 10 754 env9284 = env9285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 754 env9284 == env9285) = true)

theorem identity9285 : scanCanonicalize (H12AffineFastState.compose env9285 (packedSelected [0,1,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound9285 : packedSelected [0,1,8,9,10] rootPS < 2^1333 := by decide +kernel

def env9286 : List Nat := [2,4,8,16,32,64,128,173,1,172,243,201,83,233,11,120,153,43,4,11,65,113,232,34,218,17,163,152,201,211,85,169,5,0,17,81]

theorem envBound9286 : H12AffineFastState.Bounded env9286 := by
  intro p hp
  have h : env9286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9285_9286 : H12AffineEnvironment.transform 8 1 env9285 = env9286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env9285 == env9286) = true)

theorem identity9286 : scanCanonicalize (H12AffineFastState.compose env9286 (packedSelected [0,4,5,8,9] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9286 : packedSelected [0,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env9287 : List Nat := [2,4,3,16,32,64,128,166,1,167,243,194,83,226,0,115,146,32,4,0,65,113,227,34,209,17,163,147,194,211,85,162,5,0,17,81]

theorem envBound9287 : H12AffineFastState.Bounded env9287 := by
  intro p hp
  have h : env9287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9286_9287 : H12AffineEnvironment.transform 2 3 env9286 = env9287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9286 == env9287) = true)

theorem identity9287 : scanCanonicalize (H12AffineFastState.compose env9287 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound9287 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env9288 : List Nat := [2,4,3,16,32,64,34,4,1,5,81,96,83,64,0,115,48,32,4,0,65,113,65,34,115,17,1,49,96,113,85,0,5,0,17,81]

theorem envBound9288 : H12AffineFastState.Bounded env9288 := by
  intro p hp
  have h : env9288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9287_9288 : H12AffineEnvironment.transform 6 34 env9287 = env9288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env9287 == env9288) = true)

theorem identity9288 : scanCanonicalize (H12AffineFastState.compose env9288 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound9288 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env9289 : List Nat := [2,4,3,16,32,16,34,4,1,5,1,48,3,16,0,35,48,32,4,0,17,33,17,34,35,17,1,49,48,33,5,0,5,0,17,1]

theorem envBound9289 : H12AffineFastState.Bounded env9289 := by
  intro p hp
  have h : env9289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9288_9289 : H12AffineEnvironment.transform 5 16 env9288 = env9289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9288 == env9289) = true)

theorem identity9289 : scanCanonicalize (H12AffineFastState.compose env9289 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound9289 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9290 : List Nat := [2,4,3,16,17,16,19,4,1,5,1,1,3,16,0,18,1,17,4,0,17,16,17,19,18,17,1,0,1,16,5,0,5,0,17,1]

theorem envBound9290 : H12AffineFastState.Bounded env9290 := by
  intro p hp
  have h : env9290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9289_9290 : H12AffineEnvironment.transform 4 17 env9289 = env9290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env9289 == env9290) = true)

def env9291 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,4194304,524524,90337,8329,21041,807680,4735912,4735572,605035,529049,4796990,524289,602955,2695635,90942]

theorem envBound9291 : H12AffineFastState.Bounded env9291 := by
  intro p hp
  have h : env9291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9159_9291 : H12AffineEnvironment.transform 23 90337 env9159 = env9291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90337 env9159 == env9291) = true)

def env9292 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,262144,4960,8693,2097152,4194304,5004,90337,8329,21041,278624,4214984,4215092,75787,505,4268382,4961,73771,2175667,90942]

theorem envBound9292 : H12AffineFastState.Bounded env9292 := by
  intro p hp
  have h : env9292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9291_9292 : H12AffineEnvironment.transform 18 4960 env9291 = env9292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4960 env9291 == env9292) = true)

theorem identity9292 : scanCanonicalize (H12AffineFastState.compose env9292 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 24771) := by decide +kernel

theorem selectedBound9292 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9293 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,24771,4605,262144,4960,8693,2097152,4194304,5004,34,8329,21041,278624,4214984,4215092,18632,505,4211101,4961,16616,2118256,1021]

theorem envBound9293 : H12AffineFastState.Bounded env9293 := by
  intro p hp
  have h : env9293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9292_9293 : H12AffineEnvironment.transform 15 24771 env9292 = env9293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24771 env9292 == env9293) = true)

def env9294 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,24771,4605,262144,4960,8693,64,4194304,5004,34,8329,21041,278624,4214984,4215092,18632,505,4211101,4961,16616,21040,1021]

theorem envBound9294 : H12AffineFastState.Bounded env9294 := by
  intro p hp
  have h : env9294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9293_9294 : H12AffineEnvironment.transform 20 64 env9293 = env9294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env9293 == env9294) = true)

theorem identity9294 : scanCanonicalize (H12AffineFastState.compose env9294 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 262818) := by decide +kernel

theorem selectedBound9294 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9295 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,24771,4605,262144,4960,8693,64,262818,5004,34,8329,21041,278624,283242,283542,18632,505,279359,4961,16616,21040,1021]

theorem envBound9295 : H12AffineFastState.Bounded env9295 := by
  intro p hp
  have h : env9295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9294_9295 : H12AffineEnvironment.transform 21 262818 env9294 = env9295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 262818 env9294 == env9295) = true)

def env9296 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,560,8693,8947,4605,262144,4960,8693,64,262818,5004,34,8329,4097,262736,266330,266662,2808,505,262415,4961,728,4096,1021]

theorem envBound9296 : H12AffineFastState.Bounded env9296 := by
  intro p hp
  have h : env9296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9295_9296 : H12AffineEnvironment.transform 13 560 env9295 = env9296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env9295 == env9296) = true)

def env9297 : List Nat := [2,4,8,16,32,64,128,256,216,257,2048,4096,8192,232,8693,8235,4605,262144,4536,8693,64,262266,4436,34,8329,4097,262280,266330,266662,2080,505,262415,4537,0,4096,293]

theorem envBound9297 : H12AffineFastState.Bounded env9297 := by
  intro p hp
  have h : env9297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9296_9297 : H12AffineEnvironment.transform 8 216 env9296 = env9297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env9296 == env9297) = true)

theorem identity9297 : scanCanonicalize (H12AffineFastState.compose env9297 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 423) := by decide +kernel

theorem selectedBound9297 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9298 : List Nat := [2,4,8,16,32,64,128,256,216,257,2048,4096,8192,232,8693,8235,4605,423,4536,8693,64,477,4436,34,8329,4097,303,4605,4097,2080,505,168,4537,0,4096,293]

theorem envBound9298 : H12AffineFastState.Bounded env9298 := by
  intro p hp
  have h : env9298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9297_9298 : H12AffineEnvironment.transform 17 423 env9297 = env9298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 423 env9297 == env9298) = true)

theorem identity9298 : scanCanonicalize (H12AffineFastState.compose env9298 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound9298 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9299 : List Nat := [2,4,8,16,32,64,128,84,216,85,2048,4096,8192,232,8353,8235,4265,243,4332,8353,64,137,4096,34,8329,4097,123,4265,4097,2080,173,168,4333,0,4096,113]

theorem envBound9299 : H12AffineFastState.Bounded env9299 := by
  intro p hp
  have h : env9299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9298_9299 : H12AffineEnvironment.transform 7 84 env9298 = env9299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env9298 == env9299) = true)

theorem identity9299 : scanCanonicalize (H12AffineFastState.compose env9299 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 6347) := by decide +kernel

theorem selectedBound9299 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env9300 : List Nat := [2,4,8,16,32,64,128,84,216,85,2048,4096,6347,232,6250,6368,4265,243,4332,6250,64,137,4096,34,6210,4097,123,4265,4097,2080,173,168,4333,0,4096,113]

theorem envBound9300 : H12AffineFastState.Bounded env9300 := by
  intro p hp
  have h : env9300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9299_9300 : H12AffineEnvironment.transform 12 6347 env9299 = env9300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6347 env9299 == env9300) = true)

theorem identity9300 : scanCanonicalize (H12AffineFastState.compose env9300 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(11+1) ^^^ 2091) := by decide +kernel

theorem selectedBound9300 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env9301 : List Nat := [2,4,8,16,32,64,128,84,216,85,2048,2091,224,232,65,203,2178,243,2247,65,64,137,2091,34,105,2090,123,2178,2090,2080,173,168,2246,0,2091,113]

theorem envBound9301 : H12AffineFastState.Bounded env9301 := by
  intro p hp
  have h : env9301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9300_9301 : H12AffineEnvironment.transform 11 2091 env9300 = env9301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2091 env9300 == env9301) = true)

theorem identity9301 : scanCanonicalize (H12AffineFastState.compose env9301 (packedSelected [1,3,4,9,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound9301 : packedSelected [1,3,4,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env9302 : List Nat := [2,4,8,16,32,64,128,84,216,85,49,26,224,232,65,203,179,243,246,65,64,137,26,34,105,27,123,179,27,17,173,168,247,0,26,113]

theorem envBound9302 : H12AffineFastState.Bounded env9302 := by
  intro p hp
  have h : env9302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9301_9302 : H12AffineEnvironment.transform 10 49 env9301 = env9302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env9301 == env9302) = true)

theorem identity9302 : scanCanonicalize (H12AffineFastState.compose env9302 (packedSelected [0,1,3,4,5,7,8,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound9302 : packedSelected [0,1,3,4,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env9303 : List Nat := [2,4,8,16,26,64,128,84,216,85,11,26,218,210,65,203,137,201,204,65,64,137,26,24,83,27,65,137,27,17,151,146,205,0,26,75]

theorem envBound9303 : H12AffineFastState.Bounded env9303 := by
  intro p hp
  have h : env9303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9302_9303 : H12AffineEnvironment.transform 4 26 env9302 = env9303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env9302 == env9303) = true)

theorem identity9303 : scanCanonicalize (H12AffineFastState.compose env9303 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound9303 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env9304 : List Nat := [2,4,8,11,1,64,128,79,195,78,11,1,193,201,65,203,137,201,204,65,64,137,1,3,72,0,65,137,0,10,140,137,205,0,1,75]

theorem envBound9304 : H12AffineFastState.Bounded env9304 := by
  intro p hp
  have h : env9304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9303_9304 : H12AffineEnvironment.transform 3 11 env9303 = env9304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env9303 == env9304) = true)

theorem identity9304 : scanCanonicalize (H12AffineFastState.compose env9304 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9304 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env9305 : List Nat := [2,4,3,0,1,64,128,68,195,69,0,1,193,194,65,192,130,194,199,65,64,130,1,3,67,0,65,130,0,1,135,130,198,0,1,64]

theorem envBound9305 : H12AffineFastState.Bounded env9305 := by
  intro p hp
  have h : env9305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9304_9305 : H12AffineEnvironment.transform 2 3 env9304 = env9305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9304 == env9305) = true)

theorem identity9305 : scanCanonicalize (H12AffineFastState.compose env9305 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound9305 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9306 : List Nat := [2,4,3,0,1,64,66,68,1,69,0,1,3,0,65,2,64,0,5,65,64,64,1,3,67,0,65,64,0,1,69,64,4,0,1,64]

theorem envBound9306 : H12AffineFastState.Bounded env9306 := by
  intro p hp
  have h : env9306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9305_9306 : H12AffineEnvironment.transform 6 66 env9305 = env9306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env9305 == env9306) = true)

theorem identity9306 : scanCanonicalize (H12AffineFastState.compose env9306 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound9306 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9307 : List Nat := [2,4,3,0,1,1,3,5,1,4,0,1,3,0,0,2,1,0,5,0,1,1,1,3,2,0,0,1,0,1,4,1,4,0,1,1]

theorem envBound9307 : H12AffineFastState.Bounded env9307 := by
  intro p hp
  have h : env9307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9306_9307 : H12AffineEnvironment.transform 5 1 env9306 = env9307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env9306 == env9307) = true)

def env9308 : List Nat := [2,4,8,16,32,64,128,256,217,257,2048,4096,8192,233,8693,8234,4605,262144,4537,8693,64,262267,4437,34,8329,4097,262281,266330,266662,2081,505,262415,4536,1,4096,292]

theorem envBound9308 : H12AffineFastState.Bounded env9308 := by
  intro p hp
  have h : env9308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9296_9308 : H12AffineEnvironment.transform 8 217 env9296 = env9308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env9296 == env9308) = true)

theorem identity9308 : scanCanonicalize (H12AffineFastState.compose env9308 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound9308 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9309 : List Nat := [2,4,8,16,32,64,128,84,217,85,2048,4096,8192,233,8353,8234,4265,262144,4333,8353,64,262267,4097,34,8329,4097,262281,266330,266482,2081,173,262235,4332,1,4096,112]

theorem envBound9309 : H12AffineFastState.Bounded env9309 := by
  intro p hp
  have h : env9309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9308_9309 : H12AffineEnvironment.transform 7 84 env9308 = env9309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env9308 == env9309) = true)

theorem identity9309 : scanCanonicalize (H12AffineFastState.compose env9309 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(17+1) ^^^ 91) := by decide +kernel

theorem selectedBound9309 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env9310 : List Nat := [2,4,8,16,32,64,128,84,217,85,2048,4096,8192,233,8353,8234,4265,91,4333,8353,64,32,4097,34,8329,4097,210,4097,4265,2081,173,0,4332,1,4096,112]

theorem envBound9310 : H12AffineFastState.Bounded env9310 := by
  intro p hp
  have h : env9310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9309_9310 : H12AffineEnvironment.transform 17 91 env9309 = env9310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 91 env9309 == env9310) = true)

theorem identity9310 : scanCanonicalize (H12AffineFastState.compose env9310 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2107) := by decide +kernel

theorem selectedBound9310 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env9311 : List Nat := [2,4,8,16,32,64,128,84,217,85,2048,2107,8192,233,8353,8234,2194,91,2262,8353,64,32,2106,34,8329,2106,210,2106,2194,2081,173,0,2263,1,2107,112]

theorem envBound9311 : H12AffineFastState.Bounded env9311 := by
  intro p hp
  have h : env9311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9310_9311 : H12AffineEnvironment.transform 11 2107 env9310 = env9311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2107 env9310 == env9311) = true)

theorem identity9311 : scanCanonicalize (H12AffineFastState.compose env9311 (packedSelected [0,1,3,4,7,9,12,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound9311 : packedSelected [0,1,3,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env9312 : List Nat := [2,4,8,16,32,64,41,84,112,85,2048,2107,8192,64,8200,8234,2107,91,2175,8200,64,32,2106,34,8224,2106,123,2106,2107,2081,4,0,2174,1,2107,112]

theorem envBound9312 : H12AffineFastState.Bounded env9312 := by
  intro p hp
  have h : env9312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9311_9312 : H12AffineEnvironment.transform 6 41 env9311 = env9312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env9311 == env9312) = true)

theorem identity9312 : scanCanonicalize (H12AffineFastState.compose env9312 (packedSelected [0,1,2,3,4,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 98) := by decide +kernel

theorem selectedBound9312 : packedSelected [0,1,2,3,4,8,11] rootPS < 2^1333 := by decide +kernel

def env9313 : List Nat := [2,4,8,16,32,64,41,84,112,85,2048,2107,98,64,106,72,2107,91,2175,106,64,32,2106,34,66,2106,123,2106,2107,2081,4,0,2174,1,2107,112]

theorem envBound9313 : H12AffineFastState.Bounded env9313 := by
  intro p hp
  have h : env9313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9312_9313 : H12AffineEnvironment.transform 12 98 env9312 = env9313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 98 env9312 == env9313) = true)

theorem identity9313 : scanCanonicalize (H12AffineFastState.compose env9313 (packedSelected [3,5,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound9313 : packedSelected [3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env9314 : List Nat := [2,4,8,16,32,64,41,84,112,85,81,106,98,64,106,72,106,91,46,106,64,32,107,34,66,107,123,107,106,112,4,0,47,1,106,112]

theorem envBound9314 : H12AffineFastState.Bounded env9314 := by
  intro p hp
  have h : env9314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9313_9314 : H12AffineEnvironment.transform 10 81 env9313 = env9314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env9313 == env9314) = true)

theorem identity9314 : scanCanonicalize (H12AffineFastState.compose env9314 (packedSelected [0,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound9314 : packedSelected [0,2,4,5] rootPS < 2^1333 := by decide +kernel

def env9315 : List Nat := [2,4,8,16,10,64,3,84,90,85,81,64,72,64,64,72,64,91,4,64,64,10,65,8,66,65,81,65,64,90,4,0,5,1,64,90]

theorem envBound9315 : H12AffineFastState.Bounded env9315 := by
  intro p hp
  have h : env9315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9314_9315 : H12AffineEnvironment.transform 4 10 env9314 = env9315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env9314 == env9315) = true)

theorem identity9315 : scanCanonicalize (H12AffineFastState.compose env9315 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9315 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env9316 : List Nat := [2,4,8,0,10,64,3,68,74,69,65,64,72,64,64,72,64,75,4,64,64,10,65,8,66,65,65,65,64,74,4,0,5,1,64,74]

theorem envBound9316 : H12AffineFastState.Bounded env9316 := by
  intro p hp
  have h : env9316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9315_9316 : H12AffineEnvironment.transform 3 0 env9315 = env9316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9315 == env9316) = true)

theorem identity9316 : scanCanonicalize (H12AffineFastState.compose env9316 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9316 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9317 : List Nat := [2,4,3,0,1,64,3,68,65,69,65,64,67,64,64,67,64,64,4,64,64,1,65,3,66,65,65,65,64,65,4,0,5,1,64,65]

theorem envBound9317 : H12AffineFastState.Bounded env9317 := by
  intro p hp
  have h : env9317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9316_9317 : H12AffineEnvironment.transform 2 3 env9316 = env9317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9316 == env9317) = true)

theorem identity9317 : scanCanonicalize (H12AffineFastState.compose env9317 (packedSelected [7] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound9317 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9318 : List Nat := [2,4,3,0,1,0,3,4,1,5,1,0,3,0,0,3,0,0,4,0,0,1,1,3,2,1,1,1,0,1,4,0,5,1,0,1]

theorem envBound9318 : H12AffineFastState.Bounded env9318 := by
  intro p hp
  have h : env9318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9317_9318 : H12AffineEnvironment.transform 5 0 env9317 = env9318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env9317 == env9318) = true)

def env9319 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,561,8693,8946,4605,262144,4960,8693,64,262818,5004,34,8329,4096,262737,266331,266663,2809,505,262414,4961,729,4097,1021]

theorem envBound9319 : H12AffineFastState.Bounded env9319 := by
  intro p hp
  have h : env9319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9295_9319 : H12AffineEnvironment.transform 13 561 env9295 = env9319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env9295 == env9319) = true)

def env9320 : List Nat := [2,4,8,16,32,64,128,256,216,257,2048,4096,8192,233,8693,8234,4605,262144,4536,8693,64,262266,4436,34,8329,4096,262281,266331,266663,2081,505,262414,4537,1,4097,293]

theorem envBound9320 : H12AffineFastState.Bounded env9320 := by
  intro p hp
  have h : env9320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9319_9320 : H12AffineEnvironment.transform 8 216 env9319 = env9320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env9319 == env9320) = true)

theorem identity9320 : scanCanonicalize (H12AffineFastState.compose env9320 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound9320 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9321 : List Nat := [2,4,8,16,32,64,128,84,216,85,2048,4096,8192,233,8353,8234,4265,262144,4332,8353,64,262266,4096,34,8329,4096,262281,266331,266483,2081,173,262234,4333,1,4097,113]

theorem envBound9321 : H12AffineFastState.Bounded env9321 := by
  intro p hp
  have h : env9321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9320_9321 : H12AffineEnvironment.transform 7 84 env9320 = env9321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env9320 == env9321) = true)

theorem identity9321 : scanCanonicalize (H12AffineFastState.compose env9321 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound9321 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env9322 : List Nat := [2,4,8,16,32,64,41,84,113,85,2048,4096,8192,64,8200,8234,4096,262144,4165,8200,64,262266,4096,34,8224,4096,262176,266331,266330,2081,4,262234,4164,1,4097,113]

theorem envBound9322 : H12AffineFastState.Bounded env9322 := by
  intro p hp
  have h : env9322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9321_9322 : H12AffineEnvironment.transform 6 41 env9321 = env9322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env9321 == env9322) = true)

theorem identity9322 : scanCanonicalize (H12AffineFastState.compose env9322 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 90) := by decide +kernel

theorem selectedBound9322 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9323 : List Nat := [2,4,8,16,32,64,41,84,113,85,2048,4096,8192,64,8200,8234,4096,90,4165,8200,64,32,4096,34,8224,4096,122,4097,4096,2081,4,0,4164,1,4097,113]

theorem envBound9323 : H12AffineFastState.Bounded env9323 := by
  intro p hp
  have h : env9323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9322_9323 : H12AffineEnvironment.transform 17 90 env9322 = env9323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 90 env9322 == env9323) = true)

theorem identity9323 : scanCanonicalize (H12AffineFastState.compose env9323 (packedSelected [1,3,13] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound9323 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env9324 : List Nat := [2,4,8,16,32,64,41,84,113,85,2048,4096,8,64,0,34,4096,90,4165,0,64,32,4096,34,40,4096,122,4097,4096,2081,4,0,4164,1,4097,113]

theorem envBound9324 : H12AffineFastState.Bounded env9324 := by
  intro p hp
  have h : env9324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9323_9324 : H12AffineEnvironment.transform 12 8 env9323 = env9324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env9323 == env9324) = true)

theorem identity9324 : scanCanonicalize (H12AffineFastState.compose env9324 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound9324 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env9325 : List Nat := [2,4,8,16,32,64,41,84,113,85,2048,16,8,64,0,34,16,90,85,0,64,32,16,34,40,16,122,17,16,2081,4,0,84,1,17,113]

theorem envBound9325 : H12AffineFastState.Bounded env9325 := by
  intro p hp
  have h : env9325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9324_9325 : H12AffineEnvironment.transform 11 16 env9324 = env9325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env9324 == env9325) = true)

theorem identity9325 : scanCanonicalize (H12AffineFastState.compose env9325 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 106) := by decide +kernel

theorem selectedBound9325 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env9326 : List Nat := [2,4,8,16,32,64,41,84,113,85,106,16,8,64,0,34,16,90,85,0,64,32,16,34,40,16,122,17,16,75,4,0,84,1,17,113]

theorem envBound9326 : H12AffineFastState.Bounded env9326 := by
  intro p hp
  have h : env9326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9325_9326 : H12AffineEnvironment.transform 10 106 env9325 = env9326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 106 env9325 == env9326) = true)

theorem identity9326 : scanCanonicalize (H12AffineFastState.compose env9326 (packedSelected [2,3] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound9326 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env9327 : List Nat := [2,4,8,16,32,59,41,47,10,46,17,16,8,59,0,34,16,33,46,0,59,32,16,34,40,16,1,17,16,48,4,0,47,1,17,10]

theorem envBound9327 : H12AffineFastState.Bounded env9327 := by
  intro p hp
  have h : env9327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9326_9327 : H12AffineEnvironment.transform 5 59 env9326 = env9327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env9326 == env9327) = true)

theorem identity9327 : scanCanonicalize (H12AffineFastState.compose env9327 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9327 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env9328 : List Nat := [2,4,2,16,32,49,35,37,0,36,17,16,2,49,0,34,16,33,36,0,49,32,16,34,34,16,1,17,16,48,4,0,37,1,17,0]

theorem envBound9328 : H12AffineFastState.Bounded env9328 := by
  intro p hp
  have h : env9328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9327_9328 : H12AffineEnvironment.transform 2 2 env9327 = env9328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9327 == env9328) = true)

theorem identity9328 : scanCanonicalize (H12AffineFastState.compose env9328 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound9328 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9329 : List Nat := [2,4,2,16,0,17,3,5,0,4,17,16,2,17,0,2,16,1,4,0,17,0,16,2,2,16,1,17,16,16,4,0,5,1,17,0]

theorem envBound9329 : H12AffineFastState.Bounded env9329 := by
  intro p hp
  have h : env9329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9328_9329 : H12AffineEnvironment.transform 4 0 env9328 = env9329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9328 == env9329) = true)

theorem identity9329 : scanCanonicalize (H12AffineFastState.compose env9329 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9329 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9330 : List Nat := [2,4,2,0,0,1,3,5,0,4,1,0,2,1,0,2,0,1,4,0,1,0,0,2,2,0,1,1,0,0,4,0,5,1,1,0]

theorem envBound9330 : H12AffineFastState.Bounded env9330 := by
  intro p hp
  have h : env9330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9329_9330 : H12AffineEnvironment.transform 3 0 env9329 = env9330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9329 == env9330) = true)

def leafEnv9330 : List Nat := [2,4,2,0,0,1,3,5,0,4,1,0,2,1,0,2,0,1,4,0,1,0,0,2,4,2,1,0,1,1,0,0,4,0,5,1,4,3,1,0,1,0,0]

def active9330 : List Nat := [0,1]

def tree9330 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9330 : H12WitnessSearch.Good tree9330 := H12GlobalWitnessIndex.good

theorem leafIdentity9330 : H12AffineFastState.composeSystem env9330 rootObs = leafEnv9330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9330 rootObs == leafEnv9330) = true)

theorem terminalChecked9330 : H12PackedTerminal.terminalCheckFast leafEnv9330 active9330 tree9330 = true := by decide +kernel

def env9331 : List Nat := [2,4,8,16,32,64,128,256,217,257,2048,4096,8192,232,8693,8235,4605,262144,4537,8693,64,262267,4437,34,8329,4096,262280,266331,266663,2080,505,262414,4536,0,4097,292]

theorem envBound9331 : H12AffineFastState.Bounded env9331 := by
  intro p hp
  have h : env9331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9319_9331 : H12AffineEnvironment.transform 8 217 env9319 = env9331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env9319 == env9331) = true)

theorem identity9331 : scanCanonicalize (H12AffineFastState.compose env9331 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 422) := by decide +kernel

theorem selectedBound9331 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9332 : List Nat := [2,4,8,16,32,64,128,256,217,257,2048,4096,8192,232,8693,8235,4605,422,4537,8693,64,477,4437,34,8329,4096,302,4605,4097,2080,505,168,4536,0,4097,292]

theorem envBound9332 : H12AffineFastState.Bounded env9332 := by
  intro p hp
  have h : env9332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9331_9332 : H12AffineEnvironment.transform 17 422 env9331 = env9332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 422 env9331 == env9332) = true)

theorem identity9332 : scanCanonicalize (H12AffineFastState.compose env9332 (packedSelected [1,3,4,9,12,14,18,20,23,38] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound9332 : packedSelected [1,3,4,9,12,14,18,20,23,38] rootPS < 2^1333 := by decide +kernel

def env9333 : List Nat := [2,4,8,16,32,64,121,256,32,257,2048,4096,8192,17,8460,8235,4356,351,4416,8460,64,292,4437,34,8304,4096,302,4356,4097,2080,256,81,4417,0,4097,292]

theorem envBound9333 : H12AffineFastState.Bounded env9333 := by
  intro p hp
  have h : env9333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9332_9333 : H12AffineEnvironment.transform 6 121 env9332 = env9333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env9332 == env9333) = true)

theorem identity9333 : scanCanonicalize (H12AffineFastState.compose env9333 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2154) := by decide +kernel

theorem selectedBound9333 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env9334 : List Nat := [2,4,8,16,32,64,121,256,32,257,2048,2154,8192,17,8460,8235,2414,351,2346,8460,64,292,2367,34,8304,2154,302,2414,2155,2080,256,81,2347,0,2155,292]

theorem envBound9334 : H12AffineFastState.Bounded env9334 := by
  intro p hp
  have h : env9334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9333_9334 : H12AffineEnvironment.transform 11 2154 env9333 = env9334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2154 env9333 == env9334) = true)

theorem identity9334 : scanCanonicalize (H12AffineFastState.compose env9334 (packedSelected [2,3,5,7,9,11,12,13,14] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound9334 : packedSelected [2,3,5,7,9,11,12,13,14] rootPS < 2^1333 := by decide +kernel

def env9335 : List Nat := [2,4,8,16,32,64,121,4,32,5,2048,2154,8192,17,8200,8235,2154,91,2094,8200,64,32,2107,34,8304,2154,42,2154,2155,2080,4,81,2095,0,2155,32]

theorem envBound9335 : H12AffineFastState.Bounded env9335 := by
  intro p hp
  have h : env9335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9334_9335 : H12AffineEnvironment.transform 7 4 env9334 = env9335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env9334 == env9335) = true)

theorem identity9335 : scanCanonicalize (H12AffineFastState.compose env9335 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound9335 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9336 : List Nat := [2,4,8,16,32,16,41,4,32,5,2048,2106,8192,17,8200,8235,2106,11,2094,8200,16,32,2107,34,8224,2106,42,2106,2107,2080,4,1,2095,0,2107,32]

theorem envBound9336 : H12AffineFastState.Bounded env9336 := by
  intro p hp
  have h : env9336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9335_9336 : H12AffineEnvironment.transform 5 16 env9335 = env9336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9335 == env9336) = true)

theorem identity9336 : scanCanonicalize (H12AffineFastState.compose env9336 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2073) := by decide +kernel

theorem selectedBound9336 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9337 : List Nat := [2,4,8,16,32,16,41,4,32,5,2048,2106,2073,17,2065,2098,2106,11,2094,2065,16,32,2107,34,2105,2106,42,2106,2107,2080,4,1,2095,0,2107,32]

theorem envBound9337 : H12AffineFastState.Bounded env9337 := by
  intro p hp
  have h : env9337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9336_9337 : H12AffineEnvironment.transform 12 2073 env9336 = env9337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2073 env9336 == env9337) = true)

theorem identity9337 : scanCanonicalize (H12AffineFastState.compose env9337 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound9337 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9338 : List Nat := [2,4,8,16,17,16,24,4,17,5,2048,2059,2073,17,2065,2051,2059,11,2079,2065,16,17,2058,19,2056,2059,27,2059,2058,2065,4,1,2078,0,2058,17]

theorem envBound9338 : H12AffineFastState.Bounded env9338 := by
  intro p hp
  have h : env9338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9337_9338 : H12AffineEnvironment.transform 4 17 env9337 = env9338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env9337 == env9338) = true)

theorem identity9338 : scanCanonicalize (H12AffineFastState.compose env9338 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound9338 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9339 : List Nat := [2,4,8,16,17,16,24,4,17,5,1,10,24,17,16,2,10,11,30,16,16,17,11,19,9,10,27,10,11,16,4,1,31,0,11,17]

theorem envBound9339 : H12AffineFastState.Bounded env9339 := by
  intro p hp
  have h : env9339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9338_9339 : H12AffineEnvironment.transform 10 1 env9338 = env9339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env9338 == env9339) = true)

theorem identity9339 : scanCanonicalize (H12AffineFastState.compose env9339 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound9339 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9340 : List Nat := [2,4,8,11,10,11,3,4,10,5,1,10,3,10,11,2,10,11,5,11,11,10,11,8,9,10,0,10,11,11,4,1,4,0,11,10]

theorem envBound9340 : H12AffineFastState.Bounded env9340 := by
  intro p hp
  have h : env9340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9339_9340 : H12AffineEnvironment.transform 3 11 env9339 = env9340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env9339 == env9340) = true)

theorem identity9340 : scanCanonicalize (H12AffineFastState.compose env9340 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9340 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env9341 : List Nat := [2,4,3,0,1,0,3,4,1,5,1,1,3,1,0,2,1,0,5,0,0,1,0,3,2,1,0,1,0,0,4,1,4,0,0,1]

theorem envBound9341 : H12AffineFastState.Bounded env9341 := by
  intro p hp
  have h : env9341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9340_9341 : H12AffineEnvironment.transform 2 3 env9340 = env9341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9340 == env9341) = true)

def leafEnv9341 : List Nat := [2,4,3,0,1,0,3,4,1,5,1,1,3,1,0,2,1,0,5,0,0,1,0,3,4,2,1,1,0,1,0,0,4,1,4,0,4,2,0,1,1,0,0]

def active9341 : List Nat := [0,1]

def tree9341 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9341 : H12WitnessSearch.Good tree9341 := H12GlobalWitnessIndex.good

theorem leafIdentity9341 : H12AffineFastState.composeSystem env9341 rootObs = leafEnv9341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9341 rootObs == leafEnv9341) = true)

theorem terminalChecked9341 : H12PackedTerminal.terminalCheckFast leafEnv9341 active9341 tree9341 = true := by decide +kernel

def env9342 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,24771,4605,262144,4960,8693,65,4194304,5004,34,8329,21041,278624,4214984,4215092,18632,505,4211101,4961,16616,21041,1021]

theorem envBound9342 : H12AffineFastState.Bounded env9342 := by
  intro p hp
  have h : env9342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9293_9342 : H12AffineEnvironment.transform 20 65 env9293 = env9342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env9293 == env9342) = true)

theorem identity9342 : scanCanonicalize (H12AffineFastState.compose env9342 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 266435) := by decide +kernel

theorem selectedBound9342 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9343 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,24771,4605,262144,4960,8693,65,266435,5004,34,8329,21041,278624,278539,279031,18632,505,282974,4961,16616,21041,1021]

theorem envBound9343 : H12AffineFastState.Bounded env9343 := by
  intro p hp
  have h : env9343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9342_9343 : H12AffineEnvironment.transform 21 266435 env9342 = env9343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 266435 env9342 == env9343) = true)

def env9344 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,560,8693,8947,4605,262144,4960,8693,65,266435,5004,34,8329,4097,262736,262715,263111,2808,505,267118,4961,728,4097,1021]

theorem envBound9344 : H12AffineFastState.Bounded env9344 := by
  intro p hp
  have h : env9344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9343_9344 : H12AffineEnvironment.transform 13 560 env9343 = env9344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env9343 == env9344) = true)

def env9345 : List Nat := [2,4,8,16,32,64,128,256,216,257,2048,4096,8192,232,8693,8235,4605,262144,4536,8693,65,266435,4436,34,8329,4097,262280,262371,262431,2080,505,266678,4537,0,4097,293]

theorem envBound9345 : H12AffineFastState.Bounded env9345 := by
  intro p hp
  have h : env9345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9344_9345 : H12AffineEnvironment.transform 8 216 env9344 = env9345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env9344 == env9345) = true)

theorem identity9345 : scanCanonicalize (H12AffineFastState.compose env9345 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 4383) := by decide +kernel

theorem selectedBound9345 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9346 : List Nat := [2,4,8,16,32,64,128,256,216,257,2048,4096,8192,232,8693,8235,4605,4383,4536,8693,65,476,4436,34,8329,4097,4503,4604,4096,2080,505,169,4537,0,4097,293]

theorem envBound9346 : H12AffineFastState.Bounded env9346 := by
  intro p hp
  have h : env9346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9345_9346 : H12AffineEnvironment.transform 17 4383 env9345 = env9346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4383 env9345 == env9346) = true)

theorem identity9346 : scanCanonicalize (H12AffineFastState.compose env9346 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound9346 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9347 : List Nat := [2,4,8,16,32,64,128,256,216,257,2048,185,8192,232,8693,8235,324,422,257,8693,65,476,493,34,8329,184,302,325,185,2080,505,169,256,0,184,293]

theorem envBound9347 : H12AffineFastState.Bounded env9347 := by
  intro p hp
  have h : env9347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9346_9347 : H12AffineEnvironment.transform 11 185 env9346 = env9347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env9346 == env9347) = true)

theorem identity9347 : scanCanonicalize (H12AffineFastState.compose env9347 (packedSelected [0,1,3,7,12,13,14,15,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound9347 : packedSelected [0,1,3,7,12,13,14,15,17,20] rootPS < 2^1333 := by decide +kernel

def env9348 : List Nat := [2,4,8,16,32,64,120,256,32,257,2048,65,8192,16,8461,8235,324,350,257,8461,65,292,277,34,8305,64,302,325,65,2080,257,81,256,0,64,293]

theorem envBound9348 : H12AffineFastState.Bounded env9348 := by
  intro p hp
  have h : env9348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9347_9348 : H12AffineEnvironment.transform 6 120 env9347 = env9348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env9347 == env9348) = true)

theorem identity9348 : scanCanonicalize (H12AffineFastState.compose env9348 (packedSelected [14] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound9348 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env9349 : List Nat := [2,4,8,16,32,64,120,4,32,5,2048,65,8192,16,8201,8235,64,90,5,8201,65,32,17,34,8305,64,42,65,65,2080,5,81,4,0,64,33]

theorem envBound9349 : H12AffineFastState.Bounded env9349 := by
  intro p hp
  have h : env9349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9348_9349 : H12AffineEnvironment.transform 7 4 env9348 = env9349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env9348 == env9349) = true)

theorem identity9349 : scanCanonicalize (H12AffineFastState.compose env9349 (packedSelected [0,1,3,4,7,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 86) := by decide +kernel

theorem selectedBound9349 : packedSelected [0,1,3,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env9350 : List Nat := [2,4,8,16,32,64,120,4,32,5,2048,65,86,16,95,125,64,90,5,95,65,32,17,34,39,64,42,65,65,2080,5,81,4,0,64,33]

theorem envBound9350 : H12AffineFastState.Bounded env9350 := by
  intro p hp
  have h : env9350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9349_9350 : H12AffineEnvironment.transform 12 86 env9349 = env9350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 86 env9349 == env9350) = true)

theorem identity9350 : scanCanonicalize (H12AffineFastState.compose env9350 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9350 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9351 : List Nat := [2,4,8,0,32,64,104,4,32,5,2048,65,70,0,79,109,64,74,5,79,65,32,1,34,39,64,42,65,65,2080,5,65,4,0,64,33]

theorem envBound9351 : H12AffineFastState.Bounded env9351 := by
  intro p hp
  have h : env9351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9350_9351 : H12AffineEnvironment.transform 3 0 env9350 = env9351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9350 == env9351) = true)

theorem identity9351 : scanCanonicalize (H12AffineFastState.compose env9351 (packedSelected [1,2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound9351 : packedSelected [1,2,5,8] rootPS < 2^1333 := by decide +kernel

def env9352 : List Nat := [2,4,8,0,32,64,104,4,32,5,10,65,70,0,79,109,64,74,5,79,65,32,1,34,39,64,42,65,65,42,5,65,4,0,64,33]

theorem envBound9352 : H12AffineFastState.Bounded env9352 := by
  intro p hp
  have h : env9352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9351_9352 : H12AffineEnvironment.transform 10 10 env9351 = env9352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env9351 == env9352) = true)

def env9353 : List Nat := [2,4,8,16,32,64,128,256,217,257,2048,4096,8192,233,8693,8234,4605,262144,4537,8693,65,266435,4437,34,8329,4097,262281,262370,262430,2081,505,266679,4536,1,4097,292]

theorem envBound9353 : H12AffineFastState.Bounded env9353 := by
  intro p hp
  have h : env9353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9344_9353 : H12AffineEnvironment.transform 8 217 env9344 = env9353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env9344 == env9353) = true)

theorem identity9353 : scanCanonicalize (H12AffineFastState.compose env9353 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound9353 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9354 : List Nat := [2,4,8,16,32,64,128,85,217,84,2048,4096,8192,233,8352,8234,4264,262144,4332,8352,65,266435,4096,34,8329,4097,262281,262370,262219,2081,172,266466,4333,1,4097,113]

theorem envBound9354 : H12AffineFastState.Bounded env9354 := by
  intro p hp
  have h : env9354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9353_9354 : H12AffineEnvironment.transform 7 85 env9353 = env9354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env9353 == env9354) = true)

theorem identity9354 : scanCanonicalize (H12AffineFastState.compose env9354 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound9354 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env9355 : List Nat := [2,4,8,16,32,64,128,85,217,84,2048,16,8192,233,8352,8234,184,262144,252,8352,65,262355,16,34,8329,17,262281,262370,262219,2081,172,262386,253,1,17,113]

theorem envBound9355 : H12AffineFastState.Bounded env9355 := by
  intro p hp
  have h : env9355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9354_9355 : H12AffineEnvironment.transform 11 16 env9354 = env9355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env9354 == env9355) = true)

theorem identity9355 : scanCanonicalize (H12AffineFastState.compose env9355 (packedSelected [13,14,17] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound9355 : packedSelected [13,14,17] rootPS < 2^1333 := by decide +kernel

def env9356 : List Nat := [2,4,8,16,32,64,128,85,217,84,2048,16,8192,233,8352,8234,184,2184,252,8352,65,2139,16,34,8329,17,2049,2154,2243,2081,172,2170,253,1,17,113]

theorem envBound9356 : H12AffineFastState.Bounded env9356 := by
  intro p hp
  have h : env9356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9355_9356 : H12AffineEnvironment.transform 17 2184 env9355 = env9356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env9355 == env9356) = true)

theorem identity9356 : scanCanonicalize (H12AffineFastState.compose env9356 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound9356 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env9357 : List Nat := [2,4,8,16,32,64,128,85,217,84,43,16,8192,233,8352,8234,184,163,252,8352,65,112,16,34,8329,17,42,65,232,10,172,81,253,1,17,113]

theorem envBound9357 : H12AffineFastState.Bounded env9357 := by
  intro p hp
  have h : env9357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9356_9357 : H12AffineEnvironment.transform 10 43 env9356 = env9357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env9356 == env9357) = true)

theorem identity9357 : scanCanonicalize (H12AffineFastState.compose env9357 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound9357 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env9358 : List Nat := [2,4,8,16,32,64,120,85,33,84,43,16,8192,17,8280,8234,64,91,4,8280,65,112,16,34,8305,17,42,65,16,10,84,81,5,1,17,113]

theorem envBound9358 : H12AffineFastState.Bounded env9358 := by
  intro p hp
  have h : env9358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9357_9358 : H12AffineEnvironment.transform 6 120 env9357 = env9358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env9357 == env9358) = true)

theorem identity9358 : scanCanonicalize (H12AffineFastState.compose env9358 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound9358 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env9359 : List Nat := [2,4,8,16,32,42,18,63,33,62,43,16,8192,17,8242,8234,42,49,4,8242,43,26,16,34,8219,17,42,43,16,10,62,59,5,1,17,27]

theorem envBound9359 : H12AffineFastState.Bounded env9359 := by
  intro p hp
  have h : env9359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9358_9359 : H12AffineEnvironment.transform 5 42 env9358 = env9359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env9358 == env9359) = true)

def env9360 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,561,8693,8946,4605,262144,4960,8693,65,266435,5004,34,8329,4096,262737,262714,263110,2809,505,267119,4961,729,4096,1021]

theorem envBound9360 : H12AffineFastState.Bounded env9360 := by
  intro p hp
  have h : env9360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9343_9360 : H12AffineEnvironment.transform 13 561 env9343 = env9360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env9343 == env9360) = true)

def env9361 : List Nat := [2,4,8,16,32,64,128,256,216,257,2048,4096,8192,233,8693,8234,4605,262144,4536,8693,65,266435,4436,34,8329,4096,262281,262370,262430,2081,505,266679,4537,1,4096,293]

theorem envBound9361 : H12AffineFastState.Bounded env9361 := by
  intro p hp
  have h : env9361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9360_9361 : H12AffineEnvironment.transform 8 216 env9360 = env9361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env9360 == env9361) = true)

theorem identity9361 : scanCanonicalize (H12AffineFastState.compose env9361 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound9361 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9362 : List Nat := [2,4,8,16,32,64,128,85,216,84,2048,4096,8192,233,8352,8234,4264,262144,4333,8352,65,266435,4097,34,8329,4096,262281,262370,262219,2081,172,266466,4332,1,4096,112]

theorem envBound9362 : H12AffineFastState.Bounded env9362 := by
  intro p hp
  have h : env9362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9361_9362 : H12AffineEnvironment.transform 7 85 env9361 = env9362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env9361 == env9362) = true)

theorem identity9362 : scanCanonicalize (H12AffineFastState.compose env9362 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(17+1) ^^^ 91) := by decide +kernel

theorem selectedBound9362 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env9363 : List Nat := [2,4,8,16,32,64,128,85,216,84,2048,4096,8192,233,8352,8234,4264,91,4333,8352,65,4248,4097,34,8329,4096,210,185,16,2081,172,4281,4332,1,4096,112]

theorem envBound9363 : H12AffineFastState.Bounded env9363 := by
  intro p hp
  have h : env9363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9362_9363 : H12AffineEnvironment.transform 17 91 env9362 = env9363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 91 env9362 == env9363) = true)

theorem identity9363 : scanCanonicalize (H12AffineFastState.compose env9363 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 2106) := by decide +kernel

theorem selectedBound9363 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env9364 : List Nat := [2,4,8,16,32,64,128,85,216,84,2048,2106,8192,233,8352,8234,2194,91,2263,8352,65,2210,2107,34,8329,2106,210,185,16,2081,172,2179,2262,1,2106,112]

theorem envBound9364 : H12AffineFastState.Bounded env9364 := by
  intro p hp
  have h : env9364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9363_9364 : H12AffineEnvironment.transform 11 2106 env9363 = env9364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2106 env9363 == env9364) = true)

theorem identity9364 : scanCanonicalize (H12AffineFastState.compose env9364 (packedSelected [2,4,9,10,11,13,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 2256) := by decide +kernel

theorem selectedBound9364 : packedSelected [2,4,9,10,11,13,14,18] rootPS < 2^1333 := by decide +kernel

def env9365 : List Nat := [2,4,8,16,32,64,128,85,216,84,2048,2106,2256,233,2160,2298,2194,91,2263,2160,65,2210,2107,34,2137,2106,210,185,16,2081,172,2179,2262,1,2106,112]

theorem envBound9365 : H12AffineFastState.Bounded env9365 := by
  intro p hp
  have h : env9365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9364_9365 : H12AffineEnvironment.transform 12 2256 env9364 = env9365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2256 env9364 == env9365) = true)

theorem identity9365 : scanCanonicalize (H12AffineFastState.compose env9365 (packedSelected [2,3,8,9,11,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 83) := by decide +kernel

theorem selectedBound9365 : packedSelected [2,3,8,9,11,12,13] rootPS < 2^1333 := by decide +kernel

def env9366 : List Nat := [2,4,8,16,32,64,83,85,11,84,2048,2106,2051,58,2160,2089,2113,91,2052,2160,65,2161,2107,34,2137,2106,1,106,16,2081,127,2128,2053,1,2106,112]

theorem envBound9366 : H12AffineFastState.Bounded env9366 := by
  intro p hp
  have h : env9366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9365_9366 : H12AffineEnvironment.transform 6 83 env9365 = env9366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 83 env9365 == env9366) = true)

def env9367 : List Nat := [2,4,8,16,32,64,128,256,217,257,2048,4096,8192,232,8693,8235,4605,262144,4537,8693,65,266435,4437,34,8329,4096,262280,262371,262431,2080,505,266678,4536,0,4096,292]

theorem envBound9367 : H12AffineFastState.Bounded env9367 := by
  intro p hp
  have h : env9367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9360_9367 : H12AffineEnvironment.transform 8 217 env9360 = env9367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env9360 == env9367) = true)

theorem identity9367 : scanCanonicalize (H12AffineFastState.compose env9367 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 4383) := by decide +kernel

theorem selectedBound9367 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9368 : List Nat := [2,4,8,16,32,64,128,256,217,257,2048,4096,8192,232,8693,8235,4605,4383,4537,8693,65,476,4437,34,8329,4096,4503,4604,4096,2080,505,169,4536,0,4096,292]

theorem envBound9368 : H12AffineFastState.Bounded env9368 := by
  intro p hp
  have h : env9368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9367_9368 : H12AffineEnvironment.transform 17 4383 env9367 = env9368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4383 env9367 == env9368) = true)

theorem identity9368 : scanCanonicalize (H12AffineFastState.compose env9368 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound9368 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9369 : List Nat := [2,4,8,16,32,64,128,256,217,257,2048,493,8192,232,8693,8235,16,242,84,8693,65,476,184,34,8329,493,122,17,493,2080,505,169,85,0,493,292]

theorem envBound9369 : H12AffineFastState.Bounded env9369 := by
  intro p hp
  have h : env9369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9368_9369 : H12AffineEnvironment.transform 11 493 env9368 = env9369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env9368 == env9369) = true)

theorem identity9369 : scanCanonicalize (H12AffineFastState.compose env9369 (packedSelected [0,7,14,20] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound9369 : packedSelected [0,7,14,20] rootPS < 2^1333 := by decide +kernel

def env9370 : List Nat := [2,4,8,16,32,64,128,84,217,85,2048,185,8192,232,8353,8235,16,242,84,8353,65,136,184,34,8329,185,122,17,185,2080,173,169,85,0,185,112]

theorem envBound9370 : H12AffineFastState.Bounded env9370 := by
  intro p hp
  have h : env9370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9369_9370 : H12AffineEnvironment.transform 7 84 env9369 = env9370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env9369 == env9370) = true)

theorem identity9370 : scanCanonicalize (H12AffineFastState.compose env9370 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound9370 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env9371 : List Nat := [2,4,8,16,32,64,121,84,32,85,2048,64,8192,17,8280,8235,16,11,84,8280,65,113,65,34,8304,64,122,17,64,2080,84,80,85,0,64,112]

theorem envBound9371 : H12AffineFastState.Bounded env9371 := by
  intro p hp
  have h : env9371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9370_9371 : H12AffineEnvironment.transform 6 121 env9370 = env9371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env9370 == env9371) = true)

theorem identity9371 : scanCanonicalize (H12AffineFastState.compose env9371 (packedSelected [2,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound9371 : packedSelected [2,10,12] rootPS < 2^1333 := by decide +kernel

def env9372 : List Nat := [2,4,8,16,32,10,51,30,32,31,2048,10,8192,17,8210,8235,16,11,30,8210,11,59,11,34,8250,10,48,17,10,2080,30,26,31,0,10,58]

theorem envBound9372 : H12AffineFastState.Bounded env9372 := by
  intro p hp
  have h : env9372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9371_9372 : H12AffineEnvironment.transform 5 10 env9371 = env9372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env9371 == env9372) = true)

theorem identity9372 : scanCanonicalize (H12AffineFastState.compose env9372 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2051) := by decide +kernel

theorem selectedBound9372 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env9373 : List Nat := [2,4,8,16,32,10,51,30,32,31,2048,10,2051,17,2065,2088,16,11,30,2065,11,59,11,34,2105,10,48,17,10,2080,30,26,31,0,10,58]

theorem envBound9373 : H12AffineFastState.Bounded env9373 := by
  intro p hp
  have h : env9373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9372_9373 : H12AffineEnvironment.transform 12 2051 env9372 = env9373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2051 env9372 == env9373) = true)

theorem identity9373 : scanCanonicalize (H12AffineFastState.compose env9373 (packedSelected [0,1,2,5,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound9373 : packedSelected [0,1,2,5,9] rootPS < 2^1333 := by decide +kernel

def env9374 : List Nat := [2,4,8,10,32,10,41,4,32,5,2048,10,2051,11,2059,2088,10,11,4,2059,11,33,11,34,2083,10,42,11,10,2080,4,0,5,0,10,32]

theorem envBound9374 : H12AffineFastState.Bounded env9374 := by
  intro p hp
  have h : env9374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9373_9374 : H12AffineEnvironment.transform 3 10 env9373 = env9374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env9373 == env9374) = true)

theorem identity9374 : scanCanonicalize (H12AffineFastState.compose env9374 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound9374 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9375 : List Nat := [2,4,8,10,0,10,9,4,0,5,2048,10,2051,11,2059,2056,10,11,4,2059,11,1,11,2,2051,10,10,11,10,2048,4,0,5,0,10,0]

theorem envBound9375 : H12AffineFastState.Bounded env9375 := by
  intro p hp
  have h : env9375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9374_9375 : H12AffineEnvironment.transform 4 0 env9374 = env9375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9374 == env9375) = true)

theorem identity9375 : scanCanonicalize (H12AffineFastState.compose env9375 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9375 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9376 : List Nat := [2,4,3,1,0,1,2,4,0,5,2048,1,2051,0,2048,2051,1,0,4,2048,0,1,0,2,2051,1,1,0,1,2048,4,0,5,0,1,0]

theorem envBound9376 : H12AffineFastState.Bounded env9376 := by
  intro p hp
  have h : env9376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9375_9376 : H12AffineEnvironment.transform 2 3 env9375 = env9376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9375 == env9376) = true)

theorem identity9376 : scanCanonicalize (H12AffineFastState.compose env9376 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound9376 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9377 : List Nat := [2,4,3,1,0,1,2,4,0,5,0,1,3,0,0,3,1,0,4,0,0,1,0,2,3,1,1,0,1,0,4,0,5,0,1,0]

theorem envBound9377 : H12AffineFastState.Bounded env9377 := by
  intro p hp
  have h : env9377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9376_9377 : H12AffineEnvironment.transform 10 0 env9376 = env9377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env9376 == env9377) = true)

def env9378 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,262144,4961,8693,2097152,4194304,5005,90337,8329,21041,278625,4214985,4215093,75786,504,4268383,4960,73770,2175666,90942]

theorem envBound9378 : H12AffineFastState.Bounded env9378 := by
  intro p hp
  have h : env9378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9291_9378 : H12AffineEnvironment.transform 18 4961 env9291 = env9378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4961 env9291 == env9378) = true)

theorem identity9378 : scanCanonicalize (H12AffineFastState.compose env9378 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound9378 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9379 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,262144,4764,8200,2097152,4194304,4720,90337,8329,21041,278625,4214985,4214984,75786,5,4268194,4765,73770,2175666,90819]

theorem envBound9379 : H12AffineFastState.Bounded env9379 := by
  intro p hp
  have h : env9379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9378_9379 : H12AffineEnvironment.transform 7 253 env9378 = env9379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env9378 == env9379) = true)

def env9380 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,262144,4764,8200,64,4194304,4720,90337,8329,21041,278625,4214985,4214984,75786,5,4268194,4765,73770,78578,90819]

theorem envBound9380 : H12AffineFastState.Bounded env9380 := by
  intro p hp
  have h : env9380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9379_9380 : H12AffineEnvironment.transform 20 64 env9379 = env9380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env9379 == env9380) = true)

theorem identity9380 : scanCanonicalize (H12AffineFastState.compose env9380 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 723) := by decide +kernel

theorem selectedBound9380 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9381 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,723,4764,8200,64,4194304,4720,90337,8329,21041,17074,4214985,4214984,75786,5,4268194,4765,73770,78578,90819]

theorem envBound9381 : H12AffineFastState.Bounded env9381 := by
  intro p hp
  have h : env9381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9380_9381 : H12AffineEnvironment.transform 17 723 env9380 = env9381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 723 env9380 == env9381) = true)

def env9382 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,723,4764,8200,64,16960,4720,90337,8329,21041,17074,4745,4744,75786,5,90850,4765,73770,78578,90819]

theorem envBound9382 : H12AffineFastState.Bounded env9382 := by
  intro p hp
  have h : env9382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9381_9382 : H12AffineEnvironment.transform 21 16960 env9381 = env9382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16960 env9381 == env9382) = true)

def env9383 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,560,8200,65536,4096,723,4764,8200,64,112,4720,74449,8329,4097,130,4745,4744,75786,5,73938,4765,73770,78578,73971]

theorem envBound9383 : H12AffineFastState.Bounded env9383 := by
  intro p hp
  have h : env9383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9382_9383 : H12AffineEnvironment.transform 13 560 env9382 = env9383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env9382 == env9383) = true)

theorem identity9383 : scanCanonicalize (H12AffineFastState.compose env9383 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8714) := by decide +kernel

theorem selectedBound9383 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9384 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,560,8200,8714,4096,723,4764,8200,64,112,4720,219,8329,4097,130,4745,4744,2560,5,728,4765,544,4344,761]

theorem envBound9384 : H12AffineFastState.Bounded env9384 := by
  intro p hp
  have h : env9384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9383_9384 : H12AffineEnvironment.transform 15 8714 env9383 = env9384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8714 env9383 == env9384) = true)

theorem identity9384 : scanCanonicalize (H12AffineFastState.compose env9384 (packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound9384 : packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env9385 : List Nat := [2,4,8,16,32,64,128,253,137,252,2048,4096,8192,185,8200,8323,4096,90,4117,8200,64,112,4345,219,8329,4097,130,4096,4097,2185,5,81,4116,169,4344,112]

theorem envBound9385 : H12AffineFastState.Bounded env9385 := by
  intro p hp
  have h : env9385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9384_9385 : H12AffineEnvironment.transform 8 137 env9384 = env9385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env9384 == env9385) = true)

theorem identity9385 : scanCanonicalize (H12AffineFastState.compose env9385 (packedSelected [2,11,13,14,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound9385 : packedSelected [2,11,13,14,17,18] rootPS < 2^1333 := by decide +kernel

def env9386 : List Nat := [2,4,8,16,32,64,121,4,112,5,2048,4096,8192,64,8200,8314,4096,90,4117,8200,64,112,4096,34,8304,4097,123,4096,4097,2160,5,81,4116,80,4097,112]

theorem envBound9386 : H12AffineFastState.Bounded env9386 := by
  intro p hp
  have h : env9386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9385_9386 : H12AffineEnvironment.transform 6 121 env9385 = env9386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env9385 == env9386) = true)

theorem identity9386 : scanCanonicalize (H12AffineFastState.compose env9386 (packedSelected [1,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound9386 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env9387 : List Nat := [2,4,8,16,32,64,121,4,112,5,2048,4096,24,64,16,98,4096,90,4117,16,64,112,4096,34,104,4097,123,4096,4097,2160,5,81,4116,80,4097,112]

theorem envBound9387 : H12AffineFastState.Bounded env9387 := by
  intro p hp
  have h : env9387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9386_9387 : H12AffineEnvironment.transform 12 24 env9386 = env9387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env9386 == env9387) = true)

theorem identity9387 : scanCanonicalize (H12AffineFastState.compose env9387 (packedSelected [2,13,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound9387 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env9388 : List Nat := [2,4,8,16,32,17,40,4,33,5,2048,4096,24,17,16,51,4096,11,4117,16,17,33,4096,34,57,4097,42,4096,4097,2081,5,0,4116,1,4097,33]

theorem envBound9388 : H12AffineFastState.Bounded env9388 := by
  intro p hp
  have h : env9388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9387_9388 : H12AffineEnvironment.transform 5 17 env9387 = env9388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9387 == env9388) = true)

theorem identity9388 : scanCanonicalize (H12AffineFastState.compose env9388 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound9388 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9389 : List Nat := [2,4,8,16,32,17,40,4,33,5,2048,2065,24,17,16,51,2065,11,2052,16,17,33,2065,34,57,2064,42,2065,2064,2081,5,0,2053,1,2064,33]

theorem envBound9389 : H12AffineFastState.Bounded env9389 := by
  intro p hp
  have h : env9389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9388_9389 : H12AffineEnvironment.transform 11 2065 env9388 = env9389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env9388 == env9389) = true)

theorem identity9389 : scanCanonicalize (H12AffineFastState.compose env9389 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound9389 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env9390 : List Nat := [2,4,8,16,32,17,40,4,33,5,43,58,24,17,16,51,58,11,47,16,17,33,58,34,57,59,42,58,59,10,5,0,46,1,59,33]

theorem envBound9390 : H12AffineFastState.Bounded env9390 := by
  intro p hp
  have h : env9390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9389_9390 : H12AffineEnvironment.transform 10 43 env9389 = env9390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env9389 == env9390) = true)

theorem identity9390 : scanCanonicalize (H12AffineFastState.compose env9390 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound9390 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env9391 : List Nat := [2,4,8,11,32,10,40,4,33,5,43,33,3,10,11,40,33,11,47,11,10,33,33,34,34,32,42,33,32,10,5,0,46,1,32,33]

theorem envBound9391 : H12AffineFastState.Bounded env9391 := by
  intro p hp
  have h : env9391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9390_9391 : H12AffineEnvironment.transform 3 11 env9390 = env9391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env9390 == env9391) = true)

theorem identity9391 : scanCanonicalize (H12AffineFastState.compose env9391 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound9391 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9392 : List Nat := [2,4,8,11,0,10,8,4,1,5,11,1,3,10,11,8,1,11,15,11,10,1,1,2,2,0,10,1,0,10,5,0,14,1,0,1]

theorem envBound9392 : H12AffineFastState.Bounded env9392 := by
  intro p hp
  have h : env9392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9391_9392 : H12AffineEnvironment.transform 4 0 env9391 = env9392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9391 == env9392) = true)

theorem identity9392 : scanCanonicalize (H12AffineFastState.compose env9392 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9392 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env9393 : List Nat := [2,4,2,1,0,0,2,4,1,5,1,1,3,0,1,2,1,1,5,1,0,1,1,2,2,0,0,1,0,0,5,0,4,1,0,1]

theorem envBound9393 : H12AffineFastState.Bounded env9393 := by
  intro p hp
  have h : env9393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9392_9393 : H12AffineEnvironment.transform 2 2 env9392 = env9393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9392 == env9393) = true)

def env9394 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,561,8200,65536,4096,723,4764,8200,64,113,4720,74448,8329,4096,131,4745,4744,75786,5,73939,4765,73770,78578,73970]

theorem envBound9394 : H12AffineFastState.Bounded env9394 := by
  intro p hp
  have h : env9394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9382_9394 : H12AffineEnvironment.transform 13 561 env9382 = env9394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env9382 == env9394) = true)

theorem identity9394 : scanCanonicalize (H12AffineFastState.compose env9394 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8947) := by decide +kernel

theorem selectedBound9394 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9395 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,561,8200,8947,4096,723,4764,8200,64,113,4720,35,8329,4096,131,4745,4744,2809,5,544,4765,729,4097,513]

theorem envBound9395 : H12AffineFastState.Bounded env9395 := by
  intro p hp
  have h : env9395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9394_9395 : H12AffineEnvironment.transform 15 8947 env9394 = env9395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8947 env9394 == env9395) = true)

theorem identity9395 : scanCanonicalize (H12AffineFastState.compose env9395 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2259) := by decide +kernel

theorem selectedBound9395 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env9396 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,2259,8192,561,8200,8947,2259,723,2639,8200,64,113,2723,35,8329,2259,131,2650,2651,2809,5,544,2638,729,2258,513]

theorem envBound9396 : H12AffineFastState.Bounded env9396 := by
  intro p hp
  have h : env9396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9395_9396 : H12AffineEnvironment.transform 11 2259 env9395 = env9396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2259 env9395 == env9396) = true)

theorem identity9396 : scanCanonicalize (H12AffineFastState.compose env9396 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound9396 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env9397 : List Nat := [2,4,8,16,32,64,128,253,136,252,2048,2259,8192,185,8200,8315,2259,91,2247,8200,64,113,2091,35,8329,2259,131,2258,2259,2161,5,168,2246,81,2258,137]

theorem envBound9397 : H12AffineFastState.Bounded env9397 := by
  intro p hp
  have h : env9397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9396_9397 : H12AffineEnvironment.transform 8 136 env9396 = env9397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env9396 == env9397) = true)

theorem identity9397 : scanCanonicalize (H12AffineFastState.compose env9397 (packedSelected [2,13,14] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound9397 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env9398 : List Nat := [2,4,8,16,32,64,105,20,97,21,2048,2106,8192,80,8200,8315,2106,91,2094,8200,64,113,2091,35,8288,2106,106,2107,2106,2161,5,65,2095,81,2107,96]

theorem envBound9398 : H12AffineFastState.Bounded env9398 := by
  intro p hp
  have h : env9398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9397_9398 : H12AffineEnvironment.transform 6 105 env9397 = env9398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env9397 == env9398) = true)

theorem identity9398 : scanCanonicalize (H12AffineFastState.compose env9398 (packedSelected [4,5,8,9,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 2098) := by decide +kernel

theorem selectedBound9398 : packedSelected [4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env9399 : List Nat := [2,4,8,16,32,64,105,20,97,21,2048,2106,2098,80,2106,2121,2106,91,2094,2106,64,113,2091,35,2130,2106,106,2107,2106,2161,5,65,2095,81,2107,96]

theorem envBound9399 : H12AffineFastState.Bounded env9399 := by
  intro p hp
  have h : env9399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9398_9399 : H12AffineEnvironment.transform 12 2098 env9398 = env9399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2098 env9398 == env9399) = true)

theorem identity9399 : scanCanonicalize (H12AffineFastState.compose env9399 (packedSelected [1,4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 36) := by decide +kernel

theorem selectedBound9399 : packedSelected [1,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env9400 : List Nat := [2,4,8,16,32,36,13,20,5,21,2048,2106,2098,52,2106,2093,2106,63,2094,2106,36,21,2091,35,2102,2106,14,2107,2106,2069,5,37,2095,53,2107,4]

theorem envBound9400 : H12AffineFastState.Bounded env9400 := by
  intro p hp
  have h : env9400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9399_9400 : H12AffineEnvironment.transform 5 36 env9399 = env9400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 36 env9399 == env9400) = true)

theorem identity9400 : scanCanonicalize (H12AffineFastState.compose env9400 (packedSelected [0,2,7,8,10] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound9400 : packedSelected [0,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env9401 : List Nat := [2,4,8,16,5,1,13,20,5,21,2048,2079,2071,17,2079,2056,2079,26,2059,2079,1,21,2062,6,2067,2079,14,2078,2079,2069,5,0,2058,16,2078,4]

theorem envBound9401 : H12AffineFastState.Bounded env9401 := by
  intro p hp
  have h : env9401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9400_9401 : H12AffineEnvironment.transform 4 5 env9400 = env9401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env9400 == env9401) = true)

theorem identity9401 : scanCanonicalize (H12AffineFastState.compose env9401 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound9401 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9402 : List Nat := [2,4,8,16,5,1,13,20,5,21,17,14,6,17,14,25,14,26,26,14,1,21,31,6,2,14,14,15,14,4,5,0,27,16,15,4]

theorem envBound9402 : H12AffineFastState.Bounded env9402 := by
  intro p hp
  have h : env9402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9401_9402 : H12AffineEnvironment.transform 10 17 env9401 = env9402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env9401 == env9402) = true)

theorem identity9402 : scanCanonicalize (H12AffineFastState.compose env9402 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound9402 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9403 : List Nat := [2,0,8,16,1,1,9,16,1,17,17,10,2,17,10,25,10,26,26,10,1,17,27,2,2,10,10,11,10,0,1,0,27,16,11,0]

theorem envBound9403 : H12AffineFastState.Bounded env9403 := by
  intro p hp
  have h : env9403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9402_9403 : H12AffineEnvironment.transform 1 0 env9402 = env9403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env9402 == env9403) = true)

theorem identity9403 : scanCanonicalize (H12AffineFastState.compose env9403 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9403 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9404 : List Nat := [2,0,2,16,1,1,3,16,1,17,17,0,2,17,0,19,0,16,16,0,1,17,17,2,2,0,0,1,0,0,1,0,17,16,1,0]

theorem envBound9404 : H12AffineFastState.Bounded env9404 := by
  intro p hp
  have h : env9404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9403_9404 : H12AffineEnvironment.transform 2 2 env9403 = env9404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9403 == env9404) = true)

def env9405 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,723,4764,8200,64,16961,4720,90337,8329,21041,17074,4744,4745,75786,5,90851,4765,73770,78578,90819]

theorem envBound9405 : H12AffineFastState.Bounded env9405 := by
  intro p hp
  have h : env9405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9381_9405 : H12AffineEnvironment.transform 21 16961 env9381 = env9405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16961 env9381 == env9405) = true)

def env9406 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,560,8200,65536,4096,723,4764,8200,64,113,4720,74449,8329,4097,130,4744,4745,75786,5,73939,4765,73770,78578,73971]

theorem envBound9406 : H12AffineFastState.Bounded env9406 := by
  intro p hp
  have h : env9406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9405_9406 : H12AffineEnvironment.transform 13 560 env9405 = env9406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env9405 == env9406) = true)

theorem identity9406 : scanCanonicalize (H12AffineFastState.compose env9406 (packedSelected [7,20,27] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound9406 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9407 : List Nat := [2,4,8,16,32,64,120,5,512,4,2048,4096,8192,560,8200,65536,4096,555,4708,8200,64,113,4720,74281,8305,4097,122,4720,4721,75786,5,73771,4709,73770,78346,73739]

theorem envBound9407 : H12AffineFastState.Bounded env9407 := by
  intro p hp
  have h : env9407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9406_9407 : H12AffineEnvironment.transform 6 120 env9406 = env9407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env9406 == env9407) = true)

theorem identity9407 : scanCanonicalize (H12AffineFastState.compose env9407 (packedSelected [2,3,5,10,11,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 14945) := by decide +kernel

theorem selectedBound9407 : packedSelected [2,3,5,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env9408 : List Nat := [2,4,8,16,32,64,120,5,512,4,2048,4096,8192,560,8200,14945,4096,555,4708,8200,64,113,4720,6216,8305,4097,122,4720,4721,4715,5,6730,4709,6731,2155,6762]

theorem envBound9408 : H12AffineFastState.Bounded env9408 := by
  intro p hp
  have h : env9408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9407_9408 : H12AffineEnvironment.transform 15 14945 env9407 = env9408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14945 env9407 == env9408) = true)

theorem identity9408 : scanCanonicalize (H12AffineFastState.compose env9408 (packedSelected [0,1,3,4,7,9,12,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 2634) := by decide +kernel

theorem selectedBound9408 : packedSelected [0,1,3,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env9409 : List Nat := [2,4,8,16,32,64,120,5,512,4,2048,2634,8192,560,8200,8235,2634,555,2094,8200,64,113,2106,514,8305,2635,122,2106,2107,2081,5,0,2095,1,2155,32]

theorem envBound9409 : H12AffineFastState.Bounded env9409 := by
  intro p hp
  have h : env9409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9408_9409 : H12AffineEnvironment.transform 11 2634 env9408 = env9409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2634 env9408 == env9409) = true)

theorem identity9409 : scanCanonicalize (H12AffineFastState.compose env9409 (packedSelected [14] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound9409 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env9410 : List Nat := [2,4,8,16,32,64,120,5,32,4,2048,2154,8192,16,8200,8235,2154,11,2094,8200,64,113,2106,34,8305,2155,122,2106,2107,2081,5,0,2095,1,2155,32]

theorem envBound9410 : H12AffineFastState.Bounded env9410 := by
  intro p hp
  have h : env9410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9409_9410 : H12AffineEnvironment.transform 8 32 env9409 = env9410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env9409 == env9410) = true)

theorem identity9410 : scanCanonicalize (H12AffineFastState.compose env9410 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound9410 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9411 : List Nat := [2,4,8,16,32,16,40,5,32,4,2048,2106,8192,16,8200,8235,2106,11,2094,8200,16,33,2106,34,8225,2107,42,2106,2107,2081,5,0,2095,1,2107,32]

theorem envBound9411 : H12AffineFastState.Bounded env9411 := by
  intro p hp
  have h : env9411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9410_9411 : H12AffineEnvironment.transform 5 16 env9410 = env9411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9410 == env9411) = true)

theorem identity9411 : scanCanonicalize (H12AffineFastState.compose env9411 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound9411 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9412 : List Nat := [2,4,8,16,27,16,19,5,27,4,2048,2049,8192,16,8200,8208,2049,11,2069,8200,16,26,2049,25,8218,2048,17,2049,2048,2074,5,0,2068,1,2048,27]

theorem envBound9412 : H12AffineFastState.Bounded env9412 := by
  intro p hp
  have h : env9412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9411_9412 : H12AffineEnvironment.transform 4 27 env9411 = env9412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env9411 == env9412) = true)

theorem identity9412 : scanCanonicalize (H12AffineFastState.compose env9412 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound9412 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9413 : List Nat := [2,4,8,11,0,11,8,5,0,4,2048,2049,8192,11,8200,8203,2049,11,2062,8200,11,1,2049,2,8193,2048,10,2049,2048,2049,5,0,2063,1,2048,0]

theorem envBound9413 : H12AffineFastState.Bounded env9413 := by
  intro p hp
  have h : env9413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9412_9413 : H12AffineEnvironment.transform 3 11 env9412 = env9413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env9412 == env9413) = true)

theorem identity9413 : scanCanonicalize (H12AffineFastState.compose env9413 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound9413 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9414 : List Nat := [2,4,8,11,0,11,8,5,0,4,2048,2049,9,11,1,2,2049,11,2062,1,11,1,2049,2,8,2048,10,2049,2048,2049,5,0,2063,1,2048,0]

theorem envBound9414 : H12AffineFastState.Bounded env9414 := by
  intro p hp
  have h : env9414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9413_9414 : H12AffineEnvironment.transform 12 9 env9413 = env9414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env9413 == env9414) = true)

theorem identity9414 : scanCanonicalize (H12AffineFastState.compose env9414 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound9414 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env9415 : List Nat := [2,4,8,11,0,11,8,5,0,4,1,0,9,11,1,2,0,11,15,1,11,1,0,2,8,1,10,0,1,0,5,0,14,1,1,0]

theorem envBound9415 : H12AffineFastState.Bounded env9415 := by
  intro p hp
  have h : env9415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9414_9415 : H12AffineEnvironment.transform 10 1 env9414 = env9415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env9414 == env9415) = true)

def env9416 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,561,8200,65536,4096,723,4764,8200,64,112,4720,74448,8329,4096,131,4744,4745,75786,5,73938,4765,73770,78578,73970]

theorem envBound9416 : H12AffineFastState.Bounded env9416 := by
  intro p hp
  have h : env9416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9405_9416 : H12AffineEnvironment.transform 13 561 env9405 = env9416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env9405 == env9416) = true)

def env9417 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,262144,4764,8200,65,4194304,4720,90337,8329,21041,278625,4214985,4214984,75786,5,4268194,4765,73770,78579,90819]

theorem envBound9417 : H12AffineFastState.Bounded env9417 := by
  intro p hp
  have h : env9417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9379_9417 : H12AffineEnvironment.transform 20 65 env9379 = env9417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env9379 == env9417) = true)

theorem identity9417 : scanCanonicalize (H12AffineFastState.compose env9417 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 4275) := by decide +kernel

theorem selectedBound9417 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9418 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,4275,4764,8200,65,4194304,4720,90337,8329,21041,20690,4214985,4214984,75786,5,4268194,4765,73770,78579,90819]

theorem envBound9418 : H12AffineFastState.Bounded env9418 := by
  intro p hp
  have h : env9418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9417_9418 : H12AffineEnvironment.transform 17 4275 env9417 = env9418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4275 env9417 == env9418) = true)

def env9419 : List Nat := [2,4,8,16,32,64,56,69,512,68,2048,4096,8192,16384,8200,65536,4096,4107,4644,8200,65,4194304,4720,90201,8241,21041,20586,4214897,4214896,75786,5,4268058,4645,73770,78411,90747]

theorem envBound9419 : H12AffineFastState.Bounded env9419 := by
  intro p hp
  have h : env9419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9418_9419 : H12AffineEnvironment.transform 6 56 env9418 = env9419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env9418 == env9419) = true)

theorem identity9419 : scanCanonicalize (H12AffineFastState.compose env9419 (packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 4128) := by decide +kernel

theorem selectedBound9419 : packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS < 2^1333 := by decide +kernel

def env9420 : List Nat := [2,4,8,16,32,64,56,69,512,68,2048,4096,8192,16384,8200,65536,4096,4107,4644,8200,65,4128,4720,90201,8241,21041,20586,16465,16464,75786,5,77882,4645,73770,78411,90747]

theorem envBound9420 : H12AffineFastState.Bounded env9420 := by
  intro p hp
  have h : env9420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9419_9420 : H12AffineEnvironment.transform 21 4128 env9419 = env9420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 4128 env9419 == env9420) = true)

def env9421 : List Nat := [2,4,8,16,32,64,56,69,512,68,2048,4096,8192,4704,8200,65536,4096,4107,4644,8200,65,4128,4720,78393,8241,81,522,4657,4656,75786,5,77882,4645,73770,78411,77851]

theorem envBound9421 : H12AffineFastState.Bounded env9421 := by
  intro p hp
  have h : env9421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9420_9421 : H12AffineEnvironment.transform 13 4704 env9420 = env9421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4704 env9420 == env9421) = true)

theorem identity9421 : scanCanonicalize (H12AffineFastState.compose env9421 (packedSelected [1,3,11,12,14,15,18,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 8715) := by decide +kernel

theorem selectedBound9421 : packedSelected [1,3,11,12,14,15,18,23,32] rootPS < 2^1333 := by decide +kernel

def env9422 : List Nat := [2,4,8,16,32,64,56,69,512,68,2048,4096,8192,4704,8200,8715,4096,4107,4644,8200,65,4128,4720,4146,8241,81,522,4657,4656,2561,5,4657,4645,545,4160,4624]

theorem envBound9422 : H12AffineFastState.Bounded env9422 := by
  intro p hp
  have h : env9422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9421_9422 : H12AffineEnvironment.transform 15 8715 env9421 = env9422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8715 env9421 == env9422) = true)

theorem identity9422 : scanCanonicalize (H12AffineFastState.compose env9422 (packedSelected [2,5,8,10,11,12,15,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 112) := by decide +kernel

theorem selectedBound9422 : packedSelected [2,5,8,10,11,12,15,18,19] rootPS < 2^1333 := by decide +kernel

def env9423 : List Nat := [2,4,8,16,32,64,56,69,112,68,2048,4096,8192,4112,8200,8315,4096,4107,4180,8200,65,4128,4096,4146,8241,81,122,4161,4160,2161,5,4161,4181,81,4160,4192]

theorem envBound9423 : H12AffineFastState.Bounded env9423 := by
  intro p hp
  have h : env9423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9422_9423 : H12AffineEnvironment.transform 8 112 env9422 = env9423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 112 env9422 == env9423) = true)

theorem identity9423 : scanCanonicalize (H12AffineFastState.compose env9423 (packedSelected [1,5,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2170) := by decide +kernel

theorem selectedBound9423 : packedSelected [1,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env9424 : List Nat := [2,4,8,16,32,64,56,69,112,68,2048,2170,8192,2154,8200,8315,2170,2161,2094,8200,65,2138,2170,2120,8241,81,122,2107,2106,2161,5,2107,2095,81,2106,2074]

theorem envBound9424 : H12AffineFastState.Bounded env9424 := by
  intro p hp
  have h : env9424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9423_9424 : H12AffineEnvironment.transform 11 2170 env9423 = env9424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2170 env9423 == env9424) = true)

theorem identity9424 : scanCanonicalize (H12AffineFastState.compose env9424 (packedSelected [0,1,8,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 2083) := by decide +kernel

theorem selectedBound9424 : packedSelected [0,1,8,9,11] rootPS < 2^1333 := by decide +kernel

def env9425 : List Nat := [2,4,8,16,32,64,56,69,112,68,2048,2170,2083,2154,2091,2136,2170,2161,2094,2091,65,2138,2170,2120,2066,81,122,2107,2106,2161,5,2107,2095,81,2106,2074]

theorem envBound9425 : H12AffineFastState.Bounded env9425 := by
  intro p hp
  have h : env9425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9424_9425 : H12AffineEnvironment.transform 12 2083 env9424 = env9425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2083 env9424 == env9425) = true)

theorem identity9425 : scanCanonicalize (H12AffineFastState.compose env9425 (packedSelected [2,4,5,8,9,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound9425 : packedSelected [2,4,5,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env9426 : List Nat := [2,4,8,16,32,0,56,5,48,4,2048,2106,2083,2090,2091,2072,2106,2097,2094,2091,1,2074,2106,2056,2066,17,58,2107,2106,2097,5,2107,2095,17,2106,2074]

theorem envBound9426 : H12AffineFastState.Bounded env9426 := by
  intro p hp
  have h : env9426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9425_9426 : H12AffineEnvironment.transform 5 0 env9425 = env9426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env9425 == env9426) = true)

theorem identity9426 : scanCanonicalize (H12AffineFastState.compose env9426 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9426 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env9427 : List Nat := [2,4,2,16,32,0,50,5,48,4,2048,2096,2083,2080,2081,2066,2096,2097,2084,2081,1,2064,2096,2050,2066,17,48,2097,2096,2097,5,2097,2085,17,2096,2064]

theorem envBound9427 : H12AffineFastState.Bounded env9427 := by
  intro p hp
  have h : env9427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9426_9427 : H12AffineEnvironment.transform 2 2 env9426 = env9427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9426 == env9427) = true)

theorem identity9427 : scanCanonicalize (H12AffineFastState.compose env9427 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound9427 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9428 : List Nat := [2,4,2,16,17,0,3,5,1,4,2048,2049,2066,2065,2064,2066,2049,2048,2069,2064,1,2064,2049,2050,2066,17,1,2048,2049,2048,5,2048,2068,17,2049,2064]

theorem envBound9428 : H12AffineFastState.Bounded env9428 := by
  intro p hp
  have h : env9428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9427_9428 : H12AffineEnvironment.transform 4 17 env9427 = env9428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env9427 == env9428) = true)

theorem identity9428 : scanCanonicalize (H12AffineFastState.compose env9428 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9428 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9429 : List Nat := [2,4,2,0,1,0,3,5,1,4,2048,2049,2050,2049,2048,2050,2049,2048,2053,2048,1,2048,2049,2050,2050,1,1,2048,2049,2048,5,2048,2052,1,2049,2048]

theorem envBound9429 : H12AffineFastState.Bounded env9429 := by
  intro p hp
  have h : env9429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9428_9429 : H12AffineEnvironment.transform 3 0 env9428 = env9429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9428 == env9429) = true)

def env9430 : List Nat := [2,4,8,16,32,64,56,69,512,68,2048,4096,8192,4705,8200,65536,4096,4107,4644,8200,65,4128,4720,78392,8241,80,523,4656,4657,75786,5,77882,4645,73770,78411,77850]

theorem envBound9430 : H12AffineFastState.Bounded env9430 := by
  intro p hp
  have h : env9430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9420_9430 : H12AffineEnvironment.transform 13 4705 env9420 = env9430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4705 env9420 == env9430) = true)

theorem identity9430 : scanCanonicalize (H12AffineFastState.compose env9430 (packedSelected [1,3,11,12,14,15,18,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 8314) := by decide +kernel

theorem selectedBound9430 : packedSelected [1,3,11,12,14,15,18,23,32] rootPS < 2^1333 := by decide +kernel

def env9431 : List Nat := [2,4,8,16,32,64,56,69,512,68,2048,4096,8192,4705,8200,8314,4096,4107,4644,8200,65,4128,4720,4674,8241,80,523,4656,4657,2160,5,4160,4645,80,4657,4192]

theorem envBound9431 : H12AffineFastState.Bounded env9431 := by
  intro p hp
  have h : env9431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9430_9431 : H12AffineEnvironment.transform 15 8314 env9430 = env9431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8314 env9430 == env9431) = true)

theorem identity9431 : scanCanonicalize (H12AffineFastState.compose env9431 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound9431 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env9432 : List Nat := [2,4,8,16,32,64,56,69,512,68,58,4096,8192,4705,8200,8314,4096,4107,4644,8200,65,4128,4720,4674,8241,80,523,4656,4657,74,5,4160,4645,80,4657,4192]

theorem envBound9432 : H12AffineFastState.Bounded env9432 := by
  intro p hp
  have h : env9432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9431_9432 : H12AffineEnvironment.transform 10 58 env9431 = env9432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env9431 == env9432) = true)

theorem identity9432 : scanCanonicalize (H12AffineFastState.compose env9432 (packedSelected [1,3,4,5,8,9,10,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound9432 : packedSelected [1,3,4,5,8,9,10,19,20] rootPS < 2^1333 := by decide +kernel

def env9433 : List Nat := [2,4,8,16,32,64,56,69,512,68,58,16,8192,625,8200,8314,16,27,564,8200,65,48,608,594,8241,80,523,544,545,74,5,80,565,80,545,112]

theorem envBound9433 : H12AffineFastState.Bounded env9433 := by
  intro p hp
  have h : env9433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9432_9433 : H12AffineEnvironment.transform 11 16 env9432 = env9433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env9432 == env9433) = true)

theorem identity9433 : scanCanonicalize (H12AffineFastState.compose env9433 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9433 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9434 : List Nat := [2,4,8,0,32,64,40,69,512,68,42,0,8192,609,8200,8298,0,11,548,8200,65,32,608,578,8225,64,523,544,545,74,5,64,549,64,545,96]

theorem envBound9434 : H12AffineFastState.Bounded env9434 := by
  intro p hp
  have h : env9434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9433_9434 : H12AffineEnvironment.transform 3 0 env9433 = env9434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9433 == env9434) = true)

theorem identity9434 : scanCanonicalize (H12AffineFastState.compose env9434 (packedSelected [0,1,2,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound9434 : packedSelected [0,1,2,8,9] rootPS < 2^1333 := by decide +kernel

def env9435 : List Nat := [2,4,8,0,32,64,40,69,512,68,42,0,9,609,1,99,0,11,548,1,65,32,608,578,40,64,523,544,545,74,5,64,549,64,545,96]

theorem envBound9435 : H12AffineFastState.Bounded env9435 := by
  intro p hp
  have h : env9435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9434_9435 : H12AffineEnvironment.transform 12 9 env9434 = env9435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env9434 == env9435) = true)

theorem identity9435 : scanCanonicalize (H12AffineFastState.compose env9435 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound9435 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env9436 : List Nat := [2,4,8,0,11,64,3,69,512,68,1,0,9,586,1,72,0,11,527,1,65,11,587,578,3,64,523,523,522,74,5,64,526,64,522,75]

theorem envBound9436 : H12AffineFastState.Bounded env9436 := by
  intro p hp
  have h : env9436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9435_9436 : H12AffineEnvironment.transform 4 11 env9435 = env9436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env9435 == env9436) = true)

theorem identity9436 : scanCanonicalize (H12AffineFastState.compose env9436 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound9436 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env9437 : List Nat := [2,4,8,0,11,11,3,14,512,15,1,0,9,513,1,3,0,11,527,1,10,11,512,521,3,11,523,523,522,1,5,11,526,11,522,0]

theorem envBound9437 : H12AffineFastState.Bounded env9437 := by
  intro p hp
  have h : env9437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9436_9437 : H12AffineEnvironment.transform 5 11 env9436 = env9437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env9436 == env9437) = true)

def env9438 : List Nat := [2,4,8,16,32,64,57,68,512,69,2048,4096,8192,16384,8200,65536,4096,4106,4645,8200,65,4194304,4720,90200,8240,21041,20587,4214896,4214897,75786,5,4268059,4644,73770,78410,90746]

theorem envBound9438 : H12AffineFastState.Bounded env9438 := by
  intro p hp
  have h : env9438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9418_9438 : H12AffineEnvironment.transform 6 57 env9418 = env9438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env9418 == env9438) = true)

theorem identity9438 : scanCanonicalize (H12AffineFastState.compose env9438 (packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS)) = affineNative (2^(15+1) ^^^ 28779) := by decide +kernel

theorem selectedBound9438 : packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS < 2^1333 := by decide +kernel

def env9439 : List Nat := [2,4,8,16,32,64,57,68,512,69,2048,4096,8192,16384,8200,28779,4096,4106,4645,8200,65,4194304,4720,4147,8240,21041,20587,4214896,4214897,22625,5,4214896,4644,20545,16929,4625]

theorem envBound9439 : H12AffineFastState.Bounded env9439 := by
  intro p hp
  have h : env9439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9438_9439 : H12AffineEnvironment.transform 15 28779 env9438 = env9439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28779 env9438 == env9439) = true)

def env9440 : List Nat := [2,4,8,16,32,0,57,4,512,5,2048,4096,8192,16384,8200,28715,4096,4106,4645,8200,1,4194304,4656,4147,8240,21041,20523,4214832,4214833,22561,5,4214832,4644,20481,16929,4625]

theorem envBound9440 : H12AffineFastState.Bounded env9440 := by
  intro p hp
  have h : env9440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9439_9440 : H12AffineEnvironment.transform 5 0 env9439 = env9440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env9439 == env9440) = true)

theorem identity9440 : scanCanonicalize (H12AffineFastState.compose env9440 (packedSelected [1,4,5,9,10,11,20,24,28,32] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound9440 : packedSelected [1,4,5,9,10,11,20,24,28,32] rootPS < 2^1333 := by decide +kernel

def env9441 : List Nat := [2,4,8,16,32,0,57,4,512,5,58,4096,8192,16384,8200,28715,4096,4106,4645,8200,1,4194304,4656,4147,8240,21041,20523,4214832,4214833,20507,5,4214832,4644,20481,16929,4625]

theorem envBound9441 : H12AffineFastState.Bounded env9441 := by
  intro p hp
  have h : env9441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9440_9441 : H12AffineEnvironment.transform 10 58 env9440 = env9441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env9440 == env9441) = true)

theorem identity9441 : scanCanonicalize (H12AffineFastState.compose env9441 (packedSelected [0,2,3,5,7,8,11,12,13,14,15,20,21,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound9441 : packedSelected [0,2,3,5,7,8,11,12,13,14,15,20,21,23,24] rootPS < 2^1333 := by decide +kernel

def env9442 : List Nat := [2,4,8,16,32,0,57,4,512,5,58,4096,8192,4113,8200,8250,4096,4106,4645,8200,1,4194304,4656,4147,8240,544,58,4194337,4194336,10,5,4194337,4644,16,4656,4625]

theorem envBound9442 : H12AffineFastState.Bounded env9442 := by
  intro p hp
  have h : env9442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9441_9442 : H12AffineEnvironment.transform 13 4113 env9441 = env9442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env9441 == env9442) = true)

theorem identity9442 : scanCanonicalize (H12AffineFastState.compose env9442 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound9442 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env9443 : List Nat := [2,4,8,16,32,0,57,4,33,5,58,4096,8192,4113,8200,8250,4096,4106,4100,8200,1,4194304,4113,4147,8240,1,58,4194337,4194336,10,5,4194337,4101,16,4113,4144]

theorem envBound9443 : H12AffineFastState.Bounded env9443 := by
  intro p hp
  have h : env9443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9442_9443 : H12AffineEnvironment.transform 8 33 env9442 = env9443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env9442 == env9443) = true)

theorem identity9443 : scanCanonicalize (H12AffineFastState.compose env9443 (packedSelected [1,5,10,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 4144) := by decide +kernel

theorem selectedBound9443 : packedSelected [1,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env9444 : List Nat := [2,4,8,16,32,0,57,4,33,5,58,4096,8192,4113,8200,8250,4096,4106,4100,8200,1,4144,4113,4147,8240,1,58,4113,4112,10,5,4113,4101,16,4113,4144]

theorem envBound9444 : H12AffineFastState.Bounded env9444 := by
  intro p hp
  have h : env9444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9443_9444 : H12AffineEnvironment.transform 21 4144 env9443 = env9444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 4144 env9443 == env9444) = true)

theorem identity9444 : scanCanonicalize (H12AffineFastState.compose env9444 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound9444 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env9445 : List Nat := [2,4,8,16,32,0,57,4,33,5,58,17,8192,0,8200,8250,17,27,21,8200,1,33,0,34,8240,1,58,0,1,10,5,0,20,16,0,33]

theorem envBound9445 : H12AffineFastState.Bounded env9445 := by
  intro p hp
  have h : env9445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9444_9445 : H12AffineEnvironment.transform 11 17 env9444 = env9445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env9444 == env9445) = true)

theorem identity9445 : scanCanonicalize (H12AffineFastState.compose env9445 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9445 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env9446 : List Nat := [2,4,3,16,32,0,50,4,33,5,49,17,8192,0,8195,8241,17,16,21,8195,1,33,0,34,8240,1,49,0,1,1,5,0,20,16,0,33]

theorem envBound9446 : H12AffineFastState.Bounded env9446 := by
  intro p hp
  have h : env9446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9445_9446 : H12AffineEnvironment.transform 2 3 env9445 = env9446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9445 == env9446) = true)

theorem identity9446 : scanCanonicalize (H12AffineFastState.compose env9446 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 51) := by decide +kernel

theorem selectedBound9446 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9447 : List Nat := [2,4,3,16,32,0,50,4,33,5,49,17,51,0,48,2,17,16,21,48,1,33,0,34,3,1,49,0,1,1,5,0,20,16,0,33]

theorem envBound9447 : H12AffineFastState.Bounded env9447 := by
  intro p hp
  have h : env9447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9446_9447 : H12AffineEnvironment.transform 12 51 env9446 = env9447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 51 env9446 == env9447) = true)

theorem identity9447 : scanCanonicalize (H12AffineFastState.compose env9447 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound9447 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env9448 : List Nat := [2,4,3,16,0,0,18,4,1,5,17,17,19,0,16,2,17,16,21,16,1,1,0,2,3,1,17,0,1,1,5,0,20,16,0,1]

theorem envBound9448 : H12AffineFastState.Bounded env9448 := by
  intro p hp
  have h : env9448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9447_9448 : H12AffineEnvironment.transform 4 0 env9447 = env9448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9447 == env9448) = true)

theorem identity9448 : scanCanonicalize (H12AffineFastState.compose env9448 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound9448 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9449 : List Nat := [2,4,3,1,0,0,3,4,1,5,0,0,2,0,1,2,0,1,4,1,1,1,0,2,3,1,0,0,1,1,5,0,5,1,0,1]

theorem envBound9449 : H12AffineFastState.Bounded env9449 := by
  intro p hp
  have h : env9449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9448_9449 : H12AffineEnvironment.transform 3 1 env9448 = env9449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env9448 == env9449) = true)

def env9450 : List Nat := [2,4,8,16,32,1,57,5,512,4,2048,4096,8192,16384,8200,28714,4096,4106,4645,8200,0,4194304,4657,4147,8240,21041,20522,4214833,4214832,22560,5,4214833,4644,20480,16929,4625]

theorem envBound9450 : H12AffineFastState.Bounded env9450 := by
  intro p hp
  have h : env9450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9439_9450 : H12AffineEnvironment.transform 5 1 env9439 = env9450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env9439 == env9450) = true)

theorem identity9450 : scanCanonicalize (H12AffineFastState.compose env9450 (packedSelected [1,4,5,9,10,11,20,24,28,32] rootPS)) = affineNative (2^(21+1) ^^^ 16912) := by decide +kernel

theorem selectedBound9450 : packedSelected [1,4,5,9,10,11,20,24,28,32] rootPS < 2^1333 := by decide +kernel

def env9451 : List Nat := [2,4,8,16,32,1,57,5,512,4,2048,4096,8192,16384,8200,28714,4096,4106,4645,8200,0,16912,4657,4147,8240,21041,20522,4641,4640,22560,5,4641,4644,20480,16929,4625]

theorem envBound9451 : H12AffineFastState.Bounded env9451 := by
  intro p hp
  have h : env9451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9450_9451 : H12AffineEnvironment.transform 21 16912 env9450 = env9451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16912 env9450 == env9451) = true)

theorem identity9451 : scanCanonicalize (H12AffineFastState.compose env9451 (packedSelected [0,1,7,8,13,14,17,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 2090) := by decide +kernel

theorem selectedBound9451 : packedSelected [0,1,7,8,13,14,17,19,20] rootPS < 2^1333 := by decide +kernel

def env9452 : List Nat := [2,4,8,16,32,1,57,5,512,4,2048,2090,8192,16384,8200,26624,2090,2080,2575,8200,0,16912,2587,2073,8240,18971,18432,2571,2570,16394,5,2571,2574,18474,16929,2619]

theorem envBound9452 : H12AffineFastState.Bounded env9452 := by
  intro p hp
  have h : env9452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9451_9452 : H12AffineEnvironment.transform 11 2090 env9451 = env9452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2090 env9451 == env9452) = true)

theorem identity9452 : scanCanonicalize (H12AffineFastState.compose env9452 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound9452 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env9453 : List Nat := [2,4,8,16,32,1,57,5,512,4,58,16,8192,16384,8200,24634,16,26,565,8200,0,16912,545,35,8240,16929,16442,561,560,16394,5,561,564,16400,16929,513]

theorem envBound9453 : H12AffineFastState.Bounded env9453 := by
  intro p hp
  have h : env9453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9452_9453 : H12AffineEnvironment.transform 10 58 env9452 = env9453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env9452 == env9453) = true)

theorem identity9453 : scanCanonicalize (H12AffineFastState.compose env9453 (packedSelected [3,5,8,10,11,12,14] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound9453 : packedSelected [3,5,8,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env9454 : List Nat := [2,4,8,16,32,1,57,5,30,4,58,16,8192,16384,8200,24634,16,26,43,8200,0,16398,63,35,8240,16447,16442,47,46,16394,5,47,42,16400,16447,31]

theorem envBound9454 : H12AffineFastState.Bounded env9454 := by
  intro p hp
  have h : env9454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9453_9454 : H12AffineEnvironment.transform 8 30 env9453 = env9454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env9453 == env9454) = true)

theorem identity9454 : scanCanonicalize (H12AffineFastState.compose env9454 (packedSelected [8,11,12,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 0) := by decide +kernel

theorem selectedBound9454 : packedSelected [8,11,12,13,17] rootPS < 2^1333 := by decide +kernel

def env9455 : List Nat := [2,4,8,16,32,1,57,5,30,4,58,16,8192,0,8200,8250,16,26,43,8200,0,14,63,35,8240,63,58,47,46,10,5,47,42,16,63,31]

theorem envBound9455 : H12AffineFastState.Bounded env9455 := by
  intro p hp
  have h : env9455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9454_9455 : H12AffineEnvironment.transform 13 0 env9454 = env9455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env9454 == env9455) = true)

theorem identity9455 : scanCanonicalize (H12AffineFastState.compose env9455 (packedSelected [0,1,2,7,10] rootPS)) = affineNative (2^(4+1) ^^^ 31) := by decide +kernel

theorem selectedBound9455 : packedSelected [0,1,2,7,10] rootPS < 2^1333 := by decide +kernel

def env9456 : List Nat := [2,4,8,16,31,1,6,5,30,4,5,16,8192,0,8200,8197,16,26,20,8200,0,14,0,28,8207,0,5,16,17,10,5,16,21,16,0,31]

theorem envBound9456 : H12AffineFastState.Bounded env9456 := by
  intro p hp
  have h : env9456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9455_9456 : H12AffineEnvironment.transform 4 31 env9455 = env9456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 31 env9455 == env9456) = true)

def env9457 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,4194304,524524,16777216,8329,16855760,807681,4735913,4735573,17324939,529049,21517022,524289,17322923,19415347,16778207]

theorem envBound9457 : H12AffineFastState.Bounded env9457 := by
  intro p hp
  have h : env9457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9158_9457 : H12AffineEnvironment.transform 26 807681 env9158 = env9457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 807681 env9158 == env9457) = true)

def env9458 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,4194304,524524,90336,8329,21040,807681,4735913,4735573,605035,529049,4796990,524289,602955,2695635,90943]

theorem envBound9458 : H12AffineFastState.Bounded env9458 := by
  intro p hp
  have h : env9458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9457_9458 : H12AffineEnvironment.transform 23 90336 env9457 = env9458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90336 env9457 == env9458) = true)

def env9459 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,262144,4960,8693,2097152,4194304,5004,90336,8329,21040,278625,4214985,4215093,75787,505,4268382,4961,73771,2175667,90943]

theorem envBound9459 : H12AffineFastState.Bounded env9459 := by
  intro p hp
  have h : env9459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9458_9459 : H12AffineEnvironment.transform 18 4960 env9458 = env9459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4960 env9458 == env9459) = true)

theorem identity9459 : scanCanonicalize (H12AffineFastState.compose env9459 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 24770) := by decide +kernel

theorem selectedBound9459 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9460 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,24770,4605,262144,4960,8693,2097152,4194304,5004,34,8329,21040,278625,4214985,4215093,18633,505,4211100,4961,16617,2118257,1021]

theorem envBound9460 : H12AffineFastState.Bounded env9460 := by
  intro p hp
  have h : env9460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9459_9460 : H12AffineEnvironment.transform 15 24770 env9459 = env9460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24770 env9459 == env9460) = true)

def env9461 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,24770,4605,262144,4960,8693,64,4194304,5004,34,8329,21040,278625,4214985,4215093,18633,505,4211100,4961,16617,21041,1021]

theorem envBound9461 : H12AffineFastState.Bounded env9461 := by
  intro p hp
  have h : env9461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9460_9461 : H12AffineEnvironment.transform 20 64 env9460 = env9461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env9460 == env9461) = true)

theorem identity9461 : scanCanonicalize (H12AffineFastState.compose env9461 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 282926) := by decide +kernel

theorem selectedBound9461 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9462 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,24770,4605,262144,4960,8693,64,282926,5004,34,8329,21040,278625,262631,262171,18633,505,266418,4961,16617,21041,1021]

theorem envBound9462 : H12AffineFastState.Bounded env9462 := by
  intro p hp
  have h : env9462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9461_9462 : H12AffineEnvironment.transform 21 282926 env9461 = env9462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 282926 env9461 == env9462) = true)

def env9463 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,560,8693,8946,4605,262144,4960,8693,64,267038,5004,34,8329,4096,262737,262631,262171,2809,505,266418,4961,729,4097,1021]

theorem envBound9463 : H12AffineFastState.Bounded env9463 := by
  intro p hp
  have h : env9463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9462_9463 : H12AffineEnvironment.transform 13 560 env9462 = env9463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env9462 == env9463) = true)

def env9464 : List Nat := [2,4,8,16,32,64,128,256,216,257,2048,4096,8192,232,8693,8234,4605,262144,4536,8693,64,266694,4436,34,8329,4096,262281,262631,262171,2081,505,266418,4537,1,4097,293]

theorem envBound9464 : H12AffineFastState.Bounded env9464 := by
  intro p hp
  have h : env9464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9463_9464 : H12AffineEnvironment.transform 8 216 env9463 = env9464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env9463 == env9464) = true)

theorem identity9464 : scanCanonicalize (H12AffineFastState.compose env9464 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

end H12CloudChart0