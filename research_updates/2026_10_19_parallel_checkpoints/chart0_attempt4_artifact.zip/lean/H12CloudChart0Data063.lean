import H12CloudChart0Data062

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound15849 : H12AffineFastState.Bounded env15849 := by
  intro p hp
  have h : env15849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15848_15849 : H12AffineEnvironment.transform 17 32040 env15848 = env15849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env15848 == env15849) = true)

theorem identity15849 : scanCanonicalize (H12AffineFastState.compose env15849 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound15849 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env15850 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,65536,131072,23668,1024,21761,4161,136497,213334,201796,348,65,67927,152833,197703,67618,66562,21792,256,87159,82182,513]

theorem envBound15850 : H12AffineFastState.Bounded env15850 := by
  intro p hp
  have h : env15850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15849_15850 : H12AffineEnvironment.transform 12 348 env15849 = env15850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env15849 == env15850) = true)

theorem identity15850 : scanCanonicalize (H12AffineFastState.compose env15850 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound15850 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env15851 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,65536,82246,23668,1024,21761,4161,87159,16,21762,348,65,67927,70727,17665,67618,66562,21792,256,87159,82182,513]

theorem envBound15851 : H12AffineFastState.Bounded env15851 := by
  intro p hp
  have h : env15851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15850_15851 : H12AffineEnvironment.transform 16 82246 env15850 = env15851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env15850 == env15851) = true)

theorem identity15851 : scanCanonicalize (H12AffineFastState.compose env15851 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound15851 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env15852 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,21591,5393,23668,1024,21761,4161,32,16,21762,348,65,23808,16400,17665,23669,20565,21792,256,32,5457,513]

theorem envBound15852 : H12AffineFastState.Bounded env15852 := by
  intro p hp
  have h : env15852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15851_15852 : H12AffineEnvironment.transform 15 21591 env15851 = env15852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env15851 == env15852) = true)

theorem identity15852 : scanCanonicalize (H12AffineFastState.compose env15852 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound15852 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15853 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,9,16384,21589,21591,5188,23668,1024,21588,4161,32,16,21591,9,65,23637,16400,17492,23669,20565,21621,85,32,5124,513]

theorem envBound15853 : H12AffineFastState.Bounded env15853 := by
  intro p hp
  have h : env15853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15852_15853 : H12AffineEnvironment.transform 7 85 env15852 = env15853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env15852 == env15853) = true)

theorem identity15853 : scanCanonicalize (H12AffineFastState.compose env15853 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound15853 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env15854 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,9,5124,81,83,5188,2160,1024,80,4161,32,16,83,9,65,2129,5140,4176,2161,1105,113,85,32,5124,513]

theorem envBound15854 : H12AffineFastState.Bounded env15854 := by
  intro p hp
  have h : env15854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15853_15854 : H12AffineEnvironment.transform 13 5124 env15853 = env15854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env15853 == env15854) = true)

theorem identity15854 : scanCanonicalize (H12AffineFastState.compose env15854 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1557) := by decide +kernel

theorem selectedBound15854 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15855 : List Nat := [2,4,8,16,32,64,8,85,512,1024,1557,4096,9,5124,81,83,5188,1637,1024,80,4161,32,16,83,9,65,1604,5140,4176,1636,1105,113,85,32,5124,513]

theorem envBound15855 : H12AffineFastState.Bounded env15855 := by
  intro p hp
  have h : env15855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15854_15855 : H12AffineEnvironment.transform 10 1557 env15854 = env15855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1557 env15854 == env15855) = true)

theorem identity15855 : scanCanonicalize (H12AffineFastState.compose env15855 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound15855 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env15856 : List Nat := [2,4,8,1,32,64,8,68,512,1024,1540,4096,9,5124,64,66,5188,1637,1024,65,4161,32,1,66,9,65,1604,5125,4161,1636,1088,96,68,32,5124,513]

theorem envBound15856 : H12AffineFastState.Bounded env15856 := by
  intro p hp
  have h : env15856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15855_15856 : H12AffineEnvironment.transform 3 1 env15855 = env15856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env15855 == env15856) = true)

theorem identity15856 : scanCanonicalize (H12AffineFastState.compose env15856 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 97) := by decide +kernel

theorem selectedBound15856 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15857 : List Nat := [2,4,8,1,32,64,8,68,512,1024,1540,97,9,1125,64,66,1061,1637,1024,65,32,32,1,66,9,65,1604,1124,32,1636,1088,96,68,32,1125,513]

theorem envBound15857 : H12AffineFastState.Bounded env15857 := by
  intro p hp
  have h : env15857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15856_15857 : H12AffineEnvironment.transform 11 97 env15856 = env15857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 97 env15856 == env15857) = true)

theorem identity15857 : scanCanonicalize (H12AffineFastState.compose env15857 (packedSelected [0,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound15857 : packedSelected [0,3,5] rootPS < 2^1333 := by decide +kernel

def env15858 : List Nat := [2,4,8,1,32,64,8,68,512,69,577,97,9,32,64,66,96,544,69,65,32,32,1,66,9,65,513,33,32,545,5,96,68,32,32,513]

theorem envBound15858 : H12AffineFastState.Bounded env15858 := by
  intro p hp
  have h : env15858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15857_15858 : H12AffineEnvironment.transform 9 69 env15857 = env15858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env15857 == env15858) = true)

theorem identity15858 : scanCanonicalize (H12AffineFastState.compose env15858 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 75) := by decide +kernel

theorem selectedBound15858 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env15859 : List Nat := [2,4,8,1,32,64,8,68,75,69,10,97,9,32,64,66,96,107,69,65,32,32,1,66,9,65,74,33,32,106,5,96,68,32,32,74]

theorem envBound15859 : H12AffineFastState.Bounded env15859 := by
  intro p hp
  have h : env15859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15858_15859 : H12AffineEnvironment.transform 8 75 env15858 = env15859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 75 env15858 == env15859) = true)

theorem identity15859 : scanCanonicalize (H12AffineFastState.compose env15859 (packedSelected [3,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15859 : packedSelected [3,7] rootPS < 2^1333 := by decide +kernel

def env15860 : List Nat := [2,4,8,1,1,64,8,68,75,69,10,64,9,1,64,66,65,74,69,65,1,1,1,66,9,65,74,0,1,75,5,65,68,1,1,74]

theorem envBound15860 : H12AffineFastState.Bounded env15860 := by
  intro p hp
  have h : env15860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15859_15860 : H12AffineEnvironment.transform 4 1 env15859 = env15860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15859 == env15860) = true)

theorem identity15860 : scanCanonicalize (H12AffineFastState.compose env15860 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound15860 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15861 : List Nat := [2,4,8,1,1,10,8,14,1,15,10,10,9,1,10,8,11,0,15,11,1,1,1,8,9,11,0,0,1,1,5,11,14,1,1,0]

theorem envBound15861 : H12AffineFastState.Bounded env15861 := by
  intro p hp
  have h : env15861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15860_15861 : H12AffineEnvironment.transform 5 10 env15860 = env15861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env15860 == env15861) = true)

theorem identity15861 : scanCanonicalize (H12AffineFastState.compose env15861 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound15861 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15862 : List Nat := [2,4,2,1,1,0,2,4,1,5,0,0,3,1,0,2,1,0,5,1,1,1,1,2,3,1,0,0,1,1,5,1,4,1,1,0]

theorem envBound15862 : H12AffineFastState.Bounded env15862 := by
  intro p hp
  have h : env15862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15861_15862 : H12AffineEnvironment.transform 2 2 env15861 = env15862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env15861 == env15862) = true)

def env15863 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,4161,144493,474239,485741,8193,65,349474,395636,489838,67618,75103,272392,256,95531,90202,513]

theorem envBound15863 : H12AffineFastState.Bounded env15863 := by
  intro p hp
  have h : env15863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15847_15863 : H12AffineEnvironment.transform 6 9 env15847 = env15863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15847 == env15863) = true)

theorem identity15863 : scanCanonicalize (H12AffineFastState.compose env15863 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound15863 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env15864 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90138,262144,1024,29788,4161,87159,285797,264567,8193,65,349474,354670,268660,67618,75103,272392,256,95531,90202,513]

theorem envBound15864 : H12AffineFastState.Bounded env15864 := by
  intro p hp
  have h : env15864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15863_15864 : H12AffineEnvironment.transform 16 90138 env15863 = env15864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env15863 == env15864) = true)

theorem identity15864 : scanCanonicalize (H12AffineFastState.compose env15864 (packedSelected [0,4,7,9,11,14,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 22885) := by decide +kernel

theorem selectedBound15864 : packedSelected [0,4,7,9,11,14,18,23,32] rootPS < 2^1333 := by decide +kernel

def env15865 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90138,22885,1024,29788,4161,87159,1280,20498,8193,65,68679,77835,16401,67618,75103,29037,256,95531,90202,513]

theorem envBound15865 : H12AffineFastState.Bounded env15865 := by
  intro p hp
  have h : env15865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15864_15865 : H12AffineEnvironment.transform 17 22885 env15864 = env15865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22885 env15864 == env15865) = true)

theorem identity15865 : scanCanonicalize (H12AffineFastState.compose env15865 (packedSelected [3,4,5,8,9,14,15,17,18,20,23,28,38] rootPS)) = affineNative (2^(15+1) ^^^ 1046) := by decide +kernel

theorem selectedBound15865 : packedSelected [3,4,5,8,9,14,15,17,18,20,23,28,38] rootPS < 2^1333 := by decide +kernel

def env15866 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,1046,25612,22885,1024,29788,4161,20577,1280,20498,8193,65,2129,13341,16401,3124,8521,29037,256,28989,25676,513]

theorem envBound15866 : H12AffineFastState.Bounded env15866 := by
  intro p hp
  have h : env15866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15865_15866 : H12AffineEnvironment.transform 15 1046 env15865 = env15866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1046 env15865 == env15866) = true)

theorem identity15866 : scanCanonicalize (H12AffineFastState.compose env15866 (packedSelected [0,2,4,6,7,9,14,17] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound15866 : packedSelected [0,2,4,6,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env15867 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12620,1297,1046,5440,10281,1024,1296,4161,8493,1280,8542,8193,65,2129,13341,12637,3124,8521,33,256,113,5376,513]

theorem envBound15867 : H12AffineFastState.Bounded env15867 := by
  intro p hp
  have h : env15867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15866_15867 : H12AffineEnvironment.transform 13 12620 env15866 = env15867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env15866 == env15867) = true)

theorem identity15867 : scanCanonicalize (H12AffineFastState.compose env15867 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound15867 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15868 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1053,5457,1297,1046,5440,3124,1024,1296,4161,1328,1280,1347,1052,65,2129,4096,5440,3124,1364,33,256,113,5376,513]

theorem envBound15868 : H12AffineFastState.Bounded env15868 := by
  intro p hp
  have h : env15868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15867_15868 : H12AffineEnvironment.transform 12 1053 env15867 = env15868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env15867 == env15868) = true)

def env15869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180409,509986,498993,8328,65,349610,2496957,2596210,67618,119043,2373704,256,2199999,2191386,63188]

theorem envBound15869 : H12AffineFastState.Bounded env15869 := by
  intro p hp
  have h : env15869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15814_15869 : H12AffineEnvironment.transform 23 498993 env15814 = env15869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 498993 env15814 == env15869) = true)

def env15870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180409,509986,498993,8328,65,349610,395773,494898,67618,119043,272392,256,98815,90202,63188]

theorem envBound15870 : H12AffineFastState.Bounded env15870 := by
  intro p hp
  have h : env15870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15869_15870 : H12AffineEnvironment.transform 20 4160 env15869 = env15870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env15869 == env15870) = true)

def env15871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1024,32769,4160,180409,254082,243089,8328,65,97546,139613,238994,67618,119043,168,256,98815,90202,63188]

theorem envBound15871 : H12AffineFastState.Bounded env15871 := by
  intro p hp
  have h : env15871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15870_15871 : H12AffineEnvironment.transform 17 10400 env15870 = env15871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env15870 == env15871) = true)

def env15872 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,180273,253962,242969,8192,65,97546,139613,238874,67618,119043,32,256,98679,90202,63068]

theorem envBound15872 : H12AffineFastState.Bounded env15872 := by
  intro p hp
  have h : env15872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15871_15872 : H12AffineEnvironment.transform 6 8 env15871 = env15872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15871 == env15872) = true)

theorem identity15872 : scanCanonicalize (H12AffineFastState.compose env15872 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound15872 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15873 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10280,1024,29788,4160,144492,201815,213316,8192,65,97546,139613,217415,67618,75102,32,256,95530,90202,513]

theorem envBound15873 : H12AffineFastState.Bounded env15873 := by
  intro p hp
  have h : env15873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15872_15873 : H12AffineEnvironment.transform 14 29789 env15872 = env15873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env15872 == env15873) = true)

theorem identity15873 : scanCanonicalize (H12AffineFastState.compose env15873 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound15873 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env15874 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,29963,131072,10280,1024,29788,4160,144492,155996,144463,8192,65,2049,139613,140364,32041,20565,32,256,33,5457,513]

theorem envBound15874 : H12AffineFastState.Bounded env15874 := by
  intro p hp
  have h : env15874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15873_15874 : H12AffineEnvironment.transform 15 29963 env15873 = env15874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env15873 == env15874) = true)

theorem identity15874 : scanCanonicalize (H12AffineFastState.compose env15874 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound15874 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env15875 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,21590,131072,2421,1024,21761,4160,136497,147457,136466,349,65,2049,131072,132369,23668,20565,32,256,33,5457,513]

theorem envBound15875 : H12AffineFastState.Bounded env15875 := by
  intro p hp
  have h : env15875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15874_15875 : H12AffineEnvironment.transform 12 349 env15874 = env15875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env15874 == env15875) = true)

theorem identity15875 : scanCanonicalize (H12AffineFastState.compose env15875 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound15875 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env15876 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1,343,131072,2421,1024,0,4160,136497,136448,136466,349,65,2049,131072,132369,2421,1364,32,256,33,5457,513]

theorem envBound15876 : H12AffineFastState.Bounded env15876 := by
  intro p hp
  have h : env15876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15875_15876 : H12AffineEnvironment.transform 13 5377 env15875 = env15876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env15875 == env15876) = true)

theorem identity15876 : scanCanonicalize (H12AffineFastState.compose env15876 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound15876 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15877 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1,343,5392,2421,1024,0,4160,33,16,2,349,65,2049,5392,4097,2421,1364,32,256,33,5457,513]

theorem envBound15877 : H12AffineFastState.Bounded env15877 := by
  intro p hp
  have h : env15877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15876_15877 : H12AffineEnvironment.transform 16 5392 env15876 = env15877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env15876 == env15877) = true)

theorem identity15877 : scanCanonicalize (H12AffineFastState.compose env15877 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3419) := by decide +kernel

theorem selectedBound15877 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15878 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3419,349,2138,1,343,2123,2421,1024,0,3355,33,16,2,349,65,2049,2123,3418,2421,1364,32,256,33,2058,513]

theorem envBound15878 : H12AffineFastState.Bounded env15878 := by
  intro p hp
  have h : env15878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15877_15878 : H12AffineEnvironment.transform 11 3419 env15877 = env15878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3419 env15877 == env15878) = true)

theorem identity15878 : scanCanonicalize (H12AffineFastState.compose env15878 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound15878 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15879 : List Nat := [2,4,8,16,32,10,8,256,512,1024,2048,3345,279,2064,1,285,2049,2367,1024,0,3355,33,16,2,279,11,2049,2049,3344,2367,1310,32,256,33,2058,513]

theorem envBound15879 : H12AffineFastState.Bounded env15879 := by
  intro p hp
  have h : env15879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15878_15879 : H12AffineEnvironment.transform 5 10 env15878 = env15879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env15878 == env15879) = true)

theorem identity15879 : scanCanonicalize (H12AffineFastState.compose env15879 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15879 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env15880 : List Nat := [2,4,8,16,0,10,8,256,512,1024,2048,3345,279,2064,1,285,2049,2335,1024,0,3355,1,16,2,279,11,2049,2049,3344,2335,1310,0,256,1,2058,513]

theorem envBound15880 : H12AffineFastState.Bounded env15880 := by
  intro p hp
  have h : env15880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15879_15880 : H12AffineEnvironment.transform 4 0 env15879 = env15880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15879 == env15880) = true)

theorem identity15880 : scanCanonicalize (H12AffineFastState.compose env15880 (packedSelected [5,8,15] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound15880 : packedSelected [5,8,15] rootPS < 2^1333 := by decide +kernel

def env15881 : List Nat := [2,4,8,11,0,10,8,256,512,1024,2048,3338,268,2059,1,262,2049,2308,1024,0,3328,1,11,2,268,11,2049,2049,3339,2308,1285,0,256,1,2058,513]

theorem envBound15881 : H12AffineFastState.Bounded env15881 := by
  intro p hp
  have h : env15881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15880_15881 : H12AffineEnvironment.transform 3 11 env15880 = env15881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env15880 == env15881) = true)

theorem identity15881 : scanCanonicalize (H12AffineFastState.compose env15881 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound15881 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15882 : List Nat := [2,4,8,11,0,10,8,15,512,1024,2048,3077,3,2059,1,9,2049,2059,1024,0,3087,1,11,2,3,11,2049,2049,3076,2059,1034,0,15,1,2058,513]

theorem envBound15882 : H12AffineFastState.Bounded env15882 := by
  intro p hp
  have h : env15882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15881_15882 : H12AffineEnvironment.transform 7 15 env15881 = env15882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env15881 == env15882) = true)

theorem identity15882 : scanCanonicalize (H12AffineFastState.compose env15882 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound15882 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15883 : List Nat := [2,4,8,11,0,10,8,15,11,1024,2048,3077,3,2059,1,9,2049,2059,1024,0,3087,1,11,2,3,11,2049,2049,3076,2059,1034,0,15,1,2058,10]

theorem envBound15883 : H12AffineFastState.Bounded env15883 := by
  intro p hp
  have h : env15883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15882_15883 : H12AffineEnvironment.transform 8 11 env15882 = env15883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env15882 == env15883) = true)

theorem identity15883 : scanCanonicalize (H12AffineFastState.compose env15883 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1037) := by decide +kernel

theorem selectedBound15883 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15884 : List Nat := [2,4,8,11,0,10,8,15,11,1024,1037,8,3,1030,1,9,1036,1030,1024,0,2,1,11,2,3,11,1036,1036,9,1030,1034,0,15,1,1031,10]

theorem envBound15884 : H12AffineFastState.Bounded env15884 := by
  intro p hp
  have h : env15884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15883_15884 : H12AffineEnvironment.transform 10 1037 env15883 = env15884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1037 env15883 == env15884) = true)

theorem identity15884 : scanCanonicalize (H12AffineFastState.compose env15884 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound15884 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15885 : List Nat := [0,4,8,9,0,8,8,13,9,1024,1037,8,1,1028,1,9,1036,1028,1024,0,0,1,9,0,1,9,1036,1036,9,1028,1032,0,13,1,1029,8]

theorem envBound15885 : H12AffineFastState.Bounded env15885 := by
  intro p hp
  have h : env15885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15884_15885 : H12AffineEnvironment.transform 0 0 env15884 = env15885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env15884 == env15885) = true)

theorem identity15885 : scanCanonicalize (H12AffineFastState.compose env15885 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound15885 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15886 : List Nat := [0,0,8,9,0,8,8,9,9,1024,1033,8,1,1024,1,9,1032,1024,1024,0,0,1,9,0,1,9,1032,1032,9,1024,1032,0,9,1,1025,8]

theorem envBound15886 : H12AffineFastState.Bounded env15886 := by
  intro p hp
  have h : env15886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15885_15886 : H12AffineEnvironment.transform 1 0 env15885 = env15886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env15885 == env15886) = true)

theorem identity15886 : scanCanonicalize (H12AffineFastState.compose env15886 (packedSelected [8] rootPS)) = affineNative (2^(9+1) ^^^ 0) := by decide +kernel

theorem selectedBound15886 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env15887 : List Nat := [0,0,8,9,0,8,8,9,9,0,9,8,1,0,1,9,8,0,0,0,0,1,9,0,1,9,8,8,9,0,8,0,9,1,1,8]

theorem envBound15887 : H12AffineFastState.Bounded env15887 := by
  intro p hp
  have h : env15887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15886_15887 : H12AffineEnvironment.transform 9 0 env15886 = env15887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env15886 == env15887) = true)

def env15888 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,180272,253963,242968,8193,65,97546,139613,238875,67618,119043,33,256,98678,90202,63069]

theorem envBound15888 : H12AffineFastState.Bounded env15888 := by
  intro p hp
  have h : env15888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15871_15888 : H12AffineEnvironment.transform 6 9 env15871 = env15888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15871 == env15888) = true)

theorem identity15888 : scanCanonicalize (H12AffineFastState.compose env15888 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound15888 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15889 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1024,32769,4160,169265,242954,242968,8193,65,75787,139613,238875,67618,99330,33,256,98678,79195,41820]

theorem envBound15889 : H12AffineFastState.Bounded env15889 := by
  intro p hp
  have h : env15889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15888_15889 : H12AffineEnvironment.transform 13 5377 env15888 = env15889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env15888 == env15889) = true)

theorem identity15889 : scanCanonicalize (H12AffineFastState.compose env15889 (packedSelected [1,3,8,10,18,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 69974) := by decide +kernel

theorem selectedBound15889 : packedSelected [1,3,8,10,18,23,24] rootPS < 2^1333 := by decide +kernel

def env15890 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,69974,10281,1024,32769,4160,99431,42076,42062,8193,65,75787,77835,46157,67618,99330,33,256,98678,79195,41820]

theorem envBound15890 : H12AffineFastState.Bounded env15890 := by
  intro p hp
  have h : env15890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15889_15890 : H12AffineEnvironment.transform 16 69974 env15889 = env15890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 69974 env15889 == env15890) = true)

theorem identity15890 : scanCanonicalize (H12AffineFastState.compose env15890 (packedSelected [0,3,4,5,7,10,16,18,19,20,22,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound15890 : packedSelected [0,3,4,5,7,10,16,18,19,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env15891 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,69974,10281,1024,8540,4160,75066,1281,1299,8193,65,75787,77835,5392,67618,75103,33,256,73771,79195,513]

theorem envBound15891 : H12AffineFastState.Bounded env15891 := by
  intro p hp
  have h : env15891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15890_15891 : H12AffineEnvironment.transform 14 8541 env15890 = env15891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env15890 == env15891) = true)

theorem identity15891 : scanCanonicalize (H12AffineFastState.compose env15891 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 6194) := by decide +kernel

theorem selectedBound15891 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env15892 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,6194,2404,10281,1024,8540,4160,15624,1281,1299,8193,65,12345,10297,5392,4112,15725,33,256,14361,11625,513]

theorem envBound15892 : H12AffineFastState.Bounded env15892 := by
  intro p hp
  have h : env15892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15891_15892 : H12AffineEnvironment.transform 15 6194 env15891 = env15892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6194 env15891 == env15892) = true)

theorem identity15892 : scanCanonicalize (H12AffineFastState.compose env15892 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 6200) := by decide +kernel

theorem selectedBound15892 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env15893 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,6200,5377,6501,6194,2404,4113,1024,6500,4160,1328,1281,1299,6201,65,2049,4097,5392,4112,1365,33,256,33,5457,513]

theorem envBound15893 : H12AffineFastState.Bounded env15893 := by
  intro p hp
  have h : env15893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15892_15893 : H12AffineEnvironment.transform 12 6200 env15892 = env15893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6200 env15892 == env15893) = true)

theorem identity15893 : scanCanonicalize (H12AffineFastState.compose env15893 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(10+1) ^^^ 1344) := by decide +kernel

theorem selectedBound15893 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env15894 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1344,4096,5496,5377,5157,5490,1060,4113,1024,5156,4160,1328,1281,1299,5497,65,1345,4097,5392,4112,1365,33,256,33,5457,513]

theorem envBound15894 : H12AffineFastState.Bounded env15894 := by
  intro p hp
  have h : env15894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15893_15894 : H12AffineEnvironment.transform 10 1344 env15893 = env15894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env15893 == env15894) = true)

theorem identity15894 : scanCanonicalize (H12AffineFastState.compose env15894 (packedSelected [2,6,11] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound15894 : packedSelected [2,6,11] rootPS < 2^1333 := by decide +kernel

def env15895 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1076,4096,5132,5237,5157,5126,1060,4113,1024,5156,4160,1092,1141,1127,5133,65,1077,4097,5220,4112,1057,33,116,33,5157,513]

theorem envBound15895 : H12AffineFastState.Bounded env15895 := by
  intro p hp
  have h : env15895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15894_15895 : H12AffineEnvironment.transform 7 116 env15894 = env15895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env15894 == env15895) = true)

theorem identity15895 : scanCanonicalize (H12AffineFastState.compose env15895 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(11+1) ^^^ 1140) := by decide +kernel

theorem selectedBound15895 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env15896 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1076,1140,120,1,81,114,1060,1125,1024,80,1076,1092,1141,1127,121,65,1077,1141,16,1124,1057,33,116,33,81,513]

theorem envBound15896 : H12AffineFastState.Bounded env15896 := by
  intro p hp
  have h : env15896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15895_15896 : H12AffineEnvironment.transform 11 1140 env15895 = env15896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1140 env15895 == env15896) = true)

theorem identity15896 : scanCanonicalize (H12AffineFastState.compose env15896 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15896 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15897 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1076,1061,41,1,0,35,1060,1076,1024,1,1076,1045,1060,1078,40,16,1077,1060,16,1077,1057,33,37,33,0,513]

theorem envBound15897 : H12AffineFastState.Bounded env15897 := by
  intro p hp
  have h : env15897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15896_15897 : H12AffineEnvironment.transform 5 17 env15896 = env15897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15896 == env15897) = true)

theorem identity15897 : scanCanonicalize (H12AffineFastState.compose env15897 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound15897 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15898 : List Nat := [2,4,8,16,32,17,9,37,512,37,17,0,41,1,0,35,1,17,37,1,17,48,1,19,40,16,16,1,16,16,4,33,37,33,0,513]

theorem envBound15898 : H12AffineFastState.Bounded env15898 := by
  intro p hp
  have h : env15898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15897_15898 : H12AffineEnvironment.transform 9 37 env15897 = env15898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env15897 == env15898) = true)

theorem identity15898 : scanCanonicalize (H12AffineFastState.compose env15898 (packedSelected [1,2,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound15898 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env15899 : List Nat := [2,4,8,1,32,0,9,37,512,37,0,0,41,1,0,35,1,0,37,1,0,33,1,2,40,1,1,1,1,1,4,33,37,33,0,513]

theorem envBound15899 : H12AffineFastState.Bounded env15899 := by
  intro p hp
  have h : env15899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15898_15899 : H12AffineEnvironment.transform 3 1 env15898 = env15899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env15898 == env15899) = true)

theorem identity15899 : scanCanonicalize (H12AffineFastState.compose env15899 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound15899 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15900 : List Nat := [2,0,8,1,32,0,9,33,512,33,0,0,41,1,0,35,1,0,33,1,0,33,1,2,40,1,1,1,1,1,0,33,33,33,0,513]

theorem envBound15900 : H12AffineFastState.Bounded env15900 := by
  intro p hp
  have h : env15900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15899_15900 : H12AffineEnvironment.transform 1 0 env15899 = env15900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env15899 == env15900) = true)

theorem identity15900 : scanCanonicalize (H12AffineFastState.compose env15900 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound15900 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15901 : List Nat := [2,0,8,1,32,0,9,33,3,33,0,0,41,1,0,35,1,0,33,1,0,33,1,2,40,1,1,1,1,1,0,33,33,33,0,2]

theorem envBound15901 : H12AffineFastState.Bounded env15901 := by
  intro p hp
  have h : env15901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15900_15901 : H12AffineEnvironment.transform 8 3 env15900 = env15901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env15900 == env15901) = true)

theorem identity15901 : scanCanonicalize (H12AffineFastState.compose env15901 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15901 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15902 : List Nat := [2,0,8,1,0,0,9,1,3,1,0,0,9,1,0,3,1,0,1,1,0,1,1,2,8,1,1,1,1,1,0,1,1,1,0,2]

theorem envBound15902 : H12AffineFastState.Bounded env15902 := by
  intro p hp
  have h : env15902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15901_15902 : H12AffineEnvironment.transform 4 0 env15901 = env15902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15901 == env15902) = true)

theorem identity15902 : scanCanonicalize (H12AffineFastState.compose env15902 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound15902 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15903 : List Nat := [2,0,2,1,0,0,3,1,3,1,0,0,3,1,0,3,1,0,1,1,0,1,1,2,2,1,1,1,1,1,0,1,1,1,0,2]

theorem envBound15903 : H12AffineFastState.Bounded env15903 := by
  intro p hp
  have h : env15903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15902_15903 : H12AffineEnvironment.transform 2 2 env15902 = env15903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env15902 == env15903) = true)

theorem identity15903 : scanCanonicalize (H12AffineFastState.compose env15903 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound15903 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15904 : List Nat := [1,0,1,1,0,0,0,1,0,1,0,0,0,1,0,0,1,0,1,1,0,1,1,1,1,1,1,1,1,1,0,1,1,1,0,1]

theorem envBound15904 : H12AffineFastState.Bounded env15904 := by
  intro p hp
  have h : env15904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15903_15904 : H12AffineEnvironment.transform 0 1 env15903 = env15904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env15903 == env15904) = true)

def env15905 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1024,32769,4160,180409,254083,243088,8328,65,97547,139612,238995,67618,119043,169,256,98815,90202,63188]

theorem envBound15905 : H12AffineFastState.Bounded env15905 := by
  intro p hp
  have h : env15905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15870_15905 : H12AffineEnvironment.transform 17 10401 env15870 = env15905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env15870 == env15905) = true)

def env15906 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,180273,253963,242968,8192,65,97547,139612,238875,67618,119043,33,256,98679,90202,63068]

theorem envBound15906 : H12AffineFastState.Bounded env15906 := by
  intro p hp
  have h : env15906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15905_15906 : H12AffineEnvironment.transform 6 8 env15905 = env15906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15905 == env15906) = true)

theorem identity15906 : scanCanonicalize (H12AffineFastState.compose env15906 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound15906 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15907 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70727,10281,1024,32769,4160,119926,62540,41311,8192,65,97547,79131,45404,67618,119043,33,256,98679,90202,63068]

theorem envBound15907 : H12AffineFastState.Bounded env15907 := by
  intro p hp
  have h : env15907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15906_15907 : H12AffineEnvironment.transform 16 70727 env15906 = env15907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env15906 == env15907) = true)

theorem identity15907 : scanCanonicalize (H12AffineFastState.compose env15907 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound15907 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env15908 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,70727,10281,1024,8541,4160,95530,21776,3,8192,65,97547,79131,4096,67618,94303,33,256,73771,90202,22272]

theorem envBound15908 : H12AffineFastState.Bounded env15908 := by
  intro p hp
  have h : env15908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15907_15908 : H12AffineEnvironment.transform 14 8540 env15907 = env15908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env15907 == env15908) = true)

theorem identity15908 : scanCanonicalize (H12AffineFastState.compose env15908 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound15908 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,19,20,23] rootPS < 2^1333 := by decide +kernel

def env15909 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,8540,65536,70727,10281,1024,8541,4160,74078,356,3,8192,65,76159,79131,4096,67618,74795,33,256,73771,78894,884]

theorem envBound15909 : H12AffineFastState.Bounded env15909 := by
  intro p hp
  have h : env15909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15908_15909 : H12AffineEnvironment.transform 13 5236 env15908 = env15909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env15908 == env15909) = true)

theorem identity15909 : scanCanonicalize (H12AffineFastState.compose env15909 (packedSelected [0,2,4,7,9,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound15909 : packedSelected [0,2,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env15910 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,8192,4404,8540,65536,69895,10281,320,8541,4160,74078,356,3,8192,65,76159,77915,4096,67618,74091,33,256,73771,78190,884]

theorem envBound15910 : H12AffineFastState.Bounded env15910 := by
  intro p hp
  have h : env15910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15909_15910 : H12AffineEnvironment.transform 9 320 env15909 = env15910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env15909 == env15910) = true)

theorem identity15910 : scanCanonicalize (H12AffineFastState.compose env15910 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound15910 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env15911 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,41,4404,373,65536,69895,2048,320,372,4160,65911,356,3,41,65,67926,69746,4096,67618,65858,33,256,65538,69959,884]

theorem envBound15911 : H12AffineFastState.Bounded env15911 := by
  intro p hp
  have h : env15911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15910_15911 : H12AffineEnvironment.transform 12 41 env15910 = env15911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env15910 == env15911) = true)

def env15912 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,180272,253962,242969,8193,65,97547,139612,238874,67618,119043,32,256,98678,90202,63069]

theorem envBound15912 : H12AffineFastState.Bounded env15912 := by
  intro p hp
  have h : env15912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15905_15912 : H12AffineEnvironment.transform 6 9 env15905 = env15912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15905 == env15912) = true)

theorem identity15912 : scanCanonicalize (H12AffineFastState.compose env15912 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 111898) := by decide +kernel

theorem selectedBound15912 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15913 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10280,1024,32769,4160,95530,21776,3,8193,65,97547,103494,4096,67618,119043,32,256,98678,90202,63069]

theorem envBound15913 : H12AffineFastState.Bounded env15913 := by
  intro p hp
  have h : env15913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15912_15913 : H12AffineEnvironment.transform 16 111898 env15912 = env15913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111898 env15912 == env15913) = true)

theorem identity15913 : scanCanonicalize (H12AffineFastState.compose env15913 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound15913 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env15914 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,65536,103494,2420,1024,32769,4160,87158,21776,3,349,65,89175,103494,4096,67618,119043,32,256,98678,82182,55041]

theorem envBound15914 : H12AffineFastState.Bounded env15914 := by
  intro p hp
  have h : env15914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15913_15914 : H12AffineEnvironment.transform 12 348 env15913 = env15914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env15913 == env15914) = true)

theorem identity15914 : scanCanonicalize (H12AffineFastState.compose env15914 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15914 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env15915 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,32768,65536,103447,2341,1024,32769,4113,87079,21776,3,268,16,89094,103447,4096,67618,119043,32,256,98599,82182,55041]

theorem envBound15915 : H12AffineFastState.Bounded env15915 := by
  intro p hp
  have h : env15915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15914_15915 : H12AffineEnvironment.transform 5 17 env15914 = env15915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15914 == env15915) = true)

theorem identity15915 : scanCanonicalize (H12AffineFastState.compose env15915 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound15915 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env15916 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,32768,35,37940,2341,1024,32769,4113,21508,21776,3,268,16,23589,37940,4096,2049,53536,32,256,33028,16677,55041]

theorem envBound15916 : H12AffineFastState.Bounded env15916 := by
  intro p hp
  have h : env15916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15915_15916 : H12AffineEnvironment.transform 15 35 env15915 = env15916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env15915 == env15916) = true)

theorem identity15916 : scanCanonicalize (H12AffineFastState.compose env15916 (packedSelected [0,2,6,7,11,12,15,16,23] rootPS)) = affineNative (2^(14+1) ^^^ 21540) := by decide +kernel

theorem selectedBound15916 : packedSelected [0,2,6,7,11,12,15,16,23] rootPS < 2^1333 := by decide +kernel

def env15917 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,21540,35,16400,2341,1024,21541,4113,21508,21776,3,268,16,23589,16400,4096,2049,1284,32,256,21792,16677,805]

theorem envBound15917 : H12AffineFastState.Bounded env15917 := by
  intro p hp
  have h : env15917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15916_15917 : H12AffineEnvironment.transform 14 21540 env15916 = env15917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21540 env15916 == env15917) = true)

theorem identity15917 : scanCanonicalize (H12AffineFastState.compose env15917 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound15917 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15918 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5156,0,35,5172,2341,1024,1,4113,32,308,3,268,16,2049,5172,4096,2049,1284,32,256,260,5377,805]

theorem envBound15918 : H12AffineFastState.Bounded env15918 := by
  intro p hp
  have h : env15918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15917_15918 : H12AffineEnvironment.transform 13 5156 env15917 = env15918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env15917 == env15918) = true)

theorem identity15918 : scanCanonicalize (H12AffineFastState.compose env15918 (packedSelected [1,3,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15918 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env15919 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,269,5124,0,3,5140,2309,1024,1,4113,0,276,3,268,16,2049,5140,4096,2049,1284,0,256,260,5377,773]

theorem envBound15919 : H12AffineFastState.Bounded env15919 := by
  intro p hp
  have h : env15919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15918_15919 : H12AffineEnvironment.transform 4 0 env15918 = env15919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15918 == env15919) = true)

theorem identity15919 : scanCanonicalize (H12AffineFastState.compose env15919 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15919 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env15920 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,4096,9,5124,0,3,5140,2049,1024,1,4113,0,16,3,8,16,2049,5140,4096,2049,1024,0,4,0,5125,513]

theorem envBound15920 : H12AffineFastState.Bounded env15920 := by
  intro p hp
  have h : env15920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15919_15920 : H12AffineEnvironment.transform 7 4 env15919 = env15920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15919 == env15920) = true)

theorem identity15920 : scanCanonicalize (H12AffineFastState.compose env15920 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound15920 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15921 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,17,9,1045,0,3,1029,2049,1024,1,0,0,16,3,8,16,2049,1029,17,2049,1024,0,4,0,1044,513]

theorem envBound15921 : H12AffineFastState.Bounded env15921 := by
  intro p hp
  have h : env15921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15920_15921 : H12AffineEnvironment.transform 11 17 env15920 = env15921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env15920 == env15921) = true)

theorem identity15921 : scanCanonicalize (H12AffineFastState.compose env15921 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound15921 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15922 : List Nat := [2,4,8,16,0,17,9,4,17,1024,2048,17,9,1045,0,3,1029,2049,1024,1,0,0,16,3,8,16,2049,1029,17,2049,1024,0,4,0,1044,16]

theorem envBound15922 : H12AffineFastState.Bounded env15922 := by
  intro p hp
  have h : env15922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15921_15922 : H12AffineEnvironment.transform 8 17 env15921 = env15922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env15921 == env15922) = true)

theorem identity15922 : scanCanonicalize (H12AffineFastState.compose env15922 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound15922 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15923 : List Nat := [2,4,8,1,0,0,9,4,0,1024,2048,0,9,1028,0,3,1029,2049,1024,1,0,0,1,3,8,1,2049,1029,0,2049,1024,0,4,0,1029,1]

theorem envBound15923 : H12AffineFastState.Bounded env15923 := by
  intro p hp
  have h : env15923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15922_15923 : H12AffineEnvironment.transform 3 1 env15922 = env15923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env15922 == env15923) = true)

def env15924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180409,509986,498993,8328,65,349610,395772,494899,67618,119043,272393,256,98814,90203,63188]

theorem envBound15924 : H12AffineFastState.Bounded env15924 := by
  intro p hp
  have h : env15924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15869_15924 : H12AffineEnvironment.transform 20 4161 env15869 = env15924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env15869 == env15924) = true)

theorem identity15924 : scanCanonicalize (H12AffineFastState.compose env15924 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190520) := by decide +kernel

theorem selectedBound15924 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,180409,73754,95497,8328,65,245138,57796,91403,67618,119043,180273,256,98814,90203,63188]

theorem envBound15925 : H12AffineFastState.Bounded env15925 := by
  intro p hp
  have h : env15925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15924_15925 : H12AffineEnvironment.transform 17 190520 env15924 = env15925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190520 env15924 == env15925) = true)

def env15926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,10400,1024,32769,4161,33,73754,95497,8328,65,97546,57796,91403,67618,119043,169,256,98814,90203,63188]

theorem envBound15926 : H12AffineFastState.Bounded env15926 := by
  intro p hp
  have h : env15926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15925_15926 : H12AffineEnvironment.transform 16 49304 env15925 = env15926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env15925 == env15926) = true)

theorem identity15926 : scanCanonicalize (H12AffineFastState.compose env15926 (packedSelected [1,2,4,5,6,7,12,14,16,18,20,22,24,27,28,31,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound15926 : packedSelected [1,2,4,5,6,7,12,14,16,18,20,22,24,27,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env15927 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,136,65536,16400,10400,1024,137,4161,33,73754,95497,8328,65,97546,24908,91403,67618,86411,169,256,65910,90203,30300]

theorem envBound15927 : H12AffineFastState.Bounded env15927 := by
  intro p hp
  have h : env15927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15926_15927 : H12AffineEnvironment.transform 14 136 env15926 = env15927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env15926 == env15927) = true)

theorem identity15927 : scanCanonicalize (H12AffineFastState.compose env15927 (packedSelected [0,3,4,7,10,11,16,17,19,20,22,24,32] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound15927 : packedSelected [0,3,4,7,10,11,16,17,19,20,22,24,32] rootPS < 2^1333 := by decide +kernel

def env15928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,136,65536,16400,2420,1024,137,4161,33,65998,87261,348,65,89310,16536,83167,67618,86411,169,256,65910,82319,22408]

theorem envBound15928 : H12AffineFastState.Bounded env15928 := by
  intro p hp
  have h : env15928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15927_15928 : H12AffineEnvironment.transform 12 468 env15927 = env15928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env15927 == env15928) = true)

theorem identity15928 : scanCanonicalize (H12AffineFastState.compose env15928 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound15928 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5377,136,65536,5393,2420,1024,137,4161,33,65998,66012,348,65,68063,5529,70110,67618,66698,169,256,65910,70798,649]

theorem envBound15929 : H12AffineFastState.Bounded env15929 := by
  intro p hp
  have h : env15929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15928_15929 : H12AffineEnvironment.transform 13 5377 env15928 = env15929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env15928 == env15929) = true)

theorem identity15929 : scanCanonicalize (H12AffineFastState.compose env15929 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound15929 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env15930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5377,136,398,5393,2420,1024,137,4161,33,64,82,348,65,2129,5529,4176,2476,1284,169,256,248,5376,649]

theorem envBound15930 : H12AffineFastState.Bounded env15930 := by
  intro p hp
  have h : env15930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15929_15930 : H12AffineEnvironment.transform 15 398 env15929 = env15930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env15929 == env15930) = true)

theorem identity15930 : scanCanonicalize (H12AffineFastState.compose env15930 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound15930 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env15931 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,0,262,5393,2420,1024,1,4161,33,64,82,348,65,2129,5393,4176,2340,1284,33,256,112,5376,513]

theorem envBound15931 : H12AffineFastState.Bounded env15931 := by
  intro p hp
  have h : env15931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15930_15931 : H12AffineEnvironment.transform 6 8 env15930 = env15931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15930 == env15931) = true)

theorem identity15931 : scanCanonicalize (H12AffineFastState.compose env15931 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15931 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env15932 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,0,262,5393,2340,1024,1,4113,33,16,2,268,17,2049,5393,4096,2340,1284,33,256,32,5376,513]

theorem envBound15932 : H12AffineFastState.Bounded env15932 := by
  intro p hp
  have h : env15932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15931_15932 : H12AffineEnvironment.transform 5 16 env15931 = env15932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15931 == env15932) = true)

theorem identity15932 : scanCanonicalize (H12AffineFastState.compose env15932 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound15932 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15933 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,277,268,1044,0,262,1028,2340,1024,1,260,33,16,2,268,17,2049,1028,277,2340,1284,33,256,32,1045,513]

theorem envBound15933 : H12AffineFastState.Bounded env15933 := by
  intro p hp
  have h : env15933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15932_15933 : H12AffineEnvironment.transform 11 277 env15932 = env15933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env15932 == env15933) = true)

theorem identity15933 : scanCanonicalize (H12AffineFastState.compose env15933 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound15933 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15934 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,277,268,293,0,262,309,2340,305,1,260,33,16,2,268,17,2049,309,277,2340,53,33,256,32,292,513]

theorem envBound15934 : H12AffineFastState.Bounded env15934 := by
  intro p hp
  have h : env15934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15933_15934 : H12AffineEnvironment.transform 9 305 env15933 = env15934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env15933 == env15934) = true)

theorem identity15934 : scanCanonicalize (H12AffineFastState.compose env15934 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound15934 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15935 : List Nat := [2,4,8,16,32,16,8,256,293,305,2048,277,268,293,0,262,309,2340,305,1,260,33,16,2,268,17,2049,309,277,2340,53,33,256,32,292,292]

theorem envBound15935 : H12AffineFastState.Bounded env15935 := by
  intro p hp
  have h : env15935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15934_15935 : H12AffineEnvironment.transform 8 293 env15934 = env15935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env15934 == env15935) = true)

theorem identity15935 : scanCanonicalize (H12AffineFastState.compose env15935 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound15935 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env15936 : List Nat := [2,4,8,16,17,16,8,256,276,256,2048,277,268,276,0,262,260,2325,256,1,260,16,16,2,268,17,2049,260,277,2325,4,16,256,17,277,277]

theorem envBound15936 : H12AffineFastState.Bounded env15936 := by
  intro p hp
  have h : env15936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15935_15936 : H12AffineEnvironment.transform 4 17 env15935 = env15936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env15935 == env15936) = true)

theorem identity15936 : scanCanonicalize (H12AffineFastState.compose env15936 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound15936 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15937 : List Nat := [2,4,8,16,17,16,8,256,276,256,17,277,268,276,0,262,260,260,256,1,260,16,16,2,268,17,16,260,277,260,4,16,256,17,277,277]

theorem envBound15937 : H12AffineFastState.Bounded env15937 := by
  intro p hp
  have h : env15937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15936_15937 : H12AffineEnvironment.transform 10 17 env15936 = env15937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env15936 == env15937) = true)

def env15938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,10401,1024,32769,4161,32,73754,95497,8328,65,97547,57796,91403,67618,119043,168,256,98814,90203,63188]

theorem envBound15938 : H12AffineFastState.Bounded env15938 := by
  intro p hp
  have h : env15938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15925_15938 : H12AffineEnvironment.transform 16 49305 env15925 = env15938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env15925 == env15938) = true)

theorem identity15938 : scanCanonicalize (H12AffineFastState.compose env15938 (packedSelected [1,2,4,5,6,7,12,14,16,18,20,22,24,27,28,31,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 21677) := by decide +kernel

theorem selectedBound15938 : packedSelected [1,2,4,5,6,7,12,14,16,18,20,22,24,27,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env15939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21677,65536,5172,10401,1024,21676,4161,32,73754,95497,8328,65,97547,13673,91403,67618,66990,168,256,87379,90203,8825]

theorem envBound15939 : H12AffineFastState.Bounded env15939 := by
  intro p hp
  have h : env15939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15938_15939 : H12AffineEnvironment.transform 14 21677 env15938 = env15939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21677 env15938 == env15939) = true)

theorem identity15939 : scanCanonicalize (H12AffineFastState.compose env15939 (packedSelected [2,5,6,7,8,9,10,12,16,19,22,23,24,27,28,32,41] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound15939 : packedSelected [2,5,6,7,8,9,10,12,16,19,22,23,24,27,28,32,41] rootPS < 2^1333 := by decide +kernel

def env15940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,428,65536,5172,10401,1024,429,4161,32,73754,73736,8328,65,75786,13673,77834,67618,66990,168,256,65618,79194,8825]

theorem envBound15940 : H12AffineFastState.Bounded env15940 := by
  intro p hp
  have h : env15940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15939_15940 : H12AffineEnvironment.transform 13 5377 env15939 = env15940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env15939 == env15940) = true)

theorem identity15940 : scanCanonicalize (H12AffineFastState.compose env15940 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound15940 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env15941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,428,65536,5172,2557,1024,429,4161,32,65862,65876,468,65,67926,5173,69974,67618,66990,168,256,65618,70662,805]

theorem envBound15941 : H12AffineFastState.Bounded env15941 := by
  intro p hp
  have h : env15941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15940_15941 : H12AffineEnvironment.transform 12 348 env15940 = env15941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env15940 == env15941) = true)

theorem identity15941 : scanCanonicalize (H12AffineFastState.compose env15941 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,16,17,19,20,23] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15941 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,16,17,19,20,23] rootPS < 2^1333 := by decide +kernel

def env15942 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5377,428,65536,5172,2477,1024,429,4113,32,65814,65796,388,17,67846,5173,69894,67618,66990,168,256,65538,70662,805]

theorem envBound15942 : H12AffineFastState.Bounded env15942 := by
  intro p hp
  have h : env15942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15941_15942 : H12AffineEnvironment.transform 5 16 env15941 = env15942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15941 == env15942) = true)

theorem identity15942 : scanCanonicalize (H12AffineFastState.compose env15942 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound15942 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env15943 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5377,428,398,5172,2477,1024,429,4113,32,152,138,388,17,2184,5173,4232,2476,1056,168,256,396,5512,805]

theorem envBound15943 : H12AffineFastState.Bounded env15943 := by
  intro p hp
  have h : env15943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15942_15943 : H12AffineEnvironment.transform 15 398 env15942 = env15943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env15942 == env15943) = true)

theorem identity15943 : scanCanonicalize (H12AffineFastState.compose env15943 (packedSelected [0,1,2,3,5,6,7,8,14,17] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound15943 : packedSelected [0,1,2,3,5,6,7,8,14,17] rootPS < 2^1333 := by decide +kernel

def env15944 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,160,5293,0,34,5172,2049,1024,1,4113,32,152,138,40,17,2184,5173,4232,2048,1056,168,172,32,5156,649]

theorem envBound15944 : H12AffineFastState.Bounded env15944 := by
  intro p hp
  have h : env15944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15943_15944 : H12AffineEnvironment.transform 7 172 env15943 = env15944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env15943 == env15944) = true)

theorem identity15944 : scanCanonicalize (H12AffineFastState.compose env15944 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15944 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env15945 : List Nat := [2,4,8,16,0,16,128,140,512,1024,2048,4096,128,5261,0,2,5140,2049,1024,1,4113,0,152,138,8,17,2184,5141,4232,2048,1024,136,140,0,5124,649]

theorem envBound15945 : H12AffineFastState.Bounded env15945 := by
  intro p hp
  have h : env15945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15944_15945 : H12AffineEnvironment.transform 4 0 env15944 = env15945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15944 == env15945) = true)

def env15946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507600,8830977,25265168,23160256,257,27378861,27337993,25207750]

theorem envBound15946 : H12AffineFastState.Bounded env15946 := by
  intro p hp
  have h : env15946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15725_15946 : H12AffineEnvironment.transform 18 1025 env15725 = env15946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env15725 == env15946) = true)

theorem identity15946 : scanCanonicalize (H12AffineFastState.compose env15946 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 272546) := by decide +kernel

theorem selectedBound15946 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env15947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,272546,8328,65,12839075,2468911,10507600,8830977,8760498,6638946,257,10873871,10816939,8686436]

theorem envBound15947 : H12AffineFastState.Bounded env15947 := by
  intro p hp
  have h : env15947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15946_15947 : H12AffineEnvironment.transform 23 272546 env15946 = env15947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 272546 env15946 == env15947) = true)

def env15948 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,147592,272546,8328,65,4302891,2468911,2233816,295049,519226,6638946,257,2600071,2575651,445420]

theorem envBound15948 : H12AffineFastState.Bounded env15948 := by
  intro p hp
  have h : env15948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15947_15948 : H12AffineEnvironment.transform 22 147592 env15947 = env15948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147592 env15947 == env15948) = true)

def env15949 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,152,272546,8328,65,4302891,2468911,2119112,295049,371754,6638946,257,2485399,2428211,297980]

theorem envBound15949 : H12AffineFastState.Bounded env15949 := by
  intro p hp
  have h : env15949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15948_15949 : H12AffineEnvironment.transform 16 16400 env15948 = env15949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env15948 == env15949) = true)

def env15950 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,16,272426,8192,65,4302891,2468911,2118976,294913,371754,6638946,257,2485279,2428211,297844]

theorem envBound15950 : H12AffineFastState.Bounded env15950 := by
  intro p hp
  have h : env15950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15949_15950 : H12AffineEnvironment.transform 6 8 env15949 = env15950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15949 == env15950) = true)

theorem identity15950 : scanCanonicalize (H12AffineFastState.compose env15950 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound15950 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env15951 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1025,32769,2097152,4194304,16,272426,8192,65,4229153,2395173,2118976,294913,298016,6581608,257,2411541,2370873,297844]

theorem envBound15951 : H12AffineFastState.Bounded env15951 := by
  intro p hp
  have h : env15951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15950_15951 : H12AffineEnvironment.transform 15 8202 env15950 = env15951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env15950 == env15951) = true)

theorem identity15951 : scanCanonicalize (H12AffineFastState.compose env15951 (packedSelected [1,3,4,5,7,8,9,10,16,17,19,20,27] rootPS)) = affineNative (2^(20+1) ^^^ 17680) := by decide +kernel

theorem selectedBound15951 : packedSelected [1,3,4,5,7,8,9,10,16,17,19,20,27] rootPS < 2^1333 := by decide +kernel

def env15952 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1025,32769,17680,4194304,16,272426,8192,65,4229153,313653,4176,294913,298016,4466808,257,297221,288809,297844]

theorem envBound15952 : H12AffineFastState.Bounded env15952 := by
  intro p hp
  have h : env15952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15951_15952 : H12AffineEnvironment.transform 20 17680 env15951 = env15952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17680 env15951 == env15952) = true)

def env15953 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,32040,1025,32769,17680,4194304,16,21762,8192,65,4229153,46109,4176,64809,61704,4216144,257,62509,5377,63068]

theorem envBound15953 : H12AffineFastState.Bounded env15953 := by
  intro p hp
  have h : env15953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15952_15953 : H12AffineEnvironment.transform 17 32040 env15952 = env15953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env15952 == env15953) = true)

theorem identity15953 : scanCanonicalize (H12AffineFastState.compose env15953 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 62509) := by decide +kernel

theorem selectedBound15953 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15954 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,32040,1025,32769,17680,62509,16,21762,8192,65,31756,46109,4176,64809,61704,41341,257,62509,5377,63068]

theorem envBound15954 : H12AffineFastState.Bounded env15954 := by
  intro p hp
  have h : env15954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15953_15954 : H12AffineEnvironment.transform 21 62509 env15953 = env15954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62509 env15953 == env15954) = true)

theorem identity15954 : scanCanonicalize (H12AffineFastState.compose env15954 (packedSelected [3,4,5,9,10,11,12,14,15,16,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 29992) := by decide +kernel

theorem selectedBound15954 : packedSelected [3,4,5,9,10,11,12,14,15,16,18,23,32] rootPS < 2^1333 := by decide +kernel

def env15955 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29992,8202,16400,32040,1025,29993,17680,261,16,21762,8192,65,31756,16693,4176,2049,1056,21589,257,261,5377,884]

theorem envBound15955 : H12AffineFastState.Bounded env15955 := by
  intro p hp
  have h : env15955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15954_15955 : H12AffineEnvironment.transform 14 29992 env15954 = env15955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29992 env15954 == env15955) = true)

theorem identity15955 : scanCanonicalize (H12AffineFastState.compose env15955 (packedSelected [0,2,4,6,7,9,11,14,16,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound15955 : packedSelected [0,2,4,6,7,9,11,14,16,20,23] rootPS < 2^1333 := by decide +kernel

def env15956 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,16384,21841,115,16400,23889,1025,21840,17680,261,16,21762,121,65,23669,16693,4176,2049,1056,21589,257,261,5377,884]

theorem envBound15956 : H12AffineFastState.Bounded env15956 := by
  intro p hp
  have h : env15956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15955_15956 : H12AffineEnvironment.transform 12 121 env15955 = env15956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env15955 == env15956) = true)

theorem identity15956 : scanCanonicalize (H12AffineFastState.compose env15956 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound15956 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env15957 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,5376,81,115,5392,2129,1025,80,4112,261,16,2,121,65,2421,5173,4176,2049,1056,341,257,261,5377,884]

theorem envBound15957 : H12AffineFastState.Bounded env15957 := by
  intro p hp
  have h : env15957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15956_15957 : H12AffineEnvironment.transform 13 5376 env15956 = env15957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env15956 == env15957) = true)

theorem identity15957 : scanCanonicalize (H12AffineFastState.compose env15957 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15957 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15958 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,40,5376,0,34,5392,2048,1025,1,4112,261,16,2,40,16,2340,5173,4097,2049,1056,260,257,261,5377,805]

theorem envBound15958 : H12AffineFastState.Bounded env15958 := by
  intro p hp
  have h : env15958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15957_15958 : H12AffineEnvironment.transform 5 17 env15957 = env15958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15957 == env15958) = true)

theorem identity15958 : scanCanonicalize (H12AffineFastState.compose env15958 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15958 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15959 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,8,5376,0,2,5392,2048,1025,1,4112,261,16,2,8,16,2308,5141,4097,2049,1024,260,257,261,5377,773]

theorem envBound15959 : H12AffineFastState.Bounded env15959 := by
  intro p hp
  have h : env15959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15958_15959 : H12AffineEnvironment.transform 4 0 env15958 = env15959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15958 == env15959) = true)

def env15960 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,32041,1025,32769,17680,4194304,16,21763,8192,65,4229153,46108,4176,64808,61705,4216145,257,62508,5376,63069]

theorem envBound15960 : H12AffineFastState.Bounded env15960 := by
  intro p hp
  have h : env15960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15952_15960 : H12AffineEnvironment.transform 17 32041 env15952 = env15960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env15952 == env15960) = true)

theorem identity15960 : scanCanonicalize (H12AffineFastState.compose env15960 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 112) := by decide +kernel

theorem selectedBound15960 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15961 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,32041,1025,32769,17680,112,16,21763,8192,65,34897,46108,4176,64808,61705,21793,257,62508,5376,63069]

theorem envBound15961 : H12AffineFastState.Bounded env15961 := by
  intro p hp
  have h : env15961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15960_15961 : H12AffineEnvironment.transform 21 112 env15960 = env15961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 112 env15960 == env15961) = true)

theorem identity15961 : scanCanonicalize (H12AffineFastState.compose env15961 (packedSelected [1,4,5,9,10,12,14,15,16,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound15961 : packedSelected [1,4,5,9,10,12,14,15,16,24,28] rootPS < 2^1333 := by decide +kernel

def env15962 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5156,32768,8202,5172,10509,1025,32769,4404,112,16,295,8192,65,34897,46108,4176,43276,42285,261,257,40968,5376,41593]

theorem envBound15962 : H12AffineFastState.Bounded env15962 := by
  intro p hp
  have h : env15962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15961_15962 : H12AffineEnvironment.transform 13 5156 env15961 = env15962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env15961 == env15962) = true)

theorem identity15962 : scanCanonicalize (H12AffineFastState.compose env15962 (packedSelected [0,2,3,5,6,7,10,11,12,15,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound15962 : packedSelected [0,2,3,5,6,7,10,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env15963 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5156,0,8202,5172,10509,1025,1,4404,112,16,295,8192,65,2129,13340,4176,10508,9517,261,257,8200,5376,8825]

theorem envBound15963 : H12AffineFastState.Bounded env15963 := by
  intro p hp
  have h : env15963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15962_15963 : H12AffineEnvironment.transform 14 0 env15962 = env15963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env15962 == env15963) = true)

theorem identity15963 : scanCanonicalize (H12AffineFastState.compose env15963 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound15963 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env15964 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,5156,0,8202,5172,10280,1025,1,4113,112,16,2,8192,65,2129,13340,4176,10281,9224,32,36,8200,5157,8825]

theorem envBound15964 : H12AffineFastState.Bounded env15964 := by
  intro p hp
  have h : env15964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15963_15964 : H12AffineEnvironment.transform 7 37 env15963 = env15964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env15963 == env15964) = true)

theorem identity15964 : scanCanonicalize (H12AffineFastState.compose env15964 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15964 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env15965 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,5156,0,8202,5172,10280,1025,1,4113,32,16,2,8192,17,2049,13340,4096,10281,9224,32,36,8200,5157,8745]

theorem envBound15965 : H12AffineFastState.Bounded env15965 := by
  intro p hp
  have h : env15965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15964_15965 : H12AffineEnvironment.transform 5 16 env15964 = env15965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15964 == env15965) = true)

theorem identity15965 : scanCanonicalize (H12AffineFastState.compose env15965 (packedSelected [0,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound15965 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env15966 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,5156,0,34,5172,2048,1025,1,4113,32,16,2,40,17,2049,5172,4096,2049,1056,32,36,32,5157,513]

theorem envBound15966 : H12AffineFastState.Bounded env15966 := by
  intro p hp
  have h : env15966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15965_15966 : H12AffineEnvironment.transform 12 40 env15965 = env15966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env15965 == env15966) = true)

theorem identity15966 : scanCanonicalize (H12AffineFastState.compose env15966 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound15966 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15967 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,1077,40,17,0,34,1,2048,1025,1,1060,32,16,2,40,17,2049,1,1077,2049,1056,32,36,32,16,513]

theorem envBound15967 : H12AffineFastState.Bounded env15967 := by
  intro p hp
  have h : env15967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15966_15967 : H12AffineEnvironment.transform 11 1077 env15966 = env15967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env15966 == env15967) = true)

theorem identity15967 : scanCanonicalize (H12AffineFastState.compose env15967 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound15967 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15968 : List Nat := [2,4,8,16,32,16,8,37,1,1024,2048,1077,40,17,0,34,1,2048,1025,1,1060,32,16,2,40,17,2049,1,1077,2049,1056,32,36,32,16,0]

theorem envBound15968 : H12AffineFastState.Bounded env15968 := by
  intro p hp
  have h : env15968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15967_15968 : H12AffineEnvironment.transform 8 1 env15967 = env15968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env15967 == env15968) = true)

theorem identity15968 : scanCanonicalize (H12AffineFastState.compose env15968 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound15968 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15969 : List Nat := [2,4,8,16,32,16,8,37,1,1024,17,1077,40,17,0,34,1,17,1025,1,1060,32,16,2,40,17,16,1,1077,16,1056,32,36,32,16,0]

theorem envBound15969 : H12AffineFastState.Bounded env15969 := by
  intro p hp
  have h : env15969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15968_15969 : H12AffineEnvironment.transform 10 17 env15968 = env15969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env15968 == env15969) = true)

theorem identity15969 : scanCanonicalize (H12AffineFastState.compose env15969 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound15969 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env15970 : List Nat := [2,4,8,16,32,16,8,37,1,53,17,0,40,17,0,34,1,17,52,1,17,32,16,2,40,17,16,1,0,16,21,32,36,32,16,0]

theorem envBound15970 : H12AffineFastState.Bounded env15970 := by
  intro p hp
  have h : env15970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15969_15970 : H12AffineEnvironment.transform 9 53 env15969 = env15970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env15969 == env15970) = true)

theorem identity15970 : scanCanonicalize (H12AffineFastState.compose env15970 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound15970 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15971 : List Nat := [2,4,8,16,16,16,8,21,1,5,17,0,24,17,0,18,1,17,4,1,17,16,16,2,24,17,16,1,0,16,21,16,20,16,16,0]

theorem envBound15971 : H12AffineFastState.Bounded env15971 := by
  intro p hp
  have h : env15971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15970_15971 : H12AffineEnvironment.transform 4 16 env15970 = env15971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env15970 == env15971) = true)

def env15972 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,17,272427,8193,65,4302891,2468911,2118977,294912,371754,6638946,257,2485278,2428211,297845]

theorem envBound15972 : H12AffineFastState.Bounded env15972 := by
  intro p hp
  have h : env15972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15949_15972 : H12AffineEnvironment.transform 6 9 env15949 = env15972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15949 == env15972) = true)

theorem identity15972 : scanCanonicalize (H12AffineFastState.compose env15972 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound15972 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env15973 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,2097152,4194304,17,41311,8193,65,4302891,2172251,2118977,2420,75102,6407190,257,2188650,2196551,513]

theorem envBound15973 : H12AffineFastState.Bounded env15973 := by
  intro p hp
  have h : env15973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15972_15973 : H12AffineEnvironment.transform 17 35188 env15972 = env15973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env15972 == env15973) = true)

theorem identity15973 : scanCanonicalize (H12AffineFastState.compose env15973 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound15973 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env15974 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,115735,4194304,17,41311,8193,65,4302891,57676,102742,2420,75102,4194305,257,41341,16464,513]

theorem envBound15974 : H12AffineFastState.Bounded env15974 := by
  intro p hp
  have h : env15974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15973_15974 : H12AffineEnvironment.transform 20 115735 env15973 = env15974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env15973 == env15974) = true)

def env15975 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,65536,16400,10588,1025,8233,91199,4194304,17,375,8193,65,4261891,16740,78206,2420,75102,4194305,257,341,16464,513]

theorem envBound15975 : H12AffineFastState.Bounded env15975 := by
  intro p hp
  have h : env15975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15974_15975 : H12AffineEnvironment.transform 14 8232 env15974 = env15975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env15974 == env15975) = true)

theorem identity15975 : scanCanonicalize (H12AffineFastState.compose env15975 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound15975 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env15976 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,1,65536,16400,2421,1025,0,82966,4194304,17,375,40,65,4261891,16740,69975,2420,66935,4194305,257,341,16464,513]

theorem envBound15976 : H12AffineFastState.Bounded env15976 := by
  intro p hp
  have h : env15976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15975_15976 : H12AffineEnvironment.transform 12 41 env15975 = env15976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env15975 == env15976) = true)

theorem identity15976 : scanCanonicalize (H12AffineFastState.compose env15976 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound15976 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env15977 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,1,65536,16400,2421,1025,0,82966,32,17,375,40,65,67619,16740,69975,2420,66935,33,257,341,16464,513]

theorem envBound15977 : H12AffineFastState.Bounded env15977 := by
  intro p hp
  have h : env15977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15976_15977 : H12AffineEnvironment.transform 21 32 env15976 = env15977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env15976 == env15977) = true)

theorem identity15977 : scanCanonicalize (H12AffineFastState.compose env15977 (packedSelected [3,10,19,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15977 : packedSelected [3,10,19,24] rootPS < 2^1333 := by decide +kernel

def env15978 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,41,16384,1,65536,16400,2341,1025,0,82966,32,17,295,40,17,67619,16692,69895,2340,66855,33,257,261,16384,513]

theorem envBound15978 : H12AffineFastState.Bounded env15978 := by
  intro p hp
  have h : env15978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15977_15978 : H12AffineEnvironment.transform 5 16 env15977 = env15978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15977 == env15978) = true)

theorem identity15978 : scanCanonicalize (H12AffineFastState.compose env15978 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound15978 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15979 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,41,16384,1,262,16400,2341,1025,0,17680,32,17,295,40,17,2341,16692,4097,2340,1057,33,257,261,16384,513]

theorem envBound15979 : H12AffineFastState.Bounded env15979 := by
  intro p hp
  have h : env15979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15978_15979 : H12AffineEnvironment.transform 15 262 env15978 = env15979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env15978 == env15979) = true)

theorem identity15979 : scanCanonicalize (H12AffineFastState.compose env15979 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 6160) := by decide +kernel

theorem selectedBound15979 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env15980 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,41,6160,1,262,6144,2341,1025,0,7424,32,17,295,40,17,2341,6436,4097,2340,1057,33,257,261,6160,513]

theorem envBound15980 : H12AffineFastState.Bounded env15980 := by
  intro p hp
  have h : env15980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15979_15980 : H12AffineEnvironment.transform 13 6160 env15979 = env15980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6160 env15979 == env15980) = true)

theorem identity15980 : scanCanonicalize (H12AffineFastState.compose env15980 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound15980 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env15981 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2357,41,293,1,262,309,2341,1025,0,1077,32,17,295,40,17,2341,17,2356,2340,1057,33,257,261,293,513]

theorem envBound15981 : H12AffineFastState.Bounded env15981 := by
  intro p hp
  have h : env15981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15980_15981 : H12AffineEnvironment.transform 11 2357 env15980 = env15981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env15980 == env15981) = true)

theorem identity15981 : scanCanonicalize (H12AffineFastState.compose env15981 (packedSelected [2,4,9] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound15981 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env15982 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,2357,41,293,1,262,309,2341,52,0,0,32,17,295,40,17,2341,17,2356,2340,20,33,257,261,293,513]

theorem envBound15982 : H12AffineFastState.Bounded env15982 := by
  intro p hp
  have h : env15982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15981_15982 : H12AffineEnvironment.transform 9 53 env15981 = env15982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env15981 == env15982) = true)

theorem identity15982 : scanCanonicalize (H12AffineFastState.compose env15982 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound15982 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env15983 : List Nat := [2,4,8,16,32,16,9,256,512,53,293,16,41,293,1,262,309,0,52,0,0,32,17,295,40,17,0,17,17,1,20,33,257,261,293,513]

theorem envBound15983 : H12AffineFastState.Bounded env15983 := by
  intro p hp
  have h : env15983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15982_15983 : H12AffineEnvironment.transform 10 293 env15982 = env15983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env15982 == env15983) = true)

def env15984 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,65536,16400,10589,1025,8232,91198,4194304,17,374,8193,65,4261890,16741,78207,2420,75102,4194305,257,340,16464,513]

theorem envBound15984 : H12AffineFastState.Bounded env15984 := by
  intro p hp
  have h : env15984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15974_15984 : H12AffineEnvironment.transform 14 8233 env15974 = env15984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env15974 == env15984) = true)

theorem identity15984 : scanCanonicalize (H12AffineFastState.compose env15984 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound15984 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env15985 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,372,65536,16400,2048,1025,373,83299,4194304,17,374,348,65,4261890,16741,69666,2420,66563,4194305,257,340,16464,513]

theorem envBound15985 : H12AffineFastState.Bounded env15985 := by
  intro p hp
  have h : env15985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15984_15985 : H12AffineEnvironment.transform 12 349 env15984 = env15985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env15984 == env15985) = true)

theorem identity15985 : scanCanonicalize (H12AffineFastState.compose env15985 (packedSelected [2,4,6,7,9,11,18,27] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound15985 : packedSelected [2,4,6,7,9,11,18,27] rootPS < 2^1333 := by decide +kernel

def env15986 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,16384,1,65536,16400,2048,1025,0,82966,4194304,17,3,41,65,4261890,16400,69666,2049,66563,4194305,116,33,16464,513]

theorem envBound15986 : H12AffineFastState.Bounded env15986 := by
  intro p hp
  have h : env15986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15985_15986 : H12AffineEnvironment.transform 7 117 env15985 = env15986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env15985 == env15986) = true)

theorem identity15986 : scanCanonicalize (H12AffineFastState.compose env15986 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound15986 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15987 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,16384,1,34,16400,2048,1025,0,17460,4194304,17,3,41,65,4196384,16400,4096,2049,1057,4194305,116,33,16464,513]

theorem envBound15987 : H12AffineFastState.Bounded env15987 := by
  intro p hp
  have h : env15987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15986_15987 : H12AffineEnvironment.transform 15 34 env15986 = env15987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env15986 == env15987) = true)

theorem identity15987 : scanCanonicalize (H12AffineFastState.compose env15987 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15987 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15988 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,16384,1,34,16400,2048,1025,0,17460,4194304,17,3,41,16,4196384,16400,4096,2049,1057,4194305,37,33,16385,513]

theorem envBound15988 : H12AffineFastState.Bounded env15988 := by
  intro p hp
  have h : env15988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15987_15988 : H12AffineEnvironment.transform 5 17 env15987 = env15988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15987 == env15988) = true)

theorem identity15988 : scanCanonicalize (H12AffineFastState.compose env15988 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound15988 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env15989 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5156,1,34,5172,2048,1025,0,4112,4194304,17,3,41,16,4196384,5172,4096,2049,1057,4194305,37,33,5157,513]

theorem envBound15989 : H12AffineFastState.Bounded env15989 := by
  intro p hp
  have h : env15989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15988_15989 : H12AffineEnvironment.transform 13 5156 env15988 = env15989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env15988 == env15989) = true)

theorem identity15989 : scanCanonicalize (H12AffineFastState.compose env15989 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound15989 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15990 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5156,1,34,5172,2048,1025,0,4112,32,17,3,41,16,2048,5172,4096,2049,1057,33,37,33,5157,513]

theorem envBound15990 : H12AffineFastState.Bounded env15990 := by
  intro p hp
  have h : env15990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15989_15990 : H12AffineEnvironment.transform 21 32 env15989 = env15990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env15989 == env15990) = true)

theorem identity15990 : scanCanonicalize (H12AffineFastState.compose env15990 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15990 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15991 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,4096,8,5124,1,2,5140,2048,1025,0,4112,0,17,3,9,16,2048,5140,4096,2049,1025,1,5,1,5125,513]

theorem envBound15991 : H12AffineFastState.Bounded env15991 := by
  intro p hp
  have h : env15991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15990_15991 : H12AffineEnvironment.transform 4 0 env15990 = env15991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15990 == env15991) = true)

theorem identity15991 : scanCanonicalize (H12AffineFastState.compose env15991 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound15991 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15992 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,1029,8,1,1,2,17,2048,1025,0,1045,0,17,3,9,16,2048,17,1029,2049,1025,1,5,1,0,513]

theorem envBound15992 : H12AffineFastState.Bounded env15992 := by
  intro p hp
  have h : env15992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15991_15992 : H12AffineEnvironment.transform 11 1029 env15991 = env15992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env15991 == env15992) = true)

theorem identity15992 : scanCanonicalize (H12AffineFastState.compose env15992 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound15992 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15993 : List Nat := [2,4,8,16,0,17,9,4,17,1024,2048,1029,8,1,1,2,17,2048,1025,0,1045,0,17,3,9,16,2048,17,1029,2049,1025,1,5,1,0,16]

theorem envBound15993 : H12AffineFastState.Bounded env15993 := by
  intro p hp
  have h : env15993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15992_15993 : H12AffineEnvironment.transform 8 17 env15992 = env15993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env15992 == env15993) = true)

theorem identity15993 : scanCanonicalize (H12AffineFastState.compose env15993 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 1029) := by decide +kernel

theorem selectedBound15993 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15994 : List Nat := [2,4,8,16,0,17,9,4,17,1024,1029,1029,8,1,1,2,17,1029,1025,0,1045,0,17,3,9,16,1029,17,1029,1028,1025,1,5,1,0,16]

theorem envBound15994 : H12AffineFastState.Bounded env15994 := by
  intro p hp
  have h : env15994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15993_15994 : H12AffineEnvironment.transform 10 1029 env15993 = env15994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1029 env15993 == env15994) = true)

theorem identity15994 : scanCanonicalize (H12AffineFastState.compose env15994 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound15994 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env15995 : List Nat := [2,4,8,16,0,17,9,4,17,21,16,16,8,1,1,2,17,16,20,0,0,0,17,3,9,16,16,17,16,17,20,1,5,1,0,16]

theorem envBound15995 : H12AffineFastState.Bounded env15995 := by
  intro p hp
  have h : env15995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15994_15995 : H12AffineEnvironment.transform 9 21 env15994 = env15995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env15994 == env15995) = true)

theorem identity15995 : scanCanonicalize (H12AffineFastState.compose env15995 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound15995 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15996 : List Nat := [2,4,8,11,0,10,9,4,10,14,11,11,8,1,1,2,10,11,15,0,0,0,10,3,9,11,11,10,11,10,15,1,5,1,0,11]

theorem envBound15996 : H12AffineFastState.Bounded env15996 := by
  intro p hp
  have h : env15996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15995_15996 : H12AffineEnvironment.transform 3 11 env15995 = env15996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env15995 == env15996) = true)

theorem identity15996 : scanCanonicalize (H12AffineFastState.compose env15996 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound15996 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env15997 : List Nat := [2,4,3,0,0,1,2,4,1,5,0,0,3,1,1,2,1,0,4,0,0,0,1,3,2,0,0,1,0,1,4,1,5,1,0,0]

theorem envBound15997 : H12AffineFastState.Bounded env15997 := by
  intro p hp
  have h : env15997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15996_15997 : H12AffineEnvironment.transform 2 3 env15996 = env15997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env15996 == env15997) = true)

def env15998 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,153,272546,8328,65,4302891,2468911,2119113,295049,371755,6638946,257,2485398,2428210,297981]

theorem envBound15998 : H12AffineFastState.Bounded env15998 := by
  intro p hp
  have h : env15998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15948_15998 : H12AffineEnvironment.transform 16 16401 env15948 = env15998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env15948 == env15998) = true)

theorem identity15998 : scanCanonicalize (H12AffineFastState.compose env15998 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound15998 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env15999 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,153,138,8328,65,4302891,2196487,2119113,43169,99331,6382922,257,2213054,2172186,41941]

theorem envBound15999 : H12AffineFastState.Bounded env15999 := by
  intro p hp
  have h : env15999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15998_15999 : H12AffineEnvironment.transform 17 10280 env15998 = env15999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env15998 == env15999) = true)

def env16000 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,17,2,8192,65,4302891,2196487,2118977,43049,99331,6382922,257,2212918,2172186,41821]

theorem envBound16000 : H12AffineFastState.Bounded env16000 := by
  intro p hp
  have h : env16000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15999_16000 : H12AffineEnvironment.transform 6 8 env15999 = env16000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15999 == env16000) = true)

theorem identity16000 : scanCanonicalize (H12AffineFastState.compose env16000 (packedSelected [0,3,7,8,9,11,12,14,15,17,18,19,20,22,23,24,28,32] rootPS)) = affineNative (2^(20+1) ^^^ 58728) := by decide +kernel

theorem selectedBound16000 : packedSelected [0,3,7,8,9,11,12,14,15,17,18,19,20,22,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env16001 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,58728,4194304,17,2,8192,65,4302891,90479,45097,43049,99331,4292642,257,74078,114802,41821]

theorem envBound16001 : H12AffineFastState.Bounded env16001 := by
  intro p hp
  have h : env16001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16000_16001 : H12AffineEnvironment.transform 20 58728 env16000 = env16001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58728 env16000 == env16001) = true)

theorem identity16001 : scanCanonicalize (H12AffineFastState.compose env16001 (packedSelected [0,3,4,7,8,12,15,16,17,19,20,22,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound16001 : packedSelected [0,3,4,7,8,12,15,16,17,19,20,22,24,28] rootPS < 2^1333 := by decide +kernel

def env16002 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,10280,1025,32769,58728,4194304,17,2,8192,65,4229153,16741,45097,43049,41993,4235304,257,340,57464,41821]

theorem envBound16002 : H12AffineFastState.Bounded env16002 := by
  intro p hp
  have h : env16002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16001_16002 : H12AffineEnvironment.transform 15 8202 env16001 = env16002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env16001 == env16002) = true)

theorem identity16002 : scanCanonicalize (H12AffineFastState.compose env16002 (packedSelected [1,3,5,7,8,10,14,17,19,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 41048) := by decide +kernel

theorem selectedBound16002 : packedSelected [1,3,5,7,8,10,14,17,19,20,27] rootPS < 2^1333 := by decide +kernel

def env16003 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,10280,1025,32769,58728,41048,17,2,8192,65,10361,16741,45097,43049,41993,112,257,340,57464,41821]

theorem envBound16003 : H12AffineFastState.Bounded env16003 := by
  intro p hp
  have h : env16003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16002_16003 : H12AffineEnvironment.transform 21 41048 env16002 = env16003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41048 env16002 == env16003) = true)

theorem identity16003 : scanCanonicalize (H12AffineFastState.compose env16003 (packedSelected [0,1,7,8,9,12,14,15,17,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8312) := by decide +kernel

theorem selectedBound16003 : packedSelected [0,1,7,8,9,12,14,15,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env16004 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8312,8202,16401,10280,1025,8313,17680,32,17,2,8192,65,10361,16741,4177,2129,1137,112,257,340,16384,805]

theorem envBound16004 : H12AffineFastState.Bounded env16004 := by
  intro p hp
  have h : env16004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16003_16004 : H12AffineEnvironment.transform 14 8312 env16003 = env16004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8312 env16003 == env16004) = true)

theorem identity16004 : scanCanonicalize (H12AffineFastState.compose env16004 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound16004 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env16005 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,81,35,16401,2049,1025,80,17680,32,17,2,41,65,2128,16741,4177,2129,1137,112,257,340,16384,805]

theorem envBound16005 : H12AffineFastState.Bounded env16005 := by
  intro p hp
  have h : env16005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16004_16005 : H12AffineEnvironment.transform 12 41 env16004 = env16005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env16004 == env16005) = true)

theorem identity16005 : scanCanonicalize (H12AffineFastState.compose env16005 (packedSelected [0,3,5,6,7,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16005 : packedSelected [0,3,5,6,7,10,12,15] rootPS < 2^1333 := by decide +kernel

def env16006 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,41,16384,0,35,16401,2049,1025,1,17680,32,17,2,41,16,2049,16692,4096,2048,1056,33,257,261,16384,805]

theorem envBound16006 : H12AffineFastState.Bounded env16006 := by
  intro p hp
  have h : env16006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16005_16006 : H12AffineEnvironment.transform 5 17 env16005 = env16006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16005 == env16006) = true)

theorem identity16006 : scanCanonicalize (H12AffineFastState.compose env16006 (packedSelected [0,1,2,3,4,5,6,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound16006 : packedSelected [0,1,2,3,4,5,6,8,10] rootPS < 2^1333 := by decide +kernel

def env16007 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,16384,0,35,16401,2049,1025,1,17461,32,17,2,41,16,2049,16401,4096,2048,1056,33,36,32,16384,512]

theorem envBound16007 : H12AffineFastState.Bounded env16007 := by
  intro p hp
  have h : env16007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16006_16007 : H12AffineEnvironment.transform 7 37 env16006 = env16007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env16006 == env16007) = true)

theorem identity16007 : scanCanonicalize (H12AffineFastState.compose env16007 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16007 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16008 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,4096,9,16384,0,3,16401,2049,1025,1,17429,0,17,2,9,16,2049,16401,4096,2048,1024,1,4,0,16384,512]

theorem envBound16008 : H12AffineFastState.Bounded env16008 := by
  intro p hp
  have h : env16008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16007_16008 : H12AffineEnvironment.transform 4 0 env16007 = env16008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16007 == env16008) = true)

theorem identity16008 : scanCanonicalize (H12AffineFastState.compose env16008 (packedSelected [1,5] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound16008 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env16009 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,4096,9,5125,0,3,5140,2049,1025,1,4112,0,17,2,9,16,2049,5140,4096,2048,1024,1,4,0,5125,512]

theorem envBound16009 : H12AffineFastState.Bounded env16009 := by
  intro p hp
  have h : env16009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16008_16009 : H12AffineEnvironment.transform 13 5125 env16008 = env16009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env16008 == env16009) = true)

def env16010 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,16,9,1045,0,3,1028,2049,1025,1,0,0,17,2,9,16,2049,1028,16,2048,1024,1,4,0,1045,512]

theorem envBound16010 : H12AffineFastState.Bounded env16010 := by
  intro p hp
  have h : env16010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16009_16010 : H12AffineEnvironment.transform 11 16 env16009 = env16010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env16009 == env16010) = true)

theorem identity16010 : scanCanonicalize (H12AffineFastState.compose env16010 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound16010 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16011 : List Nat := [2,4,8,16,0,17,8,5,512,1024,1044,16,9,1045,0,3,1028,1045,1025,1,0,0,17,2,9,16,1045,1028,16,1044,1024,1,4,0,1045,512]

theorem envBound16011 : H12AffineFastState.Bounded env16011 := by
  intro p hp
  have h : env16011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16010_16011 : H12AffineEnvironment.transform 10 1044 env16010 = env16011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env16010 == env16011) = true)

def env16012 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,16,9,1,0,3,16,1,21,1,0,0,17,2,9,16,1,16,16,0,20,1,4,0,1,512]

theorem envBound16012 : H12AffineFastState.Bounded env16012 := by
  intro p hp
  have h : env16012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16011_16012 : H12AffineEnvironment.transform 9 20 env16011 = env16012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env16011 == env16012) = true)

theorem identity16012 : scanCanonicalize (H12AffineFastState.compose env16012 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound16012 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16013 : List Nat := [2,4,8,5,0,4,8,5,512,1,0,5,9,1,0,3,5,1,0,1,0,0,4,2,9,5,1,5,5,0,1,1,4,0,1,512]

theorem envBound16013 : H12AffineFastState.Bounded env16013 := by
  intro p hp
  have h : env16013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16012_16013 : H12AffineEnvironment.transform 3 5 env16012 = env16013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env16012 == env16013) = true)

def leafEnv16013 : List Nat := [2,4,8,5,0,4,8,5,512,1,0,5,9,1,0,3,5,1,0,1,0,0,4,2,0,9,1,5,1,5,5,0,1,1,4,0,5,3,1,512,1,0,0]

def active16013 : List Nat := [0,1,2,8]

def tree16013 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16013 : H12WitnessSearch.Good tree16013 := H12GlobalWitnessIndex.good

theorem leafIdentity16013 : H12AffineFastState.composeSystem env16013 rootObs = leafEnv16013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16013 rootObs == leafEnv16013) = true)

theorem terminalChecked16013 : H12PackedTerminal.terminalCheckFast leafEnv16013 active16013 tree16013 = true := by decide +kernel

def env16014 : List Nat := [2,4,8,16,0,17,8,5,512,21,1,16,9,0,0,3,17,0,20,1,0,0,17,2,9,16,0,17,16,1,21,1,4,0,0,512]

theorem envBound16014 : H12AffineFastState.Bounded env16014 := by
  intro p hp
  have h : env16014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16011_16014 : H12AffineEnvironment.transform 9 21 env16011 = env16014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env16011 == env16014) = true)

theorem identity16014 : scanCanonicalize (H12AffineFastState.compose env16014 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound16014 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16015 : List Nat := [2,4,8,16,0,17,8,5,31,21,1,16,9,0,0,3,17,0,20,1,0,0,17,2,9,16,0,17,16,1,21,1,4,0,0,31]

theorem envBound16015 : H12AffineFastState.Bounded env16015 := by
  intro p hp
  have h : env16015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16014_16015 : H12AffineEnvironment.transform 8 31 env16014 = env16015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env16014 == env16015) = true)

def leafEnv16015 : List Nat := [2,4,8,16,0,17,8,5,31,21,1,16,9,0,0,3,17,0,20,1,0,0,17,2,20,9,1,16,0,17,16,1,21,1,4,0,5,3,0,31,1,0,0]

def active16015 : List Nat := [0,1,2,3]

def tree16015 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16015 : H12WitnessSearch.Good tree16015 := H12GlobalWitnessIndex.good

theorem leafIdentity16015 : H12AffineFastState.composeSystem env16015 rootObs = leafEnv16015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16015 rootObs == leafEnv16015) = true)

theorem terminalChecked16015 : H12PackedTerminal.terminalCheckFast leafEnv16015 active16015 tree16015 = true := by decide +kernel

def env16016 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,17,9,1044,0,3,1029,2049,1025,1,1,0,17,2,9,16,2049,1029,17,2048,1024,1,4,0,1044,512]

theorem envBound16016 : H12AffineFastState.Bounded env16016 := by
  intro p hp
  have h : env16016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16009_16016 : H12AffineEnvironment.transform 11 17 env16009 = env16016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env16009 == env16016) = true)

theorem identity16016 : scanCanonicalize (H12AffineFastState.compose env16016 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound16016 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16017 : List Nat := [2,4,8,16,0,17,8,5,512,1024,0,17,9,1044,0,3,1029,1,1025,1,1,0,17,2,9,16,1,1029,17,0,1024,1,4,0,1044,512]

theorem envBound16017 : H12AffineFastState.Bounded env16017 := by
  intro p hp
  have h : env16017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16016_16017 : H12AffineEnvironment.transform 10 0 env16016 = env16017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env16016 == env16017) = true)

def env16018 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,17,9,0,0,3,17,1,21,1,1,0,17,2,9,16,1,17,17,0,20,1,4,0,0,512]

theorem envBound16018 : H12AffineFastState.Bounded env16018 := by
  intro p hp
  have h : env16018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16017_16018 : H12AffineEnvironment.transform 9 20 env16017 = env16018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env16017 == env16018) = true)

theorem identity16018 : scanCanonicalize (H12AffineFastState.compose env16018 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound16018 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16019 : List Nat := [2,4,8,5,0,4,8,5,512,1,0,4,9,0,0,3,4,1,0,1,1,0,4,2,9,5,1,4,4,0,1,1,4,0,0,512]

theorem envBound16019 : H12AffineFastState.Bounded env16019 := by
  intro p hp
  have h : env16019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16018_16019 : H12AffineEnvironment.transform 3 5 env16018 = env16019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env16018 == env16019) = true)

def leafEnv16019 : List Nat := [2,4,8,5,0,4,8,5,512,1,0,4,9,0,0,3,4,1,0,1,1,0,4,2,0,9,1,5,1,4,4,0,1,1,4,0,5,3,0,512,1,1,0]

def active16019 : List Nat := [0,1,2,8]

def tree16019 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16019 : H12WitnessSearch.Good tree16019 := H12GlobalWitnessIndex.good

theorem leafIdentity16019 : H12AffineFastState.composeSystem env16019 rootObs = leafEnv16019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16019 rootObs == leafEnv16019) = true)

theorem terminalChecked16019 : H12PackedTerminal.terminalCheckFast leafEnv16019 active16019 tree16019 = true := by decide +kernel

def env16020 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,17,9,1,0,3,16,1,20,1,1,0,17,2,9,16,1,16,17,0,21,1,4,0,1,512]

theorem envBound16020 : H12AffineFastState.Bounded env16020 := by
  intro p hp
  have h : env16020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16017_16020 : H12AffineEnvironment.transform 9 21 env16017 = env16020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env16017 == env16020) = true)

theorem identity16020 : scanCanonicalize (H12AffineFastState.compose env16020 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound16020 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16021 : List Nat := [2,4,8,16,0,17,8,5,30,21,0,17,9,1,0,3,16,1,20,1,1,0,17,2,9,16,1,16,17,0,21,1,4,0,1,30]

theorem envBound16021 : H12AffineFastState.Bounded env16021 := by
  intro p hp
  have h : env16021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16020_16021 : H12AffineEnvironment.transform 8 30 env16020 = env16021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env16020 == env16021) = true)

def leafEnv16021 : List Nat := [2,4,8,16,0,17,8,5,30,21,0,17,9,1,0,3,16,1,20,1,1,0,17,2,20,9,1,16,1,16,17,0,21,1,4,0,5,3,1,30,1,1,0]

def active16021 : List Nat := [0,1,2,3]

def tree16021 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16021 : H12WitnessSearch.Good tree16021 := H12GlobalWitnessIndex.good

theorem leafIdentity16021 : H12AffineFastState.composeSystem env16021 rootObs = leafEnv16021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16021 rootObs == leafEnv16021) = true)

theorem terminalChecked16021 : H12PackedTerminal.terminalCheckFast leafEnv16021 active16021 tree16021 = true := by decide +kernel

def env16022 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,16,3,8193,65,4302891,2196487,2118976,43048,99331,6382922,257,2212919,2172186,41820]

theorem envBound16022 : H12AffineFastState.Bounded env16022 := by
  intro p hp
  have h : env16022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15999_16022 : H12AffineEnvironment.transform 6 9 env15999 = env16022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15999 == env16022) = true)

theorem identity16022 : scanCanonicalize (H12AffineFastState.compose env16022 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound16022 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env16023 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10280,1025,8540,2097152,4194304,16,3,8193,65,4262262,2172250,2118976,2421,75102,6382922,257,2188650,2172186,513]

theorem envBound16023 : H12AffineFastState.Bounded env16023 := by
  intro p hp
  have h : env16023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16022_16023 : H12AffineEnvironment.transform 14 8541 env16022 = env16023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env16022 == env16023) = true)

theorem identity16023 : scanCanonicalize (H12AffineFastState.compose env16023 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound16023 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env16024 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16401,10280,1025,8540,2097152,4194304,16,3,8193,65,4204925,2098513,2118976,2421,1365,6309185,257,2114913,2098449,513]

theorem envBound16024 : H12AffineFastState.Bounded env16024 := by
  intro p hp
  have h : env16024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16023_16024 : H12AffineEnvironment.transform 15 8203 env16023 = env16024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env16023 == env16024) = true)

theorem identity16024 : scanCanonicalize (H12AffineFastState.compose env16024 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound16024 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env16025 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16401,10280,1025,8540,2097152,33,16,3,8193,65,10588,2098513,2118976,2421,1365,2114912,257,2114913,2098449,513]

theorem envBound16025 : H12AffineFastState.Bounded env16025 := by
  intro p hp
  have h : env16025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16024_16025 : H12AffineEnvironment.transform 21 33 env16024 = env16025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env16024 == env16025) = true)

theorem identity16025 : scanCanonicalize (H12AffineFastState.compose env16025 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 17681) := by decide +kernel

theorem selectedBound16025 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16026 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16401,10280,1025,8540,17681,33,16,3,8193,65,10588,16448,4177,2421,1365,113,257,112,16384,513]

theorem envBound16026 : H12AffineFastState.Bounded env16026 := by
  intro p hp
  have h : env16026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16025_16026 : H12AffineEnvironment.transform 20 17681 env16025 = env16026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17681 env16025 == env16026) = true)

theorem identity16026 : scanCanonicalize (H12AffineFastState.compose env16026 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13357) := by decide +kernel

theorem selectedBound16026 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env16027 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13357,8541,8203,13372,10280,1025,8540,12604,33,16,3,8193,65,10588,13421,4177,2421,1365,113,257,112,13357,513]

theorem envBound16027 : H12AffineFastState.Bounded env16027 := by
  intro p hp
  have h : env16027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16026_16027 : H12AffineEnvironment.transform 13 13357 env16026 = env16027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13357 env16026 == env16027) = true)

theorem identity16027 : scanCanonicalize (H12AffineFastState.compose env16027 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound16027 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env16028 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5489,1,343,5472,2420,1025,0,4192,33,16,3,349,65,2048,5425,4177,2421,1365,113,257,112,5489,513]

theorem envBound16028 : H12AffineFastState.Bounded env16028 := by
  intro p hp
  have h : env16028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16027_16028 : H12AffineEnvironment.transform 12 348 env16027 = env16028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env16027 == env16028) = true)

theorem identity16028 : scanCanonicalize (H12AffineFastState.compose env16028 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 3621) := by decide +kernel

theorem selectedBound16028 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env16029 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3621,348,2900,1,343,2885,2420,1025,0,3653,33,16,3,349,65,2048,2836,3700,2421,1365,113,257,112,2900,513]

theorem envBound16029 : H12AffineFastState.Bounded env16029 := by
  intro p hp
  have h : env16029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16028_16029 : H12AffineEnvironment.transform 11 3621 env16028 = env16029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3621 env16028 == env16029) = true)

theorem identity16029 : scanCanonicalize (H12AffineFastState.compose env16029 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound16029 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env16030 : List Nat := [2,4,8,16,32,64,9,256,512,1024,277,1840,348,577,1,343,592,97,1025,0,1872,33,16,3,349,65,277,513,1889,96,1365,113,257,112,577,513]

theorem envBound16030 : H12AffineFastState.Bounded env16030 := by
  intro p hp
  have h : env16030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16029_16030 : H12AffineEnvironment.transform 10 277 env16029 = env16030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env16029 == env16030) = true)

theorem identity16030 : scanCanonicalize (H12AffineFastState.compose env16030 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound16030 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env16031 : List Nat := [2,4,8,16,32,64,9,256,512,564,277,260,348,577,1,343,592,97,565,0,356,33,16,3,349,65,277,513,341,96,865,113,257,112,577,513]

theorem envBound16031 : H12AffineFastState.Bounded env16031 := by
  intro p hp
  have h : env16031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16030_16031 : H12AffineEnvironment.transform 9 564 env16030 = env16031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env16030 == env16031) = true)

theorem identity16031 : scanCanonicalize (H12AffineFastState.compose env16031 (packedSelected [3,8] rootPS)) = affineNative (2^(8+1) ^^^ 340) := by decide +kernel

theorem selectedBound16031 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env16032 : List Nat := [2,4,8,16,32,64,9,256,340,352,277,260,348,277,1,343,260,97,353,0,356,33,16,3,349,65,277,341,341,96,53,113,257,112,277,341]

theorem envBound16032 : H12AffineFastState.Bounded env16032 := by
  intro p hp
  have h : env16032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16031_16032 : H12AffineEnvironment.transform 8 340 env16031 = env16032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env16031 == env16032) = true)

theorem identity16032 : scanCanonicalize (H12AffineFastState.compose env16032 (packedSelected [0,1,2] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound16032 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env16033 : List Nat := [2,4,8,16,32,64,9,14,90,110,27,10,82,27,1,89,10,97,111,0,106,33,16,3,83,65,27,91,91,96,53,113,15,112,27,91]

theorem envBound16033 : H12AffineFastState.Bounded env16033 := by
  intro p hp
  have h : env16033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16032_16033 : H12AffineEnvironment.transform 7 14 env16032 = env16033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env16032 == env16033) = true)

def env16034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,147593,272546,8328,65,4302890,2468911,2233817,295048,519227,6638946,257,2600070,2575650,445421]

theorem envBound16034 : H12AffineFastState.Bounded env16034 := by
  intro p hp
  have h : env16034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15947_16034 : H12AffineEnvironment.transform 22 147593 env15947 = env16034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147593 env15947 == env16034) = true)

def env16035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,153,272546,8328,65,4302890,2468911,2119113,295048,371755,6638946,257,2485398,2428210,297981]

theorem envBound16035 : H12AffineFastState.Bounded env16035 := by
  intro p hp
  have h : env16035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16034_16035 : H12AffineEnvironment.transform 16 16400 env16034 = env16035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env16034 == env16035) = true)

theorem identity16035 : scanCanonicalize (H12AffineFastState.compose env16035 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound16035 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env16036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,16400,262144,1025,8661,2097152,4194304,153,272546,8328,65,4262398,2428411,2119113,270684,331263,6638946,257,2444610,2428210,272937]

theorem envBound16036 : H12AffineFastState.Bounded env16036 := by
  intro p hp
  have h : env16036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16035_16036 : H12AffineEnvironment.transform 14 8660 env16035 = env16036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env16035 == env16036) = true)

def env16037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,16400,10400,1025,8661,2097152,4194304,153,2,8328,65,4262398,2172251,2119113,2556,75103,6383042,257,2188770,2172306,649]

theorem envBound16037 : H12AffineFastState.Bounded env16037 := by
  intro p hp
  have h : env16037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16036_16037 : H12AffineEnvironment.transform 17 10400 env16036 = env16037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env16036 == env16037) = true)

theorem identity16037 : scanCanonicalize (H12AffineFastState.compose env16037 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound16037 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env16038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8322,16400,10400,1025,8661,2097152,4194304,153,2,8328,65,4204924,2098649,2119113,2556,1501,6309184,257,2114912,2098448,649]

theorem envBound16038 : H12AffineFastState.Bounded env16038 := by
  intro p hp
  have h : env16038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16037_16038 : H12AffineEnvironment.transform 15 8322 env16037 = env16038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env16037 == env16038) = true)

theorem identity16038 : scanCanonicalize (H12AffineFastState.compose env16038 (packedSelected [1,4,5,7,9,10,12,15,16,17,20,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 8281) := by decide +kernel

theorem selectedBound16038 : packedSelected [1,4,5,7,9,10,12,15,16,17,20,24,27,28] rootPS < 2^1333 := by decide +kernel

def env16039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8322,16400,10400,1025,8661,2097152,8281,153,2,8328,65,2341,2098649,2119113,2556,1501,2123033,257,2114912,2098448,649]

theorem envBound16039 : H12AffineFastState.Bounded env16039 := by
  intro p hp
  have h : env16039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16038_16039 : H12AffineEnvironment.transform 21 8281 env16038 = env16039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8281 env16038 == env16039) = true)

theorem identity16039 : scanCanonicalize (H12AffineFastState.compose env16039 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 241) := by decide +kernel

theorem selectedBound16039 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env16040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,16384,293,115,16400,2129,1025,292,2097152,168,153,2,121,65,2341,2098649,2119113,2556,1501,2115048,257,2114912,2098448,649]

theorem envBound16040 : H12AffineFastState.Bounded env16040 := by
  intro p hp
  have h : env16040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16039_16040 : H12AffineEnvironment.transform 12 241 env16039 = env16040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env16039 == env16040) = true)

theorem identity16040 : scanCanonicalize (H12AffineFastState.compose env16040 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound16040 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env16041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,5512,293,115,5528,2129,1025,292,2097152,168,153,2,121,65,2341,2098649,2097217,2556,1501,2101344,257,2101480,2098448,649]

theorem envBound16041 : H12AffineFastState.Bounded env16041 := by
  intro p hp
  have h : env16041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16040_16041 : H12AffineEnvironment.transform 13 5512 env16040 = env16041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env16040 == env16041) = true)

theorem identity16041 : scanCanonicalize (H12AffineFastState.compose env16041 (packedSelected [4,5,8,9,14] rootPS)) = affineNative (2^(20+1) ^^^ 5457) := by decide +kernel

theorem selectedBound16041 : packedSelected [4,5,8,9,14] rootPS < 2^1333 := by decide +kernel

def env16042 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,5512,293,115,5528,2129,1025,292,5457,168,153,2,121,65,2341,4232,5392,2556,1501,1329,257,1465,4161,649]

theorem envBound16042 : H12AffineFastState.Bounded env16042 := by
  intro p hp
  have h : env16042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16041_16042 : H12AffineEnvironment.transform 20 5457 env16041 = env16042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5457 env16041 == env16042) = true)

theorem identity16042 : scanCanonicalize (H12AffineFastState.compose env16042 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound16042 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env16043 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,241,4249,293,115,4233,2129,272,292,4160,168,153,2,121,65,2341,4232,4097,2556,204,32,257,168,4161,649]

theorem envBound16043 : H12AffineFastState.Bounded env16043 := by
  intro p hp
  have h : env16043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16042_16043 : H12AffineEnvironment.transform 9 273 env16042 = env16043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env16042 == env16043) = true)

theorem identity16043 : scanCanonicalize (H12AffineFastState.compose env16043 (packedSelected [2,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound16043 : packedSelected [2,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env16044 : List Nat := [2,4,8,16,32,64,128,252,512,237,2048,4096,241,4249,217,115,4233,2129,236,216,4160,168,153,2,121,65,2265,4232,4097,2048,204,32,253,168,4161,649]

theorem envBound16044 : H12AffineFastState.Bounded env16044 := by
  intro p hp
  have h : env16044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16043_16044 : H12AffineEnvironment.transform 7 252 env16043 = env16044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env16043 == env16044) = true)

theorem identity16044 : scanCanonicalize (H12AffineFastState.compose env16044 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound16044 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env16045 : List Nat := [2,4,8,16,32,64,128,252,512,237,2048,2112,241,2265,217,115,2249,2129,236,216,2048,168,153,2,121,65,2265,2248,2113,2048,204,32,253,168,2049,649]

theorem envBound16045 : H12AffineFastState.Bounded env16045 := by
  intro p hp
  have h : env16045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16044_16045 : H12AffineEnvironment.transform 11 2112 env16044 = env16045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env16044 == env16045) = true)

theorem identity16045 : scanCanonicalize (H12AffineFastState.compose env16045 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound16045 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env16046 : List Nat := [2,4,8,16,32,64,128,252,512,237,80,16,241,137,217,115,153,1,236,216,80,168,153,2,121,65,137,152,17,80,204,32,253,168,81,649]

theorem envBound16046 : H12AffineFastState.Bounded env16046 := by
  intro p hp
  have h : env16046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16045_16046 : H12AffineEnvironment.transform 10 80 env16045 = env16046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env16045 == env16046) = true)

theorem identity16046 : scanCanonicalize (H12AffineFastState.compose env16046 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound16046 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16047 : List Nat := [2,4,8,16,32,64,89,37,512,52,80,16,40,80,0,115,64,1,53,1,80,113,64,2,121,65,80,65,17,80,21,32,36,113,81,592]

theorem envBound16047 : H12AffineFastState.Bounded env16047 := by
  intro p hp
  have h : env16047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16046_16047 : H12AffineEnvironment.transform 6 89 env16046 = env16047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env16046 == env16047) = true)

def env16048 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,16400,10401,1025,8661,2097152,4194304,153,3,8328,65,4262398,2172250,2119113,2557,75102,6383043,257,2188771,2172307,648]

theorem envBound16048 : H12AffineFastState.Bounded env16048 := by
  intro p hp
  have h : env16048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16036_16048 : H12AffineEnvironment.transform 17 10401 env16036 = env16048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env16036 == env16048) = true)

theorem identity16048 : scanCanonicalize (H12AffineFastState.compose env16048 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound16048 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env16049 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10280,1025,8540,2097152,4194304,16,3,8193,65,4262263,2172250,2118976,2420,75102,6382922,257,2188650,2172186,513]

theorem envBound16049 : H12AffineFastState.Bounded env16049 := by
  intro p hp
  have h : env16049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16048_16049 : H12AffineEnvironment.transform 6 9 env16048 = env16049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16048 == env16049) = true)

theorem identity16049 : scanCanonicalize (H12AffineFastState.compose env16049 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound16049 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env16050 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,16400,10280,1025,8540,2097152,4194304,16,3,8193,65,4204925,2098512,2118976,2420,1364,6309184,257,2114912,2098448,513]

theorem envBound16050 : H12AffineFastState.Bounded env16050 := by
  intro p hp
  have h : env16050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16049_16050 : H12AffineEnvironment.transform 15 8202 env16049 = env16050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env16049 == env16050) = true)

theorem identity16050 : scanCanonicalize (H12AffineFastState.compose env16050 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound16050 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env16051 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,16400,10280,1025,8540,2097152,32,16,3,8193,65,10589,2098512,2118976,2420,1364,2114912,257,2114912,2098448,513]

theorem envBound16051 : H12AffineFastState.Bounded env16051 := by
  intro p hp
  have h : env16051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16050_16051 : H12AffineEnvironment.transform 21 32 env16050 = env16051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env16050 == env16051) = true)

theorem identity16051 : scanCanonicalize (H12AffineFastState.compose env16051 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(20+1) ^^^ 25881) := by decide +kernel

theorem selectedBound16051 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env16052 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,16400,10280,1025,8540,25881,32,16,3,8193,65,10589,24649,12377,2420,1364,8313,257,8313,24585,513]

theorem envBound16052 : H12AffineFastState.Bounded env16052 := by
  intro p hp
  have h : env16052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16051_16052 : H12AffineEnvironment.transform 20 25881 env16051 = env16052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25881 env16051 == env16052) = true)

theorem identity16052 : scanCanonicalize (H12AffineFastState.compose env16052 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound16052 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env16053 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1,342,16400,2420,1025,0,17477,32,16,3,349,65,2049,16661,4357,2420,1364,293,257,293,16725,513]

theorem envBound16053 : H12AffineFastState.Bounded env16053 := by
  intro p hp
  have h : env16053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16052_16053 : H12AffineEnvironment.transform 12 348 env16052 = env16053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env16052 == env16053) = true)

theorem identity16053 : scanCanonicalize (H12AffineFastState.compose env16053 (packedSelected [2,14] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound16053 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env16054 : List Nat := [2,4,8,16,32,64,9,4,512,1024,2048,4096,88,16384,1,82,16400,2160,1025,0,17477,32,16,3,89,65,2049,16401,4097,2160,1104,33,5,33,16465,513]

theorem envBound16054 : H12AffineFastState.Bounded env16054 := by
  intro p hp
  have h : env16054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16053_16054 : H12AffineEnvironment.transform 7 4 env16053 = env16054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env16053 == env16054) = true)

theorem identity16054 : scanCanonicalize (H12AffineFastState.compose env16054 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 576) := by decide +kernel

theorem selectedBound16054 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16055 : List Nat := [2,4,8,16,32,64,9,4,512,1024,2048,576,88,16384,1,82,16400,2160,1025,0,17477,32,16,3,89,65,2049,16401,577,2160,1104,33,5,33,16465,513]

theorem envBound16055 : H12AffineFastState.Bounded env16055 := by
  intro p hp
  have h : env16055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16054_16055 : H12AffineEnvironment.transform 11 576 env16054 = env16055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 576 env16054 == env16055) = true)

theorem identity16055 : scanCanonicalize (H12AffineFastState.compose env16055 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 2112) := by decide +kernel

theorem selectedBound16055 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env16056 : List Nat := [2,4,8,16,32,64,9,4,512,1024,2048,576,88,2112,1,82,2128,2160,1025,0,3077,32,16,3,89,65,2049,2129,577,2160,1104,33,5,33,2065,513]

theorem envBound16056 : H12AffineFastState.Bounded env16056 := by
  intro p hp
  have h : env16056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16055_16056 : H12AffineEnvironment.transform 13 2112 env16055 = env16056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2112 env16055 == env16056) = true)

def env16057 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,152,272546,8328,65,4302890,2468911,2119112,295048,371754,6638946,257,2485399,2428211,297980]

theorem envBound16057 : H12AffineFastState.Bounded env16057 := by
  intro p hp
  have h : env16057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16034_16057 : H12AffineEnvironment.transform 16 16401 env16034 = env16057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env16034 == env16057) = true)

theorem identity16057 : scanCanonicalize (H12AffineFastState.compose env16057 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35325) := by decide +kernel

theorem selectedBound16057 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env16058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35325,1025,32769,2097152,4194304,152,41311,8328,65,4302890,2172370,2119112,2421,75223,6407327,257,2188650,2196686,513]

theorem envBound16058 : H12AffineFastState.Bounded env16058 := by
  intro p hp
  have h : env16058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16057_16058 : H12AffineEnvironment.transform 17 35325 env16057 = env16058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35325 env16057 == env16058) = true)

def env16059 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,4194304,16,41311,8192,65,4302890,2172250,2118976,2421,75103,6407191,257,2188650,2196550,513]

theorem envBound16059 : H12AffineFastState.Bounded env16059 := by
  intro p hp
  have h : env16059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16058_16059 : H12AffineEnvironment.transform 6 8 env16058 = env16059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16058 == env16059) = true)

theorem identity16059 : scanCanonicalize (H12AffineFastState.compose env16059 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound16059 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env16060 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,35189,1025,32769,2097152,4194304,16,41311,8192,65,4229153,2098513,2118976,2421,1364,6349852,257,2114913,2139213,513]

theorem envBound16060 : H12AffineFastState.Bounded env16060 := by
  intro p hp
  have h : env16060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16059_16060 : H12AffineEnvironment.transform 15 8203 env16059 = env16060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env16059 == env16060) = true)

theorem identity16060 : scanCanonicalize (H12AffineFastState.compose env16060 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 41340) := by decide +kernel

theorem selectedBound16060 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16061 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,35189,1025,32769,2097152,41340,16,41311,8192,65,10589,2098513,2118976,2421,1364,2114912,257,2114913,2139213,513]

theorem envBound16061 : H12AffineFastState.Bounded env16061 := by
  intro p hp
  have h : env16061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16060_16061 : H12AffineEnvironment.transform 21 41340 env16060 = env16061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41340 env16060 == env16061) = true)

theorem identity16061 : scanCanonicalize (H12AffineFastState.compose env16061 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(20+1) ^^^ 38145) := by decide +kernel

theorem selectedBound16061 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env16062 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,35189,1025,32769,38145,41340,16,41311,8192,65,10589,36944,49217,2421,1364,53345,257,53344,12620,513]

theorem envBound16062 : H12AffineFastState.Bounded env16062 := by
  intro p hp
  have h : env16062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16061_16062 : H12AffineEnvironment.transform 20 38145 env16061 = env16062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 38145 env16061 == env16062) = true)

theorem identity16062 : scanCanonicalize (H12AffineFastState.compose env16062 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29004) := by decide +kernel

theorem selectedBound16062 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env16063 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29004,8203,16401,30777,1025,29005,25677,20528,16,20499,8192,65,10589,24860,12557,2421,1364,8493,257,8492,12620,513]

theorem envBound16063 : H12AffineFastState.Bounded env16063 := by
  intro p hp
  have h : env16063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16062_16063 : H12AffineEnvironment.transform 14 29004 env16062 = env16063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29004 env16062 == env16063) = true)

theorem identity16063 : scanCanonicalize (H12AffineFastState.compose env16063 (packedSelected [0,1,2,3,4,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 3408) := by decide +kernel

theorem selectedBound16063 : packedSelected [0,1,2,3,4,10,11,15] rootPS < 2^1333 := by decide +kernel

def env16064 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3408,8192,16384,27676,8203,16401,25961,1025,27677,25677,19808,16,19779,8192,65,10589,24860,11357,2421,1364,8493,257,8492,11292,513]

theorem envBound16064 : H12AffineFastState.Bounded env16064 := by
  intro p hp
  have h : env16064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16063_16064 : H12AffineEnvironment.transform 11 3408 env16063 = env16064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3408 env16063 == env16064) = true)

theorem identity16064 : scanCanonicalize (H12AffineFastState.compose env16064 (packedSelected [3,4,7,8,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 11625) := by decide +kernel

theorem selectedBound16064 : packedSelected [3,4,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env16065 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3408,8192,11625,373,8203,11640,2048,1025,372,2340,8201,16,8234,8192,65,10589,3189,11357,2421,1364,8493,257,8492,11292,513]

theorem envBound16065 : H12AffineFastState.Bounded env16065 := by
  intro p hp
  have h : env16065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16064_16065 : H12AffineEnvironment.transform 13 11625 env16064 = env16065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11625 env16064 == env16065) = true)

theorem identity16065 : scanCanonicalize (H12AffineFastState.compose env16065 (packedSelected [1,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound16065 : packedSelected [1,7,8,9] rootPS < 2^1333 := by decide +kernel

def env16066 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,1140,8192,9293,373,8203,9308,292,1025,372,0,8201,16,8234,8192,65,8313,1361,9593,81,1364,8493,257,8492,9528,513]

theorem envBound16066 : H12AffineFastState.Bounded env16066 := by
  intro p hp
  have h : env16066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16065_16066 : H12AffineEnvironment.transform 10 292 env16065 = env16066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env16065 == env16066) = true)

theorem identity16066 : scanCanonicalize (H12AffineFastState.compose env16066 (packedSelected [4,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound16066 : packedSelected [4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env16067 : List Nat := [2,4,8,16,32,64,8,256,512,320,292,308,8192,8461,373,8203,8476,292,321,372,0,8201,16,8234,8192,65,8313,17,8249,81,20,8493,257,8492,8312,513]

theorem envBound16067 : H12AffineFastState.Bounded env16067 := by
  intro p hp
  have h : env16067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16066_16067 : H12AffineEnvironment.transform 9 320 env16066 = env16067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env16066 == env16067) = true)

theorem identity16067 : scanCanonicalize (H12AffineFastState.compose env16067 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound16067 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16068 : List Nat := [2,4,8,16,32,64,8,256,512,320,292,308,348,81,373,343,64,292,321,372,0,341,16,374,348,65,293,17,357,81,20,113,257,112,292,513]

theorem envBound16068 : H12AffineFastState.Bounded env16068 := by
  intro p hp
  have h : env16068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16067_16068 : H12AffineEnvironment.transform 12 348 env16067 = env16068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env16067 == env16068) = true)

def env16069 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,4194304,17,41311,8193,65,4302890,2172251,2118977,2421,75102,6407190,257,2188650,2196551,513]

theorem envBound16069 : H12AffineFastState.Bounded env16069 := by
  intro p hp
  have h : env16069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16058_16069 : H12AffineEnvironment.transform 6 9 env16058 = env16069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16058 == env16069) = true)

theorem identity16069 : scanCanonicalize (H12AffineFastState.compose env16069 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound16069 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env16070 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,115735,4194304,17,41311,8193,65,4302890,57676,102742,2421,75102,4194305,257,41341,16464,513]

theorem envBound16070 : H12AffineFastState.Bounded env16070 := by
  intro p hp
  have h : env16070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16069_16070 : H12AffineEnvironment.transform 20 115735 env16069 = env16070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env16069 == env16070) = true)

theorem identity16070 : scanCanonicalize (H12AffineFastState.compose env16070 (packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound16070 : packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS < 2^1333 := by decide +kernel

def env16071 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10280,1025,8541,91467,4194304,17,3,8193,65,4262262,16400,77834,2421,75102,4194305,257,33,16464,513]

theorem envBound16071 : H12AffineFastState.Bounded env16071 := by
  intro p hp
  have h : env16071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16070_16071 : H12AffineEnvironment.transform 14 8540 env16070 = env16071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env16070 == env16071) = true)

theorem identity16071 : scanCanonicalize (H12AffineFastState.compose env16071 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound16071 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env16072 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10280,1025,8541,91467,32,17,3,8193,65,67926,16400,77834,2421,75102,33,257,33,16464,513]

theorem envBound16072 : H12AffineFastState.Bounded env16072 := by
  intro p hp
  have h : env16072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16071_16072 : H12AffineEnvironment.transform 21 32 env16071 = env16072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env16071 == env16072) = true)

def env16073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507600,9356289,25265168,23160257,525568,27902125,27337993,25733063]

theorem envBound16073 : H12AffineFastState.Bounded env16073 := by
  intro p hp
  have h : env16073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15724_16073 : H12AffineEnvironment.transform 26 30393345 env15724 = env16073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env15724 == env16073) = true)

def env16074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830977,25265168,23160257,256,27378861,27337993,25207751]

theorem envBound16074 : H12AffineFastState.Bounded env16074 := by
  intro p hp
  have h : env16074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16073_16074 : H12AffineEnvironment.transform 18 1024 env16073 = env16074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env16073 == env16074) = true)

theorem identity16074 : scanCanonicalize (H12AffineFastState.compose env16074 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10923490) := by decide +kernel

theorem selectedBound16074 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env16075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10923490,8328,65,6385123,8857966,10507600,8830977,2566642,13092899,256,485711,493803,2493989]

theorem envBound16075 : H12AffineFastState.Bounded env16075 := by
  intro p hp
  have h : env16075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16074_16075 : H12AffineEnvironment.transform 23 10923490 env16074 = env16075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10923490 env16074 == env16075) = true)

def env16076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,452768,2114882,8328,65,6385123,115150,2538992,10401,2566642,4268163,256,485711,493803,2493989]

theorem envBound16076 : H12AffineFastState.Bounded env16076 := by
  intro p hp
  have h : env16076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16075_16076 : H12AffineEnvironment.transform 22 452768 env16075 = env16076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452768 env16075 == env16076) = true)

def env16077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,4194304,452768,441778,8328,65,4691219,115150,17664,10401,119042,4268163,256,485711,493803,63189]

theorem envBound16077 : H12AffineFastState.Bounded env16077 := by
  intro p hp
  have h : env16077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16076_16077 : H12AffineEnvironment.transform 20 456944 env16076 = env16077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456944 env16076 == env16077) = true)

def env16078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,272512,452768,441778,8328,65,245139,115150,17664,10401,119042,329731,256,485711,493803,63189]

theorem envBound16078 : H12AffineFastState.Bounded env16078 := by
  intro p hp
  have h : env16078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16077_16078 : H12AffineEnvironment.transform 21 272512 env16077 = env16078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env16077 == env16078) = true)

theorem identity16078 : scanCanonicalize (H12AffineFastState.compose env16078 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212079) := by decide +kernel

theorem selectedBound16078 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212079,1024,32769,115871,201967,120015,98781,8328,65,245139,115150,17664,10401,119042,144492,256,21792,46212,63189]

theorem envBound16079 : H12AffineFastState.Bounded env16079 := by
  intro p hp
  have h : env16079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16078_16079 : H12AffineEnvironment.transform 17 212079 env16078 = env16079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212079 env16078 == env16079) = true)

def env16080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,130175,1024,32769,115871,120063,120015,98781,8328,65,97667,115150,17664,10401,119042,62588,256,21792,46212,63189]

theorem envBound16080 : H12AffineFastState.Bounded env16080 := by
  intro p hp
  have h : env16080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16079_16080 : H12AffineEnvironment.transform 16 49168 env16079 = env16080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env16079 == env16080) = true)

theorem identity16080 : scanCanonicalize (H12AffineFastState.compose env16080 (packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound16080 : packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS < 2^1333 := by decide +kernel

def env16081 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33031,49168,32120,1024,32769,17816,22008,21960,218,8328,65,64644,16585,17664,10401,20485,62588,256,21792,46212,63189]

theorem envBound16081 : H12AffineFastState.Bounded env16081 := by
  intro p hp
  have h : env16081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16080_16081 : H12AffineEnvironment.transform 15 33031 env16080 = env16081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env16080 == env16081) = true)

theorem identity16081 : scanCanonicalize (H12AffineFastState.compose env16081 (packedSelected [0,1,4,5,7,8,10,11,16,17,19,20,22,24,26,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound16081 : packedSelected [0,1,4,5,7,8,10,11,16,17,19,20,22,24,26,31,32] rootPS < 2^1333 := by decide +kernel

def env16082 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,21511,5392,32120,1024,21761,17816,22008,21960,218,8328,65,10628,16585,17664,10401,20485,8572,256,21792,24964,9173]

theorem envBound16082 : H12AffineFastState.Bounded env16082 := by
  intro p hp
  have h : env16082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16081_16082 : H12AffineEnvironment.transform 14 21760 env16081 = env16082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env16081 == env16082) = true)

theorem identity16082 : scanCanonicalize (H12AffineFastState.compose env16082 (packedSelected [0,3,4,7,10,18,19,22,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound16082 : packedSelected [0,3,4,7,10,18,19,22,23,24] rootPS < 2^1333 := by decide +kernel

def env16083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,8541,8282,5392,2341,1024,8540,12741,8613,8597,218,8328,65,10628,13460,12637,10401,9304,8572,256,8573,5593,9173]

theorem envBound16083 : H12AffineFastState.Bounded env16083 := by
  intro p hp
  have h : env16083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16082_16083 : H12AffineEnvironment.transform 13 13405 env16082 = env16083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env16082 == env16083) = true)

theorem identity16083 : scanCanonicalize (H12AffineFastState.compose env16083 (packedSelected [17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound16083 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16084 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13325,8461,8202,5392,2341,1024,8460,12693,8613,8597,138,8328,17,10628,13460,12557,10401,9224,8492,256,8493,5513,9093]

theorem envBound16084 : H12AffineFastState.Bounded env16084 := by
  intro p hp
  have h : env16084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16083_16084 : H12AffineEnvironment.transform 5 16 env16083 = env16084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16083 == env16084) = true)

theorem identity16084 : scanCanonicalize (H12AffineFastState.compose env16084 (packedSelected [0,1,2,6,7,8,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound16084 : packedSelected [0,1,2,6,7,8,10,14] rootPS < 2^1333 := by decide +kernel

def env16085 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5512,136,399,5392,2341,1024,137,4112,32,16,138,269,17,2049,5393,4232,2340,1421,169,256,168,5513,512]

theorem envBound16085 : H12AffineFastState.Bounded env16085 := by
  intro p hp
  have h : env16085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16084_16085 : H12AffineEnvironment.transform 12 389 env16084 = env16085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env16084 == env16085) = true)

theorem identity16085 : scanCanonicalize (H12AffineFastState.compose env16085 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound16085 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16086 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,300,5409,33,294,5392,2341,1024,32,4112,32,16,35,269,17,2049,5393,4129,2340,1316,0,256,1,5408,512]

theorem envBound16086 : H12AffineFastState.Bounded env16086 := by
  intro p hp
  have h : env16086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16085_16086 : H12AffineEnvironment.transform 6 41 env16085 = env16086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env16085 == env16086) = true)

theorem identity16086 : scanCanonicalize (H12AffineFastState.compose env16086 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound16086 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env16087 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,41,5156,33,35,5141,2080,1024,32,4112,32,16,35,8,17,2049,5140,4129,2081,1057,0,5,1,5157,512]

theorem envBound16087 : H12AffineFastState.Bounded env16087 := by
  intro p hp
  have h : env16087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16086_16087 : H12AffineEnvironment.transform 7 5 env16086 = env16087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16086 == env16087) = true)

theorem identity16087 : scanCanonicalize (H12AffineFastState.compose env16087 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16087 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env16088 : List Nat := [2,4,8,16,1,16,8,5,512,1024,2048,4096,8,5125,0,2,5141,2049,1024,1,4112,1,16,2,8,17,2049,5140,4096,2048,1024,0,5,1,5124,512]

theorem envBound16088 : H12AffineFastState.Bounded env16088 := by
  intro p hp
  have h : env16088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16087_16088 : H12AffineEnvironment.transform 4 1 env16087 = env16088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16087 == env16088) = true)

def env16089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,130174,1024,32769,115871,120062,120015,98781,8328,65,97666,115150,17664,10401,119042,62589,256,21792,46212,63189]

theorem envBound16089 : H12AffineFastState.Bounded env16089 := by
  intro p hp
  have h : env16089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16079_16089 : H12AffineEnvironment.transform 16 49169 env16079 = env16089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env16079 == env16089) = true)

theorem identity16089 : scanCanonicalize (H12AffineFastState.compose env16089 (packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound16089 : packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS < 2^1333 := by decide +kernel

def env16090 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,32768,65536,49169,122146,1024,32769,115871,120062,120015,98781,468,65,89310,115150,17664,2557,119042,54561,256,21792,38360,55177]

theorem envBound16090 : H12AffineFastState.Bounded env16090 := by
  intro p hp
  have h : env16090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16089_16090 : H12AffineEnvironment.transform 12 348 env16089 = env16090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env16089 == env16090) = true)

theorem identity16090 : scanCanonicalize (H12AffineFastState.compose env16090 (packedSelected [1,4,5,7,8,9,16,20,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound16090 : packedSelected [1,4,5,7,8,9,16,20,24,27] rootPS < 2^1333 := by decide +kernel

def env16091 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,32768,54359,49169,2421,1024,32769,4296,169,152,21898,468,65,34953,5529,17664,2557,1365,54561,256,21792,38360,55177]

theorem envBound16091 : H12AffineFastState.Bounded env16091 := by
  intro p hp
  have h : env16091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16090_16091 : H12AffineEnvironment.transform 15 54359 env16090 = env16091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env16090 == env16091) = true)

theorem identity16091 : scanCanonicalize (H12AffineFastState.compose env16091 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound16091 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env16092 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5376,32768,33111,38161,2421,1024,32769,4296,169,152,138,468,65,34953,5529,4096,2557,1365,32801,256,32,38360,33417]

theorem envBound16092 : H12AffineFastState.Bounded env16092 := by
  intro p hp
  have h : env16092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16091_16092 : H12AffineEnvironment.transform 13 5376 env16091 = env16092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env16091 == env16092) = true)

theorem identity16092 : scanCanonicalize (H12AffineFastState.compose env16092 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(14+1) ^^^ 1432) := by decide +kernel

theorem selectedBound16092 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env16093 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5376,1432,1231,4233,2421,1024,1433,4296,169,152,138,468,65,3345,5529,4096,2557,1365,1465,256,32,4160,1809]

theorem envBound16093 : H12AffineFastState.Bounded env16093 := by
  intro p hp
  have h : env16093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16092_16093 : H12AffineEnvironment.transform 14 1432 env16092 = env16093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1432 env16092 == env16093) = true)

theorem identity16093 : scanCanonicalize (H12AffineFastState.compose env16093 (packedSelected [0,1,4,7,8,9,10,14,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound16093 : packedSelected [0,1,4,7,8,9,10,14,15,16] rootPS < 2^1333 := by decide +kernel

def env16094 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,64,348,1344,1432,1231,201,2421,1024,1433,136,169,152,138,468,65,3345,1497,64,2557,1365,1465,256,32,0,1809]

theorem envBound16094 : H12AffineFastState.Bounded env16094 := by
  intro p hp
  have h : env16094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16093_16094 : H12AffineEnvironment.transform 11 64 env16093 = env16094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env16093 == env16094) = true)

theorem identity16094 : scanCanonicalize (H12AffineFastState.compose env16094 (packedSelected [1,3,5,8,11,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 1433) := by decide +kernel

theorem selectedBound16094 : packedSelected [1,3,5,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env16095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1433,64,348,1344,1432,1231,201,1260,1024,1433,136,169,152,138,468,65,136,1497,64,1124,1365,1465,256,32,0,1809]

theorem envBound16095 : H12AffineFastState.Bounded env16095 := by
  intro p hp
  have h : env16095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16094_16095 : H12AffineEnvironment.transform 10 1433 env16094 = env16095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1433 env16094 == env16095) = true)

theorem identity16095 : scanCanonicalize (H12AffineFastState.compose env16095 (packedSelected [2,3,5,6,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound16095 : packedSelected [2,3,5,6,10,11] rootPS < 2^1333 := by decide +kernel

def env16096 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1125,64,160,1212,1124,1231,201,1260,1024,1125,136,169,152,138,40,65,136,1061,64,1124,1193,1093,252,32,0,1773]

theorem envBound16096 : H12AffineFastState.Bounded env16096 := by
  intro p hp
  have h : env16096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16095_16096 : H12AffineEnvironment.transform 7 252 env16095 = env16096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env16095 == env16096) = true)

theorem identity16096 : scanCanonicalize (H12AffineFastState.compose env16096 (packedSelected [0,1,4,7,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound16096 : packedSelected [0,1,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env16097 : List Nat := [2,4,8,16,32,64,88,36,512,1024,1125,64,120,1124,1124,1047,17,1076,1024,1125,80,113,64,82,40,65,80,1061,64,1124,1137,1093,36,32,0,1589]

theorem envBound16097 : H12AffineFastState.Bounded env16097 := by
  intro p hp
  have h : env16097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16096_16097 : H12AffineEnvironment.transform 6 88 env16096 = env16097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env16096 == env16097) = true)

theorem identity16097 : scanCanonicalize (H12AffineFastState.compose env16097 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound16097 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env16098 : List Nat := [2,4,8,16,32,64,88,36,512,53,80,64,120,81,81,34,17,1,53,80,80,113,64,82,40,65,80,16,64,81,68,112,36,32,0,512]

theorem envBound16098 : H12AffineFastState.Bounded env16098 := by
  intro p hp
  have h : env16098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16097_16098 : H12AffineEnvironment.transform 9 53 env16097 = env16098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env16097 == env16098) = true)

theorem identity16098 : scanCanonicalize (H12AffineFastState.compose env16098 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 66) := by decide +kernel

theorem selectedBound16098 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env16099 : List Nat := [2,4,8,16,32,64,88,36,66,53,80,64,120,81,81,34,17,1,53,80,80,113,64,82,40,65,80,16,64,81,68,112,36,32,0,66]

theorem envBound16099 : H12AffineFastState.Bounded env16099 := by
  intro p hp
  have h : env16099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16098_16099 : H12AffineEnvironment.transform 8 66 env16098 = env16099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 66 env16098 == env16099) = true)

theorem identity16099 : scanCanonicalize (H12AffineFastState.compose env16099 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 24) := by decide +kernel

theorem selectedBound16099 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env16100 : List Nat := [2,4,8,16,24,64,88,28,66,13,80,64,64,81,81,26,17,1,13,80,80,73,64,82,16,65,80,16,64,81,68,72,28,24,0,66]

theorem envBound16100 : H12AffineFastState.Bounded env16100 := by
  intro p hp
  have h : env16100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16099_16100 : H12AffineEnvironment.transform 4 24 env16099 = env16100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 24 env16099 == env16100) = true)

theorem identity16100 : scanCanonicalize (H12AffineFastState.compose env16100 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 15) := by decide +kernel

theorem selectedBound16100 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env16101 : List Nat := [2,4,8,16,24,15,23,28,13,13,31,15,15,30,30,26,17,1,13,31,31,6,15,29,16,14,31,16,15,30,11,7,28,24,0,13]

theorem envBound16101 : H12AffineFastState.Bounded env16101 := by
  intro p hp
  have h : env16101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16100_16101 : H12AffineEnvironment.transform 5 15 env16100 = env16101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 15 env16100 == env16101) = true)

theorem identity16101 : scanCanonicalize (H12AffineFastState.compose env16101 (packedSelected [2,6] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound16101 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0