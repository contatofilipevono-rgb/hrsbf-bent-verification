import H12CloudChart0Data021

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env5446 : List Nat := [2,4,8,16,32,17,56,5,512,1024,2048,4096,8192,4096,8217,65536,4113,262144,1025,8217,4097,4194304,4194352,51,8241,4194352,262177,4096,4112,2080,74794,16,4,1,4198432,4194864]

theorem envBound5446 : H12AffineFastState.Bounded env5446 := by
  intro p hp
  have h : env5446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5445_5446 : H12AffineEnvironment.transform 6 56 env5445 = env5446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env5445 == env5446) = true)

theorem identity5446 : scanCanonicalize (H12AffineFastState.compose env5446 (packedSelected [2,11,18] rootPS)) = affineNative (2^(21+1) ^^^ 264209) := by decide +kernel

theorem selectedBound5446 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env5447 : List Nat := [2,4,8,16,32,17,56,5,512,1024,2048,4096,8192,4096,8217,65536,4113,262144,1025,8217,4097,264209,264225,51,8241,264225,262177,4096,4112,2080,74794,16,4,1,268337,264737]

theorem envBound5447 : H12AffineFastState.Bounded env5447 := by
  intro p hp
  have h : env5447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5446_5447 : H12AffineEnvironment.transform 21 264209 env5446 = env5447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 264209 env5446 == env5447) = true)

theorem identity5447 : scanCanonicalize (H12AffineFastState.compose env5447 (packedSelected [0,7,20] rootPS)) = affineNative (2^(17+1) ^^^ 7700) := by decide +kernel

theorem selectedBound5447 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5448 : List Nat := [2,4,8,16,32,17,56,5,512,1024,2048,4096,8192,4096,8217,65536,4113,7700,1025,8217,4097,5637,5685,51,8241,5685,7733,4096,4112,2080,74794,16,4,1,1573,5173]

theorem envBound5448 : H12AffineFastState.Bounded env5448 := by
  intro p hp
  have h : env5448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5447_5448 : H12AffineEnvironment.transform 17 7700 env5447 = env5448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7700 env5447 == env5448) = true)

theorem identity5448 : scanCanonicalize (H12AffineFastState.compose env5448 (packedSelected [1,3,4,6,9,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 5644) := by decide +kernel

theorem selectedBound5448 : packedSelected [1,3,4,6,9,12,15] rootPS < 2^1333 := by decide +kernel

def env5449 : List Nat := [2,4,8,16,32,17,56,5,512,1024,2048,4096,8192,4096,8217,5644,4113,7700,1025,8217,4097,5637,5685,51,8241,5685,7733,4096,4112,2080,12838,16,4,1,1573,5173]

theorem envBound5449 : H12AffineFastState.Bounded env5449 := by
  intro p hp
  have h : env5449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5448_5449 : H12AffineEnvironment.transform 15 5644 env5448 = env5449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5644 env5448 == env5449) = true)

theorem identity5449 : scanCanonicalize (H12AffineFastState.compose env5449 (packedSelected [0,4,7,13,17,22] rootPS)) = affineNative (2^(12+1) ^^^ 2) := by decide +kernel

theorem selectedBound5449 : packedSelected [0,4,7,13,17,22] rootPS < 2^1333 := by decide +kernel

def env5450 : List Nat := [2,4,8,16,32,17,56,5,512,1024,2048,4096,2,4096,27,5644,4113,7700,1025,27,4097,5637,5685,51,51,5685,7733,4096,4112,2080,4644,16,4,1,1573,5173]

theorem envBound5450 : H12AffineFastState.Bounded env5450 := by
  intro p hp
  have h : env5450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5449_5450 : H12AffineEnvironment.transform 12 2 env5449 = env5450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2 env5449 == env5450) = true)

theorem identity5450 : scanCanonicalize (H12AffineFastState.compose env5450 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound5450 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5451 : List Nat := [2,4,8,0,32,1,40,5,512,1024,2048,4096,2,4096,11,5644,4097,7684,1025,11,4097,5637,5669,35,35,5669,7717,4096,4096,2080,4644,0,4,1,1573,5157]

theorem envBound5451 : H12AffineFastState.Bounded env5451 := by
  intro p hp
  have h : env5451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5450_5451 : H12AffineEnvironment.transform 3 0 env5450 = env5451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5450 == env5451) = true)

theorem identity5451 : scanCanonicalize (H12AffineFastState.compose env5451 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound5451 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env5452 : List Nat := [2,4,8,0,10,1,2,5,512,1024,2048,4096,2,4096,11,5644,4097,7684,1025,11,4097,5637,5647,9,9,5647,7695,4096,4096,2058,4622,0,4,1,1551,5135]

theorem envBound5452 : H12AffineFastState.Bounded env5452 := by
  intro p hp
  have h : env5452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5451_5452 : H12AffineEnvironment.transform 4 10 env5451 = env5452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env5451 == env5452) = true)

theorem identity5452 : scanCanonicalize (H12AffineFastState.compose env5452 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound5452 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env5453 : List Nat := [2,4,8,0,10,1,2,5,512,1024,523,4096,2,4096,11,5644,4097,5135,1025,11,4097,5637,5647,9,9,5647,5124,4096,4096,513,4622,0,4,1,1551,5135]

theorem envBound5453 : H12AffineFastState.Bounded env5453 := by
  intro p hp
  have h : env5453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5452_5453 : H12AffineEnvironment.transform 10 523 env5452 = env5453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env5452 == env5453) = true)

theorem identity5453 : scanCanonicalize (H12AffineFastState.compose env5453 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 1551) := by decide +kernel

theorem selectedBound5453 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env5454 : List Nat := [2,4,8,0,10,1,2,5,512,1024,523,1551,2,1551,11,3,1550,512,1025,11,1550,10,0,9,9,0,523,1551,1551,513,1025,0,4,1,1551,512]

theorem envBound5454 : H12AffineFastState.Bounded env5454 := by
  intro p hp
  have h : env5454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5453_5454 : H12AffineEnvironment.transform 11 1551 env5453 = env5454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1551 env5453 == env5454) = true)

theorem identity5454 : scanCanonicalize (H12AffineFastState.compose env5454 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound5454 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env5455 : List Nat := [2,4,3,0,1,1,2,5,512,1024,512,1540,2,1540,0,3,1541,512,1025,0,1541,1,0,2,2,0,512,1540,1540,513,1025,0,4,1,1540,512]

theorem envBound5455 : H12AffineFastState.Bounded env5455 := by
  intro p hp
  have h : env5455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5454_5455 : H12AffineEnvironment.transform 2 3 env5454 = env5455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env5454 == env5455) = true)

theorem identity5455 : scanCanonicalize (H12AffineFastState.compose env5455 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound5455 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5456 : List Nat := [2,4,3,0,1,1,2,5,1,1024,1,1029,2,1029,0,3,1028,1,1025,0,1028,1,0,2,2,0,1,1029,1029,0,1025,0,4,1,1029,1]

theorem envBound5456 : H12AffineFastState.Bounded env5456 := by
  intro p hp
  have h : env5456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5455_5456 : H12AffineEnvironment.transform 8 1 env5455 = env5456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env5455 == env5456) = true)

def leafEnv5456 : List Nat := [2,4,3,0,1,1,2,5,1,1024,1,1029,2,1029,0,3,1028,1,1025,0,1028,1,0,2,1024,2,1,0,1,1029,1029,0,1025,0,4,1,5,2,1029,1,1,1029,0]

def active5456 : List Nat := [0,1,9]

def tree5456 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5456 : H12WitnessSearch.Good tree5456 := H12GlobalWitnessIndex.good

theorem leafIdentity5456 : H12AffineFastState.composeSystem env5456 rootObs = leafEnv5456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5456 rootObs == leafEnv5456) = true)

theorem terminalChecked5456 : H12PackedTerminal.terminalCheckFast leafEnv5456 active5456 tree5456 = true := by decide +kernel

def env5457 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,4097,8352,65536,4113,262144,1025,8352,4097,4194304,4194352,138,8329,4194352,262177,4097,4113,2081,74794,16,188,0,4198433,4194864]

theorem envBound5457 : H12AffineFastState.Bounded env5457 := by
  intro p hp
  have h : env5457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5444_5457 : H12AffineEnvironment.transform 13 4097 env5444 = env5457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env5444 == env5457) = true)

theorem identity5457 : scanCanonicalize (H12AffineFastState.compose env5457 (packedSelected [2,3,4,5,9,10,11,17,18,20,21] rootPS)) = affineNative (2^(21+1) ^^^ 264209) := by decide +kernel

theorem selectedBound5457 : packedSelected [2,3,4,5,9,10,11,17,18,20,21] rootPS < 2^1333 := by decide +kernel

def env5458 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,4097,8352,65536,4113,262144,1025,8352,4097,264209,264225,138,8329,264225,262177,4097,4113,2081,74794,16,188,0,268336,264737]

theorem envBound5458 : H12AffineFastState.Bounded env5458 := by
  intro p hp
  have h : env5458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5457_5458 : H12AffineEnvironment.transform 21 264209 env5457 = env5458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 264209 env5457 == env5458) = true)

theorem identity5458 : scanCanonicalize (H12AffineFastState.compose env5458 (packedSelected [0,2,4,7,11,13,17,18,22] rootPS)) = affineNative (2^(17+1) ^^^ 75786) := by decide +kernel

theorem selectedBound5458 : packedSelected [0,2,4,7,11,13,17,18,22] rootPS < 2^1333 := by decide +kernel

def env5459 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,4097,8352,65536,4113,75786,1025,8352,4097,73755,73771,138,8329,73771,75819,4097,4113,2081,74794,16,188,0,77882,74283]

theorem envBound5459 : H12AffineFastState.Bounded env5459 := by
  intro p hp
  have h : env5459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5458_5459 : H12AffineEnvironment.transform 17 75786 env5458 = env5459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 75786 env5458 == env5459) = true)

theorem identity5459 : scanCanonicalize (H12AffineFastState.compose env5459 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 1677) := by decide +kernel

theorem selectedBound5459 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env5460 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,1677,8192,1676,8352,65536,1692,75786,1025,8352,1676,73755,73771,138,8329,73771,75819,1676,1692,2081,74794,16,188,0,75447,74283]

theorem envBound5460 : H12AffineFastState.Bounded env5460 := by
  intro p hp
  have h : env5460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5459_5460 : H12AffineEnvironment.transform 11 1677 env5459 = env5460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1677 env5459 == env5460) = true)

theorem identity5460 : scanCanonicalize (H12AffineFastState.compose env5460 (packedSelected [4,9,20] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5460 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env5461 : List Nat := [2,4,8,16,32,17,41,20,512,1024,2048,1572,8192,1573,8201,65536,1589,75786,1025,8201,1573,73755,73771,35,8224,73771,75819,1573,1589,2081,74794,16,21,0,75294,74283]

theorem envBound5461 : H12AffineFastState.Bounded env5461 := by
  intro p hp
  have h : env5461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5460_5461 : H12AffineEnvironment.transform 6 41 env5460 = env5461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5460 == env5461) = true)

theorem identity5461 : scanCanonicalize (H12AffineFastState.compose env5461 (packedSelected [0,1,3,6,7,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 2569) := by decide +kernel

theorem selectedBound5461 : packedSelected [0,1,3,6,7,12,15] rootPS < 2^1333 := by decide +kernel

def env5462 : List Nat := [2,4,8,16,32,17,41,20,512,1024,2048,1572,8192,1573,8201,2569,1589,8707,1025,8201,1573,10770,10786,35,8224,10786,8738,1573,1589,2081,11811,16,21,0,11287,10274]

theorem envBound5462 : H12AffineFastState.Bounded env5462 := by
  intro p hp
  have h : env5462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5461_5462 : H12AffineEnvironment.transform 15 2569 env5461 = env5462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2569 env5461 == env5462) = true)

theorem identity5462 : scanCanonicalize (H12AffineFastState.compose env5462 (packedSelected [13,17] rootPS)) = affineNative (2^(12+1) ^^^ 2611) := by decide +kernel

theorem selectedBound5462 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env5463 : List Nat := [2,4,8,16,32,17,41,20,512,1024,2048,1572,2611,1573,2618,2569,1589,2096,1025,2618,1573,33,17,35,2579,17,2065,1573,1589,2081,1040,16,21,0,1572,529]

theorem envBound5463 : H12AffineFastState.Bounded env5463 := by
  intro p hp
  have h : env5463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5462_5463 : H12AffineEnvironment.transform 12 2611 env5462 = env5463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2611 env5462 == env5463) = true)

theorem identity5463 : scanCanonicalize (H12AffineFastState.compose env5463 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1588) := by decide +kernel

theorem selectedBound5463 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env5464 : List Nat := [2,4,8,16,32,17,41,20,512,1024,1588,1572,1031,1573,1038,1085,1589,1540,1025,1038,1573,33,17,35,1063,17,1573,1573,1589,1557,1040,16,21,0,1572,529]

theorem envBound5464 : H12AffineFastState.Bounded env5464 := by
  intro p hp
  have h : env5464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5463_5464 : H12AffineEnvironment.transform 10 1588 env5463 = env5464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1588 env5463 == env5464) = true)

theorem identity5464 : scanCanonicalize (H12AffineFastState.compose env5464 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound5464 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5465 : List Nat := [2,4,8,16,26,17,19,20,512,1024,1550,1566,1031,1567,1038,1031,1551,1540,1025,1038,1567,27,17,25,1053,17,1567,1567,1551,1557,1040,16,21,0,1566,529]

theorem envBound5465 : H12AffineFastState.Bounded env5465 := by
  intro p hp
  have h : env5465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5464_5465 : H12AffineEnvironment.transform 4 26 env5464 = env5465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env5464 == env5465) = true)

theorem identity5465 : scanCanonicalize (H12AffineFastState.compose env5465 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound5465 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env5466 : List Nat := [2,4,8,0,10,1,3,4,512,1024,1550,1550,1031,1551,1038,1031,1551,1540,1025,1038,1551,11,1,9,1037,1,1551,1551,1551,1541,1024,0,5,0,1550,513]

theorem envBound5466 : H12AffineFastState.Bounded env5466 := by
  intro p hp
  have h : env5466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5465_5466 : H12AffineEnvironment.transform 3 0 env5465 = env5466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5465 == env5466) = true)

theorem identity5466 : scanCanonicalize (H12AffineFastState.compose env5466 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound5466 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env5467 : List Nat := [2,1,8,0,10,1,3,1,512,1024,1547,1547,1026,1546,1035,1026,1546,1537,1025,1035,1546,11,1,9,1032,1,1546,1546,1546,1536,1024,0,0,0,1547,513]

theorem envBound5467 : H12AffineFastState.Bounded env5467 := by
  intro p hp
  have h : env5467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5466_5467 : H12AffineEnvironment.transform 1 1 env5466 = env5467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env5466 == env5467) = true)

theorem identity5467 : scanCanonicalize (H12AffineFastState.compose env5467 (packedSelected [11] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound5467 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env5468 : List Nat := [2,1,8,0,10,1,3,1,1,1024,1034,1034,1026,1035,1035,1026,1035,1024,1025,1035,1035,11,1,9,1032,1,1035,1035,1035,1025,1024,0,0,0,1034,0]

theorem envBound5468 : H12AffineFastState.Bounded env5468 := by
  intro p hp
  have h : env5468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5467_5468 : H12AffineEnvironment.transform 8 1 env5467 = env5468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env5467 == env5468) = true)

theorem identity5468 : scanCanonicalize (H12AffineFastState.compose env5468 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 10) := by decide +kernel

theorem selectedBound5468 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5469 : List Nat := [2,1,8,0,10,1,3,1,1,10,0,0,8,1,1,8,1,10,11,1,1,11,1,9,2,1,1,1,1,11,10,0,0,0,0,0]

theorem envBound5469 : H12AffineFastState.Bounded env5469 := by
  intro p hp
  have h : env5469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5468_5469 : H12AffineEnvironment.transform 9 10 env5468 = env5469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 10 env5468 == env5469) = true)

def leafEnv5469 : List Nat := [2,1,8,0,10,1,3,1,1,10,0,0,8,1,1,8,1,10,11,1,1,11,1,9,11,2,1,1,1,1,1,11,10,0,0,0,0,2,0,0,1,0,0]

def active5469 : List Nat := [0,2]

def tree5469 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5469 : H12WitnessSearch.Good tree5469 := H12GlobalWitnessIndex.good

theorem leafIdentity5469 : H12AffineFastState.composeSystem env5469 rootObs = leafEnv5469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5469 rootObs == leafEnv5469) = true)

theorem terminalChecked5469 : H12PackedTerminal.terminalCheckFast leafEnv5469 active5469 tree5469 = true := by decide +kernel

def env5470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41002,8329,8914001,2942160,16385,16893,2641008,598058,14737724,525568,2638929,6332545,8914925]

theorem envBound5470 : H12AffineFastState.Bounded env5470 := by
  intro p hp
  have h : env5470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5236_5470 : H12AffineEnvironment.transform 25 8914001 env5236 = env5470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914001 env5236 == env5470) = true)

def env5471 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4096,4194304,8388608,41002,8329,8914001,849104,16385,16893,547952,598058,12644668,525568,545873,4239489,8914925]

theorem envBound5471 : H12AffineFastState.Bounded env5471 := by
  intro p hp
  have h : env5471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5470_5471 : H12AffineEnvironment.transform 20 4096 env5470 = env5471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env5470 == env5471) = true)

def env5472 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4096,4194304,8388608,41002,8329,8388689,323792,16385,16893,22640,74794,12644668,256,20561,4239489,8389613]

theorem envBound5472 : H12AffineFastState.Bounded env5472 := by
  intro p hp
  have h : env5472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5471_5472 : H12AffineEnvironment.transform 18 1024 env5471 = env5472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env5471 == env5472) = true)

theorem identity5472 : scanCanonicalize (H12AffineFastState.compose env5472 (packedSelected [14] rootPS)) = affineNative (2^(13+1) ^^^ 4264) := by decide +kernel

theorem selectedBound5472 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5473 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4264,32768,65536,4605,262144,1024,32768,4096,4194304,8388608,41002,8329,8388689,303224,4265,4437,2264,74794,12624276,256,249,4239489,8389613]

theorem envBound5473 : H12AffineFastState.Bounded env5473 := by
  intro p hp
  have h : env5473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5472_5473 : H12AffineEnvironment.transform 13 4264 env5472 = env5473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4264 env5472 == env5473) = true)

def env5474 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,32768,65536,4525,262144,1024,32768,4096,4194304,8388608,41002,8329,8388609,303144,4265,4357,2184,74794,12624276,256,169,4239489,8389565]

theorem envBound5474 : H12AffineFastState.Bounded env5474 := by
  intro p hp
  have h : env5474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5473_5474 : H12AffineEnvironment.transform 5 16 env5473 = env5474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5473 == env5474) = true)

theorem identity5474 : scanCanonicalize (H12AffineFastState.compose env5474 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound5474 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5475 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,32768,65536,4525,262144,1024,32768,4096,4194304,445,41002,8329,444,303144,4265,4357,2184,74794,4235305,256,169,4239489,512]

theorem envBound5475 : H12AffineFastState.Bounded env5475 := by
  intro p hp
  have h : env5475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5474_5475 : H12AffineEnvironment.transform 22 445 env5474 = env5475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env5474 == env5475) = true)

theorem identity5475 : scanCanonicalize (H12AffineFastState.compose env5475 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound5475 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5476 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,32768,65536,4525,262144,1024,32768,4096,41348,445,41002,8329,444,303144,4265,4357,2184,74794,429,256,169,4357,512]

theorem envBound5476 : H12AffineFastState.Bounded env5476 := by
  intro p hp
  have h : env5476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5475_5476 : H12AffineEnvironment.transform 21 41348 env5475 = env5476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env5475 == env5476) = true)

theorem identity5476 : scanCanonicalize (H12AffineFastState.compose env5476 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13885) := by decide +kernel

theorem selectedBound5476 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5477 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,13885,65536,4525,262144,1024,13885,4096,6073,445,5655,8329,444,267797,4265,4357,2184,74794,429,256,169,4357,512]

theorem envBound5477 : H12AffineFastState.Bounded env5477 := by
  intro p hp
  have h : env5477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5476_5477 : H12AffineEnvironment.transform 14 13885 env5476 = env5477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13885 env5476 == env5477) = true)

theorem identity5477 : scanCanonicalize (H12AffineFastState.compose env5477 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 8234) := by decide +kernel

theorem selectedBound5477 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5478 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,13885,8234,4525,262144,1024,13885,4096,6073,445,5655,8329,444,267797,4265,4357,2184,1024,429,256,169,4357,512]

theorem envBound5478 : H12AffineFastState.Bounded env5478 := by
  intro p hp
  have h : env5478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5477_5478 : H12AffineEnvironment.transform 15 8234 env5477 = env5478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8234 env5477 == env5478) = true)

def env5479 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4264,32768,65536,4524,262144,1024,32768,4096,4194304,8388608,41002,8329,8388608,303145,4265,4356,2185,74794,12624276,256,168,4239489,8389564]

theorem envBound5479 : H12AffineFastState.Bounded env5479 := by
  intro p hp
  have h : env5479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5473_5479 : H12AffineEnvironment.transform 5 17 env5473 = env5479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5473 == env5479) = true)

def env5480 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,4264,32768,65536,4096,262144,1024,32768,4096,4194304,8388608,41002,8329,8388608,303145,4265,4264,2185,74794,12623928,172,168,4239489,8389136]

theorem envBound5480 : H12AffineFastState.Bounded env5480 := by
  intro p hp
  have h : env5480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5479_5480 : H12AffineEnvironment.transform 7 172 env5479 = env5480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env5479 == env5480) = true)

theorem identity5480 : scanCanonicalize (H12AffineFastState.compose env5480 (packedSelected [0,3,5,8,10,11,13,18,21,23,27,28,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 7701) := by decide +kernel

theorem selectedBound5480 : packedSelected [0,3,5,8,10,11,13,18,21,23,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5481 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,4264,32768,65536,4096,7701,1024,32768,4096,4194304,8388608,41002,8329,8388608,48700,4265,4264,2185,74794,12623928,172,168,4239489,8389136]

theorem envBound5481 : H12AffineFastState.Bounded env5481 := by
  intro p hp
  have h : env5481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5480_5481 : H12AffineEnvironment.transform 17 7701 env5480 = env5481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7701 env5480 == env5481) = true)

def env5482 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,4264,32768,65536,4096,7701,1024,32768,4096,41088,8388608,41002,8329,8388608,48700,4265,4264,2185,74794,8388792,172,168,4097,8389136]

theorem envBound5482 : H12AffineFastState.Bounded env5482 := by
  intro p hp
  have h : env5482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5481_5482 : H12AffineEnvironment.transform 21 41088 env5481 = env5482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env5481 == env5482) = true)

theorem identity5482 : scanCanonicalize (H12AffineFastState.compose env5482 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound5482 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5483 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,4096,8192,4096,32768,65536,4096,7701,1024,32768,4096,41000,8388608,41002,8225,8388608,48700,4097,4096,2081,74794,8388624,4,0,4097,8389136]

theorem envBound5483 : H12AffineFastState.Bounded env5483 := by
  intro p hp
  have h : env5483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5482_5483 : H12AffineEnvironment.transform 6 40 env5482 = env5483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5482 == env5483) = true)

theorem identity5483 : scanCanonicalize (H12AffineFastState.compose env5483 (packedSelected [1,5,8,17,21,24] rootPS)) = affineNative (2^(22+1) ^^^ 103942) := by decide +kernel

theorem selectedBound5483 : packedSelected [1,5,8,17,21,24] rootPS < 2^1333 := by decide +kernel

def env5484 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,4096,8192,4096,32768,65536,4096,7701,1024,32768,4096,41000,103942,41002,8225,103942,48700,4097,4096,2081,74794,103958,4,0,4097,103446]

theorem envBound5484 : H12AffineFastState.Bounded env5484 := by
  intro p hp
  have h : env5484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5483_5484 : H12AffineEnvironment.transform 22 103942 env5483 = env5484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 103942 env5483 == env5484) = true)

theorem identity5484 : scanCanonicalize (H12AffineFastState.compose env5484 (packedSelected [0,4,7,9,13,17] rootPS)) = affineNative (2^(15+1) ^^^ 13854) := by decide +kernel

theorem selectedBound5484 : packedSelected [0,4,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env5485 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,4096,8192,4096,32768,13854,4096,7701,1024,32768,4096,41000,40984,41002,8225,40984,48700,4097,4096,2081,4660,40968,4,0,4097,41480]

theorem envBound5485 : H12AffineFastState.Bounded env5485 := by
  intro p hp
  have h : env5485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5484_5485 : H12AffineEnvironment.transform 15 13854 env5484 = env5485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13854 env5484 == env5485) = true)

theorem identity5485 : scanCanonicalize (H12AffineFastState.compose env5485 (packedSelected [1,2,4,5,6,9,11,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 14898) := by decide +kernel

theorem selectedBound5485 : packedSelected [1,2,4,5,6,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env5486 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,4096,8192,4096,14898,13854,4096,7701,1024,14898,4096,6682,6698,6680,8225,6698,1038,4097,4096,2081,4660,6714,4,0,4097,6202]

theorem envBound5486 : H12AffineFastState.Bounded env5486 := by
  intro p hp
  have h : env5486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5485_5486 : H12AffineEnvironment.transform 14 14898 env5485 = env5486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14898 env5485 == env5486) = true)

theorem identity5486 : scanCanonicalize (H12AffineFastState.compose env5486 (packedSelected [0,7,20] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound5486 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5487 : List Nat := [2,4,8,16,32,17,40,4,512,1024,1038,4096,8192,4096,13884,13854,4096,4635,1024,13884,4096,5652,5668,5654,8225,5668,1038,4097,4096,1071,4660,5684,4,0,4097,5172]

theorem envBound5487 : H12AffineFastState.Bounded env5487 := by
  intro p hp
  have h : env5487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5486_5487 : H12AffineEnvironment.transform 10 1038 env5486 = env5487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env5486 == env5487) = true)

theorem identity5487 : scanCanonicalize (H12AffineFastState.compose env5487 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound5487 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5488 : List Nat := [2,4,8,16,32,17,40,4,512,1024,1038,1077,8192,1077,8713,8747,1077,1582,1024,8713,1077,545,529,547,8225,529,1038,1076,1077,1071,1537,513,4,0,1076,1]

theorem envBound5488 : H12AffineFastState.Bounded env5488 := by
  intro p hp
  have h : env5488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5487_5488 : H12AffineEnvironment.transform 11 1077 env5487 = env5488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env5487 == env5488) = true)

theorem identity5488 : scanCanonicalize (H12AffineFastState.compose env5488 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(12+1) ^^^ 1031) := by decide +kernel

theorem selectedBound5488 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env5489 : List Nat := [2,4,8,16,32,17,40,4,512,1024,1038,1077,1031,1077,1550,1580,1077,1582,1024,1550,1077,545,529,547,1062,529,1038,1076,1077,1071,1537,513,4,0,1076,1]

theorem envBound5489 : H12AffineFastState.Bounded env5489 := by
  intro p hp
  have h : env5489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5488_5489 : H12AffineEnvironment.transform 12 1031 env5488 = env5489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1031 env5488 == env5489) = true)

theorem identity5489 : scanCanonicalize (H12AffineFastState.compose env5489 (packedSelected [4,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound5489 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env5490 : List Nat := [2,4,8,16,32,17,40,4,0,1024,1038,1077,1031,1077,1038,1068,1077,1070,1024,1038,1077,33,17,35,1062,17,1038,1076,1077,1071,1025,1,4,0,1076,1]

theorem envBound5490 : H12AffineFastState.Bounded env5490 := by
  intro p hp
  have h : env5490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5489_5490 : H12AffineEnvironment.transform 8 0 env5489 = env5490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env5489 == env5490) = true)

theorem identity5490 : scanCanonicalize (H12AffineFastState.compose env5490 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound5490 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5491 : List Nat := [2,4,3,16,32,17,35,4,0,1024,1029,1077,1031,1077,1029,1063,1077,1061,1024,1029,1077,33,17,35,1062,17,1029,1076,1077,1060,1025,1,4,0,1076,1]

theorem envBound5491 : H12AffineFastState.Bounded env5491 := by
  intro p hp
  have h : env5491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5490_5491 : H12AffineEnvironment.transform 2 3 env5490 = env5491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env5490 == env5491) = true)

theorem identity5491 : scanCanonicalize (H12AffineFastState.compose env5491 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound5491 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5492 : List Nat := [2,4,3,16,4,17,7,4,0,1024,1029,1041,1031,1041,1029,1027,1041,1025,1024,1029,1041,5,17,7,1026,17,1029,1040,1041,1024,1025,1,4,0,1040,1]

theorem envBound5492 : H12AffineFastState.Bounded env5492 := by
  intro p hp
  have h : env5492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5491_5492 : H12AffineEnvironment.transform 4 4 env5491 = env5492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env5491 == env5492) = true)

theorem identity5492 : scanCanonicalize (H12AffineFastState.compose env5492 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 16) := by decide +kernel

theorem selectedBound5492 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5493 : List Nat := [2,4,3,16,4,17,7,4,0,16,21,1,23,1,21,19,1,17,16,21,1,5,17,7,18,17,21,0,1,16,17,1,4,0,0,1]

theorem envBound5493 : H12AffineFastState.Bounded env5493 := by
  intro p hp
  have h : env5493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5492_5493 : H12AffineEnvironment.transform 9 16 env5492 = env5493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 16 env5492 == env5493) = true)

theorem identity5493 : scanCanonicalize (H12AffineFastState.compose env5493 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound5493 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env5494 : List Nat := [2,4,3,4,4,5,7,4,0,4,1,1,3,1,1,7,1,5,4,1,1,5,5,7,6,5,1,0,1,4,5,1,4,0,0,1]

theorem envBound5494 : H12AffineFastState.Bounded env5494 := by
  intro p hp
  have h : env5494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5493_5494 : H12AffineEnvironment.transform 3 4 env5493 = env5494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env5493 == env5494) = true)

theorem identity5494 : scanCanonicalize (H12AffineFastState.compose env5494 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound5494 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env5495 : List Nat := [2,0,3,0,0,1,3,0,0,0,1,1,3,1,1,3,1,1,0,1,1,1,1,3,2,1,1,0,1,0,1,1,0,0,0,1]

theorem envBound5495 : H12AffineFastState.Bounded env5495 := by
  intro p hp
  have h : env5495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5494_5495 : H12AffineEnvironment.transform 1 0 env5494 = env5495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env5494 == env5495) = true)

def env5496 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,4264,32768,65536,4096,7701,1024,32768,4096,41089,8388608,41002,8329,8388608,48700,4265,4264,2185,74794,8388793,172,168,4096,8389136]

theorem envBound5496 : H12AffineFastState.Bounded env5496 := by
  intro p hp
  have h : env5496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5481_5496 : H12AffineEnvironment.transform 21 41089 env5481 = env5496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env5481 == env5496) = true)

theorem identity5496 : scanCanonicalize (H12AffineFastState.compose env5496 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 185) := by decide +kernel

theorem selectedBound5496 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5497 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,4264,32768,65536,4096,7701,1024,32768,4096,41089,185,41002,8329,185,48700,4265,4264,2185,74794,0,172,168,4096,681]

theorem envBound5497 : H12AffineFastState.Bounded env5497 := by
  intro p hp
  have h : env5497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5496_5497 : H12AffineEnvironment.transform 22 185 env5496 = env5497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 185 env5496 == env5497) = true)

theorem identity5497 : scanCanonicalize (H12AffineFastState.compose env5497 (packedSelected [0,3,5,7,8,13,17,18,20,23,28] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound5497 : packedSelected [0,3,5,7,8,13,17,18,20,23,28] rootPS < 2^1333 := by decide +kernel

def env5498 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,4264,8200,65536,4096,7701,1024,8200,4096,137,185,34,8329,185,7732,4265,4264,2185,74794,0,172,168,4096,681]

theorem envBound5498 : H12AffineFastState.Bounded env5498 := by
  intro p hp
  have h : env5498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5497_5498 : H12AffineEnvironment.transform 14 8200 env5497 = env5498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env5497 == env5498) = true)

theorem identity5498 : scanCanonicalize (H12AffineFastState.compose env5498 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound5498 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5499 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1588,8192,1692,8200,65536,1588,2081,1024,8200,1588,137,185,34,8329,185,2048,1693,1692,2185,74794,0,172,168,1588,681]

theorem envBound5499 : H12AffineFastState.Bounded env5499 := by
  intro p hp
  have h : env5499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5498_5499 : H12AffineEnvironment.transform 11 1588 env5498 = env5499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env5498 == env5499) = true)

theorem identity5499 : scanCanonicalize (H12AffineFastState.compose env5499 (packedSelected [1,2,6,7,8,9,11,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 2698) := by decide +kernel

theorem selectedBound5499 : packedSelected [1,2,6,7,8,9,11,13,15] rootPS < 2^1333 := by decide +kernel

def env5500 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1588,8192,1692,8200,2698,1588,2081,1024,8200,1588,137,185,34,8329,185,2048,1693,1692,2185,11936,0,172,168,1588,681]

theorem envBound5500 : H12AffineFastState.Bounded env5500 := by
  intro p hp
  have h : env5500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5499_5500 : H12AffineEnvironment.transform 15 2698 env5499 = env5500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2698 env5499 == env5500) = true)

theorem identity5500 : scanCanonicalize (H12AffineFastState.compose env5500 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1702) := by decide +kernel

theorem selectedBound5500 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env5501 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1702,1588,8192,1692,8200,1068,1588,1671,1024,8200,1588,137,185,34,8329,185,1702,1693,1692,1583,8198,0,172,168,1588,681]

theorem envBound5501 : H12AffineFastState.Bounded env5501 := by
  intro p hp
  have h : env5501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5500_5501 : H12AffineEnvironment.transform 10 1702 env5500 = env5501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1702 env5500 == env5501) = true)

theorem identity5501 : scanCanonicalize (H12AffineFastState.compose env5501 (packedSelected [0,4,7,9,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 1030) := by decide +kernel

theorem selectedBound5501 : packedSelected [0,4,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env5502 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1702,1588,1030,1692,1038,1068,1588,1671,1024,1038,1588,137,185,34,1167,185,1702,1693,1692,1583,1024,0,172,168,1588,681]

theorem envBound5502 : H12AffineFastState.Bounded env5502 := by
  intro p hp
  have h : env5502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5501_5502 : H12AffineEnvironment.transform 12 1030 env5501 = env5502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1030 env5501 == env5502) = true)

theorem identity5502 : scanCanonicalize (H12AffineFastState.compose env5502 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound5502 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5503 : List Nat := [2,4,8,16,32,17,40,4,512,1024,1550,1588,1030,1588,1038,1068,1588,1583,1024,1038,1588,33,17,34,1063,17,1550,1589,1588,1583,1024,0,4,0,1588,513]

theorem envBound5503 : H12AffineFastState.Bounded env5503 := by
  intro p hp
  have h : env5503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5502_5503 : H12AffineEnvironment.transform 6 40 env5502 = env5503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5502 == env5503) = true)

theorem identity5503 : scanCanonicalize (H12AffineFastState.compose env5503 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 52) := by decide +kernel

theorem selectedBound5503 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env5504 : List Nat := [2,4,8,16,32,17,40,4,52,1024,1082,1024,1030,1024,1038,1068,1024,1051,1024,1038,1024,33,17,34,1063,17,1082,1025,1024,1051,1024,0,4,0,1024,53]

theorem envBound5504 : H12AffineFastState.Bounded env5504 := by
  intro p hp
  have h : env5504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5503_5504 : H12AffineEnvironment.transform 8 52 env5503 = env5504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 52 env5503 == env5504) = true)

theorem identity5504 : scanCanonicalize (H12AffineFastState.compose env5504 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound5504 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5505 : List Nat := [2,4,8,11,32,10,40,4,47,1024,1057,1024,1030,1024,1038,1068,1024,1024,1024,1038,1024,33,10,34,1063,10,1057,1025,1024,1024,1024,0,4,0,1024,46]

theorem envBound5505 : H12AffineFastState.Bounded env5505 := by
  intro p hp
  have h : env5505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5504_5505 : H12AffineEnvironment.transform 3 11 env5504 = env5505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env5504 == env5505) = true)

def env5506 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4264,32768,65536,4097,262144,1024,32768,4096,4194304,8388608,41002,8329,8388608,303145,4265,4265,2185,74794,12623929,173,168,4239489,8389137]

theorem envBound5506 : H12AffineFastState.Bounded env5506 := by
  intro p hp
  have h : env5506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5479_5506 : H12AffineEnvironment.transform 7 173 env5479 = env5506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env5479 == env5506) = true)

theorem identity5506 : scanCanonicalize (H12AffineFastState.compose env5506 (packedSelected [0,3,5,8,10,11,13,18,21,23,27,28,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 81471) := by decide +kernel

theorem selectedBound5506 : packedSelected [0,3,5,8,10,11,13,18,21,23,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5507 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4264,32768,65536,4097,81471,1024,32768,4096,4194304,8388608,41002,8329,8388608,106006,4265,4265,2185,74794,12623929,173,168,4239489,8389137]

theorem envBound5507 : H12AffineFastState.Bounded env5507 := by
  intro p hp
  have h : env5507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5506_5507 : H12AffineEnvironment.transform 17 81471 env5506 = env5507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 81471 env5506 == env5507) = true)

def env5508 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4264,32768,65536,4097,81471,1024,32768,4096,41088,8388608,41002,8329,8388608,106006,4265,4265,2185,74794,8388793,173,168,4097,8389137]

theorem envBound5508 : H12AffineFastState.Bounded env5508 := by
  intro p hp
  have h : env5508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5507_5508 : H12AffineEnvironment.transform 21 41088 env5507 = env5508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env5507 == env5508) = true)

theorem identity5508 : scanCanonicalize (H12AffineFastState.compose env5508 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5508 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5509 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,4097,32768,65536,4097,81471,1024,32768,4096,41001,8388608,41002,8224,8388608,106006,4096,4096,2080,74794,8388624,4,1,4097,8389137]

theorem envBound5509 : H12AffineFastState.Bounded env5509 := by
  intro p hp
  have h : env5509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5508_5509 : H12AffineEnvironment.transform 6 41 env5508 = env5509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5508 == env5509) = true)

theorem identity5509 : scanCanonicalize (H12AffineFastState.compose env5509 (packedSelected [1,5,8,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 32802) := by decide +kernel

theorem selectedBound5509 : packedSelected [1,5,8,17,21,24] rootPS < 2^1333 := by decide +kernel

def env5510 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,4097,32768,32802,4097,48669,1024,32768,4096,41001,8388608,41002,8224,8388608,7732,4096,4096,2080,41992,8388624,4,1,4097,8389137]

theorem envBound5510 : H12AffineFastState.Bounded env5510 := by
  intro p hp
  have h : env5510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5509_5510 : H12AffineEnvironment.transform 15 32802 env5509 = env5510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32802 env5509 == env5510) = true)

theorem identity5510 : scanCanonicalize (H12AffineFastState.compose env5510 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound5510 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env5511 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,4097,8201,8235,4097,7700,1024,8201,4096,32,8388608,35,8224,8388608,7732,4096,4096,2080,1025,8388624,4,1,4097,8389137]

theorem envBound5511 : H12AffineFastState.Bounded env5511 := by
  intro p hp
  have h : env5511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5510_5511 : H12AffineEnvironment.transform 14 8201 env5510 = env5511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env5510 == env5511) = true)

theorem identity5511 : scanCanonicalize (H12AffineFastState.compose env5511 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 1550) := by decide +kernel

theorem selectedBound5511 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env5512 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,1550,8192,1551,8201,8235,1551,2074,1024,8201,1550,32,8388608,35,8224,8388608,2106,1550,1550,2080,1025,8388624,4,1,1551,8389137]

theorem envBound5512 : H12AffineFastState.Bounded env5512 := by
  intro p hp
  have h : env5512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5511_5512 : H12AffineEnvironment.transform 11 1550 env5511 = env5512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1550 env5511 == env5512) = true)

theorem identity5512 : scanCanonicalize (H12AffineFastState.compose env5512 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound5512 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5513 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,1550,8192,1551,8201,8235,1551,2074,1024,8201,1550,32,17,35,8224,17,2106,1550,1550,2080,1025,1,4,1,1551,512]

theorem envBound5513 : H12AffineFastState.Bounded env5513 := by
  intro p hp
  have h : env5513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5512_5513 : H12AffineEnvironment.transform 22 17 env5512 = env5513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env5512 == env5513) = true)

theorem identity5513 : scanCanonicalize (H12AffineFastState.compose env5513 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1550) := by decide +kernel

theorem selectedBound5513 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5514 : List Nat := [2,4,8,16,32,17,41,4,512,1024,1550,1550,8192,1551,8201,8235,1551,1556,1024,8201,1550,32,17,35,8224,17,1588,1550,1550,1582,1025,1,4,1,1551,512]

theorem envBound5514 : H12AffineFastState.Bounded env5514 := by
  intro p hp
  have h : env5514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5513_5514 : H12AffineEnvironment.transform 10 1550 env5513 = env5514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1550 env5513 == env5514) = true)

theorem identity5514 : scanCanonicalize (H12AffineFastState.compose env5514 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound5514 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env5515 : List Nat := [2,4,8,16,27,17,18,4,512,1024,1550,1550,8192,1551,8201,8208,1551,1556,1024,8201,1550,27,17,24,8219,17,1551,1550,1550,1557,1025,1,4,1,1551,512]

theorem envBound5515 : H12AffineFastState.Bounded env5515 := by
  intro p hp
  have h : env5515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5514_5515 : H12AffineEnvironment.transform 4 27 env5514 = env5515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env5514 == env5515) = true)

theorem identity5515 : scanCanonicalize (H12AffineFastState.compose env5515 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound5515 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env5516 : List Nat := [2,4,8,16,27,17,18,4,512,1024,1550,1550,1053,1551,1044,1037,1551,1556,1024,1044,1550,27,17,24,1030,17,1551,1550,1550,1557,1025,1,4,1,1551,512]

theorem envBound5516 : H12AffineFastState.Bounded env5516 := by
  intro p hp
  have h : env5516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5515_5516 : H12AffineEnvironment.transform 12 1053 env5515 = env5516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env5515 == env5516) = true)

theorem identity5516 : scanCanonicalize (H12AffineFastState.compose env5516 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound5516 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env5517 : List Nat := [2,4,8,16,27,17,18,4,1,1024,1039,1039,1053,1038,1044,1037,1038,1045,1024,1044,1039,27,17,24,1030,17,1038,1039,1039,1044,1025,1,4,1,1038,1]

theorem envBound5517 : H12AffineFastState.Bounded env5517 := by
  intro p hp
  have h : env5517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5516_5517 : H12AffineEnvironment.transform 8 1 env5516 = env5517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env5516 == env5517) = true)

theorem identity5517 : scanCanonicalize (H12AffineFastState.compose env5517 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound5517 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5518 : List Nat := [2,4,8,16,27,17,18,4,1,21,26,26,8,27,1,24,27,0,21,1,26,27,17,24,19,17,27,26,26,1,20,1,4,1,27,1]

theorem envBound5518 : H12AffineFastState.Bounded env5518 := by
  intro p hp
  have h : env5518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5517_5518 : H12AffineEnvironment.transform 9 21 env5517 = env5518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env5517 == env5518) = true)

def env5519 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4264,32768,65536,4097,81471,1024,32768,4096,41089,8388608,41002,8329,8388608,106006,4265,4265,2185,74794,8388792,173,168,4096,8389137]

theorem envBound5519 : H12AffineFastState.Bounded env5519 := by
  intro p hp
  have h : env5519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5507_5519 : H12AffineEnvironment.transform 21 41089 env5507 = env5519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env5507 == env5519) = true)

theorem identity5519 : scanCanonicalize (H12AffineFastState.compose env5519 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 185) := by decide +kernel

theorem selectedBound5519 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5520 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4264,32768,65536,4097,81471,1024,32768,4096,41089,185,41002,8329,185,106006,4265,4265,2185,74794,1,173,168,4096,680]

theorem envBound5520 : H12AffineFastState.Bounded env5520 := by
  intro p hp
  have h : env5520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5519_5520 : H12AffineEnvironment.transform 22 185 env5519 = env5520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 185 env5519 == env5520) = true)

theorem identity5520 : scanCanonicalize (H12AffineFastState.compose env5520 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound5520 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env5521 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4264,32768,8235,4097,7700,1024,32768,4096,41089,185,41002,8329,185,48701,4265,4265,2185,1025,1,173,168,4096,680]

theorem envBound5521 : H12AffineFastState.Bounded env5521 := by
  intro p hp
  have h : env5521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5520_5521 : H12AffineEnvironment.transform 15 8235 env5520 = env5521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env5520 == env5521) = true)

theorem identity5521 : scanCanonicalize (H12AffineFastState.compose env5521 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 1692) := by decide +kernel

theorem selectedBound5521 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env5522 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,1692,8192,1588,32768,8235,1693,2184,1024,32768,1692,41089,185,41002,8329,185,43169,1589,1589,2185,1025,1,173,168,1692,680]

theorem envBound5522 : H12AffineFastState.Bounded env5522 := by
  intro p hp
  have h : env5522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5521_5522 : H12AffineEnvironment.transform 11 1692 env5521 = env5522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1692 env5521 == env5522) = true)

theorem identity5522 : scanCanonicalize (H12AffineFastState.compose env5522 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 8352) := by decide +kernel

theorem selectedBound5522 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5523 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,1692,8192,1588,8352,8235,1693,2184,1024,8352,1692,33,185,138,8329,185,2049,1589,1589,2185,1025,1,173,168,1692,680]

theorem envBound5523 : H12AffineFastState.Bounded env5523 := by
  intro p hp
  have h : env5523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5522_5523 : H12AffineEnvironment.transform 14 8352 env5522 = env5523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env5522 == env5523) = true)

theorem identity5523 : scanCanonicalize (H12AffineFastState.compose env5523 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1725) := by decide +kernel

theorem selectedBound5523 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env5524 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1725,1692,8192,1588,8352,8235,1693,1589,1024,8352,1692,33,185,138,8329,185,1724,1589,1589,1588,1025,1,173,168,1692,680]

theorem envBound5524 : H12AffineFastState.Bounded env5524 := by
  intro p hp
  have h : env5524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5523_5524 : H12AffineEnvironment.transform 10 1725 env5523 = env5524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1725 env5523 == env5524) = true)

theorem identity5524 : scanCanonicalize (H12AffineFastState.compose env5524 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound5524 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5525 : List Nat := [2,4,8,16,32,17,51,30,512,1024,1550,1583,8192,1588,8211,8235,1582,1589,1024,8211,1583,33,10,57,8250,10,1551,1589,1589,1588,1025,1,30,27,1583,539]

theorem envBound5525 : H12AffineFastState.Bounded env5525 := by
  intro p hp
  have h : env5525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5524_5525 : H12AffineEnvironment.transform 6 51 env5524 = env5525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env5524 == env5525) = true)

theorem identity5525 : scanCanonicalize (H12AffineFastState.compose env5525 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 1062) := by decide +kernel

theorem selectedBound5525 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env5526 : List Nat := [2,4,8,16,32,17,51,30,512,1024,1550,1583,1062,1588,1077,1037,1582,1589,1024,1077,1583,33,10,57,1052,10,1551,1589,1589,1588,1025,1,30,27,1583,539]

theorem envBound5526 : H12AffineFastState.Bounded env5526 := by
  intro p hp
  have h : env5526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5525_5526 : H12AffineEnvironment.transform 12 1062 env5525 = env5526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1062 env5525 == env5526) = true)

theorem identity5526 : scanCanonicalize (H12AffineFastState.compose env5526 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound5526 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env5527 : List Nat := [2,4,8,10,32,11,41,4,512,1024,1550,1583,1062,1582,1071,1037,1582,1583,1024,1071,1583,33,10,35,1030,10,1551,1583,1583,1582,1025,1,4,1,1583,513]

theorem envBound5527 : H12AffineFastState.Bounded env5527 := by
  intro p hp
  have h : env5527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5526_5527 : H12AffineEnvironment.transform 3 10 env5526 = env5527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env5526 == env5527) = true)

theorem identity5527 : scanCanonicalize (H12AffineFastState.compose env5527 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound5527 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env5528 : List Nat := [2,4,7,5,32,4,38,4,512,1024,1537,1568,1062,1569,1056,1026,1569,1568,1024,1056,1568,33,5,35,1030,5,1536,1568,1568,1569,1025,1,4,1,1568,513]

theorem envBound5528 : H12AffineFastState.Bounded env5528 := by
  intro p hp
  have h : env5528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5527_5528 : H12AffineEnvironment.transform 2 7 env5527 = env5528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env5527 == env5528) = true)

theorem identity5528 : scanCanonicalize (H12AffineFastState.compose env5528 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound5528 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env5529 : List Nat := [2,1,2,0,32,1,35,1,512,1024,1537,1568,1059,1569,1056,1026,1569,1568,1024,1056,1568,33,0,35,1027,0,1536,1568,1568,1569,1025,1,1,1,1568,513]

theorem envBound5529 : H12AffineFastState.Bounded env5529 := by
  intro p hp
  have h : env5529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5528_5529 : H12AffineEnvironment.transform 1 1 env5528 = env5529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env5528 == env5529) = true)

theorem identity5529 : scanCanonicalize (H12AffineFastState.compose env5529 (packedSelected [11] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound5529 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env5530 : List Nat := [2,1,2,0,32,1,35,1,1,1024,1024,1057,1059,1056,1056,1026,1056,1057,1024,1056,1057,33,0,35,1027,0,1025,1057,1057,1056,1025,1,1,1,1057,0]

theorem envBound5530 : H12AffineFastState.Bounded env5530 := by
  intro p hp
  have h : env5530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5529_5530 : H12AffineEnvironment.transform 8 1 env5529 = env5530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env5529 == env5530) = true)

theorem identity5530 : scanCanonicalize (H12AffineFastState.compose env5530 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 33) := by decide +kernel

theorem selectedBound5530 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5531 : List Nat := [2,1,2,0,32,1,35,1,1,33,33,0,2,1,1,35,1,0,33,1,0,33,0,35,34,0,32,0,0,1,32,1,1,1,0,0]

theorem envBound5531 : H12AffineFastState.Bounded env5531 := by
  intro p hp
  have h : env5531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5530_5531 : H12AffineEnvironment.transform 9 33 env5530 = env5531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 33 env5530 == env5531) = true)

def leafEnv5531 : List Nat := [2,1,2,0,32,1,35,1,1,33,33,0,2,1,1,35,1,0,33,1,0,33,0,35,32,34,1,0,32,0,0,1,32,1,1,1,1,3,0,0,1,1,0]

def active5531 : List Nat := [0,4]

def tree5531 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5531 : H12WitnessSearch.Good tree5531 := H12GlobalWitnessIndex.good

theorem leafIdentity5531 : H12AffineFastState.composeSystem env5531 rootObs = leafEnv5531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5531 rootObs == leafEnv5531) = true)

theorem terminalChecked5531 : H12PackedTerminal.terminalCheckFast leafEnv5531 active5531 tree5531 = true := by decide +kernel

def env5532 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4096,4194304,8388608,41002,8329,8388688,323793,16385,16893,22641,74795,12644668,257,20560,4239489,8389612]

theorem envBound5532 : H12AffineFastState.Bounded env5532 := by
  intro p hp
  have h : env5532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5471_5532 : H12AffineEnvironment.transform 18 1025 env5471 = env5532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env5471 == env5532) = true)

theorem identity5532 : scanCanonicalize (H12AffineFastState.compose env5532 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 5545) := by decide +kernel

theorem selectedBound5532 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5533 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4096,4194304,5545,41002,8329,5625,323793,16385,16893,22641,74795,4252821,257,20560,4239489,5701]

theorem envBound5533 : H12AffineFastState.Bounded env5533 := by
  intro p hp
  have h : env5533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5532_5533 : H12AffineEnvironment.transform 22 5545 env5532 = env5533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5545 env5532 == env5533) = true)

def env5534 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4096,4194304,5545,41002,8329,5545,323713,16385,16813,22561,74795,4252821,257,20480,4239489,5653]

theorem envBound5534 : H12AffineFastState.Bounded env5534 := by
  intro p hp
  have h : env5534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5533_5534 : H12AffineEnvironment.transform 5 16 env5533 = env5534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5533 == env5534) = true)

def env5535 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4096,41260,5545,41002,8329,5545,323713,16385,16813,22561,74795,17849,257,20480,4525,5653]

theorem envBound5535 : H12AffineFastState.Bounded env5535 := by
  intro p hp
  have h : env5535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5534_5535 : H12AffineEnvironment.transform 21 41260 env5534 = env5535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41260 env5534 == env5535) = true)

theorem identity5535 : scanCanonicalize (H12AffineFastState.compose env5535 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 25914) := by decide +kernel

theorem selectedBound5535 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env5536 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,25914,4525,262144,1025,32768,4096,41260,5545,41002,8329,5545,323713,16385,16813,22561,16657,17849,257,20480,4525,5653]

theorem envBound5536 : H12AffineFastState.Bounded env5536 := by
  intro p hp
  have h : env5536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5535_5536 : H12AffineEnvironment.transform 15 25914 env5535 = env5536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25914 env5535 == env5536) = true)

def env5537 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1464,8192,16384,32768,25914,1045,262144,1025,32768,1464,41260,17,41002,8329,17,320825,16385,16813,19865,16657,17849,257,17848,1045,941]

theorem envBound5537 : H12AffineFastState.Bounded env5537 := by
  intro p hp
  have h : env5537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5536_5537 : H12AffineEnvironment.transform 11 1464 env5536 = env5537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1464 env5536 == env5537) = true)

theorem identity5537 : scanCanonicalize (H12AffineFastState.compose env5537 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5537 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5538 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1297,8192,16384,32768,25914,1045,262144,1025,32768,1297,41260,17,41002,8224,17,320825,16385,16644,19760,16657,17680,257,17681,1045,772]

theorem envBound5538 : H12AffineFastState.Bounded env5538 := by
  intro p hp
  have h : env5538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5537_5538 : H12AffineEnvironment.transform 6 41 env5537 = env5538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5537 == env5538) = true)

theorem identity5538 : scanCanonicalize (H12AffineFastState.compose env5538 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 57622) := by decide +kernel

theorem selectedBound5538 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5539 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1297,8192,16384,32768,25914,1045,57622,1025,32768,1297,41260,17,41002,8224,17,1071,16385,16644,19760,16657,17680,257,17681,1045,772]

theorem envBound5539 : H12AffineFastState.Bounded env5539 := by
  intro p hp
  have h : env5539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5538_5539 : H12AffineEnvironment.transform 17 57622 env5538 = env5539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 57622 env5538 == env5539) = true)

theorem identity5539 : scanCanonicalize (H12AffineFastState.compose env5539 (packedSelected [1,5,13,15] rootPS)) = affineNative (2^(14+1) ^^^ 16411) := by decide +kernel

theorem selectedBound5539 : packedSelected [1,5,13,15] rootPS < 2^1333 := by decide +kernel

def env5540 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1297,8192,16384,16411,25914,1045,8461,1025,16411,1297,24887,17,24625,8224,17,1071,16385,16644,19760,16657,17680,257,17681,1045,772]

theorem envBound5540 : H12AffineFastState.Bounded env5540 := by
  intro p hp
  have h : env5540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5539_5540 : H12AffineEnvironment.transform 14 16411 env5539 = env5540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 16411 env5539 == env5540) = true)

theorem identity5540 : scanCanonicalize (H12AffineFastState.compose env5540 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound5540 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env5541 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,1045,8192,16384,16411,25662,1045,8201,1025,16411,1045,24627,17,24625,8224,17,1071,16385,16384,19508,16405,17428,5,17429,1045,512]

theorem envBound5541 : H12AffineFastState.Bounded env5541 := by
  intro p hp
  have h : env5541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5540_5541 : H12AffineEnvironment.transform 7 4 env5540 = env5541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env5540 == env5541) = true)

theorem identity5541 : scanCanonicalize (H12AffineFastState.compose env5541 (packedSelected [3,5,12,13] rootPS)) = affineNative (2^(13+1) ^^^ 2106) := by decide +kernel

theorem selectedBound5541 : packedSelected [3,5,12,13] rootPS < 2^1333 := by decide +kernel

def env5542 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,1045,8192,2106,2081,11268,1045,8201,1025,2081,1045,10249,17,10251,8224,17,1071,2107,2106,1038,2095,3118,5,3119,1045,512]

theorem envBound5542 : H12AffineFastState.Bounded env5542 := by
  intro p hp
  have h : env5542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5541_5542 : H12AffineEnvironment.transform 13 2106 env5541 = env5542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2106 env5541 == env5542) = true)

theorem identity5542 : scanCanonicalize (H12AffineFastState.compose env5542 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound5542 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env5543 : List Nat := [2,4,8,16,32,16,41,4,512,1024,1076,1045,8192,1038,1045,8240,1045,8201,1025,1045,1045,9277,17,9279,8224,17,1071,1039,1038,1038,1051,26,5,27,1045,512]

theorem envBound5543 : H12AffineFastState.Bounded env5543 := by
  intro p hp
  have h : env5543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5542_5543 : H12AffineEnvironment.transform 10 1076 env5542 = env5543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env5542 == env5543) = true)

theorem identity5543 : scanCanonicalize (H12AffineFastState.compose env5543 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(12+1) ^^^ 1062) := by decide +kernel

theorem selectedBound5543 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env5544 : List Nat := [2,4,8,16,32,16,41,4,512,1024,1076,1045,1062,1038,1045,1046,1045,1071,1025,1045,1045,27,17,25,1030,17,1071,1039,1038,1038,1051,26,5,27,1045,512]

theorem envBound5544 : H12AffineFastState.Bounded env5544 := by
  intro p hp
  have h : env5544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5543_5544 : H12AffineEnvironment.transform 12 1062 env5543 = env5544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1062 env5543 == env5544) = true)

theorem identity5544 : scanCanonicalize (H12AffineFastState.compose env5544 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound5544 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5545 : List Nat := [2,4,8,16,32,16,41,4,512,21,33,0,51,27,0,3,0,58,20,0,0,27,17,25,19,17,58,26,27,27,14,26,5,27,0,512]

theorem envBound5545 : H12AffineFastState.Bounded env5545 := by
  intro p hp
  have h : env5545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5544_5545 : H12AffineEnvironment.transform 9 21 env5544 = env5545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env5544 == env5545) = true)

theorem identity5545 : scanCanonicalize (H12AffineFastState.compose env5545 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound5545 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env5546 : List Nat := [2,4,8,16,26,16,19,4,512,21,27,0,9,27,0,3,0,0,20,0,0,27,17,25,19,17,0,26,27,27,14,26,5,27,0,512]

theorem envBound5546 : H12AffineFastState.Bounded env5546 := by
  intro p hp
  have h : env5546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5545_5546 : H12AffineEnvironment.transform 4 26 env5545 = env5546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env5545 == env5546) = true)

theorem identity5546 : scanCanonicalize (H12AffineFastState.compose env5546 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound5546 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5547 : List Nat := [2,4,8,11,1,11,8,4,512,14,0,0,9,0,0,3,0,0,15,0,0,0,10,2,8,10,0,1,0,0,14,1,5,0,0,512]

theorem envBound5547 : H12AffineFastState.Bounded env5547 := by
  intro p hp
  have h : env5547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5546_5547 : H12AffineEnvironment.transform 3 11 env5546 = env5547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env5546 == env5547) = true)

def env5548 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1465,8192,16384,32768,25914,1044,262144,1025,32768,1465,41260,16,41002,8329,16,320824,16385,16813,19864,16657,17849,257,17849,1044,940]

theorem envBound5548 : H12AffineFastState.Bounded env5548 := by
  intro p hp
  have h : env5548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5536_5548 : H12AffineEnvironment.transform 11 1465 env5536 = env5548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1465 env5536 == env5548) = true)

theorem identity5548 : scanCanonicalize (H12AffineFastState.compose env5548 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound5548 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5549 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1212,8192,16384,32768,25663,1044,262144,1025,32768,1212,41001,16,41002,8329,16,320573,16385,16552,19613,16404,17596,4,17596,1044,681]

theorem envBound5549 : H12AffineFastState.Bounded env5549 := by
  intro p hp
  have h : env5549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5548_5549 : H12AffineEnvironment.transform 7 5 env5548 = env5549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env5548 == env5549) = true)

theorem identity5549 : scanCanonicalize (H12AffineFastState.compose env5549 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 1589) := by decide +kernel

theorem selectedBound5549 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env5550 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1212,8192,1589,32768,8714,1044,262144,1025,32768,1212,41001,16,41002,8329,16,303624,1588,1693,2728,1569,649,4,649,1044,681]

theorem envBound5550 : H12AffineFastState.Bounded env5550 := by
  intro p hp
  have h : env5550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5549_5550 : H12AffineEnvironment.transform 13 1589 env5549 = env5550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1589 env5549 == env5550) = true)

theorem identity5550 : scanCanonicalize (H12AffineFastState.compose env5550 (packedSelected [2,3,5,10,11,17,18,21] rootPS)) = affineNative (2^(14+1) ^^^ 8352) := by decide +kernel

theorem selectedBound5550 : packedSelected [2,3,5,10,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env5551 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1212,8192,1589,8352,8714,1044,262144,1025,8352,1212,137,16,138,8329,16,262824,1588,1693,2728,1569,649,4,649,1044,681]

theorem envBound5551 : H12AffineFastState.Bounded env5551 := by
  intro p hp
  have h : env5551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5550_5551 : H12AffineEnvironment.transform 14 8352 env5550 = env5551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env5550 == env5551) = true)

theorem identity5551 : scanCanonicalize (H12AffineFastState.compose env5551 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 2729) := by decide +kernel

theorem selectedBound5551 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5552 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1212,8192,1589,8352,8714,1044,2729,1025,8352,1212,137,16,138,8329,16,2049,1588,1693,2728,1569,649,4,649,1044,681]

theorem envBound5552 : H12AffineFastState.Bounded env5552 := by
  intro p hp
  have h : env5552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5551_5552 : H12AffineEnvironment.transform 17 2729 env5551 = env5552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2729 env5551 == env5552) = true)

theorem identity5552 : scanCanonicalize (H12AffineFastState.compose env5552 (packedSelected [2,5,6,8,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound5552 : packedSelected [2,5,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env5553 : List Nat := [2,4,8,16,32,16,128,5,147,1024,2048,1212,8192,1190,8352,8345,1044,2106,1025,8352,1212,137,16,138,8329,16,2049,1191,1038,2107,1202,26,4,26,1044,58]

theorem envBound5553 : H12AffineFastState.Bounded env5553 := by
  intro p hp
  have h : env5553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5552_5553 : H12AffineEnvironment.transform 8 147 env5552 = env5553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env5552 == env5553) = true)

theorem identity5553 : scanCanonicalize (H12AffineFastState.compose env5553 (packedSelected [0,2,7,13] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound5553 : packedSelected [0,2,7,13] rootPS < 2^1333 := by decide +kernel

def env5554 : List Nat := [2,4,8,16,32,16,128,5,147,53,2048,137,8192,147,8352,8345,33,2106,52,8352,137,137,16,138,8329,16,2049,146,59,2107,135,26,4,26,33,58]

theorem envBound5554 : H12AffineFastState.Bounded env5554 := by
  intro p hp
  have h : env5554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5553_5554 : H12AffineEnvironment.transform 9 53 env5553 = env5554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env5553 == env5554) = true)

theorem identity5554 : scanCanonicalize (H12AffineFastState.compose env5554 (packedSelected [1,2,3,4,7,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound5554 : packedSelected [1,2,3,4,7,10,11] rootPS < 2^1333 := by decide +kernel

def env5555 : List Nat := [2,4,8,16,32,16,128,5,147,53,2048,137,8,147,168,145,33,2106,52,168,137,137,16,138,129,16,2049,146,59,2107,135,26,4,26,33,58]

theorem envBound5555 : H12AffineFastState.Bounded env5555 := by
  intro p hp
  have h : env5555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5554_5555 : H12AffineEnvironment.transform 12 8 env5554 = env5555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env5554 == env5555) = true)

theorem identity5555 : scanCanonicalize (H12AffineFastState.compose env5555 (packedSelected [1,2,3,4,5,6,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound5555 : packedSelected [1,2,3,4,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env5556 : List Nat := [2,4,8,16,32,16,51,5,32,53,2048,58,8,32,27,34,33,2106,52,27,58,58,16,57,50,16,2049,33,59,2107,52,26,4,26,33,58]

theorem envBound5556 : H12AffineFastState.Bounded env5556 := by
  intro p hp
  have h : env5556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5555_5556 : H12AffineEnvironment.transform 6 51 env5555 = env5556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env5555 == env5556) = true)

theorem identity5556 : scanCanonicalize (H12AffineFastState.compose env5556 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 59) := by decide +kernel

theorem selectedBound5556 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env5557 : List Nat := [2,4,8,16,32,16,51,5,32,53,59,58,8,32,27,34,33,1,52,27,58,58,16,57,50,16,58,33,59,0,52,26,4,26,33,58]

theorem envBound5557 : H12AffineFastState.Bounded env5557 := by
  intro p hp
  have h : env5557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5556_5557 : H12AffineEnvironment.transform 10 59 env5556 = env5557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 59 env5556 == env5557) = true)

def env5558 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4096,41261,5545,41002,8329,5545,323713,16385,16813,22561,74795,17848,257,20480,4524,5653]

theorem envBound5558 : H12AffineFastState.Bounded env5558 := by
  intro p hp
  have h : env5558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5534_5558 : H12AffineEnvironment.transform 21 41261 env5534 = env5558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41261 env5534 == env5558) = true)

theorem identity5558 : scanCanonicalize (H12AffineFastState.compose env5558 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5558 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env5559 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,16384,32768,65536,4356,262144,1025,32768,4096,41261,5376,41002,8224,5376,323624,16385,16644,22561,74795,17681,257,20480,4357,5653]

theorem envBound5559 : H12AffineFastState.Bounded env5559 := by
  intro p hp
  have h : env5559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5558_5559 : H12AffineEnvironment.transform 6 41 env5558 = env5559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5558 == env5559) = true)

def env5560 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1296,8192,16384,32768,65536,1044,262144,1025,32768,1296,41261,16,41002,8224,16,320824,16385,16644,19761,74795,17681,257,17680,1045,773]

theorem envBound5560 : H12AffineFastState.Bounded env5560 := by
  intro p hp
  have h : env5560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5559_5560 : H12AffineEnvironment.transform 11 1296 env5559 = env5560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env5559 == env5560) = true)

def env5561 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1297,8192,16384,32768,65536,1045,262144,1025,32768,1297,41261,17,41002,8224,17,320825,16385,16644,19760,74795,17681,257,17681,1044,772]

theorem envBound5561 : H12AffineFastState.Bounded env5561 := by
  intro p hp
  have h : env5561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5559_5561 : H12AffineEnvironment.transform 11 1297 env5559 = env5561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env5559 == env5561) = true)

theorem identity5561 : scanCanonicalize (H12AffineFastState.compose env5561 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound5561 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5562 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,1044,8192,16384,32768,65536,1045,262144,1025,32768,1044,41000,17,41002,8224,17,320572,16385,16385,19509,74795,17428,4,17428,1044,513]

theorem envBound5562 : H12AffineFastState.Bounded env5562 := by
  intro p hp
  have h : env5562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5561_5562 : H12AffineEnvironment.transform 7 5 env5561 = env5562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env5561 == env5562) = true)

theorem identity5562 : scanCanonicalize (H12AffineFastState.compose env5562 (packedSelected [0,7,20] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound5562 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5563 : List Nat := [2,4,8,16,32,16,41,5,33,1024,2048,1044,8192,16384,32768,65536,1045,262144,1025,32768,1044,41000,17,41002,8224,17,320572,16385,16385,19509,74795,17428,4,17428,1044,32]

theorem envBound5563 : H12AffineFastState.Bounded env5563 := by
  intro p hp
  have h : env5563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5562_5563 : H12AffineEnvironment.transform 8 33 env5562 = env5563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env5562 == env5563) = true)

theorem identity5563 : scanCanonicalize (H12AffineFastState.compose env5563 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 25647) := by decide +kernel

theorem selectedBound5563 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5564 : List Nat := [2,4,8,16,32,16,41,5,33,1024,2048,1044,8192,16384,32768,25647,1045,262144,1025,32768,1044,41000,17,41002,8224,17,320572,16385,16385,19509,16388,17428,4,17428,1044,32]

theorem envBound5564 : H12AffineFastState.Bounded env5564 := by
  intro p hp
  have h : env5564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5563_5564 : H12AffineEnvironment.transform 15 25647 env5563 = env5564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25647 env5563 == env5564) = true)

theorem identity5564 : scanCanonicalize (H12AffineFastState.compose env5564 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8217) := by decide +kernel

theorem selectedBound5564 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env5565 : List Nat := [2,4,8,16,32,16,41,5,33,1024,2048,1044,8192,16384,8217,25647,1045,262144,1025,8217,1044,49,17,51,8224,17,279589,16385,16385,19509,16388,17428,4,17428,1044,32]

theorem envBound5565 : H12AffineFastState.Bounded env5565 := by
  intro p hp
  have h : env5565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5564_5565 : H12AffineEnvironment.transform 14 8217 env5564 = env5565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8217 env5564 == env5565) = true)

theorem identity5565 : scanCanonicalize (H12AffineFastState.compose env5565 (packedSelected [2,6,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 54) := by decide +kernel

theorem selectedBound5565 : packedSelected [2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env5566 : List Nat := [2,4,8,16,32,16,41,5,33,1024,2048,1044,54,16384,47,17433,1045,262144,1025,47,1044,49,17,51,22,17,279589,16385,16385,19509,16388,17428,4,17428,1044,32]

theorem envBound5566 : H12AffineFastState.Bounded env5566 := by
  intro p hp
  have h : env5566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5565_5566 : H12AffineEnvironment.transform 12 54 env5565 = env5566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 54 env5565 == env5566) = true)

theorem identity5566 : scanCanonicalize (H12AffineFastState.compose env5566 (packedSelected [0,1,2,4,5,6,7,8,9,15] rootPS)) = affineNative (2^(17+1) ^^^ 2097) := by decide +kernel

theorem selectedBound5566 : packedSelected [0,1,2,4,5,6,7,8,9,15] rootPS < 2^1333 := by decide +kernel

def env5567 : List Nat := [2,4,8,16,32,16,41,5,33,1024,2048,1044,54,16384,47,17433,1045,2097,1025,47,1044,49,17,51,22,17,19476,16385,16385,19509,16388,17428,4,17428,1044,32]

theorem envBound5567 : H12AffineFastState.Bounded env5567 := by
  intro p hp
  have h : env5567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5566_5567 : H12AffineEnvironment.transform 17 2097 env5566 = env5567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2097 env5566 == env5567) = true)

theorem identity5567 : scanCanonicalize (H12AffineFastState.compose env5567 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound5567 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env5568 : List Nat := [2,4,8,1,32,1,41,5,33,1024,2048,1029,39,16384,47,17416,1028,2080,1025,47,1029,32,0,34,7,0,19461,16385,16385,19492,16388,17413,4,17413,1029,32]

theorem envBound5568 : H12AffineFastState.Bounded env5568 := by
  intro p hp
  have h : env5568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5567_5568 : H12AffineEnvironment.transform 3 1 env5567 = env5568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5567 == env5568) = true)

theorem identity5568 : scanCanonicalize (H12AffineFastState.compose env5568 (packedSelected [0,1,4] rootPS)) = affineNative (2^(13+1) ^^^ 3114) := by decide +kernel

theorem selectedBound5568 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env5569 : List Nat := [2,4,8,1,32,1,41,5,33,1024,2048,1029,39,3114,47,2082,1028,2080,1025,47,1029,32,0,34,7,0,47,3115,3115,14,3118,2095,4,2095,1029,32]

theorem envBound5569 : H12AffineFastState.Bounded env5569 := by
  intro p hp
  have h : env5569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5568_5569 : H12AffineEnvironment.transform 13 3114 env5568 = env5569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3114 env5568 == env5569) = true)

theorem identity5569 : scanCanonicalize (H12AffineFastState.compose env5569 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound5569 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5570 : List Nat := [2,4,8,1,32,1,41,5,33,15,2048,10,39,2085,47,2082,11,2080,14,47,10,32,0,34,7,0,47,2084,2084,14,2081,2095,4,2095,10,32]

theorem envBound5570 : H12AffineFastState.Bounded env5570 := by
  intro p hp
  have h : env5570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5569_5570 : H12AffineEnvironment.transform 9 15 env5569 = env5570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env5569 == env5570) = true)

theorem identity5570 : scanCanonicalize (H12AffineFastState.compose env5570 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 37) := by decide +kernel

theorem selectedBound5570 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5571 : List Nat := [2,4,8,1,32,1,41,5,33,15,37,10,39,0,47,7,11,5,14,47,10,32,0,34,7,0,47,1,1,14,4,10,4,10,10,32]

theorem envBound5571 : H12AffineFastState.Bounded env5571 := by
  intro p hp
  have h : env5571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5570_5571 : H12AffineEnvironment.transform 10 37 env5570 = env5571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 37 env5570 == env5571) = true)

theorem identity5571 : scanCanonicalize (H12AffineFastState.compose env5571 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound5571 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env5572 : List Nat := [2,4,7,1,32,1,38,5,33,0,37,5,39,0,32,7,4,5,1,32,5,32,0,34,7,0,32,1,1,1,4,5,4,5,5,32]

theorem envBound5572 : H12AffineFastState.Bounded env5572 := by
  intro p hp
  have h : env5572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5571_5572 : H12AffineEnvironment.transform 2 7 env5571 = env5572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env5571 == env5572) = true)

theorem identity5572 : scanCanonicalize (H12AffineFastState.compose env5572 (packedSelected [2,7] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound5572 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env5573 : List Nat := [2,4,7,1,5,1,3,5,4,0,0,5,2,0,5,7,4,5,1,5,5,5,0,7,7,0,5,1,1,1,4,5,4,5,5,5]

theorem envBound5573 : H12AffineFastState.Bounded env5573 := by
  intro p hp
  have h : env5573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5572_5573 : H12AffineEnvironment.transform 4 5 env5572 = env5573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env5572 == env5573) = true)

def leafEnv5573 : List Nat := [2,4,7,1,5,1,3,5,4,0,0,5,2,0,5,7,4,5,1,5,5,5,0,7,4,7,1,0,5,1,1,1,4,5,4,5,4,3,5,5,1,1,0]

def active5573 : List Nat := [0,1]

def tree5573 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5573 : H12WitnessSearch.Good tree5573 := H12GlobalWitnessIndex.good

theorem leafIdentity5573 : H12AffineFastState.composeSystem env5573 rootObs = leafEnv5573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5573 rootObs == leafEnv5573) = true)

theorem terminalChecked5573 : H12PackedTerminal.terminalCheckFast leafEnv5573 active5573 tree5573 = true := by decide +kernel

def env5574 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,4194304,5545,41002,8329,5544,323712,16385,16812,22560,74795,4252821,257,20481,4239489,5652]

theorem envBound5574 : H12AffineFastState.Bounded env5574 := by
  intro p hp
  have h : env5574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5533_5574 : H12AffineEnvironment.transform 5 17 env5533 = env5574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5533 == env5574) = true)

theorem identity5574 : scanCanonicalize (H12AffineFastState.compose env5574 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound5574 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5575 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1044,8192,16384,32768,65536,1464,262144,1025,32768,1044,4194304,445,41002,8329,444,320660,16385,16812,19508,74795,4252821,257,17429,4236437,512]

theorem envBound5575 : H12AffineFastState.Bounded env5575 := by
  intro p hp
  have h : env5575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5574_5575 : H12AffineEnvironment.transform 11 1044 env5574 = env5575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env5574 == env5575) = true)

theorem identity5575 : scanCanonicalize (H12AffineFastState.compose env5575 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound5575 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5576 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1044,8192,16384,32768,65536,1464,262144,1025,32768,1044,41349,445,41002,8329,444,320660,16385,16812,19508,74795,17680,257,17429,1296,512]

theorem envBound5576 : H12AffineFastState.Bounded env5576 := by
  intro p hp
  have h : env5576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5575_5576 : H12AffineEnvironment.transform 21 41349 env5575 = env5576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env5575 == env5576) = true)

theorem identity5576 : scanCanonicalize (H12AffineFastState.compose env5576 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26260) := by decide +kernel

theorem selectedBound5576 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5577 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1044,8192,16384,26260,65536,1464,262144,1025,26260,1044,18193,445,18110,8329,444,262656,16385,16812,19508,74795,17680,257,17429,1296,512]

theorem envBound5577 : H12AffineFastState.Bounded env5577 := by
  intro p hp
  have h : env5577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5576_5577 : H12AffineEnvironment.transform 14 26260 env5576 = env5577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26260 env5576 == env5577) = true)

theorem identity5577 : scanCanonicalize (H12AffineFastState.compose env5577 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 25750) := by decide +kernel

theorem selectedBound5577 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5578 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1044,8192,16384,26260,25750,1464,262144,1025,26260,1044,18193,445,18110,8329,444,262656,16385,16812,19508,16573,17680,257,17429,1296,512]

theorem envBound5578 : H12AffineFastState.Bounded env5578 := by
  intro p hp
  have h : env5578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5577_5578 : H12AffineEnvironment.transform 15 25750 env5577 = env5578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25750 env5577 == env5578) = true)

theorem identity5578 : scanCanonicalize (H12AffineFastState.compose env5578 (packedSelected [0,1,3,8,10,12,13,15,17,18,23,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound5578 : packedSelected [0,1,3,8,10,12,13,15,17,18,23,27,28] rootPS < 2^1333 := by decide +kernel

def env5579 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1044,8192,16384,26260,25750,1464,2341,1025,26260,1044,18193,445,18110,8329,444,2853,16385,16812,19508,16573,17680,257,17429,1296,512]

theorem envBound5579 : H12AffineFastState.Bounded env5579 := by
  intro p hp
  have h : env5579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5578_5579 : H12AffineEnvironment.transform 17 2341 env5578 = env5579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env5578 == env5579) = true)

theorem identity5579 : scanCanonicalize (H12AffineFastState.compose env5579 (packedSelected [1,3,4,7,9,12,13,15,17,27] rootPS)) = affineNative (2^(13+1) ^^^ 1841) := by decide +kernel

theorem selectedBound5579 : packedSelected [1,3,4,7,9,12,13,15,17,27] rootPS < 2^1333 := by decide +kernel

def env5580 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1044,8192,1841,8613,9127,1464,2341,1025,8613,1044,32,445,399,8329,444,2853,1840,1693,2821,1932,545,257,804,1296,512]

theorem envBound5580 : H12AffineFastState.Bounded env5580 := by
  intro p hp
  have h : env5580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5579_5580 : H12AffineEnvironment.transform 13 1841 env5579 = env5580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1841 env5579 == env5580) = true)

theorem identity5580 : scanCanonicalize (H12AffineFastState.compose env5580 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound5580 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env5581 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,1044,8192,1841,8461,8975,1296,2341,1025,8461,1044,32,277,295,8225,276,2853,1840,1589,2821,1828,545,257,804,1296,512]

theorem envBound5581 : H12AffineFastState.Bounded env5581 := by
  intro p hp
  have h : env5581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5580_5581 : H12AffineEnvironment.transform 6 40 env5580 = env5581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5580 == env5581) = true)

theorem identity5581 : scanCanonicalize (H12AffineFastState.compose env5581 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound5581 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5582 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,1044,8192,1589,8201,8715,1044,2081,1025,8201,1044,32,17,35,8225,16,2593,1588,1589,2561,1568,545,5,544,1044,512]

theorem envBound5582 : H12AffineFastState.Bounded env5582 := by
  intro p hp
  have h : env5582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5581_5582 : H12AffineEnvironment.transform 7 4 env5581 = env5582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env5581 == env5582) = true)

theorem identity5582 : scanCanonicalize (H12AffineFastState.compose env5582 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound5582 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env5583 : List Nat := [2,4,8,16,32,17,40,4,1,1024,2048,1044,8192,1076,8201,8202,1044,2081,1025,8201,1044,32,17,35,8225,16,2080,1077,1076,2048,1057,32,5,33,1044,1]

theorem envBound5583 : H12AffineFastState.Bounded env5583 := by
  intro p hp
  have h : env5583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5582_5583 : H12AffineEnvironment.transform 8 1 env5582 = env5583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env5582 == env5583) = true)

theorem identity5583 : scanCanonicalize (H12AffineFastState.compose env5583 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 3110) := by decide +kernel

theorem selectedBound5583 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5584 : List Nat := [2,4,8,16,32,17,40,4,1,1024,2048,1044,3110,1076,3119,3116,1044,2081,1025,3119,1044,32,17,35,3079,16,2080,1077,1076,2048,1057,32,5,33,1044,1]

theorem envBound5584 : H12AffineFastState.Bounded env5584 := by
  intro p hp
  have h : env5584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5583_5584 : H12AffineEnvironment.transform 12 3110 env5583 = env5584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3110 env5583 == env5584) = true)

theorem identity5584 : scanCanonicalize (H12AffineFastState.compose env5584 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound5584 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5585 : List Nat := [2,4,8,16,32,17,40,4,1,47,2048,59,2057,27,2048,2051,59,2081,46,2048,59,32,17,35,2088,16,2080,26,27,2048,14,32,5,33,59,1]

theorem envBound5585 : H12AffineFastState.Bounded env5585 := by
  intro p hp
  have h : env5585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5584_5585 : H12AffineEnvironment.transform 9 47 env5584 = env5585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env5584 == env5585) = true)

theorem identity5585 : scanCanonicalize (H12AffineFastState.compose env5585 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound5585 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env5586 : List Nat := [2,4,8,16,27,17,19,4,1,20,2048,0,2057,27,2048,2051,0,2074,21,2048,0,27,17,24,2067,16,2075,26,27,2048,14,27,5,26,0,1]

theorem envBound5586 : H12AffineFastState.Bounded env5586 := by
  intro p hp
  have h : env5586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5585_5586 : H12AffineEnvironment.transform 4 27 env5585 = env5586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env5585 == env5586) = true)

theorem identity5586 : scanCanonicalize (H12AffineFastState.compose env5586 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound5586 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env5587 : List Nat := [2,4,8,16,27,17,19,4,1,20,27,0,18,27,27,24,0,1,21,27,0,27,17,24,8,16,0,26,27,27,14,27,5,26,0,1]

theorem envBound5587 : H12AffineFastState.Bounded env5587 := by
  intro p hp
  have h : env5587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5586_5587 : H12AffineEnvironment.transform 10 27 env5586 = env5587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env5586 == env5587) = true)

def env5588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4097,4194304,8388608,41002,8329,8914001,849105,16385,16893,547953,598058,12644669,525568,545872,4239488,8914925]

theorem envBound5588 : H12AffineFastState.Bounded env5588 := by
  intro p hp
  have h : env5588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5470_5588 : H12AffineEnvironment.transform 20 4097 env5470 = env5588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env5470 == env5588) = true)

def env5589 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,4194304,8388608,41002,8329,8388689,323793,16385,16893,22641,74794,12644669,256,20560,4239488,8389613]

theorem envBound5589 : H12AffineFastState.Bounded env5589 := by
  intro p hp
  have h : env5589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5588_5589 : H12AffineEnvironment.transform 18 1024 env5588 = env5589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env5588 == env5589) = true)

theorem identity5589 : scanCanonicalize (H12AffineFastState.compose env5589 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4255801) := by decide +kernel

theorem selectedBound5589 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,4194304,4255801,41002,8329,4255848,323793,16385,16893,22641,74794,260,256,20560,4239488,4256724]

theorem envBound5590 : H12AffineFastState.Bounded env5590 := by
  intro p hp
  have h : env5590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5589_5590 : H12AffineEnvironment.transform 22 4255801 env5589 = env5590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4255801 env5589 == env5590) = true)

def env5591 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,4194304,4255801,41002,8329,4255800,323713,16385,16813,22561,74794,260,256,20480,4239488,4256644]

theorem envBound5591 : H12AffineFastState.Bounded env5591 := by
  intro p hp
  have h : env5591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5590_5591 : H12AffineEnvironment.transform 5 16 env5590 = env5591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5590 == env5591) = true)

def env5592 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,136,61617,41002,8329,61616,323713,16385,16813,22561,74794,260,256,20480,45064,62220]

theorem envBound5592 : H12AffineFastState.Bounded env5592 := by
  intro p hp
  have h : env5592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5591_5592 : H12AffineEnvironment.transform 21 136 env5591 = env5592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136 env5591 == env5592) = true)

theorem identity5592 : scanCanonicalize (H12AffineFastState.compose env5592 (packedSelected [0,3,5,7,8,10,17,20,21,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 93758) := by decide +kernel

theorem selectedBound5592 : packedSelected [0,3,5,7,8,10,17,20,21,28,31] rootPS < 2^1333 := by decide +kernel

def env5593 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,93758,1024,32768,4097,136,61617,41002,8329,61616,106175,16385,16813,22561,74794,260,256,20480,45064,62220]

theorem envBound5593 : H12AffineFastState.Bounded env5593 := by
  intro p hp
  have h : env5593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5592_5593 : H12AffineEnvironment.transform 17 93758 env5592 = env5593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 93758 env5592 == env5593) = true)

def env5594 : List Nat := [2,4,8,16,32,16,56,256,512,1024,2048,4096,8192,16384,32768,65536,4373,93758,1024,32768,4097,48,61449,41002,8241,61448,105991,16385,16661,22561,74794,260,256,20480,45064,62220]

theorem envBound5594 : H12AffineFastState.Bounded env5594 := by
  intro p hp
  have h : env5594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5593_5594 : H12AffineEnvironment.transform 6 56 env5593 = env5594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env5593 == env5594) = true)

theorem identity5594 : scanCanonicalize (H12AffineFastState.compose env5594 (packedSelected [0,2,7,13,17,20,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 28680) := by decide +kernel

theorem selectedBound5594 : packedSelected [0,2,7,13,17,20,23,32] rootPS < 2^1333 := by decide +kernel

def env5595 : List Nat := [2,4,8,16,32,16,56,256,512,1024,2048,4096,8192,16384,28680,65536,4373,93758,1024,28680,4097,48,1,20514,8241,0,93711,16385,16661,22561,74794,260,256,20480,16384,772]

theorem envBound5595 : H12AffineFastState.Bounded env5595 := by
  intro p hp
  have h : env5595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5594_5595 : H12AffineEnvironment.transform 14 28680 env5594 = env5595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28680 env5594 == env5595) = true)

theorem identity5595 : scanCanonicalize (H12AffineFastState.compose env5595 (packedSelected [3,5,9,10,17,21,22] rootPS)) = affineNative (2^(15+1) ^^^ 8251) := by decide +kernel

theorem selectedBound5595 : packedSelected [3,5,9,10,17,21,22] rootPS < 2^1333 := by decide +kernel

def env5596 : List Nat := [2,4,8,16,32,16,56,256,512,1024,2048,4096,8192,16384,28680,8251,4373,19973,1024,28680,4097,48,1,20514,8241,0,20020,16385,16661,22561,1041,260,256,20480,16384,772]

theorem envBound5596 : H12AffineFastState.Bounded env5596 := by
  intro p hp
  have h : env5596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5595_5596 : H12AffineEnvironment.transform 15 8251 env5595 = env5596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8251 env5595 == env5596) = true)

theorem identity5596 : scanCanonicalize (H12AffineFastState.compose env5596 (packedSelected [1,3,8,10,13,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1824) := by decide +kernel

theorem selectedBound5596 : packedSelected [1,3,8,10,13,21,24] rootPS < 2^1333 := by decide +kernel

def env5597 : List Nat := [2,4,8,16,32,16,56,256,512,1024,2048,4096,8192,1824,14120,8251,4373,2341,1024,14120,4097,48,1,5890,8241,0,2324,1825,1589,7937,1041,260,256,5920,1824,772]

theorem envBound5597 : H12AffineFastState.Bounded env5597 := by
  intro p hp
  have h : env5597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5596_5597 : H12AffineEnvironment.transform 13 1824 env5596 = env5597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1824 env5596 == env5597) = true)

theorem identity5597 : scanCanonicalize (H12AffineFastState.compose env5597 (packedSelected [0,4,7,9,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 1825) := by decide +kernel

theorem selectedBound5597 : packedSelected [0,4,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env5598 : List Nat := [2,4,8,16,32,16,56,256,512,1024,2048,1825,8192,1824,8201,8251,1588,2341,1024,8201,1824,48,1,35,8241,0,2324,1825,1589,2080,1041,260,256,1,1824,772]

theorem envBound5598 : H12AffineFastState.Bounded env5598 := by
  intro p hp
  have h : env5598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5597_5598 : H12AffineEnvironment.transform 11 1825 env5597 = env5598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1825 env5597 == env5598) = true)

theorem identity5598 : scanCanonicalize (H12AffineFastState.compose env5598 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound5598 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5599 : List Nat := [2,4,8,16,32,16,56,4,512,1024,2048,1573,8192,1572,8201,8251,1588,2081,1024,8201,1572,48,1,35,8241,0,2064,1573,1589,2080,1041,0,4,1,1572,512]

theorem envBound5599 : H12AffineFastState.Bounded env5599 := by
  intro p hp
  have h : env5599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5598_5599 : H12AffineEnvironment.transform 7 4 env5598 = env5599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env5598 == env5599) = true)

theorem identity5599 : scanCanonicalize (H12AffineFastState.compose env5599 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound5599 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env5600 : List Nat := [2,4,8,16,16,16,8,4,512,1024,2048,1557,8192,1556,8201,8203,1540,2065,1024,8201,1556,0,1,19,8193,0,2064,1557,1541,2064,1041,0,4,1,1556,512]

theorem envBound5600 : H12AffineFastState.Bounded env5600 := by
  intro p hp
  have h : env5600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5599_5600 : H12AffineEnvironment.transform 4 16 env5599 = env5600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env5599 == env5600) = true)

theorem identity5600 : scanCanonicalize (H12AffineFastState.compose env5600 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound5600 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env5601 : List Nat := [2,4,8,16,16,16,8,4,512,1024,539,1557,8192,1556,8201,8203,1540,522,1024,8201,1556,0,1,19,8193,0,523,1557,1541,523,1041,0,4,1,1556,512]

theorem envBound5601 : H12AffineFastState.Bounded env5601 := by
  intro p hp
  have h : env5601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5600_5601 : H12AffineEnvironment.transform 10 539 env5600 = env5601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env5600 == env5601) = true)

theorem identity5601 : scanCanonicalize (H12AffineFastState.compose env5601 (packedSelected [2,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound5601 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env5602 : List Nat := [2,4,8,16,16,16,8,4,16,1024,11,1029,8192,1028,8201,8203,1044,26,1024,8201,1028,0,1,19,8193,0,27,1029,1045,27,1041,0,4,1,1028,16]

theorem envBound5602 : H12AffineFastState.Bounded env5602 := by
  intro p hp
  have h : env5602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5601_5602 : H12AffineEnvironment.transform 8 16 env5601 = env5602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env5601 == env5602) = true)

theorem identity5602 : scanCanonicalize (H12AffineFastState.compose env5602 (packedSelected [0,1,6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound5602 : packedSelected [0,1,6] rootPS < 2^1333 := by decide +kernel

def env5603 : List Nat := [2,4,8,0,0,0,8,4,0,1024,11,1029,8192,1028,8201,8203,1028,10,1024,8201,1028,0,1,3,8193,0,11,1029,1029,11,1025,0,4,1,1028,0]

theorem envBound5603 : H12AffineFastState.Bounded env5603 := by
  intro p hp
  have h : env5603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5602_5603 : H12AffineEnvironment.transform 3 0 env5602 = env5603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5602 == env5603) = true)

theorem identity5603 : scanCanonicalize (H12AffineFastState.compose env5603 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound5603 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5604 : List Nat := [2,4,8,0,0,0,8,4,0,1024,11,1029,9,1028,0,2,1028,10,1024,0,1028,0,1,3,8,0,11,1029,1029,11,1025,0,4,1,1028,0]

theorem envBound5604 : H12AffineFastState.Bounded env5604 := by
  intro p hp
  have h : env5604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5603_5604 : H12AffineEnvironment.transform 12 9 env5603 = env5604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env5603 == env5604) = true)

theorem identity5604 : scanCanonicalize (H12AffineFastState.compose env5604 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound5604 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5605 : List Nat := [2,4,2,0,0,0,2,4,0,1024,1,1029,3,1028,0,2,1028,0,1024,0,1028,0,1,3,2,0,1,1029,1029,1,1025,0,4,1,1028,0]

theorem envBound5605 : H12AffineFastState.Bounded env5605 := by
  intro p hp
  have h : env5605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5604_5605 : H12AffineEnvironment.transform 2 2 env5604 = env5605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env5604 == env5605) = true)

def leafEnv5605 : List Nat := [2,4,2,0,0,0,2,4,0,1024,1,1029,3,1028,0,2,1028,0,1024,0,1028,0,1,3,1025,2,1,0,1,1029,1029,1,1025,0,4,1,4,2,1028,0,1,1029,0]

def active5605 : List Nat := [0,1,9]

def tree5605 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5605 : H12WitnessSearch.Good tree5605 := H12GlobalWitnessIndex.good

theorem leafIdentity5605 : H12AffineFastState.composeSystem env5605 rootObs = leafEnv5605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5605 rootObs == leafEnv5605) = true)

theorem terminalChecked5605 : H12PackedTerminal.terminalCheckFast leafEnv5605 active5605 tree5605 = true := by decide +kernel

def env5606 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,4096,8192,16384,32768,65536,4372,93758,1024,32768,4097,49,61448,41002,8240,61449,105990,16385,16660,22561,74794,260,256,20480,45064,62220]

theorem envBound5606 : H12AffineFastState.Bounded env5606 := by
  intro p hp
  have h : env5606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5593_5606 : H12AffineEnvironment.transform 6 57 env5593 = env5606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env5593 == env5606) = true)

theorem identity5606 : scanCanonicalize (H12AffineFastState.compose env5606 (packedSelected [0,2,7,13,17,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 53542) := by decide +kernel

theorem selectedBound5606 : packedSelected [0,2,7,13,17,20,23,32] rootPS < 2^1333 := by decide +kernel

def env5607 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,4096,8192,16384,32768,53542,4372,48920,1024,32768,4097,49,61448,41002,8240,61449,20256,16385,16660,22561,62732,260,256,20480,45064,62220]

theorem envBound5607 : H12AffineFastState.Bounded env5607 := by
  intro p hp
  have h : env5607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5606_5607 : H12AffineEnvironment.transform 15 53542 env5606 = env5607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53542 env5606 == env5607) = true)

theorem identity5607 : scanCanonicalize (H12AffineFastState.compose env5607 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 28680) := by decide +kernel

theorem selectedBound5607 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env5608 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,4096,8192,16384,28680,8494,4372,20240,1024,28680,4097,49,0,20514,8240,1,20256,16385,16660,22561,1284,260,256,20480,16384,772]

theorem envBound5608 : H12AffineFastState.Bounded env5608 := by
  intro p hp
  have h : env5608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5607_5608 : H12AffineEnvironment.transform 14 28680 env5607 = env5608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28680 env5607 == env5608) = true)

theorem identity5608 : scanCanonicalize (H12AffineFastState.compose env5608 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound5608 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env5609 : List Nat := [2,4,8,0,32,0,41,256,512,1024,2048,4096,8192,16384,28680,8494,4356,20224,1024,28680,4097,33,0,20514,8224,1,20256,16385,16644,22561,1284,260,256,20480,16384,772]

theorem envBound5609 : H12AffineFastState.Bounded env5609 := by
  intro p hp
  have h : env5609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5608_5609 : H12AffineEnvironment.transform 3 0 env5608 = env5609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5608 == env5609) = true)

theorem identity5609 : scanCanonicalize (H12AffineFastState.compose env5609 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 15116) := by decide +kernel

theorem selectedBound5609 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env5610 : List Nat := [2,4,8,0,32,0,41,256,512,1024,2048,4096,8192,15116,2820,8494,4356,13324,1024,2820,4097,33,0,11054,8224,1,13356,15117,14856,9005,1284,260,256,11020,15116,772]

theorem envBound5610 : H12AffineFastState.Bounded env5610 := by
  intro p hp
  have h : env5610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5609_5610 : H12AffineEnvironment.transform 13 15116 env5609 = env5610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15116 env5609 == env5610) = true)

theorem identity5610 : scanCanonicalize (H12AffineFastState.compose env5610 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 1030) := by decide +kernel

theorem selectedBound5610 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env5611 : List Nat := [2,4,8,0,32,0,41,256,512,1024,2048,4096,1030,7946,2820,1320,4356,4106,1024,2820,4097,33,0,3880,1062,1,4138,7947,7694,1835,1284,260,256,3850,7946,772]

theorem envBound5611 : H12AffineFastState.Bounded env5611 := by
  intro p hp
  have h : env5611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5610_5611 : H12AffineEnvironment.transform 12 1030 env5610 = env5611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1030 env5610 == env5611) = true)

theorem identity5611 : scanCanonicalize (H12AffineFastState.compose env5611 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 1572) := by decide +kernel

theorem selectedBound5611 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env5612 : List Nat := [2,4,8,0,32,0,41,256,512,1024,2048,1572,1030,2350,2820,1320,1824,1582,1024,2820,1573,33,0,3880,1062,1,1550,2351,2090,1835,1284,260,256,3850,2350,772]

theorem envBound5612 : H12AffineFastState.Bounded env5612 := by
  intro p hp
  have h : env5612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5611_5612 : H12AffineEnvironment.transform 11 1572 env5611 = env5612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1572 env5611 == env5612) = true)

theorem identity5612 : scanCanonicalize (H12AffineFastState.compose env5612 (packedSelected [2,6,11,18] rootPS)) = affineNative (2^(10+1) ^^^ 1803) := by decide +kernel

theorem selectedBound5612 : packedSelected [2,6,11,18] rootPS < 2^1333 := by decide +kernel

def env5613 : List Nat := [2,4,8,0,32,0,41,256,512,1024,1803,1572,1030,1573,1039,1320,1824,1582,1024,1039,1573,33,0,35,1062,1,1550,1572,1825,1835,1284,260,256,1,1573,772]

theorem envBound5613 : H12AffineFastState.Bounded env5613 := by
  intro p hp
  have h : env5613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5612_5613 : H12AffineEnvironment.transform 10 1803 env5612 = env5613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1803 env5612 == env5613) = true)

theorem identity5613 : scanCanonicalize (H12AffineFastState.compose env5613 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound5613 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env5614 : List Nat := [2,4,8,0,32,0,41,15,512,1024,1540,1572,1030,1573,1039,1063,1583,1582,1024,1039,1573,33,0,35,1062,1,1550,1572,1582,1572,1035,11,15,1,1573,523]

theorem envBound5614 : H12AffineFastState.Bounded env5614 := by
  intro p hp
  have h : env5614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5613_5614 : H12AffineEnvironment.transform 7 15 env5613 = env5614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env5613 == env5614) = true)

theorem identity5614 : scanCanonicalize (H12AffineFastState.compose env5614 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound5614 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env5615 : List Nat := [2,4,2,0,32,0,35,5,512,1024,1540,1572,1030,1573,1029,1063,1573,1572,1024,1029,1573,33,0,35,1062,1,1540,1572,1572,1572,1025,1,5,1,1573,513]

theorem envBound5615 : H12AffineFastState.Bounded env5615 := by
  intro p hp
  have h : env5615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5614_5615 : H12AffineEnvironment.transform 2 2 env5614 = env5615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env5614 == env5615) = true)

theorem identity5615 : scanCanonicalize (H12AffineFastState.compose env5615 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound5615 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env5616 : List Nat := [2,4,2,0,32,0,35,5,5,1024,1025,1057,1030,1056,1029,1063,1056,1057,1024,1029,1056,33,0,35,1062,1,1025,1057,1057,1057,1025,1,5,1,1056,4]

theorem envBound5616 : H12AffineFastState.Bounded env5616 := by
  intro p hp
  have h : env5616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5615_5616 : H12AffineEnvironment.transform 8 5 env5615 = env5616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env5615 == env5616) = true)

theorem identity5616 : scanCanonicalize (H12AffineFastState.compose env5616 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound5616 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env5617 : List Nat := [2,0,2,0,32,0,35,1,1,1024,1025,1057,1026,1056,1025,1059,1056,1057,1024,1025,1056,33,0,35,1058,1,1025,1057,1057,1057,1025,1,1,1,1056,0]

theorem envBound5617 : H12AffineFastState.Bounded env5617 := by
  intro p hp
  have h : env5617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5616_5617 : H12AffineEnvironment.transform 1 0 env5616 = env5617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env5616 == env5617) = true)

theorem identity5617 : scanCanonicalize (H12AffineFastState.compose env5617 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 33) := by decide +kernel

theorem selectedBound5617 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5618 : List Nat := [2,0,2,0,32,0,35,1,1,33,32,0,35,1,32,2,1,0,33,32,1,33,0,35,3,1,32,0,0,0,32,1,1,1,1,0]

theorem envBound5618 : H12AffineFastState.Bounded env5618 := by
  intro p hp
  have h : env5618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5617_5618 : H12AffineEnvironment.transform 9 33 env5617 = env5618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 33 env5617 == env5618) = true)

def leafEnv5618 : List Nat := [2,0,2,0,32,0,35,1,1,33,32,0,35,1,32,2,1,0,33,32,1,33,0,35,32,3,1,1,32,0,0,0,32,1,1,1,0,34,1,0,1,1,0]

def active5618 : List Nat := [0,4]

def tree5618 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5618 : H12WitnessSearch.Good tree5618 := H12GlobalWitnessIndex.good

theorem leafIdentity5618 : H12AffineFastState.composeSystem env5618 rootObs = leafEnv5618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5618 rootObs == leafEnv5618) = true)

theorem terminalChecked5618 : H12PackedTerminal.terminalCheckFast leafEnv5618 active5618 tree5618 = true := by decide +kernel

def env5619 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,137,61616,41002,8329,61617,323713,16385,16813,22561,74794,260,256,20480,45065,62221]

theorem envBound5619 : H12AffineFastState.Bounded env5619 := by
  intro p hp
  have h : env5619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5591_5619 : H12AffineEnvironment.transform 21 137 env5591 = env5619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 137 env5591 == env5619) = true)

theorem identity5619 : scanCanonicalize (H12AffineFastState.compose env5619 (packedSelected [0,3,5,7,8,10,17,20,21,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 94098) := by decide +kernel

theorem selectedBound5619 : packedSelected [0,3,5,7,8,10,17,20,21,28,31] rootPS < 2^1333 := by decide +kernel

def env5620 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,94098,1024,32768,4097,137,61616,41002,8329,61617,106259,16385,16813,22561,74794,260,256,20480,45065,62221]

theorem envBound5620 : H12AffineFastState.Bounded env5620 := by
  intro p hp
  have h : env5620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5619_5620 : H12AffineEnvironment.transform 17 94098 env5619 = env5620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 94098 env5619 == env5620) = true)

def env5621 : List Nat := [2,4,8,16,32,16,56,256,512,1024,2048,4096,8192,16384,32768,65536,4373,93994,1024,32768,4097,49,61448,41002,8241,61449,106259,16385,16661,22561,74794,260,256,20480,45065,62221]

theorem envBound5621 : H12AffineFastState.Bounded env5621 := by
  intro p hp
  have h : env5621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5620_5621 : H12AffineEnvironment.transform 6 56 env5620 = env5621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env5620 == env5621) = true)

theorem identity5621 : scanCanonicalize (H12AffineFastState.compose env5621 (packedSelected [0,2,7,13,17,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 53542) := by decide +kernel

theorem selectedBound5621 : packedSelected [0,2,7,13,17,20,23,32] rootPS < 2^1333 := by decide +kernel

def env5622 : List Nat := [2,4,8,16,32,16,56,256,512,1024,2048,4096,8192,16384,32768,53542,4373,48652,1024,32768,4097,49,61448,41002,8241,61449,20021,16385,16661,22561,62732,260,256,20480,45065,62221]

theorem envBound5622 : H12AffineFastState.Bounded env5622 := by
  intro p hp
  have h : env5622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5621_5622 : H12AffineEnvironment.transform 15 53542 env5621 = env5622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53542 env5621 == env5622) = true)

theorem identity5622 : scanCanonicalize (H12AffineFastState.compose env5622 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 28680) := by decide +kernel

theorem selectedBound5622 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env5623 : List Nat := [2,4,8,16,32,16,56,256,512,1024,2048,4096,8192,16384,28680,8494,4373,19972,1024,28680,4097,49,0,20514,8241,1,20021,16385,16661,22561,1284,260,256,20480,16385,773]

theorem envBound5623 : H12AffineFastState.Bounded env5623 := by
  intro p hp
  have h : env5623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5622_5623 : H12AffineEnvironment.transform 14 28680 env5622 = env5623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28680 env5622 == env5623) = true)

theorem identity5623 : scanCanonicalize (H12AffineFastState.compose env5623 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound5623 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env5624 : List Nat := [2,4,8,0,32,0,40,256,512,1024,2048,4096,8192,16384,28680,8494,4357,19972,1024,28680,4097,33,0,20514,8225,1,20005,16385,16645,22561,1284,260,256,20480,16385,773]

theorem envBound5624 : H12AffineFastState.Bounded env5624 := by
  intro p hp
  have h : env5624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5623_5624 : H12AffineEnvironment.transform 3 0 env5623 = env5624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5623 == env5624) = true)

theorem identity5624 : scanCanonicalize (H12AffineFastState.compose env5624 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 15149) := by decide +kernel

theorem selectedBound5624 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env5625 : List Nat := [2,4,8,0,32,0,40,256,512,1024,2048,4096,8192,15149,2853,8494,4357,13609,1024,2853,4097,33,0,11023,8225,1,13576,15148,14888,8972,1284,260,256,11053,15148,773]

theorem envBound5625 : H12AffineFastState.Bounded env5625 := by
  intro p hp
  have h : env5625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5624_5625 : H12AffineEnvironment.transform 13 15149 env5624 = env5625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15149 env5624 == env5625) = true)

theorem identity5625 : scanCanonicalize (H12AffineFastState.compose env5625 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1551) := by decide +kernel

theorem selectedBound5625 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env5626 : List Nat := [2,4,8,0,32,0,40,256,512,1024,1551,4096,8192,13602,1322,8494,4357,13609,1024,1322,4097,33,0,9472,8225,1,13576,13603,13351,8972,1284,260,256,9506,13603,773]

theorem envBound5626 : H12AffineFastState.Bounded env5626 := by
  intro p hp
  have h : env5626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5625_5626 : H12AffineEnvironment.transform 10 1551 env5625 = env5626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1551 env5625 == env5626) = true)

theorem identity5626 : scanCanonicalize (H12AffineFastState.compose env5626 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 1824) := by decide +kernel

theorem selectedBound5626 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env5627 : List Nat := [2,4,8,0,32,0,40,256,512,1024,1551,1824,8192,8706,1322,8494,1573,8713,1024,1322,1825,33,0,9472,8225,1,8744,8707,8967,8972,1284,260,256,9506,8707,773]

theorem envBound5627 : H12AffineFastState.Bounded env5627 := by
  intro p hp
  have h : env5627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5626_5627 : H12AffineEnvironment.transform 11 1824 env5626 = env5627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1824 env5626 == env5627) = true)

theorem identity5627 : scanCanonicalize (H12AffineFastState.compose env5627 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound5627 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env5628 : List Nat := [2,4,8,0,32,0,40,5,512,1024,1551,1573,8192,8706,1071,8235,1573,8713,1024,1071,1572,33,0,9221,8225,1,8744,8707,8706,8713,1025,1,5,9255,8707,512]

theorem envBound5628 : H12AffineFastState.Bounded env5628 := by
  intro p hp
  have h : env5628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5627_5628 : H12AffineEnvironment.transform 7 5 env5627 = env5628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env5627 == env5628) = true)

theorem identity5628 : scanCanonicalize (H12AffineFastState.compose env5628 (packedSelected [1,2,4] rootPS)) = affineNative (2^(12+1) ^^^ 547) := by decide +kernel

theorem selectedBound5628 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env5629 : List Nat := [2,4,8,0,32,0,40,5,512,1024,1551,1573,547,33,1071,520,1573,42,1024,1071,1572,33,0,1574,514,1,11,32,33,42,1025,1,5,1540,32,512]

theorem envBound5629 : H12AffineFastState.Bounded env5629 := by
  intro p hp
  have h : env5629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5628_5629 : H12AffineEnvironment.transform 12 547 env5628 = env5629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 547 env5628 == env5629) = true)

theorem identity5629 : scanCanonicalize (H12AffineFastState.compose env5629 (packedSelected [0,3] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound5629 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env5630 : List Nat := [2,4,8,0,32,0,40,5,10,1024,1029,1071,41,33,1071,2,1071,42,1024,1071,1070,33,0,1068,8,1,11,32,33,42,1025,1,5,1038,32,10]

theorem envBound5630 : H12AffineFastState.Bounded env5630 := by
  intro p hp
  have h : env5630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5629_5630 : H12AffineEnvironment.transform 8 10 env5629 = env5630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env5629 == env5630) = true)

theorem identity5630 : scanCanonicalize (H12AffineFastState.compose env5630 (packedSelected [0,1,2] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound5630 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env5631 : List Nat := [2,4,8,0,32,0,40,5,10,47,42,0,41,33,0,2,0,42,47,0,1,33,0,3,8,1,11,32,33,42,46,1,5,33,32,10]

theorem envBound5631 : H12AffineFastState.Bounded env5631 := by
  intro p hp
  have h : env5631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5630_5631 : H12AffineEnvironment.transform 9 47 env5630 = env5631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env5630 == env5631) = true)

theorem identity5631 : scanCanonicalize (H12AffineFastState.compose env5631 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound5631 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env5632 : List Nat := [2,4,8,0,11,0,3,5,10,4,1,0,2,10,0,2,0,1,4,0,1,10,0,3,8,1,11,11,10,1,5,1,5,10,11,10]

theorem envBound5632 : H12AffineFastState.Bounded env5632 := by
  intro p hp
  have h : env5632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5631_5632 : H12AffineEnvironment.transform 4 11 env5631 = env5632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env5631 == env5632) = true)

theorem identity5632 : scanCanonicalize (H12AffineFastState.compose env5632 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound5632 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5633 : List Nat := [2,4,2,0,1,0,3,5,0,4,1,0,2,0,0,2,0,1,4,0,1,0,0,3,2,1,1,1,0,1,5,1,5,0,1,0]

theorem envBound5633 : H12AffineFastState.Bounded env5633 := by
  intro p hp
  have h : env5633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5632_5633 : H12AffineEnvironment.transform 2 2 env5632 = env5633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env5632 == env5633) = true)

def env5634 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,4096,8192,16384,32768,65536,4372,93995,1024,32768,4097,48,61449,41002,8240,61448,106259,16385,16660,22561,74794,260,256,20480,45065,62221]

theorem envBound5634 : H12AffineFastState.Bounded env5634 := by
  intro p hp
  have h : env5634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5620_5634 : H12AffineEnvironment.transform 6 57 env5620 = env5634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env5620 == env5634) = true)

theorem identity5634 : scanCanonicalize (H12AffineFastState.compose env5634 (packedSelected [0,2,7,13,17,20,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 28680) := by decide +kernel

theorem selectedBound5634 : packedSelected [0,2,7,13,17,20,23,32] rootPS < 2^1333 := by decide +kernel

def env5635 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,4096,8192,16384,28680,65536,4372,93995,1024,28680,4097,48,1,20514,8240,0,93979,16385,16660,22561,74794,260,256,20480,16385,773]

theorem envBound5635 : H12AffineFastState.Bounded env5635 := by
  intro p hp
  have h : env5635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5634_5635 : H12AffineEnvironment.transform 14 28680 env5634 = env5635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28680 env5634 == env5635) = true)

theorem identity5635 : scanCanonicalize (H12AffineFastState.compose env5635 (packedSelected [3,5,9,10,17,21,22] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound5635 : packedSelected [3,5,9,10,17,21,22] rootPS < 2^1333 := by decide +kernel

def env5636 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,4096,8192,16384,28680,8250,4372,20241,1024,28680,4097,48,1,20514,8240,0,20257,16385,16660,22561,1040,260,256,20480,16385,773]

theorem envBound5636 : H12AffineFastState.Bounded env5636 := by
  intro p hp
  have h : env5636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5635_5636 : H12AffineEnvironment.transform 15 8250 env5635 = env5636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env5635 == env5636) = true)

theorem identity5636 : scanCanonicalize (H12AffineFastState.compose env5636 (packedSelected [1,3,8,10,13,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 4097) := by decide +kernel

theorem selectedBound5636 : packedSelected [1,3,8,10,13,21,24] rootPS < 2^1333 := by decide +kernel

def env5637 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,4096,8192,4097,8201,8250,4372,7952,1024,8201,4097,48,1,35,8240,0,7968,4096,4373,2080,1040,260,256,1,4096,773]

theorem envBound5637 : H12AffineFastState.Bounded env5637 := by
  intro p hp
  have h : env5637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5636_5637 : H12AffineEnvironment.transform 13 4097 env5636 = env5637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env5636 == env5637) = true)

theorem identity5637 : scanCanonicalize (H12AffineFastState.compose env5637 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 1825) := by decide +kernel

theorem selectedBound5637 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env5638 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,1825,8192,1824,8201,8250,1589,2097,1024,8201,1824,48,1,35,8240,0,2049,1825,1588,2080,1040,260,256,1,1825,773]

theorem envBound5638 : H12AffineFastState.Bounded env5638 := by
  intro p hp
  have h : env5638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5637_5638 : H12AffineEnvironment.transform 11 1825 env5637 = env5638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1825 env5637 == env5638) = true)

def env5639 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,4194304,4255801,41002,8329,4255801,323712,16385,16812,22560,74794,260,256,20481,4239488,4256645]

theorem envBound5639 : H12AffineFastState.Bounded env5639 := by
  intro p hp
  have h : env5639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5590_5639 : H12AffineEnvironment.transform 5 17 env5590 = env5639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5590 == env5639) = true)

theorem identity5639 : scanCanonicalize (H12AffineFastState.compose env5639 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 61829) := by decide +kernel

theorem selectedBound5639 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5640 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,61829,444,41002,8329,444,323712,16385,16812,22560,74794,260,256,20481,16645,512]

theorem envBound5640 : H12AffineFastState.Bounded env5640 := by
  intro p hp
  have h : env5640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5639_5640 : H12AffineEnvironment.transform 21 61829 env5639 = env5640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 61829 env5639 == env5640) = true)

theorem identity5640 : scanCanonicalize (H12AffineFastState.compose env5640 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4096) := by decide +kernel

theorem selectedBound5640 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5641 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,4524,262144,1024,32768,4097,41349,444,41002,8329,444,303232,4097,4524,2080,74794,260,256,1,4357,512]

theorem envBound5641 : H12AffineFastState.Bounded env5641 := by
  intro p hp
  have h : env5641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5640_5641 : H12AffineEnvironment.transform 13 4096 env5640 = env5641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env5640 == env5641) = true)

theorem identity5641 : scanCanonicalize (H12AffineFastState.compose env5641 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13972) := by decide +kernel

theorem selectedBound5641 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5642 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,13972,65536,4524,262144,1024,13972,4097,5905,444,5822,8329,444,267796,4097,4524,2080,74794,260,256,1,4357,512]

theorem envBound5642 : H12AffineFastState.Bounded env5642 := by
  intro p hp
  have h : env5642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5641_5642 : H12AffineEnvironment.transform 14 13972 env5641 = env5642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13972 env5641 == env5642) = true)

theorem identity5642 : scanCanonicalize (H12AffineFastState.compose env5642 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound5642 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5643 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,13972,8322,4524,262144,1024,13972,4097,5905,444,5822,8329,444,267796,4097,4524,2080,1192,260,256,1,4357,512]

theorem envBound5643 : H12AffineFastState.Bounded env5643 := by
  intro p hp
  have h : env5643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5642_5643 : H12AffineEnvironment.transform 15 8322 env5642 = env5643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env5642 == env5643) = true)

theorem identity5643 : scanCanonicalize (H12AffineFastState.compose env5643 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound5643 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env5644 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,13972,8322,4524,2080,1024,13972,4097,5905,444,5822,8329,444,7732,4097,4524,2080,1192,260,256,1,4357,512]

theorem envBound5644 : H12AffineFastState.Bounded env5644 := by
  intro p hp
  have h : env5644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5643_5644 : H12AffineEnvironment.transform 17 2080 env5643 = env5644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env5643 == env5644) = true)

theorem identity5644 : scanCanonicalize (H12AffineFastState.compose env5644 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1692) := by decide +kernel

theorem selectedBound5644 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5645 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1692,8192,1692,8200,8322,1840,2080,1024,8200,1693,397,444,34,8329,444,2216,1693,1840,2080,1192,260,256,1,1945,512]

theorem envBound5645 : H12AffineFastState.Bounded env5645 := by
  intro p hp
  have h : env5645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5644_5645 : H12AffineEnvironment.transform 11 1692 env5644 = env5645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1692 env5644 == env5645) = true)

theorem identity5645 : scanCanonicalize (H12AffineFastState.compose env5645 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound5645 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env5646 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,1692,8192,1692,8200,8322,1693,2080,1024,8200,1693,32,17,34,8329,17,2216,1693,1693,2080,1192,169,173,1,1588,512]

theorem envBound5646 : H12AffineFastState.Bounded env5646 := by
  intro p hp
  have h : env5646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5645_5646 : H12AffineEnvironment.transform 7 173 env5645 = env5646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env5645 == env5646) = true)

theorem identity5646 : scanCanonicalize (H12AffineFastState.compose env5646 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound5646 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5647 : List Nat := [2,4,8,16,32,17,128,173,512,1024,674,1692,8192,1692,8200,8322,1693,642,1024,8200,1693,32,17,34,8329,17,522,1693,1693,642,1192,169,173,1,1588,512]

theorem envBound5647 : H12AffineFastState.Bounded env5647 := by
  intro p hp
  have h : env5647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5646_5647 : H12AffineEnvironment.transform 10 674 env5646 = env5647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env5646 == env5647) = true)

theorem identity5647 : scanCanonicalize (H12AffineFastState.compose env5647 (packedSelected [0,1,2,3,4,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 35) := by decide +kernel

theorem selectedBound5647 : packedSelected [0,1,2,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env5648 : List Nat := [2,4,8,16,32,17,128,173,512,1024,674,1692,35,1692,43,161,1693,642,1024,43,1693,32,17,34,170,17,522,1693,1693,642,1192,169,173,1,1588,512]

theorem envBound5648 : H12AffineFastState.Bounded env5648 := by
  intro p hp
  have h : env5648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5647_5648 : H12AffineEnvironment.transform 12 35 env5647 = env5648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 35 env5647 == env5648) = true)

theorem identity5648 : scanCanonicalize (H12AffineFastState.compose env5648 (packedSelected [2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound5648 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env5649 : List Nat := [2,4,8,16,32,17,25,52,512,1024,571,1541,35,1541,43,56,1540,539,1024,43,1540,32,17,34,51,17,522,1540,1540,539,1073,48,52,1,1588,512]

theorem envBound5649 : H12AffineFastState.Bounded env5649 := by
  intro p hp
  have h : env5649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5648_5649 : H12AffineEnvironment.transform 6 25 env5648 = env5649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env5648 == env5649) = true)

theorem identity5649 : scanCanonicalize (H12AffineFastState.compose env5649 (packedSelected [2,3,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound5649 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env5650 : List Nat := [2,4,3,16,32,17,18,52,512,1024,560,1541,35,1541,32,51,1540,528,1024,32,1540,32,17,34,51,17,513,1540,1540,528,1073,48,52,1,1588,512]

theorem envBound5650 : H12AffineFastState.Bounded env5650 := by
  intro p hp
  have h : env5650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5649_5650 : H12AffineEnvironment.transform 2 3 env5649 = env5650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env5649 == env5650) = true)

theorem identity5650 : scanCanonicalize (H12AffineFastState.compose env5650 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound5650 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env5651 : List Nat := [2,4,3,16,0,17,18,20,512,1024,528,1541,3,1541,0,19,1540,528,1024,0,1540,0,17,2,19,17,513,1540,1540,528,1041,16,20,1,1556,512]

theorem envBound5651 : H12AffineFastState.Bounded env5651 := by
  intro p hp
  have h : env5651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5650_5651 : H12AffineEnvironment.transform 4 0 env5650 = env5651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env5650 == env5651) = true)

theorem identity5651 : scanCanonicalize (H12AffineFastState.compose env5651 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound5651 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5652 : List Nat := [2,4,3,16,0,17,18,20,0,1024,16,1029,3,1029,0,19,1028,16,1024,0,1028,0,17,2,19,17,1,1028,1028,16,1041,16,20,1,1044,0]

theorem envBound5652 : H12AffineFastState.Bounded env5652 := by
  intro p hp
  have h : env5652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5651_5652 : H12AffineEnvironment.transform 8 0 env5651 = env5652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env5651 == env5652) = true)

theorem identity5652 : scanCanonicalize (H12AffineFastState.compose env5652 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound5652 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5653 : List Nat := [2,4,3,0,0,1,2,4,0,1024,0,1029,3,1029,0,3,1028,0,1024,0,1028,0,1,2,3,1,1,1028,1028,0,1025,0,4,1,1028,0]

theorem envBound5653 : H12AffineFastState.Bounded env5653 := by
  intro p hp
  have h : env5653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5652_5653 : H12AffineEnvironment.transform 3 0 env5652 = env5653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5652 == env5653) = true)

def leafEnv5653 : List Nat := [2,4,3,0,0,1,2,4,0,1024,0,1029,3,1029,0,3,1028,0,1024,0,1028,0,1,2,1025,3,1,1,1,1028,1028,0,1025,0,4,1,4,2,1028,0,1,1028,0]

def active5653 : List Nat := [0,1,9]

def tree5653 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5653 : H12WitnessSearch.Good tree5653 := H12GlobalWitnessIndex.good

theorem leafIdentity5653 : H12AffineFastState.composeSystem env5653 rootObs = leafEnv5653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5653 rootObs == leafEnv5653) = true)

theorem terminalChecked5653 : H12PackedTerminal.terminalCheckFast leafEnv5653 active5653 tree5653 = true := by decide +kernel

def env5654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,4194304,8388608,41002,8329,8388688,323792,16385,16893,22640,74795,12644669,257,20561,4239488,8389612]

theorem envBound5654 : H12AffineFastState.Bounded env5654 := by
  intro p hp
  have h : env5654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5588_5654 : H12AffineEnvironment.transform 18 1025 env5588 = env5654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env5588 == env5654) = true)

theorem identity5654 : scanCanonicalize (H12AffineFastState.compose env5654 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 46393) := by decide +kernel

theorem selectedBound5654 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,46393,8388608,41002,8329,8388688,323792,16385,16893,22640,74795,8406020,257,20561,1465,8389612]

theorem envBound5655 : H12AffineFastState.Bounded env5655 := by
  intro p hp
  have h : env5655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5654_5655 : H12AffineEnvironment.transform 21 46393 env5654 = env5655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46393 env5654 == env5655) = true)

def env5656 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,46393,8388608,41002,8329,8388608,323712,16385,16813,22560,74795,8406020,257,20481,1465,8389564]

theorem envBound5656 : H12AffineFastState.Bounded env5656 := by
  intro p hp
  have h : env5656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5655_5656 : H12AffineEnvironment.transform 5 16 env5655 = env5656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5655 == env5656) = true)

theorem identity5656 : scanCanonicalize (H12AffineFastState.compose env5656 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound5656 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5657 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,46393,444,41002,8329,444,323712,16385,16813,22560,74795,17848,257,20481,1465,512]

theorem envBound5657 : H12AffineFastState.Bounded env5657 := by
  intro p hp
  have h : env5657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5656_5657 : H12AffineEnvironment.transform 22 444 env5656 = env5657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env5656 == env5657) = true)

theorem identity5657 : scanCanonicalize (H12AffineFastState.compose env5657 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound5657 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5658 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,16384,32768,65536,1296,262144,1025,32768,1212,41348,444,41002,8329,444,320573,16385,16813,19613,74795,17848,257,17596,1465,512]

theorem envBound5658 : H12AffineFastState.Bounded env5658 := by
  intro p hp
  have h : env5658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5657_5658 : H12AffineEnvironment.transform 11 1213 env5657 = env5658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env5657 == env5658) = true)

theorem identity5658 : scanCanonicalize (H12AffineFastState.compose env5658 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26261) := by decide +kernel

theorem selectedBound5658 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5659 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,16384,26261,65536,1296,262144,1025,26261,1212,18193,444,18111,8329,444,262824,16385,16813,19613,74795,17848,257,17596,1465,512]

theorem envBound5659 : H12AffineFastState.Bounded env5659 := by
  intro p hp
  have h : env5659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5658_5659 : H12AffineEnvironment.transform 14 26261 env5658 = env5659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26261 env5658 == env5659) = true)

theorem identity5659 : scanCanonicalize (H12AffineFastState.compose env5659 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 25663) := by decide +kernel

theorem selectedBound5659 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5660 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,16384,26261,25663,1296,262144,1025,26261,1212,18193,444,18111,8329,444,262824,16385,16813,19613,16404,17848,257,17596,1465,512]

theorem envBound5660 : H12AffineFastState.Bounded env5660 := by
  intro p hp
  have h : env5660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5659_5660 : H12AffineEnvironment.transform 15 25663 env5659 = env5660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25663 env5659 == env5660) = true)

theorem identity5660 : scanCanonicalize (H12AffineFastState.compose env5660 (packedSelected [11,12,15,18,23,24,28,32] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound5660 : packedSelected [11,12,15,18,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env5661 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1045,8192,16384,26173,25663,1296,262144,1025,26173,1044,18193,276,17943,8225,276,262656,16385,16645,19509,16404,17680,257,17428,1297,512]

theorem envBound5661 : H12AffineFastState.Bounded env5661 := by
  intro p hp
  have h : env5661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5660_5661 : H12AffineEnvironment.transform 6 40 env5660 = env5661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5660 == env5661) = true)

def env5662 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,46393,8388608,41002,8329,8388609,323713,16385,16812,22561,74795,8406020,257,20480,1465,8389565]

theorem envBound5662 : H12AffineFastState.Bounded env5662 := by
  intro p hp
  have h : env5662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5655_5662 : H12AffineEnvironment.transform 5 17 env5655 = env5662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5655 == env5662) = true)

def env5663 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,16384,32768,65536,4112,262144,1025,32768,4097,46213,8388608,41002,8329,8388609,323713,16385,16400,22561,74795,8406020,189,20480,1029,8389121]

theorem envBound5663 : H12AffineFastState.Bounded env5663 := by
  intro p hp
  have h : env5663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5662_5663 : H12AffineEnvironment.transform 7 188 env5662 = env5663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env5662 == env5663) = true)

theorem identity5663 : scanCanonicalize (H12AffineFastState.compose env5663 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(22+1) ^^^ 46260) := by decide +kernel

theorem selectedBound5663 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5664 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,16384,32768,65536,4112,262144,1025,32768,4097,46213,46260,41002,8329,46261,323713,16385,16400,22561,74795,61616,189,20480,1029,46773]

theorem envBound5664 : H12AffineFastState.Bounded env5664 := by
  intro p hp
  have h : env5664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5663_5664 : H12AffineEnvironment.transform 22 46260 env5663 = env5664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 46260 env5663 == env5664) = true)

def env5665 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,16384,32768,65536,4096,262144,1025,32768,4097,46213,46244,41002,8329,46245,323713,16385,16384,22561,74795,61600,173,20480,1029,46757]

theorem envBound5665 : H12AffineFastState.Bounded env5665 := by
  intro p hp
  have h : env5665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5664_5665 : H12AffineEnvironment.transform 3 0 env5664 = env5665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5664 == env5665) = true)

theorem identity5665 : scanCanonicalize (H12AffineFastState.compose env5665 (packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound5665 : packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env5666 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,16384,32768,53282,4096,262144,1025,32768,4097,46213,46244,41002,8329,46245,323713,16385,16384,22561,62473,61600,173,20480,1029,46757]

theorem envBound5666 : H12AffineFastState.Bounded env5666 := by
  intro p hp
  have h : env5666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5665_5666 : H12AffineEnvironment.transform 15 53282 env5665 = env5666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env5665 == env5666) = true)

theorem identity5666 : scanCanonicalize (H12AffineFastState.compose env5666 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 63528) := by decide +kernel

theorem selectedBound5666 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env5667 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,16384,32768,53282,4096,63528,1025,32768,4097,46213,46244,41002,8329,46245,2217,16385,16384,22561,62473,61600,173,20480,1029,46757]

theorem envBound5667 : H12AffineFastState.Bounded env5667 := by
  intro p hp
  have h : env5667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5666_5667 : H12AffineEnvironment.transform 17 63528 env5666 = env5667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 63528 env5666 == env5667) = true)

theorem identity5667 : scanCanonicalize (H12AffineFastState.compose env5667 (packedSelected [0,3,5,7,10,18,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 29313) := by decide +kernel

theorem selectedBound5667 : packedSelected [0,3,5,7,10,18,20,23] rootPS < 2^1333 := by decide +kernel

def env5668 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,16384,29313,8867,4096,2729,1025,29313,4097,17924,17957,21163,8329,17956,2217,16385,16384,22561,1672,545,173,20480,1029,17444]

theorem envBound5668 : H12AffineFastState.Bounded env5668 := by
  intro p hp
  have h : env5668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5667_5668 : H12AffineEnvironment.transform 14 29313 env5667 = env5668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29313 env5667 == env5668) = true)

theorem identity5668 : scanCanonicalize (H12AffineFastState.compose env5668 (packedSelected [1,2,3,4,9,11,12,15,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 4640) := by decide +kernel

theorem selectedBound5668 : packedSelected [1,2,3,4,9,11,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env5669 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,4640,8353,8867,4096,2729,1025,8353,4097,5156,5125,139,8329,5124,2217,4641,4640,2561,1672,545,173,544,1029,5636]

theorem envBound5669 : H12AffineFastState.Bounded env5669 := by
  intro p hp
  have h : env5669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5668_5669 : H12AffineEnvironment.transform 13 4640 env5668 = env5669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4640 env5668 == env5669) = true)

theorem identity5669 : scanCanonicalize (H12AffineFastState.compose env5669 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1677) := by decide +kernel

theorem selectedBound5669 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env5670 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,1677,8192,1197,8353,8867,1677,2729,1025,8353,1676,681,648,139,8329,649,2217,1196,1197,2561,1672,545,173,544,1029,137]

theorem envBound5670 : H12AffineFastState.Bounded env5670 := by
  intro p hp
  have h : env5670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5669_5670 : H12AffineEnvironment.transform 11 1677 env5669 = env5670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1677 env5669 == env5670) = true)

theorem identity5670 : scanCanonicalize (H12AffineFastState.compose env5670 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound5670 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env5671 : List Nat := [2,4,8,0,32,1,128,172,137,1024,2048,1028,8192,1197,8353,8234,1028,2080,1025,8353,1029,32,1,139,8329,0,2217,1196,1197,2184,1025,168,173,169,1029,137]

theorem envBound5671 : H12AffineFastState.Bounded env5671 := by
  intro p hp
  have h : env5671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5670_5671 : H12AffineEnvironment.transform 8 137 env5670 = env5671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env5670 == env5671) = true)

theorem identity5671 : scanCanonicalize (H12AffineFastState.compose env5671 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound5671 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env5672 : List Nat := [2,4,8,0,0,1,128,140,137,1024,2048,1028,8192,1165,8321,8202,1028,2048,1025,8321,1029,0,1,139,8329,0,2185,1164,1165,2184,1025,136,141,137,1029,137]

theorem envBound5672 : H12AffineFastState.Bounded env5672 := by
  intro p hp
  have h : env5672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5671_5672 : H12AffineEnvironment.transform 4 0 env5671 = env5672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env5671 == env5672) = true)

theorem identity5672 : scanCanonicalize (H12AffineFastState.compose env5672 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 1165) := by decide +kernel

theorem selectedBound5672 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env5673 : List Nat := [2,4,8,0,0,1,128,140,137,1024,1165,1028,8192,1165,8321,8202,1028,1165,1025,8321,1029,0,1,139,8329,0,1028,1164,1165,1029,1025,136,141,137,1029,137]

theorem envBound5673 : H12AffineFastState.Bounded env5673 := by
  intro p hp
  have h : env5673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5672_5673 : H12AffineEnvironment.transform 10 1165 env5672 = env5673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1165 env5672 == env5673) = true)

theorem identity5673 : scanCanonicalize (H12AffineFastState.compose env5673 (packedSelected [2,3] rootPS)) = affineNative (2^(12+1) ^^^ 3) := by decide +kernel

theorem selectedBound5673 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env5674 : List Nat := [2,4,8,0,0,1,128,140,137,1024,1165,1028,3,1165,130,9,1028,1165,1025,130,1029,0,1,139,138,0,1028,1164,1165,1029,1025,136,141,137,1029,137]

theorem envBound5674 : H12AffineFastState.Bounded env5674 := by
  intro p hp
  have h : env5674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5673_5674 : H12AffineEnvironment.transform 12 3 env5673 = env5674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3 env5673 == env5674) = true)

theorem identity5674 : scanCanonicalize (H12AffineFastState.compose env5674 (packedSelected [0,5] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound5674 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env5675 : List Nat := [2,4,8,0,0,1,128,140,137,140,1,136,3,1,130,9,136,1,141,130,137,0,1,139,138,0,136,0,1,137,141,136,141,137,137,137]

theorem envBound5675 : H12AffineFastState.Bounded env5675 := by
  intro p hp
  have h : env5675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5674_5675 : H12AffineEnvironment.transform 9 140 env5674 = env5675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env5674 == env5675) = true)

theorem identity5675 : scanCanonicalize (H12AffineFastState.compose env5675 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound5675 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5676 : List Nat := [2,4,2,0,0,1,128,134,131,134,1,130,3,1,130,3,130,1,135,130,131,0,1,129,128,0,130,0,1,131,135,130,135,131,131,131]

theorem envBound5676 : H12AffineFastState.Bounded env5676 := by
  intro p hp
  have h : env5676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5675_5676 : H12AffineEnvironment.transform 2 2 env5675 = env5676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env5675 == env5676) = true)

def env5677 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,4096,8192,16384,32768,65536,4097,262144,1025,32768,4097,46213,46245,41002,8329,46244,323713,16385,16385,22561,74795,61601,172,20480,1029,46756]

theorem envBound5677 : H12AffineFastState.Bounded env5677 := by
  intro p hp
  have h : env5677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5664_5677 : H12AffineEnvironment.transform 3 1 env5664 = env5677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5664 == env5677) = true)

theorem identity5677 : scanCanonicalize (H12AffineFastState.compose env5677 (packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound5677 : packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env5678 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,1025,8201,4097,5260,5292,35,8329,5293,282760,16385,16385,22561,74795,20648,172,20480,1029,5805]

theorem envBound5678 : H12AffineFastState.Bounded env5678 := by
  intro p hp
  have h : env5678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5677_5678 : H12AffineEnvironment.transform 14 8201 env5677 = env5678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env5677 == env5678) = true)

theorem identity5678 : scanCanonicalize (H12AffineFastState.compose env5678 (packedSelected [0,3,5,7,9,10,13,20,21,22] rootPS)) = affineNative (2^(15+1) ^^^ 13359) := by decide +kernel

theorem selectedBound5678 : packedSelected [0,3,5,7,9,10,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env5679 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,4096,8192,16384,8201,13359,4097,262144,1025,8201,4097,5260,5292,35,8329,5293,282760,16385,16385,22561,4100,20648,172,20480,1029,5805]

theorem envBound5679 : H12AffineFastState.Bounded env5679 := by
  intro p hp
  have h : env5679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5678_5679 : H12AffineEnvironment.transform 15 13359 env5678 = env5679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13359 env5678 == env5679) = true)

theorem identity5679 : scanCanonicalize (H12AffineFastState.compose env5679 (packedSelected [0,2,7,11,13,18,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 23040) := by decide +kernel

theorem selectedBound5679 : packedSelected [0,2,7,11,13,18,20,21] rootPS < 2^1333 := by decide +kernel

def env5680 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,4096,8192,16384,8201,13359,4097,23040,1025,8201,4097,5260,5292,35,8329,5293,2696,16385,16385,22561,4100,20648,172,20480,1029,5805]

theorem envBound5680 : H12AffineFastState.Bounded env5680 := by
  intro p hp
  have h : env5680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5679_5680 : H12AffineEnvironment.transform 17 23040 env5679 = env5680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23040 env5679 == env5680) = true)

theorem identity5680 : scanCanonicalize (H12AffineFastState.compose env5680 (packedSelected [0,1,2,3,7,11,12,15,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 1573) := by decide +kernel

theorem selectedBound5680 : packedSelected [0,1,2,3,7,11,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env5681 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1573,8192,16384,8201,8714,1572,19493,1025,8201,1572,681,649,35,8329,648,2696,16385,16385,19972,1569,18061,172,17957,1029,136]

theorem envBound5681 : H12AffineFastState.Bounded env5681 := by
  intro p hp
  have h : env5681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5680_5681 : H12AffineEnvironment.transform 11 1573 env5680 = env5681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1573 env5680 == env5681) = true)

theorem identity5681 : scanCanonicalize (H12AffineFastState.compose env5681 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5681 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5682 : List Nat := [2,4,8,1,32,0,41,4,512,1024,2048,1573,8192,16384,8201,8714,1572,19493,1025,8201,1572,512,544,35,8224,545,2593,16385,16385,19972,1569,17956,5,17957,1029,33]

theorem envBound5682 : H12AffineFastState.Bounded env5682 := by
  intro p hp
  have h : env5682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5681_5682 : H12AffineEnvironment.transform 6 41 env5681 = env5682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5681 == env5682) = true)

theorem identity5682 : scanCanonicalize (H12AffineFastState.compose env5682 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound5682 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env5683 : List Nat := [2,4,8,1,32,0,41,4,42,1024,2048,1039,8192,16384,8201,8224,1038,19493,1025,8201,1038,42,10,35,8224,11,2059,16385,16385,19502,1035,17422,5,17423,1029,33]

theorem envBound5683 : H12AffineFastState.Bounded env5683 := by
  intro p hp
  have h : env5683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5682_5683 : H12AffineEnvironment.transform 8 42 env5682 = env5683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env5682 == env5683) = true)

theorem identity5683 : scanCanonicalize (H12AffineFastState.compose env5683 (packedSelected [0,4,6] rootPS)) = affineNative (2^(13+1) ^^^ 11277) := by decide +kernel

theorem selectedBound5683 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env5684 : List Nat := [2,4,8,1,32,0,41,4,42,1024,2048,1039,8192,11277,8201,8224,1038,8232,1025,8201,1038,42,10,35,8224,11,2059,11276,11276,8227,1035,10243,5,10242,1029,33]

theorem envBound5684 : H12AffineFastState.Bounded env5684 := by
  intro p hp
  have h : env5684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5683_5684 : H12AffineEnvironment.transform 13 11277 env5683 = env5684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11277 env5683 == env5684) = true)

theorem identity5684 : scanCanonicalize (H12AffineFastState.compose env5684 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 1063) := by decide +kernel

theorem selectedBound5684 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5685 : List Nat := [2,4,8,1,32,0,41,4,42,1024,2048,1039,1063,2090,1070,1031,1038,1039,1025,1070,1038,42,10,35,1031,11,2059,2091,2091,1028,1035,3108,5,3109,1029,33]

theorem envBound5685 : H12AffineFastState.Bounded env5685 := by
  intro p hp
  have h : env5685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5684_5685 : H12AffineEnvironment.transform 12 1063 env5684 = env5685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1063 env5684 == env5685) = true)

theorem identity5685 : scanCanonicalize (H12AffineFastState.compose env5685 (packedSelected [1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound5685 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env5686 : List Nat := [2,4,8,1,32,0,41,4,42,1024,1,1039,1063,43,1070,1031,1038,1039,1025,1070,1038,42,10,35,1031,11,10,42,42,1028,1035,1061,5,1060,1029,33]

theorem envBound5686 : H12AffineFastState.Bounded env5686 := by
  intro p hp
  have h : env5686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5685_5686 : H12AffineEnvironment.transform 10 1 env5685 = env5686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env5685 == env5686) = true)

def env5687 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,16384,32768,65536,4113,262144,1025,32768,4097,46212,8388608,41002,8329,8388609,323713,16385,16401,22561,74795,8406020,188,20480,1028,8389120]

theorem envBound5687 : H12AffineFastState.Bounded env5687 := by
  intro p hp
  have h : env5687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5662_5687 : H12AffineEnvironment.transform 7 189 env5662 = env5687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env5662 == env5687) = true)

theorem identity5687 : scanCanonicalize (H12AffineFastState.compose env5687 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 53403) := by decide +kernel

theorem selectedBound5687 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5688 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,16384,32768,53403,4113,262144,1025,32768,4097,46212,8388608,41002,8329,8388609,323713,16385,16401,22561,62640,8406020,188,20480,1028,8389120]

theorem envBound5688 : H12AffineFastState.Bounded env5688 := by
  intro p hp
  have h : env5688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5687_5688 : H12AffineEnvironment.transform 15 53403 env5687 = env5688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53403 env5687 == env5688) = true)

def env5689 : List Nat := [2,4,8,0,32,1,128,173,512,1024,2048,4096,8192,16384,32768,53387,4097,262144,1025,32768,4097,46212,8388608,41002,8329,8388609,323713,16385,16385,22561,62624,8406020,172,20480,1028,8389120]

theorem envBound5689 : H12AffineFastState.Bounded env5689 := by
  intro p hp
  have h : env5689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5688_5689 : H12AffineEnvironment.transform 3 0 env5688 = env5689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5688 == env5689) = true)

theorem identity5689 : scanCanonicalize (H12AffineFastState.compose env5689 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(22+1) ^^^ 5124) := by decide +kernel

theorem selectedBound5689 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env5690 : List Nat := [2,4,8,0,32,1,128,173,512,1024,2048,4096,8192,16384,32768,53387,4097,262144,1025,32768,4097,46212,5124,41002,8329,5125,323713,16385,16385,22561,62624,20480,172,20480,1028,5636]

theorem envBound5690 : H12AffineFastState.Bounded env5690 := by
  intro p hp
  have h : env5690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5689_5690 : H12AffineEnvironment.transform 22 5124 env5689 = env5690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5124 env5689 == env5690) = true)

theorem identity5690 : scanCanonicalize (H12AffineFastState.compose env5690 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5690 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5691 : List Nat := [2,4,8,0,32,1,41,4,512,1024,2048,4096,8192,16384,32768,53282,4097,262144,1025,32768,4097,46125,5124,41002,8224,5125,323624,16385,16385,22561,62473,20480,5,20480,1028,5636]

theorem envBound5691 : H12AffineFastState.Bounded env5691 := by
  intro p hp
  have h : env5691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5690_5691 : H12AffineEnvironment.transform 6 41 env5690 = env5691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5690 == env5691) = true)

theorem identity5691 : scanCanonicalize (H12AffineFastState.compose env5691 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound5691 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5692 : List Nat := [2,4,8,0,32,1,41,4,512,1024,2048,4096,8192,16384,8201,28715,4097,262144,1025,8201,4097,5156,5124,35,8224,5125,282657,16385,16385,22561,21504,20480,5,20480,1028,5636]

theorem envBound5692 : H12AffineFastState.Bounded env5692 := by
  intro p hp
  have h : env5692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5691_5692 : H12AffineEnvironment.transform 14 8201 env5691 = env5692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env5691 == env5692) = true)

theorem identity5692 : scanCanonicalize (H12AffineFastState.compose env5692 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 8713) := by decide +kernel

theorem selectedBound5692 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env5693 : List Nat := [2,4,8,0,32,1,41,4,512,1024,2048,4096,8192,16384,8201,28715,4097,8713,1025,8201,4097,5156,5124,35,8224,5125,29224,16385,16385,22561,21504,20480,5,20480,1028,5636]

end H12CloudChart0