import H12CloudChart0Data017

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound4441 : H12AffineFastState.Bounded env4441 := by
  intro p hp
  have h : env4441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4440_4441 : H12AffineEnvironment.transform 2 6 env4440 = env4441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env4440 == env4441) = true)

theorem identity4441 : scanCanonicalize (H12AffineFastState.compose env4441 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound4441 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env4442 : List Nat := [2,1,3,1,32,1,34,0,0,32,33,0,3,1,0,35,0,1,32,0,0,33,0,35,35,1,32,1,0,0,32,0,0,0,0,1]

theorem envBound4442 : H12AffineFastState.Bounded env4442 := by
  intro p hp
  have h : env4442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4441_4442 : H12AffineEnvironment.transform 1 1 env4441 = env4442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env4441 == env4442) = true)

def leafEnv4442 : List Nat := [2,1,3,1,32,1,34,0,0,32,33,0,3,1,0,35,0,1,32,0,0,33,0,35,32,35,1,1,32,1,0,0,32,0,0,0,1,3,0,1,1,1,0]

def active4442 : List Nat := [0,4]

def tree4442 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4442 : H12WitnessSearch.Good tree4442 := H12GlobalWitnessIndex.good

theorem leafIdentity4442 : H12AffineFastState.composeSystem env4442 rootObs = leafEnv4442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4442 rootObs == leafEnv4442) = true)

theorem terminalChecked4442 : H12PackedTerminal.terminalCheckFast leafEnv4442 active4442 tree4442 = true := by decide +kernel

def env4443 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8494,4524,262144,1024,32768,4096,137,8388608,41003,8329,8388609,323713,16384,16813,22560,1285,8450485,256,20481,8405177,8389564]

theorem envBound4443 : H12AffineFastState.Bounded env4443 := by
  intro p hp
  have h : env4443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4415_4443 : H12AffineEnvironment.transform 21 137 env4415 = env4443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 137 env4415 == env4443) = true)

theorem identity4443 : scanCanonicalize (H12AffineFastState.compose env4443 (packedSelected [7,9,13,17,20,22,27] rootPS)) = affineNative (2^(22+1) ^^^ 270080) := by decide +kernel

theorem selectedBound4443 : packedSelected [7,9,13,17,20,22,27] rootPS < 2^1333 := by decide +kernel

def env4444 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8494,4524,262144,1024,32768,4096,137,270080,41003,8329,270081,323713,16384,16813,22560,1285,323253,256,20481,286649,269500]

theorem envBound4444 : H12AffineFastState.Bounded env4444 := by
  intro p hp
  have h : env4444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4443_4444 : H12AffineEnvironment.transform 22 270080 env4443 = env4444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 270080 env4443 == env4444) = true)

def env4445 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,32768,8494,4356,262144,1024,32768,4096,33,270080,41003,8225,270081,323625,16384,16645,22560,1285,323101,256,20481,286481,269332]

theorem envBound4445 : H12AffineFastState.Bounded env4445 := by
  intro p hp
  have h : env4445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4444_4445 : H12AffineEnvironment.transform 6 40 env4444 = env4445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4444 == env4445) = true)

theorem identity4445 : scanCanonicalize (H12AffineFastState.compose env4445 (packedSelected [3,9,10,11,13,18,21,22,23,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 48921) := by decide +kernel

theorem selectedBound4445 : packedSelected [3,9,10,11,13,18,21,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env4446 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,32768,8494,4356,48921,1024,32768,4096,33,40985,41003,8225,40984,20272,16384,16645,22560,1285,20740,256,20481,57352,41741]

theorem envBound4446 : H12AffineFastState.Bounded env4446 := by
  intro p hp
  have h : env4446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4445_4446 : H12AffineEnvironment.transform 17 48921 env4445 = env4446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 48921 env4445 == env4446) = true)

theorem identity4446 : scanCanonicalize (H12AffineFastState.compose env4446 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 13884) := by decide +kernel

theorem selectedBound4446 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4447 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,13884,8494,4356,2341,1024,13884,4096,33,5669,5655,8225,5668,20272,16384,16645,22560,1285,20740,256,20481,22068,5425]

theorem envBound4447 : H12AffineFastState.Bounded env4447 := by
  intro p hp
  have h : env4447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4446_4447 : H12AffineEnvironment.transform 14 13884 env4446 = env4447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13884 env4446 == env4447) = true)

theorem identity4447 : scanCanonicalize (H12AffineFastState.compose env4447 (packedSelected [1,5,8,13,21,24] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4447 : packedSelected [1,5,8,13,21,24] rootPS < 2^1333 := by decide +kernel

def env4448 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,4096,8192,16384,13884,8235,4097,2080,1024,13884,4096,33,5669,5655,8225,5668,20021,16384,16384,22560,1024,20481,5,20481,22068,5172]

theorem envBound4448 : H12AffineFastState.Bounded env4448 := by
  intro p hp
  have h : env4448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4447_4448 : H12AffineEnvironment.transform 7 5 env4447 = env4448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4447 == env4448) = true)

theorem identity4448 : scanCanonicalize (H12AffineFastState.compose env4448 (packedSelected [0,1,2,3,6,7,12,13] rootPS)) = affineNative (2^(11+1) ^^^ 1038) := by decide +kernel

theorem selectedBound4448 : packedSelected [0,1,2,3,6,7,12,13] rootPS < 2^1333 := by decide +kernel

def env4449 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,1038,8192,16384,8754,8235,1039,2080,1024,8754,1038,33,555,537,8225,554,20021,16384,16384,19502,1024,17423,5,17423,16954,58]

theorem envBound4449 : H12AffineFastState.Bounded env4449 := by
  intro p hp
  have h : env4449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4448_4449 : H12AffineEnvironment.transform 11 1038 env4448 = env4449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1038 env4448 == env4449) = true)

theorem identity4449 : scanCanonicalize (H12AffineFastState.compose env4449 (packedSelected [3,5,10,12,18] rootPS)) = affineNative (2^(13+1) ^^^ 1038) := by decide +kernel

theorem selectedBound4449 : packedSelected [3,5,10,12,18] rootPS < 2^1333 := by decide +kernel

def env4450 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,1038,8192,1038,8754,8235,1039,2080,1024,8754,1038,33,555,537,8225,554,2619,1038,1038,2080,1024,1,5,1,1588,58]

theorem envBound4450 : H12AffineFastState.Bounded env4450 := by
  intro p hp
  have h : env4450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4449_4450 : H12AffineEnvironment.transform 13 1038 env4449 = env4450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1038 env4449 == env4450) = true)

theorem identity4450 : scanCanonicalize (H12AffineFastState.compose env4450 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound4450 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4451 : List Nat := [2,4,8,16,32,16,40,5,512,1024,523,1038,8192,1038,8754,8235,1039,555,1024,8754,1038,33,555,537,8225,554,48,1038,1038,555,1024,1,5,1,1588,58]

theorem envBound4451 : H12AffineFastState.Bounded env4451 := by
  intro p hp
  have h : env4451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4450_4451 : H12AffineEnvironment.transform 10 523 env4450 = env4451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env4450 == env4451) = true)

theorem identity4451 : scanCanonicalize (H12AffineFastState.compose env4451 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 58) := by decide +kernel

theorem selectedBound4451 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env4452 : List Nat := [2,4,8,16,32,16,40,5,58,1024,49,1038,8192,1038,8200,8235,1039,17,1024,8200,1038,33,17,35,8225,16,48,1038,1038,17,1024,1,5,1,1038,58]

theorem envBound4452 : H12AffineFastState.Bounded env4452 := by
  intro p hp
  have h : env4452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4451_4452 : H12AffineEnvironment.transform 8 58 env4451 = env4452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 58 env4451 == env4452) = true)

theorem identity4452 : scanCanonicalize (H12AffineFastState.compose env4452 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 50) := by decide +kernel

theorem selectedBound4452 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4453 : List Nat := [2,4,8,16,32,16,40,5,58,1024,49,1038,50,1038,58,25,1039,17,1024,58,1038,33,17,35,19,16,48,1038,1038,17,1024,1,5,1,1038,58]

theorem envBound4453 : H12AffineFastState.Bounded env4453 := by
  intro p hp
  have h : env4453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4452_4453 : H12AffineEnvironment.transform 12 50 env4452 = env4453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 50 env4452 == env4453) = true)

theorem identity4453 : scanCanonicalize (H12AffineFastState.compose env4453 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound4453 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4454 : List Nat := [2,4,8,0,32,0,40,5,42,1024,33,1038,34,1038,42,9,1039,1,1024,42,1038,33,1,35,3,0,32,1038,1038,1,1024,1,5,1,1038,42]

theorem envBound4454 : H12AffineFastState.Bounded env4454 := by
  intro p hp
  have h : env4454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4453_4454 : H12AffineEnvironment.transform 3 0 env4453 = env4454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4453 == env4454) = true)

theorem identity4454 : scanCanonicalize (H12AffineFastState.compose env4454 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4454 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env4455 : List Nat := [2,4,3,0,32,0,35,5,33,1024,33,1029,34,1029,33,2,1028,1,1024,33,1029,33,1,35,3,0,32,1029,1029,1,1024,1,5,1,1029,33]

theorem envBound4455 : H12AffineFastState.Bounded env4455 := by
  intro p hp
  have h : env4455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4454_4455 : H12AffineEnvironment.transform 2 3 env4454 = env4455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4454 == env4455) = true)

def env4456 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,16384,32768,8494,4357,262144,1024,32768,4096,32,270080,41003,8224,270081,323624,16384,16644,22560,1285,323100,256,20481,286480,269333]

theorem envBound4456 : H12AffineFastState.Bounded env4456 := by
  intro p hp
  have h : env4456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4444_4456 : H12AffineEnvironment.transform 6 41 env4444 = env4456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4444 == env4456) = true)

theorem identity4456 : scanCanonicalize (H12AffineFastState.compose env4456 (packedSelected [3,9,10,11,13,18,21,22,23,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 60956) := by decide +kernel

theorem selectedBound4456 : packedSelected [3,9,10,11,13,18,21,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env4457 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,16384,32768,8494,4357,60956,1024,32768,4096,32,61724,41003,8224,61725,7732,16384,16644,22560,1285,0,256,20481,45324,61961]

theorem envBound4457 : H12AffineFastState.Bounded env4457 := by
  intro p hp
  have h : env4457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4456_4457 : H12AffineEnvironment.transform 17 60956 env4456 = env4457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 60956 env4456 == env4457) = true)

theorem identity4457 : scanCanonicalize (H12AffineFastState.compose env4457 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 13885) := by decide +kernel

theorem selectedBound4457 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env4458 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,16384,13885,8494,4357,22561,1024,13885,4096,32,18209,5654,8224,18208,7732,16384,16644,22560,1285,0,256,20481,1841,17460]

theorem envBound4458 : H12AffineFastState.Bounded env4458 := by
  intro p hp
  have h : env4458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4457_4458 : H12AffineEnvironment.transform 14 13885 env4457 = env4458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13885 env4457 == env4458) = true)

theorem identity4458 : scanCanonicalize (H12AffineFastState.compose env4458 (packedSelected [4,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound4458 : packedSelected [4,20,22] rootPS < 2^1333 := by decide +kernel

def env4459 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1589,8192,16384,8200,8494,1840,19988,1024,8200,1589,32,18209,35,8224,18208,2049,16384,16644,19989,1285,0,256,17972,1841,17460]

theorem envBound4459 : H12AffineFastState.Bounded env4459 := by
  intro p hp
  have h : env4459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4458_4459 : H12AffineEnvironment.transform 11 1589 env4458 = env4459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env4458 == env4459) = true)

theorem identity4459 : scanCanonicalize (H12AffineFastState.compose env4459 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4459 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env4460 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,1589,8192,16384,8200,8235,1589,19988,1024,8200,1589,32,17956,35,8224,17957,2049,16384,16385,19989,1024,0,5,17972,1588,17460]

theorem envBound4460 : H12AffineFastState.Bounded env4460 := by
  intro p hp
  have h : env4460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4459_4460 : H12AffineEnvironment.transform 7 5 env4459 = env4460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4459 == env4460) = true)

theorem identity4460 : scanCanonicalize (H12AffineFastState.compose env4460 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1589) := by decide +kernel

theorem selectedBound4460 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4461 : List Nat := [2,4,8,16,32,16,41,5,512,1024,1589,1589,8192,16384,8200,8235,1589,16417,1024,8200,1589,32,17956,35,8224,17957,1588,16384,16385,16416,1024,0,5,17972,1588,17460]

theorem envBound4461 : H12AffineFastState.Bounded env4461 := by
  intro p hp
  have h : env4461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4460_4461 : H12AffineEnvironment.transform 10 1589 env4460 = env4461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1589 env4460 == env4461) = true)

theorem identity4461 : scanCanonicalize (H12AffineFastState.compose env4461 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 1550) := by decide +kernel

theorem selectedBound4461 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4462 : List Nat := [2,4,8,16,32,16,41,5,512,1024,1589,1589,8192,1550,8200,8235,1589,1583,1024,8200,1589,32,42,35,8224,43,1588,1550,1551,1582,1024,0,5,58,1588,570]

theorem envBound4462 : H12AffineFastState.Bounded env4462 := by
  intro p hp
  have h : env4462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4461_4462 : H12AffineEnvironment.transform 13 1550 env4461 = env4462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1550 env4461 == env4462) = true)

theorem identity4462 : scanCanonicalize (H12AffineFastState.compose env4462 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(12+1) ^^^ 1063) := by decide +kernel

theorem selectedBound4462 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env4463 : List Nat := [2,4,8,16,32,16,41,5,512,1024,1589,1589,1063,1550,1071,1036,1589,1583,1024,1071,1589,32,42,35,1031,43,1588,1550,1551,1582,1024,0,5,58,1588,570]

theorem envBound4463 : H12AffineFastState.Bounded env4463 := by
  intro p hp
  have h : env4463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4462_4463 : H12AffineEnvironment.transform 12 1063 env4462 = env4463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1063 env4462 == env4463) = true)

theorem identity4463 : scanCanonicalize (H12AffineFastState.compose env4463 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound4463 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env4464 : List Nat := [2,4,8,16,26,16,19,5,512,1024,1551,1551,1053,1550,1045,1036,1551,1557,1024,1045,1551,26,16,25,1031,17,1550,1550,1551,1556,1024,0,5,0,1550,512]

theorem envBound4464 : H12AffineFastState.Bounded env4464 := by
  intro p hp
  have h : env4464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4463_4464 : H12AffineEnvironment.transform 4 26 env4463 = env4464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env4463 == env4464) = true)

theorem identity4464 : scanCanonicalize (H12AffineFastState.compose env4464 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound4464 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env4465 : List Nat := [2,4,8,16,26,16,19,5,0,1024,1039,1039,1053,1038,1045,1036,1039,1045,1024,1045,1039,26,16,25,1031,17,1038,1038,1039,1044,1024,0,5,0,1038,0]

theorem envBound4465 : H12AffineFastState.Bounded env4465 := by
  intro p hp
  have h : env4465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4464_4465 : H12AffineEnvironment.transform 8 0 env4464 = env4465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env4464 == env4465) = true)

theorem identity4465 : scanCanonicalize (H12AffineFastState.compose env4465 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound4465 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4466 : List Nat := [2,4,8,16,26,16,19,5,0,15,0,0,18,1,26,3,0,26,15,26,0,26,16,25,8,17,1,1,0,27,15,0,5,0,1,0]

theorem envBound4466 : H12AffineFastState.Bounded env4466 := by
  intro p hp
  have h : env4466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4465_4466 : H12AffineEnvironment.transform 9 15 env4465 = env4466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env4465 == env4466) = true)

def env4467 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8494,4525,262144,1024,32768,4096,4194304,8388608,41003,8329,8388608,323712,16384,16812,22561,1285,12644668,256,20480,8405177,8389565]

theorem envBound4467 : H12AffineFastState.Bounded env4467 := by
  intro p hp
  have h : env4467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4414_4467 : H12AffineEnvironment.transform 5 17 env4414 = env4467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4414 == env4467) = true)

theorem identity4467 : scanCanonicalize (H12AffineFastState.compose env4467 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound4467 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4468 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8494,4525,262144,1024,32768,4096,4194304,445,41003,8329,445,323712,16384,16812,22561,1285,4255873,256,20480,16644,512]

theorem envBound4468 : H12AffineFastState.Bounded env4468 := by
  intro p hp
  have h : env4468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4467_4468 : H12AffineEnvironment.transform 22 445 env4467 = env4468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env4467 == env4468) = true)

theorem identity4468 : scanCanonicalize (H12AffineFastState.compose env4468 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound4468 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4469 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8494,4525,262144,1024,32768,4096,41348,445,41003,8329,445,323712,16384,16812,22561,1285,20741,256,20480,16644,512]

theorem envBound4469 : H12AffineFastState.Bounded env4469 := by
  intro p hp
  have h : env4469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4468_4469 : H12AffineEnvironment.transform 21 41348 env4468 = env4469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env4468 == env4469) = true)

theorem identity4469 : scanCanonicalize (H12AffineFastState.compose env4469 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13972) := by decide +kernel

theorem selectedBound4469 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4470 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,13972,8494,4525,262144,1024,13972,4096,5904,445,5823,8329,445,280084,16384,16812,22561,1285,20741,256,20480,16644,512]

theorem envBound4470 : H12AffineFastState.Bounded env4470 := by
  intro p hp
  have h : env4470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4469_4470 : H12AffineEnvironment.transform 14 13972 env4469 = env4470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13972 env4469 == env4470) = true)

theorem identity4470 : scanCanonicalize (H12AffineFastState.compose env4470 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4524) := by decide +kernel

theorem selectedBound4470 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4471 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4524,13972,8494,4525,262144,1024,13972,4096,5904,445,5823,8329,445,268216,4524,4096,2445,1285,169,256,428,4264,512]

theorem envBound4471 : H12AffineFastState.Bounded env4471 := by
  intro p hp
  have h : env4471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4470_4471 : H12AffineEnvironment.transform 13 4524 env4470 = env4471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4524 env4470 == env4471) = true)

theorem identity4471 : scanCanonicalize (H12AffineFastState.compose env4471 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 7868) := by decide +kernel

theorem selectedBound4471 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env4472 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4524,13972,8494,4525,7868,1024,13972,4096,5904,445,5823,8329,445,2308,4524,4096,2445,1285,169,256,428,4264,512]

theorem envBound4472 : H12AffineFastState.Bounded env4472 := by
  intro p hp
  have h : env4472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4471_4472 : H12AffineEnvironment.transform 17 7868 env4471 = env4472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7868 env4471 == env4472) = true)

theorem identity4472 : scanCanonicalize (H12AffineFastState.compose env4472 (packedSelected [3,5,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4472 : packedSelected [3,5,8,28] rootPS < 2^1333 := by decide +kernel

def env4473 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,4096,8192,4264,13972,8234,4265,7868,1024,13972,4096,5652,185,5823,8329,185,2048,4264,4096,2185,1025,169,4,168,4264,512]

theorem envBound4473 : H12AffineFastState.Bounded env4473 := by
  intro p hp
  have h : env4473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4472_4473 : H12AffineEnvironment.transform 7 4 env4472 = env4473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4472 == env4473) = true)

theorem identity4473 : scanCanonicalize (H12AffineFastState.compose env4473 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound4473 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env4474 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,1588,8192,1692,8352,8234,1693,2184,1024,8352,1588,32,185,139,8329,185,2048,1692,1588,2185,1025,169,4,168,1692,512]

theorem envBound4474 : H12AffineFastState.Bounded env4474 := by
  intro p hp
  have h : env4474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4473_4474 : H12AffineEnvironment.transform 11 1588 env4473 = env4474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env4473 == env4474) = true)

theorem identity4474 : scanCanonicalize (H12AffineFastState.compose env4474 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound4474 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env4475 : List Nat := [2,4,8,16,32,17,128,4,512,1024,538,1588,8192,1692,8352,8234,1693,658,1024,8352,1588,32,185,139,8329,185,538,1692,1588,659,1025,169,4,168,1692,512]

theorem envBound4475 : H12AffineFastState.Bounded env4475 := by
  intro p hp
  have h : env4475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4474_4475 : H12AffineEnvironment.transform 10 538 env4474 = env4475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env4474 == env4475) = true)

theorem identity4475 : scanCanonicalize (H12AffineFastState.compose env4475 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound4475 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env4476 : List Nat := [2,4,8,16,32,17,128,4,512,1024,538,1588,41,1692,137,3,1693,658,1024,137,1588,32,185,139,160,185,538,1692,1588,659,1025,169,4,168,1692,512]

theorem envBound4476 : H12AffineFastState.Bounded env4476 := by
  intro p hp
  have h : env4476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4475_4476 : H12AffineEnvironment.transform 12 41 env4475 = env4476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env4475 == env4476) = true)

theorem identity4476 : scanCanonicalize (H12AffineFastState.compose env4476 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4476 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env4477 : List Nat := [2,4,8,16,32,17,41,4,512,1024,538,1588,41,1589,32,3,1588,571,1024,32,1588,32,16,34,9,16,538,1589,1588,570,1025,0,4,1,1589,512]

theorem envBound4477 : H12AffineFastState.Bounded env4477 := by
  intro p hp
  have h : env4477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4476_4477 : H12AffineEnvironment.transform 6 41 env4476 = env4477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4476 == env4477) = true)

theorem identity4477 : scanCanonicalize (H12AffineFastState.compose env4477 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound4477 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4478 : List Nat := [2,4,8,16,11,17,2,4,512,1024,538,1567,2,1566,11,3,1567,528,1024,11,1567,11,16,9,9,16,538,1566,1567,529,1025,0,4,1,1566,512]

theorem envBound4478 : H12AffineFastState.Bounded env4478 := by
  intro p hp
  have h : env4478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4477_4478 : H12AffineEnvironment.transform 4 11 env4477 = env4478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env4477 == env4478) = true)

theorem identity4478 : scanCanonicalize (H12AffineFastState.compose env4478 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound4478 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4479 : List Nat := [2,4,8,11,11,10,2,4,512,1024,513,1540,2,1541,11,3,1540,523,1024,11,1540,11,11,9,9,11,513,1541,1540,522,1025,0,4,1,1541,512]

theorem envBound4479 : H12AffineFastState.Bounded env4479 := by
  intro p hp
  have h : env4479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4478_4479 : H12AffineEnvironment.transform 3 11 env4478 = env4479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env4478 == env4479) = true)

theorem identity4479 : scanCanonicalize (H12AffineFastState.compose env4479 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4479 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env4480 : List Nat := [2,4,3,0,0,1,2,4,512,1024,513,1540,2,1541,0,3,1540,512,1024,0,1540,0,0,2,2,0,513,1541,1540,513,1025,0,4,1,1541,512]

theorem envBound4480 : H12AffineFastState.Bounded env4480 := by
  intro p hp
  have h : env4480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4479_4480 : H12AffineEnvironment.transform 2 3 env4479 = env4480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4479 == env4480) = true)

theorem identity4480 : scanCanonicalize (H12AffineFastState.compose env4480 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound4480 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4481 : List Nat := [2,4,3,0,0,1,2,4,0,1024,1,1028,2,1029,0,3,1028,0,1024,0,1028,0,0,2,2,0,1,1029,1028,1,1025,0,4,1,1029,0]

theorem envBound4481 : H12AffineFastState.Bounded env4481 := by
  intro p hp
  have h : env4481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4480_4481 : H12AffineEnvironment.transform 8 0 env4480 = env4481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env4480 == env4481) = true)

def leafEnv4481 : List Nat := [2,4,3,0,0,1,2,4,0,1024,1,1028,2,1029,0,3,1028,0,1024,0,1028,0,0,2,1025,2,1,0,1,1029,1028,1,1025,0,4,1,4,2,1029,0,1,1029,0]

def active4481 : List Nat := [0,1,9]

def tree4481 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4481 : H12WitnessSearch.Good tree4481 := H12GlobalWitnessIndex.good

theorem leafIdentity4481 : H12AffineFastState.composeSystem env4481 rootObs = leafEnv4481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4481 rootObs == leafEnv4481) = true)

theorem terminalChecked4481 : H12PackedTerminal.terminalCheckFast leafEnv4481 active4481 tree4481 = true := by decide +kernel

def env4482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4096,4194304,8388608,41003,8329,8388688,323792,16384,16893,22641,74794,12644668,257,20560,8479127,8389613]

theorem envBound4482 : H12AffineFastState.Bounded env4482 := by
  intro p hp
  have h : env4482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4412_4482 : H12AffineEnvironment.transform 18 1025 env4412 = env4482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env4412 == env4482) = true)

theorem identity4482 : scanCanonicalize (H12AffineFastState.compose env4482 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 91182) := by decide +kernel

theorem selectedBound4482 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4483 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4096,4194304,91182,41003,8329,91262,323792,16384,16893,22641,74794,4298002,257,20560,1465,92099]

theorem envBound4483 : H12AffineFastState.Bounded env4483 := by
  intro p hp
  have h : env4483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4482_4483 : H12AffineEnvironment.transform 22 91182 env4482 = env4483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 91182 env4482 == env4483) = true)

def env4484 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,4194304,91182,41003,8329,91182,323712,16384,16813,22561,74794,4298002,257,20480,1465,92051]

theorem envBound4484 : H12AffineFastState.Bounded env4484 := by
  intro p hp
  have h : env4484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4483_4484 : H12AffineEnvironment.transform 5 16 env4483 = env4484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4483 == env4484) = true)

theorem identity4484 : scanCanonicalize (H12AffineFastState.compose env4484 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 26003) := by decide +kernel

theorem selectedBound4484 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4485 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,26003,4524,262144,1025,32768,4096,4194304,445,41003,8329,445,323712,16384,16813,22561,16825,4255873,257,20480,1465,512]

theorem envBound4485 : H12AffineFastState.Bounded env4485 := by
  intro p hp
  have h : env4485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4484_4485 : H12AffineEnvironment.transform 15 26003 env4484 = env4485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26003 env4484 == env4485) = true)

theorem identity4485 : scanCanonicalize (H12AffineFastState.compose env4485 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound4485 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4486 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,26003,4524,262144,1025,32768,4096,41349,445,41003,8329,445,323712,16384,16813,22561,16825,20740,257,20480,1465,512]

theorem envBound4486 : H12AffineFastState.Bounded env4486 := by
  intro p hp
  have h : env4486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4485_4486 : H12AffineEnvironment.transform 21 41349 env4485 = env4486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env4485 == env4486) = true)

theorem identity4486 : scanCanonicalize (H12AffineFastState.compose env4486 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29225) := by decide +kernel

theorem selectedBound4486 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4487 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29225,26003,4524,262144,1025,29225,4096,21420,445,20994,8329,445,262825,16384,16813,22561,16825,20740,257,20480,1465,512]

theorem envBound4487 : H12AffineFastState.Bounded env4487 := by
  intro p hp
  have h : env4487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4486_4487 : H12AffineEnvironment.transform 14 29225 env4486 = env4487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29225 env4486 == env4487) = true)

theorem identity4487 : scanCanonicalize (H12AffineFastState.compose env4487 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound4487 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4488 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,16384,26424,26003,1213,262144,1025,26424,1297,18109,445,18195,8329,445,262825,16384,16813,19760,16825,17429,257,17681,1465,512]

theorem envBound4488 : H12AffineFastState.Bounded env4488 := by
  intro p hp
  have h : env4488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4487_4488 : H12AffineEnvironment.transform 11 1297 env4487 = env4488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env4487 == env4488) = true)

theorem identity4488 : scanCanonicalize (H12AffineFastState.compose env4488 (packedSelected [11,12,15,18,23,24,28,32] rootPS)) = affineNative (2^(13+1) ^^^ 1693) := by decide +kernel

theorem selectedBound4488 : packedSelected [11,12,15,18,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env4489 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1693,8613,8974,1213,262144,1025,8613,1297,32,445,398,8329,445,262825,1693,1840,2989,1828,648,257,908,1465,512]

theorem envBound4489 : H12AffineFastState.Bounded env4489 := by
  intro p hp
  have h : env4489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4488_4489 : H12AffineEnvironment.transform 13 1693 env4488 = env4489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1693 env4488 == env4489) = true)

theorem identity4489 : scanCanonicalize (H12AffineFastState.compose env4489 (packedSelected [8,10,12,15,18,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound4489 : packedSelected [8,10,12,15,18,23,24] rootPS < 2^1333 := by decide +kernel

def env4490 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1212,8192,1693,8200,8867,1213,262144,1025,8200,1212,32,16,35,8329,16,262825,1693,1693,2560,1673,648,172,545,1044,512]

theorem envBound4490 : H12AffineFastState.Bounded env4490 := by
  intro p hp
  have h : env4490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4489_4490 : H12AffineEnvironment.transform 7 173 env4489 = env4490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env4489 == env4490) = true)

theorem identity4490 : scanCanonicalize (H12AffineFastState.compose env4490 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 1582) := by decide +kernel

theorem selectedBound4490 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4491 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1212,8192,1693,8200,8867,1213,1582,1025,8200,1212,32,16,35,8329,16,1159,1693,1693,2560,1673,648,172,545,1044,512]

theorem envBound4491 : H12AffineFastState.Bounded env4491 := by
  intro p hp
  have h : env4491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4490_4491 : H12AffineEnvironment.transform 17 1582 env4490 = env4491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1582 env4490 == env4491) = true)

def env4492 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4096,4194304,91182,41003,8329,91183,323713,16384,16812,22560,74794,4298002,257,20481,1465,92050]

theorem envBound4492 : H12AffineFastState.Bounded env4492 := by
  intro p hp
  have h : env4492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4483_4492 : H12AffineEnvironment.transform 5 17 env4483 = env4492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4483 == env4492) = true)

def env4493 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4096,41088,91182,41003,8329,91183,323713,16384,16812,22560,74794,79250,257,20481,1465,92050]

theorem envBound4493 : H12AffineFastState.Bounded env4493 := by
  intro p hp
  have h : env4493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4492_4493 : H12AffineEnvironment.transform 21 41088 env4492 = env4493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env4492 == env4493) = true)

theorem identity4493 : scanCanonicalize (H12AffineFastState.compose env4493 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 25751) := by decide +kernel

theorem selectedBound4493 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4494 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,25751,4525,262144,1025,32768,4096,41088,185,41003,8329,184,323713,16384,16812,22560,16573,20741,257,20481,1465,773]

theorem envBound4494 : H12AffineFastState.Bounded env4494 := by
  intro p hp
  have h : env4494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4493_4494 : H12AffineEnvironment.transform 15 25751 env4493 = env4494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25751 env4493 == env4494) = true)

def env4495 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1464,8192,16384,32768,25751,1045,262144,1025,32768,1464,41088,185,41003,8329,184,320825,16384,16812,19864,16573,17597,257,17849,1465,773]

theorem envBound4495 : H12AffineFastState.Bounded env4495 := by
  intro p hp
  have h : env4495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4494_4495 : H12AffineEnvironment.transform 11 1464 env4494 = env4495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1464 env4494 == env4495) = true)

theorem identity4495 : scanCanonicalize (H12AffineFastState.compose env4495 (packedSelected [13,21] rootPS)) = affineNative (2^(14+1) ^^^ 26032) := by decide +kernel

theorem selectedBound4495 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env4496 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1464,8192,16384,26032,25751,1045,262144,1025,26032,1464,17712,185,17819,8329,184,262281,16384,16812,19864,16573,17597,257,17849,1465,773]

theorem envBound4496 : H12AffineFastState.Bounded env4496 := by
  intro p hp
  have h : env4496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4495_4496 : H12AffineEnvironment.transform 14 26032 env4495 = env4496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26032 env4495 == env4496) = true)

theorem identity4496 : scanCanonicalize (H12AffineFastState.compose env4496 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 19761) := by decide +kernel

theorem selectedBound4496 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4497 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1464,8192,16384,26032,25751,1045,19761,1025,26032,1464,17712,185,17819,8329,184,19896,16384,16812,19864,16573,17597,257,17849,1465,773]

theorem envBound4497 : H12AffineFastState.Bounded env4497 := by
  intro p hp
  have h : env4497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4496_4497 : H12AffineEnvironment.transform 17 19761 env4496 = env4497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19761 env4496 == env4497) = true)

theorem identity4497 : scanCanonicalize (H12AffineFastState.compose env4497 (packedSelected [3,5,10,12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound4497 : packedSelected [3,5,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env4498 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1464,9,16384,17849,17566,1045,19761,1025,17849,1464,17712,185,17819,128,184,19896,16384,16812,19864,16573,17597,257,17849,1465,773]

theorem envBound4498 : H12AffineFastState.Bounded env4498 := by
  intro p hp
  have h : env4498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4497_4498 : H12AffineEnvironment.transform 12 9 env4497 = env4498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env4497 == env4498) = true)

theorem identity4498 : scanCanonicalize (H12AffineFastState.compose env4498 (packedSelected [1,2,5,6,10,11,13,18] rootPS)) = affineNative (2^(10+1) ^^^ 798) := by decide +kernel

theorem selectedBound4498 : packedSelected [1,2,5,6,10,11,13,18] rootPS < 2^1333 := by decide +kernel

def env4499 : List Nat := [2,4,8,16,32,17,128,256,512,1024,798,1464,9,16384,17849,17566,1045,17967,1025,17849,1464,17712,185,17819,128,184,18086,16384,16812,18054,16573,17597,257,17849,1465,773]

theorem envBound4499 : H12AffineFastState.Bounded env4499 := by
  intro p hp
  have h : env4499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4498_4499 : H12AffineEnvironment.transform 10 798 env4498 = env4499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 798 env4498 == env4499) = true)

theorem identity4499 : scanCanonicalize (H12AffineFastState.compose env4499 (packedSelected [0,7,20] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound4499 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4500 : List Nat := [2,4,8,16,32,17,128,256,32,1024,318,1464,9,16384,17849,17566,1045,17423,1025,17849,1464,17712,185,17819,128,184,17542,16384,16812,17574,16573,17597,257,17849,1465,293]

theorem envBound4500 : H12AffineFastState.Bounded env4500 := by
  intro p hp
  have h : env4500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4499_4500 : H12AffineEnvironment.transform 8 32 env4499 = env4500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env4499 == env4500) = true)

theorem identity4500 : scanCanonicalize (H12AffineFastState.compose env4500 (packedSelected [0,2,4,6,7,9,11,23] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound4500 : packedSelected [0,2,4,6,7,9,11,23] rootPS < 2^1333 := by decide +kernel

def env4501 : List Nat := [2,4,8,16,32,17,128,173,32,1024,147,1045,9,16384,17428,17566,1045,17423,1025,17428,1045,17565,185,17462,128,184,17542,16384,16385,17574,16573,17597,172,17428,1044,136]

theorem envBound4501 : H12AffineFastState.Bounded env4501 := by
  intro p hp
  have h : env4501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4500_4501 : H12AffineEnvironment.transform 7 173 env4500 = env4501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env4500 == env4501) = true)

theorem identity4501 : scanCanonicalize (H12AffineFastState.compose env4501 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 1028) := by decide +kernel

theorem selectedBound4501 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4502 : List Nat := [2,4,8,16,32,17,128,173,32,1024,147,1045,9,1028,16,154,1045,11,1025,16,1045,153,185,50,128,184,130,1028,1029,162,1209,185,172,16,1044,136]

theorem envBound4502 : H12AffineFastState.Bounded env4502 := by
  intro p hp
  have h : env4502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4501_4502 : H12AffineEnvironment.transform 13 1028 env4501 = env4502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1028 env4501 == env4502) = true)

theorem identity4502 : scanCanonicalize (H12AffineFastState.compose env4502 (packedSelected [2,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound4502 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env4503 : List Nat := [2,4,8,16,32,17,128,173,32,52,147,33,9,48,16,154,33,11,53,16,33,153,185,50,128,184,130,48,49,162,141,185,172,16,32,136]

theorem envBound4503 : H12AffineFastState.Bounded env4503 := by
  intro p hp
  have h : env4503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4502_4503 : H12AffineEnvironment.transform 9 52 env4502 = env4503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env4502 == env4503) = true)

theorem identity4503 : scanCanonicalize (H12AffineFastState.compose env4503 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound4503 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4504 : List Nat := [2,4,8,16,27,17,128,150,27,15,147,26,9,11,16,154,26,11,14,16,26,153,130,9,128,131,130,11,10,153,141,130,151,16,27,136]

theorem envBound4504 : H12AffineFastState.Bounded env4504 := by
  intro p hp
  have h : env4504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4503_4504 : H12AffineEnvironment.transform 4 27 env4503 = env4504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env4503 == env4504) = true)

theorem identity4504 : scanCanonicalize (H12AffineFastState.compose env4504 (packedSelected [2,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound4504 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env4505 : List Nat := [2,4,2,16,17,17,128,150,17,5,147,16,3,1,16,144,16,1,4,16,16,147,130,3,128,131,130,1,0,147,135,130,151,16,17,130]

theorem envBound4505 : H12AffineFastState.Bounded env4505 := by
  intro p hp
  have h : env4505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4504_4505 : H12AffineEnvironment.transform 2 2 env4504 = env4505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env4504 == env4505) = true)

theorem identity4505 : scanCanonicalize (H12AffineFastState.compose env4505 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound4505 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env4506 : List Nat := [2,4,2,16,17,17,19,5,17,5,0,16,3,1,16,3,16,1,4,16,16,0,17,3,19,16,17,1,0,0,20,17,4,16,17,17]

theorem envBound4506 : H12AffineFastState.Bounded env4506 := by
  intro p hp
  have h : env4506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4505_4506 : H12AffineEnvironment.transform 6 19 env4505 = env4506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env4505 == env4506) = true)

def env4507 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1465,8192,16384,32768,25751,1044,262144,1025,32768,1465,41088,185,41003,8329,184,320824,16384,16812,19865,16573,17596,257,17848,1465,773]

theorem envBound4507 : H12AffineFastState.Bounded env4507 := by
  intro p hp
  have h : env4507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4494_4507 : H12AffineEnvironment.transform 11 1465 env4494 = env4507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1465 env4494 == env4507) = true)

theorem identity4507 : scanCanonicalize (H12AffineFastState.compose env4507 (packedSelected [7,20,27] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4507 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env4508 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1296,8192,16384,32768,25662,1044,262144,1025,32768,1296,41001,16,41003,8224,17,320824,16384,16645,19760,16404,17429,257,17681,1296,773]

theorem envBound4508 : H12AffineFastState.Bounded env4508 := by
  intro p hp
  have h : env4508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4507_4508 : H12AffineEnvironment.transform 6 41 env4507 = env4508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4507 == env4508) = true)

theorem identity4508 : scanCanonicalize (H12AffineFastState.compose env4508 (packedSelected [5,6,8,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 42023) := by decide +kernel

theorem selectedBound4508 : packedSelected [5,6,8,13,17] rootPS < 2^1333 := by decide +kernel

def env4509 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1296,8192,16384,32768,25662,1044,42023,1025,32768,1296,41001,16,41003,8224,17,16671,16384,16645,19760,16404,17429,257,17681,1296,773]

theorem envBound4509 : H12AffineFastState.Bounded env4509 := by
  intro p hp
  have h : env4509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4508_4509 : H12AffineEnvironment.transform 17 42023 env4508 = env4509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 42023 env4508 == env4509) = true)

theorem identity4509 : scanCanonicalize (H12AffineFastState.compose env4509 (packedSelected [2,5,8,11,18] rootPS)) = affineNative (2^(14+1) ^^^ 25913) := by decide +kernel

theorem selectedBound4509 : packedSelected [2,5,8,11,18] rootPS < 2^1333 := by decide +kernel

def env4510 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1296,8192,16384,25913,25662,1044,16670,1025,25913,1296,17680,16,17682,8224,17,16671,16384,16645,19760,16404,17429,257,17681,1296,773]

theorem envBound4510 : H12AffineFastState.Bounded env4510 := by
  intro p hp
  have h : env4510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4509_4510 : H12AffineEnvironment.transform 14 25913 env4509 = env4510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25913 env4509 == env4510) = true)

theorem identity4510 : scanCanonicalize (H12AffineFastState.compose env4510 (packedSelected [1,2,3,10,11,12,23] rootPS)) = affineNative (2^(13+1) ^^^ 11292) := by decide +kernel

theorem selectedBound4510 : packedSelected [1,2,3,10,11,12,23] rootPS < 2^1333 := by decide +kernel

def env4511 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1296,8192,11292,2341,2082,1044,11522,1025,2341,1296,10508,16,10510,8224,17,11523,11292,11545,8492,11272,10249,257,10509,1296,773]

theorem envBound4511 : H12AffineFastState.Bounded env4511 := by
  intro p hp
  have h : env4511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4510_4511 : H12AffineEnvironment.transform 13 11292 env4510 = env4511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11292 env4510 == env4511) = true)

theorem identity4511 : scanCanonicalize (H12AffineFastState.compose env4511 (packedSelected [3,4,5,6,7,11,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4511 : packedSelected [3,4,5,6,7,11,12,13] rootPS < 2^1333 := by decide +kernel

def env4512 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,1044,8192,11292,2081,2082,1044,11270,1025,2081,1044,10248,16,10250,8224,17,11271,11292,11293,8232,11272,10249,5,10249,1044,513]

theorem envBound4512 : H12AffineFastState.Bounded env4512 := by
  intro p hp
  have h : env4512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4511_4512 : H12AffineEnvironment.transform 7 4 env4511 = env4512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4511 == env4512) = true)

theorem identity4512 : scanCanonicalize (H12AffineFastState.compose env4512 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound4512 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4513 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,1044,2088,1076,2081,2082,1044,1070,1025,2081,1044,32,16,34,2056,17,1071,1076,1077,2048,1056,33,5,33,1044,513]

theorem envBound4513 : H12AffineFastState.Bounded env4513 := by
  intro p hp
  have h : env4513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4512_4513 : H12AffineEnvironment.transform 12 2088 env4512 = env4513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env4512 == env4513) = true)

theorem identity4513 : scanCanonicalize (H12AffineFastState.compose env4513 (packedSelected [5] rootPS)) = affineNative (2^(9+1) ^^^ 32) := by decide +kernel

theorem selectedBound4513 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env4514 : List Nat := [2,4,8,16,32,17,41,4,512,32,2048,52,2088,20,2081,2082,52,14,33,2081,52,32,16,34,2056,17,15,20,21,2048,0,33,5,33,52,513]

theorem envBound4514 : H12AffineFastState.Bounded env4514 := by
  intro p hp
  have h : env4514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4513_4514 : H12AffineEnvironment.transform 9 32 env4513 = env4514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 32 env4513 == env4514) = true)

theorem identity4514 : scanCanonicalize (H12AffineFastState.compose env4514 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound4514 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env4515 : List Nat := [2,4,8,16,32,17,41,4,32,32,2048,52,2088,20,2081,2082,52,14,33,2081,52,32,16,34,2056,17,15,20,21,2048,0,33,5,33,52,33]

theorem envBound4515 : H12AffineFastState.Bounded env4515 := by
  intro p hp
  have h : env4515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4514_4515 : H12AffineEnvironment.transform 8 32 env4514 = env4515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env4514 == env4515) = true)

theorem identity4515 : scanCanonicalize (H12AffineFastState.compose env4515 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound4515 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4516 : List Nat := [2,4,6,16,32,17,39,4,32,32,2048,52,2086,20,2081,2082,52,0,33,2081,52,32,16,34,2054,17,1,20,21,2048,0,33,5,33,52,33]

theorem envBound4516 : H12AffineFastState.Bounded env4516 := by
  intro p hp
  have h : env4516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4515_4516 : H12AffineEnvironment.transform 2 6 env4515 = env4516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env4515 == env4516) = true)

theorem identity4516 : scanCanonicalize (H12AffineFastState.compose env4516 (packedSelected [1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 20) := by decide +kernel

theorem selectedBound4516 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env4517 : List Nat := [2,4,6,16,20,17,19,4,20,20,2048,0,2066,20,2069,2070,0,0,21,2069,0,20,16,22,2054,17,1,20,21,2048,0,21,5,21,0,21]

theorem envBound4517 : H12AffineFastState.Bounded env4517 := by
  intro p hp
  have h : env4517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4516_4517 : H12AffineEnvironment.transform 4 20 env4516 = env4517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 20 env4516 == env4517) = true)

theorem identity4517 : scanCanonicalize (H12AffineFastState.compose env4517 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 21) := by decide +kernel

theorem selectedBound4517 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env4518 : List Nat := [2,4,6,16,20,17,19,4,20,20,21,0,7,20,0,3,0,0,21,0,0,20,16,22,19,17,1,20,21,21,0,21,5,21,0,21]

theorem envBound4518 : H12AffineFastState.Bounded env4518 := by
  intro p hp
  have h : env4518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4517_4518 : H12AffineEnvironment.transform 10 21 env4517 = env4518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 21 env4517 == env4518) = true)

theorem identity4518 : scanCanonicalize (H12AffineFastState.compose env4518 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound4518 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env4519 : List Nat := [2,4,6,0,4,1,3,4,4,4,5,0,7,4,0,3,0,0,5,0,0,4,0,6,3,1,1,4,5,5,0,5,5,5,0,5]

theorem envBound4519 : H12AffineFastState.Bounded env4519 := by
  intro p hp
  have h : env4519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4518_4519 : H12AffineEnvironment.transform 3 0 env4518 = env4519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4518 == env4519) = true)

def leafEnv4519 : List Nat := [2,4,6,0,4,1,3,4,4,4,5,0,7,4,0,3,0,0,5,0,0,4,0,6,0,3,1,1,1,4,5,5,0,5,5,5,4,6,0,5,1,5,0]

def active4519 : List Nat := [0,1]

def tree4519 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4519 : H12WitnessSearch.Good tree4519 := H12GlobalWitnessIndex.good

theorem leafIdentity4519 : H12AffineFastState.composeSystem env4519 rootObs = leafEnv4519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4519 rootObs == leafEnv4519) = true)

theorem terminalChecked4519 : H12PackedTerminal.terminalCheckFast leafEnv4519 active4519 tree4519 = true := by decide +kernel

def env4520 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4096,41089,91182,41003,8329,91183,323713,16384,16812,22560,74794,79251,257,20481,1465,92050]

theorem envBound4520 : H12AffineFastState.Bounded env4520 := by
  intro p hp
  have h : env4520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4492_4520 : H12AffineEnvironment.transform 21 41089 env4492 = env4520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env4492 == env4520) = true)

theorem identity4520 : scanCanonicalize (H12AffineFastState.compose env4520 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4520 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4521 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,4096,8192,16384,32768,65536,4265,262144,1025,32768,4096,41089,91182,41003,8329,91183,323713,16384,16552,22560,74794,78999,5,20481,1213,91798]

theorem envBound4521 : H12AffineFastState.Bounded env4521 := by
  intro p hp
  have h : env4521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4520_4521 : H12AffineEnvironment.transform 7 4 env4520 = env4521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4520 == env4521) = true)

def env4522 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,4096,8192,16384,32768,65536,4097,262144,1025,32768,4096,41001,91182,41003,8225,91183,323625,16384,16384,22560,74794,78911,5,20481,1045,91710]

theorem envBound4522 : H12AffineFastState.Bounded env4522 := by
  intro p hp
  have h : env4522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4521_4522 : H12AffineEnvironment.transform 6 40 env4521 = env4522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4521 == env4522) = true)

def env4523 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,16384,32768,65536,4096,262144,1025,32768,4096,41000,91182,41003,8224,91183,323624,16384,16385,22560,74794,78910,5,20481,1044,91711]

theorem envBound4523 : H12AffineFastState.Bounded env4523 := by
  intro p hp
  have h : env4523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4521_4523 : H12AffineEnvironment.transform 6 41 env4521 = env4523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4521 == env4523) = true)

theorem identity4523 : scanCanonicalize (H12AffineFastState.compose env4523 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound4523 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env4524 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,1045,8192,16384,32768,65536,1045,262144,1025,32768,1045,41000,91182,41003,8224,91183,320573,16384,16385,19509,74794,73771,5,17428,1044,91711]

theorem envBound4524 : H12AffineFastState.Bounded env4524 := by
  intro p hp
  have h : env4524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4523_4524 : H12AffineEnvironment.transform 11 1045 env4523 = env4524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env4523 == env4524) = true)

theorem identity4524 : scanCanonicalize (H12AffineFastState.compose env4524 (packedSelected [1,5,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 60446) := by decide +kernel

theorem selectedBound4524 : packedSelected [1,5,13,15] rootPS < 2^1333 := by decide +kernel

def env4525 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,1045,8192,16384,32768,60446,1045,262144,1025,32768,1045,41000,34864,41003,8224,34865,320573,16384,16385,19509,51252,52277,5,17428,1044,35361]

theorem envBound4525 : H12AffineFastState.Bounded env4525 := by
  intro p hp
  have h : env4525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4524_4525 : H12AffineEnvironment.transform 15 60446 env4524 = env4525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 60446 env4524 == env4525) = true)

theorem identity4525 : scanCanonicalize (H12AffineFastState.compose env4525 (packedSelected [2,5,8,11,18] rootPS)) = affineNative (2^(14+1) ^^^ 19476) := by decide +kernel

theorem selectedBound4525 : packedSelected [2,5,8,11,18] rootPS < 2^1333 := by decide +kernel

def env4526 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,1045,8192,16384,19476,8202,1045,262144,1025,19476,1045,27708,17444,27711,8224,17445,272425,16384,16385,19509,1056,33,5,17428,1044,17973]

theorem envBound4526 : H12AffineFastState.Bounded env4526 := by
  intro p hp
  have h : env4526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4525_4526 : H12AffineEnvironment.transform 14 19476 env4525 = env4526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 19476 env4525 == env4526) = true)

theorem identity4526 : scanCanonicalize (H12AffineFastState.compose env4526 (packedSelected [2,3,4,8,9,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 8201) := by decide +kernel

theorem selectedBound4526 : packedSelected [2,3,4,8,9,12,13] rootPS < 2^1333 := by decide +kernel

def env4527 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,1045,8192,16384,19476,8202,1045,8201,1025,19476,1045,27708,17444,27711,8224,17445,2080,16384,16385,19509,1056,33,5,17428,1044,17973]

theorem envBound4527 : H12AffineFastState.Bounded env4527 := by
  intro p hp
  have h : env4527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4526_4527 : H12AffineEnvironment.transform 17 8201 env4526 = env4527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8201 env4526 == env4527) = true)

theorem identity4527 : scanCanonicalize (H12AffineFastState.compose env4527 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 1543) := by decide +kernel

theorem selectedBound4527 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env4528 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,1045,1543,16384,19476,1549,1045,1550,1025,19476,1045,19003,17444,19000,1575,17445,2080,16384,16385,19509,1056,33,5,17428,1044,17973]

theorem envBound4528 : H12AffineFastState.Bounded env4528 := by
  intro p hp
  have h : env4528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4527_4528 : H12AffineEnvironment.transform 12 1543 env4527 = env4528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1543 env4527 == env4528) = true)

theorem identity4528 : scanCanonicalize (H12AffineFastState.compose env4528 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(10+1) ^^^ 1583) := by decide +kernel

theorem selectedBound4528 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env4529 : List Nat := [2,4,8,16,32,17,41,4,512,1024,1583,1045,1543,16384,16955,1549,1045,1550,1025,16955,1045,17428,17444,17431,1575,17445,1551,16384,16385,16922,1056,33,5,17428,1044,17973]

theorem envBound4529 : H12AffineFastState.Bounded env4529 := by
  intro p hp
  have h : env4529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4528_4529 : H12AffineEnvironment.transform 10 1583 env4528 = env4529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1583 env4528 == env4529) = true)

theorem identity4529 : scanCanonicalize (H12AffineFastState.compose env4529 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 58) := by decide +kernel

theorem selectedBound4529 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env4530 : List Nat := [2,4,8,16,32,17,41,4,58,1024,1045,1045,1085,16384,16385,1079,1045,1076,1025,16385,1045,17428,17444,17431,1053,17445,1077,16384,16385,16416,1056,33,5,17428,1044,17423]

theorem envBound4530 : H12AffineFastState.Bounded env4530 := by
  intro p hp
  have h : env4530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4529_4530 : H12AffineEnvironment.transform 8 58 env4529 = env4530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 58 env4529 == env4530) = true)

theorem identity4530 : scanCanonicalize (H12AffineFastState.compose env4530 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 1077) := by decide +kernel

theorem selectedBound4530 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env4531 : List Nat := [2,4,8,16,32,17,41,4,58,1024,1045,1045,1085,1077,1076,1079,1045,1076,1025,1076,1045,33,17,34,1053,16,1077,1077,1076,1045,1056,33,5,33,1044,58]

theorem envBound4531 : H12AffineFastState.Bounded env4531 := by
  intro p hp
  have h : env4531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4530_4531 : H12AffineEnvironment.transform 13 1077 env4530 = env4531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1077 env4530 == env4531) = true)

theorem identity4531 : scanCanonicalize (H12AffineFastState.compose env4531 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound4531 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4532 : List Nat := [2,4,8,16,32,17,41,4,58,21,0,0,40,32,33,34,0,33,20,33,0,33,17,34,8,16,32,32,33,0,53,33,5,33,1,58]

theorem envBound4532 : H12AffineFastState.Bounded env4532 := by
  intro p hp
  have h : env4532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4531_4532 : H12AffineEnvironment.transform 9 21 env4531 = env4532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env4531 == env4532) = true)

theorem identity4532 : scanCanonicalize (H12AffineFastState.compose env4532 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound4532 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env4533 : List Nat := [2,4,8,16,27,17,18,4,1,21,0,0,19,27,26,25,0,26,20,26,0,26,17,25,8,16,27,27,26,0,14,26,5,26,1,1]

theorem envBound4533 : H12AffineFastState.Bounded env4533 := by
  intro p hp
  have h : env4533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4532_4533 : H12AffineEnvironment.transform 4 27 env4532 = env4533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env4532 == env4533) = true)

theorem identity4533 : scanCanonicalize (H12AffineFastState.compose env4533 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound4533 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4534 : List Nat := [2,4,8,10,1,11,8,4,1,15,0,0,9,1,0,3,0,0,14,0,0,0,11,3,8,10,1,1,0,0,14,0,5,0,1,1]

theorem envBound4534 : H12AffineFastState.Bounded env4534 := by
  intro p hp
  have h : env4534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4533_4534 : H12AffineEnvironment.transform 3 10 env4533 = env4534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env4533 == env4534) = true)

def env4535 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4096,4194304,8388608,41003,8329,8914001,849105,16385,16892,547952,598059,12644668,525568,545873,8479127,8914924]

theorem envBound4535 : H12AffineFastState.Bounded env4535 := by
  intro p hp
  have h : env4535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4411_4535 : H12AffineEnvironment.transform 27 16385 env4411 = env4535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16385 env4411 == env4535) = true)

def env4536 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,4194304,8388608,41003,8329,8388689,323793,16385,16892,22640,74795,12644668,256,20561,8479127,8389612]

theorem envBound4536 : H12AffineFastState.Bounded env4536 := by
  intro p hp
  have h : env4536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4535_4536 : H12AffineEnvironment.transform 18 1024 env4535 = env4536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env4535 == env4536) = true)

theorem identity4536 : scanCanonicalize (H12AffineFastState.compose env4536 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4293054) := by decide +kernel

theorem selectedBound4536 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4537 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,4194304,4293054,41003,8329,4293103,323793,16385,16892,22640,74795,94338,256,20561,4251689,4293202]

theorem envBound4537 : H12AffineFastState.Bounded env4537 := by
  intro p hp
  have h : env4537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4536_4537 : H12AffineEnvironment.transform 22 4293054 env4536 = env4537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4293054 env4536 == env4537) = true)

def env4538 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,4194304,4293054,41003,8329,4293055,323713,16385,16812,22560,74795,94338,256,20481,4251689,4293122]

theorem envBound4538 : H12AffineFastState.Bounded env4538 := by
  intro p hp
  have h : env4538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4537_4538 : H12AffineEnvironment.transform 5 16 env4537 = env4538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4537 == env4538) = true)

theorem identity4538 : scanCanonicalize (H12AffineFastState.compose env4538 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 98306) := by decide +kernel

theorem selectedBound4538 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4539 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,98306,444,41003,8329,445,323713,16385,16812,22560,74795,94338,256,20481,90155,512]

theorem envBound4539 : H12AffineFastState.Bounded env4539 := by
  intro p hp
  have h : env4539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4538_4539 : H12AffineEnvironment.transform 21 98306 env4538 = env4539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98306 env4538 == env4539) = true)

theorem identity4539 : scanCanonicalize (H12AffineFastState.compose env4539 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8583) := by decide +kernel

theorem selectedBound4539 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4540 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8583,4524,262144,1024,32768,4096,41349,444,41003,8329,445,323713,16385,16812,22560,1452,20741,256,20481,16812,512]

theorem envBound4540 : H12AffineFastState.Bounded env4540 := by
  intro p hp
  have h : env4540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4539_4540 : H12AffineEnvironment.transform 15 8583 env4539 = env4540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8583 env4539 == env4540) = true)

theorem identity4540 : scanCanonicalize (H12AffineFastState.compose env4540 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13885) := by decide +kernel

theorem selectedBound4540 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4541 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,13885,8583,4524,262144,1024,13885,4096,6072,444,5654,8329,445,280252,16385,16812,22560,1452,20741,256,20481,16812,512]

theorem envBound4541 : H12AffineFastState.Bounded env4541 := by
  intro p hp
  have h : env4541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4540_4541 : H12AffineEnvironment.transform 14 13885 env4540 = env4541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13885 env4540 == env4541) = true)

theorem identity4541 : scanCanonicalize (H12AffineFastState.compose env4541 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4356) := by decide +kernel

theorem selectedBound4541 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4542 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4356,13885,8583,4524,262144,1024,13885,4096,6072,444,5654,8329,445,268216,4357,4264,2340,1452,1,256,261,4264,512]

theorem envBound4542 : H12AffineFastState.Bounded env4542 := by
  intro p hp
  have h : env4542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4541_4542 : H12AffineEnvironment.transform 13 4356 env4541 = env4542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4356 env4541 == env4542) = true)

theorem identity4542 : scanCanonicalize (H12AffineFastState.compose env4542 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound4542 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env4543 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4356,13885,8583,4524,2340,1024,13885,4096,6072,444,5654,8329,445,7836,4357,4264,2340,1452,1,256,261,4264,512]

theorem envBound4543 : H12AffineFastState.Bounded env4543 := by
  intro p hp
  have h : env4543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4542_4543 : H12AffineEnvironment.transform 17 2340 env4542 = env4543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env4542 == env4543) = true)

theorem identity4543 : scanCanonicalize (H12AffineFastState.compose env4543 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4543 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env4544 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,4096,8192,4097,13885,8322,4265,2081,1024,13885,4096,5821,185,5654,8329,184,7836,4096,4264,2081,1193,1,5,0,4264,512]

theorem envBound4544 : H12AffineFastState.Bounded env4544 := by
  intro p hp
  have h : env4544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4543_4544 : H12AffineEnvironment.transform 7 5 env4543 = env4544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4543 == env4544) = true)

theorem identity4544 : scanCanonicalize (H12AffineFastState.compose env4544 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1692) := by decide +kernel

theorem selectedBound4544 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env4545 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1692,8192,1693,8353,8322,1589,2081,1024,8353,1692,33,185,138,8329,184,2048,1692,1588,2081,1193,1,5,0,1588,512]

theorem envBound4545 : H12AffineFastState.Bounded env4545 := by
  intro p hp
  have h : env4545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4544_4545 : H12AffineEnvironment.transform 11 1692 env4544 = env4545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1692 env4544 == env4545) = true)

theorem identity4545 : scanCanonicalize (H12AffineFastState.compose env4545 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound4545 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env4546 : List Nat := [2,4,8,16,32,16,128,5,512,188,2048,544,8192,545,8353,8322,649,2081,188,8353,544,33,185,138,8329,184,2048,544,648,2081,21,1,5,0,648,512]

theorem envBound4546 : H12AffineFastState.Bounded env4546 := by
  intro p hp
  have h : env4546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4545_4546 : H12AffineEnvironment.transform 9 188 env4545 = env4546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env4545 == env4546) = true)

theorem identity4546 : scanCanonicalize (H12AffineFastState.compose env4546 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound4546 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env4547 : List Nat := [2,4,8,16,32,16,50,5,512,14,2048,544,8192,545,8211,8240,571,2081,14,8211,544,33,11,56,8251,10,2048,544,570,2081,21,1,5,0,570,512]

theorem envBound4547 : H12AffineFastState.Bounded env4547 := by
  intro p hp
  have h : env4547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4546_4547 : H12AffineEnvironment.transform 6 50 env4546 = env4547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env4546 == env4547) = true)

theorem identity4547 : scanCanonicalize (H12AffineFastState.compose env4547 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound4547 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env4548 : List Nat := [2,4,8,11,32,11,41,5,512,14,2048,544,8192,545,8200,8235,544,2081,14,8200,544,33,11,35,8224,10,2048,544,545,2081,14,1,5,0,545,512]

theorem envBound4548 : H12AffineFastState.Bounded env4548 := by
  intro p hp
  have h : env4548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4547_4548 : H12AffineEnvironment.transform 3 11 env4547 = env4548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env4547 == env4548) = true)

theorem identity4548 : scanCanonicalize (H12AffineFastState.compose env4548 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound4548 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4549 : List Nat := [2,4,8,11,32,11,41,5,512,14,523,544,8192,545,8200,8235,544,554,14,8200,544,33,11,35,8224,10,523,544,545,554,14,1,5,0,545,512]

theorem envBound4549 : H12AffineFastState.Bounded env4549 := by
  intro p hp
  have h : env4549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4548_4549 : H12AffineEnvironment.transform 10 523 env4548 = env4549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env4548 == env4549) = true)

theorem identity4549 : scanCanonicalize (H12AffineFastState.compose env4549 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 546) := by decide +kernel

theorem selectedBound4549 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4550 : List Nat := [2,4,8,11,32,11,41,5,512,14,523,544,546,545,554,521,544,554,14,554,544,33,11,35,514,10,523,544,545,554,14,1,5,0,545,512]

theorem envBound4550 : H12AffineFastState.Bounded env4550 := by
  intro p hp
  have h : env4550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4549_4550 : H12AffineEnvironment.transform 12 546 env4549 = env4550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 546 env4549 == env4550) = true)

def env4551 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,4194304,4293054,41003,8329,4293054,323712,16385,16813,22561,74795,94338,256,20480,4251689,4293123]

theorem envBound4551 : H12AffineFastState.Bounded env4551 := by
  intro p hp
  have h : env4551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4537_4551 : H12AffineEnvironment.transform 5 17 env4537 = env4551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4537 == env4551) = true)

def env4552 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4264,32768,65536,4525,262144,1024,32768,4096,4194304,4293054,41003,8329,4293054,303144,4265,4357,2185,74795,73770,256,168,4239489,4293123]

theorem envBound4552 : H12AffineFastState.Bounded env4552 := by
  intro p hp
  have h : env4552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4551_4552 : H12AffineEnvironment.transform 13 4264 env4551 = env4552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4264 env4551 == env4552) = true)

theorem identity4552 : scanCanonicalize (H12AffineFastState.compose env4552 (packedSelected [0,7,9,13,20,21,22] rootPS)) = affineNative (2^(14+1) ^^^ 8353) := by decide +kernel

theorem selectedBound4552 : packedSelected [0,7,9,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env4553 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4264,8353,65536,4525,262144,1024,8353,4096,4194304,4268319,138,8329,4268319,262281,4265,4357,2185,74795,73770,256,168,4198432,4268706]

theorem envBound4553 : H12AffineFastState.Bounded env4553 := by
  intro p hp
  have h : env4553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4552_4553 : H12AffineEnvironment.transform 14 8353 env4552 = env4553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env4552 == env4553) = true)

theorem identity4553 : scanCanonicalize (H12AffineFastState.compose env4553 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 75938) := by decide +kernel

theorem selectedBound4553 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4554 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4264,8353,65536,4525,75938,1024,8353,4096,4194304,4268319,138,8329,4268319,75819,4265,4357,2185,74795,73770,256,168,4198432,4268706]

theorem envBound4554 : H12AffineFastState.Bounded env4554 := by
  intro p hp
  have h : env4554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4553_4554 : H12AffineEnvironment.transform 17 75938 env4553 = env4554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 75938 env4553 == env4554) = true)

theorem identity4554 : scanCanonicalize (H12AffineFastState.compose env4554 (packedSelected [1,5,6,10,13] rootPS)) = affineNative (2^(15+1) ^^^ 8080) := by decide +kernel

theorem selectedBound4554 : packedSelected [1,5,6,10,13] rootPS < 2^1333 := by decide +kernel

def env4555 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4264,8353,8080,4525,14130,1024,8353,4096,4194304,4210319,138,8329,4210319,14267,4265,4357,2185,15291,16314,256,168,4198432,4209970]

theorem envBound4555 : H12AffineFastState.Bounded env4555 := by
  intro p hp
  have h : env4555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4554_4555 : H12AffineEnvironment.transform 15 8080 env4554 = env4555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8080 env4554 == env4555) = true)

theorem identity4555 : scanCanonicalize (H12AffineFastState.compose env4555 (packedSelected [2,11,18] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound4555 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env4556 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,4264,8353,8064,4525,14114,1024,8353,4096,4194304,4210319,138,8329,4210319,14251,4265,4357,2185,15275,16298,256,168,4198432,4209954]

theorem envBound4556 : H12AffineFastState.Bounded env4556 := by
  intro p hp
  have h : env4556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4555_4556 : H12AffineEnvironment.transform 3 0 env4555 = env4556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4555 == env4556) = true)

theorem identity4556 : scanCanonicalize (H12AffineFastState.compose env4556 (packedSelected [0,3,5,6,7,10,20] rootPS)) = affineNative (2^(21+1) ^^^ 2951) := by decide +kernel

theorem selectedBound4556 : packedSelected [0,3,5,6,7,10,20] rootPS < 2^1333 := by decide +kernel

def env4557 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,4264,8353,8064,4525,14114,1024,8353,4096,2951,13576,138,8329,13576,14251,4265,4357,2185,15275,16298,256,168,7079,13989]

theorem envBound4557 : H12AffineFastState.Bounded env4557 := by
  intro p hp
  have h : env4557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4556_4557 : H12AffineEnvironment.transform 21 2951 env4556 = env4557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2951 env4556 == env4557) = true)

theorem identity4557 : scanCanonicalize (H12AffineFastState.compose env4557 (packedSelected [0,1,3,4,7,9,21] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4557 : packedSelected [0,1,3,4,7,9,21] rootPS < 2^1333 := by decide +kernel

def env4558 : List Nat := [2,4,8,0,32,1,128,5,512,1024,2048,4096,8192,4264,8353,7813,4264,13863,1024,8353,4096,2690,13325,138,8329,13325,13998,4265,4096,2185,15022,16047,5,168,6818,13989]

theorem envBound4558 : H12AffineFastState.Bounded env4558 := by
  intro p hp
  have h : env4558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4557_4558 : H12AffineEnvironment.transform 7 5 env4557 = env4558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4557 == env4558) = true)

theorem identity4558 : scanCanonicalize (H12AffineFastState.compose env4558 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 4131) := by decide +kernel

theorem selectedBound4558 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env4559 : List Nat := [2,4,8,0,32,1,128,5,512,1024,2048,4096,4131,4264,4226,7813,4264,1540,1024,4226,4096,2690,1070,138,4266,1070,1677,4265,4096,2185,2701,3724,5,168,6818,1670]

theorem envBound4559 : H12AffineFastState.Bounded env4559 := by
  intro p hp
  have h : env4559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4558_4559 : H12AffineEnvironment.transform 12 4131 env4558 = env4559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4131 env4558 == env4559) = true)

theorem identity4559 : scanCanonicalize (H12AffineFastState.compose env4559 (packedSelected [0,1,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1197) := by decide +kernel

theorem selectedBound4559 : packedSelected [0,1,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env4560 : List Nat := [2,4,8,0,32,1,128,5,512,1024,2048,1197,1166,1029,1071,2600,1029,1540,1024,1071,1197,2690,1070,138,1031,1070,1677,1028,1197,2185,2701,3724,5,168,3599,1670]

theorem envBound4560 : H12AffineFastState.Bounded env4560 := by
  intro p hp
  have h : env4560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4559_4560 : H12AffineEnvironment.transform 11 1197 env4559 = env4560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1197 env4559 == env4560) = true)

theorem identity4560 : scanCanonicalize (H12AffineFastState.compose env4560 (packedSelected [0,2,4,7,9,11,23] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound4560 : packedSelected [0,2,4,7,9,11,23] rootPS < 2^1333 := by decide +kernel

def env4561 : List Nat := [2,4,8,0,32,1,128,5,512,1024,42,1197,1166,1029,1071,514,1029,1540,1024,1071,1197,680,1070,138,1031,1070,1677,1028,1197,163,679,1702,5,168,1573,1670]

theorem envBound4561 : H12AffineFastState.Bounded env4561 := by
  intro p hp
  have h : env4561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4560_4561 : H12AffineEnvironment.transform 10 42 env4560 = env4561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env4560 == env4561) = true)

theorem identity4561 : scanCanonicalize (H12AffineFastState.compose env4561 (packedSelected [1,3,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 134) := by decide +kernel

theorem selectedBound4561 : packedSelected [1,3,11,12] rootPS < 2^1333 := by decide +kernel

def env4562 : List Nat := [2,4,8,0,32,1,128,5,512,134,42,43,8,131,169,514,131,642,134,169,43,680,168,138,129,168,523,130,43,163,679,544,5,168,675,512]

theorem envBound4562 : H12AffineFastState.Bounded env4562 := by
  intro p hp
  have h : env4562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4561_4562 : H12AffineEnvironment.transform 9 134 env4561 = env4562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 134 env4561 == env4562) = true)

theorem identity4562 : scanCanonicalize (H12AffineFastState.compose env4562 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4562 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env4563 : List Nat := [2,4,3,0,32,1,128,5,512,134,33,32,3,131,162,514,131,642,134,162,32,675,163,129,129,163,512,130,32,163,679,544,5,163,675,512]

theorem envBound4563 : H12AffineFastState.Bounded env4563 := by
  intro p hp
  have h : env4563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4562_4563 : H12AffineEnvironment.transform 2 3 env4562 = env4563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4562 == env4563) = true)

theorem identity4563 : scanCanonicalize (H12AffineFastState.compose env4563 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound4563 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env4564 : List Nat := [2,4,3,0,32,1,128,5,32,134,33,32,3,131,162,34,131,162,134,162,32,131,163,129,129,163,32,130,32,163,135,0,5,163,131,32]

theorem envBound4564 : H12AffineFastState.Bounded env4564 := by
  intro p hp
  have h : env4564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4563_4564 : H12AffineEnvironment.transform 8 32 env4563 = env4564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env4563 == env4564) = true)

theorem identity4564 : scanCanonicalize (H12AffineFastState.compose env4564 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound4564 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4565 : List Nat := [2,4,3,0,32,1,35,5,32,37,33,32,3,32,1,34,32,1,37,1,32,32,0,34,34,0,32,33,32,0,36,0,5,0,32,32]

theorem envBound4565 : H12AffineFastState.Bounded env4565 := by
  intro p hp
  have h : env4565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4564_4565 : H12AffineEnvironment.transform 6 35 env4564 = env4565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env4564 == env4565) = true)

theorem identity4565 : scanCanonicalize (H12AffineFastState.compose env4565 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound4565 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4566 : List Nat := [2,4,3,0,0,1,3,5,0,5,1,0,3,0,1,2,0,1,5,1,0,0,0,2,2,0,0,1,0,0,4,0,5,0,0,0]

theorem envBound4566 : H12AffineFastState.Bounded env4566 := by
  intro p hp
  have h : env4566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4565_4566 : H12AffineEnvironment.transform 4 0 env4565 = env4566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env4565 == env4566) = true)

def env4567 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4265,32768,65536,4525,262144,1024,32768,4096,4194304,4293054,41003,8329,4293054,303145,4264,4356,2184,74795,73771,256,169,4239488,4293123]

theorem envBound4567 : H12AffineFastState.Bounded env4567 := by
  intro p hp
  have h : env4567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4551_4567 : H12AffineEnvironment.transform 13 4265 env4551 = env4567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4265 env4551 == env4567) = true)

theorem identity4567 : scanCanonicalize (H12AffineFastState.compose env4567 (packedSelected [2,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound4567 : packedSelected [2,23,32] rootPS < 2^1333 := by decide +kernel

def env4568 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4265,32768,33166,4525,262144,1024,32768,4096,4194304,4194352,41003,8329,4194352,303145,4264,4356,2184,42405,41381,256,169,4239488,4195213]

theorem envBound4568 : H12AffineFastState.Bounded env4568 := by
  intro p hp
  have h : env4568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4567_4568 : H12AffineEnvironment.transform 15 33166 env4567 = env4568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env4567 == env4568) = true)

theorem identity4568 : scanCanonicalize (H12AffineFastState.compose env4568 (packedSelected [0,2,6,7,11,17,18,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 1922) := by decide +kernel

theorem selectedBound4568 : packedSelected [0,2,6,7,11,17,18,20,21] rootPS < 2^1333 := by decide +kernel

def env4569 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4265,32768,33166,4525,1922,1024,32768,4096,4194304,4194352,41003,8329,4194352,42923,4264,4356,2184,42405,41381,256,169,4239488,4195213]

theorem envBound4569 : H12AffineFastState.Bounded env4569 := by
  intro p hp
  have h : env4569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4568_4569 : H12AffineEnvironment.transform 17 1922 env4568 = env4569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1922 env4568 == env4569) = true)

def env4570 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4265,32768,33166,4525,1922,1024,32768,4096,41088,41136,41003,8329,41136,42923,4264,4356,2184,42405,41381,256,169,4096,41741]

theorem envBound4570 : H12AffineFastState.Bounded env4570 := by
  intro p hp
  have h : env4570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4569_4570 : H12AffineEnvironment.transform 21 41088 env4569 = env4570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env4569 == env4570) = true)

theorem identity4570 : scanCanonicalize (H12AffineFastState.compose env4570 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 11951) := by decide +kernel

theorem selectedBound4570 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4571 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4265,11951,12065,4525,1922,1024,11951,4096,3631,3615,3716,8329,3615,2308,4264,4356,2184,2826,3850,256,169,4096,3490]

theorem envBound4571 : H12AffineFastState.Bounded env4571 := by
  intro p hp
  have h : env4571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4570_4571 : H12AffineEnvironment.transform 14 11951 env4570 = env4571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11951 env4570 == env4571) = true)

theorem identity4571 : scanCanonicalize (H12AffineFastState.compose env4571 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(11+1) ^^^ 1944) := by decide +kernel

theorem selectedBound4571 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env4572 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1944,8192,1841,11951,12065,1589,1922,1024,11951,1944,3631,3615,3716,8329,3615,2308,1840,1692,2184,2826,3850,256,169,1944,3490]

theorem envBound4572 : H12AffineFastState.Bounded env4572 := by
  intro p hp
  have h : env4572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4571_4572 : H12AffineEnvironment.transform 11 1944 env4571 = env4572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1944 env4571 == env4572) = true)

theorem identity4572 : scanCanonicalize (H12AffineFastState.compose env4572 (packedSelected [3,4,5,6,9,10,12,13,15,20] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound4572 : packedSelected [3,4,5,6,9,10,12,13,15,20] rootPS < 2^1333 := by decide +kernel

def env4573 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1703,1944,8192,1841,8200,8582,1589,1922,1024,8200,1944,136,184,35,8329,184,1955,1840,1692,1583,1453,429,256,169,1944,773]

theorem envBound4573 : H12AffineFastState.Bounded env4573 := by
  intro p hp
  have h : env4573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4572_4573 : H12AffineEnvironment.transform 10 1703 env4572 = env4573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env4572 == env4573) = true)

theorem identity4573 : scanCanonicalize (H12AffineFastState.compose env4573 (packedSelected [3,5,10,12,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4573 : packedSelected [3,5,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env4574 : List Nat := [2,4,8,16,32,17,41,256,512,1024,1550,1841,8192,1841,8200,8495,1589,1835,1024,8200,1841,33,17,35,8224,17,1802,1840,1589,1583,1284,260,256,0,1841,773]

theorem envBound4574 : H12AffineFastState.Bounded env4574 := by
  intro p hp
  have h : env4574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4573_4574 : H12AffineEnvironment.transform 6 41 env4573 = env4574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4573 == env4574) = true)

theorem identity4574 : scanCanonicalize (H12AffineFastState.compose env4574 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound4574 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4575 : List Nat := [2,4,8,11,32,10,41,256,512,1024,1550,1834,8192,1834,8200,8495,1582,1835,1024,8200,1834,33,10,35,8224,10,1802,1835,1582,1583,1284,260,256,0,1834,773]

theorem envBound4575 : H12AffineFastState.Bounded env4575 := by
  intro p hp
  have h : env4575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4574_4575 : H12AffineEnvironment.transform 3 11 env4574 = env4575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env4574 == env4575) = true)

theorem identity4575 : scanCanonicalize (H12AffineFastState.compose env4575 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 1030) := by decide +kernel

theorem selectedBound4575 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env4576 : List Nat := [2,4,8,11,32,10,41,256,512,1024,1550,1834,1030,1834,1038,1321,1582,1835,1024,1038,1834,33,10,35,1062,10,1802,1835,1582,1583,1284,260,256,0,1834,773]

theorem envBound4576 : H12AffineFastState.Bounded env4576 := by
  intro p hp
  have h : env4576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4575_4576 : H12AffineEnvironment.transform 12 1030 env4575 = env4576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1030 env4575 == env4576) = true)

theorem identity4576 : scanCanonicalize (H12AffineFastState.compose env4576 (packedSelected [2,11,23] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4576 : packedSelected [2,11,23] rootPS < 2^1333 := by decide +kernel

def env4577 : List Nat := [2,4,8,11,32,10,41,4,512,1024,1550,1582,1030,1582,1038,1069,1582,1583,1024,1038,1582,33,10,35,1062,10,1550,1583,1582,1583,1024,0,4,0,1582,513]

theorem envBound4577 : H12AffineFastState.Bounded env4577 := by
  intro p hp
  have h : env4577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4576_4577 : H12AffineEnvironment.transform 7 4 env4576 = env4577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4576 == env4577) = true)

theorem identity4577 : scanCanonicalize (H12AffineFastState.compose env4577 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound4577 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env4578 : List Nat := [2,4,8,11,32,10,41,4,14,1024,1024,1056,1030,1056,1038,1069,1056,1057,1024,1038,1056,33,10,35,1062,10,1024,1057,1056,1057,1024,0,4,0,1056,15]

theorem envBound4578 : H12AffineFastState.Bounded env4578 := by
  intro p hp
  have h : env4578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4577_4578 : H12AffineEnvironment.transform 8 14 env4577 = env4578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env4577 == env4578) = true)

theorem identity4578 : scanCanonicalize (H12AffineFastState.compose env4578 (packedSelected [10] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4578 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env4579 : List Nat := [2,4,3,0,32,1,34,4,5,1024,1024,1056,1030,1056,1029,1062,1056,1057,1024,1029,1056,33,1,35,1062,1,1024,1057,1056,1057,1024,0,4,0,1056,4]

theorem envBound4579 : H12AffineFastState.Bounded env4579 := by
  intro p hp
  have h : env4579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4578_4579 : H12AffineEnvironment.transform 2 3 env4578 = env4579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4578 == env4579) = true)

theorem identity4579 : scanCanonicalize (H12AffineFastState.compose env4579 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound4579 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env4580 : List Nat := [2,1,3,0,32,1,34,1,0,1024,1024,1056,1027,1056,1024,1059,1056,1057,1024,1024,1056,33,1,35,1059,1,1024,1057,1056,1057,1024,0,1,0,1056,1]

theorem envBound4580 : H12AffineFastState.Bounded env4580 := by
  intro p hp
  have h : env4580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4579_4580 : H12AffineEnvironment.transform 1 1 env4579 = env4580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env4579 == env4580) = true)

theorem identity4580 : scanCanonicalize (H12AffineFastState.compose env4580 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 32) := by decide +kernel

theorem selectedBound4580 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4581 : List Nat := [2,1,3,0,32,1,34,1,0,32,32,0,35,0,32,3,0,1,32,32,0,33,1,35,3,1,32,1,0,1,32,0,1,0,0,1]

theorem envBound4581 : H12AffineFastState.Bounded env4581 := by
  intro p hp
  have h : env4581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4580_4581 : H12AffineEnvironment.transform 9 32 env4580 = env4581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 32 env4580 == env4581) = true)

def leafEnv4581 : List Nat := [2,1,3,0,32,1,34,1,0,32,32,0,35,0,32,3,0,1,32,32,0,33,1,35,32,3,1,1,32,1,0,1,32,0,1,0,1,35,0,1,1,0,0]

def active4581 : List Nat := [0,4]

def tree4581 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4581 : H12WitnessSearch.Good tree4581 := H12GlobalWitnessIndex.good

theorem leafIdentity4581 : H12AffineFastState.composeSystem env4581 rootObs = leafEnv4581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4581 rootObs == leafEnv4581) = true)

theorem terminalChecked4581 : H12PackedTerminal.terminalCheckFast leafEnv4581 active4581 tree4581 = true := by decide +kernel

def env4582 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4265,32768,33166,4525,1922,1024,32768,4096,41089,41137,41003,8329,41137,42923,4264,4356,2184,42405,41381,256,169,4097,41740]

theorem envBound4582 : H12AffineFastState.Bounded env4582 := by
  intro p hp
  have h : env4582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4569_4582 : H12AffineEnvironment.transform 21 41089 env4569 = env4582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env4569 == env4582) = true)

theorem identity4582 : scanCanonicalize (H12AffineFastState.compose env4582 (packedSelected [13,17] rootPS)) = affineNative (2^(10+1) ^^^ 1550) := by decide +kernel

theorem selectedBound4582 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4583 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1550,4096,8192,4265,32768,33166,4525,1922,1024,32768,4096,41089,41137,41003,8329,41137,42923,4264,4356,1670,42405,41381,256,169,4097,41740]

theorem envBound4583 : H12AffineFastState.Bounded env4583 := by
  intro p hp
  have h : env4583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4582_4583 : H12AffineEnvironment.transform 10 1550 env4582 = env4583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1550 env4582 == env4583) = true)

theorem identity4583 : scanCanonicalize (H12AffineFastState.compose env4583 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 13973) := by decide +kernel

theorem selectedBound4583 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env4584 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1550,4096,8192,4265,13973,14107,4525,1922,1024,13973,4096,5652,5668,5822,8329,5668,4414,4264,4356,1670,4912,5936,256,169,4097,5529]

theorem envBound4584 : H12AffineFastState.Bounded env4584 := by
  intro p hp
  have h : env4584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4583_4584 : H12AffineEnvironment.transform 14 13973 env4583 = env4584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13973 env4583 == env4584) = true)

theorem identity4584 : scanCanonicalize (H12AffineFastState.compose env4584 (packedSelected [3,4,5,6,9,10,12,13,15,20] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4584 : packedSelected [3,4,5,6,9,10,12,13,15,20] rootPS < 2^1333 := by decide +kernel

def env4585 : List Nat := [2,4,8,16,32,17,128,4,512,1024,1550,4096,8192,4265,13973,13855,4265,1670,1024,13973,4096,5652,5668,5822,8329,5668,4154,4264,4096,1670,4660,5684,4,169,4097,5277]

theorem envBound4585 : H12AffineFastState.Bounded env4585 := by
  intro p hp
  have h : env4585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4584_4585 : H12AffineEnvironment.transform 7 4 env4584 = env4585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4584 == env4585) = true)

theorem identity4585 : scanCanonicalize (H12AffineFastState.compose env4585 (packedSelected [3,5,10,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound4585 : packedSelected [3,5,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env4586 : List Nat := [2,4,8,16,32,17,128,4,512,1024,1550,1588,8192,1693,8353,8235,1693,1670,1024,8353,1588,32,16,138,8329,16,1550,1692,1588,1670,1024,0,4,169,1589,681]

theorem envBound4586 : H12AffineFastState.Bounded env4586 := by
  intro p hp
  have h : env4586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4585_4586 : H12AffineEnvironment.transform 11 1588 env4585 = env4586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env4585 == env4586) = true)

theorem identity4586 : scanCanonicalize (H12AffineFastState.compose env4586 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound4586 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4587 : List Nat := [2,4,8,16,32,17,19,4,512,1024,1550,1588,8192,1550,8242,8235,1550,1557,1024,8242,1588,32,16,25,8218,16,1550,1551,1588,1557,1024,0,4,58,1589,570]

theorem envBound4587 : H12AffineFastState.Bounded env4587 := by
  intro p hp
  have h : env4587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4586_4587 : H12AffineEnvironment.transform 6 19 env4586 = env4587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env4586 == env4587) = true)

theorem identity4587 : scanCanonicalize (H12AffineFastState.compose env4587 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 1031) := by decide +kernel

theorem selectedBound4587 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env4588 : List Nat := [2,4,8,16,32,17,19,4,512,1024,1550,1588,1031,1550,1077,1068,1550,1557,1024,1077,1588,32,16,25,1053,16,1550,1551,1588,1557,1024,0,4,58,1589,570]

theorem envBound4588 : H12AffineFastState.Bounded env4588 := by
  intro p hp
  have h : env4588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4587_4588 : H12AffineEnvironment.transform 12 1031 env4587 = env4588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1031 env4587 == env4588) = true)

theorem identity4588 : scanCanonicalize (H12AffineFastState.compose env4588 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound4588 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env4589 : List Nat := [2,4,8,16,26,17,19,4,512,1024,1550,1550,1031,1550,1039,1046,1550,1557,1024,1039,1550,26,16,25,1053,16,1550,1551,1550,1557,1024,0,4,0,1551,512]

theorem envBound4589 : H12AffineFastState.Bounded env4589 := by
  intro p hp
  have h : env4589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4588_4589 : H12AffineEnvironment.transform 4 26 env4588 = env4589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env4588 == env4589) = true)

def env4590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4096,4194304,8388608,41003,8329,8388688,323792,16385,16892,22641,74794,12644668,257,20560,8479127,8389613]

theorem envBound4590 : H12AffineFastState.Bounded env4590 := by
  intro p hp
  have h : env4590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4535_4590 : H12AffineEnvironment.transform 18 1025 env4535 = env4590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env4535 == env4590) = true)

theorem identity4590 : scanCanonicalize (H12AffineFastState.compose env4590 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 115903) := by decide +kernel

theorem selectedBound4590 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4096,115903,8388608,41003,8329,8388688,323792,16385,16892,22641,74794,8467843,257,20560,8479127,8389613]

theorem envBound4591 : H12AffineFastState.Bounded env4591 := by
  intro p hp
  have h : env4591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4590_4591 : H12AffineEnvironment.transform 21 115903 env4590 = env4591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 115903 env4590 == env4591) = true)

def env4592 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,115903,8388608,41003,8329,8388608,323712,16385,16812,22561,74794,8467843,257,20480,8479127,8389565]

theorem envBound4592 : H12AffineFastState.Bounded env4592 := by
  intro p hp
  have h : env4592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4591_4592 : H12AffineEnvironment.transform 5 16 env4591 = env4592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4591 == env4592) = true)

def env4593 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,115903,5544,41003,8329,5544,323712,16385,16812,22561,74794,73771,257,20480,95295,5653]

theorem envBound4593 : H12AffineFastState.Bounded env4593 := by
  intro p hp
  have h : env4593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4592_4593 : H12AffineEnvironment.transform 22 5544 env4592 = env4593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5544 env4592 == env4593) = true)

theorem identity4593 : scanCanonicalize (H12AffineFastState.compose env4593 (packedSelected [7,13,20,21,27] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound4593 : packedSelected [7,13,20,21,27] rootPS < 2^1333 := by decide +kernel

def env4594 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,32768,65536,4356,262144,1025,32768,4096,115735,5376,41003,8225,5376,323624,16385,16644,22561,74794,73771,257,20480,95295,5653]

theorem envBound4594 : H12AffineFastState.Bounded env4594 := by
  intro p hp
  have h : env4594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4593_4594 : H12AffineEnvironment.transform 6 40 env4593 = env4594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4593 == env4594) = true)

theorem identity4594 : scanCanonicalize (H12AffineFastState.compose env4594 (packedSelected [1,3,13,17,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound4594 : packedSelected [1,3,13,17,24,28] rootPS < 2^1333 := by decide +kernel

def env4595 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,8200,65536,4356,262144,1025,8200,4096,91167,5376,35,8225,5376,282656,16385,16644,22561,74794,73771,257,20480,95295,5653]

theorem envBound4595 : H12AffineFastState.Bounded env4595 := by
  intro p hp
  have h : env4595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4594_4595 : H12AffineEnvironment.transform 14 8200 env4594 = env4595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env4594 == env4595) = true)

theorem identity4595 : scanCanonicalize (H12AffineFastState.compose env4595 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound4595 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4596 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,8200,65536,4356,2080,1025,8200,4096,91167,5376,35,8225,5376,22528,16385,16644,22561,74794,73771,257,20480,95295,5653]

theorem envBound4596 : H12AffineFastState.Bounded env4596 := by
  intro p hp
  have h : env4596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4595_4596 : H12AffineEnvironment.transform 17 2080 env4595 = env4596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env4595 == env4596) = true)

theorem identity4596 : scanCanonicalize (H12AffineFastState.compose env4596 (packedSelected [2,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 4129) := by decide +kernel

theorem selectedBound4596 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env4597 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,4129,8200,65536,4356,2080,1025,8200,4096,78910,5376,35,8225,5376,2081,4128,4389,2048,74794,73771,257,33,74782,5653]

theorem envBound4597 : H12AffineFastState.Bounded env4597 := by
  intro p hp
  have h : env4597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4596_4597 : H12AffineEnvironment.transform 13 4129 env4596 = env4597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4129 env4596 == env4597) = true)

theorem identity4597 : scanCanonicalize (H12AffineFastState.compose env4597 (packedSelected [4,6,7,11] rootPS)) = affineNative (2^(15+1) ^^^ 2342) := by decide +kernel

theorem selectedBound4597 : packedSelected [4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env4598 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,4129,8200,2342,4356,2080,1025,8200,4096,15640,5376,35,8225,5376,2081,4128,4389,2048,11532,10509,257,33,11576,5653]

theorem envBound4598 : H12AffineFastState.Bounded env4598 := by
  intro p hp
  have h : env4598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4597_4598 : H12AffineEnvironment.transform 15 2342 env4597 = env4598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2342 env4597 == env4598) = true)

theorem identity4598 : scanCanonicalize (H12AffineFastState.compose env4598 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 4648) := by decide +kernel

theorem selectedBound4598 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env4599 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,4648,4129,4640,2342,4356,2080,1025,4640,4096,3888,5376,35,4617,5376,2081,4128,4389,2048,7972,6949,257,33,7952,5653]

theorem envBound4599 : H12AffineFastState.Bounded env4599 := by
  intro p hp
  have h : env4599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4598_4599 : H12AffineEnvironment.transform 12 4648 env4598 = env4599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4648 env4598 == env4599) = true)

theorem identity4599 : scanCanonicalize (H12AffineFastState.compose env4599 (packedSelected [2,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4599 : packedSelected [2,10,12] rootPS < 2^1333 := by decide +kernel

def env4600 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,4648,4129,4640,2082,4096,2080,1025,4640,4096,3636,5124,35,4617,5124,2081,4128,4129,2048,7712,6689,5,33,7700,5653]

theorem envBound4600 : H12AffineFastState.Bounded env4600 := by
  intro p hp
  have h : env4600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4599_4600 : H12AffineEnvironment.transform 7 4 env4599 = env4600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4599 == env4600) = true)

theorem identity4600 : scanCanonicalize (H12AffineFastState.compose env4600 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1071) := by decide +kernel

theorem selectedBound4600 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env4601 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,1071,1543,1038,1551,2082,1071,2080,1025,1551,1071,3636,43,35,1574,43,2081,1039,1038,2048,2575,3598,5,33,2619,570]

theorem envBound4601 : H12AffineFastState.Bounded env4601 := by
  intro p hp
  have h : env4601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4600_4601 : H12AffineEnvironment.transform 11 1071 env4600 = env4601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1071 env4600 == env4601) = true)

theorem identity4601 : scanCanonicalize (H12AffineFastState.compose env4601 (packedSelected [10,15] rootPS)) = affineNative (2^(10+1) ^^^ 1583) := by decide +kernel

theorem selectedBound4601 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env4602 : List Nat := [2,4,8,16,32,16,40,4,512,1024,1583,1071,1543,1038,1551,1549,1071,1551,1025,1551,1071,27,43,35,1574,43,1550,1039,1038,1583,1056,33,5,33,1044,570]

theorem envBound4602 : H12AffineFastState.Bounded env4602 := by
  intro p hp
  have h : env4602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4601_4602 : H12AffineEnvironment.transform 10 1583 env4601 = env4602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1583 env4601 == env4602) = true)

def env4603 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,115903,5545,41003,8329,5545,323712,16385,16812,22561,74794,73770,257,20480,95294,5652]

theorem envBound4603 : H12AffineFastState.Bounded env4603 := by
  intro p hp
  have h : env4603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4592_4603 : H12AffineEnvironment.transform 22 5545 env4592 = env4603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5545 env4592 == env4603) = true)

theorem identity4603 : scanCanonicalize (H12AffineFastState.compose env4603 (packedSelected [0,7,9,13,20,21,22] rootPS)) = affineNative (2^(14+1) ^^^ 28681) := by decide +kernel

theorem selectedBound4603 : packedSelected [0,7,9,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env4604 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,28681,65536,4524,262144,1025,28681,4096,79030,5545,20514,8329,5545,262281,16385,16812,22561,74794,73770,257,20480,95294,5652]

theorem envBound4604 : H12AffineFastState.Bounded env4604 := by
  intro p hp
  have h : env4604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4603_4604 : H12AffineEnvironment.transform 14 28681 env4603 = env4604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28681 env4603 == env4604) = true)

theorem identity4604 : scanCanonicalize (H12AffineFastState.compose env4604 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound4604 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env4605 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1044,8192,16384,25629,65536,1464,262144,1025,25629,1044,73890,445,17462,8329,445,262281,16385,16812,19509,74794,73770,257,17428,90154,512]

theorem envBound4605 : H12AffineFastState.Bounded env4605 := by
  intro p hp
  have h : env4605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4604_4605 : H12AffineEnvironment.transform 11 1044 env4604 = env4605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env4604 == env4605) = true)

theorem identity4605 : scanCanonicalize (H12AffineFastState.compose env4605 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound4605 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env4606 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,1044,8192,16384,25629,65536,1044,262144,1025,25629,1044,73890,17,17462,8329,17,262281,16385,16384,19509,74794,73770,173,17428,90154,512]

theorem envBound4606 : H12AffineFastState.Bounded env4606 := by
  intro p hp
  have h : env4606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4605_4606 : H12AffineEnvironment.transform 7 172 env4605 = env4606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env4605 == env4606) = true)

theorem identity4606 : scanCanonicalize (H12AffineFastState.compose env4606 (packedSelected [6,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 3222) := by decide +kernel

theorem selectedBound4606 : packedSelected [6,13,17] rootPS < 2^1333 := by decide +kernel

def env4607 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,1044,8192,3222,10379,65536,1044,262144,1025,10379,1044,73890,17,2208,8329,17,262281,3223,3222,163,74794,73770,173,2178,76988,512]

theorem envBound4607 : H12AffineFastState.Bounded env4607 := by
  intro p hp
  have h : env4607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4606_4607 : H12AffineEnvironment.transform 13 3222 env4606 = env4607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3222 env4606 == env4607) = true)

theorem identity4607 : scanCanonicalize (H12AffineFastState.compose env4607 (packedSelected [2,11,18] rootPS)) = affineNative (2^(17+1) ^^^ 26) := by decide +kernel

theorem selectedBound4607 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env4608 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,1044,8192,3222,10379,65536,1044,26,1025,10379,1044,73890,17,2208,8329,17,147,3223,3222,163,74794,73770,173,2178,76988,512]

theorem envBound4608 : H12AffineFastState.Bounded env4608 := by
  intro p hp
  have h : env4608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4607_4608 : H12AffineEnvironment.transform 17 26 env4607 = env4608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 26 env4607 == env4608) = true)

theorem identity4608 : scanCanonicalize (H12AffineFastState.compose env4608 (packedSelected [0,7,20] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound4608 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4609 : List Nat := [2,4,8,16,32,16,128,172,136,1024,2048,1044,8192,3222,10379,65536,1044,26,1025,10379,1044,73890,17,2208,8329,17,147,3223,3222,163,74794,73770,173,2178,76988,136]

theorem envBound4609 : H12AffineFastState.Bounded env4609 := by
  intro p hp
  have h : env4609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4608_4609 : H12AffineEnvironment.transform 8 136 env4608 = env4609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env4608 == env4609) = true)

theorem identity4609 : scanCanonicalize (H12AffineFastState.compose env4609 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 10241) := by decide +kernel

theorem selectedBound4609 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env4610 : List Nat := [2,4,8,16,32,16,128,172,136,1024,2048,1044,8192,3222,10379,10241,1044,26,1025,10379,1044,2211,17,2208,8329,17,147,3223,3222,163,3115,2091,173,2178,1213,136]

theorem envBound4610 : H12AffineFastState.Bounded env4610 := by
  intro p hp
  have h : env4610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4609_4610 : H12AffineEnvironment.transform 15 10241 env4609 = env4610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10241 env4609 == env4610) = true)

theorem identity4610 : scanCanonicalize (H12AffineFastState.compose env4610 (packedSelected [1,3,6,12,15] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound4610 : packedSelected [1,3,6,12,15] rootPS < 2^1333 := by decide +kernel

def env4611 : List Nat := [2,4,8,0,32,0,128,172,136,1024,2048,1028,8192,3206,10379,10241,1028,10,1025,10379,1028,2211,1,2208,8329,1,131,3207,3206,163,3115,2091,173,2178,1197,136]

theorem envBound4611 : H12AffineFastState.Bounded env4611 := by
  intro p hp
  have h : env4611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4610_4611 : H12AffineEnvironment.transform 3 0 env4610 = env4611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4610 == env4611) = true)

theorem identity4611 : scanCanonicalize (H12AffineFastState.compose env4611 (packedSelected [1,4,5,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound4611 : packedSelected [1,4,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env4612 : List Nat := [2,4,8,0,32,0,128,172,136,1024,2048,1028,160,3206,2091,2209,1028,10,1025,2091,1028,2211,1,2208,41,1,131,3207,3206,163,3115,2091,173,2178,1197,136]

theorem envBound4612 : H12AffineFastState.Bounded env4612 := by
  intro p hp
  have h : env4612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4611_4612 : H12AffineEnvironment.transform 12 160 env4611 = env4612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env4611 == env4612) = true)

theorem identity4612 : scanCanonicalize (H12AffineFastState.compose env4612 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound4612 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4613 : List Nat := [2,4,8,0,32,0,128,172,136,46,2048,42,160,2216,2091,2209,42,10,47,2091,42,2211,1,2208,41,1,131,2217,2216,163,2053,2091,173,2178,131,136]

theorem envBound4613 : H12AffineFastState.Bounded env4613 := by
  intro p hp
  have h : env4613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4612_4613 : H12AffineEnvironment.transform 9 46 env4612 = env4613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env4612 == env4613) = true)

theorem identity4613 : scanCanonicalize (H12AffineFastState.compose env4613 (packedSelected [0,1,3,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound4613 : packedSelected [0,1,3,6,7] rootPS < 2^1333 := by decide +kernel

def env4614 : List Nat := [2,4,8,0,32,0,128,172,136,46,137,42,160,33,162,40,42,10,47,162,42,42,1,41,41,1,131,32,33,163,140,162,173,11,131,136]

theorem envBound4614 : H12AffineFastState.Bounded env4614 := by
  intro p hp
  have h : env4614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4613_4614 : H12AffineEnvironment.transform 10 137 env4613 = env4614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env4613 == env4614) = true)

def env4615 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4096,115903,8388608,41003,8329,8388609,323713,16385,16813,22560,74794,8467843,257,20481,8479127,8389564]

theorem envBound4615 : H12AffineFastState.Bounded env4615 := by
  intro p hp
  have h : env4615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4591_4615 : H12AffineEnvironment.transform 5 17 env4591 = env4615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4591 == env4615) = true)

theorem identity4615 : scanCanonicalize (H12AffineFastState.compose env4615 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound4615 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4616 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4096,115903,444,41003,8329,445,323713,16385,16813,22560,74794,78911,257,20481,90155,512]

theorem envBound4616 : H12AffineFastState.Bounded env4616 := by
  intro p hp
  have h : env4616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4615_4616 : H12AffineEnvironment.transform 22 444 env4615 = env4616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env4615 == env4616) = true)

theorem identity4616 : scanCanonicalize (H12AffineFastState.compose env4616 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 25915) := by decide +kernel

theorem selectedBound4616 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4617 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,25915,4525,262144,1025,32768,4096,41348,444,41003,8329,445,323713,16385,16813,22560,16657,20740,257,20481,1296,512]

theorem envBound4617 : H12AffineFastState.Bounded env4617 := by
  intro p hp
  have h : env4617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4616_4617 : H12AffineEnvironment.transform 15 25915 env4616 = env4617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25915 env4616 == env4617) = true)

theorem identity4617 : scanCanonicalize (H12AffineFastState.compose env4617 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29313) := by decide +kernel

theorem selectedBound4617 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4618 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29313,25915,4525,262144,1025,29313,4096,21253,444,21162,8329,445,262656,16385,16813,22560,16657,20740,257,20481,1296,512]

theorem envBound4618 : H12AffineFastState.Bounded env4618 := by
  intro p hp
  have h : env4618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4617_4618 : H12AffineEnvironment.transform 14 29313 env4617 = env4618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29313 env4617 == env4618) = true)

theorem identity4618 : scanCanonicalize (H12AffineFastState.compose env4618 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1464) := by decide +kernel

theorem selectedBound4618 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4619 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1464,8192,16384,26425,25915,1045,262144,1025,26425,1464,18109,444,18194,8329,445,262656,16385,16813,19864,16657,17596,257,17849,1296,512]

theorem envBound4619 : H12AffineFastState.Bounded env4619 := by
  intro p hp
  have h : env4619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4618_4619 : H12AffineEnvironment.transform 11 1464 env4618 = env4619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1464 env4618 == env4619) = true)

theorem identity4619 : scanCanonicalize (H12AffineFastState.compose env4619 (packedSelected [0,8,10,11,12,13,15,17,24,27,32] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound4619 : packedSelected [0,8,10,11,12,13,15,17,24,27,32] rootPS < 2^1333 := by decide +kernel

def env4620 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,1296,8192,16384,26425,25915,1045,262144,1025,26425,1296,17941,276,18194,8225,277,262656,16385,16645,19760,16657,17428,257,17681,1296,512]

theorem envBound4620 : H12AffineFastState.Bounded env4620 := by
  intro p hp
  have h : env4620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4619_4620 : H12AffineEnvironment.transform 6 40 env4619 = env4620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4619 == env4620) = true)

def env4621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4097,4194304,8388608,41003,8329,8914000,849105,268435456,268435965,547952,598058,12644668,525568,545873,8479127,8914924]

theorem envBound4621 : H12AffineFastState.Bounded env4621 := by
  intro p hp
  have h : env4621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4410_4621 : H12AffineEnvironment.transform 20 4097 env4410 = env4621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env4410 == env4621) = true)

def env4622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4097,4194304,8388608,41003,8329,8914000,849105,16384,16893,547952,598058,12644668,525568,545873,8479127,8914924]

theorem envBound4622 : H12AffineFastState.Bounded env4622 := by
  intro p hp
  have h : env4622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4621_4622 : H12AffineEnvironment.transform 27 16384 env4621 = env4622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16384 env4621 == env4622) = true)

def env4623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4097,4194304,8388608,41003,8329,8388688,323793,16384,16893,22640,74794,12644668,256,20561,8479127,8389612]

theorem envBound4623 : H12AffineFastState.Bounded env4623 := by
  intro p hp
  have h : env4623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4622_4623 : H12AffineEnvironment.transform 18 1024 env4622 = env4623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env4622 == env4623) = true)

theorem identity4623 : scanCanonicalize (H12AffineFastState.compose env4623 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 91351) := by decide +kernel

theorem selectedBound4623 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4097,4194304,91351,41003,8329,91271,323793,16384,16893,22640,74794,4298219,256,20561,1344,91963]

theorem envBound4624 : H12AffineFastState.Bounded env4624 := by
  intro p hp
  have h : env4624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4623_4624 : H12AffineEnvironment.transform 22 91351 env4623 = env4624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 91351 env4623 == env4624) = true)

def env4625 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,4194304,91271,41003,8329,91271,323713,16384,16813,22560,74794,4298171,256,20481,1296,91963]

theorem envBound4625 : H12AffineFastState.Bounded env4625 := by
  intro p hp
  have h : env4625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4624_4625 : H12AffineEnvironment.transform 5 16 env4624 = env4625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4624 == env4625) = true)

def env4626 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,41088,91271,41003,8329,91271,323713,16384,16813,22560,74794,79163,256,20481,1296,91963]

theorem envBound4626 : H12AffineFastState.Bounded env4626 := by
  intro p hp
  have h : env4626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4625_4626 : H12AffineEnvironment.transform 21 41088 env4625 = env4626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env4625 == env4626) = true)

theorem identity4626 : scanCanonicalize (H12AffineFastState.compose env4626 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 25663) := by decide +kernel

theorem selectedBound4626 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4627 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,25663,4524,262144,1024,32768,4097,41088,184,41003,8329,184,323713,16384,16813,22560,16405,20740,256,20481,1296,772]

theorem envBound4627 : H12AffineFastState.Bounded env4627 := by
  intro p hp
  have h : env4627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4626_4627 : H12AffineEnvironment.transform 15 25663 env4626 = env4627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25663 env4626 == env4627) = true)

def env4628 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,16384,32768,25663,1212,262144,1024,32768,1297,41088,184,41003,8329,184,320913,16384,16813,19760,16405,17428,256,17681,1296,772]

theorem envBound4628 : H12AffineFastState.Bounded env4628 := by
  intro p hp
  have h : env4628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4627_4628 : H12AffineEnvironment.transform 11 1296 env4627 = env4628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env4627 == env4628) = true)

theorem identity4628 : scanCanonicalize (H12AffineFastState.compose env4628 (packedSelected [7,20,27] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4628 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env4629 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1296,8192,16384,32768,25663,1045,262144,1024,32768,1297,41001,17,41003,8224,17,320824,16384,16644,19760,16405,17428,256,17681,1296,772]

theorem envBound4629 : H12AffineFastState.Bounded env4629 := by
  intro p hp
  have h : env4629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4628_4629 : H12AffineEnvironment.transform 6 41 env4628 = env4629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4628 == env4629) = true)

theorem identity4629 : scanCanonicalize (H12AffineFastState.compose env4629 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound4629 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env4630 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1296,8192,16384,32768,25663,1045,2081,1024,32768,1297,41001,17,41003,8224,17,60697,16384,16644,19760,16405,17428,256,17681,1296,772]

theorem envBound4630 : H12AffineFastState.Bounded env4630 := by
  intro p hp
  have h : env4630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4629_4630 : H12AffineEnvironment.transform 17 2081 env4629 = env4630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env4629 == env4630) = true)

theorem identity4630 : scanCanonicalize (H12AffineFastState.compose env4630 (packedSelected [1,3,5,8,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 19728) := by decide +kernel

theorem selectedBound4630 : packedSelected [1,3,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env4631 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1296,8192,16384,19728,25663,1045,2081,1024,19728,1297,27961,17,27963,8224,17,8201,16384,16644,19760,16405,17428,256,17681,1296,772]

theorem envBound4631 : H12AffineFastState.Bounded env4631 := by
  intro p hp
  have h : env4631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4630_4631 : H12AffineEnvironment.transform 14 19728 env4630 = env4631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 19728 env4630 == env4631) = true)

theorem identity4631 : scanCanonicalize (H12AffineFastState.compose env4631 (packedSelected [0,1,2,6,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 318) := by decide +kernel

theorem selectedBound4631 : packedSelected [0,1,2,6,7,8] rootPS < 2^1333 := by decide +kernel

def env4632 : List Nat := [2,4,8,16,32,16,41,256,318,1024,2048,1296,8192,16384,19728,25663,1045,2081,1024,19728,1297,27961,17,27963,8224,17,8201,16384,16644,19760,16405,17428,256,17681,1296,58]

theorem envBound4632 : H12AffineFastState.Bounded env4632 := by
  intro p hp
  have h : env4632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4631_4632 : H12AffineEnvironment.transform 8 318 env4631 = env4632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 318 env4631 == env4632) = true)

theorem identity4632 : scanCanonicalize (H12AffineFastState.compose env4632 (packedSelected [0,1,4,5,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 11545) := by decide +kernel

theorem selectedBound4632 : packedSelected [0,1,4,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env4633 : List Nat := [2,4,8,16,32,16,41,256,318,1024,2048,1296,8192,11545,8201,2342,1045,2081,1024,8201,1297,32,17,34,8224,17,8201,11545,11293,8233,11532,10509,256,10248,1296,58]

theorem envBound4633 : H12AffineFastState.Bounded env4633 := by
  intro p hp
  have h : env4633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4632_4633 : H12AffineEnvironment.transform 13 11545 env4632 = env4633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11545 env4632 == env4633) = true)

theorem identity4633 : scanCanonicalize (H12AffineFastState.compose env4633 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 1063) := by decide +kernel

theorem selectedBound4633 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env4634 : List Nat := [2,4,8,16,32,16,41,256,318,1024,2048,1296,1063,2366,1070,2342,1045,2081,1024,1070,1297,32,17,34,1031,17,1070,2366,2106,1038,2347,3370,256,3119,1296,58]

theorem envBound4634 : H12AffineFastState.Bounded env4634 := by
  intro p hp
  have h : env4634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4633_4634 : H12AffineEnvironment.transform 12 1063 env4633 = env4634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1063 env4633 == env4634) = true)

theorem identity4634 : scanCanonicalize (H12AffineFastState.compose env4634 (packedSelected [2,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 1039) := by decide +kernel

theorem selectedBound4634 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env4635 : List Nat := [2,4,8,16,32,16,41,256,318,1024,1039,1296,1063,1329,1070,1321,1045,1070,1024,1070,1297,32,17,34,1031,17,1070,1329,1077,1038,1316,293,256,32,1296,58]

theorem envBound4635 : H12AffineFastState.Bounded env4635 := by
  intro p hp
  have h : env4635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4634_4635 : H12AffineEnvironment.transform 10 1039 env4634 = env4635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1039 env4634 == env4635) = true)

theorem identity4635 : scanCanonicalize (H12AffineFastState.compose env4635 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4635 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4636 : List Nat := [2,4,8,16,32,16,41,5,59,1024,1039,1045,1063,1076,1070,1068,1045,1070,1024,1070,1044,32,17,34,1031,17,1070,1076,1077,1038,1057,32,5,32,1045,58]

theorem envBound4636 : H12AffineFastState.Bounded env4636 := by
  intro p hp
  have h : env4636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4635_4636 : H12AffineEnvironment.transform 7 5 env4635 = env4636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4635 == env4636) = true)

theorem identity4636 : scanCanonicalize (H12AffineFastState.compose env4636 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 59) := by decide +kernel

theorem selectedBound4636 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4637 : List Nat := [2,4,8,16,32,16,41,5,59,59,52,46,28,15,21,23,46,21,59,21,47,32,17,34,60,17,21,15,14,53,26,32,5,32,46,58]

theorem envBound4637 : H12AffineFastState.Bounded env4637 := by
  intro p hp
  have h : env4637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4636_4637 : H12AffineEnvironment.transform 9 59 env4636 = env4637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 59 env4636 == env4637) = true)

theorem identity4637 : scanCanonicalize (H12AffineFastState.compose env4637 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound4637 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env4638 : List Nat := [2,4,8,10,32,10,41,5,33,33,46,46,6,15,15,13,46,15,33,15,47,32,11,34,38,11,15,15,14,47,0,32,5,32,46,32]

theorem envBound4638 : H12AffineFastState.Bounded env4638 := by
  intro p hp
  have h : env4638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4637_4638 : H12AffineEnvironment.transform 3 10 env4637 = env4638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env4637 == env4638) = true)

theorem identity4638 : scanCanonicalize (H12AffineFastState.compose env4638 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound4638 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4639 : List Nat := [2,4,8,10,15,10,6,5,14,14,1,1,6,15,15,13,1,15,14,15,0,15,11,13,9,11,15,15,14,0,0,15,5,15,1,15]

theorem envBound4639 : H12AffineFastState.Bounded env4639 := by
  intro p hp
  have h : env4639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4638_4639 : H12AffineEnvironment.transform 4 15 env4638 = env4639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env4638 == env4639) = true)

theorem identity4639 : scanCanonicalize (H12AffineFastState.compose env4639 (packedSelected [10] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4639 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env4640 : List Nat := [2,4,3,1,4,1,6,5,5,5,1,1,6,4,4,6,1,4,5,4,0,4,0,6,2,0,4,4,5,0,0,4,5,4,1,4]

theorem envBound4640 : H12AffineFastState.Bounded env4640 := by
  intro p hp
  have h : env4640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4639_4640 : H12AffineEnvironment.transform 2 3 env4639 = env4640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4639 == env4640) = true)

def leafEnv4640 : List Nat := [2,4,3,1,4,1,6,5,5,5,1,1,6,4,4,6,1,4,5,4,0,4,0,6,1,2,1,0,4,4,5,0,0,4,5,4,5,3,1,4,1,4,0]

def active4640 : List Nat := [0,1]

def tree4640 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4640 : H12WitnessSearch.Good tree4640 := H12GlobalWitnessIndex.good

theorem leafIdentity4640 : H12AffineFastState.composeSystem env4640 rootObs = leafEnv4640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4640 rootObs == leafEnv4640) = true)

theorem terminalChecked4640 : H12PackedTerminal.terminalCheckFast leafEnv4640 active4640 tree4640 = true := by decide +kernel

def env4641 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,16384,32768,25663,1213,262144,1024,32768,1296,41088,184,41003,8329,184,320912,16384,16813,19761,16405,17429,256,17680,1296,772]

theorem envBound4641 : H12AffineFastState.Bounded env4641 := by
  intro p hp
  have h : env4641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4627_4641 : H12AffineEnvironment.transform 11 1297 env4627 = env4641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env4627 == env4641) = true)

theorem identity4641 : scanCanonicalize (H12AffineFastState.compose env4641 (packedSelected [13,21] rootPS)) = affineNative (2^(14+1) ^^^ 25881) := by decide +kernel

theorem selectedBound4641 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env4642 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,16384,25881,25663,1213,262144,1024,25881,1296,17817,184,17714,8329,184,262281,16384,16813,19761,16405,17429,256,17680,1296,772]

theorem envBound4642 : H12AffineFastState.Bounded env4642 := by
  intro p hp
  have h : env4642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4641_4642 : H12AffineEnvironment.transform 14 25881 env4641 = env4642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25881 env4641 == env4642) = true)

theorem identity4642 : scanCanonicalize (H12AffineFastState.compose env4642 (packedSelected [0,1,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 11570) := by decide +kernel

theorem selectedBound4642 : packedSelected [0,1,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env4643 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,11570,2091,2317,1213,262144,1024,2091,1296,10411,184,10240,8329,184,262281,11570,11423,8195,11559,10535,256,10274,1296,772]

theorem envBound4643 : H12AffineFastState.Bounded env4643 := by
  intro p hp
  have h : env4643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4642_4643 : H12AffineEnvironment.transform 13 11570 env4642 = env4643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11570 env4642 == env4643) = true)

theorem identity4643 : scanCanonicalize (H12AffineFastState.compose env4643 (packedSelected [0,1,4,5,6,7,9,10,17] rootPS)) = affineNative (2^(17+1) ^^^ 8362) := by decide +kernel

theorem selectedBound4643 : packedSelected [0,1,4,5,6,7,9,10,17] rootPS < 2^1333 := by decide +kernel

def env4644 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,11570,2091,2317,1213,8362,1024,2091,1296,10411,184,10240,8329,184,8227,11570,11423,8195,11559,10535,256,10274,1296,772]

theorem envBound4644 : H12AffineFastState.Bounded env4644 := by
  intro p hp
  have h : env4644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4643_4644 : H12AffineEnvironment.transform 17 8362 env4643 = env4644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8362 env4643 == env4644) = true)

theorem identity4644 : scanCanonicalize (H12AffineFastState.compose env4644 (packedSelected [0,1,3,4,6,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound4644 : packedSelected [0,1,3,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env4645 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,9,3387,2091,2317,1213,163,1024,2091,1296,2210,184,2057,128,184,42,3387,3222,10,3374,2350,256,2091,1296,772]

theorem envBound4645 : H12AffineFastState.Bounded env4645 := by
  intro p hp
  have h : env4645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4644_4645 : H12AffineEnvironment.transform 12 9 env4644 = env4645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env4644 == env4645) = true)

theorem identity4645 : scanCanonicalize (H12AffineFastState.compose env4645 (packedSelected [0,7,20] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound4645 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4646 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1297,9,3387,2091,2317,1213,163,1024,2091,1296,2210,184,2057,128,184,42,3387,3222,10,3374,2350,256,2091,1296,396]

theorem envBound4646 : H12AffineFastState.Bounded env4646 := by
  intro p hp
  have h : env4646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4645_4646 : H12AffineEnvironment.transform 8 136 env4645 = env4646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env4645 == env4646) = true)

theorem identity4646 : scanCanonicalize (H12AffineFastState.compose env4646 (packedSelected [0,2,4,6,7,9,11,23] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound4646 : packedSelected [0,2,4,6,7,9,11,23] rootPS < 2^1333 := by decide +kernel

def env4647 : List Nat := [2,4,8,16,32,16,128,256,136,1024,58,1297,9,1281,17,311,1213,163,1024,17,1296,152,184,51,128,184,42,1281,1196,10,1300,276,256,17,1296,396]

theorem envBound4647 : H12AffineFastState.Bounded env4647 := by
  intro p hp
  have h : env4647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4646_4647 : H12AffineEnvironment.transform 10 58 env4646 = env4647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env4646 == env4647) = true)

theorem identity4647 : scanCanonicalize (H12AffineFastState.compose env4647 (packedSelected [2,3,5,10,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 189) := by decide +kernel

theorem selectedBound4647 : packedSelected [2,3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env4648 : List Nat := [2,4,8,16,32,16,128,189,136,1024,58,1196,9,1212,17,138,1213,163,1024,17,1197,152,184,51,128,184,42,1212,1196,10,1193,169,189,17,1197,49]

theorem envBound4648 : H12AffineFastState.Bounded env4648 := by
  intro p hp
  have h : env4648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4647_4648 : H12AffineEnvironment.transform 7 189 env4647 = env4648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env4647 == env4648) = true)

theorem identity4648 : scanCanonicalize (H12AffineFastState.compose env4648 (packedSelected [3,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound4648 : packedSelected [3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env4649 : List Nat := [2,4,8,16,32,16,50,15,58,1024,58,1054,9,1038,17,56,1039,17,1024,17,1055,42,10,51,50,10,42,1038,1054,10,1051,27,15,17,1055,49]

theorem envBound4649 : H12AffineFastState.Bounded env4649 := by
  intro p hp
  have h : env4649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4648_4649 : H12AffineEnvironment.transform 6 50 env4648 = env4649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env4648 == env4649) = true)

theorem identity4649 : scanCanonicalize (H12AffineFastState.compose env4649 (packedSelected [0,2,3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound4649 : packedSelected [0,2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env4650 : List Nat := [2,4,8,16,32,16,50,15,58,37,58,59,9,43,17,56,42,17,37,17,58,42,10,51,50,10,42,43,59,10,62,27,15,17,58,49]

theorem envBound4650 : H12AffineFastState.Bounded env4650 := by
  intro p hp
  have h : env4650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4649_4650 : H12AffineEnvironment.transform 9 37 env4649 = env4650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env4649 == env4650) = true)

theorem identity4650 : scanCanonicalize (H12AffineFastState.compose env4650 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound4650 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4651 : List Nat := [2,4,8,16,0,16,18,15,26,5,26,27,9,11,17,24,10,17,5,17,26,10,10,19,18,10,10,11,27,10,30,27,15,17,26,17]

theorem envBound4651 : H12AffineFastState.Bounded env4651 := by
  intro p hp
  have h : env4651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4650_4651 : H12AffineEnvironment.transform 4 0 env4650 = env4651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env4650 == env4651) = true)

def env4652 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,41089,91271,41003,8329,91271,323713,16384,16813,22560,74794,79162,256,20481,1296,91963]

theorem envBound4652 : H12AffineFastState.Bounded env4652 := by
  intro p hp
  have h : env4652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4625_4652 : H12AffineEnvironment.transform 21 41089 env4625 = env4652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env4625 == env4652) = true)

theorem identity4652 : scanCanonicalize (H12AffineFastState.compose env4652 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4652 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4653 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,4096,8192,16384,32768,65536,4265,262144,1024,32768,4097,41089,91271,41003,8329,91271,323713,16384,16552,22560,74794,78911,5,20481,1045,91710]

theorem envBound4653 : H12AffineFastState.Bounded env4653 := by
  intro p hp
  have h : env4653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4652_4653 : H12AffineEnvironment.transform 7 5 env4652 = env4653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4652 == env4653) = true)

def env4654 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,4096,8192,16384,32768,65536,4097,262144,1024,32768,4097,41001,91183,41003,8225,91183,323625,16384,16384,22560,74794,78911,5,20481,1045,91710]

theorem envBound4654 : H12AffineFastState.Bounded env4654 := by
  intro p hp
  have h : env4654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4653_4654 : H12AffineEnvironment.transform 6 40 env4653 = env4654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4653 == env4654) = true)

def env4655 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,16384,32768,65536,4096,262144,1024,32768,4097,41000,91182,41003,8224,91182,323624,16384,16385,22560,74794,78911,5,20481,1045,91710]

theorem envBound4655 : H12AffineFastState.Bounded env4655 := by
  intro p hp
  have h : env4655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4653_4655 : H12AffineEnvironment.transform 6 41 env4653 = env4655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4653 == env4655) = true)

theorem identity4655 : scanCanonicalize (H12AffineFastState.compose env4655 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound4655 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env4656 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,1044,8192,16384,32768,65536,1044,262144,1024,32768,1045,41000,91182,41003,8224,91182,320572,16384,16385,19508,74794,73771,5,17429,1045,91710]

theorem envBound4656 : H12AffineFastState.Bounded env4656 := by
  intro p hp
  have h : env4656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4655_4656 : H12AffineEnvironment.transform 11 1044 env4655 = env4656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env4655 == env4656) = true)

theorem identity4656 : scanCanonicalize (H12AffineFastState.compose env4656 (packedSelected [1,5,13,15] rootPS)) = affineNative (2^(17+1) ^^^ 82999) := by decide +kernel

theorem selectedBound4656 : packedSelected [1,5,13,15] rootPS < 2^1333 := by decide +kernel

def env4657 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,1044,8192,16384,32768,65536,1044,82999,1024,32768,1045,41000,91182,41003,8224,91182,106507,16384,16385,19508,74794,73771,5,17429,1045,91710]

theorem envBound4657 : H12AffineFastState.Bounded env4657 := by
  intro p hp
  have h : env4657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4656_4657 : H12AffineEnvironment.transform 17 82999 env4656 = env4657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82999 env4656 == env4657) = true)

theorem identity4657 : scanCanonicalize (H12AffineFastState.compose env4657 (packedSelected [2,5,8,11,18] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound4657 : packedSelected [2,5,8,11,18] rootPS < 2^1333 := by decide +kernel

def env4658 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,1044,8192,16384,32768,8203,1044,25660,1024,32768,1045,41000,17445,41003,8224,17445,32768,16384,16385,19508,1057,32,5,17429,1045,17973]

theorem envBound4658 : H12AffineFastState.Bounded env4658 := by
  intro p hp
  have h : env4658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4657_4658 : H12AffineEnvironment.transform 15 8203 env4657 = env4658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env4657 == env4658) = true)

theorem identity4658 : scanCanonicalize (H12AffineFastState.compose env4658 (packedSelected [0,2,3,5,6,7,12,13] rootPS)) = affineNative (2^(13+1) ^^^ 8755) := by decide +kernel

theorem selectedBound4658 : packedSelected [0,2,3,5,6,7,12,13] rootPS < 2^1333 := by decide +kernel

def env4659 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,1044,8192,8755,32768,8203,1044,1551,1024,32768,1045,41000,9750,41003,8224,9750,32768,8755,8754,11783,1057,32,5,9766,1045,9222]

theorem envBound4659 : H12AffineFastState.Bounded env4659 := by
  intro p hp
  have h : env4659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4658_4659 : H12AffineEnvironment.transform 13 8755 env4658 = env4659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8755 env4658 == env4659) = true)

theorem identity4659 : scanCanonicalize (H12AffineFastState.compose env4659 (packedSelected [2,3,5,6,7,9,11,12,17] rootPS)) = affineNative (2^(14+1) ^^^ 11815) := by decide +kernel

theorem selectedBound4659 : packedSelected [2,3,5,6,7,9,11,12,17] rootPS < 2^1333 := by decide +kernel

def env4660 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,1044,8192,8755,11815,8203,1044,1551,1024,11815,1045,3599,9750,3596,8224,9750,11815,8755,8754,11783,1057,32,5,9766,1045,9222]

theorem envBound4660 : H12AffineFastState.Bounded env4660 := by
  intro p hp
  have h : env4660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4659_4660 : H12AffineEnvironment.transform 14 11815 env4659 = env4660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11815 env4659 == env4660) = true)

theorem identity4660 : scanCanonicalize (H12AffineFastState.compose env4660 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound4660 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env4661 : List Nat := [2,4,8,10,32,10,41,5,512,1024,2048,1038,8192,8745,11815,8203,1038,1551,1024,11815,1039,3599,9740,3596,8224,9740,11815,8745,8744,11783,1057,32,5,9766,1039,9222]

theorem envBound4661 : H12AffineFastState.Bounded env4661 := by
  intro p hp
  have h : env4661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4660_4661 : H12AffineEnvironment.transform 3 10 env4660 = env4661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env4660 == env4661) = true)

theorem identity4661 : scanCanonicalize (H12AffineFastState.compose env4661 (packedSelected [0,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound4661 : packedSelected [0,5,8,9] rootPS < 2^1333 := by decide +kernel

def env4662 : List Nat := [2,4,8,10,32,10,41,5,512,1024,2048,1038,2088,2561,1551,2083,1038,1551,1024,1551,1039,3599,3620,3596,2056,3620,1551,2561,2560,1583,1057,32,5,3598,1039,3118]

theorem envBound4662 : H12AffineFastState.Bounded env4662 := by
  intro p hp
  have h : env4662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4661_4662 : H12AffineEnvironment.transform 12 2088 env4661 = env4662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env4661 == env4662) = true)

theorem identity4662 : scanCanonicalize (H12AffineFastState.compose env4662 (packedSelected [3,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound4662 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env4663 : List Nat := [2,4,8,10,32,10,41,5,1,1024,2048,1038,2088,2048,1038,2083,1038,1038,1024,1038,1039,3086,3109,3085,2056,3109,1038,2048,2049,1070,1057,32,5,3087,1039,3118]

theorem envBound4663 : H12AffineFastState.Bounded env4663 := by
  intro p hp
  have h : env4663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4662_4663 : H12AffineEnvironment.transform 8 1 env4662 = env4663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env4662 == env4663) = true)

theorem identity4663 : scanCanonicalize (H12AffineFastState.compose env4663 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 1071) := by decide +kernel

theorem selectedBound4663 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env4664 : List Nat := [2,4,8,10,32,10,41,5,1,1024,1071,1038,1031,1071,1038,1036,1038,1038,1024,1038,1039,33,10,34,1063,10,1038,1071,1070,1070,1057,32,5,32,1039,1]

theorem envBound4664 : H12AffineFastState.Bounded env4664 := by
  intro p hp
  have h : env4664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4663_4664 : H12AffineEnvironment.transform 10 1071 env4663 = env4664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1071 env4663 == env4664) = true)

theorem identity4664 : scanCanonicalize (H12AffineFastState.compose env4664 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound4664 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4665 : List Nat := [2,4,8,10,32,10,41,5,1,47,0,33,40,0,33,35,33,33,47,33,32,33,10,34,8,10,33,0,1,1,14,32,5,32,32,1]

theorem envBound4665 : H12AffineFastState.Bounded env4665 := by
  intro p hp
  have h : env4665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4664_4665 : H12AffineEnvironment.transform 9 47 env4664 = env4665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env4664 == env4665) = true)

theorem identity4665 : scanCanonicalize (H12AffineFastState.compose env4665 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound4665 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4666 : List Nat := [2,4,8,10,0,10,9,5,1,15,0,1,8,0,1,3,1,1,15,1,0,1,10,2,8,10,1,0,1,1,14,0,5,0,0,1]

theorem envBound4666 : H12AffineFastState.Bounded env4666 := by
  intro p hp
  have h : env4666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4665_4666 : H12AffineEnvironment.transform 4 0 env4665 = env4666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env4665 == env4666) = true)

def env4667 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,4194304,91270,41003,8329,91271,323712,16384,16812,22561,74794,4298170,256,20480,1297,91963]

theorem envBound4667 : H12AffineFastState.Bounded env4667 := by
  intro p hp
  have h : env4667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4624_4667 : H12AffineEnvironment.transform 5 17 env4624 = env4667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4624 == env4667) = true)

theorem identity4667 : scanCanonicalize (H12AffineFastState.compose env4667 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 25915) := by decide +kernel

theorem selectedBound4667 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4668 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,25915,4525,262144,1024,32768,4097,4194304,445,41003,8329,444,323712,16384,16812,22561,16657,4255873,256,20480,1297,512]

theorem envBound4668 : H12AffineFastState.Bounded env4668 := by
  intro p hp
  have h : env4668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4667_4668 : H12AffineEnvironment.transform 15 25915 env4667 = env4668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25915 env4667 == env4668) = true)

theorem identity4668 : scanCanonicalize (H12AffineFastState.compose env4668 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound4668 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4669 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,25915,4525,262144,1024,32768,4097,41348,445,41003,8329,444,323712,16384,16812,22561,16657,20741,256,20480,1297,512]

theorem envBound4669 : H12AffineFastState.Bounded env4669 := by
  intro p hp
  have h : env4669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4668_4669 : H12AffineEnvironment.transform 21 41348 env4668 = env4669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env4668 == env4669) = true)

theorem identity4669 : scanCanonicalize (H12AffineFastState.compose env4669 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29312) := by decide +kernel

theorem selectedBound4669 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4670 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29312,25915,4525,262144,1024,29312,4097,21252,445,21163,8329,444,262656,16384,16812,22561,16657,20741,256,20480,1297,512]

theorem envBound4670 : H12AffineFastState.Bounded env4670 := by
  intro p hp
  have h : env4670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4669_4670 : H12AffineEnvironment.transform 14 29312 env4669 = env4670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29312 env4669 == env4670) = true)

theorem identity4670 : scanCanonicalize (H12AffineFastState.compose env4670 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1465) := by decide +kernel

theorem selectedBound4670 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4671 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1465,8192,16384,26425,25915,1044,262144,1024,26425,1464,18109,445,18194,8329,444,262656,16384,16812,19864,16657,17596,256,17849,1297,512]

theorem envBound4671 : H12AffineFastState.Bounded env4671 := by
  intro p hp
  have h : env4671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4670_4671 : H12AffineEnvironment.transform 11 1465 env4670 = env4671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1465 env4670 == env4671) = true)

theorem identity4671 : scanCanonicalize (H12AffineFastState.compose env4671 (packedSelected [0,8,10,11,12,13,15,17,24,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 20157) := by decide +kernel

theorem selectedBound4671 : packedSelected [0,8,10,11,12,13,15,17,24,27,32] rootPS < 2^1333 := by decide +kernel

def env4672 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1465,8192,16384,26425,25915,1044,20157,1024,26425,1464,18109,445,18194,8329,444,19645,16384,16812,19864,16657,17596,256,17849,1297,512]

theorem envBound4672 : H12AffineFastState.Bounded env4672 := by
  intro p hp
  have h : env4672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4671_4672 : H12AffineEnvironment.transform 17 20157 env4671 = env4672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20157 env4671 == env4672) = true)

theorem identity4672 : scanCanonicalize (H12AffineFastState.compose env4672 (packedSelected [1,3,8,10,18,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 1841) := by decide +kernel

theorem selectedBound4672 : packedSelected [1,3,8,10,18,23,24] rootPS < 2^1333 := by decide +kernel

def env4673 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1465,8192,1841,8200,8714,1044,2444,1024,8200,1464,396,445,35,8329,444,2956,1841,1693,2729,1568,909,256,648,1297,512]

theorem envBound4673 : H12AffineFastState.Bounded env4673 := by
  intro p hp
  have h : env4673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4672_4673 : H12AffineEnvironment.transform 13 1841 env4672 = env4673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1841 env4672 == env4673) = true)

theorem identity4673 : scanCanonicalize (H12AffineFastState.compose env4673 (packedSelected [0,4,7,9,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound4673 : packedSelected [0,4,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env4674 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1045,8192,1693,8200,8714,1044,2080,1024,8200,1044,32,17,35,8329,16,2592,1693,1693,2729,1568,545,172,648,1213,512]

theorem envBound4674 : H12AffineFastState.Bounded env4674 := by
  intro p hp
  have h : env4674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4673_4674 : H12AffineEnvironment.transform 7 172 env4673 = env4674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env4673 == env4674) = true)

theorem identity4674 : scanCanonicalize (H12AffineFastState.compose env4674 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1550) := by decide +kernel

theorem selectedBound4674 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4675 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1550,1045,8192,1693,8200,8714,1044,1582,1024,8200,1044,32,17,35,8329,16,1070,1693,1693,1191,1568,545,172,648,1213,512]

theorem envBound4675 : H12AffineFastState.Bounded env4675 := by
  intro p hp
  have h : env4675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4674_4675 : H12AffineEnvironment.transform 10 1550 env4674 = env4675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1550 env4674 == env4675) = true)

theorem identity4675 : scanCanonicalize (H12AffineFastState.compose env4675 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 1031) := by decide +kernel

theorem selectedBound4675 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env4676 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1550,1045,1031,1693,1039,1549,1044,1582,1024,1039,1044,32,17,35,1166,16,1070,1693,1693,1191,1568,545,172,648,1213,512]

theorem envBound4676 : H12AffineFastState.Bounded env4676 := by
  intro p hp
  have h : env4676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4675_4676 : H12AffineEnvironment.transform 12 1031 env4675 = env4676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1031 env4675 == env4676) = true)

theorem identity4676 : scanCanonicalize (H12AffineFastState.compose env4676 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 169) := by decide +kernel

theorem selectedBound4676 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env4677 : List Nat := [2,4,8,16,32,17,128,172,169,1024,1191,1045,1031,1076,1039,1188,1044,1159,1024,1039,1044,32,17,35,1166,16,1070,1076,1076,1191,1161,136,172,33,1213,169]

theorem envBound4677 : H12AffineFastState.Bounded env4677 := by
  intro p hp
  have h : env4677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4676_4677 : H12AffineEnvironment.transform 8 169 env4676 = env4677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env4676 == env4677) = true)

theorem identity4677 : scanCanonicalize (H12AffineFastState.compose env4677 (packedSelected [2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound4677 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env4678 : List Nat := [2,4,8,16,32,17,51,31,26,1024,1044,1045,1031,1076,1039,1047,1044,1076,1024,1039,1044,32,17,35,1085,16,1070,1076,1076,1044,1082,59,31,33,1038,26]

theorem envBound4678 : H12AffineFastState.Bounded env4678 := by
  intro p hp
  have h : env4678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4677_4678 : H12AffineEnvironment.transform 6 51 env4677 = env4678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env4677 == env4678) = true)

theorem identity4678 : scanCanonicalize (H12AffineFastState.compose env4678 (packedSelected [3] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound4678 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env4679 : List Nat := [2,4,8,16,32,17,51,31,26,46,58,59,41,26,33,57,58,26,46,33,58,32,17,35,19,16,0,26,26,58,20,59,31,33,32,26]

theorem envBound4679 : H12AffineFastState.Bounded env4679 := by
  intro p hp
  have h : env4679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4678_4679 : H12AffineEnvironment.transform 9 46 env4678 = env4679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env4678 == env4679) = true)

def env4680 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4097,4194304,8388608,41003,8329,8388689,323792,16384,16893,22641,74795,12644668,257,20560,8479127,8389613]

theorem envBound4680 : H12AffineFastState.Bounded env4680 := by
  intro p hp
  have h : env4680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4622_4680 : H12AffineEnvironment.transform 18 1025 env4622 = env4680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env4622 == env4680) = true)

theorem identity4680 : scanCanonicalize (H12AffineFastState.compose env4680 (packedSelected [14] rootPS)) = affineNative (2^(15+1) ^^^ 8662) := by decide +kernel

theorem selectedBound4680 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4681 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8662,4604,262144,1025,32768,4097,4194304,8388608,41003,8329,8388689,323792,16384,16893,22641,1533,12644668,257,20560,8405057,8389613]

theorem envBound4681 : H12AffineFastState.Bounded env4681 := by
  intro p hp
  have h : env4681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4680_4681 : H12AffineEnvironment.transform 15 8662 env4680 = env4681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8662 env4680 == env4681) = true)

def env4682 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8582,4524,262144,1025,32768,4097,4194304,8388608,41003,8329,8388609,323712,16384,16813,22561,1453,12644668,257,20480,8405009,8389565]

theorem envBound4682 : H12AffineFastState.Bounded env4682 := by
  intro p hp
  have h : env4682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4681_4682 : H12AffineEnvironment.transform 5 16 env4681 = env4682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4681 == env4682) = true)

theorem identity4682 : scanCanonicalize (H12AffineFastState.compose env4682 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound4682 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4683 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8582,4524,262144,1025,32768,4097,4194304,445,41003,8329,444,323712,16384,16813,22561,1453,4255873,257,20480,16812,512]

theorem envBound4683 : H12AffineFastState.Bounded env4683 := by
  intro p hp
  have h : env4683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4682_4683 : H12AffineEnvironment.transform 22 445 env4682 = env4683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env4682 == env4683) = true)

theorem identity4683 : scanCanonicalize (H12AffineFastState.compose env4683 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound4683 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4684 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8582,4524,262144,1025,32768,4097,41349,445,41003,8329,444,323712,16384,16813,22561,1453,20740,257,20480,16812,512]

theorem envBound4684 : H12AffineFastState.Bounded env4684 := by
  intro p hp
  have h : env4684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4683_4684 : H12AffineEnvironment.transform 21 41349 env4683 = env4684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env4683 == env4684) = true)

theorem identity4684 : scanCanonicalize (H12AffineFastState.compose env4684 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13885) := by decide +kernel

theorem selectedBound4684 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4685 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,13885,8582,4524,262144,1025,13885,4097,6072,445,5654,8329,444,280253,16384,16813,22561,1453,20740,257,20480,16812,512]

theorem envBound4685 : H12AffineFastState.Bounded env4685 := by
  intro p hp
  have h : env4685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4684_4685 : H12AffineEnvironment.transform 14 13885 env4684 = env4685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13885 env4684 == env4685) = true)

theorem identity4685 : scanCanonicalize (H12AffineFastState.compose env4685 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4356) := by decide +kernel

theorem selectedBound4685 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4686 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4356,13885,8582,4524,262144,1025,13885,4097,6072,445,5654,8329,444,268217,4356,4265,2341,1453,0,257,260,4264,512]

theorem envBound4686 : H12AffineFastState.Bounded env4686 := by
  intro p hp
  have h : env4686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4685_4686 : H12AffineEnvironment.transform 13 4356 env4685 = env4686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4356 env4685 == env4686) = true)

theorem identity4686 : scanCanonicalize (H12AffineFastState.compose env4686 (packedSelected [3,5,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4686 : packedSelected [3,5,8,28] rootPS < 2^1333 := by decide +kernel

def env4687 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,4096,8192,4097,13885,8323,4265,262144,1025,13885,4097,5821,184,5654,8329,185,267964,4097,4265,2080,1192,0,4,1,4264,512]

theorem envBound4687 : H12AffineFastState.Bounded env4687 := by
  intro p hp
  have h : env4687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4686_4687 : H12AffineEnvironment.transform 7 5 env4686 = env4687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4686 == env4687) = true)

theorem identity4687 : scanCanonicalize (H12AffineFastState.compose env4687 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound4687 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4688 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,4096,8192,4097,13885,8323,4265,2184,1025,13885,4097,5821,184,5654,8329,185,7732,4097,4265,2080,1192,0,4,1,4264,512]

theorem envBound4688 : H12AffineFastState.Bounded env4688 := by
  intro p hp
  have h : env4688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4687_4688 : H12AffineEnvironment.transform 17 2184 env4687 = env4688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env4687 == env4688) = true)

theorem identity4688 : scanCanonicalize (H12AffineFastState.compose env4688 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 1693) := by decide +kernel

theorem selectedBound4688 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env4689 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1693,8192,1692,8352,8323,1588,2184,1025,8352,1692,32,184,139,8329,185,2217,1692,1588,2080,1192,0,4,1,1589,512]

theorem envBound4689 : H12AffineFastState.Bounded env4689 := by
  intro p hp
  have h : env4689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4688_4689 : H12AffineEnvironment.transform 11 1693 env4688 = env4689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1693 env4688 == env4689) = true)

theorem identity4689 : scanCanonicalize (H12AffineFastState.compose env4689 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 19) := by decide +kernel

theorem selectedBound4689 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env4690 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1693,19,1692,179,144,1588,2184,1025,179,1692,32,184,139,154,185,2217,1692,1588,2080,1192,0,4,1,1589,512]

theorem envBound4690 : H12AffineFastState.Bounded env4690 := by
  intro p hp
  have h : env4690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4689_4690 : H12AffineEnvironment.transform 12 19 env4689 = env4690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 19 env4689 == env4690) = true)

theorem identity4690 : scanCanonicalize (H12AffineFastState.compose env4690 (packedSelected [1,3,4,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 690) := by decide +kernel

end H12CloudChart0