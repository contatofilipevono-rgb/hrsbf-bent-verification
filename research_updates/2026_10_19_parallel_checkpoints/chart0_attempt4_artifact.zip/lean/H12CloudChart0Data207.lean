import H12CloudChart0Data206

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans52403_52404 : H12AffineEnvironment.transform 15 62730 env52403 = env52404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env52403 == env52404) = true)

theorem identity52404 : scanCanonicalize (H12AffineFastState.compose env52404 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound52404 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52405 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,8202,16401,10281,1025,21761,4161,33,8524,21762,8193,64,10589,13388,25692,23669,1365,32,257,21792,24845,513]

theorem envBound52405 : H12AffineFastState.Bounded env52405 := by
  intro p hp
  have h : env52405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52404_52405 : H12AffineEnvironment.transform 14 21760 env52404 = env52405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env52404 == env52405) = true)

theorem identity52405 : scanCanonicalize (H12AffineFastState.compose env52405 (packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound52405 : packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env52406 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,342,16401,2421,1025,21761,4161,33,16,21762,349,64,2049,5392,17664,23669,1365,32,257,21792,16465,513]

theorem envBound52406 : H12AffineFastState.Bounded env52406 := by
  intro p hp
  have h : env52406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52405_52406 : H12AffineEnvironment.transform 12 348 env52405 = env52406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env52405 == env52406) = true)

def env52407 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10401,1025,32769,4161,73770,120015,21762,8328,64,64605,115151,102879,35188,1500,168,257,21792,46212,74251]

theorem envBound52407 : H12AffineFastState.Bounded env52407 := by
  intro p hp
  have h : env52407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52390_52407 : H12AffineEnvironment.transform 17 10401 env52390 = env52407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env52390 == env52407) = true)

def env52408 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10281,1025,32769,4161,73770,119879,21762,8192,64,64605,115015,102743,35188,1364,32,257,21792,46092,74251]

theorem envBound52408 : H12AffineFastState.Bounded env52408 := by
  intro p hp
  have h : env52408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52407_52408 : H12AffineEnvironment.transform 6 8 env52407 = env52408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52407 == env52408) = true)

theorem identity52408 : scanCanonicalize (H12AffineFastState.compose env52408 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound52408 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52409 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,49169,10281,1025,32769,4161,21792,41293,21762,8192,64,64605,46157,58461,35188,1364,32,257,21792,46092,22273]

theorem envBound52409 : H12AffineFastState.Bounded env52409 := by
  intro p hp
  have h : env52409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52408_52409 : H12AffineEnvironment.transform 15 29962 env52408 = env52409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env52408 == env52409) = true)

theorem identity52409 : scanCanonicalize (H12AffineFastState.compose env52409 (packedSelected [2,3,5,10,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 29992) := by decide +kernel

theorem selectedBound52409 : packedSelected [2,3,5,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env52410 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29992,29962,13625,10281,1025,29993,4161,21792,21605,21762,8192,64,2421,16741,4469,31836,1364,32,257,21792,16676,22273]

theorem envBound52410 : H12AffineFastState.Bounded env52410 := by
  intro p hp
  have h : env52410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52409_52410 : H12AffineEnvironment.transform 14 29992 env52409 = env52410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29992 env52409 == env52410) = true)

theorem identity52410 : scanCanonicalize (H12AffineFastState.compose env52410 (packedSelected [0,4,6,7,9,12,15,16,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52410 : packedSelected [0,4,6,7,9,12,15,16,20] rootPS < 2^1333 := by decide +kernel

def env52411 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29992,29962,13625,10281,1025,29993,4113,21792,21557,21762,8192,16,2341,16693,4389,31756,1284,32,257,21792,16676,22273]

theorem envBound52411 : H12AffineFastState.Bounded env52411 := by
  intro p hp
  have h : env52411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52410_52411 : H12AffineEnvironment.transform 5 16 env52410 = env52411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52410 == env52411) = true)

theorem identity52411 : scanCanonicalize (H12AffineFastState.compose env52411 (packedSelected [1,3,5,6,8,11,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound52411 : packedSelected [1,3,5,6,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env52412 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3109,8192,16384,26893,26927,10524,10281,1025,26892,3124,18693,18448,18727,8192,16,2341,16693,3328,24617,1284,32,257,18693,16676,19236]

theorem envBound52412 : H12AffineFastState.Bounded env52412 := by
  intro p hp
  have h : env52412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52411_52412 : H12AffineEnvironment.transform 11 3109 env52411 = env52412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env52411 == env52412) = true)

def env52413 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10280,1025,32769,4161,73770,119878,21762,8193,64,64605,115014,102742,35188,1365,33,257,21792,46093,74251]

theorem envBound52413 : H12AffineFastState.Bounded env52413 := by
  intro p hp
  have h : env52413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52407_52413 : H12AffineEnvironment.transform 6 9 env52407 = env52413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52407 == env52413) = true)

theorem identity52413 : scanCanonicalize (H12AffineFastState.compose env52413 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound52413 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52414 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,24909,10280,1025,32769,4161,62588,16,21762,8193,64,64605,5392,17664,35188,1365,33,257,21792,46093,63069]

theorem envBound52414 : H12AffineFastState.Bounded env52414 := by
  intro p hp
  have h : env52414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52413_52414 : H12AffineEnvironment.transform 15 54358 env52413 = env52414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env52413 == env52414) = true)

theorem identity52414 : scanCanonicalize (H12AffineFastState.compose env52414 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1297) := by decide +kernel

theorem selectedBound52414 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52415 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1297,20807,24909,10280,1025,1296,4161,29037,16,21762,8193,64,31052,5392,17664,3173,1365,33,257,21792,12572,29516]

theorem envBound52415 : H12AffineFastState.Bounded env52415 := by
  intro p hp
  have h : env52415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52414_52415 : H12AffineEnvironment.transform 14 1297 env52414 = env52415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1297 env52414 == env52415) = true)

theorem identity52415 : scanCanonicalize (H12AffineFastState.compose env52415 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound52415 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env52416 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,1297,20807,16400,2421,1025,1296,4161,20528,16,21762,348,64,22545,5392,17664,3173,1365,33,257,21792,4161,21009]

theorem envBound52416 : H12AffineFastState.Bounded env52416 := by
  intro p hp
  have h : env52416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52415_52416 : H12AffineEnvironment.transform 12 349 env52415 = env52416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env52415 == env52416) = true)

theorem identity52416 : scanCanonicalize (H12AffineFastState.compose env52416 (packedSelected [1,8,11,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound52416 : packedSelected [1,8,11,18,19] rootPS < 2^1333 := by decide +kernel

def env52417 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,120,16384,1076,20578,16400,2128,1025,1077,4161,20528,16,21543,121,64,22545,5173,17445,3173,1136,33,36,21509,4161,21009]

theorem envBound52417 : H12AffineFastState.Bounded env52417 := by
  intro p hp
  have h : env52417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52416_52417 : H12AffineEnvironment.transform 7 37 env52416 = env52417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env52416 == env52417) = true)

def env52418 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441745,2257301,253977,8328,64,2157597,2253973,140484,2404756,2102685,2373705,257,21792,46212,2175562]

theorem envBound52418 : H12AffineFastState.Bounded env52418 := by
  intro p hp
  have h : env52418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52360_52418 : H12AffineEnvironment.transform 21 441745 env52360 = env52418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441745 env52360 == env52418) = true)

def env52419 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441745,156117,253977,8328,64,64605,160981,140484,303572,1501,272393,257,21792,46212,74250]

theorem envBound52419 : H12AffineFastState.Bounded env52419 := by
  intro p hp
  have h : env52419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52418_52419 : H12AffineEnvironment.transform 20 4160 env52418 = env52419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env52418 == env52419) = true)

theorem identity52419 : scanCanonicalize (H12AffineFastState.compose env52419 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82383) := by decide +kernel

theorem selectedBound52419 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52420 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,4160,392286,73754,41430,8328,64,64605,79130,91403,303572,1501,272393,257,21792,46212,74250]

theorem envBound52420 : H12AffineFastState.Bounded env52420 := by
  intro p hp
  have h : env52420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52419_52420 : H12AffineEnvironment.transform 16 82383 env52419 = env52420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82383 env52419 == env52420) = true)

def env52421 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,4160,392286,73754,41310,8192,64,64605,79130,91403,303452,1365,272393,257,21792,46092,74250]

theorem envBound52421 : H12AffineFastState.Bounded env52421 := by
  intro p hp
  have h : env52421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52420_52421 : H12AffineEnvironment.transform 6 8 env52420 = env52421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52420 == env52421) = true)

theorem identity52421 : scanCanonicalize (H12AffineFastState.compose env52421 (packedSelected [1,4,5,9,11,12,14,19,20,24,26,28,31,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 8313) := by decide +kernel

theorem selectedBound52421 : packedSelected [1,4,5,9,11,12,14,19,20,24,26,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env52422 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8313,65536,82247,262144,1025,8312,4160,351271,73754,295,8192,64,23588,79130,91403,262437,1365,272393,257,21792,5237,74250]

theorem envBound52422 : H12AffineFastState.Bounded env52422 := by
  intro p hp
  have h : env52422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52421_52422 : H12AffineEnvironment.transform 14 8313 env52421 = env52422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8313 env52421 == env52422) = true)

theorem identity52422 : scanCanonicalize (H12AffineFastState.compose env52422 (packedSelected [1,2,3,4,6,7,8,12,14,15,18,22,24,27,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound52422 : packedSelected [1,2,3,4,6,7,8,12,14,15,18,22,24,27,31,32] rootPS < 2^1333 := by decide +kernel

def env52423 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8313,65536,82247,89378,1025,8312,4160,261,73754,295,8192,64,23588,79130,91403,89095,1365,95531,257,21792,5237,74250]

theorem envBound52423 : H12AffineFastState.Bounded env52423 := by
  intro p hp
  have h : env52423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52422_52423 : H12AffineEnvironment.transform 17 89378 env52422 = env52423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env52422 == env52423) = true)

theorem identity52423 : scanCanonicalize (H12AffineFastState.compose env52423 (packedSelected [0,1,4,7,8,12,15,17,18,19,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound52423 : packedSelected [0,1,4,7,8,12,15,17,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env52424 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,373,65536,82247,89378,1025,372,4160,261,65814,295,268,64,23588,70678,82951,89095,1365,87079,257,21792,5237,66310]

theorem envBound52424 : H12AffineFastState.Bounded env52424 := by
  intro p hp
  have h : env52424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52423_52424 : H12AffineEnvironment.transform 12 268 env52423 = env52424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env52423 == env52424) = true)

theorem identity52424 : scanCanonicalize (H12AffineFastState.compose env52424 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,18,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound52424 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env52425 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,373,115,16692,23889,1025,372,4160,261,357,295,268,64,23588,5221,17524,23668,1365,21588,257,21792,5237,885]

theorem envBound52425 : H12AffineFastState.Bounded env52425 := by
  intro p hp
  have h : env52425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52424_52425 : H12AffineEnvironment.transform 15 115 env52424 = env52425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env52424 == env52425) = true)

theorem identity52425 : scanCanonicalize (H12AffineFastState.compose env52425 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound52425 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env52426 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,121,16384,0,115,16449,23588,1025,1,4160,112,16,82,121,64,23588,5221,17524,23668,1056,21588,116,21589,5237,512]

theorem envBound52426 : H12AffineFastState.Bounded env52426 := by
  intro p hp
  have h : env52426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52425_52426 : H12AffineEnvironment.transform 7 117 env52425 = env52426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env52425 == env52426) = true)

theorem identity52426 : scanCanonicalize (H12AffineFastState.compose env52426 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52426 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52427 : List Nat := [2,4,8,16,1,64,8,84,512,1024,2048,4096,88,16384,0,82,16449,23557,1025,1,4160,81,16,82,88,64,23557,5188,17493,23637,1025,21588,85,21589,5204,512]

theorem envBound52427 : H12AffineFastState.Bounded env52427 := by
  intro p hp
  have h : env52427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52426_52427 : H12AffineEnvironment.transform 4 1 env52426 = env52427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52426 == env52427) = true)

theorem identity52427 : scanCanonicalize (H12AffineFastState.compose env52427 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52427 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env52428 : List Nat := [2,4,8,16,1,17,8,5,512,1024,2048,4096,9,16384,0,3,16400,23557,1025,1,4113,0,16,3,9,17,23557,5141,17412,23556,1025,21509,4,21508,5125,512]

theorem envBound52428 : H12AffineFastState.Bounded env52428 := by
  intro p hp
  have h : env52428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52427_52428 : H12AffineEnvironment.transform 5 17 env52427 = env52428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52427 == env52428) = true)

theorem identity52428 : scanCanonicalize (H12AffineFastState.compose env52428 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 6170) := by decide +kernel

theorem selectedBound52428 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env52429 : List Nat := [2,4,8,16,1,17,8,5,512,1024,2048,4096,9,6170,0,3,6154,1055,1025,1,4113,0,16,3,9,17,1055,5141,7198,1054,1025,3103,4,3102,5125,512]

theorem envBound52429 : H12AffineFastState.Bounded env52429 := by
  intro p hp
  have h : env52429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52428_52429 : H12AffineEnvironment.transform 13 6170 env52428 = env52429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6170 env52428 == env52429) = true)

theorem identity52429 : scanCanonicalize (H12AffineFastState.compose env52429 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound52429 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env52430 : List Nat := [2,4,8,16,1,17,8,5,512,1024,2048,1045,9,3087,0,3,3103,1055,1025,1,1028,0,16,3,9,17,1055,0,2059,1054,1025,3103,4,3102,16,512]

theorem envBound52430 : H12AffineFastState.Bounded env52430 := by
  intro p hp
  have h : env52430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52429_52430 : H12AffineEnvironment.transform 11 1045 env52429 = env52430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env52429 == env52430) = true)

theorem identity52430 : scanCanonicalize (H12AffineFastState.compose env52430 (packedSelected [2,11] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound52430 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env52431 : List Nat := [2,4,8,16,1,17,8,5,512,21,2048,0,9,2074,0,3,2058,10,20,1,17,0,16,3,9,17,10,0,2059,11,20,2058,4,2059,16,512]

theorem envBound52431 : H12AffineFastState.Bounded env52431 := by
  intro p hp
  have h : env52431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52430_52431 : H12AffineEnvironment.transform 9 21 env52430 = env52431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env52430 == env52431) = true)

theorem identity52431 : scanCanonicalize (H12AffineFastState.compose env52431 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 19) := by decide +kernel

theorem selectedBound52431 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env52432 : List Nat := [2,4,8,16,1,17,8,5,512,21,19,0,9,9,0,3,25,10,20,1,17,0,16,3,9,17,10,0,24,11,20,25,4,24,16,512]

theorem envBound52432 : H12AffineFastState.Bounded env52432 := by
  intro p hp
  have h : env52432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52431_52432 : H12AffineEnvironment.transform 10 19 env52431 = env52432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 19 env52431 == env52432) = true)

def env52433 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,4160,392286,73754,41311,8193,64,64605,79130,91403,303453,1364,272393,257,21792,46093,74250]

theorem envBound52433 : H12AffineFastState.Bounded env52433 := by
  intro p hp
  have h : env52433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52420_52433 : H12AffineEnvironment.transform 6 9 env52420 = env52433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52420 == env52433) = true)

theorem identity52433 : scanCanonicalize (H12AffineFastState.compose env52433 (packedSelected [1,4,5,9,11,12,14,19,20,24,26,28,31,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound52433 : packedSelected [1,4,5,9,11,12,14,19,20,24,26,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env52434 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40970,57676,262144,1025,32769,4160,285780,32784,41311,8193,64,64605,38160,50433,303453,1364,272393,257,21792,46093,33280]

theorem envBound52434 : H12AffineFastState.Bounded env52434 := by
  intro p hp
  have h : env52434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52433_52434 : H12AffineEnvironment.transform 15 40970 env52433 = env52434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env52433 == env52434) = true)

theorem identity52434 : scanCanonicalize (H12AffineFastState.compose env52434 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound52434 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env52435 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40970,57676,35189,1025,32769,4160,54561,32784,41311,8193,64,64605,38160,50433,10280,1364,41340,257,21792,46093,33280]

theorem envBound52435 : H12AffineFastState.Bounded env52435 := by
  intro p hp
  have h : env52435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52434_52435 : H12AffineEnvironment.transform 17 35189 env52434 = env52435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env52434 == env52435) = true)

theorem identity52435 : scanCanonicalize (H12AffineFastState.compose env52435 (packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound52435 : packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env52436 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,40970,46156,35189,1025,32769,4160,32801,32784,41311,8193,64,43357,38160,36865,10280,1364,41340,257,32,46093,33280]

theorem envBound52436 : H12AffineFastState.Bounded env52436 := by
  intro p hp
  have h : env52436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52435_52436 : H12AffineEnvironment.transform 13 5376 env52435 = env52436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env52435 == env52436) = true)

theorem identity52436 : scanCanonicalize (H12AffineFastState.compose env52436 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound52436 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env52437 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,343,5393,10280,1025,8540,4160,8572,8525,2,8193,64,2048,13389,12636,10280,1364,33,257,32,5456,9053]

theorem envBound52437 : H12AffineFastState.Bounded env52437 := by
  intro p hp
  have h : env52437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52436_52437 : H12AffineEnvironment.transform 14 8541 env52436 = env52437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env52436 == env52437) = true)

theorem identity52437 : scanCanonicalize (H12AffineFastState.compose env52437 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound52437 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52438 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,5376,1296,343,5393,3173,1025,1297,4160,1329,1280,2,1100,64,2048,4096,5393,3173,1364,33,257,32,5456,1808]

theorem envBound52438 : H12AffineFastState.Bounded env52438 := by
  intro p hp
  have h : env52438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52437_52438 : H12AffineEnvironment.transform 12 1101 env52437 = env52438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env52437 == env52438) = true)

theorem identity52438 : scanCanonicalize (H12AffineFastState.compose env52438 (packedSelected [4,6,9] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound52438 : packedSelected [4,6,9] rootPS < 2^1333 := by decide +kernel

def env52439 : List Nat := [2,4,8,16,32,64,9,256,512,304,2048,4096,381,4144,32,343,4129,2389,305,33,4160,1,48,2,380,64,2048,4096,4129,2389,100,33,257,32,4192,544]

theorem envBound52439 : H12AffineFastState.Bounded env52439 := by
  intro p hp
  have h : env52439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52438_52439 : H12AffineEnvironment.transform 9 304 env52438 = env52439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env52438 == env52439) = true)

theorem identity52439 : scanCanonicalize (H12AffineFastState.compose env52439 (packedSelected [1,3,11] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound52439 : packedSelected [1,3,11] rootPS < 2^1333 := by decide +kernel

def env52440 : List Nat := [2,4,8,16,32,64,9,256,512,304,2048,2404,381,2388,32,343,2373,2389,305,33,2340,1,48,2,380,64,2048,2404,2373,2389,100,33,257,32,2308,544]

theorem envBound52440 : H12AffineFastState.Bounded env52440 := by
  intro p hp
  have h : env52440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52439_52440 : H12AffineEnvironment.transform 11 2404 env52439 = env52440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env52439 == env52440) = true)

theorem identity52440 : scanCanonicalize (H12AffineFastState.compose env52440 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 836) := by decide +kernel

theorem selectedBound52440 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env52441 : List Nat := [2,4,8,16,32,64,9,256,512,304,836,544,381,528,32,343,513,529,305,33,608,1,48,2,380,64,836,544,513,529,100,33,257,32,576,544]

theorem envBound52441 : H12AffineFastState.Bounded env52441 := by
  intro p hp
  have h : env52441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52440_52441 : H12AffineEnvironment.transform 10 836 env52440 = env52441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 836 env52440 == env52441) = true)

theorem identity52441 : scanCanonicalize (H12AffineFastState.compose env52441 (packedSelected [2,3,4,5,7,12] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound52441 : packedSelected [2,3,4,5,7,12] rootPS < 2^1333 := by decide +kernel

def env52442 : List Nat := [2,4,8,16,32,64,9,4,512,52,576,544,121,528,32,83,513,529,53,33,608,1,48,2,120,64,576,544,513,529,100,33,5,32,576,544]

theorem envBound52442 : H12AffineFastState.Bounded env52442 := by
  intro p hp
  have h : env52442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52441_52442 : H12AffineEnvironment.transform 7 4 env52441 = env52442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env52441 == env52442) = true)

theorem identity52442 : scanCanonicalize (H12AffineFastState.compose env52442 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52442 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52443 : List Nat := [2,4,8,16,32,17,9,4,512,52,529,544,40,528,32,2,513,529,53,33,561,1,48,2,41,17,529,544,513,529,53,33,5,32,529,544]

theorem envBound52443 : H12AffineFastState.Bounded env52443 := by
  intro p hp
  have h : env52443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52442_52443 : H12AffineEnvironment.transform 5 17 env52442 = env52443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52442 == env52443) = true)

theorem identity52443 : scanCanonicalize (H12AffineFastState.compose env52443 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound52443 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52444 : List Nat := [2,4,8,1,32,0,9,4,512,37,512,544,40,513,32,2,513,512,36,33,544,1,33,2,41,0,512,544,513,512,36,33,5,32,512,544]

theorem envBound52444 : H12AffineFastState.Bounded env52444 := by
  intro p hp
  have h : env52444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52443_52444 : H12AffineEnvironment.transform 3 1 env52443 = env52444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env52443 == env52444) = true)

theorem identity52444 : scanCanonicalize (H12AffineFastState.compose env52444 (packedSelected [2,4] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound52444 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env52445 : List Nat := [2,4,8,1,32,0,9,4,33,37,33,1,40,32,32,2,32,33,36,33,1,1,33,2,41,0,33,1,32,33,36,33,5,32,33,1]

theorem envBound52445 : H12AffineFastState.Bounded env52445 := by
  intro p hp
  have h : env52445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52444_52445 : H12AffineEnvironment.transform 8 33 env52444 = env52445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env52444 == env52445) = true)

theorem identity52445 : scanCanonicalize (H12AffineFastState.compose env52445 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52445 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52446 : List Nat := [2,4,8,1,1,0,9,4,0,4,0,1,9,1,1,2,1,0,5,0,1,1,0,2,8,0,0,1,1,0,5,0,5,1,0,1]

theorem envBound52446 : H12AffineFastState.Bounded env52446 := by
  intro p hp
  have h : env52446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52445_52446 : H12AffineEnvironment.transform 4 1 env52445 = env52446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52445 == env52446) = true)

def env52447 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441745,156116,253977,8328,64,64604,160980,140484,303573,1500,272392,257,21792,46212,74251]

theorem envBound52447 : H12AffineFastState.Bounded env52447 := by
  intro p hp
  have h : env52447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52418_52447 : H12AffineEnvironment.transform 20 4161 env52418 = env52447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env52418 == env52447) = true)

theorem identity52447 : scanCanonicalize (H12AffineFastState.compose env52447 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound52447 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52448 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,4161,441745,156116,144583,8328,64,64604,160980,140484,303573,1500,272392,257,21792,46212,63189]

theorem envBound52448 : H12AffineFastState.Bounded env52448 := by
  intro p hp
  have h : env52448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52447_52448 : H12AffineEnvironment.transform 15 54494 env52447 = env52448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env52447 == env52448) = true)

def env52449 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,262144,1025,32769,4113,441745,156036,144535,8328,16,64524,160900,140436,303493,1420,272392,257,21792,46212,63109]

theorem envBound52449 : H12AffineFastState.Bounded env52449 := by
  intro p hp
  have h : env52449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52448_52449 : H12AffineEnvironment.transform 5 16 env52448 = env52449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52448 == env52449) = true)

theorem identity52449 : scanCanonicalize (H12AffineFastState.compose env52449 (packedSelected [3,4,7,9,12,19,24,27,31,41] rootPS)) = affineNative (2^(17+1) ^^^ 157752) := by decide +kernel

theorem selectedBound52449 : packedSelected [3,4,7,9,12,19,24,27,31,41] rootPS < 2^1333 := by decide +kernel

def env52450 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,157752,1025,32769,4113,54697,156036,144535,8328,16,64524,160900,140436,182717,1420,147504,257,21792,46212,63109]

theorem envBound52450 : H12AffineFastState.Bounded env52450 := by
  intro p hp
  have h : env52450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52449_52450 : H12AffineEnvironment.transform 17 157752 env52449 = env52450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157752 env52449 == env52450) = true)

theorem identity52450 : scanCanonicalize (H12AffineFastState.compose env52450 (packedSelected [0,1,3,4,5,7,8,14,18,22,23,26,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound52450 : packedSelected [0,1,3,4,5,7,8,14,18,22,23,26,31,35] rootPS < 2^1333 := by decide +kernel

def env52451 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,5529,32161,1025,32769,4113,54697,29725,8462,8328,16,64524,24861,12557,56356,1420,21929,257,21792,46212,63109]

theorem envBound52451 : H12AffineFastState.Bounded env52451 := by
  intro p hp
  have h : env52451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52450_52451 : H12AffineEnvironment.transform 16 5529 env52450 = env52451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env52450 == env52451) = true)

theorem identity52451 : scanCanonicalize (H12AffineFastState.compose env52451 (packedSelected [0,1,4,5,7,8,16,17,18,20,22,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 21897) := by decide +kernel

theorem selectedBound52451 : packedSelected [0,1,4,5,7,8,16,17,18,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env52452 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21897,263,5529,32161,1025,21896,4113,32,29725,8462,8328,16,10629,24861,12557,2477,1420,21929,257,21792,24845,8972]

theorem envBound52452 : H12AffineFastState.Bounded env52452 := by
  intro p hp
  have h : env52452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52451_52452 : H12AffineEnvironment.transform 14 21897 env52451 = env52452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21897 env52451 == env52452) = true)

theorem identity52452 : scanCanonicalize (H12AffineFastState.compose env52452 (packedSelected [16,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound52452 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env52453 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,21897,263,5529,23724,1025,21896,4113,32,21776,3,389,16,2184,16400,4096,2477,1420,21929,257,21792,16384,513]

theorem envBound52453 : H12AffineFastState.Bounded env52453 := by
  intro p hp
  have h : env52453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52452_52453 : H12AffineEnvironment.transform 12 269 env52452 = env52453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env52452 == env52453) = true)

theorem identity52453 : scanCanonicalize (H12AffineFastState.compose env52453 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound52453 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52454 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,21760,263,5392,23589,1025,21761,4113,32,21776,3,268,16,2049,16400,4096,2340,1285,21792,257,21792,16384,513]

theorem envBound52454 : H12AffineFastState.Bounded env52454 := by
  intro p hp
  have h : env52454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52453_52454 : H12AffineEnvironment.transform 6 9 env52453 = env52454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52453 == env52454) = true)

theorem identity52454 : scanCanonicalize (H12AffineFastState.compose env52454 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound52454 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env52455 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,4096,269,16384,20789,263,4389,22544,52,20788,4113,32,20773,3,268,16,2049,16400,4096,2340,304,20757,257,20757,16384,513]

theorem envBound52455 : H12AffineFastState.Bounded env52455 := by
  intro p hp
  have h : env52455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52454_52455 : H12AffineEnvironment.transform 9 53 env52454 = env52455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env52454 == env52455) = true)

theorem identity52455 : scanCanonicalize (H12AffineFastState.compose env52455 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound52455 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env52456 : List Nat := [2,4,8,16,32,16,9,256,512,53,1,4096,269,16384,20789,263,4389,20497,52,20788,4113,32,20773,3,268,16,0,16400,4096,293,304,20757,257,20757,16384,513]

theorem envBound52456 : H12AffineFastState.Bounded env52456 := by
  intro p hp
  have h : env52456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52455_52456 : H12AffineEnvironment.transform 10 1 env52455 = env52456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env52455 == env52456) = true)

theorem identity52456 : scanCanonicalize (H12AffineFastState.compose env52456 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound52456 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env52457 : List Nat := [2,4,8,16,32,16,9,256,512,53,1,4096,269,4404,1,263,4389,293,52,0,4113,32,17,3,268,16,0,4388,4096,293,304,33,257,33,4404,513]

theorem envBound52457 : H12AffineFastState.Bounded env52457 := by
  intro p hp
  have h : env52457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52456_52457 : H12AffineEnvironment.transform 13 4404 env52456 = env52457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env52456 == env52457) = true)

theorem identity52457 : scanCanonicalize (H12AffineFastState.compose env52457 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound52457 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52458 : List Nat := [2,4,8,16,32,16,9,5,512,53,1,4096,8,4145,1,2,4128,32,52,0,4113,32,17,3,9,16,0,4129,4096,32,53,33,4,33,4145,513]

theorem envBound52458 : H12AffineFastState.Bounded env52458 := by
  intro p hp
  have h : env52458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52457_52458 : H12AffineEnvironment.transform 7 5 env52457 = env52458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env52457 == env52458) = true)

theorem identity52458 : scanCanonicalize (H12AffineFastState.compose env52458 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 570) := by decide +kernel

theorem selectedBound52458 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52459 : List Nat := [2,4,8,16,32,16,9,5,512,53,1,570,8,523,1,2,538,32,52,0,555,32,17,3,9,16,0,539,570,32,53,33,4,33,523,513]

theorem envBound52459 : H12AffineFastState.Bounded env52459 := by
  intro p hp
  have h : env52459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52458_52459 : H12AffineEnvironment.transform 11 570 env52458 = env52459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 570 env52458 == env52459) = true)

theorem identity52459 : scanCanonicalize (H12AffineFastState.compose env52459 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound52459 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52460 : List Nat := [2,4,2,16,32,16,3,5,512,53,1,560,2,513,1,2,528,32,52,0,545,32,17,3,3,16,0,529,560,32,53,33,4,33,513,513]

theorem envBound52460 : H12AffineFastState.Bounded env52460 := by
  intro p hp
  have h : env52460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52459_52460 : H12AffineEnvironment.transform 2 2 env52459 = env52460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env52459 == env52460) = true)

theorem identity52460 : scanCanonicalize (H12AffineFastState.compose env52460 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 52) := by decide +kernel

theorem selectedBound52460 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52461 : List Nat := [2,4,2,16,32,16,3,5,52,53,1,4,2,53,1,2,36,32,52,0,21,32,17,3,3,16,0,37,4,32,53,33,4,33,53,53]

theorem envBound52461 : H12AffineFastState.Bounded env52461 := by
  intro p hp
  have h : env52461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52460_52461 : H12AffineEnvironment.transform 8 52 env52460 = env52461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 52 env52460 == env52461) = true)

theorem identity52461 : scanCanonicalize (H12AffineFastState.compose env52461 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound52461 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52462 : List Nat := [2,4,2,16,17,16,3,5,5,4,1,4,2,4,1,2,21,17,5,0,21,17,17,3,3,16,0,20,4,17,4,16,4,16,4,4]

theorem envBound52462 : H12AffineFastState.Bounded env52462 := by
  intro p hp
  have h : env52462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52461_52462 : H12AffineEnvironment.transform 4 17 env52461 = env52462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env52461 == env52462) = true)

theorem identity52462 : scanCanonicalize (H12AffineFastState.compose env52462 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound52462 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env52463 : List Nat := [2,4,2,4,5,4,3,5,5,4,1,4,2,4,1,2,1,5,5,0,1,5,5,3,3,4,0,0,4,5,4,4,4,4,4,4]

theorem envBound52463 : H12AffineFastState.Bounded env52463 := by
  intro p hp
  have h : env52463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52462_52463 : H12AffineEnvironment.transform 3 4 env52462 = env52463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env52462 == env52463) = true)

theorem identity52463 : scanCanonicalize (H12AffineFastState.compose env52463 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound52463 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52464 : List Nat := [2,2,2,2,3,2,3,3,3,2,1,2,2,2,1,2,1,3,3,0,1,3,3,3,3,2,0,0,2,3,2,2,2,2,2,2]

theorem envBound52464 : H12AffineFastState.Bounded env52464 := by
  intro p hp
  have h : env52464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52463_52464 : H12AffineEnvironment.transform 1 2 env52463 = env52464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env52463 == env52464) = true)

def env52465 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,262144,1025,32769,4112,441745,156037,144534,8328,17,64525,160901,140437,303492,1421,272392,257,21792,46212,63108]

theorem envBound52465 : H12AffineFastState.Bounded env52465 := by
  intro p hp
  have h : env52465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52448_52465 : H12AffineEnvironment.transform 5 17 env52448 = env52465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52448 == env52465) = true)

theorem identity52465 : scanCanonicalize (H12AffineFastState.compose env52465 (packedSelected [1,5,8,11,16,17,20,24,32] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound52465 : packedSelected [1,5,8,11,16,17,20,24,32] rootPS < 2^1333 := by decide +kernel

def env52466 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,33030,131072,262144,1025,32769,4112,441745,144396,144534,8328,17,43396,139532,140437,303492,1421,272392,257,169,46212,41741]

theorem envBound52466 : H12AffineFastState.Bounded env52466 := by
  intro p hp
  have h : env52466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52465_52466 : H12AffineEnvironment.transform 13 5513 env52465 = env52466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env52465 == env52466) = true)

theorem identity52466 : scanCanonicalize (H12AffineFastState.compose env52466 (packedSelected [3,4,5,7,8,9,16,17,18,20,23,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 35109) := by decide +kernel

theorem selectedBound52466 : packedSelected [3,4,5,7,8,9,16,17,18,20,23,27,28] rootPS < 2^1333 := by decide +kernel

def env52467 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,33030,131072,35109,1025,32769,4112,144564,144396,144534,8328,17,43396,139532,140437,10401,1421,41261,257,169,46212,41741]

theorem envBound52467 : H12AffineFastState.Bounded env52467 := by
  intro p hp
  have h : env52467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52466_52467 : H12AffineEnvironment.transform 17 35109 env52466 = env52467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35109 env52466 == env52467) = true)

theorem identity52467 : scanCanonicalize (H12AffineFastState.compose env52467 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 38296) := by decide +kernel

theorem selectedBound52467 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env52468 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,33030,38296,35109,1025,32769,4112,41260,41364,41230,8328,17,43396,46228,45325,10401,1421,41261,257,169,46212,41741]

theorem envBound52468 : H12AffineFastState.Bounded env52468 := by
  intro p hp
  have h : env52468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52467_52468 : H12AffineEnvironment.transform 16 38296 env52467 = env52468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env52467 == env52468) = true)

theorem identity52468 : scanCanonicalize (H12AffineFastState.compose env52468 (packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound52468 : packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS < 2^1333 := by decide +kernel

def env52469 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5513,32768,33030,38296,35109,1025,32769,4112,32800,32920,32770,388,17,34952,38296,36865,2477,1421,32801,257,169,38280,33281]

theorem envBound52469 : H12AffineFastState.Bounded env52469 := by
  intro p hp
  have h : env52469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52468_52469 : H12AffineEnvironment.transform 12 268 env52468 = env52469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env52468 == env52469) = true)

theorem identity52469 : scanCanonicalize (H12AffineFastState.compose env52469 (packedSelected [0,3,5,7,11,17] rootPS)) = affineNative (2^(14+1) ^^^ 1448) := by decide +kernel

theorem selectedBound52469 : packedSelected [0,3,5,7,11,17] rootPS < 2^1333 := by decide +kernel

def env52470 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5513,1448,1198,4144,3213,1025,1449,4112,1416,1328,1450,388,17,3360,4144,5545,2477,1421,1417,257,169,4128,1961]

theorem envBound52470 : H12AffineFastState.Bounded env52470 := by
  intro p hp
  have h : env52470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52469_52470 : H12AffineEnvironment.transform 14 1448 env52469 = env52470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1448 env52469 == env52470) = true)

theorem identity52470 : scanCanonicalize (H12AffineFastState.compose env52470 (packedSelected [0,1,3,5,6,7,8,11,16] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound52470 : packedSelected [0,1,3,5,6,7,8,11,16] rootPS < 2^1333 := by decide +kernel

def env52471 : List Nat := [2,4,8,16,32,17,128,256,512,20,2048,4096,268,4509,444,186,4144,2201,21,445,4112,412,292,446,388,17,2356,4144,4541,2477,409,413,257,169,4128,957]

theorem envBound52471 : H12AffineFastState.Bounded env52471 := by
  intro p hp
  have h : env52471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52470_52471 : H12AffineEnvironment.transform 9 20 env52470 = env52471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env52470 == env52471) = true)

theorem identity52471 : scanCanonicalize (H12AffineFastState.compose env52471 (packedSelected [0,1,4,7,8,9,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound52471 : packedSelected [0,1,4,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env52472 : List Nat := [2,4,8,16,32,17,40,256,512,20,2048,4096,268,4405,276,18,4144,2097,21,277,4112,308,292,278,300,17,2356,4144,4373,2309,305,309,257,1,4128,789]

theorem envBound52472 : H12AffineFastState.Bounded env52472 := by
  intro p hp
  have h : env52472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52471_52472 : H12AffineEnvironment.transform 6 40 env52471 = env52472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env52471 == env52472) = true)

theorem identity52472 : scanCanonicalize (H12AffineFastState.compose env52472 (packedSelected [2,14] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52472 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env52473 : List Nat := [2,4,8,16,1,17,9,256,512,20,2048,4096,268,4372,276,18,4113,2064,21,277,4112,277,261,278,269,17,2325,4113,4373,2309,272,276,257,1,4097,789]

theorem envBound52473 : H12AffineFastState.Bounded env52473 := by
  intro p hp
  have h : env52473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52472_52473 : H12AffineEnvironment.transform 4 1 env52472 = env52473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52472 == env52473) = true)

def env52474 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507600,155254785,25265168,145662400,525568,140903596,27337992,25733063]

theorem envBound52474 : H12AffineFastState.Bounded env52474 := by
  intro p hp
  have h : env52474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51619_52474 : H12AffineEnvironment.transform 25 65 env51619 = env52474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env51619 == env52474) = true)

def env52475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507600,9356289,25265168,23160256,525568,27902124,27337992,25733063]

theorem envBound52475 : H12AffineFastState.Bounded env52475 := by
  intro p hp
  have h : env52475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52474_52475 : H12AffineEnvironment.transform 26 30393344 env52474 = env52475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env52474 == env52475) = true)

def env52476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830977,25265168,23160256,256,27378860,27337992,25207751]

theorem envBound52476 : H12AffineFastState.Bounded env52476 := by
  intro p hp
  have h : env52476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52475_52476 : H12AffineEnvironment.transform 18 1024 env52475 = env52476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env52475 == env52476) = true)

theorem identity52476 : scanCanonicalize (H12AffineFastState.compose env52476 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 437625) := by decide +kernel

theorem selectedBound52476 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env52477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,4194304,8388608,16777216,8328,65,29868032,17246708,8845353,8830977,25265168,21481657,256,25651669,25659505,25207751]

theorem envBound52477 : H12AffineFastState.Bounded env52477 := by
  intro p hp
  have h : env52477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52476_52477 : H12AffineEnvironment.transform 20 437625 env52476 = env52477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437625 env52476 == env52477) = true)

def env52478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,4194304,8388608,8862964,8328,65,4259060,8393984,8845353,8830977,440548,12645453,256,21793,46213,499507]

theorem envBound52478 : H12AffineFastState.Bounded env52478 := by
  intro p hp
  have h : env52478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52477_52478 : H12AffineEnvironment.transform 23 8862964 env52477 = env52478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8862964 env52477 == env52478) = true)

def env52479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,4194304,441640,98780,8328,65,4259060,436264,17665,32041,440548,4606309,256,21793,46213,499507]

theorem envBound52479 : H12AffineFastState.Bounded env52479 := by
  intro p hp
  have h : env52479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52478_52479 : H12AffineEnvironment.transform 22 441640 env52478 = env52479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441640 env52478 == env52479) = true)

def env52480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,272512,441640,98780,8328,65,316532,436264,17665,32041,440548,156133,256,21793,46213,499507]

theorem envBound52480 : H12AffineFastState.Bounded env52480 := by
  intro p hp
  have h : env52480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52479_52480 : H12AffineEnvironment.transform 21 272512 env52479 = env52480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env52479 == env52480) = true)

theorem identity52480 : scanCanonicalize (H12AffineFastState.compose env52480 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound52480 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52481 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,437625,272512,441640,21763,8328,65,316532,436264,17665,32041,440548,156133,256,21793,46213,412652]

theorem envBound52481 : H12AffineFastState.Bounded env52481 := by
  intro p hp
  have h : env52481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52480_52481 : H12AffineEnvironment.transform 15 54495 env52480 = env52481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env52480 == env52481) = true)

def env52482 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,437625,272392,441640,21763,8192,65,316532,436264,17665,32041,440428,156013,256,21793,46093,412516]

theorem envBound52482 : H12AffineFastState.Bounded env52482 := by
  intro p hp
  have h : env52482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52481_52482 : H12AffineEnvironment.transform 6 8 env52481 = env52482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52481 == env52482) = true)

theorem identity52482 : scanCanonicalize (H12AffineFastState.compose env52482 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound52482 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env52483 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,54359,131072,262144,1024,32769,429093,264532,433268,21763,348,65,316532,428404,17665,23669,432432,147505,256,21793,38225,412516]

theorem envBound52483 : H12AffineFastState.Bounded env52483 := by
  intro p hp
  have h : env52483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52482_52483 : H12AffineEnvironment.transform 12 348 env52482 = env52483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env52482 == env52483) = true)

theorem identity52483 : scanCanonicalize (H12AffineFastState.compose env52483 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 182628) := by decide +kernel

theorem selectedBound52483 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env52484 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,54359,131072,182628,1024,32769,17729,180272,21776,21763,348,65,138512,16400,17665,23669,20564,147505,256,21793,38225,33280]

theorem envBound52484 : H12AffineFastState.Bounded env52484 := by
  intro p hp
  have h : env52484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52483_52484 : H12AffineEnvironment.transform 17 182628 env52483 = env52484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182628 env52483 == env52484) = true)

theorem identity52484 : scanCanonicalize (H12AffineFastState.compose env52484 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound52484 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env52485 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,54359,5393,56437,1024,32769,17729,54561,21776,21763,348,65,2049,16400,17665,23669,20564,21792,256,21793,38225,33280]

theorem envBound52485 : H12AffineFastState.Bounded env52485 := by
  intro p hp
  have h : env52485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52484_52485 : H12AffineEnvironment.transform 16 5393 env52484 = env52485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env52484 == env52485) = true)

theorem identity52485 : scanCanonicalize (H12AffineFastState.compose env52485 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound52485 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env52486 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,342,5393,2420,1024,21760,17729,32,21776,21763,348,65,2049,16400,17665,23669,20564,21792,256,21793,16464,22273]

theorem envBound52486 : H12AffineFastState.Bounded env52486 := by
  intro p hp
  have h : env52486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52485_52486 : H12AffineEnvironment.transform 14 21761 env52485 = env52486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env52485 == env52486) = true)

theorem identity52486 : scanCanonicalize (H12AffineFastState.compose env52486 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound52486 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env52487 : List Nat := [2,4,8,16,32,64,8,5,512,1024,2048,4096,89,16384,21508,83,5140,2161,1024,21509,17476,32,21525,21510,89,65,2049,16400,17412,23669,20564,21541,5,21540,16464,22020]

theorem envBound52487 : H12AffineFastState.Bounded env52487 := by
  intro p hp
  have h : env52487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52486_52487 : H12AffineEnvironment.transform 7 5 env52486 = env52487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env52486 == env52487) = true)

theorem identity52487 : scanCanonicalize (H12AffineFastState.compose env52487 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound52487 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52488 : List Nat := [2,4,8,16,32,64,8,5,512,20,2048,4096,89,16384,20496,83,4096,2161,20,20497,16464,32,20481,20498,89,65,2049,16400,16400,22625,20564,20529,5,20528,16464,21008]

theorem envBound52488 : H12AffineFastState.Bounded env52488 := by
  intro p hp
  have h : env52488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52487_52488 : H12AffineEnvironment.transform 9 20 env52487 = env52488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env52487 == env52488) = true)

theorem identity52488 : scanCanonicalize (H12AffineFastState.compose env52488 (packedSelected [0,1,3,5,7,8,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound52488 : packedSelected [0,1,3,5,7,8,12,14] rootPS < 2^1333 := by decide +kernel

def env52489 : List Nat := [2,4,8,16,32,64,8,5,512,20,2048,4096,89,2048,6160,83,4096,2161,20,6161,2128,32,6145,6162,89,65,2049,2064,2064,4193,6228,6193,5,6192,2128,6672]

theorem envBound52489 : H12AffineFastState.Bounded env52489 := by
  intro p hp
  have h : env52489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52488_52489 : H12AffineEnvironment.transform 13 2048 env52488 = env52489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env52488 == env52489) = true)

theorem identity52489 : scanCanonicalize (H12AffineFastState.compose env52489 (packedSelected [3,4,5,6,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 545) := by decide +kernel

theorem selectedBound52489 : packedSelected [3,4,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env52490 : List Nat := [2,4,8,16,32,64,8,5,512,20,2048,545,89,2048,2609,83,545,2161,20,2608,2128,32,2592,2611,89,65,2049,2064,2064,576,2677,2576,5,2577,2128,2097]

theorem envBound52490 : H12AffineFastState.Bounded env52490 := by
  intro p hp
  have h : env52490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52489_52490 : H12AffineEnvironment.transform 11 545 env52489 = env52490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env52489 == env52490) = true)

theorem identity52490 : scanCanonicalize (H12AffineFastState.compose env52490 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound52490 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env52491 : List Nat := [2,4,8,16,32,64,8,5,512,20,529,545,89,529,32,83,545,608,20,33,577,32,49,34,89,65,528,513,513,576,100,1,5,0,577,544]

theorem envBound52491 : H12AffineFastState.Bounded env52491 := by
  intro p hp
  have h : env52491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52490_52491 : H12AffineEnvironment.transform 10 529 env52490 = env52491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env52490 == env52491) = true)

theorem identity52491 : scanCanonicalize (H12AffineFastState.compose env52491 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound52491 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env52492 : List Nat := [2,4,8,16,32,49,8,5,512,20,529,545,40,529,32,34,545,529,20,33,560,32,49,34,40,48,528,513,513,561,21,1,5,0,560,544]

theorem envBound52492 : H12AffineFastState.Bounded env52492 := by
  intro p hp
  have h : env52492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52491_52492 : H12AffineEnvironment.transform 5 49 env52491 = env52492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env52491 == env52492) = true)

theorem identity52492 : scanCanonicalize (H12AffineFastState.compose env52492 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound52492 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52493 : List Nat := [2,4,8,16,32,49,8,5,33,20,48,0,40,48,32,34,0,48,20,33,17,32,49,34,40,48,49,32,32,16,21,1,5,0,17,1]

theorem envBound52493 : H12AffineFastState.Bounded env52493 := by
  intro p hp
  have h : env52493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52492_52493 : H12AffineEnvironment.transform 8 33 env52492 = env52493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env52492 == env52493) = true)

theorem identity52493 : scanCanonicalize (H12AffineFastState.compose env52493 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52493 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52494 : List Nat := [2,4,8,16,1,16,8,5,0,20,17,0,9,17,1,3,0,17,20,0,17,1,16,3,9,17,16,1,1,16,21,1,5,0,17,1]

theorem envBound52494 : H12AffineFastState.Bounded env52494 := by
  intro p hp
  have h : env52494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52493_52494 : H12AffineEnvironment.transform 4 1 env52493 = env52494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52493 == env52494) = true)

def env52495 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,437625,272393,441640,21763,8193,65,316532,436264,17665,32041,440429,156012,256,21793,46092,412517]

theorem envBound52495 : H12AffineFastState.Bounded env52495 := by
  intro p hp
  have h : env52495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52481_52495 : H12AffineEnvironment.transform 6 9 env52481 = env52495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52481 == env52495) = true)

theorem identity52495 : scanCanonicalize (H12AffineFastState.compose env52495 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound52495 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env52496 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10281,1024,32769,165200,32,169217,21763,8193,65,64605,163841,17665,32041,168004,156012,256,21793,46092,156492]

theorem envBound52496 : H12AffineFastState.Bounded env52496 := by
  intro p hp
  have h : env52496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52495_52496 : H12AffineEnvironment.transform 17 10281 env52495 = env52496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env52495 == env52496) = true)

theorem identity52496 : scanCanonicalize (H12AffineFastState.compose env52496 (packedSelected [3,4,8,9,12,14,15,16,19,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound52496 : packedSelected [3,4,8,9,12,14,15,16,19,24,28] rootPS < 2^1333 := by decide +kernel

def env52497 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,49168,10281,1024,32769,17728,32,21777,21763,8193,65,64605,16401,17665,32041,20564,41340,256,21793,46092,41820]

theorem envBound52497 : H12AffineFastState.Bounded env52497 := by
  intro p hp
  have h : env52497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52496_52497 : H12AffineEnvironment.transform 16 49168 env52496 = env52497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env52496 == env52497) = true)

theorem identity52497 : scanCanonicalize (H12AffineFastState.compose env52497 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound52497 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env52498 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,29963,24909,10281,1024,8540,17728,32,21777,21763,8193,65,23808,16401,17665,32041,20564,33,256,21793,5457,513]

theorem envBound52498 : H12AffineFastState.Bounded env52498 := by
  intro p hp
  have h : env52498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52497_52498 : H12AffineEnvironment.transform 14 8541 env52497 = env52498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env52497 == env52498) = true)

theorem identity52498 : scanCanonicalize (H12AffineFastState.compose env52498 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52498 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env52499 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,29963,24860,10281,1024,8461,17681,32,21777,21763,8193,16,23808,16401,17665,32041,20485,33,256,21793,5376,513]

theorem envBound52499 : H12AffineFastState.Bounded env52499 := by
  intro p hp
  have h : env52499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52498_52499 : H12AffineEnvironment.transform 5 17 env52498 = env52499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52498 == env52499) = true)

theorem identity52499 : scanCanonicalize (H12AffineFastState.compose env52499 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound52499 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env52500 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,1,21510,16401,2340,1024,0,17681,32,21777,21763,268,16,23808,16401,17665,23588,20485,33,256,21793,5376,513]

theorem envBound52500 : H12AffineFastState.Bounded env52500 := by
  intro p hp
  have h : env52500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52499_52500 : H12AffineEnvironment.transform 12 269 env52499 = env52500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env52499 == env52500) = true)

def env52501 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,272513,441640,98780,8328,65,316533,436264,17665,32041,440548,156132,256,21793,46213,499507]

theorem envBound52501 : H12AffineFastState.Bounded env52501 := by
  intro p hp
  have h : env52501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52479_52501 : H12AffineEnvironment.transform 21 272513 env52479 = env52501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env52479 == env52501) = true)

theorem identity52501 : scanCanonicalize (H12AffineFastState.compose env52501 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223719) := by decide +kernel

theorem selectedBound52501 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52502 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,115870,213350,120015,98780,8328,65,245138,115151,17665,32041,119043,156132,256,21793,46213,63188]

theorem envBound52502 : H12AffineFastState.Bounded env52502 := by
  intro p hp
  have h : env52502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52501_52502 : H12AffineEnvironment.transform 17 223719 env52501 = env52502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223719 env52501 == env52502) = true)

def env52503 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223671,1024,32769,115870,213302,119967,98700,8328,17,245138,115103,17665,32041,119043,156084,256,21793,46213,63108]

theorem envBound52503 : H12AffineFastState.Bounded env52503 := by
  intro p hp
  have h : env52503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52502_52503 : H12AffineEnvironment.transform 5 16 env52502 = env52503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52502 == env52503) = true)

theorem identity52503 : scanCanonicalize (H12AffineFastState.compose env52503 (packedSelected [1,3,10,18,23,24,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound52503 : packedSelected [1,3,10,18,23,24,28,31] rootPS < 2^1333 := by decide +kernel

def env52504 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,35245,1024,32769,115870,41260,119967,98700,8328,17,23944,115103,17665,32041,119043,98734,256,21793,46213,63108]

theorem envBound52504 : H12AffineFastState.Bounded env52504 := by
  intro p hp
  have h : env52504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52503_52504 : H12AffineEnvironment.transform 16 122906 env52503 = env52504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env52503 == env52504) = true)

theorem identity52504 : scanCanonicalize (H12AffineFastState.compose env52504 (packedSelected [3,10,14,16,18,19,20,23,24,35] rootPS)) = affineNative (2^(15+1) ^^^ 62850) := by decide +kernel

theorem selectedBound52504 : packedSelected [3,10,14,16,18,19,20,23,24,35] rootPS < 2^1333 := by decide +kernel

def env52505 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,62850,5528,35245,1024,32769,12572,41260,8477,29710,8328,17,23944,13341,17665,32041,9345,29740,256,21793,46213,63108]

theorem envBound52505 : H12AffineFastState.Bounded env52505 := by
  intro p hp
  have h : env52505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52504_52505 : H12AffineEnvironment.transform 15 62850 env52504 = env52505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62850 env52504 == env52505) = true)

theorem identity52505 : scanCanonicalize (H12AffineFastState.compose env52505 (packedSelected [1,3,5,8,10,17,18,19,23] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound52505 : packedSelected [1,3,5,8,10,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env52506 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5512,32768,40970,5528,35245,1024,32769,12572,41260,8477,8582,8328,17,2048,13341,4233,10401,9345,8612,256,169,46213,41740]

theorem envBound52506 : H12AffineFastState.Bounded env52506 := by
  intro p hp
  have h : env52506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52505_52506 : H12AffineEnvironment.transform 13 5512 env52505 = env52506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env52505 == env52506) = true)

theorem identity52506 : scanCanonicalize (H12AffineFastState.compose env52506 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound52506 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env52507 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5512,32768,33031,5528,35245,1024,32769,4113,32801,16,139,389,17,2048,5392,4233,2476,1420,169,256,169,38280,33281]

theorem envBound52507 : H12AffineFastState.Bounded env52507 := by
  intro p hp
  have h : env52507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52506_52507 : H12AffineEnvironment.transform 12 269 env52506 = env52507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env52506 == env52507) = true)

theorem identity52507 : scanCanonicalize (H12AffineFastState.compose env52507 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 1718) := by decide +kernel

theorem selectedBound52507 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env52508 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1718,4096,269,5512,32768,33031,5528,34587,1024,32769,4113,32801,16,139,389,17,1718,5392,4233,1818,1420,169,256,169,38280,33281]

theorem envBound52508 : H12AffineFastState.Bounded env52508 := by
  intro p hp
  have h : env52508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52507_52508 : H12AffineEnvironment.transform 10 1718 env52507 = env52508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1718 env52507 == env52508) = true)

theorem identity52508 : scanCanonicalize (H12AffineFastState.compose env52508 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound52508 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env52509 : List Nat := [2,4,8,16,32,16,128,37,512,1024,1718,4096,40,5293,32768,32802,5309,34366,1024,32769,4113,32801,16,139,160,17,1718,5173,4233,1599,1193,169,37,169,38061,33281]

theorem envBound52509 : H12AffineFastState.Bounded env52509 := by
  intro p hp
  have h : env52509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52508_52509 : H12AffineEnvironment.transform 7 37 env52508 = env52509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env52508 == env52509) = true)

theorem identity52509 : scanCanonicalize (H12AffineFastState.compose env52509 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound52509 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env52510 : List Nat := [2,4,8,16,32,16,128,37,512,542,168,4096,40,4787,32768,32802,4771,32800,542,32769,4113,32801,16,139,160,17,168,4651,4233,33,695,169,37,169,37555,33281]

theorem envBound52510 : H12AffineFastState.Bounded env52510 := by
  intro p hp
  have h : env52510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52509_52510 : H12AffineEnvironment.transform 9 542 env52509 = env52510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env52509 == env52510) = true)

theorem identity52510 : scanCanonicalize (H12AffineFastState.compose env52510 (packedSelected [2,3,5] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound52510 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env52511 : List Nat := [2,4,8,16,32,16,128,37,512,542,168,4096,40,4787,136,170,4771,168,542,137,4113,169,16,139,160,17,168,4651,4233,33,695,169,37,169,4667,649]

theorem envBound52511 : H12AffineFastState.Bounded env52511 := by
  intro p hp
  have h : env52511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52510_52511 : H12AffineEnvironment.transform 14 136 env52510 = env52511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env52510 == env52511) = true)

theorem identity52511 : scanCanonicalize (H12AffineFastState.compose env52511 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 538) := by decide +kernel

theorem selectedBound52511 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env52512 : List Nat := [2,4,8,16,32,16,128,37,512,542,168,538,40,169,136,170,185,168,542,137,523,169,16,139,160,17,168,49,659,33,695,169,37,169,33,649]

theorem envBound52512 : H12AffineFastState.Bounded env52512 := by
  intro p hp
  have h : env52512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52511_52512 : H12AffineEnvironment.transform 11 538 env52511 = env52512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 538 env52511 == env52512) = true)

theorem identity52512 : scanCanonicalize (H12AffineFastState.compose env52512 (packedSelected [1,2,3,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 60) := by decide +kernel

theorem selectedBound52512 : packedSelected [1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env52513 : List Nat := [2,4,8,16,32,16,60,37,512,542,20,538,40,21,52,22,5,20,542,53,523,21,16,55,28,17,20,49,559,33,523,21,37,21,33,565]

theorem envBound52513 : H12AffineFastState.Bounded env52513 := by
  intro p hp
  have h : env52513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52512_52513 : H12AffineEnvironment.transform 6 60 env52512 = env52513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 60 env52512 == env52513) = true)

theorem identity52513 : scanCanonicalize (H12AffineFastState.compose env52513 (packedSelected [0,2,3,6] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound52513 : packedSelected [0,2,3,6] rootPS < 2^1333 := by decide +kernel

def env52514 : List Nat := [2,4,8,16,2,16,30,7,512,542,20,538,10,21,22,22,5,20,542,23,523,21,16,21,28,17,20,19,525,3,523,21,7,21,3,535]

theorem envBound52514 : H12AffineFastState.Bounded env52514 := by
  intro p hp
  have h : env52514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52513_52514 : H12AffineEnvironment.transform 4 2 env52513 = env52514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env52513 == env52514) = true)

theorem identity52514 : scanCanonicalize (H12AffineFastState.compose env52514 (packedSelected [2,10] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound52514 : packedSelected [2,10] rootPS < 2^1333 := by decide +kernel

def env52515 : List Nat := [2,4,8,16,2,16,30,7,9,23,20,19,10,21,22,22,5,20,23,23,2,21,16,21,28,17,20,19,4,3,2,21,7,21,3,30]

theorem envBound52515 : H12AffineFastState.Bounded env52515 := by
  intro p hp
  have h : env52515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52514_52515 : H12AffineEnvironment.transform 8 9 env52514 = env52515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env52514 == env52515) = true)

theorem identity52515 : scanCanonicalize (H12AffineFastState.compose env52515 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound52515 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env52516 : List Nat := [2,4,8,4,2,4,10,7,9,3,0,7,10,1,2,2,5,0,3,3,2,1,4,1,8,5,0,7,4,3,2,1,7,1,3,10]

theorem envBound52516 : H12AffineFastState.Bounded env52516 := by
  intro p hp
  have h : env52516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52515_52516 : H12AffineEnvironment.transform 3 4 env52515 = env52516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env52515 == env52516) = true)

theorem identity52516 : scanCanonicalize (H12AffineFastState.compose env52516 (packedSelected [0,3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound52516 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env52517 : List Nat := [1,4,8,4,1,4,9,4,9,0,0,4,9,1,1,1,5,0,0,0,1,1,4,1,8,5,0,4,4,0,1,1,4,1,0,9]

theorem envBound52517 : H12AffineFastState.Bounded env52517 := by
  intro p hp
  have h : env52517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52516_52517 : H12AffineEnvironment.transform 0 1 env52516 = env52517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env52516 == env52517) = true)

theorem identity52517 : scanCanonicalize (H12AffineFastState.compose env52517 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound52517 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52518 : List Nat := [1,4,5,4,1,4,4,4,4,0,0,4,4,1,1,1,5,0,0,0,1,1,4,1,5,5,0,4,4,0,1,1,4,1,0,4]

theorem envBound52518 : H12AffineFastState.Bounded env52518 := by
  intro p hp
  have h : env52518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52517_52518 : H12AffineEnvironment.transform 2 5 env52517 = env52518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env52517 == env52518) = true)

theorem identity52518 : scanCanonicalize (H12AffineFastState.compose env52518 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound52518 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52519 : List Nat := [1,1,0,1,1,1,1,1,1,0,0,1,1,1,1,1,0,0,0,0,1,1,1,1,0,0,0,1,1,0,1,1,1,1,0,1]

theorem envBound52519 : H12AffineFastState.Bounded env52519 := by
  intro p hp
  have h : env52519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52518_52519 : H12AffineEnvironment.transform 1 1 env52518 = env52519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env52518 == env52519) = true)

def env52520 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223670,1024,32769,115870,213303,119966,98701,8328,16,245138,115102,17665,32041,119043,156085,256,21793,46213,63109]

theorem envBound52520 : H12AffineFastState.Bounded env52520 := by
  intro p hp
  have h : env52520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52502_52520 : H12AffineEnvironment.transform 5 17 env52502 = env52520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52502 == env52520) = true)

theorem identity52520 : scanCanonicalize (H12AffineFastState.compose env52520 (packedSelected [1,3,10,18,23,24,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 54279) := by decide +kernel

theorem selectedBound52520 : packedSelected [1,3,10,18,23,24,28,31] rootPS < 2^1333 := by decide +kernel

def env52521 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54279,131072,179633,1024,32769,4249,169264,153,21898,8328,16,158101,5529,17665,32041,1284,156085,256,21793,46213,63109]

theorem envBound52521 : H12AffineFastState.Bounded env52521 := by
  intro p hp
  have h : env52521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52520_52521 : H12AffineEnvironment.transform 15 54279 env52520 = env52521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54279 env52520 == env52521) = true)

theorem identity52521 : scanCanonicalize (H12AffineFastState.compose env52521 (packedSelected [0,4,7,16,17,19,20,22,26] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound52521 : packedSelected [0,4,7,16,17,19,20,22,26] rootPS < 2^1333 := by decide +kernel

def env52522 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,136,21647,131072,146745,1024,137,4249,136632,153,21898,8328,16,158101,5529,17665,32041,1284,156085,256,21793,13325,30221]

theorem envBound52522 : H12AffineFastState.Bounded env52522 := by
  intro p hp
  have h : env52522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52521_52522 : H12AffineEnvironment.transform 14 136 env52521 = env52522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env52521 == env52522) = true)

theorem identity52522 : scanCanonicalize (H12AffineFastState.compose env52522 (packedSelected [1,10,16,17,19,20,28] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound52522 : packedSelected [1,10,16,17,19,20,28] rootPS < 2^1333 := by decide +kernel

def env52523 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,136,262,131072,146745,1024,137,4249,136632,153,3,8328,16,146460,5529,4232,10400,1284,144444,256,168,13325,9092]

theorem envBound52523 : H12AffineFastState.Bounded env52523 := by
  intro p hp
  have h : env52523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52522_52523 : H12AffineEnvironment.transform 13 5513 env52522 = env52523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env52522 == env52523) = true)

theorem identity52523 : scanCanonicalize (H12AffineFastState.compose env52523 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 13461) := by decide +kernel

theorem selectedBound52523 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env52524 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,136,262,13461,2476,1024,137,4249,8493,153,3,8328,16,2185,5529,4232,10400,1284,169,256,168,13325,9092]

theorem envBound52524 : H12AffineFastState.Bounded env52524 := by
  intro p hp
  have h : env52524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52523_52524 : H12AffineEnvironment.transform 16 13461 env52523 = env52524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13461 env52523 == env52524) = true)

theorem identity52524 : scanCanonicalize (H12AffineFastState.compose env52524 (packedSelected [3,4,5,9,10,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound52524 : packedSelected [3,4,5,9,10,14,15,16] rootPS < 2^1333 := by decide +kernel

def env52525 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,5156,136,171,13461,2049,1024,137,4249,8320,153,3,8328,16,2185,5172,4232,10400,1193,169,173,168,13325,8745]

theorem envBound52525 : H12AffineFastState.Bounded env52525 := by
  intro p hp
  have h : env52525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52524_52525 : H12AffineEnvironment.transform 7 173 env52524 = env52525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env52524 == env52525) = true)

theorem identity52525 : scanCanonicalize (H12AffineFastState.compose env52525 (packedSelected [0,4,7,9,11,14] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound52525 : packedSelected [0,4,7,9,11,14] rootPS < 2^1333 := by decide +kernel

def env52526 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,161,5156,136,171,5172,2049,1024,137,4249,33,153,3,41,16,2185,5172,4232,2049,1193,169,173,168,5292,648]

theorem envBound52526 : H12AffineFastState.Bounded env52526 := by
  intro p hp
  have h : env52526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52525_52526 : H12AffineEnvironment.transform 12 161 env52525 = env52526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env52525 == env52526) = true)

theorem identity52526 : scanCanonicalize (H12AffineFastState.compose env52526 (packedSelected [4,7] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound52526 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env52527 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8,5156,33,2,5172,2049,1024,32,4144,33,48,3,41,16,2080,5172,4129,2049,1024,0,4,1,5125,545]

theorem envBound52527 : H12AffineFastState.Bounded env52527 := by
  intro p hp
  have h : env52527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52526_52527 : H12AffineEnvironment.transform 6 41 env52526 = env52527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env52526 == env52527) = true)

def env52528 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,4194304,441641,98781,8328,65,4259060,436265,17664,32040,440548,4606308,256,21793,46213,499507]

theorem envBound52528 : H12AffineFastState.Bounded env52528 := by
  intro p hp
  have h : env52528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52478_52528 : H12AffineEnvironment.transform 22 441641 env52478 = env52528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441641 env52478 == env52528) = true)

def env52529 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,272512,441641,98781,8328,65,316532,436265,17664,32040,440548,156132,256,21793,46213,499507]

theorem envBound52529 : H12AffineFastState.Bounded env52529 := by
  intro p hp
  have h : env52529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52528_52529 : H12AffineEnvironment.transform 21 272512 env52528 = env52529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env52528 == env52529) = true)

theorem identity52529 : scanCanonicalize (H12AffineFastState.compose env52529 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound52529 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,437625,272512,441641,41430,8328,65,316532,436265,17664,32040,440548,156132,256,21793,46213,442168]

theorem envBound52530 : H12AffineFastState.Bounded env52530 := by
  intro p hp
  have h : env52530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52529_52530 : H12AffineEnvironment.transform 15 8203 env52529 = env52530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env52529 == env52530) = true)

def env52531 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,437625,272392,441641,41310,8192,65,316532,436265,17664,32040,440428,156012,256,21793,46093,442168]

theorem envBound52531 : H12AffineFastState.Bounded env52531 := by
  intro p hp
  have h : env52531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52530_52531 : H12AffineEnvironment.transform 6 8 env52530 = env52531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52530 == env52531) = true)

theorem identity52531 : scanCanonicalize (H12AffineFastState.compose env52531 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound52531 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env52532 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,13389,262144,1024,32769,301364,272392,297316,41310,8192,65,316532,302180,17664,32040,298017,21793,256,21793,46093,297845]

theorem envBound52532 : H12AffineFastState.Bounded env52532 := by
  intro p hp
  have h : env52532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52531_52532 : H12AffineEnvironment.transform 16 13389 env52531 = env52532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env52531 == env52532) = true)

theorem identity52532 : scanCanonicalize (H12AffineFastState.compose env52532 (packedSelected [0,2,3,7,9,10,11,16,17,18,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 34817) := by decide +kernel

theorem selectedBound52532 : packedSelected [0,2,3,7,9,10,11,16,17,18,22,24,26] rootPS < 2^1333 := by decide +kernel

def env52533 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,13389,34817,1024,32769,4405,40969,357,41310,8192,65,23669,5221,17664,32040,1056,21793,256,21793,46093,884]

theorem envBound52533 : H12AffineFastState.Bounded env52533 := by
  intro p hp
  have h : env52533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52532_52533 : H12AffineEnvironment.transform 17 34817 env52532 = env52533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34817 env52532 == env52533) = true)

theorem identity52533 : scanCanonicalize (H12AffineFastState.compose env52533 (packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound52533 : packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS < 2^1333 := by decide +kernel

def env52534 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8203,13389,10589,1024,8541,4405,341,357,2,8192,65,23669,5221,17664,32040,1056,21793,256,21793,5457,884]

theorem envBound52534 : H12AffineFastState.Bounded env52534 := by
  intro p hp
  have h : env52534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52533_52534 : H12AffineEnvironment.transform 14 8540 env52533 = env52534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env52533 == env52534) = true)

theorem identity52534 : scanCanonicalize (H12AffineFastState.compose env52534 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound52534 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env52535 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,8540,8203,13389,10589,1024,8541,4405,341,357,2,8192,65,10588,5221,12329,2049,1056,8200,256,8200,5457,884]

theorem envBound52535 : H12AffineFastState.Bounded env52535 := by
  intro p hp
  have h : env52535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52534_52535 : H12AffineEnvironment.transform 13 13609 env52534 = env52535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env52534 == env52535) = true)

theorem identity52535 : scanCanonicalize (H12AffineFastState.compose env52535 (packedSelected [2,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound52535 : packedSelected [2,12,14,15] rootPS < 2^1333 := by decide +kernel

def env52536 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5156,81,262,5440,2128,1024,80,4405,341,357,2,269,65,2129,5221,4388,2049,1056,261,256,261,5457,884]

theorem envBound52536 : H12AffineFastState.Bounded env52536 := by
  intro p hp
  have h : env52536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52535_52536 : H12AffineEnvironment.transform 12 269 env52535 = env52536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env52535 == env52536) = true)

theorem identity52536 : scanCanonicalize (H12AffineFastState.compose env52536 (packedSelected [0,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound52536 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env52537 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,64,269,1124,81,262,1280,2128,1024,80,373,341,357,2,269,65,2129,1061,356,2049,1056,261,256,261,1297,884]

theorem envBound52537 : H12AffineFastState.Bounded env52537 := by
  intro p hp
  have h : env52537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52536_52537 : H12AffineEnvironment.transform 11 64 env52536 = env52537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env52536 == env52537) = true)

theorem identity52537 : scanCanonicalize (H12AffineFastState.compose env52537 (packedSelected [1,2,3,4,5,6,8,9,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound52537 : packedSelected [1,2,3,4,5,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env52538 : List Nat := [2,4,8,16,32,64,8,256,512,20,2048,64,269,112,81,262,276,2128,20,80,373,341,357,2,269,65,2129,49,356,2049,52,261,256,261,261,884]

theorem envBound52538 : H12AffineFastState.Bounded env52538 := by
  intro p hp
  have h : env52538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52537_52538 : H12AffineEnvironment.transform 9 20 env52537 = env52538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env52537 == env52538) = true)

theorem identity52538 : scanCanonicalize (H12AffineFastState.compose env52538 (packedSelected [2,3,4,5,6,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52538 : packedSelected [2,3,4,5,6,9,10] rootPS < 2^1333 := by decide +kernel

def env52539 : List Nat := [2,4,8,16,1,64,8,256,512,20,2048,64,269,81,81,262,276,2128,20,80,340,341,324,2,269,65,2129,16,325,2049,21,261,256,261,261,853]

theorem envBound52539 : H12AffineFastState.Bounded env52539 := by
  intro p hp
  have h : env52539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52538_52539 : H12AffineEnvironment.transform 4 1 env52538 = env52539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52538 == env52539) = true)

theorem identity52539 : scanCanonicalize (H12AffineFastState.compose env52539 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52539 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52540 : List Nat := [2,4,8,16,1,16,8,256,512,20,2048,16,269,1,1,262,276,2048,20,0,260,261,276,2,269,17,2049,16,277,2049,21,261,256,261,261,773]

theorem envBound52540 : H12AffineFastState.Bounded env52540 := by
  intro p hp
  have h : env52540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52539_52540 : H12AffineEnvironment.transform 5 16 env52539 = env52540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52539 == env52540) = true)

theorem identity52540 : scanCanonicalize (H12AffineFastState.compose env52540 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 21) := by decide +kernel

theorem selectedBound52540 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52541 : List Nat := [2,4,8,16,1,16,8,256,21,20,2048,16,269,1,1,262,276,2048,20,0,260,261,276,2,269,17,2049,16,277,2049,21,261,256,261,261,272]

theorem envBound52541 : H12AffineFastState.Bounded env52541 := by
  intro p hp
  have h : env52541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52540_52541 : H12AffineEnvironment.transform 8 21 env52540 = env52541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 21 env52540 == env52541) = true)

theorem identity52541 : scanCanonicalize (H12AffineFastState.compose env52541 (packedSelected [2,3] rootPS)) = affineNative (2^(7+1) ^^^ 7) := by decide +kernel

theorem selectedBound52541 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env52542 : List Nat := [2,4,8,16,1,16,8,7,21,20,2048,16,10,1,1,1,19,2048,20,0,3,2,19,2,10,17,2049,16,18,2049,21,2,7,2,2,23]

theorem envBound52542 : H12AffineFastState.Bounded env52542 := by
  intro p hp
  have h : env52542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52541_52542 : H12AffineEnvironment.transform 7 7 env52541 = env52542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 7 env52541 == env52542) = true)

theorem identity52542 : scanCanonicalize (H12AffineFastState.compose env52542 (packedSelected [2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 3) := by decide +kernel

theorem selectedBound52542 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env52543 : List Nat := [2,4,8,16,1,16,8,7,21,20,3,16,10,1,1,1,19,3,20,0,3,2,19,2,10,17,2,16,18,2,21,2,7,2,2,23]

theorem envBound52543 : H12AffineFastState.Bounded env52543 := by
  intro p hp
  have h : env52543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52542_52543 : H12AffineEnvironment.transform 10 3 env52542 = env52543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 3 env52542 == env52543) = true)

theorem identity52543 : scanCanonicalize (H12AffineFastState.compose env52543 (packedSelected [1,8] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound52543 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env52544 : List Nat := [0,4,8,16,1,16,8,5,21,20,1,16,8,1,1,1,17,1,20,0,1,0,17,0,8,17,0,16,16,0,21,0,5,0,0,21]

theorem envBound52544 : H12AffineFastState.Bounded env52544 := by
  intro p hp
  have h : env52544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52543_52544 : H12AffineEnvironment.transform 0 0 env52543 = env52544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env52543 == env52544) = true)

theorem identity52544 : scanCanonicalize (H12AffineFastState.compose env52544 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound52544 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52545 : List Nat := [0,4,8,13,1,13,8,5,8,9,1,13,8,1,1,1,12,1,9,0,1,0,12,0,8,12,0,13,13,0,8,0,5,0,0,8]

theorem envBound52545 : H12AffineFastState.Bounded env52545 := by
  intro p hp
  have h : env52545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52544_52545 : H12AffineEnvironment.transform 3 13 env52544 = env52545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env52544 == env52545) = true)

def env52546 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,437625,272393,441641,41311,8193,65,316532,436265,17664,32040,440429,156013,256,21793,46092,442168]

theorem envBound52546 : H12AffineFastState.Bounded env52546 := by
  intro p hp
  have h : env52546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52530_52546 : H12AffineEnvironment.transform 6 9 env52530 = env52546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52530 == env52546) = true)

theorem identity52546 : scanCanonicalize (H12AffineFastState.compose env52546 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound52546 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env52547 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,38161,262144,1024,32769,276584,272393,272440,41311,8193,65,316532,277816,17664,32040,273788,62588,256,21793,46092,272937]

theorem envBound52547 : H12AffineFastState.Bounded env52547 := by
  intro p hp
  have h : env52547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52546_52547 : H12AffineEnvironment.transform 16 38161 env52546 = env52547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env52546 == env52547) = true)

theorem identity52547 : scanCanonicalize (H12AffineFastState.compose env52547 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound52547 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52548 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,38161,10281,1024,32769,4161,32,17,41311,8193,65,64605,5393,17664,32040,1365,62588,256,21793,46092,512]

theorem envBound52548 : H12AffineFastState.Bounded env52548 := by
  intro p hp
  have h : env52548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52547_52548 : H12AffineEnvironment.transform 17 10281 env52547 = env52548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env52547 == env52548) = true)

theorem identity52548 : scanCanonicalize (H12AffineFastState.compose env52548 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 1297) := by decide +kernel

theorem selectedBound52548 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env52549 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,1297,32768,8203,38161,10281,1024,32769,4161,32,17,41311,8193,65,47436,5393,17,14393,1365,45421,256,4144,46092,512]

theorem envBound52549 : H12AffineFastState.Bounded env52549 := by
  intro p hp
  have h : env52549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52548_52549 : H12AffineEnvironment.transform 13 1297 env52548 = env52549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env52548 == env52549) = true)

theorem identity52549 : scanCanonicalize (H12AffineFastState.compose env52549 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 12344) := by decide +kernel

theorem selectedBound52549 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env52550 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,1297,12344,8203,9513,10281,1024,12345,4161,32,17,4455,8193,65,2420,5393,17,14393,1365,341,256,4144,1076,512]

theorem envBound52550 : H12AffineFastState.Bounded env52550 := by
  intro p hp
  have h : env52550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52549_52550 : H12AffineEnvironment.transform 14 12344 env52549 = env52550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12344 env52549 == env52550) = true)

theorem identity52550 : scanCanonicalize (H12AffineFastState.compose env52550 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound52550 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env52551 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,8192,1297,12344,8203,9513,10281,1024,12345,4144,32,17,4374,8193,48,2309,5393,17,14393,1316,292,256,4144,1076,512]

theorem envBound52551 : H12AffineFastState.Bounded env52551 := by
  intro p hp
  have h : env52551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52550_52551 : H12AffineEnvironment.transform 5 49 env52550 = env52551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env52550 == env52551) = true)

def env52552 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,272513,441641,98781,8328,65,316533,436265,17664,32040,440548,156133,256,21793,46213,499507]

theorem envBound52552 : H12AffineFastState.Bounded env52552 := by
  intro p hp
  have h : env52552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52528_52552 : H12AffineEnvironment.transform 21 272513 env52528 = env52552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env52528 == env52552) = true)

theorem identity52552 : scanCanonicalize (H12AffineFastState.compose env52552 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236850) := by decide +kernel

theorem selectedBound52552 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52553 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236850,1024,32769,77899,243123,73755,98781,8328,65,215367,79131,17664,32040,75222,156133,256,21793,46213,513]

theorem envBound52553 : H12AffineFastState.Bounded env52553 := by
  intro p hp
  have h : env52553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52552_52553 : H12AffineEnvironment.transform 17 236850 env52552 = env52553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236850 env52552 == env52553) = true)

def env52554 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236850,1024,32769,77899,243003,73755,98645,8192,65,215367,79131,17664,32040,75102,156013,256,21793,46093,513]

theorem envBound52554 : H12AffineFastState.Bounded env52554 := by
  intro p hp
  have h : env52554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52553_52554 : H12AffineEnvironment.transform 6 8 env52553 = env52554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52553 == env52554) = true)

theorem identity52554 : scanCanonicalize (H12AffineFastState.compose env52554 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound52554 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env52555 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,64809,1024,32769,77899,54560,73755,98645,8192,65,10588,79131,17664,32040,75102,65910,256,21793,46093,513]

theorem envBound52555 : H12AffineFastState.Bounded env52555 := by
  intro p hp
  have h : env52555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52554_52555 : H12AffineEnvironment.transform 16 90139 env52554 = env52555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env52554 == env52555) = true)

theorem identity52555 : scanCanonicalize (H12AffineFastState.compose env52555 (packedSelected [0,2,4,6,9,18,20,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 1344) := by decide +kernel

theorem selectedBound52555 : packedSelected [0,2,4,6,9,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env52556 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1344,65536,90139,30825,1024,1345,77899,20576,73755,66581,8192,65,10588,79131,17664,32040,75102,65910,256,21793,12621,513]

theorem envBound52556 : H12AffineFastState.Bounded env52556 := by
  intro p hp
  have h : env52556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52555_52556 : H12AffineEnvironment.transform 14 1344 env52555 = env52556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1344 env52555 == env52556) = true)

theorem identity52556 : scanCanonicalize (H12AffineFastState.compose env52556 (packedSelected [2,3,4,5,6,9,10,12,14,17,20,38] rootPS)) = affineNative (2^(15+1) ^^^ 28990) := by decide +kernel

theorem selectedBound52556 : packedSelected [2,3,4,5,6,9,10,12,14,17,20,38] rootPS < 2^1333 := by decide +kernel

def env52557 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1344,28990,4389,30825,1024,1345,16757,20576,20773,29995,8192,65,10588,17445,17664,32040,21600,28744,256,21793,12621,513]

theorem envBound52557 : H12AffineFastState.Bounded env52557 := by
  intro p hp
  have h : env52557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52556_52557 : H12AffineEnvironment.transform 15 28990 env52556 = env52557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28990 env52556 == env52557) = true)

theorem identity52557 : scanCanonicalize (H12AffineFastState.compose env52557 (packedSelected [1,2,3,6,12,15,18,24,28,32] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound52557 : packedSelected [1,2,3,6,12,15,18,24,28,32] rootPS < 2^1333 := by decide +kernel

def env52558 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,1076,28746,4177,30825,1024,1077,16385,20576,20561,29791,8192,65,10280,17445,17524,31836,21600,28744,116,21589,12345,513]

theorem envBound52558 : H12AffineFastState.Bounded env52558 := by
  intro p hp
  have h : env52558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52557_52558 : H12AffineEnvironment.transform 7 116 env52557 = env52558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env52557 == env52558) = true)

theorem identity52558 : scanCanonicalize (H12AffineFastState.compose env52558 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound52558 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52559 : List Nat := [2,4,8,16,32,64,8,116,512,53,2048,4096,8192,16384,1,28746,4177,30825,53,0,16385,20576,20561,28778,8192,65,10280,16400,16449,30825,20565,28744,116,20576,12345,513]

theorem envBound52559 : H12AffineFastState.Bounded env52559 := by
  intro p hp
  have h : env52559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52558_52559 : H12AffineEnvironment.transform 9 53 env52558 = env52559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env52558 == env52559) = true)

theorem identity52559 : scanCanonicalize (H12AffineFastState.compose env52559 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52559 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52560 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,4096,8192,16384,1,28698,4097,30777,53,0,16385,20528,20481,28730,8192,17,10280,16400,16401,30777,20485,28696,36,20528,12345,513]

theorem envBound52560 : H12AffineFastState.Bounded env52560 := by
  intro p hp
  have h : env52560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52559_52560 : H12AffineEnvironment.transform 5 16 env52559 = env52560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52559 == env52560) = true)

def env52561 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236850,1024,32769,77899,243002,73755,98644,8193,65,215367,79131,17664,32040,75103,156012,256,21793,46092,513]

theorem envBound52561 : H12AffineFastState.Bounded env52561 := by
  intro p hp
  have h : env52561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52553_52561 : H12AffineEnvironment.transform 6 9 env52553 = env52561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52553 == env52561) = true)

theorem identity52561 : scanCanonicalize (H12AffineFastState.compose env52561 (packedSelected [0,2,3,4,6,9,10,18,20,23,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound52561 : packedSelected [0,2,3,4,6,9,10,18,20,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env52562 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,65536,131072,215090,1024,21761,77899,221242,73755,87124,8193,65,215367,79131,17664,32040,75103,156012,256,21793,24844,513]

theorem envBound52562 : H12AffineFastState.Bounded env52562 := by
  intro p hp
  have h : env52562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52561_52562 : H12AffineEnvironment.transform 14 21760 env52561 = env52562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env52561 == env52562) = true)

theorem identity52562 : scanCanonicalize (H12AffineFastState.compose env52562 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound52562 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env52563 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,65536,90139,10281,1024,21761,77899,33,73755,87124,8193,65,10588,79131,17664,32040,75103,65911,256,21793,24844,513]

theorem envBound52563 : H12AffineFastState.Bounded env52563 := by
  intro p hp
  have h : env52563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52562_52563 : H12AffineEnvironment.transform 16 90139 env52562 = env52563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env52562 == env52563) = true)

theorem identity52563 : scanCanonicalize (H12AffineFastState.compose env52563 (packedSelected [0,3,5,7,10,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound52563 : packedSelected [0,3,5,7,10,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env52564 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,65536,82247,2421,1024,21761,69911,33,65863,87124,349,65,2048,70727,17664,23668,66563,65911,256,21793,16464,513]

theorem envBound52564 : H12AffineFastState.Bounded env52564 := by
  intro p hp
  have h : env52564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52563_52564 : H12AffineEnvironment.transform 12 348 env52563 = env52564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env52563 == env52564) = true)

theorem identity52564 : scanCanonicalize (H12AffineFastState.compose env52564 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound52564 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52565 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,21591,5392,2421,1024,21761,17728,33,21776,3,349,65,2048,16400,17664,23668,20564,21792,256,21793,16464,513]

theorem envBound52565 : H12AffineFastState.Bounded env52565 := by
  intro p hp
  have h : env52565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52564_52565 : H12AffineEnvironment.transform 15 21591 env52564 = env52565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env52564 == env52565) = true)

theorem identity52565 : scanCanonicalize (H12AffineFastState.compose env52565 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52565 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env52566 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,21760,21511,5392,2341,1024,21761,17680,33,21776,3,269,17,2048,16400,17664,23588,20484,21792,256,21793,16384,513]

theorem envBound52566 : H12AffineFastState.Bounded env52566 := by
  intro p hp
  have h : env52566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52565_52566 : H12AffineEnvironment.transform 5 16 env52565 = env52566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52565 == env52566) = true)

theorem identity52566 : scanCanonicalize (H12AffineFastState.compose env52566 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound52566 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env52567 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,1,262,5392,2341,1024,0,4113,33,17,3,269,17,2048,5393,4097,2341,1285,33,256,32,5377,513]

theorem envBound52567 : H12AffineFastState.Bounded env52567 := by
  intro p hp
  have h : env52567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52566_52567 : H12AffineEnvironment.transform 13 5377 env52566 = env52567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env52566 == env52567) = true)

theorem identity52567 : scanCanonicalize (H12AffineFastState.compose env52567 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound52567 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52568 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5156,1,35,5173,2048,1024,0,4113,33,17,3,40,17,2048,5172,4097,2048,1056,33,37,32,5156,513]

theorem envBound52568 : H12AffineFastState.Bounded env52568 := by
  intro p hp
  have h : env52568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52567_52568 : H12AffineEnvironment.transform 7 37 env52567 = env52568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env52567 == env52568) = true)

def env52569 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,41,1044,1,35,1029,2048,1024,0,33,33,17,3,40,17,2048,1028,49,2048,1056,33,37,32,1044,513]

theorem envBound52569 : H12AffineFastState.Bounded env52569 := by
  intro p hp
  have h : env52569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52568_52569 : H12AffineEnvironment.transform 11 48 env52568 = env52569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env52568 == env52569) = true)

theorem identity52569 : scanCanonicalize (H12AffineFastState.compose env52569 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound52569 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52570 : List Nat := [2,4,8,16,32,16,9,37,512,1024,561,48,41,1044,1,35,1029,561,1024,0,33,33,17,3,40,17,561,1028,49,561,1056,33,37,32,1044,513]

theorem envBound52570 : H12AffineFastState.Bounded env52570 := by
  intro p hp
  have h : env52570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52569_52570 : H12AffineEnvironment.transform 10 561 env52569 = env52570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env52569 == env52570) = true)

def env52571 : List Nat := [2,4,8,16,32,16,9,37,512,52,561,48,41,32,1,35,49,561,52,0,33,33,17,3,40,17,561,48,49,561,20,33,37,32,32,513]

theorem envBound52571 : H12AffineFastState.Bounded env52571 := by
  intro p hp
  have h : env52571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52570_52571 : H12AffineEnvironment.transform 9 52 env52570 = env52571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env52570 == env52571) = true)

theorem identity52571 : scanCanonicalize (H12AffineFastState.compose env52571 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound52571 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52572 : List Nat := [2,4,8,16,32,16,9,37,16,52,33,48,41,32,1,35,49,33,52,0,33,33,17,3,40,17,33,48,49,33,20,33,37,32,32,17]

theorem envBound52572 : H12AffineFastState.Bounded env52572 := by
  intro p hp
  have h : env52572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52571_52572 : H12AffineEnvironment.transform 8 16 env52571 = env52572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env52571 == env52572) = true)

def leafEnv52572 : List Nat := [2,4,8,16,32,16,9,37,16,52,33,48,41,32,1,35,49,33,52,0,33,33,17,3,20,40,1,17,33,48,49,33,20,33,37,32,4,34,32,17,1,33,0]

def active52572 : List Nat := [0,1,2,3,4]

def tree52572 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52572 : H12WitnessSearch.Good tree52572 := H12GlobalWitnessIndex.good

theorem leafIdentity52572 : H12AffineFastState.composeSystem env52572 rootObs = leafEnv52572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52572 rootObs == leafEnv52572) = true)

theorem terminalChecked52572 : H12PackedTerminal.terminalCheckFast leafEnv52572 active52572 tree52572 = true := by decide +kernel

def env52573 : List Nat := [2,4,8,16,32,16,9,37,512,53,561,48,41,33,1,35,48,561,53,0,33,33,17,3,40,17,561,49,49,561,21,33,37,32,33,513]

theorem envBound52573 : H12AffineFastState.Bounded env52573 := by
  intro p hp
  have h : env52573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52570_52573 : H12AffineEnvironment.transform 9 53 env52570 = env52573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env52570 == env52573) = true)

theorem identity52573 : scanCanonicalize (H12AffineFastState.compose env52573 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound52573 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52574 : List Nat := [2,4,8,16,26,16,9,31,512,15,523,10,19,27,1,25,10,523,15,0,27,27,17,3,18,17,523,11,11,523,21,27,31,26,27,513]

theorem envBound52574 : H12AffineFastState.Bounded env52574 := by
  intro p hp
  have h : env52574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52573_52574 : H12AffineEnvironment.transform 4 26 env52573 = env52574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env52573 == env52574) = true)

def leafEnv52574 : List Nat := [2,4,8,16,26,16,9,31,512,15,523,10,19,27,1,25,10,523,15,0,27,27,17,3,21,18,1,17,523,11,11,523,21,27,31,26,4,24,27,513,1,27,0]

def active52574 : List Nat := [0,1,2,3,8]

def tree52574 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52574 : H12WitnessSearch.Good tree52574 := H12GlobalWitnessIndex.good

theorem leafIdentity52574 : H12AffineFastState.composeSystem env52574 rootObs = leafEnv52574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52574 rootObs == leafEnv52574) = true)

theorem terminalChecked52574 : H12PackedTerminal.terminalCheckFast leafEnv52574 active52574 tree52574 = true := by decide +kernel

def env52575 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,41,1045,1,35,1028,2048,1024,0,32,33,17,3,40,17,2048,1029,48,2048,1056,33,37,32,1045,513]

theorem envBound52575 : H12AffineFastState.Bounded env52575 := by
  intro p hp
  have h : env52575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52568_52575 : H12AffineEnvironment.transform 11 49 env52568 = env52575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env52568 == env52575) = true)

theorem identity52575 : scanCanonicalize (H12AffineFastState.compose env52575 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound52575 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52576 : List Nat := [2,4,8,16,32,16,9,37,512,1024,1541,49,41,1045,1,35,1028,1541,1024,0,32,33,17,3,40,17,1541,1029,48,1541,1056,33,37,32,1045,513]

theorem envBound52576 : H12AffineFastState.Bounded env52576 := by
  intro p hp
  have h : env52576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52575_52576 : H12AffineEnvironment.transform 10 1541 env52575 = env52576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env52575 == env52576) = true)

def env52577 : List Nat := [2,4,8,16,32,16,9,37,512,52,561,49,41,33,1,35,48,561,52,0,32,33,17,3,40,17,561,49,48,561,20,33,37,32,33,513]

theorem envBound52577 : H12AffineFastState.Bounded env52577 := by
  intro p hp
  have h : env52577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52576_52577 : H12AffineEnvironment.transform 9 52 env52576 = env52577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env52576 == env52577) = true)

theorem identity52577 : scanCanonicalize (H12AffineFastState.compose env52577 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound52577 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52578 : List Nat := [2,4,8,16,32,16,9,37,17,52,32,49,41,33,1,35,48,32,52,0,32,33,17,3,40,17,32,49,48,32,20,33,37,32,33,16]

theorem envBound52578 : H12AffineFastState.Bounded env52578 := by
  intro p hp
  have h : env52578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52577_52578 : H12AffineEnvironment.transform 8 17 env52577 = env52578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env52577 == env52578) = true)

def leafEnv52578 : List Nat := [2,4,8,16,32,16,9,37,17,52,32,49,41,33,1,35,48,32,52,0,32,33,17,3,20,40,1,17,32,49,48,32,20,33,37,32,4,34,33,16,1,32,0]

def active52578 : List Nat := [0,1,2,3,4]

def tree52578 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52578 : H12WitnessSearch.Good tree52578 := H12GlobalWitnessIndex.good

theorem leafIdentity52578 : H12AffineFastState.composeSystem env52578 rootObs = leafEnv52578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52578 rootObs == leafEnv52578) = true)

theorem terminalChecked52578 : H12PackedTerminal.terminalCheckFast leafEnv52578 active52578 tree52578 = true := by decide +kernel

def env52579 : List Nat := [2,4,8,16,32,16,9,37,512,53,560,49,41,32,1,35,49,560,53,0,32,33,17,3,40,17,560,48,48,560,21,33,37,32,32,513]

theorem envBound52579 : H12AffineFastState.Bounded env52579 := by
  intro p hp
  have h : env52579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52576_52579 : H12AffineEnvironment.transform 9 53 env52576 = env52579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env52576 == env52579) = true)

theorem identity52579 : scanCanonicalize (H12AffineFastState.compose env52579 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound52579 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52580 : List Nat := [2,4,8,16,27,16,9,30,512,14,523,10,18,27,1,24,10,523,14,0,27,26,17,3,19,17,523,11,11,523,21,26,30,27,27,513]

theorem envBound52580 : H12AffineFastState.Bounded env52580 := by
  intro p hp
  have h : env52580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52579_52580 : H12AffineEnvironment.transform 4 27 env52579 = env52580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env52579 == env52580) = true)

def leafEnv52580 : List Nat := [2,4,8,16,27,16,9,30,512,14,523,10,18,27,1,24,10,523,14,0,27,26,17,3,21,19,1,17,523,11,11,523,21,26,30,27,4,25,27,513,1,27,0]

def active52580 : List Nat := [0,1,2,3,8]

def tree52580 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52580 : H12WitnessSearch.Good tree52580 := H12GlobalWitnessIndex.good

theorem leafIdentity52580 : H12AffineFastState.composeSystem env52580 rootObs = leafEnv52580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52580 rootObs == leafEnv52580) = true)

theorem terminalChecked52580 : H12PackedTerminal.terminalCheckFast leafEnv52580 active52580 tree52580 = true := by decide +kernel

def env52581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,4194304,8388608,8862965,8328,65,4259061,8393985,8845353,8830977,440549,12645452,256,21792,46212,499506]

theorem envBound52581 : H12AffineFastState.Bounded env52581 := by
  intro p hp
  have h : env52581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52477_52581 : H12AffineEnvironment.transform 23 8862965 env52477 = env52581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8862965 env52477 == env52581) = true)

def env52582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,4194304,441640,98781,8328,65,4259061,436265,17665,32041,440549,4606308,256,21792,46212,499506]

theorem envBound52582 : H12AffineFastState.Bounded env52582 := by
  intro p hp
  have h : env52582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52581_52582 : H12AffineEnvironment.transform 22 441640 env52581 = env52582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441640 env52581 == env52582) = true)

def env52583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,272512,441640,98781,8328,65,316533,436265,17665,32041,440549,156132,256,21792,46212,499506]

theorem envBound52583 : H12AffineFastState.Bounded env52583 := by
  intro p hp
  have h : env52583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52582_52583 : H12AffineEnvironment.transform 21 272512 env52582 = env52583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env52582 == env52583) = true)

theorem identity52583 : scanCanonicalize (H12AffineFastState.compose env52583 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179512) := by decide +kernel

theorem selectedBound52583 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52584 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,169400,16,98781,8328,65,158029,5393,17665,32041,1501,156132,256,21792,46212,74250]

theorem envBound52584 : H12AffineFastState.Bounded env52584 := by
  intro p hp
  have h : env52584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52583_52584 : H12AffineEnvironment.transform 17 179512 env52583 = env52584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env52583 == env52584) = true)

theorem identity52584 : scanCanonicalize (H12AffineFastState.compose env52584 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound52584 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env52585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179512,1024,32769,4161,169400,16,41430,8328,65,158029,5393,17665,32041,1501,156132,256,21792,46212,513]

theorem envBound52585 : H12AffineFastState.Bounded env52585 := by
  intro p hp
  have h : env52585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52584_52585 : H12AffineEnvironment.transform 15 8203 env52584 = env52585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env52584 == env52585) = true)

def env52586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,272513,441640,98781,8328,65,316532,436265,17665,32041,440549,156133,256,21792,46212,499506]

theorem envBound52586 : H12AffineFastState.Bounded env52586 := by
  intro p hp
  have h : env52586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52582_52586 : H12AffineEnvironment.transform 21 272513 env52582 = env52586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env52582 == env52586) = true)

def env52587 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,272393,441640,98645,8192,65,316532,436265,17665,32041,440429,156013,256,21792,46092,499506]

theorem envBound52587 : H12AffineFastState.Bounded env52587 := by
  intro p hp
  have h : env52587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52586_52587 : H12AffineEnvironment.transform 6 8 env52586 = env52587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52586 == env52587) = true)

theorem identity52587 : scanCanonicalize (H12AffineFastState.compose env52587 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 122146) := by decide +kernel

theorem selectedBound52587 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env52588 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,122146,1024,32769,225371,128299,221194,98645,8192,65,67926,226571,17665,32041,222543,156013,256,21792,46092,147984]

theorem envBound52588 : H12AffineFastState.Bounded env52588 := by
  intro p hp
  have h : env52588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52587_52588 : H12AffineEnvironment.transform 17 122146 env52587 = env52588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122146 env52587 == env52588) = true)

theorem identity52588 : scanCanonicalize (H12AffineFastState.compose env52588 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound52588 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env52589 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,122146,1024,32769,102679,128299,98630,98645,8192,65,67926,103495,17665,32041,99331,32801,256,21792,46092,41820]

theorem envBound52589 : H12AffineFastState.Bounded env52589 := by
  intro p hp
  have h : env52589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52588_52589 : H12AffineEnvironment.transform 16 57676 env52588 = env52589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env52588 == env52589) = true)

theorem identity52589 : scanCanonicalize (H12AffineFastState.compose env52589 (packedSelected [0,3,5,8,9,10,14,17,22,27,28,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound52589 : packedSelected [0,3,5,8,9,10,14,17,22,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env52590 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,97407,1024,8540,77898,87158,73755,73736,8192,65,67926,79130,17665,32041,75102,8572,256,21792,5457,513]

theorem envBound52590 : H12AffineFastState.Bounded env52590 := by
  intro p hp
  have h : env52590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52589_52590 : H12AffineEnvironment.transform 14 8541 env52589 = env52590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env52589 == env52590) = true)

theorem identity52590 : scanCanonicalize (H12AffineFastState.compose env52590 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound52590 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52591 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8541,65536,16401,96623,272,8540,77898,86374,73755,73736,8192,65,67926,77834,16401,30777,73806,8572,256,20528,4161,513]

theorem envBound52591 : H12AffineFastState.Bounded env52591 := by
  intro p hp
  have h : env52591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52590_52591 : H12AffineEnvironment.transform 9 272 env52590 = env52591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env52590 == env52591) = true)

theorem identity52591 : scanCanonicalize (H12AffineFastState.compose env52591 (packedSelected [1,2,6,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 12621) := by decide +kernel

theorem selectedBound52591 : packedSelected [1,2,6,8,19] rootPS < 2^1333 := by decide +kernel

def env52592 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,12621,8541,65536,12636,67618,272,8540,77898,73771,73755,73736,8192,65,67926,77834,12636,2420,73806,8572,256,8573,4161,513]

theorem envBound52592 : H12AffineFastState.Bounded env52592 := by
  intro p hp
  have h : env52592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52591_52592 : H12AffineEnvironment.transform 13 12621 env52591 = env52592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12621 env52591 == env52592) = true)

theorem identity52592 : scanCanonicalize (H12AffineFastState.compose env52592 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound52592 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52593 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,12621,8541,8203,12636,10281,272,8540,4161,32,16,3,8192,65,10589,4097,12636,2420,69,8572,256,8573,4161,513]

theorem envBound52593 : H12AffineFastState.Bounded env52593 := by
  intro p hp
  have h : env52593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52592_52593 : H12AffineEnvironment.transform 15 8203 env52592 = env52593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env52592 == env52593) = true)

theorem identity52593 : scanCanonicalize (H12AffineFastState.compose env52593 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound52593 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52594 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,72,4357,277,67,4372,2145,272,276,4161,32,16,3,72,65,2325,4097,4372,2420,69,308,256,309,4161,513]

theorem envBound52594 : H12AffineFastState.Bounded env52594 := by
  intro p hp
  have h : env52594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52593_52594 : H12AffineEnvironment.transform 12 72 env52593 = env52594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env52593 == env52594) = true)

theorem identity52594 : scanCanonicalize (H12AffineFastState.compose env52594 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound52594 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52595 : List Nat := [2,4,8,16,32,64,8,20,512,4,2048,4096,72,4113,1,67,4096,2145,4,0,4161,32,16,3,72,65,2049,4097,4096,2144,69,32,20,33,4161,513]

theorem envBound52595 : H12AffineFastState.Bounded env52595 := by
  intro p hp
  have h : env52595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52594_52595 : H12AffineEnvironment.transform 7 20 env52594 = env52595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env52594 == env52595) = true)

theorem identity52595 : scanCanonicalize (H12AffineFastState.compose env52595 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound52595 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52596 : List Nat := [2,4,8,16,32,64,8,20,512,4,58,4096,72,4113,1,67,4096,91,4,0,4161,32,16,3,72,65,59,4097,4096,90,69,32,20,33,4161,513]

theorem envBound52596 : H12AffineFastState.Bounded env52596 := by
  intro p hp
  have h : env52596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52595_52596 : H12AffineEnvironment.transform 10 58 env52595 = env52596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env52595 == env52596) = true)

theorem identity52596 : scanCanonicalize (H12AffineFastState.compose env52596 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound52596 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env52597 : List Nat := [2,4,8,16,32,64,8,20,512,4,58,0,72,17,1,67,0,91,4,0,65,32,16,3,72,65,59,1,0,90,69,32,20,33,65,513]

theorem envBound52597 : H12AffineFastState.Bounded env52597 := by
  intro p hp
  have h : env52597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52596_52597 : H12AffineEnvironment.transform 11 0 env52596 = env52597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env52596 == env52597) = true)

theorem identity52597 : scanCanonicalize (H12AffineFastState.compose env52597 (packedSelected [4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52597 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env52598 : List Nat := [2,4,8,16,1,64,8,20,512,4,27,0,72,17,1,67,0,91,4,0,65,1,16,3,72,65,26,1,0,90,69,1,20,0,65,513]

theorem envBound52598 : H12AffineFastState.Bounded env52598 := by
  intro p hp
  have h : env52598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52597_52598 : H12AffineEnvironment.transform 4 1 env52597 = env52598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52597 == env52598) = true)

theorem identity52598 : scanCanonicalize (H12AffineFastState.compose env52598 (packedSelected [0,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 18) := by decide +kernel

theorem selectedBound52598 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env52599 : List Nat := [2,4,8,16,1,18,8,20,512,4,27,0,26,17,1,17,0,9,4,0,19,1,16,3,26,19,26,1,0,8,23,1,20,0,19,513]

theorem envBound52599 : H12AffineFastState.Bounded env52599 := by
  intro p hp
  have h : env52599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52598_52599 : H12AffineEnvironment.transform 5 18 env52598 = env52599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 18 env52598 == env52599) = true)

theorem identity52599 : scanCanonicalize (H12AffineFastState.compose env52599 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 18) := by decide +kernel

theorem selectedBound52599 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env52600 : List Nat := [2,4,8,16,1,18,8,20,18,4,27,0,26,17,1,17,0,9,4,0,19,1,16,3,26,19,26,1,0,8,23,1,20,0,19,19]

theorem envBound52600 : H12AffineFastState.Bounded env52600 := by
  intro p hp
  have h : env52600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52599_52600 : H12AffineEnvironment.transform 8 18 env52599 = env52600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 18 env52599 == env52600) = true)

theorem identity52600 : scanCanonicalize (H12AffineFastState.compose env52600 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound52600 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env52601 : List Nat := [2,4,8,3,1,1,8,7,1,4,8,0,9,2,1,2,0,9,4,0,0,1,3,3,9,0,9,1,0,8,4,1,7,0,0,0]

theorem envBound52601 : H12AffineFastState.Bounded env52601 := by
  intro p hp
  have h : env52601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52600_52601 : H12AffineEnvironment.transform 3 3 env52600 = env52601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env52600 == env52601) = true)

theorem identity52601 : scanCanonicalize (H12AffineFastState.compose env52601 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound52601 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52602 : List Nat := [2,4,4,3,1,1,4,7,1,4,4,0,5,2,1,2,0,5,4,0,0,1,3,3,5,0,5,1,0,4,4,1,7,0,0,0]

theorem envBound52602 : H12AffineFastState.Bounded env52602 := by
  intro p hp
  have h : env52602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52601_52602 : H12AffineEnvironment.transform 2 4 env52601 = env52602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env52601 == env52602) = true)

theorem identity52602 : scanCanonicalize (H12AffineFastState.compose env52602 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound52602 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env52603 : List Nat := [2,3,3,3,1,1,3,0,1,3,3,0,2,2,1,2,0,2,3,0,0,1,3,3,2,0,2,1,0,3,3,1,0,0,0,0]

theorem envBound52603 : H12AffineFastState.Bounded env52603 := by
  intro p hp
  have h : env52603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52602_52603 : H12AffineEnvironment.transform 1 3 env52602 = env52603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env52602 == env52603) = true)

theorem identity52603 : scanCanonicalize (H12AffineFastState.compose env52603 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound52603 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52604 : List Nat := [1,0,0,0,1,1,0,0,1,0,0,0,1,1,1,1,0,1,0,0,0,1,0,0,1,0,1,1,0,0,0,1,0,0,0,0]

theorem envBound52604 : H12AffineFastState.Bounded env52604 := by
  intro p hp
  have h : env52604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52603_52604 : H12AffineEnvironment.transform 0 1 env52603 = env52604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env52603 == env52604) = true)

def env52605 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,272392,441640,98644,8193,65,316532,436265,17665,32041,440428,156012,256,21792,46093,499506]

theorem envBound52605 : H12AffineFastState.Bounded env52605 := by
  intro p hp
  have h : env52605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52586_52605 : H12AffineEnvironment.transform 6 9 env52586 = env52605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52586 == env52605) = true)

def env52606 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1024,32769,276585,272392,272440,98644,8193,65,316532,277817,17665,32041,273788,62588,256,21792,46093,330274]

theorem envBound52606 : H12AffineFastState.Bounded env52606 := by
  intro p hp
  have h : env52606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52605_52606 : H12AffineEnvironment.transform 16 38160 env52605 = env52606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env52605 == env52606) = true)

theorem identity52606 : scanCanonicalize (H12AffineFastState.compose env52606 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound52606 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52607 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1024,32769,4160,33,17,98644,8193,65,64605,5392,17665,32041,1365,62588,256,21792,46093,74251]

theorem envBound52607 : H12AffineFastState.Bounded env52607 := by
  intro p hp
  have h : env52607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52606_52607 : H12AffineEnvironment.transform 17 10281 env52606 = env52607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env52606 == env52607) = true)

theorem identity52607 : scanCanonicalize (H12AffineFastState.compose env52607 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 54279) := by decide +kernel

theorem selectedBound52607 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env52608 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54279,38160,10281,1024,32769,4160,33,17,21843,8193,65,64605,5392,17665,32041,1365,62588,256,21792,46093,62988]

theorem envBound52608 : H12AffineFastState.Bounded env52608 := by
  intro p hp
  have h : env52608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52607_52608 : H12AffineEnvironment.transform 15 54279 env52607 = env52608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54279 env52607 == env52608) = true)

theorem identity52608 : scanCanonicalize (H12AffineFastState.compose env52608 (packedSelected [2,3,4,5,6,10,11,16,18,22] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound52608 : packedSelected [2,3,4,5,6,10,11,16,18,22] rootPS < 2^1333 := by decide +kernel

def env52609 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,32768,40971,38160,10281,1024,32769,4160,33,17,8543,8193,65,34897,5392,12557,2341,1365,32880,256,8492,46093,33280]

theorem envBound52609 : H12AffineFastState.Bounded env52609 := by
  intro p hp
  have h : env52609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52608_52609 : H12AffineEnvironment.transform 13 13324 env52608 = env52609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env52608 == env52609) = true)

theorem identity52609 : scanCanonicalize (H12AffineFastState.compose env52609 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound52609 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env52610 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,1,8202,5393,10281,1024,0,4160,33,17,8543,8193,65,2128,5392,12557,2341,1365,113,256,8492,13324,513]

theorem envBound52610 : H12AffineFastState.Bounded env52610 := by
  intro p hp
  have h : env52610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52609_52610 : H12AffineEnvironment.transform 14 1 env52609 = env52610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env52609 == env52610) = true)

theorem identity52610 : scanCanonicalize (H12AffineFastState.compose env52610 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound52610 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52611 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5456,1,342,5393,2421,1024,0,4160,33,17,3,349,65,2128,5392,4177,2341,1365,113,256,112,5456,513]

theorem envBound52611 : H12AffineFastState.Bounded env52611 := by
  intro p hp
  have h : env52611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52610_52611 : H12AffineEnvironment.transform 12 348 env52610 = env52611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env52610 == env52611) = true)

theorem identity52611 : scanCanonicalize (H12AffineFastState.compose env52611 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52611 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env52612 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,1,262,5393,2341,1024,0,4112,33,17,3,269,17,2048,5392,4097,2341,1285,33,256,32,5376,513]

theorem envBound52612 : H12AffineFastState.Bounded env52612 := by
  intro p hp
  have h : env52612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52611_52612 : H12AffineEnvironment.transform 5 16 env52611 = env52612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52611 == env52612) = true)

theorem identity52612 : scanCanonicalize (H12AffineFastState.compose env52612 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound52612 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52613 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,5156,1,34,5173,2049,1024,0,4112,33,17,3,41,17,2048,5172,4097,2049,1057,33,36,32,5156,513]

theorem envBound52613 : H12AffineFastState.Bounded env52613 := by
  intro p hp
  have h : env52613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52612_52613 : H12AffineEnvironment.transform 7 36 env52612 = env52613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env52612 == env52613) = true)

def env52614 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,48,40,1044,1,34,1029,2049,1024,0,32,33,17,3,41,17,2048,1028,49,2049,1057,33,36,32,1044,513]

theorem envBound52614 : H12AffineFastState.Bounded env52614 := by
  intro p hp
  have h : env52614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52613_52614 : H12AffineEnvironment.transform 11 48 env52613 = env52614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env52613 == env52614) = true)

theorem identity52614 : scanCanonicalize (H12AffineFastState.compose env52614 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound52614 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52615 : List Nat := [2,4,8,16,32,16,9,36,512,20,2048,48,40,0,1,34,17,2049,20,0,32,33,17,3,41,17,2048,16,49,2049,53,33,36,32,0,513]

theorem envBound52615 : H12AffineFastState.Bounded env52615 := by
  intro p hp
  have h : env52615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52614_52615 : H12AffineEnvironment.transform 9 20 env52614 = env52615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env52614 == env52615) = true)

def env52616 : List Nat := [2,4,8,16,0,16,9,4,512,20,2048,16,8,0,1,2,17,2049,20,0,0,1,17,3,9,17,2048,16,17,2049,21,1,4,0,0,513]

theorem envBound52616 : H12AffineFastState.Bounded env52616 := by
  intro p hp
  have h : env52616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52615_52616 : H12AffineEnvironment.transform 4 0 env52615 = env52616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52615 == env52616) = true)

theorem identity52616 : scanCanonicalize (H12AffineFastState.compose env52616 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound52616 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52617 : List Nat := [2,4,8,16,0,16,9,4,512,20,1,16,8,0,1,2,17,0,20,0,0,1,17,3,9,17,1,16,17,0,21,1,4,0,0,513]

theorem envBound52617 : H12AffineFastState.Bounded env52617 := by
  intro p hp
  have h : env52617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52616_52617 : H12AffineEnvironment.transform 10 1 env52616 = env52617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env52616 == env52617) = true)

def leafEnv52617 : List Nat := [2,4,8,16,0,16,9,4,512,20,1,16,8,0,1,2,17,0,20,0,0,1,17,3,21,9,1,17,1,16,17,0,21,1,4,0,4,3,0,513,1,0,0]

def active52617 : List Nat := [0,1,2,3,8]

def tree52617 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52617 : H12WitnessSearch.Good tree52617 := H12GlobalWitnessIndex.good

theorem leafIdentity52617 : H12AffineFastState.composeSystem env52617 rootObs = leafEnv52617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52617 rootObs == leafEnv52617) = true)

theorem terminalChecked52617 : H12PackedTerminal.terminalCheckFast leafEnv52617 active52617 tree52617 = true := by decide +kernel

def env52618 : List Nat := [2,4,8,16,1,16,9,5,512,20,2048,17,9,0,1,3,17,2049,20,0,1,0,17,3,8,17,2048,16,16,2049,20,0,5,1,0,513]

theorem envBound52618 : H12AffineFastState.Bounded env52618 := by
  intro p hp
  have h : env52618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52615_52618 : H12AffineEnvironment.transform 4 1 env52615 = env52618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52615 == env52618) = true)

theorem identity52618 : scanCanonicalize (H12AffineFastState.compose env52618 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound52618 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52619 : List Nat := [2,4,8,16,1,16,9,5,512,20,522,17,9,0,1,3,17,523,20,0,1,0,17,3,8,17,522,16,16,523,20,0,5,1,0,513]

theorem envBound52619 : H12AffineFastState.Bounded env52619 := by
  intro p hp
  have h : env52619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52618_52619 : H12AffineEnvironment.transform 10 522 env52618 = env52619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env52618 == env52619) = true)

def leafEnv52619 : List Nat := [2,4,8,16,1,16,9,5,512,20,522,17,9,0,1,3,17,523,20,0,1,0,17,3,20,8,1,17,522,16,16,523,20,0,5,1,4,2,0,513,1,1,0]

def active52619 : List Nat := [0,1,2,3,8]

def tree52619 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52619 : H12WitnessSearch.Good tree52619 := H12GlobalWitnessIndex.good

theorem leafIdentity52619 : H12AffineFastState.composeSystem env52619 rootObs = leafEnv52619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52619 rootObs == leafEnv52619) = true)

theorem terminalChecked52619 : H12PackedTerminal.terminalCheckFast leafEnv52619 active52619 tree52619 = true := by decide +kernel

def env52620 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,49,40,1045,1,34,1028,2049,1024,0,33,33,17,3,41,17,2048,1029,48,2049,1057,33,36,32,1045,513]

theorem envBound52620 : H12AffineFastState.Bounded env52620 := by
  intro p hp
  have h : env52620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52613_52620 : H12AffineEnvironment.transform 11 49 env52613 = env52620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env52613 == env52620) = true)

theorem identity52620 : scanCanonicalize (H12AffineFastState.compose env52620 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52620 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52621 : List Nat := [2,4,8,16,0,16,9,4,512,1024,2048,17,8,1045,1,2,1028,2049,1024,0,1,1,17,3,9,17,2048,1029,16,2049,1025,1,4,0,1045,513]

theorem envBound52621 : H12AffineFastState.Bounded env52621 := by
  intro p hp
  have h : env52621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52620_52621 : H12AffineEnvironment.transform 4 0 env52620 = env52621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52620 == env52621) = true)

def env52622 : List Nat := [2,4,8,16,0,16,9,4,512,20,2048,17,8,1,1,2,16,2049,20,0,1,1,17,3,9,17,2048,17,16,2049,21,1,4,0,1,513]

theorem envBound52622 : H12AffineFastState.Bounded env52622 := by
  intro p hp
  have h : env52622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52621_52622 : H12AffineEnvironment.transform 9 20 env52621 = env52622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env52621 == env52622) = true)

theorem identity52622 : scanCanonicalize (H12AffineFastState.compose env52622 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound52622 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52623 : List Nat := [2,4,8,16,0,16,9,4,512,20,0,17,8,1,1,2,16,1,20,0,1,1,17,3,9,17,0,17,16,1,21,1,4,0,1,513]

theorem envBound52623 : H12AffineFastState.Bounded env52623 := by
  intro p hp
  have h : env52623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52622_52623 : H12AffineEnvironment.transform 10 0 env52622 = env52623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env52622 == env52623) = true)

def leafEnv52623 : List Nat := [2,4,8,16,0,16,9,4,512,20,0,17,8,1,1,2,16,1,20,0,1,1,17,3,21,9,1,17,0,17,16,1,21,1,4,0,4,3,1,513,1,1,0]

def active52623 : List Nat := [0,1,2,3,8]

def tree52623 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52623 : H12WitnessSearch.Good tree52623 := H12GlobalWitnessIndex.good

theorem leafIdentity52623 : H12AffineFastState.composeSystem env52623 rootObs = leafEnv52623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52623 rootObs == leafEnv52623) = true)

theorem terminalChecked52623 : H12PackedTerminal.terminalCheckFast leafEnv52623 active52623 tree52623 = true := by decide +kernel

def env52624 : List Nat := [2,4,8,16,0,16,9,4,512,21,2048,17,8,0,1,2,17,2049,21,0,1,1,17,3,9,17,2048,16,16,2049,20,1,4,0,0,513]

theorem envBound52624 : H12AffineFastState.Bounded env52624 := by
  intro p hp
  have h : env52624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52621_52624 : H12AffineEnvironment.transform 9 21 env52621 = env52624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env52621 == env52624) = true)

theorem identity52624 : scanCanonicalize (H12AffineFastState.compose env52624 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound52624 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52625 : List Nat := [2,4,8,16,0,16,9,4,512,21,522,17,8,0,1,2,17,523,21,0,1,1,17,3,9,17,522,16,16,523,20,1,4,0,0,513]

theorem envBound52625 : H12AffineFastState.Bounded env52625 := by
  intro p hp
  have h : env52625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52624_52625 : H12AffineEnvironment.transform 10 522 env52624 = env52625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env52624 == env52625) = true)

def leafEnv52625 : List Nat := [2,4,8,16,0,16,9,4,512,21,522,17,8,0,1,2,17,523,21,0,1,1,17,3,20,9,1,17,522,16,16,523,20,1,4,0,4,3,0,513,1,1,0]

def active52625 : List Nat := [0,1,2,3,8]

def tree52625 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52625 : H12WitnessSearch.Good tree52625 := H12GlobalWitnessIndex.good

theorem leafIdentity52625 : H12AffineFastState.composeSystem env52625 rootObs = leafEnv52625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52625 rootObs == leafEnv52625) = true)

theorem terminalChecked52625 : H12PackedTerminal.terminalCheckFast leafEnv52625 active52625 tree52625 = true := by decide +kernel

def env52626 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1024,32769,276584,272392,272441,98644,8193,65,316532,277816,17665,32041,273789,62589,256,21792,46093,330275]

theorem envBound52626 : H12AffineFastState.Bounded env52626 := by
  intro p hp
  have h : env52626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52605_52626 : H12AffineEnvironment.transform 16 38161 env52605 = env52626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env52605 == env52626) = true)

def env52627 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,64808,1024,32769,50496,54560,54545,98644,8193,65,10588,49168,17665,32041,53333,62589,256,21792,46093,128779]

theorem envBound52627 : H12AffineFastState.Bounded env52627 := by
  intro p hp
  have h : env52627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52626_52627 : H12AffineEnvironment.transform 17 64808 env52626 = env52627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64808 env52626 == env52627) = true)

theorem identity52627 : scanCanonicalize (H12AffineFastState.compose env52627 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound52627 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env52628 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,38161,64808,1024,32769,50496,54560,54545,29790,8193,65,10588,49168,17665,32041,53333,62589,256,21792,46093,513]

theorem envBound52628 : H12AffineFastState.Bounded env52628 := by
  intro p hp
  have h : env52628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52627_52628 : H12AffineEnvironment.transform 15 62730 env52627 = env52628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env52627 == env52628) = true)

theorem identity52628 : scanCanonicalize (H12AffineFastState.compose env52628 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound52628 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52629 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,54358,38161,56436,1024,32769,50496,54560,54545,21762,349,65,2048,49168,17665,23669,53333,54561,256,21792,38225,513]

theorem envBound52629 : H12AffineFastState.Bounded env52629 := by
  intro p hp
  have h : env52629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52628_52629 : H12AffineEnvironment.transform 12 348 env52628 = env52629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env52628 == env52629) = true)

theorem identity52629 : scanCanonicalize (H12AffineFastState.compose env52629 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound52629 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env52630 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,0,21590,5393,23668,1024,1,17728,21792,21777,21762,349,65,2048,16400,17665,23669,20565,21793,256,21792,5457,513]

theorem envBound52630 : H12AffineFastState.Bounded env52630 := by
  intro p hp
  have h : env52630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52629_52630 : H12AffineEnvironment.transform 14 0 env52629 = env52630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env52629 == env52630) = true)

theorem identity52630 : scanCanonicalize (H12AffineFastState.compose env52630 (packedSelected [1,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 1124) := by decide +kernel

theorem selectedBound52630 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env52631 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,1124,0,4146,5393,6160,1024,1,292,4420,4469,4454,349,65,2048,1140,357,6161,5169,4421,256,4420,5457,513]

theorem envBound52631 : H12AffineFastState.Bounded env52631 := by
  intro p hp
  have h : env52631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52630_52631 : H12AffineEnvironment.transform 13 1124 env52630 = env52631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1124 env52630 == env52631) = true)

theorem identity52631 : scanCanonicalize (H12AffineFastState.compose env52631 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(11+1) ^^^ 357) := by decide +kernel

theorem selectedBound52631 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52632 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,357,348,1124,0,343,1140,2421,1024,1,292,33,16,3,349,65,2048,1140,357,2420,1364,32,256,33,1076,513]

theorem envBound52632 : H12AffineFastState.Bounded env52632 := by
  intro p hp
  have h : env52632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52631_52632 : H12AffineEnvironment.transform 11 357 env52631 = env52632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 357 env52631 == env52632) = true)

theorem identity52632 : scanCanonicalize (H12AffineFastState.compose env52632 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound52632 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env52633 : List Nat := [2,4,8,16,32,64,9,256,512,1024,373,357,348,1124,0,343,1140,0,1024,1,292,33,16,3,349,65,373,1140,357,1,1364,32,256,33,1076,513]

theorem envBound52633 : H12AffineFastState.Bounded env52633 := by
  intro p hp
  have h : env52633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52632_52633 : H12AffineEnvironment.transform 10 373 env52632 = env52633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env52632 == env52633) = true)

theorem identity52633 : scanCanonicalize (H12AffineFastState.compose env52633 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound52633 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env52634 : List Nat := [2,4,8,16,32,64,9,256,512,517,373,357,348,609,0,343,625,0,517,1,292,33,16,3,349,65,373,625,357,1,849,32,256,33,561,513]

theorem envBound52634 : H12AffineFastState.Bounded env52634 := by
  intro p hp
  have h : env52634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52633_52634 : H12AffineEnvironment.transform 9 517 env52633 = env52634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env52633 == env52634) = true)

theorem identity52634 : scanCanonicalize (H12AffineFastState.compose env52634 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound52634 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env52635 : List Nat := [2,4,8,16,32,64,9,256,260,257,373,357,348,357,0,343,373,0,257,1,292,33,16,3,349,65,373,373,357,1,85,32,256,33,309,261]

theorem envBound52635 : H12AffineFastState.Bounded env52635 := by
  intro p hp
  have h : env52635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52634_52635 : H12AffineEnvironment.transform 8 260 env52634 = env52635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env52634 == env52635) = true)

theorem identity52635 : scanCanonicalize (H12AffineFastState.compose env52635 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52635 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env52636 : List Nat := [2,4,8,16,0,64,9,256,260,257,341,325,348,325,0,343,341,0,257,1,260,1,16,3,349,65,341,341,325,1,85,0,256,1,277,261]

theorem envBound52636 : H12AffineFastState.Bounded env52636 := by
  intro p hp
  have h : env52636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52635_52636 : H12AffineEnvironment.transform 4 0 env52635 = env52636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52635 == env52636) = true)

theorem identity52636 : scanCanonicalize (H12AffineFastState.compose env52636 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound52636 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env52637 : List Nat := [2,4,8,0,0,64,9,256,260,257,325,325,332,325,0,327,325,0,257,1,260,1,0,3,333,65,325,325,325,1,69,0,256,1,261,261]

theorem envBound52637 : H12AffineFastState.Bounded env52637 := by
  intro p hp
  have h : env52637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52636_52637 : H12AffineEnvironment.transform 3 0 env52636 = env52637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env52636 == env52637) = true)

theorem identity52637 : scanCanonicalize (H12AffineFastState.compose env52637 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound52637 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env52638 : List Nat := [2,4,8,0,0,64,9,68,64,69,1,1,8,1,0,3,1,0,69,1,64,1,0,3,9,65,1,1,1,1,69,0,68,1,65,65]

theorem envBound52638 : H12AffineFastState.Bounded env52638 := by
  intro p hp
  have h : env52638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52637_52638 : H12AffineEnvironment.transform 7 68 env52637 = env52638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env52637 == env52638) = true)

def env52639 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,64809,1024,32769,50497,54561,54544,98644,8193,65,10589,49169,17665,32041,53332,62589,256,21792,46093,128778]

theorem envBound52639 : H12AffineFastState.Bounded env52639 := by
  intro p hp
  have h : env52639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52626_52639 : H12AffineEnvironment.transform 17 64809 env52626 = env52639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64809 env52626 == env52639) = true)

theorem identity52639 : scanCanonicalize (H12AffineFastState.compose env52639 (packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound52639 : packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env52640 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,65536,16401,10281,1024,21761,4161,33,16,87124,8193,65,10589,5393,17665,32041,1364,8573,256,21792,24845,74250]

theorem envBound52640 : H12AffineFastState.Bounded env52640 := by
  intro p hp
  have h : env52640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52639_52640 : H12AffineEnvironment.transform 14 21760 env52639 = env52640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env52639 == env52640) = true)

theorem identity52640 : scanCanonicalize (H12AffineFastState.compose env52640 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound52640 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env52641 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,21590,16401,10281,1024,21761,4161,33,16,2,8193,65,10589,5393,17665,32041,1364,8573,256,21792,24845,30300]

theorem envBound52641 : H12AffineFastState.Bounded env52641 := by
  intro p hp
  have h : env52641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52640_52641 : H12AffineEnvironment.transform 15 21590 env52640 = env52641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env52640 == env52641) = true)

theorem identity52641 : scanCanonicalize (H12AffineFastState.compose env52641 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound52641 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52642 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8541,8203,13388,10281,1024,8540,4161,33,16,2,8193,65,10589,5393,12636,2420,1364,8573,256,8573,5456,513]

theorem envBound52642 : H12AffineFastState.Bounded env52642 := by
  intro p hp
  have h : env52642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52641_52642 : H12AffineEnvironment.transform 13 13405 env52641 = env52642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env52641 == env52642) = true)

def env52643 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,4194304,441641,98780,8328,65,4259061,436264,17664,32040,440549,4606309,256,21792,46212,499506]

theorem envBound52643 : H12AffineFastState.Bounded env52643 := by
  intro p hp
  have h : env52643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52581_52643 : H12AffineEnvironment.transform 22 441641 env52581 = env52643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441641 env52581 == env52643) = true)

def env52644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,272512,441641,98780,8328,65,316533,436264,17664,32040,440549,156133,256,21792,46212,499506]

theorem envBound52644 : H12AffineFastState.Bounded env52644 := by
  intro p hp
  have h : env52644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52643_52644 : H12AffineEnvironment.transform 21 272512 env52643 = env52644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env52643 == env52644) = true)

theorem identity52644 : scanCanonicalize (H12AffineFastState.compose env52644 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149997) := by decide +kernel

theorem selectedBound52644 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52645 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,58516,156013,62660,98780,8328,65,171416,57797,17664,32040,61704,156133,256,21792,46212,120543]

theorem envBound52645 : H12AffineFastState.Bounded env52645 := by
  intro p hp
  have h : env52645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52644_52645 : H12AffineEnvironment.transform 17 149997 env52644 = env52645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149997 env52644 == env52645) = true)

def env52646 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,56573,1024,32769,58516,62589,62660,98780,8328,65,2184,57797,17664,32040,61704,62709,256,21792,46212,120543]

theorem envBound52646 : H12AffineFastState.Bounded env52646 := by
  intro p hp
  have h : env52646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52645_52646 : H12AffineEnvironment.transform 16 38160 env52645 = env52646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env52645 == env52646) = true)

def env52647 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,38160,35325,1024,32769,45460,41341,41412,98780,8328,65,2184,46277,4096,10280,41992,41461,256,32,46212,99295]

theorem envBound52647 : H12AffineFastState.Bounded env52647 := by
  intro p hp
  have h : env52647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52646_52647 : H12AffineEnvironment.transform 13 5376 env52646 = env52647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env52646 == env52647) = true)

theorem identity52647 : scanCanonicalize (H12AffineFastState.compose env52647 (packedSelected [1,4,7,9,16,20,26,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 41090) := by decide +kernel

theorem selectedBound52647 : packedSelected [1,4,7,9,16,20,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env52648 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,41090,38160,35325,1024,32769,45460,41341,41412,8542,8328,65,2184,46277,4096,10280,41992,41461,256,32,46212,9053]

theorem envBound52648 : H12AffineFastState.Bounded env52648 := by
  intro p hp
  have h : env52648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52647_52648 : H12AffineEnvironment.transform 15 41090 env52647 = env52648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41090 env52647 == env52648) = true)

theorem identity52648 : scanCanonicalize (H12AffineFastState.compose env52648 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound52648 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env52649 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5376,32768,33111,38160,35325,1024,32769,36929,32936,32785,139,349,65,2184,38160,4096,2557,34269,32800,256,32,38225,648]

theorem envBound52649 : H12AffineFastState.Bounded env52649 := by
  intro p hp
  have h : env52649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52648_52649 : H12AffineEnvironment.transform 12 469 env52648 = env52649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env52648 == env52649) = true)

theorem identity52649 : scanCanonicalize (H12AffineFastState.compose env52649 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound52649 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env52650 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5376,81,262,5441,2476,1024,80,4112,249,64,139,349,65,2184,5441,4096,2557,1420,113,256,32,5376,648]

theorem envBound52650 : H12AffineFastState.Bounded env52650 := by
  intro p hp
  have h : env52650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52649_52650 : H12AffineEnvironment.transform 14 81 env52649 = env52650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env52649 == env52650) = true)

theorem identity52650 : scanCanonicalize (H12AffineFastState.compose env52650 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound52650 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env52651 : List Nat := [2,4,8,16,32,64,128,256,512,52,2048,4096,469,4404,81,262,4469,2476,52,80,4112,249,64,139,349,65,2184,4469,4096,2557,440,113,256,32,4404,648]

theorem envBound52651 : H12AffineFastState.Bounded env52651 := by
  intro p hp
  have h : env52651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52650_52651 : H12AffineEnvironment.transform 9 52 env52650 = env52651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env52650 == env52651) = true)

theorem identity52651 : scanCanonicalize (H12AffineFastState.compose env52651 (packedSelected [1,8,12,15,19] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound52651 : packedSelected [1,8,12,15,19] rootPS < 2^1333 := by decide +kernel

def env52652 : List Nat := [2,4,8,16,32,64,89,256,512,52,2048,4096,268,4404,81,262,4469,2421,52,80,4112,32,64,82,349,65,2129,4469,4096,2340,353,113,256,32,4404,593]

theorem envBound52652 : H12AffineFastState.Bounded env52652 := by
  intro p hp
  have h : env52652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52651_52652 : H12AffineEnvironment.transform 6 89 env52651 = env52652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env52651 == env52652) = true)

theorem identity52652 : scanCanonicalize (H12AffineFastState.compose env52652 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound52652 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env52653 : List Nat := [2,4,8,16,32,64,89,52,512,52,2048,4096,56,4096,81,50,4161,2113,52,80,4112,32,64,82,105,65,2129,4161,4096,2064,85,113,52,32,4096,593]

theorem envBound52653 : H12AffineFastState.Bounded env52653 := by
  intro p hp
  have h : env52653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52652_52653 : H12AffineEnvironment.transform 7 52 env52652 = env52653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env52652 == env52653) = true)

theorem identity52653 : scanCanonicalize (H12AffineFastState.compose env52653 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 592) := by decide +kernel

theorem selectedBound52653 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env52654 : List Nat := [2,4,8,16,32,64,89,52,512,52,592,4096,56,4096,81,50,4161,529,52,80,4112,32,64,82,105,65,513,4161,4096,576,85,113,52,32,4096,593]

theorem envBound52654 : H12AffineFastState.Bounded env52654 := by
  intro p hp
  have h : env52654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52653_52654 : H12AffineEnvironment.transform 10 592 env52653 = env52654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 592 env52653 == env52654) = true)

def env52655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,38160,35324,1024,32769,45461,41340,41413,98780,8328,65,2184,46276,4097,10281,41993,41460,256,33,46212,99294]

theorem envBound52655 : H12AffineFastState.Bounded env52655 := by
  intro p hp
  have h : env52655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52646_52655 : H12AffineEnvironment.transform 13 5377 env52646 = env52655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env52646 == env52655) = true)

theorem identity52655 : scanCanonicalize (H12AffineFastState.compose env52655 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound52655 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52656 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,38160,35189,1024,32769,45340,41340,41292,98645,8193,65,2049,46157,4097,10281,41993,41341,256,33,46093,99159]

theorem envBound52656 : H12AffineFastState.Bounded env52656 := by
  intro p hp
  have h : env52656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52655_52656 : H12AffineEnvironment.transform 6 9 env52655 = env52656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52655 == env52656) = true)

theorem identity52656 : scanCanonicalize (H12AffineFastState.compose env52656 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

end H12CloudChart0