import H12CloudChart0Data210

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans53415_53416 : H12AffineEnvironment.transform 7 117 env53415 = env53416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env53415 == env53416) = true)

theorem identity53416 : scanCanonicalize (H12AffineFastState.compose env53416 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound53416 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env53417 : List Nat := [2,4,8,16,32,64,9,117,512,15,2048,2090,19,2075,112,25,2059,2106,15,113,2155,32,16,72,18,64,2107,2113,2145,2122,47,32,117,106,2123,512]

theorem envBound53417 : H12AffineFastState.Bounded env53417 := by
  intro p hp
  have h : env53417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53416_53417 : H12AffineEnvironment.transform 9 15 env53416 = env53417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env53416 == env53417) = true)

theorem identity53417 : scanCanonicalize (H12AffineFastState.compose env53417 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 90) := by decide +kernel

theorem selectedBound53417 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env53418 : List Nat := [2,4,8,16,32,64,9,117,512,15,90,112,19,65,112,25,81,96,15,113,49,32,16,72,18,64,97,27,59,16,47,32,117,106,17,512]

theorem envBound53418 : H12AffineFastState.Bounded env53418 := by
  intro p hp
  have h : env53418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53417_53418 : H12AffineEnvironment.transform 10 90 env53417 = env53418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 90 env53417 == env53418) = true)

theorem identity53418 : scanCanonicalize (H12AffineFastState.compose env53418 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound53418 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env53419 : List Nat := [2,4,8,10,32,64,9,111,512,15,64,106,9,65,106,3,75,96,15,107,43,32,10,72,8,64,97,1,33,10,47,32,111,106,11,512]

theorem envBound53419 : H12AffineFastState.Bounded env53419 := by
  intro p hp
  have h : env53419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53418_53419 : H12AffineEnvironment.transform 3 10 env53418 = env53419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env53418 == env53419) = true)

theorem identity53419 : scanCanonicalize (H12AffineFastState.compose env53419 (packedSelected [2,4] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound53419 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env53420 : List Nat := [2,4,6,4,32,64,7,97,512,1,64,100,7,65,100,3,69,96,1,101,37,32,4,70,6,64,97,1,33,4,33,32,97,100,5,512]

theorem envBound53420 : H12AffineFastState.Bounded env53420 := by
  intro p hp
  have h : env53420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53419_53420 : H12AffineEnvironment.transform 2 6 env53419 = env53420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env53419 == env53420) = true)

theorem identity53420 : scanCanonicalize (H12AffineFastState.compose env53420 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 36) := by decide +kernel

theorem selectedBound53420 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53421 : List Nat := [2,4,6,4,32,36,7,5,512,1,36,0,7,37,0,3,33,4,1,1,37,32,4,34,6,36,5,1,33,4,33,32,5,0,5,512]

theorem envBound53421 : H12AffineFastState.Bounded env53421 := by
  intro p hp
  have h : env53421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53420_53421 : H12AffineEnvironment.transform 5 36 env53420 = env53421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 36 env53420 == env53421) = true)

theorem identity53421 : scanCanonicalize (H12AffineFastState.compose env53421 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound53421 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env53422 : List Nat := [2,4,6,4,5,1,7,5,512,1,1,0,7,0,0,3,4,4,1,1,0,5,4,7,6,1,5,1,4,4,4,5,5,0,5,512]

theorem envBound53422 : H12AffineFastState.Bounded env53422 := by
  intro p hp
  have h : env53422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53421_53422 : H12AffineEnvironment.transform 4 5 env53421 = env53422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env53421 == env53422) = true)

theorem identity53422 : scanCanonicalize (H12AffineFastState.compose env53422 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound53422 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53423 : List Nat := [2,0,2,0,1,1,3,1,512,1,1,0,3,0,0,3,0,0,1,1,0,1,0,3,2,1,1,1,0,0,0,1,1,0,1,512]

theorem envBound53423 : H12AffineFastState.Bounded env53423 := by
  intro p hp
  have h : env53423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53422_53423 : H12AffineEnvironment.transform 1 0 env53422 = env53423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env53422 == env53423) = true)

theorem identity53423 : scanCanonicalize (H12AffineFastState.compose env53423 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound53423 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53424 : List Nat := [2,0,2,0,1,1,3,1,3,1,1,0,3,0,0,3,0,0,1,1,0,1,0,3,2,1,1,1,0,0,0,1,1,0,1,3]

theorem envBound53424 : H12AffineFastState.Bounded env53424 := by
  intro p hp
  have h : env53424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53423_53424 : H12AffineEnvironment.transform 8 3 env53423 = env53424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env53423 == env53424) = true)

def env53425 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272513,2101329,98781,8328,64,2259213,2098512,17664,2543697,2102685,2411677,256,21793,46212,2175563]

theorem envBound53425 : H12AffineFastState.Bounded env53425 := by
  intro p hp
  have h : env53425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53383_53425 : H12AffineEnvironment.transform 21 272513 env53383 = env53425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env53383 == env53425) = true)

theorem identity53425 : scanCanonicalize (H12AffineFastState.compose env53425 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115871) := by decide +kernel

theorem selectedBound53425 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53426 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115871,272513,120014,98781,8328,64,245138,115151,17664,464078,119042,329730,256,21793,46212,63188]

theorem envBound53426 : H12AffineFastState.Bounded env53426 := by
  intro p hp
  have h : env53426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53425_53426 : H12AffineEnvironment.transform 20 115871 env53425 = env53426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115871 env53425 == env53426) = true)

def env53427 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,272393,119878,98645,8192,64,245018,115015,17664,463942,119042,329730,256,21793,46092,63068]

theorem envBound53427 : H12AffineFastState.Bounded env53427 := by
  intro p hp
  have h : env53427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53426_53427 : H12AffineEnvironment.transform 6 8 env53426 = env53427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53426 == env53427) = true)

theorem identity53427 : scanCanonicalize (H12AffineFastState.compose env53427 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 171108) := by decide +kernel

theorem selectedBound53427 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env53428 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,171108,1024,32769,115735,177261,119878,98645,8192,64,245018,115015,17664,100386,119042,234598,256,21793,46092,63068]

theorem envBound53428 : H12AffineFastState.Bounded env53428 := by
  intro p hp
  have h : env53428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53427_53428 : H12AffineEnvironment.transform 17 171108 env53427 = env53428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171108 env53427 == env53428) = true)

theorem identity53428 : scanCanonicalize (H12AffineFastState.compose env53428 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound53428 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env53429 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,171108,1024,32769,102678,177261,98631,98645,8192,64,245018,103494,4097,100386,99331,234598,256,32,46092,41821]

theorem envBound53429 : H12AffineFastState.Bounded env53429 := by
  intro p hp
  have h : env53429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53428_53429 : H12AffineEnvironment.transform 13 5377 env53428 = env53429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env53428 == env53429) = true)

theorem identity53429 : scanCanonicalize (H12AffineFastState.compose env53429 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 103495) := by decide +kernel

theorem selectedBound53429 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env53430 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,103495,67619,1024,32769,102678,73770,98631,98645,8192,64,10589,103494,4097,100386,99331,33,256,32,46092,41821]

theorem envBound53430 : H12AffineFastState.Bounded env53430 := by
  intro p hp
  have h : env53430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53429_53430 : H12AffineEnvironment.transform 16 103495 env53429 = env53430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103495 env53429 == env53430) = true)

theorem identity53430 : scanCanonicalize (H12AffineFastState.compose env53430 (packedSelected [3,4,5,9,10,12,14,15,18,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound53430 : packedSelected [3,4,5,9,10,12,14,15,18,20,23] rootPS < 2^1333 := by decide +kernel

def env53431 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,5377,32768,65536,103495,67619,1024,32769,102678,65619,98631,98645,121,64,2340,103494,4097,100386,99331,33,256,32,38005,33572]

theorem envBound53431 : H12AffineFastState.Bounded env53431 := by
  intro p hp
  have h : env53431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53430_53431 : H12AffineEnvironment.transform 12 121 env53430 = env53431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env53430 == env53431) = true)

def env53432 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,272392,119879,98644,8193,64,245019,115014,17664,463943,119042,329730,256,21793,46093,63069]

theorem envBound53432 : H12AffineFastState.Bounded env53432 := by
  intro p hp
  have h : env53432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53426_53432 : H12AffineEnvironment.transform 6 9 env53426 = env53432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53426 == env53432) = true)

theorem identity53432 : scanCanonicalize (H12AffineFastState.compose env53432 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound53432 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env53433 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,115734,32,119879,98644,8193,64,245019,115014,17664,212079,119042,73770,256,21793,46093,63069]

theorem envBound53433 : H12AffineFastState.Bounded env53433 := by
  intro p hp
  have h : env53433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53432_53433 : H12AffineEnvironment.transform 17 10280 env53432 = env53433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env53432 == env53433) = true)

theorem identity53433 : scanCanonicalize (H12AffineFastState.compose env53433 (packedSelected [0,1,3,7,9,12,14,15,20,22,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound53433 : packedSelected [0,1,3,7,9,12,14,15,20,22,24,28] rootPS < 2^1333 := by decide +kernel

def env53434 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10280,1024,32769,115734,32,119879,98644,8193,64,64604,115014,17664,32040,119042,73770,256,21793,46093,63069]

theorem envBound53434 : H12AffineFastState.Bounded env53434 := by
  intro p hp
  have h : env53434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53433_53434 : H12AffineEnvironment.transform 16 82247 env53433 = env53434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env53433 == env53434) = true)

theorem identity53434 : scanCanonicalize (H12AffineFastState.compose env53434 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound53434 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env53435 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,82247,10280,1024,29789,77898,32,73755,95496,8193,64,2048,79130,17664,32040,75102,73770,256,21793,16465,513]

theorem envBound53435 : H12AffineFastState.Bounded env53435 := by
  intro p hp
  have h : env53435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53434_53435 : H12AffineEnvironment.transform 14 29788 env53434 = env53435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env53434 == env53435) = true)

theorem identity53435 : scanCanonicalize (H12AffineFastState.compose env53435 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound53435 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env53436 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,342,16401,10280,1024,29789,12572,32,8525,29790,8193,64,2048,13388,17664,32040,9224,8572,256,21793,16465,513]

theorem envBound53436 : H12AffineFastState.Bounded env53436 := by
  intro p hp
  have h : env53436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53435_53436 : H12AffineEnvironment.transform 15 342 env53435 = env53436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env53435 == env53436) = true)

theorem identity53436 : scanCanonicalize (H12AffineFastState.compose env53436 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound53436 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53437 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,342,16401,2421,1024,21760,4161,32,16,21763,348,64,2048,5393,17664,23669,1365,33,256,21793,16465,513]

theorem envBound53437 : H12AffineFastState.Bounded env53437 := by
  intro p hp
  have h : env53437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53436_53437 : H12AffineEnvironment.transform 12 349 env53436 = env53437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env53436 == env53437) = true)

theorem identity53437 : scanCanonicalize (H12AffineFastState.compose env53437 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound53437 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env53438 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,342,5392,2421,1024,1,4161,32,16,2,348,64,2048,5393,4097,2420,1365,33,256,32,5456,513]

theorem envBound53438 : H12AffineFastState.Bounded env53438 := by
  intro p hp
  have h : env53438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53437_53438 : H12AffineEnvironment.transform 13 5377 env53437 = env53438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env53437 == env53438) = true)

theorem identity53438 : scanCanonicalize (H12AffineFastState.compose env53438 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 868) := by decide +kernel

theorem selectedBound53438 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53439 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,868,349,1637,0,342,1652,2421,1024,1,805,32,16,2,348,64,2048,1653,869,2420,1365,33,256,32,1588,513]

theorem envBound53439 : H12AffineFastState.Bounded env53439 := by
  intro p hp
  have h : env53439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53438_53439 : H12AffineEnvironment.transform 11 868 env53438 = env53439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 868 env53438 == env53439) = true)

theorem identity53439 : scanCanonicalize (H12AffineFastState.compose env53439 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1793) := by decide +kernel

theorem selectedBound53439 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env53440 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1793,868,349,1637,0,342,1652,1652,1024,1,805,32,16,2,348,64,1793,1653,869,1653,1365,33,256,32,1588,513]

theorem envBound53440 : H12AffineFastState.Bounded env53440 := by
  intro p hp
  have h : env53440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53439_53440 : H12AffineEnvironment.transform 10 1793 env53439 = env53440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env53439 == env53440) = true)

theorem identity53440 : scanCanonicalize (H12AffineFastState.compose env53440 (packedSelected [5,8,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53440 : packedSelected [5,8,15] rootPS < 2^1333 := by decide +kernel

def env53441 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,821,268,1588,0,263,1573,1573,1024,1,805,32,16,2,269,17,1793,1572,820,1572,1284,33,256,32,1588,513]

theorem envBound53441 : H12AffineFastState.Bounded env53441 := by
  intro p hp
  have h : env53441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53440_53441 : H12AffineEnvironment.transform 5 17 env53440 = env53441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53440 == env53441) = true)

theorem identity53441 : scanCanonicalize (H12AffineFastState.compose env53441 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound53441 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53442 : List Nat := [2,4,8,16,32,17,9,53,512,1024,1588,512,57,1588,0,50,1573,1573,1024,1,528,32,16,2,56,17,1588,1572,513,1572,1073,33,53,32,1588,513]

theorem envBound53442 : H12AffineFastState.Bounded env53442 := by
  intro p hp
  have h : env53442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53441_53442 : H12AffineEnvironment.transform 7 53 env53441 = env53442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env53441 == env53442) = true)

theorem identity53442 : scanCanonicalize (H12AffineFastState.compose env53442 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound53442 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53443 : List Nat := [2,4,8,16,32,17,9,53,512,564,0,512,57,0,0,50,17,17,564,1,528,32,16,2,56,17,0,16,513,16,517,33,53,32,0,513]

theorem envBound53443 : H12AffineFastState.Bounded env53443 := by
  intro p hp
  have h : env53443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53442_53443 : H12AffineEnvironment.transform 9 564 env53442 = env53443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env53442 == env53443) = true)

theorem identity53443 : scanCanonicalize (H12AffineFastState.compose env53443 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound53443 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env53444 : List Nat := [2,4,8,16,32,17,9,53,17,37,0,17,57,0,0,50,17,17,37,1,1,32,16,2,56,17,0,16,16,16,20,33,53,32,0,16]

theorem envBound53444 : H12AffineFastState.Bounded env53444 := by
  intro p hp
  have h : env53444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53443_53444 : H12AffineEnvironment.transform 8 17 env53443 = env53444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env53443 == env53444) = true)

theorem identity53444 : scanCanonicalize (H12AffineFastState.compose env53444 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53444 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53445 : List Nat := [2,4,8,16,1,17,9,20,17,4,0,17,24,0,0,19,17,17,4,1,1,1,16,2,25,17,0,16,16,16,20,0,20,1,0,16]

theorem envBound53445 : H12AffineFastState.Bounded env53445 := by
  intro p hp
  have h : env53445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53444_53445 : H12AffineEnvironment.transform 4 1 env53444 = env53445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53444 == env53445) = true)

theorem identity53445 : scanCanonicalize (H12AffineFastState.compose env53445 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound53445 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53446 : List Nat := [2,4,8,1,1,0,9,5,0,4,0,0,9,0,0,2,0,0,4,1,1,1,1,2,8,0,0,1,1,1,5,0,5,1,0,1]

theorem envBound53446 : H12AffineFastState.Bounded env53446 := by
  intro p hp
  have h : env53446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53445_53446 : H12AffineEnvironment.transform 3 1 env53445 = env53446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env53445 == env53446) = true)

def env53447 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10588557,8328,64,6705549,8393984,10507601,8830976,2102684,12645452,256,21792,46213,2175562]

theorem envBound53447 : H12AffineFastState.Bounded env53447 := by
  intro p hp
  have h : env53447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53273_53447 : H12AffineEnvironment.transform 23 10588557 env53273 = env53447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588557 env53273 == env53447) = true)

def env53448 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2101328,98781,8328,64,6705549,2098512,17665,2543696,2102684,6349852,256,21792,46213,2175562]

theorem envBound53448 : H12AffineFastState.Bounded env53448 := by
  intro p hp
  have h : env53448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53447_53448 : H12AffineEnvironment.transform 22 2101328 env53447 = env53448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env53447 == env53448) = true)

def env53449 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272512,2101328,98781,8328,64,2259213,2098512,17665,2543696,2102684,2411676,256,21792,46213,2175562]

theorem envBound53449 : H12AffineFastState.Bounded env53449 := by
  intro p hp
  have h : env53449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53448_53449 : H12AffineEnvironment.transform 21 272512 env53448 = env53449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env53448 == env53449) = true)

theorem identity53449 : scanCanonicalize (H12AffineFastState.compose env53449 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58516) := by decide +kernel

theorem selectedBound53449 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53450 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58516,272512,62660,98781,8328,64,171417,57796,17665,406724,61704,272392,256,21792,46213,120542]

theorem envBound53450 : H12AffineFastState.Bounded env53450 := by
  intro p hp
  have h : env53450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53449_53450 : H12AffineEnvironment.transform 20 58516 env53449 = env53450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58516 env53449 == env53450) = true)

def env53451 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,272392,62540,98645,8192,64,171281,57676,17665,406604,61704,272392,256,21792,46093,120406]

theorem envBound53451 : H12AffineFastState.Bounded env53451 := by
  intro p hp
  have h : env53451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53450_53451 : H12AffineEnvironment.transform 6 8 env53450 = env53451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53450 == env53451) = true)

theorem identity53451 : scanCanonicalize (H12AffineFastState.compose env53451 (packedSelected [0,3,4,7,10,12,15,16,17,20,22,24,26,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 157752) := by decide +kernel

theorem selectedBound53451 : packedSelected [0,3,4,7,10,12,15,16,17,20,22,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env53452 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157752,1024,32769,58396,147504,62540,98645,8192,64,171281,57676,17665,23668,61704,147504,256,21792,46093,120406]

theorem envBound53452 : H12AffineFastState.Bounded env53452 := by
  intro p hp
  have h : env53452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53451_53452 : H12AffineEnvironment.transform 17 157752 env53451 = env53452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157752 env53451 == env53452) = true)

theorem identity53452 : scanCanonicalize (H12AffineFastState.compose env53452 (packedSelected [0,4,5,7,8,16,17,20,22,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound53452 : packedSelected [0,4,5,7,8,16,17,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env53453 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,35189,1024,32769,58396,41341,62540,98645,8192,64,31836,57676,17665,23668,61704,41341,256,21792,46093,120406]

theorem envBound53453 : H12AffineFastState.Bounded env53453 := by
  intro p hp
  have h : env53453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53452_53453 : H12AffineEnvironment.transform 16 57677 env53452 = env53453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env53452 == env53453) = true)

theorem identity53453 : scanCanonicalize (H12AffineFastState.compose env53453 (packedSelected [1,5,8,17,19,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound53453 : packedSelected [1,5,8,17,19,24,26] rootPS < 2^1333 := by decide +kernel

def env53454 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,46157,35189,1024,32769,45340,41341,41292,98645,8192,64,10588,46156,4097,2420,41992,41341,256,32,46093,99158]

theorem envBound53454 : H12AffineFastState.Bounded env53454 := by
  intro p hp
  have h : env53454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53453_53454 : H12AffineEnvironment.transform 13 5376 env53453 = env53454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env53453 == env53454) = true)

theorem identity53454 : scanCanonicalize (H12AffineFastState.compose env53454 (packedSelected [3,4,8,9,12,14,15,16,18,19,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound53454 : packedSelected [3,4,8,9,12,14,15,16,18,19,23,24,28] rootPS < 2^1333 := by decide +kernel

def env53455 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,35,46157,35189,1024,32769,45340,41341,41292,33142,8192,64,10588,46156,4097,2420,41992,41341,256,32,46093,33653]

theorem envBound53455 : H12AffineFastState.Bounded env53455 := by
  intro p hp
  have h : env53455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53454_53455 : H12AffineEnvironment.transform 15 35 env53454 = env53455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env53454 == env53455) = true)

theorem identity53455 : scanCanonicalize (H12AffineFastState.compose env53455 (packedSelected [3,5,10,12,15,16,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound53455 : packedSelected [3,5,10,12,15,16,20] rootPS < 2^1333 := by decide +kernel

def env53456 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,35,5393,10281,1024,8541,4160,33,16,8234,8192,64,10588,5392,4097,2420,1364,33,256,32,5457,8745]

theorem envBound53456 : H12AffineFastState.Bounded env53456 := by
  intro p hp
  have h : env53456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53455_53456 : H12AffineEnvironment.transform 14 8540 env53455 = env53456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env53455 == env53456) = true)

theorem identity53456 : scanCanonicalize (H12AffineFastState.compose env53456 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound53456 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env53457 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8,5376,340,35,5393,2081,1024,341,4160,33,16,34,8,64,2388,5392,4097,2420,1364,33,256,32,5457,545]

theorem envBound53457 : H12AffineFastState.Bounded env53457 := by
  intro p hp
  have h : env53457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53456_53457 : H12AffineEnvironment.transform 12 8 env53456 = env53457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env53456 == env53457) = true)

theorem identity53457 : scanCanonicalize (H12AffineFastState.compose env53457 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound53457 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53458 : List Nat := [2,4,8,16,32,64,8,256,512,305,2048,4096,8,4145,340,35,4128,2081,305,341,4160,33,16,34,8,64,2388,4129,4097,2420,101,33,256,32,4192,545]

theorem envBound53458 : H12AffineFastState.Bounded env53458 := by
  intro p hp
  have h : env53458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53457_53458 : H12AffineEnvironment.transform 9 305 env53457 = env53458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env53457 == env53458) = true)

theorem identity53458 : scanCanonicalize (H12AffineFastState.compose env53458 (packedSelected [2,6,11] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound53458 : packedSelected [2,6,11] rootPS < 2^1333 := by decide +kernel

def env53459 : List Nat := [2,4,8,16,32,48,8,256,512,305,2048,4096,8,4145,292,35,4128,2081,305,293,4144,33,16,34,8,48,2340,4129,4097,2308,21,33,256,32,4112,545]

theorem envBound53459 : H12AffineFastState.Bounded env53459 := by
  intro p hp
  have h : env53459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53458_53459 : H12AffineEnvironment.transform 5 48 env53458 = env53459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env53458 == env53459) = true)

theorem identity53459 : scanCanonicalize (H12AffineFastState.compose env53459 (packedSelected [2,6,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound53459 : packedSelected [2,6,12] rootPS < 2^1333 := by decide +kernel

def env53460 : List Nat := [2,4,8,16,32,48,8,37,512,20,2048,4096,8,4145,1,35,4128,2081,20,0,4144,33,16,34,8,48,2049,4129,4097,2081,21,33,37,32,4112,545]

theorem envBound53460 : H12AffineFastState.Bounded env53460 := by
  intro p hp
  have h : env53460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53459_53460 : H12AffineEnvironment.transform 7 37 env53459 = env53460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env53459 == env53460) = true)

theorem identity53460 : scanCanonicalize (H12AffineFastState.compose env53460 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound53460 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env53461 : List Nat := [2,4,8,16,0,16,8,5,512,20,2048,4096,8,4113,1,3,4096,2049,20,0,4112,1,16,2,8,16,2049,4097,4097,2049,21,1,5,0,4112,513]

theorem envBound53461 : H12AffineFastState.Bounded env53461 := by
  intro p hp
  have h : env53461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53460_53461 : H12AffineEnvironment.transform 4 0 env53460 = env53461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53460 == env53461) = true)

theorem identity53461 : scanCanonicalize (H12AffineFastState.compose env53461 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound53461 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53462 : List Nat := [2,4,8,16,0,16,8,5,512,20,529,4096,8,4113,1,3,4096,528,20,0,4112,1,16,2,8,16,528,4097,4097,528,21,1,5,0,4112,513]

theorem envBound53462 : H12AffineFastState.Bounded env53462 := by
  intro p hp
  have h : env53462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53461_53462 : H12AffineEnvironment.transform 10 529 env53461 = env53462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env53461 == env53462) = true)

theorem identity53462 : scanCanonicalize (H12AffineFastState.compose env53462 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound53462 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53463 : List Nat := [2,4,8,0,0,0,8,5,512,4,513,4096,8,4097,1,3,4096,512,4,0,4096,1,0,2,8,0,512,4097,4097,512,5,1,5,0,4096,513]

theorem envBound53463 : H12AffineFastState.Bounded env53463 := by
  intro p hp
  have h : env53463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53462_53463 : H12AffineEnvironment.transform 3 0 env53462 = env53463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53462 == env53463) = true)

theorem identity53463 : scanCanonicalize (H12AffineFastState.compose env53463 (packedSelected [3] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound53463 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53464 : List Nat := [2,4,8,0,0,0,8,5,512,4,513,512,8,513,1,3,512,512,4,0,512,1,0,2,8,0,512,513,513,512,5,1,5,0,512,513]

theorem envBound53464 : H12AffineFastState.Bounded env53464 := by
  intro p hp
  have h : env53464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53463_53464 : H12AffineEnvironment.transform 11 512 env53463 = env53464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env53463 == env53464) = true)

def env53465 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,272393,62541,98644,8193,64,171280,57677,17665,406605,61704,272392,256,21792,46092,120407]

theorem envBound53465 : H12AffineFastState.Bounded env53465 := by
  intro p hp
  have h : env53465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53450_53465 : H12AffineEnvironment.transform 6 9 env53450 = env53465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53450 == env53465) = true)

theorem identity53465 : scanCanonicalize (H12AffineFastState.compose env53465 (packedSelected [0,3,4,7,10,12,15,16,17,20,22,24,26,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 130174) := by decide +kernel

theorem selectedBound53465 : packedSelected [0,3,4,7,10,12,15,16,17,20,22,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env53466 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,130174,1024,32769,58397,119927,62541,98644,8193,64,171280,57677,17665,247859,61704,119926,256,21792,46092,120407]

theorem envBound53466 : H12AffineFastState.Bounded env53466 := by
  intro p hp
  have h : env53466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53465_53466 : H12AffineEnvironment.transform 17 130174 env53465 = env53466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130174 env53465 == env53466) = true)

def env53467 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,67618,1024,29789,4161,73771,17,95496,8193,64,158028,5393,17665,212079,1364,73770,256,21792,16464,74251]

theorem envBound53467 : H12AffineFastState.Bounded env53467 := by
  intro p hp
  have h : env53467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53466_53467 : H12AffineEnvironment.transform 14 29788 env53466 = env53467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env53466 == env53467) = true)

theorem identity53467 : scanCanonicalize (H12AffineFastState.compose env53467 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound53467 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53468 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,131072,10280,1024,29789,4161,33,17,21762,8193,64,158028,5393,17665,138341,1364,32,256,21792,16464,513]

theorem envBound53468 : H12AffineFastState.Bounded env53468 := by
  intro p hp
  have h : env53468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53467_53468 : H12AffineEnvironment.transform 15 8202 env53467 = env53468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env53467 == env53468) = true)

theorem identity53468 : scanCanonicalize (H12AffineFastState.compose env53468 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53468 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env53469 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29709,8202,131072,10280,1024,29708,4112,33,17,21762,8193,17,157981,5393,17665,138292,1285,32,256,21792,16385,513]

theorem envBound53469 : H12AffineFastState.Bounded env53469 := by
  intro p hp
  have h : env53469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53468_53469 : H12AffineEnvironment.transform 5 17 env53468 = env53469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53468 == env53469) = true)

theorem identity53469 : scanCanonicalize (H12AffineFastState.compose env53469 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound53469 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env53470 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,1,8202,131072,10280,1024,0,4112,33,17,8462,8193,17,138513,5393,12557,138292,1285,32,256,8492,13325,513]

theorem envBound53470 : H12AffineFastState.Bounded env53470 := by
  intro p hp
  have h : env53470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53469_53470 : H12AffineEnvironment.transform 13 13324 env53469 = env53470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env53469 == env53470) = true)

theorem identity53470 : scanCanonicalize (H12AffineFastState.compose env53470 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound53470 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53471 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,1,263,131072,2341,1024,0,4112,33,17,3,268,17,138513,5393,4096,138292,1285,32,256,33,5376,513]

theorem envBound53471 : H12AffineFastState.Bounded env53471 := by
  intro p hp
  have h : env53471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53470_53471 : H12AffineEnvironment.transform 12 269 env53470 = env53471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env53470 == env53471) = true)

theorem identity53471 : scanCanonicalize (H12AffineFastState.compose env53471 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound53471 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env53472 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3328,269,2049,1,263,131072,2341,1024,0,3344,33,17,3,268,17,131089,2065,3328,131380,1285,32,256,33,2048,513]

theorem envBound53472 : H12AffineFastState.Bounded env53472 := by
  intro p hp
  have h : env53472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53471_53472 : H12AffineEnvironment.transform 11 3328 env53471 = env53472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env53471 == env53472) = true)

theorem identity53472 : scanCanonicalize (H12AffineFastState.compose env53472 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 2064) := by decide +kernel

theorem selectedBound53472 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env53473 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3328,269,2049,1,263,2064,2341,1024,0,3344,33,17,3,268,17,2049,2065,3328,2340,1285,32,256,33,2048,513]

theorem envBound53473 : H12AffineFastState.Bounded env53473 := by
  intro p hp
  have h : env53473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53472_53473 : H12AffineEnvironment.transform 16 2064 env53472 = env53473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2064 env53472 == env53473) = true)

theorem identity53473 : scanCanonicalize (H12AffineFastState.compose env53473 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound53473 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53474 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,3109,40,2049,1,34,2064,2048,1024,0,3125,33,17,3,41,17,2049,2065,3109,2049,1056,32,37,33,2048,513]

theorem envBound53474 : H12AffineFastState.Bounded env53474 := by
  intro p hp
  have h : env53474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53473_53474 : H12AffineEnvironment.transform 7 37 env53473 = env53474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env53473 == env53474) = true)

theorem identity53474 : scanCanonicalize (H12AffineFastState.compose env53474 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1598) := by decide +kernel

theorem selectedBound53474 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53475 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1598,539,40,1599,1,34,1582,1598,1024,0,523,33,17,3,41,17,1599,1583,539,1599,1056,32,37,33,1598,513]

theorem envBound53475 : H12AffineFastState.Bounded env53475 := by
  intro p hp
  have h : env53475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53474_53475 : H12AffineEnvironment.transform 10 1598 env53474 = env53475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1598 env53474 == env53475) = true)

theorem identity53475 : scanCanonicalize (H12AffineFastState.compose env53475 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 61) := by decide +kernel

theorem selectedBound53475 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env53476 : List Nat := [2,4,8,16,32,17,9,37,61,1024,1027,38,40,1026,1,34,1043,1027,1024,0,54,33,17,3,41,17,1026,1042,38,1026,1056,32,37,33,1027,60]

theorem envBound53476 : H12AffineFastState.Bounded env53476 := by
  intro p hp
  have h : env53476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53475_53476 : H12AffineEnvironment.transform 8 61 env53475 = env53476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 61 env53475 == env53476) = true)

theorem identity53476 : scanCanonicalize (H12AffineFastState.compose env53476 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 35) := by decide +kernel

theorem selectedBound53476 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53477 : List Nat := [2,4,8,16,32,17,9,37,61,35,32,38,40,33,1,34,48,32,35,0,54,33,17,3,41,17,33,49,38,33,3,32,37,33,32,60]

theorem envBound53477 : H12AffineFastState.Bounded env53477 := by
  intro p hp
  have h : env53477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53476_53477 : H12AffineEnvironment.transform 9 35 env53476 = env53477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 35 env53476 == env53477) = true)

theorem identity53477 : scanCanonicalize (H12AffineFastState.compose env53477 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound53477 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53478 : List Nat := [2,4,8,5,32,4,9,37,40,35,32,38,40,33,1,34,37,32,35,0,35,33,4,3,41,4,33,36,38,33,3,32,37,33,32,41]

theorem envBound53478 : H12AffineFastState.Bounded env53478 := by
  intro p hp
  have h : env53478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53477_53478 : H12AffineEnvironment.transform 3 5 env53477 = env53478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env53477 == env53478) = true)

def env53479 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,67619,1024,29788,4160,73770,16,95497,8193,64,158029,5392,17665,212078,1365,73771,256,21792,16465,74250]

theorem envBound53479 : H12AffineFastState.Bounded env53479 := by
  intro p hp
  have h : env53479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53466_53479 : H12AffineEnvironment.transform 14 29789 env53466 = env53479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env53466 == env53479) = true)

theorem identity53479 : scanCanonicalize (H12AffineFastState.compose env53479 (packedSelected [2,4,6,7,11,14,22,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound53479 : packedSelected [2,4,6,7,11,14,22,23,27] rootPS < 2^1333 := by decide +kernel

def env53480 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,342,131072,2421,1024,29788,4160,8572,16,29791,8193,64,158029,5392,17665,146744,1365,8573,256,21792,16465,9052]

theorem envBound53480 : H12AffineFastState.Bounded env53480 := by
  intro p hp
  have h : env53480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53479_53480 : H12AffineEnvironment.transform 15 342 env53479 = env53480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env53479 == env53480) = true)

theorem identity53480 : scanCanonicalize (H12AffineFastState.compose env53480 (packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS)) = affineNative (2^(16+1) ^^^ 16449) := by decide +kernel

theorem selectedBound53480 : packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS < 2^1333 := by decide +kernel

def env53481 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,342,16449,2421,1024,29788,4160,8572,16,29791,8193,64,10508,5392,17665,32121,1365,8573,256,21792,16465,9052]

theorem envBound53481 : H12AffineFastState.Bounded env53481 := by
  intro p hp
  have h : env53481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53480_53481 : H12AffineEnvironment.transform 16 16449 env53480 = env53481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env53480 == env53481) = true)

theorem identity53481 : scanCanonicalize (H12AffineFastState.compose env53481 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound53481 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env53482 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,342,16449,2421,1024,21760,4160,32,16,21763,349,64,2128,5392,17665,23589,1365,33,256,21792,16465,512]

theorem envBound53482 : H12AffineFastState.Bounded env53482 := by
  intro p hp
  have h : env53482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53481_53482 : H12AffineEnvironment.transform 12 348 env53481 = env53482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env53481 == env53482) = true)

theorem identity53482 : scanCanonicalize (H12AffineFastState.compose env53482 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5408) := by decide +kernel

theorem selectedBound53482 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53483 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5408,33,342,5473,2421,1024,32,4160,32,16,35,349,64,2128,5392,4129,2309,1365,33,256,0,5489,512]

theorem envBound53483 : H12AffineFastState.Bounded env53483 := by
  intro p hp
  have h : env53483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53482_53483 : H12AffineEnvironment.transform 13 5408 env53482 = env53483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5408 env53482 == env53483) = true)

theorem identity53483 : scanCanonicalize (H12AffineFastState.compose env53483 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound53483 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53484 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,348,4145,33,342,4208,2421,273,32,4160,32,16,35,349,64,2128,4097,4129,2309,68,33,256,0,4192,512]

theorem envBound53484 : H12AffineFastState.Bounded env53484 := by
  intro p hp
  have h : env53484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53483_53484 : H12AffineEnvironment.transform 9 273 env53483 = env53484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env53483 == env53484) = true)

theorem identity53484 : scanCanonicalize (H12AffineFastState.compose env53484 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound53484 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env53485 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,2097,348,2048,33,342,2113,2421,273,32,2161,32,16,35,349,64,2128,2096,2064,2309,68,33,256,0,2129,512]

theorem envBound53485 : H12AffineFastState.Bounded env53485 := by
  intro p hp
  have h : env53485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53484_53485 : H12AffineEnvironment.transform 11 2097 env53484 = env53485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env53484 == env53485) = true)

theorem identity53485 : scanCanonicalize (H12AffineFastState.compose env53485 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound53485 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env53486 : List Nat := [2,4,8,16,32,48,9,256,512,273,2048,2097,300,2048,33,294,2097,2309,273,32,2049,32,16,35,301,48,2080,2096,2064,2309,52,33,256,0,2081,512]

theorem envBound53486 : H12AffineFastState.Bounded env53486 := by
  intro p hp
  have h : env53486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53485_53486 : H12AffineEnvironment.transform 5 48 env53485 = env53486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env53485 == env53486) = true)

theorem identity53486 : scanCanonicalize (H12AffineFastState.compose env53486 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound53486 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env53487 : List Nat := [2,4,8,16,32,48,9,5,512,20,2048,2097,41,2048,33,35,2097,2048,20,32,2049,32,16,35,40,48,2080,2096,2064,2048,52,33,5,0,2081,512]

theorem envBound53487 : H12AffineFastState.Bounded env53487 := by
  intro p hp
  have h : env53487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53486_53487 : H12AffineEnvironment.transform 7 5 env53486 = env53487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env53486 == env53487) = true)

theorem identity53487 : scanCanonicalize (H12AffineFastState.compose env53487 (packedSelected [2,14] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound53487 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env53488 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,2065,9,2048,1,3,2065,2048,20,0,2049,0,16,3,8,16,2048,2064,2064,2048,20,1,5,0,2049,512]

theorem envBound53488 : H12AffineFastState.Bounded env53488 := by
  intro p hp
  have h : env53488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53487_53488 : H12AffineEnvironment.transform 4 0 env53487 = env53488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53487 == env53488) = true)

theorem identity53488 : scanCanonicalize (H12AffineFastState.compose env53488 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound53488 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53489 : List Nat := [2,4,8,16,0,16,9,5,1,20,2048,2065,9,2048,1,3,2065,2048,20,0,2049,0,16,3,8,16,2048,2064,2064,2048,20,1,5,0,2049,1]

theorem envBound53489 : H12AffineFastState.Bounded env53489 := by
  intro p hp
  have h : env53489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53488_53489 : H12AffineEnvironment.transform 8 1 env53488 = env53489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env53488 == env53489) = true)

theorem identity53489 : scanCanonicalize (H12AffineFastState.compose env53489 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound53489 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53490 : List Nat := [2,4,8,4,0,4,9,5,1,0,2048,2053,9,2048,1,3,2053,2048,0,0,2049,0,4,3,8,4,2048,2052,2052,2048,0,1,5,0,2049,1]

theorem envBound53490 : H12AffineFastState.Bounded env53490 := by
  intro p hp
  have h : env53490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53489_53490 : H12AffineEnvironment.transform 3 4 env53489 = env53490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env53489 == env53490) = true)

def leafEnv53490 : List Nat := [2,4,8,4,0,4,9,5,1,0,2048,2053,9,2048,1,3,2053,2048,0,0,2049,0,4,3,0,8,1,4,2048,2052,2052,2048,0,1,5,0,4,2,2049,1,1,2048,0]

def active53490 : List Nat := [0,1,2,10]

def tree53490 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53490 : H12WitnessSearch.Good tree53490 := H12GlobalWitnessIndex.good

theorem leafIdentity53490 : H12AffineFastState.composeSystem env53490 rootObs = leafEnv53490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53490 rootObs == leafEnv53490) = true)

theorem terminalChecked53490 : H12PackedTerminal.terminalCheckFast leafEnv53490 active53490 tree53490 = true := by decide +kernel

def env53491 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272513,2101328,98781,8328,64,2259212,2098512,17665,2543696,2102684,2411677,256,21792,46213,2175562]

theorem envBound53491 : H12AffineFastState.Bounded env53491 := by
  intro p hp
  have h : env53491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53448_53491 : H12AffineEnvironment.transform 21 272513 env53448 = env53491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env53448 == env53491) = true)

theorem identity53491 : scanCanonicalize (H12AffineFastState.compose env53491 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound53491 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53492 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,2097152,272513,2101328,95497,8328,64,2259212,2098512,17665,2499716,2102684,2373705,256,21792,16465,2175562]

theorem envBound53492 : H12AffineFastState.Bounded env53492 := by
  intro p hp
  have h : env53492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53491_53492 : H12AffineEnvironment.transform 14 29908 env53491 = env53492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env53491 == env53492) = true)

def env53493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,262144,1024,8661,2097152,272513,2101328,73737,8328,64,2239500,2098512,4097,2499716,2102684,2373705,256,32,5457,2175562]

theorem envBound53493 : H12AffineFastState.Bounded env53493 := by
  intro p hp
  have h : env53493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53492_53493 : H12AffineEnvironment.transform 13 5376 env53492 = env53493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env53492 == env53493) = true)

def env53494 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,262144,1024,8661,4160,272513,16,73737,8328,64,146508,5392,4097,406724,1500,272393,256,32,5457,74250]

theorem envBound53494 : H12AffineFastState.Bounded env53494 := by
  intro p hp
  have h : env53494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53493_53494 : H12AffineEnvironment.transform 20 4160 env53493 = env53494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env53493 == env53494) = true)

theorem identity53494 : scanCanonicalize (H12AffineFastState.compose env53494 (packedSelected [0,2,4,7,9,11,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 138477) := by decide +kernel

theorem selectedBound53494 : packedSelected [0,2,4,7,9,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env53495 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,138477,1024,8661,4160,144492,16,73737,8328,64,146508,5392,4097,10281,1500,144612,256,32,5457,74250]

theorem envBound53495 : H12AffineFastState.Bounded env53495 := by
  intro p hp
  have h : env53495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53494_53495 : H12AffineEnvironment.transform 17 138477 env53494 = env53495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138477 env53494 == env53495) = true)

theorem identity53495 : scanCanonicalize (H12AffineFastState.compose env53495 (packedSelected [1,2,3,9,16,18,20,22,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 79298) := by decide +kernel

theorem selectedBound53495 : packedSelected [1,2,3,9,16,18,20,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env53496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,79298,76079,1024,8661,4160,65966,16,73737,8328,64,67982,5392,4097,10281,1500,65830,256,32,5457,74250]

theorem envBound53496 : H12AffineFastState.Bounded env53496 := by
  intro p hp
  have h : env53496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53495_53496 : H12AffineEnvironment.transform 16 79298 env53495 = env53496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79298 env53495 == env53496) = true)

theorem identity53496 : scanCanonicalize (H12AffineFastState.compose env53496 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound53496 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env53497 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,263,13509,10280,1024,8661,4160,169,16,8462,8328,64,2185,5392,4097,10281,1500,33,256,32,5457,8973]

theorem envBound53497 : H12AffineFastState.Bounded env53497 := by
  intro p hp
  have h : env53497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53496_53497 : H12AffineEnvironment.transform 15 263 env53496 = env53497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env53496 == env53497) = true)

theorem identity53497 : scanCanonicalize (H12AffineFastState.compose env53497 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound53497 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env53498 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,263,13388,10280,1024,8540,4160,32,16,8462,8193,64,2048,5392,4097,10281,1365,33,256,32,5457,8973]

theorem envBound53498 : H12AffineFastState.Bounded env53498 := by
  intro p hp
  have h : env53498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53497_53498 : H12AffineEnvironment.transform 6 9 env53497 = env53498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53497 == env53498) = true)

theorem identity53498 : scanCanonicalize (H12AffineFastState.compose env53498 (packedSelected [6,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound53498 : packedSelected [6,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env53499 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,263,5393,2421,1024,1,4160,32,16,83,348,64,2048,5392,4097,2420,1365,33,256,32,5457,592]

theorem envBound53499 : H12AffineFastState.Bounded env53499 := by
  intro p hp
  have h : env53499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53498_53499 : H12AffineEnvironment.transform 12 349 env53498 = env53499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env53498 == env53499) = true)

theorem identity53499 : scanCanonicalize (H12AffineFastState.compose env53499 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound53499 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env53500 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,513,349,1793,0,263,1808,2421,1024,1,577,32,16,83,348,64,2048,1809,512,2420,1365,33,256,32,1872,592]

theorem envBound53500 : H12AffineFastState.Bounded env53500 := by
  intro p hp
  have h : env53500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53499_53500 : H12AffineEnvironment.transform 11 513 env53499 = env53500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env53499 == env53500) = true)

theorem identity53500 : scanCanonicalize (H12AffineFastState.compose env53500 (packedSelected [0,1,3,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53500 : packedSelected [0,1,3,7,11] rootPS < 2^1333 := by decide +kernel

def env53501 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,513,269,1793,0,263,1808,2341,1024,1,529,32,16,3,268,16,2048,1809,512,2340,1285,33,256,32,1792,512]

theorem envBound53501 : H12AffineFastState.Bounded env53501 := by
  intro p hp
  have h : env53501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53500_53501 : H12AffineEnvironment.transform 5 16 env53500 = env53501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53500 == env53501) = true)

def env53502 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,262144,1024,8661,4161,272513,17,73737,8328,64,146509,5393,4097,406725,1501,272392,256,32,5457,74251]

theorem envBound53502 : H12AffineFastState.Bounded env53502 := by
  intro p hp
  have h : env53502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53493_53502 : H12AffineEnvironment.transform 20 4161 env53493 = env53502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env53493 == env53502) = true)

theorem identity53502 : scanCanonicalize (H12AffineFastState.compose env53502 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound53502 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53503 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10401,1024,8661,4161,32,17,73737,8328,64,146509,5393,4097,138340,1501,169,256,32,5457,74251]

theorem envBound53503 : H12AffineFastState.Bounded env53503 := by
  intro p hp
  have h : env53503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53502_53503 : H12AffineEnvironment.transform 17 10401 env53502 = env53503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env53502 == env53503) = true)

theorem identity53503 : scanCanonicalize (H12AffineFastState.compose env53503 (packedSelected [1,2,3,5,8,9,10,16,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound53503 : packedSelected [1,2,3,5,8,9,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env53504 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,89,5376,397,65536,131072,2296,1024,396,4161,32,17,65616,209,64,138260,5393,4097,138340,1501,169,256,32,5457,66130]

theorem envBound53504 : H12AffineFastState.Bounded env53504 := by
  intro p hp
  have h : env53504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53503_53504 : H12AffineEnvironment.transform 12 89 env53503 = env53504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env53503 == env53504) = true)

theorem identity53504 : scanCanonicalize (H12AffineFastState.compose env53504 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound53504 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env53505 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,89,5376,397,65536,5392,2296,1024,396,4161,32,17,65616,209,64,2308,5393,4097,2420,1501,169,256,32,5457,66130]

theorem envBound53505 : H12AffineFastState.Bounded env53505 := by
  intro p hp
  have h : env53505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53504_53505 : H12AffineEnvironment.transform 16 5392 env53504 = env53505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env53504 == env53505) = true)

theorem identity53505 : scanCanonicalize (H12AffineFastState.compose env53505 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 83) := by decide +kernel

theorem selectedBound53505 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53506 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,89,5376,397,83,5392,2296,1024,396,4161,32,17,3,209,64,2308,5393,4097,2420,1501,169,256,32,5457,513]

theorem envBound53506 : H12AffineFastState.Bounded env53506 := by
  intro p hp
  have h : env53506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53505_53506 : H12AffineEnvironment.transform 15 83 env53505 = env53506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 83 env53505 == env53506) = true)

theorem identity53506 : scanCanonicalize (H12AffineFastState.compose env53506 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound53506 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env53507 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,89,5376,260,83,5392,2161,1024,261,4161,32,17,3,88,64,2308,5393,4097,2420,1364,32,256,32,5457,513]

theorem envBound53507 : H12AffineFastState.Bounded env53507 := by
  intro p hp
  have h : env53507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53506_53507 : H12AffineEnvironment.transform 6 9 env53506 = env53507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53506 == env53507) = true)

def env53508 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,262144,1024,8660,2097152,272513,2101328,73736,8328,64,2239501,2098512,4096,2499716,2102684,2373705,256,33,5456,2175562]

theorem envBound53508 : H12AffineFastState.Bounded env53508 := by
  intro p hp
  have h : env53508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53492_53508 : H12AffineEnvironment.transform 13 5377 env53492 = env53508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env53492 == env53508) = true)

def env53509 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,262144,1024,8660,4160,272513,16,73736,8328,64,146509,5392,4096,406724,1500,272393,256,33,5456,74250]

theorem envBound53509 : H12AffineFastState.Bounded env53509 := by
  intro p hp
  have h : env53509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53508_53509 : H12AffineEnvironment.transform 20 4160 env53508 = env53509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env53508 == env53509) = true)

theorem identity53509 : scanCanonicalize (H12AffineFastState.compose env53509 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound53509 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53510 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,4160,272392,16,73736,8193,64,146509,5392,4096,406605,1365,272393,256,33,5456,74250]

theorem envBound53510 : H12AffineFastState.Bounded env53510 := by
  intro p hp
  have h : env53510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53509_53510 : H12AffineEnvironment.transform 6 9 env53509 = env53510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53509 == env53510) = true)

theorem identity53510 : scanCanonicalize (H12AffineFastState.compose env53510 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 138512) := by decide +kernel

theorem selectedBound53510 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env53511 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,131072,138512,1024,8541,4160,144664,16,73736,8193,64,146509,5392,4096,10589,1365,144665,256,33,5456,74250]

theorem envBound53511 : H12AffineFastState.Bounded env53511 := by
  intro p hp
  have h : env53511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53510_53511 : H12AffineEnvironment.transform 17 138512 env53510 = env53511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138512 env53510 == env53511) = true)

theorem identity53511 : scanCanonicalize (H12AffineFastState.compose env53511 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound53511 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env53512 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8574,131072,138512,1024,8541,4160,144664,16,374,8193,64,146509,5392,4096,10589,1365,144665,256,33,5456,884]

theorem envBound53512 : H12AffineFastState.Bounded env53512 := by
  intro p hp
  have h : env53512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53511_53512 : H12AffineEnvironment.transform 15 8574 env53511 = env53512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env53511 == env53512) = true)

theorem identity53512 : scanCanonicalize (H12AffineFastState.compose env53512 (packedSelected [0,2,7,14,20] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound53512 : packedSelected [0,2,7,14,20] rootPS < 2^1333 := by decide +kernel

def env53513 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5236,8233,8203,131072,138341,1024,8232,4160,144493,16,3,8193,64,146509,5221,4096,10280,1056,144492,117,33,5157,513]

theorem envBound53513 : H12AffineFastState.Bounded env53513 := by
  intro p hp
  have h : env53513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53512_53513 : H12AffineEnvironment.transform 7 117 env53512 = env53513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env53512 == env53513) = true)

theorem identity53513 : scanCanonicalize (H12AffineFastState.compose env53513 (packedSelected [2,14] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound53513 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env53514 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5236,8233,8203,5221,2048,1024,8232,4160,8200,16,3,8193,64,10280,5221,4096,10280,1056,8201,117,33,5157,513]

theorem envBound53514 : H12AffineFastState.Bounded env53514 := by
  intro p hp
  have h : env53514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53513_53514 : H12AffineEnvironment.transform 16 5221 env53513 = env53514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env53513 == env53514) = true)

theorem identity53514 : scanCanonicalize (H12AffineFastState.compose env53514 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound53514 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env53515 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,1,8192,1141,8233,8203,1124,2048,1024,8232,65,8200,16,3,8193,64,10280,1124,1,10280,1056,8201,117,33,1060,513]

theorem envBound53515 : H12AffineFastState.Bounded env53515 := by
  intro p hp
  have h : env53515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53514_53515 : H12AffineEnvironment.transform 11 1 env53514 = env53515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env53514 == env53515) = true)

theorem identity53515 : scanCanonicalize (H12AffineFastState.compose env53515 (packedSelected [1,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound53515 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env53516 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,1,2088,1141,2049,2083,1124,2048,1024,2048,65,2080,16,3,2089,64,0,1124,1,0,1056,2081,117,33,1060,513]

theorem envBound53516 : H12AffineFastState.Bounded env53516 := by
  intro p hp
  have h : env53516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53515_53516 : H12AffineEnvironment.transform 12 2088 env53515 = env53516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env53515 == env53516) = true)

theorem identity53516 : scanCanonicalize (H12AffineFastState.compose env53516 (packedSelected [2,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53516 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env53517 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,1,2088,1061,2049,2083,1076,2048,1024,2048,17,2080,16,3,2089,16,0,1076,1,0,1056,2081,37,33,1060,513]

theorem envBound53517 : H12AffineFastState.Bounded env53517 := by
  intro p hp
  have h : env53517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53516_53517 : H12AffineEnvironment.transform 5 16 env53516 = env53517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53516 == env53517) = true)

theorem identity53517 : scanCanonicalize (H12AffineFastState.compose env53517 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound53517 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53518 : List Nat := [2,4,8,16,32,16,9,37,512,1024,16,1,56,1061,17,51,1076,16,1024,16,17,48,16,3,57,16,0,1076,1,0,1056,49,37,33,1060,513]

theorem envBound53518 : H12AffineFastState.Bounded env53518 := by
  intro p hp
  have h : env53518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53517_53518 : H12AffineEnvironment.transform 10 16 env53517 = env53518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env53517 == env53518) = true)

theorem identity53518 : scanCanonicalize (H12AffineFastState.compose env53518 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound53518 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53519 : List Nat := [2,4,8,0,32,0,9,37,512,1024,0,1,40,1061,1,35,1060,0,1024,0,1,32,0,3,41,0,0,1060,1,0,1056,33,37,33,1060,513]

theorem envBound53519 : H12AffineFastState.Bounded env53519 := by
  intro p hp
  have h : env53519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53518_53519 : H12AffineEnvironment.transform 3 0 env53518 = env53519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53518 == env53519) = true)

theorem identity53519 : scanCanonicalize (H12AffineFastState.compose env53519 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound53519 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53520 : List Nat := [2,4,8,0,32,0,9,37,512,549,0,1,40,512,1,35,513,0,549,0,1,32,0,3,41,0,0,513,1,0,517,33,37,33,513,513]

theorem envBound53520 : H12AffineFastState.Bounded env53520 := by
  intro p hp
  have h : env53520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53519_53520 : H12AffineEnvironment.transform 9 549 env53519 = env53520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env53519 == env53520) = true)

theorem identity53520 : scanCanonicalize (H12AffineFastState.compose env53520 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound53520 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env53521 : List Nat := [2,4,8,0,32,0,9,37,1,36,0,1,40,1,1,35,0,0,36,0,1,32,0,3,41,0,0,0,1,0,4,33,37,33,0,0]

theorem envBound53521 : H12AffineFastState.Bounded env53521 := by
  intro p hp
  have h : env53521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53520_53521 : H12AffineEnvironment.transform 8 1 env53520 = env53521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env53520 == env53521) = true)

def env53522 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,262144,1024,8660,4161,272513,17,73736,8328,64,146508,5393,4096,406725,1501,272392,256,33,5456,74251]

theorem envBound53522 : H12AffineFastState.Bounded env53522 := by
  intro p hp
  have h : env53522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53508_53522 : H12AffineEnvironment.transform 20 4161 env53508 = env53522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env53508 == env53522) = true)

theorem identity53522 : scanCanonicalize (H12AffineFastState.compose env53522 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound53522 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53523 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10280,1024,8660,4161,169,17,73736,8328,64,146508,5393,4096,138477,1501,32,256,33,5456,74251]

theorem envBound53523 : H12AffineFastState.Bounded env53523 := by
  intro p hp
  have h : env53523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53522_53523 : H12AffineEnvironment.transform 17 10280 env53522 = env53523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env53522 == env53523) = true)

theorem identity53523 : scanCanonicalize (H12AffineFastState.compose env53523 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound53523 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env53524 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,5393,10280,1024,8660,4161,169,17,73736,8328,64,10589,5393,4096,2556,1501,32,256,33,5456,74251]

theorem envBound53524 : H12AffineFastState.Bounded env53524 := by
  intro p hp
  have h : env53524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53523_53524 : H12AffineEnvironment.transform 16 5393 env53523 = env53524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env53523 == env53524) = true)

theorem identity53524 : scanCanonicalize (H12AffineFastState.compose env53524 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound53524 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env53525 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,5377,113,65536,5393,2444,1024,112,4161,169,17,65964,300,64,2297,5393,4096,2556,1501,32,256,33,5456,66479]

theorem envBound53525 : H12AffineFastState.Bounded env53525 := by
  intro p hp
  have h : env53525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53524_53525 : H12AffineEnvironment.transform 12 420 env53524 = env53525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env53524 == env53525) = true)

theorem identity53525 : scanCanonicalize (H12AffineFastState.compose env53525 (packedSelected [2,6,16,20] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound53525 : packedSelected [2,6,16,20] rootPS < 2^1333 := by decide +kernel

def env53526 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,300,5377,113,65536,5393,2308,1024,112,4161,33,17,65828,300,64,2161,5393,4096,2420,1365,32,256,33,5456,66343]

theorem envBound53526 : H12AffineFastState.Bounded env53526 := by
  intro p hp
  have h : env53526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53525_53526 : H12AffineEnvironment.transform 6 8 env53525 = env53526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53525 == env53526) = true)

theorem identity53526 : scanCanonicalize (H12AffineFastState.compose env53526 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 294) := by decide +kernel

theorem selectedBound53526 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53527 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,300,5377,113,294,5393,2308,1024,112,4161,33,17,2,300,64,2161,5393,4096,2420,1365,32,256,33,5456,513]

theorem envBound53527 : H12AffineFastState.Bounded env53527 := by
  intro p hp
  have h : env53527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53526_53527 : H12AffineEnvironment.transform 15 294 env53526 = env53527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 294 env53526 == env53527) = true)

def env53528 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2101329,98780,8328,64,6705549,2098513,17664,2543697,2102684,6349853,256,21792,46213,2175562]

theorem envBound53528 : H12AffineFastState.Bounded env53528 := by
  intro p hp
  have h : env53528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53447_53528 : H12AffineEnvironment.transform 22 2101329 env53447 = env53528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env53447 == env53528) = true)

def env53529 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272512,2101329,98780,8328,64,2259213,2098513,17664,2543697,2102684,2411677,256,21792,46213,2175562]

theorem envBound53529 : H12AffineFastState.Bounded env53529 := by
  intro p hp
  have h : env53529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53528_53529 : H12AffineEnvironment.transform 21 272512 env53528 = env53529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env53528 == env53529) = true)

theorem identity53529 : scanCanonicalize (H12AffineFastState.compose env53529 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound53529 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,272512,16,98780,8328,64,158028,5392,17664,442384,1501,318684,256,21792,46213,74251]

theorem envBound53530 : H12AffineFastState.Bounded env53530 := by
  intro p hp
  have h : env53530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53529_53530 : H12AffineEnvironment.transform 20 4161 env53529 = env53530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env53529 == env53530) = true)

theorem identity53530 : scanCanonicalize (H12AffineFastState.compose env53530 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound53530 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env53531 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,4161,272512,16,41430,8328,64,158028,5392,17664,442384,1501,318684,256,21792,46213,513]

theorem envBound53531 : H12AffineFastState.Bounded env53531 := by
  intro p hp
  have h : env53531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53530_53531 : H12AffineEnvironment.transform 15 8202 env53530 = env53531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env53530 == env53531) = true)

theorem identity53531 : scanCanonicalize (H12AffineFastState.compose env53531 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 46108) := by decide +kernel

theorem selectedBound53531 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env53532 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,46108,262144,1024,32769,4161,272512,16,41430,8328,64,56656,5392,17664,291852,1501,318684,256,21792,46213,513]

theorem envBound53532 : H12AffineFastState.Bounded env53532 := by
  intro p hp
  have h : env53532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53531_53532 : H12AffineEnvironment.transform 16 46108 env53531 = env53532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46108 env53531 == env53532) = true)

def env53533 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,46108,262144,1024,32769,4161,272392,16,41310,8192,64,56656,5392,17664,291852,1365,318548,256,21792,46093,513]

theorem envBound53533 : H12AffineFastState.Bounded env53533 := by
  intro p hp
  have h : env53533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53532_53533 : H12AffineEnvironment.transform 6 8 env53532 = env53533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53532 == env53533) = true)

theorem identity53533 : scanCanonicalize (H12AffineFastState.compose env53533 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound53533 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53534 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,5440,262144,1024,8541,4161,272392,16,2,8192,64,31756,5392,17664,291852,1365,294152,256,21792,5457,513]

theorem envBound53534 : H12AffineFastState.Bounded env53534 := by
  intro p hp
  have h : env53534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53533_53534 : H12AffineEnvironment.transform 14 8540 env53533 = env53534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env53533 == env53534) = true)

theorem identity53534 : scanCanonicalize (H12AffineFastState.compose env53534 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 2129) := by decide +kernel

theorem selectedBound53534 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env53535 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,5440,2129,1024,8541,4161,8281,16,2,8192,64,31756,5392,17664,31837,1365,30041,256,21792,5457,513]

theorem envBound53535 : H12AffineFastState.Bounded env53535 := by
  intro p hp
  have h : env53535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53534_53535 : H12AffineEnvironment.transform 17 2129 env53534 = env53535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2129 env53534 == env53535) = true)

theorem identity53535 : scanCanonicalize (H12AffineFastState.compose env53535 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound53535 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env53536 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8540,8202,4176,2129,272,8541,4161,8281,16,2,8192,64,31004,4096,16400,31053,69,28745,256,20528,4161,513]

theorem envBound53536 : H12AffineFastState.Bounded env53536 := by
  intro p hp
  have h : env53536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53535_53536 : H12AffineEnvironment.transform 9 272 env53535 = env53536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env53535 == env53536) = true)

theorem identity53536 : scanCanonicalize (H12AffineFastState.compose env53536 (packedSelected [1,2,6,8,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound53536 : packedSelected [1,2,6,8,10] rootPS < 2^1333 := by decide +kernel

def env53537 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4112,8540,8202,4176,2129,272,8541,4161,8281,16,2,8192,64,10508,4096,4096,10589,69,8281,256,32,4161,513]

theorem envBound53537 : H12AffineFastState.Bounded env53537 := by
  intro p hp
  have h : env53537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53536_53537 : H12AffineEnvironment.transform 13 4112 env53536 = env53537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env53536 == env53537) = true)

theorem identity53537 : scanCanonicalize (H12AffineFastState.compose env53537 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound53537 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53538 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,40,4112,372,34,4176,2129,272,373,4161,113,16,2,40,64,2340,4096,4096,2421,69,113,256,32,4161,513]

theorem envBound53538 : H12AffineFastState.Bounded env53538 := by
  intro p hp
  have h : env53538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53537_53538 : H12AffineEnvironment.transform 12 40 env53537 = env53538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env53537 == env53538) = true)

theorem identity53538 : scanCanonicalize (H12AffineFastState.compose env53538 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53538 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env53539 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,40,4112,292,34,4096,2049,272,293,4113,33,16,2,40,16,2340,4096,4096,2341,21,33,256,32,4113,513]

theorem envBound53539 : H12AffineFastState.Bounded env53539 := by
  intro p hp
  have h : env53539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53538_53539 : H12AffineEnvironment.transform 5 16 env53538 = env53539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53538 == env53539) = true)

theorem identity53539 : scanCanonicalize (H12AffineFastState.compose env53539 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound53539 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53540 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,4096,40,4112,1,34,4096,2049,53,0,4113,33,16,2,40,16,2049,4096,4096,2048,21,33,37,32,4113,513]

theorem envBound53540 : H12AffineFastState.Bounded env53540 := by
  intro p hp
  have h : env53540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53539_53540 : H12AffineEnvironment.transform 7 37 env53539 = env53540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env53539 == env53540) = true)

theorem identity53540 : scanCanonicalize (H12AffineFastState.compose env53540 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound53540 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53541 : List Nat := [2,4,8,16,32,16,8,37,512,53,49,4096,40,4112,1,34,4096,48,53,0,4113,33,16,2,40,16,48,4096,4096,49,21,33,37,32,4113,513]

theorem envBound53541 : H12AffineFastState.Bounded env53541 := by
  intro p hp
  have h : env53541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53540_53541 : H12AffineEnvironment.transform 10 49 env53540 = env53541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env53540 == env53541) = true)

theorem identity53541 : scanCanonicalize (H12AffineFastState.compose env53541 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound53541 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env53542 : List Nat := [2,4,8,16,32,16,8,37,512,53,49,32,40,48,1,34,32,48,53,0,49,33,16,2,40,16,48,32,32,49,21,33,37,32,49,513]

theorem envBound53542 : H12AffineFastState.Bounded env53542 := by
  intro p hp
  have h : env53542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53541_53542 : H12AffineEnvironment.transform 11 32 env53541 = env53542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env53541 == env53542) = true)

def leafEnv53542 : List Nat := [2,4,8,16,32,16,8,37,512,53,49,32,40,48,1,34,32,48,53,0,49,33,16,2,21,40,1,16,48,32,32,49,21,33,37,32,4,34,49,513,1,48,0]

def active53542 : List Nat := [0,1,2,3,4,8]

def tree53542 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53542 : H12WitnessSearch.Good tree53542 := H12GlobalWitnessIndex.good

theorem leafIdentity53542 : H12AffineFastState.composeSystem env53542 rootObs = leafEnv53542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53542 rootObs == leafEnv53542) = true)

theorem terminalChecked53542 : H12PackedTerminal.terminalCheckFast leafEnv53542 active53542 tree53542 = true := by decide +kernel

def env53543 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,46108,262144,1024,32769,4161,272393,16,41311,8193,64,56656,5392,17664,291852,1364,318549,256,21792,46092,513]

theorem envBound53543 : H12AffineFastState.Bounded env53543 := by
  intro p hp
  have h : env53543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53532_53543 : H12AffineEnvironment.transform 6 9 env53532 = env53543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53532 == env53543) = true)

theorem identity53543 : scanCanonicalize (H12AffineFastState.compose env53543 (packedSelected [0,1,5,7,8,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound53543 : packedSelected [0,1,5,7,8,20,24] rootPS < 2^1333 := by decide +kernel

def env53544 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,16449,262144,1024,29788,4161,272393,16,21762,8193,64,10509,5392,17664,291852,1364,272392,256,21792,16465,513]

theorem envBound53544 : H12AffineFastState.Bounded env53544 := by
  intro p hp
  have h : env53544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53543_53544 : H12AffineEnvironment.transform 14 29789 env53543 = env53544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env53543 == env53544) = true)

theorem identity53544 : scanCanonicalize (H12AffineFastState.compose env53544 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound53544 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env53545 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,16449,2341,1024,29788,4161,8492,16,21762,8193,64,10509,5392,17664,32041,1364,8493,256,21792,16465,513]

theorem envBound53545 : H12AffineFastState.Bounded env53545 := by
  intro p hp
  have h : env53545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53544_53545 : H12AffineEnvironment.transform 17 2341 env53544 = env53545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env53544 == env53545) = true)

theorem identity53545 : scanCanonicalize (H12AffineFastState.compose env53545 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53545 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env53546 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29708,8202,16400,2341,1024,29709,4112,8492,16,21762,8193,17,10509,5392,17664,32041,1285,8493,256,21792,16384,513]

theorem envBound53546 : H12AffineFastState.Bounded env53546 := by
  intro p hp
  have h : env53546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53545_53546 : H12AffineEnvironment.transform 5 17 env53545 = env53546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53545 == env53546) = true)

theorem identity53546 : scanCanonicalize (H12AffineFastState.compose env53546 (packedSelected [5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound53546 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env53547 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,21761,263,16400,2341,1024,21760,4112,33,16,21762,268,17,2048,5392,17664,23588,1285,32,256,21792,16384,513]

theorem envBound53547 : H12AffineFastState.Bounded env53547 := by
  intro p hp
  have h : env53547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53546_53547 : H12AffineEnvironment.transform 12 269 env53546 = env53547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env53546 == env53547) = true)

theorem identity53547 : scanCanonicalize (H12AffineFastState.compose env53547 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound53547 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53548 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,0,263,5393,2341,1024,1,4112,33,16,3,268,17,2048,5392,4097,2341,1285,32,256,33,5377,513]

theorem envBound53548 : H12AffineFastState.Bounded env53548 := by
  intro p hp
  have h : env53548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53547_53548 : H12AffineEnvironment.transform 13 5377 env53547 = env53548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env53547 == env53548) = true)

theorem identity53548 : scanCanonicalize (H12AffineFastState.compose env53548 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound53548 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53549 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5157,0,35,5173,2049,1024,1,4112,33,16,3,40,17,2048,5172,4097,2049,1057,32,36,33,5157,513]

theorem envBound53549 : H12AffineFastState.Bounded env53549 := by
  intro p hp
  have h : env53549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53548_53549 : H12AffineEnvironment.transform 7 36 env53548 = env53549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env53548 == env53549) = true)

def env53550 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,41,1045,0,35,1029,2049,1024,1,32,33,16,3,40,17,2048,1028,49,2049,1057,32,36,33,1045,513]

theorem envBound53550 : H12AffineFastState.Bounded env53550 := by
  intro p hp
  have h : env53550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53549_53550 : H12AffineEnvironment.transform 11 48 env53549 = env53550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env53549 == env53550) = true)

def env53551 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,41,1044,0,35,1028,2049,1024,1,33,33,16,3,40,17,2048,1029,48,2049,1057,32,36,33,1044,513]

theorem envBound53551 : H12AffineFastState.Bounded env53551 := by
  intro p hp
  have h : env53551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53549_53551 : H12AffineEnvironment.transform 11 49 env53549 = env53551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env53549 == env53551) = true)

theorem identity53551 : scanCanonicalize (H12AffineFastState.compose env53551 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound53551 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53552 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,49,41,33,0,35,49,2049,53,1,33,33,16,3,40,17,2048,48,48,2049,20,32,36,33,33,513]

theorem envBound53552 : H12AffineFastState.Bounded env53552 := by
  intro p hp
  have h : env53552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53551_53552 : H12AffineEnvironment.transform 9 53 env53551 = env53552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env53551 == env53552) = true)

def env53553 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272513,2101329,98780,8328,64,2259212,2098513,17664,2543697,2102684,2411676,256,21792,46213,2175562]

theorem envBound53553 : H12AffineFastState.Bounded env53553 := by
  intro p hp
  have h : env53553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53528_53553 : H12AffineEnvironment.transform 21 272513 env53528 = env53553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env53528 == env53553) = true)

def env53554 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272393,2101329,98644,8192,64,2259212,2098513,17664,2543697,2102548,2411540,256,21792,46093,2175562]

theorem envBound53554 : H12AffineFastState.Bounded env53554 := by
  intro p hp
  have h : env53554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53553_53554 : H12AffineEnvironment.transform 6 8 env53553 = env53554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53553 == env53554) = true)

theorem identity53554 : scanCanonicalize (H12AffineFastState.compose env53554 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound53554 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env53555 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,2097152,272393,2101329,98644,8192,64,2111773,2098513,17664,2396224,2102548,2411540,256,21792,46093,2175562]

theorem envBound53555 : H12AffineFastState.Bounded env53555 := by
  intro p hp
  have h : env53555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53554_53555 : H12AffineEnvironment.transform 16 16401 env53554 = env53555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env53554 == env53555) = true)

def env53556 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,4160,272393,17,98644,8192,64,10589,5393,17664,294912,1364,318548,256,21792,46093,74250]

theorem envBound53556 : H12AffineFastState.Bounded env53556 := by
  intro p hp
  have h : env53556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53555_53556 : H12AffineEnvironment.transform 20 4160 env53555 = env53556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env53555 == env53556) = true)

theorem identity53556 : scanCanonicalize (H12AffineFastState.compose env53556 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound53556 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53557 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1024,32769,4160,41340,17,98644,8192,64,10589,5393,17664,2421,1364,21793,256,21792,46093,74250]

theorem envBound53557 : H12AffineFastState.Bounded env53557 := by
  intro p hp
  have h : env53557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53556_53557 : H12AffineEnvironment.transform 17 35189 env53556 = env53557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env53556 == env53557) = true)

theorem identity53557 : scanCanonicalize (H12AffineFastState.compose env53557 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 62811) := by decide +kernel

theorem selectedBound53557 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env53558 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62811,16401,35189,1024,32769,4160,41340,17,29711,8192,64,10589,5393,17664,2421,1364,21793,256,21792,46093,55121]

theorem envBound53558 : H12AffineFastState.Bounded env53558 := by
  intro p hp
  have h : env53558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53557_53558 : H12AffineEnvironment.transform 15 62811 env53557 = env53558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62811 env53557 == env53558) = true)

theorem identity53558 : scanCanonicalize (H12AffineFastState.compose env53558 (packedSelected [0,1,4,10,11,15,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound53558 : packedSelected [0,1,4,10,11,15,20,24] rootPS < 2^1333 := by decide +kernel

def env53559 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,21511,16401,10281,1024,8541,4160,32,17,29711,8192,64,10589,5393,17664,2421,1364,21793,256,21792,5457,30221]

theorem envBound53559 : H12AffineFastState.Bounded env53559 := by
  intro p hp
  have h : env53559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53558_53559 : H12AffineEnvironment.transform 14 8540 env53558 = env53559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env53558 == env53559) = true)

theorem identity53559 : scanCanonicalize (H12AffineFastState.compose env53559 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 4453) := by decide +kernel

theorem selectedBound53559 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env53560 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4453,8540,1378,4468,10281,1024,8541,4160,32,17,9578,8192,64,10589,5393,5221,2421,1364,1092,256,1093,5457,10088]

theorem envBound53560 : H12AffineFastState.Bounded env53560 := by
  intro p hp
  have h : env53560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53559_53560 : H12AffineEnvironment.transform 13 4453 env53559 = env53560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4453 env53559 == env53560) = true)

theorem identity53560 : scanCanonicalize (H12AffineFastState.compose env53560 (packedSelected [0,3,6,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound53560 : packedSelected [0,3,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env53561 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,8192,4453,8540,343,4468,10281,53,8541,4160,32,17,8543,8192,64,10589,4388,4176,2421,353,113,256,112,4452,9053]

theorem envBound53561 : H12AffineFastState.Bounded env53561 := by
  intro p hp
  have h : env53561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53560_53561 : H12AffineEnvironment.transform 9 53 env53560 = env53561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env53560 == env53561) = true)

theorem identity53561 : scanCanonicalize (H12AffineFastState.compose env53561 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53561 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env53562 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,4096,8192,4404,8461,262,4389,10281,53,8460,4113,32,17,8462,8192,17,10508,4388,4097,2340,304,32,256,33,4405,8972]

theorem envBound53562 : H12AffineFastState.Bounded env53562 := by
  intro p hp
  have h : env53562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53561_53562 : H12AffineEnvironment.transform 5 17 env53561 = env53562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53561 == env53562) = true)

theorem identity53562 : scanCanonicalize (H12AffineFastState.compose env53562 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound53562 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env53563 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,4096,8192,4113,8232,35,4096,10281,53,8233,4113,32,17,8235,8192,17,10281,4097,4097,2049,21,32,37,33,4112,8745]

theorem envBound53563 : H12AffineFastState.Bounded env53563 := by
  intro p hp
  have h : env53563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53562_53563 : H12AffineEnvironment.transform 7 37 env53562 = env53563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env53562 == env53563) = true)

theorem identity53563 : scanCanonicalize (H12AffineFastState.compose env53563 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 4136) := by decide +kernel

theorem selectedBound53563 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53564 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,4096,4136,4113,4096,35,4096,6145,53,4097,4113,32,17,4099,4136,17,6145,4097,4097,2049,21,32,37,33,4112,4609]

theorem envBound53564 : H12AffineFastState.Bounded env53564 := by
  intro p hp
  have h : env53564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53563_53564 : H12AffineEnvironment.transform 12 4136 env53563 = env53564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4136 env53563 == env53564) = true)

theorem identity53564 : scanCanonicalize (H12AffineFastState.compose env53564 (packedSelected [1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound53564 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env53565 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,1,41,16,1,35,1,2048,53,0,16,32,17,2,41,17,2048,0,0,2049,21,32,37,33,17,512]

theorem envBound53565 : H12AffineFastState.Bounded env53565 := by
  intro p hp
  have h : env53565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53564_53565 : H12AffineEnvironment.transform 11 1 env53564 = env53565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env53564 == env53565) = true)

theorem identity53565 : scanCanonicalize (H12AffineFastState.compose env53565 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 47) := by decide +kernel

theorem selectedBound53565 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53566 : List Nat := [2,4,8,16,32,17,8,37,47,53,2048,1,41,16,1,35,1,2048,53,0,16,32,17,2,41,17,2048,0,0,2049,21,32,37,33,17,47]

theorem envBound53566 : H12AffineFastState.Bounded env53566 := by
  intro p hp
  have h : env53566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53565_53566 : H12AffineEnvironment.transform 8 47 env53565 = env53566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 47 env53565 == env53566) = true)

def env53567 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,4161,272393,16,98644,8192,64,10588,5392,17664,294913,1365,318549,256,21792,46093,74251]

theorem envBound53567 : H12AffineFastState.Bounded env53567 := by
  intro p hp
  have h : env53567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53555_53567 : H12AffineEnvironment.transform 20 4161 env53555 = env53567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env53555 == env53567) = true)

theorem identity53567 : scanCanonicalize (H12AffineFastState.compose env53567 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound53567 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53568 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,262144,1024,8541,4161,272393,16,73736,8192,64,10588,5392,17664,270685,1365,294153,256,21792,5457,74251]

theorem envBound53568 : H12AffineFastState.Bounded env53568 := by
  intro p hp
  have h : env53568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53567_53568 : H12AffineEnvironment.transform 14 8540 env53567 = env53568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env53567 == env53568) = true)

theorem identity53568 : scanCanonicalize (H12AffineFastState.compose env53568 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound53568 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env53569 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16401,262144,1024,8541,4161,272393,16,2,8192,64,10588,5392,17664,270685,1365,294153,256,21792,5457,513]

theorem envBound53569 : H12AffineFastState.Bounded env53569 := by
  intro p hp
  have h : env53569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53568_53569 : H12AffineEnvironment.transform 15 8202 env53568 = env53569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env53568 == env53569) = true)

theorem identity53569 : scanCanonicalize (H12AffineFastState.compose env53569 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 2309) := by decide +kernel

theorem selectedBound53569 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env53570 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16401,2309,1024,8541,4161,8460,16,2,8192,64,10588,5392,17664,10328,1365,29708,256,21792,5457,513]

theorem envBound53570 : H12AffineFastState.Bounded env53570 := by
  intro p hp
  have h : env53570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53569_53570 : H12AffineEnvironment.transform 17 2309 env53569 = env53570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2309 env53569 == env53570) = true)

theorem identity53570 : scanCanonicalize (H12AffineFastState.compose env53570 (packedSelected [6,14] rootPS)) = affineNative (2^(13+1) ^^^ 12604) := by decide +kernel

theorem selectedBound53570 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env53571 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12604,8540,8202,12589,2309,1024,8541,4161,8460,16,2,8192,64,10588,5392,13372,10328,1365,1328,256,9244,5457,513]

theorem envBound53571 : H12AffineFastState.Bounded env53571 := by
  intro p hp
  have h : env53571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53570_53571 : H12AffineEnvironment.transform 13 12604 env53570 = env53571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12604 env53570 == env53571) = true)

theorem identity53571 : scanCanonicalize (H12AffineFastState.compose env53571 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound53571 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53572 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4193,1,343,4208,2309,1024,0,4161,81,16,2,349,64,2049,5392,5473,2309,1365,1328,256,1345,5457,513]

theorem envBound53572 : H12AffineFastState.Bounded env53572 := by
  intro p hp
  have h : env53572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53571_53572 : H12AffineEnvironment.transform 12 349 env53571 = env53572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env53571 == env53572) = true)

theorem identity53572 : scanCanonicalize (H12AffineFastState.compose env53572 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 2161) := by decide +kernel

theorem selectedBound53572 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env53573 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2161,349,2064,1,343,2049,2309,1024,0,2096,81,16,2,349,64,2049,3425,3344,2309,1365,1328,256,1345,3360,513]

theorem envBound53573 : H12AffineFastState.Bounded env53573 := by
  intro p hp
  have h : env53573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53572_53573 : H12AffineEnvironment.transform 11 2161 env53572 = env53573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2161 env53572 == env53573) = true)

theorem identity53573 : scanCanonicalize (H12AffineFastState.compose env53573 (packedSelected [1,8,19] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound53573 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env53574 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,2161,349,2064,1,343,2049,2309,273,0,2096,81,16,2,349,64,2049,2160,2049,2309,68,33,256,80,2097,513]

theorem envBound53574 : H12AffineFastState.Bounded env53574 := by
  intro p hp
  have h : env53574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53573_53574 : H12AffineEnvironment.transform 9 273 env53573 = env53574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env53573 == env53574) = true)

theorem identity53574 : scanCanonicalize (H12AffineFastState.compose env53574 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound53574 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53575 : List Nat := [2,4,8,16,32,64,8,256,512,273,293,340,349,309,1,343,292,32,273,0,277,81,16,2,349,64,292,341,292,32,68,33,256,80,276,513]

theorem envBound53575 : H12AffineFastState.Bounded env53575 := by
  intro p hp
  have h : env53575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53574_53575 : H12AffineEnvironment.transform 10 293 env53574 = env53575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env53574 == env53575) = true)

theorem identity53575 : scanCanonicalize (H12AffineFastState.compose env53575 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound53575 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53576 : List Nat := [2,4,8,16,0,64,8,256,512,273,261,340,349,277,1,343,260,0,273,0,277,81,16,2,349,64,260,341,260,0,68,1,256,80,276,513]

theorem envBound53576 : H12AffineFastState.Bounded env53576 := by
  intro p hp
  have h : env53576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53575_53576 : H12AffineEnvironment.transform 4 0 env53575 = env53576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53575 == env53576) = true)

theorem identity53576 : scanCanonicalize (H12AffineFastState.compose env53576 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 335) := by decide +kernel

theorem selectedBound53576 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env53577 : List Nat := [2,4,8,16,0,64,8,256,335,273,261,340,349,277,1,343,260,0,273,0,277,81,16,2,349,64,260,341,260,0,68,1,256,80,276,334]

theorem envBound53577 : H12AffineFastState.Bounded env53577 := by
  intro p hp
  have h : env53577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53576_53577 : H12AffineEnvironment.transform 8 335 env53576 = env53577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 335 env53576 == env53577) = true)

theorem identity53577 : scanCanonicalize (H12AffineFastState.compose env53577 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound53577 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env53578 : List Nat := [2,4,3,16,0,64,3,256,324,273,261,340,342,277,1,343,260,0,273,0,277,81,16,2,342,64,260,341,260,0,68,1,256,80,276,325]

theorem envBound53578 : H12AffineFastState.Bounded env53578 := by
  intro p hp
  have h : env53578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53577_53578 : H12AffineEnvironment.transform 2 3 env53577 = env53578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env53577 == env53578) = true)

theorem identity53578 : scanCanonicalize (H12AffineFastState.compose env53578 (packedSelected [0,3] rootPS)) = affineNative (2^(7+1) ^^^ 66) := by decide +kernel

theorem selectedBound53578 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env53579 : List Nat := [2,4,3,16,0,64,3,66,6,83,71,22,20,87,1,21,70,0,83,0,87,81,16,2,20,64,70,23,70,0,68,1,66,80,86,7]

theorem envBound53579 : H12AffineFastState.Bounded env53579 := by
  intro p hp
  have h : env53579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53578_53579 : H12AffineEnvironment.transform 7 66 env53578 = env53579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 66 env53578 == env53579) = true)

theorem identity53579 : scanCanonicalize (H12AffineFastState.compose env53579 (packedSelected [0,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound53579 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env53580 : List Nat := [2,4,3,0,0,64,3,66,6,67,71,6,4,71,1,5,70,0,67,0,71,65,0,2,4,64,70,7,70,0,68,1,66,64,70,7]

theorem envBound53580 : H12AffineFastState.Bounded env53580 := by
  intro p hp
  have h : env53580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53579_53580 : H12AffineEnvironment.transform 3 0 env53579 = env53580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53579 == env53580) = true)

theorem identity53580 : scanCanonicalize (H12AffineFastState.compose env53580 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound53580 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53581 : List Nat := [2,0,3,0,0,64,3,66,2,67,67,2,0,67,1,1,66,0,67,0,67,65,0,2,0,64,66,3,66,0,64,1,66,64,66,3]

theorem envBound53581 : H12AffineFastState.Bounded env53581 := by
  intro p hp
  have h : env53581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53580_53581 : H12AffineEnvironment.transform 1 0 env53580 = env53581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env53580 == env53581) = true)

theorem identity53581 : scanCanonicalize (H12AffineFastState.compose env53581 (packedSelected [0,11] rootPS)) = affineNative (2^(5+1) ^^^ 3) := by decide +kernel

theorem selectedBound53581 : packedSelected [0,11] rootPS < 2^1333 := by decide +kernel

def env53582 : List Nat := [2,0,3,0,0,3,3,1,2,0,0,2,0,0,1,1,1,0,0,0,0,2,0,2,0,3,1,3,1,0,3,1,1,3,1,3]

theorem envBound53582 : H12AffineFastState.Bounded env53582 := by
  intro p hp
  have h : env53582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53581_53582 : H12AffineEnvironment.transform 5 3 env53581 = env53582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 3 env53581 == env53582) = true)

def env53583 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272392,2101329,98645,8193,64,2259212,2098513,17664,2543697,2102549,2411541,256,21792,46092,2175562]

theorem envBound53583 : H12AffineFastState.Bounded env53583 := by
  intro p hp
  have h : env53583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53553_53583 : H12AffineEnvironment.transform 6 9 env53553 = env53583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53553 == env53583) = true)

theorem identity53583 : scanCanonicalize (H12AffineFastState.compose env53583 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound53583 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env53584 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77899,272392,73754,98645,8193,64,215367,79130,17664,516122,75102,392286,256,21792,46092,513]

theorem envBound53584 : H12AffineFastState.Bounded env53584 := by
  intro p hp
  have h : env53584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53583_53584 : H12AffineEnvironment.transform 20 77899 env53583 = env53584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env53583 == env53584) = true)

def env53585 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77899,32,73754,98645,8193,64,215367,79130,17664,247858,75102,119926,256,21792,46092,513]

theorem envBound53585 : H12AffineFastState.Bounded env53585 := by
  intro p hp
  have h : env53585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53584_53585 : H12AffineEnvironment.transform 17 10280 env53584 = env53585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env53584 == env53585) = true)

def env53586 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77851,32,73754,98565,8193,16,215319,79130,17664,247858,75022,119846,256,21792,46092,513]

theorem envBound53586 : H12AffineFastState.Bounded env53586 := by
  intro p hp
  have h : env53586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53585_53586 : H12AffineEnvironment.transform 5 16 env53585 = env53586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53585 == env53586) = true)

theorem identity53586 : scanCanonicalize (H12AffineFastState.compose env53586 (packedSelected [2,4,6,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound53586 : packedSelected [2,4,6,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env53587 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,0,65536,131072,10280,1024,1,77851,32,73754,65797,8193,16,215319,79130,17664,215090,75022,87078,256,21792,13324,513]

theorem envBound53587 : H12AffineFastState.Bounded env53587 := by
  intro p hp
  have h : env53587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53586_53587 : H12AffineEnvironment.transform 14 0 env53586 = env53587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env53586 == env53587) = true)

theorem identity53587 : scanCanonicalize (H12AffineFastState.compose env53587 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound53587 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env53588 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,0,65536,5393,10280,1024,1,77851,32,73754,65797,8193,16,89094,79130,17664,89379,75022,87078,256,21792,13324,513]

theorem envBound53588 : H12AffineFastState.Bounded env53588 := by
  intro p hp
  have h : env53588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53587_53588 : H12AffineEnvironment.transform 16 5393 env53587 = env53588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env53587 == env53588) = true)

theorem identity53588 : scanCanonicalize (H12AffineFastState.compose env53588 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound53588 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53589 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,0,262,5393,10280,1024,1,12573,32,8476,3,8193,16,23808,13340,17664,23589,9224,21792,256,21792,13324,513]

theorem envBound53589 : H12AffineFastState.Bounded env53589 := by
  intro p hp
  have h : env53589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53588_53589 : H12AffineEnvironment.transform 15 262 env53588 = env53589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env53588 == env53589) = true)

theorem identity53589 : scanCanonicalize (H12AffineFastState.compose env53589 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound53589 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53590 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,0,262,5393,10280,1024,1,12573,32,8476,3,8193,16,10508,13340,12556,10281,9224,8492,256,8492,13324,513]

theorem envBound53590 : H12AffineFastState.Bounded env53590 := by
  intro p hp
  have h : env53590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53589_53590 : H12AffineEnvironment.transform 13 13324 env53589 = env53590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env53589 == env53590) = true)

theorem identity53590 : scanCanonicalize (H12AffineFastState.compose env53590 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound53590 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env53591 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,0,262,5393,2340,1024,1,4113,32,16,3,269,16,2048,5392,4096,2341,1284,32,256,32,5376,513]

theorem envBound53591 : H12AffineFastState.Bounded env53591 := by
  intro p hp
  have h : env53591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53590_53591 : H12AffineEnvironment.transform 12 268 env53590 = env53591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env53590 == env53591) = true)

theorem identity53591 : scanCanonicalize (H12AffineFastState.compose env53591 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound53591 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53592 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,32,268,1312,0,262,1329,2340,1024,1,49,32,16,3,269,16,2048,1328,32,2341,1284,32,256,32,1312,513]

theorem envBound53592 : H12AffineFastState.Bounded env53592 := by
  intro p hp
  have h : env53592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53591_53592 : H12AffineEnvironment.transform 11 32 env53591 = env53592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env53591 == env53592) = true)

theorem identity53592 : scanCanonicalize (H12AffineFastState.compose env53592 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1323) := by decide +kernel

theorem selectedBound53592 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53593 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1323,32,268,1312,0,262,1329,1039,1024,1,49,32,16,3,269,16,1323,1328,32,1038,1284,32,256,32,1312,513]

theorem envBound53593 : H12AffineFastState.Bounded env53593 := by
  intro p hp
  have h : env53593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53592_53593 : H12AffineEnvironment.transform 10 1323 env53592 = env53593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1323 env53592 == env53593) = true)

theorem identity53593 : scanCanonicalize (H12AffineFastState.compose env53593 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound53593 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53594 : List Nat := [2,4,8,16,32,16,9,256,271,1024,1323,32,268,1312,0,262,1329,1039,1024,1,49,32,16,3,269,16,1323,1328,32,1038,1284,32,256,32,1312,270]

theorem envBound53594 : H12AffineFastState.Bounded env53594 := by
  intro p hp
  have h : env53594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53593_53594 : H12AffineEnvironment.transform 8 271 env53593 = env53594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env53593 == env53594) = true)

theorem identity53594 : scanCanonicalize (H12AffineFastState.compose env53594 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound53594 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env53595 : List Nat := [2,4,8,16,32,16,9,30,17,1024,1077,32,18,1086,0,24,1071,1039,1024,1,49,32,16,3,19,16,1077,1070,32,1038,1050,32,30,32,1086,16]

theorem envBound53595 : H12AffineFastState.Bounded env53595 := by
  intro p hp
  have h : env53595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53594_53595 : H12AffineEnvironment.transform 7 30 env53594 = env53595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env53594 == env53595) = true)

theorem identity53595 : scanCanonicalize (H12AffineFastState.compose env53595 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound53595 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env53596 : List Nat := [2,4,8,16,32,16,9,30,17,46,27,32,18,16,0,24,1,33,46,1,49,32,16,3,19,16,27,0,32,32,52,32,30,32,16,16]

theorem envBound53596 : H12AffineFastState.Bounded env53596 := by
  intro p hp
  have h : env53596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53595_53596 : H12AffineEnvironment.transform 9 46 env53595 = env53596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env53595 == env53596) = true)

theorem identity53596 : scanCanonicalize (H12AffineFastState.compose env53596 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound53596 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env53597 : List Nat := [2,4,8,0,32,0,9,14,1,46,11,32,2,0,0,8,1,33,46,1,33,32,0,3,3,0,11,0,32,32,36,32,14,32,0,0]

theorem envBound53597 : H12AffineFastState.Bounded env53597 := by
  intro p hp
  have h : env53597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53596_53597 : H12AffineEnvironment.transform 3 0 env53596 = env53597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53596 == env53597) = true)

theorem identity53597 : scanCanonicalize (H12AffineFastState.compose env53597 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound53597 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53598 : List Nat := [2,4,8,0,14,0,9,14,1,0,11,14,2,0,0,8,1,15,0,1,15,14,0,3,3,0,11,0,14,14,10,14,14,14,0,0]

theorem envBound53598 : H12AffineFastState.Bounded env53598 := by
  intro p hp
  have h : env53598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53597_53598 : H12AffineEnvironment.transform 4 14 env53597 = env53598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env53597 == env53598) = true)

theorem identity53598 : scanCanonicalize (H12AffineFastState.compose env53598 (packedSelected [9] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound53598 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env53599 : List Nat := [2,4,2,0,4,0,3,4,1,0,1,4,2,0,0,2,1,5,0,1,5,4,0,3,3,0,1,0,4,4,0,4,4,4,0,0]

theorem envBound53599 : H12AffineFastState.Bounded env53599 := by
  intro p hp
  have h : env53599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53598_53599 : H12AffineEnvironment.transform 2 2 env53598 = env53599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env53598 == env53599) = true)

theorem identity53599 : scanCanonicalize (H12AffineFastState.compose env53599 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound53599 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53600 : List Nat := [2,2,2,0,2,0,3,2,1,0,1,2,2,0,0,2,1,3,0,1,3,2,0,3,3,0,1,0,2,2,0,2,2,2,0,0]

theorem envBound53600 : H12AffineFastState.Bounded env53600 := by
  intro p hp
  have h : env53600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53599_53600 : H12AffineEnvironment.transform 1 2 env53599 = env53600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env53599 == env53600) = true)

def env53601 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77850,32,73754,98564,8193,17,215318,79130,17664,247858,75023,119847,256,21792,46092,513]

theorem envBound53601 : H12AffineFastState.Bounded env53601 := by
  intro p hp
  have h : env53601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53585_53601 : H12AffineEnvironment.transform 5 17 env53585 = env53601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53585 == env53601) = true)

theorem identity53601 : scanCanonicalize (H12AffineFastState.compose env53601 (packedSelected [2,4,6,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound53601 : packedSelected [2,4,6,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env53602 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,263,131072,10280,1024,32769,12573,32,8477,32771,8193,17,149521,13341,17664,182581,9224,54560,256,21792,46092,513]

theorem envBound53602 : H12AffineFastState.Bounded env53602 := by
  intro p hp
  have h : env53602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53601_53602 : H12AffineEnvironment.transform 15 263 env53601 = env53602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env53601 == env53602) = true)

theorem identity53602 : scanCanonicalize (H12AffineFastState.compose env53602 (packedSelected [0,4,7,9,11,12,15,16] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound53602 : packedSelected [0,4,7,9,11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env53603 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,263,5392,10280,1024,32769,12573,32,8477,32771,8193,17,23809,13341,17664,56357,9224,54560,256,21792,46092,513]

theorem envBound53603 : H12AffineFastState.Bounded env53603 := by
  intro p hp
  have h : env53603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53602_53603 : H12AffineEnvironment.transform 16 5392 env53602 = env53603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env53602 == env53603) = true)

theorem identity53603 : scanCanonicalize (H12AffineFastState.compose env53603 (packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound53603 : packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env53604 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,32768,263,5392,10280,1024,32769,12573,32,8477,32771,8193,17,2049,13341,4096,35109,9224,32800,256,32,46092,513]

theorem envBound53604 : H12AffineFastState.Bounded env53604 := by
  intro p hp
  have h : env53604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53603_53604 : H12AffineEnvironment.transform 13 5376 env53603 = env53604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env53603 == env53604) = true)

theorem identity53604 : scanCanonicalize (H12AffineFastState.compose env53604 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound53604 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env53605 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,1,263,5392,10280,1024,0,12573,32,8477,2,8193,17,2049,13341,4096,2340,9224,33,256,32,13325,513]

theorem envBound53605 : H12AffineFastState.Bounded env53605 := by
  intro p hp
  have h : env53605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53604_53605 : H12AffineEnvironment.transform 14 1 env53604 = env53605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env53604 == env53605) = true)

theorem identity53605 : scanCanonicalize (H12AffineFastState.compose env53605 (packedSelected [1,2,8] rootPS)) = affineNative (2^(12+1) ^^^ 1288) := by decide +kernel

theorem selectedBound53605 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env53606 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,1288,5376,1,263,5392,3360,1024,0,5141,32,1045,2,1289,17,2049,4373,4096,2340,256,33,256,32,4357,513]

theorem envBound53606 : H12AffineFastState.Bounded env53606 := by
  intro p hp
  have h : env53606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53605_53606 : H12AffineEnvironment.transform 12 1288 env53605 = env53606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env53605 == env53606) = true)

theorem identity53606 : scanCanonicalize (H12AffineFastState.compose env53606 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound53606 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env53607 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,57,4145,1,263,4129,2065,305,0,4388,32,292,2,56,17,2049,4373,4096,2340,256,33,256,32,4357,513]

theorem envBound53607 : H12AffineFastState.Bounded env53607 := by
  intro p hp
  have h : env53607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53606_53607 : H12AffineEnvironment.transform 9 305 env53606 = env53607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env53606 == env53607) = true)

theorem identity53607 : scanCanonicalize (H12AffineFastState.compose env53607 (packedSelected [2,3,5,12] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound53607 : packedSelected [2,3,5,12] rootPS < 2^1333 := by decide +kernel

def env53608 : List Nat := [2,4,8,16,32,17,9,52,512,5,2048,4096,57,4145,1,51,4129,2065,5,0,4112,32,16,2,56,17,2049,4129,4096,2064,52,33,52,32,4145,513]

theorem envBound53608 : H12AffineFastState.Bounded env53608 := by
  intro p hp
  have h : env53608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53607_53608 : H12AffineEnvironment.transform 7 52 env53607 = env53608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env53607 == env53608) = true)

theorem identity53608 : scanCanonicalize (H12AffineFastState.compose env53608 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound53608 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53609 : List Nat := [2,4,8,0,32,1,9,36,512,5,2048,4096,41,4129,1,35,4129,2049,5,0,4096,32,0,2,40,1,2049,4129,4096,2048,36,33,36,32,4129,513]

theorem envBound53609 : H12AffineFastState.Bounded env53609 := by
  intro p hp
  have h : env53609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53608_53609 : H12AffineEnvironment.transform 3 0 env53608 = env53609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53608 == env53609) = true)

theorem identity53609 : scanCanonicalize (H12AffineFastState.compose env53609 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound53609 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53610 : List Nat := [2,4,8,0,0,1,9,4,512,5,2048,4096,9,4097,1,3,4097,2049,5,0,4096,0,0,2,8,1,2049,4097,4096,2048,4,1,4,0,4097,513]

theorem envBound53610 : H12AffineFastState.Bounded env53610 := by
  intro p hp
  have h : env53610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53609_53610 : H12AffineEnvironment.transform 4 0 env53609 = env53610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53609 == env53610) = true)

theorem identity53610 : scanCanonicalize (H12AffineFastState.compose env53610 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2561) := by decide +kernel

theorem selectedBound53610 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53611 : List Nat := [2,4,8,0,0,1,9,4,512,5,2048,2561,9,2560,1,3,2560,2049,5,0,2561,0,0,2,8,1,2049,2560,2561,2048,4,1,4,0,2560,513]

theorem envBound53611 : H12AffineFastState.Bounded env53611 := by
  intro p hp
  have h : env53611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53610_53611 : H12AffineEnvironment.transform 11 2561 env53610 = env53611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2561 env53610 == env53611) = true)

theorem identity53611 : scanCanonicalize (H12AffineFastState.compose env53611 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound53611 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53612 : List Nat := [2,4,8,0,0,1,9,4,10,5,2048,2059,9,2058,1,3,2058,2049,5,0,2059,0,0,2,8,1,2049,2058,2059,2048,4,1,4,0,2058,11]

theorem envBound53612 : H12AffineFastState.Bounded env53612 := by
  intro p hp
  have h : env53612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53611_53612 : H12AffineEnvironment.transform 8 10 env53611 = env53612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env53611 == env53612) = true)

theorem identity53612 : scanCanonicalize (H12AffineFastState.compose env53612 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound53612 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env53613 : List Nat := [2,4,8,0,0,1,9,4,10,5,10,1,9,0,1,3,0,11,5,0,1,0,0,2,8,1,11,0,1,10,4,1,4,0,0,11]

theorem envBound53613 : H12AffineFastState.Bounded env53613 := by
  intro p hp
  have h : env53613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53612_53613 : H12AffineEnvironment.transform 10 10 env53612 = env53613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env53612 == env53613) = true)

def env53614 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,77899,33,73754,98645,8193,64,215367,79130,17664,247859,75102,119927,256,21792,46092,513]

theorem envBound53614 : H12AffineFastState.Bounded env53614 := by
  intro p hp
  have h : env53614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53584_53614 : H12AffineEnvironment.transform 17 10281 env53584 = env53614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env53584 == env53614) = true)

theorem identity53614 : scanCanonicalize (H12AffineFastState.compose env53614 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound53614 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53615 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,10281,1024,32769,4161,33,16,41311,8193,64,158029,5392,17664,190521,1364,62589,256,21792,46092,513]

theorem envBound53615 : H12AffineFastState.Bounded env53615 := by
  intro p hp
  have h : env53615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53614_53615 : H12AffineEnvironment.transform 15 8202 env53614 = env53615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env53614 == env53615) = true)

theorem identity53615 : scanCanonicalize (H12AffineFastState.compose env53615 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 27740) := by decide +kernel

theorem selectedBound53615 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env53616 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,27740,10281,1024,32769,4161,33,16,41311,8193,64,1297,5392,17664,33893,1364,62589,256,21792,46092,513]

theorem envBound53616 : H12AffineFastState.Bounded env53616 := by
  intro p hp
  have h : env53616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53615_53616 : H12AffineEnvironment.transform 16 27740 env53615 = env53616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 27740 env53615 == env53616) = true)

theorem identity53616 : scanCanonicalize (H12AffineFastState.compose env53616 (packedSelected [1,3,4,5,8,9,10,11,14,18,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound53616 : packedSelected [1,3,4,5,8,9,10,11,14,18,19,20] rootPS < 2^1333 := by decide +kernel

def env53617 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,32768,35,19573,2048,1024,32769,4161,33,16,33142,40,64,1297,5392,17664,33893,1364,54356,256,21792,37925,513]

theorem envBound53617 : H12AffineFastState.Bounded env53617 := by
  intro p hp
  have h : env53617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53616_53617 : H12AffineEnvironment.transform 12 41 env53616 = env53617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env53616 == env53617) = true)

theorem identity53617 : scanCanonicalize (H12AffineFastState.compose env53617 (packedSelected [2,14] rootPS)) = affineNative (2^(14+1) ^^^ 22576) := by decide +kernel

theorem selectedBound53617 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env53618 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,22576,35,19573,2048,1024,22577,4161,33,16,22854,40,64,1297,5392,17664,23637,1364,3172,256,21792,19477,513]

theorem envBound53618 : H12AffineFastState.Bounded env53618 := by
  intro p hp
  have h : env53618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53617_53618 : H12AffineEnvironment.transform 14 22576 env53617 = env53618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 22576 env53617 == env53618) = true)

theorem identity53618 : scanCanonicalize (H12AffineFastState.compose env53618 (packedSelected [11,23] rootPS)) = affineNative (2^(13+1) ^^^ 6208) := by decide +kernel

theorem selectedBound53618 : packedSelected [11,23] rootPS < 2^1333 := by decide +kernel

def env53619 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,6208,112,35,5173,2048,1024,113,4161,33,16,262,40,64,1297,5392,7488,1045,1364,3172,256,3424,5205,513]

theorem envBound53619 : H12AffineFastState.Bounded env53619 := by
  intro p hp
  have h : env53619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53618_53619 : H12AffineEnvironment.transform 13 6208 env53618 = env53619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6208 env53618 == env53619) = true)

theorem identity53619 : scanCanonicalize (H12AffineFastState.compose env53619 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound53619 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env53620 : List Nat := [2,4,8,16,32,64,9,256,512,1024,80,4096,41,4112,112,35,5173,80,1024,113,4161,33,16,262,40,64,1297,5392,5392,1045,1364,1076,256,1328,5205,513]

theorem envBound53620 : H12AffineFastState.Bounded env53620 := by
  intro p hp
  have h : env53620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53619_53620 : H12AffineEnvironment.transform 10 80 env53619 = env53620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env53619 == env53620) = true)

theorem identity53620 : scanCanonicalize (H12AffineFastState.compose env53620 (packedSelected [2,3,4,5,6,9,12,19] rootPS)) = affineNative (2^(11+1) ^^^ 97) := by decide +kernel

theorem selectedBound53620 : packedSelected [2,3,4,5,6,9,12,19] rootPS < 2^1333 := by decide +kernel

def env53621 : List Nat := [2,4,8,16,32,64,9,256,512,1024,80,97,41,113,112,35,1108,80,1024,113,32,33,16,262,40,64,1297,1393,1393,1045,1364,1076,256,1328,1076,513]

theorem envBound53621 : H12AffineFastState.Bounded env53621 := by
  intro p hp
  have h : env53621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53620_53621 : H12AffineEnvironment.transform 11 97 env53620 = env53621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 97 env53620 == env53621) = true)

theorem identity53621 : scanCanonicalize (H12AffineFastState.compose env53621 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound53621 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env53622 : List Nat := [2,4,8,16,32,64,9,256,64,1024,80,97,41,113,112,35,1108,80,1024,113,32,33,16,262,40,64,1297,1393,1393,1045,1364,1076,256,1328,1076,65]

theorem envBound53622 : H12AffineFastState.Bounded env53622 := by
  intro p hp
  have h : env53622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53621_53622 : H12AffineEnvironment.transform 8 64 env53621 = env53622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env53621 == env53622) = true)

theorem identity53622 : scanCanonicalize (H12AffineFastState.compose env53622 (packedSelected [0,1,6,7,8,12] rootPS)) = affineNative (2^(9+1) ^^^ 288) := by decide +kernel

theorem selectedBound53622 : packedSelected [0,1,6,7,8,12] rootPS < 2^1333 := by decide +kernel

def env53623 : List Nat := [2,4,8,16,32,64,9,256,64,288,80,97,41,113,112,35,372,80,288,113,32,33,16,262,40,64,49,81,81,309,116,276,256,16,276,65]

theorem envBound53623 : H12AffineFastState.Bounded env53623 := by
  intro p hp
  have h : env53623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53622_53623 : H12AffineEnvironment.transform 9 288 env53622 = env53623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 288 env53622 == env53623) = true)

theorem identity53623 : scanCanonicalize (H12AffineFastState.compose env53623 (packedSelected [0,2,3,5,6,7,10] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound53623 : packedSelected [0,2,3,5,6,7,10] rootPS < 2^1333 := by decide +kernel

def env53624 : List Nat := [2,4,8,16,32,32,9,256,32,288,48,1,41,17,16,35,276,48,288,17,32,33,16,262,40,32,49,49,49,309,20,276,256,16,276,33]

theorem envBound53624 : H12AffineFastState.Bounded env53624 := by
  intro p hp
  have h : env53624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53623_53624 : H12AffineEnvironment.transform 5 32 env53623 = env53624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env53623 == env53624) = true)

theorem identity53624 : scanCanonicalize (H12AffineFastState.compose env53624 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound53624 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53625 : List Nat := [2,4,8,16,16,16,9,256,16,272,0,1,25,17,16,19,276,0,272,17,16,17,16,262,24,16,1,1,1,261,20,276,256,16,276,17]

theorem envBound53625 : H12AffineFastState.Bounded env53625 := by
  intro p hp
  have h : env53625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53624_53625 : H12AffineEnvironment.transform 4 16 env53624 = env53625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env53624 == env53625) = true)

theorem identity53625 : scanCanonicalize (H12AffineFastState.compose env53625 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound53625 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env53626 : List Nat := [2,4,8,0,0,0,9,256,0,256,0,1,9,1,0,3,260,0,256,1,0,1,0,262,8,0,1,1,1,261,4,260,256,0,260,1]

theorem envBound53626 : H12AffineFastState.Bounded env53626 := by
  intro p hp
  have h : env53626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53625_53626 : H12AffineEnvironment.transform 3 0 env53625 = env53626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53625 == env53626) = true)

def env53627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830977,25265169,23160257,257,27378860,27337992,25207750]

theorem envBound53627 : H12AffineFastState.Bounded env53627 := by
  intro p hp
  have h : env53627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53272_53627 : H12AffineEnvironment.transform 18 1025 env53272 = env53627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env53272 == env53627) = true)

theorem identity53627 : scanCanonicalize (H12AffineFastState.compose env53627 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8642689) := by decide +kernel

theorem selectedBound53627 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env53628 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8642689,8328,64,4464768,10642445,10507601,8830977,156816,14845248,257,2237485,2278793,213831]

theorem envBound53628 : H12AffineFastState.Bounded env53628 := by
  intro p hp
  have h : env53628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53627_53628 : H12AffineEnvironment.transform 23 8642689 env53627 = env53628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8642689 env53627 == env53628) = true)

def env53629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,4194304,8388608,8642689,8328,64,4464768,8393985,8528989,8830977,156816,12645452,257,21793,46213,213831]

theorem envBound53629 : H12AffineFastState.Bounded env53629 := by
  intro p hp
  have h : env53629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53628_53629 : H12AffineEnvironment.transform 20 160012 env53628 = env53629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 160012 env53628 == env53629) = true)

def env53630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,4194304,169352,95497,8328,64,4464768,163977,45525,284041,156816,4350404,257,21793,46213,213831]

theorem envBound53630 : H12AffineFastState.Bounded env53630 := by
  intro p hp
  have h : env53630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53629_53630 : H12AffineEnvironment.transform 22 169352 env53629 = env53630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169352 env53629 == env53630) = true)

def env53631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,272512,169352,95497,8328,64,2048,163977,45525,284041,156816,411972,257,21793,46213,213831]

theorem envBound53631 : H12AffineFastState.Bounded env53631 := by
  intro p hp
  have h : env53631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53630_53631 : H12AffineEnvironment.transform 21 272512 env53630 = env53631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env53630 == env53631) = true)

theorem identity53631 : scanCanonicalize (H12AffineFastState.compose env53631 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound53631 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4160,272512,62660,95497,8328,64,2048,57797,45525,284041,1500,272392,257,21793,46213,74251]

theorem envBound53632 : H12AffineFastState.Bounded env53632 := by
  intro p hp
  have h : env53632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53631_53632 : H12AffineEnvironment.transform 16 24908 env53631 = env53632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env53631 == env53632) = true)

theorem identity53632 : scanCanonicalize (H12AffineFastState.compose env53632 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound53632 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env53633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,24908,262144,1025,32769,4160,272512,62660,21763,8328,64,2048,57797,45525,284041,1500,272392,257,21793,46213,513]

theorem envBound53633 : H12AffineFastState.Bounded env53633 := by
  intro p hp
  have h : env53633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53632_53633 : H12AffineEnvironment.transform 15 8202 env53632 = env53633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env53632 == env53633) = true)

theorem identity53633 : scanCanonicalize (H12AffineFastState.compose env53633 (packedSelected [7,14,16,27] rootPS)) = affineNative (2^(17+1) ^^^ 23668) := by decide +kernel

theorem selectedBound53633 : packedSelected [7,14,16,27] rootPS < 2^1333 := by decide +kernel

def env53634 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,24908,23668,1025,32769,4160,29940,62660,21763,8328,64,2048,57797,45525,2557,1500,29820,257,21793,46213,513]

theorem envBound53634 : H12AffineFastState.Bounded env53634 := by
  intro p hp
  have h : env53634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53633_53634 : H12AffineEnvironment.transform 17 23668 env53633 = env53634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23668 env53633 == env53634) = true)

theorem identity53634 : scanCanonicalize (H12AffineFastState.compose env53634 (packedSelected [3,5,8,11,17,18,23,28,32] rootPS)) = affineNative (2^(14+1) ^^^ 21896) := by decide +kernel

theorem selectedBound53634 : packedSelected [3,5,8,11,17,18,23,28,32] rootPS < 2^1333 := by decide +kernel

def env53635 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21896,8202,24908,23668,1025,21897,4160,29940,8524,21763,8328,64,2048,13389,25693,2557,1500,29820,257,21793,24845,513]

theorem envBound53635 : H12AffineFastState.Bounded env53635 := by
  intro p hp
  have h : env53635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53634_53635 : H12AffineEnvironment.transform 14 21896 env53634 = env53635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21896 env53634 == env53635) = true)

theorem identity53635 : scanCanonicalize (H12AffineFastState.compose env53635 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound53635 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env53636 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,8540,8202,5528,10400,1025,8541,4160,32,8524,8663,8328,64,2048,13389,4233,2557,1500,168,257,8693,5593,513]

theorem envBound53636 : H12AffineFastState.Bounded env53636 := by
  intro p hp
  have h : env53636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53635_53636 : H12AffineEnvironment.transform 13 13524 env53635 = env53636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env53635 == env53636) = true)

theorem identity53636 : scanCanonicalize (H12AffineFastState.compose env53636 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound53636 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env53637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5512,0,342,5528,2556,1025,1,4160,32,16,139,468,64,2048,5393,4233,2557,1500,168,257,169,5593,513]

theorem envBound53637 : H12AffineFastState.Bounded env53637 := by
  intro p hp
  have h : env53637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53636_53637 : H12AffineEnvironment.transform 12 348 env53636 = env53637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env53636 == env53637) = true)

theorem identity53637 : scanCanonicalize (H12AffineFastState.compose env53637 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound53637 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53638 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,348,5456,0,342,5440,2340,1025,1,4160,32,16,83,268,64,2048,5393,4177,2341,1284,112,257,113,5377,513]

theorem envBound53638 : H12AffineFastState.Bounded env53638 := by
  intro p hp
  have h : env53638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53637_53638 : H12AffineEnvironment.transform 6 88 env53637 = env53638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env53637 == env53638) = true)

theorem identity53638 : scanCanonicalize (H12AffineFastState.compose env53638 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1856) := by decide +kernel

theorem selectedBound53638 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env53639 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,1856,348,528,0,342,512,2340,1025,1,1792,32,16,83,268,64,2048,593,1809,2341,1284,112,257,113,577,513]

theorem envBound53639 : H12AffineFastState.Bounded env53639 := by
  intro p hp
  have h : env53639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53638_53639 : H12AffineEnvironment.transform 11 1856 env53638 = env53639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1856 env53638 == env53639) = true)

theorem identity53639 : scanCanonicalize (H12AffineFastState.compose env53639 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 884) := by decide +kernel

theorem selectedBound53639 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env53640 : List Nat := [2,4,8,16,32,64,88,256,512,1024,884,1856,348,528,0,342,512,592,1025,1,1792,32,16,83,268,64,884,593,1809,593,1284,112,257,113,577,513]

theorem envBound53640 : H12AffineFastState.Bounded env53640 := by
  intro p hp
  have h : env53640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53639_53640 : H12AffineEnvironment.transform 10 884 env53639 = env53640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 884 env53639 == env53640) = true)

theorem identity53640 : scanCanonicalize (H12AffineFastState.compose env53640 (packedSelected [4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound53640 : packedSelected [4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env53641 : List Nat := [2,4,8,16,32,64,88,256,512,257,884,577,348,528,0,342,512,592,256,1,513,32,16,83,268,64,884,593,528,593,5,112,257,113,577,513]

theorem envBound53641 : H12AffineFastState.Bounded env53641 := by
  intro p hp
  have h : env53641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53640_53641 : H12AffineEnvironment.transform 9 257 env53640 = env53641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env53640 == env53641) = true)

theorem identity53641 : scanCanonicalize (H12AffineFastState.compose env53641 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound53641 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env53642 : List Nat := [2,4,8,16,32,64,88,116,512,117,512,577,40,528,0,34,512,592,116,1,513,32,16,83,120,64,512,593,528,593,5,112,117,113,577,513]

theorem envBound53642 : H12AffineFastState.Bounded env53642 := by
  intro p hp
  have h : env53642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53641_53642 : H12AffineEnvironment.transform 7 116 env53641 = env53642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env53641 == env53642) = true)

def env53643 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,272513,169352,95497,8328,64,2049,163977,45525,284041,156816,411973,257,21793,46213,213831]

theorem envBound53643 : H12AffineFastState.Bounded env53643 := by
  intro p hp
  have h : env53643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53630_53643 : H12AffineEnvironment.transform 21 272513 env53630 = env53643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env53630 == env53643) = true)

theorem identity53643 : scanCanonicalize (H12AffineFastState.compose env53643 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound53643 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,160012,272513,155997,95497,8328,64,2049,160860,17664,284041,156816,411973,257,21793,16464,213831]

theorem envBound53644 : H12AffineFastState.Bounded env53644 := by
  intro p hp
  have h : env53644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53643_53644 : H12AffineEnvironment.transform 14 29909 env53643 = env53644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env53643 == env53644) = true)

theorem identity53644 : scanCanonicalize (H12AffineFastState.compose env53644 (packedSelected [12,15,16,17,20,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 149860) := by decide +kernel

theorem selectedBound53644 : packedSelected [12,15,16,17,20,38,41] rootPS < 2^1333 := by decide +kernel

def env53645 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,149860,1025,29908,160012,156133,155997,95497,8328,64,2049,160860,17664,138477,156816,33,257,21793,16464,213831]

theorem envBound53645 : H12AffineFastState.Bounded env53645 := by
  intro p hp
  have h : env53645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53644_53645 : H12AffineEnvironment.transform 17 149860 env53644 = env53645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149860 env53644 == env53645) = true)

def env53646 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,149860,1025,29788,160012,156013,155997,95497,8192,64,2049,160860,17664,138341,156696,33,257,21793,16464,213831]

theorem envBound53646 : H12AffineFastState.Bounded env53646 := by
  intro p hp
  have h : env53646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53645_53646 : H12AffineEnvironment.transform 6 8 env53645 = env53646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53645 == env53646) = true)

theorem identity53646 : scanCanonicalize (H12AffineFastState.compose env53646 (packedSelected [0,1,3,5,7,9,12,14,15,16,18,22,23,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound53646 : packedSelected [0,1,3,5,7,9,12,14,15,16,18,22,23,26,28] rootPS < 2^1333 := by decide +kernel

def env53647 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,21590,131072,149860,1025,29788,160012,156013,155997,8543,8192,64,2049,160860,17664,138341,156696,33,257,21793,16464,136977]

theorem envBound53647 : H12AffineFastState.Bounded env53647 := by
  intro p hp
  have h : env53647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53646_53647 : H12AffineEnvironment.transform 15 21590 env53646 = env53647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env53646 == env53647) = true)

theorem identity53647 : scanCanonicalize (H12AffineFastState.compose env53647 (packedSelected [0,3,9,18,22,23,24,26,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 16448) := by decide +kernel

theorem selectedBound53647 : packedSelected [0,3,9,18,22,23,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env53648 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,21590,16448,2340,1025,29788,12620,8493,8477,8543,8192,64,2049,13340,17664,23589,9304,33,257,21793,16464,22353]

theorem envBound53648 : H12AffineFastState.Bounded env53648 := by
  intro p hp
  have h : env53648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53647_53648 : H12AffineEnvironment.transform 16 16448 env53647 = env53648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env53647 == env53648) = true)

theorem identity53648 : scanCanonicalize (H12AffineFastState.compose env53648 (packedSelected [0,1,4,5,7,8,18,22,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound53648 : packedSelected [0,1,4,5,7,8,18,22,23,24] rootPS < 2^1333 := by decide +kernel

def env53649 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,21840,21590,16448,2340,1025,21841,4161,32,16,82,269,64,2049,5393,17664,23589,1365,33,257,21793,16464,22353]

theorem envBound53649 : H12AffineFastState.Bounded env53649 := by
  intro p hp
  have h : env53649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53648_53649 : H12AffineEnvironment.transform 12 269 env53648 = env53649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env53648 == env53649) = true)

theorem identity53649 : scanCanonicalize (H12AffineFastState.compose env53649 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound53649 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env53650 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,269,16384,20544,20806,16448,2340,273,20545,4161,32,16,82,269,64,2049,4097,16400,22837,69,33,257,20529,16464,21057]

theorem envBound53650 : H12AffineFastState.Bounded env53650 := by
  intro p hp
  have h : env53650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53649_53650 : H12AffineEnvironment.transform 9 272 env53649 = env53650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env53649 == env53650) = true)

theorem identity53650 : scanCanonicalize (H12AffineFastState.compose env53650 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53650 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env53651 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,4096,269,16384,20497,20759,16401,2340,273,20496,4112,32,16,3,269,17,2049,4097,16400,22837,20,33,257,20529,16385,21008]

theorem envBound53651 : H12AffineFastState.Bounded env53651 := by
  intro p hp
  have h : env53651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53650_53651 : H12AffineEnvironment.transform 5 17 env53650 = env53651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53650 == env53651) = true)

theorem identity53651 : scanCanonicalize (H12AffineFastState.compose env53651 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound53651 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env53652 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,309,269,16384,16676,16418,16401,2340,273,16677,293,32,16,3,269,17,2049,308,16400,18432,20,33,257,16644,16385,17189]

theorem envBound53652 : H12AffineFastState.Bounded env53652 := by
  intro p hp
  have h : env53652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53651_53652 : H12AffineEnvironment.transform 11 309 env53651 = env53652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env53651 == env53652) = true)

theorem identity53652 : scanCanonicalize (H12AffineFastState.compose env53652 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(13+1) ^^^ 293) := by decide +kernel

theorem selectedBound53652 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env53653 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,309,269,293,1,263,308,2340,273,0,293,32,16,3,269,17,2049,308,309,2341,20,33,257,33,292,512]

theorem envBound53653 : H12AffineFastState.Bounded env53653 := by
  intro p hp
  have h : env53653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53652_53653 : H12AffineEnvironment.transform 13 293 env53652 = env53653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 293 env53652 == env53653) = true)

theorem identity53653 : scanCanonicalize (H12AffineFastState.compose env53653 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound53653 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53654 : List Nat := [2,4,8,0,32,1,8,256,512,256,2048,293,269,293,1,263,292,2340,257,0,293,32,0,3,269,1,2049,292,293,2341,4,33,257,33,292,512]

theorem envBound53654 : H12AffineFastState.Bounded env53654 := by
  intro p hp
  have h : env53654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53653_53654 : H12AffineEnvironment.transform 3 0 env53653 = env53654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53653 == env53654) = true)

theorem identity53654 : scanCanonicalize (H12AffineFastState.compose env53654 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 769) := by decide +kernel

theorem selectedBound53654 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53655 : List Nat := [2,4,8,0,32,1,8,256,512,256,769,293,269,293,1,263,292,549,257,0,293,32,0,3,269,1,768,292,293,548,4,33,257,33,292,512]

theorem envBound53655 : H12AffineFastState.Bounded env53655 := by
  intro p hp
  have h : env53655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53654_53655 : H12AffineEnvironment.transform 10 769 env53654 = env53655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 769 env53654 == env53655) = true)

theorem identity53655 : scanCanonicalize (H12AffineFastState.compose env53655 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound53655 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53656 : List Nat := [2,4,8,0,32,1,8,256,261,256,4,293,269,293,1,263,292,288,257,0,293,32,0,3,269,1,5,292,293,289,4,33,257,33,292,261]

theorem envBound53656 : H12AffineFastState.Bounded env53656 := by
  intro p hp
  have h : env53656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53655_53656 : H12AffineEnvironment.transform 8 261 env53655 = env53656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env53655 == env53656) = true)

theorem identity53656 : scanCanonicalize (H12AffineFastState.compose env53656 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound53656 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env53657 : List Nat := [2,4,8,0,32,1,8,37,32,37,4,0,40,0,1,34,1,5,36,0,0,32,0,3,40,1,5,1,0,4,4,33,36,33,1,32]

theorem envBound53657 : H12AffineFastState.Bounded env53657 := by
  intro p hp
  have h : env53657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53656_53657 : H12AffineEnvironment.transform 7 37 env53656 = env53657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env53656 == env53657) = true)

theorem identity53657 : scanCanonicalize (H12AffineFastState.compose env53657 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound53657 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53658 : List Nat := [2,4,8,0,4,1,8,1,4,1,4,0,12,0,1,6,1,5,0,0,0,4,0,3,12,1,5,1,0,4,4,5,0,5,1,4]

theorem envBound53658 : H12AffineFastState.Bounded env53658 := by
  intro p hp
  have h : env53658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53657_53658 : H12AffineEnvironment.transform 4 4 env53657 = env53658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env53657 == env53658) = true)

theorem identity53658 : scanCanonicalize (H12AffineFastState.compose env53658 (packedSelected [6] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound53658 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53659 : List Nat := [2,1,8,0,1,1,8,1,1,1,1,0,9,0,1,3,1,0,0,0,0,1,0,3,9,1,0,1,0,1,1,0,0,0,1,1]

theorem envBound53659 : H12AffineFastState.Bounded env53659 := by
  intro p hp
  have h : env53659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53658_53659 : H12AffineEnvironment.transform 1 1 env53658 = env53659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env53658 == env53659) = true)

def env53660 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,149860,1025,29789,160012,156012,155997,95497,8193,64,2049,160860,17664,138340,156697,33,257,21793,16464,213831]

theorem envBound53660 : H12AffineFastState.Bounded env53660 := by
  intro p hp
  have h : env53660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53645_53660 : H12AffineEnvironment.transform 6 9 env53645 = env53660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53645 == env53660) = true)

theorem identity53660 : scanCanonicalize (H12AffineFastState.compose env53660 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound53660 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53661 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,13388,32040,1025,29789,17728,21792,21777,95497,8193,64,2049,16400,17664,10280,20565,33,257,21793,16464,96011]

theorem envBound53661 : H12AffineFastState.Bounded env53661 := by
  intro p hp
  have h : env53661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53660_53661 : H12AffineEnvironment.transform 16 13388 env53660 = env53661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env53660 == env53661) = true)

theorem identity53661 : scanCanonicalize (H12AffineFastState.compose env53661 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound53661 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env53662 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5157,8313,65536,13388,10509,1025,8312,4453,261,308,74028,8193,64,2049,5173,4389,10280,1136,33,257,260,5237,74542]

theorem envBound53662 : H12AffineFastState.Bounded env53662 := by
  intro p hp
  have h : env53662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53661_53662 : H12AffineEnvironment.transform 13 5157 env53661 = env53662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env53661 == env53662) = true)

theorem identity53662 : scanCanonicalize (H12AffineFastState.compose env53662 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 8495) := by decide +kernel

theorem selectedBound53662 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env53663 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5157,8313,8495,13388,10509,1025,8312,4453,261,308,3,8193,64,2049,5173,4389,10280,1136,33,257,260,5237,513]

theorem envBound53663 : H12AffineFastState.Bounded env53663 := by
  intro p hp
  have h : env53663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53662_53663 : H12AffineEnvironment.transform 15 8495 env53662 = env53663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8495 env53662 == env53663) = true)

theorem identity53663 : scanCanonicalize (H12AffineFastState.compose env53663 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound53663 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env53664 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,4405,8313,8495,12636,10509,273,8312,4453,261,308,3,8193,64,2049,4389,4389,10280,352,33,257,260,4453,513]

theorem envBound53664 : H12AffineFastState.Bounded env53664 := by
  intro p hp
  have h : env53664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53663_53664 : H12AffineEnvironment.transform 9 272 env53663 = env53664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env53663 == env53664) = true)

theorem identity53664 : scanCanonicalize (H12AffineFastState.compose env53664 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound53664 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53665 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,348,4405,293,115,4096,2129,273,292,4453,261,308,3,349,64,2049,4389,4389,2420,352,33,257,260,4453,513]

theorem envBound53665 : H12AffineFastState.Bounded env53665 := by
  intro p hp
  have h : env53665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53664_53665 : H12AffineEnvironment.transform 12 348 env53664 = env53665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env53664 == env53665) = true)

theorem identity53665 : scanCanonicalize (H12AffineFastState.compose env53665 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound53665 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53666 : List Nat := [2,4,8,16,32,64,9,36,512,52,2048,4096,120,4113,1,115,4096,2129,53,0,4161,33,16,3,121,64,2049,4097,4097,2128,68,33,37,32,4161,513]

theorem envBound53666 : H12AffineFastState.Bounded env53666 := by
  intro p hp
  have h : env53666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53665_53666 : H12AffineEnvironment.transform 7 36 env53665 = env53666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env53665 == env53666) = true)

theorem identity53666 : scanCanonicalize (H12AffineFastState.compose env53666 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53666 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53667 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,4096,40,4113,1,35,4096,2049,53,0,4113,33,16,3,41,16,2049,4097,4097,2048,20,33,37,32,4113,513]

theorem envBound53667 : H12AffineFastState.Bounded env53667 := by
  intro p hp
  have h : env53667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53666_53667 : H12AffineEnvironment.transform 5 16 env53666 = env53667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53666 == env53667) = true)

theorem identity53667 : scanCanonicalize (H12AffineFastState.compose env53667 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound53667 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53668 : List Nat := [2,4,8,16,32,16,9,36,512,52,528,4096,40,4113,1,35,4096,529,53,0,4113,33,16,3,41,16,529,4097,4097,528,20,33,37,32,4113,513]

theorem envBound53668 : H12AffineFastState.Bounded env53668 := by
  intro p hp
  have h : env53668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53667_53668 : H12AffineEnvironment.transform 10 528 env53667 = env53668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env53667 == env53668) = true)

theorem identity53668 : scanCanonicalize (H12AffineFastState.compose env53668 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 571) := by decide +kernel

theorem selectedBound53668 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53669 : List Nat := [2,4,8,16,32,16,9,36,512,52,528,571,40,554,1,35,571,529,53,0,554,33,16,3,41,16,529,570,570,528,20,33,37,32,554,513]

theorem envBound53669 : H12AffineFastState.Bounded env53669 := by
  intro p hp
  have h : env53669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53668_53669 : H12AffineEnvironment.transform 11 571 env53668 = env53669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 571 env53668 == env53669) = true)

end H12CloudChart0