import H12CloudChart0Data116

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound29671 : H12AffineFastState.Bounded env29671 := by
  intro p hp
  have h : env29671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29670_29671 : H12AffineEnvironment.transform 4 26 env29670 = env29671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env29670 == env29671) = true)

theorem identity29671 : scanCanonicalize (H12AffineFastState.compose env29671 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound29671 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env29672 : List Nat := [2,4,8,16,26,17,9,31,0,14,0,17,18,1,1,24,17,1,15,0,0,26,16,3,19,17,1,17,17,0,21,27,30,27,1,1]

theorem envBound29672 : H12AffineFastState.Bounded env29672 := by
  intro p hp
  have h : env29672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29671_29672 : H12AffineEnvironment.transform 8 0 env29671 = env29672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env29671 == env29672) = true)

def env29673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2144660,2098513,17665,2363592,2102684,2411676,257,21792,46212,2175563]

theorem envBound29673 : H12AffineFastState.Bounded env29673 := by
  intro p hp
  have h : env29673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29647_29673 : H12AffineEnvironment.transform 21 272513 env29647 = env29673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env29647 == env29673) = true)

theorem identity29673 : scanCanonicalize (H12AffineFastState.compose env29673 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound29673 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,4161,272513,17,98781,8328,64,43477,5392,17665,262281,1501,318685,257,21792,46212,74250]

theorem envBound29674 : H12AffineFastState.Bounded env29674 := by
  intro p hp
  have h : env29674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29673_29674 : H12AffineEnvironment.transform 20 4161 env29673 = env29674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env29673 == env29674) = true)

theorem identity29674 : scanCanonicalize (H12AffineFastState.compose env29674 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound29674 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env29675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49304,262144,1025,32769,4161,272513,17,41430,8328,64,43477,5392,17665,262281,1501,318685,257,21792,46212,513]

theorem envBound29675 : H12AffineFastState.Bounded env29675 := by
  intro p hp
  have h : env29675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29674_29675 : H12AffineEnvironment.transform 15 8203 env29674 = env29675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env29674 == env29675) = true)

theorem identity29675 : scanCanonicalize (H12AffineFastState.compose env29675 (packedSelected [3,4,9,10,14,17,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound29675 : packedSelected [3,4,9,10,14,17,20,24,26] rootPS < 2^1333 := by decide +kernel

def env29676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8203,25028,262144,1025,8541,4161,272513,17,138,8328,64,2185,5392,17665,262281,1501,294273,257,21792,5592,513]

theorem envBound29676 : H12AffineFastState.Bounded env29676 := by
  intro p hp
  have h : env29676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29675_29676 : H12AffineEnvironment.transform 14 8540 env29675 = env29676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env29675 == env29676) = true)

theorem identity29676 : scanCanonicalize (H12AffineFastState.compose env29676 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound29676 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8203,25028,10280,1025,8541,4161,169,17,138,8328,64,2185,5392,17665,10401,1501,21929,257,21792,5592,513]

theorem envBound29677 : H12AffineFastState.Bounded env29677 := by
  intro p hp
  have h : env29677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29676_29677 : H12AffineEnvironment.transform 17 10280 env29676 = env29677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env29676 == env29677) = true)

theorem identity29677 : scanCanonicalize (H12AffineFastState.compose env29677 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound29677 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env29678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,8203,13389,10280,1025,8541,4161,169,17,138,8328,64,2185,5392,4232,10401,1501,32,257,169,5592,513]

theorem envBound29678 : H12AffineFastState.Bounded env29678 := by
  intro p hp
  have h : env29678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29677_29678 : H12AffineEnvironment.transform 13 5513 env29677 = env29678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env29677 == env29678) = true)

theorem identity29678 : scanCanonicalize (H12AffineFastState.compose env29678 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound29678 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env29679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,161,5513,509,170,5356,2185,1025,508,4161,169,17,138,41,64,2185,5392,4232,2048,1501,32,257,169,5592,513]

theorem envBound29679 : H12AffineFastState.Bounded env29679 := by
  intro p hp
  have h : env29679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29678_29679 : H12AffineEnvironment.transform 12 161 env29678 = env29679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env29678 == env29679) = true)

theorem identity29679 : scanCanonicalize (H12AffineFastState.compose env29679 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound29679 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env29680 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,161,5372,136,170,5356,2185,1025,137,4161,169,17,138,41,64,2185,5221,4232,2048,1192,32,116,169,5293,513]

theorem envBound29680 : H12AffineFastState.Bounded env29680 := by
  intro p hp
  have h : env29680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29679_29680 : H12AffineEnvironment.transform 7 117 env29679 = env29680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env29679 == env29680) = true)

theorem identity29680 : scanCanonicalize (H12AffineFastState.compose env29680 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1260) := by decide +kernel

theorem selectedBound29680 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env29681 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,1260,161,16,136,170,0,2185,1025,137,1197,169,17,138,41,64,2185,137,1124,2048,1192,32,116,169,65,513]

theorem envBound29681 : H12AffineFastState.Bounded env29681 := by
  intro p hp
  have h : env29681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29680_29681 : H12AffineEnvironment.transform 11 1260 env29680 = env29681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1260 env29680 == env29681) = true)

theorem identity29681 : scanCanonicalize (H12AffineFastState.compose env29681 (packedSelected [2,5,8,14] rootPS)) = affineNative (2^(9+1) ^^^ 111) := by decide +kernel

theorem selectedBound29681 : packedSelected [2,5,8,14] rootPS < 2^1333 := by decide +kernel

def env29682 : List Nat := [2,4,8,16,32,64,128,117,512,111,2048,131,161,16,136,170,0,2185,110,137,194,169,17,138,41,64,2185,137,11,2048,199,32,116,169,65,513]

theorem envBound29682 : H12AffineFastState.Bounded env29682 := by
  intro p hp
  have h : env29682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29681_29682 : H12AffineEnvironment.transform 9 111 env29681 = env29682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 111 env29681 == env29682) = true)

def env29683 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6590740,2098512,17664,2363592,2102684,6349852,257,21792,46212,2175563]

theorem envBound29683 : H12AffineFastState.Bounded env29683 := by
  intro p hp
  have h : env29683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29646_29683 : H12AffineEnvironment.transform 16 49305 env29646 = env29683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env29646 == env29683) = true)

def env29684 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2144660,2098512,17664,2363592,2102684,2411676,257,21792,46212,2175563]

theorem envBound29684 : H12AffineFastState.Bounded env29684 := by
  intro p hp
  have h : env29684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29683_29684 : H12AffineEnvironment.transform 21 272512 env29683 = env29684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env29683 == env29684) = true)

theorem identity29684 : scanCanonicalize (H12AffineFastState.compose env29684 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound29684 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,13389,262144,1025,29909,2097152,272512,2101329,95496,8328,64,2116928,2098512,17664,2363592,2102684,2373704,257,21792,16464,2175563]

theorem envBound29685 : H12AffineFastState.Bounded env29685 := by
  intro p hp
  have h : env29685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29684_29685 : H12AffineEnvironment.transform 14 29908 env29684 = env29685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env29684 == env29685) = true)

def env29686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,16384,21540,65536,5309,262144,1025,21541,2097152,264304,2101329,87544,120,64,2116928,2098512,17664,2363592,2102684,2365624,257,21792,16464,2167483]

theorem envBound29686 : H12AffineFastState.Bounded env29686 := by
  intro p hp
  have h : env29686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29685_29686 : H12AffineEnvironment.transform 12 240 env29685 = env29686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env29685 == env29686) = true)

theorem identity29686 : scanCanonicalize (H12AffineFastState.compose env29686 (packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 2557) := by decide +kernel

theorem selectedBound29686 : packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS < 2^1333 := by decide +kernel

def env29687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,16384,21540,65536,5309,2557,1025,21541,2097152,397,2101329,87544,120,64,2116928,2098512,17664,2103605,2102684,2101573,257,21792,16464,2167483]

theorem envBound29687 : H12AffineFastState.Bounded env29687 := by
  intro p hp
  have h : env29687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29686_29687 : H12AffineEnvironment.transform 17 2557 env29686 = env29687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2557 env29686 == env29687) = true)

theorem identity29687 : scanCanonicalize (H12AffineFastState.compose env29687 (packedSelected [3,4,7,9,10,14,17,24,26,27,35] rootPS)) = affineNative (2^(20+1) ^^^ 4589) := by decide +kernel

theorem selectedBound29687 : packedSelected [3,4,7,9,10,14,17,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env29688 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,16384,21540,65536,5309,2557,1025,21541,4589,397,444,87544,120,64,23725,5309,17664,2264,1137,168,257,21792,16464,66390]

theorem envBound29688 : H12AffineFastState.Bounded env29688 := by
  intro p hp
  have h : env29688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29687_29688 : H12AffineEnvironment.transform 20 4589 env29687 = env29688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4589 env29687 == env29688) = true)

theorem identity29688 : scanCanonicalize (H12AffineFastState.compose env29688 (packedSelected [1,5,8,16,19,20,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 21874) := by decide +kernel

theorem selectedBound29688 : packedSelected [1,5,8,16,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env29689 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,16384,21540,21874,5309,2557,1025,21541,4589,397,444,138,120,64,23725,5309,17664,2264,1137,168,257,21792,16464,22052]

theorem envBound29689 : H12AffineFastState.Bounded env29689 := by
  intro p hp
  have h : env29689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29688_29689 : H12AffineEnvironment.transform 15 21874 env29688 = env29689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21874 env29688 == env29689) = true)

theorem identity29689 : scanCanonicalize (H12AffineFastState.compose env29689 (packedSelected [1,8,12,15,16,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound29689 : packedSelected [1,8,12,15,16,19,20] rootPS < 2^1333 := by decide +kernel

def env29690 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,240,16384,21540,21647,5309,2048,1025,21541,4112,112,65,138,120,64,23725,5309,17661,2264,1137,168,252,21725,16464,22052]

theorem envBound29690 : H12AffineFastState.Bounded env29690 := by
  intro p hp
  have h : env29690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29689_29690 : H12AffineEnvironment.transform 7 253 env29689 = env29690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env29689 == env29690) = true)

theorem identity29690 : scanCanonicalize (H12AffineFastState.compose env29690 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound29690 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env29691 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,240,5157,1,170,5309,2048,1025,0,4112,112,65,138,120,64,2184,5309,4312,2264,1137,168,252,248,5237,513]

theorem envBound29691 : H12AffineFastState.Bounded env29691 := by
  intro p hp
  have h : env29691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29690_29691 : H12AffineEnvironment.transform 13 5157 env29690 = env29691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env29690 == env29691) = true)

theorem identity29691 : scanCanonicalize (H12AffineFastState.compose env29691 (packedSelected [1,8,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound29691 : packedSelected [1,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env29692 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,2112,240,3173,1,170,3325,2048,1025,0,2128,112,65,138,120,64,2184,3325,2200,2264,1137,168,252,248,3125,513]

theorem envBound29692 : H12AffineFastState.Bounded env29692 := by
  intro p hp
  have h : env29692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29691_29692 : H12AffineEnvironment.transform 11 2112 env29691 = env29692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env29691 == env29692) = true)

theorem identity29692 : scanCanonicalize (H12AffineFastState.compose env29692 (packedSelected [1,2,6,8,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29692 : packedSelected [1,2,6,8,10] rootPS < 2^1333 := by decide +kernel

def env29693 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,2064,160,3125,1,170,3245,2048,1025,0,2048,32,17,138,40,16,2184,3245,2200,2184,1057,168,172,168,3125,513]

theorem envBound29693 : H12AffineFastState.Bounded env29693 := by
  intro p hp
  have h : env29693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29692_29693 : H12AffineEnvironment.transform 5 16 env29692 = env29693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29692 == env29693) = true)

def env29694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,16384,21541,65536,5308,262144,1025,21540,2097152,264305,2101329,87545,121,64,2116928,2098512,17664,2363592,2102684,2365625,257,21792,16464,2167482]

theorem envBound29694 : H12AffineFastState.Bounded env29694 := by
  intro p hp
  have h : env29694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29685_29694 : H12AffineEnvironment.transform 12 241 env29685 = env29694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env29685 == env29694) = true)

theorem identity29694 : scanCanonicalize (H12AffineFastState.compose env29694 (packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound29694 : packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS < 2^1333 := by decide +kernel

def env29695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,16384,21541,65536,5308,2420,1025,21540,2097152,261,2101329,87545,121,64,2116928,2098512,17664,2103740,2102684,2101709,257,21792,16464,2167482]

theorem envBound29695 : H12AffineFastState.Bounded env29695 := by
  intro p hp
  have h : env29695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29694_29695 : H12AffineEnvironment.transform 17 2420 env29694 = env29695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env29694 == env29695) = true)

theorem identity29695 : scanCanonicalize (H12AffineFastState.compose env29695 (packedSelected [0,1,2,6,7,8,10,11,12,15,16,17,23,26,31] rootPS)) = affineNative (2^(20+1) ^^^ 82967) := by decide +kernel

theorem selectedBound29695 : packedSelected [0,1,2,6,7,8,10,11,12,15,16,17,23,26,31] rootPS < 2^1333 := by decide +kernel

def env29696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,16384,21541,65536,5308,2420,1025,21540,82967,261,87110,87545,121,64,67927,82247,17664,89515,86411,87514,257,21792,16464,22189]

theorem envBound29696 : H12AffineFastState.Bounded env29696 := by
  intro p hp
  have h : env29696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29695_29696 : H12AffineEnvironment.transform 20 82967 env29695 = env29696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 82967 env29695 == env29696) = true)

theorem identity29696 : scanCanonicalize (H12AffineFastState.compose env29696 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound29696 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env29697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,5376,293,65536,5308,2420,1025,292,69911,261,65862,65785,121,64,67927,70727,4096,67755,66699,65754,257,32,5456,941]

theorem envBound29697 : H12AffineFastState.Bounded env29697 := by
  intro p hp
  have h : env29697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29696_29697 : H12AffineEnvironment.transform 13 5376 env29696 = env29697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env29696 == env29697) = true)

theorem identity29697 : scanCanonicalize (H12AffineFastState.compose env29697 (packedSelected [3,5,10,12,15,16,20] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound29697 : packedSelected [3,5,10,12,15,16,20] rootPS < 2^1333 := by decide +kernel

def env29698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,5376,293,478,5308,2420,1025,292,4297,261,152,295,121,64,2185,5529,4096,2421,1365,260,257,32,5456,941]

theorem envBound29698 : H12AffineFastState.Bounded env29698 := by
  intro p hp
  have h : env29698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29697_29698 : H12AffineEnvironment.transform 15 478 env29697 = env29698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env29697 == env29698) = true)

theorem identity29698 : scanCanonicalize (H12AffineFastState.compose env29698 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound29698 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env29699 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,5376,293,342,5172,2420,1025,292,4161,261,16,295,121,64,2049,5393,4096,2421,1365,260,257,32,5456,805]

theorem envBound29699 : H12AffineFastState.Bounded env29699 := by
  intro p hp
  have h : env29699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29698_29699 : H12AffineEnvironment.transform 6 8 env29698 = env29699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29698 == env29699) = true)

theorem identity29699 : scanCanonicalize (H12AffineFastState.compose env29699 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29699 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env29700 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,41,5376,293,262,5172,2340,1025,292,4113,261,16,295,41,16,2049,5393,4096,2341,1285,260,257,32,5376,805]

theorem envBound29700 : H12AffineFastState.Bounded env29700 := by
  intro p hp
  have h : env29700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29699_29700 : H12AffineEnvironment.transform 5 16 env29699 = env29700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29699 == env29700) = true)

theorem identity29700 : scanCanonicalize (H12AffineFastState.compose env29700 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound29700 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env29701 : List Nat := [2,4,8,16,32,16,8,4,512,1024,2048,4096,41,5124,33,2,5172,2080,1025,32,4113,1,16,35,41,16,2049,5141,4096,2081,1025,0,5,32,5124,545]

theorem envBound29701 : H12AffineFastState.Bounded env29701 := by
  intro p hp
  have h : env29701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29700_29701 : H12AffineEnvironment.transform 7 4 env29700 = env29701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env29700 == env29701) = true)

def env29702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2144661,2098512,17664,2363592,2102684,2411677,257,21792,46212,2175563]

theorem envBound29702 : H12AffineFastState.Bounded env29702 := by
  intro p hp
  have h : env29702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29683_29702 : H12AffineEnvironment.transform 21 272513 env29683 = env29702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env29683 == env29702) = true)

theorem identity29702 : scanCanonicalize (H12AffineFastState.compose env29702 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58516) := by decide +kernel

theorem selectedBound29702 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,58516,272513,62661,98780,8328,64,23809,57796,17664,324700,61704,272393,257,21792,46212,120543]

theorem envBound29703 : H12AffineFastState.Bounded env29703 := by
  intro p hp
  have h : env29703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29702_29703 : H12AffineEnvironment.transform 20 58516 env29702 = env29703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58516 env29702 == env29703) = true)

def env29704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,10280,1025,32769,58516,169,62661,98780,8328,64,23809,57796,17664,56436,61704,33,257,21792,46212,120543]

theorem envBound29704 : H12AffineFastState.Bounded env29704 := by
  intro p hp
  have h : env29704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29703_29704 : H12AffineEnvironment.transform 17 10280 env29703 = env29704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env29703 == env29704) = true)

theorem identity29704 : scanCanonicalize (H12AffineFastState.compose env29704 (packedSelected [0,1,2,3,4,6,9,15,20,23,24,27,28,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound29704 : packedSelected [0,1,2,3,4,6,9,15,20,23,24,27,28,32,38] rootPS < 2^1333 := by decide +kernel

def env29705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,25028,10280,1025,8540,17865,169,21912,73857,8328,64,23809,16537,17664,32041,20565,33,257,21792,5593,96130]

theorem envBound29705 : H12AffineFastState.Bounded env29705 := by
  intro p hp
  have h : env29705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29704_29705 : H12AffineEnvironment.transform 14 8541 env29704 = env29705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env29704 == env29705) = true)

theorem identity29705 : scanCanonicalize (H12AffineFastState.compose env29705 (packedSelected [0,2,3,4,5,6,9,10,11,16,17,18,27] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound29705 : packedSelected [0,2,3,4,5,6,9,10,11,16,17,18,27] rootPS < 2^1333 := by decide +kernel

def env29706 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8203,25028,10280,1025,8540,17865,169,21912,138,8328,64,23809,16537,17664,32041,20565,33,257,21792,5593,22409]

theorem envBound29706 : H12AffineFastState.Bounded env29706 := by
  intro p hp
  have h : env29706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29705_29706 : H12AffineEnvironment.transform 15 8203 env29705 = env29706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env29705 == env29706) = true)

theorem identity29706 : scanCanonicalize (H12AffineFastState.compose env29706 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound29706 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env29707 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5236,8541,8203,13744,10280,1025,8540,4541,169,492,138,8328,64,2421,5357,4468,10589,1057,33,257,340,5593,1021]

theorem envBound29707 : H12AffineFastState.Bounded env29707 := by
  intro p hp
  have h : env29707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29706_29707 : H12AffineEnvironment.transform 13 5236 env29706 = env29707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env29706 == env29707) = true)

theorem identity29707 : scanCanonicalize (H12AffineFastState.compose env29707 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound29707 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env29708 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,5236,372,34,5529,2049,1025,373,4541,169,492,138,161,64,2421,5357,4468,2420,1057,33,257,340,5593,1021]

theorem envBound29708 : H12AffineFastState.Bounded env29708 := by
  intro p hp
  have h : env29708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29707_29708 : H12AffineEnvironment.transform 12 41 env29707 = env29708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env29707 == env29708) = true)

theorem identity29708 : scanCanonicalize (H12AffineFastState.compose env29708 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound29708 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29709 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,41,5236,137,34,5220,2049,1025,136,4160,169,17,138,161,64,2184,5357,4233,2185,1057,33,252,169,5156,512]

theorem envBound29709 : H12AffineFastState.Bounded env29709 := by
  intro p hp
  have h : env29709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29708_29709 : H12AffineEnvironment.transform 7 253 env29708 = env29709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env29708 == env29709) = true)

theorem identity29709 : scanCanonicalize (H12AffineFastState.compose env29709 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound29709 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29710 : List Nat := [2,4,8,16,1,64,128,220,512,1024,2048,4096,8,5205,137,3,5189,2049,1025,136,4160,136,17,138,128,64,2184,5324,4233,2185,1024,0,221,136,5125,512]

theorem envBound29710 : H12AffineFastState.Bounded env29710 := by
  intro p hp
  have h : env29710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29709_29710 : H12AffineEnvironment.transform 4 1 env29709 = env29710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env29709 == env29710) = true)

def env29711 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,10281,1025,32769,58516,168,62661,98780,8328,64,23809,57796,17664,56437,61704,32,257,21792,46212,120543]

theorem envBound29711 : H12AffineFastState.Bounded env29711 := by
  intro p hp
  have h : env29711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29703_29711 : H12AffineEnvironment.transform 17 10281 env29703 = env29711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env29703 == env29711) = true)

theorem identity29711 : scanCanonicalize (H12AffineFastState.compose env29711 (packedSelected [0,1,2,3,4,6,9,15,20,23,24,27,28,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound29711 : packedSelected [0,1,2,3,4,6,9,15,20,23,24,27,28,32,38] rootPS < 2^1333 := by decide +kernel

def env29712 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,121,16384,32768,65536,49305,2128,1025,32769,50413,168,54460,98780,241,64,23809,49597,17664,56437,53617,32,257,21792,38141,120543]

theorem envBound29712 : H12AffineFastState.Bounded env29712 := by
  intro p hp
  have h : env29712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29711_29712 : H12AffineEnvironment.transform 12 121 env29711 = env29712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env29711 == env29712) = true)

theorem identity29712 : scanCanonicalize (H12AffineFastState.compose env29712 (packedSelected [0,1,2,4,5,6,7,9,10,11,12,14,15,18,19,24,26,28] rootPS)) = affineNative (2^(14+1) ^^^ 428) := by decide +kernel

theorem selectedBound29712 : packedSelected [0,1,2,4,5,6,7,9,10,11,12,14,15,18,19,24,26,28] rootPS < 2^1333 := by decide +kernel

def env29713 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,121,16384,428,65536,16693,2128,1025,429,17729,168,21776,65648,241,64,23809,16401,17664,24025,20701,32,257,21792,5457,87923]

theorem envBound29713 : H12AffineFastState.Bounded env29713 := by
  intro p hp
  have h : env29713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29712_29713 : H12AffineEnvironment.transform 14 428 env29712 = env29713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 428 env29712 == env29713) = true)

theorem identity29713 : scanCanonicalize (H12AffineFastState.compose env29713 (packedSelected [0,3,4,5,7,10,22] rootPS)) = affineNative (2^(15+1) ^^^ 20807) := by decide +kernel

theorem selectedBound29713 : packedSelected [0,3,4,5,7,10,22] rootPS < 2^1333 := by decide +kernel

def env29714 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,121,16384,428,20807,16693,2128,1025,429,17729,168,21776,20791,241,64,23809,16401,17664,24025,20701,32,257,21792,5457,1588]

theorem envBound29714 : H12AffineFastState.Bounded env29714 := by
  intro p hp
  have h : env29714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29713_29714 : H12AffineEnvironment.transform 15 20807 env29713 = env29714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20807 env29713 == env29714) = true)

theorem identity29714 : scanCanonicalize (H12AffineFastState.compose env29714 (packedSelected [1,5,8,12,15,17,18,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound29714 : packedSelected [1,5,8,12,15,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env29715 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,121,16384,428,20807,16693,2128,273,429,16465,168,20480,20791,241,64,22545,16401,16400,22729,20701,32,257,20528,4161,804]

theorem envBound29715 : H12AffineFastState.Bounded env29715 := by
  intro p hp
  have h : env29715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29714_29715 : H12AffineEnvironment.transform 9 272 env29714 = env29715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env29714 == env29715) = true)

theorem identity29715 : scanCanonicalize (H12AffineFastState.compose env29715 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound29715 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env29716 : List Nat := [2,4,8,16,32,64,88,256,512,272,2048,4096,121,16384,372,20807,16693,2128,273,373,16465,112,20480,20791,41,64,22545,16401,16400,22545,20485,32,257,20528,4161,804]

theorem envBound29716 : H12AffineFastState.Bounded env29716 := by
  intro p hp
  have h : env29716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29715_29716 : H12AffineEnvironment.transform 6 88 env29715 = env29716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env29715 == env29716) = true)

theorem identity29716 : scanCanonicalize (H12AffineFastState.compose env29716 (packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS)) = affineNative (2^(13+1) ^^^ 4453) := by decide +kernel

theorem selectedBound29716 : packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS < 2^1333 := by decide +kernel

def env29717 : List Nat := [2,4,8,16,32,64,88,256,512,272,2048,4096,121,4453,372,34,4176,2128,273,373,4404,112,357,82,41,64,2420,4468,4469,2420,352,32,257,341,4161,804]

theorem envBound29717 : H12AffineFastState.Bounded env29717 := by
  intro p hp
  have h : env29717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29716_29717 : H12AffineEnvironment.transform 13 4453 env29716 = env29717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4453 env29716 == env29717) = true)

theorem identity29717 : scanCanonicalize (H12AffineFastState.compose env29717 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound29717 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29718 : List Nat := [2,4,8,16,32,64,88,36,512,52,2048,4096,121,4161,80,34,4176,2128,53,81,4112,112,65,82,41,64,2128,4176,4177,2128,68,32,37,113,4161,512]

theorem envBound29718 : H12AffineFastState.Bounded env29718 := by
  intro p hp
  have h : env29718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29717_29718 : H12AffineEnvironment.transform 7 36 env29717 = env29718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env29717 == env29718) = true)

theorem identity29718 : scanCanonicalize (H12AffineFastState.compose env29718 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound29718 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env29719 : List Nat := [2,4,8,16,32,64,88,36,512,52,2048,0,121,65,80,34,80,2128,53,81,16,112,65,82,41,64,2128,80,81,2128,68,32,37,113,65,512]

theorem envBound29719 : H12AffineFastState.Bounded env29719 := by
  intro p hp
  have h : env29719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29718_29719 : H12AffineEnvironment.transform 11 0 env29718 = env29719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env29718 == env29719) = true)

theorem identity29719 : scanCanonicalize (H12AffineFastState.compose env29719 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound29719 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29720 : List Nat := [2,4,8,16,32,48,40,36,512,52,2048,0,9,49,32,34,32,2080,53,33,16,0,49,34,41,48,2080,32,33,2080,52,32,37,1,49,512]

theorem envBound29720 : H12AffineFastState.Bounded env29720 := by
  intro p hp
  have h : env29720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29719_29720 : H12AffineEnvironment.transform 5 48 env29719 = env29720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env29719 == env29720) = true)

theorem identity29720 : scanCanonicalize (H12AffineFastState.compose env29720 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound29720 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env29721 : List Nat := [2,4,8,16,32,48,40,36,512,52,49,0,9,49,32,34,32,17,53,33,16,0,49,34,41,48,17,32,33,17,52,32,37,1,49,512]

theorem envBound29721 : H12AffineFastState.Bounded env29721 := by
  intro p hp
  have h : env29721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29720_29721 : H12AffineEnvironment.transform 10 49 env29720 = env29721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env29720 == env29721) = true)

theorem identity29721 : scanCanonicalize (H12AffineFastState.compose env29721 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound29721 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env29722 : List Nat := [2,4,8,16,17,1,25,21,512,5,0,0,9,0,17,19,17,17,4,16,16,0,0,19,24,1,17,17,16,17,5,17,20,1,0,512]

theorem envBound29722 : H12AffineFastState.Bounded env29722 := by
  intro p hp
  have h : env29722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29721_29722 : H12AffineEnvironment.transform 4 17 env29721 = env29722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env29721 == env29722) = true)

theorem identity29722 : scanCanonicalize (H12AffineFastState.compose env29722 (packedSelected [4,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29722 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env29723 : List Nat := [2,4,8,1,0,1,8,4,512,5,0,0,9,0,0,2,0,0,4,1,1,0,0,2,9,1,0,0,1,0,5,0,5,1,0,512]

theorem envBound29723 : H12AffineFastState.Bounded env29723 := by
  intro p hp
  have h : env29723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29722_29723 : H12AffineEnvironment.transform 3 1 env29722 = env29723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29722 == env29723) = true)

theorem identity29723 : scanCanonicalize (H12AffineFastState.compose env29723 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound29723 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29724 : List Nat := [2,1,8,1,0,1,8,1,512,0,0,0,9,0,0,2,0,0,1,1,1,0,0,2,9,1,0,0,1,0,0,0,0,1,0,512]

theorem envBound29724 : H12AffineFastState.Bounded env29724 := by
  intro p hp
  have h : env29724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29723_29724 : H12AffineEnvironment.transform 1 1 env29723 = env29724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env29723 == env29724) = true)

theorem identity29724 : scanCanonicalize (H12AffineFastState.compose env29724 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound29724 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29725 : List Nat := [2,1,8,1,0,1,8,1,8,0,0,0,9,0,0,2,0,0,1,1,1,0,0,2,9,1,0,0,1,0,0,0,0,1,0,8]

theorem envBound29725 : H12AffineFastState.Bounded env29725 := by
  intro p hp
  have h : env29725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29724_29725 : H12AffineEnvironment.transform 8 8 env29724 = env29725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env29724 == env29725) = true)

theorem identity29725 : scanCanonicalize (H12AffineFastState.compose env29725 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound29725 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env29726 : List Nat := [2,1,2,1,0,1,2,1,2,0,0,0,3,0,0,2,0,0,1,1,1,0,0,2,3,1,0,0,1,0,0,0,0,1,0,2]

theorem envBound29726 : H12AffineFastState.Bounded env29726 := by
  intro p hp
  have h : env29726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29725_29726 : H12AffineEnvironment.transform 2 2 env29725 = env29726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env29725 == env29726) = true)

def env29727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2281673,213317,8328,64,6705548,2278857,165272,2363593,2102685,6431877,257,21793,46213,2175562]

theorem envBound29727 : H12AffineFastState.Bounded env29727 := by
  intro p hp
  have h : env29727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29645_29727 : H12AffineEnvironment.transform 22 2281673 env29645 = env29727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2281673 env29645 == env29727) = true)

def env29728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6590740,2098513,17664,2363593,2102685,6349853,257,21793,46213,2175562]

theorem envBound29728 : H12AffineFastState.Bounded env29728 := by
  intro p hp
  have h : env29728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29727_29728 : H12AffineEnvironment.transform 16 49304 env29727 = env29728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env29727 == env29728) = true)

def env29729 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2144660,2098513,17664,2363593,2102685,2411677,257,21793,46213,2175562]

theorem envBound29729 : H12AffineFastState.Bounded env29729 := by
  intro p hp
  have h : env29729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29728_29729 : H12AffineEnvironment.transform 21 272512 env29728 = env29729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env29728 == env29729) = true)

theorem identity29729 : scanCanonicalize (H12AffineFastState.compose env29729 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound29729 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,77899,272512,73754,98781,8328,64,100831,79130,17664,336002,75222,392406,257,21793,46213,513]

theorem envBound29730 : H12AffineFastState.Bounded env29730 := by
  intro p hp
  have h : env29730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29729_29730 : H12AffineEnvironment.transform 20 77899 env29729 = env29730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env29729 == env29730) = true)

def env29731 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,77899,272392,73754,98645,8192,64,100695,79130,17664,335882,75102,392286,257,21793,46093,513]

theorem envBound29731 : H12AffineFastState.Bounded env29731 := by
  intro p hp
  have h : env29731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29730_29731 : H12AffineEnvironment.transform 6 8 env29730 = env29731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29730 == env29731) = true)

theorem identity29731 : scanCanonicalize (H12AffineFastState.compose env29731 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound29731 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env29732 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40970,49168,262144,1025,32769,36929,272392,32784,8543,8192,64,10589,38160,17664,294912,34132,285780,257,21793,46093,513]

theorem envBound29732 : H12AffineFastState.Bounded env29732 := by
  intro p hp
  have h : env29732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29731_29732 : H12AffineEnvironment.transform 15 40970 env29731 = env29732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env29731 == env29732) = true)

theorem identity29732 : scanCanonicalize (H12AffineFastState.compose env29732 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 63545) := by decide +kernel

theorem selectedBound29732 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env29733 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40970,49168,63545,1025,32769,36929,53297,32784,8543,8192,64,10589,38160,17664,30777,34132,42093,257,21793,46093,513]

theorem envBound29733 : H12AffineFastState.Bounded env29733 := by
  intro p hp
  have h : env29733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29732_29733 : H12AffineEnvironment.transform 17 63545 env29732 = env29733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 63545 env29732 == env29733) = true)

theorem identity29733 : scanCanonicalize (H12AffineFastState.compose env29733 (packedSelected [4,7,9,17,18,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 1344) := by decide +kernel

theorem selectedBound29733 : packedSelected [4,7,9,17,18,23,27] rootPS < 2^1333 := by decide +kernel

def env29734 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1344,9546,17744,32121,1025,1345,5377,21873,1360,8543,8192,64,10589,4176,17664,30777,20,8493,257,21793,12621,513]

theorem envBound29734 : H12AffineFastState.Bounded env29734 := by
  intro p hp
  have h : env29734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29733_29734 : H12AffineEnvironment.transform 14 1344 env29733 = env29734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1344 env29733 == env29734) = true)

theorem identity29734 : scanCanonicalize (H12AffineFastState.compose env29734 (packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound29734 : packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS < 2^1333 := by decide +kernel

def env29735 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,1077,9279,17445,31756,1025,1076,5236,21508,1061,8234,8192,64,10280,4176,17525,30777,20,8280,116,21588,12344,513]

theorem envBound29735 : H12AffineFastState.Bounded env29735 := by
  intro p hp
  have h : env29735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29734_29735 : H12AffineEnvironment.transform 7 117 env29734 = env29735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env29734 == env29735) = true)

theorem identity29735 : scanCanonicalize (H12AffineFastState.compose env29735 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound29735 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env29736 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,1053,16384,1077,34,17445,22545,1025,1076,5236,21508,1061,1079,1053,64,3125,4176,17525,23588,20,1093,116,21588,5157,513]

theorem envBound29736 : H12AffineFastState.Bounded env29736 := by
  intro p hp
  have h : env29736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29735_29736 : H12AffineEnvironment.transform 12 1053 env29735 = env29736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env29735 == env29736) = true)

theorem identity29736 : scanCanonicalize (H12AffineFastState.compose env29736 (packedSelected [0,1,2,3,4,6,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound29736 : packedSelected [0,1,2,3,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env29737 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,4096,121,16384,81,34,16449,22545,101,80,4112,20576,65,83,121,64,2129,4176,16401,22592,20,33,116,20528,4161,513]

theorem envBound29737 : H12AffineFastState.Bounded env29737 := by
  intro p hp
  have h : env29737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29736_29737 : H12AffineEnvironment.transform 9 100 env29736 = env29737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env29736 == env29737) = true)

theorem identity29737 : scanCanonicalize (H12AffineFastState.compose env29737 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29737 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29738 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,4096,40,16384,0,34,16400,22545,52,1,4112,20529,16,2,40,17,2048,4097,16401,22545,20,33,37,20528,4112,513]

theorem envBound29738 : H12AffineFastState.Bounded env29738 := by
  intro p hp
  have h : env29738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29737_29738 : H12AffineEnvironment.transform 5 17 env29737 = env29738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29737 == env29738) = true)

theorem identity29738 : scanCanonicalize (H12AffineFastState.compose env29738 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound29738 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29739 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,4096,40,4113,0,34,4097,2048,52,1,4112,32,16,2,40,17,2048,4097,4096,2048,20,33,37,33,4112,513]

theorem envBound29739 : H12AffineFastState.Bounded env29739 := by
  intro p hp
  have h : env29739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29738_29739 : H12AffineEnvironment.transform 13 4113 env29738 = env29739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env29738 == env29739) = true)

theorem identity29739 : scanCanonicalize (H12AffineFastState.compose env29739 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2080) := by decide +kernel

theorem selectedBound29739 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29740 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,2080,40,2097,0,34,2081,2048,52,1,2096,32,16,2,40,17,2048,2081,2080,2048,20,33,37,33,2096,513]

theorem envBound29740 : H12AffineFastState.Bounded env29740 := by
  intro p hp
  have h : env29740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29739_29740 : H12AffineEnvironment.transform 11 2080 env29739 = env29740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2080 env29739 == env29740) = true)

theorem identity29740 : scanCanonicalize (H12AffineFastState.compose env29740 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound29740 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29741 : List Nat := [2,4,8,16,32,17,8,36,512,53,513,545,40,560,0,34,544,513,52,1,561,32,16,2,40,17,513,544,545,513,20,33,37,33,561,513]

theorem envBound29741 : H12AffineFastState.Bounded env29741 := by
  intro p hp
  have h : env29741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29740_29741 : H12AffineEnvironment.transform 10 513 env29740 = env29741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env29740 == env29741) = true)

theorem identity29741 : scanCanonicalize (H12AffineFastState.compose env29741 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound29741 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env29742 : List Nat := [2,4,8,16,32,17,8,36,49,53,48,16,40,1,0,34,17,48,52,1,0,32,16,2,40,17,48,17,16,48,20,33,37,33,0,48]

theorem envBound29742 : H12AffineFastState.Bounded env29742 := by
  intro p hp
  have h : env29742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29741_29742 : H12AffineEnvironment.transform 8 49 env29741 = env29742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env29741 == env29742) = true)

theorem identity29742 : scanCanonicalize (H12AffineFastState.compose env29742 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound29742 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env29743 : List Nat := [2,4,8,16,16,17,8,20,1,5,0,16,24,1,0,18,17,0,4,1,0,16,16,2,24,17,0,17,16,0,20,17,21,17,0,0]

theorem envBound29743 : H12AffineFastState.Bounded env29743 := by
  intro p hp
  have h : env29743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29742_29743 : H12AffineEnvironment.transform 4 16 env29742 = env29743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env29742 == env29743) = true)

def env29744 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,77899,272393,73754,98644,8193,64,100694,79130,17664,335883,75103,392287,257,21793,46092,513]

theorem envBound29744 : H12AffineFastState.Bounded env29744 := by
  intro p hp
  have h : env29744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29730_29744 : H12AffineEnvironment.transform 6 9 env29730 = env29744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29730 == env29744) = true)

theorem identity29744 : scanCanonicalize (H12AffineFastState.compose env29744 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound29744 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env29745 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35188,1025,32769,77899,41341,73754,98644,8193,64,100694,79130,17664,108927,75103,95531,257,21793,46092,513]

theorem envBound29745 : H12AffineFastState.Bounded env29745 := by
  intro p hp
  have h : env29745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29744_29745 : H12AffineEnvironment.transform 17 35188 env29744 = env29745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env29744 == env29745) = true)

theorem identity29745 : scanCanonicalize (H12AffineFastState.compose env29745 (packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound29745 : packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env29746 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,38161,35188,1025,32769,77899,41341,73754,98644,8193,64,100694,79130,4096,108927,75103,73771,257,33,46092,513]

theorem envBound29746 : H12AffineFastState.Bounded env29746 := by
  intro p hp
  have h : env29746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29745_29746 : H12AffineEnvironment.transform 13 5376 env29745 = env29746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env29745 == env29746) = true)

theorem identity29746 : scanCanonicalize (H12AffineFastState.compose env29746 (packedSelected [0,3,5,7,10,12,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound29746 : packedSelected [0,3,5,7,10,12,15,20] rootPS < 2^1333 := by decide +kernel

def env29747 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8282,38161,35188,1025,32769,4113,41341,64,41230,8193,64,43276,5440,4096,35109,1285,113,257,33,46092,513]

theorem envBound29747 : H12AffineFastState.Bounded env29747 := by
  intro p hp
  have h : env29747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29746_29747 : H12AffineEnvironment.transform 15 8282 env29746 = env29747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env29746 == env29747) = true)

theorem identity29747 : scanCanonicalize (H12AffineFastState.compose env29747 (packedSelected [0,7,16,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound29747 : packedSelected [0,7,16,18,23] rootPS < 2^1333 := by decide +kernel

def env29748 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,0,8282,5393,2420,1025,1,4113,8573,64,8462,8193,64,10508,5440,4096,2341,1285,113,257,33,13324,513]

theorem envBound29748 : H12AffineFastState.Bounded env29748 := by
  intro p hp
  have h : env29748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29747_29748 : H12AffineEnvironment.transform 14 0 env29747 = env29748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env29747 == env29748) = true)

theorem identity29748 : scanCanonicalize (H12AffineFastState.compose env29748 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29748 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env29749 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,0,8203,5393,2341,1025,1,4113,8492,17,8462,8193,17,10508,5393,4096,2341,1285,32,257,33,13324,513]

theorem envBound29749 : H12AffineFastState.Bounded env29749 := by
  intro p hp
  have h : env29749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29748_29749 : H12AffineEnvironment.transform 5 17 env29748 = env29749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29748 == env29749) = true)

theorem identity29749 : scanCanonicalize (H12AffineFastState.compose env29749 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(12+1) ^^^ 553) := by decide +kernel

theorem selectedBound29749 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env29750 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,553,5376,0,546,5393,2341,1025,1,4113,773,17,807,552,17,2853,5393,4096,2341,1285,32,257,33,5669,513]

theorem envBound29750 : H12AffineFastState.Bounded env29750 := by
  intro p hp
  have h : env29750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29749_29750 : H12AffineEnvironment.transform 12 553 env29749 = env29750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 553 env29749 == env29750) = true)

theorem identity29750 : scanCanonicalize (H12AffineFastState.compose env29750 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound29750 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env29751 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,512,553,1792,0,546,1809,2341,1025,1,529,773,17,807,552,17,2853,1809,512,2341,1285,32,257,33,1061,513]

theorem envBound29751 : H12AffineFastState.Bounded env29751 := by
  intro p hp
  have h : env29751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29750_29751 : H12AffineEnvironment.transform 11 512 env29750 = env29751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env29750 == env29751) = true)

theorem identity29751 : scanCanonicalize (H12AffineFastState.compose env29751 (packedSelected [1,3,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29751 : packedSelected [1,3,7,9] rootPS < 2^1333 := by decide +kernel

def env29752 : List Nat := [2,4,8,1,32,0,9,256,512,1024,2048,512,553,1792,0,546,1792,2341,1025,1,512,773,0,807,552,0,2853,1792,512,2341,1285,32,257,33,1061,513]

theorem envBound29752 : H12AffineFastState.Bounded env29752 := by
  intro p hp
  have h : env29752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29751_29752 : H12AffineEnvironment.transform 3 1 env29751 = env29752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29751 == env29752) = true)

theorem identity29752 : scanCanonicalize (H12AffineFastState.compose env29752 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 289) := by decide +kernel

theorem selectedBound29752 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env29753 : List Nat := [2,4,8,1,32,0,9,256,512,289,2048,512,553,545,0,546,545,2341,288,1,512,773,0,807,552,0,2853,545,512,2341,36,32,257,33,260,513]

theorem envBound29753 : H12AffineFastState.Bounded env29753 := by
  intro p hp
  have h : env29753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29752_29753 : H12AffineEnvironment.transform 9 289 env29752 = env29753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 289 env29752 == env29753) = true)

theorem identity29753 : scanCanonicalize (H12AffineFastState.compose env29753 (packedSelected [0,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound29753 : packedSelected [0,7,10] rootPS < 2^1333 := by decide +kernel

def env29754 : List Nat := [2,4,8,1,32,0,9,256,512,289,0,512,553,545,0,546,545,293,288,1,512,773,0,807,552,0,805,545,512,293,36,32,257,33,260,513]

theorem envBound29754 : H12AffineFastState.Bounded env29754 := by
  intro p hp
  have h : env29754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29753_29754 : H12AffineEnvironment.transform 10 0 env29753 = env29754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env29753 == env29754) = true)

theorem identity29754 : scanCanonicalize (H12AffineFastState.compose env29754 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound29754 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env29755 : List Nat := [2,4,8,1,32,0,9,256,293,289,0,293,268,260,0,263,260,293,288,1,293,32,0,2,269,0,0,260,293,293,36,32,257,33,260,292]

theorem envBound29755 : H12AffineFastState.Bounded env29755 := by
  intro p hp
  have h : env29755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29754_29755 : H12AffineEnvironment.transform 8 293 env29754 = env29755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env29754 == env29755) = true)

theorem identity29755 : scanCanonicalize (H12AffineFastState.compose env29755 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound29755 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29756 : List Nat := [2,4,8,1,32,0,9,4,33,37,0,33,8,0,0,3,0,33,36,1,33,32,0,2,9,0,0,0,33,33,36,32,5,33,0,32]

theorem envBound29756 : H12AffineFastState.Bounded env29756 := by
  intro p hp
  have h : env29756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29755_29756 : H12AffineEnvironment.transform 7 4 env29755 = env29756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env29755 == env29756) = true)

theorem identity29756 : scanCanonicalize (H12AffineFastState.compose env29756 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29756 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env29757 : List Nat := [2,4,8,1,0,0,9,4,1,5,0,1,8,0,0,3,0,1,4,1,1,0,0,2,9,0,0,0,1,1,4,0,5,1,0,0]

theorem envBound29757 : H12AffineFastState.Bounded env29757 := by
  intro p hp
  have h : env29757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29756_29757 : H12AffineEnvironment.transform 4 0 env29756 = env29757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29756 == env29757) = true)

theorem identity29757 : scanCanonicalize (H12AffineFastState.compose env29757 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound29757 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29758 : List Nat := [2,4,3,1,0,0,2,4,1,5,0,1,3,0,0,3,0,1,4,1,1,0,0,2,2,0,0,0,1,1,4,0,5,1,0,0]

theorem envBound29758 : H12AffineFastState.Bounded env29758 := by
  intro p hp
  have h : env29758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29757_29758 : H12AffineEnvironment.transform 2 3 env29757 = env29758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env29757 == env29758) = true)

def env29759 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2144661,2098513,17664,2363593,2102685,2411676,257,21793,46213,2175562]

theorem envBound29759 : H12AffineFastState.Bounded env29759 := by
  intro p hp
  have h : env29759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29728_29759 : H12AffineEnvironment.transform 21 272513 env29728 = env29759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env29728 == env29759) = true)

theorem identity29759 : scanCanonicalize (H12AffineFastState.compose env29759 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound29759 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49304,262144,1025,32769,2097152,272513,2101329,41430,8328,64,2144661,2098513,17664,2363593,2102685,2411676,257,21793,46213,2101825]

theorem envBound29760 : H12AffineFastState.Bounded env29760 := by
  intro p hp
  have h : env29760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29759_29760 : H12AffineEnvironment.transform 15 8203 env29759 = env29760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env29759 == env29760) = true)

theorem identity29760 : scanCanonicalize (H12AffineFastState.compose env29760 (packedSelected [3,10,16,17,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound29760 : packedSelected [3,10,16,17,20,24,26] rootPS < 2^1333 := by decide +kernel

def env29761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8203,25028,262144,1025,8541,2097152,272513,2101329,138,8328,64,2103497,2098513,17664,2363593,2102685,2387392,257,21793,5593,2101825]

theorem envBound29761 : H12AffineFastState.Bounded env29761 := by
  intro p hp
  have h : env29761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29760_29761 : H12AffineEnvironment.transform 14 8540 env29760 = env29761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env29760 == env29761) = true)

theorem identity29761 : scanCanonicalize (H12AffineFastState.compose env29761 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound29761 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env29762 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,24909,262144,1025,8541,2097152,272392,2101329,3,8193,64,2103360,2098513,17664,2363456,2102548,2387273,257,21793,5456,2101825]

theorem envBound29762 : H12AffineFastState.Bounded env29762 := by
  intro p hp
  have h : env29762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29761_29762 : H12AffineEnvironment.transform 6 9 env29761 = env29762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29761 == env29762) = true)

theorem identity29762 : scanCanonicalize (H12AffineFastState.compose env29762 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound29762 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env29763 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,24909,2048,1025,8541,2097152,8200,2101329,3,8193,64,2103360,2098513,17664,2103360,2102548,2123081,257,21793,5456,2101825]

theorem envBound29763 : H12AffineFastState.Bounded env29763 := by
  intro p hp
  have h : env29763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29762_29763 : H12AffineEnvironment.transform 17 2048 env29762 = env29763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env29762 == env29763) = true)

theorem identity29763 : scanCanonicalize (H12AffineFastState.compose env29763 (packedSelected [0,1,3,5,7,8,9,14,17,18,20,22,23] rootPS)) = affineNative (2^(20+1) ^^^ 28008) := by decide +kernel

theorem selectedBound29763 : packedSelected [0,1,3,5,7,8,9,14,17,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env29764 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,24909,2048,1025,8541,28008,8200,32057,3,8193,64,29992,26681,17664,29992,30844,2081,257,21793,5456,32553]

theorem envBound29764 : H12AffineFastState.Bounded env29764 := by
  intro p hp
  have h : env29764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29763_29764 : H12AffineEnvironment.transform 20 28008 env29763 = env29764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 28008 env29763 == env29764) = true)

theorem identity29764 : scanCanonicalize (H12AffineFastState.compose env29764 (packedSelected [1,4,5,6,8,14,17,20,22,24] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound29764 : packedSelected [1,4,5,6,8,14,17,20,22,24] rootPS < 2^1333 := by decide +kernel

def env29765 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,16384,372,35,16741,2048,1025,373,19776,32,23825,3,41,64,21760,18449,17664,21760,22612,2081,257,21793,5456,24321]

theorem envBound29765 : H12AffineFastState.Bounded env29765 := by
  intro p hp
  have h : env29765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29764_29765 : H12AffineEnvironment.transform 12 40 env29764 = env29765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env29764 == env29765) = true)

theorem identity29765 : scanCanonicalize (H12AffineFastState.compose env29765 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 7424) := by decide +kernel

theorem selectedBound29765 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29766 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,7424,372,35,7269,2048,1025,373,4160,32,17,3,41,64,2048,5393,6144,2048,1364,2081,257,2081,5456,513]

theorem envBound29766 : H12AffineFastState.Bounded env29766 := by
  intro p hp
  have h : env29766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29765_29766 : H12AffineEnvironment.transform 13 7424 env29765 = env29766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7424 env29765 == env29766) = true)

theorem identity29766 : scanCanonicalize (H12AffineFastState.compose env29766 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound29766 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env29767 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,7285,1,35,7269,2048,1025,0,4160,32,17,3,41,64,2048,5220,6144,2048,1057,2081,116,2081,5157,513]

theorem envBound29767 : H12AffineFastState.Bounded env29767 := by
  intro p hp
  have h : env29767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29766_29767 : H12AffineEnvironment.transform 7 117 env29766 = env29767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env29766 == env29767) = true)

theorem identity29767 : scanCanonicalize (H12AffineFastState.compose env29767 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 111) := by decide +kernel

theorem selectedBound29767 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29768 : List Nat := [2,4,8,16,32,64,9,117,512,111,2048,4096,40,6170,1,35,6154,2048,110,0,4160,32,17,3,41,64,2048,4107,6144,2048,78,2081,116,2081,4170,513]

theorem envBound29768 : H12AffineFastState.Bounded env29768 := by
  intro p hp
  have h : env29768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29767_29768 : H12AffineEnvironment.transform 9 111 env29767 = env29768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 111 env29767 == env29768) = true)

theorem identity29768 : scanCanonicalize (H12AffineFastState.compose env29768 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound29768 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env29769 : List Nat := [2,4,8,16,32,58,9,15,512,21,2048,4096,40,6170,1,35,6154,2048,20,0,4154,32,17,3,41,58,2048,4107,6144,2048,52,2081,14,2081,4144,513]

theorem envBound29769 : H12AffineFastState.Bounded env29769 := by
  intro p hp
  have h : env29769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29768_29769 : H12AffineEnvironment.transform 5 58 env29768 = env29769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env29768 == env29769) = true)

theorem identity29769 : scanCanonicalize (H12AffineFastState.compose env29769 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound29769 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29770 : List Nat := [2,4,8,16,32,58,9,15,512,21,1,4096,40,4123,1,35,4107,1,20,0,4154,32,17,3,41,58,1,4107,4097,1,52,32,14,32,4144,513]

theorem envBound29770 : H12AffineFastState.Bounded env29770 := by
  intro p hp
  have h : env29770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29769_29770 : H12AffineEnvironment.transform 10 1 env29769 = env29770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env29769 == env29770) = true)

theorem identity29770 : scanCanonicalize (H12AffineFastState.compose env29770 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 10) := by decide +kernel

theorem selectedBound29770 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env29771 : List Nat := [2,4,8,16,32,58,9,15,512,21,1,10,40,17,1,35,1,1,20,0,48,32,17,3,41,58,1,1,11,1,52,32,14,32,58,513]

theorem envBound29771 : H12AffineFastState.Bounded env29771 := by
  intro p hp
  have h : env29771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29770_29771 : H12AffineEnvironment.transform 11 10 env29770 = env29771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 10 env29770 == env29771) = true)

def env29772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6590741,2098512,17665,2363593,2102685,6349852,257,21793,46213,2175562]

theorem envBound29772 : H12AffineFastState.Bounded env29772 := by
  intro p hp
  have h : env29772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29727_29772 : H12AffineEnvironment.transform 16 49305 env29727 = env29772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env29727 == env29772) = true)

def env29773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2144661,2098512,17665,2363593,2102685,2411676,257,21793,46213,2175562]

theorem envBound29773 : H12AffineFastState.Bounded env29773 := by
  intro p hp
  have h : env29773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29772_29773 : H12AffineEnvironment.transform 21 272512 env29772 = env29773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env29772 == env29773) = true)

theorem identity29773 : scanCanonicalize (H12AffineFastState.compose env29773 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound29773 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,115870,272512,120014,98780,8328,64,97547,115150,17665,382039,119043,329730,257,21793,46213,63188]

theorem envBound29774 : H12AffineFastState.Bounded env29774 := by
  intro p hp
  have h : env29774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29773_29774 : H12AffineEnvironment.transform 20 115870 env29773 = env29774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env29773 == env29774) = true)

def env29775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,10400,1025,32769,115870,32,120014,98780,8328,64,97547,115150,17665,130295,119043,73890,257,21793,46213,63188]

theorem envBound29775 : H12AffineFastState.Bounded env29775 := by
  intro p hp
  have h : env29775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29774_29775 : H12AffineEnvironment.transform 17 10400 env29774 = env29775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env29774 == env29775) = true)

theorem identity29775 : scanCanonicalize (H12AffineFastState.compose env29775 (packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound29775 : packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env29776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,121,16384,32768,65536,49305,2265,1025,32769,115870,32,120014,98780,241,64,89458,115150,17665,121998,119043,65755,257,21793,38140,54957]

theorem envBound29776 : H12AffineFastState.Bounded env29776 := by
  intro p hp
  have h : env29776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29775_29776 : H12AffineEnvironment.transform 12 121 env29775 = env29776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env29775 == env29776) = true)

theorem identity29776 : scanCanonicalize (H12AffineFastState.compose env29776 (packedSelected [1,2,5,6,8,9,14,16,17,18,19,20,22,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 21930) := by decide +kernel

theorem selectedBound29776 : packedSelected [1,2,5,6,8,9,14,16,17,18,19,20,22,24,26,32] rootPS < 2^1333 := by decide +kernel

def env29777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,121,16384,32768,21930,49305,2265,1025,32769,37172,32,33124,54390,241,64,2264,37988,17665,35108,33961,21873,257,21793,38140,54957]

theorem envBound29777 : H12AffineFastState.Bounded env29777 := by
  intro p hp
  have h : env29777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29776_29777 : H12AffineEnvironment.transform 15 21930 env29776 = env29777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21930 env29776 == env29777) = true)

theorem identity29777 : scanCanonicalize (H12AffineFastState.compose env29777 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound29777 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env29778 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,16384,32768,21794,49169,2129,1025,32769,37172,32,33124,54390,121,64,2128,37988,17665,35108,33825,21873,257,21793,38004,54821]

theorem envBound29778 : H12AffineFastState.Bounded env29778 := by
  intro p hp
  have h : env29778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29777_29778 : H12AffineEnvironment.transform 6 8 env29777 = env29778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29777 == env29778) = true)

theorem identity29778 : scanCanonicalize (H12AffineFastState.compose env29778 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 21620) := by decide +kernel

theorem selectedBound29778 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29779 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,16384,21620,21794,5221,2129,1025,21621,17728,32,21776,2,121,64,2128,16400,17665,23888,20565,21873,257,21793,16384,593]

theorem envBound29779 : H12AffineFastState.Bounded env29779 := by
  intro p hp
  have h : env29779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29778_29779 : H12AffineEnvironment.transform 14 21620 env29778 = env29779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21620 env29778 == env29779) = true)

theorem identity29779 : scanCanonicalize (H12AffineFastState.compose env29779 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound29779 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env29780 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,5376,372,34,5221,2129,1025,373,4160,32,16,2,121,64,2128,5392,4097,2128,1365,113,257,33,5376,593]

theorem envBound29780 : H12AffineFastState.Bounded env29780 := by
  intro p hp
  have h : env29780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29779_29780 : H12AffineEnvironment.transform 13 5376 env29779 = env29780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env29779 == env29780) = true)

theorem identity29780 : scanCanonicalize (H12AffineFastState.compose env29780 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound29780 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env29781 : List Nat := [2,4,8,16,32,64,8,84,512,1024,2048,4096,121,5204,32,34,5221,2129,1025,33,4160,32,16,2,121,64,2128,5188,4097,2128,1025,113,85,33,5204,593]

theorem envBound29781 : H12AffineFastState.Bounded env29781 := by
  intro p hp
  have h : env29781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29780_29781 : H12AffineEnvironment.transform 7 84 env29780 = env29781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env29780 == env29781) = true)

theorem identity29781 : scanCanonicalize (H12AffineFastState.compose env29781 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29781 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env29782 : List Nat := [2,4,8,16,32,17,8,5,512,1024,2048,4096,40,5125,32,34,5172,2048,1025,33,4113,32,16,2,40,17,2049,5141,4097,2049,1025,32,4,33,5125,512]

theorem envBound29782 : H12AffineFastState.Bounded env29782 := by
  intro p hp
  have h : env29782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29781_29782 : H12AffineEnvironment.transform 5 17 env29781 = env29782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29781 == env29782) = true)

theorem identity29782 : scanCanonicalize (H12AffineFastState.compose env29782 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29782 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env29783 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,4096,8,5125,0,2,5140,2048,1025,1,4113,0,16,2,8,17,2049,5141,4097,2049,1025,0,4,1,5125,512]

theorem envBound29783 : H12AffineFastState.Bounded env29783 := by
  intro p hp
  have h : env29783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29782_29783 : H12AffineEnvironment.transform 4 0 env29782 = env29783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29782 == env29783) = true)

def env29784 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,10401,1025,32769,115870,33,120014,98780,8328,64,97547,115150,17665,130294,119043,73891,257,21793,46213,63188]

theorem envBound29784 : H12AffineFastState.Bounded env29784 := by
  intro p hp
  have h : env29784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29774_29784 : H12AffineEnvironment.transform 17 10401 env29774 = env29784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env29774 == env29784) = true)

theorem identity29784 : scanCanonicalize (H12AffineFastState.compose env29784 (packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound29784 : packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env29785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,38160,10401,1025,32769,102679,33,98631,98780,8328,64,75906,103495,4232,108927,99466,73891,257,168,46213,41821]

theorem envBound29785 : H12AffineFastState.Bounded env29785 := by
  intro p hp
  have h : env29785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29784_29785 : H12AffineEnvironment.transform 13 5513 env29784 = env29785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env29784 == env29785) = true)

theorem identity29785 : scanCanonicalize (H12AffineFastState.compose env29785 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound29785 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env29786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8661,65536,13509,10401,1025,8660,78018,33,73874,73737,8328,64,75906,79250,4232,67754,75103,73891,257,168,5456,648]

theorem envBound29786 : H12AffineFastState.Bounded env29786 := by
  intro p hp
  have h : env29786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29785_29786 : H12AffineEnvironment.transform 14 8661 env29785 = env29786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env29785 == env29786) = true)

theorem identity29786 : scanCanonicalize (H12AffineFastState.compose env29786 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound29786 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29787 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,13388,10280,1025,8541,77899,33,73755,73737,8193,64,75787,79131,4097,67619,75103,73770,257,33,5456,513]

theorem envBound29787 : H12AffineFastState.Bounded env29787 := by
  intro p hp
  have h : env29787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29786_29787 : H12AffineEnvironment.transform 6 9 env29786 = env29787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29786 == env29787) = true)

theorem identity29787 : scanCanonicalize (H12AffineFastState.compose env29787 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound29787 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29788 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,80,65536,5440,2340,1025,81,69959,33,65815,65797,269,64,67847,70679,4097,67619,66643,65830,257,33,5456,513]

theorem envBound29788 : H12AffineFastState.Bounded env29788 := by
  intro p hp
  have h : env29788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29787_29788 : H12AffineEnvironment.transform 12 268 env29787 = env29788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env29787 == env29788) = true)

theorem identity29788 : scanCanonicalize (H12AffineFastState.compose env29788 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound29788 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env29789 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,80,263,5440,2340,1025,81,4160,33,16,2,269,64,2048,5392,4097,2340,1364,33,257,33,5456,513]

theorem envBound29789 : H12AffineFastState.Bounded env29789 := by
  intro p hp
  have h : env29789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29788_29789 : H12AffineEnvironment.transform 15 263 env29788 = env29789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env29788 == env29789) = true)

theorem identity29789 : scanCanonicalize (H12AffineFastState.compose env29789 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound29789 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env29790 : List Nat := [2,4,8,16,32,64,9,256,309,1024,2048,4096,268,5376,80,263,5440,2340,1025,81,4160,33,16,2,269,64,2048,5392,4097,2340,1364,33,257,33,5456,308]

theorem envBound29790 : H12AffineFastState.Bounded env29790 := by
  intro p hp
  have h : env29790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29789_29790 : H12AffineEnvironment.transform 8 309 env29789 = env29790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env29789 == env29790) = true)

theorem identity29790 : scanCanonicalize (H12AffineFastState.compose env29790 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound29790 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env29791 : List Nat := [2,4,8,16,32,64,9,5,48,1024,2048,4096,9,5125,80,2,5189,2081,1025,81,4160,33,16,2,8,64,2048,5141,4097,2081,1105,33,4,33,5205,49]

theorem envBound29791 : H12AffineFastState.Bounded env29791 := by
  intro p hp
  have h : env29791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29790_29791 : H12AffineEnvironment.transform 7 5 env29790 = env29791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env29790 == env29791) = true)

theorem identity29791 : scanCanonicalize (H12AffineFastState.compose env29791 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound29791 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29792 : List Nat := [2,4,8,16,32,64,9,5,48,1024,2048,81,9,1108,80,2,1044,2081,1025,81,17,33,16,2,8,64,2048,1092,80,2081,1105,33,4,33,1028,49]

theorem envBound29792 : H12AffineFastState.Bounded env29792 := by
  intro p hp
  have h : env29792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29791_29792 : H12AffineEnvironment.transform 11 81 env29791 = env29792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env29791 == env29792) = true)

theorem identity29792 : scanCanonicalize (H12AffineFastState.compose env29792 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound29792 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env29793 : List Nat := [2,4,8,16,32,48,9,5,48,1024,2048,33,9,1060,32,2,1044,2081,1025,33,17,33,16,2,8,48,2048,1076,32,2081,1057,33,4,33,1028,49]

theorem envBound29793 : H12AffineFastState.Bounded env29793 := by
  intro p hp
  have h : env29793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29792_29793 : H12AffineEnvironment.transform 5 48 env29792 = env29793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env29792 == env29793) = true)

theorem identity29793 : scanCanonicalize (H12AffineFastState.compose env29793 (packedSelected [1,8] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound29793 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env29794 : List Nat := [2,4,8,16,32,48,9,5,48,1024,1076,33,9,1060,32,2,1044,1045,1025,33,17,33,16,2,8,48,1076,1076,32,1045,1057,33,4,33,1028,49]

theorem envBound29794 : H12AffineFastState.Bounded env29794 := by
  intro p hp
  have h : env29794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29793_29794 : H12AffineEnvironment.transform 10 1076 env29793 = env29794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env29793 == env29794) = true)

theorem identity29794 : scanCanonicalize (H12AffineFastState.compose env29794 (packedSelected [10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound29794 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env29795 : List Nat := [2,4,8,16,1,17,9,5,17,1024,1045,0,9,1029,1,2,1044,1045,1025,0,17,0,16,2,8,17,1045,1045,1,1045,1024,0,4,0,1028,16]

theorem envBound29795 : H12AffineFastState.Bounded env29795 := by
  intro p hp
  have h : env29795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29794_29795 : H12AffineEnvironment.transform 4 1 env29794 = env29795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env29794 == env29795) = true)

theorem identity29795 : scanCanonicalize (H12AffineFastState.compose env29795 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29795 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29796 : List Nat := [2,4,8,1,1,0,9,5,0,1024,1028,0,9,1029,1,2,1029,1028,1025,0,0,0,1,2,8,0,1028,1028,1,1028,1024,0,4,0,1028,1]

theorem envBound29796 : H12AffineFastState.Bounded env29796 := by
  intro p hp
  have h : env29796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29795_29796 : H12AffineEnvironment.transform 3 1 env29795 = env29796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29795 == env29796) = true)

theorem identity29796 : scanCanonicalize (H12AffineFastState.compose env29796 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound29796 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29797 : List Nat := [2,4,8,1,1,0,9,5,0,5,1,0,9,0,1,2,0,1,4,0,0,0,1,2,8,0,1,1,1,1,5,0,4,0,1,1]

theorem envBound29797 : H12AffineFastState.Bounded env29797 := by
  intro p hp
  have h : env29797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29796_29797 : H12AffineEnvironment.transform 9 5 env29796 = env29797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env29796 == env29797) = true)

theorem identity29797 : scanCanonicalize (H12AffineFastState.compose env29797 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound29797 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29798 : List Nat := [2,4,2,1,1,0,3,5,0,5,1,0,3,0,1,2,0,1,4,0,0,0,1,2,2,0,1,1,1,1,5,0,4,0,1,1]

theorem envBound29798 : H12AffineFastState.Bounded env29798 := by
  intro p hp
  have h : env29798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29797_29798 : H12AffineEnvironment.transform 2 2 env29797 = env29798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env29797 == env29798) = true)

def env29799 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2144660,2098512,17665,2363593,2102685,2411677,257,21793,46213,2175562]

theorem envBound29799 : H12AffineFastState.Bounded env29799 := by
  intro p hp
  have h : env29799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29772_29799 : H12AffineEnvironment.transform 21 272513 env29772 = env29799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env29772 == env29799) = true)

theorem identity29799 : scanCanonicalize (H12AffineFastState.compose env29799 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound29799 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,49305,262144,1025,32769,2097152,272513,2101328,21763,8328,64,2144660,2098512,17665,2363593,2102685,2411677,257,21793,46213,2156181]

theorem envBound29800 : H12AffineFastState.Bounded env29800 := by
  intro p hp
  have h : env29800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29799_29800 : H12AffineEnvironment.transform 15 54495 env29799 = env29800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env29799 == env29800) = true)

def env29801 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49169,262144,1025,32769,2097152,272393,2101328,21763,8192,64,2144540,2098512,17665,2363457,2102549,2411541,257,21793,46093,2156061]

theorem envBound29801 : H12AffineFastState.Bounded env29801 := by
  intro p hp
  have h : env29801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29800_29801 : H12AffineEnvironment.transform 6 8 env29800 = env29801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29800 == env29801) = true)

theorem identity29801 : scanCanonicalize (H12AffineFastState.compose env29801 (packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 17509) := by decide +kernel

theorem selectedBound29801 : packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env29802 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49169,262144,1025,32769,17509,272393,21557,21763,8192,64,64889,16693,17665,283684,20848,297072,257,21793,46093,41592]

theorem envBound29802 : H12AffineFastState.Bounded env29802 := by
  intro p hp
  have h : env29802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29801_29802 : H12AffineEnvironment.transform 20 17509 env29801 = env29802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17509 env29801 == env29802) = true)

theorem identity29802 : scanCanonicalize (H12AffineFastState.compose env29802 (packedSelected [0,1,4,8,14,15,16,17,22,26,27,41] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound29802 : packedSelected [0,1,4,8,14,15,16,17,22,26,27,41] rootPS < 2^1333 := by decide +kernel

def env29803 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49169,43048,1025,32769,17509,32801,21557,21763,8192,64,64889,16693,17665,64524,20848,8280,257,21793,46093,41592]

theorem envBound29803 : H12AffineFastState.Bounded env29803 := by
  intro p hp
  have h : env29803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29802_29803 : H12AffineEnvironment.transform 17 43048 env29802 = env29803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env29802 == env29803) = true)

theorem identity29803 : scanCanonicalize (H12AffineFastState.compose env29803 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound29803 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env29804 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,16384,32768,54359,49169,43048,1025,32769,17509,32801,21557,21543,8192,64,64605,16401,17445,64524,20564,8280,37,21509,46093,41592]

theorem envBound29804 : H12AffineFastState.Bounded env29804 := by
  intro p hp
  have h : env29804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29803_29804 : H12AffineEnvironment.transform 7 36 env29803 = env29804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env29803 == env29804) = true)

theorem identity29804 : scanCanonicalize (H12AffineFastState.compose env29804 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound29804 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env29805 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,13404,32768,40971,46157,43048,1025,32769,12345,32801,8297,8315,8192,64,34817,13389,12409,34896,9224,8280,37,8281,46093,41592]

theorem envBound29805 : H12AffineFastState.Bounded env29805 := by
  intro p hp
  have h : env29805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29804_29805 : H12AffineEnvironment.transform 13 13404 env29804 = env29805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env29804 == env29805) = true)

theorem identity29805 : scanCanonicalize (H12AffineFastState.compose env29805 (packedSelected [1,2,3,4,5,6,8,9,11,17] rootPS)) = affineNative (2^(12+1) ^^^ 6249) := by decide +kernel

theorem selectedBound29805 : packedSelected [1,2,3,4,5,6,8,9,11,17] rootPS < 2^1333 := by decide +kernel

def env29806 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,6249,3125,32768,39010,35876,36929,1025,32769,2128,32801,6144,6162,6249,64,34817,3108,2064,34896,7265,6193,37,6192,35940,39441]

theorem envBound29806 : H12AffineFastState.Bounded env29806 := by
  intro p hp
  have h : env29806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29805_29806 : H12AffineEnvironment.transform 12 6249 env29805 = env29806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6249 env29805 == env29806) = true)

theorem identity29806 : scanCanonicalize (H12AffineFastState.compose env29806 (packedSelected [0,1,3,4,5,7,8,9,11,12,16] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound29806 : packedSelected [0,1,3,4,5,7,8,9,11,12,16] rootPS < 2^1333 := by decide +kernel

def env29807 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,2064,121,3125,32768,32882,35876,34897,1025,32769,2128,32801,16,2,121,64,34817,3108,2064,34896,1137,33,37,32,35940,33281]

theorem envBound29807 : H12AffineFastState.Bounded env29807 := by
  intro p hp
  have h : env29807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29806_29807 : H12AffineEnvironment.transform 11 2064 env29806 = env29807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env29806 == env29807) = true)

theorem identity29807 : scanCanonicalize (H12AffineFastState.compose env29807 (packedSelected [1,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound29807 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env29808 : List Nat := [2,4,8,16,32,64,8,36,512,1024,1124,1140,121,81,32768,32882,32832,33845,1025,32769,1076,32801,16,2,121,64,33893,64,1140,33844,1137,33,37,32,32768,33281]

theorem envBound29808 : H12AffineFastState.Bounded env29808 := by
  intro p hp
  have h : env29808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29807_29808 : H12AffineEnvironment.transform 10 1124 env29807 = env29808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env29807 == env29808) = true)

theorem identity29808 : scanCanonicalize (H12AffineFastState.compose env29808 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29808 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env29809 : List Nat := [2,4,8,1,32,64,8,36,512,1024,1124,1125,104,64,32768,32867,32832,33828,1025,32769,1061,32801,1,2,104,64,33893,64,1125,33829,1120,33,37,32,32768,33281]

theorem envBound29809 : H12AffineFastState.Bounded env29809 := by
  intro p hp
  have h : env29809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29808_29809 : H12AffineEnvironment.transform 3 1 env29808 = env29809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29808 == env29809) = true)

theorem identity29809 : scanCanonicalize (H12AffineFastState.compose env29809 (packedSelected [3,5,6] rootPS)) = affineNative (2^(14+1) ^^^ 1124) := by decide +kernel

theorem selectedBound29809 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env29810 : List Nat := [2,4,8,1,32,64,8,36,512,1024,1124,1125,104,64,1124,1031,1060,64,1025,1125,1061,1093,1,2,104,64,1,64,1125,65,1120,33,37,32,1124,1637]

theorem envBound29810 : H12AffineFastState.Bounded env29810 := by
  intro p hp
  have h : env29810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29809_29810 : H12AffineEnvironment.transform 14 1124 env29809 = env29810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1124 env29809 == env29810) = true)

theorem identity29810 : scanCanonicalize (H12AffineFastState.compose env29810 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound29810 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env29811 : List Nat := [2,4,8,1,32,64,8,36,512,100,0,1,104,64,0,99,64,64,101,1,65,33,1,2,104,64,1,64,1,65,4,33,37,32,0,513]

theorem envBound29811 : H12AffineFastState.Bounded env29811 := by
  intro p hp
  have h : env29811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29810_29811 : H12AffineEnvironment.transform 9 100 env29810 = env29811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env29810 == env29811) = true)

def env29812 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,49168,262144,1025,32769,2097152,272392,2101328,21763,8193,64,2144541,2098512,17665,2363456,2102548,2411540,257,21793,46092,2156060]

theorem envBound29812 : H12AffineFastState.Bounded env29812 := by
  intro p hp
  have h : env29812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29800_29812 : H12AffineEnvironment.transform 6 9 env29800 = env29812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29800 == env29812) = true)

theorem identity29812 : scanCanonicalize (H12AffineFastState.compose env29812 (packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 36929) := by decide +kernel

theorem selectedBound29812 : packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env29813 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,49168,262144,1025,32769,36929,272392,32785,21763,8193,64,10588,38161,17665,294913,34133,285781,257,21793,46092,30301]

theorem envBound29813 : H12AffineFastState.Bounded env29813 := by
  intro p hp
  have h : env29813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29812_29813 : H12AffineEnvironment.transform 20 36929 env29812 = env29813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 36929 env29812 == env29813) = true)

theorem identity29813 : scanCanonicalize (H12AffineFastState.compose env29813 (packedSelected [0,1,3,5,8,9,10,22,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound29813 : packedSelected [0,1,3,5,8,9,10,22,26,27] rootPS < 2^1333 := by decide +kernel

def env29814 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,49168,56436,1025,32769,36929,62588,32785,21763,8193,64,10588,38161,17665,23669,34133,32801,257,21793,46092,30301]

theorem envBound29814 : H12AffineFastState.Bounded env29814 := by
  intro p hp
  have h : env29814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29813_29814 : H12AffineEnvironment.transform 17 56436 env29813 = env29814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env29813 == env29814) = true)

theorem identity29814 : scanCanonicalize (H12AffineFastState.compose env29814 (packedSelected [4,8,9,10,12,14,15,16,28] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound29814 : packedSelected [4,8,9,10,12,14,15,16,28] rootPS < 2^1333 := by decide +kernel

def env29815 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,54358,49168,56436,1025,32769,36929,54641,32785,21763,268,64,2129,38161,17665,23669,34133,32801,257,21793,38145,22352]

theorem envBound29815 : H12AffineFastState.Bounded env29815 := by
  intro p hp
  have h : env29815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29814_29815 : H12AffineEnvironment.transform 12 269 env29814 = env29815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env29814 == env29815) = true)

theorem identity29815 : scanCanonicalize (H12AffineFastState.compose env29815 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound29815 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env29816 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21761,343,5393,2421,1025,21760,17728,112,21776,21763,268,64,2129,16400,17665,23669,20564,21792,257,21793,16384,22352]

theorem envBound29816 : H12AffineFastState.Bounded env29816 := by
  intro p hp
  have h : env29816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29815_29816 : H12AffineEnvironment.transform 14 21761 env29815 = env29816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env29815 == env29816) = true)

theorem identity29816 : scanCanonicalize (H12AffineFastState.compose env29816 (packedSelected [2,6,12,18] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound29816 : packedSelected [2,6,12,18] rootPS < 2^1333 := by decide +kernel

def env29817 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,269,16384,20837,343,4469,2421,101,20836,16676,112,20852,20839,268,64,2129,16400,16741,22545,20564,20804,257,20805,16384,21300]

theorem envBound29817 : H12AffineFastState.Bounded env29817 := by
  intro p hp
  have h : env29817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29816_29817 : H12AffineEnvironment.transform 9 100 env29816 = env29817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env29816 == env29817) = true)

theorem identity29817 : scanCanonicalize (H12AffineFastState.compose env29817 (packedSelected [1,3,4,5,8,9,15] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound29817 : packedSelected [1,3,4,5,8,9,15] rootPS < 2^1333 := by decide +kernel

def env29818 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,269,4405,80,343,4469,2421,101,81,4113,112,65,82,268,64,2129,4389,4176,2340,353,113,257,112,4405,513]

theorem envBound29818 : H12AffineFastState.Bounded env29818 := by
  intro p hp
  have h : env29818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29817_29818 : H12AffineEnvironment.transform 13 4405 env29817 = env29818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env29817 == env29818) = true)

theorem identity29818 : scanCanonicalize (H12AffineFastState.compose env29818 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound29818 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29819 : List Nat := [2,4,8,16,32,64,9,256,0,100,2048,4096,269,4405,80,343,4469,2421,101,81,4113,112,65,82,268,64,2129,4389,4176,2340,353,113,257,112,4405,1]

theorem envBound29819 : H12AffineFastState.Bounded env29819 := by
  intro p hp
  have h : env29819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29818_29819 : H12AffineEnvironment.transform 8 0 env29818 = env29819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env29818 == env29819) = true)

theorem identity29819 : scanCanonicalize (H12AffineFastState.compose env29819 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29819 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29820 : List Nat := [2,4,8,16,32,17,9,256,0,53,2048,4096,269,4405,1,262,4388,2340,52,0,4113,33,16,3,268,17,2048,4389,4097,2340,304,32,257,33,4405,1]

theorem envBound29820 : H12AffineFastState.Bounded env29820 := by
  intro p hp
  have h : env29820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29819_29820 : H12AffineEnvironment.transform 5 17 env29819 = env29820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29819 == env29820) = true)

theorem identity29820 : scanCanonicalize (H12AffineFastState.compose env29820 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29820 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29821 : List Nat := [2,4,8,1,32,0,9,256,0,36,2048,4096,269,4388,1,262,4388,2340,37,0,4096,33,1,3,268,0,2048,4389,4097,2340,289,32,257,33,4388,1]

theorem envBound29821 : H12AffineFastState.Bounded env29821 := by
  intro p hp
  have h : env29821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29820_29821 : H12AffineEnvironment.transform 3 1 env29820 = env29821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29820 == env29821) = true)

def env29822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507600,155254784,25265168,145662401,525568,140903597,27337993,25733063]

theorem envBound29822 : H12AffineFastState.Bounded env29822 := by
  intro p hp
  have h : env29822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29145_29822 : H12AffineEnvironment.transform 25 65 env29145 = env29822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env29145 == env29822) = true)

def env29823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507600,9356288,25265168,23160257,525568,27902125,27337993,25733063]

theorem envBound29823 : H12AffineFastState.Bounded env29823 := by
  intro p hp
  have h : env29823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29822_29823 : H12AffineEnvironment.transform 26 30393344 env29822 = env29823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env29822 == env29823) = true)

def env29824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830976,25265168,23160257,256,27378861,27337993,25207751]

theorem envBound29824 : H12AffineFastState.Bounded env29824 := by
  intro p hp
  have h : env29824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29823_29824 : H12AffineEnvironment.transform 18 1024 env29823 = env29824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env29823 == env29824) = true)

theorem identity29824 : scanCanonicalize (H12AffineFastState.compose env29824 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 396325) := by decide +kernel

theorem selectedBound29824 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env29825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,4194304,8388608,16777216,8328,65,29868032,17270952,8804725,8830976,25265168,21457380,256,25675912,25635116,25207751]

theorem envBound29825 : H12AffineFastState.Bounded env29825 := by
  intro p hp
  have h : env29825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29824_29825 : H12AffineEnvironment.transform 20 396325 env29824 = env29825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 396325 env29824 == env29825) = true)

def env29826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,4194304,8388608,8887720,8328,65,4218280,8393984,8804725,8830976,399800,12645452,256,21792,46212,474735]

theorem envBound29826 : H12AffineFastState.Bounded env29826 := by
  intro p hp
  have h : env29826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29825_29826 : H12AffineEnvironment.transform 23 8887720 env29825 = env29826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8887720 env29825 == env29826) = true)

def env29827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,4194304,452768,95496,8328,65,4218280,458144,45525,10400,399800,4594924,256,21792,46212,474735]

theorem envBound29827 : H12AffineFastState.Bounded env29827 := by
  intro p hp
  have h : env29827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29826_29827 : H12AffineEnvironment.transform 22 452768 env29826 = env29827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452768 env29826 == env29827) = true)

def env29828 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,272512,452768,95496,8328,65,292136,458144,45525,10400,399800,144492,256,21792,46212,474735]

theorem envBound29828 : H12AffineFastState.Bounded env29828 := by
  intro p hp
  have h : env29828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29827_29828 : H12AffineEnvironment.transform 21 272512 env29827 = env29828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env29827 == env29828) = true)

theorem identity29828 : scanCanonicalize (H12AffineFastState.compose env29828 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212078) := by decide +kernel

theorem selectedBound29828 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29829 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212078,1024,32769,77899,201966,120014,95496,8328,65,215366,115150,45525,10400,75222,144492,256,21792,46212,513]

theorem envBound29829 : H12AffineFastState.Bounded env29829 := by
  intro p hp
  have h : env29829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29828_29829 : H12AffineEnvironment.transform 17 212078 env29828 = env29829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212078 env29828 == env29829) = true)

def env29830 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212078,1024,32769,77899,201830,119878,95496,8192,65,215366,115014,45405,10280,75102,144492,256,21792,46092,513]

theorem envBound29830 : H12AffineFastState.Bounded env29830 := by
  intro p hp
  have h : env29830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29829_29830 : H12AffineEnvironment.transform 6 8 env29829 = env29830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29829 == env29830) = true)

theorem identity29830 : scanCanonicalize (H12AffineFastState.compose env29830 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound29830 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env29831 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,23669,1024,32769,77899,29821,119878,95496,8192,65,10589,115014,45405,10280,75102,87159,256,21792,46092,513]

theorem envBound29831 : H12AffineFastState.Bounded env29831 := by
  intro p hp
  have h : env29831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29830_29831 : H12AffineEnvironment.transform 16 90139 env29830 = env29831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env29830 == env29831) = true)

theorem identity29831 : scanCanonicalize (H12AffineFastState.compose env29831 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 54279) := by decide +kernel

theorem selectedBound29831 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env29832 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54279,46108,23669,1024,32769,58444,29821,65,41231,8192,65,10589,5441,45405,10280,61785,32880,256,21792,46092,513]

theorem envBound29832 : H12AffineFastState.Bounded env29832 := by
  intro p hp
  have h : env29832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29831_29832 : H12AffineEnvironment.transform 15 54279 env29831 = env29832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54279 env29831 == env29832) = true)

theorem identity29832 : scanCanonicalize (H12AffineFastState.compose env29832 (packedSelected [2,4,6,9,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound29832 : packedSelected [2,4,6,9,14,20] rootPS < 2^1333 := by decide +kernel

def env29833 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,41051,46108,10281,1024,32769,36880,33,65,41231,8192,65,10589,5441,45405,10280,34053,32880,256,8572,46092,513]

theorem envBound29833 : H12AffineFastState.Bounded env29833 := by
  intro p hp
  have h : env29833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29832_29833 : H12AffineEnvironment.transform 13 13404 env29832 = env29833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env29832 == env29833) = true)

theorem identity29833 : scanCanonicalize (H12AffineFastState.compose env29833 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 7425) := by decide +kernel

theorem selectedBound29833 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env29834 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,7425,15706,10525,10281,1024,7424,3345,33,65,15374,8192,65,10589,5441,11356,10280,6148,7537,256,8572,10509,513]

theorem envBound29834 : H12AffineFastState.Bounded env29834 := by
  intro p hp
  have h : env29834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29833_29834 : H12AffineEnvironment.transform 14 7425 env29833 = env29834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7425 env29833 == env29834) = true)

theorem identity29834 : scanCanonicalize (H12AffineFastState.compose env29834 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound29834 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env29835 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5456,7425,7254,2065,2341,1024,7424,3345,33,65,7426,268,65,2129,5441,3408,2340,6148,7537,256,112,2049,513]

theorem envBound29835 : H12AffineFastState.Bounded env29835 := by
  intro p hp
  have h : env29835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29834_29835 : H12AffineEnvironment.transform 12 268 env29834 = env29835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env29834 == env29835) = true)

theorem identity29835 : scanCanonicalize (H12AffineFastState.compose env29835 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound29835 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env29836 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3188,268,2340,373,34,2065,2341,1024,372,3345,33,65,374,268,65,2129,2357,3408,2340,1136,261,256,112,2049,513]

theorem envBound29836 : H12AffineFastState.Bounded env29836 := by
  intro p hp
  have h : env29836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29835_29836 : H12AffineEnvironment.transform 11 3188 env29835 = env29836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env29835 == env29836) = true)

theorem identity29836 : scanCanonicalize (H12AffineFastState.compose env29836 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound29836 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env29837 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,2065,268,2340,373,34,2065,2341,101,372,2420,33,65,374,268,65,2129,2357,2357,2340,21,261,256,112,2049,513]

theorem envBound29837 : H12AffineFastState.Bounded env29837 := by
  intro p hp
  have h : env29837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29836_29837 : H12AffineEnvironment.transform 9 101 env29836 = env29837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env29836 == env29837) = true)

theorem identity29837 : scanCanonicalize (H12AffineFastState.compose env29837 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29837 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env29838 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,2065,268,2340,293,34,2065,2341,53,292,2340,33,17,294,268,17,2049,2357,2357,2340,21,261,256,32,2049,513]

theorem envBound29838 : H12AffineFastState.Bounded env29838 := by
  intro p hp
  have h : env29838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29837_29838 : H12AffineEnvironment.transform 5 16 env29837 = env29838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29837 == env29838) = true)

theorem identity29838 : scanCanonicalize (H12AffineFastState.compose env29838 (packedSelected [0,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 318) := by decide +kernel

theorem selectedBound29838 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env29839 : List Nat := [2,4,8,16,32,16,8,256,318,53,2048,2065,268,2340,293,34,2065,2341,53,292,2340,33,17,294,268,17,2049,2357,2357,2340,21,261,256,32,2049,319]

theorem envBound29839 : H12AffineFastState.Bounded env29839 := by
  intro p hp
  have h : env29839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29838_29839 : H12AffineEnvironment.transform 8 318 env29838 = env29839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 318 env29838 == env29839) = true)

theorem identity29839 : scanCanonicalize (H12AffineFastState.compose env29839 (packedSelected [0,1,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound29839 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env29840 : List Nat := [2,4,8,16,32,16,8,37,27,53,2048,2065,41,2049,0,34,2065,2048,53,1,2049,33,17,3,41,17,2049,2064,2064,2049,21,32,37,32,2049,26]

theorem envBound29840 : H12AffineFastState.Bounded env29840 := by
  intro p hp
  have h : env29840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29839_29840 : H12AffineEnvironment.transform 7 37 env29839 = env29840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env29839 == env29840) = true)

theorem identity29840 : scanCanonicalize (H12AffineFastState.compose env29840 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound29840 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29841 : List Nat := [2,4,8,16,32,16,8,37,27,53,10,27,41,11,0,34,27,10,53,1,11,33,17,3,41,17,11,26,26,11,21,32,37,32,11,26]

theorem envBound29841 : H12AffineFastState.Bounded env29841 := by
  intro p hp
  have h : env29841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29840_29841 : H12AffineEnvironment.transform 10 10 env29840 = env29841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env29840 == env29841) = true)

theorem identity29841 : scanCanonicalize (H12AffineFastState.compose env29841 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound29841 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29842 : List Nat := [2,4,2,16,32,16,2,37,17,53,0,17,35,1,0,34,17,0,53,1,1,33,17,3,35,17,1,16,16,1,21,32,37,32,1,16]

theorem envBound29842 : H12AffineFastState.Bounded env29842 := by
  intro p hp
  have h : env29842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29841_29842 : H12AffineEnvironment.transform 2 2 env29841 = env29842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env29841 == env29842) = true)

theorem identity29842 : scanCanonicalize (H12AffineFastState.compose env29842 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound29842 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29843 : List Nat := [2,4,2,16,16,16,2,21,17,5,0,17,19,1,0,18,17,0,5,1,1,17,17,3,19,17,1,16,16,1,21,16,21,16,1,16]

theorem envBound29843 : H12AffineFastState.Bounded env29843 := by
  intro p hp
  have h : env29843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29842_29843 : H12AffineEnvironment.transform 4 16 env29842 = env29843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env29842 == env29843) = true)

theorem identity29843 : scanCanonicalize (H12AffineFastState.compose env29843 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29843 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env29844 : List Nat := [2,4,2,1,1,1,2,4,0,5,0,0,2,1,0,3,0,0,5,1,1,0,0,3,2,0,1,1,1,1,4,1,4,1,1,1]

theorem envBound29844 : H12AffineFastState.Bounded env29844 := by
  intro p hp
  have h : env29844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29843_29844 : H12AffineEnvironment.transform 3 1 env29843 = env29844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29843 == env29844) = true)

def env29845 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212078,1024,32769,77899,201831,119879,95496,8193,65,215366,115015,45404,10281,75103,144492,256,21792,46093,513]

theorem envBound29845 : H12AffineFastState.Bounded env29845 := by
  intro p hp
  have h : env29845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29829_29845 : H12AffineEnvironment.transform 6 9 env29829 = env29845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29829 == env29845) = true)

theorem identity29845 : scanCanonicalize (H12AffineFastState.compose env29845 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound29845 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env29846 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70726,10280,1024,32769,77899,33,119879,95496,8193,65,23808,115015,45404,10281,75103,73770,256,21792,46093,513]

theorem envBound29846 : H12AffineFastState.Bounded env29846 := by
  intro p hp
  have h : env29846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29845_29846 : H12AffineEnvironment.transform 16 70726 env29845 = env29846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env29845 == env29846) = true)

theorem identity29846 : scanCanonicalize (H12AffineFastState.compose env29846 (packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound29846 : packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env29847 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,70726,10280,1024,8541,77899,33,95515,95496,8193,65,23808,90139,4096,10281,75103,73770,256,21792,5457,513]

theorem envBound29847 : H12AffineFastState.Bounded env29847 := by
  intro p hp
  have h : env29847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29846_29847 : H12AffineEnvironment.transform 14 8540 env29846 = env29847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env29846 == env29847) = true)

theorem identity29847 : scanCanonicalize (H12AffineFastState.compose env29847 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound29847 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env29848 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,21591,16401,10280,1024,8541,25628,33,8524,8543,8193,65,23808,13388,4096,10281,28936,29821,256,21792,5457,513]

theorem envBound29848 : H12AffineFastState.Bounded env29848 := by
  intro p hp
  have h : env29848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29847_29848 : H12AffineEnvironment.transform 15 21591 env29847 = env29848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env29847 == env29848) = true)

theorem identity29848 : scanCanonicalize (H12AffineFastState.compose env29848 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound29848 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29849 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,0,21591,16401,2420,1024,1,17728,33,16,3,349,65,23808,5392,4096,2421,20564,21793,256,21792,5457,513]

theorem envBound29849 : H12AffineFastState.Bounded env29849 := by
  intro p hp
  have h : env29849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29848_29849 : H12AffineEnvironment.transform 12 348 env29848 = env29849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env29848 == env29849) = true)

theorem identity29849 : scanCanonicalize (H12AffineFastState.compose env29849 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound29849 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env29850 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,0,342,5392,2420,1024,1,4161,33,16,3,349,65,2049,5392,4096,2421,1365,32,256,33,5457,513]

theorem envBound29850 : H12AffineFastState.Bounded env29850 := by
  intro p hp
  have h : env29850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29849_29850 : H12AffineEnvironment.transform 13 5377 env29849 = env29850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env29849 == env29850) = true)

theorem identity29850 : scanCanonicalize (H12AffineFastState.compose env29850 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound29850 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29851 : List Nat := [2,4,8,16,32,64,9,256,512,564,2048,4096,348,4917,0,342,4900,2420,564,1,4161,33,16,3,349,65,2049,4900,4096,2421,865,32,256,33,4965,513]

theorem envBound29851 : H12AffineFastState.Bounded env29851 := by
  intro p hp
  have h : env29851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29850_29851 : H12AffineEnvironment.transform 9 564 env29850 = env29851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env29850 == env29851) = true)

theorem identity29851 : scanCanonicalize (H12AffineFastState.compose env29851 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29851 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29852 : List Nat := [2,4,8,16,32,17,9,256,512,564,2048,4096,269,4917,0,263,4900,2341,564,1,4112,33,16,3,268,16,2049,4900,4096,2340,816,32,256,33,4916,513]

theorem envBound29852 : H12AffineFastState.Bounded env29852 := by
  intro p hp
  have h : env29852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29851_29852 : H12AffineEnvironment.transform 5 17 env29851 = env29852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29851 == env29852) = true)

theorem identity29852 : scanCanonicalize (H12AffineFastState.compose env29852 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound29852 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29853 : List Nat := [2,4,8,16,32,17,9,256,512,564,2048,512,269,309,0,263,292,2341,564,1,528,33,16,3,268,16,2049,292,512,2340,816,32,256,33,308,513]

theorem envBound29853 : H12AffineFastState.Bounded env29853 := by
  intro p hp
  have h : env29853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29852_29853 : H12AffineEnvironment.transform 11 512 env29852 = env29853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env29852 == env29853) = true)

theorem identity29853 : scanCanonicalize (H12AffineFastState.compose env29853 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 820) := by decide +kernel

theorem selectedBound29853 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29854 : List Nat := [2,4,8,16,32,17,9,256,512,564,820,512,269,309,0,263,292,529,564,1,528,33,16,3,268,16,821,292,512,528,816,32,256,33,308,513]

theorem envBound29854 : H12AffineFastState.Bounded env29854 := by
  intro p hp
  have h : env29854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29853_29854 : H12AffineEnvironment.transform 10 820 env29853 = env29854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 820 env29853 == env29854) = true)

theorem identity29854 : scanCanonicalize (H12AffineFastState.compose env29854 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound29854 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env29855 : List Nat := [2,4,8,16,32,17,9,256,292,272,16,292,269,309,0,263,292,309,272,1,308,33,16,3,268,16,17,292,292,308,20,32,256,33,308,293]

theorem envBound29855 : H12AffineFastState.Bounded env29855 := by
  intro p hp
  have h : env29855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29854_29855 : H12AffineEnvironment.transform 8 292 env29854 = env29855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env29854 == env29855) = true)

theorem identity29855 : scanCanonicalize (H12AffineFastState.compose env29855 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound29855 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env29856 : List Nat := [2,4,8,16,17,17,9,256,277,272,16,277,269,260,0,263,277,260,272,1,261,16,16,3,268,16,17,277,277,261,20,17,256,16,261,276]

theorem envBound29856 : H12AffineFastState.Bounded env29856 := by
  intro p hp
  have h : env29856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29855_29856 : H12AffineEnvironment.transform 4 17 env29855 = env29856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env29855 == env29856) = true)

theorem identity29856 : scanCanonicalize (H12AffineFastState.compose env29856 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound29856 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env29857 : List Nat := [2,4,8,16,17,17,9,21,0,5,16,0,24,17,0,18,0,17,5,1,16,16,16,3,25,16,17,0,0,16,20,17,21,16,16,1]

theorem envBound29857 : H12AffineFastState.Bounded env29857 := by
  intro p hp
  have h : env29857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29856_29857 : H12AffineEnvironment.transform 7 21 env29856 = env29857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env29856 == env29857) = true)

def env29858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,272513,452768,95496,8328,65,292137,458144,45525,10400,399800,144493,256,21792,46212,474735]

theorem envBound29858 : H12AffineFastState.Bounded env29858 := by
  intro p hp
  have h : env29858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29827_29858 : H12AffineEnvironment.transform 21 272513 env29827 = env29858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env29827 == env29858) = true)

theorem identity29858 : scanCanonicalize (H12AffineFastState.compose env29858 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound29858 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,396325,272513,452768,41430,8328,65,292137,458144,45525,10400,399800,144493,256,21792,46212,453297]

theorem envBound29859 : H12AffineFastState.Bounded env29859 := by
  intro p hp
  have h : env29859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29858_29859 : H12AffineEnvironment.transform 15 54494 env29858 = env29859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env29858 == env29859) = true)

def env29860 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,396325,272393,452648,41310,8192,65,292137,458024,45405,10280,399664,144493,256,21792,46092,453177]

theorem envBound29860 : H12AffineFastState.Bounded env29860 := by
  intro p hp
  have h : env29860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29859_29860 : H12AffineEnvironment.transform 6 8 env29859 = env29860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29859 == env29860) = true)

theorem identity29860 : scanCanonicalize (H12AffineFastState.compose env29860 (packedSelected [0,1,3,4,8,11,14,16,17,19,22,24,26,27,31,32,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 21541) := by decide +kernel

theorem selectedBound29860 : packedSelected [0,1,3,4,8,11,14,16,17,19,22,24,26,27,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env29861 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21541,115,131072,262144,1024,21540,396325,272393,408589,30075,8192,65,292137,403725,25976,10280,399664,144493,256,21792,24617,409116]

theorem envBound29861 : H12AffineFastState.Bounded env29861 := by
  intro p hp
  have h : env29861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29860_29861 : H12AffineEnvironment.transform 14 21541 env29860 = env29861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21541 env29860 == env29861) = true)

theorem identity29861 : scanCanonicalize (H12AffineFastState.compose env29861 (packedSelected [1,3,4,9,10,18,19,20,23,24,26,28,31,35] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29861 : packedSelected [1,3,4,9,10,18,19,20,23,24,26,28,31,35] rootPS < 2^1333 := by decide +kernel

def env29862 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,21541,34,131072,262144,1024,21540,396325,272393,408589,29994,8192,16,292137,403725,25897,10280,399664,144444,256,21792,24617,409116]

theorem envBound29862 : H12AffineFastState.Bounded env29862 := by
  intro p hp
  have h : env29862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29861_29862 : H12AffineEnvironment.transform 5 17 env29861 = env29862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29861 == env29862) = true)

theorem identity29862 : scanCanonicalize (H12AffineFastState.compose env29862 (packedSelected [0,7,9,14,17,20,22] rootPS)) = affineNative (2^(17+1) ^^^ 146745) := by decide +kernel

theorem selectedBound29862 : packedSelected [0,7,9,14,17,20,22] rootPS < 2^1333 := by decide +kernel

def env29863 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,21541,34,131072,146745,1024,21540,12572,136496,308,29994,8192,16,149520,5172,25897,10280,9225,144444,256,21792,24617,805]

theorem envBound29863 : H12AffineFastState.Bounded env29863 := by
  intro p hp
  have h : env29863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29862_29863 : H12AffineEnvironment.transform 17 146745 env29862 = env29863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146745 env29862 == env29863) = true)

theorem identity29863 : scanCanonicalize (H12AffineFastState.compose env29863 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound29863 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env29864 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,21541,34,24861,23588,1024,21540,12572,29741,308,29994,8192,16,10509,5172,25897,10280,9225,21793,256,21792,24617,805]

theorem envBound29864 : H12AffineFastState.Bounded env29864 := by
  intro p hp
  have h : env29864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29863_29864 : H12AffineEnvironment.transform 16 24861 env29863 = env29864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env29863 == env29864) = true)

theorem identity29864 : scanCanonicalize (H12AffineFastState.compose env29864 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound29864 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env29865 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,21541,34,16400,23588,1024,21540,4113,21792,308,21543,269,16,2048,5172,17444,2341,1284,21793,256,21792,16676,805]

theorem envBound29865 : H12AffineFastState.Bounded env29865 := by
  intro p hp
  have h : env29865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29864_29865 : H12AffineEnvironment.transform 12 269 env29864 = env29865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env29864 == env29865) = true)

theorem identity29865 : scanCanonicalize (H12AffineFastState.compose env29865 (packedSelected [0,4,6,7,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound29865 : packedSelected [0,4,6,7,9,11] rootPS < 2^1333 := by decide +kernel

def env29866 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,4096,269,16384,20788,34,16400,22837,273,20789,4113,20529,308,20790,269,16,2048,4389,16693,2341,21,20528,256,20529,16676,805]

theorem envBound29866 : H12AffineFastState.Bounded env29866 := by
  intro p hp
  have h : env29866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29865_29866 : H12AffineEnvironment.transform 9 273 env29865 = env29866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env29865 == env29866) = true)

def env29867 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,396325,272392,452649,41311,8193,65,292137,458025,45404,10281,399665,144493,256,21792,46093,453176]

theorem envBound29867 : H12AffineFastState.Bounded env29867 := by
  intro p hp
  have h : env29867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29859_29867 : H12AffineEnvironment.transform 6 9 env29859 = env29867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29859 == env29867) = true)

theorem identity29867 : scanCanonicalize (H12AffineFastState.compose env29867 (packedSelected [0,1,3,4,8,11,14,16,17,19,22,24,26,27,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 171061) := by decide +kernel

theorem selectedBound29867 : packedSelected [0,1,3,4,8,11,14,16,17,19,22,24,26,27,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env29868 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,171061,1024,32769,36880,177213,29724,41311,8193,65,190748,24860,45404,10281,34052,144493,256,21792,46093,30221]

theorem envBound29868 : H12AffineFastState.Bounded env29868 := by
  intro p hp
  have h : env29868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29867_29868 : H12AffineEnvironment.transform 17 171061 env29867 = env29868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171061 env29867 == env29868) = true)

theorem identity29868 : scanCanonicalize (H12AffineFastState.compose env29868 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound29868 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env29869 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,49169,23588,1024,32769,36880,29740,29724,41311,8193,65,10509,24860,45404,10281,34052,62588,256,21792,46093,30221]

theorem envBound29869 : H12AffineFastState.Bounded env29869 := by
  intro p hp
  have h : env29869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29868_29869 : H12AffineEnvironment.transform 16 49169 env29868 = env29869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env29868 == env29869) = true)

theorem identity29869 : scanCanonicalize (H12AffineFastState.compose env29869 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound29869 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29870 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,32768,41051,46109,10280,1024,32769,36880,32,16,41311,8193,65,10509,5392,45404,10281,34052,32880,256,8492,46093,513]

theorem envBound29870 : H12AffineFastState.Bounded env29870 := by
  intro p hp
  have h : env29870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29869_29870 : H12AffineEnvironment.transform 13 13324 env29869 = env29870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env29869 == env29870) = true)

theorem identity29870 : scanCanonicalize (H12AffineFastState.compose env29870 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound29870 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env29871 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8461,342,5392,10280,1024,8460,12573,32,16,82,8193,65,10509,5392,4177,10281,9225,8573,256,8492,5376,513]

theorem envBound29871 : H12AffineFastState.Bounded env29871 := by
  intro p hp
  have h : env29871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29870_29871 : H12AffineEnvironment.transform 14 8461 env29870 = env29871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env29870 == env29871) = true)

theorem identity29871 : scanCanonicalize (H12AffineFastState.compose env29871 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound29871 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29872 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,0,342,5392,2341,1024,1,4112,32,16,82,268,65,2048,5392,4177,2340,1284,112,256,33,5376,513]

theorem envBound29872 : H12AffineFastState.Bounded env29872 := by
  intro p hp
  have h : env29872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29871_29872 : H12AffineEnvironment.transform 12 269 env29871 = env29872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env29871 == env29872) = true)

theorem identity29872 : scanCanonicalize (H12AffineFastState.compose env29872 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29872 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env29873 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,0,263,5392,2341,1024,1,4112,32,16,3,268,16,2048,5392,4096,2340,1284,33,256,33,5376,513]

theorem envBound29873 : H12AffineFastState.Bounded env29873 := by
  intro p hp
  have h : env29873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29872_29873 : H12AffineEnvironment.transform 5 17 env29872 = env29873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29872 == env29873) = true)

theorem identity29873 : scanCanonicalize (H12AffineFastState.compose env29873 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1328) := by decide +kernel

theorem selectedBound29873 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29874 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1328,269,49,0,263,32,2341,1024,1,1312,32,16,3,268,16,2048,32,1328,2340,1284,33,256,33,48,513]

theorem envBound29874 : H12AffineFastState.Bounded env29874 := by
  intro p hp
  have h : env29874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29873_29874 : H12AffineEnvironment.transform 11 1328 env29873 = env29874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1328 env29873 == env29874) = true)

theorem identity29874 : scanCanonicalize (H12AffineFastState.compose env29874 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound29874 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29875 : List Nat := [2,4,8,16,32,17,9,256,276,1024,2048,1328,269,49,0,263,32,2341,1024,1,1312,32,16,3,268,16,2048,32,1328,2340,1284,33,256,33,48,277]

theorem envBound29875 : H12AffineFastState.Bounded env29875 := by
  intro p hp
  have h : env29875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29874_29875 : H12AffineEnvironment.transform 8 276 env29874 = env29875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env29874 == env29875) = true)

theorem identity29875 : scanCanonicalize (H12AffineFastState.compose env29875 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound29875 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29876 : List Nat := [2,4,8,16,32,17,9,256,276,1024,1076,1328,269,49,0,263,32,1297,1024,1,1312,32,16,3,268,16,1076,32,1328,1296,1284,33,256,33,48,277]

theorem envBound29876 : H12AffineFastState.Bounded env29876 := by
  intro p hp
  have h : env29876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29875_29876 : H12AffineEnvironment.transform 10 1076 env29875 = env29876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env29875 == env29876) = true)

theorem identity29876 : scanCanonicalize (H12AffineFastState.compose env29876 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound29876 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env29877 : List Nat := [2,4,8,16,32,17,9,256,276,305,261,1,269,49,0,263,32,32,305,1,17,32,16,3,268,16,261,32,1,33,53,33,256,33,48,277]

theorem envBound29877 : H12AffineFastState.Bounded env29877 := by
  intro p hp
  have h : env29877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29876_29877 : H12AffineEnvironment.transform 9 305 env29876 = env29877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env29876 == env29877) = true)

def env29878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,4194304,452769,95497,8328,65,4218280,458145,45524,10401,399800,4594925,256,21792,46212,474735]

theorem envBound29878 : H12AffineFastState.Bounded env29878 := by
  intro p hp
  have h : env29878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29826_29878 : H12AffineEnvironment.transform 22 452769 env29826 = env29878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452769 env29826 == env29878) = true)

def env29879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,272512,452769,95497,8328,65,292136,458145,45524,10401,399800,144493,256,21792,46212,474735]

theorem envBound29879 : H12AffineFastState.Bounded env29879 := by
  intro p hp
  have h : env29879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29878_29879 : H12AffineEnvironment.transform 21 272512 env29878 = env29879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env29878 == env29879) = true)

theorem identity29879 : scanCanonicalize (H12AffineFastState.compose env29879 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247994) := by decide +kernel

theorem selectedBound29879 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,115871,254010,73755,95497,8328,65,245138,79131,45524,10401,119042,144493,256,21792,46212,63189]

theorem envBound29880 : H12AffineFastState.Bounded env29880 := by
  intro p hp
  have h : env29880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29879_29880 : H12AffineEnvironment.transform 17 247994 env29879 = env29880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247994 env29879 == env29880) = true)

def env29881 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,67754,1024,32769,115871,73770,73755,95497,8328,65,97666,79131,45524,10401,119042,62589,256,21792,46212,63189]

theorem envBound29881 : H12AffineFastState.Bounded env29881 := by
  intro p hp
  have h : env29881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29880_29881 : H12AffineEnvironment.transform 16 49168 env29880 = env29881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env29880 == env29881) = true)

theorem identity29881 : scanCanonicalize (H12AffineFastState.compose env29881 (packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound29881 : packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS < 2^1333 := by decide +kernel

def env29882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,65536,5393,67754,1024,21760,70046,73770,73755,95497,8328,65,97666,79131,25813,10401,66563,8572,256,21792,24965,9172]

theorem envBound29882 : H12AffineFastState.Bounded env29882 := by
  intro p hp
  have h : env29882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29881_29882 : H12AffineEnvironment.transform 14 21761 env29881 = env29882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env29881 == env29882) = true)

theorem identity29882 : scanCanonicalize (H12AffineFastState.compose env29882 (packedSelected [3,4,7,9,10,14,24,26,27,35] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound29882 : packedSelected [3,4,7,9,10,14,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env29883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,21761,65536,5393,67754,1024,21760,70046,65910,65863,87125,468,65,89310,70727,17801,2557,66563,32,256,21792,16601,648]

theorem envBound29883 : H12AffineFastState.Bounded env29883 := by
  intro p hp
  have h : env29883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29882_29883 : H12AffineEnvironment.transform 12 348 env29882 = env29883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env29882 == env29883) = true)

theorem identity29883 : scanCanonicalize (H12AffineFastState.compose env29883 (packedSelected [0,2,3,6,7,10,20,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound29883 : packedSelected [0,2,3,6,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env29884 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,21761,478,5393,2420,1024,21760,4160,168,153,21899,468,65,23808,5529,17801,2557,1501,32,256,21792,16601,648]

theorem envBound29884 : H12AffineFastState.Bounded env29884 := by
  intro p hp
  have h : env29884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29883_29884 : H12AffineEnvironment.transform 15 478 env29883 = env29884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env29883 == env29884) = true)

theorem identity29884 : scanCanonicalize (H12AffineFastState.compose env29884 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound29884 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,0,478,5393,2420,1024,1,4160,168,153,138,468,65,2049,5529,4232,2557,1501,32,256,33,5592,648]

theorem envBound29885 : H12AffineFastState.Bounded env29885 := by
  intro p hp
  have h : env29885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29884_29885 : H12AffineEnvironment.transform 13 5377 env29884 = env29885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env29884 == env29885) = true)

theorem identity29885 : scanCanonicalize (H12AffineFastState.compose env29885 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound29885 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env29886 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,348,5377,0,478,5393,2389,1024,1,4160,137,153,138,468,65,2049,5529,4232,2524,1501,1,256,0,5592,648]

theorem envBound29886 : H12AffineFastState.Bounded env29886 := by
  intro p hp
  have h : env29886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29885_29886 : H12AffineEnvironment.transform 4 1 env29885 = env29886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env29885 == env29886) = true)

theorem identity29886 : scanCanonicalize (H12AffineFastState.compose env29886 (packedSelected [0,1,2,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound29886 : packedSelected [0,1,2,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env29887 : List Nat := [2,4,8,16,1,64,89,256,512,1024,2048,4096,348,5377,0,263,5393,2389,1024,1,4160,80,64,83,269,65,2049,5440,4177,2309,1284,1,256,0,5377,593]

theorem envBound29887 : H12AffineFastState.Bounded env29887 := by
  intro p hp
  have h : env29887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29886_29887 : H12AffineEnvironment.transform 6 89 env29886 = env29887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env29886 == env29887) = true)

theorem identity29887 : scanCanonicalize (H12AffineFastState.compose env29887 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound29887 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env29888 : List Nat := [2,4,8,16,1,64,89,4,512,1024,2048,4096,88,5125,0,3,5141,2129,1024,1,4160,80,64,83,9,65,2049,5188,4177,2049,1024,1,4,0,5125,593]

theorem envBound29888 : H12AffineFastState.Bounded env29888 := by
  intro p hp
  have h : env29888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29887_29888 : H12AffineEnvironment.transform 7 4 env29887 = env29888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env29887 == env29888) = true)

theorem identity29888 : scanCanonicalize (H12AffineFastState.compose env29888 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29888 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env29889 : List Nat := [2,4,8,16,1,17,8,4,512,1024,2048,4096,9,5125,0,3,5141,2048,1024,1,4113,1,17,2,9,16,2049,5141,4096,2049,1024,1,4,0,5125,512]

theorem envBound29889 : H12AffineFastState.Bounded env29889 := by
  intro p hp
  have h : env29889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29888_29889 : H12AffineEnvironment.transform 5 17 env29888 = env29889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29888 == env29889) = true)

def env29890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,67755,1024,32769,115871,73771,73755,95497,8328,65,97667,79131,45524,10401,119042,62588,256,21792,46212,63189]

theorem envBound29890 : H12AffineFastState.Bounded env29890 := by
  intro p hp
  have h : env29890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29880_29890 : H12AffineEnvironment.transform 16 49169 env29880 = env29890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env29880 == env29890) = true)

theorem identity29890 : scanCanonicalize (H12AffineFastState.compose env29890 (packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound29890 : packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS < 2^1333 := by decide +kernel

def env29891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,25029,67755,1024,8661,91467,73771,73755,95497,8328,65,97667,79131,4096,10401,94422,21928,256,21792,5456,22273]

theorem envBound29891 : H12AffineFastState.Bounded env29891 := by
  intro p hp
  have h : env29891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29890_29891 : H12AffineEnvironment.transform 14 8660 env29890 = env29891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env29890 == env29891) = true)

theorem identity29891 : scanCanonicalize (H12AffineFastState.compose env29891 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound29891 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29892 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,30083,25029,32040,1024,8661,4296,21928,21912,138,8328,65,2048,16536,4096,10401,1365,21928,256,21792,5456,22273]

theorem envBound29892 : H12AffineFastState.Bounded env29892 := by
  intro p hp
  have h : env29892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29891_29892 : H12AffineEnvironment.transform 15 30083 env29891 = env29892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env29891 == env29892) = true)

theorem identity29892 : scanCanonicalize (H12AffineFastState.compose env29892 (packedSelected [0,4,7,16,18,20,22,23] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound29892 : packedSelected [0,4,7,16,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env29893 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,8461,30042,24860,32040,1024,8460,4113,21873,21825,83,8273,65,2048,16449,4096,10360,1365,21873,256,21792,5456,22273]

theorem envBound29893 : H12AffineFastState.Bounded env29893 := by
  intro p hp
  have h : env29893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29892_29893 : H12AffineEnvironment.transform 6 89 env29892 = env29893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env29892 == env29893) = true)

theorem identity29893 : scanCanonicalize (H12AffineFastState.compose env29893 (packedSelected [0,2,4,6,7,9,10,11,12,15,16,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound29893 : packedSelected [0,2,4,6,7,9,10,11,12,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env29894 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,5456,8461,8202,13388,10360,1024,8460,4113,33,17,83,8273,65,2048,5393,4096,10360,1365,33,256,112,5456,593]

theorem envBound29894 : H12AffineFastState.Bounded env29894 := by
  intro p hp
  have h : env29894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29893_29894 : H12AffineEnvironment.transform 13 5456 env29893 = env29894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env29893 == env29894) = true)

theorem identity29894 : scanCanonicalize (H12AffineFastState.compose env29894 (packedSelected [0,1,4,6,7,8,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound29894 : packedSelected [0,1,4,6,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env29895 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5456,1,262,5440,2420,1024,0,4113,33,17,83,349,65,2048,5393,4096,2420,1365,33,256,112,5456,593]

theorem envBound29895 : H12AffineFastState.Bounded env29895 := by
  intro p hp
  have h : env29895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29894_29895 : H12AffineEnvironment.transform 12 268 env29894 = env29895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env29894 == env29895) = true)

theorem identity29895 : scanCanonicalize (H12AffineFastState.compose env29895 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound29895 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env29896 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,2405,268,3125,1,262,3109,2420,1024,0,2420,33,17,83,349,65,2048,3188,2405,2420,1365,33,256,112,3125,593]

theorem envBound29896 : H12AffineFastState.Bounded env29896 := by
  intro p hp
  have h : env29896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29895_29896 : H12AffineEnvironment.transform 11 2405 env29895 = env29896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env29895 == env29896) = true)

theorem identity29896 : scanCanonicalize (H12AffineFastState.compose env29896 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 340) := by decide +kernel

theorem selectedBound29896 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env29897 : List Nat := [2,4,8,16,32,64,89,256,512,1024,340,49,268,1377,1,262,1393,32,1024,0,32,33,17,83,349,65,340,1312,49,32,1365,33,256,112,1377,593]

theorem envBound29897 : H12AffineFastState.Bounded env29897 := by
  intro p hp
  have h : env29897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29896_29897 : H12AffineEnvironment.transform 10 340 env29896 = env29897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 340 env29896 == env29897) = true)

theorem identity29897 : scanCanonicalize (H12AffineFastState.compose env29897 (packedSelected [0,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29897 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env29898 : List Nat := [2,4,8,16,32,16,9,256,512,1024,260,49,268,1329,1,262,1313,32,1024,0,32,33,17,3,269,17,260,1312,49,32,1285,33,256,32,1329,513]

theorem envBound29898 : H12AffineFastState.Bounded env29898 := by
  intro p hp
  have h : env29898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29897_29898 : H12AffineEnvironment.transform 5 16 env29897 = env29898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29897 == env29898) = true)

theorem identity29898 : scanCanonicalize (H12AffineFastState.compose env29898 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound29898 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29899 : List Nat := [2,4,8,16,32,16,9,256,512,5,260,49,268,308,1,262,292,32,5,0,32,33,17,3,269,17,260,293,49,32,256,33,256,32,308,513]

theorem envBound29899 : H12AffineFastState.Bounded env29899 := by
  intro p hp
  have h : env29899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29898_29899 : H12AffineEnvironment.transform 9 5 env29898 = env29899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env29898 == env29899) = true)

theorem identity29899 : scanCanonicalize (H12AffineFastState.compose env29899 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound29899 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29900 : List Nat := [2,4,8,16,32,16,9,14,512,5,10,49,2,58,1,8,42,32,5,0,32,33,17,3,3,17,10,43,49,32,14,33,14,32,58,513]

theorem envBound29900 : H12AffineFastState.Bounded env29900 := by
  intro p hp
  have h : env29900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29899_29900 : H12AffineEnvironment.transform 7 14 env29899 = env29900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env29899 == env29900) = true)

def env29901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,272513,452769,95497,8328,65,292137,458145,45524,10401,399800,144492,256,21792,46212,474735]

theorem envBound29901 : H12AffineFastState.Bounded env29901 := by
  intro p hp
  have h : env29901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29878_29901 : H12AffineEnvironment.transform 21 272513 env29878 = env29901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env29878 == env29901) = true)

theorem identity29901 : scanCanonicalize (H12AffineFastState.compose env29901 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound29901 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,396325,272513,452769,21762,8328,65,292137,458145,45524,10401,399800,144492,256,21792,46212,400996]

theorem envBound29902 : H12AffineFastState.Bounded env29902 := by
  intro p hp
  have h : env29902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29901_29902 : H12AffineEnvironment.transform 15 8203 env29901 = env29902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env29901 == env29902) = true)

def env29903 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,396325,272393,452649,21762,8192,65,292137,458025,45404,10281,399664,144492,256,21792,46092,400996]

theorem envBound29903 : H12AffineFastState.Bounded env29903 := by
  intro p hp
  have h : env29903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29902_29903 : H12AffineEnvironment.transform 6 8 env29902 = env29903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29902 == env29903) = true)

theorem identity29903 : scanCanonicalize (H12AffineFastState.compose env29903 (packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 46393) := by decide +kernel

theorem selectedBound29903 : packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS < 2^1333 := by decide +kernel

def env29904 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,46393,262144,1024,32769,309532,272393,285968,21762,8192,65,292137,280592,45404,10281,306185,33109,256,21792,46092,306013]

theorem envBound29904 : H12AffineFastState.Bounded env29904 := by
  intro p hp
  have h : env29904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29903_29904 : H12AffineEnvironment.transform 16 46393 env29903 = env29904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46393 env29903 == env29904) = true)

theorem identity29904 : scanCanonicalize (H12AffineFastState.compose env29904 (packedSelected [0,2,4,7,8,10,11,12,14,15,17,22,23,28] rootPS)) = affineNative (2^(17+1) ^^^ 64605) := by decide +kernel

theorem selectedBound29904 : packedSelected [0,2,4,7,8,10,11,12,14,15,17,22,23,28] rootPS < 2^1333 := by decide +kernel

def env29905 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,46393,64605,1024,32769,17729,54356,41293,21762,8192,65,35188,46157,45404,10281,20564,33109,256,21792,46092,22272]

theorem envBound29905 : H12AffineFastState.Bounded env29905 := by
  intro p hp
  have h : env29905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29904_29905 : H12AffineEnvironment.transform 17 64605 env29904 = env29905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64605 env29904 == env29905) = true)

theorem identity29905 : scanCanonicalize (H12AffineFastState.compose env29905 (packedSelected [0,2,6,7,11,16,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound29905 : packedSelected [0,2,6,7,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env29906 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,46393,43357,1024,32769,4161,33108,41293,2,8192,65,35188,46157,45404,10281,1364,33109,256,32,46092,512]

theorem envBound29906 : H12AffineFastState.Bounded env29906 := by
  intro p hp
  have h : env29906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29905_29906 : H12AffineEnvironment.transform 13 5376 env29905 = env29906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env29905 == env29906) = true)

def env29907 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,396325,272392,452648,21762,8193,65,292137,458024,45405,10280,399665,144492,256,21792,46093,400996]

theorem envBound29907 : H12AffineFastState.Bounded env29907 := by
  intro p hp
  have h : env29907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29902_29907 : H12AffineEnvironment.transform 6 9 env29902 = env29907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29902 == env29907) = true)

theorem identity29907 : scanCanonicalize (H12AffineFastState.compose env29907 (packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 23668) := by decide +kernel

theorem selectedBound29907 : packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS < 2^1333 := by decide +kernel

def env29908 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,23668,1024,32769,151633,29820,177244,21762,8193,65,10589,172380,45405,10280,148805,144492,256,21792,46093,147984]

theorem envBound29908 : H12AffineFastState.Bounded env29908 := by
  intro p hp
  have h : env29908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29907_29908 : H12AffineEnvironment.transform 17 23668 env29907 = env29908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23668 env29907 == env29908) = true)

theorem identity29908 : scanCanonicalize (H12AffineFastState.compose env29908 (packedSelected [0,4,8,10,12,14,15,18,20,22,23,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound29908 : packedSelected [0,4,8,10,12,14,15,18,20,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env29909 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,8203,131072,23668,1024,21761,151633,29820,155996,21762,8193,65,10589,160860,25693,10280,148805,144492,256,21792,24845,147984]

theorem envBound29909 : H12AffineFastState.Bounded env29909 := by
  intro p hp
  have h : env29909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29908_29909 : H12AffineEnvironment.transform 14 21760 env29908 = env29909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env29908 == env29909) = true)

def env29910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,4194304,8388608,8887721,8328,65,4218281,8393985,8804725,8830976,399801,12645453,256,21793,46213,474734]

theorem envBound29910 : H12AffineFastState.Bounded env29910 := by
  intro p hp
  have h : env29910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29825_29910 : H12AffineEnvironment.transform 23 8887721 env29825 = env29910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8887721 env29825 == env29910) = true)

def env29911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,4194304,452768,95497,8328,65,4218281,458145,45525,10400,399801,4594925,256,21793,46213,474734]

theorem envBound29911 : H12AffineFastState.Bounded env29911 := by
  intro p hp
  have h : env29911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29910_29911 : H12AffineEnvironment.transform 22 452768 env29910 = env29911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452768 env29910 == env29911) = true)

def env29912 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,272512,452768,95497,8328,65,292137,458145,45525,10400,399801,144493,256,21793,46213,474734]

theorem envBound29912 : H12AffineFastState.Bounded env29912 := by
  intro p hp
  have h : env29912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29911_29912 : H12AffineEnvironment.transform 21 272512 env29911 = env29912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env29911 == env29912) = true)

def env29913 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,272392,452648,95497,8192,65,292137,458025,45405,10280,399665,144493,256,21793,46093,474734]

theorem envBound29913 : H12AffineFastState.Bounded env29913 := by
  intro p hp
  have h : env29913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29912_29913 : H12AffineEnvironment.transform 6 8 env29912 = env29913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29912 == env29913) = true)

def env29914 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,314421,272392,272440,95497,8192,65,292137,277817,45405,10280,317729,62589,256,21793,46093,392830]

theorem envBound29914 : H12AffineFastState.Bounded env29914 := by
  intro p hp
  have h : env29914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29913_29914 : H12AffineEnvironment.transform 16 49168 env29913 = env29914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env29913 == env29914) = true)

theorem identity29914 : scanCanonicalize (H12AffineFastState.compose env29914 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound29914 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29915 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,49168,262144,1024,32769,314421,272392,272440,2,8192,65,292137,277817,45405,10280,317729,62589,256,21793,46093,297845]

theorem envBound29915 : H12AffineFastState.Bounded env29915 := by
  intro p hp
  have h : env29915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29914_29915 : H12AffineEnvironment.transform 15 29963 env29914 = env29915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env29914 == env29915) = true)

theorem identity29915 : scanCanonicalize (H12AffineFastState.compose env29915 (packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 56576) := by decide +kernel

theorem selectedBound29915 : packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env29916 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,49168,56576,1024,32769,4405,62728,62776,2,8192,65,43049,57401,45405,10280,1057,62589,256,21793,46093,22133]

theorem envBound29916 : H12AffineFastState.Bounded env29916 := by
  intro p hp
  have h : env29916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29915_29916 : H12AffineEnvironment.transform 17 56576 env29915 = env29916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56576 env29915 == env29916) = true)

theorem identity29916 : scanCanonicalize (H12AffineFastState.compose env29916 (packedSelected [2,6,7,9,11,16,18,22,27] rootPS)) = affineNative (2^(14+1) ^^^ 29993) := by decide +kernel

theorem selectedBound29916 : packedSelected [2,6,7,9,11,16,18,22,27] rootPS < 2^1333 := by decide +kernel

def env29917 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29993,29963,13625,10281,1024,29992,4405,33,17,2,8192,65,23808,5392,17524,10280,1057,340,256,21793,16676,22133]

theorem envBound29917 : H12AffineFastState.Bounded env29917 := by
  intro p hp
  have h : env29917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29916_29917 : H12AffineEnvironment.transform 14 29993 env29916 = env29917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29993 env29916 == env29917) = true)

theorem identity29917 : scanCanonicalize (H12AffineFastState.compose env29917 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound29917 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env29918 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,1,35,13625,10281,1024,0,4405,33,17,2,8192,65,10280,5392,12636,10280,1057,340,256,8201,13324,9053]

theorem envBound29918 : H12AffineFastState.Bounded env29918 := by
  intro p hp
  have h : env29918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29917_29918 : H12AffineEnvironment.transform 13 13608 env29917 = env29918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env29917 == env29918) = true)

theorem identity29918 : scanCanonicalize (H12AffineFastState.compose env29918 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound29918 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29919 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1337,4113,1,35,4096,3344,1024,0,4405,33,17,2,1337,65,3345,5392,5221,3345,1057,340,256,1328,4405,1636]

theorem envBound29919 : H12AffineFastState.Bounded env29919 := by
  intro p hp
  have h : env29919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29918_29919 : H12AffineEnvironment.transform 12 1337 env29918 = env29919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env29918 == env29919) = true)

theorem identity29919 : scanCanonicalize (H12AffineFastState.compose env29919 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound29919 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env29920 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,41,4113,1,35,4096,2048,272,0,4405,33,17,2,41,65,2049,4096,4469,2049,305,340,256,32,4405,884]

theorem envBound29920 : H12AffineFastState.Bounded env29920 := by
  intro p hp
  have h : env29920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29919_29920 : H12AffineEnvironment.transform 9 272 env29919 = env29920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env29919 == env29920) = true)

theorem identity29920 : scanCanonicalize (H12AffineFastState.compose env29920 (packedSelected [0,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound29920 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env29921 : List Nat := [2,4,8,16,32,64,8,117,512,101,2048,4096,41,4113,1,35,4096,2048,101,0,4160,33,17,2,41,65,2049,4096,4096,2049,68,33,117,32,4160,513]

theorem envBound29921 : H12AffineFastState.Bounded env29921 := by
  intro p hp
  have h : env29921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29920_29921 : H12AffineEnvironment.transform 7 117 env29920 = env29921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env29920 == env29921) = true)

theorem identity29921 : scanCanonicalize (H12AffineFastState.compose env29921 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29921 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29922 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,4096,41,4113,1,35,4096,2048,53,0,4112,33,17,2,41,17,2049,4096,4096,2049,20,33,37,32,4112,513]

theorem envBound29922 : H12AffineFastState.Bounded env29922 := by
  intro p hp
  have h : env29922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29921_29922 : H12AffineEnvironment.transform 5 16 env29921 = env29922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29921 == env29922) = true)

theorem identity29922 : scanCanonicalize (H12AffineFastState.compose env29922 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound29922 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29923 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,513,41,528,1,35,513,2048,53,0,529,33,17,2,41,17,2049,513,513,2049,20,33,37,32,529,513]

theorem envBound29923 : H12AffineFastState.Bounded env29923 := by
  intro p hp
  have h : env29923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29922_29923 : H12AffineEnvironment.transform 11 513 env29922 = env29923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env29922 == env29923) = true)

theorem identity29923 : scanCanonicalize (H12AffineFastState.compose env29923 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound29923 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29924 : List Nat := [2,4,8,16,32,16,8,37,512,53,10,513,41,528,1,35,513,10,53,0,529,33,17,2,41,17,11,513,513,11,20,33,37,32,529,513]

theorem envBound29924 : H12AffineFastState.Bounded env29924 := by
  intro p hp
  have h : env29924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29923_29924 : H12AffineEnvironment.transform 10 10 env29923 = env29924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env29923 == env29924) = true)

theorem identity29924 : scanCanonicalize (H12AffineFastState.compose env29924 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound29924 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env29925 : List Nat := [2,4,8,16,32,16,8,37,27,53,10,26,41,11,1,35,26,10,53,0,10,33,17,2,41,17,11,26,26,11,20,33,37,32,10,26]

theorem envBound29925 : H12AffineFastState.Bounded env29925 := by
  intro p hp
  have h : env29925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29924_29925 : H12AffineEnvironment.transform 8 27 env29924 = env29925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env29924 == env29925) = true)

def env29926 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,314420,272392,272441,95497,8192,65,292137,277816,45405,10280,317728,62588,256,21793,46093,392831]

theorem envBound29926 : H12AffineFastState.Bounded env29926 := by
  intro p hp
  have h : env29926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29913_29926 : H12AffineEnvironment.transform 16 49169 env29913 = env29926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env29913 == env29926) = true)

theorem identity29926 : scanCanonicalize (H12AffineFastState.compose env29926 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 89379) := by decide +kernel

theorem selectedBound29926 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29927 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,89379,1024,32769,102679,95531,95514,95497,8192,65,75786,90139,45405,10280,99331,62588,256,21793,46093,41820]

theorem envBound29927 : H12AffineFastState.Bounded env29927 := by
  intro p hp
  have h : env29927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29926_29927 : H12AffineEnvironment.transform 17 89379 env29926 = env29927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89379 env29926 == env29927) = true)

theorem identity29927 : scanCanonicalize (H12AffineFastState.compose env29927 (packedSelected [1,5,7,10,12,14,15,16,18,19,23,24,26,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 30072) := by decide +kernel

theorem selectedBound29927 : packedSelected [1,5,7,10,12,14,15,16,18,19,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env29928 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,30072,65536,13673,89379,1024,30073,91247,95531,95514,95497,8192,65,75786,90139,17445,10280,94587,260,256,21793,16757,22052]

theorem envBound29928 : H12AffineFastState.Bounded env29928 := by
  intro p hp
  have h : env29928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29927_29928 : H12AffineEnvironment.transform 14 30072 env29927 = env29928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30072 env29927 == env29928) = true)

theorem identity29928 : scanCanonicalize (H12AffineFastState.compose env29928 (packedSelected [0,1,2,5,6,7,8,11,16,23,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29928 : packedSelected [0,1,2,5,6,7,8,11,16,23,24] rootPS < 2^1333 := by decide +kernel

def env29929 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29992,65536,13625,89379,1024,29993,91199,95531,95514,95497,8192,17,75786,90139,17445,10280,94507,260,256,21793,16677,22052]

end H12CloudChart0