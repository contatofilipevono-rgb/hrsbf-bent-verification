import H12CloudChart0Data205

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity52153 : scanCanonicalize (H12AffineFastState.compose env52153 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound52153 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52154 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5157,1,263,5172,2341,1024,0,4404,33,16,2,268,17,2048,5173,4097,2341,1285,33,256,32,5157,513]

theorem envBound52154 : H12AffineFastState.Bounded env52154 := by
  intro p hp
  have h : env52154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52153_52154 : H12AffineEnvironment.transform 13 5157 env52153 = env52154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env52153 == env52154) = true)

def env52155 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3888,268,2837,1,263,2820,2341,1024,0,3588,33,16,2,268,17,2048,2821,3889,2341,1285,33,256,32,2837,513]

theorem envBound52155 : H12AffineFastState.Bounded env52155 := by
  intro p hp
  have h : env52155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52154_52155 : H12AffineEnvironment.transform 11 3888 env52154 = env52155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env52154 == env52155) = true)

def env52156 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,48,268,1045,1,263,1028,1573,1024,0,260,33,16,2,268,17,1792,1029,49,1573,1285,33,256,32,1045,513]

theorem envBound52156 : H12AffineFastState.Bounded env52156 := by
  intro p hp
  have h : env52156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52155_52156 : H12AffineEnvironment.transform 10 1792 env52155 = env52156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env52155 == env52156) = true)

theorem identity52156 : scanCanonicalize (H12AffineFastState.compose env52156 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound52156 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52157 : List Nat := [2,4,8,16,32,17,8,256,309,1024,1077,48,268,1045,1,263,1028,1296,1024,0,260,33,16,2,268,17,1077,1029,49,1296,1285,33,256,32,1045,308]

theorem envBound52157 : H12AffineFastState.Bounded env52157 := by
  intro p hp
  have h : env52157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52156_52157 : H12AffineEnvironment.transform 8 309 env52156 = env52157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env52156 == env52157) = true)

def env52158 : List Nat := [2,4,8,16,32,17,8,256,309,52,1,48,268,33,1,263,48,292,52,0,260,33,16,2,268,17,1,49,49,292,305,33,256,32,33,308]

theorem envBound52158 : H12AffineFastState.Bounded env52158 := by
  intro p hp
  have h : env52158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52157_52158 : H12AffineEnvironment.transform 9 52 env52157 = env52158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env52157 == env52158) = true)

theorem identity52158 : scanCanonicalize (H12AffineFastState.compose env52158 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52158 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52159 : List Nat := [2,4,8,16,0,17,8,256,277,20,1,16,268,1,1,263,16,260,20,0,260,1,16,2,268,17,1,17,17,260,273,1,256,0,1,276]

theorem envBound52159 : H12AffineFastState.Bounded env52159 := by
  intro p hp
  have h : env52159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52158_52159 : H12AffineEnvironment.transform 4 0 env52158 = env52159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52158 == env52159) = true)

def leafEnv52159 : List Nat := [2,4,8,16,0,17,8,256,277,20,1,16,268,1,1,263,16,260,20,0,260,1,16,2,273,268,1,17,1,17,17,260,273,1,256,0,4,263,1,276,1,260,0]

def active52159 : List Nat := [0,1,2,3,7]

def tree52159 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52159 : H12WitnessSearch.Good tree52159 := H12GlobalWitnessIndex.good

theorem leafIdentity52159 : H12AffineFastState.composeSystem env52159 rootObs = leafEnv52159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52159 rootObs == leafEnv52159) = true)

theorem terminalChecked52159 : H12PackedTerminal.terminalCheckFast leafEnv52159 active52159 tree52159 = true := by decide +kernel

def env52160 : List Nat := [2,4,8,16,32,17,8,256,309,53,0,48,268,32,1,263,49,293,53,0,260,33,16,2,268,17,0,48,49,293,304,33,256,32,32,308]

theorem envBound52160 : H12AffineFastState.Bounded env52160 := by
  intro p hp
  have h : env52160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52157_52160 : H12AffineEnvironment.transform 9 53 env52157 = env52160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env52157 == env52160) = true)

theorem identity52160 : scanCanonicalize (H12AffineFastState.compose env52160 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound52160 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52161 : List Nat := [2,4,8,11,32,10,8,256,302,46,0,43,268,32,1,263,42,293,46,0,260,33,11,2,268,10,0,43,42,293,299,33,256,32,32,303]

theorem envBound52161 : H12AffineFastState.Bounded env52161 := by
  intro p hp
  have h : env52161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52160_52161 : H12AffineEnvironment.transform 3 11 env52160 = env52161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env52160 == env52161) = true)

def leafEnv52161 : List Nat := [2,4,8,11,32,10,8,256,302,46,0,43,268,32,1,263,42,293,46,0,260,33,11,2,299,268,1,10,0,43,42,293,299,33,256,32,4,263,32,303,1,260,0]

def active52161 : List Nat := [0,1,2,4,7]

def tree52161 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52161 : H12WitnessSearch.Good tree52161 := H12GlobalWitnessIndex.good

theorem leafIdentity52161 : H12AffineFastState.composeSystem env52161 rootObs = leafEnv52161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52161 rootObs == leafEnv52161) = true)

theorem terminalChecked52161 : H12PackedTerminal.terminalCheckFast leafEnv52161 active52161 tree52161 = true := by decide +kernel

def env52162 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,49,268,1044,1,263,1029,1572,1024,0,261,33,16,2,268,17,1793,1028,48,1572,1285,33,256,32,1044,513]

theorem envBound52162 : H12AffineFastState.Bounded env52162 := by
  intro p hp
  have h : env52162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52155_52162 : H12AffineEnvironment.transform 10 1793 env52155 = env52162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env52155 == env52162) = true)

theorem identity52162 : scanCanonicalize (H12AffineFastState.compose env52162 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound52162 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52163 : List Nat := [2,4,8,16,32,17,8,256,512,548,293,49,268,560,1,263,545,0,548,0,261,33,16,2,268,17,293,544,48,0,801,33,256,32,560,513]

theorem envBound52163 : H12AffineFastState.Bounded env52163 := by
  intro p hp
  have h : env52163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52162_52163 : H12AffineEnvironment.transform 9 548 env52162 = env52163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env52162 == env52163) = true)

def env52164 : List Nat := [2,4,8,16,32,17,8,256,16,52,293,49,268,32,1,263,49,0,52,0,261,33,16,2,268,17,293,48,48,0,305,33,256,32,32,17]

theorem envBound52164 : H12AffineFastState.Bounded env52164 := by
  intro p hp
  have h : env52164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52163_52164 : H12AffineEnvironment.transform 8 16 env52163 = env52164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env52163 == env52164) = true)

theorem identity52164 : scanCanonicalize (H12AffineFastState.compose env52164 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound52164 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52165 : List Nat := [2,4,8,16,32,17,8,5,16,52,32,49,9,32,1,2,49,0,52,0,0,33,16,2,9,17,32,48,48,0,52,33,5,32,32,17]

theorem envBound52165 : H12AffineFastState.Bounded env52165 := by
  intro p hp
  have h : env52165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52164_52165 : H12AffineEnvironment.transform 7 5 env52164 = env52165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env52164 == env52165) = true)

def leafEnv52165 : List Nat := [2,4,8,16,32,17,8,5,16,52,32,49,9,32,1,2,49,0,52,0,0,33,16,2,52,9,1,17,32,48,48,0,52,33,5,32,4,2,32,17,1,0,0]

def active52165 : List Nat := [0,1,2,3,4]

def tree52165 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52165 : H12WitnessSearch.Good tree52165 := H12GlobalWitnessIndex.good

theorem leafIdentity52165 : H12AffineFastState.composeSystem env52165 rootObs = leafEnv52165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52165 rootObs == leafEnv52165) = true)

theorem terminalChecked52165 : H12PackedTerminal.terminalCheckFast leafEnv52165 active52165 tree52165 = true := by decide +kernel

def env52166 : List Nat := [2,4,8,16,32,17,8,256,17,53,293,49,268,33,1,263,48,0,53,0,261,33,16,2,268,17,293,49,48,0,304,33,256,32,33,16]

theorem envBound52166 : H12AffineFastState.Bounded env52166 := by
  intro p hp
  have h : env52166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52163_52166 : H12AffineEnvironment.transform 8 17 env52163 = env52166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env52163 == env52166) = true)

theorem identity52166 : scanCanonicalize (H12AffineFastState.compose env52166 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound52166 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52167 : List Nat := [2,4,8,10,32,11,8,256,11,47,293,43,268,33,1,263,42,0,47,0,261,33,10,2,268,11,293,43,42,0,298,33,256,32,33,10]

theorem envBound52167 : H12AffineFastState.Bounded env52167 := by
  intro p hp
  have h : env52167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52166_52167 : H12AffineEnvironment.transform 3 10 env52166 = env52167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env52166 == env52167) = true)

def leafEnv52167 : List Nat := [2,4,8,10,32,11,8,256,11,47,293,43,268,33,1,263,42,0,47,0,261,33,10,2,298,268,1,11,293,43,42,0,298,33,256,32,4,263,33,10,1,261,0]

def active52167 : List Nat := [0,1,2,4,7]

def tree52167 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52167 : H12WitnessSearch.Good tree52167 := H12GlobalWitnessIndex.good

theorem leafIdentity52167 : H12AffineFastState.composeSystem env52167 rootObs = leafEnv52167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52167 rootObs == leafEnv52167) = true)

theorem terminalChecked52167 : H12PackedTerminal.terminalCheckFast leafEnv52167 active52167 tree52167 = true := by decide +kernel

def env52168 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3889,268,2836,1,263,2821,2341,1024,0,3589,33,16,2,268,17,2048,2820,3888,2341,1285,33,256,32,2836,513]

theorem envBound52168 : H12AffineFastState.Bounded env52168 := by
  intro p hp
  have h : env52168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52154_52168 : H12AffineEnvironment.transform 11 3889 env52154 = env52168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env52154 == env52168) = true)

def env52169 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,49,268,1044,1,263,1029,1573,1024,0,261,33,16,2,268,17,1792,1028,48,1573,1285,33,256,32,1044,513]

theorem envBound52169 : H12AffineFastState.Bounded env52169 := by
  intro p hp
  have h : env52169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52168_52169 : H12AffineEnvironment.transform 10 1792 env52168 = env52169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env52168 == env52169) = true)

theorem identity52169 : scanCanonicalize (H12AffineFastState.compose env52169 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 768) := by decide +kernel

theorem selectedBound52169 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52170 : List Nat := [2,4,8,16,32,17,8,256,512,768,0,49,268,788,1,263,773,293,768,0,261,33,16,2,268,17,0,772,48,293,517,33,256,32,788,513]

theorem envBound52170 : H12AffineFastState.Bounded env52170 := by
  intro p hp
  have h : env52170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52169_52170 : H12AffineEnvironment.transform 9 768 env52169 = env52170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env52169 == env52170) = true)

def env52171 : List Nat := [2,4,8,16,32,17,8,256,308,52,0,49,268,32,1,263,49,293,52,0,261,33,16,2,268,17,0,48,48,293,305,33,256,32,32,309]

theorem envBound52171 : H12AffineFastState.Bounded env52171 := by
  intro p hp
  have h : env52171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52170_52171 : H12AffineEnvironment.transform 8 308 env52170 = env52171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env52170 == env52171) = true)

theorem identity52171 : scanCanonicalize (H12AffineFastState.compose env52171 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52171 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52172 : List Nat := [2,4,8,16,0,17,8,256,276,20,0,17,268,0,1,263,17,261,20,0,261,1,16,2,268,17,0,16,16,261,273,1,256,0,0,277]

theorem envBound52172 : H12AffineFastState.Bounded env52172 := by
  intro p hp
  have h : env52172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52171_52172 : H12AffineEnvironment.transform 4 0 env52171 = env52172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52171 == env52172) = true)

def leafEnv52172 : List Nat := [2,4,8,16,0,17,8,256,276,20,0,17,268,0,1,263,17,261,20,0,261,1,16,2,273,268,1,17,0,16,16,261,273,1,256,0,4,263,0,277,1,261,0]

def active52172 : List Nat := [0,1,2,3,7]

def tree52172 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52172 : H12WitnessSearch.Good tree52172 := H12GlobalWitnessIndex.good

theorem leafIdentity52172 : H12AffineFastState.composeSystem env52172 rootObs = leafEnv52172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52172 rootObs == leafEnv52172) = true)

theorem terminalChecked52172 : H12PackedTerminal.terminalCheckFast leafEnv52172 active52172 tree52172 = true := by decide +kernel

def env52173 : List Nat := [2,4,8,16,32,17,8,256,309,53,0,49,268,33,1,263,48,293,53,0,261,33,16,2,268,17,0,49,48,293,304,33,256,32,33,308]

theorem envBound52173 : H12AffineFastState.Bounded env52173 := by
  intro p hp
  have h : env52173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52170_52173 : H12AffineEnvironment.transform 8 309 env52170 = env52173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env52170 == env52173) = true)

theorem identity52173 : scanCanonicalize (H12AffineFastState.compose env52173 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound52173 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52174 : List Nat := [2,4,8,11,32,10,8,256,302,46,0,42,268,33,1,263,43,293,46,0,261,33,11,2,268,10,0,42,43,293,299,33,256,32,33,303]

theorem envBound52174 : H12AffineFastState.Bounded env52174 := by
  intro p hp
  have h : env52174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52173_52174 : H12AffineEnvironment.transform 3 11 env52173 = env52174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env52173 == env52174) = true)

def leafEnv52174 : List Nat := [2,4,8,11,32,10,8,256,302,46,0,42,268,33,1,263,43,293,46,0,261,33,11,2,299,268,1,10,0,42,43,293,299,33,256,32,4,263,33,303,1,261,0]

def active52174 : List Nat := [0,1,2,4,7]

def tree52174 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52174 : H12WitnessSearch.Good tree52174 := H12GlobalWitnessIndex.good

theorem leafIdentity52174 : H12AffineFastState.composeSystem env52174 rootObs = leafEnv52174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52174 rootObs == leafEnv52174) = true)

theorem terminalChecked52174 : H12PackedTerminal.terminalCheckFast leafEnv52174 active52174 tree52174 = true := by decide +kernel

def env52175 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,48,268,1045,1,263,1028,1572,1024,0,260,33,16,2,268,17,1793,1029,49,1572,1285,33,256,32,1045,513]

theorem envBound52175 : H12AffineFastState.Bounded env52175 := by
  intro p hp
  have h : env52175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52168_52175 : H12AffineEnvironment.transform 10 1793 env52168 = env52175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env52168 == env52175) = true)

theorem identity52175 : scanCanonicalize (H12AffineFastState.compose env52175 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound52175 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52176 : List Nat := [2,4,8,16,32,17,8,256,17,1024,1296,48,268,1045,1,263,1028,1077,1024,0,260,33,16,2,268,17,1296,1029,49,1077,1285,33,256,32,1045,16]

theorem envBound52176 : H12AffineFastState.Bounded env52176 := by
  intro p hp
  have h : env52176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52175_52176 : H12AffineEnvironment.transform 8 17 env52175 = env52176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env52175 == env52176) = true)

def env52177 : List Nat := [2,4,8,16,32,17,8,256,17,52,292,48,268,33,1,263,48,1,52,0,260,33,16,2,268,17,292,49,49,1,305,33,256,32,33,16]

theorem envBound52177 : H12AffineFastState.Bounded env52177 := by
  intro p hp
  have h : env52177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52176_52177 : H12AffineEnvironment.transform 9 52 env52176 = env52177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env52176 == env52177) = true)

theorem identity52177 : scanCanonicalize (H12AffineFastState.compose env52177 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound52177 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52178 : List Nat := [2,4,8,16,32,17,8,5,17,52,33,48,9,33,1,2,48,1,52,0,1,33,16,2,9,17,33,49,49,1,52,33,5,32,33,16]

theorem envBound52178 : H12AffineFastState.Bounded env52178 := by
  intro p hp
  have h : env52178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52177_52178 : H12AffineEnvironment.transform 7 5 env52177 = env52178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env52177 == env52178) = true)

def leafEnv52178 : List Nat := [2,4,8,16,32,17,8,5,17,52,33,48,9,33,1,2,48,1,52,0,1,33,16,2,52,9,1,17,33,49,49,1,52,33,5,32,4,2,33,16,1,1,0]

def active52178 : List Nat := [0,1,2,3,4]

def tree52178 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52178 : H12WitnessSearch.Good tree52178 := H12GlobalWitnessIndex.good

theorem leafIdentity52178 : H12AffineFastState.composeSystem env52178 rootObs = leafEnv52178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52178 rootObs == leafEnv52178) = true)

theorem terminalChecked52178 : H12PackedTerminal.terminalCheckFast leafEnv52178 active52178 tree52178 = true := by decide +kernel

def env52179 : List Nat := [2,4,8,16,32,17,8,256,17,53,293,48,268,32,1,263,49,0,53,0,260,33,16,2,268,17,293,48,49,0,304,33,256,32,32,16]

theorem envBound52179 : H12AffineFastState.Bounded env52179 := by
  intro p hp
  have h : env52179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52176_52179 : H12AffineEnvironment.transform 9 53 env52176 = env52179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env52176 == env52179) = true)

theorem identity52179 : scanCanonicalize (H12AffineFastState.compose env52179 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound52179 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52180 : List Nat := [2,4,8,10,32,11,8,256,11,47,293,42,268,32,1,263,43,0,47,0,260,33,10,2,268,11,293,42,43,0,298,33,256,32,32,10]

theorem envBound52180 : H12AffineFastState.Bounded env52180 := by
  intro p hp
  have h : env52180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52179_52180 : H12AffineEnvironment.transform 3 10 env52179 = env52180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env52179 == env52180) = true)

def leafEnv52180 : List Nat := [2,4,8,10,32,11,8,256,11,47,293,42,268,32,1,263,43,0,47,0,260,33,10,2,298,268,1,11,293,42,43,0,298,33,256,32,4,263,32,10,1,260,0]

def active52180 : List Nat := [0,1,2,4,7]

def tree52180 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52180 : H12WitnessSearch.Good tree52180 := H12GlobalWitnessIndex.good

theorem leafIdentity52180 : H12AffineFastState.composeSystem env52180 rootObs = leafEnv52180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52180 rootObs == leafEnv52180) = true)

theorem terminalChecked52180 : H12PackedTerminal.terminalCheckFast leafEnv52180 active52180 tree52180 = true := by decide +kernel

def env52181 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,58397,4194304,16,41310,8192,64,4530526,115014,45404,294913,75103,4268042,256,98678,90203,513]

theorem envBound52181 : H12AffineFastState.Bounded env52181 := by
  intro p hp
  have h : env52181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52146_52181 : H12AffineEnvironment.transform 20 58397 env52146 = env52181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env52146 == env52181) = true)

def env52182 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,58397,4194304,16,41230,8192,16,4530446,114966,45324,294913,75023,4268042,256,98598,90123,513]

theorem envBound52182 : H12AffineFastState.Bounded env52182 := by
  intro p hp
  have h : env52182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52181_52182 : H12AffineEnvironment.transform 5 16 env52181 = env52182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52181 == env52182) = true)

theorem identity52182 : scanCanonicalize (H12AffineFastState.compose env52182 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 272393) := by decide +kernel

theorem selectedBound52182 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env52183 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,58397,272393,16,41230,8192,16,67847,114966,45324,294913,75023,329731,256,98598,90123,513]

theorem envBound52183 : H12AffineFastState.Bounded env52183 := by
  intro p hp
  have h : env52183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52182_52183 : H12AffineEnvironment.transform 21 272393 env52182 = env52183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272393 env52182 == env52183) = true)

theorem identity52183 : scanCanonicalize (H12AffineFastState.compose env52183 (packedSelected [0,3,7,10,19,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound52183 : packedSelected [0,3,7,10,19,20,24] rootPS < 2^1333 := by decide +kernel

def env52184 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,33030,16401,262144,1024,32769,58397,272393,16,41230,8192,16,34817,16400,45324,294913,41993,297221,256,32,57613,513]

theorem envBound52184 : H12AffineFastState.Bounded env52184 := by
  intro p hp
  have h : env52184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52183_52184 : H12AffineEnvironment.transform 15 33030 env52183 = env52184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env52183 == env52184) = true)

theorem identity52184 : scanCanonicalize (H12AffineFastState.compose env52184 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound52184 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52185 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,33030,16401,2341,1024,32769,58397,8492,16,41230,8192,16,34817,16400,45324,35108,41993,32800,256,32,57613,513]

theorem envBound52185 : H12AffineFastState.Bounded env52185 := by
  intro p hp
  have h : env52185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52184_52185 : H12AffineEnvironment.transform 17 2341 env52184 = env52185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env52184 == env52185) = true)

theorem identity52185 : scanCanonicalize (H12AffineFastState.compose env52185 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound52185 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52186 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,0,262,16401,2341,1024,1,25629,8492,16,8462,8192,16,2049,16400,12556,2340,9225,32,256,32,24845,513]

theorem envBound52186 : H12AffineFastState.Bounded env52186 := by
  intro p hp
  have h : env52186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52185_52186 : H12AffineEnvironment.transform 14 0 env52185 = env52186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env52185 == env52186) = true)

theorem identity52186 : scanCanonicalize (H12AffineFastState.compose env52186 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound52186 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env52187 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,0,262,13340,2341,1024,1,4112,8492,16,8462,8192,16,2049,13341,12556,2340,9225,32,256,32,5376,513]

theorem envBound52187 : H12AffineFastState.Bounded env52187 := by
  intro p hp
  have h : env52187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52186_52187 : H12AffineEnvironment.transform 13 13325 env52186 = env52187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env52186 == env52187) = true)

theorem identity52187 : scanCanonicalize (H12AffineFastState.compose env52187 (packedSelected [1,3,4,5,8,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound52187 : packedSelected [1,3,4,5,8,9,12] rootPS < 2^1333 := by decide +kernel

def env52188 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,308,8192,9529,0,262,9512,2341,1024,1,292,8492,16,8462,8192,16,2049,9513,8248,2340,9225,32,256,32,1076,513]

theorem envBound52188 : H12AffineFastState.Bounded env52188 := by
  intro p hp
  have h : env52188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52187_52188 : H12AffineEnvironment.transform 11 308 env52187 = env52188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env52187 == env52188) = true)

theorem identity52188 : scanCanonicalize (H12AffineFastState.compose env52188 (packedSelected [0,1,3,5,7,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 3384) := by decide +kernel

theorem selectedBound52188 : packedSelected [0,1,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env52189 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,308,3384,2049,0,262,2064,2341,1024,1,292,3092,16,3126,3384,16,2049,2065,3328,2340,2353,32,256,32,1076,513]

theorem envBound52189 : H12AffineFastState.Bounded env52189 := by
  intro p hp
  have h : env52189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52188_52189 : H12AffineEnvironment.transform 12 3384 env52188 = env52189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3384 env52188 == env52189) = true)

theorem identity52189 : scanCanonicalize (H12AffineFastState.compose env52189 (packedSelected [0,4,7,9,15] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound52189 : packedSelected [0,4,7,9,15] rootPS < 2^1333 := by decide +kernel

def env52190 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,308,269,1076,0,262,1061,1296,1024,1,292,33,16,3,269,16,1076,1060,309,1297,1284,32,256,32,1076,513]

theorem envBound52190 : H12AffineFastState.Bounded env52190 := by
  intro p hp
  have h : env52190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52189_52190 : H12AffineEnvironment.transform 10 1077 env52189 = env52190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env52189 == env52190) = true)

theorem identity52190 : scanCanonicalize (H12AffineFastState.compose env52190 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound52190 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52191 : List Nat := [2,4,8,16,32,16,8,256,512,20,33,308,269,32,0,262,49,260,20,1,292,33,16,3,269,16,32,48,309,261,272,32,256,32,32,513]

theorem envBound52191 : H12AffineFastState.Bounded env52191 := by
  intro p hp
  have h : env52191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52190_52191 : H12AffineEnvironment.transform 9 20 env52190 = env52191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env52190 == env52191) = true)

theorem identity52191 : scanCanonicalize (H12AffineFastState.compose env52191 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52191 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52192 : List Nat := [2,4,8,16,0,16,8,256,512,20,1,276,269,0,0,262,17,260,20,1,260,1,16,3,269,16,0,16,277,261,272,0,256,0,0,513]

theorem envBound52192 : H12AffineFastState.Bounded env52192 := by
  intro p hp
  have h : env52192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52191_52192 : H12AffineEnvironment.transform 4 0 env52191 = env52192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52191 == env52192) = true)

theorem identity52192 : scanCanonicalize (H12AffineFastState.compose env52192 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound52192 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52193 : List Nat := [2,4,8,16,0,16,8,256,260,20,1,276,269,0,0,262,17,260,20,1,260,1,16,3,269,16,0,16,277,261,272,0,256,0,0,261]

theorem envBound52193 : H12AffineFastState.Bounded env52193 := by
  intro p hp
  have h : env52193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52192_52193 : H12AffineEnvironment.transform 8 260 env52192 = env52193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env52192 == env52193) = true)

def env52194 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,58397,4194304,16,41231,8192,17,4530447,114967,45325,294913,75022,4268042,256,98599,90122,513]

theorem envBound52194 : H12AffineFastState.Bounded env52194 := by
  intro p hp
  have h : env52194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52181_52194 : H12AffineEnvironment.transform 5 17 env52181 = env52194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52181 == env52194) = true)

theorem identity52194 : scanCanonicalize (H12AffineFastState.compose env52194 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 329731) := by decide +kernel

theorem selectedBound52194 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env52195 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,58397,329731,16,41231,8192,17,10508,114967,45325,294913,75022,272393,256,98599,90122,513]

theorem envBound52195 : H12AffineFastState.Bounded env52195 := by
  intro p hp
  have h : env52195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52194_52195 : H12AffineEnvironment.transform 21 329731 env52194 = env52195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 329731 env52194 == env52195) = true)

theorem identity52195 : scanCanonicalize (H12AffineFastState.compose env52195 (packedSelected [1,2,3,4,5,6,8,9,10,14,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound52195 : packedSelected [1,2,3,4,5,6,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env52196 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,2341,1024,32769,58397,65830,16,41231,8192,17,10508,114967,45325,35108,75022,8492,256,98599,90122,513]

theorem envBound52196 : H12AffineFastState.Bounded env52196 := by
  intro p hp
  have h : env52196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52195_52196 : H12AffineEnvironment.transform 17 2341 env52195 = env52196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env52195 == env52196) = true)

theorem identity52196 : scanCanonicalize (H12AffineFastState.compose env52196 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound52196 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env52197 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,65536,16401,2341,1024,8461,17681,65830,16,3,8192,17,10508,90139,4097,10280,75022,8492,256,73771,90122,513]

theorem envBound52197 : H12AffineFastState.Bounded env52197 := by
  intro p hp
  have h : env52197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52196_52197 : H12AffineEnvironment.transform 14 8460 env52196 = env52197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env52196 == env52197) = true)

theorem identity52197 : scanCanonicalize (H12AffineFastState.compose env52197 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound52197 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52198 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,0,65536,16401,2341,1024,1,17681,65830,16,3,268,17,2048,82199,4097,2340,66562,32,256,65831,82182,513]

theorem envBound52198 : H12AffineFastState.Bounded env52198 := by
  intro p hp
  have h : env52198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52197_52198 : H12AffineEnvironment.transform 12 268 env52197 = env52198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env52197 == env52198) = true)

theorem identity52198 : scanCanonicalize (H12AffineFastState.compose env52198 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound52198 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52199 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,0,262,16401,2341,1024,1,17681,32,16,3,268,17,2048,16401,4097,2340,1284,32,256,33,16384,513]

theorem envBound52199 : H12AffineFastState.Bounded env52199 := by
  intro p hp
  have h : env52199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52198_52199 : H12AffineEnvironment.transform 15 262 env52198 = env52199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env52198 == env52199) = true)

theorem identity52199 : scanCanonicalize (H12AffineFastState.compose env52199 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1076) := by decide +kernel

theorem selectedBound52199 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52200 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,1076,0,262,1061,2341,1024,1,293,32,16,3,268,17,2048,1061,4097,2340,1284,32,256,33,1076,513]

theorem envBound52200 : H12AffineFastState.Bounded env52200 := by
  intro p hp
  have h : env52200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52199_52200 : H12AffineEnvironment.transform 13 1076 env52199 = env52200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1076 env52199 == env52200) = true)

theorem identity52200 : scanCanonicalize (H12AffineFastState.compose env52200 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound52200 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52201 : List Nat := [2,4,8,16,32,17,8,256,512,1024,523,4096,268,1076,0,262,1061,814,1024,1,293,32,16,3,268,17,523,1061,4097,815,1284,32,256,33,1076,513]

theorem envBound52201 : H12AffineFastState.Bounded env52201 := by
  intro p hp
  have h : env52201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52200_52201 : H12AffineEnvironment.transform 10 523 env52200 = env52201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env52200 == env52201) = true)

theorem identity52201 : scanCanonicalize (H12AffineFastState.compose env52201 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 827) := by decide +kernel

theorem selectedBound52201 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52202 : List Nat := [2,4,8,16,32,17,8,256,512,827,523,4096,268,783,0,262,798,814,827,1,293,32,16,3,268,17,523,798,4097,815,575,32,256,33,783,513]

theorem envBound52202 : H12AffineFastState.Bounded env52202 := by
  intro p hp
  have h : env52202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52201_52202 : H12AffineEnvironment.transform 9 827 env52201 = env52202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 827 env52201 == env52202) = true)

theorem identity52202 : scanCanonicalize (H12AffineFastState.compose env52202 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 539) := by decide +kernel

theorem selectedBound52202 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52203 : List Nat := [2,4,8,16,32,17,8,256,512,827,523,539,268,783,0,262,798,814,827,1,293,32,16,3,268,17,523,798,538,815,575,32,256,33,783,513]

theorem envBound52203 : H12AffineFastState.Bounded env52203 := by
  intro p hp
  have h : env52203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52202_52203 : H12AffineEnvironment.transform 11 539 env52202 = env52203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 539 env52202 == env52203) = true)

theorem identity52203 : scanCanonicalize (H12AffineFastState.compose env52203 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound52203 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env52204 : List Nat := [2,4,8,16,32,17,8,256,43,272,32,48,268,292,0,262,309,261,272,1,293,32,16,3,268,17,32,309,49,260,20,32,256,33,292,42]

theorem envBound52204 : H12AffineFastState.Bounded env52204 := by
  intro p hp
  have h : env52204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52203_52204 : H12AffineEnvironment.transform 8 43 env52203 = env52204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env52203 == env52204) = true)

def env52205 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,17,16777216,8193,64,21479440,18973700,2118976,442385,16876544,23160136,256,18990133,18949401,16819039]

theorem envBound52205 : H12AffineFastState.Bounded env52205 := by
  intro p hp
  have h : env52205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52063_52205 : H12AffineEnvironment.transform 6 9 env52063 = env52205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52063 == env52205) = true)

theorem identity52205 : scanCanonicalize (H12AffineFastState.compose env52205 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound52205 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env52206 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1024,32769,2097152,4194304,17,16777216,8193,64,21186916,18973700,2118976,149861,16876544,23160136,256,18990133,18949401,16819039]

theorem envBound52206 : H12AffineFastState.Bounded env52206 := by
  intro p hp
  have h : env52206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52205_52206 : H12AffineEnvironment.transform 17 35188 env52205 = env52206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env52205 == env52206) = true)

theorem identity52206 : scanCanonicalize (H12AffineFastState.compose env52206 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(23+1) ^^^ 246084) := by decide +kernel

theorem selectedBound52206 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env52207 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1024,32769,2097152,4194304,17,246084,8193,64,4229152,2245952,2118976,149861,148804,6464524,256,2229617,2286685,221723]

theorem envBound52207 : H12AffineFastState.Bounded env52207 := by
  intro p hp
  have h : env52207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52206_52207 : H12AffineEnvironment.transform 23 246084 env52206 = env52207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 246084 env52206 == env52207) = true)

def env52208 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1024,32769,2097152,4194304,17,98644,8193,64,4229152,2098512,2118976,2421,1364,6349852,256,2114913,2139213,74251]

theorem envBound52208 : H12AffineFastState.Bounded env52208 := by
  intro p hp
  have h : env52208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52207_52208 : H12AffineEnvironment.transform 16 16400 env52207 = env52208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env52207 == env52208) = true)

theorem identity52208 : scanCanonicalize (H12AffineFastState.compose env52208 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound52208 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env52209 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,35188,1024,32769,2097152,4194304,17,41310,8193,64,4229152,2098512,2118976,2421,1364,6349852,256,2114913,2139213,513]

theorem envBound52209 : H12AffineFastState.Bounded env52209 := by
  intro p hp
  have h : env52209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52208_52209 : H12AffineEnvironment.transform 15 8202 env52208 = env52209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env52208 == env52209) = true)

theorem identity52209 : scanCanonicalize (H12AffineFastState.compose env52209 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 41340) := by decide +kernel

theorem selectedBound52209 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52210 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,35188,1024,32769,2097152,41340,17,41310,8193,64,10588,2098512,2118976,2421,1364,2114912,256,2114913,2139213,513]

theorem envBound52210 : H12AffineFastState.Bounded env52210 := by
  intro p hp
  have h : env52210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52209_52210 : H12AffineEnvironment.transform 21 41340 env52209 = env52210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41340 env52209 == env52210) = true)

theorem identity52210 : scanCanonicalize (H12AffineFastState.compose env52210 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(20+1) ^^^ 38145) := by decide +kernel

theorem selectedBound52210 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52211 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,35188,1024,32769,38145,41340,17,41310,8193,64,10588,36945,49217,2421,1364,53345,256,53344,12620,513]

theorem envBound52211 : H12AffineFastState.Bounded env52211 := by
  intro p hp
  have h : env52211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52210_52211 : H12AffineEnvironment.transform 20 38145 env52210 = env52211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 38145 env52210 == env52211) = true)

theorem identity52211 : scanCanonicalize (H12AffineFastState.compose env52211 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29004) := by decide +kernel

theorem selectedBound52211 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env52212 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,8202,16400,30776,1024,29005,25677,20528,17,20498,8193,64,10588,24861,12557,2421,1364,8493,256,8492,12620,513]

theorem envBound52212 : H12AffineFastState.Bounded env52212 := by
  intro p hp
  have h : env52212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52211_52212 : H12AffineEnvironment.transform 14 29004 env52211 = env52212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29004 env52211 == env52212) = true)

theorem identity52212 : scanCanonicalize (H12AffineFastState.compose env52212 (packedSelected [0,1,2,3,4,10,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound52212 : packedSelected [0,1,2,3,4,10,11,15] rootPS < 2^1333 := by decide +kernel

def env52213 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,8192,16384,29004,8202,16400,30776,100,29005,24617,20528,17,20498,8193,64,10588,24861,12557,2421,304,8493,256,8492,12620,513]

theorem envBound52213 : H12AffineFastState.Bounded env52213 := by
  intro p hp
  have h : env52213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52212_52213 : H12AffineEnvironment.transform 9 100 env52212 = env52213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env52212 == env52213) = true)

theorem identity52213 : scanCanonicalize (H12AffineFastState.compose env52213 (packedSelected [2,5,8] rootPS)) = affineNative (2^(13+1) ^^^ 10588) := by decide +kernel

theorem selectedBound52213 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env52214 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,8192,10588,6160,8202,10572,4452,100,6161,2421,14700,17,14670,8193,64,10588,2113,12557,2421,304,8493,256,8492,12620,513]

theorem envBound52214 : H12AffineFastState.Bounded env52214 := by
  intro p hp
  have h : env52214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52213_52214 : H12AffineEnvironment.transform 13 10588 env52213 = env52214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10588 env52213 == env52214) = true)

def env52215 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1024,32769,2097152,4194304,17,98645,8193,64,4229152,2098513,2118976,2420,1365,6349853,256,2114912,2139212,74250]

theorem envBound52215 : H12AffineFastState.Bounded env52215 := by
  intro p hp
  have h : env52215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52207_52215 : H12AffineEnvironment.transform 16 16401 env52207 = env52215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env52207 == env52215) = true)

theorem identity52215 : scanCanonicalize (H12AffineFastState.compose env52215 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 73771) := by decide +kernel

theorem selectedBound52215 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env52216 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1024,32769,2097152,73771,17,98645,8193,64,108555,2098513,2118976,2420,1365,2212918,256,2114912,2139212,74250]

theorem envBound52216 : H12AffineFastState.Bounded env52216 := by
  intro p hp
  have h : env52216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52215_52216 : H12AffineEnvironment.transform 21 73771 env52215 = env52216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73771 env52215 == env52216) = true)

theorem identity52216 : scanCanonicalize (H12AffineFastState.compose env52216 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 124187) := by decide +kernel

theorem selectedBound52216 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env52217 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1024,32769,124187,73771,17,98645,8193,64,108555,122954,110683,2420,1365,8493,256,106619,82263,74250]

theorem envBound52217 : H12AffineFastState.Bounded env52217 := by
  intro p hp
  have h : env52217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52216_52217 : H12AffineEnvironment.transform 20 124187 env52216 = env52217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 124187 env52216 == env52217) = true)

theorem identity52217 : scanCanonicalize (H12AffineFastState.compose env52217 (packedSelected [0,1,2,3,4,6,7,8,9,11,12,15,17,18,19,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound52217 : packedSelected [0,1,2,3,4,6,7,8,9,11,12,15,17,18,19,20,24] rootPS < 2^1333 := by decide +kernel

def env52218 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,263,16401,35188,1024,32769,58396,8492,17,32850,8193,64,43276,57677,45404,2420,1365,8493,256,41340,16464,8973]

theorem envBound52218 : H12AffineFastState.Bounded env52218 := by
  intro p hp
  have h : env52218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52217_52218 : H12AffineEnvironment.transform 15 263 env52217 = env52218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env52217 == env52218) = true)

theorem identity52218 : scanCanonicalize (H12AffineFastState.compose env52218 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound52218 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env52219 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,263,16401,10281,1024,8540,17729,8492,17,8463,8193,64,2129,16400,4097,2420,1365,8493,256,33,16464,8973]

theorem envBound52219 : H12AffineFastState.Bounded env52219 := by
  intro p hp
  have h : env52219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52218_52219 : H12AffineEnvironment.transform 14 8541 env52218 = env52219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env52218 == env52219) = true)

theorem identity52219 : scanCanonicalize (H12AffineFastState.compose env52219 (packedSelected [0,1,3,5,8,9,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound52219 : packedSelected [0,1,3,5,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env52220 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,8541,263,5220,10281,1024,8540,4404,8492,17,8463,8193,64,2129,5221,4097,2420,1365,8493,256,33,5157,8973]

theorem envBound52220 : H12AffineFastState.Bounded env52220 := by
  intro p hp
  have h : env52220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52219_52220 : H12AffineEnvironment.transform 13 5237 env52219 = env52220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env52219 == env52220) = true)

theorem identity52220 : scanCanonicalize (H12AffineFastState.compose env52220 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound52220 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env52221 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5237,80,263,5220,2340,1024,81,4404,33,17,2,268,64,2129,5221,4097,2420,1365,32,256,33,5157,512]

theorem envBound52221 : H12AffineFastState.Bounded env52221 := by
  intro p hp
  have h : env52221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52220_52221 : H12AffineEnvironment.transform 12 269 env52220 = env52221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env52220 == env52221) = true)

theorem identity52221 : scanCanonicalize (H12AffineFastState.compose env52221 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound52221 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env52222 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5237,80,114,5220,2129,1024,81,4161,33,17,2,121,64,2129,5221,4097,2049,1056,32,117,33,5157,512]

theorem envBound52222 : H12AffineFastState.Bounded env52222 := by
  intro p hp
  have h : env52222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52221_52222 : H12AffineEnvironment.transform 7 117 env52221 = env52222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env52221 == env52222) = true)

theorem identity52222 : scanCanonicalize (H12AffineFastState.compose env52222 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52222 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env52223 : List Nat := [2,4,8,16,0,64,9,85,512,1024,2048,4096,88,5205,80,82,5188,2129,1024,81,4161,1,17,2,89,64,2129,5189,4097,2049,1024,0,85,1,5125,512]

theorem envBound52223 : H12AffineFastState.Bounded env52223 := by
  intro p hp
  have h : env52223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52222_52223 : H12AffineEnvironment.transform 4 0 env52222 = env52223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52222 == env52223) = true)

theorem identity52223 : scanCanonicalize (H12AffineFastState.compose env52223 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound52223 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env52224 : List Nat := [2,4,8,16,0,64,9,85,512,1024,1,4096,88,5205,80,82,5188,80,1024,81,4161,1,17,2,89,64,80,5189,4097,0,1024,0,85,1,5125,512]

theorem envBound52224 : H12AffineFastState.Bounded env52224 := by
  intro p hp
  have h : env52224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52223_52224 : H12AffineEnvironment.transform 10 1 env52223 = env52224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env52223 == env52224) = true)

def env52225 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830977,25265169,23160257,257,27378860,27337992,25207750]

theorem envBound52225 : H12AffineFastState.Bounded env52225 := by
  intro p hp
  have h : env52225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52061_52225 : H12AffineEnvironment.transform 18 1025 env52061 = env52225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env52061 == env52225) = true)

theorem identity52225 : scanCanonicalize (H12AffineFastState.compose env52225 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 253977) := by decide +kernel

theorem selectedBound52225 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env52226 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,253977,8328,64,12853273,2253973,10507601,8830977,8545288,6456792,257,10626229,10667281,8602591]

theorem envBound52226 : H12AffineFastState.Bounded env52226 := by
  intro p hp
  have h : env52226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52225_52226 : H12AffineEnvironment.transform 23 253977 env52225 = env52226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 253977 env52225 == env52226) = true)

def env52227 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2257300,253977,8328,64,6705549,2253973,140485,2404757,2102684,6456792,257,21793,46213,2175563]

theorem envBound52227 : H12AffineFastState.Bounded env52227 := by
  intro p hp
  have h : env52227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52226_52227 : H12AffineEnvironment.transform 22 2257300 env52226 = env52227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2257300 env52226 == env52227) = true)

def env52228 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441744,2257300,253977,8328,64,2157597,2253973,140485,2404757,2102684,2373704,257,21793,46213,2175563]

theorem envBound52228 : H12AffineFastState.Bounded env52228 := by
  intro p hp
  have h : env52228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52227_52228 : H12AffineEnvironment.transform 21 441744 env52227 = env52228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441744 env52227 == env52228) = true)

def env52229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441744,156116,253977,8328,64,64605,160981,140485,303573,1500,272392,257,21793,46213,74251]

theorem envBound52229 : H12AffineFastState.Bounded env52229 := by
  intro p hp
  have h : env52229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52228_52229 : H12AffineEnvironment.transform 20 4160 env52228 = env52229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env52228 == env52229) = true)

theorem identity52229 : scanCanonicalize (H12AffineFastState.compose env52229 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound52229 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,4160,411973,156116,201932,8328,64,2184,160981,140485,283904,1500,272392,257,21793,16464,74251]

theorem envBound52230 : H12AffineFastState.Bounded env52230 := by
  intro p hp
  have h : env52230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52229_52230 : H12AffineEnvironment.transform 14 29909 env52229 = env52230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env52229 == env52230) = true)

def env52231 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,262144,1025,29828,4112,411925,156036,201884,8328,16,2184,160901,140437,283904,1420,272392,257,21793,16384,74251]

theorem envBound52231 : H12AffineFastState.Bounded env52231 := by
  intro p hp
  have h : env52231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52230_52231 : H12AffineEnvironment.transform 5 16 env52230 = env52231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52230 == env52231) = true)

theorem identity52231 : scanCanonicalize (H12AffineFastState.compose env52231 (packedSelected [4,5,7,8,9,11,12,15,16,17,19,20,24,27,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 215090) := by decide +kernel

theorem selectedBound52231 : packedSelected [4,5,7,8,9,11,12,15,16,17,19,20,24,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env52232 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,215090,1025,29828,4112,65831,156036,201884,8328,16,2184,160901,140437,204082,1420,221242,257,21793,16384,74251]

theorem envBound52232 : H12AffineFastState.Bounded env52232 := by
  intro p hp
  have h : env52232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52231_52232 : H12AffineEnvironment.transform 17 215090 env52231 = env52232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 215090 env52231 == env52232) = true)

theorem identity52232 : scanCanonicalize (H12AffineFastState.compose env52232 (packedSelected [0,1,9,10,11,17,18,19,22,23,27,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound52232 : packedSelected [0,1,9,10,11,17,18,19,22,23,27,28,32] rootPS < 2^1333 := by decide +kernel

def env52233 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,5528,89514,1025,29828,4112,65831,29724,65796,8328,16,2184,24861,12557,67754,1420,95650,257,21793,16384,74251]

theorem envBound52233 : H12AffineFastState.Bounded env52233 := by
  intro p hp
  have h : env52233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52232_52233 : H12AffineEnvironment.transform 16 5528 env52232 = env52233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env52232 == env52233) = true)

theorem identity52233 : scanCanonicalize (H12AffineFastState.compose env52233 (packedSelected [0,3,4,7,10,16,17,19,20,22,24] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound52233 : packedSelected [0,3,4,7,10,16,17,19,20,22,24] rootPS < 2^1333 := by decide +kernel

def env52234 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,263,5528,23725,1025,29828,4112,32,29724,3,8328,16,2184,24861,12557,2477,1420,29861,257,21793,16384,8972]

theorem envBound52234 : H12AffineFastState.Bounded env52234 := by
  intro p hp
  have h : env52234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52233_52234 : H12AffineEnvironment.transform 15 263 env52233 = env52234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env52233 == env52234) = true)

theorem identity52234 : scanCanonicalize (H12AffineFastState.compose env52234 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound52234 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env52235 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,21896,263,5528,23725,1025,21897,4112,32,21777,3,389,16,2184,16400,4096,2477,1420,21928,257,21793,16384,513]

theorem envBound52235 : H12AffineFastState.Bounded env52235 := by
  intro p hp
  have h : env52235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52234_52235 : H12AffineEnvironment.transform 12 269 env52234 = env52235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env52234 == env52235) = true)

theorem identity52235 : scanCanonicalize (H12AffineFastState.compose env52235 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound52235 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52236 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,21761,263,5393,23588,1025,21760,4112,32,21777,3,268,16,2049,16400,4096,2340,1285,21793,257,21793,16384,513]

theorem envBound52236 : H12AffineFastState.Bounded env52236 := by
  intro p hp
  have h : env52236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52235_52236 : H12AffineEnvironment.transform 6 9 env52235 = env52236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52235 == env52236) = true)

theorem identity52236 : scanCanonicalize (H12AffineFastState.compose env52236 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound52236 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env52237 : List Nat := [2,4,8,16,32,16,9,256,512,52,2048,4096,269,16384,20789,263,4389,22544,53,20788,4112,32,20773,3,268,16,2049,16400,4096,2340,305,20757,257,20757,16384,513]

theorem envBound52237 : H12AffineFastState.Bounded env52237 := by
  intro p hp
  have h : env52237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52236_52237 : H12AffineEnvironment.transform 9 52 env52236 = env52237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env52236 == env52237) = true)

theorem identity52237 : scanCanonicalize (H12AffineFastState.compose env52237 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound52237 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env52238 : List Nat := [2,4,8,16,32,16,9,256,512,52,1,4096,269,16384,20789,263,4389,20497,53,20788,4112,32,20773,3,268,16,0,16400,4096,293,305,20757,257,20757,16384,513]

theorem envBound52238 : H12AffineFastState.Bounded env52238 := by
  intro p hp
  have h : env52238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52237_52238 : H12AffineEnvironment.transform 10 1 env52237 = env52238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env52237 == env52238) = true)

theorem identity52238 : scanCanonicalize (H12AffineFastState.compose env52238 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound52238 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env52239 : List Nat := [2,4,8,16,32,16,9,256,512,52,1,4096,269,4404,1,263,4389,293,53,0,4112,32,17,3,268,16,0,4388,4096,293,305,33,257,33,4404,513]

theorem envBound52239 : H12AffineFastState.Bounded env52239 := by
  intro p hp
  have h : env52239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52238_52239 : H12AffineEnvironment.transform 13 4404 env52238 = env52239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env52238 == env52239) = true)

theorem identity52239 : scanCanonicalize (H12AffineFastState.compose env52239 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound52239 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52240 : List Nat := [2,4,8,16,32,16,9,5,512,52,1,4096,8,4145,1,2,4128,32,53,0,4112,32,17,3,9,16,0,4129,4096,32,52,33,4,33,4145,513]

theorem envBound52240 : H12AffineFastState.Bounded env52240 := by
  intro p hp
  have h : env52240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52239_52240 : H12AffineEnvironment.transform 7 5 env52239 = env52240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env52239 == env52240) = true)

theorem identity52240 : scanCanonicalize (H12AffineFastState.compose env52240 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 570) := by decide +kernel

theorem selectedBound52240 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52241 : List Nat := [2,4,8,16,32,16,9,5,512,52,1,570,8,523,1,2,538,32,53,0,554,32,17,3,9,16,0,539,570,32,52,33,4,33,523,513]

theorem envBound52241 : H12AffineFastState.Bounded env52241 := by
  intro p hp
  have h : env52241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52240_52241 : H12AffineEnvironment.transform 11 570 env52240 = env52241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 570 env52240 == env52241) = true)

theorem identity52241 : scanCanonicalize (H12AffineFastState.compose env52241 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound52241 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52242 : List Nat := [2,4,3,16,32,16,2,5,512,52,1,561,3,512,1,2,529,32,53,0,545,32,17,3,2,16,0,528,561,32,52,33,4,33,512,513]

theorem envBound52242 : H12AffineFastState.Bounded env52242 := by
  intro p hp
  have h : env52242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52241_52242 : H12AffineEnvironment.transform 2 3 env52241 = env52242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env52241 == env52242) = true)

theorem identity52242 : scanCanonicalize (H12AffineFastState.compose env52242 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound52242 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52243 : List Nat := [2,4,3,16,32,16,2,5,4,52,1,53,3,4,1,2,21,32,53,0,37,32,17,3,2,16,0,20,53,32,52,33,4,33,4,5]

theorem envBound52243 : H12AffineFastState.Bounded env52243 := by
  intro p hp
  have h : env52243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52242_52243 : H12AffineEnvironment.transform 8 4 env52242 = env52243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env52242 == env52243) = true)

theorem identity52243 : scanCanonicalize (H12AffineFastState.compose env52243 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound52243 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52244 : List Nat := [2,4,3,16,16,16,2,5,4,4,1,5,3,4,1,2,21,16,5,0,21,16,17,3,2,16,0,20,5,16,4,17,4,17,4,5]

theorem envBound52244 : H12AffineFastState.Bounded env52244 := by
  intro p hp
  have h : env52244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52243_52244 : H12AffineEnvironment.transform 4 16 env52243 = env52244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env52243 == env52244) = true)

theorem identity52244 : scanCanonicalize (H12AffineFastState.compose env52244 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound52244 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env52245 : List Nat := [2,4,3,4,4,4,2,5,4,4,1,5,3,4,1,2,1,4,5,0,1,4,5,3,2,4,0,0,5,4,4,5,4,5,4,5]

theorem envBound52245 : H12AffineFastState.Bounded env52245 := by
  intro p hp
  have h : env52245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52244_52245 : H12AffineEnvironment.transform 3 4 env52244 = env52245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env52244 == env52245) = true)

theorem identity52245 : scanCanonicalize (H12AffineFastState.compose env52245 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound52245 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52246 : List Nat := [0,4,1,4,4,4,0,5,4,4,1,5,1,4,1,0,1,4,5,0,1,4,5,1,0,4,0,0,5,4,4,5,4,5,4,5]

theorem envBound52246 : H12AffineFastState.Bounded env52246 := by
  intro p hp
  have h : env52246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52245_52246 : H12AffineEnvironment.transform 0 0 env52245 = env52246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env52245 == env52246) = true)

def env52247 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,262144,1025,29829,4113,411924,156037,201885,8328,17,2184,160900,140436,283904,1421,272392,257,21793,16385,74251]

theorem envBound52247 : H12AffineFastState.Bounded env52247 := by
  intro p hp
  have h : env52247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52230_52247 : H12AffineEnvironment.transform 5 17 env52230 = env52247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52230 == env52247) = true)

theorem identity52247 : scanCanonicalize (H12AffineFastState.compose env52247 (packedSelected [4,5,7,8,9,11,12,15,16,17,19,20,24,27,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 204219) := by decide +kernel

theorem selectedBound52247 : packedSelected [4,5,7,8,9,11,12,15,16,17,19,20,24,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env52248 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,204219,1025,29829,4113,87215,156037,201885,8328,17,2184,160900,140436,215227,1421,210355,257,21793,16385,74251]

theorem envBound52248 : H12AffineFastState.Bounded env52248 := by
  intro p hp
  have h : env52248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52247_52248 : H12AffineEnvironment.transform 17 204219 env52247 = env52248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 204219 env52247 == env52248) = true)

theorem identity52248 : scanCanonicalize (H12AffineFastState.compose env52248 (packedSelected [5,8,10,16,17,18,20,23,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 79250) := by decide +kernel

theorem selectedBound52248 : packedSelected [5,8,10,16,17,18,20,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env52249 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,79250,10281,1025,29829,4113,87215,87063,8463,8328,17,2184,82198,69894,32041,1421,33,257,21793,16385,74251]

theorem envBound52249 : H12AffineFastState.Bounded env52249 := by
  intro p hp
  have h : env52249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52248_52249 : H12AffineEnvironment.transform 16 79250 env52248 = env52249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79250 env52248 == env52249) = true)

theorem identity52249 : scanCanonicalize (H12AffineFastState.compose env52249 (packedSelected [0,2,3,5,6,7,10,11,17,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13444) := by decide +kernel

theorem selectedBound52249 : packedSelected [0,2,3,5,6,7,10,11,17,20,23] rootPS < 2^1333 := by decide +kernel

def env52250 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13444,0,65536,79250,10281,1025,1,4113,73771,73875,8463,8328,17,2184,79250,69894,2477,1421,33,257,8613,13445,74251]

theorem envBound52250 : H12AffineFastState.Bounded env52250 := by
  intro p hp
  have h : env52250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52249_52250 : H12AffineEnvironment.transform 13 13444 env52249 = env52250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13444 env52249 == env52250) = true)

theorem identity52250 : scanCanonicalize (H12AffineFastState.compose env52250 (packedSelected [1,8,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound52250 : packedSelected [1,8,17,19] rootPS < 2^1333 := by decide +kernel

def env52251 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13444,0,263,13461,10281,1025,1,4113,8492,8596,8463,8328,17,2184,13461,4097,2477,1421,33,257,8613,13445,8972]

theorem envBound52251 : H12AffineFastState.Bounded env52251 := by
  intro p hp
  have h : env52251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52250_52251 : H12AffineEnvironment.transform 15 263 env52250 = env52251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env52250 == env52251) = true)

theorem identity52251 : scanCanonicalize (H12AffineFastState.compose env52251 (packedSelected [2,4,5,6,7,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 6315) := by decide +kernel

theorem selectedBound52251 : packedSelected [2,4,5,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env52252 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,6315,3119,0,263,3134,4226,1025,1,4113,6535,6463,6564,6179,17,2184,3134,4097,2477,1421,33,257,6414,3118,7079]

theorem envBound52252 : H12AffineFastState.Bounded env52252 := by
  intro p hp
  have h : env52252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52251_52252 : H12AffineEnvironment.transform 12 6315 env52251 = env52252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6315 env52251 == env52252) = true)

theorem identity52252 : scanCanonicalize (H12AffineFastState.compose env52252 (packedSelected [0,1,5,9,11,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 2200) := by decide +kernel

theorem selectedBound52252 : packedSelected [0,1,5,9,11,15,16] rootPS < 2^1333 := by decide +kernel

def env52253 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2200,51,3119,0,263,3134,2074,1025,1,2185,287,423,316,187,17,2184,3134,2201,2477,1421,33,257,406,3118,831]

theorem envBound52253 : H12AffineFastState.Bounded env52253 := by
  intro p hp
  have h : env52253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52252_52253 : H12AffineEnvironment.transform 11 2200 env52252 = env52253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2200 env52252 == env52253) = true)

theorem identity52253 : scanCanonicalize (H12AffineFastState.compose env52253 (packedSelected [0,2,6,7,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 435) := by decide +kernel

theorem selectedBound52253 : packedSelected [0,2,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env52254 : List Nat := [2,4,8,16,32,17,128,256,512,435,2048,2200,51,2460,0,263,2445,2074,434,1,2185,287,423,316,187,17,2184,2445,2201,2477,62,33,257,406,2461,831]

theorem envBound52254 : H12AffineFastState.Bounded env52254 := by
  intro p hp
  have h : env52254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52253_52254 : H12AffineEnvironment.transform 9 435 env52253 = env52254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 435 env52253 == env52254) = true)

theorem identity52254 : scanCanonicalize (H12AffineFastState.compose env52254 (packedSelected [0,1,5,6,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound52254 : packedSelected [0,1,5,6,9,10] rootPS < 2^1333 := by decide +kernel

def env52255 : List Nat := [2,4,8,16,32,17,128,31,512,172,2048,2200,51,2179,0,24,2194,2074,173,1,2185,0,184,35,187,17,2184,2194,2201,2226,62,33,30,137,2178,544]

theorem envBound52255 : H12AffineFastState.Bounded env52255 := by
  intro p hp
  have h : env52255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52254_52255 : H12AffineEnvironment.transform 7 31 env52254 = env52255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env52254 == env52255) = true)

theorem identity52255 : scanCanonicalize (H12AffineFastState.compose env52255 (packedSelected [0,1,2,3,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52255 : packedSelected [0,1,2,3,9] rootPS < 2^1333 := by decide +kernel

def env52256 : List Nat := [2,4,8,16,32,17,8,31,512,36,2048,2064,51,2059,0,24,2074,2074,37,1,2049,0,48,35,51,17,2048,2074,2065,2106,62,33,30,1,2058,544]

theorem envBound52256 : H12AffineFastState.Bounded env52256 := by
  intro p hp
  have h : env52256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52255_52256 : H12AffineEnvironment.transform 6 8 env52255 = env52256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52255 == env52256) = true)

theorem identity52256 : scanCanonicalize (H12AffineFastState.compose env52256 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound52256 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env52257 : List Nat := [2,4,8,16,32,17,8,31,16,36,2048,2064,51,2059,0,24,2074,2074,37,1,2049,0,48,35,51,17,2048,2074,2065,2106,62,33,30,1,2058,48]

theorem envBound52257 : H12AffineFastState.Bounded env52257 := by
  intro p hp
  have h : env52257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52256_52257 : H12AffineEnvironment.transform 8 16 env52256 = env52257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env52256 == env52257) = true)

theorem identity52257 : scanCanonicalize (H12AffineFastState.compose env52257 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52257 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52258 : List Nat := [2,4,8,16,1,17,8,31,16,5,2048,2064,18,2059,0,24,2074,2074,4,1,2049,0,17,2,18,17,2048,2074,2065,2075,31,0,30,1,2058,17]

theorem envBound52258 : H12AffineFastState.Bounded env52258 := by
  intro p hp
  have h : env52258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52257_52258 : H12AffineEnvironment.transform 4 1 env52257 = env52258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52257 == env52258) = true)

theorem identity52258 : scanCanonicalize (H12AffineFastState.compose env52258 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound52258 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52259 : List Nat := [2,4,8,3,1,2,8,12,3,5,2048,2051,1,2059,0,11,2057,2057,4,1,2049,0,2,2,1,2,2048,2057,2050,2056,12,0,13,1,2058,2]

theorem envBound52259 : H12AffineFastState.Bounded env52259 := by
  intro p hp
  have h : env52259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52258_52259 : H12AffineEnvironment.transform 3 3 env52258 = env52259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env52258 == env52259) = true)

theorem identity52259 : scanCanonicalize (H12AffineFastState.compose env52259 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound52259 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52260 : List Nat := [2,4,0,3,1,2,0,4,3,5,2048,2051,1,2051,0,3,2049,2049,4,1,2049,0,2,2,1,2,2048,2049,2050,2048,4,0,5,1,2050,2]

theorem envBound52260 : H12AffineFastState.Bounded env52260 := by
  intro p hp
  have h : env52260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52259_52260 : H12AffineEnvironment.transform 2 0 env52259 = env52260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env52259 == env52260) = true)

theorem identity52260 : scanCanonicalize (H12AffineFastState.compose env52260 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound52260 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52261 : List Nat := [2,4,0,3,1,2,0,4,3,5,1,2,1,2,0,3,0,0,4,1,0,0,2,2,1,2,1,0,3,1,4,0,5,1,3,2]

theorem envBound52261 : H12AffineFastState.Bounded env52261 := by
  intro p hp
  have h : env52261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52260_52261 : H12AffineEnvironment.transform 10 1 env52260 = env52261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env52260 == env52261) = true)

theorem identity52261 : scanCanonicalize (H12AffineFastState.compose env52261 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound52261 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52262 : List Nat := [2,2,0,3,1,2,0,2,3,3,1,2,1,2,0,3,0,0,2,1,0,0,2,2,1,2,1,0,3,1,2,0,3,1,3,2]

theorem envBound52262 : H12AffineFastState.Bounded env52262 := by
  intro p hp
  have h : env52262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52261_52262 : H12AffineEnvironment.transform 1 2 env52261 = env52262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env52261 == env52262) = true)

theorem identity52262 : scanCanonicalize (H12AffineFastState.compose env52262 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound52262 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env52263 : List Nat := [0,0,0,1,1,0,0,0,1,1,1,0,1,0,0,1,0,0,0,1,0,0,0,0,1,0,1,0,1,1,0,0,1,1,1,0]

theorem envBound52263 : H12AffineFastState.Bounded env52263 := by
  intro p hp
  have h : env52263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52262_52263 : H12AffineEnvironment.transform 0 0 env52262 = env52263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env52262 == env52263) = true)

def env52264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441744,156117,253977,8328,64,64604,160980,140485,303572,1501,272393,257,21793,46213,74250]

theorem envBound52264 : H12AffineFastState.Bounded env52264 := by
  intro p hp
  have h : env52264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52228_52264 : H12AffineEnvironment.transform 20 4161 env52228 = env52264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env52228 == env52264) = true)

theorem identity52264 : scanCanonicalize (H12AffineFastState.compose env52264 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 25028) := by decide +kernel

theorem selectedBound52264 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,4161,318548,17,98781,8328,64,64604,5392,17665,303572,1501,272393,257,21793,46213,74250]

theorem envBound52265 : H12AffineFastState.Bounded env52265 := by
  intro p hp
  have h : env52265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52264_52265 : H12AffineEnvironment.transform 16 25028 env52264 = env52265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25028 env52264 == env52265) = true)

def env52266 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4161,318548,17,98645,8192,64,64604,5392,17665,303452,1365,272393,257,21793,46093,74250]

theorem envBound52266 : H12AffineFastState.Bounded env52266 := by
  intro p hp
  have h : env52266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52265_52266 : H12AffineEnvironment.transform 6 8 env52265 = env52266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52265 == env52266) = true)

theorem identity52266 : scanCanonicalize (H12AffineFastState.compose env52266 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound52266 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52267 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,35189,1025,32769,4161,21793,17,98645,8192,64,64604,5392,17665,10281,1365,41340,257,21793,46093,74250]

theorem envBound52267 : H12AffineFastState.Bounded env52267 := by
  intro p hp
  have h : env52267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52266_52267 : H12AffineEnvironment.transform 17 35189 env52266 = env52267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env52266 == env52267) = true)

theorem identity52267 : scanCanonicalize (H12AffineFastState.compose env52267 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52267 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env52268 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24860,35109,1025,32769,4113,21793,17,98565,8192,16,64524,5392,17665,10281,1285,41260,257,21793,46093,74250]

theorem envBound52268 : H12AffineFastState.Bounded env52268 := by
  intro p hp
  have h : env52268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52267_52268 : H12AffineEnvironment.transform 5 16 env52267 = env52268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52267 == env52268) = true)

theorem identity52268 : scanCanonicalize (H12AffineFastState.compose env52268 (packedSelected [4,5,9,12,14,15,19,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 21795) := by decide +kernel

theorem selectedBound52268 : packedSelected [4,5,9,12,14,15,19,20,24] rootPS < 2^1333 := by decide +kernel

def env52269 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,21795,24860,35109,1025,32769,4113,21793,17,54310,8192,16,64524,5392,17665,10281,1285,41260,257,21793,46093,30505]

theorem envBound52269 : H12AffineFastState.Bounded env52269 := by
  intro p hp
  have h : env52269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52268_52269 : H12AffineEnvironment.transform 15 21795 env52268 = env52269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21795 env52268 == env52269) = true)

theorem identity52269 : scanCanonicalize (H12AffineFastState.compose env52269 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound52269 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env52270 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13608,32768,8203,5172,35109,1025,32769,4113,8201,17,41230,8192,16,35108,5392,12329,10281,1285,41260,257,8201,46093,513]

theorem envBound52270 : H12AffineFastState.Bounded env52270 := by
  intro p hp
  have h : env52270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52269_52270 : H12AffineEnvironment.transform 13 13608 env52269 = env52270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env52269 == env52270) = true)

theorem identity52270 : scanCanonicalize (H12AffineFastState.compose env52270 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound52270 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52271 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,1337,4113,32768,1330,5172,35109,1025,32769,4113,1328,17,33847,1337,16,35108,5392,5392,3344,1285,33813,257,1328,37172,513]

theorem envBound52271 : H12AffineFastState.Bounded env52271 := by
  intro p hp
  have h : env52271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52270_52271 : H12AffineEnvironment.transform 12 1337 env52270 = env52271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env52270 == env52271) = true)

def env52272 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4161,318548,17,98644,8193,64,64604,5392,17665,303453,1364,272393,257,21793,46092,74250]

theorem envBound52272 : H12AffineFastState.Bounded env52272 := by
  intro p hp
  have h : env52272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52265_52272 : H12AffineEnvironment.transform 6 9 env52265 = env52272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52265 == env52272) = true)

theorem identity52272 : scanCanonicalize (H12AffineFastState.compose env52272 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound52272 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52273 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,10281,1025,32769,4161,62589,17,98644,8193,64,64604,5392,17665,35188,1364,32,257,21793,46092,74250]

theorem envBound52273 : H12AffineFastState.Bounded env52273 := by
  intro p hp
  have h : env52273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52272_52273 : H12AffineEnvironment.transform 17 10281 env52272 = env52273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env52272 == env52273) = true)

theorem identity52273 : scanCanonicalize (H12AffineFastState.compose env52273 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound52273 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env52274 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,24909,10281,1025,32769,4161,62589,17,29791,8193,64,64604,5392,17665,35188,1364,32,257,21793,46092,55041]

theorem envBound52274 : H12AffineFastState.Bounded env52274 := by
  intro p hp
  have h : env52274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52273_52274 : H12AffineEnvironment.transform 15 62731 env52273 = env52274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env52273 == env52274) = true)

theorem identity52274 : scanCanonicalize (H12AffineFastState.compose env52274 (packedSelected [0,1,4,7,8,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound52274 : packedSelected [0,1,4,7,8,19,22] rootPS < 2^1333 := by decide +kernel

def env52275 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,21591,24909,10281,1025,8541,4161,21793,17,29791,8193,64,23808,5392,17665,10280,1364,32,257,21793,5456,30301]

theorem envBound52275 : H12AffineFastState.Bounded env52275 := by
  intro p hp
  have h : env52275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52274_52275 : H12AffineEnvironment.transform 14 8540 env52274 = env52275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env52274 == env52275) = true)

theorem identity52275 : scanCanonicalize (H12AffineFastState.compose env52275 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound52275 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env52276 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8540,8203,5393,10281,1025,8541,4161,8573,17,3,8193,64,10588,5392,12637,10280,1364,32,257,8573,5456,513]

theorem envBound52276 : H12AffineFastState.Bounded env52276 := by
  intro p hp
  have h : env52276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52275_52276 : H12AffineEnvironment.transform 13 13404 env52275 = env52276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env52275 == env52276) = true)

theorem identity52276 : scanCanonicalize (H12AffineFastState.compose env52276 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound52276 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52277 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,343,5393,2421,1025,1,4161,33,17,3,349,64,2048,5392,4097,2420,1364,32,257,33,5456,513]

theorem envBound52277 : H12AffineFastState.Bounded env52277 := by
  intro p hp
  have h : env52277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52276_52277 : H12AffineEnvironment.transform 12 348 env52276 = env52277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env52276 == env52277) = true)

theorem identity52277 : scanCanonicalize (H12AffineFastState.compose env52277 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound52277 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52278 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,16,348,1296,0,343,1281,2421,1025,1,81,33,17,3,349,64,2048,1280,17,2420,1364,32,257,33,1344,513]

theorem envBound52278 : H12AffineFastState.Bounded env52278 := by
  intro p hp
  have h : env52278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52277_52278 : H12AffineEnvironment.transform 11 16 env52277 = env52278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env52277 == env52278) = true)

theorem identity52278 : scanCanonicalize (H12AffineFastState.compose env52278 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 1556) := by decide +kernel

theorem selectedBound52278 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env52279 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1556,16,348,1296,0,343,1281,1889,1025,1,81,33,17,3,349,64,1556,1280,17,1888,1364,32,257,33,1344,513]

theorem envBound52279 : H12AffineFastState.Bounded env52279 := by
  intro p hp
  have h : env52279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52278_52279 : H12AffineEnvironment.transform 10 1556 env52278 = env52279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1556 env52278 == env52279) = true)

theorem identity52279 : scanCanonicalize (H12AffineFastState.compose env52279 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 865) := by decide +kernel

theorem selectedBound52279 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env52280 : List Nat := [2,4,8,16,32,64,9,256,512,865,373,16,348,625,0,343,608,0,864,1,81,33,17,3,349,64,373,609,17,1,565,32,257,33,545,513]

theorem envBound52280 : H12AffineFastState.Bounded env52280 := by
  intro p hp
  have h : env52280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52279_52280 : H12AffineEnvironment.transform 9 865 env52279 = env52280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 865 env52279 == env52280) = true)

theorem identity52280 : scanCanonicalize (H12AffineFastState.compose env52280 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound52280 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env52281 : List Nat := [2,4,8,16,32,64,9,256,277,116,373,16,348,356,0,343,373,0,117,1,81,33,17,3,349,64,373,372,17,1,288,32,257,33,308,276]

theorem envBound52281 : H12AffineFastState.Bounded env52281 := by
  intro p hp
  have h : env52281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52280_52281 : H12AffineEnvironment.transform 8 277 env52280 = env52281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env52280 == env52281) = true)

theorem identity52281 : scanCanonicalize (H12AffineFastState.compose env52281 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52281 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env52282 : List Nat := [2,4,8,16,0,64,9,256,277,84,341,16,348,324,0,343,341,0,85,1,81,1,17,3,349,64,341,340,17,1,256,0,257,1,276,276]

theorem envBound52282 : H12AffineFastState.Bounded env52282 := by
  intro p hp
  have h : env52282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52281_52282 : H12AffineEnvironment.transform 4 0 env52281 = env52282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52281 == env52282) = true)

theorem identity52282 : scanCanonicalize (H12AffineFastState.compose env52282 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound52282 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env52283 : List Nat := [2,4,8,16,0,64,9,69,80,84,16,16,25,1,0,18,16,0,85,1,81,1,17,3,24,64,16,17,17,1,69,0,68,1,81,81]

theorem envBound52283 : H12AffineFastState.Bounded env52283 := by
  intro p hp
  have h : env52283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52282_52283 : H12AffineEnvironment.transform 7 69 env52282 = env52283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env52282 == env52283) = true)

theorem identity52283 : scanCanonicalize (H12AffineFastState.compose env52283 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52283 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env52284 : List Nat := [2,4,8,16,0,16,9,21,0,4,16,16,25,1,0,18,16,0,5,1,1,1,17,3,24,16,16,17,17,1,21,0,20,1,1,1]

theorem envBound52284 : H12AffineFastState.Bounded env52284 := by
  intro p hp
  have h : env52284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52283_52284 : H12AffineEnvironment.transform 5 16 env52283 = env52284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52283 == env52284) = true)

theorem identity52284 : scanCanonicalize (H12AffineFastState.compose env52284 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound52284 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52285 : List Nat := [2,4,8,1,0,1,9,4,0,4,1,1,8,1,0,3,1,0,5,1,1,1,0,3,9,1,1,0,0,1,4,0,5,1,1,1]

theorem envBound52285 : H12AffineFastState.Bounded env52285 := by
  intro p hp
  have h : env52285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52284_52285 : H12AffineEnvironment.transform 3 1 env52284 = env52285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env52284 == env52285) = true)

def env52286 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441745,2257300,253977,8328,64,2157596,2253973,140485,2404757,2102684,2373705,257,21793,46213,2175563]

theorem envBound52286 : H12AffineFastState.Bounded env52286 := by
  intro p hp
  have h : env52286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52227_52286 : H12AffineEnvironment.transform 21 441745 env52227 = env52286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441745 env52227 == env52286) = true)

def env52287 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441745,156116,253977,8328,64,64604,160981,140485,303573,1500,272393,257,21793,46213,74251]

theorem envBound52287 : H12AffineFastState.Bounded env52287 := by
  intro p hp
  have h : env52287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52286_52287 : H12AffineEnvironment.transform 20 4160 env52286 = env52287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env52286 == env52287) = true)

theorem identity52287 : scanCanonicalize (H12AffineFastState.compose env52287 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound52287 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52288 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4160,272513,62660,95497,8328,64,64604,57797,45525,303573,1500,272393,257,21793,46213,74251]

theorem envBound52288 : H12AffineFastState.Bounded env52288 := by
  intro p hp
  have h : env52288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52287_52288 : H12AffineEnvironment.transform 16 38160 env52287 = env52288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env52287 == env52288) = true)

theorem identity52288 : scanCanonicalize (H12AffineFastState.compose env52288 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound52288 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env52289 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38160,262144,1025,32769,4160,272513,62660,21763,8328,64,64604,57797,45525,303573,1500,272393,257,21793,46213,513]

theorem envBound52289 : H12AffineFastState.Bounded env52289 := by
  intro p hp
  have h : env52289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52288_52289 : H12AffineEnvironment.transform 15 8202 env52288 = env52289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env52288 == env52289) = true)

theorem identity52289 : scanCanonicalize (H12AffineFastState.compose env52289 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 64929) := by decide +kernel

theorem selectedBound52289 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env52290 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38160,64929,1025,32769,4160,54560,62660,21763,8328,64,64604,57797,45525,23668,1500,54696,257,21793,46213,513]

theorem envBound52290 : H12AffineFastState.Bounded env52290 := by
  intro p hp
  have h : env52290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52289_52290 : H12AffineEnvironment.transform 17 64929 env52289 = env52290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64929 env52289 == env52290) = true)

theorem identity52290 : scanCanonicalize (H12AffineFastState.compose env52290 (packedSelected [2,3,4,5,6,7,8,9,11,16,20,27,28,32] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound52290 : packedSelected [2,3,4,5,6,7,8,9,11,16,20,27,28,32] rootPS < 2^1333 := by decide +kernel

def env52291 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13325,32768,8202,38160,35244,1025,32769,4160,41261,32969,8462,8328,64,34897,38344,45525,10361,1500,41381,257,8492,46213,513]

theorem envBound52291 : H12AffineFastState.Bounded env52291 := by
  intro p hp
  have h : env52291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52290_52291 : H12AffineEnvironment.transform 13 13325 env52290 = env52291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env52290 == env52291) = true)

theorem identity52291 : scanCanonicalize (H12AffineFastState.compose env52291 (packedSelected [2,4,6,9,14,16,17,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound52291 : packedSelected [2,4,6,9,14,16,17,18,23] rootPS < 2^1333 := by decide +kernel

def env52292 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13325,8541,8202,13389,10481,1025,8540,4160,112,8596,8462,8328,64,10508,13461,4232,10361,1500,248,257,8492,5592,513]

theorem envBound52292 : H12AffineFastState.Bounded env52292 := by
  intro p hp
  have h : env52292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52291_52292 : H12AffineEnvironment.transform 14 8541 env52291 = env52292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env52291 == env52292) = true)

theorem identity52292 : scanCanonicalize (H12AffineFastState.compose env52292 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52292 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env52293 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,8541,8202,13389,10361,1025,8540,4160,112,8476,8462,8192,64,10508,13341,4096,10361,1364,112,257,8492,5456,513]

theorem envBound52293 : H12AffineFastState.Bounded env52293 := by
  intro p hp
  have h : env52293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52292_52293 : H12AffineEnvironment.transform 6 8 env52292 = env52293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52292 == env52293) = true)

theorem identity52293 : scanCanonicalize (H12AffineFastState.compose env52293 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound52293 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52294 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,4096,8192,12620,8541,8202,12556,10361,320,8540,4160,112,8476,8462,8192,64,10508,12636,4096,10361,21,112,257,8492,4113,513]

theorem envBound52294 : H12AffineFastState.Bounded env52294 := by
  intro p hp
  have h : env52294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52293_52294 : H12AffineEnvironment.transform 9 321 env52293 = env52294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env52293 == env52294) = true)

theorem identity52294 : scanCanonicalize (H12AffineFastState.compose env52294 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound52294 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env52295 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,4096,269,4161,80,263,4097,2420,320,81,4160,112,17,3,269,64,2049,4177,4096,2420,21,112,257,33,4113,513]

theorem envBound52295 : H12AffineFastState.Bounded env52295 := by
  intro p hp
  have h : env52295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52294_52295 : H12AffineEnvironment.transform 12 269 env52294 = env52295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env52294 == env52295) = true)

theorem identity52295 : scanCanonicalize (H12AffineFastState.compose env52295 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound52295 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env52296 : List Nat := [2,4,8,16,32,64,8,256,512,321,293,4096,269,4161,80,263,4097,81,320,81,4160,112,17,3,269,64,292,4177,4096,81,21,112,257,33,4113,513]

theorem envBound52296 : H12AffineFastState.Bounded env52296 := by
  intro p hp
  have h : env52296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52295_52296 : H12AffineEnvironment.transform 10 293 env52295 = env52296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env52295 == env52296) = true)

def env52297 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441745,156117,253977,8328,64,64605,160980,140485,303572,1501,272392,257,21793,46213,74250]

theorem envBound52297 : H12AffineFastState.Bounded env52297 := by
  intro p hp
  have h : env52297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52286_52297 : H12AffineEnvironment.transform 20 4161 env52286 = env52297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env52286 == env52297) = true)

def env52298 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4161,169401,156117,253977,8328,64,64605,160980,140485,35324,1501,32,257,21793,46213,74250]

theorem envBound52298 : H12AffineFastState.Bounded env52298 := by
  intro p hp
  have h : env52298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52297_52298 : H12AffineEnvironment.transform 17 10280 env52297 = env52298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env52297 == env52298) = true)

def env52299 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1025,32769,4161,21929,41413,73737,8328,64,64605,46276,58581,35324,1501,32,257,21793,46213,74250]

theorem envBound52299 : H12AffineFastState.Bounded env52299 := by
  intro p hp
  have h : env52299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52298_52299 : H12AffineEnvironment.transform 16 49168 env52298 = env52299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env52298 == env52299) = true)

theorem identity52299 : scanCanonicalize (H12AffineFastState.compose env52299 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound52299 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52300 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,25029,10280,1025,8660,4161,21929,16,73737,8328,64,23944,5393,17664,10281,1501,32,257,21793,5456,74250]

theorem envBound52300 : H12AffineFastState.Bounded env52300 := by
  intro p hp
  have h : env52300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52299_52300 : H12AffineEnvironment.transform 14 8661 env52299 = env52300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env52299 == env52300) = true)

theorem identity52300 : scanCanonicalize (H12AffineFastState.compose env52300 (packedSelected [4,5,7,9,19,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 28866) := by decide +kernel

theorem selectedBound52300 : packedSelected [4,5,7,9,19,24,27] rootPS < 2^1333 := by decide +kernel

def env52301 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,28866,25029,10280,1025,8660,4161,21929,16,20683,8328,64,23944,5393,17664,10281,1501,32,257,21793,5456,21192]

theorem envBound52301 : H12AffineFastState.Bounded env52301 := by
  intro p hp
  have h : env52301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52300_52301 : H12AffineEnvironment.transform 15 28866 env52300 = env52301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28866 env52300 == env52301) = true)

theorem identity52301 : scanCanonicalize (H12AffineFastState.compose env52301 (packedSelected [0,1,2,6,7,8,18,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 12692) := by decide +kernel

theorem selectedBound52301 : packedSelected [0,1,2,6,7,8,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env52302 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12692,8661,342,4177,10280,1025,8660,4161,9277,16,8543,8328,64,11292,5393,13460,10281,1501,32,257,9397,5456,9052]

theorem envBound52302 : H12AffineFastState.Bounded env52302 := by
  intro p hp
  have h : env52302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52301_52302 : H12AffineEnvironment.transform 13 12692 env52301 = env52302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12692 env52301 == env52302) = true)

theorem identity52302 : scanCanonicalize (H12AffineFastState.compose env52302 (packedSelected [0,1,4,7,8,16,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound52302 : packedSelected [0,1,4,7,8,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env52303 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,4248,217,342,4177,2340,1025,216,4161,1329,16,83,388,64,3344,5393,5528,2341,1501,32,257,1465,5456,592]

theorem envBound52303 : H12AffineFastState.Bounded env52303 := by
  intro p hp
  have h : env52303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52302_52303 : H12AffineEnvironment.transform 12 268 env52302 = env52303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env52302 == env52303) = true)

theorem identity52303 : scanCanonicalize (H12AffineFastState.compose env52303 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound52303 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env52304 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,161,4248,217,251,4177,2185,1025,216,4161,1180,16,83,41,64,3261,5308,5173,2184,1136,32,172,1044,5373,592]

theorem envBound52304 : H12AffineFastState.Bounded env52304 := by
  intro p hp
  have h : env52304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52303_52304 : H12AffineEnvironment.transform 7 173 env52303 = env52304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env52303 == env52304) = true)

theorem identity52304 : scanCanonicalize (H12AffineFastState.compose env52304 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound52304 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env52305 : List Nat := [2,4,8,16,32,64,89,116,512,1024,2048,4096,120,4161,0,34,4177,2128,1025,1,4161,1093,16,83,41,64,3172,5221,5173,2129,1136,32,117,1044,5156,592]

theorem envBound52305 : H12AffineFastState.Bounded env52305 := by
  intro p hp
  have h : env52305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52304_52305 : H12AffineEnvironment.transform 6 89 env52304 = env52305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env52304 == env52305) = true)

theorem identity52305 : scanCanonicalize (H12AffineFastState.compose env52305 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound52305 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52306 : List Nat := [2,4,8,16,32,64,89,116,512,101,2048,4096,120,4161,0,34,4177,2128,100,1,4161,32,16,83,41,64,2049,4096,4176,2129,21,32,117,113,4161,592]

theorem envBound52306 : H12AffineFastState.Bounded env52306 := by
  intro p hp
  have h : env52306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52305_52306 : H12AffineEnvironment.transform 9 101 env52305 = env52306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env52305 == env52306) = true)

theorem identity52306 : scanCanonicalize (H12AffineFastState.compose env52306 (packedSelected [4,6] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound52306 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env52307 : List Nat := [2,4,8,16,4,64,89,80,512,65,2048,4096,92,4161,0,6,4177,2128,64,1,4161,4,16,83,13,64,2049,4096,4176,2129,21,4,81,85,4161,592]

theorem envBound52307 : H12AffineFastState.Bounded env52307 := by
  intro p hp
  have h : env52307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52306_52307 : H12AffineEnvironment.transform 4 4 env52306 = env52307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env52306 == env52307) = true)

theorem identity52307 : scanCanonicalize (H12AffineFastState.compose env52307 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound52307 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env52308 : List Nat := [2,4,8,16,4,64,89,80,512,65,2048,2065,92,2128,0,6,2112,2128,64,1,2128,4,16,83,13,64,2049,2065,2113,2129,21,4,81,85,2128,592]

theorem envBound52308 : H12AffineFastState.Bounded env52308 := by
  intro p hp
  have h : env52308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52307_52308 : H12AffineEnvironment.transform 11 2065 env52307 = env52308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env52307 == env52308) = true)

theorem identity52308 : scanCanonicalize (H12AffineFastState.compose env52308 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 4) := by decide +kernel

theorem selectedBound52308 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env52309 : List Nat := [2,4,8,16,4,64,89,80,512,65,4,21,92,84,0,6,68,84,64,1,84,4,16,83,13,64,5,21,69,85,21,4,81,85,84,592]

theorem envBound52309 : H12AffineFastState.Bounded env52309 := by
  intro p hp
  have h : env52309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52308_52309 : H12AffineEnvironment.transform 10 4 env52308 = env52309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 4 env52308 == env52309) = true)

theorem identity52309 : scanCanonicalize (H12AffineFastState.compose env52309 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound52309 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52310 : List Nat := [2,1,8,16,1,64,89,80,512,65,1,16,89,81,0,3,65,81,64,1,81,1,16,83,8,64,0,16,64,80,16,1,81,80,81,592]

theorem envBound52310 : H12AffineFastState.Bounded env52310 := by
  intro p hp
  have h : env52310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52309_52310 : H12AffineEnvironment.transform 1 1 env52309 = env52310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env52309 == env52310) = true)

theorem identity52310 : scanCanonicalize (H12AffineFastState.compose env52310 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52310 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env52311 : List Nat := [2,1,8,16,1,16,9,0,512,17,1,16,9,1,0,3,17,1,16,1,1,1,16,3,8,16,0,16,16,0,16,1,1,0,1,512]

theorem envBound52311 : H12AffineFastState.Bounded env52311 := by
  intro p hp
  have h : env52311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52310_52311 : H12AffineEnvironment.transform 5 16 env52310 = env52311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52310 == env52311) = true)

theorem identity52311 : scanCanonicalize (H12AffineFastState.compose env52311 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound52311 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52312 : List Nat := [2,1,8,1,1,1,9,0,512,0,1,1,9,1,0,3,0,1,1,1,1,1,1,3,8,1,0,1,1,0,1,1,1,0,1,512]

theorem envBound52312 : H12AffineFastState.Bounded env52312 := by
  intro p hp
  have h : env52312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52311_52312 : H12AffineEnvironment.transform 3 1 env52311 = env52312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env52311 == env52312) = true)

theorem identity52312 : scanCanonicalize (H12AffineFastState.compose env52312 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound52312 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52313 : List Nat := [2,1,8,1,1,1,9,0,9,0,1,1,9,1,0,3,0,1,1,1,1,1,1,3,8,1,0,1,1,0,1,1,1,0,1,9]

theorem envBound52313 : H12AffineFastState.Bounded env52313 := by
  intro p hp
  have h : env52313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52312_52313 : H12AffineEnvironment.transform 8 9 env52312 = env52313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env52312 == env52313) = true)

theorem identity52313 : scanCanonicalize (H12AffineFastState.compose env52313 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound52313 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env52314 : List Nat := [2,1,3,1,1,1,2,0,2,0,1,1,2,1,0,3,0,1,1,1,1,1,1,3,3,1,0,1,1,0,1,1,1,0,1,2]

theorem envBound52314 : H12AffineFastState.Bounded env52314 := by
  intro p hp
  have h : env52314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52313_52314 : H12AffineEnvironment.transform 2 3 env52313 = env52314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env52313 == env52314) = true)

def env52315 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1025,32769,4161,21928,41412,73736,8328,64,64605,46277,58580,35324,1501,32,257,21793,46213,74250]

theorem envBound52315 : H12AffineFastState.Bounded env52315 := by
  intro p hp
  have h : env52315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52298_52315 : H12AffineEnvironment.transform 16 49169 env52298 = env52315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env52298 == env52315) = true)

theorem identity52315 : scanCanonicalize (H12AffineFastState.compose env52315 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound52315 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52316 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,24908,10280,1025,8540,4161,21928,153,73736,8328,64,23808,5528,17801,10401,1501,32,257,21793,5592,74250]

theorem envBound52316 : H12AffineFastState.Bounded env52316 := by
  intro p hp
  have h : env52316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52315_52316 : H12AffineEnvironment.transform 14 8541 env52315 = env52316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env52315 == env52316) = true)

theorem identity52316 : scanCanonicalize (H12AffineFastState.compose env52316 (packedSelected [4,5,7,9,18,19,23,24,27] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound52316 : packedSelected [4,5,7,9,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env52317 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,16384,8541,65536,24908,10280,273,8540,4161,20664,153,73736,8328,64,22544,4232,16537,10401,205,32,257,20529,4296,74250]

theorem envBound52317 : H12AffineFastState.Bounded env52317 := by
  intro p hp
  have h : env52317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52316_52317 : H12AffineEnvironment.transform 9 272 env52316 = env52317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env52316 == env52317) = true)

theorem identity52317 : scanCanonicalize (H12AffineFastState.compose env52317 (packedSelected [11,23] rootPS)) = affineNative (2^(13+1) ^^^ 4541) := by decide +kernel

theorem selectedBound52317 : packedSelected [11,23] rootPS < 2^1333 := by decide +kernel

def env52318 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,4541,8541,65536,12529,10280,273,8540,4161,261,153,73736,8328,64,2477,4232,4388,10401,205,32,257,396,4296,74250]

theorem envBound52318 : H12AffineFastState.Bounded env52318 := by
  intro p hp
  have h : env52318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52317_52318 : H12AffineEnvironment.transform 13 4541 env52317 = env52318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4541 env52317 == env52318) = true)

theorem identity52318 : scanCanonicalize (H12AffineFastState.compose env52318 (packedSelected [0,1,2,3,4,6,7,8,9,10,11,14,18,19,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound52318 : packedSelected [0,1,2,3,4,6,7,8,9,10,11,14,18,19,24,26] rootPS < 2^1333 := by decide +kernel

def env52319 : List Nat := [2,4,8,16,32,64,88,256,512,272,2048,4096,8192,4453,8541,65536,12329,10280,273,8540,4161,261,65,73736,8272,64,2421,4176,4388,10361,21,32,257,340,4112,74250]

theorem envBound52319 : H12AffineFastState.Bounded env52319 := by
  intro p hp
  have h : env52319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52318_52319 : H12AffineEnvironment.transform 6 88 env52318 = env52319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env52318 == env52319) = true)

theorem identity52319 : scanCanonicalize (H12AffineFastState.compose env52319 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(15+1) ^^^ 8494) := by decide +kernel

theorem selectedBound52319 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env52320 : List Nat := [2,4,8,16,32,64,88,256,512,272,2048,4096,8192,4453,8541,8494,12329,10280,273,8540,4161,261,65,294,8272,64,2421,4176,4388,10361,21,32,257,340,4112,804]

theorem envBound52320 : H12AffineFastState.Bounded env52320 := by
  intro p hp
  have h : env52320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52319_52320 : H12AffineEnvironment.transform 15 8494 env52319 = env52320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8494 env52319 == env52320) = true)

theorem identity52320 : scanCanonicalize (H12AffineFastState.compose env52320 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound52320 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env52321 : List Nat := [2,4,8,16,32,64,88,256,512,272,2048,4096,40,4453,373,262,4097,2048,273,372,4161,261,65,294,120,64,2421,4176,4388,2129,21,32,257,340,4112,804]

theorem envBound52321 : H12AffineFastState.Bounded env52321 := by
  intro p hp
  have h : env52321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52320_52321 : H12AffineEnvironment.transform 12 40 env52320 = env52321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env52320 == env52321) = true)

theorem identity52321 : scanCanonicalize (H12AffineFastState.compose env52321 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52321 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52322 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,40,4404,292,262,4097,2048,273,293,4112,261,16,294,41,17,2340,4097,4388,2048,21,32,257,261,4112,804]

theorem envBound52322 : H12AffineFastState.Bounded env52322 := by
  intro p hp
  have h : env52322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52321_52322 : H12AffineEnvironment.transform 5 17 env52321 = env52322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52321 == env52322) = true)

theorem identity52322 : scanCanonicalize (H12AffineFastState.compose env52322 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 820) := by decide +kernel

theorem selectedBound52322 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env52323 : List Nat := [2,4,8,16,32,17,9,256,512,272,820,4096,40,4404,292,262,4097,820,273,293,4112,261,16,294,41,17,528,4097,4388,820,21,32,257,261,4112,804]

theorem envBound52323 : H12AffineFastState.Bounded env52323 := by
  intro p hp
  have h : env52323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52322_52323 : H12AffineEnvironment.transform 10 820 env52322 = env52323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 820 env52322 == env52323) = true)

theorem identity52323 : scanCanonicalize (H12AffineFastState.compose env52323 (packedSelected [4,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound52323 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env52324 : List Nat := [2,4,8,16,16,17,9,256,512,272,772,4096,24,4356,276,262,4097,772,273,277,4112,261,16,278,25,17,528,4097,4372,772,21,16,257,261,4112,788]

theorem envBound52324 : H12AffineFastState.Bounded env52324 := by
  intro p hp
  have h : env52324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52323_52324 : H12AffineEnvironment.transform 4 16 env52323 = env52324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env52323 == env52324) = true)

theorem identity52324 : scanCanonicalize (H12AffineFastState.compose env52324 (packedSelected [1,2,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound52324 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env52325 : List Nat := [2,4,8,16,16,17,9,4,512,20,512,4096,24,4096,16,2,4097,512,21,17,4112,1,16,18,25,17,528,4097,4112,512,21,16,5,1,4112,528]

theorem envBound52325 : H12AffineFastState.Bounded env52325 := by
  intro p hp
  have h : env52325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52324_52325 : H12AffineEnvironment.transform 7 4 env52324 = env52325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env52324 == env52325) = true)

def env52326 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4161,169400,156117,253977,8328,64,64605,160980,140485,35325,1501,33,257,21793,46213,74250]

theorem envBound52326 : H12AffineFastState.Bounded env52326 := by
  intro p hp
  have h : env52326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52297_52326 : H12AffineEnvironment.transform 17 10281 env52297 = env52326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env52297 == env52326) = true)

def env52327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1025,32769,4161,21928,41413,73737,8328,64,64605,46276,58581,35325,1501,33,257,21793,46213,74250]

theorem envBound52327 : H12AffineFastState.Bounded env52327 := by
  intro p hp
  have h : env52327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52326_52327 : H12AffineEnvironment.transform 16 49168 env52326 = env52327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env52326 == env52327) = true)

def env52328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,65536,49168,2557,1025,32769,4161,21928,32785,66013,348,64,56713,38160,50433,35325,1501,33,257,21793,38225,66526]

theorem envBound52328 : H12AffineFastState.Bounded env52328 := by
  intro p hp
  have h : env52328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52327_52328 : H12AffineEnvironment.transform 12 468 env52327 = env52328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env52327 == env52328) = true)

theorem identity52328 : scanCanonicalize (H12AffineFastState.compose env52328 (packedSelected [1,2,6,7,8,9,19,20,22,23,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound52328 : packedSelected [1,2,6,7,8,9,19,20,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env52329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21761,65536,5393,2557,1025,21760,4161,21928,21776,66013,348,64,2184,16401,4096,23804,1501,33,257,21793,16464,66526]

theorem envBound52329 : H12AffineFastState.Bounded env52329 := by
  intro p hp
  have h : env52329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52328_52329 : H12AffineEnvironment.transform 14 21761 env52328 = env52329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env52328 == env52329) = true)

theorem identity52329 : scanCanonicalize (H12AffineFastState.compose env52329 (packedSelected [2,3,5,6,7,9,10,11,16,18,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound52329 : packedSelected [2,3,5,6,7,9,10,11,16,18,22,27] rootPS < 2^1333 := by decide +kernel

def env52330 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21761,21590,5393,2557,1025,21760,4161,21928,21776,21899,348,64,2184,16401,4096,23804,1501,33,257,21793,16464,22408]

theorem envBound52330 : H12AffineFastState.Bounded env52330 := by
  intro p hp
  have h : env52330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52329_52330 : H12AffineEnvironment.transform 15 21590 env52329 = env52330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env52329 == env52330) = true)

theorem identity52330 : scanCanonicalize (H12AffineFastState.compose env52330 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound52330 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env52331 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,137,478,5393,2557,1025,136,4161,32,152,3,348,64,2184,5529,4096,2420,1501,33,257,169,5592,512]

theorem envBound52331 : H12AffineFastState.Bounded env52331 := by
  intro p hp
  have h : env52331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52330_52331 : H12AffineEnvironment.transform 13 5512 env52330 = env52331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env52330 == env52331) = true)

theorem identity52331 : scanCanonicalize (H12AffineFastState.compose env52331 (packedSelected [2,4,6,9,12,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound52331 : packedSelected [2,4,6,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env52332 : List Nat := [2,4,8,16,32,64,128,256,512,1024,137,4096,468,5512,137,478,5393,372,1025,136,4161,32,152,3,348,64,1,5529,4096,509,1501,33,257,169,5592,512]

theorem envBound52332 : H12AffineFastState.Bounded env52332 := by
  intro p hp
  have h : env52332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52331_52332 : H12AffineEnvironment.transform 10 137 env52331 = env52332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env52331 == env52332) = true)

theorem identity52332 : scanCanonicalize (H12AffineFastState.compose env52332 (packedSelected [1,3,4,5,8,9,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound52332 : packedSelected [1,3,4,5,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env52333 : List Nat := [2,4,8,16,32,49,128,256,512,1024,137,4096,421,5512,137,431,5393,261,1025,136,4144,32,152,3,301,49,1,5529,4096,396,1452,33,257,169,5545,512]

theorem envBound52333 : H12AffineFastState.Bounded env52333 := by
  intro p hp
  have h : env52333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52332_52333 : H12AffineEnvironment.transform 5 49 env52332 = env52333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env52332 == env52333) = true)

theorem identity52333 : scanCanonicalize (H12AffineFastState.compose env52333 (packedSelected [0,1,3,4,5,6,7,8,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound52333 : packedSelected [0,1,3,4,5,6,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env52334 : List Nat := [2,4,8,16,32,49,128,37,512,1024,137,4096,128,5293,137,138,5172,32,1025,136,4144,32,152,3,8,49,1,5308,4096,169,1161,33,36,169,5260,512]

theorem envBound52334 : H12AffineFastState.Bounded env52334 := by
  intro p hp
  have h : env52334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52333_52334 : H12AffineEnvironment.transform 7 37 env52333 = env52334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env52333 == env52334) = true)

theorem identity52334 : scanCanonicalize (H12AffineFastState.compose env52334 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 1196) := by decide +kernel

theorem selectedBound52334 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env52335 : List Nat := [2,4,8,16,32,49,128,37,512,1024,137,1196,128,1,137,138,152,32,1025,136,1180,32,152,3,8,49,1,16,1196,169,1161,33,36,169,32,512]

theorem envBound52335 : H12AffineFastState.Bounded env52335 := by
  intro p hp
  have h : env52335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52334_52335 : H12AffineEnvironment.transform 11 1196 env52334 = env52335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1196 env52334 == env52335) = true)

theorem identity52335 : scanCanonicalize (H12AffineFastState.compose env52335 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound52335 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env52336 : List Nat := [2,4,8,16,32,49,9,37,512,1024,0,1061,9,1,0,3,17,32,1025,1,1045,32,17,3,8,49,1,16,1061,32,1024,33,36,32,32,512]

theorem envBound52336 : H12AffineFastState.Bounded env52336 := by
  intro p hp
  have h : env52336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52335_52336 : H12AffineEnvironment.transform 6 9 env52335 = env52336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52335 == env52336) = true)

theorem identity52336 : scanCanonicalize (H12AffineFastState.compose env52336 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound52336 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52337 : List Nat := [2,4,8,16,32,49,9,37,512,543,0,570,9,1,0,3,17,32,542,1,522,32,17,3,8,49,1,16,570,32,543,33,36,32,32,512]

theorem envBound52337 : H12AffineFastState.Bounded env52337 := by
  intro p hp
  have h : env52337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52336_52337 : H12AffineEnvironment.transform 9 543 env52336 = env52337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env52336 == env52337) = true)

theorem identity52337 : scanCanonicalize (H12AffineFastState.compose env52337 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound52337 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52338 : List Nat := [2,4,8,16,32,49,9,37,32,63,0,26,9,1,0,3,17,32,62,1,42,32,17,3,8,49,1,16,26,32,63,33,36,32,32,32]

theorem envBound52338 : H12AffineFastState.Bounded env52338 := by
  intro p hp
  have h : env52338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52337_52338 : H12AffineEnvironment.transform 8 32 env52337 = env52338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env52337 == env52338) = true)

theorem identity52338 : scanCanonicalize (H12AffineFastState.compose env52338 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound52338 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52339 : List Nat := [2,4,6,16,32,49,7,37,32,49,0,20,7,1,0,3,17,32,48,1,36,32,17,3,6,49,1,16,20,32,49,33,36,32,32,32]

theorem envBound52339 : H12AffineFastState.Bounded env52339 := by
  intro p hp
  have h : env52339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52338_52339 : H12AffineEnvironment.transform 2 6 env52338 = env52339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env52338 == env52339) = true)

theorem identity52339 : scanCanonicalize (H12AffineFastState.compose env52339 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound52339 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52340 : List Nat := [2,4,6,5,32,36,7,37,32,36,0,1,7,1,0,3,4,32,37,1,36,32,4,3,6,36,1,5,1,32,36,33,36,32,32,32]

theorem envBound52340 : H12AffineFastState.Bounded env52340 := by
  intro p hp
  have h : env52340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52339_52340 : H12AffineEnvironment.transform 3 5 env52339 = env52340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env52339 == env52340) = true)

theorem identity52340 : scanCanonicalize (H12AffineFastState.compose env52340 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound52340 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env52341 : List Nat := [2,2,0,3,32,34,1,35,32,34,0,1,1,1,0,3,2,32,35,1,34,32,2,3,0,34,1,3,1,32,34,33,34,32,32,32]

theorem envBound52341 : H12AffineFastState.Bounded env52341 := by
  intro p hp
  have h : env52341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52340_52341 : H12AffineEnvironment.transform 1 2 env52340 = env52341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env52340 == env52341) = true)

theorem identity52341 : scanCanonicalize (H12AffineFastState.compose env52341 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound52341 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env52342 : List Nat := [1,1,0,0,32,33,1,32,32,33,0,1,1,1,0,0,1,32,32,1,33,32,1,0,0,33,1,0,1,32,33,33,33,32,32,32]

theorem envBound52342 : H12AffineFastState.Bounded env52342 := by
  intro p hp
  have h : env52342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52341_52342 : H12AffineEnvironment.transform 0 1 env52341 = env52342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env52341 == env52342) = true)

def env52343 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,32768,65536,49168,2556,1025,32769,4161,21928,32784,66012,349,64,56712,38161,50432,35325,1501,33,257,21793,38224,66527]

theorem envBound52343 : H12AffineFastState.Bounded env52343 := by
  intro p hp
  have h : env52343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52327_52343 : H12AffineEnvironment.transform 12 469 env52327 = env52343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env52327 == env52343) = true)

theorem identity52343 : scanCanonicalize (H12AffineFastState.compose env52343 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound52343 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env52344 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,32768,478,49168,2556,1025,32769,4161,21928,32784,2,349,64,56712,38161,50432,35325,1501,33,257,21793,38224,513]

theorem envBound52344 : H12AffineFastState.Bounded env52344 := by
  intro p hp
  have h : env52344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52343_52344 : H12AffineEnvironment.transform 15 478 env52343 = env52344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env52343 == env52344) = true)

theorem identity52344 : scanCanonicalize (H12AffineFastState.compose env52344 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound52344 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env52345 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,1,478,16401,2556,1025,0,4161,21928,17,2,349,64,23945,5392,17665,2556,1501,33,257,21793,5457,513]

theorem envBound52345 : H12AffineFastState.Bounded env52345 := by
  intro p hp
  have h : env52345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52344_52345 : H12AffineEnvironment.transform 14 1 env52344 = env52345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env52344 == env52345) = true)

theorem identity52345 : scanCanonicalize (H12AffineFastState.compose env52345 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound52345 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52346 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1,343,16401,2421,1025,0,4161,21793,17,2,349,64,23808,5392,17665,2421,1364,33,257,21793,5457,513]

theorem envBound52346 : H12AffineFastState.Bounded env52346 := by
  intro p hp
  have h : env52346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52345_52346 : H12AffineEnvironment.transform 6 9 env52345 = env52346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52345 == env52346) = true)

theorem identity52346 : scanCanonicalize (H12AffineFastState.compose env52346 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52346 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env52347 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,1,263,16401,2341,1025,0,4113,21793,17,2,269,16,23808,5392,17665,2341,1284,33,257,21793,5377,513]

theorem envBound52347 : H12AffineFastState.Bounded env52347 := by
  intro p hp
  have h : env52347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52346_52347 : H12AffineEnvironment.transform 5 16 env52346 = env52347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52346 == env52347) = true)

theorem identity52347 : scanCanonicalize (H12AffineFastState.compose env52347 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 7204) := by decide +kernel

theorem selectedBound52347 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env52348 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,7204,1,263,7221,2341,1025,0,4113,2309,17,2,269,16,292,5392,6437,2341,1284,33,257,2309,5377,513]

theorem envBound52348 : H12AffineFastState.Bounded env52348 := by
  intro p hp
  have h : env52348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52347_52348 : H12AffineEnvironment.transform 13 7204 env52347 = env52348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7204 env52347 == env52348) = true)

theorem identity52348 : scanCanonicalize (H12AffineFastState.compose env52348 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound52348 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env52349 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,4096,268,6161,1,263,6144,2341,52,0,4113,2309,17,2,269,16,292,4389,6437,2341,305,33,257,2309,4404,513]

theorem envBound52349 : H12AffineFastState.Bounded env52349 := by
  intro p hp
  have h : env52349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52348_52349 : H12AffineEnvironment.transform 9 53 env52348 = env52349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env52348 == env52349) = true)

theorem identity52349 : scanCanonicalize (H12AffineFastState.compose env52349 (packedSelected [4,9,14] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound52349 : packedSelected [4,9,14] rootPS < 2^1333 := by decide +kernel

def env52350 : List Nat := [2,4,8,16,32,16,9,256,512,53,292,4096,268,4405,1,263,4388,1,52,0,4113,33,17,2,269,16,292,4389,4097,1,305,33,257,33,4404,513]

theorem envBound52350 : H12AffineFastState.Bounded env52350 := by
  intro p hp
  have h : env52350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52349_52350 : H12AffineEnvironment.transform 10 292 env52349 = env52350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env52349 == env52350) = true)

theorem identity52350 : scanCanonicalize (H12AffineFastState.compose env52350 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound52350 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52351 : List Nat := [2,4,8,16,32,16,9,256,512,53,292,49,268,260,1,263,277,1,52,0,32,33,17,2,269,16,292,276,48,1,305,33,257,33,261,513]

theorem envBound52351 : H12AffineFastState.Bounded env52351 := by
  intro p hp
  have h : env52351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52350_52351 : H12AffineEnvironment.transform 11 49 env52350 = env52351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env52350 == env52351) = true)

theorem identity52351 : scanCanonicalize (H12AffineFastState.compose env52351 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound52351 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52352 : List Nat := [2,4,8,16,32,16,9,37,512,53,1,49,41,33,1,34,48,1,52,0,32,33,17,2,40,16,1,49,48,1,20,33,36,33,32,513]

theorem envBound52352 : H12AffineFastState.Bounded env52352 := by
  intro p hp
  have h : env52352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52351_52352 : H12AffineEnvironment.transform 7 37 env52351 = env52352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env52351 == env52352) = true)

theorem identity52352 : scanCanonicalize (H12AffineFastState.compose env52352 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound52352 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52353 : List Nat := [2,4,8,16,32,16,9,37,32,53,1,49,41,33,1,34,48,1,52,0,32,33,17,2,40,16,1,49,48,1,20,33,36,33,32,33]

theorem envBound52353 : H12AffineFastState.Bounded env52353 := by
  intro p hp
  have h : env52353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52352_52353 : H12AffineEnvironment.transform 8 32 env52352 = env52353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env52352 == env52353) = true)

theorem identity52353 : scanCanonicalize (H12AffineFastState.compose env52353 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound52353 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52354 : List Nat := [2,4,8,16,11,16,9,14,11,30,1,26,2,10,1,9,27,1,31,0,11,10,17,2,3,16,1,26,27,1,20,10,15,10,11,10]

theorem envBound52354 : H12AffineFastState.Bounded env52354 := by
  intro p hp
  have h : env52354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52353_52354 : H12AffineEnvironment.transform 4 11 env52353 = env52354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env52353 == env52354) = true)

def env52355 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1025,32769,4161,21929,41412,73736,8328,64,64605,46277,58580,35325,1501,33,257,21793,46213,74250]

theorem envBound52355 : H12AffineFastState.Bounded env52355 := by
  intro p hp
  have h : env52355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52326_52355 : H12AffineEnvironment.transform 16 49169 env52326 = env52355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env52326 == env52355) = true)

theorem identity52355 : scanCanonicalize (H12AffineFastState.compose env52355 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound52355 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52356 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1025,32769,4161,21792,41293,73736,8193,64,64605,46156,58461,35188,1364,33,257,21793,46092,74250]

theorem envBound52356 : H12AffineFastState.Bounded env52356 := by
  intro p hp
  have h : env52356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52355_52356 : H12AffineEnvironment.transform 6 9 env52355 = env52356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52355 == env52356) = true)

theorem identity52356 : scanCanonicalize (H12AffineFastState.compose env52356 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound52356 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env52357 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,13388,10281,1025,29788,4161,21792,21776,73736,8193,64,2048,16401,4096,32041,1364,33,257,21793,16465,74250]

theorem envBound52357 : H12AffineFastState.Bounded env52357 := by
  intro p hp
  have h : env52357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52356_52357 : H12AffineEnvironment.transform 14 29789 env52356 = env52357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env52356 == env52357) = true)

theorem identity52357 : scanCanonicalize (H12AffineFastState.compose env52357 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound52357 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env52358 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,13388,10281,1025,8541,4161,33,17,73736,8193,64,2048,5392,4096,10280,1364,33,257,32,5456,74250]

theorem envBound52358 : H12AffineFastState.Bounded env52358 := by
  intro p hp
  have h : env52358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52357_52358 : H12AffineEnvironment.transform 13 5377 env52357 = env52358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env52357 == env52358) = true)

theorem identity52358 : scanCanonicalize (H12AffineFastState.compose env52358 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 375) := by decide +kernel

theorem selectedBound52358 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env52359 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,375,13388,10281,1025,8541,4161,33,17,8575,8193,64,2048,5392,4096,10280,1364,33,257,32,5456,9085]

theorem envBound52359 : H12AffineFastState.Bounded env52359 := by
  intro p hp
  have h : env52359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52358_52359 : H12AffineEnvironment.transform 15 375 env52358 = env52359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 375 env52358 == env52359) = true)

def env52360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2257301,253977,8328,64,6705548,2253973,140484,2404756,2102685,6456792,257,21792,46212,2175562]

theorem envBound52360 : H12AffineFastState.Bounded env52360 := by
  intro p hp
  have h : env52360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52226_52360 : H12AffineEnvironment.transform 22 2257301 env52226 = env52360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2257301 env52226 == env52360) = true)

def env52361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441744,2257301,253977,8328,64,2157596,2253973,140484,2404756,2102685,2373704,257,21792,46212,2175562]

theorem envBound52361 : H12AffineFastState.Bounded env52361 := by
  intro p hp
  have h : env52361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52360_52361 : H12AffineEnvironment.transform 21 441744 env52360 = env52361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441744 env52360 == env52361) = true)

def env52362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441744,156117,253977,8328,64,64604,160981,140484,303572,1501,272392,257,21792,46212,74250]

theorem envBound52362 : H12AffineFastState.Bounded env52362 := by
  intro p hp
  have h : env52362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52361_52362 : H12AffineEnvironment.transform 20 4160 env52361 = env52362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env52361 == env52362) = true)

theorem identity52362 : scanCanonicalize (H12AffineFastState.compose env52362 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound52362 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52363 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,4160,441744,156117,180242,8328,64,64604,160981,140484,303572,1501,272392,257,21792,46212,513]

theorem envBound52363 : H12AffineFastState.Bounded env52363 := by
  intro p hp
  have h : env52363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52362_52363 : H12AffineEnvironment.transform 15 8203 env52362 = env52363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env52362 == env52363) = true)

def env52364 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1025,32769,4160,327040,8645,32770,8328,64,64604,13509,25812,303572,1501,272392,257,21792,46212,513]

theorem envBound52364 : H12AffineFastState.Bounded env52364 := by
  intro p hp
  have h : env52364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52363_52364 : H12AffineEnvironment.transform 16 16400 env52363 = env52364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env52363 == env52364) = true)

theorem identity52364 : scanCanonicalize (H12AffineFastState.compose env52364 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound52364 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env52365 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,479,16400,262144,1025,32769,4160,318548,17,32770,348,64,56712,5393,17664,294912,1501,264668,257,21792,38224,513]

theorem envBound52365 : H12AffineFastState.Bounded env52365 := by
  intro p hp
  have h : env52365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52364_52365 : H12AffineEnvironment.transform 12 468 env52364 = env52365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env52364 == env52365) = true)

theorem identity52365 : scanCanonicalize (H12AffineFastState.compose env52365 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 56573) := by decide +kernel

theorem selectedBound52365 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env52366 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,479,16400,56573,1025,32769,4160,169,17,32770,348,64,56712,5393,17664,23805,1501,54561,257,21792,38224,513]

theorem envBound52366 : H12AffineFastState.Bounded env52366 := by
  intro p hp
  have h : env52366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52365_52366 : H12AffineEnvironment.transform 17 56573 env52365 = env52366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56573 env52365 == env52366) = true)

theorem identity52366 : scanCanonicalize (H12AffineFastState.compose env52366 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound52366 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env52367 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,342,16400,56436,1025,32769,4160,32,17,32770,348,64,56577,5393,17664,23668,1364,54561,257,21792,38224,513]

theorem envBound52367 : H12AffineFastState.Bounded env52367 := by
  intro p hp
  have h : env52367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52366_52367 : H12AffineEnvironment.transform 6 9 env52366 = env52367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52366 == env52367) = true)

theorem identity52367 : scanCanonicalize (H12AffineFastState.compose env52367 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound52367 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52368 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,342,16400,2420,1025,21761,4160,32,17,21762,348,64,2049,5393,17664,23668,1364,33,257,21792,16464,513]

theorem envBound52368 : H12AffineFastState.Bounded env52368 := by
  intro p hp
  have h : env52368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52367_52368 : H12AffineEnvironment.transform 14 21760 env52367 = env52368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env52367 == env52368) = true)

theorem identity52368 : scanCanonicalize (H12AffineFastState.compose env52368 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound52368 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env52369 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5456,80,342,5440,2420,1025,81,4160,32,17,82,348,64,2049,5393,4176,2340,1364,33,257,112,5376,513]

theorem envBound52369 : H12AffineFastState.Bounded env52369 := by
  intro p hp
  have h : env52369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52368_52369 : H12AffineEnvironment.transform 13 5456 env52368 = env52369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env52368 == env52369) = true)

theorem identity52369 : scanCanonicalize (H12AffineFastState.compose env52369 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 1386) := by decide +kernel

theorem selectedBound52369 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env52370 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1386,349,58,80,342,42,2420,1025,81,1322,32,17,82,348,64,2049,123,1338,2340,1364,33,257,112,106,513]

theorem envBound52370 : H12AffineFastState.Bounded env52370 := by
  intro p hp
  have h : env52370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52369_52370 : H12AffineEnvironment.transform 11 1386 env52369 = env52370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1386 env52369 == env52370) = true)

theorem identity52370 : scanCanonicalize (H12AffineFastState.compose env52370 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 351) := by decide +kernel

theorem selectedBound52370 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env52371 : List Nat := [2,4,8,16,32,64,9,256,512,1024,351,1386,349,58,80,342,42,43,1025,81,1322,32,17,82,348,64,350,123,1338,123,1364,33,257,112,106,513]

theorem envBound52371 : H12AffineFastState.Bounded env52371 := by
  intro p hp
  have h : env52371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52370_52371 : H12AffineEnvironment.transform 10 351 env52370 = env52371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 351 env52370 == env52371) = true)

theorem identity52371 : scanCanonicalize (H12AffineFastState.compose env52371 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(9+1) ^^^ 117) := by decide +kernel

theorem selectedBound52371 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env52372 : List Nat := [2,4,8,16,32,64,9,256,512,117,351,287,349,58,80,342,42,43,116,81,351,32,17,82,348,64,350,123,335,123,289,33,257,112,106,513]

theorem envBound52372 : H12AffineFastState.Bounded env52372 := by
  intro p hp
  have h : env52372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52371_52372 : H12AffineEnvironment.transform 9 117 env52371 = env52372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 117 env52371 == env52372) = true)

theorem identity52372 : scanCanonicalize (H12AffineFastState.compose env52372 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound52372 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env52373 : List Nat := [2,4,8,16,32,64,9,110,512,117,49,113,51,58,80,56,42,43,116,81,49,32,17,82,50,64,48,123,33,123,79,33,111,112,106,513]

theorem envBound52373 : H12AffineFastState.Bounded env52373 := by
  intro p hp
  have h : env52373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52372_52373 : H12AffineEnvironment.transform 7 110 env52372 = env52373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env52372 == env52373) = true)

theorem identity52373 : scanCanonicalize (H12AffineFastState.compose env52373 (packedSelected [1,2,3,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52373 : packedSelected [1,2,3,11] rootPS < 2^1333 := by decide +kernel

def env52374 : List Nat := [2,4,8,16,32,17,9,63,512,36,49,32,51,58,1,56,42,43,37,0,49,32,17,3,50,17,48,42,33,42,30,33,62,33,59,513]

theorem envBound52374 : H12AffineFastState.Bounded env52374 := by
  intro p hp
  have h : env52374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52373_52374 : H12AffineEnvironment.transform 5 17 env52373 = env52374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52373 == env52374) = true)

theorem identity52374 : scanCanonicalize (H12AffineFastState.compose env52374 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound52374 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52375 : List Nat := [2,4,8,11,32,10,9,36,512,36,42,32,40,33,1,35,42,43,37,0,42,32,10,3,41,10,43,42,33,42,5,33,37,33,32,513]

theorem envBound52375 : H12AffineFastState.Bounded env52375 := by
  intro p hp
  have h : env52375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52374_52375 : H12AffineEnvironment.transform 3 11 env52374 = env52375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env52374 == env52375) = true)

theorem identity52375 : scanCanonicalize (H12AffineFastState.compose env52375 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 37) := by decide +kernel

theorem selectedBound52375 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52376 : List Nat := [2,4,8,11,32,10,9,36,37,36,42,32,40,33,1,35,42,43,37,0,42,32,10,3,41,10,43,42,33,42,5,33,37,33,32,36]

theorem envBound52376 : H12AffineFastState.Bounded env52376 := by
  intro p hp
  have h : env52376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52375_52376 : H12AffineEnvironment.transform 8 37 env52375 = env52376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 37 env52375 == env52376) = true)

theorem identity52376 : scanCanonicalize (H12AffineFastState.compose env52376 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52376 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52377 : List Nat := [2,4,8,11,0,10,9,4,5,4,10,0,8,1,1,3,10,11,5,0,10,0,10,3,9,10,11,10,1,10,5,1,5,1,0,4]

theorem envBound52377 : H12AffineFastState.Bounded env52377 := by
  intro p hp
  have h : env52377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52376_52377 : H12AffineEnvironment.transform 4 0 env52376 = env52377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52376 == env52377) = true)

def env52378 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1025,32769,4160,327041,8644,32771,8328,64,64604,13508,25813,303572,1501,272392,257,21792,46212,513]

theorem envBound52378 : H12AffineFastState.Bounded env52378 := by
  intro p hp
  have h : env52378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52363_52378 : H12AffineEnvironment.transform 16 16401 env52363 = env52378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env52363 == env52378) = true)

def env52379 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1025,32769,4160,326921,8524,32771,8192,64,64604,13388,25693,303452,1365,272392,257,21792,46092,513]

theorem envBound52379 : H12AffineFastState.Bounded env52379 := by
  intro p hp
  have h : env52379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52378_52379 : H12AffineEnvironment.transform 6 8 env52378 = env52379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52378 == env52379) = true)

theorem identity52379 : scanCanonicalize (H12AffineFastState.compose env52379 (packedSelected [0,14,27] rootPS)) = affineNative (2^(13+1) ^^^ 12621) := by decide +kernel

theorem selectedBound52379 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env52380 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12621,32768,8203,12636,262144,1025,32769,4160,298052,8524,32771,8192,64,36113,13388,5392,303452,1365,272392,257,9325,46092,513]

theorem envBound52380 : H12AffineFastState.Bounded env52380 := by
  intro p hp
  have h : env52380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52379_52380 : H12AffineEnvironment.transform 13 12621 env52379 = env52380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12621 env52379 == env52380) = true)

theorem identity52380 : scanCanonicalize (H12AffineFastState.compose env52380 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound52380 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env52381 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,5377,32768,1095,5392,262144,1025,32769,4160,298052,1280,32771,1100,64,36113,4096,5392,296208,1365,265284,257,33,36928,513]

theorem envBound52381 : H12AffineFastState.Bounded env52381 := by
  intro p hp
  have h : env52381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52380_52381 : H12AffineEnvironment.transform 12 1100 env52380 = env52381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env52380 == env52381) = true)

theorem identity52381 : scanCanonicalize (H12AffineFastState.compose env52381 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound52381 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52382 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,5377,32768,1095,5392,35188,1025,32769,4160,1328,1280,32771,1100,64,36113,4096,5392,3172,1365,34096,257,33,36928,513]

theorem envBound52382 : H12AffineFastState.Bounded env52382 := by
  intro p hp
  have h : env52382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52381_52382 : H12AffineEnvironment.transform 17 35188 env52381 = env52382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env52381 == env52382) = true)

theorem identity52382 : scanCanonicalize (H12AffineFastState.compose env52382 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1296) := by decide +kernel

theorem selectedBound52382 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52383 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,5377,1296,1095,5392,3172,1025,1297,4160,1328,1280,1299,1100,64,2049,4096,5392,3172,1365,32,257,33,5456,513]

theorem envBound52383 : H12AffineFastState.Bounded env52383 := by
  intro p hp
  have h : env52383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52382_52383 : H12AffineEnvironment.transform 14 1296 env52382 = env52383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1296 env52382 == env52383) = true)

theorem identity52383 : scanCanonicalize (H12AffineFastState.compose env52383 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(11+1) ^^^ 3189) := by decide +kernel

theorem selectedBound52383 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env52384 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3189,1100,2420,1296,1095,2405,3172,1025,1297,3125,1328,1280,1299,1100,64,2049,3189,2405,3172,1365,32,257,33,2341,513]

theorem envBound52384 : H12AffineFastState.Bounded env52384 := by
  intro p hp
  have h : env52384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52383_52384 : H12AffineEnvironment.transform 11 3189 env52383 = env52384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3189 env52383 == env52384) = true)

theorem identity52384 : scanCanonicalize (H12AffineFastState.compose env52384 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 869) := by decide +kernel

theorem selectedBound52384 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env52385 : List Nat := [2,4,8,16,32,64,8,256,512,1024,869,1808,1100,529,1296,1095,512,1793,1025,1297,1872,1328,1280,1299,1100,64,868,1808,512,1793,1365,32,257,33,576,513]

theorem envBound52385 : H12AffineFastState.Bounded env52385 := by
  intro p hp
  have h : env52385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52384_52385 : H12AffineEnvironment.transform 10 869 env52384 = env52385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 869 env52384 == env52385) = true)

theorem identity52385 : scanCanonicalize (H12AffineFastState.compose env52385 (packedSelected [1,2,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 827) := by decide +kernel

theorem selectedBound52385 : packedSelected [1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env52386 : List Nat := [2,4,8,16,32,64,8,256,512,827,869,43,887,529,555,892,512,58,826,554,107,523,571,552,887,64,868,43,512,58,622,32,257,33,576,513]

theorem envBound52386 : H12AffineFastState.Bounded env52386 := by
  intro p hp
  have h : env52386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52385_52386 : H12AffineEnvironment.transform 9 827 env52385 = env52386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 827 env52385 == env52386) = true)

theorem identity52386 : scanCanonicalize (H12AffineFastState.compose env52386 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound52386 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env52387 : List Nat := [2,4,8,16,32,64,8,37,512,542,576,43,594,529,555,601,512,58,543,554,107,523,571,552,594,64,577,43,512,58,622,32,36,33,576,513]

theorem envBound52387 : H12AffineFastState.Bounded env52387 := by
  intro p hp
  have h : env52387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52386_52387 : H12AffineEnvironment.transform 7 37 env52386 = env52387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env52386 == env52387) = true)

def env52388 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1025,32769,4160,326920,8525,32771,8193,64,64604,13389,25692,303453,1364,272392,257,21792,46093,513]

theorem envBound52388 : H12AffineFastState.Bounded env52388 := by
  intro p hp
  have h : env52388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52378_52388 : H12AffineEnvironment.transform 6 9 env52378 = env52388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52378 == env52388) = true)

def env52389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441744,156116,253977,8328,64,64605,160980,140484,303573,1500,272393,257,21792,46212,74251]

theorem envBound52389 : H12AffineFastState.Bounded env52389 := by
  intro p hp
  have h : env52389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52361_52389 : H12AffineEnvironment.transform 20 4161 env52361 = env52389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env52361 == env52389) = true)

theorem identity52389 : scanCanonicalize (H12AffineFastState.compose env52389 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 111899) := by decide +kernel

theorem selectedBound52389 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111899,262144,1025,32769,4161,329867,120015,21762,8328,64,64605,115151,102879,303573,1500,272393,257,21792,46212,74251]

theorem envBound52390 : H12AffineFastState.Bounded env52390 := by
  intro p hp
  have h : env52390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52389_52390 : H12AffineEnvironment.transform 16 111899 env52389 = env52390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111899 env52389 == env52390) = true)

def env52391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10400,1025,32769,4161,73771,120015,21762,8328,64,64605,115151,102879,35189,1500,169,257,21792,46212,74251]

theorem envBound52391 : H12AffineFastState.Bounded env52391 := by
  intro p hp
  have h : env52391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52390_52391 : H12AffineEnvironment.transform 17 10400 env52390 = env52391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env52390 == env52391) = true)

def env52392 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10280,1025,32769,4161,73771,119879,21762,8192,64,64605,115015,102743,35189,1364,33,257,21792,46092,74251]

theorem envBound52392 : H12AffineFastState.Bounded env52392 := by
  intro p hp
  have h : env52392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52391_52392 : H12AffineEnvironment.transform 6 8 env52391 = env52392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52391 == env52392) = true)

theorem identity52392 : scanCanonicalize (H12AffineFastState.compose env52392 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound52392 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52393 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,70726,10280,1025,8540,4161,73771,95514,21762,8192,64,23808,90138,77834,10280,1364,33,257,21792,5457,74251]

theorem envBound52393 : H12AffineFastState.Bounded env52393 := by
  intro p hp
  have h : env52393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52392_52393 : H12AffineEnvironment.transform 14 8541 env52392 = env52393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env52392 == env52393) = true)

theorem identity52393 : scanCanonicalize (H12AffineFastState.compose env52393 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound52393 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env52394 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,70726,10280,1025,8540,4161,73771,73755,3,8192,64,2049,79131,77834,10280,1364,33,257,33,5457,74251]

theorem envBound52394 : H12AffineFastState.Bounded env52394 := by
  intro p hp
  have h : env52394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52393_52394 : H12AffineEnvironment.transform 13 5377 env52393 = env52394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env52393 == env52394) = true)

theorem identity52394 : scanCanonicalize (H12AffineFastState.compose env52394 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound52394 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env52395 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,8192,4452,8541,65536,69667,10280,100,8540,4161,73771,73755,3,8192,64,2049,78206,77834,10280,305,33,257,33,4404,74251]

theorem envBound52395 : H12AffineFastState.Bounded env52395 := by
  intro p hp
  have h : env52395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52394_52395 : H12AffineEnvironment.transform 9 101 env52394 = env52395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env52394 == env52395) = true)

theorem identity52395 : scanCanonicalize (H12AffineFastState.compose env52395 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound52395 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env52396 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,8192,4452,8541,8283,12408,10280,100,8540,4161,112,64,3,8192,64,2049,4389,4177,10280,305,33,257,33,4404,592]

theorem envBound52396 : H12AffineFastState.Bounded env52396 := by
  intro p hp
  have h : env52396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52395_52396 : H12AffineEnvironment.transform 15 8283 env52395 = env52396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env52395 == env52396) = true)

theorem identity52396 : scanCanonicalize (H12AffineFastState.compose env52396 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound52396 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env52397 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,348,4452,1,263,4388,2420,100,0,4161,112,64,3,348,64,2049,4389,4177,2420,305,33,257,33,4404,592]

theorem envBound52397 : H12AffineFastState.Bounded env52397 := by
  intro p hp
  have h : env52397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52396_52397 : H12AffineEnvironment.transform 12 348 env52396 = env52397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env52396 == env52397) = true)

theorem identity52397 : scanCanonicalize (H12AffineFastState.compose env52397 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound52397 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env52398 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,2404,348,2048,1,263,2112,2420,100,0,2341,112,64,3,348,64,2049,2113,2357,2420,305,33,257,33,2128,592]

theorem envBound52398 : H12AffineFastState.Bounded env52398 := by
  intro p hp
  have h : env52398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52397_52398 : H12AffineEnvironment.transform 11 2404 env52397 = env52398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env52397 == env52398) = true)

theorem identity52398 : scanCanonicalize (H12AffineFastState.compose env52398 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound52398 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env52399 : List Nat := [2,4,8,16,32,64,8,256,512,101,261,97,348,261,1,263,325,113,100,0,32,112,64,3,348,64,260,324,48,113,305,33,257,33,341,592]

theorem envBound52399 : H12AffineFastState.Bounded env52399 := by
  intro p hp
  have h : env52399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52398_52399 : H12AffineEnvironment.transform 10 261 env52398 = env52399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env52398 == env52399) = true)

theorem identity52399 : scanCanonicalize (H12AffineFastState.compose env52399 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52399 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env52400 : List Nat := [2,4,8,16,0,64,8,256,512,69,261,65,348,261,1,263,325,81,68,0,0,80,64,3,348,64,260,324,16,81,273,1,257,1,341,592]

theorem envBound52400 : H12AffineFastState.Bounded env52400 := by
  intro p hp
  have h : env52400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52399_52400 : H12AffineEnvironment.transform 4 0 env52399 = env52400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52399 == env52400) = true)

theorem identity52400 : scanCanonicalize (H12AffineFastState.compose env52400 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52400 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52401 : List Nat := [2,4,8,16,0,17,8,256,512,20,261,16,269,261,1,263,276,0,21,0,0,1,17,3,269,17,260,277,16,0,273,1,257,1,260,513]

theorem envBound52401 : H12AffineFastState.Bounded env52401 := by
  intro p hp
  have h : env52401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52400_52401 : H12AffineEnvironment.transform 5 17 env52400 = env52401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52400 == env52401) = true)

theorem identity52401 : scanCanonicalize (H12AffineFastState.compose env52401 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound52401 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52402 : List Nat := [2,4,8,16,0,17,8,256,270,20,261,16,269,261,1,263,276,0,21,0,0,1,17,3,269,17,260,277,16,0,273,1,257,1,260,271]

theorem envBound52402 : H12AffineFastState.Bounded env52402 := by
  intro p hp
  have h : env52402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52401_52402 : H12AffineEnvironment.transform 8 270 env52401 = env52402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env52401 == env52402) = true)

def env52403 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10281,1025,32769,4161,73771,119878,21762,8193,64,64605,115014,102742,35189,1365,32,257,21792,46093,74251]

theorem envBound52403 : H12AffineFastState.Bounded env52403 := by
  intro p hp
  have h : env52403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52391_52403 : H12AffineEnvironment.transform 6 9 env52391 = env52403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52391 == env52403) = true)

theorem identity52403 : scanCanonicalize (H12AffineFastState.compose env52403 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound52403 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env52404 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,16401,10281,1025,32769,4161,54561,8524,21762,8193,64,64605,13388,25692,35189,1365,32,257,21792,46093,55041]

theorem envBound52404 : H12AffineFastState.Bounded env52404 := by
  intro p hp
  have h : env52404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0