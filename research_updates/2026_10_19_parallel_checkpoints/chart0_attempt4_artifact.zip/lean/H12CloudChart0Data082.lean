import H12CloudChart0Data081

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env20698 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1124,4096,41,16384,372,20531,4468,1125,1025,373,5457,4194304,17,3,41,65,4195396,16400,16400,21621,21829,4194304,257,33,16464,513]

theorem envBound20698 : H12AffineFastState.Bounded env20698 := by
  intro p hp
  have h : env20698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20697_20698 : H12AffineEnvironment.transform 12 41 env20697 = env20698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env20697 == env20698) = true)

theorem identity20698 : scanCanonicalize (H12AffineFastState.compose env20698 (packedSelected [1,8,19] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound20698 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env20699 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1124,4096,41,16384,0,20531,4096,1125,1025,1,5157,4194304,17,3,41,65,4195396,16400,16400,21621,21553,4194304,117,33,16464,513]

theorem envBound20699 : H12AffineFastState.Bounded env20699 := by
  intro p hp
  have h : env20699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20698_20699 : H12AffineEnvironment.transform 7 116 env20698 = env20699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env20698 == env20699) = true)

theorem identity20699 : scanCanonicalize (H12AffineFastState.compose env20699 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 1044) := by decide +kernel

theorem selectedBound20699 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env20700 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1124,4096,41,16384,0,20531,4096,1125,1025,1,5157,1044,17,3,41,65,80,16400,16400,21621,21553,1044,117,33,16464,513]

theorem envBound20700 : H12AffineFastState.Bounded env20700 := by
  intro p hp
  have h : env20700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20699_20700 : H12AffineEnvironment.transform 21 1044 env20699 = env20700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1044 env20699 == env20700) = true)

theorem identity20700 : scanCanonicalize (H12AffineFastState.compose env20700 (packedSelected [0,1,2,3,4,5,6,7,8,9,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 0) := by decide +kernel

theorem selectedBound20700 : packedSelected [0,1,2,3,4,5,6,7,8,9,14,15] rootPS < 2^1333 := by decide +kernel

def env20701 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1124,4096,41,0,0,4147,4096,1125,1025,1,5157,1044,17,3,41,65,80,16,16,5237,5169,1044,117,33,80,513]

theorem envBound20701 : H12AffineFastState.Bounded env20701 := by
  intro p hp
  have h : env20701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20700_20701 : H12AffineEnvironment.transform 13 0 env20700 = env20701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env20700 == env20701) = true)

theorem identity20701 : scanCanonicalize (H12AffineFastState.compose env20701 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound20701 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env20702 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1124,17,41,0,0,34,17,1125,1025,1,1076,1044,17,3,41,65,80,16,16,1124,1056,1044,117,33,80,513]

theorem envBound20702 : H12AffineFastState.Bounded env20702 := by
  intro p hp
  have h : env20702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20701_20702 : H12AffineEnvironment.transform 11 17 env20701 = env20702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env20701 == env20702) = true)

theorem identity20702 : scanCanonicalize (H12AffineFastState.compose env20702 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20702 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20703 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1077,17,41,0,0,34,17,1076,1025,1,1076,1044,17,3,41,16,1,16,16,1077,1056,1044,36,33,1,513]

theorem envBound20703 : H12AffineFastState.Bounded env20703 := by
  intro p hp
  have h : env20703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20702_20703 : H12AffineEnvironment.transform 5 17 env20702 = env20703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20702 == env20703) = true)

theorem identity20703 : scanCanonicalize (H12AffineFastState.compose env20703 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20703 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env20704 : List Nat := [2,4,8,16,0,17,8,5,512,1024,1045,17,9,0,0,2,17,1044,1025,1,1044,1044,17,3,9,16,1,16,16,1045,1024,1044,4,1,1,513]

theorem envBound20704 : H12AffineFastState.Bounded env20704 := by
  intro p hp
  have h : env20704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20703_20704 : H12AffineEnvironment.transform 4 0 env20703 = env20704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20703 == env20704) = true)

theorem identity20704 : scanCanonicalize (H12AffineFastState.compose env20704 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound20704 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20705 : List Nat := [2,4,8,16,0,17,8,5,512,20,1,17,9,0,0,2,17,0,21,1,0,0,17,3,9,16,1,16,16,1,20,0,4,1,1,513]

theorem envBound20705 : H12AffineFastState.Bounded env20705 := by
  intro p hp
  have h : env20705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20704_20705 : H12AffineEnvironment.transform 9 20 env20704 = env20705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env20704 == env20705) = true)

theorem identity20705 : scanCanonicalize (H12AffineFastState.compose env20705 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound20705 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20706 : List Nat := [2,4,8,16,0,17,8,5,1,20,1,17,9,0,0,2,17,0,21,1,0,0,17,3,9,16,1,16,16,1,20,0,4,1,1,0]

theorem envBound20706 : H12AffineFastState.Bounded env20706 := by
  intro p hp
  have h : env20706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20705_20706 : H12AffineEnvironment.transform 8 1 env20705 = env20706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env20705 == env20706) = true)

def env20707 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1125,4096,8192,16384,8540,65536,82247,9292,1025,8541,91466,4194304,17,2,8192,65,4195396,16401,77835,66631,75103,4194304,257,32,16464,513]

theorem envBound20707 : H12AffineFastState.Bounded env20707 := by
  intro p hp
  have h : env20707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20695_20707 : H12AffineEnvironment.transform 10 1125 env20695 = env20707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env20695 == env20707) = true)

def env20708 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,4096,8192,16384,8460,65536,82199,9244,1025,8461,91418,4194304,17,2,8192,17,4195348,16401,77835,66583,75023,4194304,257,32,16384,513]

theorem envBound20708 : H12AffineFastState.Bounded env20708 := by
  intro p hp
  have h : env20708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20707_20708 : H12AffineEnvironment.transform 5 16 env20707 = env20708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20707 == env20708) = true)

theorem identity20708 : scanCanonicalize (H12AffineFastState.compose env20708 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound20708 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env20709 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,4096,268,16384,0,65536,82199,1296,1025,1,82966,4194304,17,2,268,17,4195348,16401,69895,66583,66563,4194304,257,32,16384,513]

theorem envBound20709 : H12AffineFastState.Bounded env20709 := by
  intro p hp
  have h : env20709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20708_20709 : H12AffineEnvironment.transform 12 268 env20708 = env20709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env20708 == env20709) = true)

theorem identity20709 : scanCanonicalize (H12AffineFastState.compose env20709 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound20709 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env20710 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,4096,268,16384,0,65536,82199,1296,1025,1,82966,32,17,2,268,17,1076,16401,69895,66583,66563,32,257,32,16384,513]

theorem envBound20710 : H12AffineFastState.Bounded env20710 := by
  intro p hp
  have h : env20710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20709_20710 : H12AffineEnvironment.transform 21 32 env20709 = env20710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env20709 == env20710) = true)

theorem identity20710 : scanCanonicalize (H12AffineFastState.compose env20710 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound20710 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20711 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,4096,268,16384,0,262,16401,1296,1025,1,17680,32,17,2,268,17,1076,16401,4097,1297,1285,32,257,32,16384,513]

theorem envBound20711 : H12AffineFastState.Bounded env20711 := by
  intro p hp
  have h : env20711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20710_20711 : H12AffineEnvironment.transform 15 262 env20710 = env20711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env20710 == env20711) = true)

theorem identity20711 : scanCanonicalize (H12AffineFastState.compose env20711 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1296) := by decide +kernel

theorem selectedBound20711 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20712 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,4096,268,1296,0,262,1281,1296,1025,1,0,32,17,2,268,17,1076,1281,4097,1297,1285,32,257,32,1296,513]

theorem envBound20712 : H12AffineFastState.Bounded env20712 := by
  intro p hp
  have h : env20712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20711_20712 : H12AffineEnvironment.transform 13 1296 env20711 = env20712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env20711 == env20712) = true)

theorem identity20712 : scanCanonicalize (H12AffineFastState.compose env20712 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 794) := by decide +kernel

theorem selectedBound20712 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20713 : List Nat := [2,4,8,16,32,16,8,256,512,794,815,4096,268,522,0,262,539,522,795,1,0,32,17,2,268,17,814,539,4097,523,543,32,257,32,522,513]

theorem envBound20713 : H12AffineFastState.Bounded env20713 := by
  intro p hp
  have h : env20713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20712_20713 : H12AffineEnvironment.transform 9 794 env20712 = env20713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 794 env20712 == env20713) = true)

theorem identity20713 : scanCanonicalize (H12AffineFastState.compose env20713 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound20713 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20714 : List Nat := [2,4,8,16,32,16,8,4,512,542,555,4096,8,522,0,2,539,522,543,1,0,32,17,2,8,17,554,539,4097,523,543,32,5,32,522,513]

theorem envBound20714 : H12AffineFastState.Bounded env20714 := by
  intro p hp
  have h : env20714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20713_20714 : H12AffineEnvironment.transform 7 4 env20713 = env20714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env20713 == env20714) = true)

theorem identity20714 : scanCanonicalize (H12AffineFastState.compose env20714 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound20714 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env20715 : List Nat := [2,4,8,16,32,16,8,4,512,542,555,16,8,522,0,2,539,522,543,1,0,32,17,2,8,17,554,539,17,523,543,32,5,32,522,513]

theorem envBound20715 : H12AffineFastState.Bounded env20715 := by
  intro p hp
  have h : env20715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20714_20715 : H12AffineEnvironment.transform 11 16 env20714 = env20715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env20714 == env20715) = true)

theorem identity20715 : scanCanonicalize (H12AffineFastState.compose env20715 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound20715 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20716 : List Nat := [2,4,8,16,32,16,8,4,11,21,32,16,8,1,0,2,16,1,20,1,0,32,17,2,8,17,33,16,17,0,20,32,5,32,1,10]

theorem envBound20716 : H12AffineFastState.Bounded env20716 := by
  intro p hp
  have h : env20716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20715_20716 : H12AffineEnvironment.transform 8 11 env20715 = env20716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env20715 == env20716) = true)

theorem identity20716 : scanCanonicalize (H12AffineFastState.compose env20716 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20716 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env20717 : List Nat := [2,4,8,16,0,16,8,4,11,21,0,16,8,1,0,2,16,1,20,1,0,0,17,2,8,17,1,16,17,0,20,0,5,0,1,10]

theorem envBound20717 : H12AffineFastState.Bounded env20717 := by
  intro p hp
  have h : env20717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20716_20717 : H12AffineEnvironment.transform 4 0 env20716 = env20717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20716 == env20717) = true)

theorem identity20717 : scanCanonicalize (H12AffineFastState.compose env20717 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound20717 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20718 : List Nat := [2,1,8,16,0,16,8,1,11,16,0,16,8,1,0,2,16,1,17,1,0,0,17,2,8,17,1,16,17,0,17,0,0,0,1,10]

theorem envBound20718 : H12AffineFastState.Bounded env20718 := by
  intro p hp
  have h : env20718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20717_20718 : H12AffineEnvironment.transform 1 1 env20717 = env20718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env20717 == env20718) = true)

theorem identity20718 : scanCanonicalize (H12AffineFastState.compose env20718 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound20718 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20719 : List Nat := [2,1,8,3,0,3,8,1,11,3,0,3,8,1,0,2,3,1,2,1,0,0,2,2,8,2,1,3,2,0,2,0,0,0,1,10]

theorem envBound20719 : H12AffineFastState.Bounded env20719 := by
  intro p hp
  have h : env20719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20718_20719 : H12AffineEnvironment.transform 3 3 env20718 = env20719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env20718 == env20719) = true)

def env20720 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1076,4096,8192,16384,8461,65536,82198,9245,1025,8460,91419,4194304,17,2,8192,16,4195349,16401,77835,66582,75022,4194304,257,32,16385,513]

theorem envBound20720 : H12AffineFastState.Bounded env20720 := by
  intro p hp
  have h : env20720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20707_20720 : H12AffineEnvironment.transform 5 17 env20707 = env20720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20707 == env20720) = true)

theorem identity20720 : scanCanonicalize (H12AffineFastState.compose env20720 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound20720 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env20721 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1076,4096,8192,16384,8461,263,16401,9245,1025,8460,25628,4194304,17,2,8192,16,4195349,16401,12556,1297,9225,4194304,257,32,16385,513]

theorem envBound20721 : H12AffineFastState.Bounded env20721 := by
  intro p hp
  have h : env20721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20720_20721 : H12AffineEnvironment.transform 15 263 env20720 = env20721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env20720 == env20721) = true)

theorem identity20721 : scanCanonicalize (H12AffineFastState.compose env20721 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound20721 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env20722 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1076,4096,8192,16384,8461,263,16401,9245,1025,8460,25628,32,17,2,8192,16,1077,16401,12556,1297,9225,32,257,32,16385,513]

theorem envBound20722 : H12AffineFastState.Bounded env20722 := by
  intro p hp
  have h : env20722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20721_20722 : H12AffineEnvironment.transform 21 32 env20721 = env20722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env20721 == env20722) = true)

theorem identity20722 : scanCanonicalize (H12AffineFastState.compose env20722 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 1077) := by decide +kernel

theorem selectedBound20722 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env20723 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1076,4096,8192,1077,8461,263,1060,9245,1025,8460,8233,32,17,2,8192,16,1077,1060,12556,1297,9225,32,257,32,1076,513]

theorem envBound20723 : H12AffineFastState.Bounded env20723 := by
  intro p hp
  have h : env20723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20722_20723 : H12AffineEnvironment.transform 13 1077 env20722 = env20723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1077 env20722 == env20723) = true)

theorem identity20723 : scanCanonicalize (H12AffineFastState.compose env20723 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound20723 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env20724 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1076,4096,268,1077,1,263,1060,1297,1025,0,293,32,17,2,268,16,1077,1060,4096,1297,1285,32,257,32,1076,513]

theorem envBound20724 : H12AffineFastState.Bounded env20724 := by
  intro p hp
  have h : env20724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20723_20724 : H12AffineEnvironment.transform 12 268 env20723 = env20724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env20723 == env20724) = true)

theorem identity20724 : scanCanonicalize (H12AffineFastState.compose env20724 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20724 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20725 : List Nat := [2,4,8,16,1,17,8,256,512,1024,1045,4096,268,1044,1,263,1029,1297,1025,0,260,1,17,2,268,16,1044,1029,4096,1297,1285,1,257,1,1045,513]

theorem envBound20725 : H12AffineFastState.Bounded env20725 := by
  intro p hp
  have h : env20725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20724_20725 : H12AffineEnvironment.transform 4 1 env20724 = env20725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20724 == env20725) = true)

theorem identity20725 : scanCanonicalize (H12AffineFastState.compose env20725 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound20725 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20726 : List Nat := [2,4,8,16,1,17,8,256,512,1024,1045,16,268,1044,1,263,1029,1297,1025,0,260,1,17,2,268,16,1044,1029,16,1297,1285,1,257,1,1045,513]

theorem envBound20726 : H12AffineFastState.Bounded env20726 := by
  intro p hp
  have h : env20726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20725_20726 : H12AffineEnvironment.transform 11 16 env20725 = env20726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env20725 == env20726) = true)

theorem identity20726 : scanCanonicalize (H12AffineFastState.compose env20726 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound20726 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20727 : List Nat := [2,4,8,16,1,17,8,256,260,1024,1045,16,268,1044,1,263,1029,1297,1025,0,260,1,17,2,268,16,1044,1029,16,1297,1285,1,257,1,1045,261]

theorem envBound20727 : H12AffineFastState.Bounded env20727 := by
  intro p hp
  have h : env20727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20726_20727 : H12AffineEnvironment.transform 8 260 env20726 = env20727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env20726 == env20727) = true)

theorem identity20727 : scanCanonicalize (H12AffineFastState.compose env20727 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound20727 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env20728 : List Nat := [2,4,8,16,1,17,8,256,260,256,277,16,268,276,1,263,261,17,257,0,260,1,17,2,268,16,276,261,16,17,5,1,257,1,277,261]

theorem envBound20728 : H12AffineFastState.Bounded env20728 := by
  intro p hp
  have h : env20728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20727_20728 : H12AffineEnvironment.transform 9 256 env20727 = env20728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env20727 == env20728) = true)

def env20729 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8661050,8193,65,4450362,10857534,10507600,8830977,371754,15027571,257,2485278,2428211,297845]

theorem envBound20729 : H12AffineFastState.Bounded env20729 := by
  intro p hp
  have h : env20729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20655_20729 : H12AffineEnvironment.transform 6 9 env20655 = env20729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20655 == env20729) = true)

theorem identity20729 : scanCanonicalize (H12AffineFastState.compose env20729 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound20729 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env20730 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1025,32769,2097152,4194304,8388608,8661050,8193,65,4229152,10857534,10507600,8757275,371754,15027571,257,2485278,2428211,297845]

theorem envBound20730 : H12AffineFastState.Bounded env20730 := by
  intro p hp
  have h : env20730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20729_20730 : H12AffineEnvironment.transform 16 90138 env20729 = env20730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env20729 == env20730) = true)

def env20731 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35188,1025,32769,2097152,4194304,8388608,8429902,8193,65,4229152,10560842,10507600,8464751,75102,14795783,257,2188650,2196551,513]

theorem envBound20731 : H12AffineFastState.Bounded env20731 := by
  intro p hp
  have h : env20731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20730_20731 : H12AffineEnvironment.transform 17 35188 env20730 = env20731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env20730 == env20731) = true)

def env20732 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35188,1025,32769,2097152,4194304,16,41310,8193,65,4229152,2172250,2118976,76159,75102,6407191,257,2188650,2196551,513]

theorem envBound20732 : H12AffineFastState.Bounded env20732 := by
  intro p hp
  have h : env20732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20731_20732 : H12AffineEnvironment.transform 22 16 env20731 = env20732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env20731 == env20732) = true)

theorem identity20732 : scanCanonicalize (H12AffineFastState.compose env20732 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29005) := by decide +kernel

theorem selectedBound20732 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env20733 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,65536,90138,30777,1025,29004,2097152,4194304,16,20499,8193,65,4225389,2172250,2118976,76159,75102,6370650,257,2188650,2192650,513]

theorem envBound20733 : H12AffineFastState.Bounded env20733 := by
  intro p hp
  have h : env20733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20732_20733 : H12AffineEnvironment.transform 14 29005 env20732 = env20733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29005 env20732 == env20733) = true)

def env20734 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,65536,90138,30777,1025,29004,5456,4194304,16,20499,8193,65,4225389,77834,16400,76159,75102,4268042,257,94266,90202,513]

theorem envBound20734 : H12AffineFastState.Bounded env20734 := by
  intro p hp
  have h : env20734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20733_20734 : H12AffineEnvironment.transform 20 5456 env20733 = env20734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5456 env20733 == env20734) = true)

theorem identity20734 : scanCanonicalize (H12AffineFastState.compose env20734 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound20734 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20735 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,65536,90138,30777,1025,29004,5456,73770,16,20499,8193,65,88391,77834,16400,76159,75102,32,257,94266,90202,513]

theorem envBound20735 : H12AffineFastState.Bounded env20735 := by
  intro p hp
  have h : env20735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20734_20735 : H12AffineEnvironment.transform 21 73770 env20734 = env20735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env20734 == env20735) = true)

theorem identity20735 : scanCanonicalize (H12AffineFastState.compose env20735 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound20735 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20736 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,8540,65536,77835,10280,1025,8541,5456,73770,16,2,8193,65,67926,77834,4097,76159,75102,32,257,73771,77899,513]

theorem envBound20736 : H12AffineFastState.Bounded env20736 := by
  intro p hp
  have h : env20736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20735_20736 : H12AffineEnvironment.transform 13 4113 env20735 = env20736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env20735 == env20736) = true)

theorem identity20736 : scanCanonicalize (H12AffineFastState.compose env20736 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 7458) := by decide +kernel

theorem selectedBound20736 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env20737 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,8540,7458,11561,10280,1025,8541,5456,15624,16,2,8193,65,5236,11560,4097,13405,14460,32,257,15625,11625,513]

theorem envBound20737 : H12AffineFastState.Bounded env20737 := by
  intro p hp
  have h : env20737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20736_20737 : H12AffineEnvironment.transform 15 7458 env20736 = env20737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7458 env20736 == env20737) = true)

def env20738 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,65536,90138,30777,1025,29004,5457,4194304,16,20499,8193,65,4225389,77835,16401,76159,75102,4268043,257,94267,90203,513]

theorem envBound20738 : H12AffineFastState.Bounded env20738 := by
  intro p hp
  have h : env20738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20733_20738 : H12AffineEnvironment.transform 20 5457 env20733 = env20738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5457 env20733 == env20738) = true)

theorem identity20738 : scanCanonicalize (H12AffineFastState.compose env20738 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 94266) := by decide +kernel

theorem selectedBound20738 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20739 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,65536,90138,30777,1025,29004,5457,94266,16,20499,8193,65,67927,77835,16401,76159,75102,20529,257,94267,90203,513]

theorem envBound20739 : H12AffineFastState.Bounded env20739 := by
  intro p hp
  have h : env20739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20738_20739 : H12AffineEnvironment.transform 21 94266 env20738 = env20739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 94266 env20738 == env20739) = true)

theorem identity20739 : scanCanonicalize (H12AffineFastState.compose env20739 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound20739 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20740 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,8203,16401,30777,1025,29004,5457,20529,16,20499,8193,65,10588,4096,16401,2420,1365,20529,257,20528,16464,513]

theorem envBound20740 : H12AffineFastState.Bounded env20740 := by
  intro p hp
  have h : env20740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20739_20740 : H12AffineEnvironment.transform 15 8203 env20739 = env20740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env20739 == env20740) = true)

theorem identity20740 : scanCanonicalize (H12AffineFastState.compose env20740 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound20740 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env20741 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4112,8541,8203,4097,10281,1025,8540,5457,33,16,3,8193,65,10588,4096,4097,2420,1365,33,257,32,4160,513]

theorem envBound20741 : H12AffineFastState.Bounded env20741 := by
  intro p hp
  have h : env20741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20740_20741 : H12AffineEnvironment.transform 13 4112 env20740 = env20741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env20740 == env20741) = true)

def env20742 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35188,1025,32769,2097152,4194304,17,41311,8193,65,4229152,2172251,2118977,76158,75102,6407190,257,2188650,2196551,513]

theorem envBound20742 : H12AffineFastState.Bounded env20742 := by
  intro p hp
  have h : env20742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20731_20742 : H12AffineEnvironment.transform 22 17 env20731 = env20742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env20731 == env20742) = true)

theorem identity20742 : scanCanonicalize (H12AffineFastState.compose env20742 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 46093) := by decide +kernel

theorem selectedBound20742 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env20743 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35188,1025,32769,46093,4194304,17,41311,8193,65,4229152,102742,57676,76158,75102,4288539,257,119143,77898,513]

theorem envBound20743 : H12AffineFastState.Bounded env20743 := by
  intro p hp
  have h : env20743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20742_20743 : H12AffineEnvironment.transform 20 46093 env20742 = env20743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 46093 env20742 == env20743) = true)

theorem identity20743 : scanCanonicalize (H12AffineFastState.compose env20743 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound20743 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env20744 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,90138,10280,1025,8541,5457,4194304,17,3,8193,65,4204924,77834,16400,76158,75102,4288539,257,94267,77898,513]

theorem envBound20744 : H12AffineFastState.Bounded env20744 := by
  intro p hp
  have h : env20744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20743_20744 : H12AffineEnvironment.transform 14 8540 env20743 = env20744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env20743 == env20744) = true)

theorem identity20744 : scanCanonicalize (H12AffineFastState.compose env20744 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 20759) := by decide +kernel

theorem selectedBound20744 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env20745 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,20759,12557,10280,1025,8541,5457,4194304,17,3,8193,65,4204924,24861,16400,30825,29769,4202764,257,8492,24925,513]

theorem envBound20745 : H12AffineFastState.Bounded env20745 := by
  intro p hp
  have h : env20745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20744_20745 : H12AffineEnvironment.transform 15 20759 env20744 = env20745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20759 env20744 == env20745) = true)

theorem identity20745 : scanCanonicalize (H12AffineFastState.compose env20745 (packedSelected [0,4,7,9,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound20745 : packedSelected [0,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env20746 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1337,16384,1125,20759,5172,3345,1025,1124,5457,4194304,17,3,1336,65,4197445,17444,16400,23888,20848,4195381,257,1045,17508,513]

theorem envBound20746 : H12AffineFastState.Bounded env20746 := by
  intro p hp
  have h : env20746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20745_20746 : H12AffineEnvironment.transform 12 1337 env20745 = env20746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env20745 == env20746) = true)

theorem identity20746 : scanCanonicalize (H12AffineFastState.compose env20746 (packedSelected [0,7,14,17,18] rootPS)) = affineNative (2^(21+1) ^^^ 7252) := by decide +kernel

theorem selectedBound20746 : packedSelected [0,7,14,17,18] rootPS < 2^1333 := by decide +kernel

def env20747 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1337,16384,1125,20759,5172,3345,1025,1124,5457,7252,17,3,1336,65,4113,17444,16400,23888,20848,6241,257,1045,17508,513]

theorem envBound20747 : H12AffineFastState.Bounded env20747 := by
  intro p hp
  have h : env20747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20746_20747 : H12AffineEnvironment.transform 21 7252 env20746 = env20747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 7252 env20746 == env20747) = true)

theorem identity20747 : scanCanonicalize (H12AffineFastState.compose env20747 (packedSelected [0,1,3,4,5,7,8,9,14,23] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound20747 : packedSelected [0,1,3,4,5,7,8,9,14,23] rootPS < 2^1333 := by decide +kernel

def env20748 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1337,5157,1125,1330,5172,3345,1025,1124,5457,7252,17,3,1336,65,4113,4097,5173,2421,1365,6241,257,1045,4161,513]

theorem envBound20748 : H12AffineFastState.Bounded env20748 := by
  intro p hp
  have h : env20748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20747_20748 : H12AffineEnvironment.transform 13 5157 env20747 = env20748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env20747 == env20748) = true)

theorem identity20748 : scanCanonicalize (H12AffineFastState.compose env20748 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 3189) := by decide +kernel

theorem selectedBound20748 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env20749 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3189,1337,2128,1125,1330,2113,3345,1025,1124,2340,33,17,3,1336,65,3172,3188,2112,2421,1365,1044,257,1045,3124,513]

theorem envBound20749 : H12AffineFastState.Bounded env20749 := by
  intro p hp
  have h : env20749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20748_20749 : H12AffineEnvironment.transform 11 3189 env20748 = env20749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3189 env20748 == env20749) = true)

theorem identity20749 : scanCanonicalize (H12AffineFastState.compose env20749 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound20749 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env20750 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,2065,349,2128,1,342,2113,2421,101,0,2340,33,17,3,348,65,2048,2064,2112,2421,305,112,257,113,2128,513]

theorem envBound20750 : H12AffineFastState.Bounded env20750 := by
  intro p hp
  have h : env20750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20749_20750 : H12AffineEnvironment.transform 9 100 env20749 = env20750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env20749 == env20750) = true)

theorem identity20750 : scanCanonicalize (H12AffineFastState.compose env20750 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20750 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20751 : List Nat := [2,4,8,16,32,16,9,256,512,52,2048,2065,269,2048,1,262,2065,2341,53,0,2340,33,17,3,268,17,2048,2064,2064,2341,305,32,257,33,2048,513]

theorem envBound20751 : H12AffineFastState.Bounded env20751 := by
  intro p hp
  have h : env20751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20750_20751 : H12AffineEnvironment.transform 5 16 env20750 = env20751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20750 == env20751) = true)

theorem identity20751 : scanCanonicalize (H12AffineFastState.compose env20751 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 773) := by decide +kernel

theorem selectedBound20751 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env20752 : List Nat := [2,4,8,16,32,16,9,256,512,52,773,788,269,773,1,262,788,544,53,0,545,33,17,3,268,17,773,789,789,544,305,32,257,33,773,513]

theorem envBound20752 : H12AffineFastState.Bounded env20752 := by
  intro p hp
  have h : env20752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20751_20752 : H12AffineEnvironment.transform 10 773 env20751 = env20752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 773 env20751 == env20752) = true)

def env20753 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35189,1025,32769,2097152,4194304,8388608,8429903,8193,65,4229152,10560843,10507600,8464750,75103,14795782,257,2188651,2196550,512]

theorem envBound20753 : H12AffineFastState.Bounded env20753 := by
  intro p hp
  have h : env20753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20730_20753 : H12AffineEnvironment.transform 17 35189 env20730 = env20753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env20730 == env20753) = true)

theorem identity20753 : scanCanonicalize (H12AffineFastState.compose env20753 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 17460) := by decide +kernel

theorem selectedBound20753 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env20754 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35189,1025,32769,17460,4194304,8388608,8429903,8193,65,4229152,8479103,8393060,8464750,75103,12681266,257,74079,114802,512]

theorem envBound20754 : H12AffineFastState.Bounded env20754 := by
  intro p hp
  have h : env20754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20753_20754 : H12AffineEnvironment.transform 20 17460 env20753 = env20754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17460 env20753 == env20754) = true)

theorem identity20754 : scanCanonicalize (H12AffineFastState.compose env20754 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 21604) := by decide +kernel

theorem selectedBound20754 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env20755 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35189,1025,32769,17460,4194304,21604,62763,8193,65,4229152,79131,17664,97546,75103,4314198,257,74079,114802,512]

theorem envBound20755 : H12AffineFastState.Bounded env20755 := by
  intro p hp
  have h : env20755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20754_20755 : H12AffineEnvironment.transform 22 21604 env20754 = env20755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 21604 env20754 == env20755) = true)

theorem identity20755 : scanCanonicalize (H12AffineFastState.compose env20755 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 62728) := by decide +kernel

theorem selectedBound20755 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env20756 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35189,1025,32769,17460,62728,21604,62763,8193,65,32040,79131,17664,97546,75103,74078,257,74079,114802,512]

theorem envBound20756 : H12AffineFastState.Bounded env20756 := by
  intro p hp
  have h : env20756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20755_20756 : H12AffineEnvironment.transform 21 62728 env20755 = env20756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62728 env20755 == env20756) = true)

theorem identity20756 : scanCanonicalize (H12AffineFastState.compose env20756 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound20756 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env20757 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16401,35189,1025,32769,17460,62728,21604,62763,8193,65,32040,5392,17664,23809,1364,341,257,340,57465,512]

theorem envBound20757 : H12AffineFastState.Bounded env20757 := by
  intro p hp
  have h : env20757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20756_20757 : H12AffineEnvironment.transform 15 8203 env20756 = env20757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env20756 == env20757) = true)

theorem identity20757 : scanCanonicalize (H12AffineFastState.compose env20757 (packedSelected [0,7,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 8572) := by decide +kernel

theorem selectedBound20757 : packedSelected [0,7,17,20] rootPS < 2^1333 := by decide +kernel

def env20758 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8572,8203,16401,10249,1025,8573,17460,21620,21604,21591,8193,65,32040,5392,17664,23809,1364,341,257,340,16645,512]

theorem envBound20758 : H12AffineFastState.Bounded env20758 := by
  intro p hp
  have h : env20758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20757_20758 : H12AffineEnvironment.transform 14 8572 env20757 = env20758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8572 env20757 == env20758) = true)

theorem identity20758 : scanCanonicalize (H12AffineFastState.compose env20758 (packedSelected [3,5,6,10,12,14,15,21] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound20758 : packedSelected [3,5,6,10,12,14,15,21] rootPS < 2^1333 := by decide +kernel

def env20759 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5124,8572,8203,5141,10249,1025,8573,4144,112,96,83,8193,65,10540,5392,4356,2309,1364,341,257,340,5377,512]

theorem envBound20759 : H12AffineFastState.Bounded env20759 := by
  intro p hp
  have h : env20759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20758_20759 : H12AffineEnvironment.transform 13 5124 env20758 = env20759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env20758 == env20759) = true)

theorem identity20759 : scanCanonicalize (H12AffineFastState.compose env20759 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 381) := by decide +kernel

theorem selectedBound20759 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env20760 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,381,5124,1,374,5141,2420,1025,0,4144,112,96,83,380,65,2129,5392,4356,2309,1364,341,257,340,5377,512]

theorem envBound20760 : H12AffineFastState.Bounded env20760 := by
  intro p hp
  have h : env20760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20759_20760 : H12AffineEnvironment.transform 12 381 env20759 = env20760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 381 env20759 == env20760) = true)

theorem identity20760 : scanCanonicalize (H12AffineFastState.compose env20760 (packedSelected [2,14] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20760 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env20761 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,349,5124,1,342,5141,2388,1025,0,4112,80,64,83,348,65,2129,5392,4356,2309,1364,341,257,340,5377,512]

theorem envBound20761 : H12AffineFastState.Bounded env20761 := by
  intro p hp
  have h : env20761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20760_20761 : H12AffineEnvironment.transform 4 0 env20760 = env20761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20760 == env20761) = true)

theorem identity20761 : scanCanonicalize (H12AffineFastState.compose env20761 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20761 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env20762 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,268,5124,1,263,5141,2309,1025,0,4112,1,17,2,269,16,2048,5392,4356,2309,1285,260,257,261,5377,512]

theorem envBound20762 : H12AffineFastState.Bounded env20762 := by
  intro p hp
  have h : env20762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20761_20762 : H12AffineEnvironment.transform 5 17 env20761 = env20762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20761 == env20762) = true)

theorem identity20762 : scanCanonicalize (H12AffineFastState.compose env20762 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1054) := by decide +kernel

theorem selectedBound20762 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20763 : List Nat := [2,4,8,16,0,17,9,256,512,1024,1054,4096,268,5124,1,263,5141,1307,1025,0,4112,1,17,2,269,16,1054,5392,4356,1307,1285,260,257,261,5377,512]

theorem envBound20763 : H12AffineFastState.Bounded env20763 := by
  intro p hp
  have h : env20763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20762_20763 : H12AffineEnvironment.transform 10 1054 env20762 = env20763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1054 env20762 == env20763) = true)

theorem identity20763 : scanCanonicalize (H12AffineFastState.compose env20763 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound20763 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20764 : List Nat := [2,4,8,16,0,17,9,4,512,1024,1054,4096,8,5124,1,3,5141,1055,1025,0,4112,1,17,2,9,16,1054,5140,4096,1055,1025,0,5,1,5125,512]

theorem envBound20764 : H12AffineFastState.Bounded env20764 := by
  intro p hp
  have h : env20764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20763_20764 : H12AffineEnvironment.transform 7 4 env20763 = env20764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env20763 == env20764) = true)

theorem identity20764 : scanCanonicalize (H12AffineFastState.compose env20764 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound20764 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20765 : List Nat := [2,4,8,16,0,17,9,4,512,1024,1054,1,8,1029,1,3,1044,1055,1025,0,17,1,17,2,9,16,1054,1045,1,1055,1025,0,5,1,1028,512]

theorem envBound20765 : H12AffineFastState.Bounded env20765 := by
  intro p hp
  have h : env20765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20764_20765 : H12AffineEnvironment.transform 11 1 env20764 = env20765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env20764 == env20765) = true)

theorem identity20765 : scanCanonicalize (H12AffineFastState.compose env20765 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound20765 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20766 : List Nat := [2,4,8,16,0,17,9,4,10,1024,1054,1,8,1029,1,3,1044,1055,1025,0,17,1,17,2,9,16,1054,1045,1,1055,1025,0,5,1,1028,10]

theorem envBound20766 : H12AffineFastState.Bounded env20766 := by
  intro p hp
  have h : env20766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20765_20766 : H12AffineEnvironment.transform 8 10 env20765 = env20766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env20765 == env20766) = true)

theorem identity20766 : scanCanonicalize (H12AffineFastState.compose env20766 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound20766 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20767 : List Nat := [2,4,8,12,0,13,9,4,10,1024,1026,1,8,1029,1,3,1032,1027,1025,0,13,1,13,2,9,12,1026,1033,1,1027,1025,0,5,1,1028,10]

theorem envBound20767 : H12AffineFastState.Bounded env20767 := by
  intro p hp
  have h : env20767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20766_20767 : H12AffineEnvironment.transform 3 12 env20766 = env20767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env20766 == env20767) = true)

theorem identity20767 : scanCanonicalize (H12AffineFastState.compose env20767 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound20767 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env20768 : List Nat := [2,4,4,0,0,1,5,4,6,1024,1026,1,4,1029,1,3,1028,1027,1025,0,1,1,1,2,5,0,1026,1029,1,1027,1025,0,5,1,1028,6]

theorem envBound20768 : H12AffineFastState.Bounded env20768 := by
  intro p hp
  have h : env20768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20767_20768 : H12AffineEnvironment.transform 2 4 env20767 = env20768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env20767 == env20768) = true)

theorem identity20768 : scanCanonicalize (H12AffineFastState.compose env20768 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 1) := by decide +kernel

theorem selectedBound20768 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20769 : List Nat := [2,4,4,0,0,1,5,4,6,1,3,1,4,4,1,3,5,2,0,0,1,1,1,2,5,0,3,4,1,2,0,0,5,1,5,6]

theorem envBound20769 : H12AffineFastState.Bounded env20769 := by
  intro p hp
  have h : env20769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20768_20769 : H12AffineEnvironment.transform 9 1 env20768 = env20769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env20768 == env20769) = true)

theorem identity20769 : scanCanonicalize (H12AffineFastState.compose env20769 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound20769 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env20770 : List Nat := [2,0,0,0,0,1,1,0,2,1,3,1,0,0,1,3,1,2,0,0,1,1,1,2,1,0,3,0,1,2,0,0,1,1,1,2]

theorem envBound20770 : H12AffineFastState.Bounded env20770 := by
  intro p hp
  have h : env20770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20769_20770 : H12AffineEnvironment.transform 1 0 env20769 = env20770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env20769 == env20770) = true)

def env20771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,536870912,1073741824,92374097,4294967296,525568,4308116844,620851224,25733063]

theorem envBound20771 : H12AffineFastState.Bounded env20771 := by
  intro p hp
  have h : env20771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9855_20771 : H12AffineEnvironment.transform 27 19497101 env9855 = env20771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 19497101 env9855 == env20771) = true)

def env20772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616400,1073741824,92374097,4294967296,525568,4308116844,27337992,25733063]

theorem envBound20772 : H12AffineFastState.Bounded env20772 := by
  intro p hp
  have h : env20772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20771_20772 : H12AffineEnvironment.transform 28 77616400 env20771 = env20772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 77616400 env20771 == env20772) = true)

def env20773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616400,1073741824,92374097,145662400,525568,140903596,27337992,25733063]

theorem envBound20773 : H12AffineFastState.Bounded env20773 := by
  intro p hp
  have h : env20773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20772_20773 : H12AffineEnvironment.transform 31 145662400 env20772 = env20773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662400 env20772 == env20773) = true)

def env20774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616400,155254784,92374097,145662400,525568,140903596,27337992,25733063]

theorem envBound20774 : H12AffineFastState.Bounded env20774 := by
  intro p hp
  have h : env20774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20773_20774 : H12AffineEnvironment.transform 29 155254784 env20773 = env20774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env20773 == env20774) = true)

def env20775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507600,155254784,25265169,145662400,525568,140903596,27337992,25733063]

theorem envBound20775 : H12AffineFastState.Bounded env20775 := by
  intro p hp
  have h : env20775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20774_20775 : H12AffineEnvironment.transform 25 64 env20774 = env20775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env20774 == env20775) = true)

def env20776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507600,9356288,25265169,23160256,525568,27902124,27337992,25733063]

theorem envBound20776 : H12AffineFastState.Bounded env20776 := by
  intro p hp
  have h : env20776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20775_20776 : H12AffineEnvironment.transform 26 30393344 env20775 = env20776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env20775 == env20776) = true)

def env20777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830976,25265169,23160256,256,27378860,27337992,25207751]

theorem envBound20777 : H12AffineFastState.Bounded env20777 := by
  intro p hp
  have h : env20777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20776_20777 : H12AffineEnvironment.transform 18 1024 env20776 = env20777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env20776 == env20777) = true)

theorem identity20777 : scanCanonicalize (H12AffineFastState.compose env20777 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2188736) := by decide +kernel

theorem selectedBound20777 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env20778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2188736,8328,64,15115712,57677,10507600,8830976,10543569,4194304,256,8429932,8405192,10601991]

theorem envBound20778 : H12AffineFastState.Bounded env20778 := by
  intro p hp
  have h : env20778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20777_20778 : H12AffineEnvironment.transform 23 2188736 env20777 = env20778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2188736 env20777 == env20778) = true)

def env20779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,62540,2188736,8328,64,6705548,57677,2138396,406604,2102685,4194304,256,21792,46212,2175563]

theorem envBound20779 : H12AffineFastState.Bounded env20779 := by
  intro p hp
  have h : env20779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20778_20779 : H12AffineEnvironment.transform 22 62540 env20778 = env20779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 62540 env20778 == env20779) = true)

def env20780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2101344,62540,2188736,8328,64,410092,57677,2138396,406604,2102685,2101344,256,21792,46212,2175563]

theorem envBound20780 : H12AffineFastState.Bounded env20780 := by
  intro p hp
  have h : env20780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20779_20780 : H12AffineEnvironment.transform 21 2101344 env20779 = env20780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2101344 env20779 == env20780) = true)

def env20781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21792,62540,73856,8328,64,410092,57677,58460,406604,20701,21792,256,21792,46212,96011]

theorem envBound20781 : H12AffineFastState.Bounded env20781 := by
  intro p hp
  have h : env20781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20780_20781 : H12AffineEnvironment.transform 20 17728 env20780 = env20781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env20780 == env20781) = true)

theorem identity20781 : scanCanonicalize (H12AffineFastState.compose env20781 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20781 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20782 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21792,62540,73736,8192,64,409956,57677,58460,406604,20565,21792,256,21792,46092,96011]

theorem envBound20782 : H12AffineFastState.Bounded env20782 := by
  intro p hp
  have h : env20782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20781_20782 : H12AffineEnvironment.transform 6 8 env20781 = env20782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20781 == env20782) = true)

def env20783 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,17728,21792,62540,73736,8192,64,158028,57677,58460,138340,20565,21792,256,21792,46092,96011]

theorem envBound20783 : H12AffineFastState.Bounded env20783 := by
  intro p hp
  have h : env20783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20782_20783 : H12AffineEnvironment.transform 17 10280 env20782 = env20783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env20782 == env20783) = true)

theorem identity20783 : scanCanonicalize (H12AffineFastState.compose env20783 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound20783 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20784 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,131072,10280,1024,32769,17728,21792,62540,21762,8192,64,158028,57677,58460,138340,20565,21792,256,21792,46092,513]

theorem envBound20784 : H12AffineFastState.Bounded env20784 := by
  intro p hp
  have h : env20784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20783_20784 : H12AffineEnvironment.transform 15 29962 env20783 = env20784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env20783 == env20784) = true)

theorem identity20784 : scanCanonicalize (H12AffineFastState.compose env20784 (packedSelected [1,8,10,14,15,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 49217) := by decide +kernel

theorem selectedBound20784 : packedSelected [1,8,10,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env20785 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,49217,10280,1024,32769,17728,21792,62540,21762,8192,64,43277,57677,58460,56357,20565,21792,256,21792,46092,513]

theorem envBound20785 : H12AffineFastState.Bounded env20785 := by
  intro p hp
  have h : env20785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20784_20785 : H12AffineEnvironment.transform 16 49217 env20784 = env20785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49217 env20784 == env20785) = true)

theorem identity20785 : scanCanonicalize (H12AffineFastState.compose env20785 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20785 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env20786 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,29962,49169,10280,1024,32769,17680,21792,62492,21762,8192,16,43277,57629,58380,56357,20485,21792,256,21792,46092,513]

theorem envBound20786 : H12AffineFastState.Bounded env20786 := by
  intro p hp
  have h : env20786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20785_20786 : H12AffineEnvironment.transform 5 16 env20785 = env20786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20785 == env20786) = true)

theorem identity20786 : scanCanonicalize (H12AffineFastState.compose env20786 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound20786 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env20787 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,32768,21510,49169,2340,1024,32769,17680,21792,54544,21762,268,16,34817,49169,50432,56357,20485,21792,256,21792,38144,513]

theorem envBound20787 : H12AffineFastState.Bounded env20787 := by
  intro p hp
  have h : env20787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20786_20787 : H12AffineEnvironment.transform 12 268 env20786 = env20787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env20786 == env20787) = true)

theorem identity20787 : scanCanonicalize (H12AffineFastState.compose env20787 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound20787 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20788 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,21760,21510,5393,2340,1024,21761,17680,21792,16,21762,268,16,23809,5393,4096,2341,20485,21792,256,21792,16384,513]

theorem envBound20788 : H12AffineFastState.Bounded env20788 := by
  intro p hp
  have h : env20788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20787_20788 : H12AffineEnvironment.transform 14 21760 env20787 = env20788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env20787 == env20788) = true)

theorem identity20788 : scanCanonicalize (H12AffineFastState.compose env20788 (packedSelected [1,2,3,4,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 1077) := by decide +kernel

theorem selectedBound20788 : packedSelected [1,2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env20789 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,1077,4405,4147,5393,2340,1024,4404,293,4373,16,4407,268,16,6452,5393,4096,2341,5168,4373,256,4373,1077,513]

theorem envBound20789 : H12AffineFastState.Bounded env20789 := by
  intro p hp
  have h : env20789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20788_20789 : H12AffineEnvironment.transform 13 1077 env20788 = env20789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1077 env20788 == env20789) = true)

theorem identity20789 : scanCanonicalize (H12AffineFastState.compose env20789 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound20789 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env20790 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,1077,4113,4147,5173,2048,1024,4112,1,4145,16,4115,40,16,6160,5173,4096,2049,5168,4145,36,4145,1077,513]

theorem envBound20790 : H12AffineFastState.Bounded env20790 := by
  intro p hp
  have h : env20790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20789_20790 : H12AffineEnvironment.transform 7 36 env20789 = env20790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20789 == env20790) = true)

theorem identity20790 : scanCanonicalize (H12AffineFastState.compose env20790 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound20790 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20791 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1,4096,40,1077,4113,4147,5173,1,1024,4112,1,4145,16,4115,40,16,4113,5173,4096,0,5168,4145,36,4145,1077,513]

theorem envBound20791 : H12AffineFastState.Bounded env20791 := by
  intro p hp
  have h : env20791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20790_20791 : H12AffineEnvironment.transform 10 1 env20790 = env20791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env20790 == env20791) = true)

theorem identity20791 : scanCanonicalize (H12AffineFastState.compose env20791 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound20791 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env20792 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1,16,40,1077,1,35,1061,1,1024,0,1,33,16,3,40,16,1,1061,16,0,1056,33,36,33,1077,513]

theorem envBound20792 : H12AffineFastState.Bounded env20792 := by
  intro p hp
  have h : env20792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20791_20792 : H12AffineEnvironment.transform 11 16 env20791 = env20792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env20791 == env20792) = true)

def env20793 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,17728,21792,62540,73736,8192,64,158029,57677,58460,138341,20565,21792,256,21792,46092,96011]

theorem envBound20793 : H12AffineFastState.Bounded env20793 := by
  intro p hp
  have h : env20793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20782_20793 : H12AffineEnvironment.transform 17 10281 env20782 = env20793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env20782 == env20793) = true)

theorem identity20793 : scanCanonicalize (H12AffineFastState.compose env20793 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound20793 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20794 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,131072,10281,1024,32769,17728,21792,62540,41310,8192,64,158029,57677,58460,138341,20565,21792,256,21792,46092,63069]

theorem envBound20794 : H12AffineFastState.Bounded env20794 := by
  intro p hp
  have h : env20794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20793_20794 : H12AffineEnvironment.transform 15 33110 env20793 = env20794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env20793 == env20794) = true)

theorem identity20794 : scanCanonicalize (H12AffineFastState.compose env20794 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound20794 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env20795 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,5393,10281,1024,32769,17728,21792,62540,41310,8192,64,31836,57677,58460,2420,20565,21792,256,21792,46092,63069]

theorem envBound20795 : H12AffineFastState.Bounded env20795 := by
  intro p hp
  have h : env20795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20794_20795 : H12AffineEnvironment.transform 16 5393 env20794 = env20795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env20794 == env20795) = true)

theorem identity20795 : scanCanonicalize (H12AffineFastState.compose env20795 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound20795 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20796 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,16384,32768,33110,4096,10281,273,32769,16465,20529,61789,41310,8192,64,31053,57677,57677,2420,20565,20529,256,20529,45341,62284]

theorem envBound20796 : H12AffineFastState.Bounded env20796 := by
  intro p hp
  have h : env20796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20795_20796 : H12AffineEnvironment.transform 9 273 env20795 = env20796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env20795 == env20796) = true)

theorem identity20796 : scanCanonicalize (H12AffineFastState.compose env20796 (packedSelected [1,8,19] rootPS)) = affineNative (2^(14+1) ^^^ 29005) := by decide +kernel

theorem selectedBound20796 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env20797 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,16384,29005,28699,4096,10281,273,29004,16465,20529,16,20499,8192,64,31053,4096,4096,2420,20565,20529,256,20529,16464,513]

theorem envBound20797 : H12AffineFastState.Bounded env20797 := by
  intro p hp
  have h : env20797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20796_20797 : H12AffineEnvironment.transform 14 29005 env20796 = env20797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29005 env20796 == env20797) = true)

theorem identity20797 : scanCanonicalize (H12AffineFastState.compose env20797 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 381) := by decide +kernel

theorem selectedBound20797 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env20798 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,381,16384,20528,20838,4096,2388,273,20529,16465,20529,16,20499,381,64,22576,4096,4096,2420,20565,20529,256,20529,16464,513]

theorem envBound20798 : H12AffineFastState.Bounded env20798 := by
  intro p hp
  have h : env20798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20797_20798 : H12AffineEnvironment.transform 12 381 env20797 = env20798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 381 env20797 == env20798) = true)

theorem identity20798 : scanCanonicalize (H12AffineFastState.compose env20798 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound20798 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env20799 : List Nat := [2,4,8,16,32,64,8,256,512,273,81,4096,381,16384,20528,20838,4096,261,273,20529,16465,20529,16,20499,381,64,20577,4096,4096,293,20565,20529,256,20529,16464,513]

theorem envBound20799 : H12AffineFastState.Bounded env20799 := by
  intro p hp
  have h : env20799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20798_20799 : H12AffineEnvironment.transform 10 81 env20798 = env20799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env20798 == env20799) = true)

theorem identity20799 : scanCanonicalize (H12AffineFastState.compose env20799 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound20799 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env20800 : List Nat := [2,4,8,16,32,64,8,256,512,273,81,48,381,16384,16384,16726,48,261,273,16385,16465,16385,16,16419,381,64,16465,48,48,293,16485,16385,256,16385,16464,513]

theorem envBound20800 : H12AffineFastState.Bounded env20800 := by
  intro p hp
  have h : env20800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20799_20800 : H12AffineEnvironment.transform 11 48 env20799 = env20800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env20799 == env20800) = true)

theorem identity20800 : scanCanonicalize (H12AffineFastState.compose env20800 (packedSelected [0,7,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound20800 : packedSelected [0,7,14,18] rootPS < 2^1333 := by decide +kernel

def env20801 : List Nat := [2,4,8,16,32,64,8,84,512,69,81,48,41,16384,16384,16386,48,81,69,16385,16465,16385,16,16419,41,64,16465,48,48,113,16485,16385,84,16385,16464,513]

theorem envBound20801 : H12AffineFastState.Bounded env20801 := by
  intro p hp
  have h : env20801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20800_20801 : H12AffineEnvironment.transform 7 84 env20800 = env20801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env20800 == env20801) = true)

theorem identity20801 : scanCanonicalize (H12AffineFastState.compose env20801 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound20801 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20802 : List Nat := [2,4,8,16,32,64,8,84,80,69,81,48,41,16384,16384,16386,48,81,69,16385,16465,16385,16,16419,41,64,16465,48,48,113,16485,16385,84,16385,16464,81]

theorem envBound20802 : H12AffineFastState.Bounded env20802 := by
  intro p hp
  have h : env20802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20801_20802 : H12AffineEnvironment.transform 8 80 env20801 = env20802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env20801 == env20802) = true)

theorem identity20802 : scanCanonicalize (H12AffineFastState.compose env20802 (packedSelected [1,5] rootPS)) = affineNative (2^(13+1) ^^^ 97) := by decide +kernel

theorem selectedBound20802 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env20803 : List Nat := [2,4,8,16,32,64,8,84,80,69,81,48,41,97,97,99,48,81,69,96,48,96,16,66,41,64,48,48,48,113,4,96,84,96,49,81]

theorem envBound20803 : H12AffineFastState.Bounded env20803 := by
  intro p hp
  have h : env20803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20802_20803 : H12AffineEnvironment.transform 13 97 env20802 = env20803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 97 env20802 == env20803) = true)

theorem identity20803 : scanCanonicalize (H12AffineFastState.compose env20803 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound20803 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env20804 : List Nat := [2,4,8,16,17,64,8,84,80,69,81,1,24,80,80,82,1,81,69,81,1,81,16,66,24,64,1,1,1,64,4,81,84,81,0,81]

theorem envBound20804 : H12AffineFastState.Bounded env20804 := by
  intro p hp
  have h : env20804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20803_20804 : H12AffineEnvironment.transform 4 17 env20803 = env20804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env20803 == env20804) = true)

theorem identity20804 : scanCanonicalize (H12AffineFastState.compose env20804 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound20804 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20805 : List Nat := [2,4,8,1,0,64,8,69,65,69,64,1,9,65,65,67,1,64,69,64,1,64,1,66,9,64,1,1,1,64,4,64,69,64,0,64]

theorem envBound20805 : H12AffineFastState.Bounded env20805 := by
  intro p hp
  have h : env20805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20804_20805 : H12AffineEnvironment.transform 3 1 env20804 = env20805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env20804 == env20805) = true)

theorem identity20805 : scanCanonicalize (H12AffineFastState.compose env20805 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound20805 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20806 : List Nat := [2,4,8,1,0,0,8,5,1,5,0,1,9,1,1,3,1,0,5,0,1,0,1,2,9,0,1,1,1,0,4,0,5,0,0,0]

theorem envBound20806 : H12AffineFastState.Bounded env20806 := by
  intro p hp
  have h : env20806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20805_20806 : H12AffineEnvironment.transform 5 0 env20805 = env20806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env20805 == env20806) = true)

def env20807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21793,62540,73857,8328,64,410092,57677,58461,406604,20700,21793,256,21792,46212,96010]

theorem envBound20807 : H12AffineFastState.Bounded env20807 := by
  intro p hp
  have h : env20807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20780_20807 : H12AffineEnvironment.transform 20 17729 env20780 = env20807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env20780 == env20807) = true)

theorem identity20807 : scanCanonicalize (H12AffineFastState.compose env20807 (packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 89515) := by decide +kernel

theorem selectedBound20807 : packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env20808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89515,1024,32769,17729,21793,62540,73857,8328,64,203847,57677,58461,223719,20700,21793,256,21792,46212,96010]

theorem envBound20808 : H12AffineFastState.Bounded env20808 := by
  intro p hp
  have h : env20808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20807_20808 : H12AffineEnvironment.transform 17 89515 env20807 = env20808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89515 env20807 == env20808) = true)

def env20809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,89515,1024,29789,17729,21793,16,73857,8328,64,203847,5393,4097,223719,20700,21793,256,21792,16600,96010]

theorem envBound20809 : H12AffineFastState.Bounded env20809 := by
  intro p hp
  have h : env20809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20808_20809 : H12AffineEnvironment.transform 14 29788 env20808 = env20809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env20808 == env20809) = true)

theorem identity20809 : scanCanonicalize (H12AffineFastState.compose env20809 (packedSelected [0,2,7,9,12,15,18,20,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 13444) := by decide +kernel

theorem selectedBound20809 : packedSelected [0,2,7,9,12,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env20810 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13444,216,65536,131072,76079,1024,217,12741,8613,16,73857,8328,64,203847,5393,4097,204131,9304,8613,256,8612,13404,66446]

theorem envBound20810 : H12AffineFastState.Bounded env20810 := by
  intro p hp
  have h : env20810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20809_20810 : H12AffineEnvironment.transform 13 13444 env20809 = env20810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13444 env20809 == env20810) = true)

def env20811 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,80,65536,131072,76079,1024,81,12621,8493,16,73737,8192,64,203847,5393,4097,204131,9304,8493,256,8492,13404,66310]

theorem envBound20811 : H12AffineFastState.Bounded env20811 := by
  intro p hp
  have h : env20811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20810_20811 : H12AffineEnvironment.transform 6 8 env20810 = env20811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20810 == env20811) = true)

theorem identity20811 : scanCanonicalize (H12AffineFastState.compose env20811 (packedSelected [1,4,6,8,9,10,12,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound20811 : packedSelected [1,4,6,8,9,10,12,14,18] rootPS < 2^1333 := by decide +kernel

def env20812 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,80,8202,131072,2341,1024,81,12621,8493,16,3,8192,64,146509,5393,4097,146793,9304,8493,256,8492,13404,8972]

theorem envBound20812 : H12AffineFastState.Bounded env20812 := by
  intro p hp
  have h : env20812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20811_20812 : H12AffineEnvironment.transform 15 8202 env20811 = env20812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env20811 == env20812) = true)

theorem identity20812 : scanCanonicalize (H12AffineFastState.compose env20812 (packedSelected [0,1,8,9,11,15] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound20812 : packedSelected [0,1,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env20813 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,80,8202,5393,2341,1024,81,12621,8493,16,3,8192,64,10588,5393,4097,10360,9304,8493,256,8492,13404,8972]

theorem envBound20813 : H12AffineFastState.Bounded env20813 := by
  intro p hp
  have h : env20813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20812_20813 : H12AffineEnvironment.transform 16 5393 env20812 = env20813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env20812 == env20813) = true)

theorem identity20813 : scanCanonicalize (H12AffineFastState.compose env20813 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 814) := by decide +kernel

theorem selectedBound20813 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env20814 : List Nat := [2,4,8,16,32,64,8,256,512,1024,814,4096,8192,13324,80,8202,5393,523,1024,81,12621,8493,16,3,8192,64,8818,5393,4097,9046,9304,8493,256,8492,13404,8972]

theorem envBound20814 : H12AffineFastState.Bounded env20814 := by
  intro p hp
  have h : env20814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20813_20814 : H12AffineEnvironment.transform 10 814 env20813 = env20814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 814 env20813 == env20814) = true)

theorem identity20814 : scanCanonicalize (H12AffineFastState.compose env20814 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound20814 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env20815 : List Nat := [2,4,8,16,32,64,8,116,512,1024,602,4096,8192,13324,80,8202,5221,523,1024,81,12345,8281,16,3,8192,64,8818,5221,4097,8738,9304,8281,116,8280,13404,8824]

theorem envBound20815 : H12AffineFastState.Bounded env20815 := by
  intro p hp
  have h : env20815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20814_20815 : H12AffineEnvironment.transform 7 116 env20814 = env20815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env20814 == env20815) = true)

theorem identity20815 : scanCanonicalize (H12AffineFastState.compose env20815 (packedSelected [4,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound20815 : packedSelected [4,7,10,20] rootPS < 2^1333 := by decide +kernel

def env20816 : List Nat := [2,4,8,16,32,64,8,116,512,1024,602,4096,120,5236,80,114,5221,523,1024,81,4161,33,16,3,120,64,522,5221,4097,602,1056,33,116,32,5156,512]

theorem envBound20816 : H12AffineFastState.Bounded env20816 := by
  intro p hp
  have h : env20816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20815_20816 : H12AffineEnvironment.transform 12 120 env20815 = env20816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env20815 == env20816) = true)

theorem identity20816 : scanCanonicalize (H12AffineFastState.compose env20816 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound20816 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env20817 : List Nat := [2,4,8,16,32,48,8,4,512,1024,554,4096,8,5124,32,2,5141,523,1024,33,4145,33,16,3,8,48,522,5141,4097,554,1056,33,4,32,5156,512]

theorem envBound20817 : H12AffineFastState.Bounded env20817 := by
  intro p hp
  have h : env20817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20816_20817 : H12AffineEnvironment.transform 5 48 env20816 = env20817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env20816 == env20817) = true)

theorem identity20817 : scanCanonicalize (H12AffineFastState.compose env20817 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 574) := by decide +kernel

theorem selectedBound20817 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20818 : List Nat := [2,4,8,16,32,48,8,4,512,574,554,4096,8,4666,32,2,4651,523,574,33,4145,33,16,3,8,48,522,4651,4097,554,542,33,4,32,4634,512]

theorem envBound20818 : H12AffineFastState.Bounded env20818 := by
  intro p hp
  have h : env20818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20817_20818 : H12AffineEnvironment.transform 9 574 env20817 = env20818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 574 env20817 == env20818) = true)

theorem identity20818 : scanCanonicalize (H12AffineFastState.compose env20818 (packedSelected [0,1,4] rootPS)) = affineNative (2^(11+1) ^^^ 38) := by decide +kernel

theorem selectedBound20818 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env20819 : List Nat := [2,4,8,16,32,48,8,4,512,574,554,38,8,540,32,2,525,523,574,33,23,33,16,3,8,48,522,525,39,554,542,33,4,32,572,512]

theorem envBound20819 : H12AffineFastState.Bounded env20819 := by
  intro p hp
  have h : env20819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20818_20819 : H12AffineEnvironment.transform 11 38 env20818 = env20819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 38 env20818 == env20819) = true)

theorem identity20819 : scanCanonicalize (H12AffineFastState.compose env20819 (packedSelected [1,10] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound20819 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env20820 : List Nat := [2,4,8,16,32,48,8,4,10,52,32,38,8,22,32,2,7,1,52,33,23,33,16,3,8,48,0,7,39,32,20,33,4,32,54,10]

theorem envBound20820 : H12AffineFastState.Bounded env20820 := by
  intro p hp
  have h : env20820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20819_20820 : H12AffineEnvironment.transform 8 10 env20819 = env20820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env20819 == env20820) = true)

theorem identity20820 : scanCanonicalize (H12AffineFastState.compose env20820 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound20820 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20821 : List Nat := [2,4,8,16,8,24,8,4,10,28,8,14,8,22,8,2,7,1,28,9,23,9,16,3,8,24,0,7,15,8,20,9,4,8,30,10]

theorem envBound20821 : H12AffineFastState.Bounded env20821 := by
  intro p hp
  have h : env20821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20820_20821 : H12AffineEnvironment.transform 4 8 env20820 = env20821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env20820 == env20821) = true)

theorem identity20821 : scanCanonicalize (H12AffineFastState.compose env20821 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound20821 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20822 : List Nat := [2,4,8,7,8,15,8,4,10,11,8,14,8,1,8,2,7,1,11,9,0,9,7,3,8,15,0,7,15,8,3,9,4,8,9,10]

theorem envBound20822 : H12AffineFastState.Bounded env20822 := by
  intro p hp
  have h : env20822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20821_20822 : H12AffineEnvironment.transform 3 7 env20821 = env20822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env20821 == env20822) = true)

theorem identity20822 : scanCanonicalize (H12AffineFastState.compose env20822 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound20822 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20823 : List Nat := [2,4,0,7,0,7,0,4,2,3,0,6,0,1,0,2,7,1,3,1,0,1,7,3,0,7,0,7,7,0,3,1,4,0,1,2]

theorem envBound20823 : H12AffineFastState.Bounded env20823 := by
  intro p hp
  have h : env20823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20822_20823 : H12AffineEnvironment.transform 2 0 env20822 = env20823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env20822 == env20823) = true)

def env20824 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,81,65536,131072,76079,1024,80,12620,8492,16,73736,8193,64,203847,5393,4097,204131,9304,8492,256,8493,13404,66311]

theorem envBound20824 : H12AffineFastState.Bounded env20824 := by
  intro p hp
  have h : env20824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20810_20824 : H12AffineEnvironment.transform 6 9 env20810 = env20824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20810 == env20824) = true)

theorem identity20824 : scanCanonicalize (H12AffineFastState.compose env20824 (packedSelected [1,4,6,8,9,10,12,14,18] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound20824 : packedSelected [1,4,6,8,9,10,12,14,18] rootPS < 2^1333 := by decide +kernel

def env20825 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,81,65536,5221,76079,1024,80,12620,8492,16,73736,8193,64,67618,5393,4097,67846,9304,8492,256,8493,13404,66311]

theorem envBound20825 : H12AffineFastState.Bounded env20825 := by
  intro p hp
  have h : env20825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20824_20825 : H12AffineEnvironment.transform 16 5221 env20824 = env20825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env20824 == env20825) = true)

theorem identity20825 : scanCanonicalize (H12AffineFastState.compose env20825 (packedSelected [0,1,7,8,10,11,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound20825 : packedSelected [0,1,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env20826 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,81,8203,5221,2340,1024,80,12620,8492,16,3,8193,64,10281,5393,4097,10509,9304,8492,256,8493,13404,8972]

theorem envBound20826 : H12AffineFastState.Bounded env20826 := by
  intro p hp
  have h : env20826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20825_20826 : H12AffineEnvironment.transform 15 8203 env20825 = env20826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env20825 == env20826) = true)

theorem identity20826 : scanCanonicalize (H12AffineFastState.compose env20826 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound20826 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env20827 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,13325,81,8203,5221,2129,1024,80,12345,8281,16,3,8193,64,10281,5220,4097,10360,9304,8281,117,8280,13404,8825]

theorem envBound20827 : H12AffineFastState.Bounded env20827 := by
  intro p hp
  have h : env20827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20826_20827 : H12AffineEnvironment.transform 7 117 env20826 = env20827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env20826 == env20827) = true)

theorem identity20827 : scanCanonicalize (H12AffineFastState.compose env20827 (packedSelected [4,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound20827 : packedSelected [4,7,10,20] rootPS < 2^1333 := by decide +kernel

def env20828 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,5157,81,35,5221,2129,1024,80,4113,113,16,3,41,64,2049,5220,4097,2128,1136,113,117,112,5236,593]

theorem envBound20828 : H12AffineFastState.Bounded env20828 := by
  intro p hp
  have h : env20828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20827_20828 : H12AffineEnvironment.transform 12 40 env20827 = env20828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env20827 == env20828) = true)

theorem identity20828 : scanCanonicalize (H12AffineFastState.compose env20828 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20828 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env20829 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5157,0,35,5172,2048,1024,1,4113,32,16,3,41,17,2049,5173,4097,2049,1057,32,36,33,5157,512]

theorem envBound20829 : H12AffineFastState.Bounded env20829 := by
  intro p hp
  have h : env20829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20828_20829 : H12AffineEnvironment.transform 5 17 env20828 = env20829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20828 == env20829) = true)

theorem identity20829 : scanCanonicalize (H12AffineFastState.compose env20829 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20829 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20830 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,9,5124,0,2,5141,2048,1024,1,4113,1,16,3,8,17,2049,5140,4097,2049,1024,1,5,0,5124,512]

theorem envBound20830 : H12AffineFastState.Bounded env20830 := by
  intro p hp
  have h : env20830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20829_20830 : H12AffineEnvironment.transform 4 1 env20829 = env20830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20829 == env20830) = true)

def env20831 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,16,9,1044,0,2,1029,2048,1024,1,1,1,16,3,8,17,2049,1028,17,2049,1024,1,5,0,1044,512]

theorem envBound20831 : H12AffineFastState.Bounded env20831 := by
  intro p hp
  have h : env20831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20830_20831 : H12AffineEnvironment.transform 11 16 env20830 = env20831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env20830 == env20831) = true)

def env20832 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,17,9,1045,0,2,1028,2048,1024,1,0,1,16,3,8,17,2049,1029,16,2049,1024,1,5,0,1045,512]

theorem envBound20832 : H12AffineFastState.Bounded env20832 := by
  intro p hp
  have h : env20832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20830_20832 : H12AffineEnvironment.transform 11 17 env20830 = env20832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env20830 == env20832) = true)

theorem identity20832 : scanCanonicalize (H12AffineFastState.compose env20832 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound20832 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20833 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,17,9,0,0,2,17,2048,21,1,0,1,16,3,8,17,2049,16,16,2049,21,1,5,0,0,512]

theorem envBound20833 : H12AffineFastState.Bounded env20833 := by
  intro p hp
  have h : env20833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20832_20833 : H12AffineEnvironment.transform 9 21 env20832 = env20833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env20832 == env20833) = true)

theorem identity20833 : scanCanonicalize (H12AffineFastState.compose env20833 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound20833 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20834 : List Nat := [2,4,8,4,1,5,9,5,512,1,2048,5,9,0,0,2,5,2048,1,1,0,1,4,3,8,5,2049,4,4,2049,1,1,5,0,0,512]

theorem envBound20834 : H12AffineFastState.Bounded env20834 := by
  intro p hp
  have h : env20834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20833_20834 : H12AffineEnvironment.transform 3 4 env20833 = env20834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env20833 == env20834) = true)

def leafEnv20834 : List Nat := [2,4,8,4,1,5,9,5,512,1,2048,5,9,0,0,2,5,2048,1,1,0,1,4,3,1,8,1,5,2049,4,4,2049,1,1,5,0,4,3,0,512,1,0,0]

def active20834 : List Nat := [0,1,2,8,10]

def tree20834 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20834 : H12WitnessSearch.Good tree20834 := H12GlobalWitnessIndex.good

theorem leafIdentity20834 : H12AffineFastState.composeSystem env20834 rootObs = leafEnv20834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20834 rootObs == leafEnv20834) = true)

theorem terminalChecked20834 : H12PackedTerminal.terminalCheckFast leafEnv20834 active20834 tree20834 = true := by decide +kernel

def env20835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,89515,1024,29788,17729,21793,17,73857,8328,64,203847,5392,4096,223719,20700,21793,256,21792,16601,96010]

theorem envBound20835 : H12AffineFastState.Bounded env20835 := by
  intro p hp
  have h : env20835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20808_20835 : H12AffineEnvironment.transform 14 29789 env20808 = env20835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env20808 == env20835) = true)

theorem identity20835 : scanCanonicalize (H12AffineFastState.compose env20835 (packedSelected [0,2,7,9,12,15,18,20,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound20835 : packedSelected [0,2,7,9,12,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env20836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,5392,89515,1024,29788,17729,21793,17,73857,8328,64,67927,5392,4096,97527,20700,21793,256,21792,16601,96010]

theorem envBound20836 : H12AffineFastState.Bounded env20836 := by
  intro p hp
  have h : env20836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20835_20836 : H12AffineEnvironment.transform 16 5392 env20835 = env20836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env20835 == env20836) = true)

theorem identity20836 : scanCanonicalize (H12AffineFastState.compose env20836 (packedSelected [0,2,4,5,6,9,20,24,26,27] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound20836 : packedSelected [0,2,4,5,6,9,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env20837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,16384,21977,65536,5392,89515,1024,21976,17729,21793,17,65797,268,64,67927,5392,4096,89459,20700,21793,256,21792,16601,87694]

theorem envBound20837 : H12AffineFastState.Bounded env20837 := by
  intro p hp
  have h : env20837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20836_20837 : H12AffineEnvironment.transform 12 388 env20836 = env20837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env20836 == env20837) = true)

theorem identity20837 : scanCanonicalize (H12AffineFastState.compose env20837 (packedSelected [0,1,2,7,8,10,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20837 : packedSelected [0,1,2,7,8,10,15,18] rootPS < 2^1333 := by decide +kernel

def env20838 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,21897,65536,5392,89515,1024,21896,17681,21793,17,65797,268,16,67847,5392,4096,89379,20620,21793,256,21792,16521,87694]

theorem envBound20838 : H12AffineFastState.Bounded env20838 := by
  intro p hp
  have h : env20838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20837_20838 : H12AffineEnvironment.transform 5 16 env20837 = env20838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20837 == env20838) = true)

theorem identity20838 : scanCanonicalize (H12AffineFastState.compose env20838 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 21646) := by decide +kernel

theorem selectedBound20838 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env20839 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,21897,21646,5392,2341,1024,21896,17681,21793,17,21899,268,16,23945,5392,4096,2477,20620,21793,256,21792,16521,512]

theorem envBound20839 : H12AffineFastState.Bounded env20839 := by
  intro p hp
  have h : env20839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20838_20839 : H12AffineEnvironment.transform 15 21646 env20838 = env20839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21646 env20838 == env20839) = true)

theorem identity20839 : scanCanonicalize (H12AffineFastState.compose env20839 (packedSelected [1,2,7,8,9,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 156) := by decide +kernel

theorem selectedBound20839 : packedSelected [1,2,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env20840 : List Nat := [2,4,8,16,32,16,128,256,512,156,2048,4096,388,16384,20757,20498,4492,2341,156,20756,16781,20925,17,20759,268,16,22805,4492,4096,2477,20620,20925,256,20924,16521,512]

theorem envBound20840 : H12AffineFastState.Bounded env20840 := by
  intro p hp
  have h : env20840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20839_20840 : H12AffineEnvironment.transform 9 156 env20839 = env20840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 156 env20839 == env20840) = true)

theorem identity20840 : scanCanonicalize (H12AffineFastState.compose env20840 (packedSelected [0,2,6,9,12] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound20840 : packedSelected [0,2,6,9,12] rootPS < 2^1333 := by decide +kernel

def env20841 : List Nat := [2,4,8,16,32,16,40,256,512,52,2048,4096,300,16384,20757,20498,4388,2341,52,20756,16677,20757,17,20759,268,16,22805,4388,4096,2309,20516,20757,256,20756,16417,512]

theorem envBound20841 : H12AffineFastState.Bounded env20841 := by
  intro p hp
  have h : env20841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20840_20841 : H12AffineEnvironment.transform 6 40 env20840 = env20841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env20840 == env20841) = true)

theorem identity20841 : scanCanonicalize (H12AffineFastState.compose env20841 (packedSelected [3,4,5,6,7] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound20841 : packedSelected [3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env20842 : List Nat := [2,4,8,16,32,16,40,256,512,52,2048,4096,300,4112,261,2,4388,2341,52,260,4405,261,17,263,268,16,2309,4388,4096,2309,52,261,256,260,4145,512]

theorem envBound20842 : H12AffineFastState.Bounded env20842 := by
  intro p hp
  have h : env20842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20841_20842 : H12AffineEnvironment.transform 13 4112 env20841 = env20842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env20841 == env20842) = true)

theorem identity20842 : scanCanonicalize (H12AffineFastState.compose env20842 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20842 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env20843 : List Nat := [2,4,8,16,0,16,8,256,512,20,2048,4096,268,4112,261,2,4356,2309,20,260,4373,261,17,263,268,16,2309,4356,4096,2309,20,261,256,260,4113,512]

theorem envBound20843 : H12AffineFastState.Bounded env20843 := by
  intro p hp
  have h : env20843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20842_20843 : H12AffineEnvironment.transform 4 0 env20842 = env20843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20842 == env20843) = true)

theorem identity20843 : scanCanonicalize (H12AffineFastState.compose env20843 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound20843 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20844 : List Nat := [2,4,8,16,0,16,8,256,512,20,2048,2065,268,2049,261,2,2325,2309,20,260,2308,261,17,263,268,16,2309,2325,2065,2309,20,261,256,260,2048,512]

theorem envBound20844 : H12AffineFastState.Bounded env20844 := by
  intro p hp
  have h : env20844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20843_20844 : H12AffineEnvironment.transform 11 2065 env20843 = env20844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env20843 == env20844) = true)

def env20845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2101345,62540,2188736,8328,64,410093,57677,2138396,406604,2102685,2101345,256,21792,46212,2175563]

theorem envBound20845 : H12AffineFastState.Bounded env20845 := by
  intro p hp
  have h : env20845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20779_20845 : H12AffineEnvironment.transform 21 2101345 env20779 = env20845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2101345 env20779 == env20845) = true)

def env20846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21793,62540,73856,8328,64,410093,57677,58460,406604,20701,21793,256,21792,46212,96011]

theorem envBound20846 : H12AffineFastState.Bounded env20846 := by
  intro p hp
  have h : env20846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20845_20846 : H12AffineEnvironment.transform 20 17728 env20845 = env20846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env20845 == env20846) = true)

theorem identity20846 : scanCanonicalize (H12AffineFastState.compose env20846 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound20846 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,17728,21793,152,73856,8328,64,410093,5529,4232,406604,20701,21793,256,21792,16464,96011]

theorem envBound20847 : H12AffineFastState.Bounded env20847 := by
  intro p hp
  have h : env20847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20846_20847 : H12AffineEnvironment.transform 14 29908 env20846 = env20847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env20846 == env20847) = true)

theorem identity20847 : scanCanonicalize (H12AffineFastState.compose env20847 (packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 89514) := by decide +kernel

theorem selectedBound20847 : packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env20848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,89514,1024,29909,17728,21793,152,73856,8328,64,203847,5529,4232,223718,20701,21793,256,21792,16464,96011]

theorem envBound20848 : H12AffineFastState.Bounded env20848 := by
  intro p hp
  have h : env20848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20847_20848 : H12AffineEnvironment.transform 17 89514 env20847 = env20848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89514 env20847 == env20848) = true)

theorem identity20848 : scanCanonicalize (H12AffineFastState.compose env20848 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound20848 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env20849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,29962,131072,10400,1024,29909,17728,21793,152,21898,8328,64,158029,5529,4232,138476,20701,21793,256,21792,16464,513]

theorem envBound20849 : H12AffineFastState.Bounded env20849 := by
  intro p hp
  have h : env20849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20848_20849 : H12AffineEnvironment.transform 15 29962 env20848 = env20849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env20848 == env20849) = true)

theorem identity20849 : scanCanonicalize (H12AffineFastState.compose env20849 (packedSelected [0,1,2,6,7,8,10,11,14,15,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound20849 : packedSelected [0,1,2,6,7,8,10,11,14,15,18,23] rootPS < 2^1333 := by decide +kernel

def env20850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13325,217,263,131072,10400,1024,216,12621,8492,152,8583,8328,64,138560,5529,4232,138476,9424,8492,256,8493,13405,513]

theorem envBound20850 : H12AffineFastState.Bounded env20850 := by
  intro p hp
  have h : env20850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20849_20850 : H12AffineEnvironment.transform 13 13325 env20849 = env20850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env20849 == env20850) = true)

theorem identity20850 : scanCanonicalize (H12AffineFastState.compose env20850 (packedSelected [0,1,4,6,7,8,9,10,11,12,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 5561) := by decide +kernel

theorem selectedBound20850 : packedSelected [0,1,4,6,7,8,9,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env20851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13325,217,263,5561,10400,1024,216,12621,8492,152,8583,8328,64,2297,5529,4232,2389,9424,8492,256,8493,13405,513]

theorem envBound20851 : H12AffineFastState.Bounded env20851 := by
  intro p hp
  have h : env20851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20850_20851 : H12AffineEnvironment.transform 16 5561 env20850 = env20851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5561 env20850 == env20851) = true)

theorem identity20851 : scanCanonicalize (H12AffineFastState.compose env20851 (packedSelected [11,12,15,18,21] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound20851 : packedSelected [11,12,15,18,21] rootPS < 2^1333 := by decide +kernel

def env20852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,5545,217,263,5561,2308,1024,216,4329,136,152,35,300,64,2297,5529,4232,2389,1396,136,256,137,5625,513]

theorem envBound20852 : H12AffineFastState.Bounded env20852 := by
  intro p hp
  have h : env20852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20851_20852 : H12AffineEnvironment.transform 12 420 env20851 = env20852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env20851 == env20852) = true)

theorem identity20852 : scanCanonicalize (H12AffineFastState.compose env20852 (packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound20852 : packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env20853 : List Nat := [2,4,8,16,32,64,120,256,512,1024,2048,4096,348,5457,33,263,5441,2308,1024,32,4113,112,96,35,300,64,2049,5473,4208,2389,1396,112,256,113,5377,513]

theorem envBound20853 : H12AffineFastState.Bounded env20853 := by
  intro p hp
  have h : env20853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20852_20853 : H12AffineEnvironment.transform 6 120 env20852 = env20853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env20852 == env20853) = true)

def env20854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21792,62540,73857,8328,64,410093,57677,58461,406604,20700,21792,256,21792,46212,96010]

theorem envBound20854 : H12AffineFastState.Bounded env20854 := by
  intro p hp
  have h : env20854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20845_20854 : H12AffineEnvironment.transform 20 17729 env20845 = env20854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env20845 == env20854) = true)

theorem identity20854 : scanCanonicalize (H12AffineFastState.compose env20854 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound20854 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,17729,21792,16,73857,8328,64,410093,5393,4097,406604,20700,21792,256,21792,16600,96010]

theorem envBound20855 : H12AffineFastState.Bounded env20855 := by
  intro p hp
  have h : env20855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20854_20855 : H12AffineEnvironment.transform 14 29788 env20854 = env20855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env20854 == env20855) = true)

def env20856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,262144,1024,8541,4161,32,16,73857,8328,64,398573,5393,4097,406604,1500,32,256,32,5592,74250]

theorem envBound20856 : H12AffineFastState.Bounded env20856 := by
  intro p hp
  have h : env20856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20855_20856 : H12AffineEnvironment.transform 13 5376 env20855 = env20856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env20855 == env20856) = true)

theorem identity20856 : scanCanonicalize (H12AffineFastState.compose env20856 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound20856 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8203,131072,262144,1024,8541,4161,32,16,138,8328,64,398573,5393,4097,406604,1500,32,256,32,5592,513]

theorem envBound20857 : H12AffineFastState.Bounded env20857 := by
  intro p hp
  have h : env20857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20856_20857 : H12AffineEnvironment.transform 15 8203 env20856 = env20857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env20856 == env20857) = true)

theorem identity20857 : scanCanonicalize (H12AffineFastState.compose env20857 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 146913) := by decide +kernel

theorem selectedBound20857 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8203,131072,146913,1024,8541,4161,32,16,138,8328,64,10508,5393,4097,2477,1500,32,256,32,5592,513]

theorem envBound20858 : H12AffineFastState.Bounded env20858 := by
  intro p hp
  have h : env20858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20857_20858 : H12AffineEnvironment.transform 17 146913 env20857 = env20858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146913 env20857 == env20858) = true)

theorem identity20858 : scanCanonicalize (H12AffineFastState.compose env20858 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound20858 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env20859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8203,5392,10481,1024,8541,4161,32,16,138,8328,64,10508,5393,4097,2477,1500,32,256,32,5592,513]

theorem envBound20859 : H12AffineFastState.Bounded env20859 := by
  intro p hp
  have h : env20859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20858_20859 : H12AffineEnvironment.transform 16 5392 env20858 = env20859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env20858 == env20859) = true)

theorem identity20859 : scanCanonicalize (H12AffineFastState.compose env20859 (packedSelected [0,3,4,7,8,9,10,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound20859 : packedSelected [0,3,4,7,8,9,10,11,18] rootPS < 2^1333 := by decide +kernel

def env20860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,5376,373,34,5392,2264,1024,372,4161,32,16,138,161,64,2341,5393,4097,2477,1500,32,256,32,5592,513]

theorem envBound20860 : H12AffineFastState.Bounded env20860 := by
  intro p hp
  have h : env20860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20859_20860 : H12AffineEnvironment.transform 12 41 env20859 = env20860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env20859 == env20860) = true)

theorem identity20860 : scanCanonicalize (H12AffineFastState.compose env20860 (packedSelected [0,7,12,14,15,20] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound20860 : packedSelected [0,7,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env20861 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,41,5373,136,34,5357,2264,1024,137,4161,32,16,138,161,64,2264,5356,4097,2128,1057,32,253,32,5157,513]

theorem envBound20861 : H12AffineFastState.Bounded env20861 := by
  intro p hp
  have h : env20861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20860_20861 : H12AffineEnvironment.transform 7 253 env20860 = env20861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env20860 == env20861) = true)

theorem identity20861 : scanCanonicalize (H12AffineFastState.compose env20861 (packedSelected [0,4,5,7,8,9,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20861 : packedSelected [0,4,5,7,8,9,14] rootPS < 2^1333 := by decide +kernel

def env20862 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,41,5236,1,34,5220,2129,1024,0,4161,32,16,3,40,64,2129,5221,4097,2128,1057,32,116,32,5157,513]

theorem envBound20862 : H12AffineFastState.Bounded env20862 := by
  intro p hp
  have h : env20862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20861_20862 : H12AffineEnvironment.transform 6 9 env20861 = env20862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20861 == env20862) = true)

theorem identity20862 : scanCanonicalize (H12AffineFastState.compose env20862 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound20862 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env20863 : List Nat := [2,4,8,16,32,64,9,116,512,100,2048,4096,41,4112,1,34,4096,2129,100,0,4161,32,16,3,40,64,2129,4097,4097,2128,69,32,116,32,4161,513]

theorem envBound20863 : H12AffineFastState.Bounded env20863 := by
  intro p hp
  have h : env20863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20862_20863 : H12AffineEnvironment.transform 9 100 env20862 = env20863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env20862 == env20863) = true)

theorem identity20863 : scanCanonicalize (H12AffineFastState.compose env20863 (packedSelected [1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 2656) := by decide +kernel

theorem selectedBound20863 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env20864 : List Nat := [2,4,8,16,32,64,9,116,512,100,2048,2656,41,2672,1,34,2656,2129,100,0,2593,32,16,3,40,64,2129,2657,2657,2128,69,32,116,32,2593,513]

theorem envBound20864 : H12AffineFastState.Bounded env20864 := by
  intro p hp
  have h : env20864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20863_20864 : H12AffineEnvironment.transform 11 2656 env20863 = env20864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2656 env20863 == env20864) = true)

theorem identity20864 : scanCanonicalize (H12AffineFastState.compose env20864 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound20864 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env20865 : List Nat := [2,4,8,16,32,64,9,116,33,100,2048,2113,41,2129,1,34,2113,2129,100,0,2048,32,16,3,40,64,2129,2112,2112,2128,69,32,116,32,2048,32]

theorem envBound20865 : H12AffineFastState.Bounded env20865 := by
  intro p hp
  have h : env20865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20864_20865 : H12AffineEnvironment.transform 8 33 env20864 = env20865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env20864 == env20865) = true)

def env20866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,4160,33,16,73857,8328,64,398572,5393,4097,406604,1501,33,256,33,5593,74251]

theorem envBound20866 : H12AffineFastState.Bounded env20866 := by
  intro p hp
  have h : env20866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20855_20866 : H12AffineEnvironment.transform 13 5377 env20855 = env20866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env20855 == env20866) = true)

theorem identity20866 : scanCanonicalize (H12AffineFastState.compose env20866 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound20866 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,8322,131072,262144,1024,8540,4160,33,16,3,8328,64,398572,5393,4097,406604,1501,33,256,33,5593,649]

theorem envBound20867 : H12AffineFastState.Bounded env20867 := by
  intro p hp
  have h : env20867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20866_20867 : H12AffineEnvironment.transform 15 8322 env20866 = env20867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env20866 == env20867) = true)

theorem identity20867 : scanCanonicalize (H12AffineFastState.compose env20867 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20867 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env20868 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8202,131072,262144,1024,8540,4160,33,16,3,8192,64,398436,5393,4097,406604,1365,33,256,33,5457,513]

theorem envBound20868 : H12AffineFastState.Bounded env20868 := by
  intro p hp
  have h : env20868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20867_20868 : H12AffineEnvironment.transform 6 8 env20867 = env20868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20867 == env20868) = true)

theorem identity20868 : scanCanonicalize (H12AffineFastState.compose env20868 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound20868 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20869 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8202,131072,2421,1024,8540,4160,33,16,3,8192,64,138513,5393,4097,146745,1365,33,256,33,5457,513]

theorem envBound20869 : H12AffineFastState.Bounded env20869 := by
  intro p hp
  have h : env20869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20868_20869 : H12AffineEnvironment.transform 17 2421 env20868 = env20869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env20868 == env20869) = true)

def env20870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,62541,2188736,8328,64,6705549,57677,2138397,406605,2102684,4194304,256,21793,46213,2175562]

theorem envBound20870 : H12AffineFastState.Bounded env20870 := by
  intro p hp
  have h : env20870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20778_20870 : H12AffineEnvironment.transform 22 62541 env20778 = env20870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 62541 env20778 == env20870) = true)

def env20871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2101344,62541,2188736,8328,64,410093,57677,2138397,406605,2102684,2101344,256,21793,46213,2175562]

theorem envBound20871 : H12AffineFastState.Bounded env20871 := by
  intro p hp
  have h : env20871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20870_20871 : H12AffineEnvironment.transform 21 2101344 env20870 = env20871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2101344 env20870 == env20871) = true)

def env20872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21792,62541,73856,8328,64,410093,57677,58461,406605,20700,21792,256,21793,46213,96010]

theorem envBound20872 : H12AffineFastState.Bounded env20872 := by
  intro p hp
  have h : env20872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20871_20872 : H12AffineEnvironment.transform 20 17728 env20871 = env20872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env20871 == env20872) = true)

theorem identity20872 : scanCanonicalize (H12AffineFastState.compose env20872 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound20872 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,131072,262144,1024,32769,17728,21792,62541,41310,8328,64,410093,57677,58461,406605,20700,21792,256,21793,46213,63188]

theorem envBound20873 : H12AffineFastState.Bounded env20873 := by
  intro p hp
  have h : env20873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20872_20873 : H12AffineEnvironment.transform 15 33246 env20872 = env20873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env20872 == env20873) = true)

theorem identity20873 : scanCanonicalize (H12AffineFastState.compose env20873 (packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound20873 : packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env20874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,131072,56437,1024,32769,17728,21792,62541,41310,8328,64,171416,57677,58461,190520,20700,21792,256,21793,46213,63188]

theorem envBound20874 : H12AffineFastState.Bounded env20874 := by
  intro p hp
  have h : env20874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20873_20874 : H12AffineEnvironment.transform 17 56437 env20873 = env20874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env20873 == env20874) = true)

theorem identity20874 : scanCanonicalize (H12AffineFastState.compose env20874 (packedSelected [0,2,4,12,15,20,22,27] rootPS)) = affineNative (2^(13+1) ^^^ 13356) := by decide +kernel

theorem selectedBound20874 : packedSelected [0,2,4,12,15,20,22,27] rootPS < 2^1333 := by decide +kernel

def env20875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13356,32768,33246,131072,43097,1024,32769,12652,8460,32865,41310,8328,64,171416,38241,36977,171028,9456,8460,256,8461,46213,33528]

theorem envBound20875 : H12AffineFastState.Bounded env20875 := by
  intro p hp
  have h : env20875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20874_20875 : H12AffineEnvironment.transform 13 13356 env20874 = env20875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13356 env20874 == env20875) = true)

theorem identity20875 : scanCanonicalize (H12AffineFastState.compose env20875 (packedSelected [0,2,7,9,12,14,15,16,22,35] rootPS)) = affineNative (2^(14+1) ^^^ 249) := by decide +kernel

theorem selectedBound20875 : packedSelected [0,2,7,9,12,14,15,16,22,35] rootPS < 2^1333 := by decide +kernel

def env20876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13356,249,295,131072,10400,1024,248,12652,8460,152,8615,8328,64,138593,5528,4232,138477,9456,8460,256,8461,13436,513]

theorem envBound20876 : H12AffineFastState.Bounded env20876 := by
  intro p hp
  have h : env20876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20875_20876 : H12AffineEnvironment.transform 14 249 env20875 = env20876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 249 env20875 == env20876) = true)

theorem identity20876 : scanCanonicalize (H12AffineFastState.compose env20876 (packedSelected [0,1,2,6,7,8,10,11,14,15,18,23] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20876 : packedSelected [0,1,2,6,7,8,10,11,14,15,18,23] rootPS < 2^1333 := by decide +kernel

def env20877 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,13324,217,263,131072,10368,1024,216,12620,8460,152,8583,8328,64,138561,5528,4232,138445,9424,8460,256,8461,13404,513]

theorem envBound20877 : H12AffineFastState.Bounded env20877 := by
  intro p hp
  have h : env20877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20876_20877 : H12AffineEnvironment.transform 4 0 env20876 = env20877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20876 == env20877) = true)

theorem identity20877 : scanCanonicalize (H12AffineFastState.compose env20877 (packedSelected [0,1,4,6,7,8,9,10,11,12,14,16] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20877 : packedSelected [0,1,4,6,7,8,9,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env20878 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,4096,8192,13324,81,263,131072,10248,1024,80,12620,8460,16,8463,8192,64,138561,5392,4096,138309,9304,8460,256,8461,13404,513]

theorem envBound20878 : H12AffineFastState.Bounded env20878 := by
  intro p hp
  have h : env20878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20877_20878 : H12AffineEnvironment.transform 6 8 env20877 = env20878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20877 == env20878) = true)

theorem identity20878 : scanCanonicalize (H12AffineFastState.compose env20878 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound20878 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env20879 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,4096,348,5456,81,263,131072,2388,1024,80,4112,80,16,83,348,64,138561,5392,4096,138309,1284,80,256,81,5376,513]

theorem envBound20879 : H12AffineFastState.Bounded env20879 := by
  intro p hp
  have h : env20879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20878_20879 : H12AffineEnvironment.transform 12 348 env20878 = env20879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env20878 == env20879) = true)

theorem identity20879 : scanCanonicalize (H12AffineFastState.compose env20879 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20879 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env20880 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,4096,268,5376,1,263,131072,2308,1024,0,4112,0,16,3,268,16,138513,5392,4096,138261,1284,0,256,1,5376,513]

theorem envBound20880 : H12AffineFastState.Bounded env20880 := by
  intro p hp
  have h : env20880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20879_20880 : H12AffineEnvironment.transform 5 16 env20879 = env20880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20879 == env20880) = true)

theorem identity20880 : scanCanonicalize (H12AffineFastState.compose env20880 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 789) := by decide +kernel

theorem selectedBound20880 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env20881 : List Nat := [2,4,8,16,0,16,8,256,512,1024,789,4096,268,5376,1,263,131072,529,1024,0,4112,0,16,3,268,16,136708,5392,4096,136960,1284,0,256,1,5376,513]

theorem envBound20881 : H12AffineFastState.Bounded env20881 := by
  intro p hp
  have h : env20881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20880_20881 : H12AffineEnvironment.transform 10 789 env20880 = env20881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 789 env20880 == env20881) = true)

theorem identity20881 : scanCanonicalize (H12AffineFastState.compose env20881 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound20881 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20882 : List Nat := [2,4,8,16,0,16,8,256,512,1024,789,4096,268,5376,1,263,5393,529,1024,0,4112,0,16,3,268,16,789,5392,4096,529,1284,0,256,1,5376,513]

theorem envBound20882 : H12AffineFastState.Bounded env20882 := by
  intro p hp
  have h : env20882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20881_20882 : H12AffineEnvironment.transform 16 5393 env20881 = env20882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env20881 == env20882) = true)

theorem identity20882 : scanCanonicalize (H12AffineFastState.compose env20882 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 260) := by decide +kernel

theorem selectedBound20882 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20883 : List Nat := [2,4,8,16,0,16,8,256,512,1024,789,260,268,1028,1,263,1045,529,1024,0,276,0,16,3,268,16,789,1044,260,529,1284,0,256,1,1028,513]

theorem envBound20883 : H12AffineFastState.Bounded env20883 := by
  intro p hp
  have h : env20883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20882_20883 : H12AffineEnvironment.transform 11 260 env20882 = env20883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 260 env20882 == env20883) = true)

theorem identity20883 : scanCanonicalize (H12AffineFastState.compose env20883 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 286) := by decide +kernel

theorem selectedBound20883 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20884 : List Nat := [2,4,8,16,0,16,8,256,286,1024,11,260,268,1028,1,263,1045,271,1024,0,276,0,16,3,268,16,11,1044,260,271,1284,0,256,1,1028,287]

theorem envBound20884 : H12AffineFastState.Bounded env20884 := by
  intro p hp
  have h : env20884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20883_20884 : H12AffineEnvironment.transform 8 286 env20883 = env20884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 286 env20883 == env20884) = true)

theorem identity20884 : scanCanonicalize (H12AffineFastState.compose env20884 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 283) := by decide +kernel

theorem selectedBound20884 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20885 : List Nat := [2,4,8,16,0,16,8,256,286,283,11,260,268,287,1,263,270,271,283,0,276,0,16,3,268,16,11,271,260,271,31,0,256,1,287,287]

theorem envBound20885 : H12AffineFastState.Bounded env20885 := by
  intro p hp
  have h : env20885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20884_20885 : H12AffineEnvironment.transform 9 283 env20884 = env20885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 283 env20884 == env20885) = true)

theorem identity20885 : scanCanonicalize (H12AffineFastState.compose env20885 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound20885 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env20886 : List Nat := [2,4,2,16,0,16,2,256,276,273,1,260,262,277,1,263,260,261,273,0,276,0,16,3,262,16,1,261,260,261,21,0,256,1,277,277]

theorem envBound20886 : H12AffineFastState.Bounded env20886 := by
  intro p hp
  have h : env20886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20885_20886 : H12AffineEnvironment.transform 2 2 env20885 = env20886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env20885 == env20886) = true)

theorem identity20886 : scanCanonicalize (H12AffineFastState.compose env20886 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound20886 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env20887 : List Nat := [2,4,2,6,0,6,2,256,258,263,1,260,262,259,1,263,260,261,263,0,258,0,6,3,262,6,1,261,260,261,3,0,256,1,259,259]

theorem envBound20887 : H12AffineFastState.Bounded env20887 := by
  intro p hp
  have h : env20887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20886_20887 : H12AffineEnvironment.transform 3 6 env20886 = env20887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env20886 == env20887) = true)

def env20888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21793,62541,73857,8328,64,410093,57677,58460,406605,20701,21793,256,21793,46213,96011]

theorem envBound20888 : H12AffineFastState.Bounded env20888 := by
  intro p hp
  have h : env20888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20871_20888 : H12AffineEnvironment.transform 20 17729 env20871 = env20888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env20871 == env20888) = true)

theorem identity20888 : scanCanonicalize (H12AffineFastState.compose env20888 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound20888 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33111,131072,262144,1024,32769,17729,21793,62541,41430,8328,64,410093,57677,58460,406605,20701,21793,256,21793,46213,63068]

theorem envBound20889 : H12AffineFastState.Bounded env20889 := by
  intro p hp
  have h : env20889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20888_20889 : H12AffineEnvironment.transform 15 33111 env20888 = env20889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env20888 == env20889) = true)

def env20890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33111,131072,10400,1024,32769,17729,21793,62541,41430,8328,64,158029,57677,58460,138477,20701,21793,256,21793,46213,63068]

theorem envBound20890 : H12AffineFastState.Bounded env20890 := by
  intro p hp
  have h : env20890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20889_20890 : H12AffineEnvironment.transform 17 10400 env20889 = env20890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env20889 == env20890) = true)

theorem identity20890 : scanCanonicalize (H12AffineFastState.compose env20890 (packedSelected [1,3,4,6,9,11,16,18,21,24,28] rootPS)) = affineNative (2^(7+1) ^^^ 220) := by decide +kernel

theorem selectedBound20890 : packedSelected [1,3,4,6,9,11,16,18,21,24,28] rootPS < 2^1333 := by decide +kernel

def env20891 : List Nat := [2,4,8,16,32,64,128,220,512,1024,2048,4096,8192,16384,32768,32907,131072,10400,1024,32769,17565,21757,62541,40970,8328,64,157841,57489,58460,138477,20701,21757,220,21757,46213,63068]

theorem envBound20891 : H12AffineFastState.Bounded env20891 := by
  intro p hp
  have h : env20891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20890_20891 : H12AffineEnvironment.transform 7 220 env20890 = env20891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 220 env20890 == env20891) = true)

theorem identity20891 : scanCanonicalize (H12AffineFastState.compose env20891 (packedSelected [0,3,6,7,9,19,20,21,22,23,24,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound20891 : packedSelected [0,3,6,7,9,19,20,21,22,23,24,31,32] rootPS < 2^1333 := by decide +kernel

def env20892 : List Nat := [2,4,8,16,32,64,128,220,512,1024,2048,4096,8192,16384,29909,29790,131072,10400,1024,29908,17565,21757,152,21727,8328,64,157841,5188,4233,138477,20701,21757,220,21757,16464,649]

theorem envBound20892 : H12AffineFastState.Bounded env20892 := by
  intro p hp
  have h : env20892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20891_20892 : H12AffineEnvironment.transform 14 29909 env20891 = env20892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env20891 == env20892) = true)

def env20893 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33111,131072,10401,1024,32769,17729,21793,62541,41430,8328,64,158028,57677,58460,138476,20701,21793,256,21793,46213,63068]

theorem envBound20893 : H12AffineFastState.Bounded env20893 := by
  intro p hp
  have h : env20893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20889_20893 : H12AffineEnvironment.transform 17 10401 env20889 = env20893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env20889 == env20893) = true)

theorem identity20893 : scanCanonicalize (H12AffineFastState.compose env20893 (packedSelected [1,3,4,6,9,11,16,18,21,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound20893 : packedSelected [1,3,4,6,9,11,16,18,21,24,28] rootPS < 2^1333 := by decide +kernel

def env20894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5157,32768,33111,131072,10401,1024,32769,4452,260,41064,41430,8328,64,146793,46440,45177,138476,1272,260,256,260,46213,41593]

theorem envBound20894 : H12AffineFastState.Bounded env20894 := by
  intro p hp
  have h : env20894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20893_20894 : H12AffineEnvironment.transform 13 5157 env20893 = env20894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env20893 == env20894) = true)

theorem identity20894 : scanCanonicalize (H12AffineFastState.compose env20894 (packedSelected [0,3,6,7,9,19,20,21,22,23,24,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound20894 : packedSelected [0,3,6,7,9,19,20,21,22,23,24,31,32] rootPS < 2^1333 := by decide +kernel

def env20895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5157,8540,8203,131072,10401,1024,8541,4452,260,308,138,8328,64,146793,5172,4389,138476,1272,260,256,260,5593,805]

theorem envBound20895 : H12AffineFastState.Bounded env20895 := by
  intro p hp
  have h : env20895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20894_20895 : H12AffineEnvironment.transform 14 8540 env20894 = env20895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env20894 == env20895) = true)

theorem identity20895 : scanCanonicalize (H12AffineFastState.compose env20895 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound20895 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env20896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5157,8540,8203,5221,10401,1024,8541,4452,260,308,138,8328,64,10508,5172,4389,2185,1272,260,256,260,5593,805]

theorem envBound20896 : H12AffineFastState.Bounded env20896 := by
  intro p hp
  have h : env20896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20895_20896 : H12AffineEnvironment.transform 16 5221 env20895 = env20896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env20895 == env20896) = true)

theorem identity20896 : scanCanonicalize (H12AffineFastState.compose env20896 (packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound20896 : packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS < 2^1333 := by decide +kernel

def env20897 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,5157,372,35,5221,2185,1024,373,4452,260,308,138,160,64,2340,5172,4389,2185,1272,260,256,260,5593,805]

theorem envBound20897 : H12AffineFastState.Bounded env20897 := by
  intro p hp
  have h : env20897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20896_20897 : H12AffineEnvironment.transform 12 40 env20896 = env20897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env20896 == env20897) = true)

theorem identity20897 : scanCanonicalize (H12AffineFastState.compose env20897 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound20897 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env20898 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,40,5157,217,35,5221,2185,1024,216,4297,169,153,138,160,64,2185,5172,4232,2185,1272,169,173,169,5236,648]

theorem envBound20898 : H12AffineFastState.Bounded env20898 := by
  intro p hp
  have h : env20898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20897_20898 : H12AffineEnvironment.transform 7 173 env20897 = env20898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env20897 == env20898) = true)

theorem identity20898 : scanCanonicalize (H12AffineFastState.compose env20898 (packedSelected [0,2,3,4,5,7,9,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound20898 : packedSelected [0,2,3,4,5,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env20899 : List Nat := [2,4,8,16,32,64,128,173,512,1024,81,4096,40,5157,217,35,5221,216,1024,216,4297,169,153,138,160,64,216,5172,4232,216,1272,169,173,169,5236,648]

theorem envBound20899 : H12AffineFastState.Bounded env20899 := by
  intro p hp
  have h : env20899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20898_20899 : H12AffineEnvironment.transform 10 81 env20898 = env20899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env20898 == env20899) = true)

theorem identity20899 : scanCanonicalize (H12AffineFastState.compose env20899 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 1197) := by decide +kernel

theorem selectedBound20899 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env20900 : List Nat := [2,4,8,16,32,64,128,173,512,1024,81,1197,40,136,217,35,200,216,1024,216,1124,169,153,138,160,64,216,153,1061,216,1272,169,173,169,217,648]

theorem envBound20900 : H12AffineFastState.Bounded env20900 := by
  intro p hp
  have h : env20900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20899_20900 : H12AffineEnvironment.transform 11 1197 env20899 = env20900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1197 env20899 == env20900) = true)

theorem identity20900 : scanCanonicalize (H12AffineFastState.compose env20900 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound20900 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env20901 : List Nat := [2,4,8,16,32,64,89,116,512,1024,81,1140,40,81,0,35,17,1,1024,1,1124,112,64,83,121,64,1,64,1061,1,1057,112,116,112,0,593]

theorem envBound20901 : H12AffineFastState.Bounded env20901 := by
  intro p hp
  have h : env20901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20900_20901 : H12AffineEnvironment.transform 6 89 env20900 = env20901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env20900 == env20901) = true)

theorem identity20901 : scanCanonicalize (H12AffineFastState.compose env20901 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20901 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env20902 : List Nat := [2,4,8,16,32,17,8,37,512,1024,0,1061,40,0,0,35,17,1,1024,1,1077,33,17,2,40,17,1,17,1061,1,1057,33,37,33,0,512]

theorem envBound20902 : H12AffineFastState.Bounded env20902 := by
  intro p hp
  have h : env20902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20901_20902 : H12AffineEnvironment.transform 5 17 env20901 = env20902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20901 == env20902) = true)

theorem identity20902 : scanCanonicalize (H12AffineFastState.compose env20902 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound20902 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20903 : List Nat := [2,4,8,0,32,1,8,37,512,1024,0,1061,40,0,0,35,1,1,1024,1,1061,33,1,2,40,1,1,1,1061,1,1057,33,37,33,0,512]

theorem envBound20903 : H12AffineFastState.Bounded env20903 := by
  intro p hp
  have h : env20903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20902_20903 : H12AffineEnvironment.transform 3 0 env20902 = env20903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env20902 == env20903) = true)

theorem identity20903 : scanCanonicalize (H12AffineFastState.compose env20903 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound20903 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20904 : List Nat := [2,4,8,0,32,1,8,37,512,516,0,545,40,0,0,35,1,1,516,1,545,33,1,2,40,1,1,1,545,1,549,33,37,33,0,512]

theorem envBound20904 : H12AffineFastState.Bounded env20904 := by
  intro p hp
  have h : env20904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20903_20904 : H12AffineEnvironment.transform 9 516 env20903 = env20904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env20903 == env20904) = true)

theorem identity20904 : scanCanonicalize (H12AffineFastState.compose env20904 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20904 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env20905 : List Nat := [2,4,8,0,0,1,8,5,512,516,0,513,8,0,0,3,1,1,516,1,513,1,1,2,8,1,1,1,513,1,517,1,5,1,0,512]

theorem envBound20905 : H12AffineFastState.Bounded env20905 := by
  intro p hp
  have h : env20905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20904_20905 : H12AffineEnvironment.transform 4 0 env20904 = env20905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20904 == env20905) = true)

def env20906 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2101345,62541,2188736,8328,64,410092,57677,2138397,406605,2102684,2101345,256,21793,46213,2175562]

theorem envBound20906 : H12AffineFastState.Bounded env20906 := by
  intro p hp
  have h : env20906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20870_20906 : H12AffineEnvironment.transform 21 2101345 env20870 = env20906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2101345 env20870 == env20906) = true)

def env20907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21793,62541,73856,8328,64,410092,57677,58461,406605,20700,21793,256,21793,46213,96010]

theorem envBound20907 : H12AffineFastState.Bounded env20907 := by
  intro p hp
  have h : env20907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20906_20907 : H12AffineEnvironment.transform 20 17728 env20906 = env20907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env20906 == env20907) = true)

theorem identity20907 : scanCanonicalize (H12AffineFastState.compose env20907 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound20907 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,30083,131072,262144,1024,32769,17728,21793,62541,21763,8328,64,410092,57677,58461,406605,20700,21793,256,21793,46213,649]

theorem envBound20908 : H12AffineFastState.Bounded env20908 := by
  intro p hp
  have h : env20908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20907_20908 : H12AffineEnvironment.transform 15 30083 env20907 = env20908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env20907 == env20908) = true)

theorem identity20908 : scanCanonicalize (H12AffineFastState.compose env20908 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20908 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env20909 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,262144,1024,32769,17728,21793,62541,21763,8192,64,409956,57677,58461,406605,20564,21793,256,21793,46093,513]

theorem envBound20909 : H12AffineFastState.Bounded env20909 := by
  intro p hp
  have h : env20909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20908_20909 : H12AffineEnvironment.transform 6 8 env20908 = env20909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20908 == env20909) = true)

theorem identity20909 : scanCanonicalize (H12AffineFastState.compose env20909 (packedSelected [0,4,7,9,11,14,15,16,20,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 146745) := by decide +kernel

theorem selectedBound20909 : packedSelected [0,4,7,9,11,14,15,16,20,32,38] rootPS < 2^1333 := by decide +kernel

def env20910 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,146745,1024,32769,17728,21793,62541,21763,8192,64,31837,57677,58461,2420,20564,21793,256,21793,46093,513]

theorem envBound20910 : H12AffineFastState.Bounded env20910 := by
  intro p hp
  have h : env20910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20909_20910 : H12AffineEnvironment.transform 17 146745 env20909 = env20910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146745 env20909 == env20910) = true)

theorem identity20910 : scanCanonicalize (H12AffineFastState.compose env20910 (packedSelected [4,9,14,16,21] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound20910 : packedSelected [4,9,14,16,21] rootPS < 2^1333 := by decide +kernel

def env20911 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,29963,131072,146745,1024,29788,17728,21793,16,21763,8192,64,31837,5392,4096,2420,20564,21793,256,21793,16464,513]

theorem envBound20911 : H12AffineFastState.Bounded env20911 := by
  intro p hp
  have h : env20911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20910_20911 : H12AffineEnvironment.transform 14 29789 env20910 = env20911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env20910 == env20911) = true)

def env20912 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21792,62541,73857,8328,64,410092,57677,58460,406605,20701,21792,256,21793,46213,96011]

theorem envBound20912 : H12AffineFastState.Bounded env20912 := by
  intro p hp
  have h : env20912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20906_20912 : H12AffineEnvironment.transform 20 17729 env20906 = env20912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env20906 == env20912) = true)

theorem identity20912 : scanCanonicalize (H12AffineFastState.compose env20912 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound20912 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20913 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,29962,131072,262144,1024,32769,17729,21792,62541,21899,8328,64,410092,57677,58460,406605,20701,21792,256,21793,46213,513]

theorem envBound20913 : H12AffineFastState.Bounded env20913 := by
  intro p hp
  have h : env20913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20912_20913 : H12AffineEnvironment.transform 15 29962 env20912 = env20913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env20912 == env20913) = true)

theorem identity20913 : scanCanonicalize (H12AffineFastState.compose env20913 (packedSelected [11,12,15,18,23,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound20913 : packedSelected [11,12,15,18,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env20914 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,29962,131072,10400,1024,32769,17729,21792,62541,21899,8328,64,158028,57677,58460,138477,20701,21792,256,21793,46213,513]

theorem envBound20914 : H12AffineFastState.Bounded env20914 := by
  intro p hp
  have h : env20914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20913_20914 : H12AffineEnvironment.transform 17 10400 env20913 = env20914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env20913 == env20914) = true)

theorem identity20914 : scanCanonicalize (H12AffineFastState.compose env20914 (packedSelected [1,2,6,8,9,10,11,15,18,20,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound20914 : packedSelected [1,2,6,8,9,10,11,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env20915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8461,29962,131072,10400,1024,8460,17729,21792,21824,21899,8328,64,158028,16448,17745,138477,20701,21792,256,21793,5512,513]

theorem envBound20915 : H12AffineFastState.Bounded env20915 := by
  intro p hp
  have h : env20915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20914_20915 : H12AffineEnvironment.transform 14 8461 env20914 = env20915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env20914 == env20915) = true)

theorem identity20915 : scanCanonicalize (H12AffineFastState.compose env20915 (packedSelected [0,4,6,7,11,14,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound20915 : packedSelected [0,4,6,7,11,14,18,22] rootPS < 2^1333 := by decide +kernel

def env20916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,16384,1,21510,131072,2476,1024,0,17729,21792,21824,21899,388,64,149568,16448,17745,138477,20701,21792,256,21793,5512,513]

theorem envBound20916 : H12AffineFastState.Bounded env20916 := by
  intro p hp
  have h : env20916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20915_20916 : H12AffineEnvironment.transform 12 268 env20915 = env20916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env20915 == env20916) = true)

theorem identity20916 : scanCanonicalize (H12AffineFastState.compose env20916 (packedSelected [0,1,4,7,8,9,10,12,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5592) := by decide +kernel

theorem selectedBound20916 : packedSelected [0,1,4,7,8,9,10,12,16,18] rootPS < 2^1333 := by decide +kernel

def env20917 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5592,1,478,131072,2476,1024,0,4249,248,152,83,388,64,138648,5528,4233,138477,1285,248,256,249,5512,513]

theorem envBound20917 : H12AffineFastState.Bounded env20917 := by
  intro p hp
  have h : env20917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20916_20917 : H12AffineEnvironment.transform 13 5592 env20916 = env20917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5592 env20916 == env20917) = true)

theorem identity20917 : scanCanonicalize (H12AffineFastState.compose env20917 (packedSelected [6,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound20917 : packedSelected [6,12,14,15] rootPS < 2^1333 := by decide +kernel

def env20918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5592,1,478,5392,2476,1024,0,4249,248,152,83,388,64,2184,5528,4233,2557,1285,248,256,249,5512,513]

theorem envBound20918 : H12AffineFastState.Bounded env20918 := by
  intro p hp
  have h : env20918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20917_20918 : H12AffineEnvironment.transform 16 5392 env20917 = env20918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env20917 == env20918) = true)

theorem identity20918 : scanCanonicalize (H12AffineFastState.compose env20918 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20918 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20919 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5457,1,343,5392,2341,1024,0,4112,113,17,83,269,64,2049,5393,4096,2420,1285,113,256,112,5377,513]

theorem envBound20919 : H12AffineFastState.Bounded env20919 := by
  intro p hp
  have h : env20919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20918_20919 : H12AffineEnvironment.transform 6 9 env20918 = env20919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20918 == env20919) = true)

theorem identity20919 : scanCanonicalize (H12AffineFastState.compose env20919 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound20919 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env20920 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,4096,268,4113,1,343,4176,2341,320,0,4112,113,17,83,269,64,2049,4177,4096,2420,69,113,256,112,4161,513]

theorem envBound20920 : H12AffineFastState.Bounded env20920 := by
  intro p hp
  have h : env20920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20919_20920 : H12AffineEnvironment.transform 9 320 env20919 = env20920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env20919 == env20920) = true)

theorem identity20920 : scanCanonicalize (H12AffineFastState.compose env20920 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2324) := by decide +kernel

theorem selectedBound20920 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env20921 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,2324,268,2309,1,343,2372,2341,320,0,2308,113,17,83,269,64,2049,2373,2324,2420,69,113,256,112,2389,513]

theorem envBound20921 : H12AffineFastState.Bounded env20921 := by
  intro p hp
  have h : env20921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20920_20921 : H12AffineEnvironment.transform 11 2324 env20920 = env20921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2324 env20920 == env20921) = true)

theorem identity20921 : scanCanonicalize (H12AffineFastState.compose env20921 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound20921 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env20922 : List Nat := [2,4,8,16,32,64,9,117,512,53,2048,2145,121,2160,1,34,2097,2128,53,0,2161,113,17,83,120,64,2049,2096,2145,2049,69,113,117,112,2080,513]

theorem envBound20922 : H12AffineFastState.Bounded env20922 := by
  intro p hp
  have h : env20922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20921_20922 : H12AffineEnvironment.transform 7 117 env20921 = env20922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env20921 == env20922) = true)

theorem identity20922 : scanCanonicalize (H12AffineFastState.compose env20922 (packedSelected [1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 607) := by decide +kernel

theorem selectedBound20922 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env20923 : List Nat := [2,4,8,16,32,64,9,117,512,53,607,574,121,559,1,34,622,527,53,0,558,113,17,83,120,64,606,623,574,606,69,113,117,112,639,513]

theorem envBound20923 : H12AffineFastState.Bounded env20923 := by
  intro p hp
  have h : env20923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20922_20923 : H12AffineEnvironment.transform 10 607 env20922 = env20923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 607 env20922 == env20923) = true)

theorem identity20923 : scanCanonicalize (H12AffineFastState.compose env20923 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20923 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env20924 : List Nat := [2,4,8,16,32,16,9,37,512,53,527,574,41,559,1,34,574,527,53,0,558,33,17,3,40,16,526,575,574,526,21,33,37,32,559,513]

theorem envBound20924 : H12AffineFastState.Bounded env20924 := by
  intro p hp
  have h : env20924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20923_20924 : H12AffineEnvironment.transform 5 16 env20923 = env20924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20923 == env20924) = true)

theorem identity20924 : scanCanonicalize (H12AffineFastState.compose env20924 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound20924 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20925 : List Nat := [2,1,8,16,32,16,9,32,512,48,522,571,41,554,1,34,571,522,48,0,555,33,17,3,40,16,523,570,571,523,16,33,32,32,554,513]

theorem envBound20925 : H12AffineFastState.Bounded env20925 := by
  intro p hp
  have h : env20925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20924_20925 : H12AffineEnvironment.transform 1 1 env20924 = env20925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env20924 == env20925) = true)

theorem identity20925 : scanCanonicalize (H12AffineFastState.compose env20925 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 50) := by decide +kernel

theorem selectedBound20925 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20926 : List Nat := [2,1,8,16,32,16,9,32,50,48,56,9,41,24,1,34,9,56,48,0,25,33,17,3,40,16,57,8,9,57,16,33,32,32,24,51]

theorem envBound20926 : H12AffineFastState.Bounded env20926 := by
  intro p hp
  have h : env20926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20925_20926 : H12AffineEnvironment.transform 8 50 env20925 = env20926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 50 env20925 == env20926) = true)

def env20927 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830977,25265169,23160256,257,27378861,27337992,25207750]

theorem envBound20927 : H12AffineFastState.Bounded env20927 := by
  intro p hp
  have h : env20927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20776_20927 : H12AffineEnvironment.transform 18 1025 env20776 = env20927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env20776 == env20927) = true)

theorem identity20927 : scanCanonicalize (H12AffineFastState.compose env20927 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2262337) := by decide +kernel

theorem selectedBound20927 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env20928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2262337,16777216,8328,64,23414080,18973836,184337,2377024,19071312,23160256,257,16990700,17014857,19015303]

theorem envBound20928 : H12AffineFastState.Bounded env20928 := by
  intro p hp
  have h : env20928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20927_20928 : H12AffineEnvironment.transform 22 2262337 env20927 = env20928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2262337 env20927 == env20928) = true)

def env20929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2262337,201932,8328,64,6705548,2265152,184337,2377024,2102684,6451468,257,21792,46213,2175563]

theorem envBound20929 : H12AffineFastState.Bounded env20929 := by
  intro p hp
  have h : env20929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20928_20929 : H12AffineEnvironment.transform 23 201932 env20928 = env20929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 201932 env20928 == env20929) = true)

def env20930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6603932,2098512,17665,2377024,2102684,6349852,257,21792,46213,2175563]

theorem envBound20930 : H12AffineFastState.Bounded env20930 := by
  intro p hp
  have h : env20930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20929_20930 : H12AffineEnvironment.transform 16 38160 env20929 = env20930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env20929 == env20930) = true)

def env20931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2157596,2098512,17665,2377024,2102684,2411676,257,21792,46213,2175563]

theorem envBound20931 : H12AffineFastState.Bounded env20931 := by
  intro p hp
  have h : env20931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20930_20931 : H12AffineEnvironment.transform 21 272512 env20930 = env20931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env20930 == env20931) = true)

theorem identity20931 : scanCanonicalize (H12AffineFastState.compose env20931 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound20931 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20932 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,25028,262144,1025,29909,2097152,272512,2101329,95496,8328,64,2103496,2098512,17665,2377024,2102684,2373704,257,21792,16465,2175563]

theorem envBound20932 : H12AffineFastState.Bounded env20932 := by
  intro p hp
  have h : env20932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20931_20932 : H12AffineEnvironment.transform 14 29908 env20931 = env20932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env20931 == env20932) = true)

def env20933 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,24980,262144,1025,29829,2097152,272512,2101249,95496,8328,16,2103448,2098432,17665,2376976,2102684,2373656,257,21792,16385,2175515]

theorem envBound20933 : H12AffineFastState.Bounded env20933 := by
  intro p hp
  have h : env20933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20932_20933 : H12AffineEnvironment.transform 5 16 env20932 = env20933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20932 == env20933) = true)

theorem identity20933 : scanCanonicalize (H12AffineFastState.compose env20933 (packedSelected [3,4,5,7,8,9,10,11,17,19,26,27,28,31,32] rootPS)) = affineNative (2^(20+1) ^^^ 17681) := by decide +kernel

theorem selectedBound20933 : packedSelected [3,4,5,7,8,9,10,11,17,19,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env20934 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,24980,262144,1025,29829,17681,272512,21776,95496,8328,16,23945,16401,17665,262145,20621,294153,257,21792,16385,96010]

theorem envBound20934 : H12AffineFastState.Bounded env20934 := by
  intro p hp
  have h : env20934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20933_20934 : H12AffineEnvironment.transform 20 17681 env20933 = env20934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17681 env20933 == env20934) = true)

theorem identity20934 : scanCanonicalize (H12AffineFastState.compose env20934 (packedSelected [0,9,10,14,16,19,20,22,26,27,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound20934 : packedSelected [0,9,10,14,16,19,20,22,26,27,31,35] rootPS < 2^1333 := by decide +kernel

def env20935 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,24980,10280,1025,29829,17681,168,21776,95496,8328,16,23945,16401,17665,10281,20621,21793,257,21792,16385,96010]

theorem envBound20935 : H12AffineFastState.Bounded env20935 := by
  intro p hp
  have h : env20935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20934_20935 : H12AffineEnvironment.transform 17 10280 env20934 = env20935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env20934 == env20935) = true)

theorem identity20935 : scanCanonicalize (H12AffineFastState.compose env20935 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 30082) := by decide +kernel

theorem selectedBound20935 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20936 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,30082,24980,10280,1025,29829,17681,168,21776,138,8328,16,23945,16401,17665,10281,20621,21793,257,21792,16385,648]

theorem envBound20936 : H12AffineFastState.Bounded env20936 := by
  intro p hp
  have h : env20936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20935_20936 : H12AffineEnvironment.transform 15 30082 env20935 = env20936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30082 env20935 == env20936) = true)

theorem identity20936 : scanCanonicalize (H12AffineFastState.compose env20936 (packedSelected [2,4,6,9,11,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound20936 : packedSelected [2,4,6,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env20937 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,21896,21646,16536,2340,1025,21897,17681,168,21776,138,388,16,23945,16401,17665,2341,20621,21793,257,21792,16385,648]

theorem envBound20937 : H12AffineFastState.Bounded env20937 := by
  intro p hp
  have h : env20937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20936_20937 : H12AffineEnvironment.transform 12 268 env20936 = env20937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env20936 == env20937) = true)

theorem identity20937 : scanCanonicalize (H12AffineFastState.compose env20937 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound20937 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20938 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5512,0,262,5392,2340,1025,1,4249,168,152,138,388,16,2049,5529,4233,2341,1285,169,257,168,5513,648]

theorem envBound20938 : H12AffineFastState.Bounded env20938 := by
  intro p hp
  have h : env20938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20937_20938 : H12AffineEnvironment.transform 13 5512 env20937 = env20938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env20937 == env20938) = true)

theorem identity20938 : scanCanonicalize (H12AffineFastState.compose env20938 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20938 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env20939 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,0,262,5392,2340,1025,1,4113,32,16,2,268,16,2049,5393,4097,2341,1285,33,257,32,5377,512]

theorem envBound20939 : H12AffineFastState.Bounded env20939 := by
  intro p hp
  have h : env20939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20938_20939 : H12AffineEnvironment.transform 6 8 env20938 = env20939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20938 == env20939) = true)

theorem identity20939 : scanCanonicalize (H12AffineFastState.compose env20939 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound20939 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20940 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,268,4145,0,262,4129,2340,304,1,4113,32,16,2,268,16,2049,4128,4097,2341,52,33,257,32,4144,512]

theorem envBound20940 : H12AffineFastState.Bounded env20940 := by
  intro p hp
  have h : env20940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20939_20940 : H12AffineEnvironment.transform 9 305 env20939 = env20940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env20939 == env20940) = true)

theorem identity20940 : scanCanonicalize (H12AffineFastState.compose env20940 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20940 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20941 : List Nat := [2,4,8,16,0,16,8,256,512,273,2048,4096,268,4113,0,262,4097,2308,272,1,4113,0,16,2,268,16,2049,4096,4097,2309,20,1,257,0,4112,512]

theorem envBound20941 : H12AffineFastState.Bounded env20941 := by
  intro p hp
  have h : env20941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20940_20941 : H12AffineEnvironment.transform 4 0 env20940 = env20941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20940 == env20941) = true)

theorem identity20941 : scanCanonicalize (H12AffineFastState.compose env20941 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound20941 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20942 : List Nat := [2,4,8,16,0,16,8,256,512,273,2048,277,268,260,0,262,276,2308,272,1,260,0,16,2,268,16,2049,277,276,2309,20,1,257,0,261,512]

theorem envBound20942 : H12AffineFastState.Bounded env20942 := by
  intro p hp
  have h : env20942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20941_20942 : H12AffineEnvironment.transform 11 277 env20941 = env20942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env20941 == env20942) = true)

theorem identity20942 : scanCanonicalize (H12AffineFastState.compose env20942 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound20942 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env20943 : List Nat := [2,4,8,16,0,16,8,256,512,273,261,277,268,260,0,262,276,1,272,1,260,0,16,2,268,16,260,277,276,0,20,1,257,0,261,512]

theorem envBound20943 : H12AffineFastState.Bounded env20943 := by
  intro p hp
  have h : env20943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20942_20943 : H12AffineEnvironment.transform 10 261 env20942 = env20943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env20942 == env20943) = true)

def env20944 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,24981,262144,1025,29828,2097152,272512,2101248,95496,8328,17,2103449,2098433,17665,2376977,2102684,2373657,257,21792,16384,2175514]

theorem envBound20944 : H12AffineFastState.Bounded env20944 := by
  intro p hp
  have h : env20944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20932_20944 : H12AffineEnvironment.transform 5 17 env20932 = env20944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20932 == env20944) = true)

theorem identity20944 : scanCanonicalize (H12AffineFastState.compose env20944 (packedSelected [3,4,5,7,8,9,10,11,17,19,26,27,28,31,32] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20944 : packedSelected [3,4,5,7,8,9,10,11,17,19,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env20945 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29709,65536,24861,262144,1025,29708,2097152,272392,2101248,95496,8192,17,2103313,2098433,17665,2376977,2102548,2373657,257,21792,16384,2175514]

theorem envBound20945 : H12AffineFastState.Bounded env20945 := by
  intro p hp
  have h : env20945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20944_20945 : H12AffineEnvironment.transform 6 8 env20944 = env20945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20944 == env20945) = true)

theorem identity20945 : scanCanonicalize (H12AffineFastState.compose env20945 (packedSelected [0,1,3,5,7,9,12,14,15,16,17,22,26,28] rootPS)) = affineNative (2^(20+1) ^^^ 347158) := by decide +kernel

theorem selectedBound20945 : packedSelected [0,1,3,5,7,9,12,14,15,16,17,22,26,28] rootPS < 2^1333 := by decide +kernel

def env20946 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29709,65536,24861,262144,1025,29708,347158,272392,351254,95496,8192,17,349191,346391,17665,67847,350466,95247,257,21792,16384,294412]

theorem envBound20946 : H12AffineFastState.Bounded env20946 := by
  intro p hp
  have h : env20946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20945_20946 : H12AffineEnvironment.transform 20 347158 env20945 = env20946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 347158 env20945 == env20946) = true)

theorem identity20946 : scanCanonicalize (H12AffineFastState.compose env20946 (packedSelected [2,3,6,7,9,10,11,16,17,18,19,22,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound20946 : packedSelected [2,3,6,7,9,10,11,16,17,18,19,22,24,27] rootPS < 2^1333 := by decide +kernel

def env20947 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29709,263,24861,262144,1025,29708,281873,272392,285969,29711,8192,17,283904,280592,17665,2048,284677,29960,257,21792,16384,294412]

theorem envBound20947 : H12AffineFastState.Bounded env20947 := by
  intro p hp
  have h : env20947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20946_20947 : H12AffineEnvironment.transform 15 263 env20946 = env20947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env20946 == env20947) = true)

theorem identity20947 : scanCanonicalize (H12AffineFastState.compose env20947 (packedSelected [1,8,12,15,16,17,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound20947 : packedSelected [1,8,12,15,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env20948 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,41,16384,21540,263,16692,262144,1025,21541,281873,264225,285969,21542,41,17,283904,280592,17665,2048,284677,21793,257,21792,16384,286245]

theorem envBound20948 : H12AffineFastState.Bounded env20948 := by
  intro p hp
  have h : env20948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20947_20948 : H12AffineEnvironment.transform 12 41 env20947 = env20948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env20947 == env20948) = true)

theorem identity20948 : scanCanonicalize (H12AffineFastState.compose env20948 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound20948 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env20949 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,16384,21540,35,16400,262144,1025,21541,281653,264225,285749,21542,41,17,283684,280592,17445,2048,284677,21509,37,21508,16384,286245]

theorem envBound20949 : H12AffineFastState.Bounded env20949 := by
  intro p hp
  have h : env20949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20948_20949 : H12AffineEnvironment.transform 7 36 env20948 = env20949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20948 == env20949) = true)

theorem identity20949 : scanCanonicalize (H12AffineFastState.compose env20949 (packedSelected [3,4,5,6,7,11] rootPS)) = affineNative (2^(17+1) ^^^ 23589) := by decide +kernel

theorem selectedBound20949 : packedSelected [3,4,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env20950 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,16384,21540,35,16400,23589,1025,21541,4112,21508,16,21542,41,17,2049,5173,17445,2048,1056,21509,37,21508,16384,512]

theorem envBound20950 : H12AffineFastState.Bounded env20950 := by
  intro p hp
  have h : env20950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20949_20950 : H12AffineEnvironment.transform 17 23589 env20949 = env20950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23589 env20949 == env20950) = true)

theorem identity20950 : scanCanonicalize (H12AffineFastState.compose env20950 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20950 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env20951 : List Nat := [2,4,8,16,1,17,8,5,512,1024,2048,4096,8,16384,21509,2,16400,23556,1025,21508,4112,21508,16,21511,8,17,2049,5140,17412,2048,1025,21509,4,21508,16384,512]

theorem envBound20951 : H12AffineFastState.Bounded env20951 := by
  intro p hp
  have h : env20951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20950_20951 : H12AffineEnvironment.transform 4 1 env20950 = env20951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20950 == env20951) = true)

theorem identity20951 : scanCanonicalize (H12AffineFastState.compose env20951 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound20951 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20952 : List Nat := [2,4,8,16,1,17,8,5,512,1024,2048,4096,8,5125,0,2,5141,2049,1025,1,4112,1,16,2,8,17,2049,5140,4097,2048,1025,0,4,1,5125,512]

theorem envBound20952 : H12AffineFastState.Bounded env20952 := by
  intro p hp
  have h : env20952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20951_20952 : H12AffineEnvironment.transform 13 5125 env20951 = env20952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env20951 == env20952) = true)

def env20953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2157597,2098512,17665,2377024,2102684,2411677,257,21792,46213,2175563]

theorem envBound20953 : H12AffineFastState.Bounded env20953 := by
  intro p hp
  have h : env20953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20930_20953 : H12AffineEnvironment.transform 21 272513 env20930 = env20953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env20930 == env20953) = true)

theorem identity20953 : scanCanonicalize (H12AffineFastState.compose env20953 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58516) := by decide +kernel

theorem selectedBound20953 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,58516,272513,62661,98780,8328,64,2185,57796,17665,303572,61704,272393,257,21792,46213,120543]

theorem envBound20954 : H12AffineFastState.Bounded env20954 := by
  intro p hp
  have h : env20954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20953_20954 : H12AffineEnvironment.transform 20 58516 env20953 = env20954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58516 env20953 == env20954) = true)

def env20955 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1025,32769,58516,169,62661,98780,8328,64,2185,57796,17665,35324,61704,33,257,21792,46213,120543]

theorem envBound20955 : H12AffineFastState.Bounded env20955 := by
  intro p hp
  have h : env20955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20954_20955 : H12AffineEnvironment.transform 17 10280 env20954 = env20955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env20954 == env20955) = true)

theorem identity20955 : scanCanonicalize (H12AffineFastState.compose env20955 (packedSelected [0,1,2,4,5,6,8,9,17,19,20,23,24,26,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound20955 : packedSelected [0,1,2,4,5,6,8,9,17,19,20,23,24,26,27,32] rootPS < 2^1333 := by decide +kernel

def env20956 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,13508,10280,1025,8661,17728,169,21777,73736,8328,64,2185,16400,17665,10280,20700,33,257,21792,5457,96011]

theorem envBound20956 : H12AffineFastState.Bounded env20956 := by
  intro p hp
  have h : env20956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20955_20956 : H12AffineEnvironment.transform 14 8660 env20955 = env20956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env20955 == env20956) = true)

theorem identity20956 : scanCanonicalize (H12AffineFastState.compose env20956 (packedSelected [0,1,2,4,6,8,9,11,18,19,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound20956 : packedSelected [0,1,2,4,6,8,9,11,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env20957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8202,13508,10280,1025,8661,17728,169,21777,2,8328,64,2185,16400,17665,10280,20700,33,257,21792,5457,22273]

end H12CloudChart0