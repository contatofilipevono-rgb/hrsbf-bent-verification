import H12CloudChart0Data002

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans711_712 : H12AffineEnvironment.transform 3 5 env711 = env712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env711 == env712) = true)

def leafEnv712 : List Nat := [2,4,0,5,4,4,1,1,1,2,2,1,4,3,1,6,6,3,2,1,4,4,4,3,6,5,1,5,2,6,1,2,6,4,1,4,4,7,3,1,1,5,0]

def active712 : List Nat := [0,1]

def tree712 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood712 : H12WitnessSearch.Good tree712 := H12GlobalWitnessIndex.good

theorem leafIdentity712 : H12AffineFastState.composeSystem env712 rootObs = leafEnv712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env712 rootObs == leafEnv712) = true)

theorem terminalChecked712 : H12PackedTerminal.terminalCheckFast leafEnv712 active712 tree712 = true := by decide +kernel

def env713 : List Nat := [2,4,8,16,32,17,9,37,512,46,570,49,40,10,1,34,43,522,46,1,16,32,17,3,41,16,523,43,49,570,14,32,37,32,59,512]

theorem envBound713 : H12AffineFastState.Bounded env713 := by
  intro p hp
  have h : env713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans704_713 : H12AffineEnvironment.transform 11 49 env704 = env713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env704 == env713) = true)

theorem identity713 : scanCanonicalize (H12AffineFastState.compose env713 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 34) := by decide +kernel

theorem selectedBound713 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env714 : List Nat := [2,4,8,16,32,17,9,37,34,46,24,49,40,10,1,34,43,40,46,1,16,32,17,3,41,16,41,43,49,24,14,32,37,32,59,34]

theorem envBound714 : H12AffineFastState.Bounded env714 := by
  intro p hp
  have h : env714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans713_714 : H12AffineEnvironment.transform 8 34 env713 = env714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 34 env713 == env714) = true)

def env715 : List Nat := [2,4,8,16,16,17,9,21,18,30,24,1,24,10,1,18,27,24,30,1,16,16,17,3,25,16,25,27,1,24,14,16,21,16,11,18]

theorem envBound715 : H12AffineFastState.Bounded env715 := by
  intro p hp
  have h : env715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans714_715 : H12AffineEnvironment.transform 4 16 env714 = env715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env714 == env715) = true)

theorem identity715 : scanCanonicalize (H12AffineFastState.compose env715 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound715 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env716 : List Nat := [2,4,1,16,16,17,0,21,18,23,17,1,17,3,1,18,18,17,23,1,16,16,17,3,16,16,16,18,1,17,7,16,21,16,2,18]

theorem envBound716 : H12AffineFastState.Bounded env716 := by
  intro p hp
  have h : env716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans715_716 : H12AffineEnvironment.transform 2 1 env715 = env716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env715 == env716) = true)

theorem identity716 : scanCanonicalize (H12AffineFastState.compose env716 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound716 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env717 : List Nat := [2,4,1,6,6,7,0,3,4,1,7,1,7,3,1,4,4,7,1,1,6,6,7,3,6,6,6,4,1,7,7,6,3,6,2,4]

theorem envBound717 : H12AffineFastState.Bounded env717 := by
  intro p hp
  have h : env717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans716_717 : H12AffineEnvironment.transform 3 6 env716 = env717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env716 == env717) = true)

def leafEnv717 : List Nat := [2,4,1,6,6,7,0,3,4,1,7,1,7,3,1,4,4,7,1,1,6,6,7,3,7,6,1,6,6,4,1,7,7,6,3,6,4,5,2,4,1,6,0]

def active717 : List Nat := [0,1]

def tree717 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood717 : H12WitnessSearch.Good tree717 := H12GlobalWitnessIndex.good

theorem leafIdentity717 : H12AffineFastState.composeSystem env717 rootObs = leafEnv717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env717 rootObs == leafEnv717) = true)

theorem terminalChecked717 : H12PackedTerminal.terminalCheckFast leafEnv717 active717 tree717 = true := by decide +kernel

def env718 : List Nat := [2,4,8,16,17,17,9,20,19,31,24,0,25,10,1,19,26,25,31,1,16,17,17,3,24,16,24,26,0,24,14,17,20,17,10,19]

theorem envBound718 : H12AffineFastState.Bounded env718 := by
  intro p hp
  have h : env718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans714_718 : H12AffineEnvironment.transform 4 17 env714 = env718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env714 == env718) = true)

theorem identity718 : scanCanonicalize (H12AffineFastState.compose env718 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound718 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env719 : List Nat := [2,4,8,3,2,2,9,7,0,12,11,0,10,10,1,0,9,10,12,1,3,2,2,3,11,3,11,9,0,11,14,2,7,2,10,0]

theorem envBound719 : H12AffineFastState.Bounded env719 := by
  intro p hp
  have h : env719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans718_719 : H12AffineEnvironment.transform 3 3 env718 = env719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env718 == env719) = true)

theorem identity719 : scanCanonicalize (H12AffineFastState.compose env719 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound719 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env720 : List Nat := [2,4,7,3,2,2,6,7,0,3,4,0,5,5,1,0,6,5,3,1,3,2,2,3,4,3,4,6,0,4,1,2,7,2,5,0]

theorem envBound720 : H12AffineFastState.Bounded env720 := by
  intro p hp
  have h : env720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans719_720 : H12AffineEnvironment.transform 2 7 env719 = env720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env719 == env720) = true)

def leafEnv720 : List Nat := [2,4,7,3,2,2,6,7,0,3,4,0,5,5,1,0,6,5,3,1,3,2,2,3,1,4,1,3,4,6,0,4,1,2,7,2,4,1,5,0,1,2,0]

def active720 : List Nat := [0,1]

def tree720 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood720 : H12WitnessSearch.Good tree720 := H12GlobalWitnessIndex.good

theorem leafIdentity720 : H12AffineFastState.composeSystem env720 rootObs = leafEnv720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env720 rootObs == leafEnv720) = true)

theorem terminalChecked720 : H12PackedTerminal.terminalCheckFast leafEnv720 active720 tree720 = true := by decide +kernel

def env721 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,33,8388608,8988133,8328,599234,262280,11105475,11232451,8990183,75223,73770,525568,8988103,34359738368,74371]

theorem envBound721 : H12AffineFastState.Bounded env721 := by
  intro p hp
  have h : env721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans651_721 : H12AffineEnvironment.transform 21 33 env651 = env721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env651 == env721) = true)

theorem identity721 : scanCanonicalize (H12AffineFastState.compose env721 (packedSelected [0,3,7,9,10,13,14,20,21,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8575) := by decide +kernel

theorem selectedBound721 : packedSelected [0,3,7,9,10,13,14,20,21,22,24,26] rootPS < 2^1333 := by decide +kernel

def env722 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,8575,131072,262144,524288,8352,2097152,33,8388608,8914074,8328,525757,262280,11031996,11158972,8916120,1192,341,525568,8914104,34359738368,1020]

theorem envBound722 : H12AffineFastState.Bounded env722 := by
  intro p hp
  have h : env722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans721_722 : H12AffineEnvironment.transform 15 8575 env721 = env722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8575 env721 == env722) = true)

theorem identity722 : scanCanonicalize (H12AffineFastState.compose env722 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound722 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env723 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8352,8323,131072,262144,524288,8352,2097152,33,8388608,8914074,8328,525377,262280,11031616,11158592,8916120,1192,169,525564,8914104,34359738368,512]

theorem envBound723 : H12AffineFastState.Bounded env723 := by
  intro p hp
  have h : env723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans722_723 : H12AffineEnvironment.transform 7 252 env722 = env723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env722 == env723) = true)

theorem identity723 : scanCanonicalize (H12AffineFastState.compose env723 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 17596) := by decide +kernel

theorem selectedBound723 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env724 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8352,8323,131072,262144,524288,8352,17596,33,8388608,8914074,8328,525377,262280,8917244,9044220,8916120,1192,169,525564,8914104,34359738368,512]

theorem envBound724 : H12AffineFastState.Bounded env724 := by
  intro p hp
  have h : env724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans723_724 : H12AffineEnvironment.transform 20 17596 env723 = env724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17596 env723 == env724) = true)

theorem identity724 : scanCanonicalize (H12AffineFastState.compose env724 (packedSelected [11,12,13,15,18] rootPS)) = affineNative (2^(34+1) ^^^ 940085) := by decide +kernel

theorem selectedBound724 : packedSelected [11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env725 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8352,8323,131072,262144,524288,8352,17596,33,8388608,8914074,8328,525377,262280,8917244,9044220,8916120,1192,169,525564,8914104,940085,512]

theorem envBound725 : H12AffineFastState.Bounded env725 := by
  intro p hp
  have h : env725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans724_725 : H12AffineEnvironment.transform 34 940085 env724 = env725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 940085 env724 == env725) = true)

theorem identity725 : scanCanonicalize (H12AffineFastState.compose env725 (packedSelected [0,4,7,9,11,12,13,14,15,23] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound725 : packedSelected [0,4,7,9,11,12,13,14,15,23] rootPS < 2^1333 := by decide +kernel

def env726 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,160,16384,0,35,131072,262144,524288,0,17596,33,8388608,8914074,40,525377,262280,8917244,9044220,8916120,1192,169,525564,8914104,940085,512]

theorem envBound726 : H12AffineFastState.Bounded env726 := by
  intro p hp
  have h : env726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans725_726 : H12AffineEnvironment.transform 12 160 env725 = env726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env725 == env726) = true)

theorem identity726 : scanCanonicalize (H12AffineFastState.compose env726 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 5357) := by decide +kernel

theorem selectedBound726 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env727 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,160,16384,0,35,5357,262144,524288,0,17596,33,8388608,8914074,40,525377,262280,8917244,8918033,8916120,1192,169,525564,8914104,806104,512]

theorem envBound727 : H12AffineFastState.Bounded env727 := by
  intro p hp
  have h : env727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans726_727 : H12AffineEnvironment.transform 16 5357 env726 = env727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5357 env726 == env727) = true)

theorem identity727 : scanCanonicalize (H12AffineFastState.compose env727 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(22+1) ^^^ 789657) := by decide +kernel

theorem selectedBound727 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env728 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,160,16384,0,35,5357,262144,524288,0,17596,33,789657,264195,40,525377,262280,269413,268424,262145,1192,169,525564,264225,806104,512]

theorem envBound728 : H12AffineFastState.Bounded env728 := by
  intro p hp
  have h : env728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans727_728 : H12AffineEnvironment.transform 22 789657 env727 = env728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 789657 env727 == env728) = true)

theorem identity728 : scanCanonicalize (H12AffineFastState.compose env728 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound728 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env729 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,160,16384,0,35,5357,2185,524288,0,17596,33,525328,138,40,525377,2049,5356,4097,2184,1192,169,525564,168,541777,512]

theorem envBound729 : H12AffineFastState.Bounded env729 := by
  intro p hp
  have h : env729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans728_729 : H12AffineEnvironment.transform 17 2185 env728 = env729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env728 == env729) = true)

theorem identity729 : scanCanonicalize (H12AffineFastState.compose env729 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound729 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env730 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8,16384,0,35,5189,2081,524288,0,17428,33,525328,34,40,525377,2049,5188,4097,2080,1024,1,525396,0,541777,512]

theorem envBound730 : H12AffineFastState.Bounded env730 := by
  intro p hp
  have h : env730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans729_730 : H12AffineEnvironment.transform 6 40 env729 = env730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env729 == env730) = true)

def env731 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8,16384,0,35,5189,2081,1104,0,17428,33,64,34,40,17,2049,5188,4097,2080,1024,1,4,0,16385,512]

theorem envBound731 : H12AffineFastState.Bounded env731 := by
  intro p hp
  have h : env731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans730_731 : H12AffineEnvironment.transform 18 1104 env730 = env731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1104 env730 == env731) = true)

theorem identity731 : scanCanonicalize (H12AffineFastState.compose env731 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 80) := by decide +kernel

theorem selectedBound731 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env732 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8,80,0,35,5189,2081,1104,0,1092,33,64,34,40,17,2049,5188,4097,2080,1024,1,4,0,81,512]

theorem envBound732 : H12AffineFastState.Bounded env732 := by
  intro p hp
  have h : env732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans731_732 : H12AffineEnvironment.transform 13 80 env731 = env732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 80 env731 == env732) = true)

theorem identity732 : scanCanonicalize (H12AffineFastState.compose env732 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1086) := by decide +kernel

theorem selectedBound732 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env733 : List Nat := [2,4,8,16,32,64,40,84,512,1024,1086,4096,8,80,0,35,5189,1055,1104,0,1092,33,64,34,40,17,1087,5188,4097,1054,1024,1,4,0,81,512]

theorem envBound733 : H12AffineFastState.Bounded env733 := by
  intro p hp
  have h : env733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans732_733 : H12AffineEnvironment.transform 10 1086 env732 = env733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1086 env732 == env733) = true)

theorem identity733 : scanCanonicalize (H12AffineFastState.compose env733 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound733 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env734 : List Nat := [2,4,8,16,32,32,40,52,512,1024,1086,4096,8,48,0,35,5157,1055,1072,0,1060,33,32,34,40,17,1087,5156,4097,1054,1024,1,4,0,49,512]

theorem envBound734 : H12AffineFastState.Bounded env734 := by
  intro p hp
  have h : env734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans733_734 : H12AffineEnvironment.transform 5 32 env733 = env734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env733 == env734) = true)

theorem identity734 : scanCanonicalize (H12AffineFastState.compose env734 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound734 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env735 : List Nat := [2,4,8,16,26,26,18,14,512,1024,1028,4096,8,10,0,25,5151,1055,1034,0,1054,27,26,24,18,17,1029,5150,4097,1054,1024,1,4,0,11,512]

theorem envBound735 : H12AffineFastState.Bounded env735 := by
  intro p hp
  have h : env735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans734_735 : H12AffineEnvironment.transform 4 26 env734 = env735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env734 == env735) = true)

def env736 : List Nat := [2,4,8,16,26,26,18,14,512,1024,1028,1044,8,10,0,25,11,1055,1034,0,1054,27,26,24,18,17,1029,10,1045,1054,1024,1,4,0,11,512]

theorem envBound736 : H12AffineFastState.Bounded env736 := by
  intro p hp
  have h : env736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans735_736 : H12AffineEnvironment.transform 11 1044 env735 = env736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env735 == env736) = true)

theorem identity736 : scanCanonicalize (H12AffineFastState.compose env736 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound736 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env737 : List Nat := [2,4,8,2,8,8,0,14,512,1024,1028,1030,8,10,0,11,11,1037,1034,0,1036,9,8,10,0,3,1029,10,1031,1036,1024,1,4,0,11,512]

theorem envBound737 : H12AffineFastState.Bounded env737 := by
  intro p hp
  have h : env737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans736_737 : H12AffineEnvironment.transform 3 2 env736 = env737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env736 == env737) = true)

def env738 : List Nat := [2,4,8,2,8,8,0,14,8,1024,1028,1030,8,10,0,11,11,1037,1034,0,1036,9,8,10,0,3,1029,10,1031,1036,1024,1,4,0,11,8]

theorem envBound738 : H12AffineFastState.Bounded env738 := by
  intro p hp
  have h : env738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans737_738 : H12AffineEnvironment.transform 8 8 env737 = env738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env737 == env738) = true)

theorem identity738 : scanCanonicalize (H12AffineFastState.compose env738 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound738 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env739 : List Nat := [2,0,8,2,8,8,0,10,8,1024,1024,1026,8,10,0,11,11,1033,1034,0,1032,9,8,10,0,3,1025,10,1027,1032,1024,1,0,0,11,8]

theorem envBound739 : H12AffineFastState.Bounded env739 := by
  intro p hp
  have h : env739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans738_739 : H12AffineEnvironment.transform 1 0 env738 = env739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env738 == env739) = true)

def leafEnv739 : List Nat := [2,0,8,2,8,8,0,10,8,1024,1024,1026,8,10,0,11,11,1033,1034,0,1032,9,8,10,1035,0,1,3,1025,10,1027,1032,1024,1,0,0,11,3,11,8,1,1032,0]

def active739 : List Nat := [0,2,9]

def tree739 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood739 : H12WitnessSearch.Good tree739 := H12GlobalWitnessIndex.good

theorem leafIdentity739 : H12AffineFastState.composeSystem env739 rootObs = leafEnv739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env739 rootObs == leafEnv739) = true)

theorem terminalChecked739 : H12PackedTerminal.terminalCheckFast leafEnv739 active739 tree739 = true := by decide +kernel

def env740 : List Nat := [2,4,8,2,8,8,0,14,9,1024,1028,1030,8,10,0,11,11,1037,1034,0,1036,9,8,10,0,3,1029,10,1031,1036,1024,1,4,0,11,9]

theorem envBound740 : H12AffineFastState.Bounded env740 := by
  intro p hp
  have h : env740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans737_740 : H12AffineEnvironment.transform 8 9 env737 = env740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env737 == env740) = true)

theorem identity740 : scanCanonicalize (H12AffineFastState.compose env740 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 8) := by decide +kernel

theorem selectedBound740 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env741 : List Nat := [2,4,8,2,8,8,0,14,9,8,12,14,8,10,0,11,11,5,2,0,4,9,8,10,0,3,13,10,15,4,8,1,4,0,11,9]

theorem envBound741 : H12AffineFastState.Bounded env741 := by
  intro p hp
  have h : env741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans740_741 : H12AffineEnvironment.transform 9 8 env740 = env741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 8 env740 == env741) = true)

def leafEnv741 : List Nat := [2,4,8,2,8,8,0,14,9,8,12,14,8,10,0,11,11,5,2,0,4,9,8,10,3,0,1,3,13,10,15,4,8,1,4,0,15,3,11,9,1,4,0]

def active741 : List Nat := [0,1,2]

def tree741 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood741 : H12WitnessSearch.Good tree741 := H12GlobalWitnessIndex.good

theorem leafIdentity741 : H12AffineFastState.composeSystem env741 rootObs = leafEnv741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env741 rootObs == leafEnv741) = true)

theorem terminalChecked741 : H12PackedTerminal.terminalCheckFast leafEnv741 active741 tree741 = true := by decide +kernel

def env742 : List Nat := [2,4,8,16,26,26,18,14,512,1024,1028,1045,8,10,0,25,10,1055,1034,0,1054,27,26,24,18,17,1029,11,1044,1054,1024,1,4,0,11,512]

theorem envBound742 : H12AffineFastState.Bounded env742 := by
  intro p hp
  have h : env742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans735_742 : H12AffineEnvironment.transform 11 1045 env735 = env742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env735 == env742) = true)

theorem identity742 : scanCanonicalize (H12AffineFastState.compose env742 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 12) := by decide +kernel

theorem selectedBound742 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env743 : List Nat := [2,4,8,16,26,26,18,14,512,12,8,25,8,10,0,25,10,19,6,0,18,27,26,24,18,17,9,11,24,18,12,1,4,0,11,512]

theorem envBound743 : H12AffineFastState.Bounded env743 := by
  intro p hp
  have h : env743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans742_743 : H12AffineEnvironment.transform 9 12 env742 = env743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 12 env742 == env743) = true)

def env744 : List Nat := [2,4,8,16,26,26,18,14,8,12,8,25,8,10,0,25,10,19,6,0,18,27,26,24,18,17,9,11,24,18,12,1,4,0,11,8]

theorem envBound744 : H12AffineFastState.Bounded env744 := by
  intro p hp
  have h : env744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans743_744 : H12AffineEnvironment.transform 8 8 env743 = env744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env743 == env744) = true)

theorem identity744 : scanCanonicalize (H12AffineFastState.compose env744 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound744 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env745 : List Nat := [2,4,8,7,13,13,5,14,8,12,8,14,8,10,0,14,10,4,6,0,5,12,13,15,5,6,9,11,15,5,12,1,4,0,11,8]

theorem envBound745 : H12AffineFastState.Bounded env745 := by
  intro p hp
  have h : env745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans744_745 : H12AffineEnvironment.transform 3 7 env744 = env745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env744 == env745) = true)

def leafEnv745 : List Nat := [2,4,8,7,13,13,5,14,8,12,8,14,8,10,0,14,10,4,6,0,5,12,13,15,7,5,1,6,9,11,15,5,12,1,4,0,15,3,11,8,1,5,0]

def active745 : List Nat := [0,1,2]

def tree745 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood745 : H12WitnessSearch.Good tree745 := H12GlobalWitnessIndex.good

theorem leafIdentity745 : H12AffineFastState.composeSystem env745 rootObs = leafEnv745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env745 rootObs == leafEnv745) = true)

theorem terminalChecked745 : H12PackedTerminal.terminalCheckFast leafEnv745 active745 tree745 = true := by decide +kernel

def env746 : List Nat := [2,4,8,16,26,26,18,14,9,12,8,25,8,10,0,25,10,19,6,0,18,27,26,24,18,17,9,11,24,18,12,1,4,0,11,9]

theorem envBound746 : H12AffineFastState.Bounded env746 := by
  intro p hp
  have h : env746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans743_746 : H12AffineEnvironment.transform 8 9 env743 = env746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env743 == env746) = true)

theorem identity746 : scanCanonicalize (H12AffineFastState.compose env746 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound746 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env747 : List Nat := [2,1,8,16,26,26,18,11,9,9,8,25,8,10,0,25,10,19,3,0,18,27,26,24,18,17,9,11,24,18,9,1,1,0,11,9]

theorem envBound747 : H12AffineFastState.Bounded env747 := by
  intro p hp
  have h : env747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans746_747 : H12AffineEnvironment.transform 1 1 env746 = env747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env746 == env747) = true)

def leafEnv747 : List Nat := [2,1,8,16,26,26,18,11,9,9,8,25,8,10,0,25,10,19,3,0,18,27,26,24,2,18,1,17,9,11,24,18,9,1,1,0,10,3,11,9,1,18,0]

def active747 : List Nat := [0,2,3]

def tree747 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood747 : H12WitnessSearch.Good tree747 := H12GlobalWitnessIndex.good

theorem leafIdentity747 : H12AffineFastState.composeSystem env747 rootObs = leafEnv747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env747 rootObs == leafEnv747) = true)

theorem terminalChecked747 : H12PackedTerminal.terminalCheckFast leafEnv747 active747 tree747 = true := by decide +kernel

def env748 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8,16384,0,35,5189,2081,1105,0,17428,33,65,34,40,16,2049,5188,4097,2080,1024,1,5,0,16384,512]

theorem envBound748 : H12AffineFastState.Bounded env748 := by
  intro p hp
  have h : env748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans730_748 : H12AffineEnvironment.transform 18 1105 env730 = env748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1105 env730 == env748) = true)

theorem identity748 : scanCanonicalize (H12AffineFastState.compose env748 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1092) := by decide +kernel

theorem selectedBound748 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env749 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8,1092,0,35,5189,2081,1105,0,80,33,65,34,40,16,2049,5188,4097,2080,1024,1,5,0,1092,512]

theorem envBound749 : H12AffineFastState.Bounded env749 := by
  intro p hp
  have h : env749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans748_749 : H12AffineEnvironment.transform 13 1092 env748 = env749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1092 env748 == env749) = true)

theorem identity749 : scanCanonicalize (H12AffineFastState.compose env749 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1086) := by decide +kernel

theorem selectedBound749 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env750 : List Nat := [2,4,8,16,32,64,40,84,512,1024,1086,4096,8,1092,0,35,5189,1055,1105,0,80,33,65,34,40,16,1087,5188,4097,1054,1024,1,5,0,1092,512]

theorem envBound750 : H12AffineFastState.Bounded env750 := by
  intro p hp
  have h : env750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans749_750 : H12AffineEnvironment.transform 10 1086 env749 = env750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1086 env749 == env750) = true)

theorem identity750 : scanCanonicalize (H12AffineFastState.compose env750 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound750 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env751 : List Nat := [2,4,8,16,32,10,40,30,512,1024,1086,4096,8,1038,0,35,5135,1055,1051,0,26,33,11,34,40,16,1087,5134,4097,1054,1024,1,5,0,1038,512]

theorem envBound751 : H12AffineFastState.Bounded env751 := by
  intro p hp
  have h : env751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans750_751 : H12AffineEnvironment.transform 5 10 env750 = env751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env750 == env751) = true)

theorem identity751 : scanCanonicalize (H12AffineFastState.compose env751 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound751 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env752 : List Nat := [2,4,8,16,16,10,24,30,512,1024,1038,4096,8,1038,0,19,5135,1055,1051,0,26,17,11,18,24,16,1039,5134,4097,1054,1024,1,5,0,1038,512]

theorem envBound752 : H12AffineFastState.Bounded env752 := by
  intro p hp
  have h : env752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans751_752 : H12AffineEnvironment.transform 4 16 env751 = env752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env751 == env752) = true)

def env753 : List Nat := [2,4,8,16,16,10,24,30,512,1024,1038,1044,8,1038,0,19,27,1055,1051,0,26,17,11,18,24,16,1039,26,1045,1054,1024,1,5,0,1038,512]

theorem envBound753 : H12AffineFastState.Bounded env753 := by
  intro p hp
  have h : env753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans752_753 : H12AffineEnvironment.transform 11 1044 env752 = env753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env752 == env753) = true)

theorem identity753 : scanCanonicalize (H12AffineFastState.compose env753 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 6) := by decide +kernel

theorem selectedBound753 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env754 : List Nat := [2,4,8,16,16,10,24,30,512,6,8,18,8,8,0,19,27,25,29,0,26,17,11,18,24,16,9,26,19,24,6,1,5,0,8,512]

theorem envBound754 : H12AffineFastState.Bounded env754 := by
  intro p hp
  have h : env754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans753_754 : H12AffineEnvironment.transform 9 6 env753 = env754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 6 env753 == env754) = true)

def env755 : List Nat := [2,4,8,16,16,10,24,30,16,6,8,18,8,8,0,19,27,25,29,0,26,17,11,18,24,16,9,26,19,24,6,1,5,0,8,16]

theorem envBound755 : H12AffineFastState.Bounded env755 := by
  intro p hp
  have h : env755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans754_755 : H12AffineEnvironment.transform 8 16 env754 = env755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env754 == env755) = true)

theorem identity755 : scanCanonicalize (H12AffineFastState.compose env755 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound755 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env756 : List Nat := [2,4,8,6,6,10,14,8,6,6,8,4,8,8,0,5,13,15,11,0,12,7,11,4,14,6,9,12,5,14,6,1,5,0,8,6]

theorem envBound756 : H12AffineFastState.Bounded env756 := by
  intro p hp
  have h : env756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans755_756 : H12AffineEnvironment.transform 3 6 env755 = env756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env755 == env756) = true)

def leafEnv756 : List Nat := [2,4,8,6,6,10,14,8,6,6,8,4,8,8,0,5,13,15,11,0,12,7,11,4,10,14,1,6,9,12,5,14,6,1,5,0,8,3,8,6,1,13,0]

def active756 : List Nat := [0,1,2]

def tree756 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood756 : H12WitnessSearch.Good tree756 := H12GlobalWitnessIndex.good

theorem leafIdentity756 : H12AffineFastState.composeSystem env756 rootObs = leafEnv756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env756 rootObs == leafEnv756) = true)

theorem terminalChecked756 : H12PackedTerminal.terminalCheckFast leafEnv756 active756 tree756 = true := by decide +kernel

def env757 : List Nat := [2,4,8,16,16,10,24,30,17,6,8,18,8,8,0,19,27,25,29,0,26,17,11,18,24,16,9,26,19,24,6,1,5,0,8,17]

theorem envBound757 : H12AffineFastState.Bounded env757 := by
  intro p hp
  have h : env757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans754_757 : H12AffineEnvironment.transform 8 17 env754 = env757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env754 == env757) = true)

theorem identity757 : scanCanonicalize (H12AffineFastState.compose env757 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound757 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env758 : List Nat := [2,4,8,14,14,10,6,0,15,6,8,12,8,8,0,13,5,7,3,0,4,15,11,12,6,14,9,4,13,6,6,1,5,0,8,15]

theorem envBound758 : H12AffineFastState.Bounded env758 := by
  intro p hp
  have h : env758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans757_758 : H12AffineEnvironment.transform 3 14 env757 = env758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env757 == env758) = true)

def leafEnv758 : List Nat := [2,4,8,14,14,10,6,0,15,6,8,12,8,8,0,13,5,7,3,0,4,15,11,12,2,6,1,14,9,4,13,6,6,1,5,0,0,3,8,15,1,5,0]

def active758 : List Nat := [0,1,2]

def tree758 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood758 : H12WitnessSearch.Good tree758 := H12GlobalWitnessIndex.good

theorem leafIdentity758 : H12AffineFastState.composeSystem env758 rootObs = leafEnv758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env758 rootObs == leafEnv758) = true)

theorem terminalChecked758 : H12PackedTerminal.terminalCheckFast leafEnv758 active758 tree758 = true := by decide +kernel

def env759 : List Nat := [2,4,8,16,16,10,24,30,512,1024,1038,1045,8,1038,0,19,26,1055,1051,0,26,17,11,18,24,16,1039,27,1044,1054,1024,1,5,0,1038,512]

theorem envBound759 : H12AffineFastState.Bounded env759 := by
  intro p hp
  have h : env759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans752_759 : H12AffineEnvironment.transform 11 1045 env752 = env759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env752 == env759) = true)

theorem identity759 : scanCanonicalize (H12AffineFastState.compose env759 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound759 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env760 : List Nat := [2,4,0,16,16,2,16,22,512,1024,1030,1045,0,1030,0,19,18,1047,1043,0,18,17,3,18,16,16,1031,19,1044,1046,1024,1,5,0,1030,512]

theorem envBound760 : H12AffineFastState.Bounded env760 := by
  intro p hp
  have h : env760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans759_760 : H12AffineEnvironment.transform 2 0 env759 = env760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env759 == env760) = true)

def env761 : List Nat := [2,4,0,16,16,2,16,22,16,1024,1030,1045,0,1030,0,19,18,1047,1043,0,18,17,3,18,16,16,1031,19,1044,1046,1024,1,5,0,1030,16]

theorem envBound761 : H12AffineFastState.Bounded env761 := by
  intro p hp
  have h : env761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans760_761 : H12AffineEnvironment.transform 8 16 env760 = env761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env760 == env761) = true)

theorem identity761 : scanCanonicalize (H12AffineFastState.compose env761 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 17) := by decide +kernel

theorem selectedBound761 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env762 : List Nat := [2,4,0,16,16,2,16,22,16,17,23,4,0,23,0,19,18,6,2,0,18,17,3,18,16,16,22,19,5,7,17,1,5,0,23,16]

theorem envBound762 : H12AffineFastState.Bounded env762 := by
  intro p hp
  have h : env762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans761_762 : H12AffineEnvironment.transform 9 17 env761 = env762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 17 env761 == env762) = true)

def leafEnv762 : List Nat := [2,4,0,16,16,2,16,22,16,17,23,4,0,23,0,19,18,6,2,0,18,17,3,18,3,16,1,16,22,19,5,7,17,1,5,0,22,3,23,16,1,19,0]

def active762 : List Nat := [0,1,3]

def tree762 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood762 : H12WitnessSearch.Good tree762 := H12GlobalWitnessIndex.good

theorem leafIdentity762 : H12AffineFastState.composeSystem env762 rootObs = leafEnv762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env762 rootObs == leafEnv762) = true)

theorem terminalChecked762 : H12PackedTerminal.terminalCheckFast leafEnv762 active762 tree762 = true := by decide +kernel

def env763 : List Nat := [2,4,0,16,16,2,16,22,17,1024,1030,1045,0,1030,0,19,18,1047,1043,0,18,17,3,18,16,16,1031,19,1044,1046,1024,1,5,0,1030,17]

theorem envBound763 : H12AffineFastState.Bounded env763 := by
  intro p hp
  have h : env763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans760_763 : H12AffineEnvironment.transform 8 17 env760 = env763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env760 == env763) = true)

theorem identity763 : scanCanonicalize (H12AffineFastState.compose env763 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound763 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env764 : List Nat := [2,4,0,7,7,2,7,1,6,1024,1030,1026,0,1030,0,4,5,1024,1028,0,5,6,3,5,7,7,1031,4,1027,1025,1024,1,5,0,1030,6]

theorem envBound764 : H12AffineFastState.Bounded env764 := by
  intro p hp
  have h : env764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans763_764 : H12AffineEnvironment.transform 3 7 env763 = env764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env763 == env764) = true)

def leafEnv764 : List Nat := [2,4,0,7,7,2,7,1,6,1024,1030,1026,0,1030,0,4,5,1024,1028,0,5,6,3,5,1029,7,1,7,1031,4,1027,1025,1024,1,5,0,1,3,1030,6,1,4,0]

def active764 : List Nat := [0,1,9]

def tree764 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood764 : H12WitnessSearch.Good tree764 := H12GlobalWitnessIndex.good

theorem leafIdentity764 : H12AffineFastState.composeSystem env764 rootObs = leafEnv764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env764 rootObs == leafEnv764) = true)

theorem terminalChecked764 : H12PackedTerminal.terminalCheckFast leafEnv764 active764 tree764 = true := by decide +kernel

def env765 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,65536,131072,262144,524288,8353,2097152,4194304,8388608,8988133,8328,599234,262280,11105475,11232451,13184455,75222,73770,525568,13182439,34359738368,74370]

theorem envBound765 : H12AffineFastState.Bounded env765 := by
  intro p hp
  have h : env765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans650_765 : H12AffineEnvironment.transform 14 8353 env650 = env765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env650 == env765) = true)

theorem identity765 : scanCanonicalize (H12AffineFastState.compose env765 (packedSelected [0,7,9,11,14,18,20,22,23,32] rootPS)) = affineNative (2^(21+1) ^^^ 74078) := by decide +kernel

theorem selectedBound765 : packedSelected [0,7,9,11,14,18,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,65536,131072,262144,524288,8353,2097152,74078,8388608,8988133,8328,599234,262280,11105475,11232451,8916121,75222,73770,525568,8914105,34359738368,74370]

theorem envBound766 : H12AffineFastState.Bounded env766 := by
  intro p hp
  have h : env766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans765_766 : H12AffineEnvironment.transform 21 74078 env765 = env766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 74078 env765 == env766) = true)

def env767 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,65536,131072,262144,524288,8353,2097152,73890,8388608,8987673,8328,599234,262280,11105475,11232451,8916121,74794,73770,525564,8914105,34359738368,74370]

theorem envBound767 : H12AffineFastState.Bounded env767 := by
  intro p hp
  have h : env767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans766_767 : H12AffineEnvironment.transform 7 252 env766 = env767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env766 == env767) = true)

theorem identity767 : scanCanonicalize (H12AffineFastState.compose env767 (packedSelected [1,2,5,6,7,9,10,18,20,21,22,23,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound767 : packedSelected [1,2,5,6,7,9,10,18,20,21,22,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env768 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,8323,131072,262144,524288,8353,2097152,33,8388608,8914074,8328,525377,262280,11031616,11158592,8916121,1193,169,525564,8914105,34359738368,513]

theorem envBound768 : H12AffineFastState.Bounded env768 := by
  intro p hp
  have h : env768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans767_768 : H12AffineEnvironment.transform 15 8323 env767 = env768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env767 == env768) = true)

theorem identity768 : scanCanonicalize (H12AffineFastState.compose env768 (packedSelected [3,5,10] rootPS)) = affineNative (2^(22+1) ^^^ 2102460) := by decide +kernel

theorem selectedBound768 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env769 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,8323,131072,262144,524288,8353,2097152,33,2102460,2625574,8328,525377,262280,540924,676092,2627621,1193,169,525564,2625541,34359738368,513]

theorem envBound769 : H12AffineFastState.Bounded env769 := by
  intro p hp
  have h : env769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans768_769 : H12AffineEnvironment.transform 22 2102460 env768 = env769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2102460 env768 == env769) = true)

theorem identity769 : scanCanonicalize (H12AffineFastState.compose env769 (packedSelected [11,12,13,15,18] rootPS)) = affineNative (2^(34+1) ^^^ 2241733) := by decide +kernel

theorem selectedBound769 : packedSelected [11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env770 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,8323,131072,262144,524288,8353,2097152,33,2102460,2625574,8328,525377,262280,540924,676092,2627621,1193,169,525564,2625541,2241733,513]

theorem envBound770 : H12AffineFastState.Bounded env770 := by
  intro p hp
  have h : env770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans769_770 : H12AffineEnvironment.transform 34 2241733 env769 = env770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 2241733 env769 == env770) = true)

theorem identity770 : scanCanonicalize (H12AffineFastState.compose env770 (packedSelected [13,21] rootPS)) = affineNative (2^(20+1) ^^^ 12392) := by decide +kernel

theorem selectedBound770 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env771 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,8323,131072,262144,524288,8353,12392,33,9428,532558,8328,525377,262280,540924,676092,534605,1193,169,525564,532589,132269,513]

theorem envBound771 : H12AffineFastState.Bounded env771 := by
  intro p hp
  have h : env771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans770_771 : H12AffineEnvironment.transform 20 12392 env770 = env771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12392 env770 == env771) = true)

theorem identity771 : scanCanonicalize (H12AffineFastState.compose env771 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 8388) := by decide +kernel

theorem selectedBound771 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env772 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,8323,131072,262144,8388,8353,12392,33,9428,138,8328,9349,262280,24632,159800,2185,1193,169,9272,169,132269,513]

theorem envBound772 : H12AffineFastState.Bounded env772 := by
  intro p hp
  have h : env772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans771_772 : H12AffineEnvironment.transform 18 8388 env771 = env772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 8388 env771 == env772) = true)

theorem identity772 : scanCanonicalize (H12AffineFastState.compose env772 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 12297) := by decide +kernel

theorem selectedBound772 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env773 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,8323,12297,262144,8388,8353,12392,33,9428,138,8328,9349,262280,24632,16433,2185,1193,169,9272,169,13476,513]

theorem envBound773 : H12AffineFastState.Bounded env773 := by
  intro p hp
  have h : env773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans772_773 : H12AffineEnvironment.transform 16 12297 env772 = env773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12297 env772 == env773) = true)

def env774 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8353,65536,131072,262144,524288,8353,2097152,73891,8388608,8987672,8328,599234,262280,11105475,11232451,8916121,74795,73770,525565,8914105,34359738368,74370]

theorem envBound774 : H12AffineFastState.Bounded env774 := by
  intro p hp
  have h : env774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans766_774 : H12AffineEnvironment.transform 7 253 env766 = env774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env766 == env774) = true)

theorem identity774 : scanCanonicalize (H12AffineFastState.compose env774 (packedSelected [13,17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound774 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env775 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8353,8322,131072,262144,524288,8353,2097152,33,8388608,8914074,8328,525376,262280,11031617,11158593,8916121,1193,168,525565,8914105,34359738368,512]

theorem envBound775 : H12AffineFastState.Bounded env775 := by
  intro p hp
  have h : env775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans774_775 : H12AffineEnvironment.transform 15 8322 env774 = env775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env774 == env775) = true)

theorem identity775 : scanCanonicalize (H12AffineFastState.compose env775 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5356) := by decide +kernel

theorem selectedBound775 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env776 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8353,8322,5356,262144,524288,8353,2097152,33,8388608,8914074,8328,525376,262280,11031617,11030701,8916121,1193,168,525565,8914105,34359738368,512]

theorem envBound776 : H12AffineFastState.Bounded env776 := by
  intro p hp
  have h : env776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans775_776 : H12AffineEnvironment.transform 16 5356 env775 = env776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5356 env775 == env776) = true)

theorem identity776 : scanCanonicalize (H12AffineFastState.compose env776 (packedSelected [11,12,13,15,18] rootPS)) = affineNative (2^(34+1) ^^^ 24737) := by decide +kernel

theorem selectedBound776 : packedSelected [11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env777 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8353,8322,5356,262144,524288,8353,2097152,33,8388608,8914074,8328,525376,262280,11031617,11030701,8916121,1193,168,525565,8914105,24737,512]

theorem envBound777 : H12AffineFastState.Bounded env777 := by
  intro p hp
  have h : env777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans776_777 : H12AffineEnvironment.transform 34 24737 env776 = env777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 24737 env776 == env777) = true)

theorem identity777 : scanCanonicalize (H12AffineFastState.compose env777 (packedSelected [12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound777 : packedSelected [12,13,15] rootPS < 2^1333 := by decide +kernel

def env778 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,0,35,5356,262144,524288,0,2097152,33,8388608,8914074,41,525376,262280,11031617,11030701,8916121,1193,168,525565,8914105,16384,512]

theorem envBound778 : H12AffineFastState.Bounded env778 := by
  intro p hp
  have h : env778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans777_778 : H12AffineEnvironment.transform 12 161 env777 = env778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env777 == env778) = true)

def env779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,268570625,1073741824,92374096,1086893388,525568,1073743904,34359738368,25733062]

theorem envBound779 : H12AffineFastState.Bounded env779 := by
  intro p hp
  have h : env779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7_779 : H12AffineEnvironment.transform 28 268570625 env7 = env779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 268570625 env7 == env779) = true)

theorem identity779 : scanCanonicalize (H12AffineFastState.compose env779 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(26+1) ^^^ 9176216) := by decide +kernel

theorem selectedBound779 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,9176216,268435456,268570625,1073741824,92374096,1086893388,525568,1073743904,34359738368,25733062]

theorem envBound780 : H12AffineFastState.Bounded env780 := by
  intro p hp
  have h : env780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans779_780 : H12AffineEnvironment.transform 26 9176216 env779 = env780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 9176216 env779 == env780) = true)

def env781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,9176216,268435456,268570625,268453920,92374096,281601388,525568,268451840,34359738368,25733062]

theorem envBound781 : H12AffineFastState.Bounded env781 := by
  intro p hp
  have h : env781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans780_781 : H12AffineEnvironment.transform 29 268453920 env780 = env781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 268453920 env780 == env781) = true)

def env782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,8914000,9176216,268435456,268570625,268453920,17399808,281601388,525568,268451840,34359738368,25733062]

theorem envBound782 : H12AffineFastState.Bounded env782 := by
  intro p hp
  have h : env782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans781_782 : H12AffineEnvironment.transform 25 8914000 env781 = env782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914000 env781 == env782) = true)

def env783 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,8914000,9176216,16384,151553,2080,17399808,13149548,525568,0,34359738368,25733062]

theorem envBound783 : H12AffineFastState.Bounded env783 := by
  intro p hp
  have h : env783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans782_783 : H12AffineEnvironment.transform 27 16384 env782 = env783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16384 env782 == env783) = true)

def env784 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,8388608,16777216,8328,8914000,9176216,16384,151553,2080,17375732,13108376,525568,0,34359738368,25691698]

theorem envBound784 : H12AffineFastState.Bounded env784 := by
  intro p hp
  have h : env784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans783_784 : H12AffineEnvironment.transform 14 8692 env783 = env784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8692 env783 == env784) = true)

def env785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,147520,16777216,8328,672784,935128,16384,151553,2080,17375732,4867288,525568,0,34359738368,17450610]

theorem envBound785 : H12AffineFastState.Bounded env785 := by
  intro p hp
  have h : env785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans784_785 : H12AffineEnvironment.transform 22 147520 env784 = env785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147520 env784 == env785) = true)

def env786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,4194304,147520,16777216,8328,147472,409816,16384,151553,2080,16852468,4341976,256,0,34359738368,16925298]

theorem envBound786 : H12AffineFastState.Bounded env786 := by
  intro p hp
  have h : env786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans785_786 : H12AffineEnvironment.transform 18 1024 env785 = env786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env785 == env786) = true)

def env787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,4194304,147520,16777216,8328,147472,409816,16384,151553,2080,16852468,4341976,256,0,131072,16925298]

theorem envBound787 : H12AffineFastState.Bounded env787 := by
  intro p hp
  have h : env787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans786_787 : H12AffineEnvironment.transform 34 131072 env786 = env787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env786 == env787) = true)

theorem identity787 : scanCanonicalize (H12AffineFastState.compose env787 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 204976) := by decide +kernel

theorem selectedBound787 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,4194304,147520,204976,8328,147472,409816,16384,151553,2080,132420,4341976,256,0,131072,90818]

theorem envBound788 : H12AffineFastState.Bounded env788 := by
  intro p hp
  have h : env788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans787_788 : H12AffineEnvironment.transform 23 204976 env787 = env788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 204976 env787 == env788) = true)

theorem identity788 : scanCanonicalize (H12AffineFastState.compose env788 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 293) := by decide +kernel

theorem selectedBound788 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,293,147520,204976,8328,147472,409816,16384,151553,2080,132420,147965,256,0,131072,90818]

theorem envBound789 : H12AffineFastState.Bounded env789 := by
  intro p hp
  have h : env789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans788_789 : H12AffineEnvironment.transform 21 293 env788 = env789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 293 env788 == env789) = true)

def env790 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,16892,262144,1024,8692,2097152,293,444,90444,8328,492,262436,16384,4605,2080,17592,1,256,0,16892,90818]

theorem envBound790 : H12AffineFastState.Bounded env790 := by
  intro p hp
  have h : env790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans789_790 : H12AffineEnvironment.transform 16 16892 env789 = env790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16892 env789 == env790) = true)

theorem identity790 : scanCanonicalize (H12AffineFastState.compose env790 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8575) := by decide +kernel

theorem selectedBound790 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8575,16892,262144,1024,8692,2097152,293,444,16435,8328,492,262436,16384,4605,2080,17592,1,256,0,16892,17341]

theorem envBound791 : H12AffineFastState.Bounded env791 := by
  intro p hp
  have h : env791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans790_791 : H12AffineEnvironment.transform 15 8575 env790 = env791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8575 env790 == env791) = true)

def env792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,16893,262144,1024,8692,2097152,293,445,90445,8328,493,262437,16384,4604,2080,17593,0,256,0,16893,90818]

theorem envBound792 : H12AffineFastState.Bounded env792 := by
  intro p hp
  have h : env792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans789_792 : H12AffineEnvironment.transform 16 16893 env789 = env792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16893 env789 == env792) = true)

theorem identity792 : scanCanonicalize (H12AffineFastState.compose env792 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 445) := by decide +kernel

theorem selectedBound792 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,445,8692,65536,64,262144,1024,8692,2097152,293,445,73968,8328,493,262437,445,4604,2080,1284,0,256,0,64,74623]

theorem envBound793 : H12AffineFastState.Bounded env793 := by
  intro p hp
  have h : env793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans792_793 : H12AffineEnvironment.transform 13 445 env792 = env793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 445 env792 == env793) = true)

theorem identity793 : scanCanonicalize (H12AffineFastState.compose env793 (packedSelected [15,18,23,38] rootPS)) = affineNative (2^(17+1) ^^^ 2264) := by decide +kernel

theorem selectedBound793 : packedSelected [15,18,23,38] rootPS < 2^1333 := by decide +kernel

def env794 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,445,8692,65536,64,2264,1024,8692,2097152,293,445,73968,8328,493,2557,445,4604,2080,1284,0,256,0,64,74623]

theorem envBound794 : H12AffineFastState.Bounded env794 := by
  intro p hp
  have h : env794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans793_794 : H12AffineEnvironment.transform 17 2264 env793 = env794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2264 env793 == env794) = true)

theorem identity794 : scanCanonicalize (H12AffineFastState.compose env794 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 8314) := by decide +kernel

theorem selectedBound794 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,445,8692,8314,64,2264,1024,8692,2097152,293,445,138,8328,493,2557,445,4604,2080,1284,0,256,0,64,773]

theorem envBound795 : H12AffineFastState.Bounded env795 := by
  intro p hp
  have h : env795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans794_795 : H12AffineEnvironment.transform 15 8314 env794 = env795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8314 env794 == env795) = true)

theorem identity795 : scanCanonicalize (H12AffineFastState.compose env795 (packedSelected [0,4,5,7,8,9,13,17] rootPS)) = affineNative (2^(20+1) ^^^ 11439) := by decide +kernel

theorem selectedBound795 : packedSelected [0,4,5,7,8,9,13,17] rootPS < 2^1333 := by decide +kernel

def env796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,445,8692,8314,64,2264,1024,8692,11439,293,445,138,8328,493,2557,445,4604,2080,1284,0,256,0,64,773]

theorem envBound796 : H12AffineFastState.Bounded env796 := by
  intro p hp
  have h : env796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans795_796 : H12AffineEnvironment.transform 20 11439 env795 = env796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 11439 env795 == env796) = true)

theorem identity796 : scanCanonicalize (H12AffineFastState.compose env796 (packedSelected [0,4,7,9,10,13,18] rootPS)) = affineNative (2^(12+1) ^^^ 3117) := by decide +kernel

theorem selectedBound796 : packedSelected [0,4,7,9,10,13,18] rootPS < 2^1333 := by decide +kernel

def env797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3117,445,3545,3159,64,2264,1024,3545,130,293,445,138,3237,493,2557,445,4604,2080,1284,0,256,0,64,773]

theorem envBound797 : H12AffineFastState.Bounded env797 := by
  intro p hp
  have h : env797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans796_797 : H12AffineEnvironment.transform 12 3117 env796 = env797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3117 env796 == env797) = true)

theorem identity797 : scanCanonicalize (H12AffineFastState.compose env797 (packedSelected [0,1,2,5,6,7,11,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound797 : packedSelected [0,1,2,5,6,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env798 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,3117,185,3293,3159,64,2264,1024,3293,130,33,185,138,3237,233,2297,185,4344,2080,1024,0,4,0,64,513]

theorem envBound798 : H12AffineFastState.Bounded env798 := by
  intro p hp
  have h : env798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans797_798 : H12AffineEnvironment.transform 7 4 env797 = env798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env797 == env798) = true)

theorem identity798 : scanCanonicalize (H12AffineFastState.compose env798 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 1709) := by decide +kernel

theorem selectedBound798 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env799 : List Nat := [2,4,8,16,32,64,128,4,512,1024,1709,4096,640,185,624,762,64,1653,1024,624,130,33,185,138,520,233,1620,185,4344,1677,1024,0,4,0,64,513]

theorem envBound799 : H12AffineFastState.Bounded env799 := by
  intro p hp
  have h : env799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans798_799 : H12AffineEnvironment.transform 10 1709 env798 = env799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1709 env798 == env799) = true)

theorem identity799 : scanCanonicalize (H12AffineFastState.compose env799 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 1676) := by decide +kernel

theorem selectedBound799 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env800 : List Nat := [2,4,8,16,32,64,128,4,512,1024,1709,1676,640,185,624,762,64,1653,1024,624,130,33,185,138,520,233,1620,185,1652,1677,1024,0,4,0,64,513]

theorem envBound800 : H12AffineFastState.Bounded env800 := by
  intro p hp
  have h : env800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans799_800 : H12AffineEnvironment.transform 11 1676 env799 = env800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1676 env799 == env800) = true)

theorem identity800 : scanCanonicalize (H12AffineFastState.compose env800 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound800 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env801 : List Nat := [2,4,8,16,32,64,24,4,512,1024,1589,1556,536,33,624,610,64,1653,1024,624,26,33,33,18,520,113,1620,33,1652,1557,1024,0,4,0,64,513]

theorem envBound801 : H12AffineFastState.Bounded env801 := by
  intro p hp
  have h : env801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans800_801 : H12AffineEnvironment.transform 6 24 env800 = env801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env800 == env801) = true)

theorem identity801 : scanCanonicalize (H12AffineFastState.compose env801 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 622) := by decide +kernel

theorem selectedBound801 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env802 : List Nat := [2,4,8,16,32,64,24,4,512,622,91,122,536,33,624,610,64,27,622,624,26,33,33,18,520,113,58,33,26,123,622,0,4,0,64,513]

theorem envBound802 : H12AffineFastState.Bounded env802 := by
  intro p hp
  have h : env802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans801_802 : H12AffineEnvironment.transform 9 622 env801 = env802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 622 env801 == env802) = true)

theorem identity802 : scanCanonicalize (H12AffineFastState.compose env802 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound802 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env803 : List Nat := [2,4,8,16,32,59,24,4,512,533,32,1,536,33,523,537,59,27,533,523,26,33,33,18,520,10,58,33,26,0,533,0,4,0,59,513]

theorem envBound803 : H12AffineFastState.Bounded env803 := by
  intro p hp
  have h : env803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans802_803 : H12AffineEnvironment.transform 5 59 env802 = env803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env802 == env803) = true)

theorem identity803 : scanCanonicalize (H12AffineFastState.compose env803 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound803 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env804 : List Nat := [2,4,8,16,32,59,24,4,33,52,32,1,57,33,42,56,59,27,52,42,26,33,33,18,41,10,58,33,26,0,52,0,4,0,59,32]

theorem envBound804 : H12AffineFastState.Bounded env804 := by
  intro p hp
  have h : env804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans803_804 : H12AffineEnvironment.transform 8 33 env803 = env804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env803 == env804) = true)

theorem identity804 : scanCanonicalize (H12AffineFastState.compose env804 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 31) := by decide +kernel

theorem selectedBound804 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env805 : List Nat := [2,4,8,16,31,4,24,4,30,11,31,1,6,30,21,7,4,27,11,21,26,30,30,18,22,10,5,30,26,0,11,0,4,0,4,31]

theorem envBound805 : H12AffineFastState.Bounded env805 := by
  intro p hp
  have h : env805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans804_805 : H12AffineEnvironment.transform 4 31 env804 = env805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 31 env804 == env805) = true)

def env806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,4194304,147520,16777216,8328,147472,409816,16384,151553,2080,16852468,4341976,256,0,131073,16925298]

theorem envBound806 : H12AffineFastState.Bounded env806 := by
  intro p hp
  have h : env806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans786_806 : H12AffineEnvironment.transform 34 131073 env786 = env806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env786 == env806) = true)

theorem identity806 : scanCanonicalize (H12AffineFastState.compose env806 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 2306224) := by decide +kernel

theorem selectedBound806 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,4194304,147520,2306224,8328,147472,409816,16384,151553,2080,2233668,4341976,256,0,131073,2192066]

theorem envBound807 : H12AffineFastState.Bounded env807 := by
  intro p hp
  have h : env807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans806_807 : H12AffineEnvironment.transform 23 2306224 env806 = env807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2306224 env806 == env807) = true)

theorem identity807 : scanCanonicalize (H12AffineFastState.compose env807 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 8314) := by decide +kernel

theorem selectedBound807 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8314,131072,262144,1024,8692,2097152,4194304,147520,2232522,8328,147472,409816,16384,151553,2080,2233668,4341976,256,0,131073,2118328]

theorem envBound808 : H12AffineFastState.Bounded env808 := by
  intro p hp
  have h : env808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans807_808 : H12AffineEnvironment.transform 15 8314 env807 = env808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8314 env807 == env808) = true)

def env809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8314,131072,262144,1024,8692,2097152,2232416,147520,2232522,8328,147472,409816,16384,151553,2080,2233668,2117816,256,0,131073,2118328]

theorem envBound809 : H12AffineFastState.Bounded env809 := by
  intro p hp
  have h : env809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans808_809 : H12AffineEnvironment.transform 21 2232416 env808 = env809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2232416 env808 == env809) = true)

theorem identity809 : scanCanonicalize (H12AffineFastState.compose env809 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound809 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env810 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8433,8314,131072,262144,1024,8433,2097152,2232416,147520,2232522,8328,147472,409816,16384,151553,2080,2233409,2117816,5,0,131073,2118328]

theorem envBound810 : H12AffineFastState.Bounded env810 := by
  intro p hp
  have h : env810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans809_810 : H12AffineEnvironment.transform 7 5 env809 = env810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env809 == env810) = true)

theorem identity810 : scanCanonicalize (H12AffineFastState.compose env810 (packedSelected [4,9,17,18,19,20,21,23,26] rootPS)) = affineNative (2^(20+1) ^^^ 20664) := by decide +kernel

theorem selectedBound810 : packedSelected [4,9,17,18,19,20,21,23,26] rootPS < 2^1333 := by decide +kernel

def env811 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8433,8314,131072,262144,1024,8433,20664,147672,147520,147570,8328,147472,409816,16384,151553,2080,148729,0,5,0,131073,512]

theorem envBound811 : H12AffineFastState.Bounded env811 := by
  intro p hp
  have h : env811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans810_811 : H12AffineEnvironment.transform 20 20664 env810 = env811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 20664 env810 == env811) = true)

theorem identity811 : scanCanonicalize (H12AffineFastState.compose env811 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 16632) := by decide +kernel

theorem selectedBound811 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env812 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8433,8314,16632,262144,1024,8433,20664,32,184,138,8328,232,262176,16384,4345,2080,1025,0,5,0,16633,512]

theorem envBound812 : H12AffineFastState.Bounded env812 := by
  intro p hp
  have h : env812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans811_812 : H12AffineEnvironment.transform 16 16632 env811 = env812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16632 env811 == env812) = true)

theorem identity812 : scanCanonicalize (H12AffineFastState.compose env812 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 7310) := by decide +kernel

theorem selectedBound812 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env813 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,7310,16384,7295,7412,16632,262144,1024,7295,20664,32,184,138,7174,232,262176,16384,4345,2080,1025,0,5,0,16633,512]

theorem envBound813 : H12AffineFastState.Bounded env813 := by
  intro p hp
  have h : env813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans812_813 : H12AffineEnvironment.transform 12 7310 env812 = env813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7310 env812 == env813) = true)

theorem identity813 : scanCanonicalize (H12AffineFastState.compose env813 (packedSelected [3,8,10] rootPS)) = affineNative (2^(17+1) ^^^ 2264) := by decide +kernel

theorem selectedBound813 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env814 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,7310,16384,7295,7412,16632,2264,1024,7295,20664,32,184,138,7174,232,2296,16384,4345,2080,1025,0,5,0,16633,512]

theorem envBound814 : H12AffineFastState.Bounded env814 := by
  intro p hp
  have h : env814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans813_814 : H12AffineEnvironment.transform 17 2264 env813 = env814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2264 env813 == env814) = true)

theorem identity814 : scanCanonicalize (H12AffineFastState.compose env814 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 152) := by decide +kernel

theorem selectedBound814 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env815 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,152,3094,16384,3303,3180,16632,2264,1024,3303,16416,32,184,138,3230,232,2296,16384,97,2080,1025,0,5,0,16633,512]

theorem envBound815 : H12AffineFastState.Bounded env815 := by
  intro p hp
  have h : env815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans814_815 : H12AffineEnvironment.transform 11 152 env814 = env815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 152 env814 == env815) = true)

theorem identity815 : scanCanonicalize (H12AffineFastState.compose env815 (packedSelected [1,3,6] rootPS)) = affineNative (2^(13+1) ^^^ 2259) := by decide +kernel

theorem selectedBound815 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env816 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,152,3094,2259,3303,3180,2091,2264,1024,3303,2291,32,184,138,3230,232,2296,2259,97,2080,1025,0,5,0,2090,512]

theorem envBound816 : H12AffineFastState.Bounded env816 := by
  intro p hp
  have h : env816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans815_816 : H12AffineEnvironment.transform 13 2259 env815 = env816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2259 env815 == env816) = true)

theorem identity816 : scanCanonicalize (H12AffineFastState.compose env816 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 96) := by decide +kernel

theorem selectedBound816 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env817 : List Nat := [2,4,8,16,32,64,128,5,512,1024,96,152,1142,179,1159,1036,75,184,1024,1159,147,32,184,138,1278,232,152,179,97,64,1025,0,5,0,74,512]

theorem envBound817 : H12AffineFastState.Bounded env817 := by
  intro p hp
  have h : env817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans816_817 : H12AffineEnvironment.transform 10 96 env816 = env817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 96 env816 == env817) = true)

theorem identity817 : scanCanonicalize (H12AffineFastState.compose env817 (packedSelected [0,1,2,3,4,11] rootPS)) = affineNative (2^(9+1) ^^^ 78) := by decide +kernel

theorem selectedBound817 : packedSelected [0,1,2,3,4,11] rootPS < 2^1333 := by decide +kernel

def env818 : List Nat := [2,4,8,16,32,64,128,5,512,78,96,152,56,179,201,66,75,184,78,201,147,32,184,138,176,232,152,179,97,64,79,0,5,0,74,512]

theorem envBound818 : H12AffineFastState.Bounded env818 := by
  intro p hp
  have h : env818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans817_818 : H12AffineEnvironment.transform 9 78 env817 = env818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 78 env817 == env818) = true)

theorem identity818 : scanCanonicalize (H12AffineFastState.compose env818 (packedSelected [1,2,5,12] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound818 : packedSelected [1,2,5,12] rootPS < 2^1333 := by decide +kernel

def env819 : List Nat := [2,4,8,11,32,64,128,5,512,78,96,131,35,168,201,66,75,163,78,201,136,32,163,138,171,232,131,168,97,64,79,0,5,0,74,512]

theorem envBound819 : H12AffineFastState.Bounded env819 := by
  intro p hp
  have h : env819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans818_819 : H12AffineEnvironment.transform 3 11 env818 = env819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env818 == env819) = true)

theorem identity819 : scanCanonicalize (H12AffineFastState.compose env819 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound819 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env820 : List Nat := [2,4,8,11,11,64,128,5,512,78,75,131,8,131,201,66,75,136,78,201,136,11,136,138,128,195,131,131,74,64,79,0,5,0,74,512]

theorem envBound820 : H12AffineFastState.Bounded env820 := by
  intro p hp
  have h : env820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans819_820 : H12AffineEnvironment.transform 4 11 env819 = env820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env819 == env820) = true)

theorem identity820 : scanCanonicalize (H12AffineFastState.compose env820 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound820 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env821 : List Nat := [2,4,8,11,11,64,3,5,512,78,75,0,8,0,74,66,75,11,78,74,11,11,11,9,3,64,0,0,74,64,79,0,5,0,74,512]

theorem envBound821 : H12AffineFastState.Bounded env821 := by
  intro p hp
  have h : env821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans820_821 : H12AffineEnvironment.transform 6 3 env820 = env821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env820 == env821) = true)

theorem identity821 : scanCanonicalize (H12AffineFastState.compose env821 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound821 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env822 : List Nat := [2,4,5,6,6,64,3,5,512,67,70,0,5,0,71,66,70,6,67,71,6,6,6,4,3,64,0,0,71,64,66,0,5,0,71,512]

theorem envBound822 : H12AffineFastState.Bounded env822 := by
  intro p hp
  have h : env822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans821_822 : H12AffineEnvironment.transform 2 5 env821 = env822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env821 == env822) = true)

theorem identity822 : scanCanonicalize (H12AffineFastState.compose env822 (packedSelected [0,1,5] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound822 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env823 : List Nat := [2,4,5,6,6,6,3,5,512,5,0,0,5,0,1,4,0,6,5,1,6,6,6,4,3,6,0,0,1,6,4,0,5,0,1,512]

theorem envBound823 : H12AffineFastState.Bounded env823 := by
  intro p hp
  have h : env823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans822_823 : H12AffineEnvironment.transform 5 6 env822 = env823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env822 == env823) = true)

def env824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8314,131072,262144,1024,8692,2097152,2232417,147520,2232522,8328,147472,409816,16384,151553,2080,2233668,2117817,256,0,131073,2118328]

theorem envBound824 : H12AffineFastState.Bounded env824 := by
  intro p hp
  have h : env824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans808_824 : H12AffineEnvironment.transform 21 2232417 env808 = env824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2232417 env808 == env824) = true)

theorem identity824 : scanCanonicalize (H12AffineFastState.compose env824 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 20925) := by decide +kernel

theorem selectedBound824 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8314,131072,262144,1024,8692,20925,147932,147520,147831,8328,147472,409816,16384,151553,2080,148729,260,256,0,131073,773]

theorem envBound825 : H12AffineFastState.Bounded env825 := by
  intro p hp
  have h : env825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans824_825 : H12AffineEnvironment.transform 20 20925 env824 = env825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 20925 env824 == env825) = true)

theorem identity825 : scanCanonicalize (H12AffineFastState.compose env825 (packedSelected [4,9,17,18,19,20,21,23,26] rootPS)) = affineNative (2^(17+1) ^^^ 2264) := by decide +kernel

theorem selectedBound825 : packedSelected [4,9,17,18,19,20,21,23,26] rootPS < 2^1333 := by decide +kernel

def env826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8314,131072,2264,1024,8692,20925,147932,147520,147831,8328,147472,149504,16384,151553,2080,148729,260,256,0,131073,773]

theorem envBound826 : H12AffineFastState.Bounded env826 := by
  intro p hp
  have h : env826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans825_826 : H12AffineEnvironment.transform 17 2264 env825 = env826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2264 env825 == env826) = true)

theorem identity826 : scanCanonicalize (H12AffineFastState.compose env826 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 16385) := by decide +kernel

theorem selectedBound826 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8314,16385,2264,1024,8692,20925,477,65,374,8328,17,2049,16384,4096,2080,1272,260,256,0,16384,773]

theorem envBound827 : H12AffineFastState.Bounded env827 := by
  intro p hp
  have h : env827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans826_827 : H12AffineEnvironment.transform 16 16385 env826 = env827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16385 env826 == env827) = true)

theorem identity827 : scanCanonicalize (H12AffineFastState.compose env827 (packedSelected [17,21] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound827 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env828 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8433,8314,16385,2264,1024,8433,20664,216,65,115,8328,17,2049,16384,4096,2080,1272,1,5,0,16384,512]

theorem envBound828 : H12AffineFastState.Bounded env828 := by
  intro p hp
  have h : env828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans827_828 : H12AffineEnvironment.transform 7 5 env827 = env828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env827 == env828) = true)

theorem identity828 : scanCanonicalize (H12AffineFastState.compose env828 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 5213) := by decide +kernel

theorem selectedBound828 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env829 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,5213,16384,5292,5159,16385,2264,1024,5292,20664,216,65,115,5333,17,2049,16384,4096,2080,1272,1,5,0,16384,512]

theorem envBound829 : H12AffineFastState.Bounded env829 := by
  intro p hp
  have h : env829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans828_829 : H12AffineEnvironment.transform 12 5213 env828 = env829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5213 env828 == env829) = true)

theorem identity829 : scanCanonicalize (H12AffineFastState.compose env829 (packedSelected [1,3,4,5,7,8,10] rootPS)) = affineNative (2^(13+1) ^^^ 194) := by decide +kernel

theorem selectedBound829 : packedSelected [1,3,4,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env830 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,5213,194,5292,5159,195,2264,1024,5292,4218,216,65,115,5333,17,2049,194,4096,2080,1272,1,5,0,194,512]

theorem envBound830 : H12AffineFastState.Bounded env830 := by
  intro p hp
  have h : env830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans829_830 : H12AffineEnvironment.transform 13 194 env829 = env830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 194 env829 == env830) = true)

theorem identity830 : scanCanonicalize (H12AffineFastState.compose env830 (packedSelected [0,1,4,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 1109) := by decide +kernel

theorem selectedBound830 : packedSelected [0,1,4,8,11] rootPS < 2^1333 := by decide +kernel

def env831 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,1109,8,194,249,114,195,2264,1024,249,1071,216,65,115,128,17,2049,194,1109,2080,1272,1,5,0,194,512]

theorem envBound831 : H12AffineFastState.Bounded env831 := by
  intro p hp
  have h : env831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans830_831 : H12AffineEnvironment.transform 11 1109 env830 = env831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1109 env830 == env831) = true)

theorem identity831 : scanCanonicalize (H12AffineFastState.compose env831 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound831 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env832 : List Nat := [2,4,8,16,32,64,121,5,512,1024,2048,1109,8,59,0,114,58,2081,1024,0,1071,33,65,115,121,17,2049,59,1109,2080,1025,1,5,0,59,512]

theorem envBound832 : H12AffineFastState.Bounded env832 := by
  intro p hp
  have h : env832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans831_832 : H12AffineEnvironment.transform 6 121 env831 = env832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env831 == env832) = true)

theorem identity832 : scanCanonicalize (H12AffineFastState.compose env832 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound832 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env833 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,1028,8,59,0,35,58,2081,1024,0,1071,33,16,34,40,17,2049,59,1028,2080,1025,1,5,0,59,512]

theorem envBound833 : H12AffineFastState.Bounded env833 := by
  intro p hp
  have h : env833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans832_833 : H12AffineEnvironment.transform 5 17 env832 = env833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env832 == env833) = true)

theorem identity833 : scanCanonicalize (H12AffineFastState.compose env833 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 544) := by decide +kernel

theorem selectedBound833 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env834 : List Nat := [2,4,8,16,32,17,40,5,512,1024,544,1028,8,59,0,35,58,513,1024,0,1071,33,16,34,40,17,545,59,1028,512,1025,1,5,0,59,512]

theorem envBound834 : H12AffineFastState.Bounded env834 := by
  intro p hp
  have h : env834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans833_834 : H12AffineEnvironment.transform 10 544 env833 = env834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 544 env833 == env834) = true)

theorem identity834 : scanCanonicalize (H12AffineFastState.compose env834 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound834 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env835 : List Nat := [2,4,8,16,32,17,40,5,512,548,544,544,8,59,0,35,58,513,548,0,523,33,16,34,40,17,545,59,544,512,549,1,5,0,59,512]

theorem envBound835 : H12AffineFastState.Bounded env835 := by
  intro p hp
  have h : env835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans834_835 : H12AffineEnvironment.transform 9 548 env834 = env835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env834 == env835) = true)

theorem identity835 : scanCanonicalize (H12AffineFastState.compose env835 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound835 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env836 : List Nat := [2,4,2,16,32,17,34,5,512,548,544,544,2,49,0,35,48,513,548,0,513,33,16,34,34,17,545,49,544,512,549,1,5,0,49,512]

theorem envBound836 : H12AffineFastState.Bounded env836 := by
  intro p hp
  have h : env836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans835_836 : H12AffineEnvironment.transform 2 2 env835 = env836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env835 == env836) = true)

theorem identity836 : scanCanonicalize (H12AffineFastState.compose env836 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound836 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env837 : List Nat := [2,4,2,16,16,17,18,5,512,532,528,528,2,1,0,19,0,513,532,0,513,17,16,18,18,17,529,1,528,512,533,1,5,0,1,512]

theorem envBound837 : H12AffineFastState.Bounded env837 := by
  intro p hp
  have h : env837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans836_837 : H12AffineEnvironment.transform 4 16 env836 = env837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env836 == env837) = true)

theorem identity837 : scanCanonicalize (H12AffineFastState.compose env837 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound837 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env838 : List Nat := [2,4,2,6,6,7,4,5,512,514,518,518,2,1,0,5,0,513,514,0,513,7,6,4,4,7,519,1,518,512,515,1,5,0,1,512]

theorem envBound838 : H12AffineFastState.Bounded env838 := by
  intro p hp
  have h : env838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans837_838 : H12AffineEnvironment.transform 3 6 env837 = env838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env837 == env838) = true)

theorem identity838 : scanCanonicalize (H12AffineFastState.compose env838 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound838 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env839 : List Nat := [2,4,2,6,6,7,4,5,1,3,7,7,2,1,0,5,0,0,3,0,0,7,6,4,4,7,6,1,7,1,2,1,5,0,1,1]

theorem envBound839 : H12AffineFastState.Bounded env839 := by
  intro p hp
  have h : env839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans838_839 : H12AffineEnvironment.transform 8 1 env838 = env839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env838 == env839) = true)

def env840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147520,16777216,8328,147473,409817,16384,151553,2080,16852469,4341977,257,0,34359738368,16925299]

theorem envBound840 : H12AffineFastState.Bounded env840 := by
  intro p hp
  have h : env840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans785_840 : H12AffineEnvironment.transform 18 1025 env785 = env840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env785 == env840) = true)

def env841 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147520,16777216,8328,147473,409817,16384,151553,2080,16852469,4341977,257,0,131072,16925299]

theorem envBound841 : H12AffineFastState.Bounded env841 := by
  intro p hp
  have h : env841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans840_841 : H12AffineEnvironment.transform 34 131072 env840 = env841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env840 == env841) = true)

theorem identity841 : scanCanonicalize (H12AffineFastState.compose env841 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 75248) := by decide +kernel

theorem selectedBound841 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147520,75248,8328,147473,409817,16384,151553,2080,5,4341977,257,0,131072,223107]

theorem envBound842 : H12AffineFastState.Bounded env842 := by
  intro p hp
  have h : env842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans841_842 : H12AffineEnvironment.transform 23 75248 env841 = env842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 75248 env841 == env842) = true)

theorem identity842 : scanCanonicalize (H12AffineFastState.compose env842 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 1061) := by decide +kernel

theorem selectedBound842 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env843 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,1061,147520,75248,8328,147473,409817,16384,151553,2080,5,148732,257,0,131072,223107]

theorem envBound843 : H12AffineFastState.Bounded env843 := by
  intro p hp
  have h : env843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans842_843 : H12AffineEnvironment.transform 21 1061 env842 = env843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1061 env842 == env843) = true)

theorem identity843 : scanCanonicalize (H12AffineFastState.compose env843 (packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 91523) := by decide +kernel

theorem selectedBound843 : packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,91523,262144,1025,8692,2097152,1061,75203,75248,8328,75154,337242,16384,79234,2080,5,74111,257,0,91523,512]

theorem envBound844 : H12AffineFastState.Bounded env844 := by
  intro p hp
  have h : env844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans843_844 : H12AffineEnvironment.transform 16 91523 env843 = env844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 91523 env843 == env844) = true)

theorem identity844 : scanCanonicalize (H12AffineFastState.compose env844 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound844 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env845 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,8192,16384,8692,65536,90503,262144,5,8692,2097152,33,74183,74228,8328,74134,336222,16384,78214,2080,5,74111,257,0,90503,512]

theorem envBound845 : H12AffineFastState.Bounded env845 := by
  intro p hp
  have h : env845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans844_845 : H12AffineEnvironment.transform 9 4 env844 = env845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env844 == env845) = true)

theorem identity845 : scanCanonicalize (H12AffineFastState.compose env845 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound845 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env846 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,8192,16384,8692,8574,16633,262144,5,8692,2097152,33,185,138,8328,232,262176,16384,4344,2080,5,1,257,0,16633,512]

theorem envBound846 : H12AffineFastState.Bounded env846 := by
  intro p hp
  have h : env846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans845_846 : H12AffineEnvironment.transform 15 8574 env845 = env846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env845 == env846) = true)

theorem identity846 : scanCanonicalize (H12AffineFastState.compose env846 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound846 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env847 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,8192,16384,8692,8574,16633,2080,5,8692,2097152,33,185,138,8328,232,2048,16384,4344,2080,5,1,257,0,16633,512]

theorem envBound847 : H12AffineFastState.Bounded env847 := by
  intro p hp
  have h : env847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans846_847 : H12AffineEnvironment.transform 17 2080 env846 = env847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env846 == env847) = true)

theorem identity847 : scanCanonicalize (H12AffineFastState.compose env847 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound847 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env848 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,4096,8192,16384,8200,8322,16633,2080,5,8200,2097152,33,185,138,8328,232,2048,16384,4344,2080,5,1,253,0,16633,512]

theorem envBound848 : H12AffineFastState.Bounded env848 := by
  intro p hp
  have h : env848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans847_848 : H12AffineEnvironment.transform 7 252 env847 = env848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env847 == env848) = true)

theorem identity848 : scanCanonicalize (H12AffineFastState.compose env848 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(20+1) ^^^ 26826) := by decide +kernel

theorem selectedBound848 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env849 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,4096,8192,16384,8200,8322,16633,2080,5,8200,26826,33,185,138,8328,232,2048,16384,4344,2080,5,1,253,0,16633,512]

theorem envBound849 : H12AffineFastState.Bounded env849 := by
  intro p hp
  have h : env849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans848_849 : H12AffineEnvironment.transform 20 26826 env848 = env849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 26826 env848 == env849) = true)

theorem identity849 : scanCanonicalize (H12AffineFastState.compose env849 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 12496) := by decide +kernel

theorem selectedBound849 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env850 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,4096,8192,12496,8200,8322,12329,2080,5,8200,6170,33,185,138,8328,232,2048,12496,4344,2080,5,1,253,0,12329,512]

theorem envBound850 : H12AffineFastState.Bounded env850 := by
  intro p hp
  have h : env850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans849_850 : H12AffineEnvironment.transform 13 12496 env849 = env850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12496 env849 == env850) = true)

theorem identity850 : scanCanonicalize (H12AffineFastState.compose env850 (packedSelected [0,1,2,3,7,12] rootPS)) = affineNative (2^(12+1) ^^^ 2283) := by decide +kernel

theorem selectedBound850 : packedSelected [0,1,2,3,7,12] rootPS < 2^1333 := by decide +kernel

def env851 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,4096,2283,6203,2275,2153,6338,2080,5,2275,6170,33,185,138,2147,232,2048,6203,4344,2080,5,1,253,0,6338,512]

theorem envBound851 : H12AffineFastState.Bounded env851 := by
  intro p hp
  have h : env851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans850_851 : H12AffineEnvironment.transform 12 2283 env850 = env851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2283 env850 == env851) = true)

theorem identity851 : scanCanonicalize (H12AffineFastState.compose env851 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2129) := by decide +kernel

theorem selectedBound851 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env852 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,2129,2283,106,2275,2153,147,2080,5,2275,75,33,185,138,2147,232,2048,106,2217,2080,5,1,253,0,147,512]

theorem envBound852 : H12AffineFastState.Bounded env852 := by
  intro p hp
  have h : env852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans851_852 : H12AffineEnvironment.transform 11 2129 env851 = env852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2129 env851 == env852) = true)

theorem identity852 : scanCanonicalize (H12AffineFastState.compose env852 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound852 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env853 : List Nat := [2,4,8,16,32,64,128,252,512,4,58,107,209,106,217,83,147,26,5,217,75,33,185,138,89,232,58,106,147,26,5,1,253,0,147,512]

theorem envBound853 : H12AffineFastState.Bounded env853 := by
  intro p hp
  have h : env853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans852_853 : H12AffineEnvironment.transform 10 58 env852 = env853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env852 == env853) = true)

theorem identity853 : scanCanonicalize (H12AffineFastState.compose env853 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound853 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env854 : List Nat := [2,4,8,16,32,43,128,151,512,4,58,0,186,1,178,56,147,26,5,178,32,33,185,138,50,131,58,1,147,26,5,1,150,0,147,512]

theorem envBound854 : H12AffineFastState.Bounded env854 := by
  intro p hp
  have h : env854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans853_854 : H12AffineEnvironment.transform 5 43 env853 = env854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env853 == env854) = true)

def env855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147520,16777216,8328,147473,409817,16384,151553,2080,16852469,4341977,257,0,131073,16925299]

theorem envBound855 : H12AffineFastState.Bounded env855 := by
  intro p hp
  have h : env855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans840_855 : H12AffineEnvironment.transform 34 131073 env840 = env855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env840 == env855) = true)

theorem identity855 : scanCanonicalize (H12AffineFastState.compose env855 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 2176496) := by decide +kernel

theorem selectedBound855 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147520,2176496,8328,147473,409817,16384,151553,2080,2101253,4341977,257,0,131073,2324355]

theorem envBound856 : H12AffineFastState.Bounded env856 := by
  intro p hp
  have h : env856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans855_856 : H12AffineEnvironment.transform 23 2176496 env855 = env856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2176496 env855 == env856) = true)

theorem identity856 : scanCanonicalize (H12AffineFastState.compose env856 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(20+1) ^^^ 79227) := by decide +kernel

theorem selectedBound856 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,79227,4194304,147520,139,8328,147473,409817,16384,151553,2080,75134,4341977,257,0,131073,148216]

theorem envBound857 : H12AffineFastState.Bounded env857 := by
  intro p hp
  have h : env857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans856_857 : H12AffineEnvironment.transform 20 79227 env856 = env857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 79227 env856 == env857) = true)

def env858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,79227,32,147520,139,8328,147473,409817,16384,151553,2080,75134,147705,257,0,131073,148216]

theorem envBound858 : H12AffineFastState.Bounded env858 := by
  intro p hp
  have h : env858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans857_858 : H12AffineEnvironment.transform 21 32 env857 = env858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env857 == env858) = true)

theorem identity858 : scanCanonicalize (H12AffineFastState.compose env858 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90502) := by decide +kernel

theorem selectedBound858 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,90502,262144,1025,8692,79227,32,74182,139,8328,74135,336223,16384,78215,2080,75134,74111,257,0,90503,74622]

theorem envBound859 : H12AffineFastState.Bounded env859 := by
  intro p hp
  have h : env859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans858_859 : H12AffineEnvironment.transform 16 90502 env858 = env859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90502 env858 == env859) = true)

theorem identity859 : scanCanonicalize (H12AffineFastState.compose env859 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8663) := by decide +kernel

theorem selectedBound859 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8663,16465,262144,1025,8692,5292,32,17,139,8328,64,262280,16384,4176,2080,1193,168,257,0,16464,681]

theorem envBound860 : H12AffineFastState.Bounded env860 := by
  intro p hp
  have h : env860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans859_860 : H12AffineEnvironment.transform 15 8663 env859 = env860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8663 env859 == env860) = true)

theorem identity860 : scanCanonicalize (H12AffineFastState.compose env860 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,15,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 12573) := by decide +kernel

theorem selectedBound860 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,15,21,23] rootPS < 2^1333 := by decide +kernel

def env861 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12573,8692,8663,12620,262144,1025,8692,5292,32,17,139,8328,64,262280,12573,4176,2080,1193,168,257,0,12621,681]

theorem envBound861 : H12AffineFastState.Bounded env861 := by
  intro p hp
  have h : env861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans860_861 : H12AffineEnvironment.transform 13 12573 env860 = env861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12573 env860 == env861) = true)

theorem identity861 : scanCanonicalize (H12AffineFastState.compose env861 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound861 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env862 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,12573,8541,8574,12620,262144,1025,8541,5125,32,17,34,8225,64,262177,12573,4176,2080,1024,1,257,0,12621,512]

theorem envBound862 : H12AffineFastState.Bounded env862 := by
  intro p hp
  have h : env862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans861_862 : H12AffineEnvironment.transform 6 41 env861 = env862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env861 == env862) = true)

theorem identity862 : scanCanonicalize (H12AffineFastState.compose env862 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound862 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env863 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,12573,8461,8494,12572,262144,1025,8461,5125,32,17,34,8225,16,262177,12573,4096,2080,1024,1,257,0,12573,512]

theorem envBound863 : H12AffineFastState.Bounded env863 := by
  intro p hp
  have h : env863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans862_863 : H12AffineEnvironment.transform 5 16 env862 = env863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env862 == env863) = true)

theorem identity863 : scanCanonicalize (H12AffineFastState.compose env863 (packedSelected [0,2,4,5,6,7,8,9] rootPS)) = affineNative (2^(17+1) ^^^ 8982) := by decide +kernel

theorem selectedBound863 : packedSelected [0,2,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env864 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,12573,8461,8494,12572,8982,1025,8461,5125,32,17,34,8225,16,9015,12573,4096,2080,1024,1,257,0,12573,512]

theorem envBound864 : H12AffineFastState.Bounded env864 := by
  intro p hp
  have h : env864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans863_864 : H12AffineEnvironment.transform 17 8982 env863 = env864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8982 env863 == env864) = true)

theorem identity864 : scanCanonicalize (H12AffineFastState.compose env864 (packedSelected [0,1,3,6,7,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 2871) := by decide +kernel

theorem selectedBound864 : packedSelected [0,1,3,6,7,11,12] rootPS < 2^1333 := by decide +kernel

def env865 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,2871,6698,2618,2585,6699,2081,1025,2618,5125,32,17,34,2838,16,2048,6698,4096,2080,1024,1,257,0,6698,512]

theorem envBound865 : H12AffineFastState.Bounded env865 := by
  intro p hp
  have h : env865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans864_865 : H12AffineEnvironment.transform 12 2871 env864 = env865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2871 env864 == env865) = true)

theorem identity865 : scanCanonicalize (H12AffineFastState.compose env865 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1338) := by decide +kernel

theorem selectedBound865 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env866 : List Nat := [2,4,8,16,32,16,41,256,512,1024,1338,4096,1549,5904,1792,1827,5905,1307,1025,1792,5125,32,17,34,1580,16,1338,5904,4096,1306,1024,1,257,0,5904,512]

theorem envBound866 : H12AffineFastState.Bounded env866 := by
  intro p hp
  have h : env866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans865_866 : H12AffineEnvironment.transform 10 1338 env865 = env866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1338 env865 == env866) = true)

theorem identity866 : scanCanonicalize (H12AffineFastState.compose env866 (packedSelected [1,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 1306) := by decide +kernel

theorem selectedBound866 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env867 : List Nat := [2,4,8,16,32,16,41,256,512,1024,1338,1306,1549,522,1792,1827,523,1307,1025,1792,287,32,17,34,1580,16,1338,522,1306,1306,1024,1,257,0,522,512]

theorem envBound867 : H12AffineFastState.Bounded env867 := by
  intro p hp
  have h : env867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans866_867 : H12AffineEnvironment.transform 11 1306 env866 = env867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1306 env866 == env867) = true)

theorem identity867 : scanCanonicalize (H12AffineFastState.compose env867 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 817) := by decide +kernel

theorem selectedBound867 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env868 : List Nat := [2,4,8,16,32,16,41,256,512,817,523,555,316,522,49,18,523,554,816,49,287,32,17,34,285,16,523,522,555,555,817,1,257,0,522,512]

theorem envBound868 : H12AffineFastState.Bounded env868 := by
  intro p hp
  have h : env868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans867_868 : H12AffineEnvironment.transform 9 817 env867 = env868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 817 env867 == env868) = true)

theorem identity868 : scanCanonicalize (H12AffineFastState.compose env868 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound868 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env869 : List Nat := [2,4,8,16,32,16,41,256,11,314,0,32,316,1,49,18,0,33,315,49,287,32,17,34,285,16,0,1,32,32,314,1,257,0,1,11]

theorem envBound869 : H12AffineFastState.Bounded env869 := by
  intro p hp
  have h : env869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans868_869 : H12AffineEnvironment.transform 8 11 env868 = env869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env868 == env869) = true)

theorem identity869 : scanCanonicalize (H12AffineFastState.compose env869 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound869 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env870 : List Nat := [2,4,8,16,32,16,41,5,11,63,0,32,57,1,49,18,0,33,62,49,26,32,17,34,24,16,0,1,32,32,63,1,4,0,1,11]

theorem envBound870 : H12AffineFastState.Bounded env870 := by
  intro p hp
  have h : env870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans869_870 : H12AffineEnvironment.transform 7 5 env869 = env870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env869 == env870) = true)

theorem identity870 : scanCanonicalize (H12AffineFastState.compose env870 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound870 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env871 : List Nat := [2,4,8,16,16,16,25,5,11,15,0,16,9,1,1,18,0,17,14,1,26,16,17,18,24,16,0,1,16,16,15,1,4,0,1,11]

theorem envBound871 : H12AffineFastState.Bounded env871 := by
  intro p hp
  have h : env871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans870_871 : H12AffineEnvironment.transform 4 16 env870 = env871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env870 == env871) = true)

theorem identity871 : scanCanonicalize (H12AffineFastState.compose env871 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound871 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env872 : List Nat := [2,2,8,16,16,16,25,3,11,9,0,16,9,1,1,18,0,17,8,1,26,16,17,18,24,16,0,1,16,16,9,1,2,0,1,11]

theorem envBound872 : H12AffineFastState.Bounded env872 := by
  intro p hp
  have h : env872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans871_872 : H12AffineEnvironment.transform 1 2 env871 = env872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env871 == env872) = true)

def env873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,79227,33,147520,139,8328,147473,409817,16384,151553,2080,75134,147704,257,0,131073,148216]

theorem envBound873 : H12AffineFastState.Bounded env873 := by
  intro p hp
  have h : env873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans857_873 : H12AffineEnvironment.transform 21 33 env857 = env873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env857 == env873) = true)

theorem identity873 : scanCanonicalize (H12AffineFastState.compose env873 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound873 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,131072,262144,1025,8692,5125,33,147520,139,8328,147473,409817,16384,151553,2080,1024,147704,257,0,131073,148216]

theorem envBound874 : H12AffineFastState.Bounded env874 := by
  intro p hp
  have h : env874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans873_874 : H12AffineEnvironment.transform 15 8574 env873 = env874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env873 == env874) = true)

theorem identity874 : scanCanonicalize (H12AffineFastState.compose env874 (packedSelected [1,5,8,17,19,21,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 16632) := by decide +kernel

theorem selectedBound874 : packedSelected [1,5,8,17,19,21,24,26] rootPS < 2^1333 := by decide +kernel

def env875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,16632,262144,1025,8692,5125,33,184,139,8328,233,262177,16384,4345,2080,1024,0,257,0,16633,512]

theorem envBound875 : H12AffineFastState.Bounded env875 := by
  intro p hp
  have h : env875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans874_875 : H12AffineEnvironment.transform 16 16632 env874 = env875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16632 env874 == env875) = true)

def env876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,147521,16777216,8328,672785,935129,16384,151553,2080,17375732,4867289,525568,0,34359738368,17450611]

theorem envBound876 : H12AffineFastState.Bounded env876 := by
  intro p hp
  have h : env876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans784_876 : H12AffineEnvironment.transform 22 147521 env784 = env876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147521 env784 == env876) = true)

def env877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,4194304,147521,16777216,8328,147473,409817,16384,151553,2080,16852468,4341977,256,0,34359738368,16925299]

theorem envBound877 : H12AffineFastState.Bounded env877 := by
  intro p hp
  have h : env877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans876_877 : H12AffineEnvironment.transform 18 1024 env876 = env877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env876 == env877) = true)

def env878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,4194304,147521,16777216,8328,147473,409817,16384,151553,2080,16852468,4341977,256,0,131072,16925299]

theorem envBound878 : H12AffineFastState.Bounded env878 := by
  intro p hp
  have h : env878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans877_878 : H12AffineEnvironment.transform 34 131072 env877 = env878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env877 == env878) = true)

theorem identity878 : scanCanonicalize (H12AffineFastState.compose env878 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 225505) := by decide +kernel

theorem selectedBound878 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,4194304,147521,225505,8328,147473,409817,16384,151553,2080,152853,4341977,256,0,131072,78482]

theorem envBound879 : H12AffineFastState.Bounded env879 := by
  intro p hp
  have h : env879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans878_879 : H12AffineEnvironment.transform 23 225505 env878 = env879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 225505 env878 == env879) = true)

theorem identity879 : scanCanonicalize (H12AffineFastState.compose env879 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 293) := by decide +kernel

theorem selectedBound879 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,293,147521,225505,8328,147473,409817,16384,151553,2080,152853,147964,256,0,131072,78482]

theorem envBound880 : H12AffineFastState.Bounded env880 := by
  intro p hp
  have h : env880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans879_880 : H12AffineEnvironment.transform 21 293 env879 = env880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 293 env879 == env880) = true)

def env881 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,16892,262144,1024,8692,2097152,293,445,78109,8328,493,262437,16384,4605,2080,5353,0,256,0,16892,78482]

theorem envBound881 : H12AffineFastState.Bounded env881 := by
  intro p hp
  have h : env881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans880_881 : H12AffineEnvironment.transform 16 16892 env880 = env881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16892 env880 == env881) = true)

theorem identity881 : scanCanonicalize (H12AffineFastState.compose env881 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound881 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,8192,16384,8692,65536,16892,262144,1024,8692,2097152,293,445,73968,8328,493,262437,16384,16,2080,1284,0,256,0,16892,74623]

theorem envBound882 : H12AffineFastState.Bounded env882 := by
  intro p hp
  have h : env882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans881_882 : H12AffineEnvironment.transform 11 493 env881 = env882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env881 == env882) = true)

theorem identity882 : scanCanonicalize (H12AffineFastState.compose env882 (packedSelected [3,5,8,10,17,18,19,21,23,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 2524) := by decide +kernel

theorem selectedBound882 : packedSelected [3,5,8,10,17,18,19,21,23,26,28,31] rootPS < 2^1333 := by decide +kernel

def env883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,8192,16384,8692,65536,16892,2524,1024,8692,2097152,293,445,73968,8328,493,2297,16384,16,2080,1284,0,256,0,16892,74623]

theorem envBound883 : H12AffineFastState.Bounded env883 := by
  intro p hp
  have h : env883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans882_883 : H12AffineEnvironment.transform 17 2524 env882 = env883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2524 env882 == env883) = true)

theorem identity883 : scanCanonicalize (H12AffineFastState.compose env883 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound883 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env884 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,232,8192,16384,8433,65536,16633,2265,1024,8433,2097152,32,184,73968,8328,232,2297,16384,16,2080,1025,0,5,0,16633,74362]

theorem envBound884 : H12AffineFastState.Bounded env884 := by
  intro p hp
  have h : env884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans883_884 : H12AffineEnvironment.transform 7 5 env883 = env884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env883 == env884) = true)

theorem identity884 : scanCanonicalize (H12AffineFastState.compose env884 (packedSelected [2,6,11,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 8315) := by decide +kernel

theorem selectedBound884 : packedSelected [2,6,11,15,17] rootPS < 2^1333 := by decide +kernel

def env885 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,232,8192,16384,8433,8315,16633,2265,1024,8433,2097152,32,184,139,8328,232,2297,16384,16,2080,1025,0,5,0,16633,513]

theorem envBound885 : H12AffineFastState.Bounded env885 := by
  intro p hp
  have h : env885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans884_885 : H12AffineEnvironment.transform 15 8315 env884 = env885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8315 env884 == env885) = true)

theorem identity885 : scanCanonicalize (H12AffineFastState.compose env885 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(20+1) ^^^ 3766) := by decide +kernel

theorem selectedBound885 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env886 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,232,8192,16384,8433,8315,16633,2265,1024,8433,3766,32,184,139,8328,232,2297,16384,16,2080,1025,0,5,0,16633,513]

theorem envBound886 : H12AffineFastState.Bounded env886 := by
  intro p hp
  have h : env886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans885_886 : H12AffineEnvironment.transform 20 3766 env885 = env886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 3766 env885 == env886) = true)

theorem identity886 : scanCanonicalize (H12AffineFastState.compose env886 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(13+1) ^^^ 2297) := by decide +kernel

theorem selectedBound886 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env887 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,232,8192,2297,8433,8315,2048,2265,1024,8433,3766,32,184,139,8328,232,2297,2297,16,2080,1025,0,5,0,2048,513]

theorem envBound887 : H12AffineFastState.Bounded env887 := by
  intro p hp
  have h : env887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans886_887 : H12AffineEnvironment.transform 13 2297 env886 = env887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2297 env886 == env887) = true)

theorem identity887 : scanCanonicalize (H12AffineFastState.compose env887 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 1671) := by decide +kernel

theorem selectedBound887 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env888 : List Nat := [2,4,8,16,32,64,128,5,512,1024,1671,232,8192,1662,8433,8315,1671,1630,1024,8433,49,32,184,139,8328,232,1662,1662,16,1703,1025,0,5,0,1671,513]

theorem envBound888 : H12AffineFastState.Bounded env888 := by
  intro p hp
  have h : env888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans887_888 : H12AffineEnvironment.transform 10 1671 env887 = env888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1671 env887 == env888) = true)

theorem identity888 : scanCanonicalize (H12AffineFastState.compose env888 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 1236) := by decide +kernel

theorem selectedBound888 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env889 : List Nat := [2,4,8,16,32,64,128,5,512,1024,1671,232,1236,1662,1061,1199,1671,1630,1024,1061,49,32,184,139,1116,232,1662,1662,16,1703,1025,0,5,0,1671,513]

theorem envBound889 : H12AffineFastState.Bounded env889 := by
  intro p hp
  have h : env889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans888_889 : H12AffineEnvironment.transform 12 1236 env888 = env889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1236 env888 == env889) = true)

theorem identity889 : scanCanonicalize (H12AffineFastState.compose env889 (packedSelected [0,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 678) := by decide +kernel

theorem selectedBound889 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env890 : List Nat := [2,4,8,16,32,64,128,5,512,678,33,232,626,216,643,521,33,248,678,643,49,32,184,139,762,232,216,216,16,1,679,0,5,0,33,513]

theorem envBound890 : H12AffineFastState.Bounded env890 := by
  intro p hp
  have h : env890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans889_890 : H12AffineEnvironment.transform 9 678 env889 = env890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 678 env889 == env890) = true)

theorem identity890 : scanCanonicalize (H12AffineFastState.compose env890 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound890 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env891 : List Nat := [2,4,8,16,32,49,128,5,512,678,33,153,515,169,643,521,33,137,678,643,49,32,184,139,651,153,169,169,16,1,679,0,5,0,33,513]

theorem envBound891 : H12AffineFastState.Bounded env891 := by
  intro p hp
  have h : env891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans890_891 : H12AffineEnvironment.transform 5 49 env890 = env891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env890 == env891) = true)

theorem identity891 : scanCanonicalize (H12AffineFastState.compose env891 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound891 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env892 : List Nat := [2,4,8,16,32,49,128,5,43,141,33,153,40,169,168,34,33,137,141,168,49,32,184,139,160,153,169,169,16,1,140,0,5,0,33,42]

theorem envBound892 : H12AffineFastState.Bounded env892 := by
  intro p hp
  have h : env892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans891_892 : H12AffineEnvironment.transform 8 43 env891 = env892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env891 == env892) = true)

theorem identity892 : scanCanonicalize (H12AffineFastState.compose env892 (packedSelected [1,6] rootPS)) = affineNative (2^(6+1) ^^^ 26) := by decide +kernel

theorem selectedBound892 : packedSelected [1,6] rootPS < 2^1333 := by decide +kernel

def env893 : List Nat := [2,4,8,16,32,49,26,5,43,23,33,3,40,51,50,34,33,19,23,50,49,32,34,17,58,3,51,51,16,1,22,0,5,0,33,42]

theorem envBound893 : H12AffineFastState.Bounded env893 := by
  intro p hp
  have h : env893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans892_893 : H12AffineEnvironment.transform 6 26 env892 = env893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 26 env892 == env893) = true)

theorem identity893 : scanCanonicalize (H12AffineFastState.compose env893 (packedSelected [1,11] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound893 : packedSelected [1,11] rootPS < 2^1333 := by decide +kernel

def env894 : List Nat := [2,4,8,3,32,34,9,5,43,4,33,3,40,32,33,34,33,0,4,33,34,32,34,2,41,3,32,32,3,1,5,0,5,0,33,42]

theorem envBound894 : H12AffineFastState.Bounded env894 := by
  intro p hp
  have h : env894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans893_894 : H12AffineEnvironment.transform 3 3 env893 = env894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env893 == env894) = true)

theorem identity894 : scanCanonicalize (H12AffineFastState.compose env894 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound894 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env895 : List Nat := [2,4,8,3,3,1,9,5,8,4,2,3,11,3,2,1,2,0,4,2,1,3,1,2,10,3,3,3,3,1,5,0,5,0,2,9]

theorem envBound895 : H12AffineFastState.Bounded env895 := by
  intro p hp
  have h : env895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans894_895 : H12AffineEnvironment.transform 4 3 env894 = env895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env894 == env895) = true)

theorem identity895 : scanCanonicalize (H12AffineFastState.compose env895 (packedSelected [12] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound895 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env896 : List Nat := [1,4,8,0,0,1,9,5,8,4,1,0,8,0,1,1,1,0,4,1,1,0,1,1,9,0,0,0,0,1,5,0,5,0,1,9]

theorem envBound896 : H12AffineFastState.Bounded env896 := by
  intro p hp
  have h : env896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans895_896 : H12AffineEnvironment.transform 0 1 env895 = env896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env895 == env896) = true)

theorem identity896 : scanCanonicalize (H12AffineFastState.compose env896 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound896 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env897 : List Nat := [1,4,5,0,0,1,4,5,5,4,1,0,5,0,1,1,1,0,4,1,1,0,1,1,4,0,0,0,0,1,5,0,5,0,1,4]

theorem envBound897 : H12AffineFastState.Bounded env897 := by
  intro p hp
  have h : env897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans896_897 : H12AffineEnvironment.transform 2 5 env896 = env897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env896 == env897) = true)

def env898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,16893,262144,1024,8692,2097152,293,444,78108,8328,492,262436,16384,4604,2080,5352,1,256,0,16893,78482]

theorem envBound898 : H12AffineFastState.Bounded env898 := by
  intro p hp
  have h : env898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans880_898 : H12AffineEnvironment.transform 16 16893 env880 = env898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16893 env880 == env898) = true)

theorem identity898 : scanCanonicalize (H12AffineFastState.compose env898 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8575) := by decide +kernel

theorem selectedBound898 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8575,16893,262144,1024,8692,2097152,293,444,4195,8328,492,262436,16384,4604,2080,5352,1,256,0,16893,5101]

theorem envBound899 : H12AffineFastState.Bounded env899 := by
  intro p hp
  have h : env899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans898_899 : H12AffineEnvironment.transform 15 8575 env898 = env899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8575 env898 == env899) = true)

def env900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,4194304,147521,16777216,8328,147473,409817,16384,151553,2080,16852468,4341977,256,0,131073,16925299]

theorem envBound900 : H12AffineFastState.Bounded env900 := by
  intro p hp
  have h : env900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans877_900 : H12AffineEnvironment.transform 34 131073 env877 = env900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env877 == env900) = true)

theorem identity900 : scanCanonicalize (H12AffineFastState.compose env900 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 2318561) := by decide +kernel

theorem selectedBound900 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,4194304,147521,2318561,8328,147473,409817,16384,151553,2080,2245909,4341977,256,0,131073,2171538]

theorem envBound901 : H12AffineFastState.Bounded env901 := by
  intro p hp
  have h : env901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans900_901 : H12AffineEnvironment.transform 23 2318561 env900 = env901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2318561 env900 == env901) = true)

theorem identity901 : scanCanonicalize (H12AffineFastState.compose env901 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 8314) := by decide +kernel

theorem selectedBound901 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8314,131072,262144,1024,8692,2097152,4194304,147521,2244763,8328,147473,409817,16384,151553,2080,2245909,4341977,256,0,131073,2097896]

theorem envBound902 : H12AffineFastState.Bounded env902 := by
  intro p hp
  have h : env902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans901_902 : H12AffineEnvironment.transform 15 8314 env901 = env902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8314 env901 == env902) = true)

def env903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8314,131072,262144,1024,8692,2097152,2244656,147521,2244763,8328,147473,409817,16384,151553,2080,2245909,2097385,256,0,131073,2097896]

theorem envBound903 : H12AffineFastState.Bounded env903 := by
  intro p hp
  have h : env903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans902_903 : H12AffineEnvironment.transform 21 2244656 env902 = env903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2244656 env902 == env903) = true)

theorem identity903 : scanCanonicalize (H12AffineFastState.compose env903 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 493) := by decide +kernel

theorem selectedBound903 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8314,131072,262144,1024,8692,493,147933,147521,147830,8328,147473,409817,16384,151553,2080,148728,260,256,0,131073,773]

theorem envBound904 : H12AffineFastState.Bounded env904 := by
  intro p hp
  have h : env904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans903_904 : H12AffineEnvironment.transform 20 493 env903 = env904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 493 env903 == env904) = true)

theorem identity904 : scanCanonicalize (H12AffineFastState.compose env904 (packedSelected [4,9,17,18,19,20,21,23,26] rootPS)) = affineNative (2^(16+1) ^^^ 16893) := by decide +kernel

theorem selectedBound904 : packedSelected [4,9,17,18,19,20,21,23,26] rootPS < 2^1333 := by decide +kernel

def env905 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8314,16893,262144,1024,8692,493,32,444,139,8328,492,262436,16384,4604,2080,1285,260,256,0,16892,773]

theorem envBound905 : H12AffineFastState.Bounded env905 := by
  intro p hp
  have h : env905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans904_905 : H12AffineEnvironment.transform 16 16893 env904 = env905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16893 env904 == env905) = true)

theorem identity905 : scanCanonicalize (H12AffineFastState.compose env905 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound905 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env906 : List Nat := [2,4,8,16,32,64,121,256,512,1024,2048,4096,8192,16384,8461,8314,16644,262144,1024,8461,276,32,325,114,8305,277,262436,16384,4357,2080,1285,260,256,0,16645,773]

theorem envBound906 : H12AffineFastState.Bounded env906 := by
  intro p hp
  have h : env906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans905_906 : H12AffineEnvironment.transform 6 121 env905 = env906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env905 == env906) = true)

theorem identity906 : scanCanonicalize (H12AffineFastState.compose env906 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 5133) := by decide +kernel

theorem selectedBound906 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env907 : List Nat := [2,4,8,16,32,64,121,256,512,1024,2048,4096,5133,16384,5376,5239,16644,262144,1024,5376,276,32,325,114,5244,277,262436,16384,4357,2080,1285,260,256,0,16645,773]

theorem envBound907 : H12AffineFastState.Bounded env907 := by
  intro p hp
  have h : env907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans906_907 : H12AffineEnvironment.transform 12 5133 env906 = env907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5133 env906 == env907) = true)

theorem identity907 : scanCanonicalize (H12AffineFastState.compose env907 (packedSelected [0,2,4,7,9,11,12,15,17,18] rootPS)) = affineNative (2^(17+1) ^^^ 22836) := by decide +kernel

theorem selectedBound907 : packedSelected [0,2,4,7,9,11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env908 : List Nat := [2,4,8,16,32,64,121,256,512,1024,2048,4096,5133,16384,5376,5239,16644,22836,1024,5376,276,32,325,114,5244,277,22544,16384,4357,2080,1285,260,256,0,16645,773]

theorem envBound908 : H12AffineFastState.Bounded env908 := by
  intro p hp
  have h : env908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans907_908 : H12AffineEnvironment.transform 17 22836 env907 = env908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22836 env907 == env908) = true)

theorem identity908 : scanCanonicalize (H12AffineFastState.compose env908 (packedSelected [0,4,6,7,9,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound908 : packedSelected [0,4,6,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env909 : List Nat := [2,4,8,16,32,64,121,256,512,1024,2048,4096,5133,4112,5376,5239,4372,2340,1024,5376,276,32,325,114,5244,277,2048,4112,4357,2080,1285,260,256,0,4373,773]

theorem envBound909 : H12AffineFastState.Bounded env909 := by
  intro p hp
  have h : env909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans908_909 : H12AffineEnvironment.transform 13 4112 env908 = env909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env908 == env909) = true)

theorem identity909 : scanCanonicalize (H12AffineFastState.compose env909 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound909 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env910 : List Nat := [2,4,8,16,32,64,121,256,512,1024,2048,308,1337,292,1076,1347,32,2340,1024,1076,276,32,325,114,1352,277,2048,292,49,2080,1285,260,256,0,33,773]

theorem envBound910 : H12AffineFastState.Bounded env910 := by
  intro p hp
  have h : env910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans909_910 : H12AffineEnvironment.transform 11 308 env909 = env910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env909 == env910) = true)

theorem identity910 : scanCanonicalize (H12AffineFastState.compose env910 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1141) := by decide +kernel

theorem selectedBound910 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env911 : List Nat := [2,4,8,16,32,64,121,256,512,1024,1141,308,1337,292,1076,1347,32,1361,1024,1076,276,32,325,114,1352,277,1141,292,49,1109,1285,260,256,0,33,773]

theorem envBound911 : H12AffineFastState.Bounded env911 := by
  intro p hp
  have h : env911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans910_911 : H12AffineEnvironment.transform 10 1141 env910 = env911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1141 env910 == env911) = true)

theorem identity911 : scanCanonicalize (H12AffineFastState.compose env911 (packedSelected [1,2,3,4,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound911 : packedSelected [1,2,3,4,6,7] rootPS < 2^1333 := by decide +kernel

def env912 : List Nat := [2,4,8,16,32,64,121,256,512,4,113,308,317,292,48,327,32,341,4,48,276,32,325,114,332,277,113,292,49,81,257,260,256,0,33,773]

theorem envBound912 : H12AffineFastState.Bounded env912 := by
  intro p hp
  have h : env912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans911_912 : H12AffineEnvironment.transform 9 4 env911 = env912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env911 == env912) = true)

theorem identity912 : scanCanonicalize (H12AffineFastState.compose env912 (packedSelected [0,1,3,4,6,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound912 : packedSelected [0,1,3,4,6,10] rootPS < 2^1333 := by decide +kernel

def env913 : List Nat := [2,4,8,0,32,64,105,256,512,4,97,292,301,292,32,327,32,325,4,32,260,32,325,98,332,261,97,292,33,65,257,260,256,0,33,773]

theorem envBound913 : H12AffineFastState.Bounded env913 := by
  intro p hp
  have h : env913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans912_913 : H12AffineEnvironment.transform 3 0 env912 = env913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env912 == env913) = true)

theorem identity913 : scanCanonicalize (H12AffineFastState.compose env913 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound913 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env914 : List Nat := [2,4,8,0,32,1,40,256,512,4,32,292,301,292,32,262,32,260,4,32,260,32,260,35,269,261,32,292,33,0,257,260,256,0,33,773]

theorem envBound914 : H12AffineFastState.Bounded env914 := by
  intro p hp
  have h : env914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans913_914 : H12AffineEnvironment.transform 5 1 env913 = env914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env913 == env914) = true)

theorem identity914 : scanCanonicalize (H12AffineFastState.compose env914 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound914 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env915 : List Nat := [2,4,8,0,32,1,40,4,512,4,32,32,41,32,32,2,32,0,4,32,0,32,0,35,9,1,32,32,33,0,5,0,4,0,33,513]

theorem envBound915 : H12AffineFastState.Bounded env915 := by
  intro p hp
  have h : env915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans914_915 : H12AffineEnvironment.transform 7 4 env914 = env915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env914 == env915) = true)

theorem identity915 : scanCanonicalize (H12AffineFastState.compose env915 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound915 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env916 : List Nat := [2,4,8,0,7,1,15,4,512,4,7,7,14,7,7,2,7,0,4,7,0,7,0,4,9,1,7,7,6,0,5,0,4,0,6,513]

theorem envBound916 : H12AffineFastState.Bounded env916 := by
  intro p hp
  have h : env916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans915_916 : H12AffineEnvironment.transform 4 7 env915 = env916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env915 == env916) = true)

theorem identity916 : scanCanonicalize (H12AffineFastState.compose env916 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound916 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env917 : List Nat := [2,4,8,0,7,1,15,4,12,4,7,7,14,7,7,2,7,0,4,7,0,7,0,4,9,1,7,7,6,0,5,0,4,0,6,13]

theorem envBound917 : H12AffineFastState.Bounded env917 := by
  intro p hp
  have h : env917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans916_917 : H12AffineEnvironment.transform 8 12 env916 = env917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env916 == env917) = true)

theorem identity917 : scanCanonicalize (H12AffineFastState.compose env917 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound917 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env918 : List Nat := [2,3,8,0,0,1,8,3,11,3,0,0,9,0,0,2,0,0,3,0,0,0,0,3,9,1,0,0,1,0,2,0,3,0,1,10]

theorem envBound918 : H12AffineFastState.Bounded env918 := by
  intro p hp
  have h : env918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans917_918 : H12AffineEnvironment.transform 1 3 env917 = env918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env917 == env918) = true)

theorem identity918 : scanCanonicalize (H12AffineFastState.compose env918 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound918 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env919 : List Nat := [2,3,0,0,0,1,0,3,3,3,0,0,1,0,0,2,0,0,3,0,0,0,0,3,1,1,0,0,1,0,2,0,3,0,1,2]

theorem envBound919 : H12AffineFastState.Bounded env919 := by
  intro p hp
  have h : env919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans918_919 : H12AffineEnvironment.transform 2 0 env918 = env919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env918 == env919) = true)

def env920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8314,131072,262144,1024,8692,2097152,2244657,147521,2244763,8328,147473,409817,16384,151553,2080,2245909,2097384,256,0,131073,2097896]

theorem envBound920 : H12AffineFastState.Bounded env920 := by
  intro p hp
  have h : env920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans902_920 : H12AffineEnvironment.transform 21 2244657 env902 = env920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2244657 env902 == env920) = true)

theorem identity920 : scanCanonicalize (H12AffineFastState.compose env920 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound920 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env921 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8433,8314,131072,262144,1024,8433,2097152,2244657,147521,2244763,8328,147473,409817,16384,151553,2080,2245648,2097384,5,0,131073,2097896]

theorem envBound921 : H12AffineFastState.Bounded env921 := by
  intro p hp
  have h : env921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans920_921 : H12AffineEnvironment.transform 7 5 env920 = env921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env920 == env921) = true)

theorem identity921 : scanCanonicalize (H12AffineFastState.compose env921 (packedSelected [4,9,17,18,19,20,21,23,26] rootPS)) = affineNative (2^(20+1) ^^^ 411849) := by decide +kernel

theorem selectedBound921 : packedSelected [4,9,17,18,19,20,21,23,26] rootPS < 2^1333 := by decide +kernel

def env922 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8433,8314,131072,262144,1024,8433,411849,264440,147521,264274,8328,147473,409817,16384,151553,2080,265433,411681,5,0,131073,412193]

theorem envBound922 : H12AffineFastState.Bounded env922 := by
  intro p hp
  have h : env922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans921_922 : H12AffineEnvironment.transform 20 411849 env921 = env922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 411849 env921 == env922) = true)

theorem identity922 : scanCanonicalize (H12AffineFastState.compose env922 (packedSelected [1,5,8,17,18,21,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 2264) := by decide +kernel

theorem selectedBound922 : packedSelected [1,5,8,17,18,21,23,24] rootPS < 2^1333 := by decide +kernel

def env923 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8433,8314,131072,2264,1024,8433,147473,32,147521,138,8328,147473,149505,16384,151553,2080,1025,147705,5,0,131073,148217]

theorem envBound923 : H12AffineFastState.Bounded env923 := by
  intro p hp
  have h : env923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans922_923 : H12AffineEnvironment.transform 17 2264 env922 = env923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2264 env922 == env923) = true)

theorem identity923 : scanCanonicalize (H12AffineFastState.compose env923 (packedSelected [0,4,5,7,8,9,13,17] rootPS)) = affineNative (2^(16+1) ^^^ 11518) := by decide +kernel

theorem selectedBound923 : packedSelected [0,4,5,7,8,9,13,17] rootPS < 2^1333 := by decide +kernel

def env924 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8433,8314,11518,2264,1024,8433,27887,32,27839,138,8328,27887,25855,16384,31999,2080,1025,27655,5,0,11519,28167]

theorem envBound924 : H12AffineFastState.Bounded env924 := by
  intro p hp
  have h : env924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans923_924 : H12AffineEnvironment.transform 16 11518 env923 = env924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 11518 env923 == env924) = true)

theorem identity924 : scanCanonicalize (H12AffineFastState.compose env924 (packedSelected [0,1,7,8,10,12,18] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound924 : packedSelected [0,1,7,8,10,12,18] rootPS < 2^1333 := by decide +kernel

def env925 : List Nat := [2,4,8,16,32,64,120,5,512,1024,2048,4096,8192,16384,8201,8314,11270,2080,1024,8201,27671,32,27719,114,8304,27671,25607,16384,31751,2080,1025,27655,5,0,11271,28167]

theorem envBound925 : H12AffineFastState.Bounded env925 := by
  intro p hp
  have h : env925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans924_925 : H12AffineEnvironment.transform 6 120 env924 = env925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env924 == env925) = true)

theorem identity925 : scanCanonicalize (H12AffineFastState.compose env925 (packedSelected [1,2,6,8,10] rootPS)) = affineNative (2^(13+1) ^^^ 9341) := by decide +kernel

theorem selectedBound925 : packedSelected [1,2,6,8,10] rootPS < 2^1333 := by decide +kernel

def env926 : List Nat := [2,4,8,16,32,64,120,5,512,1024,2048,4096,8192,9341,8201,8314,11270,2080,1024,8201,2154,32,2106,114,8304,2154,122,9341,6266,2080,1025,2170,5,0,11271,2682]

theorem envBound926 : H12AffineFastState.Bounded env926 := by
  intro p hp
  have h : env926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans925_926 : H12AffineEnvironment.transform 13 9341 env925 = env926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9341 env925 == env926) = true)

theorem identity926 : scanCanonicalize (H12AffineFastState.compose env926 (packedSelected [0,1,3,4,6,7,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound926 : packedSelected [0,1,3,4,6,7,9,11] rootPS < 2^1333 := by decide +kernel

def env927 : List Nat := [2,4,8,16,32,64,120,5,512,1024,2048,1,8192,9341,8201,8314,11270,2080,1024,8201,2154,32,2106,114,8304,2154,122,9341,2171,2080,1025,2170,5,0,11271,2682]

theorem envBound927 : H12AffineFastState.Bounded env927 := by
  intro p hp
  have h : env927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans926_927 : H12AffineEnvironment.transform 11 1 env926 = env927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env926 == env927) = true)

theorem identity927 : scanCanonicalize (H12AffineFastState.compose env927 (packedSelected [0,1,2,3,4,5,6,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 122) := by decide +kernel

theorem selectedBound927 : packedSelected [0,1,2,3,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env928 : List Nat := [2,4,8,16,32,64,120,5,512,1024,122,1,8192,9341,8201,8314,9340,90,1024,8201,16,32,64,114,8304,16,122,9341,1,90,1025,0,5,0,9341,512]

theorem envBound928 : H12AffineFastState.Bounded env928 := by
  intro p hp
  have h : env928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans927_928 : H12AffineEnvironment.transform 10 122 env927 = env928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 122 env927 == env928) = true)

def env929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147521,16777216,8328,147472,409816,16384,151553,2080,16852469,4341976,257,0,34359738368,16925298]

theorem envBound929 : H12AffineFastState.Bounded env929 := by
  intro p hp
  have h : env929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans876_929 : H12AffineEnvironment.transform 18 1025 env876 = env929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env876 == env929) = true)

def env930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147521,16777216,8328,147472,409816,16384,151553,2080,16852469,4341976,257,0,131072,16925298]

theorem envBound930 : H12AffineFastState.Bounded env930 := by
  intro p hp
  have h : env930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans929_930 : H12AffineEnvironment.transform 34 131072 env929 = env930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env929 == env930) = true)

theorem identity930 : scanCanonicalize (H12AffineFastState.compose env930 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 95649) := by decide +kernel

theorem selectedBound930 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147521,95649,8328,147472,409816,16384,151553,2080,20564,4341976,257,0,131072,210899]

theorem envBound931 : H12AffineFastState.Bounded env931 := by
  intro p hp
  have h : env931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans930_931 : H12AffineEnvironment.transform 23 95649 env930 = env931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95649 env930 == env931) = true)

theorem identity931 : scanCanonicalize (H12AffineFastState.compose env931 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 21621) := by decide +kernel

theorem selectedBound931 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env932 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,21621,147521,95649,8328,147472,409816,16384,151553,2080,20564,136365,257,0,131072,210899]

theorem envBound932 : H12AffineFastState.Bounded env932 := by
  intro p hp
  have h : env932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans931_932 : H12AffineEnvironment.transform 21 21621 env931 = env932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21621 env931 == env932) = true)

theorem identity932 : scanCanonicalize (H12AffineFastState.compose env932 (packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound932 : packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env933 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,131072,262144,1025,8692,2097152,21621,147521,21727,8328,147472,409816,16384,151553,2080,20564,136365,257,0,131072,136877]

theorem envBound933 : H12AffineFastState.Bounded env933 := by
  intro p hp
  have h : env933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans932_933 : H12AffineEnvironment.transform 15 8574 env932 = env933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env932 == env933) = true)

def env934 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,16464,262144,1025,8692,2097152,21621,17,21727,8328,64,262280,16384,4177,2080,20564,21757,257,0,16464,22269]

theorem envBound934 : H12AffineFastState.Bounded env934 := by
  intro p hp
  have h : env934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans933_934 : H12AffineEnvironment.transform 16 16464 env933 = env934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env933 == env934) = true)

theorem identity934 : scanCanonicalize (H12AffineFastState.compose env934 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5205) := by decide +kernel

theorem selectedBound934 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5205,8692,8574,5125,262144,1025,8692,2097152,32,17,138,8328,64,262280,5205,4177,2080,1025,168,257,0,5125,680]

theorem envBound935 : H12AffineFastState.Bounded env935 := by
  intro p hp
  have h : env935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans934_935 : H12AffineEnvironment.transform 13 5205 env934 = env935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5205 env934 == env935) = true)

theorem identity935 : scanCanonicalize (H12AffineFastState.compose env935 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound935 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env936 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,5205,8352,8234,5125,262144,1025,8352,2097152,32,17,138,8328,64,262280,5205,4177,2080,1025,168,85,0,5125,680]

theorem envBound936 : H12AffineFastState.Bounded env936 := by
  intro p hp
  have h : env936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans935_936 : H12AffineEnvironment.transform 7 84 env935 = env936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env935 == env936) = true)

theorem identity936 : scanCanonicalize (H12AffineFastState.compose env936 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 4113) := by decide +kernel

theorem selectedBound936 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env937 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,5205,8352,8234,5125,262144,1025,8352,4113,32,17,138,8328,64,262280,5205,4177,2080,1025,168,85,0,5125,680]

theorem envBound937 : H12AffineFastState.Bounded env937 := by
  intro p hp
  have h : env937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans936_937 : H12AffineEnvironment.transform 20 4113 env936 = env937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4113 env936 == env937) = true)

theorem identity937 : scanCanonicalize (H12AffineFastState.compose env937 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 241) := by decide +kernel

theorem selectedBound937 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env938 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,241,5205,81,219,5125,262144,1025,81,4113,32,17,138,121,64,262280,5205,4177,2080,1025,168,85,0,5125,680]

theorem envBound938 : H12AffineFastState.Bounded env938 := by
  intro p hp
  have h : env938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans937_938 : H12AffineEnvironment.transform 12 241 env937 = env938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env937 == env938) = true)

theorem identity938 : scanCanonicalize (H12AffineFastState.compose env938 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound938 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env939 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,88,5205,81,114,5125,262144,1025,81,4113,32,17,35,121,64,262177,5205,4177,2080,1025,1,85,0,5125,513]

theorem envBound939 : H12AffineFastState.Bounded env939 := by
  intro p hp
  have h : env939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans938_939 : H12AffineEnvironment.transform 6 41 env938 = env939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env938 == env939) = true)

theorem identity939 : scanCanonicalize (H12AffineFastState.compose env939 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound939 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env940 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,4096,8,5125,1,34,5125,262144,1025,1,4113,32,17,35,41,16,262177,5125,4097,2080,1025,1,5,0,5125,513]

theorem envBound940 : H12AffineFastState.Bounded env940 := by
  intro p hp
  have h : env940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans939_940 : H12AffineEnvironment.transform 5 16 env939 = env940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env939 == env940) = true)

theorem identity940 : scanCanonicalize (H12AffineFastState.compose env940 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound940 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env941 : List Nat := [2,4,8,1,32,1,41,4,512,1024,2048,4096,8,5125,1,34,5125,262144,1025,1,4096,32,0,35,41,1,262177,5125,4097,2080,1025,1,5,0,5125,513]

theorem envBound941 : H12AffineFastState.Bounded env941 := by
  intro p hp
  have h : env941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans940_941 : H12AffineEnvironment.transform 3 1 env940 = env941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env940 == env941) = true)

theorem identity941 : scanCanonicalize (H12AffineFastState.compose env941 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 522) := by decide +kernel

theorem selectedBound941 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env942 : List Nat := [2,4,8,1,32,1,41,4,512,1024,2048,4096,8,5125,1,34,5125,522,1025,1,4096,32,0,35,41,1,555,5125,4097,2080,1025,1,5,0,5125,513]

theorem envBound942 : H12AffineFastState.Bounded env942 := by
  intro p hp
  have h : env942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans941_942 : H12AffineEnvironment.transform 17 522 env941 = env942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 522 env941 == env942) = true)

theorem identity942 : scanCanonicalize (H12AffineFastState.compose env942 (packedSelected [0,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound942 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env943 : List Nat := [2,4,8,1,32,1,41,4,512,1024,554,4096,8,5125,1,34,5125,522,1025,1,4096,32,0,35,41,1,555,5125,4097,522,1025,1,5,0,5125,513]

theorem envBound943 : H12AffineFastState.Bounded env943 := by
  intro p hp
  have h : env943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans942_943 : H12AffineEnvironment.transform 10 554 env942 = env943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env942 == env943) = true)

theorem identity943 : scanCanonicalize (H12AffineFastState.compose env943 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound943 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env944 : List Nat := [2,4,8,1,32,1,41,4,512,1024,554,1060,8,33,1,34,33,522,1025,1,1060,32,0,35,41,1,555,33,1061,522,1025,1,5,0,33,513]

theorem envBound944 : H12AffineFastState.Bounded env944 := by
  intro p hp
  have h : env944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans943_944 : H12AffineEnvironment.transform 11 1060 env943 = env944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env943 == env944) = true)

theorem identity944 : scanCanonicalize (H12AffineFastState.compose env944 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound944 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env945 : List Nat := [2,4,8,1,32,1,41,4,512,36,554,0,8,33,1,34,33,522,37,1,0,32,0,35,41,1,555,33,1,522,37,1,5,0,33,513]

theorem envBound945 : H12AffineFastState.Bounded env945 := by
  intro p hp
  have h : env945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans944_945 : H12AffineEnvironment.transform 9 36 env944 = env945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env944 == env945) = true)

theorem identity945 : scanCanonicalize (H12AffineFastState.compose env945 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 46) := by decide +kernel

theorem selectedBound945 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env946 : List Nat := [2,4,8,1,32,1,41,4,46,36,4,0,8,33,1,34,33,36,37,1,0,32,0,35,41,1,5,33,1,36,37,1,5,0,33,47]

theorem envBound946 : H12AffineFastState.Bounded env946 := by
  intro p hp
  have h : env946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans945_946 : H12AffineEnvironment.transform 8 46 env945 = env946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 46 env945 == env946) = true)

theorem identity946 : scanCanonicalize (H12AffineFastState.compose env946 (packedSelected [0,5] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound946 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env947 : List Nat := [2,1,8,1,32,1,41,1,43,33,1,0,8,33,1,34,33,33,32,1,0,32,0,35,41,1,0,33,1,33,32,1,0,0,33,42]

theorem envBound947 : H12AffineFastState.Bounded env947 := by
  intro p hp
  have h : env947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans946_947 : H12AffineEnvironment.transform 1 1 env946 = env947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env946 == env947) = true)

theorem identity947 : scanCanonicalize (H12AffineFastState.compose env947 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound947 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env948 : List Nat := [1,1,8,1,32,1,41,1,40,33,1,0,8,33,1,33,33,33,32,1,0,32,0,32,41,1,0,33,1,33,32,1,0,0,33,41]

theorem envBound948 : H12AffineFastState.Bounded env948 := by
  intro p hp
  have h : env948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans947_948 : H12AffineEnvironment.transform 0 1 env947 = env948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env947 == env948) = true)

def env949 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,16465,262144,1025,8692,2097152,21621,16,21727,8328,65,262281,16384,4176,2080,20564,21756,257,0,16465,22268]

theorem envBound949 : H12AffineFastState.Bounded env949 := by
  intro p hp
  have h : env949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans933_949 : H12AffineEnvironment.transform 16 16465 env933 = env949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env933 == env949) = true)

theorem identity949 : scanCanonicalize (H12AffineFastState.compose env949 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5373) := by decide +kernel

theorem selectedBound949 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env950 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5373,8692,8574,5292,262144,1025,8692,2097152,136,16,34,8328,65,262281,5373,4176,2080,1193,1,257,0,5292,513]

theorem envBound950 : H12AffineFastState.Bounded env950 := by
  intro p hp
  have h : env950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans949_950 : H12AffineEnvironment.transform 13 5373 env949 = env950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5373 env949 == env950) = true)

theorem identity950 : scanCanonicalize (H12AffineFastState.compose env950 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4345) := by decide +kernel

theorem selectedBound950 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env951 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5373,8692,8574,5292,262144,1025,8692,4345,136,16,34,8328,65,262281,5373,4176,2080,1193,1,257,0,5292,513]

theorem envBound951 : H12AffineFastState.Bounded env951 := by
  intro p hp
  have h : env951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans950_951 : H12AffineEnvironment.transform 20 4345 env950 = env951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4345 env950 == env951) = true)

theorem identity951 : scanCanonicalize (H12AffineFastState.compose env951 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 188) := by decide +kernel

theorem selectedBound951 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env952 : List Nat := [2,4,8,16,32,64,128,188,512,1024,2048,4096,8192,5373,8264,8386,5292,262144,1025,8264,4345,136,16,34,8328,65,262281,5373,4176,2080,1193,1,189,0,5292,513]

theorem envBound952 : H12AffineFastState.Bounded env952 := by
  intro p hp
  have h : env952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans951_952 : H12AffineEnvironment.transform 7 188 env951 = env952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env951 == env952) = true)

theorem identity952 : scanCanonicalize (H12AffineFastState.compose env952 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound952 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env953 : List Nat := [2,4,8,16,32,1,128,188,512,1024,2048,4096,8192,5308,8201,8323,5292,262144,1025,8201,4280,136,16,34,8328,0,262281,5308,4113,2080,1193,1,189,0,5292,513]

theorem envBound953 : H12AffineFastState.Bounded env953 := by
  intro p hp
  have h : env953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans952_953 : H12AffineEnvironment.transform 5 1 env952 = env953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env952 == env953) = true)

theorem identity953 : scanCanonicalize (H12AffineFastState.compose env953 (packedSelected [2,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 10385) := by decide +kernel

theorem selectedBound953 : packedSelected [2,12,15] rootPS < 2^1333 := by decide +kernel

def env954 : List Nat := [2,4,8,16,32,1,128,188,512,1024,2048,4096,8192,5308,8201,8323,5292,10385,1025,8201,4280,136,16,34,8328,0,10264,5308,4113,2080,1193,1,189,0,5292,513]

theorem envBound954 : H12AffineFastState.Bounded env954 := by
  intro p hp
  have h : env954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans953_954 : H12AffineEnvironment.transform 17 10385 env953 = env954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10385 env953 == env954) = true)

theorem identity954 : scanCanonicalize (H12AffineFastState.compose env954 (packedSelected [1,2,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound954 : packedSelected [1,2,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env955 : List Nat := [2,4,8,16,32,1,57,5,512,1024,2048,4096,8192,5125,8201,8250,5141,10280,1025,8201,4097,49,16,34,8241,0,10264,5125,4113,2080,1040,1,4,0,5141,513]

theorem envBound955 : H12AffineFastState.Bounded env955 := by
  intro p hp
  have h : env955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans954_955 : H12AffineEnvironment.transform 6 57 env954 = env955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env954 == env955) = true)

theorem identity955 : scanCanonicalize (H12AffineFastState.compose env955 (packedSelected [3,5,6,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound955 : packedSelected [3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env956 : List Nat := [2,4,8,1,32,1,40,5,512,1024,2048,4096,8192,5125,8201,8235,5124,10280,1025,8201,4097,32,1,34,8224,0,10249,5125,4096,2080,1025,1,4,0,5124,513]

theorem envBound956 : H12AffineFastState.Bounded env956 := by
  intro p hp
  have h : env956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans955_956 : H12AffineEnvironment.transform 3 1 env955 = env956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env955 == env956) = true)

theorem identity956 : scanCanonicalize (H12AffineFastState.compose env956 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound956 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env957 : List Nat := [2,4,8,1,32,1,40,5,512,1024,2048,4096,9,5125,0,34,5124,2081,1025,0,4097,32,1,34,41,0,2048,5125,4096,2080,1025,1,4,0,5124,513]

theorem envBound957 : H12AffineFastState.Bounded env957 := by
  intro p hp
  have h : env957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans956_957 : H12AffineEnvironment.transform 12 9 env956 = env957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env956 == env957) = true)

theorem identity957 : scanCanonicalize (H12AffineFastState.compose env957 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2570) := by decide +kernel

theorem selectedBound957 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env958 : List Nat := [2,4,8,1,32,1,40,5,512,1024,2048,2570,9,3599,0,34,3598,2081,1025,0,2571,32,1,34,41,0,2048,3599,2570,2080,1025,1,4,0,3598,513]

theorem envBound958 : H12AffineFastState.Bounded env958 := by
  intro p hp
  have h : env958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans957_958 : H12AffineEnvironment.transform 11 2570 env957 = env958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2570 env957 == env958) = true)

theorem identity958 : scanCanonicalize (H12AffineFastState.compose env958 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound958 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env959 : List Nat := [2,4,8,1,32,1,40,5,43,1024,2048,2081,9,3108,0,34,3109,2081,1025,0,2080,32,1,34,41,0,2048,3108,2081,2080,1025,1,4,0,3109,42]

theorem envBound959 : H12AffineFastState.Bounded env959 := by
  intro p hp
  have h : env959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans958_959 : H12AffineEnvironment.transform 8 43 env958 = env959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env958 == env959) = true)

end H12CloudChart0