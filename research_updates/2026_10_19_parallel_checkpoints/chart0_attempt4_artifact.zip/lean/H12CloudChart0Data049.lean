import H12CloudChart0Data048

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env12268 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,107,269,1354,32,262,1370,2421,1024,33,42,33,16,34,349,65,2129,1402,74,2389,1284,113,256,1,1307,512]

theorem envBound12268 : H12AffineFastState.Bounded env12268 := by
  intro p hp
  have h : env12268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12267_12268 : H12AffineEnvironment.transform 11 107 env12267 = env12268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 107 env12267 == env12268) = true)

theorem identity12268 : scanCanonicalize (H12AffineFastState.compose env12268 (packedSelected [0,1,2,3,5,8,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 1615) := by decide +kernel

theorem selectedBound12268 : packedSelected [0,1,2,3,5,8,9,12] rootPS < 2^1333 := by decide +kernel

def env12269 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1615,107,269,1354,32,262,1370,1850,1024,33,42,33,16,34,349,65,1566,1402,74,1818,1284,113,256,1,1307,512]

theorem envBound12269 : H12AffineFastState.Bounded env12269 := by
  intro p hp
  have h : env12269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12268_12269 : H12AffineEnvironment.transform 10 1615 env12268 = env12269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1615 env12268 == env12269) = true)

theorem identity12269 : scanCanonicalize (H12AffineFastState.compose env12269 (packedSelected [0,3,5,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 527) := by decide +kernel

theorem selectedBound12269 : packedSelected [0,3,5,9,14] rootPS < 2^1333 := by decide +kernel

def env12270 : List Nat := [2,4,8,16,32,64,88,256,512,527,64,107,269,837,32,262,853,309,527,33,42,33,16,34,349,65,17,885,74,277,779,113,256,1,788,512]

theorem envBound12270 : H12AffineFastState.Bounded env12270 := by
  intro p hp
  have h : env12270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12269_12270 : H12AffineEnvironment.transform 9 527 env12269 = env12270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 527 env12269 == env12270) = true)

theorem identity12270 : scanCanonicalize (H12AffineFastState.compose env12270 (packedSelected [0,1,4,5,7,9,15] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound12270 : packedSelected [0,1,4,5,7,9,15] rootPS < 2^1333 := by decide +kernel

def env12271 : List Nat := [2,4,8,16,32,64,88,5,512,527,64,107,8,576,32,3,592,48,527,33,42,33,16,34,88,65,17,624,74,16,526,113,5,1,529,512]

theorem envBound12271 : H12AffineFastState.Bounded env12271 := by
  intro p hp
  have h : env12271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12270_12271 : H12AffineEnvironment.transform 7 5 env12270 = env12271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env12270 == env12271) = true)

theorem identity12271 : scanCanonicalize (H12AffineFastState.compose env12271 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12271 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12272 : List Nat := [2,4,8,16,1,64,88,5,512,527,64,74,8,576,1,3,592,17,527,0,11,0,16,3,88,65,17,593,74,16,526,80,5,1,529,512]

theorem envBound12272 : H12AffineFastState.Bounded env12272 := by
  intro p hp
  have h : env12272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12271_12272 : H12AffineEnvironment.transform 4 1 env12271 = env12272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12271 == env12272) = true)

theorem identity12272 : scanCanonicalize (H12AffineFastState.compose env12272 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 75) := by decide +kernel

theorem selectedBound12272 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12273 : List Nat := [2,4,8,16,1,64,88,5,75,68,64,74,8,11,1,3,27,17,68,0,11,0,16,3,88,65,17,26,74,16,69,80,5,1,90,75]

theorem envBound12273 : H12AffineFastState.Bounded env12273 := by
  intro p hp
  have h : env12273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12272_12273 : H12AffineEnvironment.transform 8 75 env12272 = env12273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 75 env12272 == env12273) = true)

theorem identity12273 : scanCanonicalize (H12AffineFastState.compose env12273 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound12273 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12274 : List Nat := [2,4,8,5,1,64,77,5,75,68,64,74,8,11,1,3,14,4,68,0,11,0,5,3,77,65,4,15,74,5,69,69,5,1,79,75]

theorem envBound12274 : H12AffineFastState.Bounded env12274 := by
  intro p hp
  have h : env12274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12273_12274 : H12AffineEnvironment.transform 3 5 env12273 = env12274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env12273 == env12274) = true)

theorem identity12274 : scanCanonicalize (H12AffineFastState.compose env12274 (packedSelected [1,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound12274 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env12275 : List Nat := [2,4,7,5,1,64,66,5,68,68,64,69,7,4,1,3,1,4,68,0,4,0,5,3,66,65,4,0,69,5,69,69,5,1,64,68]

theorem envBound12275 : H12AffineFastState.Bounded env12275 := by
  intro p hp
  have h : env12275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12274_12275 : H12AffineEnvironment.transform 2 7 env12274 = env12275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env12274 == env12275) = true)

theorem identity12275 : scanCanonicalize (H12AffineFastState.compose env12275 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 2) := by decide +kernel

theorem selectedBound12275 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env12276 : List Nat := [2,4,7,5,1,2,0,5,6,6,2,7,7,4,1,3,1,4,6,0,4,0,5,3,0,3,4,0,7,5,7,7,5,1,2,6]

theorem envBound12276 : H12AffineFastState.Bounded env12276 := by
  intro p hp
  have h : env12276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12275_12276 : H12AffineEnvironment.transform 5 2 env12275 = env12276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 2 env12275 == env12276) = true)

def env12277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,156132,485758,16777216,8328,65,16959643,17246589,102878,108926,17231214,17148372,256,16777250,16834951,17287865]

theorem envBound12277 : H12AffineFastState.Bounded env12277 := by
  intro p hp
  have h : env12277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12243_12277 : H12AffineEnvironment.transform 20 437745 env12243 = env12277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437745 env12243 == env12277) = true)

def env12278 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4161,156132,120014,16777216,8328,65,16959643,16880845,102878,108926,16797918,16979044,256,16777250,16834951,16873225]

theorem envBound12278 : H12AffineFastState.Bounded env12278 := by
  intro p hp
  have h : env12278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12277_12278 : H12AffineEnvironment.transform 17 179632 env12277 = env12278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179632 env12277 == env12278) = true)

def env12279 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13744,34816,1024,32769,4161,21588,120014,16777216,8328,65,16842027,16880845,102878,108926,16797918,16851412,256,16777250,16834951,16873225]

theorem envBound12279 : H12AffineFastState.Bounded env12279 := by
  intro p hp
  have h : env12279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12278_12279 : H12AffineEnvironment.transform 16 13744 env12278 = env12279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13744 env12278 == env12279) = true)

theorem identity12279 : scanCanonicalize (H12AffineFastState.compose env12279 (packedSelected [1,3,7,8,10,12,17,19,20,24,26,27,35,38] rootPS)) = affineNative (2^(23+1) ^^^ 95476) := by decide +kernel

theorem selectedBound12279 : packedSelected [1,3,7,8,10,12,17,19,20,24,26,27,35,38] rootPS < 2^1333 := by decide +kernel

def env12280 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13744,34816,1024,32769,4161,21588,120014,95476,8328,65,100831,57401,102878,108926,74794,21792,256,95446,103795,1021]

theorem envBound12280 : H12AffineFastState.Bounded env12280 := by
  intro p hp
  have h : env12280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12279_12280 : H12AffineEnvironment.transform 23 95476 env12279 = env12280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95476 env12279 == env12280) = true)

def env12281 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,13744,34816,1024,32769,4113,21508,119966,95396,8328,17,100751,57401,102798,108846,74794,21792,256,95366,103715,941]

theorem envBound12281 : H12AffineFastState.Bounded env12281 := by
  intro p hp
  have h : env12281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12280_12281 : H12AffineEnvironment.transform 5 16 env12280 = env12281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12280 == env12281) = true)

theorem identity12281 : scanCanonicalize (H12AffineFastState.compose env12281 (packedSelected [0,1,3,4,8,10,14,15,17,18,20,22,23,24,27,41] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound12281 : packedSelected [0,1,3,4,8,10,14,15,17,18,20,22,23,24,27,41] rootPS < 2^1333 := by decide +kernel

def env12282 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29708,65536,13744,31756,1024,29709,4113,21508,73874,95396,8328,17,97667,5173,91522,89378,74794,21792,256,95366,90415,941]

theorem envBound12282 : H12AffineFastState.Bounded env12282 := by
  intro p hp
  have h : env12282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12281_12282 : H12AffineEnvironment.transform 14 29708 env12281 = env12282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env12281 == env12282) = true)

theorem identity12282 : scanCanonicalize (H12AffineFastState.compose env12282 (packedSelected [1,2,3,4,5,6,8,10,11,16,17,19,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound12282 : packedSelected [1,2,3,4,5,6,8,10,11,16,17,19,22,23] rootPS < 2^1333 := by decide +kernel

def env12283 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29708,8202,13744,31756,1024,29709,4113,21508,152,21678,8328,17,23945,5173,17800,32040,1056,21792,256,21644,16677,941]

theorem envBound12283 : H12AffineFastState.Bounded env12283 := by
  intro p hp
  have h : env12283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12282_12283 : H12AffineEnvironment.transform 15 8202 env12282 = env12283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env12282 == env12283) = true)

theorem identity12283 : scanCanonicalize (H12AffineFastState.compose env12283 (packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound12283 : packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env12284 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13325,1,8202,13744,2049,1024,0,4113,8201,152,8355,8328,17,10628,5173,12677,2341,1056,8493,256,8321,13608,941]

theorem envBound12284 : H12AffineFastState.Bounded env12284 := by
  intro p hp
  have h : env12284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12283_12284 : H12AffineEnvironment.transform 13 13325 env12283 = env12284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env12283 == env12284) = true)

theorem identity12284 : scanCanonicalize (H12AffineFastState.compose env12284 (packedSelected [0,2,3,4,6,8,10,11,12,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 1945) := by decide +kernel

theorem selectedBound12284 : packedSelected [0,2,3,4,6,8,10,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env12285 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1945,4096,8192,13325,1,8202,13744,1944,1024,0,4113,8201,152,8355,8328,17,9757,5173,12677,1724,1056,8493,256,8321,13608,941]

theorem envBound12285 : H12AffineFastState.Bounded env12285 := by
  intro p hp
  have h : env12285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12284_12285 : H12AffineEnvironment.transform 10 1945 env12284 = env12285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1945 env12284 == env12285) = true)

theorem identity12285 : scanCanonicalize (H12AffineFastState.compose env12285 (packedSelected [3,7,8,9,10,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound12285 : packedSelected [3,7,8,9,10,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env12286 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1945,4096,160,5293,1,170,5392,1944,1024,0,4113,169,152,3,40,17,1725,5173,4389,1724,1056,397,256,33,5512,941]

theorem envBound12286 : H12AffineFastState.Bounded env12286 := by
  intro p hp
  have h : env12286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12285_12286 : H12AffineEnvironment.transform 12 160 env12285 = env12286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env12285 == env12286) = true)

theorem identity12286 : scanCanonicalize (H12AffineFastState.compose env12286 (packedSelected [0,7,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 648) := by decide +kernel

theorem selectedBound12286 : packedSelected [0,7,10,12] rootPS < 2^1333 := by decide +kernel

def env12287 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1945,648,160,1573,1,170,1944,1944,1024,0,665,169,152,3,40,17,1725,1725,941,1724,1056,397,256,33,1792,941]

theorem envBound12287 : H12AffineFastState.Bounded env12287 := by
  intro p hp
  have h : env12287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12286_12287 : H12AffineEnvironment.transform 11 648 env12286 = env12287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 648 env12286 == env12287) = true)

theorem identity12287 : scanCanonicalize (H12AffineFastState.compose env12287 (packedSelected [0,1,2,5,6,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound12287 : packedSelected [0,1,2,5,6,7,10] rootPS < 2^1333 := by decide +kernel

def env12288 : List Nat := [2,4,8,16,32,16,128,256,512,188,805,648,160,665,1,170,804,804,188,0,665,169,152,3,40,17,513,513,941,512,156,397,256,33,956,941]

theorem envBound12288 : H12AffineFastState.Bounded env12288 := by
  intro p hp
  have h : env12288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12287_12288 : H12AffineEnvironment.transform 9 188 env12287 = env12288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env12287 == env12288) = true)

theorem identity12288 : scanCanonicalize (H12AffineFastState.compose env12288 (packedSelected [0,2,5,6,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound12288 : packedSelected [0,2,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env12289 : List Nat := [2,4,8,16,32,16,128,256,1,188,292,137,160,152,1,170,293,293,188,0,152,169,152,3,40,17,0,0,428,1,156,397,256,33,445,428]

theorem envBound12289 : H12AffineFastState.Bounded env12289 := by
  intro p hp
  have h : env12289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12288_12289 : H12AffineEnvironment.transform 8 1 env12288 = env12289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env12288 == env12289) = true)

theorem identity12289 : scanCanonicalize (H12AffineFastState.compose env12289 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound12289 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env12290 : List Nat := [2,4,8,16,32,16,9,256,1,53,292,0,41,17,1,35,293,293,53,0,17,32,17,3,40,17,0,0,293,1,21,260,256,33,308,293]

theorem envBound12290 : H12AffineFastState.Bounded env12290 := by
  intro p hp
  have h : env12290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12289_12290 : H12AffineEnvironment.transform 6 9 env12289 = env12290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12289 == env12290) = true)

theorem identity12290 : scanCanonicalize (H12AffineFastState.compose env12290 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound12290 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env12291 : List Nat := [2,4,8,16,32,16,9,52,1,53,16,0,41,17,1,35,17,17,53,0,17,32,17,3,40,17,0,0,17,1,21,48,52,33,0,17]

theorem envBound12291 : H12AffineFastState.Bounded env12291 := by
  intro p hp
  have h : env12291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12290_12291 : H12AffineEnvironment.transform 7 52 env12290 = env12291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env12290 == env12291) = true)

def env12292 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,13744,34816,1024,32769,4112,21509,119967,95397,8328,16,100750,57401,102799,108847,74794,21792,256,95367,103714,940]

theorem envBound12292 : H12AffineFastState.Bounded env12292 := by
  intro p hp
  have h : env12292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12280_12292 : H12AffineEnvironment.transform 5 17 env12280 = env12292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12280 == env12292) = true)

theorem identity12292 : scanCanonicalize (H12AffineFastState.compose env12292 (packedSelected [0,1,3,4,8,10,14,15,17,18,20,22,23,24,27,41] rootPS)) = affineNative (2^(15+1) ^^^ 54698) := by decide +kernel

theorem selectedBound12292 : packedSelected [0,1,3,4,8,10,14,15,17,18,20,22,23,24,27,41] rootPS < 2^1333 := by decide +kernel

def env12293 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54698,13744,34816,1024,32769,4112,21509,309,41231,8328,16,23588,57401,17445,31877,61824,21792,256,41261,16520,940]

theorem envBound12293 : H12AffineFastState.Bounded env12293 := by
  intro p hp
  have h : env12293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12292_12293 : H12AffineEnvironment.transform 15 54698 env12292 = env12293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54698 env12292 == env12293) = true)

theorem identity12293 : scanCanonicalize (H12AffineFastState.compose env12293 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,26] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound12293 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,26] rootPS < 2^1333 := by decide +kernel

def env12294 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,1,21931,13744,2049,1024,0,4112,21509,309,8462,8328,16,23588,24632,17445,31877,29057,21792,256,8492,16520,940]

theorem envBound12294 : H12AffineFastState.Bounded env12294 := by
  intro p hp
  have h : env12294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12293_12294 : H12AffineEnvironment.transform 14 1 env12293 = env12294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env12293 == env12294) = true)

theorem identity12294 : scanCanonicalize (H12AffineFastState.compose env12294 (packedSelected [0,1,2,3,5,6,7,8,10,11,17,18,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound12294 : packedSelected [0,1,2,3,5,6,7,8,10,11,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env12295 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,16384,1,21931,5172,2049,1024,0,4112,21509,309,138,268,16,23588,16828,17445,23809,20485,21792,256,168,16520,940]

theorem envBound12295 : H12AffineFastState.Bounded env12295 := by
  intro p hp
  have h : env12295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12294_12295 : H12AffineEnvironment.transform 12 388 env12294 = env12295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env12294 == env12295) = true)

theorem identity12295 : scanCanonicalize (H12AffineFastState.compose env12295 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound12295 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12296 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,1,21794,5172,2049,1024,0,4112,21509,309,3,268,16,23588,16693,17445,23809,20485,21792,256,33,16385,805]

theorem envBound12296 : H12AffineFastState.Bounded env12296 := by
  intro p hp
  have h : env12296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12295_12296 : H12AffineEnvironment.transform 6 9 env12295 = env12296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12295 == env12296) = true)

theorem identity12296 : scanCanonicalize (H12AffineFastState.compose env12296 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12296 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env12297 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,16384,1,21510,5172,2049,1024,0,4112,21509,17,3,40,16,23588,16401,17445,23589,20485,21508,36,33,16385,513]

theorem envBound12297 : H12AffineFastState.Bounded env12297 := by
  intro p hp
  have h : env12297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12296_12297 : H12AffineEnvironment.transform 7 36 env12296 = env12297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12296 == env12297) = true)

theorem identity12297 : scanCanonicalize (H12AffineFastState.compose env12297 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound12297 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env12298 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,2064,41,16384,1,19478,3108,2049,1024,0,2048,19477,17,3,40,16,17460,16401,17445,17461,18453,19476,36,33,16385,513]

theorem envBound12298 : H12AffineFastState.Bounded env12298 := by
  intro p hp
  have h : env12298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12297_12298 : H12AffineEnvironment.transform 11 2064 env12297 = env12298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env12297 == env12298) = true)

theorem identity12298 : scanCanonicalize (H12AffineFastState.compose env12298 (packedSelected [3,5] rootPS)) = affineNative (2^(13+1) ^^^ 1077) := by decide +kernel

theorem selectedBound12298 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env12299 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,2064,41,1077,1,2083,3108,2049,1024,0,2048,2080,17,3,40,16,1,1060,16,0,3104,2081,36,33,1076,513]

theorem envBound12299 : H12AffineFastState.Bounded env12299 := by
  intro p hp
  have h : env12299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12298_12299 : H12AffineEnvironment.transform 13 1077 env12298 = env12299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1077 env12298 == env12299) = true)

theorem identity12299 : scanCanonicalize (H12AffineFastState.compose env12299 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound12299 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env12300 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,2064,41,1,1,2083,2064,2049,52,0,2048,2080,17,3,40,16,1,16,16,0,2068,2081,36,33,0,513]

theorem envBound12300 : H12AffineFastState.Bounded env12300 := by
  intro p hp
  have h : env12300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12299_12300 : H12AffineEnvironment.transform 9 52 env12299 = env12300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env12299 == env12300) = true)

theorem identity12300 : scanCanonicalize (H12AffineFastState.compose env12300 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 570) := by decide +kernel

theorem selectedBound12300 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12301 : List Nat := [2,4,8,16,32,17,9,36,512,52,570,554,41,1,1,537,554,571,52,0,570,538,17,3,40,16,1,16,16,0,558,539,36,33,0,513]

theorem envBound12301 : H12AffineFastState.Bounded env12301 := by
  intro p hp
  have h : env12301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12300_12301 : H12AffineEnvironment.transform 10 570 env12300 = env12301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 570 env12300 == env12301) = true)

def env12302 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13745,34817,1024,32769,4161,21589,120014,16777216,8328,65,16842026,16880845,102878,108926,16797918,16851413,256,16777250,16834951,16873225]

theorem envBound12302 : H12AffineFastState.Bounded env12302 := by
  intro p hp
  have h : env12302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12278_12302 : H12AffineEnvironment.transform 16 13745 env12278 = env12302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13745 env12278 == env12302) = true)

theorem identity12302 : scanCanonicalize (H12AffineFastState.compose env12302 (packedSelected [1,3,7,8,10,12,17,19,20,24,26,27,35,38] rootPS)) = affineNative (2^(23+1) ^^^ 95357) := by decide +kernel

theorem selectedBound12302 : packedSelected [1,3,7,8,10,12,17,19,20,24,26,27,35,38] rootPS < 2^1333 := by decide +kernel

def env12303 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13745,34817,1024,32769,4161,21589,120014,95357,8328,65,100695,57520,102878,108926,74915,21928,256,95327,103930,884]

theorem envBound12303 : H12AffineFastState.Bounded env12303 := by
  intro p hp
  have h : env12303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12302_12303 : H12AffineEnvironment.transform 23 95357 env12302 = env12303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95357 env12302 == env12303) = true)

theorem identity12303 : scanCanonicalize (H12AffineFastState.compose env12303 (packedSelected [0,2,4,5,6,9,15,16,17,23,24,26,27,32,41] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound12303 : packedSelected [0,2,4,5,6,9,15,16,17,23,24,26,27,32,41] rootPS < 2^1333 := by decide +kernel

def env12304 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,29962,13745,34817,1024,32769,4161,21589,41412,375,8328,65,64605,57520,58580,56436,20905,21928,256,341,57584,884]

theorem envBound12304 : H12AffineFastState.Bounded env12304 := by
  intro p hp
  have h : env12304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12303_12304 : H12AffineEnvironment.transform 15 29962 env12303 = env12304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env12303 == env12304) = true)

theorem identity12304 : scanCanonicalize (H12AffineFastState.compose env12304 (packedSelected [0,1,2,6,8,11,12,14,15,17,18,19,27] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound12304 : packedSelected [0,1,2,6,8,11,12,14,15,17,18,19,27] rootPS < 2^1333 := by decide +kernel

def env12305 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,29962,13745,2049,1024,1,4161,21589,8644,375,8328,65,31837,24752,25812,23668,20905,21928,256,341,24816,884]

theorem envBound12305 : H12AffineFastState.Bounded env12305 := by
  intro p hp
  have h : env12305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12304_12305 : H12AffineEnvironment.transform 14 0 env12304 = env12305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env12304 == env12305) = true)

theorem identity12305 : scanCanonicalize (H12AffineFastState.compose env12305 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound12305 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env12306 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,0,29943,13388,2049,1024,1,4161,21589,8249,138,8328,65,31837,24752,25812,23668,20564,21589,253,168,24816,649]

theorem envBound12306 : H12AffineFastState.Bounded env12306 := by
  intro p hp
  have h : env12306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12305_12306 : H12AffineEnvironment.transform 7 253 env12305 = env12306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env12305 == env12306) = true)

theorem identity12306 : scanCanonicalize (H12AffineFastState.compose env12306 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound12306 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12307 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,40,16384,0,21727,5220,2049,1024,1,4161,21589,17,138,160,65,23669,16536,17660,23668,20564,21589,253,168,16600,649]

theorem envBound12307 : H12AffineFastState.Bounded env12307 := by
  intro p hp
  have h : env12307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12306_12307 : H12AffineEnvironment.transform 12 40 env12306 = env12307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env12306 == env12307) = true)

def env12308 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4160,156132,120015,16777216,8328,65,16959643,16880844,102878,108926,16797919,16979045,256,16777250,16834951,16873224]

theorem envBound12308 : H12AffineFastState.Bounded env12308 := by
  intro p hp
  have h : env12308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12277_12308 : H12AffineEnvironment.transform 17 179633 env12277 = env12308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179633 env12277 == env12308) = true)

theorem identity12308 : scanCanonicalize (H12AffineFastState.compose env12308 (packedSelected [21] rootPS)) = affineNative (2^(23+1) ^^^ 95497) := by decide +kernel

theorem selectedBound12308 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12309 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4160,156132,120015,95497,8328,65,245138,57797,102878,108926,75222,156012,256,95531,103566,513]

theorem envBound12309 : H12AffineFastState.Bounded env12309 := by
  intro p hp
  have h : env12309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12308_12309 : H12AffineEnvironment.transform 23 95497 env12308 = env12309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env12308 == env12309) = true)

def env12310 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,156012,119879,95497,8192,65,245018,57677,102742,108926,75102,156012,256,95531,103430,513]

theorem envBound12310 : H12AffineFastState.Bounded env12310 := by
  intro p hp
  have h : env12310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12309_12310 : H12AffineEnvironment.transform 6 8 env12309 = env12310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12309 == env12310) = true)

def env12311 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,156013,119878,95497,8193,65,245019,57676,102743,108926,75103,156012,256,95531,103431,513]

theorem envBound12311 : H12AffineFastState.Bounded env12311 := by
  intro p hp
  have h : env12311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12309_12311 : H12AffineEnvironment.transform 6 9 env12309 = env12311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12309 == env12311) = true)

theorem identity12311 : scanCanonicalize (H12AffineFastState.compose env12311 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound12311 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env12312 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,122147,1024,32769,4160,65910,119878,95497,8193,65,56576,57676,102743,108926,75103,65911,256,95531,103431,513]

theorem envBound12312 : H12AffineFastState.Bounded env12312 := by
  intro p hp
  have h : env12312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12311_12312 : H12AffineEnvironment.transform 16 90139 env12311 = env12312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env12311 == env12312) = true)

theorem identity12312 : scanCanonicalize (H12AffineFastState.compose env12312 (packedSelected [0,1,3,4,8,9,10,11,12,15,18,20,23,24,27,32] rootPS)) = affineNative (2^(15+1) ^^^ 61806) := by decide +kernel

theorem selectedBound12312 : packedSelected [0,1,3,4,8,9,10,11,12,15,18,20,23,24,27,32] rootPS < 2^1333 := by decide +kernel

def env12313 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,61806,37237,11341,1024,32769,4160,61464,9512,33895,8193,65,56576,57676,24633,22544,54321,61465,256,33861,25961,513]

theorem envBound12313 : H12AffineFastState.Bounded env12313 := by
  intro p hp
  have h : env12313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12312_12313 : H12AffineEnvironment.transform 15 61806 env12312 = env12313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 61806 env12312 == env12313) = true)

theorem identity12313 : scanCanonicalize (H12AffineFastState.compose env12313 (packedSelected [1,2,5,6,7,8,11,12,14,15,20,23,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound12313 : packedSelected [1,2,5,6,7,8,11,12,14,15,20,23,24,27] rootPS < 2^1333 := by decide +kernel

def env12314 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,32768,42047,37237,11341,1024,32769,4160,42313,9512,33895,8193,65,34897,46109,13672,3393,33120,42312,256,33861,12344,513]

theorem envBound12314 : H12AffineFastState.Bounded env12314 := by
  intro p hp
  have h : env12314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12313_12314 : H12AffineEnvironment.transform 13 5457 env12313 = env12314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env12313 == env12314) = true)

theorem identity12314 : scanCanonicalize (H12AffineFastState.compose env12314 (packedSelected [11,12,15,23] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound12314 : packedSelected [11,12,15,23] rootPS < 2^1333 := by decide +kernel

def env12315 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,8192,4404,32768,41050,37237,10280,101,32769,4160,41260,8525,32770,8193,65,34897,45176,12557,2340,33120,41261,256,32800,12344,513]

theorem envBound12315 : H12AffineFastState.Bounded env12315 := by
  intro p hp
  have h : env12315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12314_12315 : H12AffineEnvironment.transform 9 101 env12314 = env12315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env12314 == env12315) = true)

theorem identity12315 : scanCanonicalize (H12AffineFastState.compose env12315 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound12315 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env12316 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,8192,4404,373,8495,4096,10280,101,372,4160,8281,8525,375,8193,65,2340,12557,12557,2340,21,8280,256,341,12344,513]

theorem envBound12316 : H12AffineFastState.Bounded env12316 := by
  intro p hp
  have h : env12316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12315_12316 : H12AffineEnvironment.transform 14 373 env12315 = env12316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env12315 == env12316) = true)

theorem identity12316 : scanCanonicalize (H12AffineFastState.compose env12316 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound12316 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env12317 : List Nat := [2,4,8,16,32,64,9,116,512,101,2048,4096,8192,4160,1,8283,4096,10280,101,0,4160,8281,8249,3,8193,65,2128,12409,12409,2128,21,8280,116,33,12344,513]

theorem envBound12317 : H12AffineFastState.Bounded env12317 := by
  intro p hp
  have h : env12317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12316_12317 : H12AffineEnvironment.transform 7 116 env12316 = env12317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env12316 == env12317) = true)

theorem identity12317 : scanCanonicalize (H12AffineFastState.compose env12317 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound12317 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12318 : List Nat := [2,4,8,16,32,64,9,116,512,101,2048,4096,40,4160,1,115,4096,2048,101,0,4160,113,17,3,41,65,2128,4177,4177,2128,21,112,116,33,4112,513]

theorem envBound12318 : H12AffineFastState.Bounded env12318 := by
  intro p hp
  have h : env12318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12317_12318 : H12AffineEnvironment.transform 12 40 env12317 = env12318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env12317 == env12318) = true)

theorem identity12318 : scanCanonicalize (H12AffineFastState.compose env12318 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound12318 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12319 : List Nat := [2,4,8,16,32,58,9,14,512,31,2048,4096,40,4154,1,9,4096,2048,31,0,4154,11,17,3,41,59,2090,4139,4139,2090,21,10,14,33,4112,513]

theorem envBound12319 : H12AffineFastState.Bounded env12319 := by
  intro p hp
  have h : env12319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12318_12319 : H12AffineEnvironment.transform 5 58 env12318 = env12319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env12318 == env12319) = true)

theorem identity12319 : scanCanonicalize (H12AffineFastState.compose env12319 (packedSelected [3,4] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound12319 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env12320 : List Nat := [2,4,8,16,32,58,9,14,512,31,529,4096,40,4154,1,9,4096,529,31,0,4154,11,17,3,41,59,571,4139,4139,571,21,10,14,33,4112,513]

theorem envBound12320 : H12AffineFastState.Bounded env12320 := by
  intro p hp
  have h : env12320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12319_12320 : H12AffineEnvironment.transform 10 529 env12319 = env12320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env12319 == env12320) = true)

theorem identity12320 : scanCanonicalize (H12AffineFastState.compose env12320 (packedSelected [0,2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound12320 : packedSelected [0,2,3,5] rootPS < 2^1333 := by decide +kernel

def env12321 : List Nat := [2,4,8,16,10,16,9,14,512,31,529,4096,2,4112,1,9,4096,529,31,0,4112,11,17,3,3,17,529,4097,4097,529,21,10,14,11,4112,513]

theorem envBound12321 : H12AffineFastState.Bounded env12321 := by
  intro p hp
  have h : env12321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12320_12321 : H12AffineEnvironment.transform 4 10 env12320 = env12321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env12320 == env12321) = true)

theorem identity12321 : scanCanonicalize (H12AffineFastState.compose env12321 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound12321 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env12322 : List Nat := [2,4,8,16,10,16,9,14,512,31,529,513,2,529,1,9,513,529,31,0,529,11,17,3,3,17,529,512,512,529,21,10,14,11,529,513]

theorem envBound12322 : H12AffineFastState.Bounded env12322 := by
  intro p hp
  have h : env12322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12321_12322 : H12AffineEnvironment.transform 11 513 env12321 = env12322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env12321 == env12322) = true)

def env12323 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,156133,485758,16777216,8328,65,16959642,18973836,2571311,108926,17231214,19072036,256,19312083,19287158,17287865]

theorem envBound12323 : H12AffineFastState.Bounded env12323 := by
  intro p hp
  have h : env12323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12242_12323 : H12AffineEnvironment.transform 21 156133 env12242 = env12323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156133 env12242 == env12323) = true)

def env12324 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,156133,485758,16777216,8328,65,16959642,17246588,102879,108926,17231214,17148372,256,16777251,16834950,17287865]

theorem envBound12324 : H12AffineFastState.Bounded env12324 := by
  intro p hp
  have h : env12324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12323_12324 : H12AffineEnvironment.transform 20 437744 env12323 = env12324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437744 env12323 == env12324) = true)

theorem identity12324 : scanCanonicalize (H12AffineFastState.compose env12324 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 362665) := by decide +kernel

theorem selectedBound12324 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env12325 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,156133,485758,362665,8328,65,475187,172501,102879,108926,222663,8573,256,362634,354607,147984]

theorem envBound12325 : H12AffineFastState.Bounded env12325 := by
  intro p hp
  have h : env12325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12324_12325 : H12AffineEnvironment.transform 23 362665 env12324 = env12325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 362665 env12324 == env12325) = true)

def env12326 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,64928,1024,32769,151632,156133,234718,95497,8328,65,245139,172501,102879,108926,222663,8573,256,95530,103567,147984]

theorem envBound12326 : H12AffineFastState.Bounded env12326 := by
  intro p hp
  have h : env12326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12325_12326 : H12AffineEnvironment.transform 17 64928 env12325 = env12326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64928 env12325 == env12326) = true)

theorem identity12326 : scanCanonicalize (H12AffineFastState.compose env12326 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound12326 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,64928,1024,32769,151632,156133,177364,21763,8328,65,171417,172501,45525,35188,148941,8573,256,21792,46213,147984]

theorem envBound12327 : H12AffineFastState.Bounded env12327 := by
  intro p hp
  have h : env12327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12326_12327 : H12AffineEnvironment.transform 15 8202 env12326 = env12327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env12326 == env12327) = true)

theorem identity12327 : scanCanonicalize (H12AffineFastState.compose env12327 (packedSelected [0,1,5,8,9,15,17,22,24,27,38] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound12327 : packedSelected [0,1,5,8,9,15,17,22,24,27,38] rootPS < 2^1333 := by decide +kernel

def env12328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,32768,8202,131072,43249,1024,32769,132353,144564,177364,82,8328,65,171417,172501,45525,35188,135324,8573,256,113,46213,137025]

theorem envBound12328 : H12AffineFastState.Bounded env12328 := by
  intro p hp
  have h : env12328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12327_12328 : H12AffineEnvironment.transform 13 5457 env12327 = env12328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env12327 == env12328) = true)

theorem identity12328 : scanCanonicalize (H12AffineFastState.compose env12328 (packedSelected [16,17,18,19,20,23,26] rootPS)) = affineNative (2^(16+1) ^^^ 46109) := by decide +kernel

theorem selectedBound12328 : packedSelected [16,17,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env12329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,32768,8202,46109,43249,1024,32769,45340,32937,201,82,8328,65,10628,5576,45525,35188,42113,8573,256,113,46213,41820]

theorem envBound12329 : H12AffineFastState.Bounded env12329 := by
  intro p hp
  have h : env12329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12328_12329 : H12AffineEnvironment.transform 16 46109 env12328 = env12329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46109 env12328 == env12329) = true)

theorem identity12329 : scanCanonicalize (H12AffineFastState.compose env12329 (packedSelected [0,1,3,5,7,8,9,11,12,15,17,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound12329 : packedSelected [0,1,3,5,7,8,9,11,12,15,17,18,22] rootPS < 2^1333 := by decide +kernel

def env12330 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5457,32768,262,38161,35325,1024,32769,36880,32937,201,82,388,65,2184,5576,37081,35188,34189,113,256,113,38281,33360]

theorem envBound12330 : H12AffineFastState.Bounded env12330 := by
  intro p hp
  have h : env12330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12329_12330 : H12AffineEnvironment.transform 12 268 env12329 = env12330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env12329 == env12330) = true)

theorem identity12330 : scanCanonicalize (H12AffineFastState.compose env12330 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound12330 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env12331 : List Nat := [2,4,8,16,32,64,128,256,512,52,2048,4096,268,4453,32768,262,37157,35325,52,32769,36880,32937,201,82,388,65,2184,4604,37081,35188,33209,113,256,113,37309,33360]

theorem envBound12331 : H12AffineFastState.Bounded env12331 := by
  intro p hp
  have h : env12331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12330_12331 : H12AffineEnvironment.transform 9 52 env12330 = env12331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env12330 == env12331) = true)

theorem identity12331 : scanCanonicalize (H12AffineFastState.compose env12331 (packedSelected [0,2,6,7,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 6452) := by decide +kernel

theorem selectedBound12331 : packedSelected [0,2,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env12332 : List Nat := [2,4,8,16,32,64,128,256,512,52,2048,4096,268,4453,6452,262,2065,4297,52,6453,2340,6557,201,82,388,65,2184,4604,2541,4160,6285,113,256,113,2185,7012]

theorem envBound12332 : H12AffineFastState.Bounded env12332 := by
  intro p hp
  have h : env12332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12331_12332 : H12AffineEnvironment.transform 14 6452 env12331 = env12332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6452 env12331 == env12332) = true)

theorem identity12332 : scanCanonicalize (H12AffineFastState.compose env12332 (packedSelected [1,4,5,7,12] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound12332 : packedSelected [1,4,5,7,12] rootPS < 2^1333 := by decide +kernel

def env12333 : List Nat := [2,4,8,16,32,64,128,256,512,52,2048,493,268,136,2265,262,2065,292,52,2264,2340,2160,201,82,388,65,2184,17,2541,429,2400,113,256,113,2185,2697]

theorem envBound12333 : H12AffineFastState.Bounded env12333 := by
  intro p hp
  have h : env12333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12332_12333 : H12AffineEnvironment.transform 11 493 env12332 = env12333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env12332 == env12333) = true)

theorem identity12333 : scanCanonicalize (H12AffineFastState.compose env12333 (packedSelected [0,3,4,8,10,15] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound12333 : packedSelected [0,3,4,8,10,15] rootPS < 2^1333 := by decide +kernel

def env12334 : List Nat := [2,4,8,16,32,64,128,256,512,52,292,493,268,136,509,262,309,292,52,508,0,340,201,82,388,65,428,17,201,429,68,113,256,113,429,941]

theorem envBound12334 : H12AffineFastState.Bounded env12334 := by
  intro p hp
  have h : env12334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12333_12334 : H12AffineEnvironment.transform 10 292 env12333 = env12334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env12333 == env12334) = true)

theorem identity12334 : scanCanonicalize (H12AffineFastState.compose env12334 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound12334 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env12335 : List Nat := [2,4,8,16,32,64,8,256,512,52,292,357,268,0,373,262,309,292,52,372,0,340,65,82,268,65,292,17,65,293,68,113,256,113,293,805]

theorem envBound12335 : H12AffineFastState.Bounded env12335 := by
  intro p hp
  have h : env12335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12334_12335 : H12AffineEnvironment.transform 6 8 env12334 = env12335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12334 == env12335) = true)

theorem identity12335 : scanCanonicalize (H12AffineFastState.compose env12335 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound12335 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env12336 : List Nat := [2,4,8,16,32,64,8,116,512,52,80,17,120,0,1,114,65,80,52,0,0,32,65,82,120,65,80,17,65,81,68,113,116,113,81,593]

theorem envBound12336 : H12AffineFastState.Bounded env12336 := by
  intro p hp
  have h : env12336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12335_12336 : H12AffineEnvironment.transform 7 116 env12335 = env12336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env12335 == env12336) = true)

theorem identity12336 : scanCanonicalize (H12AffineFastState.compose env12336 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12336 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12337 : List Nat := [2,4,8,16,32,16,8,36,512,52,0,17,40,0,1,34,17,0,52,0,0,32,17,2,40,17,0,17,17,1,20,33,36,33,1,513]

theorem envBound12337 : H12AffineFastState.Bounded env12337 := by
  intro p hp
  have h : env12337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12336_12337 : H12AffineEnvironment.transform 5 16 env12336 = env12337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12336 == env12337) = true)

theorem identity12337 : scanCanonicalize (H12AffineFastState.compose env12337 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound12337 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12338 : List Nat := [2,4,2,16,32,16,2,36,512,52,0,17,34,0,1,34,17,0,52,0,0,32,17,2,34,17,0,17,17,1,20,33,36,33,1,513]

theorem envBound12338 : H12AffineFastState.Bounded env12338 := by
  intro p hp
  have h : env12338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12337_12338 : H12AffineEnvironment.transform 2 2 env12337 = env12338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env12337 == env12338) = true)

theorem identity12338 : scanCanonicalize (H12AffineFastState.compose env12338 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound12338 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12339 : List Nat := [2,4,2,16,17,16,2,21,512,5,0,17,19,0,1,19,17,0,5,0,0,17,17,2,19,17,0,17,17,1,20,16,21,16,1,513]

theorem envBound12339 : H12AffineFastState.Bounded env12339 := by
  intro p hp
  have h : env12339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12338_12339 : H12AffineEnvironment.transform 4 17 env12338 = env12339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env12338 == env12339) = true)

theorem identity12339 : scanCanonicalize (H12AffineFastState.compose env12339 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound12339 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env12340 : List Nat := [2,4,2,16,17,16,2,21,1,5,0,17,19,0,1,19,17,0,5,0,0,17,17,2,19,17,0,17,17,1,20,16,21,16,1,0]

theorem envBound12340 : H12AffineFastState.Bounded env12340 := by
  intro p hp
  have h : env12340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12339_12340 : H12AffineEnvironment.transform 8 1 env12339 = env12340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env12339 == env12340) = true)

theorem identity12340 : scanCanonicalize (H12AffineFastState.compose env12340 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound12340 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env12341 : List Nat := [2,4,2,1,0,1,2,4,1,5,0,0,2,0,1,2,0,0,5,0,0,0,0,2,2,0,0,0,0,1,5,1,4,1,1,0]

theorem envBound12341 : H12AffineFastState.Bounded env12341 := by
  intro p hp
  have h : env12341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12340_12341 : H12AffineEnvironment.transform 3 1 env12340 = env12341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env12340 == env12341) = true)

def env12342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,64929,1024,32769,151633,156133,234719,95496,8328,65,245138,172501,102879,108926,222663,8573,256,95531,103566,147984]

theorem envBound12342 : H12AffineFastState.Bounded env12342 := by
  intro p hp
  have h : env12342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12325_12342 : H12AffineEnvironment.transform 17 64929 env12325 = env12342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64929 env12325 == env12342) = true)

theorem identity12342 : scanCanonicalize (H12AffineFastState.compose env12342 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound12342 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12343 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90139,64929,1024,32769,77898,66046,62660,95496,8328,65,56713,115150,102879,108926,1500,8573,256,95531,103566,74251]

theorem envBound12343 : H12AffineFastState.Bounded env12343 := by
  intro p hp
  have h : env12343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12342_12343 : H12AffineEnvironment.transform 16 90139 env12342 = env12343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env12342 == env12343) = true)

theorem identity12343 : scanCanonicalize (H12AffineFastState.compose env12343 (packedSelected [1,3,4,5,7,8,9,10,15,16,17,20,26,27,38] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound12343 : packedSelected [1,3,4,5,7,8,9,10,15,16,17,20,26,27,38] rootPS < 2^1333 := by decide +kernel

def env12344 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,32768,65536,79179,43249,1024,32769,77898,66046,41364,73816,8328,65,35033,103582,102879,108926,1500,8573,256,73851,103566,74251]

theorem envBound12344 : H12AffineFastState.Bounded env12344 := by
  intro p hp
  have h : env12344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12343_12344 : H12AffineEnvironment.transform 13 5456 env12343 = env12344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env12343 == env12344) = true)

theorem identity12344 : scanCanonicalize (H12AffineFastState.compose env12344 (packedSelected [0,4,7,17,18,19,22,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound12344 : packedSelected [0,4,7,17,18,19,22,23,26] rootPS < 2^1333 := by decide +kernel

def env12345 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,8541,65536,79179,2476,1024,8540,77898,66046,201,73816,8328,65,10628,79299,77954,67619,1500,8573,256,73851,79315,74251]

theorem envBound12345 : H12AffineFastState.Bounded env12345 := by
  intro p hp
  have h : env12345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12344_12345 : H12AffineEnvironment.transform 14 8541 env12344 = env12345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env12344 == env12345) = true)

theorem identity12345 : scanCanonicalize (H12AffineFastState.compose env12345 (packedSelected [10,11,12,14,15,16,17,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 8403) := by decide +kernel

theorem selectedBound12345 : packedSelected [10,11,12,14,15,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env12346 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,8541,8403,5528,2476,1024,8540,4249,8493,201,139,8328,65,10628,5392,4177,10480,1500,8573,256,168,5376,728]

theorem envBound12346 : H12AffineFastState.Bounded env12346 := by
  intro p hp
  have h : env12346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12345_12346 : H12AffineEnvironment.transform 15 8403 env12345 = env12346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8403 env12345 == env12346) = true)

theorem identity12346 : scanCanonicalize (H12AffineFastState.compose env12346 (packedSelected [1,3,5,8,11,12,14,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound12346 : packedSelected [1,3,5,8,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env12347 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5456,137,263,5528,2476,1024,136,4249,249,201,139,348,65,2128,5392,4177,2340,1500,169,256,168,5376,728]

theorem envBound12347 : H12AffineFastState.Bounded env12347 := by
  intro p hp
  have h : env12347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12346_12347 : H12AffineEnvironment.transform 12 468 env12346 = env12347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env12346 == env12347) = true)

theorem identity12347 : scanCanonicalize (H12AffineFastState.compose env12347 (packedSelected [0,7,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound12347 : packedSelected [0,7,10,11] rootPS < 2^1333 := by decide +kernel

def env12348 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,4096,468,4541,137,263,4469,2476,237,136,4249,249,201,139,348,65,2128,4605,4177,2340,305,169,256,168,4589,728]

theorem envBound12348 : H12AffineFastState.Bounded env12348 := by
  intro p hp
  have h : env12348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12347_12348 : H12AffineEnvironment.transform 9 237 env12347 = env12348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env12347 == env12348) = true)

theorem identity12348 : scanCanonicalize (H12AffineFastState.compose env12348 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound12348 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env12349 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,349,4404,0,263,4469,2341,100,1,4112,112,64,2,348,65,2128,4468,4177,2340,305,32,256,33,4452,593]

theorem envBound12349 : H12AffineFastState.Bounded env12349 := by
  intro p hp
  have h : env12349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12348_12349 : H12AffineEnvironment.transform 6 9 env12348 = env12349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12348 == env12349) = true)

theorem identity12349 : scanCanonicalize (H12AffineFastState.compose env12349 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12349 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env12350 : List Nat := [2,4,8,16,32,64,9,36,512,100,2048,4096,121,4112,0,35,4177,2049,100,1,4112,112,64,2,120,65,2128,4176,4177,2048,21,32,36,33,4160,593]

theorem envBound12350 : H12AffineFastState.Bounded env12350 := by
  intro p hp
  have h : env12350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12349_12350 : H12AffineEnvironment.transform 7 36 env12349 = env12350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12349 == env12350) = true)

theorem identity12350 : scanCanonicalize (H12AffineFastState.compose env12350 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12350 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env12351 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,4096,41,4112,0,35,4097,2049,52,1,4112,32,16,2,40,17,2048,4096,4097,2048,21,32,36,33,4112,513]

theorem envBound12351 : H12AffineFastState.Bounded env12351 := by
  intro p hp
  have h : env12351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12350_12351 : H12AffineEnvironment.transform 5 16 env12350 = env12351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12350 == env12351) = true)

theorem identity12351 : scanCanonicalize (H12AffineFastState.compose env12351 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound12351 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12352 : List Nat := [2,4,8,16,32,16,9,36,512,52,17,4096,41,4112,0,35,4097,16,52,1,4112,32,16,2,40,17,17,4096,4097,17,21,32,36,33,4112,513]

theorem envBound12352 : H12AffineFastState.Bounded env12352 := by
  intro p hp
  have h : env12352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12351_12352 : H12AffineEnvironment.transform 10 17 env12351 = env12352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env12351 == env12352) = true)

theorem identity12352 : scanCanonicalize (H12AffineFastState.compose env12352 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound12352 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12353 : List Nat := [2,4,8,16,32,16,9,36,10,52,17,4096,41,4112,0,35,4097,16,52,1,4112,32,16,2,40,17,17,4096,4097,17,21,32,36,33,4112,11]

theorem envBound12353 : H12AffineFastState.Bounded env12353 := by
  intro p hp
  have h : env12353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12352_12353 : H12AffineEnvironment.transform 8 10 env12352 = env12353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env12352 == env12353) = true)

theorem identity12353 : scanCanonicalize (H12AffineFastState.compose env12353 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound12353 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12354 : List Nat := [2,4,8,16,32,16,9,36,10,52,17,16,41,0,0,35,17,16,52,1,0,32,16,2,40,17,17,16,17,17,21,32,36,33,0,11]

theorem envBound12354 : H12AffineFastState.Bounded env12354 := by
  intro p hp
  have h : env12354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12353_12354 : H12AffineEnvironment.transform 11 16 env12353 = env12354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env12353 == env12354) = true)

def env12355 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,156133,485758,16777216,8328,65,16959642,17246589,102878,108926,17231214,17148373,256,16777250,16834951,17287865]

theorem envBound12355 : H12AffineFastState.Bounded env12355 := by
  intro p hp
  have h : env12355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12323_12355 : H12AffineEnvironment.transform 20 437745 env12323 = env12355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437745 env12323 == env12355) = true)

theorem identity12355 : scanCanonicalize (H12AffineFastState.compose env12355 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 223598) := by decide +kernel

theorem selectedBound12355 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env12356 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,115871,156133,16,16777216,8328,65,16959642,16793619,102878,108926,16876544,16957627,256,16777250,16834951,16819159]

theorem envBound12356 : H12AffineFastState.Bounded env12356 := by
  intro p hp
  have h : env12356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12355_12356 : H12AffineEnvironment.transform 17 223598 env12355 = env12356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223598 env12355 == env12356) = true)

def env12357 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,115871,156133,16,95496,8328,65,245138,79131,102878,108926,61704,243123,256,95530,103567,120543]

theorem envBound12357 : H12AffineFastState.Bounded env12357 := by
  intro p hp
  have h : env12357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12356_12357 : H12AffineEnvironment.transform 23 95496 env12356 = env12357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env12356 == env12357) = true)

theorem identity12357 : scanCanonicalize (H12AffineFastState.compose env12357 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound12357 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,179632,1024,32769,4161,156133,16,41430,8328,65,158028,57797,17664,32160,61704,156013,256,41460,16465,513]

theorem envBound12358 : H12AffineFastState.Bounded env12358 := by
  intro p hp
  have h : env12358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12357_12358 : H12AffineEnvironment.transform 15 54494 env12357 = env12358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env12357 == env12358) = true)

def env12359 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,179512,1024,32769,4161,156013,16,41310,8192,65,158028,57677,17664,32040,61704,156013,256,41340,16465,513]

theorem envBound12359 : H12AffineFastState.Bounded env12359 := by
  intro p hp
  have h : env12359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12358_12359 : H12AffineEnvironment.transform 6 8 env12358 = env12359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12358 == env12359) = true)

theorem identity12359 : scanCanonicalize (H12AffineFastState.compose env12359 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound12359 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12360 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38161,10281,1024,32769,4161,62588,16,41310,8192,65,64605,57677,17664,32040,61704,62588,256,41340,16465,513]

theorem envBound12360 : H12AffineFastState.Bounded env12360 := by
  intro p hp
  have h : env12360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12359_12360 : H12AffineEnvironment.transform 16 38161 env12359 = env12360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env12359 == env12360) = true)

theorem identity12360 : scanCanonicalize (H12AffineFastState.compose env12360 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound12360 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env12361 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,38161,10281,1024,32769,4161,41340,16,41310,8192,65,43357,46157,4096,10280,41992,41340,256,41340,5457,513]

theorem envBound12361 : H12AffineFastState.Bounded env12361 := by
  intro p hp
  have h : env12361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12360_12361 : H12AffineEnvironment.transform 13 5376 env12360 = env12361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env12360 == env12361) = true)

theorem identity12361 : scanCanonicalize (H12AffineFastState.compose env12361 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound12361 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12362 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,32768,32803,37988,10281,1024,32769,4161,40969,16,41003,8192,65,43048,46157,4096,10280,41992,40969,117,40969,5156,513]

theorem envBound12362 : H12AffineFastState.Bounded env12362 := by
  intro p hp
  have h : env12362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12361_12362 : H12AffineEnvironment.transform 7 117 env12361 = env12362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env12361 == env12362) = true)

theorem identity12362 : scanCanonicalize (H12AffineFastState.compose env12362 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound12362 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env12363 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,81,114,5173,10281,1024,80,4161,8280,16,8314,8192,65,10361,13340,4096,10280,9305,8280,117,8280,5156,513]

theorem envBound12363 : H12AffineFastState.Bounded env12363 := by
  intro p hp
  have h : env12363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12362_12363 : H12AffineEnvironment.transform 14 81 env12362 = env12363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env12362 == env12363) = true)

theorem identity12363 : scanCanonicalize (H12AffineFastState.compose env12363 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound12363 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env12364 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,120,5237,81,114,5173,2129,1024,80,4161,32,16,2,120,65,2049,5220,4096,2128,1057,32,117,32,5156,513]

theorem envBound12364 : H12AffineFastState.Bounded env12364 := by
  intro p hp
  have h : env12364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12363_12364 : H12AffineEnvironment.transform 12 120 env12363 = env12364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env12363 == env12364) = true)

theorem identity12364 : scanCanonicalize (H12AffineFastState.compose env12364 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound12364 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env12365 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,17,120,1124,81,114,1060,2129,1024,80,80,32,16,2,120,65,2049,1141,17,2128,1057,32,117,32,1077,513]

theorem envBound12365 : H12AffineFastState.Bounded env12365 := by
  intro p hp
  have h : env12365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12364_12365 : H12AffineEnvironment.transform 11 17 env12364 = env12365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env12364 == env12365) = true)

theorem identity12365 : scanCanonicalize (H12AffineFastState.compose env12365 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound12365 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env12366 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1124,17,120,1124,81,114,1060,1077,1024,80,80,32,16,2,120,65,1125,1141,17,1076,1057,32,117,32,1077,513]

theorem envBound12366 : H12AffineFastState.Bounded env12366 := by
  intro p hp
  have h : env12366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12365_12366 : H12AffineEnvironment.transform 10 1124 env12365 = env12366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env12365 == env12366) = true)

theorem identity12366 : scanCanonicalize (H12AffineFastState.compose env12366 (packedSelected [2,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12366 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env12367 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1076,17,40,1076,1,34,1060,1077,1024,0,0,32,16,2,40,17,1077,1061,17,1076,1057,32,37,32,1077,513]

theorem envBound12367 : H12AffineFastState.Bounded env12367 := by
  intro p hp
  have h : env12367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12366_12367 : H12AffineEnvironment.transform 5 16 env12366 = env12367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12366 == env12367) = true)

theorem identity12367 : scanCanonicalize (H12AffineFastState.compose env12367 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound12367 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12368 : List Nat := [2,4,8,1,32,1,8,37,512,1024,1061,0,40,1061,1,34,1060,1060,1024,0,0,32,1,2,40,0,1060,1061,0,1061,1057,32,37,32,1060,513]

theorem envBound12368 : H12AffineFastState.Bounded env12368 := by
  intro p hp
  have h : env12368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12367_12368 : H12AffineEnvironment.transform 3 1 env12367 = env12368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env12367 == env12368) = true)

theorem identity12368 : scanCanonicalize (H12AffineFastState.compose env12368 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound12368 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12369 : List Nat := [2,4,8,1,32,1,8,37,512,47,10,0,40,10,1,34,11,11,47,0,0,32,1,2,40,0,11,10,0,10,14,32,37,32,11,513]

theorem envBound12369 : H12AffineFastState.Bounded env12369 := by
  intro p hp
  have h : env12369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12368_12369 : H12AffineEnvironment.transform 9 47 env12368 = env12369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env12368 == env12369) = true)

theorem identity12369 : scanCanonicalize (H12AffineFastState.compose env12369 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound12369 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12370 : List Nat := [2,4,8,1,11,1,8,14,512,4,10,0,3,10,1,9,11,11,4,0,0,11,1,2,3,0,11,10,0,10,14,11,14,11,11,513]

theorem envBound12370 : H12AffineFastState.Bounded env12370 := by
  intro p hp
  have h : env12370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12369_12370 : H12AffineEnvironment.transform 4 11 env12369 = env12370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env12369 == env12370) = true)

theorem identity12370 : scanCanonicalize (H12AffineFastState.compose env12370 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound12370 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12371 : List Nat := [2,0,8,1,11,1,8,10,512,0,10,0,3,10,1,9,11,11,0,0,0,11,1,2,3,0,11,10,0,10,10,11,10,11,11,513]

theorem envBound12371 : H12AffineFastState.Bounded env12371 := by
  intro p hp
  have h : env12371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12370_12371 : H12AffineEnvironment.transform 1 0 env12370 = env12371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env12370 == env12371) = true)

theorem identity12371 : scanCanonicalize (H12AffineFastState.compose env12371 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound12371 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env12372 : List Nat := [2,0,2,1,1,1,2,0,512,0,0,0,3,0,1,3,1,1,0,0,0,1,1,2,3,0,1,0,0,0,0,1,0,1,1,513]

theorem envBound12372 : H12AffineFastState.Bounded env12372 := by
  intro p hp
  have h : env12372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12371_12372 : H12AffineEnvironment.transform 2 2 env12371 = env12372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env12371 == env12372) = true)

theorem identity12372 : scanCanonicalize (H12AffineFastState.compose env12372 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound12372 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12373 : List Nat := [0,0,0,1,1,1,0,0,512,0,0,0,1,0,1,1,1,1,0,0,0,1,1,0,1,0,1,0,0,0,0,1,0,1,1,513]

theorem envBound12373 : H12AffineFastState.Bounded env12373 := by
  intro p hp
  have h : env12373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12372_12373 : H12AffineEnvironment.transform 0 0 env12372 = env12373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env12372 == env12373) = true)

def env12374 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,179513,1024,32769,4161,156012,16,41311,8193,65,158028,57676,17664,32041,61704,156013,256,41341,16465,513]

theorem envBound12374 : H12AffineFastState.Bounded env12374 := by
  intro p hp
  have h : env12374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12358_12374 : H12AffineEnvironment.transform 6 9 env12358 = env12374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12358 == env12374) = true)

theorem identity12374 : scanCanonicalize (H12AffineFastState.compose env12374 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound12374 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12375 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,13388,35189,1024,32769,4161,21792,16,41311,8193,65,23808,57676,17664,32041,61704,21793,256,41341,16465,513]

theorem envBound12375 : H12AffineFastState.Bounded env12375 := by
  intro p hp
  have h : env12375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12374_12375 : H12AffineEnvironment.transform 16 13388 env12374 = env12375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env12374 == env12375) = true)

theorem identity12375 : scanCanonicalize (H12AffineFastState.compose env12375 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound12375 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env12376 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,9292,28699,13388,11577,1024,9293,4161,21792,16,1299,8193,65,23808,17664,17664,32041,21828,21793,256,1329,16465,513]

theorem envBound12376 : H12AffineFastState.Bounded env12376 := by
  intro p hp
  have h : env12376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12375_12376 : H12AffineEnvironment.transform 14 9292 env12375 = env12376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env12375 == env12376) = true)

theorem identity12376 : scanCanonicalize (H12AffineFastState.compose env12376 (packedSelected [1,8,19] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound12376 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env12377 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,16384,0,21591,4096,2421,1024,1,4161,21792,16,1299,1101,65,23808,17664,17664,22885,21828,21793,256,1329,16465,513]

theorem envBound12377 : H12AffineFastState.Bounded env12377 := by
  intro p hp
  have h : env12377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12376_12377 : H12AffineEnvironment.transform 12 1100 env12376 = env12377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env12376 == env12377) = true)

theorem identity12377 : scanCanonicalize (H12AffineFastState.compose env12377 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound12377 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env12378 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,348,16384,0,20807,4096,2421,272,1,4161,20528,16,3,349,65,22544,16400,16400,22885,20564,20529,256,33,16465,513]

theorem envBound12378 : H12AffineFastState.Bounded env12378 := by
  intro p hp
  have h : env12378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12377_12378 : H12AffineEnvironment.transform 9 272 env12377 = env12378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env12377 == env12378) = true)

theorem identity12378 : scanCanonicalize (H12AffineFastState.compose env12378 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound12378 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env12379 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,16,348,16384,0,16727,16,2421,272,1,81,16416,16,3,349,65,18432,16400,16400,18805,16452,16417,256,33,16465,513]

theorem envBound12379 : H12AffineFastState.Bounded env12379 := by
  intro p hp
  have h : env12379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12378_12379 : H12AffineEnvironment.transform 11 16 env12378 = env12379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env12378 == env12379) = true)

theorem identity12379 : scanCanonicalize (H12AffineFastState.compose env12379 (packedSelected [0,6,7] rootPS)) = affineNative (2^(13+1) ^^^ 373) := by decide +kernel

theorem selectedBound12379 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env12380 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,16,348,373,0,34,16,2421,272,1,81,341,16,3,349,65,2421,357,357,2048,305,340,256,33,292,513]

theorem envBound12380 : H12AffineFastState.Bounded env12380 := by
  intro p hp
  have h : env12380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12379_12380 : H12AffineEnvironment.transform 13 373 env12379 = env12380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 373 env12379 == env12380) = true)

theorem identity12380 : scanCanonicalize (H12AffineFastState.compose env12380 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound12380 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env12381 : List Nat := [2,4,8,16,32,64,9,21,512,5,2048,16,73,96,0,34,16,2144,5,1,81,64,16,3,72,65,2144,112,112,2048,36,65,21,33,49,513]

theorem envBound12381 : H12AffineFastState.Bounded env12381 := by
  intro p hp
  have h : env12381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12380_12381 : H12AffineEnvironment.transform 7 21 env12380 = env12381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env12380 == env12381) = true)

theorem identity12381 : scanCanonicalize (H12AffineFastState.compose env12381 (packedSelected [0,2,6] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound12381 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env12382 : List Nat := [2,4,8,16,32,64,9,21,512,5,529,16,73,96,0,34,16,625,5,1,81,64,16,3,72,65,625,112,112,529,36,65,21,33,49,513]

theorem envBound12382 : H12AffineFastState.Bounded env12382 := by
  intro p hp
  have h : env12382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12381_12382 : H12AffineEnvironment.transform 10 529 env12381 = env12382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env12381 == env12382) = true)

theorem identity12382 : scanCanonicalize (H12AffineFastState.compose env12382 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound12382 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env12383 : List Nat := [2,4,8,16,32,64,9,21,64,5,81,16,73,96,0,34,16,49,5,1,81,64,16,3,72,65,49,112,112,81,36,65,21,33,49,65]

theorem envBound12383 : H12AffineFastState.Bounded env12383 := by
  intro p hp
  have h : env12383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12382_12383 : H12AffineEnvironment.transform 8 64 env12382 = env12383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env12382 == env12383) = true)

theorem identity12383 : scanCanonicalize (H12AffineFastState.compose env12383 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound12383 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env12384 : List Nat := [2,4,8,16,32,33,9,21,33,5,48,16,40,1,0,34,16,49,5,1,48,33,16,3,41,32,49,17,17,48,36,32,21,33,49,32]

theorem envBound12384 : H12AffineFastState.Bounded env12384 := by
  intro p hp
  have h : env12384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12383_12384 : H12AffineEnvironment.transform 5 33 env12383 = env12384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env12383 == env12384) = true)

def env12385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,115871,156133,16,95497,8328,65,245139,79130,102878,108926,61705,243122,256,95531,103566,120542]

theorem envBound12385 : H12AffineFastState.Bounded env12385 := by
  intro p hp
  have h : env12385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12356_12385 : H12AffineEnvironment.transform 23 95497 env12356 = env12385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env12356 == env12385) = true)

def env12386 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,115735,156013,16,95497,8192,65,245019,79130,102742,108926,61705,243002,256,95531,103430,120406]

theorem envBound12386 : H12AffineFastState.Bounded env12386 := by
  intro p hp
  have h : env12386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12385_12386 : H12AffineEnvironment.transform 6 8 env12385 = env12386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12385 == env12386) = true)

theorem identity12386 : scanCanonicalize (H12AffineFastState.compose env12386 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound12386 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12387 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,130174,1024,32769,115735,62589,16,95497,8192,65,75787,79130,102742,108926,61705,73770,256,95531,103430,120406]

theorem envBound12387 : H12AffineFastState.Bounded env12387 := by
  intro p hp
  have h : env12387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12386_12387 : H12AffineEnvironment.transform 16 38160 env12386 = env12387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env12386 == env12387) = true)

theorem identity12387 : scanCanonicalize (H12AffineFastState.compose env12387 (packedSelected [1,3,8,9,12,16,19,22,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound12387 : packedSelected [1,3,8,9,12,16,19,22,23,24] rootPS < 2^1333 := by decide +kernel

def env12388 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,262,38160,64888,1024,32769,50449,62589,16,29711,8192,65,10509,13340,36944,43128,61705,8492,256,29741,38144,55120]

theorem envBound12388 : H12AffineFastState.Bounded env12388 := by
  intro p hp
  have h : env12388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12387_12388 : H12AffineEnvironment.transform 15 262 env12387 = env12388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env12387 == env12388) = true)

theorem identity12388 : scanCanonicalize (H12AffineFastState.compose env12388 (packedSelected [0,1,2,6,7,8,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound12388 : packedSelected [0,1,2,6,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env12389 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,262,38160,35109,1024,32769,45388,32800,16,82,8192,65,10509,13340,36944,43128,34132,8492,256,112,38144,41741]

theorem envBound12389 : H12AffineFastState.Bounded env12389 := by
  intro p hp
  have h : env12389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12388_12389 : H12AffineEnvironment.transform 13 13405 env12388 = env12389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env12388 == env12389) = true)

theorem identity12389 : scanCanonicalize (H12AffineFastState.compose env12389 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound12389 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env12390 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,80,262,5440,2421,1024,81,12572,112,16,82,8192,65,10509,13340,4096,10280,1284,8492,256,112,5456,9053]

theorem envBound12390 : H12AffineFastState.Bounded env12390 := by
  intro p hp
  have h : env12390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12389_12390 : H12AffineEnvironment.transform 14 80 env12389 = env12390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env12389 == env12390) = true)

theorem identity12390 : scanCanonicalize (H12AffineFastState.compose env12390 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound12390 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env12391 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5237,80,262,5440,2421,1024,81,4404,112,16,82,40,65,2341,5172,4096,2048,1284,260,256,112,5456,885]

theorem envBound12391 : H12AffineFastState.Bounded env12391 := by
  intro p hp
  have h : env12391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12390_12391 : H12AffineEnvironment.transform 12 40 env12390 = env12391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env12390 == env12391) = true)

theorem identity12391 : scanCanonicalize (H12AffineFastState.compose env12391 (packedSelected [0,1,2,3,5,7,8,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound12391 : packedSelected [0,1,2,3,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env12392 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,40,5237,80,35,5221,2128,1024,81,4113,112,16,82,40,65,2048,5172,4096,2048,1057,33,37,112,5237,592]

theorem envBound12392 : H12AffineFastState.Bounded env12392 := by
  intro p hp
  have h : env12392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12391_12392 : H12AffineEnvironment.transform 7 37 env12391 = env12392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env12391 == env12392) = true)

theorem identity12392 : scanCanonicalize (H12AffineFastState.compose env12392 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound12392 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env12393 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,3109,40,2128,80,35,2112,2128,1024,81,3124,112,16,82,40,65,2048,2065,3109,2048,1057,33,37,112,2128,592]

theorem envBound12393 : H12AffineFastState.Bounded env12393 := by
  intro p hp
  have h : env12393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12392_12393 : H12AffineEnvironment.transform 11 3109 env12392 = env12393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env12392 == env12393) = true)

theorem identity12393 : scanCanonicalize (H12AffineFastState.compose env12393 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12393 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env12394 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,3109,40,2048,0,35,2064,2048,1024,1,3124,32,16,2,40,17,2048,2065,3109,2048,1057,33,37,32,2048,512]

theorem envBound12394 : H12AffineFastState.Bounded env12394 := by
  intro p hp
  have h : env12394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12393_12394 : H12AffineEnvironment.transform 5 16 env12393 = env12394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12393 == env12394) = true)

theorem identity12394 : scanCanonicalize (H12AffineFastState.compose env12394 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound12394 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12395 : List Nat := [2,4,8,16,32,16,8,37,512,20,2048,2097,40,2048,0,35,2064,2048,20,1,2080,32,16,2,40,17,2048,2065,2097,2048,53,33,37,32,2048,512]

theorem envBound12395 : H12AffineFastState.Bounded env12395 := by
  intro p hp
  have h : env12395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12394_12395 : H12AffineEnvironment.transform 9 20 env12394 = env12395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env12394 == env12395) = true)

theorem identity12395 : scanCanonicalize (H12AffineFastState.compose env12395 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound12395 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12396 : List Nat := [2,4,8,16,32,16,8,37,512,20,554,539,40,554,0,35,570,554,20,1,522,32,16,2,40,17,554,571,539,554,53,33,37,32,554,512]

theorem envBound12396 : H12AffineFastState.Bounded env12396 := by
  intro p hp
  have h : env12396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12395_12396 : H12AffineEnvironment.transform 10 554 env12395 = env12396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env12395 == env12396) = true)

theorem identity12396 : scanCanonicalize (H12AffineFastState.compose env12396 (packedSelected [0,1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound12396 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env12397 : List Nat := [0,4,8,16,32,16,8,37,512,20,552,537,40,552,0,33,568,552,20,1,520,32,16,0,40,17,552,569,537,552,53,33,37,32,552,512]

theorem envBound12397 : H12AffineFastState.Bounded env12397 := by
  intro p hp
  have h : env12397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12396_12397 : H12AffineEnvironment.transform 0 0 env12396 = env12397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env12396 == env12397) = true)

theorem identity12397 : scanCanonicalize (H12AffineFastState.compose env12397 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12397 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12398 : List Nat := [0,4,8,16,1,16,8,4,512,20,521,537,9,521,0,0,537,521,20,1,520,1,16,0,9,17,521,536,537,521,20,0,4,1,521,512]

theorem envBound12398 : H12AffineFastState.Bounded env12398 := by
  intro p hp
  have h : env12398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12397_12398 : H12AffineEnvironment.transform 4 1 env12397 = env12398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12397 == env12398) = true)

theorem identity12398 : scanCanonicalize (H12AffineFastState.compose env12398 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound12398 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12399 : List Nat := [0,0,8,16,1,16,8,0,512,16,521,537,9,521,0,0,537,521,16,1,520,1,16,0,9,17,521,536,537,521,16,0,0,1,521,512]

theorem envBound12399 : H12AffineFastState.Bounded env12399 := by
  intro p hp
  have h : env12399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12398_12399 : H12AffineEnvironment.transform 1 0 env12398 = env12399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env12398 == env12399) = true)

def env12400 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,115734,156012,16,95497,8193,65,245018,79130,102743,108926,61705,243003,256,95531,103431,120407]

theorem envBound12400 : H12AffineFastState.Bounded env12400 := by
  intro p hp
  have h : env12400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12385_12400 : H12AffineEnvironment.transform 6 9 env12385 = env12400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12385 == env12400) = true)

theorem identity12400 : scanCanonicalize (H12AffineFastState.compose env12400 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound12400 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12401 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13389,89379,1024,32769,115734,21793,16,95497,8193,65,100695,79130,102743,108926,61705,98678,256,95531,103431,120407]

theorem envBound12401 : H12AffineFastState.Bounded env12401 := by
  intro p hp
  have h : env12401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12400_12401 : H12AffineEnvironment.transform 16 13389 env12400 = env12401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env12400 == env12401) = true)

theorem identity12401 : scanCanonicalize (H12AffineFastState.compose env12401 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound12401 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env12402 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21590,13389,2421,1024,32769,36928,21793,16,8543,8193,65,56577,24908,50433,64808,61705,54560,256,8573,49233,33281]

theorem envBound12402 : H12AffineFastState.Bounded env12402 := by
  intro p hp
  have h : env12402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12401_12402 : H12AffineEnvironment.transform 15 21590 env12401 = env12402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env12401 == env12402) = true)

theorem identity12402 : scanCanonicalize (H12AffineFastState.compose env12402 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound12402 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env12403 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,21590,5393,2421,1024,32769,36928,21793,16,3,349,65,56577,16400,50433,56436,53333,54560,256,33,49233,33281]

theorem envBound12403 : H12AffineFastState.Bounded env12403 := by
  intro p hp
  have h : env12403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12402_12403 : H12AffineEnvironment.transform 12 348 env12402 = env12403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env12402 == env12403) = true)

theorem identity12403 : scanCanonicalize (H12AffineFastState.compose env12403 (packedSelected [4,9,12,14,15,20] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound12403 : packedSelected [4,9,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env12404 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,16384,32768,21590,5220,2048,1024,32769,36928,21588,16,3,40,65,56436,16400,50292,56436,53333,54357,117,33,49233,33281]

theorem envBound12404 : H12AffineFastState.Bounded env12404 := by
  intro p hp
  have h : env12404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12403_12404 : H12AffineEnvironment.transform 7 117 env12403 = env12404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env12403 == env12404) = true)

theorem identity12404 : scanCanonicalize (H12AffineFastState.compose env12404 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 21621) := by decide +kernel

theorem selectedBound12404 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env12405 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,16384,21621,21590,5220,2048,1024,21620,17461,21588,16,3,40,65,2049,16400,4097,2049,1056,32,117,33,5156,22132]

theorem envBound12405 : H12AffineFastState.Bounded env12405 := by
  intro p hp
  have h : env12405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12404_12405 : H12AffineEnvironment.transform 14 21621 env12404 = env12405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21621 env12404 == env12405) = true)

theorem identity12405 : scanCanonicalize (H12AffineFastState.compose env12405 (packedSelected [4,6,9,12] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound12405 : packedSelected [4,6,9,12] rootPS < 2^1333 := by decide +kernel

def env12406 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5236,1,34,5220,2048,1024,0,4161,32,16,3,40,65,2049,5220,4097,2049,1056,32,117,33,5156,512]

theorem envBound12406 : H12AffineFastState.Bounded env12406 := by
  intro p hp
  have h : env12406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12405_12406 : H12AffineEnvironment.transform 13 5236 env12405 = env12406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env12405 == env12406) = true)

theorem identity12406 : scanCanonicalize (H12AffineFastState.compose env12406 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound12406 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12407 : List Nat := [2,4,8,16,32,64,9,117,512,1024,554,4096,41,5236,1,34,5220,554,1024,0,4161,32,16,3,40,65,555,5220,4097,555,1056,32,117,33,5156,512]

theorem envBound12407 : H12AffineFastState.Bounded env12407 := by
  intro p hp
  have h : env12407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12406_12407 : H12AffineEnvironment.transform 10 554 env12406 = env12407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env12406 == env12407) = true)

theorem identity12407 : scanCanonicalize (H12AffineFastState.compose env12407 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound12407 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12408 : List Nat := [2,4,8,16,32,48,9,5,512,1024,554,4096,41,5124,1,34,5140,554,1024,0,4145,32,16,3,40,49,555,5140,4097,555,1056,32,5,33,5156,512]

theorem envBound12408 : H12AffineFastState.Bounded env12408 := by
  intro p hp
  have h : env12408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12407_12408 : H12AffineEnvironment.transform 5 48 env12407 = env12408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env12407 == env12408) = true)

theorem identity12408 : scanCanonicalize (H12AffineFastState.compose env12408 (packedSelected [5,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12408 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env12409 : List Nat := [2,4,8,16,1,17,9,5,512,1024,523,4096,8,5124,1,3,5140,523,1024,0,4112,1,16,3,9,16,522,5140,4097,522,1025,1,5,0,5125,512]

theorem envBound12409 : H12AffineFastState.Bounded env12409 := by
  intro p hp
  have h : env12409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12408_12409 : H12AffineEnvironment.transform 4 1 env12408 = env12409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12408 == env12409) = true)

def env12410 : List Nat := [2,4,8,16,1,17,9,5,512,1024,523,16,8,1044,1,3,1028,523,1024,0,0,1,16,3,9,16,522,1028,17,522,1025,1,5,0,1045,512]

theorem envBound12410 : H12AffineFastState.Bounded env12410 := by
  intro p hp
  have h : env12410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12409_12410 : H12AffineEnvironment.transform 11 16 env12409 = env12410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env12409 == env12410) = true)

theorem identity12410 : scanCanonicalize (H12AffineFastState.compose env12410 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 0) := by decide +kernel

theorem selectedBound12410 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12411 : List Nat := [2,4,8,16,1,17,9,5,512,0,523,16,8,20,1,3,4,523,0,0,0,1,16,3,9,16,522,4,17,522,1,1,5,0,21,512]

theorem envBound12411 : H12AffineFastState.Bounded env12411 := by
  intro p hp
  have h : env12411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12410_12411 : H12AffineEnvironment.transform 9 0 env12410 = env12411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env12410 == env12411) = true)

def env12412 : List Nat := [2,4,8,4,1,5,9,5,512,0,523,4,8,0,1,3,4,523,0,0,0,1,4,3,9,4,522,4,5,522,1,1,5,0,1,512]

theorem envBound12412 : H12AffineFastState.Bounded env12412 := by
  intro p hp
  have h : env12412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12411_12412 : H12AffineEnvironment.transform 3 4 env12411 = env12412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env12411 == env12412) = true)

theorem identity12412 : scanCanonicalize (H12AffineFastState.compose env12412 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound12412 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12413 : List Nat := [2,4,8,4,1,5,9,5,8,0,3,4,8,0,1,3,4,3,0,0,0,1,4,3,9,4,2,4,5,2,1,1,5,0,1,8]

theorem envBound12413 : H12AffineFastState.Bounded env12413 := by
  intro p hp
  have h : env12413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12412_12413 : H12AffineEnvironment.transform 8 8 env12412 = env12413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env12412 == env12413) = true)

def leafEnv12413 : List Nat := [2,4,8,4,1,5,9,5,8,0,3,4,8,0,1,3,4,3,0,0,0,1,4,3,0,9,1,4,2,4,5,2,1,1,5,0,5,2,1,8,1,1,0]

def active12413 : List Nat := [0,1,2]

def tree12413 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12413 : H12WitnessSearch.Good tree12413 := H12GlobalWitnessIndex.good

theorem leafIdentity12413 : H12AffineFastState.composeSystem env12413 rootObs = leafEnv12413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12413 rootObs == leafEnv12413) = true)

theorem terminalChecked12413 : H12PackedTerminal.terminalCheckFast leafEnv12413 active12413 tree12413 = true := by decide +kernel

def env12414 : List Nat := [2,4,8,5,1,4,9,5,512,0,523,5,8,1,1,3,4,523,0,0,0,1,5,3,9,5,522,4,4,522,1,1,5,0,0,512]

theorem envBound12414 : H12AffineFastState.Bounded env12414 := by
  intro p hp
  have h : env12414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12411_12414 : H12AffineEnvironment.transform 3 5 env12411 = env12414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env12411 == env12414) = true)

theorem identity12414 : scanCanonicalize (H12AffineFastState.compose env12414 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound12414 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12415 : List Nat := [0,4,8,5,1,4,9,5,512,0,521,5,8,1,1,1,4,521,0,0,0,1,5,1,9,5,520,4,4,520,1,1,5,0,0,512]

theorem envBound12415 : H12AffineFastState.Bounded env12415 := by
  intro p hp
  have h : env12415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12414_12415 : H12AffineEnvironment.transform 0 0 env12414 = env12415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env12414 == env12415) = true)

def leafEnv12415 : List Nat := [0,4,8,5,1,4,9,5,512,0,521,5,8,1,1,1,4,521,0,0,0,1,5,1,0,9,1,5,520,4,4,520,1,1,5,0,5,0,0,512,1,1,0]

def active12415 : List Nat := [1,2,8]

def tree12415 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12415 : H12WitnessSearch.Good tree12415 := H12GlobalWitnessIndex.good

theorem leafIdentity12415 : H12AffineFastState.composeSystem env12415 rootObs = leafEnv12415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12415 rootObs == leafEnv12415) = true)

theorem terminalChecked12415 : H12PackedTerminal.terminalCheckFast leafEnv12415 active12415 tree12415 = true := by decide +kernel

def env12416 : List Nat := [2,4,8,16,1,17,9,5,512,1024,523,17,8,1045,1,3,1029,523,1024,0,1,1,16,3,9,16,522,1029,16,522,1025,1,5,0,1044,512]

theorem envBound12416 : H12AffineFastState.Bounded env12416 := by
  intro p hp
  have h : env12416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12409_12416 : H12AffineEnvironment.transform 11 17 env12409 = env12416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env12409 == env12416) = true)

theorem identity12416 : scanCanonicalize (H12AffineFastState.compose env12416 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound12416 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12417 : List Nat := [2,4,8,4,1,5,9,5,512,1024,523,5,8,1025,1,3,1029,523,1024,0,1,1,4,3,9,4,522,1029,4,522,1025,1,5,0,1024,512]

theorem envBound12417 : H12AffineFastState.Bounded env12417 := by
  intro p hp
  have h : env12417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12416_12417 : H12AffineEnvironment.transform 3 4 env12416 = env12417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env12416 == env12417) = true)

def env12418 : List Nat := [2,4,8,4,1,5,9,5,512,0,523,5,8,1,1,3,5,523,0,0,1,1,4,3,9,4,522,5,4,522,1,1,5,0,0,512]

theorem envBound12418 : H12AffineFastState.Bounded env12418 := by
  intro p hp
  have h : env12418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12417_12418 : H12AffineEnvironment.transform 9 0 env12417 = env12418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env12417 == env12418) = true)

theorem identity12418 : scanCanonicalize (H12AffineFastState.compose env12418 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound12418 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12419 : List Nat := [2,4,8,4,1,5,9,5,9,0,2,5,8,1,1,3,5,2,0,0,1,1,4,3,9,4,3,5,4,3,1,1,5,0,0,9]

theorem envBound12419 : H12AffineFastState.Bounded env12419 := by
  intro p hp
  have h : env12419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12418_12419 : H12AffineEnvironment.transform 8 9 env12418 = env12419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env12418 == env12419) = true)

def leafEnv12419 : List Nat := [2,4,8,4,1,5,9,5,9,0,2,5,8,1,1,3,5,2,0,0,1,1,4,3,0,9,1,4,3,5,4,3,1,1,5,0,5,2,0,9,1,0,0]

def active12419 : List Nat := [0,1,2]

def tree12419 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12419 : H12WitnessSearch.Good tree12419 := H12GlobalWitnessIndex.good

theorem leafIdentity12419 : H12AffineFastState.composeSystem env12419 rootObs = leafEnv12419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12419 rootObs == leafEnv12419) = true)

theorem terminalChecked12419 : H12PackedTerminal.terminalCheckFast leafEnv12419 active12419 tree12419 = true := by decide +kernel

def env12420 : List Nat := [2,4,8,4,1,5,9,5,512,1,523,5,8,0,1,3,4,523,1,0,1,1,4,3,9,4,522,4,4,522,0,1,5,0,1,512]

theorem envBound12420 : H12AffineFastState.Bounded env12420 := by
  intro p hp
  have h : env12420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12417_12420 : H12AffineEnvironment.transform 9 1 env12417 = env12420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env12417 == env12420) = true)

theorem identity12420 : scanCanonicalize (H12AffineFastState.compose env12420 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound12420 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12421 : List Nat := [0,4,8,4,1,5,9,5,512,1,521,5,8,0,1,1,4,521,1,0,1,1,4,1,9,4,520,4,4,520,0,1,5,0,1,512]

theorem envBound12421 : H12AffineFastState.Bounded env12421 := by
  intro p hp
  have h : env12421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12420_12421 : H12AffineEnvironment.transform 0 0 env12420 = env12421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env12420 == env12421) = true)

def leafEnv12421 : List Nat := [0,4,8,4,1,5,9,5,512,1,521,5,8,0,1,1,4,521,1,0,1,1,4,1,1,9,1,4,520,4,4,520,0,1,5,0,5,0,1,512,1,0,0]

def active12421 : List Nat := [1,2,8]

def tree12421 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12421 : H12WitnessSearch.Good tree12421 := H12GlobalWitnessIndex.good

theorem leafIdentity12421 : H12AffineFastState.composeSystem env12421 rootObs = leafEnv12421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12421 rootObs == leafEnv12421) = true)

theorem terminalChecked12421 : H12PackedTerminal.terminalCheckFast leafEnv12421 active12421 tree12421 = true := by decide +kernel

def env12422 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830977,25265168,23160257,257,27378860,27337992,25207750]

theorem envBound12422 : H12AffineFastState.Bounded env12422 := by
  intro p hp
  have h : env12422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12240_12422 : H12AffineEnvironment.transform 18 1025 env12240 = env12422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env12240 == env12422) = true)

theorem identity12422 : scanCanonicalize (H12AffineFastState.compose env12422 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 297471) := by decide +kernel

theorem selectedBound12422 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env12423 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,297471,8328,65,12798463,2428274,10507601,8830977,8719855,6679614,257,10833235,10857719,8661561]

theorem envBound12423 : H12AffineFastState.Bounded env12423 := by
  intro p hp
  have h : env12423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12422_12423 : H12AffineEnvironment.transform 23 297471 env12422 = env12423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 297471 env12422 == env12423) = true)

def env12424 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,297335,8192,65,12798327,2428274,10507601,8830977,8719719,6679614,257,10833235,10857599,8661561]

theorem envBound12424 : H12AffineFastState.Bounded env12424 := by
  intro p hp
  have h : env12424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12423_12424 : H12AffineEnvironment.transform 6 8 env12423 = env12424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12423 == env12424) = true)

def env12425 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,297335,8192,65,12650855,2428274,10507601,8683537,8719719,6679614,257,10833235,10857599,8661561]

theorem envBound12425 : H12AffineFastState.Bounded env12425 := by
  intro p hp
  have h : env12425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12424_12425 : H12AffineEnvironment.transform 16 16400 env12424 = env12425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env12424 == env12425) = true)

theorem identity12425 : scanCanonicalize (H12AffineFastState.compose env12425 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 297316) := by decide +kernel

theorem selectedBound12425 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env12426 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,297316,297335,8192,65,4554755,2428274,2415669,2421,99331,6679614,257,2212919,2172187,41821]

theorem envBound12426 : H12AffineFastState.Bounded env12426 := by
  intro p hp
  have h : env12426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12425_12426 : H12AffineEnvironment.transform 22 297316 env12425 = env12426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 297316 env12425 == env12426) = true)

theorem identity12426 : scanCanonicalize (H12AffineFastState.compose env12426 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound12426 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env12427 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1025,32769,2097152,4194304,297316,297335,8192,65,4497416,2370937,2415669,2421,41992,6605877,257,2155580,2098448,41821]

theorem envBound12427 : H12AffineFastState.Bounded env12427 := by
  intro p hp
  have h : env12427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12426_12427 : H12AffineEnvironment.transform 15 8203 env12426 = env12427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env12426 == env12427) = true)

theorem identity12427 : scanCanonicalize (H12AffineFastState.compose env12427 (packedSelected [1,5,8,17,19,21,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound12427 : packedSelected [1,5,8,17,19,21,24,26] rootPS < 2^1333 := by decide +kernel

def env12428 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8203,16400,262144,1025,8541,2097152,4194304,272440,272427,8192,65,4456788,2370937,2391401,2421,1364,6581609,257,2114912,2098448,513]

theorem envBound12428 : H12AffineFastState.Bounded env12428 := by
  intro p hp
  have h : env12428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12427_12428 : H12AffineEnvironment.transform 14 8540 env12427 = env12428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env12427 == env12428) = true)

theorem identity12428 : scanCanonicalize (H12AffineFastState.compose env12428 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 292888) := by decide +kernel

theorem selectedBound12428 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env12429 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8203,16400,262144,1025,8541,2097152,292888,272440,272427,8192,65,31052,2370937,2391401,2421,1364,2102641,257,2114912,2098448,513]

theorem envBound12429 : H12AffineFastState.Bounded env12429 := by
  intro p hp
  have h : env12429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12428_12429 : H12AffineEnvironment.transform 21 292888 env12428 = env12429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 292888 env12428 == env12429) = true)

theorem identity12429 : scanCanonicalize (H12AffineFastState.compose env12429 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 290153) := by decide +kernel

theorem selectedBound12429 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env12430 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8203,16400,262144,1025,8541,290153,292888,272440,272427,8192,65,31052,16400,4096,2421,1364,292888,257,272393,288889,513]

theorem envBound12430 : H12AffineFastState.Bounded env12430 := by
  intro p hp
  have h : env12430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12429_12430 : H12AffineEnvironment.transform 20 290153 env12429 = env12430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290153 env12429 == env12430) = true)

theorem identity12430 : scanCanonicalize (H12AffineFastState.compose env12430 (packedSelected [0,7,20] rootPS)) = affineNative (2^(17+1) ^^^ 30777) := by decide +kernel

theorem selectedBound12430 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env12431 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8203,16400,30777,1025,8541,5456,33,20481,20498,8192,65,31052,16400,4096,2421,1364,33,257,20528,4160,513]

theorem envBound12431 : H12AffineFastState.Bounded env12431 := by
  intro p hp
  have h : env12431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12430_12431 : H12AffineEnvironment.transform 17 30777 env12430 = env12431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 30777 env12430 == env12431) = true)

theorem identity12431 : scanCanonicalize (H12AffineFastState.compose env12431 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound12431 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env12432 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,0,343,16400,22885,1025,1,5456,33,20481,20498,348,65,22544,16400,4096,2421,1364,33,257,20528,4160,513]

theorem envBound12432 : H12AffineFastState.Bounded env12432 := by
  intro p hp
  have h : env12432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12431_12432 : H12AffineEnvironment.transform 12 348 env12431 = env12432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env12431 == env12432) = true)

theorem identity12432 : scanCanonicalize (H12AffineFastState.compose env12432 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound12432 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12433 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,4112,0,343,4096,2421,1025,1,5456,33,17,2,348,65,2048,4096,4096,2421,1364,33,257,32,4160,513]

theorem envBound12433 : H12AffineFastState.Bounded env12433 := by
  intro p hp
  have h : env12433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12432_12433 : H12AffineEnvironment.transform 13 4112 env12432 = env12433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env12432 == env12433) = true)

theorem identity12433 : scanCanonicalize (H12AffineFastState.compose env12433 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound12433 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12434 : List Nat := [2,4,8,16,32,64,8,256,512,784,2048,4096,348,4112,0,343,4096,2421,785,1,4672,33,17,2,348,65,2048,4096,4096,2421,580,33,257,32,4160,513]

theorem envBound12434 : H12AffineFastState.Bounded env12434 := by
  intro p hp
  have h : env12434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12433_12434 : H12AffineEnvironment.transform 9 784 env12433 = env12434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env12433 == env12434) = true)

def env12435 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,297335,8192,65,12650854,2428274,10507601,8683536,8719719,6679614,257,10833235,10857599,8661561]

theorem envBound12435 : H12AffineFastState.Bounded env12435 := by
  intro p hp
  have h : env12435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12424_12435 : H12AffineEnvironment.transform 16 16401 env12424 = env12435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env12424 == env12435) = true)

theorem identity12435 : scanCanonicalize (H12AffineFastState.compose env12435 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound12435 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env12436 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,262144,1025,8541,2097152,4194304,8388608,272427,8192,65,12650854,2428274,10507601,8659276,8719719,6638946,257,10833235,10816803,8661561]

theorem envBound12436 : H12AffineFastState.Bounded env12436 := by
  intro p hp
  have h : env12436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12435_12436 : H12AffineEnvironment.transform 14 8540 env12435 = env12436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env12435 == env12436) = true)

theorem identity12436 : scanCanonicalize (H12AffineFastState.compose env12436 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound12436 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env12437 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16401,262144,1025,8541,2097152,4194304,8388608,272427,8192,65,12593516,2370936,10507601,8659276,8662381,6581608,257,10775897,10759465,8661561]

theorem envBound12437 : H12AffineFastState.Bounded env12437 := by
  intro p hp
  have h : env12437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12436_12437 : H12AffineEnvironment.transform 15 8202 env12436 = env12437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env12436 == env12437) = true)

theorem identity12437 : scanCanonicalize (H12AffineFastState.compose env12437 (packedSelected [0,1,3,5,8,9,10,11,18,19,21,22,23,27,32] rootPS)) = affineNative (2^(22+1) ^^^ 6309153) := by decide +kernel

theorem selectedBound12437 : packedSelected [0,1,3,5,8,9,10,11,18,19,21,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env12438 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16401,262144,1025,8541,2097152,4194304,6309153,272427,8192,65,2124877,2370936,4198512,6579309,6580300,6581608,257,4466808,4483080,6582040]

theorem envBound12438 : H12AffineFastState.Bounded env12438 := by
  intro p hp
  have h : env12438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12437_12438 : H12AffineEnvironment.transform 22 6309153 env12437 = env12438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6309153 env12437 == env12438) = true)

theorem identity12438 : scanCanonicalize (H12AffineFastState.compose env12438 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound12438 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env12439 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16401,262144,1025,8541,2097152,32,2114817,272427,8192,65,2124877,2370936,4176,2384973,2386028,2387272,257,272472,288808,2387768]

theorem envBound12439 : H12AffineFastState.Bounded env12439 := by
  intro p hp
  have h : env12439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12438_12439 : H12AffineEnvironment.transform 21 32 env12438 = env12439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env12438 == env12439) = true)

theorem identity12439 : scanCanonicalize (H12AffineFastState.compose env12439 (packedSelected [1,3,5,8,10,16,19,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound12439 : packedSelected [1,3,5,8,10,16,19,20,21] rootPS < 2^1333 := by decide +kernel

def env12440 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16401,2420,1025,8541,2097152,32,2114817,8543,8192,65,2124877,2106380,4176,2125113,2122008,2122812,257,8492,24924,2123340]

theorem envBound12440 : H12AffineFastState.Bounded env12440 := by
  intro p hp
  have h : env12440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12439_12440 : H12AffineEnvironment.transform 17 2420 env12439 = env12440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env12439 == env12440) = true)

theorem identity12440 : scanCanonicalize (H12AffineFastState.compose env12440 (packedSelected [0,1,2,6,7,8,10,11,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound12440 : packedSelected [0,1,2,6,7,8,10,11,18,20] rootPS < 2^1333 := by decide +kernel

def env12441 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8540,8202,5220,2420,1025,8541,2097152,32,2101620,8543,8192,65,2111544,2106380,4176,2111820,2110829,2109513,257,8492,13609,2110009]

theorem envBound12441 : H12AffineFastState.Bounded env12441 := by
  intro p hp
  have h : env12441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12440_12441 : H12AffineEnvironment.transform 13 5237 env12440 = env12441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env12440 == env12441) = true)

theorem identity12441 : scanCanonicalize (H12AffineFastState.compose env12441 (packedSelected [0,1,2,4,6,7,8,9,10,11,14,17,18] rootPS)) = affineNative (2^(20+1) ^^^ 12344) := by decide +kernel

theorem selectedBound12441 : packedSelected [0,1,2,4,6,7,8,9,10,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env12442 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8540,8202,5220,2420,1025,8541,12344,32,8524,8543,8192,65,2048,5172,4176,2420,1365,113,257,8492,13609,513]

theorem envBound12442 : H12AffineFastState.Bounded env12442 := by
  intro p hp
  have h : env12442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12441_12442 : H12AffineEnvironment.transform 20 12344 env12441 = env12442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12344 env12441 == env12442) = true)

theorem identity12442 : scanCanonicalize (H12AffineFastState.compose env12442 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound12442 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env12443 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1385,5237,1077,1379,5220,2420,1025,1076,5457,32,1061,1078,1385,65,2048,5172,4176,2420,1365,113,257,1093,4160,513]

theorem envBound12443 : H12AffineFastState.Bounded env12443 := by
  intro p hp
  have h : env12443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12442_12443 : H12AffineEnvironment.transform 12 1385 env12442 = env12443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env12442 == env12443) = true)

theorem identity12443 : scanCanonicalize (H12AffineFastState.compose env12443 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12443 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env12444 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,1337,5157,1077,1331,5172,2340,1025,1076,5377,32,1061,1078,1337,17,2048,5172,4096,2340,1285,33,257,1045,4112,513]

theorem envBound12444 : H12AffineFastState.Bounded env12444 := by
  intro p hp
  have h : env12444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12443_12444 : H12AffineEnvironment.transform 5 16 env12443 = env12444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12443 == env12444) = true)

def env12445 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,297334,8193,65,12798326,2428274,10507601,8830977,8719718,6679614,257,10833235,10857598,8661561]

theorem envBound12445 : H12AffineFastState.Bounded env12445 := by
  intro p hp
  have h : env12445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12423_12445 : H12AffineEnvironment.transform 6 9 env12423 = env12445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12423 == env12445) = true)

def env12446 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,297334,8193,65,12650854,2428274,10507601,8683537,8719718,6679614,257,10833235,10857598,8661561]

theorem envBound12446 : H12AffineFastState.Bounded env12446 := by
  intro p hp
  have h : env12446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12445_12446 : H12AffineEnvironment.transform 16 16400 env12445 = env12446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env12445 == env12446) = true)

theorem identity12446 : scanCanonicalize (H12AffineFastState.compose env12446 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound12446 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env12447 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,2097152,4194304,8388608,41311,8193,65,12650854,2172251,10507601,8431672,8463695,6407191,257,10577274,10585175,8389136]

theorem envBound12447 : H12AffineFastState.Bounded env12447 := by
  intro p hp
  have h : env12447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12446_12447 : H12AffineEnvironment.transform 17 10281 env12446 = env12447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env12446 == env12447) = true)

theorem identity12447 : scanCanonicalize (H12AffineFastState.compose env12447 (packedSelected [17,21] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound12447 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env12448 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,2097152,4194304,17,41311,8193,65,4262263,2172251,2118976,43049,75102,6407191,257,2188651,2196550,513]

theorem envBound12448 : H12AffineFastState.Bounded env12448 := by
  intro p hp
  have h : env12448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12447_12448 : H12AffineEnvironment.transform 22 17 env12447 = env12448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env12447 == env12448) = true)

theorem identity12448 : scanCanonicalize (H12AffineFastState.compose env12448 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound12448 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env12449 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,115734,4194304,17,41311,8193,65,4262263,57677,102742,43049,75102,4194305,257,41341,16464,513]

theorem envBound12449 : H12AffineFastState.Bounded env12449 := by
  intro p hp
  have h : env12449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12448_12449 : H12AffineEnvironment.transform 20 115734 env12448 = env12449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env12448 == env12449) = true)

theorem identity12449 : scanCanonicalize (H12AffineFastState.compose env12449 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound12449 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env12450 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,342,16400,10281,1025,32769,50496,4194304,17,41311,8193,65,4196385,57677,36864,43049,9224,4194305,257,41341,16464,513]

theorem envBound12450 : H12AffineFastState.Bounded env12450 := by
  intro p hp
  have h : env12450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12449_12450 : H12AffineEnvironment.transform 15 342 env12449 = env12450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env12449 == env12450) = true)

theorem identity12450 : scanCanonicalize (H12AffineFastState.compose env12450 (packedSelected [0,7,11,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound12450 : packedSelected [0,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env12451 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,342,16400,10281,1025,8540,25629,4194304,17,2,8193,65,4196385,16400,12637,2420,9224,4194305,257,32,16464,513]

theorem envBound12451 : H12AffineFastState.Bounded env12451 := by
  intro p hp
  have h : env12451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12450_12451 : H12AffineEnvironment.transform 14 8541 env12450 = env12451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env12450 == env12451) = true)

theorem identity12451 : scanCanonicalize (H12AffineFastState.compose env12451 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound12451 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env12452 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,342,16400,10281,1025,8540,25629,8572,17,2,8193,65,10589,16400,12637,2420,9224,8573,257,32,16464,513]

theorem envBound12452 : H12AffineFastState.Bounded env12452 := by
  intro p hp
  have h : env12452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12451_12452 : H12AffineEnvironment.transform 21 8572 env12451 = env12452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env12451 == env12452) = true)

theorem identity12452 : scanCanonicalize (H12AffineFastState.compose env12452 (packedSelected [2,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 1312) := by decide +kernel

theorem selectedBound12452 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env12453 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,1312,8541,342,1328,10281,1025,8540,8509,8572,17,2,8193,65,10589,1328,12637,2420,9224,8573,257,32,1392,513]

theorem envBound12453 : H12AffineFastState.Bounded env12453 := by
  intro p hp
  have h : env12453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12452_12453 : H12AffineEnvironment.transform 13 1312 env12452 = env12453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1312 env12452 == env12453) = true)

theorem identity12453 : scanCanonicalize (H12AffineFastState.compose env12453 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound12453 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env12454 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,1312,0,342,1328,2420,1025,1,96,33,17,2,348,65,2048,1328,4096,2420,1365,32,257,32,1392,513]

theorem envBound12454 : H12AffineFastState.Bounded env12454 := by
  intro p hp
  have h : env12454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12453_12454 : H12AffineEnvironment.transform 12 349 env12453 = env12454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env12453 == env12454) = true)

theorem identity12454 : scanCanonicalize (H12AffineFastState.compose env12454 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 785) := by decide +kernel

theorem selectedBound12454 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12455 : List Nat := [2,4,8,16,32,64,9,256,512,785,2048,4096,349,561,0,342,545,2420,784,1,96,33,17,2,348,65,2048,545,4096,2420,580,32,257,32,609,513]

theorem envBound12455 : H12AffineFastState.Bounded env12455 := by
  intro p hp
  have h : env12455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12454_12455 : H12AffineEnvironment.transform 9 785 env12454 = env12455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 785 env12454 == env12455) = true)

def env12456 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,297334,8193,65,12650855,2428274,10507601,8683536,8719718,6679614,257,10833235,10857598,8661561]

theorem envBound12456 : H12AffineFastState.Bounded env12456 := by
  intro p hp
  have h : env12456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12445_12456 : H12AffineEnvironment.transform 16 16401 env12445 = env12456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env12445 == env12456) = true)

theorem identity12456 : scanCanonicalize (H12AffineFastState.compose env12456 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound12456 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env12457 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,17,297334,8193,65,4262262,2428274,2118976,294913,331127,6679614,257,2444610,2468975,272936]

theorem envBound12457 : H12AffineFastState.Bounded env12457 := by
  intro p hp
  have h : env12457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12456_12457 : H12AffineEnvironment.transform 22 17 env12456 = env12457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env12456 == env12457) = true)

theorem identity12457 : scanCanonicalize (H12AffineFastState.compose env12457 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound12457 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env12458 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,2097152,4194304,17,41311,8193,65,4262262,2172251,2118976,43048,75102,6407191,257,2188651,2196550,513]

theorem envBound12458 : H12AffineFastState.Bounded env12458 := by
  intro p hp
  have h : env12458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12457_12458 : H12AffineEnvironment.transform 17 10281 env12457 = env12458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env12457 == env12458) = true)

def env12459 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,58396,4194304,17,41311,8193,65,4262262,115015,45404,43048,75102,4268043,257,98679,90202,513]

theorem envBound12459 : H12AffineFastState.Bounded env12459 := by
  intro p hp
  have h : env12459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12458_12459 : H12AffineEnvironment.transform 20 58396 env12458 = env12459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env12458 == env12459) = true)

theorem identity12459 : scanCanonicalize (H12AffineFastState.compose env12459 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound12459 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12460 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16401,10281,1025,32769,58396,4194304,17,41311,8193,65,4204924,57677,45404,43048,1364,4194305,257,41341,16464,513]

theorem envBound12460 : H12AffineFastState.Bounded env12460 := by
  intro p hp
  have h : env12460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12459_12460 : H12AffineEnvironment.transform 15 8202 env12459 = env12460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env12459 == env12460) = true)

theorem identity12460 : scanCanonicalize (H12AffineFastState.compose env12460 (packedSelected [1,3,4,5,8,9,15,23] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound12460 : packedSelected [1,3,4,5,8,9,15,23] rootPS < 2^1333 := by decide +kernel

def env12461 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16401,10281,1025,32769,58396,113,17,41311,8193,65,10509,57677,45404,43048,1364,112,257,41341,16464,513]

theorem envBound12461 : H12AffineFastState.Bounded env12461 := by
  intro p hp
  have h : env12461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12460_12461 : H12AffineEnvironment.transform 21 113 env12460 = env12461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env12460 == env12461) = true)

theorem identity12461 : scanCanonicalize (H12AffineFastState.compose env12461 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound12461 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env12462 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,342,16401,2421,1025,32769,50496,113,17,32771,349,65,2129,49169,36864,35188,1364,112,257,32801,16464,513]

theorem envBound12462 : H12AffineFastState.Bounded env12462 := by
  intro p hp
  have h : env12462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12461_12462 : H12AffineEnvironment.transform 12 348 env12461 = env12462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env12461 == env12462) = true)

theorem identity12462 : scanCanonicalize (H12AffineFastState.compose env12462 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12462 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env12463 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,32768,262,16401,2341,1025,32769,50448,33,17,32771,269,17,2049,49169,36864,35108,1284,32,257,32801,16384,513]

theorem envBound12463 : H12AffineFastState.Bounded env12463 := by
  intro p hp
  have h : env12463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12462_12463 : H12AffineEnvironment.transform 5 16 env12462 = env12463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12462 == env12463) = true)

theorem identity12463 : scanCanonicalize (H12AffineFastState.compose env12463 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound12463 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12464 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,1,262,16401,2341,1025,0,17681,33,17,2,269,17,2049,16400,4097,2341,1284,32,257,32,16384,513]

theorem envBound12464 : H12AffineFastState.Bounded env12464 := by
  intro p hp
  have h : env12464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12463_12464 : H12AffineEnvironment.transform 14 1 env12463 = env12464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env12463 == env12464) = true)

theorem identity12464 : scanCanonicalize (H12AffineFastState.compose env12464 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound12464 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12465 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,1,262,5393,2341,1025,0,4113,33,17,2,269,17,2049,5392,4097,2341,1284,32,257,32,5376,513]

theorem envBound12465 : H12AffineFastState.Bounded env12465 := by
  intro p hp
  have h : env12465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12464_12465 : H12AffineEnvironment.transform 13 5376 env12464 = env12465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env12464 == env12465) = true)

theorem identity12465 : scanCanonicalize (H12AffineFastState.compose env12465 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound12465 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12466 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,308,268,1076,1,262,1061,2341,1025,0,293,33,17,2,269,17,2049,1060,309,2341,1284,32,257,32,1076,513]

theorem envBound12466 : H12AffineFastState.Bounded env12466 := by
  intro p hp
  have h : env12466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12465_12466 : H12AffineEnvironment.transform 11 308 env12465 = env12466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env12465 == env12466) = true)

theorem identity12466 : scanCanonicalize (H12AffineFastState.compose env12466 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound12466 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env12467 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,308,268,292,1,262,309,2341,273,0,293,33,17,2,269,17,2049,308,309,2341,20,32,257,32,292,513]

theorem envBound12467 : H12AffineFastState.Bounded env12467 := by
  intro p hp
  have h : env12467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12466_12467 : H12AffineEnvironment.transform 9 272 env12466 = env12467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env12466 == env12467) = true)

theorem identity12467 : scanCanonicalize (H12AffineFastState.compose env12467 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound12467 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12468 : List Nat := [2,4,8,16,32,16,9,256,512,272,1,308,268,292,1,262,309,292,273,0,293,33,17,2,269,17,0,308,309,292,20,32,257,32,292,513]

theorem envBound12468 : H12AffineFastState.Bounded env12468 := by
  intro p hp
  have h : env12468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12467_12468 : H12AffineEnvironment.transform 10 1 env12467 = env12468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env12467 == env12468) = true)

theorem identity12468 : scanCanonicalize (H12AffineFastState.compose env12468 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12468 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env12469 : List Nat := [2,4,8,16,32,16,9,36,512,52,1,16,40,0,1,34,17,0,53,0,1,33,17,2,41,17,0,16,17,0,20,32,37,32,0,513]

theorem envBound12469 : H12AffineFastState.Bounded env12469 := by
  intro p hp
  have h : env12469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12468_12469 : H12AffineEnvironment.transform 7 36 env12468 = env12469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12468 == env12469) = true)

theorem identity12469 : scanCanonicalize (H12AffineFastState.compose env12469 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound12469 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12470 : List Nat := [2,4,8,16,32,16,9,36,16,52,1,16,40,0,1,34,17,0,53,0,1,33,17,2,41,17,0,16,17,0,20,32,37,32,0,17]

theorem envBound12470 : H12AffineFastState.Bounded env12470 := by
  intro p hp
  have h : env12470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12469_12470 : H12AffineEnvironment.transform 8 16 env12469 = env12470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env12469 == env12470) = true)

theorem identity12470 : scanCanonicalize (H12AffineFastState.compose env12470 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound12470 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12471 : List Nat := [2,4,3,16,32,16,2,36,16,52,1,16,35,0,1,34,17,0,53,0,1,33,17,2,34,17,0,16,17,0,20,32,37,32,0,17]

theorem envBound12471 : H12AffineFastState.Bounded env12471 := by
  intro p hp
  have h : env12471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12470_12471 : H12AffineEnvironment.transform 2 3 env12470 = env12471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env12470 == env12471) = true)

def env12472 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,58397,4194304,17,41311,8193,65,4262262,115014,45405,43048,75102,4268042,257,98678,90203,513]

theorem envBound12472 : H12AffineFastState.Bounded env12472 := by
  intro p hp
  have h : env12472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12458_12472 : H12AffineEnvironment.transform 20 58397 env12458 = env12472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env12458 == env12472) = true)

theorem identity12472 : scanCanonicalize (H12AffineFastState.compose env12472 (packedSelected [1,3,4,5,8,9,15,23] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound12472 : packedSelected [1,3,4,5,8,9,15,23] rootPS < 2^1333 := by decide +kernel

def env12473 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10281,1025,8541,17729,4194304,17,3,8193,65,4262262,90138,4097,2420,75102,4268042,257,73770,90203,513]

theorem envBound12473 : H12AffineFastState.Bounded env12473 := by
  intro p hp
  have h : env12473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12472_12473 : H12AffineEnvironment.transform 14 8540 env12472 = env12473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env12472 == env12473) = true)

theorem identity12473 : scanCanonicalize (H12AffineFastState.compose env12473 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound12473 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env12474 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,262,16401,10281,1025,8541,17729,4194304,17,3,8193,65,4196464,24860,4097,2420,9304,4202764,257,8492,24925,513]

theorem envBound12474 : H12AffineFastState.Bounded env12474 := by
  intro p hp
  have h : env12474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12473_12474 : H12AffineEnvironment.transform 15 262 env12473 = env12474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env12473 == env12474) = true)

theorem identity12474 : scanCanonicalize (H12AffineFastState.compose env12474 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound12474 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env12475 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,262,16401,10281,1025,8541,17729,113,17,3,8193,65,2049,24860,4097,2420,9304,8573,257,8492,24925,513]

theorem envBound12475 : H12AffineFastState.Bounded env12475 := by
  intro p hp
  have h : env12475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12474_12475 : H12AffineEnvironment.transform 21 113 env12474 = env12475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env12474 == env12475) = true)

theorem identity12475 : scanCanonicalize (H12AffineFastState.compose env12475 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12475 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env12476 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8460,262,16401,10281,1025,8461,17681,33,17,3,8193,17,2049,24860,4097,2340,9224,8493,257,8492,24845,513]

theorem envBound12476 : H12AffineFastState.Bounded env12476 := by
  intro p hp
  have h : env12476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12475_12476 : H12AffineEnvironment.transform 5 16 env12475 = env12476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12475 == env12476) = true)

def env12477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616400,1073741824,92374097,145662401,525568,140903597,27337992,25733063]

theorem envBound12477 : H12AffineFastState.Bounded env12477 := by
  intro p hp
  have h : env12477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9857_12477 : H12AffineEnvironment.transform 31 145662401 env9857 = env12477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662401 env9857 == env12477) = true)

def env12478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616400,155254784,92374097,145662401,525568,140903597,27337992,25733063]

theorem envBound12478 : H12AffineFastState.Bounded env12478 := by
  intro p hp
  have h : env12478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12477_12478 : H12AffineEnvironment.transform 29 155254784 env12477 = env12478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env12477 == env12478) = true)

def env12479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507600,155254784,25265169,145662401,525568,140903597,27337992,25733063]

theorem envBound12479 : H12AffineFastState.Bounded env12479 := by
  intro p hp
  have h : env12479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12478_12479 : H12AffineEnvironment.transform 25 64 env12478 = env12479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env12478 == env12479) = true)

def env12480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507600,9356288,25265169,23160257,525568,27902125,27337992,25733063]

theorem envBound12480 : H12AffineFastState.Bounded env12480 := by
  intro p hp
  have h : env12480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12479_12480 : H12AffineEnvironment.transform 26 30393344 env12479 = env12480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env12479 == env12480) = true)

def env12481 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830976,25265169,23160257,256,27378861,27337992,25207751]

theorem envBound12481 : H12AffineFastState.Bounded env12481 := by
  intro p hp
  have h : env12481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12480_12481 : H12AffineEnvironment.transform 18 1024 env12480 = env12481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env12480 == env12481) = true)

theorem identity12481 : scanCanonicalize (H12AffineFastState.compose env12481 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8430022) := by decide +kernel

theorem selectedBound12481 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env12482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8430022,8328,64,4678086,10560842,10507600,8830976,75223,14795783,256,2188651,2196686,513]

theorem envBound12482 : H12AffineFastState.Bounded env12482 := by
  intro p hp
  have h : env12482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12481_12482 : H12AffineEnvironment.transform 23 8430022 env12481 = env12482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8430022 env12481 == env12482) = true)

def env12483 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8429902,8192,64,4677966,10560842,10507600,8830976,75103,14795783,256,2188651,2196550,513]

theorem envBound12483 : H12AffineFastState.Bounded env12483 := by
  intro p hp
  have h : env12483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12482_12483 : H12AffineEnvironment.transform 6 8 env12482 = env12483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12482 == env12483) = true)

theorem identity12483 : scanCanonicalize (H12AffineFastState.compose env12483 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound12483 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env12484 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1024,32769,2097152,4194304,8388608,8429902,8192,64,4456788,10560842,10507600,8757274,75103,14795783,256,2188651,2196550,513]

theorem envBound12484 : H12AffineFastState.Bounded env12484 := by
  intro p hp
  have h : env12484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12483_12484 : H12AffineEnvironment.transform 16 90138 env12483 = env12484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env12483 == env12484) = true)

def env12485 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1024,32769,2097152,4194304,16,41310,8192,64,4456788,2172250,2118976,368650,75103,6407191,256,2188651,2196550,513]

theorem envBound12485 : H12AffineFastState.Bounded env12485 := by
  intro p hp
  have h : env12485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12484_12485 : H12AffineEnvironment.transform 22 16 env12484 = env12485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env12484 == env12485) = true)

theorem identity12485 : scanCanonicalize (H12AffineFastState.compose env12485 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 46093) := by decide +kernel

theorem selectedBound12485 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env12486 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1024,32769,46093,4194304,16,41310,8192,64,4456788,102743,57677,368650,75103,4288538,256,119142,77899,513]

theorem envBound12486 : H12AffineFastState.Bounded env12486 := by
  intro p hp
  have h : env12486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12485_12486 : H12AffineEnvironment.transform 20 46093 env12485 = env12486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 46093 env12485 == env12486) = true)

theorem identity12486 : scanCanonicalize (H12AffineFastState.compose env12486 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound12486 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env12487 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90138,262144,1024,8541,5457,4194304,16,2,8192,64,4456788,77835,16401,328022,75103,4288538,256,94266,77899,513]

theorem envBound12487 : H12AffineFastState.Bounded env12487 := by
  intro p hp
  have h : env12487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12486_12487 : H12AffineEnvironment.transform 14 8540 env12486 = env12487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env12486 == env12487) = true)

def env12488 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8540,65536,77834,262144,1024,8541,5457,4194304,16,2,8192,64,4456788,77835,4097,328022,75103,4268042,256,73770,77899,513]

theorem envBound12488 : H12AffineFastState.Bounded env12488 := by
  intro p hp
  have h : env12488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12487_12488 : H12AffineEnvironment.transform 13 4112 env12487 = env12488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env12487 == env12488) = true)

theorem identity12488 : scanCanonicalize (H12AffineFastState.compose env12488 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound12488 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12489 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8540,8202,4096,262144,1024,8541,5457,4194304,16,2,8192,64,4456788,4097,4097,270684,1365,4194304,256,32,4161,513]

theorem envBound12489 : H12AffineFastState.Bounded env12489 := by
  intro p hp
  have h : env12489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12488_12489 : H12AffineEnvironment.transform 15 8202 env12488 = env12489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env12488 == env12489) = true)

theorem identity12489 : scanCanonicalize (H12AffineFastState.compose env12489 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 112) := by decide +kernel

theorem selectedBound12489 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12490 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8540,8202,4096,262144,1024,8541,5457,112,16,2,8192,64,262436,4097,4097,270684,1365,112,256,32,4161,513]

theorem envBound12490 : H12AffineFastState.Bounded env12490 := by
  intro p hp
  have h : env12490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12489_12490 : H12AffineEnvironment.transform 21 112 env12489 = env12490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 112 env12489 == env12490) = true)

theorem identity12490 : scanCanonicalize (H12AffineFastState.compose env12490 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12490 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env12491 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,4112,8460,8202,4096,262144,1024,8461,5377,32,16,2,8192,16,262436,4097,4097,270604,1285,32,256,32,4113,513]

theorem envBound12491 : H12AffineFastState.Bounded env12491 := by
  intro p hp
  have h : env12491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12490_12491 : H12AffineEnvironment.transform 5 16 env12490 = env12491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12490 == env12491) = true)

theorem identity12491 : scanCanonicalize (H12AffineFastState.compose env12491 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 11576) := by decide +kernel

theorem selectedBound12491 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env12492 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,4112,8460,8202,4096,11576,1024,8461,5377,32,16,2,8192,16,11292,4097,4097,3124,1285,32,256,32,4113,513]

theorem envBound12492 : H12AffineFastState.Bounded env12492 := by
  intro p hp
  have h : env12492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12491_12492 : H12AffineEnvironment.transform 17 11576 env12491 = env12492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11576 env12491 == env12492) = true)

theorem identity12492 : scanCanonicalize (H12AffineFastState.compose env12492 (packedSelected [0,4,7,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound12492 : packedSelected [0,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env12493 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,4096,8192,4112,8460,8202,4096,8461,1024,8461,5377,32,16,2,8192,16,8233,4097,4097,1,1285,32,256,32,4113,513]

theorem envBound12493 : H12AffineFastState.Bounded env12493 := by
  intro p hp
  have h : env12493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12492_12493 : H12AffineEnvironment.transform 10 1077 env12492 = env12493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env12492 == env12493) = true)

theorem identity12493 : scanCanonicalize (H12AffineFastState.compose env12493 (packedSelected [14] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound12493 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env12494 : List Nat := [2,4,8,16,32,16,8,256,512,52,1,4096,8192,4112,8460,8202,4096,8461,52,8461,4405,32,16,2,8192,16,8233,4097,4097,1,305,32,256,32,4113,513]

theorem envBound12494 : H12AffineFastState.Bounded env12494 := by
  intro p hp
  have h : env12494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12493_12494 : H12AffineEnvironment.transform 9 52 env12493 = env12494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env12493 == env12494) = true)

theorem identity12494 : scanCanonicalize (H12AffineFastState.compose env12494 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 317) := by decide +kernel

theorem selectedBound12494 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env12495 : List Nat := [2,4,8,16,32,16,8,256,512,52,1,4096,317,4112,49,311,4096,48,52,48,4405,32,16,2,317,16,276,4097,4097,1,305,32,256,32,4113,513]

theorem envBound12495 : H12AffineFastState.Bounded env12495 := by
  intro p hp
  have h : env12495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12494_12495 : H12AffineEnvironment.transform 12 317 env12494 = env12495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 317 env12494 == env12495) = true)

theorem identity12495 : scanCanonicalize (H12AffineFastState.compose env12495 (packedSelected [0,2,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound12495 : packedSelected [0,2,4,7] rootPS < 2^1333 := by decide +kernel

def env12496 : List Nat := [2,4,8,0,32,0,8,256,512,36,1,4096,301,4096,33,295,4096,32,36,32,4389,32,0,2,301,0,260,4097,4097,1,289,32,256,32,4097,513]

theorem envBound12496 : H12AffineFastState.Bounded env12496 := by
  intro p hp
  have h : env12496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12495_12496 : H12AffineEnvironment.transform 3 0 env12495 = env12496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env12495 == env12496) = true)

theorem identity12496 : scanCanonicalize (H12AffineFastState.compose env12496 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound12496 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12497 : List Nat := [2,4,8,0,32,0,8,37,512,36,1,4096,8,4096,33,2,4096,32,36,32,4096,32,0,2,8,0,33,4097,4097,1,4,32,37,32,4097,513]

theorem envBound12497 : H12AffineFastState.Bounded env12497 := by
  intro p hp
  have h : env12497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12496_12497 : H12AffineEnvironment.transform 7 37 env12496 = env12497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env12496 == env12497) = true)

theorem identity12497 : scanCanonicalize (H12AffineFastState.compose env12497 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 545) := by decide +kernel

theorem selectedBound12497 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12498 : List Nat := [2,4,8,0,32,0,8,37,512,36,1,545,8,545,33,2,545,32,36,32,545,32,0,2,8,0,33,544,544,1,4,32,37,32,544,513]

theorem envBound12498 : H12AffineFastState.Bounded env12498 := by
  intro p hp
  have h : env12498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12497_12498 : H12AffineEnvironment.transform 11 545 env12497 = env12498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env12497 == env12498) = true)

theorem identity12498 : scanCanonicalize (H12AffineFastState.compose env12498 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound12498 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12499 : List Nat := [2,4,8,0,32,0,8,37,32,36,1,1,8,1,33,2,1,32,36,32,1,32,0,2,8,0,33,0,0,1,4,32,37,32,0,33]

theorem envBound12499 : H12AffineFastState.Bounded env12499 := by
  intro p hp
  have h : env12499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12498_12499 : H12AffineEnvironment.transform 8 32 env12498 = env12499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env12498 == env12499) = true)

def env12500 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8540,65536,77835,262144,1024,8541,5457,4194304,16,2,8192,64,4456788,77835,4096,328022,75103,4268043,256,73771,77899,513]

theorem envBound12500 : H12AffineFastState.Bounded env12500 := by
  intro p hp
  have h : env12500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12487_12500 : H12AffineEnvironment.transform 13 4113 env12487 = env12500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env12487 == env12500) = true)

theorem identity12500 : scanCanonicalize (H12AffineFastState.compose env12500 (packedSelected [0,2,3,5,6,10,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound12500 : packedSelected [0,2,3,5,6,10,14,27] rootPS < 2^1333 := by decide +kernel

def env12501 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8540,65536,77835,262144,1024,8541,5457,33,16,2,8192,64,262517,77835,4096,328022,75103,73770,256,73771,77899,513]

theorem envBound12501 : H12AffineFastState.Bounded env12501 := by
  intro p hp
  have h : env12501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12500_12501 : H12AffineEnvironment.transform 21 33 env12500 = env12501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env12500 == env12501) = true)

theorem identity12501 : scanCanonicalize (H12AffineFastState.compose env12501 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound12501 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env12502 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8540,65536,77835,10281,1024,8541,5457,33,16,2,8192,64,10588,77835,4096,76159,75103,73770,256,73771,77899,513]

theorem envBound12502 : H12AffineFastState.Bounded env12502 := by
  intro p hp
  have h : env12502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12501_12502 : H12AffineEnvironment.transform 17 10281 env12501 = env12502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env12501 == env12502) = true)

theorem identity12502 : scanCanonicalize (H12AffineFastState.compose env12502 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 15407) := by decide +kernel

theorem selectedBound12502 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env12503 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8540,15407,3108,10281,1024,8541,5457,33,16,2,8192,64,10588,3108,4096,5456,6512,7173,256,7172,3172,513]

theorem envBound12503 : H12AffineFastState.Bounded env12503 := by
  intro p hp
  have h : env12503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12502_12503 : H12AffineEnvironment.transform 15 15407 env12502 = env12503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 15407 env12502 == env12503) = true)

theorem identity12503 : scanCanonicalize (H12AffineFastState.compose env12503 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12503 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env12504 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,4113,8461,15407,3108,10281,1024,8460,5376,33,16,2,8192,17,10509,3108,4096,5377,6433,7173,256,7172,3125,513]

theorem envBound12504 : H12AffineFastState.Bounded env12504 := by
  intro p hp
  have h : env12504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12503_12504 : H12AffineEnvironment.transform 5 17 env12503 = env12504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12503 == env12504) = true)

theorem identity12504 : scanCanonicalize (H12AffineFastState.compose env12504 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound12504 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12505 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3109,8192,3124,8461,8202,3108,10281,1024,8460,2341,33,16,2,8192,17,10509,3108,3109,2340,1284,32,256,33,3125,513]

theorem envBound12505 : H12AffineFastState.Bounded env12505 := by
  intro p hp
  have h : env12505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12504_12505 : H12AffineEnvironment.transform 11 3109 env12504 = env12505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env12504 == env12505) = true)

def env12506 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1024,32769,2097152,4194304,17,41311,8192,64,4456788,2172251,2118977,368651,75103,6407190,256,2188651,2196550,513]

theorem envBound12506 : H12AffineFastState.Bounded env12506 := by
  intro p hp
  have h : env12506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12484_12506 : H12AffineEnvironment.transform 22 17 env12484 = env12506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env12484 == env12506) = true)

theorem identity12506 : scanCanonicalize (H12AffineFastState.compose env12506 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29004) := by decide +kernel

theorem selectedBound12506 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env12507 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29004,65536,90138,262144,1024,29005,2097152,4194304,17,20499,8192,64,4456788,2172251,2118977,348487,75103,6370650,256,2188651,2192650,513]

theorem envBound12507 : H12AffineFastState.Bounded env12507 := by
  intro p hp
  have h : env12507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12506_12507 : H12AffineEnvironment.transform 14 29004 env12506 = env12507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29004 env12506 == env12507) = true)

theorem identity12507 : scanCanonicalize (H12AffineFastState.compose env12507 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 30777) := by decide +kernel

theorem selectedBound12507 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env12508 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29004,65536,90138,30777,1024,29005,2097152,4194304,17,20499,8192,64,4225389,2172251,2118977,76158,75103,6370650,256,2188651,2192650,513]

theorem envBound12508 : H12AffineFastState.Bounded env12508 := by
  intro p hp
  have h : env12508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12507_12508 : H12AffineEnvironment.transform 17 30777 env12507 = env12508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 30777 env12507 == env12508) = true)

def env12509 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29004,65536,90138,30777,1024,29005,5456,4194304,17,20499,8192,64,4225389,77835,16401,76158,75103,4268042,256,94267,90202,513]

theorem envBound12509 : H12AffineFastState.Bounded env12509 := by
  intro p hp
  have h : env12509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12508_12509 : H12AffineEnvironment.transform 20 5456 env12508 = env12509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5456 env12508 == env12509) = true)

theorem identity12509 : scanCanonicalize (H12AffineFastState.compose env12509 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 73771) := by decide +kernel

theorem selectedBound12509 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env12510 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29004,65536,90138,30777,1024,29005,5456,73771,17,20499,8192,64,88390,77835,16401,76158,75103,33,256,94267,90202,513]

theorem envBound12510 : H12AffineFastState.Bounded env12510 := by
  intro p hp
  have h : env12510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12509_12510 : H12AffineEnvironment.transform 21 73771 env12509 = env12510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73771 env12509 == env12510) = true)

theorem identity12510 : scanCanonicalize (H12AffineFastState.compose env12510 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound12510 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12511 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8540,65536,77834,10281,1024,8541,5456,73771,17,3,8192,64,67926,77835,4097,76158,75103,33,256,73771,77898,513]

theorem envBound12511 : H12AffineFastState.Bounded env12511 := by
  intro p hp
  have h : env12511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12510_12511 : H12AffineEnvironment.transform 13 4112 env12510 = env12511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env12510 == env12511) = true)

theorem identity12511 : scanCanonicalize (H12AffineFastState.compose env12511 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound12511 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env12512 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3108,8192,3124,8540,65536,76846,10281,1024,8541,2420,73771,17,3,8192,64,67926,76847,3109,76158,75103,33,256,73771,76910,513]

theorem envBound12512 : H12AffineFastState.Bounded env12512 := by
  intro p hp
  have h : env12512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12511_12512 : H12AffineEnvironment.transform 11 3108 env12511 = env12512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env12511 == env12512) = true)

def env12513 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29004,65536,90138,30777,1024,29005,5457,4194304,17,20499,8192,64,4225389,77834,16400,76158,75103,4268043,256,94266,90203,513]

theorem envBound12513 : H12AffineFastState.Bounded env12513 := by
  intro p hp
  have h : env12513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12508_12513 : H12AffineEnvironment.transform 20 5457 env12508 = env12513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5457 env12508 == env12513) = true)

theorem identity12513 : scanCanonicalize (H12AffineFastState.compose env12513 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 94266) := by decide +kernel

theorem selectedBound12513 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env12514 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29004,65536,90138,30777,1024,29005,5457,94266,17,20499,8192,64,67927,77834,16400,76158,75103,20529,256,94266,90203,513]

theorem envBound12514 : H12AffineFastState.Bounded env12514 := by
  intro p hp
  have h : env12514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12513_12514 : H12AffineEnvironment.transform 21 94266 env12513 = env12514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 94266 env12513 == env12514) = true)

theorem identity12514 : scanCanonicalize (H12AffineFastState.compose env12514 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound12514 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12515 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29004,8202,16400,30777,1024,29005,5457,20528,17,20499,8192,64,10589,4096,16400,2420,1365,20529,256,20528,16465,513]

theorem envBound12515 : H12AffineFastState.Bounded env12515 := by
  intro p hp
  have h : env12515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12514_12515 : H12AffineEnvironment.transform 15 8202 env12514 = env12515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env12514 == env12515) = true)

theorem identity12515 : scanCanonicalize (H12AffineFastState.compose env12515 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound12515 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env12516 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8541,8202,4097,10280,1024,8540,5457,33,17,2,8192,64,10589,4096,4097,2420,1365,32,256,33,4160,513]

theorem envBound12516 : H12AffineFastState.Bounded env12516 := by
  intro p hp
  have h : env12516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12515_12516 : H12AffineEnvironment.transform 13 4113 env12515 = env12516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env12515 == env12516) = true)

def env12517 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8429903,8193,64,4677967,10560842,10507600,8830976,75102,14795783,256,2188651,2196551,513]

theorem envBound12517 : H12AffineFastState.Bounded env12517 := by
  intro p hp
  have h : env12517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12482_12517 : H12AffineEnvironment.transform 6 9 env12482 = env12517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12482 == env12517) = true)

def env12518 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,41311,8193,64,4677967,2172250,2118976,442384,75102,6407191,256,2188651,2196551,513]

theorem envBound12518 : H12AffineFastState.Bounded env12518 := by
  intro p hp
  have h : env12518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12517_12518 : H12AffineEnvironment.transform 22 16 env12517 = env12518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env12517 == env12518) = true)

def env12519 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41311,8193,64,4677967,115014,45404,442384,75102,4268043,256,98679,90203,513]

theorem envBound12519 : H12AffineFastState.Bounded env12519 := by
  intro p hp
  have h : env12519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12518_12519 : H12AffineEnvironment.transform 20 58396 env12518 = env12519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env12518 == env12519) = true)

theorem identity12519 : scanCanonicalize (H12AffineFastState.compose env12519 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound12519 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12520 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,58396,4194304,16,41311,8193,64,4604229,57676,45404,442384,1364,4194305,256,41341,16465,513]

theorem envBound12520 : H12AffineFastState.Bounded env12520 := by
  intro p hp
  have h : env12520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12519_12520 : H12AffineEnvironment.transform 15 8202 env12519 = env12520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env12519 == env12520) = true)

theorem identity12520 : scanCanonicalize (H12AffineFastState.compose env12520 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 419912) := by decide +kernel

theorem selectedBound12520 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env12521 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,58396,419912,16,41311,8193,64,10509,57676,45404,442384,1364,419913,256,41341,16465,513]

theorem envBound12521 : H12AffineFastState.Bounded env12521 := by
  intro p hp
  have h : env12521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12520_12521 : H12AffineEnvironment.transform 21 419912 env12520 = env12521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 419912 env12520 == env12521) = true)

def env12522 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16448,262144,1024,32769,58396,272392,16,41311,8193,64,10509,57676,45404,294992,1364,272393,256,41341,16465,513]

theorem envBound12522 : H12AffineFastState.Bounded env12522 := by
  intro p hp
  have h : env12522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12521_12522 : H12AffineEnvironment.transform 16 16448 env12521 = env12522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env12521 == env12522) = true)

theorem identity12522 : scanCanonicalize (H12AffineFastState.compose env12522 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound12522 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env12523 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16448,10360,1024,32769,58396,112,16,41311,8193,64,10509,57676,45404,43048,1364,113,256,41341,16465,513]

theorem envBound12523 : H12AffineFastState.Bounded env12523 := by
  intro p hp
  have h : env12523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12522_12523 : H12AffineEnvironment.transform 17 10360 env12522 = env12523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env12522 == env12523) = true)

end H12CloudChart0