import H12CloudChart0Data127

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound32487 : H12AffineFastState.Bounded env32487 := by
  intro p hp
  have h : env32487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32486_32487 : H12AffineEnvironment.transform 5 17 env32486 = env32487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32486 == env32487) = true)

theorem identity32487 : scanCanonicalize (H12AffineFastState.compose env32487 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound32487 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env32488 : List Nat := [2,4,8,16,32,17,8,36,32,1024,2048,49,40,1077,32,35,1028,2081,1025,33,32,1,17,35,40,17,2080,1029,16,2081,1056,0,37,0,1076,33]

theorem envBound32488 : H12AffineFastState.Bounded env32488 := by
  intro p hp
  have h : env32488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32487_32488 : H12AffineEnvironment.transform 8 32 env32487 = env32488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env32487 == env32488) = true)

theorem identity32488 : scanCanonicalize (H12AffineFastState.compose env32488 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound32488 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32489 : List Nat := [2,4,8,16,1,17,8,5,1,1024,2048,16,9,1044,1,2,1028,2048,1025,0,1,1,17,2,9,17,2049,1029,16,2048,1025,0,4,0,1045,0]

theorem envBound32489 : H12AffineFastState.Bounded env32489 := by
  intro p hp
  have h : env32489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32488_32489 : H12AffineEnvironment.transform 4 1 env32488 = env32489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env32488 == env32489) = true)

theorem identity32489 : scanCanonicalize (H12AffineFastState.compose env32489 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1025) := by decide +kernel

theorem selectedBound32489 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32490 : List Nat := [2,4,8,16,1,17,8,5,1,1024,1025,16,9,1044,1,2,1028,1025,1025,0,1,1,17,2,9,17,1024,1029,16,1025,1025,0,4,0,1045,0]

theorem envBound32490 : H12AffineFastState.Bounded env32490 := by
  intro p hp
  have h : env32490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32489_32490 : H12AffineEnvironment.transform 10 1025 env32489 = env32490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1025 env32489 == env32490) = true)

theorem identity32490 : scanCanonicalize (H12AffineFastState.compose env32490 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound32490 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32491 : List Nat := [2,4,8,16,1,17,8,5,1,4,5,16,9,16,1,2,0,5,5,0,1,1,17,2,9,17,4,1,16,5,5,0,4,0,17,0]

theorem envBound32491 : H12AffineFastState.Bounded env32491 := by
  intro p hp
  have h : env32491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32490_32491 : H12AffineEnvironment.transform 9 4 env32490 = env32491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env32490 == env32491) = true)

theorem identity32491 : scanCanonicalize (H12AffineFastState.compose env32491 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound32491 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32492 : List Nat := [2,4,7,16,1,17,7,5,1,4,5,16,6,16,1,2,0,5,5,0,1,1,17,2,6,17,4,1,16,5,5,0,4,0,17,0]

theorem envBound32492 : H12AffineFastState.Bounded env32492 := by
  intro p hp
  have h : env32492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32491_32492 : H12AffineEnvironment.transform 2 7 env32491 = env32492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env32491 == env32492) = true)

theorem identity32492 : scanCanonicalize (H12AffineFastState.compose env32492 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound32492 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env32493 : List Nat := [2,4,7,4,1,5,7,5,1,4,5,4,6,4,1,2,0,5,5,0,1,1,5,2,6,5,4,1,4,5,5,0,4,0,5,0]

theorem envBound32493 : H12AffineFastState.Bounded env32493 := by
  intro p hp
  have h : env32493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32492_32493 : H12AffineEnvironment.transform 3 4 env32492 = env32493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env32492 == env32493) = true)

theorem identity32493 : scanCanonicalize (H12AffineFastState.compose env32493 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound32493 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32494 : List Nat := [2,3,0,3,1,2,0,2,1,3,2,3,1,3,1,2,0,2,2,0,1,1,2,2,1,2,3,1,3,2,2,0,3,0,2,0]

theorem envBound32494 : H12AffineFastState.Bounded env32494 := by
  intro p hp
  have h : env32494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32493_32494 : H12AffineEnvironment.transform 1 3 env32493 = env32494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env32493 == env32494) = true)

theorem identity32494 : scanCanonicalize (H12AffineFastState.compose env32494 (packedSelected [8] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound32494 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env32495 : List Nat := [0,1,0,1,1,0,0,0,1,1,0,1,1,1,1,0,0,0,0,0,1,1,0,0,1,0,1,1,1,0,0,0,1,0,0,0]

theorem envBound32495 : H12AffineFastState.Bounded env32495 := by
  intro p hp
  have h : env32495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32494_32495 : H12AffineEnvironment.transform 0 0 env32494 = env32495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env32494 == env32495) = true)

def env32496 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272393,180225,169235,8193,64,245019,115015,17665,262145,119043,329730,257,213351,237643,63069]

theorem envBound32496 : H12AffineFastState.Bounded env32496 := by
  intro p hp
  have h : env32496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32462_32496 : H12AffineEnvironment.transform 6 9 env32462 = env32496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32462 == env32496) = true)

def env32497 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272393,17,21763,8193,64,97547,115015,17665,262145,119043,329730,257,98679,90203,63069]

theorem envBound32497 : H12AffineFastState.Bounded env32497 := by
  intro p hp
  have h : env32497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32496_32497 : H12AffineEnvironment.transform 16 49168 env32496 = env32497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env32496 == env32497) = true)

theorem identity32497 : scanCanonicalize (H12AffineFastState.compose env32497 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound32497 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32498 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1025,32769,4160,33,17,21763,8193,64,97547,115015,17665,10281,119043,73770,257,98679,90203,63069]

theorem envBound32498 : H12AffineFastState.Bounded env32498 := by
  intro p hp
  have h : env32498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32497_32498 : H12AffineEnvironment.transform 17 10280 env32497 = env32498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env32497 == env32498) = true)

theorem identity32498 : scanCanonicalize (H12AffineFastState.compose env32498 (packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound32498 : packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS < 2^1333 := by decide +kernel

def env32499 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8282,49168,10280,1025,32769,4160,33,17,21763,8193,64,23889,57629,17665,10281,61785,112,257,41261,16385,63069]

theorem envBound32499 : H12AffineFastState.Bounded env32499 := by
  intro p hp
  have h : env32499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32498_32499 : H12AffineEnvironment.transform 15 8282 env32498 = env32499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env32498 == env32499) = true)

theorem identity32499 : scanCanonicalize (H12AffineFastState.compose env32499 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32499 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env32500 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,8202,49168,10280,1025,32769,4112,33,17,21763,8193,16,23809,57629,17665,10281,61705,32,257,41261,16385,62989]

theorem envBound32500 : H12AffineFastState.Bounded env32500 := by
  intro p hp
  have h : env32500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32499_32500 : H12AffineEnvironment.transform 5 16 env32499 = env32500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32499 == env32500) = true)

theorem identity32500 : scanCanonicalize (H12AffineFastState.compose env32500 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound32500 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env32501 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,32768,8202,46108,10280,1025,32769,4112,33,17,8463,8193,16,10509,38161,12557,10281,34053,32,257,41261,13325,33281]

theorem envBound32501 : H12AffineFastState.Bounded env32501 := by
  intro p hp
  have h : env32501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32500_32501 : H12AffineEnvironment.transform 13 13324 env32500 = env32501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env32500 == env32501) = true)

theorem identity32501 : scanCanonicalize (H12AffineFastState.compose env32501 (packedSelected [0,1,2,3,5,7,8,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 6452) := by decide +kernel

theorem selectedBound32501 : packedSelected [0,1,2,3,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env32502 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,6452,8202,11560,10280,1025,6453,4112,33,17,8463,8193,16,10509,3109,12557,10281,7217,32,257,14361,13325,6965]

theorem envBound32502 : H12AffineFastState.Bounded env32502 := by
  intro p hp
  have h : env32502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32501_32502 : H12AffineEnvironment.transform 14 6452 env32501 = env32502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6452 env32501 == env32502) = true)

theorem identity32502 : scanCanonicalize (H12AffineFastState.compose env32502 (packedSelected [0,3,6,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound32502 : packedSelected [0,3,6,8,9] rootPS < 2^1333 := by decide +kernel

def env32503 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,512,8192,9740,2868,8202,11560,10280,1025,2869,528,33,17,8463,8193,16,10509,3109,8973,10281,3633,32,257,10777,9741,2357]

theorem envBound32503 : H12AffineFastState.Bounded env32503 := by
  intro p hp
  have h : env32503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32502_32503 : H12AffineEnvironment.transform 11 512 env32502 = env32503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env32502 == env32503) = true)

theorem identity32503 : scanCanonicalize (H12AffineFastState.compose env32503 (packedSelected [0,1,7,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 1280) := by decide +kernel

theorem selectedBound32503 : packedSelected [0,1,7,8,10] rootPS < 2^1333 := by decide +kernel

def env32504 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1280,512,8192,9740,1588,8202,8232,9512,1025,1589,528,33,17,8463,8193,16,9229,293,8973,9513,817,32,257,10009,9741,1077]

theorem envBound32504 : H12AffineFastState.Bounded env32504 := by
  intro p hp
  have h : env32504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32503_32504 : H12AffineEnvironment.transform 10 1280 env32503 = env32504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1280 env32503 == env32504) = true)

theorem identity32504 : scanCanonicalize (H12AffineFastState.compose env32504 (packedSelected [0,1,5,7,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound32504 : packedSelected [0,1,5,7,12,14] rootPS < 2^1333 := by decide +kernel

def env32505 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1280,512,268,1792,1588,262,292,1060,1025,1589,528,33,17,3,269,16,1281,293,513,1061,817,32,257,1557,1793,1077]

theorem envBound32505 : H12AffineFastState.Bounded env32505 := by
  intro p hp
  have h : env32505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32504_32505 : H12AffineEnvironment.transform 12 268 env32504 = env32505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env32504 == env32505) = true)

theorem identity32505 : scanCanonicalize (H12AffineFastState.compose env32505 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound32505 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env32506 : List Nat := [2,4,8,16,32,16,9,256,512,784,528,512,268,16,292,262,292,820,785,293,528,33,17,3,269,16,529,293,513,821,817,32,257,261,17,805]

theorem envBound32506 : H12AffineFastState.Bounded env32506 := by
  intro p hp
  have h : env32506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32505_32506 : H12AffineEnvironment.transform 9 784 env32505 = env32506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env32505 == env32506) = true)

theorem identity32506 : scanCanonicalize (H12AffineFastState.compose env32506 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound32506 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env32507 : List Nat := [2,4,8,16,32,16,9,37,512,565,528,512,41,16,1,35,1,529,564,0,528,33,17,3,40,16,529,0,513,528,532,32,36,32,17,512]

theorem envBound32507 : H12AffineFastState.Bounded env32507 := by
  intro p hp
  have h : env32507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32506_32507 : H12AffineEnvironment.transform 7 37 env32506 = env32507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env32506 == env32507) = true)

theorem identity32507 : scanCanonicalize (H12AffineFastState.compose env32507 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound32507 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32508 : List Nat := [2,4,8,16,1,16,9,4,512,532,528,512,8,16,1,2,1,529,533,0,528,0,17,3,9,16,529,0,513,528,532,1,5,1,17,512]

theorem envBound32508 : H12AffineFastState.Bounded env32508 := by
  intro p hp
  have h : env32508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32507_32508 : H12AffineEnvironment.transform 4 1 env32507 = env32508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env32507 == env32508) = true)

theorem identity32508 : scanCanonicalize (H12AffineFastState.compose env32508 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound32508 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env32509 : List Nat := [2,4,8,0,1,0,9,4,512,516,512,512,8,0,1,2,1,513,517,0,512,0,1,3,9,0,513,0,513,512,516,1,5,1,1,512]

theorem envBound32509 : H12AffineFastState.Bounded env32509 := by
  intro p hp
  have h : env32509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32508_32509 : H12AffineEnvironment.transform 3 0 env32508 = env32509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env32508 == env32509) = true)

theorem identity32509 : scanCanonicalize (H12AffineFastState.compose env32509 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound32509 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32510 : List Nat := [2,4,8,0,1,0,9,4,1,5,1,1,8,0,1,2,1,0,4,0,1,0,1,3,9,0,0,0,0,1,5,1,5,1,1,1]

theorem envBound32510 : H12AffineFastState.Bounded env32510 := by
  intro p hp
  have h : env32510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32509_32510 : H12AffineEnvironment.transform 8 1 env32509 = env32510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env32509 == env32510) = true)

theorem identity32510 : scanCanonicalize (H12AffineFastState.compose env32510 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound32510 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32511 : List Nat := [2,0,8,0,1,0,9,0,1,1,1,1,8,0,1,2,1,0,0,0,1,0,1,3,9,0,0,0,0,1,1,1,1,1,1,1]

theorem envBound32511 : H12AffineFastState.Bounded env32511 := by
  intro p hp
  have h : env32511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32510_32511 : H12AffineEnvironment.transform 1 0 env32510 = env32511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env32510 == env32511) = true)

def env32512 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272393,16,21762,8193,64,97546,115015,17665,262145,119043,329730,257,98678,90202,63069]

theorem envBound32512 : H12AffineFastState.Bounded env32512 := by
  intro p hp
  have h : env32512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32496_32512 : H12AffineEnvironment.transform 16 49169 env32496 = env32512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env32496 == env32512) = true)

theorem identity32512 : scanCanonicalize (H12AffineFastState.compose env32512 (packedSelected [0,4,8,14,15,16,18,19,22,23,26,27,28,31,41] rootPS)) = affineNative (2^(17+1) ^^^ 76079) := by decide +kernel

theorem selectedBound32512 : packedSelected [0,4,8,14,15,16,18,19,22,23,26,27,28,31,41] rootPS < 2^1333 := by decide +kernel

def env32513 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,76079,1025,32769,4161,65830,16,21762,8193,64,97546,115015,17665,76078,119043,8493,257,98678,90202,63069]

theorem envBound32513 : H12AffineFastState.Bounded env32513 := by
  intro p hp
  have h : env32513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32512_32513 : H12AffineEnvironment.transform 17 76079 env32512 = env32513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76079 env32512 == env32513) = true)

theorem identity32513 : scanCanonicalize (H12AffineFastState.compose env32513 (packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound32513 : packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS < 2^1333 := by decide +kernel

def env32514 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,342,49169,10361,1025,32769,4161,112,16,21762,8193,64,31836,49169,17665,10360,53333,8493,257,32800,24844,63069]

theorem envBound32514 : H12AffineFastState.Bounded env32514 := by
  intro p hp
  have h : env32514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32513_32514 : H12AffineEnvironment.transform 15 342 env32513 = env32514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env32513 == env32514) = true)

theorem identity32514 : scanCanonicalize (H12AffineFastState.compose env32514 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound32514 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env32515 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21840,342,5441,10361,1025,21841,4161,112,16,21762,8193,64,31836,5441,17665,10360,1285,8493,257,21872,24844,8973]

theorem envBound32515 : H12AffineFastState.Bounded env32515 := by
  intro p hp
  have h : env32515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32514_32515 : H12AffineEnvironment.transform 14 21840 env32514 = env32515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env32514 == env32515) = true)

theorem identity32515 : scanCanonicalize (H12AffineFastState.compose env32515 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound32515 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env32516 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,8541,342,5441,10361,1025,8540,4161,112,16,8463,8193,64,2129,5441,12556,10360,1285,8493,257,8573,5377,8973]

theorem envBound32516 : H12AffineFastState.Bounded env32516 := by
  intro p hp
  have h : env32516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32515_32516 : H12AffineEnvironment.transform 13 13325 env32515 = env32516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env32515 == env32516) = true)

theorem identity32516 : scanCanonicalize (H12AffineFastState.compose env32516 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound32516 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env32517 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,81,342,5441,2421,1025,80,4161,112,16,3,269,64,2129,5441,4096,2420,1285,33,257,113,5377,513]

theorem envBound32517 : H12AffineFastState.Bounded env32517 := by
  intro p hp
  have h : env32517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32516_32517 : H12AffineEnvironment.transform 12 268 env32516 = env32517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env32516 == env32517) = true)

theorem identity32517 : scanCanonicalize (H12AffineFastState.compose env32517 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32517 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32518 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,1,262,5393,2341,1025,0,4113,32,16,3,269,16,2049,5393,4096,2340,1285,33,257,33,5377,513]

theorem envBound32518 : H12AffineFastState.Bounded env32518 := by
  intro p hp
  have h : env32518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32517_32518 : H12AffineEnvironment.transform 5 16 env32517 = env32518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32517 == env32518) = true)

theorem identity32518 : scanCanonicalize (H12AffineFastState.compose env32518 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound32518 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32519 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5156,1,35,5172,2048,1025,0,4113,32,16,3,40,16,2049,5172,4096,2049,1056,33,36,33,5156,513]

theorem envBound32519 : H12AffineFastState.Bounded env32519 := by
  intro p hp
  have h : env32519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32518_32519 : H12AffineEnvironment.transform 7 37 env32518 = env32519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env32518 == env32519) = true)

theorem identity32519 : scanCanonicalize (H12AffineFastState.compose env32519 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound32519 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32520 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,41,4113,1,35,4097,2048,52,0,4113,32,16,3,40,16,2049,4097,4096,2049,21,33,36,33,4113,513]

theorem envBound32520 : H12AffineFastState.Bounded env32520 := by
  intro p hp
  have h : env32520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32519_32520 : H12AffineEnvironment.transform 9 53 env32519 = env32520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env32519 == env32520) = true)

theorem identity32520 : scanCanonicalize (H12AffineFastState.compose env32520 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound32520 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32521 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,32,41,49,1,35,33,2048,52,0,49,32,16,3,40,16,2049,33,32,2049,21,33,36,33,49,513]

theorem envBound32521 : H12AffineFastState.Bounded env32521 := by
  intro p hp
  have h : env32521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32520_32521 : H12AffineEnvironment.transform 11 32 env32520 = env32521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env32520 == env32521) = true)

theorem identity32521 : scanCanonicalize (H12AffineFastState.compose env32521 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound32521 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32522 : List Nat := [2,4,8,16,32,16,9,37,512,53,512,32,41,49,1,35,33,512,52,0,49,32,16,3,40,16,513,33,32,513,21,33,36,33,49,513]

theorem envBound32522 : H12AffineFastState.Bounded env32522 := by
  intro p hp
  have h : env32522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32521_32522 : H12AffineEnvironment.transform 10 512 env32521 = env32522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env32521 == env32522) = true)

theorem identity32522 : scanCanonicalize (H12AffineFastState.compose env32522 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound32522 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env32523 : List Nat := [2,4,8,16,32,16,9,37,1,53,1,32,41,49,1,35,33,1,52,0,49,32,16,3,40,16,0,33,32,0,21,33,36,33,49,0]

theorem envBound32523 : H12AffineFastState.Bounded env32523 := by
  intro p hp
  have h : env32523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32522_32523 : H12AffineEnvironment.transform 8 1 env32522 = env32523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env32522 == env32523) = true)

theorem identity32523 : scanCanonicalize (H12AffineFastState.compose env32523 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound32523 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env32524 : List Nat := [2,4,8,16,17,16,9,20,1,4,1,17,24,0,1,18,16,1,5,0,0,17,16,3,25,16,0,16,17,0,21,16,21,16,0,0]

theorem envBound32524 : H12AffineFastState.Bounded env32524 := by
  intro p hp
  have h : env32524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32523_32524 : H12AffineEnvironment.transform 4 17 env32523 = env32524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env32523 == env32524) = true)

def env32525 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272513,180360,169370,8328,64,245139,115150,17665,262280,119043,329731,257,213351,237762,63188]

theorem envBound32525 : H12AffineFastState.Bounded env32525 := by
  intro p hp
  have h : env32525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32461_32525 : H12AffineEnvironment.transform 21 272513 env32461 = env32525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env32461 == env32525) = true)

theorem identity32525 : scanCanonicalize (H12AffineFastState.compose env32525 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49305) := by decide +kernel

theorem selectedBound32525 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32526 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,4160,272513,17,21763,8328,64,97546,115150,17665,262280,119043,329731,257,98814,90203,63188]

theorem envBound32526 : H12AffineFastState.Bounded env32526 := by
  intro p hp
  have h : env32526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32525_32526 : H12AffineEnvironment.transform 16 49305 env32525 = env32526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env32525 == env32526) = true)

def env32527 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272393,17,21763,8192,64,97546,115014,17665,262144,119043,329731,257,98678,90203,63068]

theorem envBound32527 : H12AffineFastState.Bounded env32527 := by
  intro p hp
  have h : env32527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32526_32527 : H12AffineEnvironment.transform 6 8 env32526 = env32527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32526 == env32527) = true)

theorem identity32527 : scanCanonicalize (H12AffineFastState.compose env32527 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound32527 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32528 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35188,1025,32769,4160,41341,17,21763,8192,64,97546,115014,17665,35188,119043,98679,257,98678,90203,63068]

theorem envBound32528 : H12AffineFastState.Bounded env32528 := by
  intro p hp
  have h : env32528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32527_32528 : H12AffineEnvironment.transform 17 35188 env32527 = env32528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env32527 == env32528) = true)

theorem identity32528 : scanCanonicalize (H12AffineFastState.compose env32528 (packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound32528 : packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS < 2^1333 := by decide +kernel

def env32529 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,373,65536,16740,2049,1025,372,4160,8200,17,21763,8192,64,97546,81971,17665,2049,86134,65538,257,65539,90203,30505]

theorem envBound32529 : H12AffineFastState.Bounded env32529 := by
  intro p hp
  have h : env32529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32528_32529 : H12AffineEnvironment.transform 14 373 env32528 = env32529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env32528 == env32529) = true)

theorem identity32529 : scanCanonicalize (H12AffineFastState.compose env32529 (packedSelected [0,2,4,6,7,9,11,14,16,19,20,23,26] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound32529 : packedSelected [0,2,4,6,7,9,11,14,16,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env32530 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,16384,81,65536,16448,2049,1025,80,4160,8200,17,21543,8192,64,97326,81971,17445,2049,86134,65538,37,65539,90203,30221]

theorem envBound32530 : H12AffineFastState.Bounded env32530 := by
  intro p hp
  have h : env32530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32529_32530 : H12AffineEnvironment.transform 7 36 env32529 = env32530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env32529 == env32530) = true)

theorem identity32530 : scanCanonicalize (H12AffineFastState.compose env32530 (packedSelected [2,3,5,6,9,10,11,12,14,15,16,18,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 29743) := by decide +kernel

theorem selectedBound32530 : packedSelected [2,3,5,6,9,10,11,12,14,15,16,18,20,22] rootPS < 2^1333 := by decide +kernel

def env32531 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,16384,81,29743,16448,2049,1025,80,4160,8200,17,21543,8192,64,2049,13340,17445,2049,9305,29741,37,29740,5236,30221]

theorem envBound32531 : H12AffineFastState.Bounded env32531 := by
  intro p hp
  have h : env32531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32530_32531 : H12AffineEnvironment.transform 15 29743 env32530 = env32531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29743 env32530 == env32531) = true)

def env32532 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272392,17,21763,8193,64,97546,115015,17665,262145,119043,329731,257,98679,90203,63069]

theorem envBound32532 : H12AffineFastState.Bounded env32532 := by
  intro p hp
  have h : env32532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32526_32532 : H12AffineEnvironment.transform 6 9 env32526 = env32532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32526 == env32532) = true)

theorem identity32532 : scanCanonicalize (H12AffineFastState.compose env32532 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound32532 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32533 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1025,32769,4160,32,17,21763,8193,64,97546,115015,17665,10281,119043,73771,257,98679,90203,63069]

theorem envBound32533 : H12AffineFastState.Bounded env32533 := by
  intro p hp
  have h : env32533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32532_32533 : H12AffineEnvironment.transform 17 10280 env32532 = env32533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env32532 == env32533) = true)

theorem identity32533 : scanCanonicalize (H12AffineFastState.compose env32533 (packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound32533 : packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS < 2^1333 := by decide +kernel

def env32534 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,65536,49168,2341,1025,32769,4160,32,17,21763,268,64,89095,115015,17665,2340,119043,65830,257,98679,82262,55120]

theorem envBound32534 : H12AffineFastState.Bounded env32534 := by
  intro p hp
  have h : env32534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32533_32534 : H12AffineEnvironment.transform 12 269 env32533 = env32534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env32533 == env32534) = true)

theorem identity32534 : scanCanonicalize (H12AffineFastState.compose env32534 (packedSelected [1,2,3,4,5,6,8,10,11,18,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound32534 : packedSelected [1,2,3,4,5,6,8,10,11,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env32535 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,32768,65536,38160,2341,1025,32769,4160,32,17,3,268,64,67847,103495,4097,2340,99331,65830,257,98679,70742,33360]

theorem envBound32535 : H12AffineFastState.Bounded env32535 := by
  intro p hp
  have h : env32535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32534_32535 : H12AffineEnvironment.transform 13 5376 env32534 = env32535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env32534 == env32535) = true)

theorem identity32535 : scanCanonicalize (H12AffineFastState.compose env32535 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound32535 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env32536 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,0,65536,5392,2341,1025,1,4160,32,17,3,268,64,67847,70727,4097,2340,66563,65830,257,65911,70742,592]

theorem envBound32536 : H12AffineFastState.Bounded env32536 := by
  intro p hp
  have h : env32536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32535_32536 : H12AffineEnvironment.transform 14 0 env32535 = env32536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env32535 == env32536) = true)

theorem identity32536 : scanCanonicalize (H12AffineFastState.compose env32536 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(15+1) ^^^ 6423) := by decide +kernel

theorem selectedBound32536 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env32537 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,0,6423,5392,2341,1025,1,4160,32,17,3,268,64,4112,3408,4097,2340,7444,6193,257,6240,3393,592]

theorem envBound32537 : H12AffineFastState.Bounded env32537 := by
  intro p hp
  have h : env32537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32536_32537 : H12AffineEnvironment.transform 15 6423 env32536 = env32537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6423 env32536 == env32537) = true)

theorem identity32537 : scanCanonicalize (H12AffineFastState.compose env32537 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32537 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env32538 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5376,0,6423,5392,2341,1025,1,4113,32,17,3,268,17,4112,3329,4097,2340,7444,6193,257,6193,3344,513]

theorem envBound32538 : H12AffineFastState.Bounded env32538 := by
  intro p hp
  have h : env32538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32537_32538 : H12AffineEnvironment.transform 5 17 env32537 = env32538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32537 == env32538) = true)

theorem identity32538 : scanCanonicalize (H12AffineFastState.compose env32538 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound32538 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32539 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2064,269,3344,0,263,3328,2341,1025,1,2049,32,17,3,268,17,2048,3329,2065,2340,1284,33,257,33,3344,513]

theorem envBound32539 : H12AffineFastState.Bounded env32539 := by
  intro p hp
  have h : env32539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32538_32539 : H12AffineEnvironment.transform 11 2064 env32538 = env32539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env32538 == env32539) = true)

theorem identity32539 : scanCanonicalize (H12AffineFastState.compose env32539 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1313) := by decide +kernel

theorem selectedBound32539 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32540 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1313,1329,269,49,0,263,33,1028,1025,1,1312,32,17,3,268,17,1313,32,1328,1029,1284,33,257,33,49,513]

theorem envBound32540 : H12AffineFastState.Bounded env32540 := by
  intro p hp
  have h : env32540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32539_32540 : H12AffineEnvironment.transform 10 1313 env32539 = env32540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1313 env32539 == env32540) = true)

theorem identity32540 : scanCanonicalize (H12AffineFastState.compose env32540 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound32540 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32541 : List Nat := [2,4,8,16,32,17,9,256,48,1024,1313,1329,269,49,0,263,33,1028,1025,1,1312,32,17,3,268,17,1313,32,1328,1029,1284,33,257,33,49,49]

theorem envBound32541 : H12AffineFastState.Bounded env32541 := by
  intro p hp
  have h : env32541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32540_32541 : H12AffineEnvironment.transform 8 48 env32540 = env32541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env32540 == env32541) = true)

theorem identity32541 : scanCanonicalize (H12AffineFastState.compose env32541 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound32541 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env32542 : List Nat := [2,4,8,16,32,17,9,256,48,273,48,32,269,49,0,263,33,277,272,1,49,32,17,3,268,17,48,32,33,276,21,33,257,33,49,49]

theorem envBound32542 : H12AffineFastState.Bounded env32542 := by
  intro p hp
  have h : env32542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32541_32542 : H12AffineEnvironment.transform 9 273 env32541 = env32542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env32541 == env32542) = true)

theorem identity32542 : scanCanonicalize (H12AffineFastState.compose env32542 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32542 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env32543 : List Nat := [2,4,8,16,0,17,9,256,16,273,16,0,269,17,0,263,1,277,272,1,17,0,17,3,268,17,16,0,1,276,21,1,257,1,17,17]

theorem envBound32543 : H12AffineFastState.Bounded env32543 := by
  intro p hp
  have h : env32543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32542_32543 : H12AffineEnvironment.transform 4 0 env32542 = env32543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32542 == env32543) = true)

theorem identity32543 : scanCanonicalize (H12AffineFastState.compose env32543 (packedSelected [7] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound32543 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env32544 : List Nat := [2,4,8,16,0,17,9,20,16,5,16,0,25,17,0,19,1,1,4,1,17,0,17,3,24,17,16,0,1,0,21,1,21,1,17,17]

theorem envBound32544 : H12AffineFastState.Bounded env32544 := by
  intro p hp
  have h : env32544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32543_32544 : H12AffineEnvironment.transform 7 20 env32543 = env32544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env32543 == env32544) = true)

theorem identity32544 : scanCanonicalize (H12AffineFastState.compose env32544 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound32544 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32545 : List Nat := [2,4,8,11,0,10,9,15,11,5,11,0,2,10,0,8,1,1,4,1,10,0,10,3,3,10,11,0,1,0,14,1,14,1,10,10]

theorem envBound32545 : H12AffineFastState.Bounded env32545 := by
  intro p hp
  have h : env32545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32544_32545 : H12AffineEnvironment.transform 3 11 env32544 = env32545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env32544 == env32545) = true)

theorem identity32545 : scanCanonicalize (H12AffineFastState.compose env32545 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound32545 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env32546 : List Nat := [2,4,3,0,0,1,2,4,0,5,0,0,2,1,0,3,1,1,4,1,1,0,1,3,3,1,0,0,1,0,5,1,5,1,1,1]

theorem envBound32546 : H12AffineFastState.Bounded env32546 := by
  intro p hp
  have h : env32546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32545_32546 : H12AffineEnvironment.transform 2 3 env32545 = env32546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env32545 == env32546) = true)

def env32547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,180361,2114882,8328,64,6637003,115151,2266585,262281,2294234,4268163,257,213351,237762,2237965]

theorem envBound32547 : H12AffineFastState.Bounded env32547 := by
  intro p hp
  have h : env32547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32418_32547 : H12AffineEnvironment.transform 22 180361 env32418 = env32547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180361 env32418 == env32547) = true)

def env32548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,4194304,180361,169370,8328,64,4691219,115151,17665,262281,119042,4268163,257,213351,237762,63189]

theorem envBound32548 : H12AffineFastState.Bounded env32548 := by
  intro p hp
  have h : env32548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32547_32548 : H12AffineEnvironment.transform 20 184536 env32547 = env32548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184536 env32547 == env32548) = true)

def env32549 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272512,180361,169370,8328,64,245139,115151,17665,262281,119042,329731,257,213351,237762,63189]

theorem envBound32549 : H12AffineFastState.Bounded env32549 := by
  intro p hp
  have h : env32549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32548_32549 : H12AffineEnvironment.transform 21 272512 env32548 = env32549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env32548 == env32549) = true)

theorem identity32549 : scanCanonicalize (H12AffineFastState.compose env32549 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound32549 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32550 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70727,262144,1025,32769,115871,272512,120014,98781,8328,64,43476,115151,17665,262281,119042,329731,257,21792,46213,63189]

theorem envBound32550 : H12AffineFastState.Bounded env32550 := by
  intro p hp
  have h : env32550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32549_32550 : H12AffineEnvironment.transform 16 70727 env32549 = env32550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env32549 == env32550) = true)

def env32551 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70727,10400,1025,32769,115871,32,120014,98781,8328,64,43476,115151,17665,10281,119042,73891,257,21792,46213,63189]

theorem envBound32551 : H12AffineFastState.Bounded env32551 := by
  intro p hp
  have h : env32551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32550_32551 : H12AffineEnvironment.transform 17 10400 env32550 = env32551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env32550 == env32551) = true)

theorem identity32551 : scanCanonicalize (H12AffineFastState.compose env32551 (packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound32551 : packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env32552 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,65536,70727,10400,1025,21760,70046,32,65999,87260,8328,64,31957,70862,17665,10281,66563,73891,257,21792,24964,9172]

theorem envBound32552 : H12AffineFastState.Bounded env32552 := by
  intro p hp
  have h : env32552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32551_32552 : H12AffineEnvironment.transform 14 21761 env32551 = env32552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env32551 == env32552) = true)

theorem identity32552 : scanCanonicalize (H12AffineFastState.compose env32552 (packedSelected [0,1,9,16,17,18,20,22,23,26,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound32552 : packedSelected [0,1,9,16,17,18,20,22,23,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env32553 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,21590,16401,10400,1025,21760,17864,32,21913,138,8328,64,31957,16536,17665,10281,20565,29941,257,21792,24964,9172]

theorem envBound32553 : H12AffineFastState.Bounded env32553 := by
  intro p hp
  have h : env32553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32552_32553 : H12AffineEnvironment.transform 15 21590 env32552 = env32553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env32552 == env32553) = true)

theorem identity32553 : scanCanonicalize (H12AffineFastState.compose env32553 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound32553 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env32554 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,1,342,5393,10400,1025,0,4296,32,153,138,8328,64,10709,5528,4097,10281,1365,8693,257,32,13444,9172]

theorem envBound32554 : H12AffineFastState.Bounded env32554 := by
  intro p hp
  have h : env32554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32553_32554 : H12AffineEnvironment.transform 13 5376 env32553 = env32554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env32553 == env32554) = true)

theorem identity32554 : scanCanonicalize (H12AffineFastState.compose env32554 (packedSelected [16,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound32554 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env32555 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1,342,5393,10281,1025,0,4161,32,16,3,8193,64,10588,5393,4097,10281,1365,8572,257,32,13325,9053]

theorem envBound32555 : H12AffineFastState.Bounded env32555 := by
  intro p hp
  have h : env32555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32554_32555 : H12AffineEnvironment.transform 6 9 env32554 = env32555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32554 == env32555) = true)

theorem identity32555 : scanCanonicalize (H12AffineFastState.compose env32555 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound32555 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32556 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,5376,1,342,5393,3173,1025,0,4161,32,16,3,1101,64,3344,5393,4097,3173,1365,1328,257,32,4161,1809]

theorem envBound32556 : H12AffineFastState.Bounded env32556 := by
  intro p hp
  have h : env32556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32555_32556 : H12AffineEnvironment.transform 12 1100 env32555 = env32556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env32555 == env32556) = true)

theorem identity32556 : scanCanonicalize (H12AffineFastState.compose env32556 (packedSelected [0,1,3,4,5,7,8,9,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound32556 : packedSelected [0,1,3,4,5,7,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env32557 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3328,1100,2048,1,342,2065,3173,1025,0,3393,32,16,3,1101,64,3344,2065,3329,3173,1365,1328,257,32,3393,1809]

theorem envBound32557 : H12AffineFastState.Bounded env32557 := by
  intro p hp
  have h : env32557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32556_32557 : H12AffineEnvironment.transform 11 3328 env32556 = env32557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env32556 == env32557) = true)

theorem identity32557 : scanCanonicalize (H12AffineFastState.compose env32557 (packedSelected [4,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32557 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env32558 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3328,1052,2048,1,262,2065,3125,1025,0,3345,32,16,3,1053,16,3344,2065,3329,3125,1285,1328,257,32,3345,1809]

theorem envBound32558 : H12AffineFastState.Bounded env32558 := by
  intro p hp
  have h : env32558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32557_32558 : H12AffineEnvironment.transform 5 16 env32557 = env32558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32557 == env32558) = true)

theorem identity32558 : scanCanonicalize (H12AffineFastState.compose env32558 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound32558 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env32559 : List Nat := [2,4,8,16,32,16,9,256,512,47,2048,2351,51,2048,1,262,2065,2074,46,0,2366,32,16,3,50,16,2367,2065,2350,2074,298,287,257,32,2366,830]

theorem envBound32559 : H12AffineFastState.Bounded env32559 := by
  intro p hp
  have h : env32559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32558_32559 : H12AffineEnvironment.transform 9 47 env32558 = env32559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env32558 == env32559) = true)

theorem identity32559 : scanCanonicalize (H12AffineFastState.compose env32559 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound32559 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env32560 : List Nat := [2,4,8,16,32,16,9,37,512,47,2048,2058,51,2048,1,35,2065,2074,46,0,2075,32,16,3,50,16,2074,2065,2059,2074,15,58,36,32,2075,539]

theorem envBound32560 : H12AffineFastState.Bounded env32560 := by
  intro p hp
  have h : env32560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32559_32560 : H12AffineEnvironment.transform 7 37 env32559 = env32560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env32559 == env32560) = true)

theorem identity32560 : scanCanonicalize (H12AffineFastState.compose env32560 (packedSelected [0,2,6] rootPS)) = affineNative (2^(10+1) ^^^ 558) := by decide +kernel

theorem selectedBound32560 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env32561 : List Nat := [2,4,8,16,32,16,9,37,512,47,558,548,51,558,1,35,575,564,46,0,565,32,16,3,50,16,564,575,549,564,15,58,36,32,565,539]

theorem envBound32561 : H12AffineFastState.Bounded env32561 := by
  intro p hp
  have h : env32561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32560_32561 : H12AffineEnvironment.transform 10 558 env32560 = env32561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 558 env32560 == env32561) = true)

theorem identity32561 : scanCanonicalize (H12AffineFastState.compose env32561 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound32561 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env32562 : List Nat := [2,4,8,6,32,6,9,37,512,47,558,548,37,558,1,35,553,546,46,0,547,32,6,3,36,6,546,553,549,546,15,44,36,32,547,525]

theorem envBound32562 : H12AffineFastState.Bounded env32562 := by
  intro p hp
  have h : env32562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32561_32562 : H12AffineEnvironment.transform 3 6 env32561 = env32562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env32561 == env32562) = true)

def env32563 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70727,10401,1025,32769,115871,33,120014,98781,8328,64,43476,115151,17665,10280,119042,73890,257,21792,46213,63189]

theorem envBound32563 : H12AffineFastState.Bounded env32563 := by
  intro p hp
  have h : env32563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32550_32563 : H12AffineEnvironment.transform 17 10401 env32550 = env32563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env32550 == env32563) = true)

theorem identity32563 : scanCanonicalize (H12AffineFastState.compose env32563 (packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound32563 : packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env32564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,478,5529,10401,1025,32769,50497,33,54544,32771,8328,64,43476,49169,17665,10280,53468,8572,257,21792,46213,63189]

theorem envBound32564 : H12AffineFastState.Bounded env32564 := by
  intro p hp
  have h : env32564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32563_32564 : H12AffineEnvironment.transform 15 478 env32563 = env32564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env32563 == env32564) = true)

theorem identity32564 : scanCanonicalize (H12AffineFastState.compose env32564 (packedSelected [0,9,16,17,18,19,20,22,23,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound32564 : packedSelected [0,9,16,17,18,19,20,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env32565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,478,5529,10401,1025,29909,12693,33,8644,29911,8328,64,23808,13509,17665,10280,9224,8572,257,21792,16465,513]

theorem envBound32565 : H12AffineFastState.Bounded env32565 := by
  intro p hp
  have h : env32565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32564_32565 : H12AffineEnvironment.transform 14 29908 env32564 = env32565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env32564 == env32565) = true)

theorem identity32565 : scanCanonicalize (H12AffineFastState.compose env32565 (packedSelected [1,2,3,5,6,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound32565 : packedSelected [1,2,3,5,6,8,10,19] rootPS < 2^1333 := by decide +kernel

def env32566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21760,478,5529,2421,1025,21761,4161,33,16,21763,348,64,23808,5393,17665,2556,1500,168,257,21792,16465,513]

theorem envBound32566 : H12AffineFastState.Bounded env32566 := by
  intro p hp
  have h : env32566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32565_32566 : H12AffineEnvironment.transform 12 468 env32565 = env32566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env32565 == env32566) = true)

theorem identity32566 : scanCanonicalize (H12AffineFastState.compose env32566 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound32566 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env32567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,137,478,5529,2421,1025,136,4161,33,16,138,348,64,2185,5393,4232,2556,1500,168,257,169,5592,513]

theorem envBound32567 : H12AffineFastState.Bounded env32567 := by
  intro p hp
  have h : env32567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32566_32567 : H12AffineEnvironment.transform 13 5513 env32566 = env32567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env32566 == env32567) = true)

theorem identity32567 : scanCanonicalize (H12AffineFastState.compose env32567 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound32567 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env32568 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,160,5373,137,170,5357,2049,1025,136,4161,33,16,138,40,64,2185,5221,4232,2184,1192,168,117,169,5292,513]

theorem envBound32568 : H12AffineFastState.Bounded env32568 := by
  intro p hp
  have h : env32568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32567_32568 : H12AffineEnvironment.transform 7 116 env32567 = env32568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env32567 == env32568) = true)

theorem identity32568 : scanCanonicalize (H12AffineFastState.compose env32568 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound32568 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32569 : List Nat := [2,4,8,16,32,64,88,116,512,1024,2048,4096,120,5157,81,114,5173,2049,1025,80,4161,33,16,82,40,64,2129,5221,4176,2128,1136,112,117,113,5236,513]

theorem envBound32569 : H12AffineFastState.Bounded env32569 := by
  intro p hp
  have h : env32569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32568_32569 : H12AffineEnvironment.transform 6 88 env32568 = env32569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env32568 == env32569) = true)

def env32570 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5157,1,34,5173,2049,1025,0,4113,33,16,2,40,16,2049,5173,4096,2048,1056,32,37,33,5156,513]

theorem envBound32570 : H12AffineFastState.Bounded env32570 := by
  intro p hp
  have h : env32570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32569_32570 : H12AffineEnvironment.transform 5 16 env32569 = env32570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32569 == env32570) = true)

theorem identity32570 : scanCanonicalize (H12AffineFastState.compose env32570 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound32570 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32571 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,4096,40,4113,1,34,4097,2049,53,0,4113,33,16,2,40,16,2049,4097,4096,2048,20,32,37,33,4112,513]

theorem envBound32571 : H12AffineFastState.Bounded env32571 := by
  intro p hp
  have h : env32571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32570_32571 : H12AffineEnvironment.transform 9 52 env32570 = env32571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env32570 == env32571) = true)

theorem identity32571 : scanCanonicalize (H12AffineFastState.compose env32571 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound32571 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32572 : List Nat := [2,4,8,16,32,16,8,36,512,52,48,4096,40,4113,1,34,4097,49,53,0,4113,33,16,2,40,16,49,4097,4096,48,20,32,37,33,4112,513]

theorem envBound32572 : H12AffineFastState.Bounded env32572 := by
  intro p hp
  have h : env32572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32571_32572 : H12AffineEnvironment.transform 10 48 env32571 = env32572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env32571 == env32572) = true)

theorem identity32572 : scanCanonicalize (H12AffineFastState.compose env32572 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound32572 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env32573 : List Nat := [2,4,8,16,32,16,8,36,512,52,48,32,40,49,1,34,33,49,53,0,49,33,16,2,40,16,49,33,32,48,20,32,37,33,48,513]

theorem envBound32573 : H12AffineFastState.Bounded env32573 := by
  intro p hp
  have h : env32573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32572_32573 : H12AffineEnvironment.transform 11 32 env32572 = env32573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env32572 == env32573) = true)

def leafEnv32573 : List Nat := [2,4,8,16,32,16,8,36,512,52,48,32,40,49,1,34,33,49,53,0,49,33,16,2,21,40,1,16,49,33,32,48,20,32,37,33,5,34,48,513,1,48,0]

def active32573 : List Nat := [0,1,2,3,4,8]

def tree32573 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood32573 : H12WitnessSearch.Good tree32573 := H12GlobalWitnessIndex.good

theorem leafIdentity32573 : H12AffineFastState.composeSystem env32573 rootObs = leafEnv32573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env32573 rootObs == leafEnv32573) = true)

theorem terminalChecked32573 : H12PackedTerminal.terminalCheckFast leafEnv32573 active32573 tree32573 = true := by decide +kernel

def env32574 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,5157,0,35,5173,2049,1025,1,4112,33,16,3,40,17,2048,5172,4097,2049,1057,33,36,32,5157,513]

theorem envBound32574 : H12AffineFastState.Bounded env32574 := by
  intro p hp
  have h : env32574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32569_32574 : H12AffineEnvironment.transform 5 17 env32569 = env32574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32569 == env32574) = true)

def env32575 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,48,41,1045,0,35,1029,2049,1025,1,32,33,16,3,40,17,2048,1028,49,2049,1057,33,36,32,1045,513]

theorem envBound32575 : H12AffineFastState.Bounded env32575 := by
  intro p hp
  have h : env32575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32574_32575 : H12AffineEnvironment.transform 11 48 env32574 = env32575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env32574 == env32575) = true)

theorem identity32575 : scanCanonicalize (H12AffineFastState.compose env32575 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound32575 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32576 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,48,41,33,0,35,49,2049,53,1,32,33,16,3,40,17,2048,48,49,2049,21,33,36,32,33,513]

theorem envBound32576 : H12AffineFastState.Bounded env32576 := by
  intro p hp
  have h : env32576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32575_32576 : H12AffineEnvironment.transform 9 52 env32575 = env32576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env32575 == env32576) = true)

def env32577 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,49,41,1044,0,35,1028,2049,1025,1,33,33,16,3,40,17,2048,1029,48,2049,1057,33,36,32,1044,513]

theorem envBound32577 : H12AffineFastState.Bounded env32577 := by
  intro p hp
  have h : env32577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32574_32577 : H12AffineEnvironment.transform 11 49 env32574 = env32577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env32574 == env32577) = true)

def env32578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272513,180361,169370,8328,64,245138,115151,17665,262281,119042,329730,257,213351,237762,63189]

theorem envBound32578 : H12AffineFastState.Bounded env32578 := by
  intro p hp
  have h : env32578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32548_32578 : H12AffineEnvironment.transform 21 272513 env32548 = env32578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env32548 == env32578) = true)

theorem identity32578 : scanCanonicalize (H12AffineFastState.compose env32578 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound32578 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32579 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,184536,272513,180361,169370,8328,64,158029,5392,17665,262281,1501,318685,257,169400,160797,63189]

theorem envBound32579 : H12AffineFastState.Bounded env32579 := by
  intro p hp
  have h : env32579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32578_32579 : H12AffineEnvironment.transform 15 54495 env32578 = env32579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env32578 == env32579) = true)

theorem identity32579 : scanCanonicalize (H12AffineFastState.compose env32579 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound32579 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env32580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8203,131072,262144,1025,29909,140300,272513,144477,155982,8328,64,158029,5392,17665,262281,1501,272393,257,156012,160797,513]

theorem envBound32580 : H12AffineFastState.Bounded env32580 := by
  intro p hp
  have h : env32580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32579_32580 : H12AffineEnvironment.transform 14 29908 env32579 = env32580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env32579 == env32580) = true)

theorem identity32580 : scanCanonicalize (H12AffineFastState.compose env32580 (packedSelected [7,12,14,15,16,27,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound32580 : packedSelected [7,12,14,15,16,27,38,41] rootPS < 2^1333 := by decide +kernel

def env32581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21760,479,131072,262144,1025,21761,132568,264533,136585,147610,348,64,149657,5392,17665,262281,1501,264669,257,147640,153033,513]

theorem envBound32581 : H12AffineFastState.Bounded env32581 := by
  intro p hp
  have h : env32581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32580_32581 : H12AffineEnvironment.transform 12 468 env32580 = env32581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env32580 == env32581) = true)

theorem identity32581 : scanCanonicalize (H12AffineFastState.compose env32581 (packedSelected [0,7,9,14,16,22] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound32581 : packedSelected [0,7,9,14,16,22] rootPS < 2^1333 := by decide +kernel

def env32582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21760,479,131072,2420,1025,21761,132568,33,136585,147610,348,64,149657,5392,17665,2557,1501,169,257,147640,153033,513]

theorem envBound32582 : H12AffineFastState.Bounded env32582 := by
  intro p hp
  have h : env32582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32581_32582 : H12AffineEnvironment.transform 17 2420 env32581 = env32582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env32581 == env32582) = true)

theorem identity32582 : scanCanonicalize (H12AffineFastState.compose env32582 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound32582 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env32583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,4113,1297,479,131072,2420,1025,1296,132568,33,136585,135307,348,64,137352,5392,5392,2557,1501,169,257,135337,132568,513]

theorem envBound32583 : H12AffineFastState.Bounded env32583 := by
  intro p hp
  have h : env32583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32582_32583 : H12AffineEnvironment.transform 13 4113 env32582 = env32583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env32582 == env32583) = true)

theorem identity32583 : scanCanonicalize (H12AffineFastState.compose env32583 (packedSelected [1,2,4,6,8,9,10,11,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 3464) := by decide +kernel

theorem selectedBound32583 : packedSelected [1,2,4,6,8,9,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env32584 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3464,468,3481,1297,479,131072,2420,1025,1296,132568,33,133121,134403,348,64,132352,2200,2200,2557,1501,169,257,134433,132568,513]

theorem envBound32584 : H12AffineFastState.Bounded env32584 := by
  intro p hp
  have h : env32584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32583_32584 : H12AffineEnvironment.transform 11 3464 env32583 = env32584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3464 env32583 == env32584) = true)

theorem identity32584 : scanCanonicalize (H12AffineFastState.compose env32584 (packedSelected [6,7,9,10,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 509) := by decide +kernel

theorem selectedBound32584 : packedSelected [6,7,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env32585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,509,1141,468,1124,1297,479,131072,137,1025,1296,132568,33,131580,132350,348,64,132352,357,357,0,1501,169,257,132316,132568,513]

theorem envBound32585 : H12AffineFastState.Bounded env32585 := by
  intro p hp
  have h : env32585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32584_32585 : H12AffineEnvironment.transform 10 509 env32584 = env32585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 509 env32584 == env32585) = true)

theorem identity32585 : scanCanonicalize (H12AffineFastState.compose env32585 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 356) := by decide +kernel

theorem selectedBound32585 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env32586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,509,1141,468,1124,1297,479,356,137,1025,1296,1212,33,152,1434,348,64,1124,357,357,0,1501,169,257,1464,1212,513]

theorem envBound32586 : H12AffineFastState.Bounded env32586 := by
  intro p hp
  have h : env32586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32585_32586 : H12AffineEnvironment.transform 16 356 env32585 = env32586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 356 env32585 == env32586) = true)

theorem identity32586 : scanCanonicalize (H12AffineFastState.compose env32586 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound32586 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32587 : List Nat := [2,4,8,16,32,64,9,256,512,1024,372,1141,349,1124,1297,342,356,0,1025,1296,1077,33,17,1299,348,64,1124,357,357,0,1364,32,257,1329,1077,513]

theorem envBound32587 : H12AffineFastState.Bounded env32587 := by
  intro p hp
  have h : env32587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32586_32587 : H12AffineEnvironment.transform 6 9 env32586 = env32587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32586 == env32587) = true)

theorem identity32587 : scanCanonicalize (H12AffineFastState.compose env32587 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound32587 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env32588 : List Nat := [2,4,8,16,32,64,9,36,512,1024,80,1141,121,1124,1077,114,64,0,1025,1076,1077,33,17,1079,120,64,1124,65,65,0,1136,32,37,1045,1077,513]

theorem envBound32588 : H12AffineFastState.Bounded env32588 := by
  intro p hp
  have h : env32588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32587_32588 : H12AffineEnvironment.transform 7 36 env32587 = env32588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env32587 == env32588) = true)

theorem identity32588 : scanCanonicalize (H12AffineFastState.compose env32588 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32588 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env32589 : List Nat := [2,4,8,16,32,16,9,36,512,1024,0,1061,41,1076,1077,34,16,0,1025,1076,1077,33,17,1079,40,16,1076,17,17,0,1056,32,37,1045,1077,513]

theorem envBound32589 : H12AffineFastState.Bounded env32589 := by
  intro p hp
  have h : env32589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32588_32589 : H12AffineEnvironment.transform 5 16 env32588 = env32589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32588 == env32589) = true)

def env32590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,4194304,180361,169371,8328,64,4691218,115151,17664,262281,119043,4268163,257,213351,237762,63188]

theorem envBound32590 : H12AffineFastState.Bounded env32590 := by
  intro p hp
  have h : env32590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32547_32590 : H12AffineEnvironment.transform 20 184537 env32547 = env32590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184537 env32547 == env32590) = true)

def env32591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272512,180361,169371,8328,64,245138,115151,17664,262281,119043,329731,257,213351,237762,63188]

theorem envBound32591 : H12AffineFastState.Bounded env32591 := by
  intro p hp
  have h : env32591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32590_32591 : H12AffineEnvironment.transform 21 272512 env32590 = env32591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env32590 == env32591) = true)

theorem identity32591 : scanCanonicalize (H12AffineFastState.compose env32591 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 123027) := by decide +kernel

theorem selectedBound32591 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,77898,272512,73754,95496,8328,64,23809,115151,17664,262281,119043,329731,257,41460,16465,63188]

theorem envBound32592 : H12AffineFastState.Bounded env32592 := by
  intro p hp
  have h : env32592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32591_32592 : H12AffineEnvironment.transform 16 123027 env32591 = env32592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 123027 env32591 == env32592) = true)

def env32593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,10400,1025,32769,77898,32,73754,95496,8328,64,23809,115151,17664,10281,119043,73891,257,41460,16465,63188]

theorem envBound32593 : H12AffineFastState.Bounded env32593 := by
  intro p hp
  have h : env32593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32592_32593 : H12AffineEnvironment.transform 17 10400 env32592 = env32593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env32592 == env32593) = true)

theorem identity32593 : scanCanonicalize (H12AffineFastState.compose env32593 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 41090) := by decide +kernel

theorem selectedBound32593 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env32594 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,41090,16401,10400,1025,32769,37064,32,32920,54666,8328,64,23809,24909,17664,10281,29057,32801,257,41460,16465,63188]

theorem envBound32594 : H12AffineFastState.Bounded env32594 := by
  intro p hp
  have h : env32594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32593_32594 : H12AffineEnvironment.transform 15 41090 env32593 = env32594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41090 env32593 == env32594) = true)

theorem identity32594 : scanCanonicalize (H12AffineFastState.compose env32594 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound32594 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env32595 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,41090,13389,10400,1025,32769,37064,32,32920,41430,8328,64,10589,5393,12636,10281,1501,32801,257,41460,13325,33416]

theorem envBound32595 : H12AffineFastState.Bounded env32595 := by
  intro p hp
  have h : env32595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32594_32595 : H12AffineEnvironment.transform 13 13404 env32594 = env32595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env32594 == env32595) = true)

theorem identity32595 : scanCanonicalize (H12AffineFastState.compose env32595 (packedSelected [16,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound32595 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env32596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,8661,343,13389,10400,1025,8660,12573,32,8525,3,8328,64,10589,5393,12636,10281,1501,8692,257,33,13325,9053]

theorem envBound32596 : H12AffineFastState.Bounded env32596 := by
  intro p hp
  have h : env32596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32595_32596 : H12AffineEnvironment.transform 14 8661 env32595 = env32596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env32595 == env32596) = true)

theorem identity32596 : scanCanonicalize (H12AffineFastState.compose env32596 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound32596 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32597 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,136,343,5392,2557,1025,137,4160,32,16,3,469,64,2048,5393,4097,2420,1501,169,257,33,5456,512]

theorem envBound32597 : H12AffineFastState.Bounded env32597 := by
  intro p hp
  have h : env32597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32596_32597 : H12AffineEnvironment.transform 12 349 env32596 = env32597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env32596 == env32597) = true)

theorem identity32597 : scanCanonicalize (H12AffineFastState.compose env32597 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound32597 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32598 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,349,5377,33,343,5392,2388,1025,32,4160,32,16,3,380,64,2048,5393,4097,2420,1396,0,257,33,5456,512]

theorem envBound32598 : H12AffineFastState.Bounded env32598 := by
  intro p hp
  have h : env32598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32597_32598 : H12AffineEnvironment.transform 6 41 env32597 = env32598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env32597 == env32598) = true)

theorem identity32598 : scanCanonicalize (H12AffineFastState.compose env32598 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound32598 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env32599 : List Nat := [2,4,8,16,32,64,41,37,512,1024,2048,4096,120,5156,33,114,5173,2161,1025,32,4160,32,16,3,89,64,2048,5172,4097,2129,1105,0,36,33,5237,512]

theorem envBound32599 : H12AffineFastState.Bounded env32599 := by
  intro p hp
  have h : env32599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32598_32599 : H12AffineEnvironment.transform 7 37 env32598 = env32599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env32598 == env32599) = true)

theorem identity32599 : scanCanonicalize (H12AffineFastState.compose env32599 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound32599 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env32600 : List Nat := [2,4,8,16,32,64,41,37,512,101,2048,4096,120,4161,33,114,4176,2161,100,32,4160,32,16,3,89,64,2048,4177,4097,2129,52,0,36,33,4112,512]

theorem envBound32600 : H12AffineFastState.Bounded env32600 := by
  intro p hp
  have h : env32600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32599_32600 : H12AffineEnvironment.transform 9 101 env32599 = env32600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env32599 == env32600) = true)

theorem identity32600 : scanCanonicalize (H12AffineFastState.compose env32600 (packedSelected [1,2,3,11] rootPS)) = affineNative (2^(11+1) ^^^ 2144) := by decide +kernel

theorem selectedBound32600 : packedSelected [1,2,3,11] rootPS < 2^1333 := by decide +kernel

def env32601 : List Nat := [2,4,8,16,32,64,41,37,512,101,2048,2144,120,2081,33,114,2096,2161,100,32,2080,32,16,3,89,64,2048,2097,2145,2129,52,0,36,33,2160,512]

theorem envBound32601 : H12AffineFastState.Bounded env32601 := by
  intro p hp
  have h : env32601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32600_32601 : H12AffineEnvironment.transform 11 2144 env32600 = env32601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2144 env32600 == env32601) = true)

theorem identity32601 : scanCanonicalize (H12AffineFastState.compose env32601 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound32601 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env32602 : List Nat := [2,4,8,16,32,48,41,37,512,21,2048,2064,8,2081,33,2,2096,2049,20,32,2080,32,16,3,41,48,2048,2097,2065,2081,52,0,36,33,2048,512]

theorem envBound32602 : H12AffineFastState.Bounded env32602 := by
  intro p hp
  have h : env32602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32601_32602 : H12AffineEnvironment.transform 5 48 env32601 = env32602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env32601 == env32602) = true)

theorem identity32602 : scanCanonicalize (H12AffineFastState.compose env32602 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32602 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32603 : List Nat := [2,4,8,16,0,16,9,5,512,21,2048,2064,8,2049,1,2,2064,2049,20,0,2048,0,16,3,9,16,2048,2065,2065,2049,20,0,4,1,2048,512]

theorem envBound32603 : H12AffineFastState.Bounded env32603 := by
  intro p hp
  have h : env32603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32602_32603 : H12AffineEnvironment.transform 4 0 env32602 = env32603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32602 == env32603) = true)

theorem identity32603 : scanCanonicalize (H12AffineFastState.compose env32603 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound32603 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32604 : List Nat := [2,4,8,16,0,16,9,5,15,21,2048,2064,8,2049,1,2,2064,2049,20,0,2048,0,16,3,9,16,2048,2065,2065,2049,20,0,4,1,2048,15]

theorem envBound32604 : H12AffineFastState.Bounded env32604 := by
  intro p hp
  have h : env32604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32603_32604 : H12AffineEnvironment.transform 8 15 env32603 = env32604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env32603 == env32604) = true)

def env32605 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,10401,1025,32769,77898,33,73754,95496,8328,64,23809,115151,17664,10280,119043,73890,257,41460,16465,63188]

theorem envBound32605 : H12AffineFastState.Bounded env32605 := by
  intro p hp
  have h : env32605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32592_32605 : H12AffineEnvironment.transform 17 10401 env32592 = env32605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env32592 == env32605) = true)

theorem identity32605 : scanCanonicalize (H12AffineFastState.compose env32605 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound32605 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env32606 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,478,57677,10401,1025,32769,12692,33,8644,29910,8328,64,23809,49169,17664,10280,53469,8572,257,41460,16465,63188]

theorem envBound32606 : H12AffineFastState.Bounded env32606 := by
  intro p hp
  have h : env32606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32605_32606 : H12AffineEnvironment.transform 15 478 env32605 = env32606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env32605 == env32606) = true)

theorem identity32606 : scanCanonicalize (H12AffineFastState.compose env32606 (packedSelected [0,9,16,17,18,19,20,22,23,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound32606 : packedSelected [0,9,16,17,18,19,20,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env32607 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,478,5528,10401,1025,29908,12692,33,8644,29910,8328,64,23809,13508,17664,10280,9224,8572,257,21793,16465,513]

theorem envBound32607 : H12AffineFastState.Bounded env32607 := by
  intro p hp
  have h : env32607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32606_32607 : H12AffineEnvironment.transform 14 29909 env32606 = env32607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env32606 == env32607) = true)

theorem identity32607 : scanCanonicalize (H12AffineFastState.compose env32607 (packedSelected [1,2,3,5,6,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound32607 : packedSelected [1,2,3,5,6,8,10,19] rootPS < 2^1333 := by decide +kernel

def env32608 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21761,478,5528,2421,1025,21760,4160,33,16,21762,348,64,23809,5392,17664,2556,1500,168,257,21793,16465,513]

theorem envBound32608 : H12AffineFastState.Bounded env32608 := by
  intro p hp
  have h : env32608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32607_32608 : H12AffineEnvironment.transform 12 468 env32607 = env32608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env32607 == env32608) = true)

theorem identity32608 : scanCanonicalize (H12AffineFastState.compose env32608 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound32608 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env32609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,137,478,5528,2421,1025,136,4160,33,16,138,348,64,2185,5392,4232,2556,1500,168,257,169,5593,513]

theorem envBound32609 : H12AffineFastState.Bounded env32609 := by
  intro p hp
  have h : env32609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32608_32609 : H12AffineEnvironment.transform 13 5512 env32608 = env32609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env32608 == env32609) = true)

theorem identity32609 : scanCanonicalize (H12AffineFastState.compose env32609 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound32609 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env32610 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,40,5236,137,34,5220,2185,1025,136,4160,33,16,138,160,64,2185,5356,4232,2048,1056,168,253,169,5157,513]

theorem envBound32610 : H12AffineFastState.Bounded env32610 := by
  intro p hp
  have h : env32610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32609_32610 : H12AffineEnvironment.transform 7 252 env32609 = env32610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env32609 == env32610) = true)

theorem identity32610 : scanCanonicalize (H12AffineFastState.compose env32610 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound32610 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32611 : List Nat := [2,4,8,16,32,64,88,36,512,1024,2048,4096,40,5236,81,34,5220,2129,1025,80,4160,33,16,82,120,64,2129,5172,4176,2048,1056,112,37,113,5157,513]

theorem envBound32611 : H12AffineFastState.Bounded env32611 := by
  intro p hp
  have h : env32611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32610_32611 : H12AffineEnvironment.transform 6 88 env32610 = env32611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env32610 == env32611) = true)

theorem identity32611 : scanCanonicalize (H12AffineFastState.compose env32611 (packedSelected [0,4,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32611 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env32612 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5157,0,34,5173,2048,1025,1,4113,33,16,3,41,17,2048,5172,4097,2048,1056,33,37,32,5157,513]

theorem envBound32612 : H12AffineFastState.Bounded env32612 := by
  intro p hp
  have h : env32612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32611_32612 : H12AffineEnvironment.transform 5 17 env32611 = env32612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32611 == env32612) = true)

def env32613 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,40,1045,0,34,1029,2048,1025,1,33,33,16,3,41,17,2048,1028,49,2048,1056,33,37,32,1045,513]

theorem envBound32613 : H12AffineFastState.Bounded env32613 := by
  intro p hp
  have h : env32613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32612_32613 : H12AffineEnvironment.transform 11 48 env32612 = env32613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env32612 == env32613) = true)

theorem identity32613 : scanCanonicalize (H12AffineFastState.compose env32613 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound32613 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32614 : List Nat := [2,4,8,16,32,17,9,36,512,1024,528,48,40,1045,0,34,1029,528,1025,1,33,33,16,3,41,17,528,1028,49,528,1056,33,37,32,1045,513]

theorem envBound32614 : H12AffineFastState.Bounded env32614 := by
  intro p hp
  have h : env32614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32613_32614 : H12AffineEnvironment.transform 10 528 env32613 = env32614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env32613 == env32614) = true)

def env32615 : List Nat := [2,4,8,16,32,17,9,36,512,52,528,48,40,33,0,34,49,528,53,1,33,33,16,3,41,17,528,48,49,528,20,33,37,32,33,513]

theorem envBound32615 : H12AffineFastState.Bounded env32615 := by
  intro p hp
  have h : env32615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32614_32615 : H12AffineEnvironment.transform 9 52 env32614 = env32615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env32614 == env32615) = true)

def env32616 : List Nat := [2,4,8,16,32,17,9,36,512,53,528,48,40,32,0,34,48,528,52,1,33,33,16,3,41,17,528,49,49,528,21,33,37,32,32,513]

theorem envBound32616 : H12AffineFastState.Bounded env32616 := by
  intro p hp
  have h : env32616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32614_32616 : H12AffineEnvironment.transform 9 53 env32614 = env32616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env32614 == env32616) = true)

theorem identity32616 : scanCanonicalize (H12AffineFastState.compose env32616 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound32616 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32617 : List Nat := [2,4,8,16,32,17,9,36,43,53,59,48,40,32,0,34,48,59,52,1,33,33,16,3,41,17,59,49,49,59,21,33,37,32,32,42]

theorem envBound32617 : H12AffineFastState.Bounded env32617 := by
  intro p hp
  have h : env32617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32616_32617 : H12AffineEnvironment.transform 8 43 env32616 = env32617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env32616 == env32617) = true)

def leafEnv32617 : List Nat := [2,4,8,16,32,17,9,36,43,53,59,48,40,32,0,34,48,59,52,1,33,33,16,3,20,41,1,17,59,49,49,59,21,33,37,32,5,35,32,42,1,33,0]

def active32617 : List Nat := [0,1,2,3,4]

def tree32617 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood32617 : H12WitnessSearch.Good tree32617 := H12GlobalWitnessIndex.good

theorem leafIdentity32617 : H12AffineFastState.composeSystem env32617 rootObs = leafEnv32617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env32617 rootObs == leafEnv32617) = true)

theorem terminalChecked32617 : H12PackedTerminal.terminalCheckFast leafEnv32617 active32617 tree32617 = true := by decide +kernel

def env32618 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,40,1044,0,34,1028,2048,1025,1,32,33,16,3,41,17,2048,1029,48,2048,1056,33,37,32,1044,513]

theorem envBound32618 : H12AffineFastState.Bounded env32618 := by
  intro p hp
  have h : env32618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32612_32618 : H12AffineEnvironment.transform 11 49 env32612 = env32618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env32612 == env32618) = true)

theorem identity32618 : scanCanonicalize (H12AffineFastState.compose env32618 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1573) := by decide +kernel

theorem selectedBound32618 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32619 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1573,49,40,1044,0,34,1028,1573,1025,1,32,33,16,3,41,17,1573,1029,48,1573,1056,33,37,32,1044,513]

theorem envBound32619 : H12AffineFastState.Bounded env32619 := by
  intro p hp
  have h : env32619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32618_32619 : H12AffineEnvironment.transform 10 1573 env32618 = env32619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1573 env32618 == env32619) = true)

def env32620 : List Nat := [2,4,8,16,32,17,9,36,512,52,529,49,40,32,0,34,48,529,53,1,32,33,16,3,41,17,529,49,48,529,20,33,37,32,32,513]

theorem envBound32620 : H12AffineFastState.Bounded env32620 := by
  intro p hp
  have h : env32620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32619_32620 : H12AffineEnvironment.transform 9 52 env32619 = env32620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env32619 == env32620) = true)

def env32621 : List Nat := [2,4,8,16,32,17,9,36,512,53,528,49,40,33,0,34,49,528,52,1,32,33,16,3,41,17,528,48,48,528,21,33,37,32,33,513]

theorem envBound32621 : H12AffineFastState.Bounded env32621 := by
  intro p hp
  have h : env32621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32619_32621 : H12AffineEnvironment.transform 9 53 env32619 = env32621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env32619 == env32621) = true)

theorem identity32621 : scanCanonicalize (H12AffineFastState.compose env32621 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound32621 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32622 : List Nat := [2,4,8,16,32,17,9,36,42,53,58,49,40,33,0,34,49,58,52,1,32,33,16,3,41,17,58,48,48,58,21,33,37,32,33,43]

theorem envBound32622 : H12AffineFastState.Bounded env32622 := by
  intro p hp
  have h : env32622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32621_32622 : H12AffineEnvironment.transform 8 42 env32621 = env32622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env32621 == env32622) = true)

def leafEnv32622 : List Nat := [2,4,8,16,32,17,9,36,42,53,58,49,40,33,0,34,49,58,52,1,32,33,16,3,20,41,1,17,58,48,48,58,21,33,37,32,5,35,33,43,1,32,0]

def active32622 : List Nat := [0,1,2,3,4]

def tree32622 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood32622 : H12WitnessSearch.Good tree32622 := H12GlobalWitnessIndex.good

theorem leafIdentity32622 : H12AffineFastState.composeSystem env32622 rootObs = leafEnv32622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env32622 rootObs == leafEnv32622) = true)

theorem terminalChecked32622 : H12PackedTerminal.terminalCheckFast leafEnv32622 active32622 tree32622 = true := by decide +kernel

def env32623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272513,180361,169371,8328,64,245139,115151,17664,262281,119043,329730,257,213351,237762,63188]

theorem envBound32623 : H12AffineFastState.Bounded env32623 := by
  intro p hp
  have h : env32623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32590_32623 : H12AffineEnvironment.transform 21 272513 env32590 = env32623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env32590 == env32623) = true)

theorem identity32623 : scanCanonicalize (H12AffineFastState.compose env32623 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound32623 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,184537,272513,180361,169371,8328,64,171416,57796,17664,262281,61704,272393,257,156012,164041,63188]

theorem envBound32624 : H12AffineFastState.Bounded env32624 := by
  intro p hp
  have h : env32624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32623_32624 : H12AffineEnvironment.transform 15 8203 env32623 = env32624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env32623 == env32624) = true)

def env32625 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,184457,272513,180361,169371,8328,16,171416,57748,17664,262281,61704,272393,257,155964,163993,63108]

theorem envBound32625 : H12AffineFastState.Bounded env32625 := by
  intro p hp
  have h : env32625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32624_32625 : H12AffineEnvironment.transform 5 16 env32624 = env32625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32624 == env32625) = true)

theorem identity32625 : scanCanonicalize (H12AffineFastState.compose env32625 (packedSelected [3,15,17,19,24,31,38] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound32625 : packedSelected [3,15,17,19,24,31,38] rootPS < 2^1333 := by decide +kernel

def env32626 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29708,8203,131072,262144,1025,29709,140421,272513,144517,156055,8328,16,158100,5528,17664,262281,1284,272393,257,155964,160917,648]

theorem envBound32626 : H12AffineFastState.Bounded env32626 := by
  intro p hp
  have h : env32626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32625_32626 : H12AffineEnvironment.transform 14 29708 env32625 = env32626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env32625 == env32626) = true)

theorem identity32626 : scanCanonicalize (H12AffineFastState.compose env32626 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound32626 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env32627 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29708,8203,131072,10280,1025,29709,140421,169,144517,156055,8328,16,158100,5528,17664,10401,1284,33,257,155964,160917,648]

theorem envBound32627 : H12AffineFastState.Bounded env32627 := by
  intro p hp
  have h : env32627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32626_32627 : H12AffineEnvironment.transform 17 10280 env32626 = env32627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env32626 == env32627) = true)

theorem identity32627 : scanCanonicalize (H12AffineFastState.compose env32627 (packedSelected [1,8,10,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound32627 : packedSelected [1,8,10,15,17] rootPS < 2^1333 := by decide +kernel

def env32628 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,8581,8203,131072,10280,1025,8580,140421,169,144517,144414,8328,16,146461,5528,4233,10401,1284,33,257,144565,139548,648]

theorem envBound32628 : H12AffineFastState.Bounded env32628 := by
  intro p hp
  have h : env32628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32627_32628 : H12AffineEnvironment.transform 13 5513 env32627 = env32628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env32627 == env32628) = true)

theorem identity32628 : scanCanonicalize (H12AffineFastState.compose env32628 (packedSelected [0,1,2,3,5,6,7,8,15,16] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound32628 : packedSelected [0,1,2,3,5,6,7,8,15,16] rootPS < 2^1333 := by decide +kernel

def env32629 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,8581,8203,5528,10280,1025,8580,12573,169,8477,8582,8328,16,10629,5528,4233,10401,1284,33,257,8493,13444,648]

theorem envBound32629 : H12AffineFastState.Bounded env32629 := by
  intro p hp
  have h : env32629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32628_32629 : H12AffineEnvironment.transform 16 5528 env32628 = env32629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env32628 == env32629) = true)

theorem identity32629 : scanCanonicalize (H12AffineFastState.compose env32629 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound32629 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32630 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5513,0,398,5528,2477,1025,1,4248,169,152,3,269,16,2048,5528,4233,2340,1284,33,257,168,5377,648]

theorem envBound32630 : H12AffineFastState.Bounded env32630 := by
  intro p hp
  have h : env32630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32629_32630 : H12AffineEnvironment.transform 12 389 env32629 = env32630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env32629 == env32630) = true)

theorem identity32630 : scanCanonicalize (H12AffineFastState.compose env32630 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound32630 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env32631 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,309,389,1212,0,398,1197,2477,1025,1,429,169,152,3,269,16,2048,1197,444,2340,1284,33,257,168,1076,648]

theorem envBound32631 : H12AffineFastState.Bounded env32631 := by
  intro p hp
  have h : env32631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32630_32631 : H12AffineEnvironment.transform 11 309 env32630 = env32631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env32630 == env32631) = true)

theorem identity32631 : scanCanonicalize (H12AffineFastState.compose env32631 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound32631 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32632 : List Nat := [2,4,8,16,32,16,128,256,512,188,2048,309,389,0,0,398,17,2477,189,1,429,169,152,3,269,16,2048,17,444,2340,440,33,257,168,136,648]

theorem envBound32632 : H12AffineFastState.Bounded env32632 := by
  intro p hp
  have h : env32632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32631_32632 : H12AffineEnvironment.transform 9 188 env32631 = env32632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env32631 == env32632) = true)

theorem identity32632 : scanCanonicalize (H12AffineFastState.compose env32632 (packedSelected [1,2,8] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound32632 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env32633 : List Nat := [2,4,8,16,32,16,128,256,512,188,136,309,389,0,0,398,17,293,189,1,429,169,152,3,269,16,136,17,444,428,440,33,257,168,136,648]

theorem envBound32633 : H12AffineFastState.Bounded env32633 := by
  intro p hp
  have h : env32633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32632_32633 : H12AffineEnvironment.transform 10 136 env32632 = env32633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env32632 == env32633) = true)

theorem identity32633 : scanCanonicalize (H12AffineFastState.compose env32633 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound32633 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32634 : List Nat := [2,4,8,16,32,16,128,36,512,188,136,17,161,0,0,170,17,1,189,1,137,169,152,3,41,16,136,17,152,136,156,33,37,168,136,648]

theorem envBound32634 : H12AffineFastState.Bounded env32634 := by
  intro p hp
  have h : env32634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32633_32634 : H12AffineEnvironment.transform 7 36 env32633 = env32634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env32633 == env32634) = true)

theorem identity32634 : scanCanonicalize (H12AffineFastState.compose env32634 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound32634 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env32635 : List Nat := [2,4,8,16,32,16,9,36,512,53,1,17,40,0,0,35,17,1,52,1,0,32,17,3,41,16,1,17,17,1,21,33,37,33,1,513]

theorem envBound32635 : H12AffineFastState.Bounded env32635 := by
  intro p hp
  have h : env32635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32634_32635 : H12AffineEnvironment.transform 6 9 env32634 = env32635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32634 == env32635) = true)

theorem identity32635 : scanCanonicalize (H12AffineFastState.compose env32635 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound32635 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32636 : List Nat := [2,4,8,16,32,16,9,36,49,53,1,17,40,0,0,35,17,1,52,1,0,32,17,3,41,16,1,17,17,1,21,33,37,33,1,48]

theorem envBound32636 : H12AffineFastState.Bounded env32636 := by
  intro p hp
  have h : env32636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32635_32636 : H12AffineEnvironment.transform 8 49 env32635 = env32636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env32635 == env32636) = true)

theorem identity32636 : scanCanonicalize (H12AffineFastState.compose env32636 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound32636 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32637 : List Nat := [2,4,8,0,32,0,9,36,33,37,1,1,40,0,0,35,1,1,36,1,0,32,1,3,41,0,1,1,1,1,5,33,37,33,1,32]

theorem envBound32637 : H12AffineFastState.Bounded env32637 := by
  intro p hp
  have h : env32637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32636_32637 : H12AffineEnvironment.transform 3 0 env32636 = env32637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env32636 == env32637) = true)

def env32638 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,184456,272513,180361,169371,8328,17,171416,57749,17664,262281,61704,272393,257,155965,163992,63109]

theorem envBound32638 : H12AffineFastState.Bounded env32638 := by
  intro p hp
  have h : env32638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32624_32638 : H12AffineEnvironment.transform 5 17 env32624 = env32638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32624 == env32638) = true)

theorem identity32638 : scanCanonicalize (H12AffineFastState.compose env32638 (packedSelected [3,15,17,19,24,31,38] rootPS)) = affineNative (2^(17+1) ^^^ 56357) := by decide +kernel

theorem selectedBound32638 : packedSelected [3,15,17,19,24,31,38] rootPS < 2^1333 := by decide +kernel

def env32639 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,56357,1025,32769,184456,62628,180361,169371,8328,17,171416,57749,17664,56492,61704,62508,257,155965,163992,63109]

theorem envBound32639 : H12AffineFastState.Bounded env32639 := by
  intro p hp
  have h : env32639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32638_32639 : H12AffineEnvironment.transform 17 56357 env32638 = env32639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56357 env32638 == env32639) = true)

theorem identity32639 : scanCanonicalize (H12AffineFastState.compose env32639 (packedSelected [1,3,11,12,15,17,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 57748) := by decide +kernel

theorem selectedBound32639 : packedSelected [1,3,11,12,15,17,23,24,28] rootPS < 2^1333 := by decide +kernel

def env32640 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8203,57748,56357,1025,32769,12572,62628,8477,29711,8328,17,31756,57749,17664,56492,61704,62508,257,32937,24844,63109]

theorem envBound32640 : H12AffineFastState.Bounded env32640 := by
  intro p hp
  have h : env32640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32639_32640 : H12AffineEnvironment.transform 16 57748 env32639 = env32640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57748 env32639 == env32640) = true)

theorem identity32640 : scanCanonicalize (H12AffineFastState.compose env32640 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound32640 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env32641 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29709,8203,5529,10280,1025,29708,12572,169,8477,29711,8328,17,31756,5528,17664,10401,1285,33,257,29860,24844,648]

theorem envBound32641 : H12AffineFastState.Bounded env32641 := by
  intro p hp
  have h : env32641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32640_32641 : H12AffineEnvironment.transform 14 29709 env32640 = env32641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env32640 == env32641) = true)

theorem identity32641 : scanCanonicalize (H12AffineFastState.compose env32641 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound32641 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env32642 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,8580,8203,5529,10280,1025,8581,12572,169,8477,8582,8328,17,10629,5528,4233,10401,1285,33,257,8493,13445,648]

theorem envBound32642 : H12AffineFastState.Bounded env32642 := by
  intro p hp
  have h : env32642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32641_32642 : H12AffineEnvironment.transform 13 5513 env32641 = env32642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env32641 == env32642) = true)

theorem identity32642 : scanCanonicalize (H12AffineFastState.compose env32642 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound32642 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32643 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8461,8203,5392,10280,1025,8460,12572,32,8477,8463,8193,17,10508,5393,4096,10280,1285,33,257,8493,13324,513]

theorem envBound32643 : H12AffineFastState.Bounded env32643 := by
  intro p hp
  have h : env32643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32642_32643 : H12AffineEnvironment.transform 6 9 env32642 = env32643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32642 == env32643) = true)

theorem identity32643 : scanCanonicalize (H12AffineFastState.compose env32643 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound32643 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32644 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,1,263,5392,2340,1025,0,4112,32,17,3,269,17,2048,5393,4096,2340,1285,33,257,33,5376,513]

theorem envBound32644 : H12AffineFastState.Bounded env32644 := by
  intro p hp
  have h : env32644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32643_32644 : H12AffineEnvironment.transform 12 268 env32643 = env32644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env32643 == env32644) = true)

theorem identity32644 : scanCanonicalize (H12AffineFastState.compose env32644 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound32644 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32645 : List Nat := [2,4,8,1,32,0,9,256,512,1024,2048,4096,268,5376,1,263,5377,2340,1025,0,4097,32,0,3,269,0,2048,5376,4096,2340,1285,33,257,33,5376,513]

theorem envBound32645 : H12AffineFastState.Bounded env32645 := by
  intro p hp
  have h : env32645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32644_32645 : H12AffineEnvironment.transform 3 1 env32644 = env32645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env32644 == env32645) = true)

theorem identity32645 : scanCanonicalize (H12AffineFastState.compose env32645 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1070) := by decide +kernel

theorem selectedBound32645 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32646 : List Nat := [2,4,8,1,32,0,9,256,512,1024,1070,4096,268,5376,1,263,5377,1290,1025,0,4097,32,0,3,269,0,1070,5376,4096,1290,1285,33,257,33,5376,513]

theorem envBound32646 : H12AffineFastState.Bounded env32646 := by
  intro p hp
  have h : env32646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32645_32646 : H12AffineEnvironment.transform 10 1070 env32645 = env32646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1070 env32645 == env32646) = true)

theorem identity32646 : scanCanonicalize (H12AffineFastState.compose env32646 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound32646 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env32647 : List Nat := [2,4,8,1,32,0,9,256,512,1024,1070,33,268,1313,1,263,1312,1290,1025,0,32,32,0,3,269,0,1070,1313,33,1290,1285,33,257,33,1313,513]

theorem envBound32647 : H12AffineFastState.Bounded env32647 := by
  intro p hp
  have h : env32647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32646_32647 : H12AffineEnvironment.transform 11 33 env32646 = env32647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env32646 == env32647) = true)

theorem identity32647 : scanCanonicalize (H12AffineFastState.compose env32647 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound32647 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env32648 : List Nat := [2,4,8,1,32,0,9,256,512,5,43,33,268,292,1,263,293,271,4,0,32,32,0,3,269,0,43,292,33,271,256,33,257,33,292,513]

theorem envBound32648 : H12AffineFastState.Bounded env32648 := by
  intro p hp
  have h : env32648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32647_32648 : H12AffineEnvironment.transform 9 5 env32647 = env32648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env32647 == env32648) = true)

theorem identity32648 : scanCanonicalize (H12AffineFastState.compose env32648 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound32648 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32649 : List Nat := [2,4,8,1,32,0,9,5,512,5,43,33,9,33,1,2,32,10,4,0,32,32,0,3,8,0,43,33,33,10,5,33,4,33,33,513]

theorem envBound32649 : H12AffineFastState.Bounded env32649 := by
  intro p hp
  have h : env32649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32648_32649 : H12AffineEnvironment.transform 7 5 env32648 = env32649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env32648 == env32649) = true)

theorem identity32649 : scanCanonicalize (H12AffineFastState.compose env32649 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 35) := by decide +kernel

theorem selectedBound32649 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32650 : List Nat := [2,4,8,1,32,0,9,5,35,5,43,33,9,33,1,2,32,10,4,0,32,32,0,3,8,0,43,33,33,10,5,33,4,33,33,34]

theorem envBound32650 : H12AffineFastState.Bounded env32650 := by
  intro p hp
  have h : env32650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32649_32650 : H12AffineEnvironment.transform 8 35 env32649 = env32650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 35 env32649 == env32650) = true)

theorem identity32650 : scanCanonicalize (H12AffineFastState.compose env32650 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound32650 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env32651 : List Nat := [2,4,8,1,11,0,9,5,8,5,0,10,9,10,1,2,11,10,4,0,11,11,0,3,8,0,0,10,10,10,5,10,4,10,10,9]

theorem envBound32651 : H12AffineFastState.Bounded env32651 := by
  intro p hp
  have h : env32651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32650_32651 : H12AffineEnvironment.transform 4 11 env32650 = env32651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env32650 == env32651) = true)

theorem identity32651 : scanCanonicalize (H12AffineFastState.compose env32651 (packedSelected [0,9] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound32651 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env32652 : List Nat := [2,4,3,1,0,0,2,5,3,5,0,1,2,1,1,2,0,1,4,0,0,0,0,3,3,0,0,1,1,1,5,1,4,1,1,2]

theorem envBound32652 : H12AffineFastState.Bounded env32652 := by
  intro p hp
  have h : env32652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32651_32652 : H12AffineEnvironment.transform 2 3 env32651 = env32652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env32651 == env32652) = true)

theorem identity32652 : scanCanonicalize (H12AffineFastState.compose env32652 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound32652 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32653 : List Nat := [2,0,3,1,0,0,2,1,3,1,0,1,2,1,1,2,0,1,0,0,0,0,0,3,3,0,0,1,1,1,1,1,0,1,1,2]

theorem envBound32653 : H12AffineFastState.Bounded env32653 := by
  intro p hp
  have h : env32653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32652_32653 : H12AffineEnvironment.transform 1 0 env32652 = env32653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env32652 == env32653) = true)

def env32654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507601,155254784,25265168,145662400,525568,140903596,27337993,25733063]

theorem envBound32654 : H12AffineFastState.Bounded env32654 := by
  intro p hp
  have h : env32654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31849_32654 : H12AffineEnvironment.transform 25 65 env31849 = env32654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env31849 == env32654) = true)

def env32655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507601,9356288,25265168,23160256,525568,27902124,27337993,25733063]

theorem envBound32655 : H12AffineFastState.Bounded env32655 := by
  intro p hp
  have h : env32655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32654_32655 : H12AffineEnvironment.transform 26 30393344 env32654 = env32655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env32654 == env32655) = true)

def env32656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830976,25265168,23160256,256,27378860,27337993,25207751]

theorem envBound32656 : H12AffineFastState.Bounded env32656 := by
  intro p hp
  have h : env32656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32655_32656 : H12AffineEnvironment.transform 18 1024 env32655 = env32656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env32655 == env32656) = true)

theorem identity32656 : scanCanonicalize (H12AffineFastState.compose env32656 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 510122) := by decide +kernel

theorem selectedBound32656 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env32657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,510122,16777216,8328,65,20973738,18973836,2596347,67754,17190074,23160256,256,19270662,19328419,17263469]

theorem envBound32657 : H12AffineFastState.Bounded env32657 := by
  intro p hp
  have h : env32657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32656_32657 : H12AffineEnvironment.transform 22 510122 env32656 = env32657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 510122 env32656 == env32657) = true)

def env32658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180272,510122,16777216,8328,65,16959642,18973836,2596347,67754,17190074,19113456,256,19270662,19328419,17263469]

theorem envBound32658 : H12AffineFastState.Bounded env32658 := by
  intro p hp
  have h : env32658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32657_32658 : H12AffineEnvironment.transform 21 180272 env32657 = env32658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180272 env32657 == env32658) = true)

def env32659 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180272,510122,499128,8328,65,349474,2496820,2596347,67754,119042,2373704,256,2199998,2191387,63189]

theorem envBound32659 : H12AffineFastState.Bounded env32659 := by
  intro p hp
  have h : env32659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32658_32659 : H12AffineEnvironment.transform 23 499128 env32658 = env32659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 499128 env32658 == env32659) = true)

def env32660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180272,510122,499128,8328,65,349474,395636,495035,67754,119042,272392,256,98814,90203,63189]

theorem envBound32660 : H12AffineFastState.Bounded env32660 := by
  intro p hp
  have h : env32660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32659_32660 : H12AffineEnvironment.transform 20 4160 env32659 = env32660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env32659 == env32660) = true)

theorem identity32660 : scanCanonicalize (H12AffineFastState.compose env32660 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247994) := by decide +kernel

theorem selectedBound32660 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32661 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4160,180272,16,21762,8328,65,171416,115150,17665,67754,119042,254130,256,98814,90203,63189]

theorem envBound32661 : H12AffineFastState.Bounded env32661 := by
  intro p hp
  have h : env32661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32660_32661 : H12AffineEnvironment.transform 17 247994 env32660 = env32661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247994 env32660 == env32661) = true)

def env32662 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,180272,16,21762,8192,65,171280,115014,17665,67618,119042,254010,256,98678,90203,63069]

theorem envBound32662 : H12AffineFastState.Bounded env32662 := by
  intro p hp
  have h : env32662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32661_32662 : H12AffineEnvironment.transform 6 8 env32661 = env32662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32661 == env32662) = true)

theorem identity32662 : scanCanonicalize (H12AffineFastState.compose env32662 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound32662 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32663 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,35188,1024,32769,4160,98678,16,21762,8192,65,121942,115014,17665,67618,119042,41340,256,98678,90203,63069]

theorem envBound32663 : H12AffineFastState.Bounded env32663 := by
  intro p hp
  have h : env32663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32662_32663 : H12AffineEnvironment.transform 16 82246 env32662 = env32663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env32662 == env32663) = true)

theorem identity32663 : scanCanonicalize (H12AffineFastState.compose env32663 (packedSelected [0,1,4,8,12,14,15,16,18,19,22,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound32663 : packedSelected [0,1,4,8,12,14,15,16,18,19,22,23,27] rootPS < 2^1333 := by decide +kernel

def env32664 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,32768,65536,78911,35188,1024,32769,4160,98678,16,8315,8192,65,108847,111679,12408,67618,107643,41340,256,98678,70946,33572]

theorem envBound32664 : H12AffineFastState.Bounded env32664 := by
  intro p hp
  have h : env32664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32663_32664 : H12AffineEnvironment.transform 13 13689 env32663 = env32664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env32663 == env32664) = true)

theorem identity32664 : scanCanonicalize (H12AffineFastState.compose env32664 (packedSelected [0,2,4,5,6,7,9,11,12,14,15,16,18,19,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound32664 : packedSelected [0,2,4,5,6,7,9,11,12,14,15,16,18,19,20,24] rootPS < 2^1333 := by decide +kernel

def env32665 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,32768,33110,46441,35188,1024,32769,4160,32,16,8315,8192,65,10361,13673,12408,35188,9517,41340,256,32,38004,33572]

theorem envBound32665 : H12AffineFastState.Bounded env32665 := by
  intro p hp
  have h : env32665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32664_32665 : H12AffineEnvironment.transform 15 33110 env32664 = env32665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env32664 == env32665) = true)

theorem identity32665 : scanCanonicalize (H12AffineFastState.compose env32665 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound32665 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env32666 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5457,32768,33110,38209,35188,1024,32769,4160,32,16,83,40,65,2129,5441,4176,35188,1285,33108,256,32,38004,33572]

theorem envBound32666 : H12AffineFastState.Bounded env32666 := by
  intro p hp
  have h : env32666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32665_32666 : H12AffineEnvironment.transform 12 40 env32665 = env32666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env32665 == env32666) = true)

theorem identity32666 : scanCanonicalize (H12AffineFastState.compose env32666 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32666 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env32667 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,40,5377,32768,33030,38161,35108,1024,32769,4112,32,16,3,40,17,2049,5393,4096,35108,1285,33028,256,32,37924,33572]

theorem envBound32667 : H12AffineFastState.Bounded env32667 := by
  intro p hp
  have h : env32667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32666_32667 : H12AffineEnvironment.transform 5 16 env32666 = env32667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32666 == env32667) = true)

theorem identity32667 : scanCanonicalize (H12AffineFastState.compose env32667 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound32667 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env32668 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,40,5377,292,34,5173,2048,1024,293,4112,32,16,3,40,17,2049,5393,4096,2048,1285,32,256,32,5376,512]

theorem envBound32668 : H12AffineFastState.Bounded env32668 := by
  intro p hp
  have h : env32668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32667_32668 : H12AffineEnvironment.transform 14 292 env32667 = env32668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env32667 == env32668) = true)

theorem identity32668 : scanCanonicalize (H12AffineFastState.compose env32668 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound32668 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32669 : List Nat := [2,4,8,16,1,16,8,256,512,1024,2048,4096,9,5377,261,3,5140,2048,1024,260,4112,1,16,3,9,17,2049,5393,4096,2048,1285,1,256,1,5376,512]

theorem envBound32669 : H12AffineFastState.Bounded env32669 := by
  intro p hp
  have h : env32669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32668_32669 : H12AffineEnvironment.transform 4 1 env32668 = env32669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env32668 == env32669) = true)

theorem identity32669 : scanCanonicalize (H12AffineFastState.compose env32669 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound32669 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env32670 : List Nat := [2,4,8,16,1,16,8,256,512,1024,260,4096,9,5377,261,3,5140,260,1024,260,4112,1,16,3,9,17,261,5393,4096,260,1285,1,256,1,5376,512]

theorem envBound32670 : H12AffineFastState.Bounded env32670 := by
  intro p hp
  have h : env32670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32669_32670 : H12AffineEnvironment.transform 10 260 env32669 = env32670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env32669 == env32670) = true)

theorem identity32670 : scanCanonicalize (H12AffineFastState.compose env32670 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound32670 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env32671 : List Nat := [2,4,8,16,1,16,8,4,512,1024,0,4096,9,5125,1,3,5140,0,1024,0,4112,1,16,3,9,17,1,5141,4096,0,1025,1,4,1,5124,512]

theorem envBound32671 : H12AffineFastState.Bounded env32671 := by
  intro p hp
  have h : env32671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32670_32671 : H12AffineEnvironment.transform 7 4 env32670 = env32671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env32670 == env32671) = true)

theorem identity32671 : scanCanonicalize (H12AffineFastState.compose env32671 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1551) := by decide +kernel

theorem selectedBound32671 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32672 : List Nat := [2,4,8,16,1,16,8,4,512,1024,0,1551,9,522,1,3,539,0,1024,0,1567,1,16,3,9,17,1,538,1551,0,1025,1,4,1,523,512]

theorem envBound32672 : H12AffineFastState.Bounded env32672 := by
  intro p hp
  have h : env32672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32671_32672 : H12AffineEnvironment.transform 11 1551 env32671 = env32672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1551 env32671 == env32672) = true)

theorem identity32672 : scanCanonicalize (H12AffineFastState.compose env32672 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound32672 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env32673 : List Nat := [2,4,8,3,1,3,8,4,512,1024,0,1551,9,522,1,3,520,0,1024,0,1548,1,3,3,9,2,1,521,1551,0,1025,1,4,1,523,512]

theorem envBound32673 : H12AffineFastState.Bounded env32673 := by
  intro p hp
  have h : env32673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32672_32673 : H12AffineEnvironment.transform 3 3 env32672 = env32673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env32672 == env32673) = true)

def env32674 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,180272,16,21762,8193,65,171281,115015,17665,67619,119042,254011,256,98679,90203,63068]

theorem envBound32674 : H12AffineFastState.Bounded env32674 := by
  intro p hp
  have h : env32674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32661_32674 : H12AffineEnvironment.transform 6 9 env32661 = env32674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32661 == env32674) = true)

theorem identity32674 : scanCanonicalize (H12AffineFastState.compose env32674 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound32674 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32675 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10280,1024,32769,4160,73771,16,21762,8193,65,97546,115015,17665,67619,119042,32,256,98679,90203,63068]

theorem envBound32675 : H12AffineFastState.Bounded env32675 := by
  intro p hp
  have h : env32675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32674_32675 : H12AffineEnvironment.transform 16 122907 env32674 = env32675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env32674 == env32675) = true)

theorem identity32675 : scanCanonicalize (H12AffineFastState.compose env32675 (packedSelected [2,4,5,6,7,8,10,11,12,14,15,18,19,22,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound32675 : packedSelected [2,4,5,6,7,8,10,11,12,14,15,18,19,22,24,27,28] rootPS < 2^1333 := by decide +kernel

def env32676 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40970,16401,10280,1024,32769,4160,32801,16,21762,8193,65,56576,24909,17665,43049,28936,32,256,8573,49233,63068]

theorem envBound32676 : H12AffineFastState.Bounded env32676 := by
  intro p hp
  have h : env32676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32675_32676 : H12AffineEnvironment.transform 15 40970 env32675 = env32676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env32675 == env32676) = true)

theorem identity32676 : scanCanonicalize (H12AffineFastState.compose env32676 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound32676 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32677 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,8202,16401,10280,1024,1,4160,33,16,21762,8193,65,23808,24909,17665,10281,28936,32,256,8573,16465,30300]

theorem envBound32677 : H12AffineFastState.Bounded env32677 := by
  intro p hp
  have h : env32677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32676_32677 : H12AffineEnvironment.transform 14 0 env32676 = env32677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env32676 == env32677) = true)

theorem identity32677 : scanCanonicalize (H12AffineFastState.compose env32677 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound32677 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env32678 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,0,8202,13340,10280,1024,1,4160,33,16,8463,8193,65,10509,5440,12556,10281,1285,32,256,8573,13404,593]

theorem envBound32678 : H12AffineFastState.Bounded env32678 := by
  intro p hp
  have h : env32678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32677_32678 : H12AffineEnvironment.transform 13 13325 env32677 = env32678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env32677 == env32678) = true)

theorem identity32678 : scanCanonicalize (H12AffineFastState.compose env32678 (packedSelected [0,1,6,7,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 6429) := by decide +kernel

theorem selectedBound32678 : packedSelected [0,1,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env32679 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,6429,3344,0,6423,3329,4405,1024,1,4160,33,16,6162,6428,65,4112,5440,2065,4404,1285,32,256,6240,3393,593]

theorem envBound32679 : H12AffineFastState.Bounded env32679 := by
  intro p hp
  have h : env32679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32678_32679 : H12AffineEnvironment.transform 12 6429 env32678 = env32679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6429 env32678 == env32679) = true)

theorem identity32679 : scanCanonicalize (H12AffineFastState.compose env32679 (packedSelected [3,5,6,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound32679 : packedSelected [3,5,6,12,14] rootPS < 2^1333 := by decide +kernel

def env32680 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2113,348,3344,0,342,3329,2420,1024,1,2049,33,16,83,349,65,2129,3329,2065,2421,1285,32,256,33,3393,593]

theorem envBound32680 : H12AffineFastState.Bounded env32680 := by
  intro p hp
  have h : env32680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32679_32680 : H12AffineEnvironment.transform 11 2113 env32679 = env32680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env32679 == env32680) = true)

theorem identity32680 : scanCanonicalize (H12AffineFastState.compose env32680 (packedSelected [4,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound32680 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env32681 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,2113,348,2128,0,342,2113,2420,320,1,2049,33,16,83,349,65,2129,2113,2065,2421,69,32,256,33,2049,593]

theorem envBound32681 : H12AffineFastState.Bounded env32681 := by
  intro p hp
  have h : env32681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32680_32681 : H12AffineEnvironment.transform 9 320 env32680 = env32681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env32680 == env32681) = true)

theorem identity32681 : scanCanonicalize (H12AffineFastState.compose env32681 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound32681 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env32682 : List Nat := [2,4,8,16,32,64,9,116,512,52,2048,2113,40,2128,0,34,2113,2048,52,1,2049,33,16,83,41,65,2129,2113,2065,2049,69,32,116,33,2049,593]

theorem envBound32682 : H12AffineFastState.Bounded env32682 := by
  intro p hp
  have h : env32682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32681_32682 : H12AffineEnvironment.transform 7 116 env32681 = env32682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env32681 == env32682) = true)

theorem identity32682 : scanCanonicalize (H12AffineFastState.compose env32682 (packedSelected [0,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32682 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env32683 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2064,40,2049,0,34,2064,2048,52,1,2049,33,16,2,41,16,2048,2064,2065,2049,20,32,37,33,2049,512]

theorem envBound32683 : H12AffineFastState.Bounded env32683 := by
  intro p hp
  have h : env32683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32682_32683 : H12AffineEnvironment.transform 5 17 env32682 = env32683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32682 == env32683) = true)

theorem identity32683 : scanCanonicalize (H12AffineFastState.compose env32683 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 565) := by decide +kernel

theorem selectedBound32683 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32684 : List Nat := [2,4,8,16,32,17,9,37,512,52,565,549,40,564,0,34,549,565,52,1,564,33,16,2,41,16,565,549,548,564,20,32,37,33,564,512]

theorem envBound32684 : H12AffineFastState.Bounded env32684 := by
  intro p hp
  have h : env32684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32683_32684 : H12AffineEnvironment.transform 10 565 env32683 = env32684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 565 env32683 == env32684) = true)

theorem identity32684 : scanCanonicalize (H12AffineFastState.compose env32684 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound32684 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32685 : List Nat := [2,4,8,16,13,17,9,8,512,25,536,520,5,537,0,15,520,536,25,1,537,12,16,2,4,16,536,520,521,537,20,13,8,12,537,512]

theorem envBound32685 : H12AffineFastState.Bounded env32685 := by
  intro p hp
  have h : env32685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32684_32685 : H12AffineEnvironment.transform 4 13 env32684 = env32685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env32684 == env32685) = true)

theorem identity32685 : scanCanonicalize (H12AffineFastState.compose env32685 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound32685 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32686 : List Nat := [2,4,4,16,1,17,5,4,512,21,532,516,5,533,0,3,516,532,21,1,533,0,16,2,4,16,532,516,517,533,20,1,4,0,533,512]

theorem envBound32686 : H12AffineFastState.Bounded env32686 := by
  intro p hp
  have h : env32686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32685_32686 : H12AffineEnvironment.transform 2 4 env32685 = env32686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env32685 == env32686) = true)

theorem identity32686 : scanCanonicalize (H12AffineFastState.compose env32686 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound32686 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env32687 : List Nat := [2,4,4,16,1,17,5,4,7,21,19,3,5,18,0,3,3,19,21,1,18,0,16,2,4,16,19,3,2,18,20,1,4,0,18,7]

theorem envBound32687 : H12AffineFastState.Bounded env32687 := by
  intro p hp
  have h : env32687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32686_32687 : H12AffineEnvironment.transform 8 7 env32686 = env32687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env32686 == env32687) = true)

theorem identity32687 : scanCanonicalize (H12AffineFastState.compose env32687 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound32687 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env32688 : List Nat := [2,4,4,2,1,3,5,4,7,7,1,3,5,0,0,3,3,1,7,1,0,0,2,2,4,2,1,3,2,0,6,1,4,0,0,7]

theorem envBound32688 : H12AffineFastState.Bounded env32688 := by
  intro p hp
  have h : env32688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32687_32688 : H12AffineEnvironment.transform 3 2 env32687 = env32688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env32687 == env32688) = true)

def env32689 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180272,510122,499128,8328,65,349474,395637,495034,67754,119042,272393,256,98815,90202,63189]

theorem envBound32689 : H12AffineFastState.Bounded env32689 := by
  intro p hp
  have h : env32689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32659_32689 : H12AffineEnvironment.transform 20 4161 env32659 = env32689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env32659 == env32689) = true)

theorem identity32689 : scanCanonicalize (H12AffineFastState.compose env32689 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound32689 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32690 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,4161,180272,452769,441779,8328,65,292137,395637,437681,10401,61705,272393,256,41460,16465,63189]

theorem envBound32690 : H12AffineFastState.Bounded env32690 := by
  intro p hp
  have h : env32690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32689_32690 : H12AffineEnvironment.transform 15 8203 env32689 = env32690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env32689 == env32690) = true)

theorem identity32690 : scanCanonicalize (H12AffineFastState.compose env32690 (packedSelected [1,4,7,9,11,12,15,18,19,23,27,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 146744) := by decide +kernel

theorem selectedBound32690 : packedSelected [1,4,7,9,11,12,15,18,19,23,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env32691 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,146744,1024,32769,4161,180272,54681,32907,8328,65,149521,13389,37001,10401,61705,136497,256,41460,16465,63189]

theorem envBound32691 : H12AffineFastState.Bounded env32691 := by
  intro p hp
  have h : env32691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32690_32691 : H12AffineEnvironment.transform 17 146744 env32690 = env32691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146744 env32690 == env32691) = true)

theorem identity32691 : scanCanonicalize (H12AffineFastState.compose env32691 (packedSelected [0,5,8,9,11,17,18,22,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound32691 : packedSelected [0,5,8,9,11,17,18,22,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env32692 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,8203,131072,146744,1024,32769,4161,169400,32785,32907,8328,65,138649,13389,37001,10401,42113,136497,256,41460,5593,41821]

theorem envBound32692 : H12AffineFastState.Bounded env32692 := by
  intro p hp
  have h : env32692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32691_32692 : H12AffineEnvironment.transform 13 5512 env32691 = env32692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env32691 == env32692) = true)

theorem identity32692 : scanCanonicalize (H12AffineFastState.compose env32692 (packedSelected [3,4,7,9,10,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 46277) := by decide +kernel

theorem selectedBound32692 : packedSelected [3,4,7,9,10,24,26,27] rootPS < 2^1333 := by decide +kernel

def env32693 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,8203,46277,35325,1024,32769,4161,8573,32785,32907,8328,65,43356,13389,37001,10401,42113,41460,256,41460,5593,41821]

theorem envBound32693 : H12AffineFastState.Bounded env32693 := by
  intro p hp
  have h : env32693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32692_32693 : H12AffineEnvironment.transform 16 46277 env32692 = env32693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46277 env32692 == env32693) = true)

theorem identity32693 : scanCanonicalize (H12AffineFastState.compose env32693 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound32693 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env32694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,8203,5529,10401,1024,8541,4161,8573,8525,8663,8328,65,2048,13389,12757,10401,1501,168,256,168,5593,513]

theorem envBound32694 : H12AffineFastState.Bounded env32694 := by
  intro p hp
  have h : env32694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32693_32694 : H12AffineEnvironment.transform 14 8540 env32693 = env32694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env32693 == env32694) = true)

theorem identity32694 : scanCanonicalize (H12AffineFastState.compose env32694 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound32694 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env32695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5512,1,342,5529,2556,1024,0,4161,32,16,138,469,65,2048,5392,4232,2556,1501,168,256,168,5593,513]

theorem envBound32695 : H12AffineFastState.Bounded env32695 := by
  intro p hp
  have h : env32695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32694_32695 : H12AffineEnvironment.transform 12 349 env32694 = env32695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env32694 == env32695) = true)

theorem identity32695 : scanCanonicalize (H12AffineFastState.compose env32695 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32695 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32696 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,1,342,5393,2420,1024,0,4161,32,16,2,349,65,2048,5392,4096,2420,1365,32,256,32,5457,513]

theorem envBound32696 : H12AffineFastState.Bounded env32696 := by
  intro p hp
  have h : env32696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32695_32696 : H12AffineEnvironment.transform 6 8 env32695 = env32696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32695 == env32696) = true)

theorem identity32696 : scanCanonicalize (H12AffineFastState.compose env32696 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 383) := by decide +kernel

theorem selectedBound32696 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32697 : List Nat := [2,4,8,16,32,64,8,256,512,1024,383,4096,349,5376,1,342,5393,11,1024,0,4161,32,16,2,349,65,383,5392,4096,11,1365,32,256,32,5457,513]

theorem envBound32697 : H12AffineFastState.Bounded env32697 := by
  intro p hp
  have h : env32697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32696_32697 : H12AffineEnvironment.transform 10 383 env32696 = env32697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 383 env32696 == env32697) = true)

theorem identity32697 : scanCanonicalize (H12AffineFastState.compose env32697 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 373) := by decide +kernel

theorem selectedBound32697 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32698 : List Nat := [2,4,8,16,32,64,8,256,512,1024,383,373,349,1141,1,342,1124,11,1024,0,308,32,16,2,349,65,383,1125,373,11,1365,32,256,32,1060,513]

theorem envBound32698 : H12AffineFastState.Bounded env32698 := by
  intro p hp
  have h : env32698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32697_32698 : H12AffineEnvironment.transform 11 373 env32697 = env32698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 373 env32697 == env32698) = true)

def env32699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180272,510122,499129,8328,65,349475,2496821,2596347,67754,119043,2373705,256,2199999,2191386,63188]

theorem envBound32699 : H12AffineFastState.Bounded env32699 := by
  intro p hp
  have h : env32699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32658_32699 : H12AffineEnvironment.transform 23 499129 env32658 = env32699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 499129 env32658 == env32699) = true)

def env32700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180272,510122,499129,8328,65,349475,395637,495035,67754,119043,272393,256,98815,90202,63188]

theorem envBound32700 : H12AffineFastState.Bounded env32700 := by
  intro p hp
  have h : env32700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32699_32700 : H12AffineEnvironment.transform 20 4160 env32699 = env32700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env32699 == env32700) = true)

theorem identity32700 : scanCanonicalize (H12AffineFastState.compose env32700 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound32700 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,4160,180272,400500,412007,8328,65,295421,395637,416101,56436,1501,272393,256,21793,46212,63188]

theorem envBound32701 : H12AffineFastState.Bounded env32701 := by
  intro p hp
  have h : env32701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32700_32701 : H12AffineEnvironment.transform 15 54494 env32700 = env32701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env32700 == env32701) = true)

def env32702 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4160,180272,400500,412007,8192,65,295285,395637,416101,56436,1365,272393,256,21793,46092,63068]

theorem envBound32702 : H12AffineFastState.Bounded env32702 := by
  intro p hp
  have h : env32702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32701_32702 : H12AffineEnvironment.transform 6 8 env32701 = env32702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32701 == env32702) = true)

theorem identity32702 : scanCanonicalize (H12AffineFastState.compose env32702 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound32702 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env32703 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,373,21795,131072,262144,1024,372,4160,147781,400500,412007,8192,65,262144,395637,416101,23809,1365,272393,256,21793,13689,30505]

theorem envBound32703 : H12AffineFastState.Bounded env32703 := by
  intro p hp
  have h : env32703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32702_32703 : H12AffineEnvironment.transform 14 373 env32702 = env32703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env32702 == env32703) = true)

theorem identity32703 : scanCanonicalize (H12AffineFastState.compose env32703 (packedSelected [0,2,3,6,8,11,12,14,15,16,17,18,20,24,26,27,28] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32703 : packedSelected [0,2,3,6,8,11,12,14,15,16,17,18,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env32704 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,292,21795,131072,262144,1024,293,4113,147732,400421,411958,8192,16,262144,395556,416052,23809,1284,272393,256,21793,13608,30505]

theorem envBound32704 : H12AffineFastState.Bounded env32704 := by
  intro p hp
  have h : env32704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32703_32704 : H12AffineEnvironment.transform 5 17 env32703 = env32704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32703 == env32704) = true)

theorem identity32704 : scanCanonicalize (H12AffineFastState.compose env32704 (packedSelected [1,2,4,6,8,11,12,15,18,19,20,22] rootPS)) = affineNative (2^(17+1) ^^^ 23808) := by decide +kernel

theorem selectedBound32704 : packedSelected [1,2,4,6,8,11,12,15,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env32705 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,292,21795,131072,23808,1024,293,4113,147732,147749,136246,8192,16,23808,152612,132148,23809,1284,29961,256,21793,13608,30505]

theorem envBound32705 : H12AffineFastState.Bounded env32705 := by
  intro p hp
  have h : env32705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32704_32705 : H12AffineEnvironment.transform 17 23808 env32704 = env32705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23808 env32704 == env32705) = true)

theorem identity32705 : scanCanonicalize (H12AffineFastState.compose env32705 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(16+1) ^^^ 5172) := by decide +kernel

theorem selectedBound32705 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env32706 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,292,21795,5172,23808,1024,293,4113,21792,21777,2,8192,16,23808,16400,4096,23809,1284,29961,256,21793,13608,30505]

theorem envBound32706 : H12AffineFastState.Bounded env32706 := by
  intro p hp
  have h : env32706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32705_32706 : H12AffineEnvironment.transform 16 5172 env32705 = env32706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5172 env32705 == env32706) = true)

theorem identity32706 : scanCanonicalize (H12AffineFastState.compose env32706 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 2340) := by decide +kernel

theorem selectedBound32706 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env32707 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,2340,292,7175,5172,5156,1024,293,4113,7172,7221,2,8192,16,5156,2356,4096,5157,1284,15405,256,7173,13608,15885]

theorem envBound32707 : H12AffineFastState.Bounded env32707 := by
  intro p hp
  have h : env32707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32706_32707 : H12AffineEnvironment.transform 13 2340 env32706 = env32707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2340 env32706 == env32707) = true)

theorem identity32707 : scanCanonicalize (H12AffineFastState.compose env32707 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound32707 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env32708 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3108,8192,2340,292,35,2064,2048,1024,293,3125,32,17,2,8192,16,2048,2356,3108,2049,1284,8201,256,33,10508,8745]

theorem envBound32708 : H12AffineFastState.Bounded env32708 := by
  intro p hp
  have h : env32708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32707_32708 : H12AffineEnvironment.transform 11 3108 env32707 = env32708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env32707 == env32708) = true)

theorem identity32708 : scanCanonicalize (H12AffineFastState.compose env32708 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound32708 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env32709 : List Nat := [2,4,8,16,32,17,8,5,512,1024,2048,3108,8192,2081,33,35,2064,2048,1024,32,3125,32,17,2,8192,16,2048,2097,3108,2049,1025,8201,5,33,10249,8745]

theorem envBound32709 : H12AffineFastState.Bounded env32709 := by
  intro p hp
  have h : env32709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32708_32709 : H12AffineEnvironment.transform 7 5 env32708 = env32709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env32708 == env32709) = true)

theorem identity32709 : scanCanonicalize (H12AffineFastState.compose env32709 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound32709 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env32710 : List Nat := [2,4,8,16,32,17,8,5,512,1024,2048,3108,9,2081,33,35,2064,2048,1024,32,3125,32,17,2,9,16,2048,2097,3108,2049,1025,0,5,33,2048,544]

theorem envBound32710 : H12AffineFastState.Bounded env32710 := by
  intro p hp
  have h : env32710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32709_32710 : H12AffineEnvironment.transform 12 9 env32709 = env32710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env32709 == env32710) = true)

theorem identity32710 : scanCanonicalize (H12AffineFastState.compose env32710 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1556) := by decide +kernel

theorem selectedBound32710 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env32711 : List Nat := [2,4,8,16,32,17,8,5,512,1024,1556,560,9,1589,33,35,1540,1556,1024,32,545,32,17,2,9,16,1556,1573,560,1557,1025,0,5,33,1556,544]

theorem envBound32711 : H12AffineFastState.Bounded env32711 := by
  intro p hp
  have h : env32711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32710_32711 : H12AffineEnvironment.transform 10 1556 env32710 = env32711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1556 env32710 == env32711) = true)

theorem identity32711 : scanCanonicalize (H12AffineFastState.compose env32711 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound32711 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32712 : List Nat := [2,4,8,16,1,17,8,5,512,1024,1556,529,9,1556,0,2,1540,1556,1024,1,512,1,17,2,9,16,1556,1540,529,1557,1025,0,5,0,1556,513]

theorem envBound32712 : H12AffineFastState.Bounded env32712 := by
  intro p hp
  have h : env32712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32711_32712 : H12AffineEnvironment.transform 4 1 env32711 = env32712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env32711 == env32712) = true)

theorem identity32712 : scanCanonicalize (H12AffineFastState.compose env32712 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound32712 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32713 : List Nat := [2,4,8,16,1,17,8,5,512,4,528,529,9,528,0,2,512,528,4,1,512,1,17,2,9,16,528,512,529,529,5,0,5,0,528,513]

theorem envBound32713 : H12AffineFastState.Bounded env32713 := by
  intro p hp
  have h : env32713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32712_32713 : H12AffineEnvironment.transform 9 4 env32712 = env32713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env32712 == env32713) = true)

theorem identity32713 : scanCanonicalize (H12AffineFastState.compose env32713 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound32713 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32714 : List Nat := [2,4,8,1,1,0,8,5,512,4,513,512,9,513,0,2,512,513,4,1,512,1,0,2,9,1,513,512,512,512,5,0,5,0,513,513]

theorem envBound32714 : H12AffineFastState.Bounded env32714 := by
  intro p hp
  have h : env32714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32713_32714 : H12AffineEnvironment.transform 3 1 env32713 = env32714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env32713 == env32714) = true)

theorem identity32714 : scanCanonicalize (H12AffineFastState.compose env32714 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound32714 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32715 : List Nat := [2,4,8,1,1,0,8,5,0,4,1,0,9,1,0,2,0,1,4,1,0,1,0,2,9,1,1,0,0,0,5,0,5,0,1,1]

theorem envBound32715 : H12AffineFastState.Bounded env32715 := by
  intro p hp
  have h : env32715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32714_32715 : H12AffineEnvironment.transform 8 0 env32714 = env32715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env32714 == env32715) = true)

theorem identity32715 : scanCanonicalize (H12AffineFastState.compose env32715 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound32715 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32716 : List Nat := [2,4,3,1,1,0,3,5,0,4,1,0,2,1,0,2,0,1,4,1,0,1,0,2,2,1,1,0,0,0,5,0,5,0,1,1]

theorem envBound32716 : H12AffineFastState.Bounded env32716 := by
  intro p hp
  have h : env32716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32715_32716 : H12AffineEnvironment.transform 2 3 env32715 = env32716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env32715 == env32716) = true)

def env32717 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4160,180272,400500,412007,8193,65,295284,395637,416101,56436,1364,272393,256,21793,46093,63069]

theorem envBound32717 : H12AffineFastState.Bounded env32717 := by
  intro p hp
  have h : env32717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32701_32717 : H12AffineEnvironment.transform 6 9 env32701 = env32717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32701 == env32717) = true)

theorem identity32717 : scanCanonicalize (H12AffineFastState.compose env32717 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound32717 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env32718 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,342,131072,262144,1024,21760,4160,136497,400500,412007,8193,65,283765,395637,416101,2421,1364,272393,256,21793,24844,9052]

theorem envBound32718 : H12AffineFastState.Bounded env32718 := by
  intro p hp
  have h : env32718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32717_32718 : H12AffineEnvironment.transform 14 21761 env32717 = env32718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env32717 == env32718) = true)

theorem identity32718 : scanCanonicalize (H12AffineFastState.compose env32718 (packedSelected [1,3,5,8,10,17,18,19,23] rootPS)) = affineNative (2^(17+1) ^^^ 146745) := by decide +kernel

theorem selectedBound32718 : packedSelected [1,3,5,8,10,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env32719 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,342,131072,146745,1024,21760,4160,136497,8525,29790,8193,65,158028,13388,25692,2421,1364,136496,256,21793,24844,9052]

theorem envBound32719 : H12AffineFastState.Bounded env32719 := by
  intro p hp
  have h : env32719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32718_32719 : H12AffineEnvironment.transform 17 146745 env32718 = env32719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146745 env32718 == env32719) = true)

theorem identity32719 : scanCanonicalize (H12AffineFastState.compose env32719 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound32719 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env32720 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,342,24908,23669,1024,21760,4160,29821,8525,29790,8193,65,2048,13388,25692,2421,1364,29820,256,21793,24844,9052]

theorem envBound32720 : H12AffineFastState.Bounded env32720 := by
  intro p hp
  have h : env32720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32719_32720 : H12AffineEnvironment.transform 16 24908 env32719 = env32720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env32719 == env32720) = true)

theorem identity32720 : scanCanonicalize (H12AffineFastState.compose env32720 (packedSelected [6,11,14,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound32720 : packedSelected [6,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env32721 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,21761,342,16741,23669,1024,21760,4160,21588,356,21623,40,65,2048,5221,17525,2421,1364,21589,256,21793,16677,885]

theorem envBound32721 : H12AffineFastState.Bounded env32721 := by
  intro p hp
  have h : env32721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32720_32721 : H12AffineEnvironment.transform 12 41 env32720 = env32721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env32720 == env32721) = true)

theorem identity32721 : scanCanonicalize (H12AffineFastState.compose env32721 (packedSelected [0,2,3,5,7,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound32721 : packedSelected [0,2,3,5,7,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env32722 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5237,372,342,5392,2048,1024,373,4160,33,356,2,40,65,2048,5221,4096,2421,1364,32,256,340,5456,885]

theorem envBound32722 : H12AffineFastState.Bounded env32722 := by
  intro p hp
  have h : env32722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32721_32722 : H12AffineEnvironment.transform 13 5237 env32721 = env32722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env32721 == env32722) = true)

theorem identity32722 : scanCanonicalize (H12AffineFastState.compose env32722 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound32722 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32723 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,41,4452,372,342,4097,2048,273,373,4160,33,356,2,40,65,2048,4468,4096,2421,69,32,256,340,4161,885]

theorem envBound32723 : H12AffineFastState.Bounded env32723 := by
  intro p hp
  have h : env32723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32722_32723 : H12AffineEnvironment.transform 9 273 env32722 = env32723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env32722 == env32723) = true)

theorem identity32723 : scanCanonicalize (H12AffineFastState.compose env32723 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound32723 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env32724 : List Nat := [2,4,8,16,32,64,9,37,512,52,2048,4096,41,4161,81,115,4097,2048,52,80,4160,33,65,2,40,65,2048,4177,4096,2128,69,32,37,113,4161,592]

theorem envBound32724 : H12AffineFastState.Bounded env32724 := by
  intro p hp
  have h : env32724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32723_32724 : H12AffineEnvironment.transform 7 37 env32723 = env32724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env32723 == env32724) = true)

theorem identity32724 : scanCanonicalize (H12AffineFastState.compose env32724 (packedSelected [3,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound32724 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env32725 : List Nat := [2,4,8,16,16,64,9,21,512,4,2048,4096,25,4161,81,67,4097,2048,4,80,4160,17,65,2,24,65,2048,4177,4096,2128,69,16,21,65,4161,592]

theorem envBound32725 : H12AffineFastState.Bounded env32725 := by
  intro p hp
  have h : env32725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32724_32725 : H12AffineEnvironment.transform 4 16 env32724 = env32725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env32724 == env32725) = true)

theorem identity32725 : scanCanonicalize (H12AffineFastState.compose env32725 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound32725 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env32726 : List Nat := [2,4,8,16,16,0,9,21,512,4,2048,4096,25,4097,17,3,4097,2048,4,16,4096,17,1,2,24,1,2048,4113,4096,2064,5,16,21,1,4097,528]

theorem envBound32726 : H12AffineFastState.Bounded env32726 := by
  intro p hp
  have h : env32726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32725_32726 : H12AffineEnvironment.transform 5 0 env32725 = env32726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env32725 == env32726) = true)

theorem identity32726 : scanCanonicalize (H12AffineFastState.compose env32726 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound32726 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32727 : List Nat := [2,4,8,0,0,0,9,5,512,4,2048,4096,9,4097,1,3,4097,2048,4,0,4096,1,1,2,8,1,2048,4097,4096,2048,5,0,5,1,4097,512]

theorem envBound32727 : H12AffineFastState.Bounded env32727 := by
  intro p hp
  have h : env32727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32726_32727 : H12AffineEnvironment.transform 3 0 env32726 = env32727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env32726 == env32727) = true)

theorem identity32727 : scanCanonicalize (H12AffineFastState.compose env32727 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound32727 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32728 : List Nat := [2,4,8,0,0,0,9,5,512,4,512,4096,9,4097,1,3,4097,512,4,0,4096,1,1,2,8,1,512,4097,4096,512,5,0,5,1,4097,512]

theorem envBound32728 : H12AffineFastState.Bounded env32728 := by
  intro p hp
  have h : env32728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32727_32728 : H12AffineEnvironment.transform 10 512 env32727 = env32728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env32727 == env32728) = true)

theorem identity32728 : scanCanonicalize (H12AffineFastState.compose env32728 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 516) := by decide +kernel

theorem selectedBound32728 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32729 : List Nat := [2,4,8,0,0,0,9,5,512,4,512,516,9,517,1,3,517,512,4,0,516,1,1,2,8,1,512,517,516,512,5,0,5,1,517,512]

theorem envBound32729 : H12AffineFastState.Bounded env32729 := by
  intro p hp
  have h : env32729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32728_32729 : H12AffineEnvironment.transform 11 516 env32728 = env32729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 516 env32728 == env32729) = true)

def env32730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180272,510122,499129,8328,65,349475,395636,495034,67754,119043,272392,256,98814,90203,63188]

theorem envBound32730 : H12AffineFastState.Bounded env32730 := by
  intro p hp
  have h : env32730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32699_32730 : H12AffineEnvironment.transform 20 4161 env32699 = env32730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env32699 == env32730) = true)

theorem identity32730 : scanCanonicalize (H12AffineFastState.compose env32730 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212079) := by decide +kernel

theorem selectedBound32730 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32731 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212079,1024,32769,4161,180272,62661,41430,8328,65,158028,79131,45525,67754,119043,201831,256,98814,90203,63188]

theorem envBound32731 : H12AffineFastState.Bounded env32731 := by
  intro p hp
  have h : env32731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32730_32731 : H12AffineEnvironment.transform 17 212079 env32730 = env32731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212079 env32730 == env32731) = true)

theorem identity32731 : scanCanonicalize (H12AffineFastState.compose env32731 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound32731 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env32732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,212079,1024,29908,4161,144613,16,21763,8328,65,158028,79131,17664,67754,75222,201831,256,95531,90203,513]

theorem envBound32732 : H12AffineFastState.Bounded env32732 := by
  intro p hp
  have h : env32732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32731_32732 : H12AffineEnvironment.transform 14 29909 env32731 = env32732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env32731 == env32732) = true)

theorem identity32732 : scanCanonicalize (H12AffineFastState.compose env32732 (packedSelected [4,9,11,14,17,18,20,23,32] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound32732 : packedSelected [4,9,11,14,17,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env32733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,21897,65536,131072,204083,1024,21896,4161,136633,16,21763,468,65,149520,70727,17664,67754,66698,201831,256,87159,82183,513]

theorem envBound32733 : H12AffineFastState.Bounded env32733 := by
  intro p hp
  have h : env32733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32732_32733 : H12AffineEnvironment.transform 12 348 env32732 = env32733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env32732 == env32733) = true)

theorem identity32733 : scanCanonicalize (H12AffineFastState.compose env32733 (packedSelected [0,1,3,7,9,14,15,17,18,19,20,22,23,24,26,28,38] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound32733 : packedSelected [0,1,3,7,9,14,15,17,18,19,20,22,23,24,26,28,38] rootPS < 2^1333 := by decide +kernel

def env32734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,21897,479,131072,138476,1024,21896,4161,136633,16,21763,468,65,149520,5528,17664,2421,1365,136632,256,21928,16600,513]

theorem envBound32734 : H12AffineFastState.Bounded env32734 := by
  intro p hp
  have h : env32734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32733_32734 : H12AffineEnvironment.transform 15 479 env32733 = env32734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env32733 == env32734) = true)

theorem identity32734 : scanCanonicalize (H12AffineFastState.compose env32734 (packedSelected [1,3,5,8,10,17,18,19,23] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound32734 : packedSelected [1,3,5,8,10,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env32735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5456,217,479,131072,138476,1024,216,4161,136633,16,83,468,65,138560,5528,4176,2421,1365,136632,256,248,5512,513]

theorem envBound32735 : H12AffineFastState.Bounded env32735 := by
  intro p hp
  have h : env32735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32734_32735 : H12AffineEnvironment.transform 13 5456 env32734 = env32735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env32734 == env32735) = true)

theorem identity32735 : scanCanonicalize (H12AffineFastState.compose env32735 (packedSelected [0,1,2,3,4,5,6,7,8,10,17,19,22] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound32735 : packedSelected [0,1,2,3,4,5,6,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env32736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5456,217,479,5528,2420,1024,216,4161,33,16,83,468,65,2264,5528,4176,2421,1365,32,256,248,5512,513]

theorem envBound32736 : H12AffineFastState.Bounded env32736 := by
  intro p hp
  have h : env32736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32735_32736 : H12AffineEnvironment.transform 16 5528 env32735 = env32736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env32735 == env32736) = true)

theorem identity32736 : scanCanonicalize (H12AffineFastState.compose env32736 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound32736 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32737 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5456,80,342,5393,2420,1024,81,4161,33,16,83,349,65,2129,5393,4176,2421,1365,32,256,113,5377,513]

theorem envBound32737 : H12AffineFastState.Bounded env32737 := by
  intro p hp
  have h : env32737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32736_32737 : H12AffineEnvironment.transform 6 9 env32736 = env32737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32736 == env32737) = true)

theorem identity32737 : scanCanonicalize (H12AffineFastState.compose env32737 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32737 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32738 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,0,262,5393,2340,1024,1,4113,33,16,3,269,17,2049,5393,4096,2341,1285,32,256,33,5377,513]

theorem envBound32738 : H12AffineFastState.Bounded env32738 := by
  intro p hp
  have h : env32738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32737_32738 : H12AffineEnvironment.transform 5 16 env32737 = env32738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32737 == env32738) = true)

theorem identity32738 : scanCanonicalize (H12AffineFastState.compose env32738 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound32738 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32739 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,292,268,1060,0,262,1077,2340,1024,1,309,33,16,3,269,17,2049,1077,292,2341,1285,32,256,33,1061,513]

theorem envBound32739 : H12AffineFastState.Bounded env32739 := by
  intro p hp
  have h : env32739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32738_32739 : H12AffineEnvironment.transform 11 292 env32738 = env32739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env32738 == env32739) = true)

theorem identity32739 : scanCanonicalize (H12AffineFastState.compose env32739 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound32739 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32740 : List Nat := [2,4,8,16,32,16,9,256,512,565,2048,292,268,529,0,262,512,2340,565,1,309,33,16,3,269,17,2049,512,292,2341,816,32,256,33,528,513]

theorem envBound32740 : H12AffineFastState.Bounded env32740 := by
  intro p hp
  have h : env32740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32739_32740 : H12AffineEnvironment.transform 9 565 env32739 = env32740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env32739 == env32740) = true)

theorem identity32740 : scanCanonicalize (H12AffineFastState.compose env32740 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 820) := by decide +kernel

end H12CloudChart0