import H12CloudChart0Data015

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound3941 : H12AffineFastState.Bounded env3941 := by
  intro p hp
  have h : env3941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3940_3941 : H12AffineEnvironment.transform 1 1 env3940 = env3941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env3940 == env3941) = true)

def leafEnv3941 : List Nat := [2,1,8,1,10,1,2,1,1,10,1,0,3,0,10,2,0,10,10,10,0,11,0,8,10,8,1,1,1,0,1,10,10,0,1,0,1,9,0,0,1,0,0]

def active3941 : List Nat := [0,2]

def tree3941 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3941 : H12WitnessSearch.Good tree3941 := H12GlobalWitnessIndex.good

theorem leafIdentity3941 : H12AffineFastState.composeSystem env3941 rootObs = leafEnv3941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3941 rootObs == leafEnv3941) = true)

theorem terminalChecked3941 : H12PackedTerminal.terminalCheckFast leafEnv3941 active3941 tree3941 = true := by decide +kernel

def env3942 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,32768,8235,4524,49072,1024,32768,4096,41088,185,41003,8329,184,8089,4265,4356,2184,1024,429,256,169,4525,773]

theorem envBound3942 : H12AffineFastState.Bounded env3942 := by
  intro p hp
  have h : env3942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3929_3942 : H12AffineEnvironment.transform 13 4265 env3929 = env3942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4265 env3929 == env3942) = true)

theorem identity3942 : scanCanonicalize (H12AffineFastState.compose env3942 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 14136) := by decide +kernel

theorem selectedBound3942 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env3943 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,14136,8235,4524,2184,1024,14136,4096,6072,185,5907,8329,184,8089,4265,4356,2184,1024,429,256,169,4525,773]

theorem envBound3943 : H12AffineFastState.Bounded env3943 := by
  intro p hp
  have h : env3943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3942_3943 : H12AffineEnvironment.transform 14 14136 env3942 = env3943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14136 env3942 == env3943) = true)

theorem identity3943 : scanCanonicalize (H12AffineFastState.compose env3943 (packedSelected [0,1,4,5,7,8,9,24] rootPS)) = affineNative (2^(11+1) ^^^ 1693) := by decide +kernel

theorem selectedBound3943 : packedSelected [0,1,4,5,7,8,9,24] rootPS < 2^1333 := by decide +kernel

def env3944 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1693,8192,1588,8613,8235,1841,2184,1024,8613,1693,293,185,398,8329,184,2308,1588,1945,2184,1024,429,256,169,1840,773]

theorem envBound3944 : H12AffineFastState.Bounded env3944 := by
  intro p hp
  have h : env3944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3943_3944 : H12AffineEnvironment.transform 11 1693 env3943 = env3944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1693 env3943 == env3944) = true)

theorem identity3944 : scanCanonicalize (H12AffineFastState.compose env3944 (packedSelected [1,2,3,5,6,7,8,9,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 2569) := by decide +kernel

theorem selectedBound3944 : packedSelected [1,2,3,5,6,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env3945 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1693,2569,1588,2988,2594,1841,2184,1024,2988,1693,293,185,398,2688,184,2308,1588,1945,2184,1024,429,256,169,1840,773]

theorem envBound3945 : H12AffineFastState.Bounded env3945 := by
  intro p hp
  have h : env3945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3944_3945 : H12AffineEnvironment.transform 12 2569 env3944 = env3945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2569 env3944 == env3945) = true)

theorem identity3945 : scanCanonicalize (H12AffineFastState.compose env3945 (packedSelected [1,2,3,4,5,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound3945 : packedSelected [1,2,3,4,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env3946 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1693,2569,1588,2729,2594,1588,2184,1024,2729,1693,32,185,139,2688,184,2049,1588,1692,2184,1024,168,5,169,1589,512]

theorem envBound3946 : H12AffineFastState.Bounded env3946 := by
  intro p hp
  have h : env3946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3945_3946 : H12AffineEnvironment.transform 7 5 env3945 = env3946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env3945 == env3946) = true)

theorem identity3946 : scanCanonicalize (H12AffineFastState.compose env3946 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound3946 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env3947 : List Nat := [2,4,8,16,32,16,18,5,512,1024,2048,1551,2569,1588,2619,2594,1588,2074,1024,2619,1551,32,43,25,2578,42,2049,1588,1550,2074,1024,58,5,59,1589,512]

theorem envBound3947 : H12AffineFastState.Bounded env3947 := by
  intro p hp
  have h : env3947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3946_3947 : H12AffineEnvironment.transform 6 18 env3946 = env3947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env3946 == env3947) = true)

theorem identity3947 : scanCanonicalize (H12AffineFastState.compose env3947 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound3947 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env3948 : List Nat := [2,4,8,16,32,16,18,5,512,1024,512,1551,9,1588,59,34,1588,538,1024,59,1551,32,43,25,18,42,513,1588,1550,538,1024,58,5,59,1589,512]

theorem envBound3948 : H12AffineFastState.Bounded env3948 := by
  intro p hp
  have h : env3948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3947_3948 : H12AffineEnvironment.transform 10 512 env3947 = env3948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env3947 == env3948) = true)

theorem identity3948 : scanCanonicalize (H12AffineFastState.compose env3948 (packedSelected [1,4,6,12] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound3948 : packedSelected [1,4,6,12] rootPS < 2^1333 := by decide +kernel

def env3949 : List Nat := [2,4,8,16,27,16,18,5,512,1024,512,1551,9,1551,0,25,1551,538,1024,0,1551,27,16,25,18,17,513,1551,1550,538,1024,1,5,0,1550,512]

theorem envBound3949 : H12AffineFastState.Bounded env3949 := by
  intro p hp
  have h : env3949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3948_3949 : H12AffineEnvironment.transform 4 27 env3948 = env3949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env3948 == env3949) = true)

theorem identity3949 : scanCanonicalize (H12AffineFastState.compose env3949 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound3949 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env3950 : List Nat := [2,4,3,16,16,16,18,5,512,1024,512,1540,2,1540,0,18,1540,529,1024,0,1540,16,16,18,18,17,513,1540,1541,529,1024,1,5,0,1541,512]

theorem envBound3950 : H12AffineFastState.Bounded env3950 := by
  intro p hp
  have h : env3950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3949_3950 : H12AffineEnvironment.transform 2 3 env3949 = env3950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env3949 == env3950) = true)

theorem identity3950 : scanCanonicalize (H12AffineFastState.compose env3950 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound3950 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env3951 : List Nat := [2,4,3,1,1,1,3,5,512,1024,512,1540,2,1540,0,3,1540,512,1024,0,1540,1,1,3,3,0,513,1540,1541,512,1024,1,5,0,1541,512]

theorem envBound3951 : H12AffineFastState.Bounded env3951 := by
  intro p hp
  have h : env3951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3950_3951 : H12AffineEnvironment.transform 3 1 env3950 = env3951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3950 == env3951) = true)

theorem identity3951 : scanCanonicalize (H12AffineFastState.compose env3951 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound3951 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3952 : List Nat := [2,4,3,1,1,1,3,5,1,1024,1,1029,2,1029,0,3,1029,1,1024,0,1029,1,1,3,3,0,0,1029,1028,1,1024,1,5,0,1028,1]

theorem envBound3952 : H12AffineFastState.Bounded env3952 := by
  intro p hp
  have h : env3952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3951_3952 : H12AffineEnvironment.transform 8 1 env3951 = env3952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3951 == env3952) = true)

def leafEnv3952 : List Nat := [2,4,3,1,1,1,3,5,1,1024,1,1029,2,1029,0,3,1029,1,1024,0,1029,1,1,3,1024,3,1,0,0,1029,1028,1,1024,1,5,0,4,3,1028,1,1,1029,0]

def active3952 : List Nat := [0,1,9]

def tree3952 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3952 : H12WitnessSearch.Good tree3952 := H12GlobalWitnessIndex.good

theorem leafIdentity3952 : H12AffineFastState.composeSystem env3952 rootObs = leafEnv3952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3952 rootObs == leafEnv3952) = true)

theorem terminalChecked3952 : H12PackedTerminal.terminalCheckFast leafEnv3952 active3952 tree3952 = true := by decide +kernel

def env3953 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,41089,73874,41003,8329,73875,323712,16384,16813,22561,74795,94510,256,20480,16644,74542]

theorem envBound3953 : H12AffineFastState.Bounded env3953 := by
  intro p hp
  have h : env3953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3926_3953 : H12AffineEnvironment.transform 21 41089 env3926 = env3953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env3926 == env3953) = true)

theorem identity3953 : scanCanonicalize (H12AffineFastState.compose env3953 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound3953 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3954 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,16384,32768,65536,4264,262144,1024,32768,4096,41089,73874,41003,8329,73875,323712,16384,16553,22561,74795,94250,4,20480,16384,74282]

theorem envBound3954 : H12AffineFastState.Bounded env3954 := by
  intro p hp
  have h : env3954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3953_3954 : H12AffineEnvironment.transform 7 4 env3953 = env3954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env3953 == env3954) = true)

theorem identity3954 : scanCanonicalize (H12AffineFastState.compose env3954 (packedSelected [0,3,7,10,11,13,17,18,20,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 38590) := by decide +kernel

theorem selectedBound3954 : packedSelected [0,3,7,10,11,13,17,18,20,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env3955 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,16384,32768,38590,4264,262144,1024,32768,4096,41089,46636,41003,8329,46637,323712,16384,16553,22561,45717,59028,4,20480,16384,46228]

theorem envBound3955 : H12AffineFastState.Bounded env3955 := by
  intro p hp
  have h : env3955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3954_3955 : H12AffineEnvironment.transform 15 38590 env3954 = env3955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38590 env3954 == env3955) = true)

def env3956 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,4096,32768,38590,4264,262144,1024,32768,4096,41089,46636,41003,8329,46637,303232,4096,4265,2081,45717,46740,4,0,4096,46228]

theorem envBound3956 : H12AffineFastState.Bounded env3956 := by
  intro p hp
  have h : env3956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3955_3956 : H12AffineEnvironment.transform 13 4096 env3955 = env3956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env3955 == env3956) = true)

theorem identity3956 : scanCanonicalize (H12AffineFastState.compose env3956 (packedSelected [0,2,7,11,13,17,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 1572) := by decide +kernel

theorem selectedBound3956 : packedSelected [0,2,7,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env3957 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1572,8192,1572,32768,32922,1676,262144,1024,32768,1572,41089,40968,41003,8329,40969,303232,1572,1677,2081,42161,41136,4,0,1572,41648]

theorem envBound3957 : H12AffineFastState.Bounded env3957 := by
  intro p hp
  have h : env3957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3956_3957 : H12AffineEnvironment.transform 11 1572 env3956 = env3957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1572 env3956 == env3957) = true)

theorem identity3957 : scanCanonicalize (H12AffineFastState.compose env3957 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound3957 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env3958 : List Nat := [2,4,8,1,32,1,128,4,512,1024,2048,1572,8192,1572,32768,32907,1676,262144,1024,32768,1572,41089,40968,41003,8329,40969,303232,1572,1677,2081,42144,41121,4,0,1572,41633]

theorem envBound3958 : H12AffineFastState.Bounded env3958 := by
  intro p hp
  have h : env3958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3957_3958 : H12AffineEnvironment.transform 3 1 env3957 = env3958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3957 == env3958) = true)

theorem identity3958 : scanCanonicalize (H12AffineFastState.compose env3958 (packedSelected [6,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound3958 : packedSelected [6,13,17] rootPS < 2^1333 := by decide +kernel

def env3959 : List Nat := [2,4,8,1,32,1,128,4,512,1024,522,1572,8192,1572,32768,32907,1676,262144,1024,32768,1572,41089,40968,41003,8329,40969,303232,1572,1677,555,42144,41121,4,0,1572,41633]

theorem envBound3959 : H12AffineFastState.Bounded env3959 := by
  intro p hp
  have h : env3959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3958_3959 : H12AffineEnvironment.transform 10 522 env3958 = env3959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env3958 == env3959) = true)

theorem identity3959 : scanCanonicalize (H12AffineFastState.compose env3959 (packedSelected [13,21] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound3959 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env3960 : List Nat := [2,4,8,1,32,1,128,4,512,1024,522,1572,8192,1572,8201,8322,1676,262144,1024,8201,1572,136,1,34,8329,0,262281,1572,1677,555,1193,168,4,0,1572,680]

theorem envBound3960 : H12AffineFastState.Bounded env3960 := by
  intro p hp
  have h : env3960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3959_3960 : H12AffineEnvironment.transform 14 8201 env3959 = env3960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env3959 == env3960) = true)

theorem identity3960 : scanCanonicalize (H12AffineFastState.compose env3960 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 554) := by decide +kernel

theorem selectedBound3960 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3961 : List Nat := [2,4,8,1,32,1,128,4,512,1024,522,1572,8192,1572,8201,8322,1676,554,1024,8201,1572,136,1,34,8329,0,675,1572,1677,555,1193,168,4,0,1572,680]

theorem envBound3961 : H12AffineFastState.Bounded env3961 := by
  intro p hp
  have h : env3961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3960_3961 : H12AffineEnvironment.transform 17 554 env3960 = env3961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 554 env3960 == env3961) = true)

theorem identity3961 : scanCanonicalize (H12AffineFastState.compose env3961 (packedSelected [2,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 679) := by decide +kernel

theorem selectedBound3961 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env3962 : List Nat := [2,4,8,1,32,1,128,4,512,679,522,131,8192,131,8201,8322,43,554,679,8201,131,136,1,34,8329,0,675,131,42,555,526,168,4,0,131,680]

theorem envBound3962 : H12AffineFastState.Bounded env3962 := by
  intro p hp
  have h : env3962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3961_3962 : H12AffineEnvironment.transform 9 679 env3961 = env3962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 679 env3961 == env3962) = true)

theorem identity3962 : scanCanonicalize (H12AffineFastState.compose env3962 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 130) := by decide +kernel

theorem selectedBound3962 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env3963 : List Nat := [2,4,8,1,32,1,128,4,130,37,136,131,8192,131,8201,8322,43,168,37,8201,131,136,1,34,8329,0,33,131,42,169,140,168,4,0,131,42]

theorem envBound3963 : H12AffineFastState.Bounded env3963 := by
  intro p hp
  have h : env3963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3962_3963 : H12AffineEnvironment.transform 8 130 env3962 = env3963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 130 env3962 == env3963) = true)

theorem identity3963 : scanCanonicalize (H12AffineFastState.compose env3963 (packedSelected [4,7] rootPS)) = affineNative (2^(12+1) ^^^ 139) := by decide +kernel

theorem selectedBound3963 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env3964 : List Nat := [2,4,8,1,32,1,128,4,130,37,136,131,139,131,130,9,43,168,37,130,131,136,1,34,2,0,33,131,42,169,140,168,4,0,131,42]

theorem envBound3964 : H12AffineFastState.Bounded env3964 := by
  intro p hp
  have h : env3964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3963_3964 : H12AffineEnvironment.transform 12 139 env3963 = env3964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 139 env3963 == env3964) = true)

theorem identity3964 : scanCanonicalize (H12AffineFastState.compose env3964 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound3964 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env3965 : List Nat := [2,4,8,1,32,1,8,4,10,37,0,11,3,11,10,9,43,32,37,10,11,0,1,34,2,0,33,11,42,33,4,32,4,0,11,42]

theorem envBound3965 : H12AffineFastState.Bounded env3965 := by
  intro p hp
  have h : env3965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3964_3965 : H12AffineEnvironment.transform 6 8 env3964 = env3965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env3964 == env3965) = true)

theorem identity3965 : scanCanonicalize (H12AffineFastState.compose env3965 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound3965 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env3966 : List Nat := [2,4,3,1,32,1,3,4,1,37,0,0,3,0,1,2,32,32,37,1,0,0,1,34,2,0,33,0,33,33,4,32,4,0,0,33]

theorem envBound3966 : H12AffineFastState.Bounded env3966 := by
  intro p hp
  have h : env3966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3965_3966 : H12AffineEnvironment.transform 2 3 env3965 = env3966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env3965 == env3966) = true)

theorem identity3966 : scanCanonicalize (H12AffineFastState.compose env3966 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound3966 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3967 : List Nat := [2,4,3,1,1,1,3,4,1,4,0,0,3,0,1,2,1,1,4,1,0,0,1,3,2,0,0,0,0,0,4,1,4,0,0,0]

theorem envBound3967 : H12AffineFastState.Bounded env3967 := by
  intro p hp
  have h : env3967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3966_3967 : H12AffineEnvironment.transform 4 1 env3966 = env3967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env3966 == env3967) = true)

theorem identity3967 : scanCanonicalize (H12AffineFastState.compose env3967 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound3967 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3968 : List Nat := [2,0,3,1,1,1,3,0,1,0,0,0,3,0,1,2,1,1,0,1,0,0,1,3,2,0,0,0,0,0,0,1,0,0,0,0]

theorem envBound3968 : H12AffineFastState.Bounded env3968 := by
  intro p hp
  have h : env3968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3967_3968 : H12AffineEnvironment.transform 1 0 env3967 = env3968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env3967 == env3968) = true)

def env3969 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,4097,32768,38590,4264,262144,1024,32768,4096,41089,46636,41003,8329,46637,303233,4097,4264,2080,45717,46741,4,1,4097,46228]

theorem envBound3969 : H12AffineFastState.Bounded env3969 := by
  intro p hp
  have h : env3969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3955_3969 : H12AffineEnvironment.transform 13 4097 env3955 = env3969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env3955 == env3969) = true)

theorem identity3969 : scanCanonicalize (H12AffineFastState.compose env3969 (packedSelected [0,2,7,11,13,17,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 1693) := by decide +kernel

theorem selectedBound3969 : packedSelected [0,2,7,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env3970 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1693,8192,1692,32768,32803,1589,262144,1024,32768,1693,41089,41137,41003,8329,41136,303233,1692,1589,2080,41992,40968,4,1,1692,41481]

theorem envBound3970 : H12AffineFastState.Bounded env3970 := by
  intro p hp
  have h : env3970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3969_3970 : H12AffineEnvironment.transform 11 1693 env3969 = env3970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1693 env3969 == env3970) = true)

theorem identity3970 : scanCanonicalize (H12AffineFastState.compose env3970 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 1671) := by decide +kernel

theorem selectedBound3970 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3971 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1693,8192,1692,32768,32803,1589,1671,1024,32768,1693,41089,41137,41003,8329,41136,42502,1692,1589,2080,41992,40968,4,1,1692,41481]

theorem envBound3971 : H12AffineFastState.Bounded env3971 := by
  intro p hp
  have h : env3971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3970_3971 : H12AffineEnvironment.transform 17 1671 env3970 = env3971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1671 env3970 == env3971) = true)

theorem identity3971 : scanCanonicalize (H12AffineFastState.compose env3971 (packedSelected [2,11,18] rootPS)) = affineNative (2^(14+1) ^^^ 11951) := by decide +kernel

theorem selectedBound3971 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env3972 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1693,8192,1692,11951,11916,1589,1671,1024,11951,1693,3630,3614,3716,8329,3615,2217,1692,1589,2080,2727,3751,4,1,1692,3238]

theorem envBound3972 : H12AffineFastState.Bounded env3972 := by
  intro p hp
  have h : env3972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3971_3972 : H12AffineEnvironment.transform 14 11951 env3971 = env3972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11951 env3971 == env3972) = true)

theorem identity3972 : scanCanonicalize (H12AffineFastState.compose env3972 (packedSelected [3,5,10,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1550) := by decide +kernel

theorem selectedBound3972 : packedSelected [3,5,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env3973 : List Nat := [2,4,8,16,32,16,128,4,512,1024,1550,1693,8192,1692,8353,8322,1589,1671,1024,8353,1693,32,16,138,8329,17,1703,1692,1589,1582,1193,169,4,1,1692,680]

theorem envBound3973 : H12AffineFastState.Bounded env3973 := by
  intro p hp
  have h : env3973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3972_3973 : H12AffineEnvironment.transform 10 1550 env3972 = env3973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1550 env3972 == env3973) = true)

theorem identity3973 : scanCanonicalize (H12AffineFastState.compose env3973 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound3973 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3974 : List Nat := [2,4,8,16,32,16,19,4,512,1024,1550,1550,8192,1551,8242,8209,1589,1556,1024,8242,1550,32,16,25,8218,17,1588,1551,1589,1582,1082,58,4,1,1551,571]

theorem envBound3974 : H12AffineFastState.Bounded env3974 := by
  intro p hp
  have h : env3974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3973_3974 : H12AffineEnvironment.transform 6 19 env3973 = env3974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env3973 == env3974) = true)

theorem identity3974 : scanCanonicalize (H12AffineFastState.compose env3974 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound3974 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env3975 : List Nat := [2,4,8,16,32,16,19,4,512,1024,1550,1550,1053,1551,1071,1036,1589,1556,1024,1071,1550,32,16,25,1031,17,1588,1551,1589,1582,1082,58,4,1,1551,571]

theorem envBound3975 : H12AffineFastState.Bounded env3975 := by
  intro p hp
  have h : env3975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3974_3975 : H12AffineEnvironment.transform 12 1053 env3974 = env3975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env3974 == env3975) = true)

theorem identity3975 : scanCanonicalize (H12AffineFastState.compose env3975 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound3975 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env3976 : List Nat := [2,4,8,16,27,16,19,4,512,1024,1550,1550,1053,1551,1044,1036,1550,1556,1024,1044,1550,27,16,25,1031,17,1551,1551,1550,1557,1025,1,4,1,1551,512]

theorem envBound3976 : H12AffineFastState.Bounded env3976 := by
  intro p hp
  have h : env3976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3975_3976 : H12AffineEnvironment.transform 4 27 env3975 = env3976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env3975 == env3976) = true)

theorem identity3976 : scanCanonicalize (H12AffineFastState.compose env3976 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound3976 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env3977 : List Nat := [2,4,8,16,27,16,19,4,1,1024,1039,1039,1053,1038,1044,1036,1039,1045,1024,1044,1039,27,16,25,1031,17,1038,1038,1039,1044,1025,1,4,1,1038,1]

theorem envBound3977 : H12AffineFastState.Bounded env3977 := by
  intro p hp
  have h : env3977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3976_3977 : H12AffineEnvironment.transform 8 1 env3976 = env3977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3976 == env3977) = true)

theorem identity3977 : scanCanonicalize (H12AffineFastState.compose env3977 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound3977 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3978 : List Nat := [2,4,8,16,27,16,19,4,1,21,26,26,8,27,1,25,26,0,21,1,26,27,16,25,18,17,27,27,26,1,20,1,4,1,27,1]

theorem envBound3978 : H12AffineFastState.Bounded env3978 := by
  intro p hp
  have h : env3978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3977_3978 : H12AffineEnvironment.transform 9 21 env3977 = env3978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env3977 == env3978) = true)

def env3979 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,4194304,73875,41003,8329,73875,323713,16384,16812,22560,74795,4313518,256,20481,16645,74542]

theorem envBound3979 : H12AffineFastState.Bounded env3979 := by
  intro p hp
  have h : env3979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3925_3979 : H12AffineEnvironment.transform 5 17 env3925 = env3979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env3925 == env3979) = true)

theorem identity3979 : scanCanonicalize (H12AffineFastState.compose env3979 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8494) := by decide +kernel

theorem selectedBound3979 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3980 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8494,4525,262144,1024,32768,4096,4194304,445,41003,8329,445,323713,16384,16812,22560,1285,4255872,256,20481,16645,512]

theorem envBound3980 : H12AffineFastState.Bounded env3980 := by
  intro p hp
  have h : env3980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3979_3980 : H12AffineEnvironment.transform 15 8494 env3979 = env3980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8494 env3979 == env3980) = true)

theorem identity3980 : scanCanonicalize (H12AffineFastState.compose env3980 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound3980 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3981 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8494,4525,262144,1024,32768,4096,41349,445,41003,8329,445,323713,16384,16812,22560,1285,20741,256,20481,16645,512]

theorem envBound3981 : H12AffineFastState.Bounded env3981 := by
  intro p hp
  have h : env3981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3980_3981 : H12AffineEnvironment.transform 21 41349 env3980 = env3981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env3980 == env3981) = true)

theorem identity3981 : scanCanonicalize (H12AffineFastState.compose env3981 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13972) := by decide +kernel

theorem selectedBound3981 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3982 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,13972,8494,4525,262144,1024,13972,4096,5905,445,5823,8329,445,280085,16384,16812,22560,1285,20741,256,20481,16645,512]

theorem envBound3982 : H12AffineFastState.Bounded env3982 := by
  intro p hp
  have h : env3982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3981_3982 : H12AffineEnvironment.transform 14 13972 env3981 = env3982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13972 env3981 == env3982) = true)

theorem identity3982 : scanCanonicalize (H12AffineFastState.compose env3982 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4524) := by decide +kernel

theorem selectedBound3982 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3983 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4524,13972,8494,4525,262144,1024,13972,4096,5905,445,5823,8329,445,268217,4524,4096,2444,1285,169,256,429,4265,512]

theorem envBound3983 : H12AffineFastState.Bounded env3983 := by
  intro p hp
  have h : env3983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3982_3983 : H12AffineEnvironment.transform 13 4524 env3982 = env3983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4524 env3982 == env3983) = true)

theorem identity3983 : scanCanonicalize (H12AffineFastState.compose env3983 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 7868) := by decide +kernel

theorem selectedBound3983 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env3984 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4524,13972,8494,4525,7868,1024,13972,4096,5905,445,5823,8329,445,2309,4524,4096,2444,1285,169,256,429,4265,512]

theorem envBound3984 : H12AffineFastState.Bounded env3984 := by
  intro p hp
  have h : env3984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3983_3984 : H12AffineEnvironment.transform 17 7868 env3983 = env3984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7868 env3983 == env3984) = true)

theorem identity3984 : scanCanonicalize (H12AffineFastState.compose env3984 (packedSelected [3,5,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound3984 : packedSelected [3,5,8,28] rootPS < 2^1333 := by decide +kernel

def env3985 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,4096,8192,4265,13972,8235,4264,7868,1024,13972,4096,5652,184,5823,8329,184,2048,4265,4096,2185,1024,169,5,168,4265,512]

theorem envBound3985 : H12AffineFastState.Bounded env3985 := by
  intro p hp
  have h : env3985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3984_3985 : H12AffineEnvironment.transform 7 5 env3984 = env3985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env3984 == env3985) = true)

theorem identity3985 : scanCanonicalize (H12AffineFastState.compose env3985 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound3985 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3986 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,1588,8192,1693,8352,8235,1692,2184,1024,8352,1588,32,184,139,8329,184,2048,1693,1588,2185,1024,169,5,168,1693,512]

theorem envBound3986 : H12AffineFastState.Bounded env3986 := by
  intro p hp
  have h : env3986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3985_3986 : H12AffineEnvironment.transform 11 1588 env3985 = env3986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env3985 == env3986) = true)

theorem identity3986 : scanCanonicalize (H12AffineFastState.compose env3986 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound3986 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env3987 : List Nat := [2,4,8,16,32,17,128,5,512,1024,538,1588,8192,1693,8352,8235,1692,658,1024,8352,1588,32,184,139,8329,184,538,1693,1588,659,1024,169,5,168,1693,512]

theorem envBound3987 : H12AffineFastState.Bounded env3987 := by
  intro p hp
  have h : env3987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3986_3987 : H12AffineEnvironment.transform 10 538 env3986 = env3987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env3986 == env3987) = true)

theorem identity3987 : scanCanonicalize (H12AffineFastState.compose env3987 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound3987 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env3988 : List Nat := [2,4,8,16,32,17,128,5,512,1024,538,1588,41,1693,137,2,1692,658,1024,137,1588,32,184,139,160,184,538,1693,1588,659,1024,169,5,168,1693,512]

theorem envBound3988 : H12AffineFastState.Bounded env3988 := by
  intro p hp
  have h : env3988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3987_3988 : H12AffineEnvironment.transform 12 41 env3987 = env3988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env3987 == env3988) = true)

theorem identity3988 : scanCanonicalize (H12AffineFastState.compose env3988 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3988 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env3989 : List Nat := [2,4,8,16,32,17,40,5,512,1024,538,1588,41,1589,33,2,1588,570,1024,33,1588,32,16,35,8,16,538,1589,1588,571,1024,1,5,0,1589,512]

theorem envBound3989 : H12AffineFastState.Bounded env3989 := by
  intro p hp
  have h : env3989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3988_3989 : H12AffineEnvironment.transform 6 40 env3988 = env3989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3988 == env3989) = true)

theorem identity3989 : scanCanonicalize (H12AffineFastState.compose env3989 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound3989 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3990 : List Nat := [2,4,8,16,10,17,2,5,512,1024,538,1566,3,1567,11,2,1566,528,1024,11,1566,10,16,9,8,16,538,1567,1566,529,1024,1,5,0,1567,512]

theorem envBound3990 : H12AffineFastState.Bounded env3990 := by
  intro p hp
  have h : env3990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3989_3990 : H12AffineEnvironment.transform 4 10 env3989 = env3990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env3989 == env3990) = true)

theorem identity3990 : scanCanonicalize (H12AffineFastState.compose env3990 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound3990 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env3991 : List Nat := [2,4,8,11,10,10,2,5,512,1024,513,1541,3,1540,11,2,1541,523,1024,11,1541,10,11,9,8,11,513,1540,1541,522,1024,1,5,0,1540,512]

theorem envBound3991 : H12AffineFastState.Bounded env3991 := by
  intro p hp
  have h : env3991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3990_3991 : H12AffineEnvironment.transform 3 11 env3990 = env3991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env3990 == env3991) = true)

theorem identity3991 : scanCanonicalize (H12AffineFastState.compose env3991 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound3991 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env3992 : List Nat := [2,4,3,0,1,1,2,5,512,1024,513,1541,3,1540,0,2,1541,512,1024,0,1541,1,0,2,3,0,513,1540,1541,513,1024,1,5,0,1540,512]

theorem envBound3992 : H12AffineFastState.Bounded env3992 := by
  intro p hp
  have h : env3992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3991_3992 : H12AffineEnvironment.transform 2 3 env3991 = env3992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env3991 == env3992) = true)

theorem identity3992 : scanCanonicalize (H12AffineFastState.compose env3992 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound3992 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3993 : List Nat := [2,4,3,0,1,1,2,5,1,1024,0,1028,3,1029,0,2,1028,1,1024,0,1028,1,0,2,3,0,0,1029,1028,0,1024,1,5,0,1029,1]

theorem envBound3993 : H12AffineFastState.Bounded env3993 := by
  intro p hp
  have h : env3993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3992_3993 : H12AffineEnvironment.transform 8 1 env3992 = env3993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3992 == env3993) = true)

def leafEnv3993 : List Nat := [2,4,3,0,1,1,2,5,1,1024,0,1028,3,1029,0,2,1028,1,1024,0,1028,1,0,2,1024,3,1,0,0,1029,1028,0,1024,1,5,0,4,3,1029,1,1,1029,0]

def active3993 : List Nat := [0,1,9]

def tree3993 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3993 : H12WitnessSearch.Good tree3993 := H12GlobalWitnessIndex.good

theorem leafIdentity3993 : H12AffineFastState.composeSystem env3993 rootObs = leafEnv3993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3993 rootObs == leafEnv3993) = true)

theorem terminalChecked3993 : H12PackedTerminal.terminalCheckFast leafEnv3993 active3993 tree3993 = true := by decide +kernel

def env3994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4096,4194304,8388608,41003,8329,8388688,323793,16384,16893,22640,74794,12644669,257,20561,8479126,8389613]

theorem envBound3994 : H12AffineFastState.Bounded env3994 := by
  intro p hp
  have h : env3994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3923_3994 : H12AffineEnvironment.transform 18 1025 env3923 = env3994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env3923 == env3994) = true)

theorem identity3994 : scanCanonicalize (H12AffineFastState.compose env3994 (packedSelected [14] rootPS)) = affineNative (2^(15+1) ^^^ 26051) := by decide +kernel

theorem selectedBound3994 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,26051,4604,262144,1025,32768,4096,4194304,8388608,41003,8329,8388688,323793,16384,16893,22640,16873,12644669,257,20561,8389717,8389613]

theorem envBound3995 : H12AffineFastState.Bounded env3995 := by
  intro p hp
  have h : env3995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3994_3995 : H12AffineEnvironment.transform 15 26051 env3994 = env3995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26051 env3994 == env3995) = true)

def env3996 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,26003,4524,262144,1025,32768,4096,4194304,8388608,41003,8329,8388608,323713,16384,16813,22560,16825,12644669,257,20481,8389637,8389565]

theorem envBound3996 : H12AffineFastState.Bounded env3996 := by
  intro p hp
  have h : env3996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3995_3996 : H12AffineEnvironment.transform 5 16 env3995 = env3996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3995 == env3996) = true)

theorem identity3996 : scanCanonicalize (H12AffineFastState.compose env3996 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound3996 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3997 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,26003,4524,262144,1025,32768,4096,4194304,445,41003,8329,445,323713,16384,16813,22560,16825,4255872,257,20481,1464,512]

theorem envBound3997 : H12AffineFastState.Bounded env3997 := by
  intro p hp
  have h : env3997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3996_3997 : H12AffineEnvironment.transform 22 445 env3996 = env3997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env3996 == env3997) = true)

theorem identity3997 : scanCanonicalize (H12AffineFastState.compose env3997 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound3997 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3998 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,26003,4524,262144,1025,32768,4096,41348,445,41003,8329,445,323713,16384,16813,22560,16825,20740,257,20481,1464,512]

theorem envBound3998 : H12AffineFastState.Bounded env3998 := by
  intro p hp
  have h : env3998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3997_3998 : H12AffineEnvironment.transform 21 41348 env3997 = env3998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env3997 == env3998) = true)

theorem identity3998 : scanCanonicalize (H12AffineFastState.compose env3998 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29225) := by decide +kernel

theorem selectedBound3998 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3999 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29225,26003,4524,262144,1025,29225,4096,21421,445,20994,8329,445,262824,16384,16813,22560,16825,20740,257,20481,1464,512]

theorem envBound3999 : H12AffineFastState.Bounded env3999 := by
  intro p hp
  have h : env3999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3998_3999 : H12AffineEnvironment.transform 14 29225 env3998 = env3999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29225 env3998 == env3999) = true)

theorem identity3999 : scanCanonicalize (H12AffineFastState.compose env3999 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound3999 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4000 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,16384,26424,26003,1213,262144,1025,26424,1297,18108,445,18195,8329,445,262824,16384,16813,19761,16825,17429,257,17680,1464,512]

theorem envBound4000 : H12AffineFastState.Bounded env4000 := by
  intro p hp
  have h : env4000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3999_4000 : H12AffineEnvironment.transform 11 1297 env3999 = env4000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env3999 == env4000) = true)

theorem identity4000 : scanCanonicalize (H12AffineFastState.compose env4000 (packedSelected [11,12,15,18,23,24,28,32] rootPS)) = affineNative (2^(13+1) ^^^ 1692) := by decide +kernel

theorem selectedBound4000 : packedSelected [11,12,15,18,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env4001 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1692,8612,8975,1213,262144,1025,8612,1297,32,445,399,8329,445,262824,1692,1841,2989,1829,649,257,908,1464,512]

theorem envBound4001 : H12AffineFastState.Bounded env4001 := by
  intro p hp
  have h : env4001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4000_4001 : H12AffineEnvironment.transform 13 1692 env4000 = env4001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1692 env4000 == env4001) = true)

theorem identity4001 : scanCanonicalize (H12AffineFastState.compose env4001 (packedSelected [8,10,12,15,18,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound4001 : packedSelected [8,10,12,15,18,23,24] rootPS < 2^1333 := by decide +kernel

def env4002 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1212,8192,1692,8201,8866,1213,262144,1025,8201,1212,32,16,34,8329,16,262824,1692,1692,2560,1672,649,172,545,1045,512]

theorem envBound4002 : H12AffineFastState.Bounded env4002 := by
  intro p hp
  have h : env4002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4001_4002 : H12AffineEnvironment.transform 7 173 env4001 = env4002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env4001 == env4002) = true)

theorem identity4002 : scanCanonicalize (H12AffineFastState.compose env4002 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 1582) := by decide +kernel

theorem selectedBound4002 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4003 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1212,8192,1692,8201,8866,1213,1582,1025,8201,1212,32,16,34,8329,16,1158,1692,1692,2560,1672,649,172,545,1045,512]

theorem envBound4003 : H12AffineFastState.Bounded env4003 := by
  intro p hp
  have h : env4003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4002_4003 : H12AffineEnvironment.transform 17 1582 env4002 = env4003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1582 env4002 == env4003) = true)

def env4004 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,26002,4525,262144,1025,32768,4096,4194304,8388608,41003,8329,8388609,323712,16384,16812,22561,16824,12644669,257,20480,8389636,8389564]

theorem envBound4004 : H12AffineFastState.Bounded env4004 := by
  intro p hp
  have h : env4004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3995_4004 : H12AffineEnvironment.transform 5 17 env3995 = env4004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env3995 == env4004) = true)

def env4005 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,26002,4525,262144,1025,32768,4096,4194304,4240696,41003,8329,4240697,323712,16384,16812,22561,16824,17413,257,20480,4239676,4241028]

theorem envBound4005 : H12AffineFastState.Bounded env4005 := by
  intro p hp
  have h : env4005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4004_4005 : H12AffineEnvironment.transform 22 4240696 env4004 = env4005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4240696 env4004 == env4005) = true)

theorem identity4005 : scanCanonicalize (H12AffineFastState.compose env4005 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 13576) := by decide +kernel

theorem selectedBound4005 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env4006 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,13576,26002,4525,262144,1025,13576,4096,4194304,4194352,5411,8329,4194353,279944,16384,16812,22561,16824,17413,257,20480,4195380,4195212]

theorem envBound4006 : H12AffineFastState.Bounded env4006 := by
  intro p hp
  have h : env4006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4005_4006 : H12AffineEnvironment.transform 14 13576 env4005 = env4006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13576 env4005 == env4006) = true)

def env4007 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,13576,25986,4525,262144,1025,13576,4096,4194304,4194336,5411,8329,4194337,279944,16384,16812,22561,16808,17413,257,20480,4195364,4195212]

theorem envBound4007 : H12AffineFastState.Bounded env4007 := by
  intro p hp
  have h : env4007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4006_4007 : H12AffineEnvironment.transform 3 0 env4006 = env4007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4006 == env4007) = true)

def env4008 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,13576,25986,4525,262144,1025,13576,4096,32,0,5411,8329,1,279944,16384,16812,22561,16808,17413,257,20480,1028,940]

theorem envBound4008 : H12AffineFastState.Bounded env4008 := by
  intro p hp
  have h : env4008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4007_4008 : H12AffineEnvironment.transform 21 32 env4007 = env4008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env4007 == env4008) = true)

theorem identity4008 : scanCanonicalize (H12AffineFastState.compose env4008 (packedSelected [0,3,7,9,10,20,22,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound4008 : packedSelected [0,3,7,9,10,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env4009 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,16384,13476,25646,4097,262144,1025,13476,4096,32,0,5263,8329,1,279588,16384,16384,22561,16388,17413,173,20480,1028,512]

theorem envBound4009 : H12AffineFastState.Bounded env4009 := by
  intro p hp
  have h : env4009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4008_4009 : H12AffineEnvironment.transform 7 172 env4008 = env4009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env4008 == env4009) = true)

theorem identity4009 : scanCanonicalize (H12AffineFastState.compose env4009 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 21671) := by decide +kernel

theorem selectedBound4009 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4010 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,16384,13476,25646,4097,21671,1025,13476,4096,32,0,5263,8329,1,4227,16384,16384,22561,16388,17413,173,20480,1028,512]

theorem envBound4010 : H12AffineFastState.Bounded env4010 := by
  intro p hp
  have h : env4010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4009_4010 : H12AffineEnvironment.transform 17 21671 env4009 = env4010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 21671 env4009 == env4010) = true)

theorem identity4010 : scanCanonicalize (H12AffineFastState.compose env4010 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 1676) := by decide +kernel

theorem selectedBound4010 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4011 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,1676,13476,8866,4097,4651,1025,13476,4096,32,0,5263,8329,1,4227,1676,1676,7853,1672,649,173,5772,1028,512]

theorem envBound4011 : H12AffineFastState.Bounded env4011 := by
  intro p hp
  have h : env4011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4010_4011 : H12AffineEnvironment.transform 13 1676 env4010 = env4011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1676 env4010 == env4011) = true)

theorem identity4011 : scanCanonicalize (H12AffineFastState.compose env4011 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1196) := by decide +kernel

theorem selectedBound4011 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env4012 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,1196,8192,1676,8200,8866,1197,1671,1025,8200,1196,32,0,35,8329,1,1071,1676,1676,2561,1672,649,173,544,1028,512]

theorem envBound4012 : H12AffineFastState.Bounded env4012 := by
  intro p hp
  have h : env4012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4011_4012 : H12AffineEnvironment.transform 11 1196 env4011 = env4012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1196 env4011 == env4012) = true)

theorem identity4012 : scanCanonicalize (H12AffineFastState.compose env4012 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound4012 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env4013 : List Nat := [2,4,8,0,32,1,40,4,512,1024,2048,1028,8192,1572,8200,8714,1029,1583,1025,8200,1028,32,0,35,8225,1,1071,1572,1572,2561,1568,545,5,544,1028,512]

theorem envBound4013 : H12AffineFastState.Bounded env4013 := by
  intro p hp
  have h : env4013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4012_4013 : H12AffineEnvironment.transform 6 40 env4012 = env4013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4012 == env4013) = true)

theorem identity4013 : scanCanonicalize (H12AffineFastState.compose env4013 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 3085) := by decide +kernel

theorem selectedBound4013 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env4014 : List Nat := [2,4,8,0,32,1,40,4,512,1024,2048,1028,3085,1572,3077,3591,1029,1583,1025,3077,1028,32,0,35,3116,1,1071,1572,1572,2561,1568,545,5,544,1028,512]

theorem envBound4014 : H12AffineFastState.Bounded env4014 := by
  intro p hp
  have h : env4014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4013_4014 : H12AffineEnvironment.transform 12 3085 env4013 = env4014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3085 env4013 == env4014) = true)

theorem identity4014 : scanCanonicalize (H12AffineFastState.compose env4014 (packedSelected [8] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound4014 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env4015 : List Nat := [2,4,8,0,32,1,40,4,512,1024,1038,1028,3,1572,11,521,1029,1583,1025,11,1028,32,0,35,34,1,1071,1572,1572,1551,1568,545,5,544,1028,512]

theorem envBound4015 : H12AffineFastState.Bounded env4015 := by
  intro p hp
  have h : env4015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4014_4015 : H12AffineEnvironment.transform 10 1038 env4014 = env4015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env4014 == env4015) = true)

theorem identity4015 : scanCanonicalize (H12AffineFastState.compose env4015 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound4015 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4016 : List Nat := [2,4,8,0,32,1,40,4,512,36,42,32,3,512,11,521,33,523,37,11,32,32,0,35,34,1,11,512,512,555,516,545,5,544,32,512]

theorem envBound4016 : H12AffineFastState.Bounded env4016 := by
  intro p hp
  have h : env4016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4015_4016 : H12AffineEnvironment.transform 9 36 env4015 = env4016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env4015 == env4016) = true)

theorem identity4016 : scanCanonicalize (H12AffineFastState.compose env4016 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound4016 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4017 : List Nat := [2,4,8,0,32,1,40,4,11,36,42,32,3,11,11,2,33,0,37,11,32,32,0,35,34,1,11,11,11,32,15,42,5,43,32,11]

theorem envBound4017 : H12AffineFastState.Bounded env4017 := by
  intro p hp
  have h : env4017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4016_4017 : H12AffineEnvironment.transform 8 11 env4016 = env4017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env4016 == env4017) = true)

theorem identity4017 : scanCanonicalize (H12AffineFastState.compose env4017 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound4017 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env4018 : List Nat := [2,4,8,0,10,1,2,4,11,14,0,10,3,11,11,2,11,0,15,11,10,10,0,9,8,1,11,11,11,10,15,0,5,1,10,11]

theorem envBound4018 : H12AffineFastState.Bounded env4018 := by
  intro p hp
  have h : env4018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4017_4018 : H12AffineEnvironment.transform 4 10 env4017 = env4018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env4017 == env4018) = true)

def env4019 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,13576,25986,4525,262144,1025,13576,4096,33,1,5411,8329,0,279944,16384,16812,22561,16808,17413,257,20480,1029,941]

theorem envBound4019 : H12AffineFastState.Bounded env4019 := by
  intro p hp
  have h : env4019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4007_4019 : H12AffineEnvironment.transform 21 33 env4007 = env4019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env4007 == env4019) = true)

def env4020 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,13576,25987,4525,262144,1025,13576,4096,4194304,4194337,5411,8329,4194336,279944,16384,16812,22561,16809,17413,257,20480,4195365,4195212]

theorem envBound4020 : H12AffineFastState.Bounded env4020 := by
  intro p hp
  have h : env4020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4006_4020 : H12AffineEnvironment.transform 3 1 env4006 = env4020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env4006 == env4020) = true)

theorem identity4020 : scanCanonicalize (H12AffineFastState.compose env4020 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound4020 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env4021 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,1029,8192,16384,8461,25987,1448,262144,1025,8461,1029,4194304,4194337,294,8329,4194336,279944,16384,16812,19492,16809,17413,257,17413,4195365,4195212]

theorem envBound4021 : H12AffineFastState.Bounded env4021 := by
  intro p hp
  have h : env4021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4020_4021 : H12AffineEnvironment.transform 11 1029 env4020 = env4021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env4020 == env4021) = true)

theorem identity4021 : scanCanonicalize (H12AffineFastState.compose env4021 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4021 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4022 : List Nat := [2,4,8,1,32,0,128,5,512,1024,2048,1029,8192,16384,8200,25734,1197,262144,1025,8200,1029,4194304,4194337,35,8329,4194336,279693,16384,16553,19492,16556,17413,4,17413,4195365,4194953]

theorem envBound4022 : H12AffineFastState.Bounded env4022 := by
  intro p hp
  have h : env4022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4021_4022 : H12AffineEnvironment.transform 7 5 env4021 = env4022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4021 == env4022) = true)

def env4023 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,26002,4525,262144,1025,32768,4096,4194304,4240697,41003,8329,4240696,323712,16384,16812,22561,16824,17412,257,20480,4239677,4241029]

theorem envBound4023 : H12AffineFastState.Bounded env4023 := by
  intro p hp
  have h : env4023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4004_4023 : H12AffineEnvironment.transform 22 4240697 env4004 = env4023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4240697 env4004 == env4023) = true)

theorem identity4023 : scanCanonicalize (H12AffineFastState.compose env4023 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 13492) := by decide +kernel

theorem selectedBound4023 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env4024 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,13492,26002,4525,262144,1025,13492,4096,4194304,4194701,5279,8329,4194700,279604,16384,16812,22561,16824,17412,257,20480,4195721,4194865]

theorem envBound4024 : H12AffineFastState.Bounded env4024 := by
  intro p hp
  have h : env4024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4023_4024 : H12AffineEnvironment.transform 14 13492 env4023 = env4024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13492 env4023 == env4024) = true)

def env4025 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1448,8192,16384,8476,26002,1029,262144,1025,8476,1448,4194304,4194701,311,8329,4194700,279604,16384,16812,19849,16824,17412,257,17832,4195721,4194865]

theorem envBound4025 : H12AffineFastState.Bounded env4025 := by
  intro p hp
  have h : env4025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4024_4025 : H12AffineEnvironment.transform 11 1448 env4024 = env4025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1448 env4024 == env4025) = true)

theorem identity4025 : scanCanonicalize (H12AffineFastState.compose env4025 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound4025 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env4026 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1028,8192,16384,8368,25662,1029,262144,1025,8368,1028,4194304,4194337,155,8329,4194336,279604,16384,16384,19493,16404,17412,173,17412,4195365,4194865]

theorem envBound4026 : H12AffineFastState.Bounded env4026 := by
  intro p hp
  have h : env4026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4025_4026 : H12AffineEnvironment.transform 7 172 env4025 = env4026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env4025 == env4026) = true)

theorem identity4026 : scanCanonicalize (H12AffineFastState.compose env4026 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4026 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4027 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,1028,8192,16384,8217,25662,1029,262144,1025,8217,1028,4194304,4194337,50,8224,4194336,279604,16384,16384,19493,16404,17412,4,17412,4195365,4194865]

theorem envBound4027 : H12AffineFastState.Bounded env4027 := by
  intro p hp
  have h : env4027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4026_4027 : H12AffineEnvironment.transform 6 41 env4026 = env4027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4026 == env4027) = true)

theorem identity4027 : scanCanonicalize (H12AffineFastState.compose env4027 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound4027 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4028 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,1028,8192,16384,8217,25662,1029,262144,1025,8217,1028,32,1,50,8224,0,279604,16384,16384,19493,16404,17412,4,17412,1029,529]

theorem envBound4028 : H12AffineFastState.Bounded env4028 := by
  intro p hp
  have h : env4028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4027_4028 : H12AffineEnvironment.transform 21 32 env4027 = env4028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env4027 == env4028) = true)

theorem identity4028 : scanCanonicalize (H12AffineFastState.compose env4028 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 19508) := by decide +kernel

theorem selectedBound4028 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4029 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,1028,8192,16384,8217,25662,1029,19508,1025,8217,1028,32,1,50,8224,0,2048,16384,16384,19493,16404,17412,4,17412,1029,529]

theorem envBound4029 : H12AffineFastState.Bounded env4029 := by
  intro p hp
  have h : env4029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4028_4029 : H12AffineEnvironment.transform 17 19508 env4028 = env4029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19508 env4028 == env4029) = true)

theorem identity4029 : scanCanonicalize (H12AffineFastState.compose env4029 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 1572) := by decide +kernel

theorem selectedBound4029 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env4030 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,1028,8192,1572,8217,8730,1029,2576,1025,8217,1028,32,1,50,8224,0,2048,1572,1572,2561,1584,544,4,544,1029,529]

theorem envBound4030 : H12AffineFastState.Bounded env4030 := by
  intro p hp
  have h : env4030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4029_4030 : H12AffineEnvironment.transform 13 1572 env4029 = env4030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1572 env4029 == env4030) = true)

theorem identity4030 : scanCanonicalize (H12AffineFastState.compose env4030 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1084) := by decide +kernel

theorem selectedBound4030 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env4031 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,1028,1084,1572,1061,1574,1029,2576,1025,1061,1028,32,1,50,1052,0,2048,1572,1572,2561,1584,544,4,544,1029,529]

theorem envBound4031 : H12AffineFastState.Bounded env4031 := by
  intro p hp
  have h : env4031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4030_4031 : H12AffineEnvironment.transform 12 1084 env4030 = env4031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1084 env4030 == env4031) = true)

theorem identity4031 : scanCanonicalize (H12AffineFastState.compose env4031 (packedSelected [3,6,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 1551) := by decide +kernel

theorem selectedBound4031 : packedSelected [3,6,8,11] rootPS < 2^1333 := by decide +kernel

def env4032 : List Nat := [2,4,8,16,32,17,41,5,512,1024,1551,1028,1084,1572,1061,1574,1029,1055,1025,1061,1028,32,1,50,1052,0,1551,1572,1572,1038,1584,544,4,544,1029,529]

theorem envBound4032 : H12AffineFastState.Bounded env4032 := by
  intro p hp
  have h : env4032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4031_4032 : H12AffineEnvironment.transform 10 1551 env4031 = env4032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1551 env4031 == env4032) = true)

theorem identity4032 : scanCanonicalize (H12AffineFastState.compose env4032 (packedSelected [0,2,5,6,7,8,13] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound4032 : packedSelected [0,2,5,6,7,8,13] rootPS < 2^1333 := by decide +kernel

def env4033 : List Nat := [2,4,8,16,32,17,41,5,512,20,539,16,40,560,49,562,17,11,21,49,16,32,1,50,8,0,539,560,560,26,548,544,4,544,17,529]

theorem envBound4033 : H12AffineFastState.Bounded env4033 := by
  intro p hp
  have h : env4033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4032_4033 : H12AffineEnvironment.transform 9 20 env4032 = env4033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env4032 == env4033) = true)

theorem identity4033 : scanCanonicalize (H12AffineFastState.compose env4033 (packedSelected [6] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound4033 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4034 : List Nat := [2,4,8,16,32,17,41,5,32,20,59,16,40,16,49,18,17,11,21,49,16,32,1,50,8,0,59,16,16,26,4,0,4,0,17,49]

theorem envBound4034 : H12AffineFastState.Bounded env4034 := by
  intro p hp
  have h : env4034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4033_4034 : H12AffineEnvironment.transform 8 32 env4033 = env4034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env4033 == env4034) = true)

theorem identity4034 : scanCanonicalize (H12AffineFastState.compose env4034 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound4034 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4035 : List Nat := [2,4,8,16,27,17,18,5,27,20,0,16,19,16,10,18,17,11,21,10,16,27,1,9,8,0,0,16,16,26,4,0,4,0,17,10]

theorem envBound4035 : H12AffineFastState.Bounded env4035 := by
  intro p hp
  have h : env4035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4034_4035 : H12AffineEnvironment.transform 4 27 env4034 = env4035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env4034 == env4035) = true)

theorem identity4035 : scanCanonicalize (H12AffineFastState.compose env4035 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound4035 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env4036 : List Nat := [2,4,8,11,0,10,9,5,0,15,0,11,8,11,10,9,10,11,14,10,11,0,1,9,8,0,0,11,11,1,4,0,4,0,10,10]

theorem envBound4036 : H12AffineFastState.Bounded env4036 := by
  intro p hp
  have h : env4036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4035_4036 : H12AffineEnvironment.transform 3 11 env4035 = env4036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env4035 == env4036) = true)

theorem identity4036 : scanCanonicalize (H12AffineFastState.compose env4036 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4036 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env4037 : List Nat := [2,4,3,0,0,1,2,5,0,4,0,0,3,0,1,2,1,0,5,1,0,0,1,2,3,0,0,0,0,1,4,0,4,0,1,1]

theorem envBound4037 : H12AffineFastState.Bounded env4037 := by
  intro p hp
  have h : env4037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4036_4037 : H12AffineEnvironment.transform 2 3 env4036 = env4037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4036 == env4037) = true)

theorem identity4037 : scanCanonicalize (H12AffineFastState.compose env4037 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound4037 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4038 : List Nat := [2,1,3,0,0,1,2,0,0,1,0,0,3,0,1,2,1,0,0,1,0,0,1,2,3,0,0,0,0,1,1,0,1,0,1,1]

theorem envBound4038 : H12AffineFastState.Bounded env4038 := by
  intro p hp
  have h : env4038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4037_4038 : H12AffineEnvironment.transform 1 1 env4037 = env4038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env4037 == env4038) = true)

def env4039 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1449,8192,16384,8477,26002,1028,262144,1025,8477,1449,4194304,4194701,310,8329,4194700,279604,16384,16812,19848,16824,17412,257,17833,4195721,4194865]

theorem envBound4039 : H12AffineFastState.Bounded env4039 := by
  intro p hp
  have h : env4039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4024_4039 : H12AffineEnvironment.transform 11 1449 env4024 = env4039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1449 env4024 == env4039) = true)

theorem identity4039 : scanCanonicalize (H12AffineFastState.compose env4039 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound4039 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env4040 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,1212,8192,16384,8200,25735,1028,262144,1025,8200,1212,4194304,4194456,35,8329,4194457,279604,16384,16569,19613,16557,17412,20,17596,4195484,4194865]

theorem envBound4040 : H12AffineFastState.Bounded env4040 := by
  intro p hp
  have h : env4040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4039_4040 : H12AffineEnvironment.transform 7 21 env4039 = env4040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env4039 == env4040) = true)

theorem identity4040 : scanCanonicalize (H12AffineFastState.compose env4040 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound4040 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env4041 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,1212,8192,16384,8200,25735,1028,262144,1025,8200,1212,32,184,35,8329,185,279604,16384,16569,19613,16557,17412,20,17596,1212,529]

theorem envBound4041 : H12AffineFastState.Bounded env4041 := by
  intro p hp
  have h : env4041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4040_4041 : H12AffineEnvironment.transform 21 32 env4040 = env4041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env4040 == env4041) = true)

theorem identity4041 : scanCanonicalize (H12AffineFastState.compose env4041 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound4041 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4042 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,1212,8192,16384,8200,25735,1028,2080,1025,8200,1212,32,184,35,8329,185,19476,16384,16569,19613,16557,17412,20,17596,1212,529]

theorem envBound4042 : H12AffineFastState.Bounded env4042 := by
  intro p hp
  have h : env4042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4041_4042 : H12AffineEnvironment.transform 17 2080 env4041 = env4042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env4041 == env4042) = true)

theorem identity4042 : scanCanonicalize (H12AffineFastState.compose env4042 (packedSelected [2,3,4,5,6,7,11,12,20,21] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound4042 : packedSelected [2,3,4,5,6,7,11,12,20,21] rootPS < 2^1333 := by decide +kernel

def env4043 : List Nat := [2,4,8,16,32,17,56,21,512,1024,2048,1028,8192,16384,8200,25663,1028,2080,1025,8200,1028,32,0,35,8241,1,19476,16384,16385,19493,16405,17412,20,17412,1028,529]

theorem envBound4043 : H12AffineFastState.Bounded env4043 := by
  intro p hp
  have h : env4043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4042_4043 : H12AffineEnvironment.transform 6 56 env4042 = env4043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env4042 == env4043) = true)

theorem identity4043 : scanCanonicalize (H12AffineFastState.compose env4043 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound4043 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env4044 : List Nat := [2,4,8,0,32,1,40,5,512,1024,2048,1028,8192,16384,8200,25647,1028,2080,1025,8200,1028,32,0,35,8225,1,19460,16384,16385,19493,16389,17412,4,17412,1028,513]

theorem envBound4044 : H12AffineFastState.Bounded env4044 := by
  intro p hp
  have h : env4044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4043_4044 : H12AffineEnvironment.transform 3 0 env4043 = env4044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4043 == env4044) = true)

theorem identity4044 : scanCanonicalize (H12AffineFastState.compose env4044 (packedSelected [0,1,4] rootPS)) = affineNative (2^(13+1) ^^^ 9250) := by decide +kernel

theorem selectedBound4044 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env4045 : List Nat := [2,4,8,0,32,1,40,5,512,1024,2048,1028,8192,9250,8200,13,1028,2080,1025,8200,1028,32,0,35,8225,1,10278,9250,9251,10247,9255,8230,4,8230,1028,513]

theorem envBound4045 : H12AffineFastState.Bounded env4045 := by
  intro p hp
  have h : env4045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4044_4045 : H12AffineEnvironment.transform 13 9250 env4044 = env4045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9250 env4044 == env4045) = true)

theorem identity4045 : scanCanonicalize (H12AffineFastState.compose env4045 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 3081) := by decide +kernel

theorem selectedBound4045 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env4046 : List Nat := [2,4,8,0,32,1,40,5,512,1024,2048,1028,3081,2091,3073,13,1028,2080,1025,3073,1028,32,0,35,3112,1,1071,2091,2090,1038,2094,3119,4,3119,1028,513]

theorem envBound4046 : H12AffineFastState.Bounded env4046 := by
  intro p hp
  have h : env4046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4045_4046 : H12AffineEnvironment.transform 12 3081 env4045 = env4046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3081 env4045 == env4046) = true)

theorem identity4046 : scanCanonicalize (H12AffineFastState.compose env4046 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 1583) := by decide +kernel

theorem selectedBound4046 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env4047 : List Nat := [2,4,8,0,32,1,40,5,512,1024,1583,1028,550,1540,558,13,1028,1551,1025,558,1028,32,0,35,519,1,1071,1540,1541,1038,1537,512,4,512,1028,513]

theorem envBound4047 : H12AffineFastState.Bounded env4047 := by
  intro p hp
  have h : env4047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4046_4047 : H12AffineEnvironment.transform 10 1583 env4046 = env4047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1583 env4046 == env4047) = true)

theorem identity4047 : scanCanonicalize (H12AffineFastState.compose env4047 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound4047 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env4048 : List Nat := [2,4,8,0,32,1,40,5,33,1024,1038,1028,7,1061,15,13,1028,1070,1025,15,1028,32,0,35,38,1,1071,1061,1060,1038,1056,33,4,33,1028,32]

theorem envBound4048 : H12AffineFastState.Bounded env4048 := by
  intro p hp
  have h : env4048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4047_4048 : H12AffineEnvironment.transform 8 33 env4047 = env4048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env4047 == env4048) = true)

theorem identity4048 : scanCanonicalize (H12AffineFastState.compose env4048 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound4048 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4049 : List Nat := [2,4,7,0,32,1,39,5,33,1024,1025,1028,7,1061,0,2,1028,1057,1025,0,1028,32,0,35,38,1,1056,1061,1060,1025,1056,33,4,33,1028,32]

theorem envBound4049 : H12AffineFastState.Bounded env4049 := by
  intro p hp
  have h : env4049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4048_4049 : H12AffineEnvironment.transform 2 7 env4048 = env4049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env4048 == env4049) = true)

theorem identity4049 : scanCanonicalize (H12AffineFastState.compose env4049 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 32) := by decide +kernel

theorem selectedBound4049 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4050 : List Nat := [2,4,7,0,32,1,39,5,33,32,33,36,7,5,0,2,36,1,33,0,36,32,0,35,38,1,0,5,4,33,0,33,4,33,36,32]

theorem envBound4050 : H12AffineFastState.Bounded env4050 := by
  intro p hp
  have h : env4050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4049_4050 : H12AffineEnvironment.transform 9 32 env4049 = env4050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 32 env4049 == env4050) = true)

theorem identity4050 : scanCanonicalize (H12AffineFastState.compose env4050 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound4050 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4051 : List Nat := [2,4,7,0,4,1,3,5,5,4,5,0,7,5,0,2,0,1,5,0,0,4,0,7,2,1,0,5,4,5,0,5,4,5,0,4]

theorem envBound4051 : H12AffineFastState.Bounded env4051 := by
  intro p hp
  have h : env4051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4050_4051 : H12AffineEnvironment.transform 4 4 env4050 = env4051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env4050 == env4051) = true)

def leafEnv4051 : List Nat := [2,4,7,0,4,1,3,5,5,4,5,0,7,5,0,2,0,1,5,0,0,4,0,7,0,2,1,1,0,5,4,5,0,5,4,5,4,6,0,4,1,4,0]

def active4051 : List Nat := [0,1]

def tree4051 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4051 : H12WitnessSearch.Good tree4051 := H12GlobalWitnessIndex.good

theorem leafIdentity4051 : H12AffineFastState.composeSystem env4051 rootObs = leafEnv4051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4051 rootObs == leafEnv4051) = true)

theorem terminalChecked4051 : H12PackedTerminal.terminalCheckFast leafEnv4051 active4051 tree4051 = true := by decide +kernel

def env4052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4096,4194304,8388608,41003,8329,8914001,849104,16385,16892,547953,598059,12644669,525568,545872,8479126,8914924]

theorem envBound4052 : H12AffineFastState.Bounded env4052 := by
  intro p hp
  have h : env4052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3922_4052 : H12AffineEnvironment.transform 27 16385 env3922 = env4052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16385 env3922 == env4052) = true)

def env4053 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,4194304,8388608,41003,8329,8388689,323792,16385,16892,22641,74795,12644669,256,20560,8479126,8389612]

theorem envBound4053 : H12AffineFastState.Bounded env4053 := by
  intro p hp
  have h : env4053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4052_4053 : H12AffineEnvironment.transform 18 1024 env4052 = env4053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env4052 == env4053) = true)

theorem identity4053 : scanCanonicalize (H12AffineFastState.compose env4053 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 98386) := by decide +kernel

theorem selectedBound4053 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4054 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,98386,8388608,41003,8329,8388689,323792,16385,16892,22641,74795,8483183,256,20560,8479126,8389612]

theorem envBound4054 : H12AffineFastState.Bounded env4054 := by
  intro p hp
  have h : env4054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4053_4054 : H12AffineEnvironment.transform 21 98386 env4053 = env4054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98386 env4053 == env4054) = true)

def env4055 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,98306,8388608,41003,8329,8388609,323712,16385,16812,22561,74795,8483135,256,20480,8479126,8389564]

theorem envBound4055 : H12AffineFastState.Bounded env4055 := by
  intro p hp
  have h : env4055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4054_4055 : H12AffineEnvironment.transform 5 16 env4054 = env4055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4054 == env4055) = true)

theorem identity4055 : scanCanonicalize (H12AffineFastState.compose env4055 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound4055 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4056 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,98306,444,41003,8329,445,323712,16385,16812,22561,74795,94339,256,20480,90154,512]

theorem envBound4056 : H12AffineFastState.Bounded env4056 := by
  intro p hp
  have h : env4056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4055_4056 : H12AffineEnvironment.transform 22 444 env4055 = env4056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env4055 == env4056) = true)

theorem identity4056 : scanCanonicalize (H12AffineFastState.compose env4056 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8582) := by decide +kernel

theorem selectedBound4056 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4057 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8582,4524,262144,1024,32768,4096,41348,444,41003,8329,445,323712,16385,16812,22561,1453,20741,256,20480,16812,512]

theorem envBound4057 : H12AffineFastState.Bounded env4057 := by
  intro p hp
  have h : env4057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4056_4057 : H12AffineEnvironment.transform 15 8582 env4056 = env4057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8582 env4056 == env4057) = true)

theorem identity4057 : scanCanonicalize (H12AffineFastState.compose env4057 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13884) := by decide +kernel

theorem selectedBound4057 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4058 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,13884,8582,4524,262144,1024,13884,4096,6072,444,5655,8329,445,280252,16385,16812,22561,1453,20741,256,20480,16812,512]

theorem envBound4058 : H12AffineFastState.Bounded env4058 := by
  intro p hp
  have h : env4058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4057_4058 : H12AffineEnvironment.transform 14 13884 env4057 = env4058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13884 env4057 == env4058) = true)

theorem identity4058 : scanCanonicalize (H12AffineFastState.compose env4058 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4357) := by decide +kernel

theorem selectedBound4058 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4059 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4357,13884,8582,4524,262144,1024,13884,4096,6072,444,5655,8329,445,268217,4356,4265,2340,1453,0,256,261,4265,512]

theorem envBound4059 : H12AffineFastState.Bounded env4059 := by
  intro p hp
  have h : env4059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4058_4059 : H12AffineEnvironment.transform 13 4357 env4058 = env4059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4357 env4058 == env4059) = true)

theorem identity4059 : scanCanonicalize (H12AffineFastState.compose env4059 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound4059 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env4060 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4357,13884,8582,4524,2340,1024,13884,4096,6072,444,5655,8329,445,7837,4356,4265,2340,1453,0,256,261,4265,512]

theorem envBound4060 : H12AffineFastState.Bounded env4060 := by
  intro p hp
  have h : env4060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4059_4060 : H12AffineEnvironment.transform 17 2340 env4059 = env4060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env4059 == env4060) = true)

theorem identity4060 : scanCanonicalize (H12AffineFastState.compose env4060 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4060 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env4061 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,4097,13884,8322,4264,2080,1024,13884,4096,5820,184,5655,8329,185,7837,4096,4265,2080,1193,0,4,1,4265,512]

theorem envBound4061 : H12AffineFastState.Bounded env4061 := by
  intro p hp
  have h : env4061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4060_4061 : H12AffineEnvironment.transform 7 4 env4060 = env4061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4060 == env4061) = true)

theorem identity4061 : scanCanonicalize (H12AffineFastState.compose env4061 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1693) := by decide +kernel

theorem selectedBound4061 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env4062 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1693,8192,1692,8353,8322,1589,2080,1024,8353,1693,33,184,138,8329,185,2048,1693,1588,2080,1193,0,4,1,1588,512]

theorem envBound4062 : H12AffineFastState.Bounded env4062 := by
  intro p hp
  have h : env4062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4061_4062 : H12AffineEnvironment.transform 11 1693 env4061 = env4062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1693 env4061 == env4062) = true)

theorem identity4062 : scanCanonicalize (H12AffineFastState.compose env4062 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound4062 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env4063 : List Nat := [2,4,8,16,32,16,128,4,512,188,2048,545,8192,544,8353,8322,649,2080,188,8353,545,33,184,138,8329,185,2048,545,648,2080,21,0,4,1,648,512]

theorem envBound4063 : H12AffineFastState.Bounded env4063 := by
  intro p hp
  have h : env4063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4062_4063 : H12AffineEnvironment.transform 9 188 env4062 = env4063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env4062 == env4063) = true)

theorem identity4063 : scanCanonicalize (H12AffineFastState.compose env4063 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound4063 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env4064 : List Nat := [2,4,8,16,32,16,51,4,512,15,2048,545,8192,544,8210,8241,570,2080,15,8210,545,33,11,57,8250,10,2048,545,571,2080,21,0,4,1,571,512]

theorem envBound4064 : H12AffineFastState.Bounded env4064 := by
  intro p hp
  have h : env4064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4063_4064 : H12AffineEnvironment.transform 6 51 env4063 = env4064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env4063 == env4064) = true)

theorem identity4064 : scanCanonicalize (H12AffineFastState.compose env4064 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound4064 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env4065 : List Nat := [2,4,8,11,32,11,40,4,512,15,2048,545,8192,544,8201,8234,545,2080,15,8201,545,33,11,34,8225,10,2048,545,544,2080,14,0,4,1,544,512]

theorem envBound4065 : H12AffineFastState.Bounded env4065 := by
  intro p hp
  have h : env4065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4064_4065 : H12AffineEnvironment.transform 3 11 env4064 = env4065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env4064 == env4065) = true)

theorem identity4065 : scanCanonicalize (H12AffineFastState.compose env4065 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound4065 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4066 : List Nat := [2,4,8,11,32,11,40,4,512,15,523,545,8192,544,8201,8234,545,555,15,8201,545,33,11,34,8225,10,523,545,544,555,14,0,4,1,544,512]

theorem envBound4066 : H12AffineFastState.Bounded env4066 := by
  intro p hp
  have h : env4066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4065_4066 : H12AffineEnvironment.transform 10 523 env4065 = env4066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env4065 == env4066) = true)

theorem identity4066 : scanCanonicalize (H12AffineFastState.compose env4066 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 546) := by decide +kernel

theorem selectedBound4066 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4067 : List Nat := [2,4,8,11,32,11,40,4,512,15,523,545,546,544,555,520,545,555,15,555,545,33,11,34,515,10,523,545,544,555,14,0,4,1,544,512]

theorem envBound4067 : H12AffineFastState.Bounded env4067 := by
  intro p hp
  have h : env4067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4066_4067 : H12AffineEnvironment.transform 12 546 env4066 = env4067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 546 env4066 == env4067) = true)

theorem identity4067 : scanCanonicalize (H12AffineFastState.compose env4067 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound4067 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env4068 : List Nat := [2,4,8,11,11,11,3,4,512,15,523,522,521,523,512,520,522,512,15,512,522,10,11,9,515,10,523,522,523,512,14,0,4,1,523,512]

theorem envBound4068 : H12AffineFastState.Bounded env4068 := by
  intro p hp
  have h : env4068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4067_4068 : H12AffineEnvironment.transform 4 11 env4067 = env4068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env4067 == env4068) = true)

theorem identity4068 : scanCanonicalize (H12AffineFastState.compose env4068 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound4068 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env4069 : List Nat := [2,4,2,1,1,1,3,4,512,5,513,512,515,513,512,514,512,512,5,512,512,0,1,3,515,0,513,512,513,512,4,0,4,1,513,512]

theorem envBound4069 : H12AffineFastState.Bounded env4069 := by
  intro p hp
  have h : env4069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4068_4069 : H12AffineEnvironment.transform 2 2 env4068 = env4069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env4068 == env4069) = true)

theorem identity4069 : scanCanonicalize (H12AffineFastState.compose env4069 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound4069 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4070 : List Nat := [2,4,2,1,1,1,3,4,1,5,0,1,2,0,1,3,1,1,5,1,1,0,1,3,2,0,0,1,0,1,4,0,4,1,0,1]

theorem envBound4070 : H12AffineFastState.Bounded env4070 := by
  intro p hp
  have h : env4070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4069_4070 : H12AffineEnvironment.transform 8 1 env4069 = env4070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env4069 == env4070) = true)

def env4071 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,98307,8388608,41003,8329,8388608,323713,16385,16813,22560,74795,8483134,256,20481,8479126,8389565]

theorem envBound4071 : H12AffineFastState.Bounded env4071 := by
  intro p hp
  have h : env4071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4054_4071 : H12AffineEnvironment.transform 5 17 env4054 = env4071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4054 == env4071) = true)

def env4072 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,98307,8388608,41003,8329,8388608,323713,16385,16813,22560,74795,8483118,256,20481,8479110,8389549]

theorem envBound4072 : H12AffineFastState.Bounded env4072 := by
  intro p hp
  have h : env4072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4071_4072 : H12AffineEnvironment.transform 3 0 env4071 = env4072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4071 == env4072) = true)

theorem identity4072 : scanCanonicalize (H12AffineFastState.compose env4072 (packedSelected [0,2,9,11,18,22,27] rootPS)) = affineNative (2^(22+1) ^^^ 284808) := by decide +kernel

theorem selectedBound4072 : packedSelected [0,2,9,11,18,22,27] rootPS < 2^1333 := by decide +kernel

def env4073 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,98307,284808,41003,8329,284808,323713,16385,16813,22560,74795,338342,256,20481,342286,285477]

theorem envBound4073 : H12AffineFastState.Bounded env4073 := by
  intro p hp
  have h : env4073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4072_4073 : H12AffineEnvironment.transform 22 284808 env4072 = env4073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 284808 env4072 == env4073) = true)

def env4074 : List Nat := [2,4,8,0,32,1,40,256,512,1024,2048,4096,8192,16384,32768,65536,4357,262144,1024,32768,4096,98307,284704,41003,8225,284704,323625,16385,16645,22560,74795,338190,256,20481,342286,285477]

theorem envBound4074 : H12AffineFastState.Bounded env4074 := by
  intro p hp
  have h : env4074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4073_4074 : H12AffineEnvironment.transform 6 40 env4073 = env4074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4073 == env4074) = true)

theorem identity4074 : scanCanonicalize (H12AffineFastState.compose env4074 (packedSelected [0,4,5,7,17,18,21,22,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8494) := by decide +kernel

theorem selectedBound4074 : packedSelected [0,4,5,7,17,18,21,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env4075 : List Nat := [2,4,8,0,32,1,40,256,512,1024,2048,4096,8192,16384,32768,8494,4357,262144,1024,32768,4096,41261,284704,41003,8225,284704,323625,16385,16645,22560,1285,264224,256,20481,268320,285477]

theorem envBound4075 : H12AffineFastState.Bounded env4075 := by
  intro p hp
  have h : env4075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4074_4075 : H12AffineEnvironment.transform 15 8494 env4074 = env4075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8494 env4074 == env4075) = true)

theorem identity4075 : scanCanonicalize (H12AffineFastState.compose env4075 (packedSelected [2,11,18] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound4075 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env4076 : List Nat := [2,4,8,0,32,1,40,256,512,1024,2048,4096,8192,16384,32768,8494,4357,2341,1024,32768,4096,41261,20741,41003,8225,20741,63756,16385,16645,22560,1285,261,256,20481,4357,20992]

theorem envBound4076 : H12AffineFastState.Bounded env4076 := by
  intro p hp
  have h : env4076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4075_4076 : H12AffineEnvironment.transform 17 2341 env4075 = env4076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env4075 == env4076) = true)

theorem identity4076 : scanCanonicalize (H12AffineFastState.compose env4076 (packedSelected [0,3,4,7,8,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 23040) := by decide +kernel

theorem selectedBound4076 : packedSelected [0,3,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env4077 : List Nat := [2,4,8,0,32,1,40,256,512,1024,2048,4096,8192,16384,23040,8494,4357,2341,1024,23040,4096,31533,20741,31275,8225,20741,8972,16385,16645,22560,1285,261,256,20481,4357,20992]

theorem envBound4077 : H12AffineFastState.Bounded env4077 := by
  intro p hp
  have h : env4077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4076_4077 : H12AffineEnvironment.transform 14 23040 env4076 = env4077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 23040 env4076 == env4077) = true)

theorem identity4077 : scanCanonicalize (H12AffineFastState.compose env4077 (packedSelected [0,4,5,6,7,8,9,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 2351) := by decide +kernel

theorem selectedBound4077 : packedSelected [0,4,5,6,7,8,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env4078 : List Nat := [2,4,8,0,32,1,40,256,512,1024,2048,2351,8192,16384,17199,8494,2090,2341,1024,17199,2351,25090,18474,25348,8225,18474,8972,16385,16645,16655,1285,261,256,18734,2090,19247]

theorem envBound4078 : H12AffineFastState.Bounded env4078 := by
  intro p hp
  have h : env4078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4077_4078 : H12AffineEnvironment.transform 11 2351 env4077 = env4078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2351 env4077 == env4078) = true)

theorem identity4078 : scanCanonicalize (H12AffineFastState.compose env4078 (packedSelected [6,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 2350) := by decide +kernel

theorem selectedBound4078 : packedSelected [6,13,17] rootPS < 2^1333 := by decide +kernel

def env4079 : List Nat := [2,4,8,0,32,1,40,256,512,1024,2048,2351,8192,2350,2561,8494,2090,2341,1024,2561,2351,11052,260,10794,8225,260,8972,2351,2091,2081,1285,261,256,0,2090,513]

theorem envBound4079 : H12AffineFastState.Bounded env4079 := by
  intro p hp
  have h : env4079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4078_4079 : H12AffineEnvironment.transform 13 2350 env4078 = env4079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2350 env4078 == env4079) = true)

theorem identity4079 : scanCanonicalize (H12AffineFastState.compose env4079 (packedSelected [5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 1803) := by decide +kernel

theorem selectedBound4079 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env4080 : List Nat := [2,4,8,0,32,1,40,256,512,1024,1803,1572,8192,1573,1290,8494,1825,1582,1024,1290,1572,9255,260,9505,8225,260,8972,1572,1824,1834,1285,261,256,0,1825,513]

theorem envBound4080 : H12AffineFastState.Bounded env4080 := by
  intro p hp
  have h : env4080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4079_4080 : H12AffineEnvironment.transform 10 1803 env4079 = env4080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1803 env4079 == env4080) = true)

theorem identity4080 : scanCanonicalize (H12AffineFastState.compose env4080 (packedSelected [0,1,2,4,7,11,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 1065) := by decide +kernel

theorem selectedBound4080 : packedSelected [0,1,2,4,7,11,12,13] rootPS < 2^1333 := by decide +kernel

def env4081 : List Nat := [2,4,8,0,32,1,40,256,512,1024,1803,1572,1065,1573,1290,1287,1825,1582,1024,1290,1572,14,260,264,1032,260,1829,1572,1824,1834,1285,261,256,0,1825,513]

theorem envBound4081 : H12AffineFastState.Bounded env4081 := by
  intro p hp
  have h : env4081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4080_4081 : H12AffineEnvironment.transform 12 1065 env4080 = env4081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1065 env4080 == env4081) = true)

theorem identity4081 : scanCanonicalize (H12AffineFastState.compose env4081 (packedSelected [0,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4081 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4082 : List Nat := [2,4,8,0,32,1,40,5,512,1024,1550,1572,1065,1573,1039,1026,1572,1582,1024,1039,1572,14,1,13,1032,1,1568,1572,1573,1583,1024,0,5,0,1572,513]

theorem envBound4082 : H12AffineFastState.Bounded env4082 := by
  intro p hp
  have h : env4082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4081_4082 : H12AffineEnvironment.transform 7 5 env4081 = env4082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4081 == env4082) = true)

theorem identity4082 : scanCanonicalize (H12AffineFastState.compose env4082 (packedSelected [0,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound4082 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env4083 : List Nat := [2,4,8,0,10,1,2,5,512,1024,1550,1550,1027,1551,1039,1026,1550,1540,1024,1039,1550,14,1,13,1032,1,1546,1550,1551,1541,1024,0,5,0,1550,513]

theorem envBound4083 : H12AffineFastState.Bounded env4083 := by
  intro p hp
  have h : env4083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4082_4083 : H12AffineEnvironment.transform 4 10 env4082 = env4083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env4082 == env4083) = true)

theorem identity4083 : scanCanonicalize (H12AffineFastState.compose env4083 (packedSelected [1,5] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound4083 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env4084 : List Nat := [2,1,8,0,10,1,2,0,512,1024,1547,1547,1027,1546,1034,1026,1547,1537,1024,1034,1547,11,1,8,1032,1,1546,1547,1546,1536,1024,0,0,0,1547,513]

theorem envBound4084 : H12AffineFastState.Bounded env4084 := by
  intro p hp
  have h : env4084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4083_4084 : H12AffineEnvironment.transform 1 1 env4083 = env4084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env4083 == env4084) = true)

theorem identity4084 : scanCanonicalize (H12AffineFastState.compose env4084 (packedSelected [11] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound4084 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env4085 : List Nat := [2,1,8,0,10,1,2,0,1,1024,1034,1034,1027,1035,1034,1026,1034,1024,1024,1034,1034,11,1,8,1032,1,1035,1034,1035,1025,1024,0,0,0,1034,0]

theorem envBound4085 : H12AffineFastState.Bounded env4085 := by
  intro p hp
  have h : env4085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4084_4085 : H12AffineEnvironment.transform 8 1 env4084 = env4085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env4084 == env4085) = true)

theorem identity4085 : scanCanonicalize (H12AffineFastState.compose env4085 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 10) := by decide +kernel

theorem selectedBound4085 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4086 : List Nat := [2,1,8,0,10,1,2,0,1,10,0,0,9,1,0,8,0,10,10,0,0,11,1,8,2,1,1,0,1,11,10,0,0,0,0,0]

theorem envBound4086 : H12AffineFastState.Bounded env4086 := by
  intro p hp
  have h : env4086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4085_4086 : H12AffineEnvironment.transform 9 10 env4085 = env4086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 10 env4085 == env4086) = true)

def leafEnv4086 : List Nat := [2,1,8,0,10,1,2,0,1,10,0,0,9,1,0,8,0,10,10,0,0,11,1,8,10,2,1,1,1,0,1,11,10,0,0,0,1,3,0,0,1,1,0]

def active4086 : List Nat := [0,2]

def tree4086 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4086 : H12WitnessSearch.Good tree4086 := H12GlobalWitnessIndex.good

theorem leafIdentity4086 : H12AffineFastState.composeSystem env4086 rootObs = leafEnv4086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4086 rootObs == leafEnv4086) = true)

theorem terminalChecked4086 : H12PackedTerminal.terminalCheckFast leafEnv4086 active4086 tree4086 = true := by decide +kernel

def env4087 : List Nat := [2,4,8,0,32,1,41,256,512,1024,2048,4096,8192,16384,32768,65536,4356,262144,1024,32768,4096,98307,284705,41003,8224,284705,323624,16385,16644,22560,74795,338191,256,20481,342286,285477]

theorem envBound4087 : H12AffineFastState.Bounded env4087 := by
  intro p hp
  have h : env4087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4073_4087 : H12AffineEnvironment.transform 6 41 env4073 = env4087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4073 == env4087) = true)

theorem identity4087 : scanCanonicalize (H12AffineFastState.compose env4087 (packedSelected [0,4,5,7,17,18,21,22,23,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4087 : packedSelected [0,4,5,7,17,18,21,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env4088 : List Nat := [2,4,8,0,32,1,41,5,512,1024,2048,4096,8192,16384,32768,65536,4097,262144,1024,32768,4096,98307,284705,41003,8224,284705,323624,16385,16385,22560,74795,337930,5,20481,342027,285216]

theorem envBound4088 : H12AffineFastState.Bounded env4088 := by
  intro p hp
  have h : env4088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4087_4088 : H12AffineEnvironment.transform 7 5 env4087 = env4088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4087 == env4088) = true)

theorem identity4088 : scanCanonicalize (H12AffineFastState.compose env4088 (packedSelected [0,2,3,4,5,7,10,11,17,18,21,22] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound4088 : packedSelected [0,2,3,4,5,7,10,11,17,18,21,22] rootPS < 2^1333 := by decide +kernel

def env4089 : List Nat := [2,4,8,0,32,1,41,5,512,1024,2048,4096,8192,16384,32768,65536,4097,2081,1024,32768,4096,98307,20480,41003,8224,20480,63497,16385,16385,22560,74795,73771,5,20481,77866,20993]

theorem envBound4089 : H12AffineFastState.Bounded env4089 := by
  intro p hp
  have h : env4089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4088_4089 : H12AffineEnvironment.transform 17 2081 env4088 = env4089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env4088 == env4089) = true)

theorem identity4089 : scanCanonicalize (H12AffineFastState.compose env4089 (packedSelected [3,5,6,10] rootPS)) = affineNative (2^(15+1) ^^^ 38921) := by decide +kernel

theorem selectedBound4089 : packedSelected [3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env4090 : List Nat := [2,4,8,0,32,1,41,5,512,1024,2048,4096,8192,16384,32768,38921,4097,2081,1024,32768,4096,6154,20480,41003,8224,20480,63497,16385,16385,22560,48162,47138,5,20481,43043,20993]

theorem envBound4090 : H12AffineFastState.Bounded env4090 := by
  intro p hp
  have h : env4090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4089_4090 : H12AffineEnvironment.transform 15 38921 env4089 = env4090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38921 env4089 == env4090) = true)

theorem identity4090 : scanCanonicalize (H12AffineFastState.compose env4090 (packedSelected [0,1,4,5,6,7,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 1582) := by decide +kernel

theorem selectedBound4090 : packedSelected [0,1,4,5,6,7,9,12] rootPS < 2^1333 := by decide +kernel

def env4091 : List Nat := [2,4,8,0,32,1,41,5,512,1024,1582,4096,8192,16384,32768,38439,4097,1551,1024,32768,4096,5668,20480,41003,8224,20480,63015,16385,16385,22030,45580,46604,5,20481,42509,20993]

theorem envBound4091 : H12AffineFastState.Bounded env4091 := by
  intro p hp
  have h : env4091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4090_4091 : H12AffineEnvironment.transform 10 1582 env4090 = env4091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1582 env4090 == env4091) = true)

theorem identity4091 : scanCanonicalize (H12AffineFastState.compose env4091 (packedSelected [1,8,13,15] rootPS)) = affineNative (2^(14+1) ^^^ 16906) := by decide +kernel

theorem selectedBound4091 : packedSelected [1,8,13,15] rootPS < 2^1333 := by decide +kernel

def env4092 : List Nat := [2,4,8,0,32,1,41,5,512,1024,1582,4096,8192,16384,16906,21549,4097,1551,1024,16906,4096,5668,20480,25121,8224,20480,13357,16385,16385,22030,28678,29702,5,20481,25607,20993]

theorem envBound4092 : H12AffineFastState.Bounded env4092 := by
  intro p hp
  have h : env4092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4091_4092 : H12AffineEnvironment.transform 14 16906 env4091 = env4092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 16906 env4091 == env4092) = true)

theorem identity4092 : scanCanonicalize (H12AffineFastState.compose env4092 (packedSelected [1,3,4,7,11,13] rootPS)) = affineNative (2^(12+1) ^^^ 4643) := by decide +kernel

theorem selectedBound4092 : packedSelected [1,3,4,7,11,13] rootPS < 2^1333 := by decide +kernel

def env4093 : List Nat := [2,4,8,0,32,1,41,5,512,1024,1582,4096,4643,16384,16906,21549,4097,1551,1024,16906,4096,5668,20480,20482,4611,20480,1550,16385,16385,22030,16933,17957,5,20481,22052,20993]

theorem envBound4093 : H12AffineFastState.Bounded env4093 := by
  intro p hp
  have h : env4093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4092_4093 : H12AffineEnvironment.transform 12 4643 env4092 = env4093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4643 env4092 == env4093) = true)

theorem identity4093 : scanCanonicalize (H12AffineFastState.compose env4093 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4093 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env4094 : List Nat := [2,4,3,0,32,1,34,5,512,1024,1573,4096,4643,16384,16897,21542,4097,1540,1024,16897,4096,5668,20480,20482,4611,20480,1541,16385,16385,22021,16933,17957,5,20481,22052,20993]

theorem envBound4094 : H12AffineFastState.Bounded env4094 := by
  intro p hp
  have h : env4094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4093_4094 : H12AffineEnvironment.transform 2 3 env4093 = env4094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4093 == env4094) = true)

theorem identity4094 : scanCanonicalize (H12AffineFastState.compose env4094 (packedSelected [0,3,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 4097) := by decide +kernel

theorem selectedBound4094 : packedSelected [0,3,8,9] rootPS < 2^1333 := by decide +kernel

def env4095 : List Nat := [2,4,3,0,32,1,34,5,512,1024,1573,4096,4643,4097,4608,1063,4097,1540,1024,4608,4096,5668,1,3,4611,1,1541,4096,4096,1540,4644,5668,5,0,1573,512]

theorem envBound4095 : H12AffineFastState.Bounded env4095 := by
  intro p hp
  have h : env4095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4094_4095 : H12AffineEnvironment.transform 13 4097 env4094 = env4095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env4094 == env4095) = true)

def env4096 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,98307,8388608,41003,8329,8388608,323713,16385,16813,22560,74795,8483119,256,20481,8479111,8389548]

theorem envBound4096 : H12AffineFastState.Bounded env4096 := by
  intro p hp
  have h : env4096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4071_4096 : H12AffineEnvironment.transform 3 1 env4071 = env4096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env4071 == env4096) = true)

theorem identity4096 : scanCanonicalize (H12AffineFastState.compose env4096 (packedSelected [0,2,9,11,18,22,27] rootPS)) = affineNative (2^(17+1) ^^^ 2445) := by decide +kernel

theorem selectedBound4096 : packedSelected [0,2,9,11,18,22,27] rootPS < 2^1333 := by decide +kernel

def env4097 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,2445,1024,32768,4096,98307,8388608,41003,8329,8388608,63756,16385,16813,22560,74795,8483119,256,20481,8479111,8389548]

theorem envBound4097 : H12AffineFastState.Bounded env4097 := by
  intro p hp
  have h : env4097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4096_4097 : H12AffineEnvironment.transform 17 2445 env4096 = env4097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2445 env4096 == env4097) = true)

def env4098 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,2445,1024,32768,4096,98307,61600,41003,8329,61600,63756,16385,16813,22560,74795,98703,256,20481,102695,62220]

theorem envBound4098 : H12AffineFastState.Bounded env4098 := by
  intro p hp
  have h : env4098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4097_4098 : H12AffineEnvironment.transform 22 61600 env4097 = env4098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 61600 env4097 == env4098) = true)

theorem identity4098 : scanCanonicalize (H12AffineFastState.compose env4098 (packedSelected [4,9,13,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 29063) := by decide +kernel

theorem selectedBound4098 : packedSelected [4,9,13,20,21] rootPS < 2^1333 := by decide +kernel

def env4099 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,32768,29063,4525,2445,1024,32768,4096,61828,61600,41003,8329,61600,63756,16385,16813,22560,21932,61448,256,20481,57504,62220]

theorem envBound4099 : H12AffineFastState.Bounded env4099 := by
  intro p hp
  have h : env4099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4098_4099 : H12AffineEnvironment.transform 15 29063 env4098 = env4099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29063 env4098 == env4099) = true)

theorem identity4099 : scanCanonicalize (H12AffineFastState.compose env4099 (packedSelected [0,3,5,7,10,13,17,18,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 13869) := by decide +kernel

theorem selectedBound4099 : packedSelected [0,3,5,7,10,13,17,18,20,23] rootPS < 2^1333 := by decide +kernel

def env4100 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,13869,29063,4525,2445,1024,13869,4096,18345,18061,5638,8329,18061,20257,16385,16813,22560,21932,17957,256,20481,22157,17697]

theorem envBound4100 : H12AffineFastState.Bounded env4100 := by
  intro p hp
  have h : env4100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4099_4100 : H12AffineEnvironment.transform 14 13869 env4099 = env4100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13869 env4099 == env4100) = true)

theorem identity4100 : scanCanonicalize (H12AffineFastState.compose env4100 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(11+1) ^^^ 1929) := by decide +kernel

theorem selectedBound4100 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env4101 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,1929,8192,16384,8612,26126,1572,2445,1024,8612,1929,18345,18061,399,8329,18061,20257,16385,16813,20393,16933,17957,256,18312,16644,17697]

theorem envBound4101 : H12AffineFastState.Bounded env4101 := by
  intro p hp
  have h : env4101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4100_4101 : H12AffineEnvironment.transform 11 1929 env4100 = env4101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1929 env4100 == env4101) = true)

theorem identity4101 : scanCanonicalize (H12AffineFastState.compose env4101 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4101 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env4102 : List Nat := [2,4,8,1,32,0,128,5,512,1024,2048,1676,8192,16384,8353,26126,1572,2184,1024,8353,1676,18092,18061,138,8329,18061,20004,16385,16552,20140,16933,17957,5,18061,16385,17444]

theorem envBound4102 : H12AffineFastState.Bounded env4102 := by
  intro p hp
  have h : env4102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4101_4102 : H12AffineEnvironment.transform 7 5 env4101 = env4102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4101 == env4102) = true)

theorem identity4102 : scanCanonicalize (H12AffineFastState.compose env4102 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 1550) := by decide +kernel

theorem selectedBound4102 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env4103 : List Nat := [2,4,8,1,32,0,128,5,512,1024,2048,1676,8192,1550,8353,8192,1572,2184,1024,8353,1676,162,131,138,8329,131,2090,1551,1702,2210,1067,43,5,131,1551,554]

theorem envBound4103 : H12AffineFastState.Bounded env4103 := by
  intro p hp
  have h : env4103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4102_4103 : H12AffineEnvironment.transform 13 1550 env4102 = env4103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1550 env4102 == env4103) = true)

theorem identity4103 : scanCanonicalize (H12AffineFastState.compose env4103 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 2720) := by decide +kernel

theorem selectedBound4103 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env4104 : List Nat := [2,4,8,1,32,0,128,5,512,1024,2048,1676,2720,1550,2561,2720,1572,2184,1024,2561,1676,162,131,138,2601,131,2090,1551,1702,2210,1067,43,5,131,1551,554]

theorem envBound4104 : H12AffineFastState.Bounded env4104 := by
  intro p hp
  have h : env4104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4103_4104 : H12AffineEnvironment.transform 12 2720 env4103 = env4104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2720 env4103 == env4104) = true)

theorem identity4104 : scanCanonicalize (H12AffineFastState.compose env4104 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1573) := by decide +kernel

theorem selectedBound4104 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env4105 : List Nat := [2,4,8,1,32,0,128,5,512,1024,1573,1676,1157,1550,1060,1157,1572,1709,1024,1060,1676,162,131,138,1036,131,1551,1551,1702,1671,1067,43,5,131,1551,554]

theorem envBound4105 : H12AffineFastState.Bounded env4105 := by
  intro p hp
  have h : env4105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4104_4105 : H12AffineEnvironment.transform 10 1573 env4104 = env4105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1573 env4104 == env4105) = true)

theorem identity4105 : scanCanonicalize (H12AffineFastState.compose env4105 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound4105 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env4106 : List Nat := [2,4,8,1,32,0,40,5,512,1024,1573,1572,1069,1550,1060,1069,1572,1541,1024,1060,1572,10,43,34,1036,43,1551,1551,1550,1583,1067,43,5,43,1551,554]

theorem envBound4106 : H12AffineFastState.Bounded env4106 := by
  intro p hp
  have h : env4106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4105_4106 : H12AffineEnvironment.transform 6 40 env4105 = env4106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4105 == env4106) = true)

def env4107 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,2445,1024,32768,4096,98307,61601,41003,8329,61601,63756,16385,16813,22560,74795,98702,256,20481,102694,62221]

theorem envBound4107 : H12AffineFastState.Bounded env4107 := by
  intro p hp
  have h : env4107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4097_4107 : H12AffineEnvironment.transform 22 61601 env4097 = env4107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 61601 env4097 == env4107) = true)

theorem identity4107 : scanCanonicalize (H12AffineFastState.compose env4107 (packedSelected [4,9,13,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound4107 : packedSelected [4,9,13,20,21] rootPS < 2^1333 := by decide +kernel

def env4108 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,32768,28803,4525,2445,1024,32768,4096,61568,61601,41003,8329,61601,63756,16385,16813,22560,21672,61709,256,20481,57765,62221]

theorem envBound4108 : H12AffineFastState.Bounded env4108 := by
  intro p hp
  have h : env4108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4107_4108 : H12AffineEnvironment.transform 15 28803 env4107 = env4108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env4107 == env4108) = true)

theorem identity4108 : scanCanonicalize (H12AffineFastState.compose env4108 (packedSelected [2,4,9,11,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound4108 : packedSelected [2,4,9,11,20,23] rootPS < 2^1333 := by decide +kernel

def env4109 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,8460,28803,4525,2445,1024,8460,4096,20876,20909,295,8329,20909,22528,16385,16813,22560,21672,20481,256,20481,16553,20993]

theorem envBound4109 : H12AffineFastState.Bounded env4109 := by
  intro p hp
  have h : env4109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4108_4109 : H12AffineEnvironment.transform 14 8460 env4108 = env4109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env4108 == env4109) = true)

theorem identity4109 : scanCanonicalize (H12AffineFastState.compose env4109 (packedSelected [0,3,4,5,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 7820) := by decide +kernel

theorem selectedBound4109 : packedSelected [0,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env4110 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,7820,8460,11791,4525,2445,1024,8460,4096,3840,3873,295,8329,3873,1676,7821,7969,1708,2596,3725,256,3725,7717,3213]

theorem envBound4110 : H12AffineFastState.Bounded env4110 := by
  intro p hp
  have h : env4110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4109_4110 : H12AffineEnvironment.transform 13 7820 env4109 = env4110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7820 env4109 == env4110) = true)

theorem identity4110 : scanCanonicalize (H12AffineFastState.compose env4110 (packedSelected [3,8,11,12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 4397) := by decide +kernel

theorem selectedBound4110 : packedSelected [3,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env4111 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,4397,7820,4129,7970,4525,2445,1024,4129,4096,3840,3873,295,4516,3873,1676,7821,7969,1708,2596,3725,256,3725,7717,3213]

theorem envBound4111 : H12AffineFastState.Bounded env4111 := by
  intro p hp
  have h : env4111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4110_4111 : H12AffineEnvironment.transform 12 4397 env4110 = env4111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4397 env4110 == env4111) = true)

theorem identity4111 : scanCanonicalize (H12AffineFastState.compose env4111 (packedSelected [6,10,11,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 1038) := by decide +kernel

theorem selectedBound4111 : packedSelected [6,10,11,13,17] rootPS < 2^1333 := by decide +kernel

def env4112 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,1038,1315,2690,1071,2860,1443,2445,1024,1071,1038,3840,3873,295,1450,3873,1676,2691,2863,1708,2596,3725,256,3725,2603,3213]

theorem envBound4112 : H12AffineFastState.Bounded env4112 := by
  intro p hp
  have h : env4112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4111_4112 : H12AffineEnvironment.transform 11 1038 env4111 = env4112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1038 env4111 == env4112) = true)

theorem identity4112 : scanCanonicalize (H12AffineFastState.compose env4112 (packedSelected [2,3,5,10,11,18] rootPS)) = affineNative (2^(10+1) ^^^ 1677) := by decide +kernel

theorem selectedBound4112 : packedSelected [2,3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env4113 : List Nat := [2,4,8,1,32,0,128,256,512,1024,1677,1038,1315,1039,1071,1441,1443,1792,1024,1071,1038,397,428,295,1450,428,1676,1038,1442,1708,1193,0,256,0,1190,512]

theorem envBound4113 : H12AffineFastState.Bounded env4113 := by
  intro p hp
  have h : env4113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4112_4113 : H12AffineEnvironment.transform 10 1677 env4112 = env4113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1677 env4112 == env4113) = true)

theorem identity4113 : scanCanonicalize (H12AffineFastState.compose env4113 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound4113 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env4114 : List Nat := [2,4,8,1,32,0,128,256,43,1024,1190,1038,1315,1039,1071,1441,1443,1323,1024,1071,1038,397,428,295,1450,428,1191,1038,1442,1159,1193,0,256,0,1190,43]

theorem envBound4114 : H12AffineFastState.Bounded env4114 := by
  intro p hp
  have h : env4114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4113_4114 : H12AffineEnvironment.transform 8 43 env4113 = env4114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env4113 == env4114) = true)

theorem identity4114 : scanCanonicalize (H12AffineFastState.compose env4114 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4114 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env4115 : List Nat := [2,4,8,1,32,0,41,256,43,1024,1039,1038,1315,1039,1071,1288,1290,1323,1024,1071,1038,292,261,295,1283,261,1038,1038,1291,1070,1024,0,256,0,1039,43]

theorem envBound4115 : H12AffineFastState.Bounded env4115 := by
  intro p hp
  have h : env4115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4114_4115 : H12AffineEnvironment.transform 6 41 env4114 = env4115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4114 == env4115) = true)

theorem identity4115 : scanCanonicalize (H12AffineFastState.compose env4115 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 289) := by decide +kernel

theorem selectedBound4115 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env4116 : List Nat := [2,4,8,1,32,0,41,256,43,289,302,303,2,302,270,41,43,10,289,270,303,292,261,295,34,261,303,303,42,271,289,0,256,0,302,43]

theorem envBound4116 : H12AffineFastState.Bounded env4116 := by
  intro p hp
  have h : env4116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4115_4116 : H12AffineEnvironment.transform 9 289 env4115 = env4116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 289 env4115 == env4116) = true)

theorem identity4116 : scanCanonicalize (H12AffineFastState.compose env4116 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound4116 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4117 : List Nat := [2,4,8,1,11,0,2,256,0,266,261,260,2,261,270,2,0,10,266,270,260,271,261,268,9,261,260,260,1,271,266,0,256,0,261,0]

theorem envBound4117 : H12AffineFastState.Bounded env4117 := by
  intro p hp
  have h : env4117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4116_4117 : H12AffineEnvironment.transform 4 11 env4116 = env4117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env4116 == env4117) = true)

def env4118 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4096,4194304,8388608,41003,8329,8388688,323793,16385,16892,22640,74794,12644669,257,20561,8479126,8389613]

theorem envBound4118 : H12AffineFastState.Bounded env4118 := by
  intro p hp
  have h : env4118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4052_4118 : H12AffineEnvironment.transform 18 1025 env4052 = env4118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env4052 == env4118) = true)

theorem identity4118 : scanCanonicalize (H12AffineFastState.compose env4118 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4310354) := by decide +kernel

theorem selectedBound4118 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4119 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4096,4194304,4310354,41003,8329,4310274,323793,16385,16892,22640,74794,78959,257,20561,4236484,4310719]

theorem envBound4119 : H12AffineFastState.Bounded env4119 := by
  intro p hp
  have h : env4119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4118_4119 : H12AffineEnvironment.transform 22 4310354 env4118 = env4119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4310354 env4118 == env4119) = true)

def env4120 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,4194304,4310274,41003,8329,4310274,323713,16385,16812,22560,74794,78911,257,20481,4236436,4310719]

theorem envBound4120 : H12AffineFastState.Bounded env4120 := by
  intro p hp
  have h : env4120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4119_4120 : H12AffineEnvironment.transform 5 16 env4119 = env4120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4119 == env4120) = true)

def env4121 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1448,8192,16384,32768,65536,1028,262144,1025,32768,1448,4194304,4310274,41003,8329,4310274,320809,16385,16812,19848,74794,74135,257,17833,4236436,4310719]

theorem envBound4121 : H12AffineFastState.Bounded env4121 := by
  intro p hp
  have h : env4121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4120_4121 : H12AffineEnvironment.transform 11 1448 env4120 = env4121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1448 env4120 == env4121) = true)

theorem identity4121 : scanCanonicalize (H12AffineFastState.compose env4121 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 50482) := by decide +kernel

theorem selectedBound4121 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env4122 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1448,8192,16384,32768,50482,1028,262144,1025,32768,1448,4194304,4194352,41003,8329,4194352,320809,16385,16812,19848,57624,58533,257,17833,4236436,4195213]

theorem envBound4122 : H12AffineFastState.Bounded env4122 := by
  intro p hp
  have h : env4122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4121_4122 : H12AffineEnvironment.transform 15 50482 env4121 = env4122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50482 env4121 == env4122) = true)

def env4123 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1448,8192,16384,32768,50466,1028,262144,1025,32768,1448,4194304,4194336,41003,8329,4194336,320809,16385,16812,19848,57608,58533,257,17833,4236420,4195213]

theorem envBound4123 : H12AffineFastState.Bounded env4123 := by
  intro p hp
  have h : env4123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4122_4123 : H12AffineEnvironment.transform 3 0 env4122 = env4123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4122 == env4123) = true)

theorem identity4123 : scanCanonicalize (H12AffineFastState.compose env4123 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound4123 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env4124 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1448,8192,16384,8460,25646,1028,262144,1025,8460,1448,4194304,4194336,295,8329,4194336,279589,16385,16812,19848,16388,17833,257,17833,4195720,4195213]

theorem envBound4124 : H12AffineFastState.Bounded env4124 := by
  intro p hp
  have h : env4124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4123_4124 : H12AffineEnvironment.transform 14 8460 env4123 = env4124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env4123 == env4124) = true)

theorem identity4124 : scanCanonicalize (H12AffineFastState.compose env4124 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4124 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4125 : List Nat := [2,4,8,0,32,0,128,4,512,1024,2048,1196,8192,16384,8200,25646,1028,262144,1025,8200,1196,4194304,4194336,35,8329,4194336,279589,16385,16552,19596,16388,17581,5,17581,4195468,4194953]

theorem envBound4125 : H12AffineFastState.Bounded env4125 := by
  intro p hp
  have h : env4125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4124_4125 : H12AffineEnvironment.transform 7 4 env4124 = env4125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4124 == env4125) = true)

def env4126 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1448,8192,16384,32768,50467,1028,262144,1025,32768,1448,4194304,4194337,41003,8329,4194337,320809,16385,16812,19848,57609,58533,257,17833,4236421,4195213]

theorem envBound4126 : H12AffineFastState.Bounded env4126 := by
  intro p hp
  have h : env4126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4122_4126 : H12AffineEnvironment.transform 3 1 env4122 = env4126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env4122 == env4126) = true)

def env4127 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1448,8192,16384,32768,50467,1028,262144,1025,32768,1448,41088,41121,41003,8329,41121,320809,16385,16812,19848,57609,58533,257,17833,1029,41741]

theorem envBound4127 : H12AffineFastState.Bounded env4127 := by
  intro p hp
  have h : env4127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4126_4127 : H12AffineEnvironment.transform 21 41088 env4126 = env4127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env4126 == env4127) = true)

theorem identity4127 : scanCanonicalize (H12AffineFastState.compose env4127 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound4127 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4128 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1448,8192,16384,8200,25899,1028,262144,1025,8200,1448,136,169,35,8329,169,279841,16385,16812,19848,16641,17581,257,17833,1029,773]

theorem envBound4128 : H12AffineFastState.Bounded env4128 := by
  intro p hp
  have h : env4128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4127_4128 : H12AffineEnvironment.transform 14 8200 env4127 = env4128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env4127 == env4128) = true)

theorem identity4128 : scanCanonicalize (H12AffineFastState.compose env4128 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 20393) := by decide +kernel

theorem selectedBound4128 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env4129 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1448,8192,16384,8200,25899,1028,20393,1025,8200,1448,136,169,35,8329,169,2696,16385,16812,19848,16641,17581,257,17833,1029,773]

theorem envBound4129 : H12AffineFastState.Bounded env4129 := by
  intro p hp
  have h : env4129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4128_4129 : H12AffineEnvironment.transform 17 20393 env4128 = env4129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20393 env4128 == env4129) = true)

theorem identity4129 : scanCanonicalize (H12AffineFastState.compose env4129 (packedSelected [1,10,12,15,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1928) := by decide +kernel

theorem selectedBound4129 : packedSelected [1,10,12,15,24,26] rootPS < 2^1333 := by decide +kernel

def env4130 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1448,8192,1928,8200,8867,1028,2081,1025,8200,1448,136,169,35,8329,169,2696,1929,1572,2560,1673,805,257,545,1029,773]

theorem envBound4130 : H12AffineFastState.Bounded env4130 := by
  intro p hp
  have h : env4130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4129_4130 : H12AffineEnvironment.transform 13 1928 env4129 = env4130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1928 env4129 == env4130) = true)

theorem identity4130 : scanCanonicalize (H12AffineFastState.compose env4130 (packedSelected [0,3,7,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 2600) := by decide +kernel

theorem selectedBound4130 : packedSelected [0,3,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env4131 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1448,2600,1928,2592,2187,1028,2081,1025,2592,1448,136,169,35,2721,169,2696,1929,1572,2560,1673,805,257,545,1029,773]

theorem envBound4131 : H12AffineFastState.Bounded env4131 := by
  intro p hp
  have h : env4131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4130_4131 : H12AffineEnvironment.transform 12 2600 env4130 = env4131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2600 env4130 == env4131) = true)

theorem identity4131 : scanCanonicalize (H12AffineFastState.compose env4131 (packedSelected [2,3,4,5,6,7,13] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4131 : packedSelected [2,3,4,5,6,7,13] rootPS < 2^1333 := by decide +kernel

def env4132 : List Nat := [2,4,8,1,32,1,41,256,512,1024,2048,1281,2600,1825,2592,2082,1028,2081,1025,2592,1281,33,0,35,2568,0,2593,1824,1572,2560,1568,805,257,545,1029,773]

theorem envBound4132 : H12AffineFastState.Bounded env4132 := by
  intro p hp
  have h : env4132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4131_4132 : H12AffineEnvironment.transform 6 41 env4131 = env4132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4131 == env4132) = true)

theorem identity4132 : scanCanonicalize (H12AffineFastState.compose env4132 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound4132 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env4133 : List Nat := [2,4,8,1,0,1,9,256,512,1024,2048,1281,2568,1793,2560,2050,1028,2049,1025,2560,1281,1,0,3,2568,0,2561,1792,1540,2560,1536,773,257,513,1029,773]

theorem envBound4133 : H12AffineFastState.Bounded env4133 := by
  intro p hp
  have h : env4133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4132_4133 : H12AffineEnvironment.transform 4 0 env4132 = env4133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env4132 == env4133) = true)

theorem identity4133 : scanCanonicalize (H12AffineFastState.compose env4133 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 778) := by decide +kernel

theorem selectedBound4133 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env4134 : List Nat := [2,4,8,1,0,1,9,256,512,778,2048,523,2568,11,2560,2050,782,2049,779,2560,523,1,0,3,2568,0,2561,10,270,2560,266,773,257,513,783,773]

theorem envBound4134 : H12AffineFastState.Bounded env4134 := by
  intro p hp
  have h : env4134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4133_4134 : H12AffineEnvironment.transform 9 778 env4133 = env4134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 778 env4133 == env4134) = true)

theorem identity4134 : scanCanonicalize (H12AffineFastState.compose env4134 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 270) := by decide +kernel

theorem selectedBound4134 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env4135 : List Nat := [2,4,8,1,0,1,9,256,512,778,270,523,774,11,782,268,782,271,779,782,523,1,0,3,774,0,783,10,270,782,266,773,257,513,783,773]

theorem envBound4135 : H12AffineFastState.Bounded env4135 := by
  intro p hp
  have h : env4135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4134_4135 : H12AffineEnvironment.transform 10 270 env4134 = env4135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 270 env4134 == env4135) = true)

theorem identity4135 : scanCanonicalize (H12AffineFastState.compose env4135 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4135 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env4136 : List Nat := [2,4,3,1,0,1,2,256,512,769,261,512,774,0,773,263,773,260,768,773,512,1,0,3,774,0,772,1,261,773,257,773,257,513,772,773]

theorem envBound4136 : H12AffineFastState.Bounded env4136 := by
  intro p hp
  have h : env4136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4135_4136 : H12AffineEnvironment.transform 2 3 env4135 = env4136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4135 == env4136) = true)

theorem identity4136 : scanCanonicalize (H12AffineFastState.compose env4136 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound4136 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4137 : List Nat := [2,4,3,1,0,1,2,256,260,5,261,260,2,0,1,263,1,260,4,1,260,1,0,3,2,0,0,1,261,1,257,1,257,261,0,1]

theorem envBound4137 : H12AffineFastState.Bounded env4137 := by
  intro p hp
  have h : env4137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4136_4137 : H12AffineEnvironment.transform 8 260 env4136 = env4137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env4136 == env4137) = true)

def env4138 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1448,8192,16384,32768,50467,1028,262144,1025,32768,1448,41089,41120,41003,8329,41120,320809,16385,16812,19848,57609,58533,257,17833,1028,41740]

theorem envBound4138 : H12AffineFastState.Bounded env4138 := by
  intro p hp
  have h : env4138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4126_4138 : H12AffineEnvironment.transform 21 41089 env4126 = env4138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env4126 == env4138) = true)

theorem identity4138 : scanCanonicalize (H12AffineFastState.compose env4138 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4138 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4139 : List Nat := [2,4,8,1,32,1,128,4,512,1024,2048,1196,8192,16384,32768,50215,1028,262144,1025,32768,1196,41089,41120,41003,8329,41120,320557,16385,16552,19596,57357,58533,5,17581,1028,41480]

theorem envBound4139 : H12AffineFastState.Bounded env4139 := by
  intro p hp
  have h : env4139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4138_4139 : H12AffineEnvironment.transform 7 4 env4138 = env4139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4138 == env4139) = true)

theorem identity4139 : scanCanonicalize (H12AffineFastState.compose env4139 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 60549) := by decide +kernel

theorem selectedBound4139 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env4140 : List Nat := [2,4,8,1,32,1,128,4,512,1024,2048,1196,8192,16384,32768,50215,1028,60549,1025,32768,1196,41089,41120,41003,8329,41120,2216,16385,16552,19596,57357,58533,5,17581,1028,41480]

theorem envBound4140 : H12AffineFastState.Bounded env4140 := by
  intro p hp
  have h : env4140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4139_4140 : H12AffineEnvironment.transform 17 60549 env4139 = env4140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 60549 env4139 == env4140) = true)

theorem identity4140 : scanCanonicalize (H12AffineFastState.compose env4140 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 26245) := by decide +kernel

theorem selectedBound4140 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env4141 : List Nat := [2,4,8,1,32,1,128,4,512,1024,2048,1196,8192,16384,26245,8866,1028,2560,1025,26245,1196,17924,17957,18094,8329,17957,2216,16385,16552,19596,1672,544,5,17581,1028,17549]

theorem envBound4141 : H12AffineFastState.Bounded env4141 := by
  intro p hp
  have h : env4141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4140_4141 : H12AffineEnvironment.transform 14 26245 env4140 = env4141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26245 env4140 == env4141) = true)

theorem identity4141 : scanCanonicalize (H12AffineFastState.compose env4141 (packedSelected [1,3,4,9,12,13,15,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 1197) := by decide +kernel

theorem selectedBound4141 : packedSelected [1,3,4,9,12,13,15,17,20] rootPS < 2^1333 := by decide +kernel

def env4142 : List Nat := [2,4,8,1,32,1,128,4,512,1024,2048,1196,8192,1197,8744,8866,1028,2560,1025,8744,1196,681,648,515,8329,648,2216,1196,1029,2081,1672,544,5,0,1028,32]

theorem envBound4142 : H12AffineFastState.Bounded env4142 := by
  intro p hp
  have h : env4142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4141_4142 : H12AffineEnvironment.transform 13 1197 env4141 = env4142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1197 env4141 == env4142) = true)

theorem identity4142 : scanCanonicalize (H12AffineFastState.compose env4142 (packedSelected [0,3,4,5,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2730) := by decide +kernel

theorem selectedBound4142 : packedSelected [0,3,4,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env4143 : List Nat := [2,4,8,1,32,1,128,4,512,1024,2048,1196,2730,1197,2178,2056,1028,2560,1025,2178,1196,681,648,515,2595,648,2216,1196,1029,2081,1672,544,5,0,1028,32]

theorem envBound4143 : H12AffineFastState.Bounded env4143 := by
  intro p hp
  have h : env4143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4142_4143 : H12AffineEnvironment.transform 12 2730 env4142 = env4143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2730 env4142 == env4143) = true)

theorem identity4143 : scanCanonicalize (H12AffineFastState.compose env4143 (packedSelected [0,1,2,6,7,8,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 130) := by decide +kernel

theorem selectedBound4143 : packedSelected [0,1,2,6,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env4144 : List Nat := [2,4,8,1,32,1,128,4,130,1024,2048,1196,2088,1197,2178,2056,1028,2178,1025,2178,1196,43,10,129,2209,10,2216,1196,1029,2081,1034,162,5,0,1028,32]

theorem envBound4144 : H12AffineFastState.Bounded env4144 := by
  intro p hp
  have h : env4144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4143_4144 : H12AffineEnvironment.transform 8 130 env4143 = env4144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 130 env4143 == env4144) = true)

theorem identity4144 : scanCanonicalize (H12AffineFastState.compose env4144 (packedSelected [3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound4144 : packedSelected [3,5,7] rootPS < 2^1333 := by decide +kernel

def env4145 : List Nat := [2,4,8,1,32,1,128,4,130,1024,33,1196,9,1197,163,41,1028,163,1025,163,1196,43,10,129,128,10,137,1196,1029,0,1034,162,5,0,1028,32]

theorem envBound4145 : H12AffineFastState.Bounded env4145 := by
  intro p hp
  have h : env4145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4144_4145 : H12AffineEnvironment.transform 10 33 env4144 = env4145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env4144 == env4145) = true)

theorem identity4145 : scanCanonicalize (H12AffineFastState.compose env4145 (packedSelected [0,3,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 172) := by decide +kernel

theorem selectedBound4145 : packedSelected [0,3,5,6] rootPS < 2^1333 := by decide +kernel

def env4146 : List Nat := [2,4,8,1,32,1,128,4,130,172,33,0,9,1,163,41,168,163,173,163,0,43,10,129,128,10,137,0,169,0,166,162,5,0,168,32]

theorem envBound4146 : H12AffineFastState.Bounded env4146 := by
  intro p hp
  have h : env4146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4145_4146 : H12AffineEnvironment.transform 9 172 env4145 = env4146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env4145 == env4146) = true)

theorem identity4146 : scanCanonicalize (H12AffineFastState.compose env4146 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound4146 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env4147 : List Nat := [2,4,8,1,32,1,3,4,1,47,33,0,9,1,32,41,43,32,46,32,0,43,10,2,3,10,10,0,42,0,37,33,5,0,43,32]

theorem envBound4147 : H12AffineFastState.Bounded env4147 := by
  intro p hp
  have h : env4147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4146_4147 : H12AffineEnvironment.transform 6 3 env4146 = env4147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env4146 == env4147) = true)

theorem identity4147 : scanCanonicalize (H12AffineFastState.compose env4147 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound4147 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env4148 : List Nat := [2,4,2,1,32,1,3,4,1,37,33,0,3,1,32,35,33,32,36,32,0,33,0,2,3,0,0,0,32,0,37,33,5,0,33,32]

theorem envBound4148 : H12AffineFastState.Bounded env4148 := by
  intro p hp
  have h : env4148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4147_4148 : H12AffineEnvironment.transform 2 2 env4147 = env4148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env4147 == env4148) = true)

theorem identity4148 : scanCanonicalize (H12AffineFastState.compose env4148 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound4148 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4149 : List Nat := [2,4,2,1,0,1,3,4,1,5,1,0,3,1,0,3,1,0,4,0,0,1,0,2,3,0,0,0,0,0,5,1,5,0,1,0]

theorem envBound4149 : H12AffineFastState.Bounded env4149 := by
  intro p hp
  have h : env4149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4148_4149 : H12AffineEnvironment.transform 4 0 env4148 = env4149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env4148 == env4149) = true)

theorem identity4149 : scanCanonicalize (H12AffineFastState.compose env4149 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound4149 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4150 : List Nat := [2,0,2,1,0,1,3,0,1,1,1,0,3,1,0,3,1,0,0,0,0,1,0,2,3,0,0,0,0,0,1,1,1,0,1,0]

theorem envBound4150 : H12AffineFastState.Bounded env4150 := by
  intro p hp
  have h : env4150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4149_4150 : H12AffineEnvironment.transform 1 0 env4149 = env4150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env4149 == env4150) = true)

def env4151 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1449,8192,16384,32768,65536,1029,262144,1025,32768,1449,4194304,4310274,41003,8329,4310274,320808,16385,16812,19849,74794,74134,257,17832,4236436,4310719]

theorem envBound4151 : H12AffineFastState.Bounded env4151 := by
  intro p hp
  have h : env4151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4120_4151 : H12AffineEnvironment.transform 11 1449 env4120 = env4151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1449 env4120 == env4151) = true)

theorem identity4151 : scanCanonicalize (H12AffineFastState.compose env4151 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 50319) := by decide +kernel

theorem selectedBound4151 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env4152 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1449,8192,16384,32768,50319,1029,262144,1025,32768,1449,4194304,4194701,41003,8329,4194701,320808,16385,16812,19849,57509,58649,257,17832,4236436,4194864]

theorem envBound4152 : H12AffineFastState.Bounded env4152 := by
  intro p hp
  have h : env4152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4151_4152 : H12AffineEnvironment.transform 15 50319 env4151 = env4152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50319 env4151 == env4152) = true)

def env4153 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1449,8192,16384,32768,50319,1029,262144,1025,32768,1449,4194304,4194701,41003,8329,4194701,320808,16385,16812,19849,57509,58633,257,17832,4236420,4194848]

theorem envBound4153 : H12AffineFastState.Bounded env4153 := by
  intro p hp
  have h : env4153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4152_4153 : H12AffineEnvironment.transform 3 0 env4152 = env4153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4152 == env4153) = true)

theorem identity4153 : scanCanonicalize (H12AffineFastState.compose env4153 (packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4153 : packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env4154 : List Nat := [2,4,8,0,32,0,41,256,512,1024,2048,1280,8192,16384,32768,50214,1029,262144,1025,32768,1280,4194304,4194596,41003,8224,4194596,320808,16385,16645,19744,57356,58633,257,17665,4236333,4194848]

theorem envBound4154 : H12AffineFastState.Bounded env4154 := by
  intro p hp
  have h : env4154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4153_4154 : H12AffineEnvironment.transform 6 41 env4153 = env4154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4153 == env4154) = true)

theorem identity4154 : scanCanonicalize (H12AffineFastState.compose env4154 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 19493) := by decide +kernel

theorem selectedBound4154 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env4155 : List Nat := [2,4,8,0,32,0,41,256,512,1024,2048,1280,8192,16384,32768,50214,1029,19493,1025,32768,1280,4194304,4194596,41003,8224,4194596,43277,16385,16645,19744,57356,58633,257,17665,4236333,4194848]

theorem envBound4155 : H12AffineFastState.Bounded env4155 := by
  intro p hp
  have h : env4155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4154_4155 : H12AffineEnvironment.transform 17 19493 env4154 = env4155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19493 env4154 == env4155) = true)

theorem identity4155 : scanCanonicalize (H12AffineFastState.compose env4155 (packedSelected [0,3,4,5,7,10,13,17,22] rootPS)) = affineNative (2^(21+1) ^^^ 41000) := by decide +kernel

theorem selectedBound4155 : packedSelected [0,3,4,5,7,10,13,17,22] rootPS < 2^1333 := by decide +kernel

def env4156 : List Nat := [2,4,8,0,32,0,41,256,512,1024,2048,1280,8192,16384,32768,50214,1029,19493,1025,32768,1280,41000,41228,41003,8224,41228,43277,16385,16645,19744,57356,58633,257,17665,1029,41480]

theorem envBound4156 : H12AffineFastState.Bounded env4156 := by
  intro p hp
  have h : env4156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4155_4156 : H12AffineEnvironment.transform 21 41000 env4155 = env4156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41000 env4155 == env4156) = true)

theorem identity4156 : scanCanonicalize (H12AffineFastState.compose env4156 (packedSelected [0,2,4,7,9,11,18] rootPS)) = affineNative (2^(13+1) ^^^ 1573) := by decide +kernel

theorem selectedBound4156 : packedSelected [0,2,4,7,9,11,18] rootPS < 2^1333 := by decide +kernel

def env4157 : List Nat := [2,4,8,0,32,0,41,256,512,1024,2048,1280,8192,1573,32768,33283,1029,2560,1025,32768,1280,41000,41228,41003,8224,41228,43277,1572,1824,2821,42537,41772,257,804,1029,41480]

theorem envBound4157 : H12AffineFastState.Bounded env4157 := by
  intro p hp
  have h : env4157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4156_4157 : H12AffineEnvironment.transform 13 1573 env4156 = env4157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1573 env4156 == env4157) = true)

theorem identity4157 : scanCanonicalize (H12AffineFastState.compose env4157 (packedSelected [1,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 8744) := by decide +kernel

theorem selectedBound4157 : packedSelected [1,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env4158 : List Nat := [2,4,8,0,32,0,41,256,512,1024,2048,1280,8192,1573,8744,8235,1029,2560,1025,8744,1280,512,804,515,8224,804,2853,1572,1824,2821,1025,260,257,804,1029,32]

theorem envBound4158 : H12AffineFastState.Bounded env4158 := by
  intro p hp
  have h : env4158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4157_4158 : H12AffineEnvironment.transform 14 8744 env4157 = env4158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8744 env4157 == env4158) = true)

theorem identity4158 : scanCanonicalize (H12AffineFastState.compose env4158 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4158 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env4159 : List Nat := [2,4,8,0,32,0,41,4,512,1024,2048,1028,8192,1573,8744,8235,1029,2560,1025,8744,1028,512,544,515,8224,544,2593,1572,1572,2561,1025,0,5,544,1029,32]

theorem envBound4159 : H12AffineFastState.Bounded env4159 := by
  intro p hp
  have h : env4159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4158_4159 : H12AffineEnvironment.transform 7 4 env4158 = env4159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4158 == env4159) = true)

theorem identity4159 : scanCanonicalize (H12AffineFastState.compose env4159 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1071) := by decide +kernel

theorem selectedBound4159 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4160 : List Nat := [2,4,8,0,32,0,41,4,512,1024,1071,1028,8192,1573,8744,8235,1029,1583,1025,8744,1028,512,544,515,8224,544,1550,1572,1572,1582,1025,0,5,544,1029,32]

theorem envBound4160 : H12AffineFastState.Bounded env4160 := by
  intro p hp
  have h : env4160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4159_4160 : H12AffineEnvironment.transform 10 1071 env4159 = env4160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1071 env4159 == env4160) = true)

theorem identity4160 : scanCanonicalize (H12AffineFastState.compose env4160 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound4160 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env4161 : List Nat := [2,4,8,0,10,0,3,4,512,1024,1029,1028,8192,1551,8706,8193,1029,1541,1025,8706,1028,512,522,515,8202,522,1550,1550,1550,1540,1025,0,5,522,1029,10]

theorem envBound4161 : H12AffineFastState.Bounded env4161 := by
  intro p hp
  have h : env4161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4160_4161 : H12AffineEnvironment.transform 4 10 env4160 = env4161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env4160 == env4161) = true)

theorem identity4161 : scanCanonicalize (H12AffineFastState.compose env4161 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(12+1) ^^^ 1549) := by decide +kernel

theorem selectedBound4161 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env4162 : List Nat := [2,4,8,0,10,0,3,4,512,1024,1029,1028,1549,1551,1039,1548,1029,1541,1025,1039,1028,512,522,515,1543,522,1550,1550,1550,1540,1025,0,5,522,1029,10]

theorem envBound4162 : H12AffineFastState.Bounded env4162 := by
  intro p hp
  have h : env4162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4161_4162 : H12AffineEnvironment.transform 12 1549 env4161 = env4162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1549 env4161 == env4162) = true)

theorem identity4162 : scanCanonicalize (H12AffineFastState.compose env4162 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound4162 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env4163 : List Nat := [2,4,8,0,10,0,3,4,512,4,1,0,521,523,11,520,1,513,5,11,0,512,522,515,515,522,522,522,522,512,5,0,5,522,1,10]

theorem envBound4163 : H12AffineFastState.Bounded env4163 := by
  intro p hp
  have h : env4163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4162_4163 : H12AffineEnvironment.transform 9 4 env4162 = env4163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env4162 == env4163) = true)

theorem identity4163 : scanCanonicalize (H12AffineFastState.compose env4163 (packedSelected [3,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound4163 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env4164 : List Nat := [2,4,2,0,0,0,3,4,512,4,1,0,515,513,1,514,1,513,5,1,0,512,512,515,515,512,512,512,512,512,5,0,5,512,1,0]

theorem envBound4164 : H12AffineFastState.Bounded env4164 := by
  intro p hp
  have h : env4164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4163_4164 : H12AffineEnvironment.transform 2 2 env4163 = env4164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env4163 == env4164) = true)

def env4165 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1449,8192,16384,32768,50319,1029,262144,1025,32768,1449,4194304,4194701,41003,8329,4194701,320808,16385,16812,19849,57509,58632,257,17832,4236421,4194849]

theorem envBound4165 : H12AffineFastState.Bounded env4165 := by
  intro p hp
  have h : env4165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4152_4165 : H12AffineEnvironment.transform 3 1 env4152 = env4165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env4152 == env4165) = true)

theorem identity4165 : scanCanonicalize (H12AffineFastState.compose env4165 (packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 8613) := by decide +kernel

theorem selectedBound4165 : packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env4166 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1449,8192,16384,8613,25898,1029,262144,1025,8613,1449,4194304,4194701,398,8329,4194701,279693,16385,16812,19849,16640,17581,257,17832,4195616,4194849]

theorem envBound4166 : H12AffineFastState.Bounded env4166 := by
  intro p hp
  have h : env4166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4165_4166 : H12AffineEnvironment.transform 14 8613 env4165 = env4166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8613 env4165 == env4166) = true)

theorem identity4166 : scanCanonicalize (H12AffineFastState.compose env4166 (packedSelected [0,3,5,7,9,10,13,20,21,22] rootPS)) = affineNative (2^(21+1) ^^^ 17444) := by decide +kernel

theorem selectedBound4166 : packedSelected [0,3,5,7,9,10,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env4167 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1449,8192,16384,8613,25898,1029,262144,1025,8613,1449,17444,17833,398,8329,17833,279693,16385,16812,19849,16640,17581,257,17832,16644,17925]

theorem envBound4167 : H12AffineFastState.Bounded env4167 := by
  intro p hp
  have h : env4167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4166_4167 : H12AffineEnvironment.transform 21 17444 env4166 = env4167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 17444 env4166 == env4167) = true)

theorem identity4167 : scanCanonicalize (H12AffineFastState.compose env4167 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound4167 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env4168 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1449,8192,16384,8613,25898,1029,2081,1025,8613,1449,17444,17833,398,8329,17833,19628,16385,16812,19849,16640,17581,257,17832,16644,17925]

theorem envBound4168 : H12AffineFastState.Bounded env4168 := by
  intro p hp
  have h : env4168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4167_4168 : H12AffineEnvironment.transform 17 2081 env4167 = env4168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env4167 == env4168) = true)

theorem identity4168 : scanCanonicalize (H12AffineFastState.compose env4168 (packedSelected [0,1,6,7,8,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 12170) := by decide +kernel

theorem selectedBound4168 : packedSelected [0,1,6,7,8,12,15] rootPS < 2^1333 := by decide +kernel

def env4169 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1449,8192,12170,8613,2720,1029,2081,1025,8613,1449,11182,10787,398,8329,10787,8998,12171,11814,8707,11914,11047,257,10786,11918,10639]

theorem envBound4169 : H12AffineFastState.Bounded env4169 := by
  intro p hp
  have h : env4169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4168_4169 : H12AffineEnvironment.transform 13 12170 env4168 = env4169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12170 env4168 == env4169) = true)

theorem identity4169 : scanCanonicalize (H12AffineFastState.compose env4169 (packedSelected [0,2,4,7,9,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 2219) := by decide +kernel

theorem selectedBound4169 : packedSelected [0,2,4,7,9,11,18] rootPS < 2^1333 := by decide +kernel

def env4170 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1449,2219,1825,2318,2720,1029,2081,1025,2318,1449,773,648,398,2082,648,2957,1824,1677,2728,1569,908,257,649,1573,292]

theorem envBound4170 : H12AffineFastState.Bounded env4170 := by
  intro p hp
  have h : env4170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4169_4170 : H12AffineEnvironment.transform 12 2219 env4169 = env4170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2219 env4169 == env4170) = true)

theorem identity4170 : scanCanonicalize (H12AffineFastState.compose env4170 (packedSelected [0,5,6,7,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4170 : packedSelected [0,5,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env4171 : List Nat := [2,4,8,1,32,1,128,5,512,1024,2048,1196,2219,1572,2059,2720,1029,2081,1025,2059,1196,512,648,139,2082,648,2696,1573,1677,2728,1569,649,4,649,1573,33]

theorem envBound4171 : H12AffineFastState.Bounded env4171 := by
  intro p hp
  have h : env4171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4170_4171 : H12AffineEnvironment.transform 7 5 env4170 = env4171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4170 == env4171) = true)

theorem identity4171 : scanCanonicalize (H12AffineFastState.compose env4171 (packedSelected [0,2,7] rootPS)) = affineNative (2^(8+1) ^^^ 168) := by decide +kernel

theorem selectedBound4171 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env4172 : List Nat := [2,4,8,1,32,1,128,5,168,1024,2048,1196,2219,1164,2059,2056,1029,2081,1025,2059,1196,168,32,139,2082,32,2080,1165,1061,2048,1161,33,4,33,1165,33]

theorem envBound4172 : H12AffineFastState.Bounded env4172 := by
  intro p hp
  have h : env4172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4171_4172 : H12AffineEnvironment.transform 8 168 env4171 = env4172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 168 env4171 == env4172) = true)

theorem identity4172 : scanCanonicalize (H12AffineFastState.compose env4172 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 172) := by decide +kernel

theorem selectedBound4172 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4173 : List Nat := [2,4,8,1,32,1,128,5,168,172,2048,0,2219,32,2059,2056,169,2081,173,2059,0,168,32,139,2082,32,2080,33,137,2048,37,33,4,33,33,33]

theorem envBound4173 : H12AffineFastState.Bounded env4173 := by
  intro p hp
  have h : env4173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4172_4173 : H12AffineEnvironment.transform 9 172 env4172 = env4173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env4172 == env4173) = true)

theorem identity4173 : scanCanonicalize (H12AffineFastState.compose env4173 (packedSelected [3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound4173 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env4174 : List Nat := [2,4,8,1,32,1,128,5,168,172,33,0,138,32,42,41,169,0,173,42,0,168,32,139,3,32,1,33,137,33,37,33,4,33,33,33]

theorem envBound4174 : H12AffineFastState.Bounded env4174 := by
  intro p hp
  have h : env4174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4173_4174 : H12AffineEnvironment.transform 10 33 env4173 = env4174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env4173 == env4174) = true)

theorem identity4174 : scanCanonicalize (H12AffineFastState.compose env4174 (packedSelected [6] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound4174 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4175 : List Nat := [2,4,2,1,32,1,128,5,162,166,33,0,128,32,32,35,163,0,167,32,0,162,32,129,3,32,1,33,131,33,37,33,4,33,33,33]

theorem envBound4175 : H12AffineFastState.Bounded env4175 := by
  intro p hp
  have h : env4175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4174_4175 : H12AffineEnvironment.transform 2 2 env4174 = env4175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env4174 == env4175) = true)

theorem identity4175 : scanCanonicalize (H12AffineFastState.compose env4175 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound4175 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4176 : List Nat := [2,4,2,1,32,1,35,5,1,5,33,0,35,32,32,35,0,0,4,32,0,1,32,34,3,32,1,33,32,33,37,33,4,33,33,33]

theorem envBound4176 : H12AffineFastState.Bounded env4176 := by
  intro p hp
  have h : env4176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4175_4176 : H12AffineEnvironment.transform 6 35 env4175 = env4176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env4175 == env4176) = true)

def env4177 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4096,4194304,4310275,41003,8329,4310274,323712,16385,16813,22561,74794,78910,257,20480,4236437,4310719]

theorem envBound4177 : H12AffineFastState.Bounded env4177 := by
  intro p hp
  have h : env4177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4119_4177 : H12AffineEnvironment.transform 5 17 env4119 = env4177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4119 == env4177) = true)

theorem identity4177 : scanCanonicalize (H12AffineFastState.compose env4177 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 115903) := by decide +kernel

theorem selectedBound4177 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4178 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4096,115903,444,41003,8329,445,323712,16385,16813,22561,74794,78910,257,20480,90154,512]

theorem envBound4178 : H12AffineFastState.Bounded env4178 := by
  intro p hp
  have h : env4178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4177_4178 : H12AffineEnvironment.transform 21 115903 env4177 = env4178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 115903 env4177 == env4178) = true)

theorem identity4178 : scanCanonicalize (H12AffineFastState.compose env4178 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 25914) := by decide +kernel

theorem selectedBound4178 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4179 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,25914,4525,262144,1025,32768,4096,41349,444,41003,8329,445,323712,16385,16813,22561,16656,20740,257,20480,1296,512]

theorem envBound4179 : H12AffineFastState.Bounded env4179 := by
  intro p hp
  have h : env4179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4178_4179 : H12AffineEnvironment.transform 15 25914 env4178 = env4179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25914 env4178 == env4179) = true)

theorem identity4179 : scanCanonicalize (H12AffineFastState.compose env4179 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29312) := by decide +kernel

theorem selectedBound4179 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4180 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29312,25914,4525,262144,1025,29312,4096,21253,444,21163,8329,445,262656,16385,16813,22561,16656,20740,257,20480,1296,512]

theorem envBound4180 : H12AffineFastState.Bounded env4180 := by
  intro p hp
  have h : env4180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4179_4180 : H12AffineEnvironment.transform 14 29312 env4179 = env4180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29312 env4179 == env4180) = true)

theorem identity4180 : scanCanonicalize (H12AffineFastState.compose env4180 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1465) := by decide +kernel

theorem selectedBound4180 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4181 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1465,8192,16384,26425,25914,1044,262144,1025,26425,1465,18108,444,18194,8329,445,262656,16385,16813,19864,16656,17597,257,17849,1296,512]

theorem envBound4181 : H12AffineFastState.Bounded env4181 := by
  intro p hp
  have h : env4181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4180_4181 : H12AffineEnvironment.transform 11 1465 env4180 = env4181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1465 env4180 == env4181) = true)

theorem identity4181 : scanCanonicalize (H12AffineFastState.compose env4181 (packedSelected [0,8,10,11,12,13,15,17,24,27,32] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4181 : packedSelected [0,8,10,11,12,13,15,17,24,27,32] rootPS < 2^1333 := by decide +kernel

def env4182 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1296,8192,16384,26425,25914,1044,262144,1025,26425,1296,17941,277,18194,8224,276,262656,16385,16644,19761,16656,17428,257,17680,1296,512]

theorem envBound4182 : H12AffineFastState.Bounded env4182 := by
  intro p hp
  have h : env4182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4181_4182 : H12AffineEnvironment.transform 6 41 env4181 = env4182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4181 == env4182) = true)

def env4183 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4097,4194304,8388608,41003,8329,8914000,849104,268435456,268435965,547953,598058,12644669,525568,545872,8479126,8914924]

theorem envBound4183 : H12AffineFastState.Bounded env4183 := by
  intro p hp
  have h : env4183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3921_4183 : H12AffineEnvironment.transform 20 4097 env3921 = env4183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env3921 == env4183) = true)

def env4184 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4097,4194304,8388608,41003,8329,8914000,849104,16384,16893,547953,598058,12644669,525568,545872,8479126,8914924]

theorem envBound4184 : H12AffineFastState.Bounded env4184 := by
  intro p hp
  have h : env4184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4183_4184 : H12AffineEnvironment.transform 27 16384 env4183 = env4184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16384 env4183 == env4184) = true)

def env4185 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4097,4194304,8388608,41003,8329,8388688,323792,16384,16893,22641,74794,12644669,256,20560,8479126,8389612]

theorem envBound4185 : H12AffineFastState.Bounded env4185 := by
  intro p hp
  have h : env4185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4184_4185 : H12AffineEnvironment.transform 18 1024 env4184 = env4185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env4184 == env4185) = true)

theorem identity4185 : scanCanonicalize (H12AffineFastState.compose env4185 (packedSelected [14] rootPS)) = affineNative (2^(15+1) ^^^ 25914) := by decide +kernel

theorem selectedBound4185 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4186 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,25914,4604,262144,1024,32768,4097,4194304,8388608,41003,8329,8388688,323792,16384,16893,22641,16656,12644669,256,20560,8389804,8389612]

theorem envBound4186 : H12AffineFastState.Bounded env4186 := by
  intro p hp
  have h : env4186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4185_4186 : H12AffineEnvironment.transform 15 25914 env4185 = env4186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25914 env4185 == env4186) = true)

def env4187 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,25914,4524,262144,1024,32768,4097,4194304,8388608,41003,8329,8388608,323712,16384,16813,22561,16656,12644669,256,20480,8389804,8389564]

theorem envBound4187 : H12AffineFastState.Bounded env4187 := by
  intro p hp
  have h : env4187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4186_4187 : H12AffineEnvironment.transform 5 16 env4186 = env4187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4186 == env4187) = true)

def env4188 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,25914,4524,262144,1024,32768,4097,4194304,4240784,41003,8329,4240784,323712,16384,16813,22561,16656,17581,256,20480,4239676,4240940]

theorem envBound4188 : H12AffineFastState.Bounded env4188 := by
  intro p hp
  have h : env4188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4187_4188 : H12AffineEnvironment.transform 22 4240784 env4187 = env4188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4240784 env4187 == env4188) = true)

theorem identity4188 : scanCanonicalize (H12AffineFastState.compose env4188 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 13729) := by decide +kernel

theorem selectedBound4188 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env4189 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,13729,25914,4524,262144,1024,13729,4097,4194304,4194353,5514,8329,4194353,279841,16384,16813,22561,16656,17581,256,20480,4195485,4195213]

theorem envBound4189 : H12AffineFastState.Bounded env4189 := by
  intro p hp
  have h : env4189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4188_4189 : H12AffineEnvironment.transform 14 13729 env4188 = env4189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13729 env4188 == env4189) = true)

def env4190 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,4096,8192,16384,13729,25898,4524,262144,1024,13729,4097,4194304,4194337,5514,8329,4194337,279841,16384,16813,22561,16640,17581,256,20480,4195469,4195213]

theorem envBound4190 : H12AffineFastState.Bounded env4190 := by
  intro p hp
  have h : env4190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4189_4190 : H12AffineEnvironment.transform 3 0 env4189 = env4190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4189 == env4190) = true)

theorem identity4190 : scanCanonicalize (H12AffineFastState.compose env4190 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 1197) := by decide +kernel

theorem selectedBound4190 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env4191 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1197,8192,16384,8460,25898,1281,262144,1024,8460,1196,4194304,4194337,295,8329,4194337,279841,16384,16813,19596,16640,17581,256,17581,4195469,4195213]

theorem envBound4191 : H12AffineFastState.Bounded env4191 := by
  intro p hp
  have h : env4191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4190_4191 : H12AffineEnvironment.transform 11 1197 env4190 = env4191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1197 env4190 == env4191) = true)

theorem identity4191 : scanCanonicalize (H12AffineFastState.compose env4191 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4191 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4192 : List Nat := [2,4,8,0,32,0,128,4,512,1024,2048,1197,8192,16384,8200,25646,1029,262144,1024,8200,1196,4194304,4194337,35,8329,4194337,279589,16384,16553,19596,16388,17581,4,17581,4195469,4194953]

theorem envBound4192 : H12AffineFastState.Bounded env4192 := by
  intro p hp
  have h : env4192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0