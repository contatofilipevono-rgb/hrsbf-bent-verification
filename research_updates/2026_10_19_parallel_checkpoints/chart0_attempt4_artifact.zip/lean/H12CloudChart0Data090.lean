import H12CloudChart0Data089

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity22749 : scanCanonicalize (H12AffineFastState.compose env22749 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 118035) := by decide +kernel

theorem selectedBound22749 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env22750 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58397,118035,16,41231,8193,16,164901,114966,45325,190520,75022,60697,256,98598,90122,513]

theorem envBound22750 : H12AffineFastState.Bounded env22750 := by
  intro p hp
  have h : env22750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22749_22750 : H12AffineEnvironment.transform 21 118035 env22749 = env22750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 118035 env22749 == env22750) = true)

theorem identity22750 : scanCanonicalize (H12AffineFastState.compose env22750 (packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound22750 : packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS < 2^1333 := by decide +kernel

def env22751 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,58397,118035,16,41231,8193,16,123966,114966,45325,100387,75022,60697,256,98598,90122,513]

theorem envBound22751 : H12AffineFastState.Bounded env22751 := by
  intro p hp
  have h : env22751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22750_22751 : H12AffineEnvironment.transform 16 90139 env22750 = env22751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env22750 == env22751) = true)

theorem identity22751 : scanCanonicalize (H12AffineFastState.compose env22751 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 11292) := by decide +kernel

theorem selectedBound22751 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env22752 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,11292,65536,90139,10280,1024,11293,18433,90383,16,3347,8193,16,84002,93450,7441,74815,75022,16645,256,77114,90122,513]

theorem envBound22752 : H12AffineFastState.Bounded env22752 := by
  intro p hp
  have h : env22752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22751_22752 : H12AffineEnvironment.transform 14 11292 env22751 = env22752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11292 env22751 == env22752) = true)

theorem identity22752 : scanCanonicalize (H12AffineFastState.compose env22752 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound22752 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env22753 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,11292,8203,16400,10280,1024,11293,18433,16644,16,3347,8193,16,26665,19713,7441,1076,1285,16645,256,3377,16385,513]

theorem envBound22753 : H12AffineFastState.Bounded env22753 := by
  intro p hp
  have h : env22753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22752_22753 : H12AffineEnvironment.transform 15 8203 env22752 = env22753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env22752 == env22753) = true)

theorem identity22753 : scanCanonicalize (H12AffineFastState.compose env22753 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound22753 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22754 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,4112,11292,8203,4096,10280,1024,11293,6161,4372,16,3347,8193,16,14393,7441,7441,1076,1285,4373,256,3377,4113,513]

theorem envBound22754 : H12AffineFastState.Bounded env22754 := by
  intro p hp
  have h : env22754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22753_22754 : H12AffineEnvironment.transform 13 4112 env22753 = env22754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env22753 == env22754) = true)

theorem identity22754 : scanCanonicalize (H12AffineFastState.compose env22754 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 5417) := by decide +kernel

theorem selectedBound22754 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env22755 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,5417,4112,6453,5410,4096,7425,1024,6452,6161,4372,16,3347,5416,16,3344,7441,7441,1076,1285,4373,256,3377,4113,513]

theorem envBound22755 : H12AffineFastState.Bounded env22755 := by
  intro p hp
  have h : env22755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22754_22755 : H12AffineEnvironment.transform 12 5417 env22754 = env22755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5417 env22754 == env22755) = true)

theorem identity22755 : scanCanonicalize (H12AffineFastState.compose env22755 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound22755 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env22756 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3328,2089,3344,1077,2082,3328,1,1024,1076,1297,3092,16,3347,2088,16,3344,17,17,1076,1285,3093,256,3377,3345,513]

theorem envBound22756 : H12AffineFastState.Bounded env22756 := by
  intro p hp
  have h : env22756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22755_22756 : H12AffineEnvironment.transform 11 3328 env22755 = env22756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env22755 == env22756) = true)

theorem identity22756 : scanCanonicalize (H12AffineFastState.compose env22756 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound22756 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env22757 : List Nat := [2,4,8,16,32,16,9,256,1,1024,2048,3328,2089,3344,1077,2082,3328,1,1024,1076,1297,3092,16,3347,2088,16,3344,17,17,1076,1285,3093,256,3377,3345,0]

theorem envBound22757 : H12AffineFastState.Bounded env22757 := by
  intro p hp
  have h : env22757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22756_22757 : H12AffineEnvironment.transform 8 1 env22756 = env22757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env22756 == env22757) = true)

theorem identity22757 : scanCanonicalize (H12AffineFastState.compose env22757 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound22757 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env22758 : List Nat := [2,4,8,16,32,16,9,256,1,273,2048,2065,2089,2049,292,2082,2065,1,273,293,0,2309,16,2050,2088,16,2049,17,17,293,20,2308,256,2080,2048,0]

theorem envBound22758 : H12AffineFastState.Bounded env22758 := by
  intro p hp
  have h : env22758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22757_22758 : H12AffineEnvironment.transform 9 273 env22757 = env22758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env22757 == env22758) = true)

theorem identity22758 : scanCanonicalize (H12AffineFastState.compose env22758 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound22758 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22759 : List Nat := [2,4,8,16,32,16,9,256,1,273,293,308,268,292,292,263,308,1,273,293,0,32,16,295,269,16,292,17,17,293,20,33,256,261,293,0]

theorem envBound22759 : H12AffineFastState.Bounded env22759 := by
  intro p hp
  have h : env22759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22758_22759 : H12AffineEnvironment.transform 10 293 env22758 = env22759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env22758 == env22759) = true)

theorem identity22759 : scanCanonicalize (H12AffineFastState.compose env22759 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound22759 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22760 : List Nat := [2,4,8,16,32,16,9,21,1,4,48,33,25,49,49,18,33,1,4,48,0,32,16,50,24,16,49,17,17,48,20,33,21,16,48,0]

theorem envBound22760 : H12AffineFastState.Bounded env22760 := by
  intro p hp
  have h : env22760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22759_22760 : H12AffineEnvironment.transform 7 21 env22759 = env22760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env22759 == env22760) = true)

def env22761 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58397,4194304,16,41231,8193,16,4409655,114966,45325,190521,75022,4268042,256,98598,90122,513]

theorem envBound22761 : H12AffineFastState.Bounded env22761 := by
  intro p hp
  have h : env22761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22748_22761 : H12AffineEnvironment.transform 17 10281 env22748 = env22761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env22748 == env22761) = true)

theorem identity22761 : scanCanonicalize (H12AffineFastState.compose env22761 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 246071) := by decide +kernel

theorem selectedBound22761 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env22762 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58397,246071,16,41231,8193,16,34816,114966,45325,190521,75022,188733,256,98598,90122,513]

theorem envBound22762 : H12AffineFastState.Bounded env22762 := by
  intro p hp
  have h : env22762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22761_22762 : H12AffineEnvironment.transform 21 246071 env22761 = env22762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 246071 env22761 == env22762) = true)

theorem identity22762 : scanCanonicalize (H12AffineFastState.compose env22762 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(16+1) ^^^ 114966) := by decide +kernel

theorem selectedBound22762 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env22763 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,114966,10281,1024,32769,58397,33,16,41231,8193,16,34816,114966,45325,76079,75022,73771,256,98598,90122,513]

theorem envBound22763 : H12AffineFastState.Bounded env22763 := by
  intro p hp
  have h : env22763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22762_22763 : H12AffineEnvironment.transform 16 114966 env22762 = env22763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114966 env22762 == env22763) = true)

theorem identity22763 : scanCanonicalize (H12AffineFastState.compose env22763 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound22763 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env22764 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,262,49168,10281,1024,32769,58397,33,16,41231,8193,16,34816,49168,45325,10281,9224,8493,256,32800,24844,513]

theorem envBound22764 : H12AffineFastState.Bounded env22764 := by
  intro p hp
  have h : env22764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22763_22764 : H12AffineEnvironment.transform 15 262 env22763 = env22764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env22763 == env22764) = true)

theorem identity22764 : scanCanonicalize (H12AffineFastState.compose env22764 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound22764 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22765 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8461,262,24861,10281,1024,8460,17680,33,16,2,8193,16,10509,24861,4096,10281,9224,8493,256,8493,24844,513]

theorem envBound22765 : H12AffineFastState.Bounded env22765 := by
  intro p hp
  have h : env22765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22764_22765 : H12AffineEnvironment.transform 14 8461 env22764 = env22765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env22764 == env22765) = true)

theorem identity22765 : scanCanonicalize (H12AffineFastState.compose env22765 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound22765 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22766 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,1,262,16401,2341,1024,0,17680,33,16,2,269,16,2049,16401,4096,2341,1284,33,256,33,16384,513]

theorem envBound22766 : H12AffineFastState.Bounded env22766 := by
  intro p hp
  have h : env22766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22765_22766 : H12AffineEnvironment.transform 12 268 env22765 = env22766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env22765 == env22766) = true)

theorem identity22766 : scanCanonicalize (H12AffineFastState.compose env22766 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound22766 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22767 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,17,268,16384,1,262,16401,2341,1024,0,17680,33,16,2,269,16,2049,16401,17,2341,1284,33,256,33,16384,513]

theorem envBound22767 : H12AffineFastState.Bounded env22767 := by
  intro p hp
  have h : env22767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22766_22767 : H12AffineEnvironment.transform 11 17 env22766 = env22767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env22766 == env22767) = true)

def env22768 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41230,8193,17,4677919,114967,45324,442384,75023,4268042,256,98599,90123,513]

theorem envBound22768 : H12AffineFastState.Bounded env22768 := by
  intro p hp
  have h : env22768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22747_22768 : H12AffineEnvironment.transform 5 17 env22747 = env22768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22747 == env22768) = true)

theorem identity22768 : scanCanonicalize (H12AffineFastState.compose env22768 (packedSelected [1,3,12,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound22768 : packedSelected [1,3,12,24,28,41] rootPS < 2^1333 := by decide +kernel

def env22769 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58397,4194304,16,41230,8193,17,4409654,114967,45324,190521,75023,4268042,256,98599,90123,513]

theorem envBound22769 : H12AffineFastState.Bounded env22769 := by
  intro p hp
  have h : env22769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22768_22769 : H12AffineEnvironment.transform 17 10281 env22768 = env22769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env22768 == env22769) = true)

theorem identity22769 : scanCanonicalize (H12AffineFastState.compose env22769 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound22769 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env22770 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,40971,131072,10281,1024,32769,58397,4194304,16,41230,8193,17,4385085,24860,45324,190521,34052,4227073,256,8492,49152,513]

theorem envBound22770 : H12AffineFastState.Bounded env22770 := by
  intro p hp
  have h : env22770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22769_22770 : H12AffineEnvironment.transform 15 40971 env22769 = env22770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env22769 == env22770) = true)

theorem identity22770 : scanCanonicalize (H12AffineFastState.compose env22770 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 147504) := by decide +kernel

theorem selectedBound22770 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env22771 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,40971,131072,10281,1024,32769,58397,147504,16,41230,8193,17,43277,24860,45324,190521,34052,180273,256,8492,49152,513]

theorem envBound22771 : H12AffineFastState.Bounded env22771 := by
  intro p hp
  have h : env22771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22770_22771 : H12AffineEnvironment.transform 21 147504 env22770 = env22771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147504 env22770 == env22771) = true)

theorem identity22771 : scanCanonicalize (H12AffineFastState.compose env22771 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound22771 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env22772 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,40971,24860,10281,1024,32769,58397,8492,16,41230,8193,17,43277,24860,45324,35109,34052,41261,256,8492,49152,513]

theorem envBound22772 : H12AffineFastState.Bounded env22772 := by
  intro p hp
  have h : env22772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22771_22772 : H12AffineEnvironment.transform 16 24860 env22771 = env22772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env22771 == env22772) = true)

def env22773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830977,25265169,23160257,257,27378860,27337992,25207750]

theorem envBound22773 : H12AffineFastState.Bounded env22773 := by
  intro p hp
  have h : env22773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22684_22773 : H12AffineEnvironment.transform 18 1025 env22684 = env22773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env22684 == env22773) = true)

theorem identity22773 : scanCanonicalize (H12AffineFastState.compose env22773 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 254097) := by decide +kernel

theorem selectedBound22773 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env22774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,254097,8328,64,12853393,2253853,10507600,8830977,8545408,6456656,257,10626109,10667417,8602455]

theorem envBound22774 : H12AffineFastState.Bounded env22774 := by
  intro p hp
  have h : env22774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22773_22774 : H12AffineEnvironment.transform 23 254097 env22773 = env22774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 254097 env22773 == env22774) = true)

def env22775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2257180,254097,8328,64,6705549,2253853,140364,2404637,2102684,6456656,257,21793,46213,2175563]

theorem envBound22775 : H12AffineFastState.Bounded env22775 := by
  intro p hp
  have h : env22775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22774_22775 : H12AffineEnvironment.transform 22 2257180 env22774 = env22775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2257180 env22774 == env22775) = true)

def env22776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441624,2257180,254097,8328,64,2157717,2253853,140364,2404637,2102684,2373704,257,21793,46213,2175563]

theorem envBound22776 : H12AffineFastState.Bounded env22776 := by
  intro p hp
  have h : env22776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22775_22776 : H12AffineEnvironment.transform 21 441624 env22775 = env22776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441624 env22775 == env22776) = true)

def env22777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441624,155996,254097,8328,64,64725,160861,140364,303453,1500,272392,257,21793,46213,74251]

theorem envBound22777 : H12AffineFastState.Bounded env22777 := by
  intro p hp
  have h : env22777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22776_22777 : H12AffineEnvironment.transform 20 4160 env22776 = env22777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env22776 == env22777) = true)

theorem identity22777 : scanCanonicalize (H12AffineFastState.compose env22777 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound22777 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,4160,392287,73755,41430,8328,64,64725,79130,91403,303453,1500,272392,257,21793,46213,74251]

theorem envBound22778 : H12AffineFastState.Bounded env22778 := by
  intro p hp
  have h : env22778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22777_22778 : H12AffineEnvironment.transform 16 82247 env22777 = env22778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env22777 == env22778) = true)

def env22779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10400,1025,32769,4160,120063,73755,41430,8328,64,64725,79130,91403,35325,1500,168,257,21793,46213,74251]

theorem envBound22779 : H12AffineFastState.Bounded env22779 := by
  intro p hp
  have h : env22779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22778_22779 : H12AffineEnvironment.transform 17 10400 env22778 = env22779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env22778 == env22779) = true)

theorem identity22779 : scanCanonicalize (H12AffineFastState.compose env22779 (packedSelected [0,2,3,6,8,10,12,14,23,24,26,27,28,31,32,38] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound22779 : packedSelected [0,2,3,6,8,10,12,14,23,24,26,27,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env22780 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,32768,65536,81970,10400,1025,32769,4160,120063,73755,41123,8328,64,64725,78959,91262,34952,1193,168,116,21588,46213,74251]

theorem envBound22780 : H12AffineFastState.Bounded env22780 := by
  intro p hp
  have h : env22780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22779_22780 : H12AffineEnvironment.transform 7 117 env22779 = env22780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env22779 == env22780) = true)

theorem identity22780 : scanCanonicalize (H12AffineFastState.compose env22780 (packedSelected [0,1,2,4,5,6,8,9,16,19,23,24,26,27,32] rootPS)) = affineNative (2^(15+1) ^^^ 29942) := by decide +kernel

theorem selectedBound22780 : packedSelected [0,1,2,4,5,6,8,9,16,19,23,24,26,27,32] rootPS < 2^1333 := by decide +kernel

def env22781 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,32768,29942,13508,10400,1025,32769,4160,40969,21741,41123,8328,64,64725,16537,4232,34952,1193,168,116,21588,46213,22269]

theorem envBound22781 : H12AffineFastState.Bounded env22781 := by
  intro p hp
  have h : env22781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22780_22781 : H12AffineEnvironment.transform 15 29942 env22780 = env22781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29942 env22780 == env22781) = true)

theorem identity22781 : scanCanonicalize (H12AffineFastState.compose env22781 (packedSelected [2,3,4,5,6,10,11,12,15,20,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound22781 : packedSelected [2,3,4,5,6,10,11,12,15,20,22,23] rootPS < 2^1333 := by decide +kernel

def env22782 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,40,16384,32768,21726,5356,2184,1025,32769,4160,32801,21741,32907,160,64,56573,16537,4232,34952,1193,168,116,21588,38061,22269]

theorem envBound22782 : H12AffineFastState.Bounded env22782 := by
  intro p hp
  have h : env22782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22781_22782 : H12AffineEnvironment.transform 12 40 env22781 = env22782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env22781 == env22782) = true)

theorem identity22782 : scanCanonicalize (H12AffineFastState.compose env22782 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound22782 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env22783 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,40,16384,136,21726,5356,2184,1025,137,4160,169,21741,3,160,64,23669,16537,4232,2048,1193,168,116,21588,5157,22269]

theorem envBound22783 : H12AffineFastState.Bounded env22783 := by
  intro p hp
  have h : env22783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22782_22783 : H12AffineEnvironment.transform 14 136 env22782 = env22783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env22782 == env22783) = true)

theorem identity22783 : scanCanonicalize (H12AffineFastState.compose env22783 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22783 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22784 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,16384,1,21591,5221,2049,1025,0,4160,32,21604,3,41,64,23669,16400,4097,2048,1056,33,116,21588,5157,22132]

theorem envBound22784 : H12AffineFastState.Bounded env22784 := by
  intro p hp
  have h : env22784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22783_22784 : H12AffineEnvironment.transform 6 9 env22783 = env22784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22783 == env22784) = true)

theorem identity22784 : scanCanonicalize (H12AffineFastState.compose env22784 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound22784 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22785 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,5236,1,35,5221,2049,1025,0,4160,32,16,3,41,64,2049,5220,4097,2048,1056,33,116,32,5157,512]

theorem envBound22785 : H12AffineFastState.Bounded env22785 := by
  intro p hp
  have h : env22785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22784_22785 : H12AffineEnvironment.transform 13 5236 env22784 = env22785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env22784 == env22785) = true)

theorem identity22785 : scanCanonicalize (H12AffineFastState.compose env22785 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22785 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22786 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,4096,9,5205,1,2,5188,2049,1025,0,4160,1,16,3,8,64,2049,5189,4097,2048,1025,0,85,1,5124,512]

theorem envBound22786 : H12AffineFastState.Bounded env22786 := by
  intro p hp
  have h : env22786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22785_22786 : H12AffineEnvironment.transform 4 1 env22785 = env22786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22785 == env22786) = true)

theorem identity22786 : scanCanonicalize (H12AffineFastState.compose env22786 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22786 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22787 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,9,5124,1,2,5141,2049,1025,0,4113,1,16,3,8,17,2049,5140,4097,2048,1025,0,4,1,5124,512]

theorem envBound22787 : H12AffineFastState.Bounded env22787 := by
  intro p hp
  have h : env22787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22786_22787 : H12AffineEnvironment.transform 5 17 env22786 = env22787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22786 == env22787) = true)

def env22788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10401,1025,32769,4160,120062,73755,41430,8328,64,64725,79130,91403,35324,1500,169,257,21793,46213,74251]

theorem envBound22788 : H12AffineFastState.Bounded env22788 := by
  intro p hp
  have h : env22788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22778_22788 : H12AffineEnvironment.transform 17 10401 env22778 = env22788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env22778 == env22788) = true)

theorem identity22788 : scanCanonicalize (H12AffineFastState.compose env22788 (packedSelected [0,2,3,6,8,10,12,14,23,24,26,27,28,31,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound22788 : packedSelected [0,2,3,6,8,10,12,14,23,24,26,27,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env22789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,82247,10401,1025,29909,4160,73770,73755,21762,8328,64,2049,79130,91403,32040,1500,169,257,21793,16465,74251]

theorem envBound22789 : H12AffineFastState.Bounded env22789 := by
  intro p hp
  have h : env22789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22788_22789 : H12AffineEnvironment.transform 14 29908 env22788 = env22789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env22788 == env22789) = true)

theorem identity22789 : scanCanonicalize (H12AffineFastState.compose env22789 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound22789 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env22790 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,343,16400,10401,1025,29909,4160,8573,8524,21762,8328,64,2049,13389,25692,32040,1500,169,257,21793,16465,9052]

theorem envBound22790 : H12AffineFastState.Bounded env22790 := by
  intro p hp
  have h : env22790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22789_22790 : H12AffineEnvironment.transform 15 343 env22789 = env22790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env22789 == env22790) = true)

theorem identity22790 : scanCanonicalize (H12AffineFastState.compose env22790 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound22790 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env22791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,21896,343,16400,2557,1025,21897,4160,33,16,21762,468,64,2049,5393,17664,23668,1500,169,257,21793,16465,512]

theorem envBound22791 : H12AffineFastState.Bounded env22791 := by
  intro p hp
  have h : env22791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22790_22791 : H12AffineEnvironment.transform 12 348 env22790 = env22791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env22790 == env22791) = true)

theorem identity22791 : scanCanonicalize (H12AffineFastState.compose env22791 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 205) := by decide +kernel

theorem selectedBound22791 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env22792 : List Nat := [2,4,8,16,32,64,128,256,512,205,2048,4096,348,16384,20805,343,16400,2557,204,20804,4160,33,16,20943,468,64,2049,4572,16845,22713,273,169,257,20972,16465,512]

theorem envBound22792 : H12AffineFastState.Bounded env22792 := by
  intro p hp
  have h : env22792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22791_22792 : H12AffineEnvironment.transform 9 205 env22791 = env22792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 205 env22791 == env22792) = true)

theorem identity22792 : scanCanonicalize (H12AffineFastState.compose env22792 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 2325) := by decide +kernel

theorem selectedBound22792 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env22793 : List Nat := [2,4,8,16,32,64,128,256,512,205,2048,2325,348,16384,18512,343,16400,2557,204,18513,2389,33,16,18650,468,64,2049,2249,16845,16812,273,169,257,18681,16465,512]

theorem envBound22793 : H12AffineFastState.Bounded env22793 := by
  intro p hp
  have h : env22793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22792_22793 : H12AffineEnvironment.transform 11 2325 env22792 = env22793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2325 env22792 == env22793) = true)

theorem identity22793 : scanCanonicalize (H12AffineFastState.compose env22793 (packedSelected [1,2,6,7,8,9,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 65) := by decide +kernel

theorem selectedBound22793 : packedSelected [1,2,6,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env22794 : List Nat := [2,4,8,16,32,64,128,256,512,205,2048,2325,348,65,2065,343,81,2557,204,2064,2389,33,16,2203,468,64,2049,2249,396,493,273,169,257,2232,16,512]

theorem envBound22794 : H12AffineFastState.Bounded env22794 := by
  intro p hp
  have h : env22794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22793_22794 : H12AffineEnvironment.transform 13 65 env22793 = env22794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 65 env22793 == env22794) = true)

theorem identity22794 : scanCanonicalize (H12AffineFastState.compose env22794 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound22794 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env22795 : List Nat := [2,4,8,16,32,64,128,116,512,205,2048,2145,40,65,2065,35,81,2185,204,2064,2081,33,16,2203,160,64,2049,2249,248,153,101,169,117,2232,16,512]

theorem envBound22795 : H12AffineFastState.Bounded env22795 := by
  intro p hp
  have h : env22795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22794_22795 : H12AffineEnvironment.transform 7 116 env22794 = env22795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env22794 == env22795) = true)

theorem identity22795 : scanCanonicalize (H12AffineFastState.compose env22795 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound22795 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env22796 : List Nat := [2,4,8,16,32,64,128,116,512,205,65,32,40,65,80,35,81,200,204,81,96,33,16,218,160,64,64,136,248,153,101,169,117,249,16,512]

theorem envBound22796 : H12AffineFastState.Bounded env22796 := by
  intro p hp
  have h : env22796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22795_22796 : H12AffineEnvironment.transform 10 65 env22795 = env22796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env22795 == env22796) = true)

theorem identity22796 : scanCanonicalize (H12AffineFastState.compose env22796 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22796 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22797 : List Nat := [2,4,8,16,32,64,8,116,512,69,65,32,40,65,80,35,81,64,68,81,96,33,16,82,40,64,64,0,112,17,101,33,117,113,16,512]

theorem envBound22797 : H12AffineFastState.Bounded env22797 := by
  intro p hp
  have h : env22797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22796_22797 : H12AffineEnvironment.transform 6 8 env22796 = env22797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22796 == env22797) = true)

theorem identity22797 : scanCanonicalize (H12AffineFastState.compose env22797 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22797 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22798 : List Nat := [2,4,8,16,0,64,8,84,512,69,65,0,8,65,80,3,81,64,68,81,64,1,16,82,8,64,64,0,80,17,69,1,85,81,16,512]

theorem envBound22798 : H12AffineFastState.Bounded env22798 := by
  intro p hp
  have h : env22798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22797_22798 : H12AffineEnvironment.transform 4 0 env22797 = env22798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22797 == env22798) = true)

theorem identity22798 : scanCanonicalize (H12AffineFastState.compose env22798 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 31) := by decide +kernel

theorem selectedBound22798 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env22799 : List Nat := [2,4,8,16,0,31,8,11,512,26,30,0,8,30,15,3,14,31,27,14,31,1,16,13,8,31,31,0,15,17,26,1,10,14,16,512]

theorem envBound22799 : H12AffineFastState.Bounded env22799 := by
  intro p hp
  have h : env22799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22798_22799 : H12AffineEnvironment.transform 5 31 env22798 = env22799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 31 env22798 == env22799) = true)

theorem identity22799 : scanCanonicalize (H12AffineFastState.compose env22799 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound22799 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env22800 : List Nat := [2,4,8,11,0,4,8,11,512,1,5,0,8,5,15,3,14,4,0,14,4,1,11,13,8,4,4,0,15,10,1,1,10,14,11,512]

theorem envBound22800 : H12AffineFastState.Bounded env22800 := by
  intro p hp
  have h : env22800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22799_22800 : H12AffineEnvironment.transform 3 11 env22799 = env22800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env22799 == env22800) = true)

def env22801 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441624,155997,254097,8328,64,64724,160860,140364,303452,1501,272393,257,21793,46213,74250]

theorem envBound22801 : H12AffineFastState.Bounded env22801 := by
  intro p hp
  have h : env22801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22776_22801 : H12AffineEnvironment.transform 20 4161 env22776 = env22801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env22776 == env22801) = true)

theorem identity22801 : scanCanonicalize (H12AffineFastState.compose env22801 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound22801 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22802 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,4161,441624,155997,144463,8328,64,64724,160860,140364,303452,1501,272393,257,21793,46213,63188]

theorem envBound22802 : H12AffineFastState.Bounded env22802 := by
  intro p hp
  have h : env22802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22801_22802 : H12AffineEnvironment.transform 15 54494 env22801 = env22802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env22801 == env22802) = true)

def env22803 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,262144,1025,32769,4113,441624,155917,144415,8328,16,64644,160780,140316,303372,1421,272393,257,21793,46213,63108]

theorem envBound22803 : H12AffineFastState.Bounded env22803 := by
  intro p hp
  have h : env22803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22802_22803 : H12AffineEnvironment.transform 5 16 env22802 = env22803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22802 == env22803) = true)

theorem identity22803 : scanCanonicalize (H12AffineFastState.compose env22803 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 171061) := by decide +kernel

theorem selectedBound22803 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env22804 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,171061,1025,32769,4113,8493,155917,144415,8328,16,64644,160780,140316,146745,1421,177212,257,21793,46213,63108]

theorem envBound22804 : H12AffineFastState.Bounded env22804 := by
  intro p hp
  have h : env22804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22803_22804 : H12AffineEnvironment.transform 17 171061 env22803 = env22804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171061 env22803 == env22804) = true)

theorem identity22804 : scanCanonicalize (H12AffineFastState.compose env22804 (packedSelected [1,3,4,5,7,8,9,16,18,19,20,23,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound22804 : packedSelected [1,3,4,5,7,8,9,16,18,19,20,23,27,31] rootPS < 2^1333 := by decide +kernel

def env22805 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,49168,23589,1025,32769,4113,8493,41245,62479,8328,16,64644,46108,58380,64809,1421,29740,257,21793,46213,63108]

theorem envBound22805 : H12AffineFastState.Bounded env22805 := by
  intro p hp
  have h : env22805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22804_22805 : H12AffineEnvironment.transform 16 49168 env22804 = env22805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env22804 == env22805) = true)

theorem identity22805 : scanCanonicalize (H12AffineFastState.compose env22805 (packedSelected [1,5,8,17,24] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound22805 : packedSelected [1,5,8,17,24] rootPS < 2^1333 := by decide +kernel

def env22806 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8461,30083,24861,23589,1025,8460,4113,8493,16,21762,8328,16,23945,5393,17665,23588,1421,29740,257,21793,5512,22409]

theorem envBound22806 : H12AffineFastState.Bounded env22806 := by
  intro p hp
  have h : env22806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22805_22806 : H12AffineEnvironment.transform 14 8461 env22805 = env22806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env22805 == env22806) = true)

theorem identity22806 : scanCanonicalize (H12AffineFastState.compose env22806 (packedSelected [0,1,4,6,7,8,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 1457) := by decide +kernel

theorem selectedBound22806 : packedSelected [0,1,4,6,7,8,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env22807 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1457,16384,1212,20530,17580,23589,1025,1213,4113,1180,16,21762,1337,16,23945,5393,17665,23588,1421,20893,257,21793,5512,22409]

theorem envBound22807 : H12AffineFastState.Bounded env22807 := by
  intro p hp
  have h : env22807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22806_22807 : H12AffineEnvironment.transform 12 1457 env22806 = env22807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1457 env22806 == env22807) = true)

theorem identity22807 : scanCanonicalize (H12AffineFastState.compose env22807 (packedSelected [0,1,2,4,8,11,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound22807 : packedSelected [0,1,2,4,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env22808 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1457,5376,1212,1330,4524,2341,1025,1213,4113,1180,16,2,1337,16,2185,5393,4097,2340,1421,1181,257,33,5512,649]

theorem envBound22808 : H12AffineFastState.Bounded env22808 := by
  intro p hp
  have h : env22808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22807_22808 : H12AffineEnvironment.transform 13 5376 env22807 = env22808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env22807 == env22808) = true)

theorem identity22808 : scanCanonicalize (H12AffineFastState.compose env22808 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22808 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env22809 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,1336,5376,1077,1330,4389,2341,1025,1076,4113,1045,16,2,1337,16,2048,5393,4097,2340,1284,1044,257,33,5377,512]

theorem envBound22809 : H12AffineFastState.Bounded env22809 := by
  intro p hp
  have h : env22809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22808_22809 : H12AffineEnvironment.transform 6 9 env22808 = env22809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22808 == env22809) = true)

theorem identity22809 : scanCanonicalize (H12AffineFastState.compose env22809 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22809 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22810 : List Nat := [2,4,8,16,0,16,9,256,512,1024,2048,4096,1304,5376,1045,1298,4357,2309,1025,1044,4113,1045,16,2,1305,16,2048,5393,4097,2308,1284,1044,257,1,5377,512]

theorem envBound22810 : H12AffineFastState.Bounded env22810 := by
  intro p hp
  have h : env22810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22809_22810 : H12AffineEnvironment.transform 4 0 env22809 = env22810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22809 == env22810) = true)

theorem identity22810 : scanCanonicalize (H12AffineFastState.compose env22810 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound22810 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env22811 : List Nat := [2,4,8,16,0,16,9,256,512,1024,2048,3329,1304,2049,1045,1298,3076,2309,1025,1044,3344,1045,16,2,1305,16,2048,2064,3328,2308,1284,1044,257,1,2048,512]

theorem envBound22811 : H12AffineFastState.Bounded env22811 := by
  intro p hp
  have h : env22811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22810_22811 : H12AffineEnvironment.transform 11 3329 env22810 = env22811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env22810 == env22811) = true)

theorem identity22811 : scanCanonicalize (H12AffineFastState.compose env22811 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22811 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env22812 : List Nat := [2,4,8,16,0,16,9,4,512,1024,2048,3077,1052,2049,1045,1046,3076,2049,1025,1044,3092,1045,16,2,1053,16,2048,2064,3076,2048,1024,1044,5,1,2048,512]

theorem envBound22812 : H12AffineFastState.Bounded env22812 := by
  intro p hp
  have h : env22812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22811_22812 : H12AffineEnvironment.transform 7 4 env22811 = env22812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22811 == env22812) = true)

def env22813 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,262144,1025,32769,4112,441624,155916,144414,8328,17,64645,160781,140317,303373,1420,272393,257,21793,46213,63109]

theorem envBound22813 : H12AffineFastState.Bounded env22813 := by
  intro p hp
  have h : env22813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22802_22813 : H12AffineEnvironment.transform 5 17 env22802 = env22813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22802 == env22813) = true)

theorem identity22813 : scanCanonicalize (H12AffineFastState.compose env22813 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 157873) := by decide +kernel

theorem selectedBound22813 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env22814 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,157873,1025,32769,4112,54697,155916,144414,8328,17,64645,160781,140317,182716,1420,147640,257,21793,46213,63109]

theorem envBound22814 : H12AffineFastState.Bounded env22814 := by
  intro p hp
  have h : env22814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22813_22814 : H12AffineEnvironment.transform 17 157873 env22813 = env22814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157873 env22813 == env22814) = true)

theorem identity22814 : scanCanonicalize (H12AffineFastState.compose env22814 (packedSelected [0,3,5,8,9,16,17,18,19,20,22,23,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound22814 : packedSelected [0,3,5,8,9,16,17,18,19,20,22,23,26,27,28] rootPS < 2^1333 := by decide +kernel

def env22815 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,5528,32041,1025,32769,4112,54697,29844,8582,8328,17,64645,24981,12677,56356,1420,21792,257,21793,46213,63109]

theorem envBound22815 : H12AffineFastState.Bounded env22815 := by
  intro p hp
  have h : env22815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22814_22815 : H12AffineEnvironment.transform 16 5528 env22814 = env22815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env22814 == env22815) = true)

theorem identity22815 : scanCanonicalize (H12AffineFastState.compose env22815 (packedSelected [3,5,9,10,11,14,15,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29828) := by decide +kernel

theorem selectedBound22815 : packedSelected [3,5,9,10,11,14,15,16,20,22] rootPS < 2^1333 := by decide +kernel

def env22816 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,8203,5528,32041,1025,29829,4112,8493,29844,8582,8328,17,2049,24981,12677,10400,1420,21792,257,21793,16385,513]

theorem envBound22816 : H12AffineFastState.Bounded env22816 := by
  intro p hp
  have h : env22816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22815_22816 : H12AffineEnvironment.transform 14 29828 env22815 = env22816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29828 env22815 == env22816) = true)

theorem identity22816 : scanCanonicalize (H12AffineFastState.compose env22816 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22816 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env22817 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29708,8203,5392,32041,1025,29709,4112,8493,29724,8462,8192,17,2049,24861,12557,10280,1284,21792,257,21793,16385,513]

theorem envBound22817 : H12AffineFastState.Bounded env22817 := by
  intro p hp
  have h : env22817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22816_22817 : H12AffineEnvironment.transform 6 8 env22816 = env22817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22816 == env22817) = true)

theorem identity22817 : scanCanonicalize (H12AffineFastState.compose env22817 (packedSelected [11,12] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound22817 : packedSelected [11,12] rootPS < 2^1333 := by decide +kernel

def env22818 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13324,0,8203,5392,2341,1025,1,4112,8493,16,8462,8192,17,2049,5393,12557,10280,1284,8492,257,8493,13325,513]

theorem envBound22818 : H12AffineFastState.Bounded env22818 := by
  intro p hp
  have h : env22818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22817_22818 : H12AffineEnvironment.transform 13 13324 env22817 = env22818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env22817 == env22818) = true)

theorem identity22818 : scanCanonicalize (H12AffineFastState.compose env22818 (packedSelected [1,2,3,5,7,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound22818 : packedSelected [1,2,3,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env22819 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,13324,0,8203,5173,2048,1025,1,4112,8200,16,8235,8192,17,2049,5172,12328,10280,1057,8201,36,8200,13325,513]

theorem envBound22819 : H12AffineFastState.Bounded env22819 := by
  intro p hp
  have h : env22819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22818_22819 : H12AffineEnvironment.transform 7 37 env22818 = env22819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env22818 == env22819) = true)

theorem identity22819 : scanCanonicalize (H12AffineFastState.compose env22819 (packedSelected [11] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound22819 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env22820 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,4096,8192,12345,0,8203,4096,2048,52,1,4112,8200,16,8235,8192,17,2049,4097,12328,10280,20,8201,36,8200,12344,513]

theorem envBound22820 : H12AffineFastState.Bounded env22820 := by
  intro p hp
  have h : env22820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22819_22820 : H12AffineEnvironment.transform 9 53 env22819 = env22820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env22819 == env22820) = true)

theorem identity22820 : scanCanonicalize (H12AffineFastState.compose env22820 (packedSelected [2,14] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound22820 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env22821 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,4096,40,4113,0,35,4096,2048,52,1,4112,32,16,3,40,17,2049,4097,4096,2048,20,33,36,32,4112,513]

theorem envBound22821 : H12AffineFastState.Bounded env22821 := by
  intro p hp
  have h : env22821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22820_22821 : H12AffineEnvironment.transform 12 40 env22820 = env22821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env22820 == env22821) = true)

theorem identity22821 : scanCanonicalize (H12AffineFastState.compose env22821 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2580) := by decide +kernel

theorem selectedBound22821 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22822 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,2580,40,2565,0,35,2580,2048,52,1,2564,32,16,3,40,17,2049,2581,2580,2048,20,33,36,32,2564,513]

theorem envBound22822 : H12AffineFastState.Bounded env22822 := by
  intro p hp
  have h : env22822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22821_22822 : H12AffineEnvironment.transform 11 2580 env22821 = env22822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2580 env22821 == env22822) = true)

theorem identity22822 : scanCanonicalize (H12AffineFastState.compose env22822 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 546) := by decide +kernel

theorem selectedBound22822 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22823 : List Nat := [2,4,8,16,32,17,8,37,512,53,546,54,40,39,0,35,54,546,52,1,38,32,16,3,40,17,547,55,54,546,20,33,36,32,38,513]

theorem envBound22823 : H12AffineFastState.Bounded env22823 := by
  intro p hp
  have h : env22823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22822_22823 : H12AffineEnvironment.transform 10 546 env22822 = env22823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 546 env22822 == env22823) = true)

theorem identity22823 : scanCanonicalize (H12AffineFastState.compose env22823 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound22823 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22824 : List Nat := [2,4,8,16,23,17,8,18,512,2,533,1,31,16,0,20,1,533,3,1,17,23,16,3,31,17,532,0,1,533,20,22,19,23,17,513]

theorem envBound22824 : H12AffineFastState.Bounded env22824 := by
  intro p hp
  have h : env22824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22823_22824 : H12AffineEnvironment.transform 4 23 env22823 = env22824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env22823 == env22824) = true)

theorem identity22824 : scanCanonicalize (H12AffineFastState.compose env22824 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound22824 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22825 : List Nat := [2,4,8,16,23,17,8,18,15,2,26,1,31,16,0,20,1,26,3,1,17,23,16,3,31,17,27,0,1,26,20,22,19,23,17,14]

theorem envBound22825 : H12AffineFastState.Bounded env22825 := by
  intro p hp
  have h : env22825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22824_22825 : H12AffineEnvironment.transform 8 15 env22824 = env22825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env22824 == env22825) = true)

theorem identity22825 : scanCanonicalize (H12AffineFastState.compose env22825 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound22825 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22826 : List Nat := [2,4,8,7,0,6,8,5,15,2,13,1,8,7,0,3,1,13,3,1,6,0,7,3,8,6,12,0,1,13,3,1,4,0,6,14]

theorem envBound22826 : H12AffineFastState.Bounded env22826 := by
  intro p hp
  have h : env22826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22825_22826 : H12AffineEnvironment.transform 3 7 env22825 = env22826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env22825 == env22826) = true)

theorem identity22826 : scanCanonicalize (H12AffineFastState.compose env22826 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound22826 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env22827 : List Nat := [2,3,8,0,0,1,8,2,8,2,10,1,8,0,0,3,1,10,3,1,1,0,0,3,8,1,11,0,1,10,3,1,3,0,1,9]

theorem envBound22827 : H12AffineFastState.Bounded env22827 := by
  intro p hp
  have h : env22827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22826_22827 : H12AffineEnvironment.transform 1 3 env22826 = env22827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env22826 == env22827) = true)

theorem identity22827 : scanCanonicalize (H12AffineFastState.compose env22827 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound22827 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env22828 : List Nat := [2,3,3,0,0,1,3,2,3,2,1,1,3,0,0,3,1,1,3,1,1,0,0,3,3,1,0,0,1,1,3,1,3,0,1,2]

theorem envBound22828 : H12AffineFastState.Bounded env22828 := by
  intro p hp
  have h : env22828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22827_22828 : H12AffineEnvironment.transform 2 3 env22827 = env22828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env22827 == env22828) = true)

def env22829 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441625,2257180,254097,8328,64,2157716,2253853,140364,2404637,2102684,2373705,257,21793,46213,2175563]

theorem envBound22829 : H12AffineFastState.Bounded env22829 := by
  intro p hp
  have h : env22829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22775_22829 : H12AffineEnvironment.transform 21 441625 env22775 = env22829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441625 env22775 == env22829) = true)

def env22830 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441625,155996,254097,8328,64,64724,160861,140364,303453,1500,272393,257,21793,46213,74251]

theorem envBound22830 : H12AffineFastState.Bounded env22830 := by
  intro p hp
  have h : env22830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22829_22830 : H12AffineEnvironment.transform 20 4160 env22829 = env22830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env22829 == env22830) = true)

theorem identity22830 : scanCanonicalize (H12AffineFastState.compose env22830 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound22830 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4160,441625,155996,180379,8328,64,64724,160861,140364,303453,1500,272393,257,21793,46213,513]

theorem envBound22831 : H12AffineFastState.Bounded env22831 := by
  intro p hp
  have h : env22831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22830_22831 : H12AffineEnvironment.transform 15 8202 env22830 = env22831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env22830 == env22831) = true)

def env22832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1025,32769,4160,326921,8524,32907,8328,64,64724,13389,25692,303453,1500,272393,257,21793,46213,513]

theorem envBound22832 : H12AffineFastState.Bounded env22832 := by
  intro p hp
  have h : env22832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22831_22832 : H12AffineEnvironment.transform 16 16400 env22831 = env22832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env22831 == env22832) = true)

theorem identity22832 : scanCanonicalize (H12AffineFastState.compose env22832 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound22832 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env22833 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,343,16400,262144,1025,32769,4160,318548,17,32907,469,64,56713,5392,17665,294912,1500,264532,257,21793,38360,513]

theorem envBound22833 : H12AffineFastState.Bounded env22833 := by
  intro p hp
  have h : env22833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22832_22833 : H12AffineEnvironment.transform 12 349 env22832 = env22833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env22832 == env22833) = true)

theorem identity22833 : scanCanonicalize (H12AffineFastState.compose env22833 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 56572) := by decide +kernel

theorem selectedBound22833 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env22834 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,343,16400,56572,1025,32769,4160,168,17,32907,469,64,56713,5392,17665,23804,1500,54696,257,21793,38360,513]

theorem envBound22834 : H12AffineFastState.Bounded env22834 := by
  intro p hp
  have h : env22834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22833_22834 : H12AffineEnvironment.transform 17 56572 env22833 = env22834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56572 env22833 == env22834) = true)

theorem identity22834 : scanCanonicalize (H12AffineFastState.compose env22834 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22834 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env22835 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,343,16400,56436,1025,32769,4160,32,17,32771,349,64,56577,5392,17665,23668,1364,54560,257,21793,38224,513]

theorem envBound22835 : H12AffineFastState.Bounded env22835 := by
  intro p hp
  have h : env22835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22834_22835 : H12AffineEnvironment.transform 6 8 env22834 = env22835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22834 == env22835) = true)

theorem identity22835 : scanCanonicalize (H12AffineFastState.compose env22835 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound22835 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22836 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,343,16400,2420,1025,21761,4160,32,17,21763,349,64,2049,5392,17665,23668,1364,32,257,21793,16464,513]

theorem envBound22836 : H12AffineFastState.Bounded env22836 := by
  intro p hp
  have h : env22836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22835_22836 : H12AffineEnvironment.transform 14 21760 env22835 = env22836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env22835 == env22836) = true)

theorem identity22836 : scanCanonicalize (H12AffineFastState.compose env22836 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound22836 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env22837 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5456,80,343,5440,2420,1025,81,4160,32,17,83,349,64,2049,5392,4177,2340,1364,32,257,113,5376,513]

theorem envBound22837 : H12AffineFastState.Bounded env22837 := by
  intro p hp
  have h : env22837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22836_22837 : H12AffineEnvironment.transform 13 5456 env22836 = env22837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env22836 == env22837) = true)

theorem identity22837 : scanCanonicalize (H12AffineFastState.compose env22837 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 1054) := by decide +kernel

theorem selectedBound22837 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env22838 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1054,349,334,80,343,350,2420,1025,81,1118,32,17,83,349,64,2049,270,1103,2340,1364,32,257,113,286,513]

theorem envBound22838 : H12AffineFastState.Bounded env22838 := by
  intro p hp
  have h : env22838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22837_22838 : H12AffineEnvironment.transform 11 1054 env22837 = env22838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1054 env22837 == env22838) = true)

theorem identity22838 : scanCanonicalize (H12AffineFastState.compose env22838 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 350) := by decide +kernel

theorem selectedBound22838 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env22839 : List Nat := [2,4,8,16,32,64,8,256,512,1024,350,1054,349,334,80,343,350,42,1025,81,1118,32,17,83,349,64,351,270,1103,122,1364,32,257,113,286,513]

theorem envBound22839 : H12AffineFastState.Bounded env22839 := by
  intro p hp
  have h : env22839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22838_22839 : H12AffineEnvironment.transform 10 350 env22838 = env22839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 350 env22838 == env22839) = true)

theorem identity22839 : scanCanonicalize (H12AffineFastState.compose env22839 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound22839 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env22840 : List Nat := [2,4,8,16,32,64,8,52,512,1024,106,1054,105,122,80,99,106,42,1025,81,1118,32,17,83,105,64,107,58,1103,122,1120,32,53,113,42,513]

theorem envBound22840 : H12AffineFastState.Bounded env22840 := by
  intro p hp
  have h : env22840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22839_22840 : H12AffineEnvironment.transform 7 52 env22839 = env22840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env22839 == env22840) = true)

theorem identity22840 : scanCanonicalize (H12AffineFastState.compose env22840 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound22840 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env22841 : List Nat := [2,4,8,16,32,64,8,52,512,53,106,43,105,122,80,99,106,42,52,81,107,32,17,83,105,64,107,58,122,122,85,32,53,113,42,513]

theorem envBound22841 : H12AffineFastState.Bounded env22841 := by
  intro p hp
  have h : env22841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22840_22841 : H12AffineEnvironment.transform 9 53 env22840 = env22841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env22840 == env22841) = true)

theorem identity22841 : scanCanonicalize (H12AffineFastState.compose env22841 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 26) := by decide +kernel

theorem selectedBound22841 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env22842 : List Nat := [2,4,8,16,32,26,8,52,512,53,48,43,51,32,10,57,48,42,52,11,49,32,17,9,51,26,49,58,32,32,15,32,53,43,42,513]

theorem envBound22842 : H12AffineFastState.Bounded env22842 := by
  intro p hp
  have h : env22842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22841_22842 : H12AffineEnvironment.transform 5 26 env22841 = env22842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 26 env22841 == env22842) = true)

theorem identity22842 : scanCanonicalize (H12AffineFastState.compose env22842 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound22842 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env22843 : List Nat := [2,4,4,16,32,22,4,52,512,53,48,39,51,32,6,53,48,38,52,7,49,32,17,5,51,22,49,54,32,32,3,32,53,39,38,513]

theorem envBound22843 : H12AffineFastState.Bounded env22843 := by
  intro p hp
  have h : env22843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22842_22843 : H12AffineEnvironment.transform 2 4 env22842 = env22843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env22842 == env22843) = true)

theorem identity22843 : scanCanonicalize (H12AffineFastState.compose env22843 (packedSelected [0,2,3,11] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound22843 : packedSelected [0,2,3,11] rootPS < 2^1333 := by decide +kernel

def env22844 : List Nat := [2,3,3,16,32,17,3,51,512,50,48,32,51,32,1,50,48,33,51,0,49,32,17,2,51,17,49,49,32,32,3,32,50,32,33,513]

theorem envBound22844 : H12AffineFastState.Bounded env22844 := by
  intro p hp
  have h : env22844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22843_22844 : H12AffineEnvironment.transform 1 3 env22843 = env22844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env22843 == env22844) = true)

theorem identity22844 : scanCanonicalize (H12AffineFastState.compose env22844 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22844 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22845 : List Nat := [2,3,3,1,32,0,3,34,512,35,33,32,34,32,1,35,33,33,34,0,32,32,0,2,34,0,32,32,32,32,3,32,35,32,33,513]

theorem envBound22845 : H12AffineFastState.Bounded env22845 := by
  intro p hp
  have h : env22845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22844_22845 : H12AffineEnvironment.transform 3 1 env22844 = env22845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22844 == env22845) = true)

theorem identity22845 : scanCanonicalize (H12AffineFastState.compose env22845 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 34) := by decide +kernel

theorem selectedBound22845 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22846 : List Nat := [2,3,3,1,32,0,3,34,34,35,33,32,34,32,1,35,33,33,34,0,32,32,0,2,34,0,32,32,32,32,3,32,35,32,33,35]

theorem envBound22846 : H12AffineFastState.Bounded env22846 := by
  intro p hp
  have h : env22846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22845_22846 : H12AffineEnvironment.transform 8 34 env22845 = env22846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 34 env22845 == env22846) = true)

theorem identity22846 : scanCanonicalize (H12AffineFastState.compose env22846 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22846 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22847 : List Nat := [2,3,3,1,0,0,3,2,2,3,1,0,2,0,1,3,1,1,2,0,0,0,0,2,2,0,0,0,0,0,3,0,3,0,1,3]

theorem envBound22847 : H12AffineFastState.Bounded env22847 := by
  intro p hp
  have h : env22847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22846_22847 : H12AffineEnvironment.transform 4 0 env22846 = env22847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22846 == env22847) = true)

def env22848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1025,32769,4160,326920,8525,32906,8328,64,64724,13388,25693,303453,1500,272393,257,21793,46213,513]

theorem envBound22848 : H12AffineFastState.Bounded env22848 := by
  intro p hp
  have h : env22848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22831_22848 : H12AffineEnvironment.transform 16 16401 env22831 = env22848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env22831 == env22848) = true)

def env22849 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1025,32769,4160,326920,8525,32770,8192,64,64604,13388,25693,303453,1364,272393,257,21793,46093,513]

theorem envBound22849 : H12AffineFastState.Bounded env22849 := by
  intro p hp
  have h : env22849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22848_22849 : H12AffineEnvironment.transform 6 8 env22848 = env22849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22848 == env22849) = true)

def env22850 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1025,32769,4160,326920,8525,32771,8193,64,64605,13388,25693,303453,1365,272393,257,21793,46092,513]

theorem envBound22850 : H12AffineFastState.Bounded env22850 := by
  intro p hp
  have h : env22850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22848_22850 : H12AffineEnvironment.transform 6 9 env22848 = env22850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22848 == env22850) = true)

theorem identity22850 : scanCanonicalize (H12AffineFastState.compose env22850 (packedSelected [0,14,27] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound22850 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env22851 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12620,32768,8202,12637,262144,1025,32769,4160,298052,8525,32771,8193,64,36113,13388,5393,303453,1365,272393,257,9325,46092,513]

theorem envBound22851 : H12AffineFastState.Bounded env22851 := by
  intro p hp
  have h : env22851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22850_22851 : H12AffineEnvironment.transform 13 12620 env22850 = env22851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env22850 == env22851) = true)

theorem identity22851 : scanCanonicalize (H12AffineFastState.compose env22851 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 1296) := by decide +kernel

theorem selectedBound22851 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env22852 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12620,1296,8202,12637,262144,1025,1297,4160,264532,8525,1299,8193,64,2049,13388,5393,271437,1365,272393,257,9325,12572,513]

theorem envBound22852 : H12AffineFastState.Bounded env22852 := by
  intro p hp
  have h : env22852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22851_22852 : H12AffineEnvironment.transform 14 1296 env22851 = env22852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1296 env22851 == env22852) = true)

theorem identity22852 : scanCanonicalize (H12AffineFastState.compose env22852 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound22852 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env22853 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12620,1296,8202,12637,10280,1025,1297,4160,8572,8525,1299,8193,64,2049,13388,5393,3173,1365,33,257,9325,12572,513]

theorem envBound22853 : H12AffineFastState.Bounded env22853 := by
  intro p hp
  have h : env22853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22852_22853 : H12AffineEnvironment.transform 17 10280 env22852 = env22853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env22852 == env22853) = true)

theorem identity22853 : scanCanonicalize (H12AffineFastState.compose env22853 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound22853 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env22854 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3108,8192,11624,1296,8202,11641,10280,1025,1297,3172,8572,8525,1299,8193,64,2049,10344,2357,3173,1365,33,257,9325,11576,513]

theorem envBound22854 : H12AffineFastState.Bounded env22854 := by
  intro p hp
  have h : env22854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22853_22854 : H12AffineEnvironment.transform 11 3108 env22853 = env22854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env22853 == env22854) = true)

theorem identity22854 : scanCanonicalize (H12AffineFastState.compose env22854 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound22854 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env22855 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2356,8192,10360,0,8202,10345,10280,273,1,2420,8572,8525,3,8193,64,2049,10344,2357,2421,69,33,257,8573,10280,513]

theorem envBound22855 : H12AffineFastState.Bounded env22855 := by
  intro p hp
  have h : env22855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22854_22855 : H12AffineEnvironment.transform 9 272 env22854 = env22855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env22854 == env22855) = true)

theorem identity22855 : scanCanonicalize (H12AffineFastState.compose env22855 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound22855 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22856 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2356,349,2341,0,343,2356,2421,273,1,2420,33,16,3,348,64,2049,2357,2357,2421,69,33,257,32,2421,513]

theorem envBound22856 : H12AffineFastState.Bounded env22856 := by
  intro p hp
  have h : env22856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22855_22856 : H12AffineEnvironment.transform 12 349 env22855 = env22856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env22855 == env22856) = true)

theorem identity22856 : scanCanonicalize (H12AffineFastState.compose env22856 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound22856 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22857 : List Nat := [2,4,8,16,17,64,9,256,512,272,2048,2309,349,2324,0,343,2309,2372,273,1,2373,16,16,3,348,64,2049,2308,2308,2372,69,16,257,17,2372,513]

theorem envBound22857 : H12AffineFastState.Bounded env22857 := by
  intro p hp
  have h : env22857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22856_22857 : H12AffineEnvironment.transform 4 17 env22856 = env22857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env22856 == env22857) = true)

theorem identity22857 : scanCanonicalize (H12AffineFastState.compose env22857 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound22857 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22858 : List Nat := [2,4,8,16,17,64,9,256,512,272,512,773,349,788,0,343,773,836,273,1,837,16,16,3,348,64,513,772,772,836,69,16,257,17,836,513]

theorem envBound22858 : H12AffineFastState.Bounded env22858 := by
  intro p hp
  have h : env22858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22857_22858 : H12AffineEnvironment.transform 10 512 env22857 = env22858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env22857 == env22858) = true)

theorem identity22858 : scanCanonicalize (H12AffineFastState.compose env22858 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound22858 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22859 : List Nat := [2,4,8,16,17,64,9,256,1,272,1,260,349,277,0,343,260,325,273,1,324,16,16,3,348,64,0,261,261,325,69,16,257,17,325,0]

theorem envBound22859 : H12AffineFastState.Bounded env22859 := by
  intro p hp
  have h : env22859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22858_22859 : H12AffineEnvironment.transform 8 1 env22858 = env22859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env22858 == env22859) = true)

theorem identity22859 : scanCanonicalize (H12AffineFastState.compose env22859 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound22859 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env22860 : List Nat := [2,4,8,16,17,64,9,84,1,68,1,80,9,65,0,3,80,17,69,1,16,16,16,3,8,64,0,81,81,17,69,16,85,17,17,0]

theorem envBound22860 : H12AffineFastState.Bounded env22860 := by
  intro p hp
  have h : env22860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22859_22860 : H12AffineEnvironment.transform 7 84 env22859 = env22860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env22859 == env22860) = true)

theorem identity22860 : scanCanonicalize (H12AffineFastState.compose env22860 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound22860 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22861 : List Nat := [2,4,2,16,17,64,3,84,1,68,1,80,3,65,0,3,80,17,69,1,16,16,16,3,2,64,0,81,81,17,69,16,85,17,17,0]

theorem envBound22861 : H12AffineFastState.Bounded env22861 := by
  intro p hp
  have h : env22861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22860_22861 : H12AffineEnvironment.transform 2 2 env22860 = env22861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env22860 == env22861) = true)

theorem identity22861 : scanCanonicalize (H12AffineFastState.compose env22861 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22861 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22862 : List Nat := [2,4,2,16,17,17,3,5,1,21,1,1,3,16,0,3,1,17,20,1,16,16,16,3,2,17,0,0,0,17,20,16,4,17,17,0]

theorem envBound22862 : H12AffineFastState.Bounded env22862 := by
  intro p hp
  have h : env22862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22861_22862 : H12AffineEnvironment.transform 5 17 env22861 = env22862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22861 == env22862) = true)

theorem identity22862 : scanCanonicalize (H12AffineFastState.compose env22862 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22862 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env22863 : List Nat := [2,4,2,0,1,1,3,5,1,5,1,1,3,0,0,3,1,1,4,1,0,0,0,3,2,1,0,0,0,1,4,0,4,1,1,0]

theorem envBound22863 : H12AffineFastState.Bounded env22863 := by
  intro p hp
  have h : env22863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22862_22863 : H12AffineEnvironment.transform 3 0 env22862 = env22863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22862 == env22863) = true)

def env22864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441625,155997,254097,8328,64,64725,160860,140364,303452,1501,272392,257,21793,46213,74250]

theorem envBound22864 : H12AffineFastState.Bounded env22864 := by
  intro p hp
  have h : env22864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22829_22864 : H12AffineEnvironment.transform 20 4161 env22829 = env22864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env22829 == env22864) = true)

theorem identity22864 : scanCanonicalize (H12AffineFastState.compose env22864 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 112018) := by decide +kernel

theorem selectedBound22864 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,112018,262144,1025,32769,4161,329867,120015,21763,8328,64,64725,115150,102878,303452,1501,272392,257,21793,46213,74250]

theorem envBound22865 : H12AffineFastState.Bounded env22865 := by
  intro p hp
  have h : env22865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22864_22865 : H12AffineEnvironment.transform 16 112018 env22864 = env22865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 112018 env22864 == env22865) = true)

def env22866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,112018,10400,1025,32769,4161,73771,120015,21763,8328,64,64725,115150,102878,35324,1501,168,257,21793,46213,74250]

theorem envBound22866 : H12AffineFastState.Bounded env22866 := by
  intro p hp
  have h : env22866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22865_22866 : H12AffineEnvironment.transform 17 10400 env22865 = env22866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env22865 == env22866) = true)

theorem identity22866 : scanCanonicalize (H12AffineFastState.compose env22866 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound22866 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env22867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54359,25029,10400,1025,32769,4161,62588,152,21763,8328,64,64725,5529,17801,35324,1501,168,257,21793,46213,63069]

theorem envBound22867 : H12AffineFastState.Bounded env22867 := by
  intro p hp
  have h : env22867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22866_22867 : H12AffineEnvironment.transform 15 54359 env22866 = env22867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env22866 == env22867) = true)

theorem identity22867 : scanCanonicalize (H12AffineFastState.compose env22867 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 21897) := by decide +kernel

theorem selectedBound22867 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env22868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21897,478,25029,10400,1025,21896,4161,8693,152,21763,8328,64,10588,5529,17801,23669,1501,168,257,21793,24844,9172]

theorem envBound22868 : H12AffineFastState.Bounded env22868 := by
  intro p hp
  have h : env22868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22867_22868 : H12AffineEnvironment.transform 14 21897 env22867 = env22868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21897 env22867 == env22868) = true)

theorem identity22868 : scanCanonicalize (H12AffineFastState.compose env22868 (packedSelected [1,2,3,4,6,7,8,10,11,12,14,15,18,22,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 5373) := by decide +kernel

theorem selectedBound22868 : packedSelected [1,2,3,4,6,7,8,10,11,12,14,15,18,22,24,27] rootPS < 2^1333 := by decide +kernel

def env22869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5373,372,478,13624,10400,1025,373,4161,8693,152,510,8328,64,10588,5529,4468,2184,1501,168,257,476,13809,9172]

theorem envBound22869 : H12AffineFastState.Bounded env22869 := by
  intro p hp
  have h : env22869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22868_22869 : H12AffineEnvironment.transform 13 5373 env22868 = env22869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5373 env22868 == env22869) = true)

theorem identity22869 : scanCanonicalize (H12AffineFastState.compose env22869 (packedSelected [2,4,9,11,16,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound22869 : packedSelected [2,4,9,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env22870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5373,372,478,5357,2421,1025,373,4161,32,152,510,349,64,2185,5529,4468,2184,1501,168,257,476,5156,513]

theorem envBound22870 : H12AffineFastState.Bounded env22870 := by
  intro p hp
  have h : env22870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22869_22870 : H12AffineEnvironment.transform 12 469 env22869 = env22870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env22869 == env22870) = true)

theorem identity22870 : scanCanonicalize (H12AffineFastState.compose env22870 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound22870 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env22871 : List Nat := [2,4,8,16,32,64,128,256,512,53,2048,4096,469,4296,372,478,4312,2421,52,373,4161,32,152,510,349,64,2185,4524,4468,2184,488,168,257,476,4113,513]

theorem envBound22871 : H12AffineFastState.Bounded env22871 := by
  intro p hp
  have h : env22871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22870_22871 : H12AffineEnvironment.transform 9 53 env22870 = env22871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env22870 == env22871) = true)

def env22872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,112018,10401,1025,32769,4161,73770,120015,21763,8328,64,64725,115150,102878,35325,1501,169,257,21793,46213,74250]

theorem envBound22872 : H12AffineFastState.Bounded env22872 := by
  intro p hp
  have h : env22872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22865_22872 : H12AffineEnvironment.transform 17 10401 env22865 = env22872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env22865 == env22872) = true)

theorem identity22872 : scanCanonicalize (H12AffineFastState.compose env22872 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound22872 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env22873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,65536,103494,2421,1025,32769,4161,66046,120015,21763,348,64,56577,115150,102878,35325,1501,169,257,21793,38225,66526]

theorem envBound22873 : H12AffineFastState.Bounded env22873 := by
  intro p hp
  have h : env22873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22872_22873 : H12AffineEnvironment.transform 12 468 env22872 = env22873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env22872 == env22873) = true)

theorem identity22873 : scanCanonicalize (H12AffineFastState.compose env22873 (packedSelected [2,3,4,5,6,7,10,11,12,14,16,17,18,20,22,27,38] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22873 : packedSelected [2,3,4,5,6,7,10,11,12,14,16,17,18,20,22,27,38] rootPS < 2^1333 := by decide +kernel

def env22874 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,65536,103494,2421,1025,32769,4161,65911,119878,21763,348,64,56577,115015,102743,35188,1364,32,257,21793,38225,66391]

theorem envBound22874 : H12AffineFastState.Bounded env22874 := by
  intro p hp
  have h : env22874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22873_22874 : H12AffineEnvironment.transform 6 9 env22873 = env22874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22873 == env22874) = true)

theorem identity22874 : scanCanonicalize (H12AffineFastState.compose env22874 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1296) := by decide +kernel

theorem selectedBound22874 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22875 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,1296,65536,69974,2421,1025,1297,4161,65911,86358,21763,348,64,22545,83031,70727,3172,1364,32,257,21793,4161,66391]

theorem envBound22875 : H12AffineFastState.Bounded env22875 := by
  intro p hp
  have h : env22875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22874_22875 : H12AffineEnvironment.transform 14 1296 env22874 = env22875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1296 env22874 == env22875) = true)

theorem identity22875 : scanCanonicalize (H12AffineFastState.compose env22875 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound22875 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22876 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,1296,1094,5392,2421,1025,1297,4161,1329,21776,21763,348,64,22545,16401,4097,3172,1364,32,257,21793,4161,1809]

theorem envBound22876 : H12AffineFastState.Bounded env22876 := by
  intro p hp
  have h : env22876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22875_22876 : H12AffineEnvironment.transform 15 1094 env22875 = env22876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env22875 == env22876) = true)

theorem identity22876 : scanCanonicalize (H12AffineFastState.compose env22876 (packedSelected [4,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound22876 : packedSelected [4,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env22877 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1296,1094,5392,2421,1025,1297,4161,1329,16,3,348,64,3345,5393,4097,3172,1364,32,257,33,4161,1809]

theorem envBound22877 : H12AffineFastState.Bounded env22877 := by
  intro p hp
  have h : env22877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22876_22877 : H12AffineEnvironment.transform 13 5376 env22876 = env22877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env22876 == env22877) = true)

theorem identity22877 : scanCanonicalize (H12AffineFastState.compose env22877 (packedSelected [2,6,11] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound22877 : packedSelected [2,6,11] rootPS < 2^1333 := by decide +kernel

def env22878 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3109,349,2341,1296,1094,2357,2421,1025,1297,3172,1329,16,3,348,64,3345,2356,3108,3172,1364,32,257,33,3172,1809]

theorem envBound22878 : H12AffineFastState.Bounded env22878 := by
  intro p hp
  have h : env22878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22877_22878 : H12AffineEnvironment.transform 11 3109 env22877 = env22878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env22877 == env22878) = true)

theorem identity22878 : scanCanonicalize (H12AffineFastState.compose env22878 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound22878 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env22879 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,3109,40,2128,1125,1094,2112,2048,1025,1124,3172,1092,16,3,41,64,3172,2113,3108,3172,1057,32,116,33,3172,1636]

theorem envBound22879 : H12AffineFastState.Bounded env22879 := by
  intro p hp
  have h : env22879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22878_22879 : H12AffineEnvironment.transform 7 117 env22878 = env22879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env22878 == env22879) = true)

theorem identity22879 : scanCanonicalize (H12AffineFastState.compose env22879 (packedSelected [0,1,2,3,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound22879 : packedSelected [0,1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env22880 : List Nat := [2,4,8,16,32,64,9,117,512,53,2048,2064,40,2128,80,115,2112,2048,52,81,2129,113,16,3,41,64,2129,2113,2065,2129,20,32,116,33,2129,593]

theorem envBound22880 : H12AffineFastState.Bounded env22880 := by
  intro p hp
  have h : env22880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22879_22880 : H12AffineEnvironment.transform 9 53 env22879 = env22880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env22879 == env22880) = true)

def env22881 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2257181,254097,8328,64,6705548,2253853,140365,2404636,2102685,6456656,257,21792,46212,2175562]

theorem envBound22881 : H12AffineFastState.Bounded env22881 := by
  intro p hp
  have h : env22881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22774_22881 : H12AffineEnvironment.transform 22 2257181 env22774 = env22881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2257181 env22774 == env22881) = true)

def env22882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441624,2257181,254097,8328,64,2157716,2253853,140365,2404636,2102685,2373704,257,21792,46212,2175562]

theorem envBound22882 : H12AffineFastState.Bounded env22882 := by
  intro p hp
  have h : env22882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22881_22882 : H12AffineEnvironment.transform 21 441624 env22881 = env22882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441624 env22881 == env22882) = true)

def env22883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441624,155997,254097,8328,64,64724,160861,140365,303452,1501,272392,257,21792,46212,74250]

theorem envBound22883 : H12AffineFastState.Bounded env22883 := by
  intro p hp
  have h : env22883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22882_22883 : H12AffineEnvironment.transform 20 4160 env22882 = env22883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env22882 == env22883) = true)

theorem identity22883 : scanCanonicalize (H12AffineFastState.compose env22883 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38296) := by decide +kernel

theorem selectedBound22883 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22884 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,4160,272512,62661,95497,8328,64,64724,57797,45525,303452,1501,272392,257,21792,46212,74250]

theorem envBound22884 : H12AffineFastState.Bounded env22884 := by
  intro p hp
  have h : env22884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22883_22884 : H12AffineEnvironment.transform 16 38296 env22883 = env22884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env22883 == env22884) = true)

theorem identity22884 : scanCanonicalize (H12AffineFastState.compose env22884 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound22884 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env22885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38296,262144,1025,32769,4160,272512,62661,21762,8328,64,64724,57797,45525,303452,1501,272392,257,21792,46212,513]

theorem envBound22885 : H12AffineFastState.Bounded env22885 := by
  intro p hp
  have h : env22885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22884_22885 : H12AffineEnvironment.transform 15 8203 env22884 = env22885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env22884 == env22885) = true)

theorem identity22885 : scanCanonicalize (H12AffineFastState.compose env22885 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound22885 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env22886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38296,2421,1025,32769,4160,8693,62661,21762,8328,64,64724,57797,45525,43049,1501,8573,257,21792,46212,513]

theorem envBound22886 : H12AffineFastState.Bounded env22886 := by
  intro p hp
  have h : env22886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22885_22886 : H12AffineEnvironment.transform 17 2421 env22885 = env22886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env22885 == env22886) = true)

theorem identity22886 : scanCanonicalize (H12AffineFastState.compose env22886 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 21896) := by decide +kernel

theorem selectedBound22886 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env22887 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21896,8203,16400,2421,1025,21897,4160,8693,8525,21762,8328,64,10588,13389,25693,32161,1501,8573,257,21792,24844,513]

theorem envBound22887 : H12AffineFastState.Bounded env22887 := by
  intro p hp
  have h : env22887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22886_22887 : H12AffineEnvironment.transform 14 21896 env22886 = env22887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21896 env22886 == env22887) = true)

theorem identity22887 : scanCanonicalize (H12AffineFastState.compose env22887 (packedSelected [2,3,5,6,8,28] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound22887 : packedSelected [2,3,5,6,8,28] rootPS < 2^1333 := by decide +kernel

def env22888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,216,8203,5440,2421,1025,217,4160,8693,8525,82,8328,64,10588,13389,12557,10481,1501,8573,257,112,13404,513]

theorem envBound22888 : H12AffineFastState.Bounded env22888 := by
  intro p hp
  have h : env22888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22887_22888 : H12AffineEnvironment.transform 13 5456 env22887 = env22888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env22887 == env22888) = true)

theorem identity22888 : scanCanonicalize (H12AffineFastState.compose env22888 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound22888 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env22889 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,5456,1,8203,5440,2421,1025,0,4160,8492,8525,82,8273,64,10588,13389,12557,10280,1284,8573,257,112,13404,513]

theorem envBound22889 : H12AffineFastState.Bounded env22889 := by
  intro p hp
  have h : env22889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22888_22889 : H12AffineEnvironment.transform 6 89 env22888 = env22889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env22888 == env22889) = true)

theorem identity22889 : scanCanonicalize (H12AffineFastState.compose env22889 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound22889 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22890 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5456,1,263,5440,2421,1025,0,4160,32,65,82,349,64,2128,5441,4097,2340,1284,113,257,112,5456,513]

theorem envBound22890 : H12AffineFastState.Bounded env22890 := by
  intro p hp
  have h : env22890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22889_22890 : H12AffineEnvironment.transform 12 268 env22889 = env22890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env22889 == env22890) = true)

theorem identity22890 : scanCanonicalize (H12AffineFastState.compose env22890 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3408) := by decide +kernel

theorem selectedBound22890 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env22891 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,3408,268,2048,1,263,2064,2421,1025,0,3344,32,65,82,349,64,2128,2065,3409,2340,1284,113,257,112,2048,513]

theorem envBound22891 : H12AffineFastState.Bounded env22891 := by
  intro p hp
  have h : env22891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22890_22891 : H12AffineEnvironment.transform 11 3408 env22890 = env22891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3408 env22890 == env22891) = true)

theorem identity22891 : scanCanonicalize (H12AffineFastState.compose env22891 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound22891 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env22892 : List Nat := [2,4,8,16,32,64,89,256,512,52,2048,2404,268,2048,1,263,2064,2421,53,0,2340,32,65,82,349,64,2128,2065,2405,2340,304,113,257,112,2048,513]

theorem envBound22892 : H12AffineFastState.Bounded env22892 := by
  intro p hp
  have h : env22892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22891_22892 : H12AffineEnvironment.transform 9 52 env22891 = env22892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env22891 == env22892) = true)

theorem identity22892 : scanCanonicalize (H12AffineFastState.compose env22892 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound22892 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env22893 : List Nat := [2,4,8,16,32,64,89,256,512,52,372,16,268,372,1,263,356,1,53,0,80,32,65,82,349,64,292,357,17,80,304,113,257,112,372,513]

theorem envBound22893 : H12AffineFastState.Bounded env22893 := by
  intro p hp
  have h : env22893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22892_22893 : H12AffineEnvironment.transform 10 372 env22892 = env22893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env22892 == env22893) = true)

theorem identity22893 : scanCanonicalize (H12AffineFastState.compose env22893 (packedSelected [2,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22893 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env22894 : List Nat := [2,4,8,16,32,17,8,256,512,52,293,16,268,293,1,263,309,1,53,0,1,32,16,3,268,17,292,308,17,1,304,32,257,33,293,513]

theorem envBound22894 : H12AffineFastState.Bounded env22894 := by
  intro p hp
  have h : env22894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22893_22894 : H12AffineEnvironment.transform 5 17 env22893 = env22894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22893 == env22894) = true)

theorem identity22894 : scanCanonicalize (H12AffineFastState.compose env22894 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound22894 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22895 : List Nat := [2,4,8,16,32,17,8,37,512,52,0,16,41,0,1,34,16,1,53,0,1,32,16,3,41,17,1,17,17,1,21,32,36,33,0,513]

theorem envBound22895 : H12AffineFastState.Bounded env22895 := by
  intro p hp
  have h : env22895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22894_22895 : H12AffineEnvironment.transform 7 37 env22894 = env22895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env22894 == env22895) = true)

theorem identity22895 : scanCanonicalize (H12AffineFastState.compose env22895 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22895 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22896 : List Nat := [2,4,8,0,32,1,8,37,512,36,0,0,41,0,1,34,0,1,37,0,1,32,0,3,41,1,1,1,1,1,5,32,36,33,0,513]

theorem envBound22896 : H12AffineFastState.Bounded env22896 := by
  intro p hp
  have h : env22896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22895_22896 : H12AffineEnvironment.transform 3 0 env22895 = env22896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22895 == env22896) = true)

theorem identity22896 : scanCanonicalize (H12AffineFastState.compose env22896 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound22896 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22897 : List Nat := [2,4,3,0,32,1,3,37,512,36,0,0,34,0,1,34,0,1,37,0,1,32,0,3,34,1,1,1,1,1,5,32,36,33,0,513]

theorem envBound22897 : H12AffineFastState.Bounded env22897 := by
  intro p hp
  have h : env22897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22896_22897 : H12AffineEnvironment.transform 2 3 env22896 = env22897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env22896 == env22897) = true)

def env22898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441624,155996,254097,8328,64,64725,160860,140365,303453,1500,272393,257,21792,46212,74251]

theorem envBound22898 : H12AffineFastState.Bounded env22898 := by
  intro p hp
  have h : env22898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22882_22898 : H12AffineEnvironment.transform 20 4161 env22882 = env22898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env22882 == env22898) = true)

def env22899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4161,169264,155996,254097,8328,64,64725,160860,140365,35189,1500,33,257,21792,46212,74251]

theorem envBound22899 : H12AffineFastState.Bounded env22899 := by
  intro p hp
  have h : env22899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22898_22899 : H12AffineEnvironment.transform 17 10280 env22898 = env22899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env22898 == env22899) = true)

def env22900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1025,32769,4161,21792,41292,73857,8328,64,64725,46156,58461,35189,1500,33,257,21792,46212,74251]

theorem envBound22900 : H12AffineFastState.Bounded env22900 := by
  intro p hp
  have h : env22900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22899_22900 : H12AffineEnvironment.transform 16 49168 env22899 = env22900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env22899 == env22900) = true)

theorem identity22900 : scanCanonicalize (H12AffineFastState.compose env22900 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound22900 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,49168,10280,1025,32769,4161,21792,41292,41311,8328,64,64725,46156,58461,35189,1500,33,257,21792,46212,41941]

theorem envBound22901 : H12AffineFastState.Bounded env22901 := by
  intro p hp
  have h : env22901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22900_22901 : H12AffineEnvironment.transform 15 33246 env22900 = env22901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env22900 == env22901) = true)

theorem identity22901 : scanCanonicalize (H12AffineFastState.compose env22901 (packedSelected [5,16,20,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 1221) := by decide +kernel

theorem selectedBound22901 : packedSelected [5,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env22902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1221,16384,32768,33246,49168,3309,1025,32769,4161,21792,34185,34202,1101,64,55312,37001,49304,35189,1500,33,257,21792,36929,34576]

theorem envBound22902 : H12AffineFastState.Bounded env22902 := by
  intro p hp
  have h : env22902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22901_22902 : H12AffineEnvironment.transform 12 1221 env22901 = env22902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1221 env22901 == env22902) = true)

theorem identity22902 : scanCanonicalize (H12AffineFastState.compose env22902 (packedSelected [4,7,9,11,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 1213) := by decide +kernel

theorem selectedBound22902 : packedSelected [4,7,9,11,23,27] rootPS < 2^1333 := by decide +kernel

def env22903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1221,16384,1213,1379,17581,3309,1025,1212,4161,21792,308,295,1101,64,23725,5172,17445,3528,1500,33,257,21792,5372,941]

theorem envBound22903 : H12AffineFastState.Bounded env22903 := by
  intro p hp
  have h : env22903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22902_22903 : H12AffineEnvironment.transform 14 1213 env22902 = env22903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1213 env22902 == env22903) = true)

theorem identity22903 : scanCanonicalize (H12AffineFastState.compose env22903 (packedSelected [0,3,7,9,10,11,14,18,19,20,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound22903 : packedSelected [0,3,7,9,10,11,14,18,19,20,22,24] rootPS < 2^1333 := by decide +kernel

def env22904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1221,5237,1213,1379,4312,3309,1025,1212,4161,341,308,295,1101,64,2264,5172,4176,3528,1500,33,257,341,5372,941]

theorem envBound22904 : H12AffineFastState.Bounded env22904 := by
  intro p hp
  have h : env22904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22903_22904 : H12AffineEnvironment.transform 13 5237 env22903 = env22904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env22903 == env22904) = true)

theorem identity22904 : scanCanonicalize (H12AffineFastState.compose env22904 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22904 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env22905 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1172,5156,1213,1330,4233,3260,1025,1212,4112,260,308,295,1052,17,2185,5172,4097,3481,1421,33,257,260,5293,941]

theorem envBound22905 : H12AffineFastState.Bounded env22905 := by
  intro p hp
  have h : env22905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22904_22905 : H12AffineEnvironment.transform 5 17 env22904 = env22905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22904 == env22905) = true)

theorem identity22905 : scanCanonicalize (H12AffineFastState.compose env22905 (packedSelected [0,1,6,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 3496) := by decide +kernel

theorem selectedBound22905 : packedSelected [0,1,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env22906 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3496,1172,2444,1213,1330,3361,3260,1025,1212,3512,260,308,295,1052,17,2185,2460,3497,3481,1421,33,257,260,2309,941]

theorem envBound22906 : H12AffineFastState.Bounded env22906 := by
  intro p hp
  have h : env22906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22905_22906 : H12AffineEnvironment.transform 11 3496 env22905 = env22906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3496 env22905 == env22906) = true)

theorem identity22906 : scanCanonicalize (H12AffineFastState.compose env22906 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound22906 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env22907 : List Nat := [2,4,8,16,32,17,128,140,512,1024,2048,3108,1172,2048,1213,1214,3245,3260,1025,1212,3124,136,184,171,1052,17,2185,2064,3109,3093,1025,33,141,136,2185,545]

theorem envBound22907 : H12AffineFastState.Bounded env22907 := by
  intro p hp
  have h : env22907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22906_22907 : H12AffineEnvironment.transform 7 140 env22906 = env22907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env22906 == env22907) = true)

theorem identity22907 : scanCanonicalize (H12AffineFastState.compose env22907 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound22907 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env22908 : List Nat := [2,4,8,16,32,17,128,140,48,1024,2048,3108,1172,2048,1213,1214,3245,3260,1025,1212,3124,136,184,171,1052,17,2185,2064,3109,3093,1025,33,141,136,2185,17]

theorem envBound22908 : H12AffineFastState.Bounded env22908 := by
  intro p hp
  have h : env22908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22907_22908 : H12AffineEnvironment.transform 8 48 env22907 = env22908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env22907 == env22908) = true)

theorem identity22908 : scanCanonicalize (H12AffineFastState.compose env22908 (packedSelected [1,6,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound22908 : packedSelected [1,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env22909 : List Nat := [2,4,8,16,32,17,128,140,48,1024,1213,153,1172,1213,1213,1214,16,1,1025,1212,137,136,184,171,1052,17,1076,1197,152,168,1025,33,141,136,1076,17]

theorem envBound22909 : H12AffineFastState.Bounded env22909 := by
  intro p hp
  have h : env22909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22908_22909 : H12AffineEnvironment.transform 10 1213 env22908 = env22909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env22908 == env22909) = true)

theorem identity22909 : scanCanonicalize (H12AffineFastState.compose env22909 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(9+1) ^^^ 172) := by decide +kernel

theorem selectedBound22909 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env22910 : List Nat := [2,4,8,16,32,17,128,140,48,172,17,153,56,17,17,18,16,1,173,16,137,136,184,171,176,17,152,1,152,168,173,33,141,136,152,17]

theorem envBound22910 : H12AffineFastState.Bounded env22910 := by
  intro p hp
  have h : env22910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22909_22910 : H12AffineEnvironment.transform 9 172 env22909 = env22910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env22909 == env22910) = true)

theorem identity22910 : scanCanonicalize (H12AffineFastState.compose env22910 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound22910 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22911 : List Nat := [2,4,8,16,32,17,25,21,48,53,17,0,56,17,17,18,16,1,52,16,16,17,33,50,41,17,1,1,1,49,52,33,20,17,1,17]

theorem envBound22911 : H12AffineFastState.Bounded env22911 := by
  intro p hp
  have h : env22911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22910_22911 : H12AffineEnvironment.transform 6 25 env22910 = env22911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env22910 == env22911) = true)

theorem identity22911 : scanCanonicalize (H12AffineFastState.compose env22911 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22911 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22912 : List Nat := [2,4,8,16,0,17,25,21,16,21,17,0,24,17,17,18,16,1,20,16,16,17,1,18,9,17,1,1,1,17,20,1,20,17,1,17]

theorem envBound22912 : H12AffineFastState.Bounded env22912 := by
  intro p hp
  have h : env22912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22911_22912 : H12AffineEnvironment.transform 4 0 env22911 = env22912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22911 == env22912) = true)

def env22913 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1025,32769,4161,21793,41293,73856,8328,64,64725,46157,58460,35189,1500,33,257,21792,46212,74251]

theorem envBound22913 : H12AffineFastState.Bounded env22913 := by
  intro p hp
  have h : env22913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22899_22913 : H12AffineEnvironment.transform 16 49169 env22899 = env22913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env22899 == env22913) = true)

theorem identity22913 : scanCanonicalize (H12AffineFastState.compose env22913 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound22913 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22914 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33111,49169,10280,1025,32769,4161,21793,41293,41431,8328,64,64725,46157,58460,35189,1500,33,257,21792,46212,41820]

theorem envBound22914 : H12AffineFastState.Bounded env22914 := by
  intro p hp
  have h : env22914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22913_22914 : H12AffineEnvironment.transform 15 33111 env22913 = env22914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env22913 == env22914) = true)

theorem identity22914 : scanCanonicalize (H12AffineFastState.compose env22914 (packedSelected [0,1,4,5,7,8,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound22914 : packedSelected [0,1,4,5,7,8,22,24] rootPS < 2^1333 := by decide +kernel

def env22915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8202,24908,10280,1025,8540,4161,21793,16,138,8328,64,23944,5392,17665,10280,1500,33,257,21792,5593,513]

theorem envBound22915 : H12AffineFastState.Bounded env22915 := by
  intro p hp
  have h : env22915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22914_22915 : H12AffineEnvironment.transform 14 8541 env22914 = env22915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env22914 == env22915) = true)

theorem identity22915 : scanCanonicalize (H12AffineFastState.compose env22915 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound22915 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env22916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,0,343,16401,2421,1025,1,4161,21793,16,138,469,64,23944,5392,17665,2421,1500,33,257,21792,5593,513]

theorem envBound22916 : H12AffineFastState.Bounded env22916 := by
  intro p hp
  have h : env22916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22915_22916 : H12AffineEnvironment.transform 12 349 env22915 = env22916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env22915 == env22916) = true)

theorem identity22916 : scanCanonicalize (H12AffineFastState.compose env22916 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound22916 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22917 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,16384,0,343,16401,2421,1025,1,4161,21793,16,82,269,64,23888,5392,17665,2421,1284,33,257,21792,5377,513]

theorem envBound22917 : H12AffineFastState.Bounded env22917 := by
  intro p hp
  have h : env22917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22916_22917 : H12AffineEnvironment.transform 6 88 env22916 = env22917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env22916 == env22917) = true)

theorem identity22917 : scanCanonicalize (H12AffineFastState.compose env22917 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound22917 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22918 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,4113,0,343,4096,2421,1025,1,4161,1328,16,82,269,64,3393,5392,5392,2421,1284,33,257,1329,5377,513]

theorem envBound22918 : H12AffineFastState.Bounded env22918 := by
  intro p hp
  have h : env22918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22917_22918 : H12AffineEnvironment.transform 13 4113 env22917 = env22918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env22917 == env22918) = true)

theorem identity22918 : scanCanonicalize (H12AffineFastState.compose env22918 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound22918 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env22919 : List Nat := [2,4,8,16,32,64,88,101,512,1024,2048,4096,56,4113,0,50,4096,2064,1025,1,4161,1109,16,82,104,64,3108,5237,5237,2064,1121,33,100,1108,5220,513]

theorem envBound22919 : H12AffineFastState.Bounded env22919 := by
  intro p hp
  have h : env22919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22918_22919 : H12AffineEnvironment.transform 7 101 env22918 = env22919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env22918 == env22919) = true)

theorem identity22919 : scanCanonicalize (H12AffineFastState.compose env22919 (packedSelected [1,2,4,7,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 555) := by decide +kernel

theorem selectedBound22919 : packedSelected [1,2,4,7,11,12] rootPS < 2^1333 := by decide +kernel

def env22920 : List Nat := [2,4,8,16,32,64,88,101,512,1024,2048,555,56,570,0,50,555,2064,1025,1,618,1109,16,82,104,64,3108,1630,1630,2064,1121,33,100,1108,1615,513]

theorem envBound22920 : H12AffineFastState.Bounded env22920 := by
  intro p hp
  have h : env22920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22919_22920 : H12AffineEnvironment.transform 11 555 env22919 = env22920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 555 env22919 == env22920) = true)

theorem identity22920 : scanCanonicalize (H12AffineFastState.compose env22920 (packedSelected [14] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound22920 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env22921 : List Nat := [2,4,8,16,32,64,88,101,512,37,2048,555,56,570,0,50,555,2064,36,1,618,112,16,82,104,64,2049,635,635,2064,68,33,100,113,618,513]

theorem envBound22921 : H12AffineFastState.Bounded env22921 := by
  intro p hp
  have h : env22921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22920_22921 : H12AffineEnvironment.transform 9 37 env22920 = env22921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env22920 == env22921) = true)

theorem identity22921 : scanCanonicalize (H12AffineFastState.compose env22921 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound22921 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env22922 : List Nat := [2,4,8,16,32,11,19,46,512,37,2048,555,56,570,0,50,555,2064,36,1,545,59,16,25,35,11,2049,560,560,2064,15,33,47,58,545,513]

theorem envBound22922 : H12AffineFastState.Bounded env22922 := by
  intro p hp
  have h : env22922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22921_22922 : H12AffineEnvironment.transform 5 11 env22921 = env22922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env22921 == env22922) = true)

theorem identity22922 : scanCanonicalize (H12AffineFastState.compose env22922 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound22922 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env22923 : List Nat := [2,4,8,16,32,11,19,46,512,37,522,555,56,570,0,50,555,538,36,1,545,59,16,25,35,11,523,560,560,538,15,33,47,58,545,513]

theorem envBound22923 : H12AffineFastState.Bounded env22923 := by
  intro p hp
  have h : env22923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22922_22923 : H12AffineEnvironment.transform 10 522 env22922 = env22923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env22922 == env22923) = true)

theorem identity22923 : scanCanonicalize (H12AffineFastState.compose env22923 (packedSelected [1,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 58) := by decide +kernel

theorem selectedBound22923 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env22924 : List Nat := [2,4,8,16,32,11,19,46,58,37,48,17,56,0,0,50,17,32,36,1,27,59,16,25,35,11,49,10,10,32,15,33,47,58,27,59]

theorem envBound22924 : H12AffineFastState.Bounded env22924 := by
  intro p hp
  have h : env22924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22923_22924 : H12AffineEnvironment.transform 8 58 env22923 = env22924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 58 env22923 == env22924) = true)

theorem identity22924 : scanCanonicalize (H12AffineFastState.compose env22924 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound22924 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env22925 : List Nat := [2,4,8,16,11,11,19,5,17,14,27,17,19,0,0,25,17,11,15,1,27,16,16,25,8,11,26,10,10,11,15,10,4,17,27,16]

theorem envBound22925 : H12AffineFastState.Bounded env22925 := by
  intro p hp
  have h : env22925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22924_22925 : H12AffineEnvironment.transform 4 11 env22924 = env22925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env22924 == env22925) = true)

theorem identity22925 : scanCanonicalize (H12AffineFastState.compose env22925 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound22925 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22926 : List Nat := [2,4,8,10,11,11,9,5,11,14,1,11,9,0,0,3,11,11,15,1,1,10,10,3,8,11,0,10,10,11,15,10,4,11,1,10]

theorem envBound22926 : H12AffineFastState.Bounded env22926 := by
  intro p hp
  have h : env22926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22925_22926 : H12AffineEnvironment.transform 3 10 env22925 = env22926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env22925 == env22926) = true)

theorem identity22926 : scanCanonicalize (H12AffineFastState.compose env22926 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound22926 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env22927 : List Nat := [2,4,3,1,0,0,2,5,0,5,1,0,2,0,0,3,0,0,4,1,1,1,1,3,3,0,0,1,1,0,4,1,4,0,1,1]

theorem envBound22927 : H12AffineFastState.Bounded env22927 := by
  intro p hp
  have h : env22927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22926_22927 : H12AffineEnvironment.transform 2 3 env22926 = env22927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env22926 == env22927) = true)

def env22928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4161,169265,155996,254097,8328,64,64725,160860,140365,35188,1500,32,257,21792,46212,74251]

theorem envBound22928 : H12AffineFastState.Bounded env22928 := by
  intro p hp
  have h : env22928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22898_22928 : H12AffineEnvironment.transform 17 10281 env22898 = env22928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env22898 == env22928) = true)

def env22929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1025,32769,4161,21793,41292,73857,8328,64,64725,46156,58461,35188,1500,32,257,21792,46212,74251]

theorem envBound22929 : H12AffineFastState.Bounded env22929 := by
  intro p hp
  have h : env22929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22928_22929 : H12AffineEnvironment.transform 16 49168 env22928 = env22929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env22928 == env22929) = true)

theorem identity22929 : scanCanonicalize (H12AffineFastState.compose env22929 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound22929 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,49168,10281,1025,32769,4161,21793,41292,3,8328,64,64725,46156,58461,35188,1500,32,257,21792,46212,649]

theorem envBound22930 : H12AffineFastState.Bounded env22930 := by
  intro p hp
  have h : env22930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22929_22930 : H12AffineEnvironment.transform 15 8322 env22929 = env22930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env22929 == env22930) = true)

theorem identity22930 : scanCanonicalize (H12AffineFastState.compose env22930 (packedSelected [9,10,12,16,18,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 13445) := by decide +kernel

theorem selectedBound22930 : packedSelected [9,10,12,16,18,19,22] rootPS < 2^1333 := by decide +kernel

def env22931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13445,32768,8322,46229,10281,1025,32769,4161,8612,41292,3,8328,64,34896,46156,37080,35188,1500,32,257,8613,46212,649]

theorem envBound22931 : H12AffineFastState.Bounded env22931 := by
  intro p hp
  have h : env22931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22930_22931 : H12AffineEnvironment.transform 13 13445 env22930 = env22931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13445 env22930 == env22931) = true)

theorem identity22931 : scanCanonicalize (H12AffineFastState.compose env22931 (packedSelected [0,1,4,7,8,9,11,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound22931 : packedSelected [0,1,4,7,8,9,11,16,19] rootPS < 2^1333 := by decide +kernel

def env22932 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13445,136,8322,13341,10281,1025,137,4161,8612,8644,3,8328,64,2264,13508,4176,2556,1500,32,257,8613,13324,649]

theorem envBound22932 : H12AffineFastState.Bounded env22932 := by
  intro p hp
  have h : env22932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22931_22932 : H12AffineEnvironment.transform 14 136 env22931 = env22932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env22931 == env22932) = true)

theorem identity22932 : scanCanonicalize (H12AffineFastState.compose env22932 (packedSelected [1,2,4,6,8,9,10,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22932 : packedSelected [1,2,4,6,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env22933 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,1,8203,13341,10281,1025,0,4161,8493,8525,3,8193,64,2129,13389,4176,2421,1365,32,257,8492,13324,512]

theorem envBound22933 : H12AffineFastState.Bounded env22933 := by
  intro p hp
  have h : env22933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22932_22933 : H12AffineEnvironment.transform 6 9 env22932 = env22933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22932 == env22933) = true)

theorem identity22933 : scanCanonicalize (H12AffineFastState.compose env22933 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22933 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22934 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,8192,13324,1,8203,13341,10248,1025,0,4161,8460,8525,3,8193,64,2129,13389,4176,2388,1365,1,257,8461,13324,512]

theorem envBound22934 : H12AffineFastState.Bounded env22934 := by
  intro p hp
  have h : env22934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22933_22934 : H12AffineEnvironment.transform 4 1 env22933 = env22934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22933 == env22934) = true)

theorem identity22934 : scanCanonicalize (H12AffineFastState.compose env22934 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound22934 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22935 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,349,5457,1,342,5440,2389,1025,0,4161,81,16,3,348,64,2129,5392,4176,2388,1365,1,257,80,5457,512]

theorem envBound22935 : H12AffineFastState.Bounded env22935 := by
  intro p hp
  have h : env22935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22934_22935 : H12AffineEnvironment.transform 12 349 env22934 = env22935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env22934 == env22935) = true)

theorem identity22935 : scanCanonicalize (H12AffineFastState.compose env22935 (packedSelected [2,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound22935 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env22936 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,4096,9,5125,1,2,5140,2049,1025,0,4161,81,16,3,8,64,2129,5188,4176,2048,1025,1,85,80,5125,512]

theorem envBound22936 : H12AffineFastState.Bounded env22936 := by
  intro p hp
  have h : env22936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22935_22936 : H12AffineEnvironment.transform 7 84 env22935 = env22936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env22935 == env22936) = true)

def env22937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1025,32769,4161,21792,41293,73856,8328,64,64725,46157,58460,35188,1500,32,257,21792,46212,74251]

theorem envBound22937 : H12AffineFastState.Bounded env22937 := by
  intro p hp
  have h : env22937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22928_22937 : H12AffineEnvironment.transform 16 49169 env22928 = env22937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env22928 == env22937) = true)

theorem identity22937 : scanCanonicalize (H12AffineFastState.compose env22937 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound22937 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49169,10281,1025,32769,4161,21792,41293,138,8328,64,64725,46157,58460,35188,1500,32,257,21792,46212,513]

theorem envBound22938 : H12AffineFastState.Bounded env22938 := by
  intro p hp
  have h : env22938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22937_22938 : H12AffineEnvironment.transform 15 8202 env22937 = env22938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env22937 == env22938) = true)

theorem identity22938 : scanCanonicalize (H12AffineFastState.compose env22938 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound22938 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env22939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,478,49169,2557,1025,32769,4161,21792,32921,138,348,64,56577,38297,50568,35188,1500,32,257,21792,38224,513]

theorem envBound22939 : H12AffineFastState.Bounded env22939 := by
  intro p hp
  have h : env22939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22938_22939 : H12AffineEnvironment.transform 12 468 env22938 = env22939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env22938 == env22939) = true)

theorem identity22939 : scanCanonicalize (H12AffineFastState.compose env22939 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22939 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22940 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,342,49169,2421,1025,32769,4161,21792,32785,2,348,64,56577,38161,50432,35188,1364,32,257,21792,38224,513]

theorem envBound22940 : H12AffineFastState.Bounded env22940 := by
  intro p hp
  have h : env22940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22939_22940 : H12AffineEnvironment.transform 6 8 env22939 = env22940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22939 == env22940) = true)

theorem identity22940 : scanCanonicalize (H12AffineFastState.compose env22940 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22940 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env22941 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,32768,262,49169,2341,1025,32769,4113,21792,32785,2,268,16,56577,38161,50432,35108,1284,32,257,21792,38144,513]

theorem envBound22941 : H12AffineFastState.Bounded env22941 := by
  intro p hp
  have h : env22941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22940_22941 : H12AffineEnvironment.transform 5 16 env22940 = env22941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22940 == env22941) = true)

theorem identity22941 : scanCanonicalize (H12AffineFastState.compose env22941 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound22941 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env22942 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,1,262,16400,2341,1025,0,4113,21792,16,2,268,16,23808,5392,17665,2341,1284,32,257,21792,5377,513]

theorem envBound22942 : H12AffineFastState.Bounded env22942 := by
  intro p hp
  have h : env22942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22941_22942 : H12AffineEnvironment.transform 14 1 env22941 = env22942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env22941 == env22942) = true)

theorem identity22942 : scanCanonicalize (H12AffineFastState.compose env22942 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 794) := by decide +kernel

theorem selectedBound22942 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env22943 : List Nat := [2,4,8,16,32,16,8,256,512,794,2048,4096,268,16384,1,262,16400,2341,795,0,4113,21050,16,2,268,16,23066,4618,16923,2341,542,32,257,21050,4635,513]

theorem envBound22943 : H12AffineFastState.Bounded env22943 := by
  intro p hp
  have h : env22943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22942_22943 : H12AffineEnvironment.transform 9 794 env22942 = env22943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 794 env22942 == env22943) = true)

def env22944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441625,2257181,254097,8328,64,2157717,2253853,140365,2404636,2102685,2373705,257,21792,46212,2175562]

theorem envBound22944 : H12AffineFastState.Bounded env22944 := by
  intro p hp
  have h : env22944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22881_22944 : H12AffineEnvironment.transform 21 441625 env22881 = env22944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441625 env22881 == env22944) = true)

def env22945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441625,155997,254097,8328,64,64725,160861,140365,303452,1501,272393,257,21792,46212,74250]

theorem envBound22945 : H12AffineFastState.Bounded env22945 := by
  intro p hp
  have h : env22945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22944_22945 : H12AffineEnvironment.transform 20 4160 env22944 = env22945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env22944 == env22945) = true)

theorem identity22945 : scanCanonicalize (H12AffineFastState.compose env22945 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound22945 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,4160,412109,155997,201797,8328,64,2049,160861,140365,284040,1501,272393,257,21792,16464,74250]

theorem envBound22946 : H12AffineFastState.Bounded env22946 := by
  intro p hp
  have h : env22946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22945_22946 : H12AffineEnvironment.transform 14 29908 env22945 = env22946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env22945 == env22946) = true)

def env22947 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,4160,411973,155997,201797,8192,64,2049,160861,140365,283904,1365,272393,257,21792,16464,74250]

theorem envBound22947 : H12AffineFastState.Bounded env22947 := by
  intro p hp
  have h : env22947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22946_22947 : H12AffineEnvironment.transform 6 8 env22946 = env22947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22946 == env22947) = true)

theorem identity22947 : scanCanonicalize (H12AffineFastState.compose env22947 (packedSelected [3,10,11,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 157800) := by decide +kernel

theorem selectedBound22947 : packedSelected [3,10,11,24,26,32] rootPS < 2^1333 := by decide +kernel

def env22948 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,157800,1025,29789,4160,8493,155997,201797,8192,64,2049,160861,140365,146792,1365,147553,257,21792,16464,74250]

theorem envBound22948 : H12AffineFastState.Bounded env22948 := by
  intro p hp
  have h : env22948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22947_22948 : H12AffineEnvironment.transform 17 157800 env22947 = env22948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157800 env22947 == env22948) = true)

theorem identity22948 : scanCanonicalize (H12AffineFastState.compose env22948 (packedSelected [0,3,4,7,14,18,19,22,23,24,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound22948 : packedSelected [0,3,4,7,14,18,19,22,23,24,31,35] rootPS < 2^1333 := by decide +kernel

def env22949 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,79130,89458,1025,29789,4160,8493,87111,8543,8192,64,2049,82247,69975,67698,1365,95611,257,21792,16464,74250]

theorem envBound22949 : H12AffineFastState.Bounded env22949 := by
  intro p hp
  have h : env22949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22948_22949 : H12AffineEnvironment.transform 16 79130 env22948 = env22949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env22948 == env22949) = true)

theorem identity22949 : scanCanonicalize (H12AffineFastState.compose env22949 (packedSelected [0,7,8,9,10,12,14,15,16,17,19,22,26,28] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound22949 : packedSelected [0,7,8,9,10,12,14,15,16,17,19,22,26,28] rootPS < 2^1333 := by decide +kernel

def env22950 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,65536,70727,89458,1025,21760,4160,112,87111,2,349,64,2049,82247,69975,67698,1365,87078,257,21792,16464,66391]

theorem envBound22950 : H12AffineFastState.Bounded env22950 := by
  intro p hp
  have h : env22950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22949_22950 : H12AffineEnvironment.transform 12 349 env22949 = env22950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env22949 == env22950) = true)

theorem identity22950 : scanCanonicalize (H12AffineFastState.compose env22950 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound22950 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env22951 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,342,5393,23588,1025,21760,4160,112,21777,2,349,64,2049,16401,4097,2340,1365,21872,257,21792,16464,513]

theorem envBound22951 : H12AffineFastState.Bounded env22951 := by
  intro p hp
  have h : env22951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22950_22951 : H12AffineEnvironment.transform 15 342 env22950 = env22951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env22950 == env22951) = true)

theorem identity22951 : scanCanonicalize (H12AffineFastState.compose env22951 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound22951 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env22952 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5157,292,342,5393,2049,1025,293,4160,112,308,2,349,64,2049,5172,4097,2340,1365,341,257,261,5237,513]

theorem envBound22952 : H12AffineFastState.Bounded env22952 := by
  intro p hp
  have h : env22952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22951_22952 : H12AffineEnvironment.transform 13 5157 env22951 = env22952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env22951 == env22952) = true)

theorem identity22952 : scanCanonicalize (H12AffineFastState.compose env22952 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22952 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env22953 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5157,292,262,5393,2049,1025,293,4112,32,308,2,269,16,2049,5172,4097,2340,1285,261,257,261,5157,513]

theorem envBound22953 : H12AffineFastState.Bounded env22953 := by
  intro p hp
  have h : env22953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22952_22953 : H12AffineEnvironment.transform 5 16 env22952 = env22953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22952 == env22953) = true)

theorem identity22953 : scanCanonicalize (H12AffineFastState.compose env22953 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound22953 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env22954 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,4096,269,5157,292,262,5393,1076,1025,293,4112,32,308,2,269,16,1076,5172,4097,1297,1285,261,257,261,5157,513]

theorem envBound22954 : H12AffineFastState.Bounded env22954 := by
  intro p hp
  have h : env22954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22953_22954 : H12AffineEnvironment.transform 10 1077 env22953 = env22954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env22953 == env22954) = true)

theorem identity22954 : scanCanonicalize (H12AffineFastState.compose env22954 (packedSelected [0,7,12] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound22954 : packedSelected [0,7,12] rootPS < 2^1333 := by decide +kernel

def env22955 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,309,269,1296,292,262,1060,1076,1025,293,293,32,308,2,269,16,1076,1281,308,1297,1285,261,257,261,1296,513]

theorem envBound22955 : H12AffineFastState.Bounded env22955 := by
  intro p hp
  have h : env22955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22954_22955 : H12AffineEnvironment.transform 11 309 env22954 = env22955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env22954 == env22955) = true)

theorem identity22955 : scanCanonicalize (H12AffineFastState.compose env22955 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound22955 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env22956 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1077,17,41,1076,0,34,1060,1076,1025,1,1,32,16,2,41,16,1076,1061,16,1077,1057,33,37,33,1076,513]

theorem envBound22956 : H12AffineFastState.Bounded env22956 := by
  intro p hp
  have h : env22956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22955_22956 : H12AffineEnvironment.transform 7 36 env22955 = env22956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env22955 == env22956) = true)

theorem identity22956 : scanCanonicalize (H12AffineFastState.compose env22956 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound22956 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22957 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,17,41,0,0,34,16,0,53,1,1,32,16,2,41,16,0,17,16,1,21,33,37,33,0,513]

theorem envBound22957 : H12AffineFastState.Bounded env22957 := by
  intro p hp
  have h : env22957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22956_22957 : H12AffineEnvironment.transform 9 52 env22956 = env22957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env22956 == env22957) = true)

theorem identity22957 : scanCanonicalize (H12AffineFastState.compose env22957 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound22957 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22958 : List Nat := [2,4,8,16,17,16,8,21,512,5,1,17,24,0,0,19,16,0,4,1,1,17,16,2,24,16,0,17,16,1,21,16,20,16,0,513]

theorem envBound22958 : H12AffineFastState.Bounded env22958 := by
  intro p hp
  have h : env22958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22957_22958 : H12AffineEnvironment.transform 4 17 env22957 = env22958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env22957 == env22958) = true)

theorem identity22958 : scanCanonicalize (H12AffineFastState.compose env22958 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22958 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22959 : List Nat := [2,4,8,0,1,0,8,5,512,5,1,1,8,0,0,3,0,0,4,1,1,1,0,2,8,0,0,1,0,1,5,0,4,0,0,513]

theorem envBound22959 : H12AffineFastState.Bounded env22959 := by
  intro p hp
  have h : env22959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22958_22959 : H12AffineEnvironment.transform 3 0 env22958 = env22959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22958 == env22959) = true)

def env22960 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,4160,411972,155997,201797,8193,64,2049,160861,140365,283905,1364,272393,257,21792,16464,74250]

theorem envBound22960 : H12AffineFastState.Bounded env22960 := by
  intro p hp
  have h : env22960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22946_22960 : H12AffineEnvironment.transform 6 9 env22946 = env22960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22946 == env22960) = true)

theorem identity22960 : scanCanonicalize (H12AffineFastState.compose env22960 (packedSelected [3,10,11,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 215091) := by decide +kernel

theorem selectedBound22960 : packedSelected [3,10,11,24,26,32] rootPS < 2^1333 := by decide +kernel

def env22961 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,215091,1025,29788,4160,65911,155997,201797,8193,64,2049,160861,140365,204082,1364,221242,257,21792,16464,74250]

theorem envBound22961 : H12AffineFastState.Bounded env22961 := by
  intro p hp
  have h : env22961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22960_22961 : H12AffineEnvironment.transform 17 215091 env22960 = env22961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 215091 env22960 == env22961) = true)

theorem identity22961 : scanCanonicalize (H12AffineFastState.compose env22961 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound22961 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env22962 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90139,10280,1025,29788,4160,65911,65862,29790,8193,64,2049,70726,83030,32041,1364,33,257,21792,16464,74250]

theorem envBound22962 : H12AffineFastState.Bounded env22962 := by
  intro p hp
  have h : env22962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22961_22962 : H12AffineEnvironment.transform 16 90139 env22961 = env22962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env22961 == env22962) = true)

theorem identity22962 : scanCanonicalize (H12AffineFastState.compose env22962 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound22962 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22963 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29963,5392,10280,1025,29788,4160,29820,29773,29790,8193,64,2049,24909,12637,32041,1364,33,257,21792,16464,22273]

theorem envBound22963 : H12AffineFastState.Bounded env22963 := by
  intro p hp
  have h : env22963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22962_22963 : H12AffineEnvironment.transform 15 29963 env22962 = env22963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env22962 == env22963) = true)

theorem identity22963 : scanCanonicalize (H12AffineFastState.compose env22963 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound22963 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22964 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,16384,20497,20807,5392,3172,1025,20496,4160,20528,20481,20498,1101,64,2049,17665,5393,22885,1364,33,257,21792,16464,22273]

theorem envBound22964 : H12AffineFastState.Bounded env22964 := by
  intro p hp
  have h : env22964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22963_22964 : H12AffineEnvironment.transform 12 1100 env22963 = env22964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env22963 == env22964) = true)

theorem identity22964 : scanCanonicalize (H12AffineFastState.compose env22964 (packedSelected [0,1,3,4,5,7,8,9,14,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22964 : packedSelected [0,1,3,4,5,7,8,9,14,15,18] rootPS < 2^1333 := by decide +kernel

def env22965 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,1053,16384,20497,20758,5392,3125,1025,20496,4113,20528,20481,20498,1052,17,2049,17665,5393,22836,1285,33,257,21792,16385,22273]

theorem envBound22965 : H12AffineFastState.Bounded env22965 := by
  intro p hp
  have h : env22965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22964_22965 : H12AffineEnvironment.transform 5 17 env22964 = env22965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22964 == env22965) = true)

theorem identity22965 : scanCanonicalize (H12AffineFastState.compose env22965 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound22965 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env22966 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,1053,5377,1296,1047,5392,3125,1025,1297,4113,1329,1280,1299,1052,17,2049,4096,5393,3125,1285,33,257,33,5376,512]

theorem envBound22966 : H12AffineFastState.Bounded env22966 := by
  intro p hp
  have h : env22966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22965_22966 : H12AffineEnvironment.transform 13 5377 env22965 = env22966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env22965 == env22966) = true)

theorem identity22966 : scanCanonicalize (H12AffineFastState.compose env22966 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 59) := by decide +kernel

theorem selectedBound22966 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env22967 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,59,1053,1338,1296,1047,1323,3125,1025,1297,42,1329,1280,1299,1052,17,2049,59,1322,3125,1285,33,257,33,1339,512]

theorem envBound22967 : H12AffineFastState.Bounded env22967 := by
  intro p hp
  have h : env22967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22966_22967 : H12AffineEnvironment.transform 11 59 env22966 = env22967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 59 env22966 == env22967) = true)

theorem identity22967 : scanCanonicalize (H12AffineFastState.compose env22967 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22967 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22968 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,27,1053,1306,1296,1047,1291,3093,1025,1297,10,1297,1280,1299,1052,17,2049,27,1290,3093,1285,1,257,1,1307,512]

theorem envBound22968 : H12AffineFastState.Bounded env22968 := by
  intro p hp
  have h : env22968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22967_22968 : H12AffineEnvironment.transform 4 0 env22967 = env22968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22967 == env22968) = true)

theorem identity22968 : scanCanonicalize (H12AffineFastState.compose env22968 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1028) := by decide +kernel

theorem selectedBound22968 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env22969 : List Nat := [2,4,8,16,0,17,9,256,512,1024,1028,27,1053,1306,1296,1047,1291,17,1025,1297,10,1297,1280,1299,1052,17,1029,27,1290,17,1285,1,257,1,1307,512]

theorem envBound22969 : H12AffineFastState.Bounded env22969 := by
  intro p hp
  have h : env22969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22968_22969 : H12AffineEnvironment.transform 10 1028 env22968 = env22969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1028 env22968 == env22969) = true)

theorem identity22969 : scanCanonicalize (H12AffineFastState.compose env22969 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound22969 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env22970 : List Nat := [2,4,8,16,0,17,9,256,512,14,10,27,19,276,286,25,261,17,15,287,10,287,270,285,18,17,11,27,260,17,267,1,257,1,277,512]

theorem envBound22970 : H12AffineFastState.Bounded env22970 := by
  intro p hp
  have h : env22970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22969_22970 : H12AffineEnvironment.transform 9 14 env22969 = env22970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env22969 == env22970) = true)

theorem identity22970 : scanCanonicalize (H12AffineFastState.compose env22970 (packedSelected [1,2,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound22970 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env22971 : List Nat := [2,4,8,16,0,17,9,5,512,14,10,27,19,17,27,25,0,17,15,26,10,26,11,24,18,17,11,27,1,17,14,1,4,1,16,512]

theorem envBound22971 : H12AffineFastState.Bounded env22971 := by
  intro p hp
  have h : env22971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22970_22971 : H12AffineEnvironment.transform 7 5 env22970 = env22971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env22970 == env22971) = true)

theorem identity22971 : scanCanonicalize (H12AffineFastState.compose env22971 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 24) := by decide +kernel

theorem selectedBound22971 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env22972 : List Nat := [2,4,8,16,0,17,9,5,24,14,10,27,19,17,27,25,0,17,15,26,10,26,11,24,18,17,11,27,1,17,14,1,4,1,16,24]

theorem envBound22972 : H12AffineFastState.Bounded env22972 := by
  intro p hp
  have h : env22972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22971_22972 : H12AffineEnvironment.transform 8 24 env22971 = env22972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 24 env22971 == env22972) = true)

theorem identity22972 : scanCanonicalize (H12AffineFastState.compose env22972 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound22972 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22973 : List Nat := [2,4,2,16,0,17,3,5,18,4,0,17,19,17,17,19,0,17,5,16,0,16,1,18,18,17,1,17,1,17,4,1,4,1,16,18]

theorem envBound22973 : H12AffineFastState.Bounded env22973 := by
  intro p hp
  have h : env22973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22972_22973 : H12AffineEnvironment.transform 2 2 env22972 = env22973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env22972 == env22973) = true)

theorem identity22973 : scanCanonicalize (H12AffineFastState.compose env22973 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound22973 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22974 : List Nat := [2,4,2,7,0,6,3,5,5,4,0,6,4,6,6,4,0,6,5,7,0,7,1,5,5,6,1,6,1,6,4,1,4,1,7,5]

theorem envBound22974 : H12AffineFastState.Bounded env22974 := by
  intro p hp
  have h : env22974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22973_22974 : H12AffineEnvironment.transform 3 7 env22973 = env22974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env22973 == env22974) = true)

def env22975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441625,155996,254097,8328,64,64724,160860,140365,303453,1500,272392,257,21792,46212,74251]

theorem envBound22975 : H12AffineFastState.Bounded env22975 := by
  intro p hp
  have h : env22975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22944_22975 : H12AffineEnvironment.transform 20 4161 env22944 = env22975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env22944 == env22975) = true)

theorem identity22975 : scanCanonicalize (H12AffineFastState.compose env22975 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound22975 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4161,318548,17,98780,8328,64,64724,5393,17664,303453,1500,272392,257,21792,46212,74251]

theorem envBound22976 : H12AffineFastState.Bounded env22976 := by
  intro p hp
  have h : env22976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22975_22976 : H12AffineEnvironment.transform 16 24909 env22975 = env22976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env22975 == env22976) = true)

def env22977 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4161,318548,17,98644,8192,64,64604,5393,17664,303453,1364,272392,257,21792,46092,74251]

theorem envBound22977 : H12AffineFastState.Bounded env22977 := by
  intro p hp
  have h : env22977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22976_22977 : H12AffineEnvironment.transform 6 8 env22976 = env22977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22976 == env22977) = true)

theorem identity22977 : scanCanonicalize (H12AffineFastState.compose env22977 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound22977 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22978 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,67619,1025,32769,4161,119927,17,98644,8192,64,64604,5393,17664,108926,1364,73771,257,21792,46092,74251]

theorem envBound22978 : H12AffineFastState.Bounded env22978 := by
  intro p hp
  have h : env22978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22977_22978 : H12AffineEnvironment.transform 17 67619 env22977 = env22978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env22977 == env22978) = true)

theorem identity22978 : scanCanonicalize (H12AffineFastState.compose env22978 (packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound22978 : packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env22979 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62730,24909,64809,1025,32769,4161,8573,17,29790,8192,64,64604,5393,17664,23668,1364,54561,257,21792,46092,55041]

theorem envBound22979 : H12AffineFastState.Bounded env22979 := by
  intro p hp
  have h : env22979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22978_22979 : H12AffineEnvironment.transform 15 62730 env22978 = env22979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env22978 == env22979) = true)

theorem identity22979 : scanCanonicalize (H12AffineFastState.compose env22979 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound22979 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env22980 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,54358,16401,56437,1025,32769,4161,33,17,21762,348,64,56576,5393,17664,23668,1364,54561,257,21792,38224,55041]

theorem envBound22980 : H12AffineFastState.Bounded env22980 := by
  intro p hp
  have h : env22980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22979_22980 : H12AffineEnvironment.transform 12 348 env22979 = env22980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env22979 == env22980) = true)

theorem identity22980 : scanCanonicalize (H12AffineFastState.compose env22980 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound22980 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env22981 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,1,21591,16401,23668,1025,0,4161,33,17,21762,348,64,23809,5393,17664,23668,1364,21792,257,21792,5457,22272]

theorem envBound22981 : H12AffineFastState.Bounded env22981 := by
  intro p hp
  have h : env22981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22980_22981 : H12AffineEnvironment.transform 14 1 env22980 = env22981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env22980 == env22981) = true)

theorem identity22981 : scanCanonicalize (H12AffineFastState.compose env22981 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5204) := by decide +kernel

theorem selectedBound22981 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env22982 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5204,1,3,5189,2080,1025,0,4161,33,17,342,348,64,2389,5393,4436,2080,1364,372,257,372,5457,852]

theorem envBound22982 : H12AffineFastState.Bounded env22982 := by
  intro p hp
  have h : env22982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22981_22982 : H12AffineEnvironment.transform 13 5204 env22981 = env22982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5204 env22981 == env22982) = true)

def env22983 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4161,318548,17,98645,8193,64,64605,5393,17664,303453,1365,272392,257,21792,46093,74251]

theorem envBound22983 : H12AffineFastState.Bounded env22983 := by
  intro p hp
  have h : env22983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22976_22983 : H12AffineEnvironment.transform 6 9 env22976 = env22983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22976 == env22983) = true)

theorem identity22983 : scanCanonicalize (H12AffineFastState.compose env22983 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 108927) := by decide +kernel

theorem selectedBound22983 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22984 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,108927,1025,32769,4161,95531,17,98645,8193,64,64605,5393,17664,67618,1365,98679,257,21792,46093,74251]

theorem envBound22984 : H12AffineFastState.Bounded env22984 := by
  intro p hp
  have h : env22984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22983_22984 : H12AffineEnvironment.transform 17 108927 env22983 = env22984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108927 env22983 == env22984) = true)

theorem identity22984 : scanCanonicalize (H12AffineFastState.compose env22984 (packedSelected [0,1,7,8,9,10,12,14,15,16,18,19,22,23,31] rootPS)) = affineNative (2^(15+1) ^^^ 21794) := by decide +kernel

theorem selectedBound22984 : packedSelected [0,1,7,8,9,10,12,14,15,16,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env22985 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21794,24909,64605,1025,32769,4161,8201,17,54391,8193,64,64605,5393,17664,23808,1365,54357,257,21792,46093,30505]

theorem envBound22985 : H12AffineFastState.Bounded env22985 := by
  intro p hp
  have h : env22985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22984_22985 : H12AffineEnvironment.transform 15 21794 env22984 = env22985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21794 env22984 == env22985) = true)

theorem identity22985 : scanCanonicalize (H12AffineFastState.compose env22985 (packedSelected [0,2,3,4,6,8,9,11,12,15,20,23,24,26,27,28] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound22985 : packedSelected [0,2,3,4,6,8,9,11,12,15,20,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env22986 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,8575,5392,34816,1025,32769,4161,8201,17,41002,8193,64,34816,5393,12637,10589,1365,40968,257,8573,46093,884]

theorem envBound22986 : H12AffineFastState.Bounded env22986 := by
  intro p hp
  have h : env22986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22985_22986 : H12AffineEnvironment.transform 13 13405 env22985 = env22986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env22985 == env22986) = true)

theorem identity22986 : scanCanonicalize (H12AffineFastState.compose env22986 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound22986 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env22987 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5237,32768,343,5392,34816,1025,32769,4161,33,17,32770,41,64,34816,5393,4469,2421,1365,32800,257,341,37925,884]

theorem envBound22987 : H12AffineFastState.Bounded env22987 := by
  intro p hp
  have h : env22987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22986_22987 : H12AffineEnvironment.transform 12 40 env22986 = env22987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env22986 == env22987) = true)

theorem identity22987 : scanCanonicalize (H12AffineFastState.compose env22987 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound22987 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env22988 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,40,5237,32768,35,5220,34816,1025,32769,4161,33,17,32770,41,64,34816,5221,4097,2049,1057,32800,117,33,37925,512]

theorem envBound22988 : H12AffineFastState.Bounded env22988 := by
  intro p hp
  have h : env22988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22987_22988 : H12AffineEnvironment.transform 7 116 env22987 = env22988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env22987 == env22988) = true)

theorem identity22988 : scanCanonicalize (H12AffineFastState.compose env22988 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 112) := by decide +kernel

theorem selectedBound22988 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22989 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,40,5237,112,35,5220,2160,1025,113,4161,33,17,114,41,64,2160,5221,4097,2049,1057,80,117,33,5205,512]

theorem envBound22989 : H12AffineFastState.Bounded env22989 := by
  intro p hp
  have h : env22989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22988_22989 : H12AffineEnvironment.transform 14 112 env22988 = env22989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 112 env22988 == env22989) = true)

theorem identity22989 : scanCanonicalize (H12AffineFastState.compose env22989 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2673) := by decide +kernel

theorem selectedBound22989 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env22990 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,2673,40,3588,112,35,3605,2160,1025,113,2608,33,17,114,41,64,2160,3604,2672,2049,1057,80,117,33,3620,512]

theorem envBound22990 : H12AffineFastState.Bounded env22990 := by
  intro p hp
  have h : env22990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22989_22990 : H12AffineEnvironment.transform 11 2673 env22989 = env22990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2673 env22989 == env22990) = true)

theorem identity22990 : scanCanonicalize (H12AffineFastState.compose env22990 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(10+1) ^^^ 1621) := by decide +kernel

theorem selectedBound22990 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env22991 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1621,1060,40,81,112,35,64,1573,1025,113,1125,33,17,114,41,64,1573,65,1061,1620,1057,80,117,33,113,512]

theorem envBound22991 : H12AffineFastState.Bounded env22991 := by
  intro p hp
  have h : env22991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22990_22991 : H12AffineEnvironment.transform 10 1621 env22990 = env22991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1621 env22990 == env22991) = true)

theorem identity22991 : scanCanonicalize (H12AffineFastState.compose env22991 (packedSelected [7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound22991 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env22992 : List Nat := [2,4,8,16,32,64,9,116,512,52,609,16,40,81,112,35,64,529,53,113,81,33,17,114,41,64,529,65,17,608,21,80,117,33,113,512]

theorem envBound22992 : H12AffineFastState.Bounded env22992 := by
  intro p hp
  have h : env22992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22991_22992 : H12AffineEnvironment.transform 9 52 env22991 = env22992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env22991 == env22992) = true)

theorem identity22992 : scanCanonicalize (H12AffineFastState.compose env22992 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound22992 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22993 : List Nat := [2,4,8,16,17,64,9,69,512,5,592,16,25,81,65,18,64,529,4,64,81,16,17,67,24,64,529,65,17,593,21,80,68,16,64,512]

theorem envBound22993 : H12AffineFastState.Bounded env22993 := by
  intro p hp
  have h : env22993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22992_22993 : H12AffineEnvironment.transform 4 17 env22992 = env22993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env22992 == env22993) = true)

theorem identity22993 : scanCanonicalize (H12AffineFastState.compose env22993 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound22993 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22994 : List Nat := [2,4,8,16,17,64,9,69,65,5,17,16,25,81,65,18,64,80,4,64,81,16,17,67,24,64,80,65,17,16,21,80,68,16,64,65]

theorem envBound22994 : H12AffineFastState.Bounded env22994 := by
  intro p hp
  have h : env22994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22993_22994 : H12AffineEnvironment.transform 8 65 env22993 = env22994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env22993 == env22994) = true)

theorem identity22994 : scanCanonicalize (H12AffineFastState.compose env22994 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound22994 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22995 : List Nat := [2,4,8,16,17,0,9,5,1,5,17,16,25,17,1,18,0,16,4,0,17,16,17,3,24,0,16,1,17,16,21,16,4,16,0,1]

theorem envBound22995 : H12AffineFastState.Bounded env22995 := by
  intro p hp
  have h : env22995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22994_22995 : H12AffineEnvironment.transform 5 0 env22994 = env22995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env22994 == env22995) = true)

def env22996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507601,155254785,25265168,145662400,525568,140903596,27337992,25733063]

theorem envBound22996 : H12AffineFastState.Bounded env22996 := by
  intro p hp
  have h : env22996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22301_22996 : H12AffineEnvironment.transform 25 65 env22301 = env22996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env22301 == env22996) = true)

def env22997 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507601,9356289,25265168,23160256,525568,27902124,27337992,25733063]

theorem envBound22997 : H12AffineFastState.Bounded env22997 := by
  intro p hp
  have h : env22997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22996_22997 : H12AffineEnvironment.transform 26 30393344 env22996 = env22997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env22996 == env22997) = true)

def env22998 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830977,25265168,23160256,256,27378860,27337992,25207751]

theorem envBound22998 : H12AffineFastState.Bounded env22998 := by
  intro p hp
  have h : env22998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22997_22998 : H12AffineEnvironment.transform 18 1024 env22997 = env22998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env22997 == env22998) = true)

theorem identity22998 : scanCanonicalize (H12AffineFastState.compose env22998 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 437745) := by decide +kernel

theorem selectedBound22998 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env22999 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,4194304,8388608,16777216,8328,65,29868032,17246588,8845472,8830977,25265168,21481521,256,25651549,25659641,25207751]

theorem envBound22999 : H12AffineFastState.Bounded env22999 := by
  intro p hp
  have h : env22999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22998_22999 : H12AffineEnvironment.transform 20 437745 env22998 = env22999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437745 env22998 == env22999) = true)

def env23000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,4194304,8388608,8862844,8328,65,4258940,8393984,8845472,8830977,440428,12645453,256,21793,46213,499643]

theorem envBound23000 : H12AffineFastState.Bounded env23000 := by
  intro p hp
  have h : env23000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22999_23000 : H12AffineEnvironment.transform 23 8862844 env22999 = env23000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8862844 env22999 == env23000) = true)

def env23001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,4194304,441760,98780,8328,65,4258940,436384,17664,32161,440428,4606445,256,21793,46213,499643]

theorem envBound23001 : H12AffineFastState.Bounded env23001 := by
  intro p hp
  have h : env23001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23000_23001 : H12AffineEnvironment.transform 22 441760 env23000 = env23001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441760 env23000 == env23001) = true)

def env23002 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,272512,441760,98780,8328,65,316668,436384,17664,32161,440428,156013,256,21793,46213,499643]

theorem envBound23002 : H12AffineFastState.Bounded env23002 := by
  intro p hp
  have h : env23002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23001_23002 : H12AffineEnvironment.transform 21 272512 env23001 = env23002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env23001 == env23002) = true)

def env23003 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,272392,441640,98644,8192,65,316532,436264,17664,32041,440428,156013,256,21793,46093,499507]

theorem envBound23003 : H12AffineFastState.Bounded env23003 := by
  intro p hp
  have h : env23003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23002_23003 : H12AffineEnvironment.transform 6 8 env23002 = env23003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23002 == env23003) = true)

theorem identity23003 : scanCanonicalize (H12AffineFastState.compose env23003 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 236850) := by decide +kernel

theorem selectedBound23003 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env23004 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236850,1024,32769,77899,243002,73754,98644,8192,65,215366,79130,17664,32041,75102,156013,256,21793,46093,513]

theorem envBound23004 : H12AffineFastState.Bounded env23004 := by
  intro p hp
  have h : env23004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23003_23004 : H12AffineEnvironment.transform 17 236850 env23003 = env23004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236850 env23003 == env23004) = true)

theorem identity23004 : scanCanonicalize (H12AffineFastState.compose env23004 (packedSelected [0,2,3,4,6,9,10,18,20,23,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound23004 : packedSelected [0,2,3,4,6,9,10,18,20,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env23005 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179513,1024,32769,4160,169265,17,41311,8192,65,158029,5393,17664,32041,1365,156013,256,21793,46093,513]

theorem envBound23005 : H12AffineFastState.Bounded env23005 := by
  intro p hp
  have h : env23005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23004_23005 : H12AffineEnvironment.transform 15 8203 env23004 = env23005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env23004 == env23005) = true)

theorem identity23005 : scanCanonicalize (H12AffineFastState.compose env23005 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound23005 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env23006 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,64808,1024,32769,4160,54560,17,41311,8192,65,10588,5393,17664,32041,1365,8572,256,21793,46093,513]

theorem envBound23006 : H12AffineFastState.Bounded env23006 := by
  intro p hp
  have h : env23006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23005_23006 : H12AffineEnvironment.transform 16 16401 env23005 = env23006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env23005 == env23006) = true)

theorem identity23006 : scanCanonicalize (H12AffineFastState.compose env23006 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound23006 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env23007 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8203,16401,23668,1024,8541,4160,29820,17,3,8192,65,10588,5393,17664,32041,1365,8572,256,21793,5457,513]

end H12CloudChart0