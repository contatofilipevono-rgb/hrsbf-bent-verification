import H12CloudChart0Data139

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound35526 : packedSelected [0,4,6,7,9,11,18] rootPS < 2^1333 := by decide +kernel

def env35527 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,292,115,16740,2129,1024,293,2097152,32,357,2,269,64,2340,2098513,2118709,2421,1057,2114580,256,2114580,2098448,513]

theorem envBound35527 : H12AffineFastState.Bounded env35527 := by
  intro p hp
  have h : env35527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35526_35527 : H12AffineEnvironment.transform 14 292 env35526 = env35527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env35526 == env35527) = true)

theorem identity35527 : scanCanonicalize (H12AffineFastState.compose env35527 (packedSelected [0,3,6,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound35527 : packedSelected [0,3,6,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env35528 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1297,4096,269,16384,292,115,16740,1344,1024,293,2097152,32,357,2,269,64,1077,2098513,2118709,1124,1057,2114580,256,2114580,2098448,513]

theorem envBound35528 : H12AffineFastState.Bounded env35528 := by
  intro p hp
  have h : env35528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35527_35528 : H12AffineEnvironment.transform 10 1297 env35527 = env35528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env35527 == env35528) = true)

theorem identity35528 : scanCanonicalize (H12AffineFastState.compose env35528 (packedSelected [3,8,10,12,15] rootPS)) = affineNative (2^(20+1) ^^^ 17680) := by decide +kernel

theorem selectedBound35528 : packedSelected [3,8,10,12,15] rootPS < 2^1333 := by decide +kernel

def env35529 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1297,4096,269,16384,292,115,16740,1344,1024,293,17680,32,357,2,269,64,1077,16449,4389,1124,1057,260,256,260,16384,513]

theorem envBound35529 : H12AffineFastState.Bounded env35529 := by
  intro p hp
  have h : env35529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35528_35529 : H12AffineEnvironment.transform 20 17680 env35528 = env35529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17680 env35528 == env35529) = true)

theorem identity35529 : scanCanonicalize (H12AffineFastState.compose env35529 (packedSelected [1,3,4,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound35529 : packedSelected [1,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env35530 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1124,4096,120,16384,81,115,16401,1077,1024,80,17509,32,16,2,120,64,1077,16449,4176,1124,1057,113,117,113,16384,513]

theorem envBound35530 : H12AffineFastState.Bounded env35530 := by
  intro p hp
  have h : env35530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35529_35530 : H12AffineEnvironment.transform 7 117 env35529 = env35530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env35529 == env35530) = true)

theorem identity35530 : scanCanonicalize (H12AffineFastState.compose env35530 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound35530 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env35531 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1124,4096,120,5237,81,115,5220,1077,1024,80,4112,32,16,2,120,64,1077,5172,4176,1124,1057,113,117,113,5237,513]

theorem envBound35531 : H12AffineFastState.Bounded env35531 := by
  intro p hp
  have h : env35531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35530_35531 : H12AffineEnvironment.transform 13 5237 env35530 = env35531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env35530 == env35531) = true)

def env35532 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57797,35189,1024,32769,2097152,33,41292,2,8328,64,68062,2196622,2159644,2557,75103,2188771,256,2188770,2196551,649]

theorem envBound35532 : H12AffineFastState.Bounded env35532 := by
  intro p hp
  have h : env35532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35522_35532 : H12AffineEnvironment.transform 21 33 env35522 = env35532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env35522 == env35532) = true)

theorem identity35532 : scanCanonicalize (H12AffineFastState.compose env35532 (packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound35532 : packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env35533 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,16536,10280,1024,8540,2097152,33,17,2,8328,64,68062,2172371,2118977,2557,75103,2188771,256,2188770,2172186,649]

theorem envBound35533 : H12AffineFastState.Bounded env35533 := by
  intro p hp
  have h : env35533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35532_35533 : H12AffineEnvironment.transform 14 8541 env35532 = env35533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env35532 == env35533) = true)

theorem identity35533 : scanCanonicalize (H12AffineFastState.compose env35533 (packedSelected [2,4,6,9,18] rootPS)) = affineNative (2^(20+1) ^^^ 25797) := by decide +kernel

theorem selectedBound35533 : packedSelected [2,4,6,9,18] rootPS < 2^1333 := by decide +kernel

def env35534 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,16536,10280,1024,8540,25797,33,17,2,8328,64,68062,82198,12676,2557,75103,65830,256,65831,82399,649]

theorem envBound35534 : H12AffineFastState.Bounded env35534 := by
  intro p hp
  have h : env35534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35533_35534 : H12AffineEnvironment.transform 20 25797 env35533 = env35534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25797 env35533 == env35534) = true)

theorem identity35534 : scanCanonicalize (H12AffineFastState.compose env35534 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound35534 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env35535 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8323,16536,10280,1024,8540,25797,33,17,2,8328,64,10589,24981,12676,2557,1500,8613,256,8612,24924,649]

theorem envBound35535 : H12AffineFastState.Bounded env35535 := by
  intro p hp
  have h : env35535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35534_35535 : H12AffineEnvironment.transform 15 8323 env35534 = env35535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env35534 == env35535) = true)

theorem identity35535 : scanCanonicalize (H12AffineFastState.compose env35535 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound35535 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env35536 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,16384,216,262,16536,2477,1024,217,17728,33,17,2,269,64,2264,16400,4097,2557,1500,32,256,33,16601,649]

theorem envBound35536 : H12AffineFastState.Bounded env35536 := by
  intro p hp
  have h : env35536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35535_35536 : H12AffineEnvironment.transform 12 389 env35535 = env35536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env35535 == env35536) = true)

theorem identity35536 : scanCanonicalize (H12AffineFastState.compose env35536 (packedSelected [4,6,7,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound35536 : packedSelected [4,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env35537 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,240,16384,216,115,16536,2264,1024,217,17461,33,17,2,120,64,2264,16400,4097,2184,1193,32,117,33,16601,649]

theorem envBound35537 : H12AffineFastState.Bounded env35537 := by
  intro p hp
  have h : env35537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35536_35537 : H12AffineEnvironment.transform 7 117 env35536 = env35537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env35536 == env35537) = true)

theorem identity35537 : scanCanonicalize (H12AffineFastState.compose env35537 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound35537 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env35538 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,240,5236,216,115,5356,2264,1024,217,4161,33,17,2,120,64,2264,5220,4097,2184,1193,32,117,33,5293,649]

theorem envBound35538 : H12AffineFastState.Bounded env35538 := by
  intro p hp
  have h : env35538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35537_35538 : H12AffineEnvironment.transform 13 5236 env35537 = env35538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env35537 == env35538) = true)

theorem identity35538 : scanCanonicalize (H12AffineFastState.compose env35538 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35538 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env35539 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,121,5236,81,115,5221,2129,1024,80,4161,33,17,2,120,64,2129,5220,4097,2049,1056,32,117,33,5156,512]

theorem envBound35539 : H12AffineFastState.Bounded env35539 := by
  intro p hp
  have h : env35539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35538_35539 : H12AffineEnvironment.transform 6 9 env35538 = env35539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35538 == env35539) = true)

theorem identity35539 : scanCanonicalize (H12AffineFastState.compose env35539 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35539 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env35540 : List Nat := [2,4,8,16,0,64,9,85,512,1024,2048,4096,89,5204,81,83,5189,2129,1024,80,4161,1,17,2,88,64,2129,5188,4097,2049,1024,0,85,1,5124,512]

theorem envBound35540 : H12AffineFastState.Bounded env35540 := by
  intro p hp
  have h : env35540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35539_35540 : H12AffineEnvironment.transform 4 0 env35539 = env35540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35539 == env35540) = true)

theorem identity35540 : scanCanonicalize (H12AffineFastState.compose env35540 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound35540 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env35541 : List Nat := [2,4,8,16,0,64,9,85,512,1024,0,4096,89,5204,81,83,5189,81,1024,80,4161,1,17,2,88,64,81,5188,4097,1,1024,0,85,1,5124,512]

theorem envBound35541 : H12AffineFastState.Bounded env35541 := by
  intro p hp
  have h : env35541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35540_35541 : H12AffineEnvironment.transform 10 0 env35540 = env35541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env35540 == env35541) = true)

def env35542 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157873,1024,32769,2097152,4194304,147593,2,8328,64,4450363,2196622,2233817,190521,246938,6383042,256,2327591,2319746,189260]

theorem envBound35542 : H12AffineFastState.Bounded env35542 := by
  intro p hp
  have h : env35542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35520_35542 : H12AffineEnvironment.transform 17 157873 env35520 = env35542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157873 env35520 == env35542) = true)

theorem identity35542 : scanCanonicalize (H12AffineFastState.compose env35542 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound35542 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env35543 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,157873,1024,8541,2097152,4194304,147593,2,8328,64,4409703,2172370,2233817,149861,222662,6383042,256,2303355,2319746,147984]

theorem envBound35543 : H12AffineFastState.Bounded env35543 := by
  intro p hp
  have h : env35543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35542_35543 : H12AffineEnvironment.transform 14 8540 env35542 = env35543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env35542 == env35543) = true)

def env35544 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10401,1024,8541,2097152,4194304,153,2,8328,64,4262263,2172370,2119113,2421,75222,6383042,256,2188651,2172306,512]

theorem envBound35544 : H12AffineFastState.Bounded env35544 := by
  intro p hp
  have h : env35544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35543_35544 : H12AffineEnvironment.transform 16 16400 env35543 = env35544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env35543 == env35544) = true)

theorem identity35544 : scanCanonicalize (H12AffineFastState.compose env35544 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35544 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env35545 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10280,1024,8541,2097152,4194304,16,2,8193,64,4262263,2172251,2118976,2421,75103,6382923,256,2188651,2172187,512]

theorem envBound35545 : H12AffineFastState.Bounded env35545 := by
  intro p hp
  have h : env35545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35544_35545 : H12AffineEnvironment.transform 6 9 env35544 = env35545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35544 == env35545) = true)

theorem identity35545 : scanCanonicalize (H12AffineFastState.compose env35545 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 91198) := by decide +kernel

theorem selectedBound35545 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env35546 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10280,1024,8541,91198,4194304,16,2,8193,64,4262263,16741,78206,2421,75103,4194677,256,341,16677,512]

theorem envBound35546 : H12AffineFastState.Bounded env35546 := by
  intro p hp
  have h : env35546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35545_35546 : H12AffineEnvironment.transform 20 91198 env35545 = env35546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91198 env35545 == env35546) = true)

theorem identity35546 : scanCanonicalize (H12AffineFastState.compose env35546 (packedSelected [0,7,20] rootPS)) = affineNative (2^(21+1) ^^^ 372) := by decide +kernel

theorem selectedBound35546 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env35547 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10280,1024,8541,91198,372,16,2,8193,64,67587,16741,78206,2421,75103,1,256,341,16677,512]

theorem envBound35547 : H12AffineFastState.Bounded env35547 := by
  intro p hp
  have h : env35547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35546_35547 : H12AffineEnvironment.transform 21 372 env35546 = env35547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 372 env35546 == env35547) = true)

theorem identity35547 : scanCanonicalize (H12AffineFastState.compose env35547 (packedSelected [0,3,5,6,7,10,11,17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound35547 : packedSelected [0,3,5,6,7,10,11,17] rootPS < 2^1333 := by decide +kernel

def env35548 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,16400,10280,1024,8541,17460,372,16,2,8193,64,10249,16741,4468,2421,1365,1,256,341,16677,512]

theorem envBound35548 : H12AffineFastState.Bounded env35548 := by
  intro p hp
  have h : env35548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35547_35548 : H12AffineEnvironment.transform 15 8202 env35547 = env35548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env35547 == env35548) = true)

theorem identity35548 : scanCanonicalize (H12AffineFastState.compose env35548 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound35548 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env35549 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,8233,8202,16400,10280,1024,8232,17460,1,16,2,8193,64,10249,16400,4097,2048,1056,1,117,32,16464,512]

theorem envBound35549 : H12AffineFastState.Bounded env35549 := by
  intro p hp
  have h : env35549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35548_35549 : H12AffineEnvironment.transform 7 117 env35548 = env35549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env35548 == env35549) = true)

theorem identity35549 : scanCanonicalize (H12AffineFastState.compose env35549 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound35549 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35550 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,16384,0,35,16400,2049,1024,1,17460,1,16,2,40,64,2080,16400,4097,2048,1056,1,117,32,16464,512]

theorem envBound35550 : H12AffineFastState.Bounded env35550 := by
  intro p hp
  have h : env35550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35549_35550 : H12AffineEnvironment.transform 12 41 env35549 = env35550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env35549 == env35550) = true)

theorem identity35550 : scanCanonicalize (H12AffineFastState.compose env35550 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound35550 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env35551 : List Nat := [2,4,8,16,32,64,9,117,43,1024,2048,4096,41,16384,0,35,16400,2049,1024,1,17460,1,16,2,40,64,2080,16400,4097,2048,1056,1,117,32,16464,43]

theorem envBound35551 : H12AffineFastState.Bounded env35551 := by
  intro p hp
  have h : env35551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35550_35551 : H12AffineEnvironment.transform 8 43 env35550 = env35551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env35550 == env35551) = true)

theorem identity35551 : scanCanonicalize (H12AffineFastState.compose env35551 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound35551 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35552 : List Nat := [2,4,8,16,32,64,9,117,43,1024,2048,4096,41,5237,0,35,5221,2049,1024,1,4161,1,16,2,40,64,2080,5221,4097,2048,1056,1,117,32,5157,43]

theorem envBound35552 : H12AffineFastState.Bounded env35552 := by
  intro p hp
  have h : env35552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35551_35552 : H12AffineEnvironment.transform 13 5237 env35551 = env35552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env35551 == env35552) = true)

def env35553 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10400,1024,8541,2097152,4194304,152,2,8328,64,4262262,2172370,2119112,2420,75223,6383042,256,2188650,2172307,513]

theorem envBound35553 : H12AffineFastState.Bounded env35553 := by
  intro p hp
  have h : env35553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35543_35553 : H12AffineEnvironment.transform 16 16401 env35543 = env35553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env35543 == env35553) = true)

def env35554 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10280,1024,8541,2097152,4194304,16,2,8192,64,4262262,2172250,2118976,2420,75103,6382922,256,2188650,2172187,513]

theorem envBound35554 : H12AffineFastState.Bounded env35554 := by
  intro p hp
  have h : env35554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35553_35554 : H12AffineEnvironment.transform 6 8 env35553 = env35554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35553 == env35554) = true)

theorem identity35554 : scanCanonicalize (H12AffineFastState.compose env35554 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 91466) := by decide +kernel

theorem selectedBound35554 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env35555 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10280,1024,8541,91466,4194304,16,2,8192,64,4262262,16400,77834,2420,75103,4194304,256,32,16465,513]

theorem envBound35555 : H12AffineFastState.Bounded env35555 := by
  intro p hp
  have h : env35555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35554_35555 : H12AffineEnvironment.transform 20 91466 env35554 = env35555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91466 env35554 == env35555) = true)

theorem identity35555 : scanCanonicalize (H12AffineFastState.compose env35555 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound35555 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env35556 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,343,16401,10280,1024,8541,25629,4194304,16,2,8192,64,4196385,16400,12637,2420,9224,4194304,256,32,16465,513]

theorem envBound35556 : H12AffineFastState.Bounded env35556 := by
  intro p hp
  have h : env35556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35555_35556 : H12AffineEnvironment.transform 15 343 env35555 = env35556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env35555 == env35556) = true)

theorem identity35556 : scanCanonicalize (H12AffineFastState.compose env35556 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound35556 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35557 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,0,343,16401,2420,1024,1,17729,4194304,16,2,348,64,4196385,16400,4097,2420,1364,4194304,256,32,16465,513]

theorem envBound35557 : H12AffineFastState.Bounded env35557 := by
  intro p hp
  have h : env35557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35556_35557 : H12AffineEnvironment.transform 12 348 env35556 = env35557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env35556 == env35557) = true)

theorem identity35557 : scanCanonicalize (H12AffineFastState.compose env35557 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35557 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35558 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,0,262,16401,2341,1024,1,17680,4194304,16,2,269,17,4196385,16400,4097,2341,1285,4194304,256,32,16384,513]

theorem envBound35558 : H12AffineFastState.Bounded env35558 := by
  intro p hp
  have h : env35558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35557_35558 : H12AffineEnvironment.transform 5 17 env35557 = env35558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35557 == env35558) = true)

theorem identity35558 : scanCanonicalize (H12AffineFastState.compose env35558 (packedSelected [5,8] rootPS)) = affineNative (2^(21+1) ^^^ 21509) := by decide +kernel

theorem selectedBound35558 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env35559 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,0,262,16401,2341,1024,1,17680,21509,16,2,269,17,23588,16400,4097,2341,1285,21509,256,32,16384,513]

theorem envBound35559 : H12AffineFastState.Bounded env35559 := by
  intro p hp
  have h : env35559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35558_35559 : H12AffineEnvironment.transform 21 21509 env35558 = env35559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21509 env35558 == env35559) = true)

theorem identity35559 : scanCanonicalize (H12AffineFastState.compose env35559 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound35559 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env35560 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5156,0,262,5173,2341,1024,1,4404,33,16,2,269,17,2048,5172,4097,2341,1285,33,256,32,5156,513]

theorem envBound35560 : H12AffineFastState.Bounded env35560 := by
  intro p hp
  have h : env35560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35559_35560 : H12AffineEnvironment.transform 13 5156 env35559 = env35560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env35559 == env35560) = true)

def env35561 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3888,269,2836,0,262,2821,2341,1024,1,3588,33,16,2,269,17,2048,2820,3889,2341,1285,33,256,32,2836,513]

theorem envBound35561 : H12AffineFastState.Bounded env35561 := by
  intro p hp
  have h : env35561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35560_35561 : H12AffineEnvironment.transform 11 3888 env35560 = env35561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env35560 == env35561) = true)

def env35562 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,48,269,1044,0,262,1029,1573,1024,1,260,33,16,2,269,17,1792,1028,49,1573,1285,33,256,32,1044,513]

theorem envBound35562 : H12AffineFastState.Bounded env35562 := by
  intro p hp
  have h : env35562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35561_35562 : H12AffineEnvironment.transform 10 1792 env35561 = env35562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env35561 == env35562) = true)

theorem identity35562 : scanCanonicalize (H12AffineFastState.compose env35562 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 768) := by decide +kernel

theorem selectedBound35562 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35563 : List Nat := [2,4,8,16,32,17,8,256,512,768,0,48,269,788,0,262,773,293,768,1,260,33,16,2,269,17,0,772,49,293,517,33,256,32,788,513]

theorem envBound35563 : H12AffineFastState.Bounded env35563 := by
  intro p hp
  have h : env35563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35562_35563 : H12AffineEnvironment.transform 9 768 env35562 = env35563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env35562 == env35563) = true)

def env35564 : List Nat := [2,4,8,16,32,17,8,256,308,52,0,48,269,32,0,262,49,293,52,1,260,33,16,2,269,17,0,48,49,293,305,33,256,32,32,309]

theorem envBound35564 : H12AffineFastState.Bounded env35564 := by
  intro p hp
  have h : env35564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35563_35564 : H12AffineEnvironment.transform 8 308 env35563 = env35564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env35563 == env35564) = true)

theorem identity35564 : scanCanonicalize (H12AffineFastState.compose env35564 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound35564 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35565 : List Nat := [2,4,8,11,32,10,8,256,303,47,0,43,269,32,0,262,42,293,47,1,260,33,11,2,269,10,0,43,42,293,298,33,256,32,32,302]

theorem envBound35565 : H12AffineFastState.Bounded env35565 := by
  intro p hp
  have h : env35565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35564_35565 : H12AffineEnvironment.transform 3 11 env35564 = env35565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env35564 == env35565) = true)

def leafEnv35565 : List Nat := [2,4,8,11,32,10,8,256,303,47,0,43,269,32,0,262,42,293,47,1,260,33,11,2,298,269,1,10,0,43,42,293,298,33,256,32,4,262,32,302,1,260,0]

def active35565 : List Nat := [0,1,2,4,7]

def tree35565 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35565 : H12WitnessSearch.Good tree35565 := H12GlobalWitnessIndex.good

theorem leafIdentity35565 : H12AffineFastState.composeSystem env35565 rootObs = leafEnv35565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35565 rootObs == leafEnv35565) = true)

theorem terminalChecked35565 : H12PackedTerminal.terminalCheckFast leafEnv35565 active35565 tree35565 = true := by decide +kernel

def env35566 : List Nat := [2,4,8,16,32,17,8,256,309,53,0,48,269,33,0,262,48,293,53,1,260,33,16,2,269,17,0,49,49,293,304,33,256,32,33,308]

theorem envBound35566 : H12AffineFastState.Bounded env35566 := by
  intro p hp
  have h : env35566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35563_35566 : H12AffineEnvironment.transform 8 309 env35563 = env35566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env35563 == env35566) = true)

theorem identity35566 : scanCanonicalize (H12AffineFastState.compose env35566 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35566 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35567 : List Nat := [2,4,8,16,1,17,8,256,276,20,0,17,269,0,0,262,17,260,20,1,260,0,16,2,269,17,0,16,16,260,273,0,256,1,0,277]

theorem envBound35567 : H12AffineFastState.Bounded env35567 := by
  intro p hp
  have h : env35567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35566_35567 : H12AffineEnvironment.transform 4 1 env35566 = env35567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35566 == env35567) = true)

def leafEnv35567 : List Nat := [2,4,8,16,1,17,8,256,276,20,0,17,269,0,0,262,17,260,20,1,260,0,16,2,273,269,1,17,0,16,16,260,273,0,256,1,4,262,0,277,1,260,0]

def active35567 : List Nat := [0,1,2,3,7]

def tree35567 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35567 : H12WitnessSearch.Good tree35567 := H12GlobalWitnessIndex.good

theorem leafIdentity35567 : H12AffineFastState.composeSystem env35567 rootObs = leafEnv35567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35567 rootObs == leafEnv35567) = true)

theorem terminalChecked35567 : H12PackedTerminal.terminalCheckFast leafEnv35567 active35567 tree35567 = true := by decide +kernel

def env35568 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,49,269,1045,0,262,1028,1572,1024,1,261,33,16,2,269,17,1793,1029,48,1572,1285,33,256,32,1045,513]

theorem envBound35568 : H12AffineFastState.Bounded env35568 := by
  intro p hp
  have h : env35568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35561_35568 : H12AffineEnvironment.transform 10 1793 env35561 = env35568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env35561 == env35568) = true)

theorem identity35568 : scanCanonicalize (H12AffineFastState.compose env35568 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound35568 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35569 : List Nat := [2,4,8,16,32,17,8,256,16,1024,1297,49,269,1045,0,262,1028,1076,1024,1,261,33,16,2,269,17,1297,1029,48,1076,1285,33,256,32,1045,17]

theorem envBound35569 : H12AffineFastState.Bounded env35569 := by
  intro p hp
  have h : env35569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35568_35569 : H12AffineEnvironment.transform 8 16 env35568 = env35569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env35568 == env35569) = true)

def env35570 : List Nat := [2,4,8,16,32,17,8,256,16,52,293,49,269,33,0,262,48,0,52,1,261,33,16,2,269,17,293,49,48,0,305,33,256,32,33,17]

theorem envBound35570 : H12AffineFastState.Bounded env35570 := by
  intro p hp
  have h : env35570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35569_35570 : H12AffineEnvironment.transform 9 52 env35569 = env35570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env35569 == env35570) = true)

theorem identity35570 : scanCanonicalize (H12AffineFastState.compose env35570 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound35570 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35571 : List Nat := [2,4,8,10,32,11,8,256,10,46,293,43,269,33,0,262,42,0,46,1,261,33,10,2,269,11,293,43,42,0,299,33,256,32,33,11]

theorem envBound35571 : H12AffineFastState.Bounded env35571 := by
  intro p hp
  have h : env35571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35570_35571 : H12AffineEnvironment.transform 3 10 env35570 = env35571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env35570 == env35571) = true)

def leafEnv35571 : List Nat := [2,4,8,10,32,11,8,256,10,46,293,43,269,33,0,262,42,0,46,1,261,33,10,2,299,269,1,11,293,43,42,0,299,33,256,32,4,262,33,11,1,261,0]

def active35571 : List Nat := [0,1,2,4,7]

def tree35571 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35571 : H12WitnessSearch.Good tree35571 := H12GlobalWitnessIndex.good

theorem leafIdentity35571 : H12AffineFastState.composeSystem env35571 rootObs = leafEnv35571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35571 rootObs == leafEnv35571) = true)

theorem terminalChecked35571 : H12PackedTerminal.terminalCheckFast leafEnv35571 active35571 tree35571 = true := by decide +kernel

def env35572 : List Nat := [2,4,8,16,32,17,8,256,16,53,292,49,269,32,0,262,49,1,53,1,261,33,16,2,269,17,292,48,48,1,304,33,256,32,32,17]

theorem envBound35572 : H12AffineFastState.Bounded env35572 := by
  intro p hp
  have h : env35572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35569_35572 : H12AffineEnvironment.transform 9 53 env35569 = env35572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env35569 == env35572) = true)

theorem identity35572 : scanCanonicalize (H12AffineFastState.compose env35572 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound35572 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35573 : List Nat := [2,4,8,16,32,17,8,4,16,53,32,49,9,32,0,2,49,1,53,1,1,33,16,2,9,17,32,48,48,1,52,33,4,32,32,17]

theorem envBound35573 : H12AffineFastState.Bounded env35573 := by
  intro p hp
  have h : env35573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35572_35573 : H12AffineEnvironment.transform 7 4 env35572 = env35573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env35572 == env35573) = true)

def leafEnv35573 : List Nat := [2,4,8,16,32,17,8,4,16,53,32,49,9,32,0,2,49,1,53,1,1,33,16,2,52,9,1,17,32,48,48,1,52,33,4,32,4,2,32,17,1,1,0]

def active35573 : List Nat := [0,1,2,3,4]

def tree35573 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35573 : H12WitnessSearch.Good tree35573 := H12GlobalWitnessIndex.good

theorem leafIdentity35573 : H12AffineFastState.composeSystem env35573 rootObs = leafEnv35573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35573 rootObs == leafEnv35573) = true)

theorem terminalChecked35573 : H12PackedTerminal.terminalCheckFast leafEnv35573 active35573 tree35573 = true := by decide +kernel

def env35574 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3889,269,2837,0,262,2820,2341,1024,1,3589,33,16,2,269,17,2048,2821,3888,2341,1285,33,256,32,2837,513]

theorem envBound35574 : H12AffineFastState.Bounded env35574 := by
  intro p hp
  have h : env35574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35560_35574 : H12AffineEnvironment.transform 11 3889 env35560 = env35574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env35560 == env35574) = true)

def env35575 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,49,269,1045,0,262,1028,1573,1024,1,261,33,16,2,269,17,1792,1029,48,1573,1285,33,256,32,1045,513]

theorem envBound35575 : H12AffineFastState.Bounded env35575 := by
  intro p hp
  have h : env35575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35574_35575 : H12AffineEnvironment.transform 10 1792 env35574 = env35575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env35574 == env35575) = true)

theorem identity35575 : scanCanonicalize (H12AffineFastState.compose env35575 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound35575 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35576 : List Nat := [2,4,8,16,32,17,8,256,308,1024,1076,49,269,1045,0,262,1028,1297,1024,1,261,33,16,2,269,17,1076,1029,48,1297,1285,33,256,32,1045,309]

theorem envBound35576 : H12AffineFastState.Bounded env35576 := by
  intro p hp
  have h : env35576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35575_35576 : H12AffineEnvironment.transform 8 308 env35575 = env35576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env35575 == env35576) = true)

def env35577 : List Nat := [2,4,8,16,32,17,8,256,308,52,0,49,269,33,0,262,48,293,52,1,261,33,16,2,269,17,0,49,48,293,305,33,256,32,33,309]

theorem envBound35577 : H12AffineFastState.Bounded env35577 := by
  intro p hp
  have h : env35577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35576_35577 : H12AffineEnvironment.transform 9 52 env35576 = env35577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env35576 == env35577) = true)

theorem identity35577 : scanCanonicalize (H12AffineFastState.compose env35577 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound35577 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35578 : List Nat := [2,4,8,11,32,10,8,256,303,47,0,42,269,33,0,262,43,293,47,1,261,33,11,2,269,10,0,42,43,293,298,33,256,32,33,302]

theorem envBound35578 : H12AffineFastState.Bounded env35578 := by
  intro p hp
  have h : env35578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35577_35578 : H12AffineEnvironment.transform 3 11 env35577 = env35578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env35577 == env35578) = true)

def leafEnv35578 : List Nat := [2,4,8,11,32,10,8,256,303,47,0,42,269,33,0,262,43,293,47,1,261,33,11,2,298,269,1,10,0,42,43,293,298,33,256,32,4,262,33,302,1,261,0]

def active35578 : List Nat := [0,1,2,4,7]

def tree35578 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35578 : H12WitnessSearch.Good tree35578 := H12GlobalWitnessIndex.good

theorem leafIdentity35578 : H12AffineFastState.composeSystem env35578 rootObs = leafEnv35578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35578 rootObs == leafEnv35578) = true)

theorem terminalChecked35578 : H12PackedTerminal.terminalCheckFast leafEnv35578 active35578 tree35578 = true := by decide +kernel

def env35579 : List Nat := [2,4,8,16,32,17,8,256,308,53,1,49,269,32,0,262,49,292,53,1,261,33,16,2,269,17,1,48,48,292,304,33,256,32,32,309]

theorem envBound35579 : H12AffineFastState.Bounded env35579 := by
  intro p hp
  have h : env35579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35576_35579 : H12AffineEnvironment.transform 9 53 env35576 = env35579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env35576 == env35579) = true)

theorem identity35579 : scanCanonicalize (H12AffineFastState.compose env35579 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35579 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35580 : List Nat := [2,4,8,16,1,17,8,256,277,20,1,16,269,1,0,262,16,261,20,1,261,0,16,2,269,17,1,17,17,261,273,0,256,1,1,276]

theorem envBound35580 : H12AffineFastState.Bounded env35580 := by
  intro p hp
  have h : env35580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35579_35580 : H12AffineEnvironment.transform 4 1 env35579 = env35580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35579 == env35580) = true)

def leafEnv35580 : List Nat := [2,4,8,16,1,17,8,256,277,20,1,16,269,1,0,262,16,261,20,1,261,0,16,2,273,269,1,17,1,17,17,261,273,0,256,1,4,262,1,276,1,261,0]

def active35580 : List Nat := [0,1,2,3,7]

def tree35580 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35580 : H12WitnessSearch.Good tree35580 := H12GlobalWitnessIndex.good

theorem leafIdentity35580 : H12AffineFastState.composeSystem env35580 rootObs = leafEnv35580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35580 rootObs == leafEnv35580) = true)

theorem terminalChecked35580 : H12PackedTerminal.terminalCheckFast leafEnv35580 active35580 tree35580 = true := by decide +kernel

def env35581 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,48,269,1044,0,262,1029,1572,1024,1,260,33,16,2,269,17,1793,1028,49,1572,1285,33,256,32,1044,513]

theorem envBound35581 : H12AffineFastState.Bounded env35581 := by
  intro p hp
  have h : env35581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35574_35581 : H12AffineEnvironment.transform 10 1793 env35574 = env35581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env35574 == env35581) = true)

theorem identity35581 : scanCanonicalize (H12AffineFastState.compose env35581 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound35581 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35582 : List Nat := [2,4,8,16,32,17,8,256,512,548,293,48,269,560,0,262,545,0,548,1,260,33,16,2,269,17,293,544,49,0,801,33,256,32,560,513]

theorem envBound35582 : H12AffineFastState.Bounded env35582 := by
  intro p hp
  have h : env35582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35581_35582 : H12AffineEnvironment.transform 9 548 env35581 = env35582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env35581 == env35582) = true)

def env35583 : List Nat := [2,4,8,16,32,17,8,256,16,52,293,48,269,32,0,262,49,0,52,1,260,33,16,2,269,17,293,48,49,0,305,33,256,32,32,17]

theorem envBound35583 : H12AffineFastState.Bounded env35583 := by
  intro p hp
  have h : env35583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35582_35583 : H12AffineEnvironment.transform 8 16 env35582 = env35583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env35582 == env35583) = true)

theorem identity35583 : scanCanonicalize (H12AffineFastState.compose env35583 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound35583 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35584 : List Nat := [2,4,8,10,32,11,8,256,10,46,293,42,269,32,0,262,43,0,46,1,260,33,10,2,269,11,293,42,43,0,299,33,256,32,32,11]

theorem envBound35584 : H12AffineFastState.Bounded env35584 := by
  intro p hp
  have h : env35584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35583_35584 : H12AffineEnvironment.transform 3 10 env35583 = env35584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env35583 == env35584) = true)

def leafEnv35584 : List Nat := [2,4,8,10,32,11,8,256,10,46,293,42,269,32,0,262,43,0,46,1,260,33,10,2,299,269,1,11,293,42,43,0,299,33,256,32,4,262,32,11,1,260,0]

def active35584 : List Nat := [0,1,2,4,7]

def tree35584 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35584 : H12WitnessSearch.Good tree35584 := H12GlobalWitnessIndex.good

theorem leafIdentity35584 : H12AffineFastState.composeSystem env35584 rootObs = leafEnv35584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35584 rootObs == leafEnv35584) = true)

theorem terminalChecked35584 : H12PackedTerminal.terminalCheckFast leafEnv35584 active35584 tree35584 = true := by decide +kernel

def env35585 : List Nat := [2,4,8,16,32,17,8,256,17,53,293,48,269,33,0,262,48,0,53,1,260,33,16,2,269,17,293,49,49,0,304,33,256,32,33,16]

theorem envBound35585 : H12AffineFastState.Bounded env35585 := by
  intro p hp
  have h : env35585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35582_35585 : H12AffineEnvironment.transform 8 17 env35582 = env35585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env35582 == env35585) = true)

theorem identity35585 : scanCanonicalize (H12AffineFastState.compose env35585 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound35585 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35586 : List Nat := [2,4,8,16,32,17,8,4,17,53,33,48,9,33,0,2,48,0,53,1,0,33,16,2,9,17,33,49,49,0,52,33,4,32,33,16]

theorem envBound35586 : H12AffineFastState.Bounded env35586 := by
  intro p hp
  have h : env35586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35585_35586 : H12AffineEnvironment.transform 7 4 env35585 = env35586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env35585 == env35586) = true)

def leafEnv35586 : List Nat := [2,4,8,16,32,17,8,4,17,53,33,48,9,33,0,2,48,0,53,1,0,33,16,2,52,9,1,17,33,49,49,0,52,33,4,32,4,2,33,16,1,0,0]

def active35586 : List Nat := [0,1,2,3,4]

def tree35586 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35586 : H12WitnessSearch.Good tree35586 := H12GlobalWitnessIndex.good

theorem leafIdentity35586 : H12AffineFastState.composeSystem env35586 rootObs = leafEnv35586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35586 rootObs == leafEnv35586) = true)

theorem terminalChecked35586 : H12PackedTerminal.terminalCheckFast leafEnv35586 active35586 tree35586 = true := by decide +kernel

def env35587 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10281,1024,8541,2097152,4194304,17,2,8193,64,4262262,2172251,2118977,2420,75102,6382923,256,2188650,2172186,513]

theorem envBound35587 : H12AffineFastState.Bounded env35587 := by
  intro p hp
  have h : env35587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35553_35587 : H12AffineEnvironment.transform 6 9 env35553 = env35587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35553 == env35587) = true)

theorem identity35587 : scanCanonicalize (H12AffineFastState.compose env35587 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound35587 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env35588 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16401,10281,1024,8541,2097152,4194304,17,2,8193,64,4204925,2098512,2118977,2420,1365,6309184,256,2114913,2098449,513]

theorem envBound35588 : H12AffineFastState.Bounded env35588 := by
  intro p hp
  have h : env35588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35587_35588 : H12AffineEnvironment.transform 15 8203 env35587 = env35588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env35587 == env35588) = true)

theorem identity35588 : scanCanonicalize (H12AffineFastState.compose env35588 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 20528) := by decide +kernel

theorem selectedBound35588 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35589 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16401,10281,1024,8541,2097152,20528,17,2,8193,64,31053,2098512,2118977,2420,1365,2102640,256,2114913,2098449,513]

theorem envBound35589 : H12AffineFastState.Bounded env35589 := by
  intro p hp
  have h : env35589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35588_35589 : H12AffineEnvironment.transform 21 20528 env35588 = env35589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 20528 env35588 == env35589) = true)

theorem identity35589 : scanCanonicalize (H12AffineFastState.compose env35589 (packedSelected [4,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 10589) := by decide +kernel

theorem selectedBound35589 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env35590 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,10589,8540,8203,10572,10281,1024,8541,2097152,14701,17,2,8193,64,4112,2098512,2112540,2420,1365,2102640,256,2108476,2098449,513]

theorem envBound35590 : H12AffineFastState.Bounded env35590 := by
  intro p hp
  have h : env35590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35589_35590 : H12AffineEnvironment.transform 13 10589 env35589 = env35590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10589 env35589 == env35590) = true)

theorem identity35590 : scanCanonicalize (H12AffineFastState.compose env35590 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 5456) := by decide +kernel

theorem selectedBound35590 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35591 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,10589,8540,8203,10572,10281,1024,8541,5456,14701,17,2,8193,64,4112,4096,10572,2420,1365,32,256,14700,4161,513]

theorem envBound35591 : H12AffineFastState.Bounded env35591 := by
  intro p hp
  have h : env35591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35590_35591 : H12AffineEnvironment.transform 20 5456 env35590 = env35591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5456 env35590 == env35591) = true)

theorem identity35591 : scanCanonicalize (H12AffineFastState.compose env35591 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound35591 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35592 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2064,8192,10589,8540,8203,10572,10281,1024,8541,3392,8573,17,2,8193,64,2048,2064,10572,2420,1365,32,256,8572,2129,513]

theorem envBound35592 : H12AffineFastState.Bounded env35592 := by
  intro p hp
  have h : env35592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35591_35592 : H12AffineEnvironment.transform 11 2064 env35591 = env35592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env35591 == env35592) = true)

theorem identity35592 : scanCanonicalize (H12AffineFastState.compose env35592 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound35592 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env35593 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2064,1385,3124,1077,1378,3109,3392,1024,1076,3392,1044,17,2,1384,64,2048,2064,3109,2420,1365,32,256,1045,2129,513]

theorem envBound35593 : H12AffineFastState.Bounded env35593 := by
  intro p hp
  have h : env35593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35592_35593 : H12AffineEnvironment.transform 12 1385 env35592 = env35593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env35592 == env35593) = true)

theorem identity35593 : scanCanonicalize (H12AffineFastState.compose env35593 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound35593 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env35594 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,2064,349,2048,1,342,2065,2420,52,0,2420,32,17,2,348,64,2048,2064,2065,2420,353,32,256,33,2129,513]

theorem envBound35594 : H12AffineFastState.Bounded env35594 := by
  intro p hp
  have h : env35594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35593_35594 : H12AffineEnvironment.transform 9 52 env35593 = env35594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env35593 == env35594) = true)

theorem identity35594 : scanCanonicalize (H12AffineFastState.compose env35594 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound35594 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35595 : List Nat := [2,4,8,16,32,64,9,256,292,52,2048,2064,349,2048,1,342,2065,2420,52,0,2420,32,17,2,348,64,2048,2064,2065,2420,353,32,256,33,2129,293]

theorem envBound35595 : H12AffineFastState.Bounded env35595 := by
  intro p hp
  have h : env35595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35594_35595 : H12AffineEnvironment.transform 8 292 env35594 = env35595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env35594 == env35595) = true)

theorem identity35595 : scanCanonicalize (H12AffineFastState.compose env35595 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound35595 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env35596 : List Nat := [2,4,8,16,32,64,9,4,32,52,2048,2064,89,2048,1,82,2065,2160,52,0,2160,32,17,2,88,64,2048,2064,2065,2160,101,32,4,33,2129,33]

theorem envBound35596 : H12AffineFastState.Bounded env35596 := by
  intro p hp
  have h : env35596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35595_35596 : H12AffineEnvironment.transform 7 4 env35595 = env35596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env35595 == env35596) = true)

theorem identity35596 : scanCanonicalize (H12AffineFastState.compose env35596 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound35596 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env35597 : List Nat := [2,4,8,16,32,64,9,4,32,52,48,32,89,48,1,82,33,64,52,0,64,32,17,2,88,64,48,32,33,64,101,32,4,33,97,33]

theorem envBound35597 : H12AffineFastState.Bounded env35597 := by
  intro p hp
  have h : env35597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35596_35597 : H12AffineEnvironment.transform 10 48 env35596 = env35597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env35596 == env35597) = true)

theorem identity35597 : scanCanonicalize (H12AffineFastState.compose env35597 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35597 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35598 : List Nat := [2,4,8,16,1,64,9,4,1,21,17,1,89,17,1,82,0,64,21,0,64,1,17,2,88,64,17,1,0,64,68,1,4,0,64,0]

theorem envBound35598 : H12AffineFastState.Bounded env35598 := by
  intro p hp
  have h : env35598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35597_35598 : H12AffineEnvironment.transform 4 1 env35597 = env35598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35597 == env35598) = true)

theorem identity35598 : scanCanonicalize (H12AffineFastState.compose env35598 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound35598 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35599 : List Nat := [2,4,8,1,1,64,9,4,1,4,0,1,72,0,1,67,0,64,4,0,64,1,0,2,73,64,0,1,0,64,68,1,4,0,64,0]

theorem envBound35599 : H12AffineFastState.Bounded env35599 := by
  intro p hp
  have h : env35599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35598_35599 : H12AffineEnvironment.transform 3 1 env35598 = env35599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env35598 == env35599) = true)

theorem identity35599 : scanCanonicalize (H12AffineFastState.compose env35599 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound35599 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35600 : List Nat := [2,4,8,1,1,0,9,4,1,4,0,1,8,0,1,3,0,0,4,0,0,1,0,2,9,0,0,1,0,0,4,1,4,0,0,0]

theorem envBound35600 : H12AffineFastState.Bounded env35600 := by
  intro p hp
  have h : env35600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35599_35600 : H12AffineEnvironment.transform 5 0 env35599 = env35600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env35599 == env35600) = true)

def env35601 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830976,25265169,23160256,257,27378861,27337993,25207750]

theorem envBound35601 : H12AffineFastState.Bounded env35601 := by
  intro p hp
  have h : env35601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35438_35601 : H12AffineEnvironment.transform 18 1025 env35438 = env35601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env35438 == env35601) = true)

theorem identity35601 : scanCanonicalize (H12AffineFastState.compose env35601 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 254082) := by decide +kernel

theorem selectedBound35601 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env35602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,254082,16777216,8328,64,21241986,18973837,2340306,336002,16934035,23160256,257,19014703,19056011,16991044]

theorem envBound35602 : H12AffineFastState.Bounded env35602 := by
  intro p hp
  have h : env35602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35601_35602 : H12AffineEnvironment.transform 22 254082 env35601 = env35602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 254082 env35601 == env35602) = true)

def env35603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452632,254082,16777216,8328,64,16959642,18973837,2340306,336002,16934035,19369432,257,19014703,19056011,16991044]

theorem envBound35603 : H12AffineFastState.Bounded env35603 := by
  intro p hp
  have h : env35603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35602_35603 : H12AffineEnvironment.transform 21 452632 env35602 = env35603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452632 env35602 == env35603) = true)

def env35604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452632,254082,243088,8328,64,97546,2240797,2340306,336002,119043,2373704,257,2199999,2191387,63188]

theorem envBound35604 : H12AffineFastState.Bounded env35604 := by
  intro p hp
  have h : env35604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35603_35604 : H12AffineEnvironment.transform 23 243088 env35603 = env35604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 243088 env35603 == env35604) = true)

def env35605 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452632,254082,243088,8328,64,97546,139613,238994,336002,119043,272392,257,98815,90203,63188]

theorem envBound35605 : H12AffineFastState.Bounded env35605 := by
  intro p hp
  have h : env35605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35604_35605 : H12AffineEnvironment.transform 20 4160 env35604 = env35605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env35604 == env35605) = true)

theorem identity35605 : scanCanonicalize (H12AffineFastState.compose env35605 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49304) := by decide +kernel

theorem selectedBound35605 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35606 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,4160,272512,73754,95496,8328,64,97546,57797,91402,336002,119043,272392,257,98815,90203,63188]

theorem envBound35606 : H12AffineFastState.Bounded env35606 := by
  intro p hp
  have h : env35606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35605_35606 : H12AffineEnvironment.transform 16 49304 env35605 = env35606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env35605 == env35606) = true)

def env35607 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,4112,272512,73754,95496,8328,16,97546,57749,91402,336002,119043,272392,257,98735,90123,63108]

theorem envBound35607 : H12AffineFastState.Bounded env35607 := by
  intro p hp
  have h : env35607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35606_35607 : H12AffineEnvironment.transform 5 16 env35606 = env35607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35606 == env35607) = true)

theorem identity35607 : scanCanonicalize (H12AffineFastState.compose env35607 (packedSelected [3,15,17,19,24,31,38] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound35607 : packedSelected [3,15,17,19,24,31,38] rootPS < 2^1333 := by decide +kernel

def env35608 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,10280,1025,32769,4112,168,73754,95496,8328,16,97546,57749,91402,67754,119043,32,257,98735,90123,63108]

theorem envBound35608 : H12AffineFastState.Bounded env35608 := by
  intro p hp
  have h : env35608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35607_35608 : H12AffineEnvironment.transform 17 10280 env35607 = env35608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env35607 == env35608) = true)

theorem identity35608 : scanCanonicalize (H12AffineFastState.compose env35608 (packedSelected [0,1,2,4,5,6,9,10,11,16,17,23,24,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound35608 : packedSelected [0,1,2,4,5,6,9,10,11,16,17,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env35609 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,137,65536,16401,10280,1025,136,4112,168,73754,95496,8328,16,97546,24860,91402,67754,86410,32,257,65830,90123,30221]

theorem envBound35609 : H12AffineFastState.Bounded env35609 := by
  intro p hp
  have h : env35609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35608_35609 : H12AffineEnvironment.transform 14 137 env35608 = env35609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env35608 == env35609) = true)

theorem identity35609 : scanCanonicalize (H12AffineFastState.compose env35609 (packedSelected [1,2,3,4,5,6,8,10,11,17,18,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound35609 : packedSelected [1,2,3,4,5,6,8,10,11,17,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env35610 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,137,29962,16401,10280,1025,136,4112,168,21776,2,8328,16,2048,24860,4096,32160,9344,32,257,29740,5377,30221]

theorem envBound35610 : H12AffineFastState.Bounded env35610 := by
  intro p hp
  have h : env35610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35609_35610 : H12AffineEnvironment.transform 15 29962 env35609 = env35610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env35609 == env35610) = true)

theorem identity35610 : scanCanonicalize (H12AffineFastState.compose env35610 (packedSelected [0,2,6,7,11,17,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound35610 : packedSelected [0,2,6,7,11,17,18,20] rootPS < 2^1333 := by decide +kernel

def env35611 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,137,8202,5393,10280,1025,136,4112,168,16,2,8328,16,2048,13340,4096,10400,9344,32,257,8492,5377,8973]

theorem envBound35611 : H12AffineFastState.Bounded env35611 := by
  intro p hp
  have h : env35611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35610_35611 : H12AffineEnvironment.transform 13 5376 env35610 = env35611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env35610 == env35611) = true)

theorem identity35611 : scanCanonicalize (H12AffineFastState.compose env35611 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35611 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35612 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,0,8202,5393,10280,1025,1,4112,33,16,2,8193,16,2048,13340,4096,10281,9225,32,257,8492,5377,8973]

theorem envBound35612 : H12AffineFastState.Bounded env35612 := by
  intro p hp
  have h : env35612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35611_35612 : H12AffineEnvironment.transform 6 9 env35611 = env35612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35611 == env35612) = true)

theorem identity35612 : scanCanonicalize (H12AffineFastState.compose env35612 (packedSelected [0,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound35612 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env35613 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,4096,8192,5376,0,8202,5393,9244,1025,1,4112,33,16,2,8193,16,1076,13340,4096,9245,9225,32,257,8492,5377,8973]

theorem envBound35613 : H12AffineFastState.Bounded env35613 := by
  intro p hp
  have h : env35613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35612_35613 : H12AffineEnvironment.transform 10 1076 env35612 = env35613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env35612 == env35613) = true)

theorem identity35613 : scanCanonicalize (H12AffineFastState.compose env35613 (packedSelected [0,1,2,6,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound35613 : packedSelected [0,1,2,6,8,9] rootPS < 2^1333 := by decide +kernel

def env35614 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,308,8192,1076,0,8202,1061,9244,1025,1,292,33,16,2,8193,16,1076,9512,308,9245,9225,32,257,8492,1077,8973]

theorem envBound35614 : H12AffineFastState.Bounded env35614 := by
  intro p hp
  have h : env35614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35613_35614 : H12AffineEnvironment.transform 11 308 env35613 = env35614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env35613 == env35614) = true)

theorem identity35614 : scanCanonicalize (H12AffineFastState.compose env35614 (packedSelected [1,2,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound35614 : packedSelected [1,2,6,8] rootPS < 2^1333 := by decide +kernel

def env35615 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,308,8,1076,0,2,1061,1044,1025,1,292,33,16,2,9,16,1076,1312,308,1045,1025,32,257,292,1077,773]

theorem envBound35615 : H12AffineFastState.Bounded env35615 := by
  intro p hp
  have h : env35615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35614_35615 : H12AffineEnvironment.transform 12 8 env35614 = env35615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env35614 == env35615) = true)

theorem identity35615 : scanCanonicalize (H12AffineFastState.compose env35615 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35615 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env35616 : List Nat := [2,4,8,16,0,16,9,256,512,1024,1044,276,8,1044,0,2,1029,1044,1025,1,260,1,16,2,9,16,1044,1280,276,1045,1025,0,257,260,1045,773]

theorem envBound35616 : H12AffineFastState.Bounded env35616 := by
  intro p hp
  have h : env35616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35615_35616 : H12AffineEnvironment.transform 4 0 env35615 = env35616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35615 == env35616) = true)

theorem identity35616 : scanCanonicalize (H12AffineFastState.compose env35616 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound35616 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35617 : List Nat := [2,4,8,16,0,16,9,4,512,1024,1044,16,8,1044,0,2,1029,1044,1025,1,0,1,16,2,9,16,1044,1028,16,1045,1025,0,5,0,1045,513]

theorem envBound35617 : H12AffineFastState.Bounded env35617 := by
  intro p hp
  have h : env35617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35616_35617 : H12AffineEnvironment.transform 7 4 env35616 = env35617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env35616 == env35617) = true)

theorem identity35617 : scanCanonicalize (H12AffineFastState.compose env35617 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 21) := by decide +kernel

theorem selectedBound35617 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35618 : List Nat := [2,4,8,16,0,16,9,4,21,1024,1044,16,8,1044,0,2,1029,1044,1025,1,0,1,16,2,9,16,1044,1028,16,1045,1025,0,5,0,1045,20]

theorem envBound35618 : H12AffineFastState.Bounded env35618 := by
  intro p hp
  have h : env35618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35617_35618 : H12AffineEnvironment.transform 8 21 env35617 = env35618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 21 env35617 == env35618) = true)

theorem identity35618 : scanCanonicalize (H12AffineFastState.compose env35618 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound35618 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35619 : List Nat := [2,4,8,1,0,1,9,4,4,1024,1029,1,8,1029,0,2,1029,1029,1025,1,0,1,1,2,9,1,1029,1028,1,1028,1025,0,5,0,1028,5]

theorem envBound35619 : H12AffineFastState.Bounded env35619 := by
  intro p hp
  have h : env35619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35618_35619 : H12AffineEnvironment.transform 3 1 env35618 = env35619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env35618 == env35619) = true)

theorem identity35619 : scanCanonicalize (H12AffineFastState.compose env35619 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound35619 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35620 : List Nat := [2,4,2,1,0,1,3,4,4,1024,1029,1,2,1029,0,2,1029,1029,1025,1,0,1,1,2,3,1,1029,1028,1,1028,1025,0,5,0,1028,5]

theorem envBound35620 : H12AffineFastState.Bounded env35620 := by
  intro p hp
  have h : env35620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35619_35620 : H12AffineEnvironment.transform 2 2 env35619 = env35620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env35619 == env35620) = true)

def env35621 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,4113,272512,73754,95496,8328,17,97546,57748,91402,336002,119043,272392,257,98734,90122,63109]

theorem envBound35621 : H12AffineFastState.Bounded env35621 := by
  intro p hp
  have h : env35621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35606_35621 : H12AffineEnvironment.transform 5 17 env35606 = env35621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35606 == env35621) = true)

def env35622 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4113,272392,73754,95496,8192,17,97546,57628,91402,335882,119043,272392,257,98598,90122,62989]

theorem envBound35622 : H12AffineFastState.Bounded env35622 := by
  intro p hp
  have h : env35622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35621_35622 : H12AffineEnvironment.transform 6 8 env35621 = env35622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35621 == env35622) = true)

theorem identity35622 : scanCanonicalize (H12AffineFastState.compose env35622 (packedSelected [0,1,9,19,22,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 54279) := by decide +kernel

theorem selectedBound35622 : packedSelected [0,1,9,19,22,27,28,31] rootPS < 2^1333 := by decide +kernel

def env35623 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,54279,49168,262144,1025,32769,4113,272392,62493,41231,8192,17,43277,57628,45325,324621,1284,272392,257,21793,46093,62989]

theorem envBound35623 : H12AffineFastState.Bounded env35623 := by
  intro p hp
  have h : env35623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35622_35623 : H12AffineEnvironment.transform 15 54279 env35622 = env35623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54279 env35622 == env35623) = true)

theorem identity35623 : scanCanonicalize (H12AffineFastState.compose env35623 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound35623 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env35624 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,54279,49168,43048,1025,32769,4113,32800,62493,41231,8192,17,43277,57628,45325,23589,1284,32800,257,21793,46093,62989]

theorem envBound35624 : H12AffineFastState.Bounded env35624 := by
  intro p hp
  have h : env35624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35623_35624 : H12AffineEnvironment.transform 17 43048 env35623 = env35624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env35623 == env35624) = true)

theorem identity35624 : scanCanonicalize (H12AffineFastState.compose env35624 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound35624 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env35625 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,16384,32768,54279,49168,43048,1025,32769,4113,32800,62493,41003,8192,17,43049,57400,45097,23589,1056,32800,37,21509,46093,62989]

theorem envBound35625 : H12AffineFastState.Bounded env35625 := by
  intro p hp
  have h : env35625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35624_35625 : H12AffineEnvironment.transform 7 36 env35624 = env35625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env35624 == env35625) = true)

theorem identity35625 : scanCanonicalize (H12AffineFastState.compose env35625 (packedSelected [3,5,10,12,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound35625 : packedSelected [3,5,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env35626 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,16384,32768,54279,49168,34817,1025,32769,4113,32800,54324,32770,41,17,34816,49169,36864,23589,1056,32800,37,21509,37924,54820]

theorem envBound35626 : H12AffineFastState.Bounded env35626 := by
  intro p hp
  have h : env35626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35625_35626 : H12AffineEnvironment.transform 12 41 env35625 = env35626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env35625 == env35626) = true)

theorem identity35626 : scanCanonicalize (H12AffineFastState.compose env35626 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound35626 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env35627 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,5124,32768,32771,37908,34817,1025,32769,4113,32800,32816,32770,41,17,34816,37909,36864,2081,1056,32800,37,1,37924,33312]

theorem envBound35627 : H12AffineFastState.Bounded env35627 := by
  intro p hp
  have h : env35627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35626_35627 : H12AffineEnvironment.transform 13 5124 env35626 = env35627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env35626 == env35627) = true)

theorem identity35627 : scanCanonicalize (H12AffineFastState.compose env35627 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 33) := by decide +kernel

theorem selectedBound35627 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35628 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,5124,33,34,5173,2080,1025,32,4113,1,17,35,41,17,2081,5172,4129,2081,1056,1,37,1,5125,513]

theorem envBound35628 : H12AffineFastState.Bounded env35628 := by
  intro p hp
  have h : env35628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35627_35628 : H12AffineEnvironment.transform 14 33 env35627 = env35628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 33 env35627 == env35628) = true)

theorem identity35628 : scanCanonicalize (H12AffineFastState.compose env35628 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound35628 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env35629 : List Nat := [2,4,8,16,32,17,8,36,512,1024,528,4096,41,5124,33,34,5173,560,1025,32,4113,1,17,35,41,17,561,5172,4129,561,1056,1,37,1,5125,513]

theorem envBound35629 : H12AffineFastState.Bounded env35629 := by
  intro p hp
  have h : env35629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35628_35629 : H12AffineEnvironment.transform 10 528 env35628 = env35629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env35628 == env35629) = true)

theorem identity35629 : scanCanonicalize (H12AffineFastState.compose env35629 (packedSelected [0,1,4,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 1572) := by decide +kernel

theorem selectedBound35629 : packedSelected [0,1,4,8,10] rootPS < 2^1333 := by decide +kernel

def env35630 : List Nat := [2,4,8,16,32,17,8,36,512,1024,528,1572,41,544,33,34,529,560,1025,32,1589,1,17,35,41,17,561,528,1541,561,1056,1,37,1,545,513]

theorem envBound35630 : H12AffineFastState.Bounded env35630 := by
  intro p hp
  have h : env35630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35629_35630 : H12AffineEnvironment.transform 11 1572 env35629 = env35630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1572 env35629 == env35630) = true)

theorem identity35630 : scanCanonicalize (H12AffineFastState.compose env35630 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound35630 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env35631 : List Nat := [2,4,8,16,32,17,8,36,512,20,528,560,41,544,33,34,529,560,21,32,545,1,17,35,41,17,561,528,529,561,52,1,37,1,545,513]

theorem envBound35631 : H12AffineFastState.Bounded env35631 := by
  intro p hp
  have h : env35631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35630_35631 : H12AffineEnvironment.transform 9 20 env35630 = env35631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env35630 == env35631) = true)

theorem identity35631 : scanCanonicalize (H12AffineFastState.compose env35631 (packedSelected [1,2,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35631 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env35632 : List Nat := [2,4,8,16,1,17,8,5,512,20,528,529,8,513,0,3,529,529,21,1,512,1,17,2,8,17,528,528,529,528,21,1,4,1,512,513]

theorem envBound35632 : H12AffineFastState.Bounded env35632 := by
  intro p hp
  have h : env35632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35631_35632 : H12AffineEnvironment.transform 4 1 env35631 = env35632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35631 == env35632) = true)

theorem identity35632 : scanCanonicalize (H12AffineFastState.compose env35632 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound35632 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35633 : List Nat := [2,4,8,16,1,17,8,5,4,20,20,21,8,5,0,3,21,21,21,1,4,1,17,2,8,17,20,20,21,20,21,1,4,1,4,5]

theorem envBound35633 : H12AffineFastState.Bounded env35633 := by
  intro p hp
  have h : env35633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35632_35633 : H12AffineEnvironment.transform 8 4 env35632 = env35633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env35632 == env35633) = true)

theorem identity35633 : scanCanonicalize (H12AffineFastState.compose env35633 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound35633 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35634 : List Nat := [2,4,8,9,1,8,8,5,4,13,13,12,8,5,0,3,12,12,12,1,4,1,8,2,8,8,13,13,12,13,12,1,4,1,4,5]

theorem envBound35634 : H12AffineFastState.Bounded env35634 := by
  intro p hp
  have h : env35634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35633_35634 : H12AffineEnvironment.transform 3 9 env35633 = env35634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env35633 == env35634) = true)

theorem identity35634 : scanCanonicalize (H12AffineFastState.compose env35634 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound35634 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35635 : List Nat := [2,4,1,0,1,1,1,5,4,4,4,5,1,5,0,3,5,5,5,1,4,1,1,2,1,1,4,4,5,4,5,1,4,1,4,5]

theorem envBound35635 : H12AffineFastState.Bounded env35635 := by
  intro p hp
  have h : env35635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35634_35635 : H12AffineEnvironment.transform 2 1 env35634 = env35635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env35634 == env35635) = true)

theorem identity35635 : scanCanonicalize (H12AffineFastState.compose env35635 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound35635 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env35636 : List Nat := [1,4,1,0,1,1,1,5,4,4,4,5,1,5,0,0,5,5,5,1,4,1,1,1,1,1,4,4,5,4,5,1,4,1,4,5]

theorem envBound35636 : H12AffineFastState.Bounded env35636 := by
  intro p hp
  have h : env35636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35635_35636 : H12AffineEnvironment.transform 0 1 env35635 = env35636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env35635 == env35636) = true)

theorem identity35636 : scanCanonicalize (H12AffineFastState.compose env35636 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound35636 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env35637 : List Nat := [1,0,1,0,1,1,1,1,0,0,0,1,1,1,0,0,1,1,1,1,0,1,1,1,1,1,0,0,1,0,1,1,0,1,0,1]

theorem envBound35637 : H12AffineFastState.Bounded env35637 := by
  intro p hp
  have h : env35637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35636_35637 : H12AffineEnvironment.transform 1 0 env35636 = env35637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env35636 == env35637) = true)

def env35638 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4113,272393,73754,95496,8193,17,97546,57629,91402,335883,119043,272392,257,98599,90122,62988]

theorem envBound35638 : H12AffineFastState.Bounded env35638 := by
  intro p hp
  have h : env35638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35621_35638 : H12AffineEnvironment.transform 6 9 env35621 = env35638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35621 == env35638) = true)

theorem identity35638 : scanCanonicalize (H12AffineFastState.compose env35638 (packedSelected [0,1,9,19,22,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound35638 : packedSelected [0,1,9,19,22,27,28,31] rootPS < 2^1333 := by decide +kernel

def env35639 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,40971,49169,262144,1025,32769,4113,272393,32785,54531,8193,17,56577,57629,50433,294912,28936,272392,257,8492,49153,62988]

theorem envBound35639 : H12AffineFastState.Bounded env35639 := by
  intro p hp
  have h : env35639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35638_35639 : H12AffineEnvironment.transform 15 40971 env35638 = env35639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env35638 == env35639) = true)

theorem identity35639 : scanCanonicalize (H12AffineFastState.compose env35639 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound35639 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env35640 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29709,21510,13340,262144,1025,29708,4113,272393,29724,8462,8193,17,10508,5392,12556,291853,28936,272392,257,8492,13324,513]

theorem envBound35640 : H12AffineFastState.Bounded env35640 := by
  intro p hp
  have h : env35640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35639_35640 : H12AffineEnvironment.transform 14 29709 env35639 = env35640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env35639 == env35640) = true)

theorem identity35640 : scanCanonicalize (H12AffineFastState.compose env35640 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound35640 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35641 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,21761,21510,5392,262144,1025,21760,4113,264453,21776,2,269,17,2048,5392,4096,283905,20484,264452,257,32,5376,513]

theorem envBound35641 : H12AffineFastState.Bounded env35641 := by
  intro p hp
  have h : env35641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35640_35641 : H12AffineEnvironment.transform 12 268 env35640 = env35641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env35640 == env35641) = true)

theorem identity35641 : scanCanonicalize (H12AffineFastState.compose env35641 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound35641 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env35642 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,21761,21510,5392,2341,1025,21760,4113,32,21776,2,269,17,2048,5392,4096,23588,20484,33,257,32,5376,513]

theorem envBound35642 : H12AffineFastState.Bounded env35642 := by
  intro p hp
  have h : env35642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35641_35642 : H12AffineEnvironment.transform 17 2341 env35641 = env35642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env35641 == env35642) = true)

theorem identity35642 : scanCanonicalize (H12AffineFastState.compose env35642 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound35642 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35643 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,268,16384,20497,20758,4096,2341,273,20496,4113,32,20480,2,269,17,2048,4096,4096,22836,20484,33,257,32,4112,513]

theorem envBound35643 : H12AffineFastState.Bounded env35643 := by
  intro p hp
  have h : env35643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35642_35643 : H12AffineEnvironment.transform 9 272 env35642 = env35643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env35642 == env35643) = true)

theorem identity35643 : scanCanonicalize (H12AffineFastState.compose env35643 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 6453) := by decide +kernel

theorem selectedBound35643 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env35644 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,268,6453,2340,2083,4096,2341,273,2341,4113,32,2357,2,269,17,2048,4096,4096,1,2353,33,257,32,4112,513]

theorem envBound35644 : H12AffineFastState.Bounded env35644 := by
  intro p hp
  have h : env35644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35643_35644 : H12AffineEnvironment.transform 13 6453 env35643 = env35644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6453 env35643 == env35644) = true)

theorem identity35644 : scanCanonicalize (H12AffineFastState.compose env35644 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound35644 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env35645 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,2064,268,293,2340,2083,2064,2341,273,2341,2049,32,2357,2,269,17,2048,2064,2064,1,2353,33,257,32,2048,513]

theorem envBound35645 : H12AffineFastState.Bounded env35645 := by
  intro p hp
  have h : env35645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35644_35645 : H12AffineEnvironment.transform 11 2064 env35644 = env35645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env35644 == env35645) = true)

theorem identity35645 : scanCanonicalize (H12AffineFastState.compose env35645 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound35645 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35646 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,2064,40,1,2048,2083,2064,2049,53,2049,2049,32,2065,2,41,17,2048,2064,2064,1,2069,33,37,32,2048,513]

theorem envBound35646 : H12AffineFastState.Bounded env35646 := by
  intro p hp
  have h : env35646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35645_35646 : H12AffineEnvironment.transform 7 36 env35645 = env35646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env35645 == env35646) = true)

theorem identity35646 : scanCanonicalize (H12AffineFastState.compose env35646 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound35646 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env35647 : List Nat := [2,4,8,16,32,17,9,36,512,52,1,17,40,1,1,34,17,0,53,0,0,32,16,2,41,17,1,17,17,1,20,33,37,32,1,513]

theorem envBound35647 : H12AffineFastState.Bounded env35647 := by
  intro p hp
  have h : env35647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35646_35647 : H12AffineEnvironment.transform 10 1 env35646 = env35647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env35646 == env35647) = true)

theorem identity35647 : scanCanonicalize (H12AffineFastState.compose env35647 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound35647 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35648 : List Nat := [2,4,8,16,27,17,9,31,512,15,1,17,19,1,1,25,17,0,14,0,0,27,16,2,18,17,1,17,17,1,20,26,30,27,1,513]

theorem envBound35648 : H12AffineFastState.Bounded env35648 := by
  intro p hp
  have h : env35648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35647_35648 : H12AffineEnvironment.transform 4 27 env35647 = env35648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env35647 == env35648) = true)

def env35649 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452632,254082,243088,8328,64,97546,139612,238995,336002,119043,272393,257,98814,90202,63188]

theorem envBound35649 : H12AffineFastState.Bounded env35649 := by
  intro p hp
  have h : env35649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35604_35649 : H12AffineEnvironment.transform 20 4161 env35604 = env35649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env35604 == env35649) = true)

def env35650 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,4161,180408,254082,243088,8328,64,97546,139612,238995,67618,119043,169,257,98814,90202,63188]

theorem envBound35650 : H12AffineFastState.Bounded env35650 := by
  intro p hp
  have h : env35650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35649_35650 : H12AffineEnvironment.transform 17 10400 env35649 = env35650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env35649 == env35650) = true)

def env35651 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4161,180272,253962,242968,8192,64,97546,139612,238875,67618,119043,33,257,98678,90202,63068]

theorem envBound35651 : H12AffineFastState.Bounded env35651 := by
  intro p hp
  have h : env35651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35650_35651 : H12AffineEnvironment.transform 6 8 env35650 = env35651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35650 == env35651) = true)

theorem identity35651 : scanCanonicalize (H12AffineFastState.compose env35651 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound35651 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35652 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10280,1025,32769,4161,98679,41293,62559,8192,64,97546,90139,58460,67618,119043,33,257,98678,90202,63068]

theorem envBound35652 : H12AffineFastState.Bounded env35652 := by
  intro p hp
  have h : env35652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35651_35652 : H12AffineEnvironment.transform 16 82247 env35651 = env35652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env35651 == env35652) = true)

theorem identity35652 : scanCanonicalize (H12AffineFastState.compose env35652 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound35652 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env35653 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,82247,2421,1025,32769,4161,98679,32784,54530,349,64,89175,82246,50433,67618,119043,33,257,98678,82183,55041]

theorem envBound35653 : H12AffineFastState.Bounded env35653 := by
  intro p hp
  have h : env35653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35652_35653 : H12AffineEnvironment.transform 12 349 env35652 = env35653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env35652 == env35653) = true)

theorem identity35653 : scanCanonicalize (H12AffineFastState.compose env35653 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound35653 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env35654 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,32768,65536,70727,2421,1025,32769,4161,98679,32784,32770,349,64,67927,70726,36865,67618,99331,33,257,98678,70663,33281]

theorem envBound35654 : H12AffineFastState.Bounded env35654 := by
  intro p hp
  have h : env35654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35653_35654 : H12AffineEnvironment.transform 13 5376 env35653 = env35654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env35653 == env35654) = true)

theorem identity35654 : scanCanonicalize (H12AffineFastState.compose env35654 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound35654 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35655 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,1,65536,70727,2421,1025,0,4161,65910,17,3,349,64,67927,70726,4096,67618,66562,33,257,65911,70663,512]

theorem envBound35655 : H12AffineFastState.Bounded env35655 := by
  intro p hp
  have h : env35655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35654_35655 : H12AffineEnvironment.transform 14 1 env35654 = env35655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env35654 == env35655) = true)

theorem identity35655 : scanCanonicalize (H12AffineFastState.compose env35655 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35655 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env35656 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,1,65536,70678,2340,1025,0,4112,65831,17,3,268,17,67846,70679,4096,67618,66562,33,257,65830,70663,512]

theorem envBound35656 : H12AffineFastState.Bounded env35656 := by
  intro p hp
  have h : env35656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35655_35656 : H12AffineEnvironment.transform 5 17 env35655 = env35656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35655 == env35656) = true)

theorem identity35656 : scanCanonicalize (H12AffineFastState.compose env35656 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35656 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35657 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,268,5376,1,65536,70678,2308,1025,0,4112,65799,17,3,268,17,67846,70679,4096,67586,66562,1,257,65798,70663,512]

theorem envBound35657 : H12AffineFastState.Bounded env35657 := by
  intro p hp
  have h : env35657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35656_35657 : H12AffineEnvironment.transform 4 0 env35656 = env35657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35656 == env35657) = true)

theorem identity35657 : scanCanonicalize (H12AffineFastState.compose env35657 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound35657 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env35658 : List Nat := [2,4,8,16,0,17,8,20,512,1024,2048,4096,24,5140,1,65536,70678,2064,1025,0,4112,65555,17,3,24,17,67602,70679,4096,67586,66562,1,21,65554,70663,512]

theorem envBound35658 : H12AffineFastState.Bounded env35658 := by
  intro p hp
  have h : env35658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35657_35658 : H12AffineEnvironment.transform 7 20 env35657 = env35658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env35657 == env35658) = true)

def env35659 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4161,180273,253963,242969,8193,64,97546,139612,238874,67618,119043,32,257,98679,90202,63069]

theorem envBound35659 : H12AffineFastState.Bounded env35659 := by
  intro p hp
  have h : env35659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35650_35659 : H12AffineEnvironment.transform 6 9 env35650 = env35659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35650 == env35659) = true)

theorem identity35659 : scanCanonicalize (H12AffineFastState.compose env35659 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound35659 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35660 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10281,1025,32769,4161,73770,16,21762,8193,64,97546,115015,17665,67618,119043,32,257,98679,90202,63069]

theorem envBound35660 : H12AffineFastState.Bounded env35660 := by
  intro p hp
  have h : env35660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35659_35660 : H12AffineEnvironment.transform 16 122907 env35659 = env35660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env35659 == env35660) = true)

theorem identity35660 : scanCanonicalize (H12AffineFastState.compose env35660 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound35660 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env35661 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,65536,103494,10281,1025,32769,4161,73770,16,8543,8193,64,67927,111898,12636,67618,107870,32,257,98679,70663,33280]

theorem envBound35661 : H12AffineFastState.Bounded env35661 := by
  intro p hp
  have h : env35661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35660_35661 : H12AffineEnvironment.transform 13 13405 env35660 = env35661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env35660 == env35661) = true)

theorem identity35661 : scanCanonicalize (H12AffineFastState.compose env35661 (packedSelected [0,2,3,4,5,6,9,10,11,16,18,27] rootPS)) = affineNative (2^(15+1) ^^^ 1330) := by decide +kernel

theorem selectedBound35661 : packedSelected [0,2,3,4,5,6,9,10,11,16,18,27] rootPS < 2^1333 := by decide +kernel

def env35662 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,1330,37236,10281,1025,32769,4161,9496,16,8543,8193,64,3173,45096,12636,3344,41068,32,257,33861,4405,33280]

theorem envBound35662 : H12AffineFastState.Bounded env35662 := by
  intro p hp
  have h : env35662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35661_35662 : H12AffineEnvironment.transform 15 1330 env35661 = env35662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1330 env35661 == env35662) = true)

theorem identity35662 : scanCanonicalize (H12AffineFastState.compose env35662 (packedSelected [1,4,8,9,11,14,16,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound35662 : packedSelected [1,4,8,9,11,14,16,18,19] rootPS < 2^1333 := by decide +kernel

def env35663 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8460,1330,12408,10281,1025,8461,4161,9496,16,8543,8193,64,3173,4388,12636,3344,352,32,257,9545,4405,8972]

theorem envBound35663 : H12AffineFastState.Bounded env35663 := by
  intro p hp
  have h : env35663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35662_35663 : H12AffineEnvironment.transform 14 8460 env35662 = env35663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env35662 == env35663) = true)

theorem identity35663 : scanCanonicalize (H12AffineFastState.compose env35663 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound35663 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env35664 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1384,4405,1124,1330,5392,3393,1025,1125,4161,112,16,1079,1385,64,3173,4388,5172,3344,352,32,257,33,4405,1636]

theorem envBound35664 : H12AffineFastState.Bounded env35664 := by
  intro p hp
  have h : env35664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35663_35664 : H12AffineEnvironment.transform 12 1384 env35663 = env35664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env35663 == env35664) = true)

theorem identity35664 : scanCanonicalize (H12AffineFastState.compose env35664 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound35664 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35665 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,41,4405,293,115,4177,2048,320,292,4161,112,16,374,40,64,2340,4388,4469,2129,352,32,257,33,4405,805]

theorem envBound35665 : H12AffineFastState.Bounded env35665 := by
  intro p hp
  have h : env35665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35664_35665 : H12AffineEnvironment.transform 9 321 env35664 = env35665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env35664 == env35665) = true)

theorem identity35665 : scanCanonicalize (H12AffineFastState.compose env35665 (packedSelected [0,1,4,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound35665 : packedSelected [0,1,4,8,11] rootPS < 2^1333 := by decide +kernel

def env35666 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,2113,41,2420,293,115,2064,2048,320,292,2048,112,16,374,40,64,2340,2405,2356,2129,352,32,257,33,2420,805]

theorem envBound35666 : H12AffineFastState.Bounded env35666 := by
  intro p hp
  have h : env35666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35665_35666 : H12AffineEnvironment.transform 11 2113 env35665 = env35666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env35665 == env35666) = true)

theorem identity35666 : scanCanonicalize (H12AffineFastState.compose env35666 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35666 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env35667 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,2065,41,2340,293,35,2064,2048,272,292,2048,32,16,294,40,16,2340,2357,2356,2049,304,32,257,33,2340,805]

theorem envBound35667 : H12AffineFastState.Bounded env35667 := by
  intro p hp
  have h : env35667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35666_35667 : H12AffineEnvironment.transform 5 16 env35666 = env35667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35666 == env35667) = true)

def env35668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,4161,180409,254082,243088,8328,64,97546,139612,238995,67619,119043,168,257,98814,90202,63188]

theorem envBound35668 : H12AffineFastState.Bounded env35668 := by
  intro p hp
  have h : env35668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35649_35668 : H12AffineEnvironment.transform 17 10401 env35649 = env35668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env35649 == env35668) = true)

def env35669 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4161,180273,253962,242968,8192,64,97546,139612,238875,67619,119043,32,257,98678,90202,63068]

theorem envBound35669 : H12AffineFastState.Bounded env35669 := by
  intro p hp
  have h : env35669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35668_35669 : H12AffineEnvironment.transform 6 8 env35668 = env35669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35668 == env35669) = true)

theorem identity35669 : scanCanonicalize (H12AffineFastState.compose env35669 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound35669 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35670 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1025,8540,4161,156012,213335,201797,8192,64,97546,139612,197702,67619,94302,32,257,73771,90202,22273]

theorem envBound35670 : H12AffineFastState.Bounded env35670 := by
  intro p hp
  have h : env35670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35669_35670 : H12AffineEnvironment.transform 14 8541 env35669 = env35670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env35669 == env35670) = true)

theorem identity35670 : scanCanonicalize (H12AffineFastState.compose env35670 (packedSelected [1,2,6,8,9,11,12,14,15,16,19,20,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound35670 : packedSelected [1,2,6,8,9,11,12,14,15,16,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env35671 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,13389,10281,1025,8540,4161,21793,95514,73736,8192,64,97546,5393,77835,67619,94302,32,257,73771,90202,22273]

theorem envBound35671 : H12AffineFastState.Bounded env35671 := by
  intro p hp
  have h : env35671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35670_35671 : H12AffineEnvironment.transform 16 13389 env35670 = env35671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env35670 == env35671) = true)

theorem identity35671 : scanCanonicalize (H12AffineFastState.compose env35671 (packedSelected [0,1,4,7,8,19,22] rootPS)) = affineNative (2^(15+1) ^^^ 20806) := by decide +kernel

theorem selectedBound35671 : packedSelected [0,1,4,7,8,19,22] rootPS < 2^1333 := by decide +kernel

def env35672 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,20806,13389,10281,1025,8540,4161,21793,9308,29006,8192,64,11340,5393,24909,22885,8472,32,257,29037,12572,22273]

theorem envBound35672 : H12AffineFastState.Bounded env35672 := by
  intro p hp
  have h : env35672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35671_35672 : H12AffineEnvironment.transform 15 20806 env35671 = env35672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20806 env35671 == env35672) = true)

theorem identity35672 : scanCanonicalize (H12AffineFastState.compose env35672 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 12392) := by decide +kernel

theorem selectedBound35672 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env35673 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12392,8541,8494,13389,10281,1025,8540,4161,9545,9308,294,8192,64,11340,5393,4389,10509,8472,32,257,261,12572,10089]

theorem envBound35673 : H12AffineFastState.Bounded env35673 := by
  intro p hp
  have h : env35673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35672_35673 : H12AffineEnvironment.transform 13 12392 env35672 = env35673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12392 env35672 == env35673) = true)

theorem identity35673 : scanCanonicalize (H12AffineFastState.compose env35673 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,14,19] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound35673 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,14,19] rootPS < 2^1333 := by decide +kernel

def env35674 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1385,5377,1076,1095,4388,3392,1025,1077,4161,32,309,294,1385,64,2341,5393,4389,3172,1137,32,257,261,5237,512]

theorem envBound35674 : H12AffineFastState.Bounded env35674 := by
  intro p hp
  have h : env35674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35673_35674 : H12AffineEnvironment.transform 12 1385 env35673 = env35674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env35673 == env35674) = true)

theorem identity35674 : scanCanonicalize (H12AffineFastState.compose env35674 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound35674 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env35675 : List Nat := [2,4,8,16,32,64,8,84,512,1024,2048,4096,1085,5205,1076,1095,4208,3092,1025,1077,4161,32,97,114,1085,64,2161,5189,4209,3172,1137,32,85,81,5237,512]

theorem envBound35675 : H12AffineFastState.Bounded env35675 := by
  intro p hp
  have h : env35675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35674_35675 : H12AffineEnvironment.transform 7 84 env35674 = env35675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env35674 == env35675) = true)

theorem identity35675 : scanCanonicalize (H12AffineFastState.compose env35675 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 1093) := by decide +kernel

theorem selectedBound35675 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env35676 : List Nat := [2,4,8,16,32,64,8,84,512,1024,1093,4096,1085,5205,1076,1095,4208,81,1025,1077,4161,32,97,114,1085,64,1076,5189,4209,33,1137,32,85,81,5237,512]

theorem envBound35676 : H12AffineFastState.Bounded env35676 := by
  intro p hp
  have h : env35676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35675_35676 : H12AffineEnvironment.transform 10 1093 env35675 = env35676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1093 env35675 == env35676) = true)

theorem identity35676 : scanCanonicalize (H12AffineFastState.compose env35676 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 96) := by decide +kernel

theorem selectedBound35676 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env35677 : List Nat := [2,4,8,16,32,64,8,84,512,1024,1093,96,1085,1077,1076,1095,16,81,1025,1077,33,32,97,114,1085,64,1076,1061,17,33,1137,32,85,81,1045,512]

theorem envBound35677 : H12AffineFastState.Bounded env35677 := by
  intro p hp
  have h : env35677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35676_35677 : H12AffineEnvironment.transform 11 96 env35676 = env35677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 96 env35676 == env35677) = true)

theorem identity35677 : scanCanonicalize (H12AffineFastState.compose env35677 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound35677 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env35678 : List Nat := [2,4,8,16,32,64,8,84,512,20,81,96,41,33,32,83,16,81,21,33,33,32,97,114,41,64,32,49,17,33,101,32,85,81,1,512]

theorem envBound35678 : H12AffineFastState.Bounded env35678 := by
  intro p hp
  have h : env35678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35677_35678 : H12AffineEnvironment.transform 9 20 env35677 = env35678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env35677 == env35678) = true)

theorem identity35678 : scanCanonicalize (H12AffineFastState.compose env35678 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35678 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env35679 : List Nat := [2,4,8,16,32,16,8,4,512,20,1,48,41,33,32,3,16,1,21,33,33,32,49,34,41,16,32,49,17,33,53,32,5,1,1,512]

theorem envBound35679 : H12AffineFastState.Bounded env35679 := by
  intro p hp
  have h : env35679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35678_35679 : H12AffineEnvironment.transform 5 16 env35678 = env35679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35678 == env35679) = true)

theorem identity35679 : scanCanonicalize (H12AffineFastState.compose env35679 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 53) := by decide +kernel

theorem selectedBound35679 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35680 : List Nat := [2,4,8,16,32,16,8,4,53,20,1,48,41,33,32,3,16,1,21,33,33,32,49,34,41,16,32,49,17,33,53,32,5,1,1,53]

theorem envBound35680 : H12AffineFastState.Bounded env35680 := by
  intro p hp
  have h : env35680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35679_35680 : H12AffineEnvironment.transform 8 53 env35679 = env35680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 53 env35679 == env35680) = true)

theorem identity35680 : scanCanonicalize (H12AffineFastState.compose env35680 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound35680 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35681 : List Nat := [2,4,8,16,17,16,8,4,4,20,1,1,24,16,17,3,16,1,21,16,16,17,0,19,24,16,17,0,17,16,4,17,5,1,1,4]

theorem envBound35681 : H12AffineFastState.Bounded env35681 := by
  intro p hp
  have h : env35681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35680_35681 : H12AffineEnvironment.transform 4 17 env35680 = env35681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env35680 == env35681) = true)

theorem identity35681 : scanCanonicalize (H12AffineFastState.compose env35681 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound35681 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env35682 : List Nat := [2,4,8,4,5,4,8,4,4,0,1,1,12,4,5,3,4,1,1,4,4,5,0,7,12,4,5,0,5,4,4,5,5,1,1,4]

theorem envBound35682 : H12AffineFastState.Bounded env35682 := by
  intro p hp
  have h : env35682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35681_35682 : H12AffineEnvironment.transform 3 4 env35681 = env35682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env35681 == env35682) = true)

theorem identity35682 : scanCanonicalize (H12AffineFastState.compose env35682 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound35682 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35683 : List Nat := [2,1,8,1,0,1,8,1,1,0,1,1,9,1,0,3,1,1,1,1,1,0,0,2,9,1,0,0,0,1,1,0,0,1,1,1]

theorem envBound35683 : H12AffineFastState.Bounded env35683 := by
  intro p hp
  have h : env35683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35682_35683 : H12AffineEnvironment.transform 1 1 env35682 = env35683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env35682 == env35683) = true)

def env35684 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4161,180272,253963,242969,8193,64,97546,139612,238874,67619,119043,33,257,98679,90202,63069]

theorem envBound35684 : H12AffineFastState.Bounded env35684 := by
  intro p hp
  have h : env35684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35668_35684 : H12AffineEnvironment.transform 6 9 env35668 = env35684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35668 == env35684) = true)

theorem identity35684 : scanCanonicalize (H12AffineFastState.compose env35684 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound35684 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env35685 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10280,1025,29789,4161,144492,201815,213317,8193,64,97546,139612,217414,67619,75103,33,257,95531,90202,513]

theorem envBound35685 : H12AffineFastState.Bounded env35685 := by
  intro p hp
  have h : env35685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35684_35685 : H12AffineEnvironment.transform 14 29788 env35684 = env35685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env35684 == env35685) = true)

theorem identity35685 : scanCanonicalize (H12AffineFastState.compose env35685 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound35685 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env35686 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,82247,10280,1025,29789,4161,95531,21776,2,8193,64,97546,90139,4097,67619,75103,33,257,95531,90202,513]

theorem envBound35686 : H12AffineFastState.Bounded env35686 := by
  intro p hp
  have h : env35686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35685_35686 : H12AffineEnvironment.transform 16 82247 env35685 = env35686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env35685 == env35686) = true)

theorem identity35686 : scanCanonicalize (H12AffineFastState.compose env35686 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound35686 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env35687 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,263,16448,10280,1025,29789,4161,29740,21776,2,8193,64,31757,24860,4097,2340,9304,33,257,29740,24925,513]

theorem envBound35687 : H12AffineFastState.Bounded env35687 := by
  intro p hp
  have h : env35687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35686_35687 : H12AffineEnvironment.transform 15 263 env35686 = env35687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env35686 == env35687) = true)

theorem identity35687 : scanCanonicalize (H12AffineFastState.compose env35687 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound35687 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env35688 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,263,5441,10280,1025,8540,4161,8493,17,2,8193,64,10508,13341,4097,2340,9304,33,257,8493,13404,513]

theorem envBound35688 : H12AffineFastState.Bounded env35688 := by
  intro p hp
  have h : env35688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35687_35688 : H12AffineEnvironment.transform 13 5377 env35687 = env35688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env35687 == env35688) = true)

theorem identity35688 : scanCanonicalize (H12AffineFastState.compose env35688 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound35688 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35689 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,263,5441,2421,1025,1,4161,112,17,2,348,64,2129,5440,4097,2340,1285,33,257,112,5377,513]

theorem envBound35689 : H12AffineFastState.Bounded env35689 := by
  intro p hp
  have h : env35689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35688_35689 : H12AffineEnvironment.transform 12 349 env35688 = env35689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env35688 == env35689) = true)

theorem identity35689 : scanCanonicalize (H12AffineFastState.compose env35689 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1589) := by decide +kernel

theorem selectedBound35689 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env35690 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1589,4096,349,5377,0,263,5441,1856,1025,1,4161,112,17,2,348,64,1636,5440,4097,1809,1285,33,257,112,5377,513]

theorem envBound35690 : H12AffineFastState.Bounded env35690 := by
  intro p hp
  have h : env35690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35689_35690 : H12AffineEnvironment.transform 10 1589 env35689 = env35690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1589 env35689 == env35690) = true)

theorem identity35690 : scanCanonicalize (H12AffineFastState.compose env35690 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 325) := by decide +kernel

theorem selectedBound35690 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env35691 : List Nat := [2,4,8,16,32,64,9,256,325,1024,1392,4096,349,5377,0,263,5441,1029,1025,1,4161,112,17,2,348,64,1313,5440,4097,1108,1285,33,257,112,5377,324]

theorem envBound35691 : H12AffineFastState.Bounded env35691 := by
  intro p hp
  have h : env35691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35690_35691 : H12AffineEnvironment.transform 8 325 env35690 = env35691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 325 env35690 == env35691) = true)

theorem identity35691 : scanCanonicalize (H12AffineFastState.compose env35691 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 117) := by decide +kernel

theorem selectedBound35691 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env35692 : List Nat := [2,4,8,16,32,64,9,256,325,117,261,4096,349,4468,0,263,4404,112,116,1,4161,112,17,2,348,64,340,4405,4097,33,368,33,257,112,4468,324]

theorem envBound35692 : H12AffineFastState.Bounded env35692 := by
  intro p hp
  have h : env35692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35691_35692 : H12AffineEnvironment.transform 9 117 env35691 = env35692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 117 env35691 == env35692) = true)

theorem identity35692 : scanCanonicalize (H12AffineFastState.compose env35692 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound35692 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35693 : List Nat := [2,4,8,16,32,64,9,256,325,117,261,261,349,113,0,263,49,112,116,1,324,112,17,2,348,64,340,48,260,33,368,33,257,112,113,324]

theorem envBound35693 : H12AffineFastState.Bounded env35693 := by
  intro p hp
  have h : env35693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35692_35693 : H12AffineEnvironment.transform 11 261 env35692 = env35693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env35692 == env35693) = true)

theorem identity35693 : scanCanonicalize (H12AffineFastState.compose env35693 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound35693 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35694 : List Nat := [2,4,8,16,32,64,9,53,112,117,48,48,104,113,0,50,49,112,116,1,113,112,17,2,105,64,97,48,49,33,69,33,52,112,113,113]

theorem envBound35694 : H12AffineFastState.Bounded env35694 := by
  intro p hp
  have h : env35694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35693_35694 : H12AffineEnvironment.transform 7 53 env35693 = env35694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env35693 == env35694) = true)

theorem identity35694 : scanCanonicalize (H12AffineFastState.compose env35694 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound35694 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35695 : List Nat := [2,4,8,10,32,64,9,47,106,111,42,42,104,107,0,40,43,106,110,1,107,106,11,2,105,64,97,42,43,33,69,33,46,106,107,107]

theorem envBound35695 : H12AffineFastState.Bounded env35695 := by
  intro p hp
  have h : env35695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35694_35695 : H12AffineEnvironment.transform 3 10 env35694 = env35695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env35694 == env35695) = true)

theorem identity35695 : scanCanonicalize (H12AffineFastState.compose env35695 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound35695 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env35696 : List Nat := [2,4,8,10,32,0,9,47,42,47,42,42,40,43,0,40,43,42,46,1,43,42,11,2,41,0,33,42,43,33,5,33,46,42,43,43]

theorem envBound35696 : H12AffineFastState.Bounded env35696 := by
  intro p hp
  have h : env35696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35695_35696 : H12AffineEnvironment.transform 5 0 env35695 = env35696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env35695 == env35696) = true)

theorem identity35696 : scanCanonicalize (H12AffineFastState.compose env35696 (packedSelected [3,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound35696 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env35697 : List Nat := [2,4,8,10,10,0,9,5,0,5,0,0,2,1,0,2,1,0,4,1,1,0,11,2,3,0,11,0,1,11,5,11,4,0,1,1]

theorem envBound35697 : H12AffineFastState.Bounded env35697 := by
  intro p hp
  have h : env35697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35696_35697 : H12AffineEnvironment.transform 4 10 env35696 = env35697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env35696 == env35697) = true)

theorem identity35697 : scanCanonicalize (H12AffineFastState.compose env35697 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound35697 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env35698 : List Nat := [2,4,2,0,0,0,3,5,0,5,0,0,2,1,0,2,1,0,4,1,1,0,1,2,3,0,1,0,1,1,5,1,4,0,1,1]

theorem envBound35698 : H12AffineFastState.Bounded env35698 := by
  intro p hp
  have h : env35698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35697_35698 : H12AffineEnvironment.transform 2 2 env35697 = env35698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env35697 == env35698) = true)

def env35699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452632,254082,243089,8328,64,97547,2240796,2340306,336002,119042,2373705,257,2199998,2191386,63189]

theorem envBound35699 : H12AffineFastState.Bounded env35699 := by
  intro p hp
  have h : env35699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35603_35699 : H12AffineEnvironment.transform 23 243089 env35603 = env35699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 243089 env35603 == env35699) = true)

def env35700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452632,254082,243089,8328,64,97547,139612,238994,336002,119042,272393,257,98814,90202,63189]

theorem envBound35700 : H12AffineFastState.Bounded env35700 := by
  intro p hp
  have h : env35700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35699_35700 : H12AffineEnvironment.transform 20 4160 env35699 = env35700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env35699 == env35700) = true)

theorem identity35700 : scanCanonicalize (H12AffineFastState.compose env35700 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound35700 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,4160,400588,201814,213317,8328,64,97547,139612,217414,336002,75222,272393,257,95530,90202,513]

theorem envBound35701 : H12AffineFastState.Bounded env35701 := by
  intro p hp
  have h : env35701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35700_35701 : H12AffineEnvironment.transform 14 29908 env35700 = env35701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env35700 == env35701) = true)

def env35702 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,4160,400452,201814,213317,8192,64,97547,139612,217414,335882,75102,272393,257,95530,90202,513]

theorem envBound35702 : H12AffineFastState.Bounded env35702 := by
  intro p hp
  have h : env35702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35701_35702 : H12AffineEnvironment.transform 6 8 env35701 = env35702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35701 == env35702) = true)

theorem identity35702 : scanCanonicalize (H12AffineFastState.compose env35702 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound35702 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env35703 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90138,262144,1025,29789,4160,359518,29772,8543,8192,64,97547,82246,12636,335882,75102,272393,257,95530,90202,513]

theorem envBound35703 : H12AffineFastState.Bounded env35703 := by
  intro p hp
  have h : env35703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35702_35703 : H12AffineEnvironment.transform 16 90138 env35702 = env35703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env35702 == env35703) = true)

theorem identity35703 : scanCanonicalize (H12AffineFastState.compose env35703 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 3172) := by decide +kernel

theorem selectedBound35703 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env35704 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90138,3172,1025,29789,4160,94266,29772,8543,8192,64,97547,82246,12636,76910,75102,9325,257,95530,90202,513]

theorem envBound35704 : H12AffineFastState.Bounded env35704 := by
  intro p hp
  have h : env35704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35703_35704 : H12AffineEnvironment.transform 17 3172 env35703 = env35704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3172 env35703 == env35704) = true)

theorem identity35704 : scanCanonicalize (H12AffineFastState.compose env35704 (packedSelected [4,7,9,12,15,18,23,27,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 12572) := by decide +kernel

theorem selectedBound35704 : packedSelected [4,7,9,12,15,18,23,27,38,41] rootPS < 2^1333 := by decide +kernel

def env35705 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12572,1344,65536,69894,3172,1025,1345,4160,65830,1360,8543,8192,64,68631,77914,12636,76910,75102,9325,257,66614,69958,513]

theorem envBound35705 : H12AffineFastState.Bounded env35705 := by
  intro p hp
  have h : env35705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35704_35705 : H12AffineEnvironment.transform 13 12572 env35704 = env35705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12572 env35704 == env35705) = true)

theorem identity35705 : scanCanonicalize (H12AffineFastState.compose env35705 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 1047) := by decide +kernel

theorem selectedBound35705 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env35706 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12572,1344,1047,5393,3172,1025,1345,4160,1329,1360,8543,8192,64,2048,13389,12636,10361,8521,9325,257,33,5457,513]

theorem envBound35706 : H12AffineFastState.Bounded env35706 := by
  intro p hp
  have h : env35706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35705_35706 : H12AffineEnvironment.transform 15 1047 env35705 = env35706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1047 env35705 == env35706) = true)

theorem identity35706 : scanCanonicalize (H12AffineFastState.compose env35706 (packedSelected [12,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound35706 : packedSelected [12,15,17] rootPS < 2^1333 := by decide +kernel

def env35707 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,12393,1077,1047,5220,3172,1025,1076,4160,1092,1061,8234,8192,64,2048,13389,12329,10361,8252,9325,116,33,5156,513]

theorem envBound35707 : H12AffineFastState.Bounded env35707 := by
  intro p hp
  have h : env35707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35706_35707 : H12AffineEnvironment.transform 7 117 env35706 = env35707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env35706 == env35707) = true)

theorem identity35707 : scanCanonicalize (H12AffineFastState.compose env35707 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound35707 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env35708 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,1100,5157,1077,1047,5220,3172,1025,1076,4160,1092,1061,1126,1100,64,2048,4097,5221,3125,1136,33,116,33,5156,513]

theorem envBound35708 : H12AffineFastState.Bounded env35708 := by
  intro p hp
  have h : env35708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35707_35708 : H12AffineEnvironment.transform 12 1100 env35707 = env35708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env35707 == env35708) = true)

theorem identity35708 : scanCanonicalize (H12AffineFastState.compose env35708 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound35708 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env35709 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,4096,121,4112,0,34,4177,2129,52,1,4160,113,16,83,121,64,2048,4097,4176,2048,69,33,116,33,4113,513]

theorem envBound35709 : H12AffineFastState.Bounded env35709 := by
  intro p hp
  have h : env35709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35708_35709 : H12AffineEnvironment.transform 9 53 env35708 = env35709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env35708 == env35709) = true)

theorem identity35709 : scanCanonicalize (H12AffineFastState.compose env35709 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound35709 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env35710 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,2065,121,2049,0,34,2112,2129,52,1,2129,113,16,83,121,64,2048,2064,2113,2048,69,33,116,33,2048,513]

theorem envBound35710 : H12AffineFastState.Bounded env35710 := by
  intro p hp
  have h : env35710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35709_35710 : H12AffineEnvironment.transform 11 2065 env35709 = env35710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env35709 == env35710) = true)

def env35711 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,4160,400453,201814,213317,8193,64,97547,139612,217414,335883,75103,272393,257,95530,90202,513]

theorem envBound35711 : H12AffineFastState.Bounded env35711 := by
  intro p hp
  have h : env35711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35701_35711 : H12AffineEnvironment.transform 6 9 env35701 = env35711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35701 == env35711) = true)

theorem identity35711 : scanCanonicalize (H12AffineFastState.compose env35711 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound35711 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env35712 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,32040,1025,29788,4160,156013,201814,213317,8193,64,97547,139612,217414,89379,75103,21793,257,95530,90202,513]

theorem envBound35712 : H12AffineFastState.Bounded env35712 := by
  intro p hp
  have h : env35712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35711_35712 : H12AffineEnvironment.transform 17 32040 env35711 = env35712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env35711 == env35712) = true)

theorem identity35712 : scanCanonicalize (H12AffineFastState.compose env35712 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound35712 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env35713 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,343,131072,32040,1025,29788,4160,156013,136449,147474,8193,64,31836,139612,151569,23668,9224,21793,257,29821,24845,513]

theorem envBound35713 : H12AffineFastState.Bounded env35713 := by
  intro p hp
  have h : env35713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35712_35713 : H12AffineEnvironment.transform 15 343 env35712 = env35713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env35712 == env35713) = true)

theorem identity35713 : scanCanonicalize (H12AffineFastState.compose env35713 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound35713 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env35714 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,0,343,131072,2421,1025,1,4160,136496,136449,144463,8193,64,2049,139612,140364,10281,9224,8572,257,32,5456,513]

theorem envBound35714 : H12AffineFastState.Bounded env35714 := by
  intro p hp
  have h : env35714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35713_35714 : H12AffineEnvironment.transform 13 13405 env35713 = env35714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env35713 == env35714) = true)

theorem identity35714 : scanCanonicalize (H12AffineFastState.compose env35714 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound35714 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env35715 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,343,131072,2421,1025,1,4160,136496,136449,136466,348,64,2049,131073,132369,2420,1365,33,257,32,5456,513]

theorem envBound35715 : H12AffineFastState.Bounded env35715 := by
  intro p hp
  have h : env35715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35714_35715 : H12AffineEnvironment.transform 12 349 env35714 = env35715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env35714 == env35715) = true)

theorem identity35715 : scanCanonicalize (H12AffineFastState.compose env35715 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound35715 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35716 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,343,5392,2421,1025,1,4160,32,17,2,348,64,2049,5393,4097,2420,1365,33,257,32,5456,513]

theorem envBound35716 : H12AffineFastState.Bounded env35716 := by
  intro p hp
  have h : env35716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35715_35716 : H12AffineEnvironment.transform 16 5392 env35715 = env35716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env35715 == env35716) = true)

theorem identity35716 : scanCanonicalize (H12AffineFastState.compose env35716 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 833) := by decide +kernel

theorem selectedBound35716 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35717 : List Nat := [2,4,8,16,32,64,9,256,512,833,2048,4096,349,4673,0,343,4689,2421,832,1,4160,32,17,2,348,64,2049,4688,4097,2420,532,33,257,32,4625,513]

theorem envBound35717 : H12AffineFastState.Bounded env35717 := by
  intro p hp
  have h : env35717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35716_35717 : H12AffineEnvironment.transform 9 833 env35716 = env35717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 833 env35716 == env35717) = true)

theorem identity35717 : scanCanonicalize (H12AffineFastState.compose env35717 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35717 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35718 : List Nat := [2,4,8,16,32,16,9,256,512,785,2048,4096,269,4625,0,263,4609,2341,784,1,4112,32,17,2,268,16,2049,4608,4097,2340,532,33,257,32,4625,513]

theorem envBound35718 : H12AffineFastState.Bounded env35718 := by
  intro p hp
  have h : env35718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35717_35718 : H12AffineEnvironment.transform 5 16 env35717 = env35718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35717 == env35718) = true)

theorem identity35718 : scanCanonicalize (H12AffineFastState.compose env35718 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound35718 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35719 : List Nat := [2,4,8,16,32,16,9,256,512,785,2048,261,269,788,0,263,772,2341,784,1,277,32,17,2,268,16,2049,773,260,2340,532,33,257,32,788,513]

theorem envBound35719 : H12AffineFastState.Bounded env35719 := by
  intro p hp
  have h : env35719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35718_35719 : H12AffineEnvironment.transform 11 261 env35718 = env35719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env35718 == env35719) = true)

theorem identity35719 : scanCanonicalize (H12AffineFastState.compose env35719 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound35719 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35720 : List Nat := [2,4,8,16,32,16,9,256,512,785,293,261,269,788,0,263,772,0,784,1,277,32,17,2,268,16,292,773,260,1,532,33,257,32,788,513]

theorem envBound35720 : H12AffineFastState.Bounded env35720 := by
  intro p hp
  have h : env35720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35719_35720 : H12AffineEnvironment.transform 10 293 env35719 = env35720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env35719 == env35720) = true)

theorem identity35720 : scanCanonicalize (H12AffineFastState.compose env35720 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound35720 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env35721 : List Nat := [2,4,8,0,32,0,9,256,512,769,293,261,269,772,0,263,772,0,768,1,261,32,1,2,268,0,292,773,260,1,516,33,257,32,772,513]

theorem envBound35721 : H12AffineFastState.Bounded env35721 := by
  intro p hp
  have h : env35721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35720_35721 : H12AffineEnvironment.transform 3 0 env35720 = env35721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env35720 == env35721) = true)

theorem identity35721 : scanCanonicalize (H12AffineFastState.compose env35721 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound35721 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env35722 : List Nat := [2,4,8,0,32,0,9,256,261,4,293,261,269,1,0,263,1,0,5,1,261,32,1,2,268,0,292,0,260,1,257,33,257,32,1,260]

theorem envBound35722 : H12AffineFastState.Bounded env35722 := by
  intro p hp
  have h : env35722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35721_35722 : H12AffineEnvironment.transform 8 261 env35721 = env35722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env35721 == env35722) = true)

def env35723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452632,254082,243089,8328,64,97547,139613,238995,336002,119042,272392,257,98815,90203,63189]

theorem envBound35723 : H12AffineFastState.Bounded env35723 := by
  intro p hp
  have h : env35723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35699_35723 : H12AffineEnvironment.transform 20 4161 env35699 = env35723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env35699 == env35723) = true)

theorem identity35723 : scanCanonicalize (H12AffineFastState.compose env35723 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound35723 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,262144,1025,32769,4161,318548,120014,98781,8328,64,97547,5393,102879,336002,119042,272392,257,98815,90203,63189]

theorem envBound35724 : H12AffineFastState.Bounded env35724 := by
  intro p hp
  have h : env35724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35723_35724 : H12AffineEnvironment.transform 16 13388 env35723 = env35724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env35723 == env35724) = true)

def env35725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,10400,1025,32769,4161,62708,120014,98781,8328,64,97547,5393,102879,67618,119042,168,257,98815,90203,63189]

theorem envBound35725 : H12AffineFastState.Bounded env35725 := by
  intro p hp
  have h : env35725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35724_35725 : H12AffineEnvironment.transform 17 10400 env35724 = env35725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env35724 == env35725) = true)

theorem identity35725 : scanCanonicalize (H12AffineFastState.compose env35725 (packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound35725 : packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS < 2^1333 := by decide +kernel

def env35726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8232,65536,13388,10400,1025,8233,4161,21724,95462,74229,8328,64,97547,5393,78327,67618,94506,168,257,74199,90203,22269]

theorem envBound35726 : H12AffineFastState.Bounded env35726 := by
  intro p hp
  have h : env35726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35725_35726 : H12AffineEnvironment.transform 14 8232 env35725 = env35726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env35725 == env35726) = true)

theorem identity35726 : scanCanonicalize (H12AffineFastState.compose env35726 (packedSelected [0,1,7,8,9,12,14,16,18,22,23,26,38] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound35726 : packedSelected [0,1,7,8,9,12,14,16,18,22,23,26,38] rootPS < 2^1333 := by decide +kernel

def env35727 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,8232,65536,13388,10400,1025,8233,4161,21724,95462,73857,8328,64,97407,5221,77955,67618,94302,168,117,73891,90203,22269]

theorem envBound35727 : H12AffineFastState.Bounded env35727 := by
  intro p hp
  have h : env35727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35726_35727 : H12AffineEnvironment.transform 7 116 env35726 = env35727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env35726 == env35727) = true)

theorem identity35727 : scanCanonicalize (H12AffineFastState.compose env35727 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29823) := by decide +kernel

theorem selectedBound35727 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35728 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,8232,29823,13388,10400,1025,8233,4161,21724,153,21758,8328,64,2048,5221,17660,31837,1057,168,117,21724,5156,22269]

theorem envBound35728 : H12AffineFastState.Bounded env35728 := by
  intro p hp
  have h : env35728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35727_35728 : H12AffineEnvironment.transform 15 29823 env35727 = env35728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29823 env35727 == env35728) = true)

theorem identity35728 : scanCanonicalize (H12AffineFastState.compose env35728 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35728 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env35729 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,8232,29823,13388,10281,1025,8233,4161,21589,16,21623,8193,64,2048,5221,17525,31837,1057,33,117,21589,5156,22132]

theorem envBound35729 : H12AffineFastState.Bounded env35729 := by
  intro p hp
  have h : env35729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35728_35729 : H12AffineEnvironment.transform 6 9 env35728 = env35729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35728 == env35729) = true)

theorem identity35729 : scanCanonicalize (H12AffineFastState.compose env35729 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound35729 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env35730 : List Nat := [2,4,8,16,32,64,9,116,512,53,2048,4096,8192,16384,8232,28746,12409,10281,52,8233,4161,20576,16,20546,8193,64,2048,4176,16448,30824,20,33,117,20576,4113,21057]

theorem envBound35730 : H12AffineFastState.Bounded env35730 := by
  intro p hp
  have h : env35730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35729_35730 : H12AffineEnvironment.transform 9 53 env35729 = env35730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env35729 == env35730) = true)

theorem identity35730 : scanCanonicalize (H12AffineFastState.compose env35730 (packedSelected [1,2,6,8,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 8233) := by decide +kernel

theorem selectedBound35730 : packedSelected [1,2,6,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env35731 : List Nat := [2,4,8,16,32,64,9,116,512,53,2048,4096,8192,8233,8232,4195,12409,10281,52,8233,4161,12361,16,12395,8193,64,2048,4176,8297,6209,20,33,117,12361,4113,12904]

theorem envBound35731 : H12AffineFastState.Bounded env35731 := by
  intro p hp
  have h : env35731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35730_35731 : H12AffineEnvironment.transform 13 8233 env35730 = env35731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8233 env35730 == env35731) = true)

theorem identity35731 : scanCanonicalize (H12AffineFastState.compose env35731 (packedSelected [0,2,3,5,7,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 2168) := by decide +kernel

theorem selectedBound35731 : packedSelected [0,2,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env35732 : List Nat := [2,4,8,16,32,64,9,116,512,53,2048,4096,2168,2129,2128,4195,6145,81,52,2129,4161,6193,16,6163,2169,64,2048,4176,2065,6209,20,33,117,6193,4113,6672]

theorem envBound35732 : H12AffineFastState.Bounded env35732 := by
  intro p hp
  have h : env35732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35731_35732 : H12AffineEnvironment.transform 12 2168 env35731 = env35732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2168 env35731 == env35732) = true)

theorem identity35732 : scanCanonicalize (H12AffineFastState.compose env35732 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound35732 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env35733 : List Nat := [2,4,8,16,32,64,9,116,512,53,2048,2064,2168,2129,2128,2163,17,81,52,2129,2129,33,16,3,2169,64,2048,2112,2065,81,20,33,117,33,2049,512]

theorem envBound35733 : H12AffineFastState.Bounded env35733 := by
  intro p hp
  have h : env35733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35732_35733 : H12AffineEnvironment.transform 11 2064 env35732 = env35733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env35732 == env35733) = true)

theorem identity35733 : scanCanonicalize (H12AffineFastState.compose env35733 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound35733 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35734 : List Nat := [2,4,8,16,32,64,9,116,512,53,33,49,89,112,113,82,17,81,52,112,112,33,16,3,88,64,33,97,48,81,20,33,117,33,32,512]

theorem envBound35734 : H12AffineFastState.Bounded env35734 := by
  intro p hp
  have h : env35734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35733_35734 : H12AffineEnvironment.transform 10 33 env35733 = env35734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env35733 == env35734) = true)

theorem identity35734 : scanCanonicalize (H12AffineFastState.compose env35734 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35734 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35735 : List Nat := [2,4,8,16,32,16,9,36,512,53,33,49,9,32,33,2,17,1,52,32,32,33,16,3,8,16,33,49,48,1,20,33,37,33,32,512]

theorem envBound35735 : H12AffineFastState.Bounded env35735 := by
  intro p hp
  have h : env35735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35734_35735 : H12AffineEnvironment.transform 5 16 env35734 = env35735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35734 == env35735) = true)

theorem identity35735 : scanCanonicalize (H12AffineFastState.compose env35735 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35735 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env35736 : List Nat := [2,4,8,16,1,16,9,5,512,20,0,16,9,1,0,2,17,1,21,1,1,0,16,3,8,16,0,16,17,1,20,0,4,0,1,512]

theorem envBound35736 : H12AffineFastState.Bounded env35736 := by
  intro p hp
  have h : env35736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35735_35736 : H12AffineEnvironment.transform 4 1 env35735 = env35736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35735 == env35736) = true)

def env35737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,10401,1025,32769,4161,62709,120014,98781,8328,64,97547,5393,102879,67619,119042,169,257,98815,90203,63189]

theorem envBound35737 : H12AffineFastState.Bounded env35737 := by
  intro p hp
  have h : env35737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35724_35737 : H12AffineEnvironment.transform 17 10401 env35724 = env35737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env35724 == env35737) = true)

theorem identity35737 : scanCanonicalize (H12AffineFastState.compose env35737 (packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound35737 : packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS < 2^1333 := by decide +kernel

def env35738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,13388,10401,1025,32769,4161,62709,17,21762,8328,64,43476,5393,17664,56572,1501,169,257,21792,46212,63189]

theorem envBound35738 : H12AffineFastState.Bounded env35738 := by
  intro p hp
  have h : env35738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35737_35738 : H12AffineEnvironment.transform 15 54495 env35737 = env35738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env35737 == env35738) = true)

theorem identity35738 : scanCanonicalize (H12AffineFastState.compose env35738 (packedSelected [16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound35738 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env35739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,13388,10401,1025,32769,4161,41460,17,3,8328,64,43476,5393,4097,35325,1501,169,257,33,46212,41940]

theorem envBound35739 : H12AffineFastState.Bounded env35739 := by
  intro p hp
  have h : env35739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35738_35739 : H12AffineEnvironment.transform 13 5377 env35738 = env35739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env35738 == env35739) = true)

theorem identity35739 : scanCanonicalize (H12AffineFastState.compose env35739 (packedSelected [0,1,2,4,7,8,11,12,14,15,17,18,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 421) := by decide +kernel

theorem selectedBound35739 : packedSelected [0,1,2,4,7,8,11,12,14,15,17,18,19,22] rootPS < 2^1333 := by decide +kernel

def env35740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,5377,32768,33246,5609,2308,1025,32769,4161,32849,17,3,301,64,34929,5393,4097,35325,1501,169,257,33,38177,33393]

theorem envBound35740 : H12AffineFastState.Bounded env35740 := by
  intro p hp
  have h : env35740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35739_35740 : H12AffineEnvironment.transform 12 421 env35739 = env35740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 421 env35739 == env35740) = true)

theorem identity35740 : scanCanonicalize (H12AffineFastState.compose env35740 (packedSelected [3,5,6,10,11,12,14,15,17,18] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound35740 : packedSelected [3,5,6,10,11,12,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env35741 : List Nat := [2,4,8,16,32,49,128,256,512,1024,2048,4096,421,5377,32768,33199,5528,2308,1025,32769,4144,32800,17,3,301,49,34816,5393,4097,35212,1452,169,257,33,38177,33280]

theorem envBound35741 : H12AffineFastState.Bounded env35741 := by
  intro p hp
  have h : env35741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35740_35741 : H12AffineEnvironment.transform 5 49 env35740 = env35741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env35740 == env35741) = true)

theorem identity35741 : scanCanonicalize (H12AffineFastState.compose env35741 (packedSelected [2,6,17] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound35741 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env35742 : List Nat := [2,4,8,16,32,49,128,256,512,1024,2048,4096,421,5377,1,430,5528,2308,1025,0,4144,33,17,3,301,49,2049,5393,4097,2445,1452,169,257,33,5408,513]

theorem envBound35742 : H12AffineFastState.Bounded env35742 := by
  intro p hp
  have h : env35742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35741_35742 : H12AffineEnvironment.transform 14 1 env35741 = env35742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env35741 == env35742) = true)

theorem identity35742 : scanCanonicalize (H12AffineFastState.compose env35742 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound35742 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env35743 : List Nat := [2,4,8,16,32,49,41,256,512,1024,2048,4096,268,5377,1,263,5425,2308,1025,0,4144,33,17,3,301,49,2049,5393,4097,2340,1285,0,257,33,5408,513]

theorem envBound35743 : H12AffineFastState.Bounded env35743 := by
  intro p hp
  have h : env35743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35742_35743 : H12AffineEnvironment.transform 6 41 env35742 = env35743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env35742 == env35743) = true)

theorem identity35743 : scanCanonicalize (H12AffineFastState.compose env35743 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1281) := by decide +kernel

theorem selectedBound35743 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env35744 : List Nat := [2,4,8,16,32,49,41,256,512,1024,1281,4096,268,5377,1,263,5425,1029,1025,0,4144,33,17,3,301,49,1280,5393,4097,1061,1285,0,257,33,5408,513]

theorem envBound35744 : H12AffineFastState.Bounded env35744 := by
  intro p hp
  have h : env35744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35743_35744 : H12AffineEnvironment.transform 10 1281 env35743 = env35744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1281 env35743 == env35744) = true)

theorem identity35744 : scanCanonicalize (H12AffineFastState.compose env35744 (packedSelected [0,1,2,4,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 1541) := by decide +kernel

theorem selectedBound35744 : packedSelected [0,1,2,4,8,10] rootPS < 2^1333 := by decide +kernel

def env35745 : List Nat := [2,4,8,16,32,49,41,256,512,1024,1281,1541,268,772,1,263,820,1029,1025,0,1589,33,17,3,301,49,1280,788,1540,1061,1285,0,257,33,805,513]

theorem envBound35745 : H12AffineFastState.Bounded env35745 := by
  intro p hp
  have h : env35745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35744_35745 : H12AffineEnvironment.transform 11 1541 env35744 = env35745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1541 env35744 == env35745) = true)

theorem identity35745 : scanCanonicalize (H12AffineFastState.compose env35745 (packedSelected [0,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound35745 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env35746 : List Nat := [2,4,8,16,32,49,41,256,512,4,261,513,268,772,1,263,820,1,5,0,561,33,17,3,301,49,260,788,512,33,257,0,257,33,805,513]

theorem envBound35746 : H12AffineFastState.Bounded env35746 := by
  intro p hp
  have h : env35746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35745_35746 : H12AffineEnvironment.transform 9 4 env35745 = env35746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env35745 == env35746) = true)

theorem identity35746 : scanCanonicalize (H12AffineFastState.compose env35746 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound35746 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35747 : List Nat := [2,4,8,16,32,49,41,256,17,4,261,16,268,277,1,263,293,1,5,0,32,33,17,3,301,49,260,261,17,33,257,0,257,33,308,16]

theorem envBound35747 : H12AffineFastState.Bounded env35747 := by
  intro p hp
  have h : env35747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35746_35747 : H12AffineEnvironment.transform 8 17 env35746 = env35747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env35746 == env35747) = true)

theorem identity35747 : scanCanonicalize (H12AffineFastState.compose env35747 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound35747 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env35748 : List Nat := [2,4,8,16,32,49,41,52,17,4,49,16,56,33,1,51,17,1,5,0,32,33,17,3,25,49,48,49,17,33,53,0,53,33,0,16]

theorem envBound35748 : H12AffineFastState.Bounded env35748 := by
  intro p hp
  have h : env35748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35747_35748 : H12AffineEnvironment.transform 7 52 env35747 = env35748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env35747 == env35748) = true)

theorem identity35748 : scanCanonicalize (H12AffineFastState.compose env35748 (packedSelected [1,2,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35748 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env35749 : List Nat := [2,4,8,16,0,17,9,20,17,4,17,16,24,1,1,19,17,1,5,0,0,1,17,3,25,17,16,17,17,1,21,0,21,1,0,16]

theorem envBound35749 : H12AffineFastState.Bounded env35749 := by
  intro p hp
  have h : env35749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35748_35749 : H12AffineEnvironment.transform 4 0 env35748 = env35749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35748 == env35749) = true)

theorem identity35749 : scanCanonicalize (H12AffineFastState.compose env35749 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound35749 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35750 : List Nat := [2,4,8,5,0,4,9,1,4,4,4,5,13,1,1,6,4,1,5,0,0,1,4,3,12,4,5,4,4,1,0,0,0,1,0,5]

theorem envBound35750 : H12AffineFastState.Bounded env35750 := by
  intro p hp
  have h : env35750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35749_35750 : H12AffineEnvironment.transform 3 5 env35749 = env35750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env35749 == env35750) = true)

theorem identity35750 : scanCanonicalize (H12AffineFastState.compose env35750 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound35750 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35751 : List Nat := [0,4,8,5,0,4,9,1,4,4,4,5,13,1,1,4,4,1,5,0,0,1,4,1,12,4,5,4,4,1,0,0,0,1,0,5]

theorem envBound35751 : H12AffineFastState.Bounded env35751 := by
  intro p hp
  have h : env35751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35750_35751 : H12AffineEnvironment.transform 0 0 env35750 = env35751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env35750 == env35751) = true)

def env35752 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452633,254082,16777216,8328,64,16959643,18973837,2340306,336002,16934035,19369433,257,19014703,19056011,16991044]

theorem envBound35752 : H12AffineFastState.Bounded env35752 := by
  intro p hp
  have h : env35752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35602_35752 : H12AffineEnvironment.transform 21 452633 env35602 = env35752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452633 env35602 == env35752) = true)

def env35753 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452633,254082,243088,8328,64,97547,2240797,2340306,336002,119043,2373705,257,2199999,2191387,63188]

theorem envBound35753 : H12AffineFastState.Bounded env35753 := by
  intro p hp
  have h : env35753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35752_35753 : H12AffineEnvironment.transform 23 243088 env35752 = env35753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 243088 env35752 == env35753) = true)

def env35754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452633,254082,243088,8328,64,97547,139613,238994,336002,119043,272393,257,98815,90203,63188]

theorem envBound35754 : H12AffineFastState.Bounded env35754 := by
  intro p hp
  have h : env35754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35753_35754 : H12AffineEnvironment.transform 20 4160 env35753 = env35754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env35753 == env35754) = true)

theorem identity35754 : scanCanonicalize (H12AffineFastState.compose env35754 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound35754 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,4160,452633,180361,169371,8328,64,23808,139613,165273,262281,61704,272393,257,41460,16464,63188]

theorem envBound35755 : H12AffineFastState.Bounded env35755 := by
  intro p hp
  have h : env35755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35754_35755 : H12AffineEnvironment.transform 15 8203 env35754 = env35755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env35754 == env35755) = true)

theorem identity35755 : scanCanonicalize (H12AffineFastState.compose env35755 (packedSelected [1,4,7,9,12,15,19,27,28,31,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound35755 : packedSelected [1,4,7,9,12,15,19,27,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env35756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,57676,262144,1025,32769,4160,264533,8645,29911,8328,64,23808,49169,25813,262281,61704,272393,257,41460,16464,63188]

theorem envBound35756 : H12AffineFastState.Bounded env35756 := by
  intro p hp
  have h : env35756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35755_35756 : H12AffineEnvironment.transform 16 57676 env35755 = env35756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env35755 == env35756) = true)

theorem identity35756 : scanCanonicalize (H12AffineFastState.compose env35756 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 35325) := by decide +kernel

theorem selectedBound35756 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env35757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,57676,35325,1025,32769,4160,32936,8645,29911,8328,64,23808,49169,25813,35188,61704,41460,257,41460,16464,63188]

theorem envBound35757 : H12AffineFastState.Bounded env35757 := by
  intro p hp
  have h : env35757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35756_35757 : H12AffineEnvironment.transform 17 35325 env35756 = env35757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35325 env35756 == env35757) = true)

theorem identity35757 : scanCanonicalize (H12AffineFastState.compose env35757 (packedSelected [3,4,7,9,10,16,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound35757 : packedSelected [3,4,7,9,10,16,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env35758 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8203,16400,10401,1025,8541,4160,8692,8645,29911,8328,64,23808,24909,25813,10280,20564,168,257,168,16464,22408]

theorem envBound35758 : H12AffineFastState.Bounded env35758 := by
  intro p hp
  have h : env35758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35757_35758 : H12AffineEnvironment.transform 14 8540 env35757 = env35758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env35757 == env35758) = true)

theorem identity35758 : scanCanonicalize (H12AffineFastState.compose env35758 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35758 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35759 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16400,10280,1025,8541,4160,8573,8524,29790,8193,64,23808,24909,25692,10280,20564,33,257,33,16464,22273]

theorem envBound35759 : H12AffineFastState.Bounded env35759 := by
  intro p hp
  have h : env35759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35758_35759 : H12AffineEnvironment.transform 6 9 env35758 = env35759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35758 == env35759) = true)

theorem identity35759 : scanCanonicalize (H12AffineFastState.compose env35759 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound35759 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env35760 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8540,8203,13388,10280,1025,8541,4160,8573,8524,2,8193,64,10588,5393,4096,10280,9224,33,257,33,13324,9053]

theorem envBound35760 : H12AffineFastState.Bounded env35760 := by
  intro p hp
  have h : env35760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35759_35760 : H12AffineEnvironment.transform 13 13404 env35759 = env35760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env35759 == env35760) = true)

theorem identity35760 : scanCanonicalize (H12AffineFastState.compose env35760 (packedSelected [0,1,3,5,6,7,8,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 352) := by decide +kernel

theorem selectedBound35760 : packedSelected [0,1,3,5,6,7,8,14,15] rootPS < 2^1333 := by decide +kernel

def env35761 : List Nat := [2,4,8,16,32,64,9,256,512,352,2048,4096,8192,12604,8540,8203,12588,10280,353,8541,4160,8573,8524,2,8193,64,10588,4209,4096,10280,8552,33,257,33,12652,9053]

theorem envBound35761 : H12AffineFastState.Bounded env35761 := by
  intro p hp
  have h : env35761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35760_35761 : H12AffineEnvironment.transform 9 352 env35760 = env35761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 352 env35760 == env35761) = true)

def env35762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452633,254082,243088,8328,64,97547,139612,238995,336002,119043,272392,257,98814,90202,63188]

theorem envBound35762 : H12AffineFastState.Bounded env35762 := by
  intro p hp
  have h : env35762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35753_35762 : H12AffineEnvironment.transform 20 4161 env35753 = env35762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env35753 == env35762) = true)

theorem identity35762 : scanCanonicalize (H12AffineFastState.compose env35762 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 123027) := by decide +kernel

theorem selectedBound35762 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,4161,329866,17,21763,8328,64,97547,115151,17664,336002,119043,272392,257,98814,90202,63188]

theorem envBound35763 : H12AffineFastState.Bounded env35763 := by
  intro p hp
  have h : env35763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35762_35763 : H12AffineEnvironment.transform 16 123027 env35762 = env35763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 123027 env35762 == env35763) = true)

def env35764 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,4161,329730,17,21763,8192,64,97547,115015,17664,335882,119043,272392,257,98678,90202,63068]

theorem envBound35764 : H12AffineFastState.Bounded env35764 := by
  intro p hp
  have h : env35764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35763_35764 : H12AffineEnvironment.transform 6 8 env35763 = env35764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35763 == env35764) = true)

theorem identity35764 : scanCanonicalize (H12AffineFastState.compose env35764 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound35764 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35765 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,35188,1025,32769,4161,98678,17,21763,8192,64,97547,115015,17664,108926,119043,41340,257,98678,90202,63068]

theorem envBound35765 : H12AffineFastState.Bounded env35765 := by
  intro p hp
  have h : env35765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35764_35765 : H12AffineEnvironment.transform 17 35188 env35764 = env35765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env35764 == env35765) = true)

theorem identity35765 : scanCanonicalize (H12AffineFastState.compose env35765 (packedSelected [16,18,19,20,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound35765 : packedSelected [16,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env35766 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,38160,35188,1025,32769,4161,62589,17,21763,8192,64,2048,46156,17664,56437,41992,41340,257,62589,5457,63068]

theorem envBound35766 : H12AffineFastState.Bounded env35766 := by
  intro p hp
  have h : env35766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35765_35766 : H12AffineEnvironment.transform 15 29963 env35765 = env35766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env35765 == env35766) = true)

theorem identity35766 : scanCanonicalize (H12AffineFastState.compose env35766 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound35766 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env35767 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,342,38160,35188,1025,32769,4161,32800,17,8542,8192,64,2048,46156,12637,43048,41992,41340,257,32800,5457,33281]

theorem envBound35767 : H12AffineFastState.Bounded env35767 := by
  intro p hp
  have h : env35767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35766_35767 : H12AffineEnvironment.transform 13 13405 env35766 = env35767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env35766 == env35767) = true)

theorem identity35767 : scanCanonicalize (H12AffineFastState.compose env35767 (packedSelected [0,3,4,5,6,7,9,10,12,15,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound35767 : packedSelected [0,3,4,5,6,7,9,10,12,15,18,23] rootPS < 2^1333 := by decide +kernel

def env35768 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8460,342,13340,10360,1025,8461,4161,8492,17,8542,8192,64,2048,5440,12637,2340,1284,112,257,8492,5457,8973]

theorem envBound35768 : H12AffineFastState.Bounded env35768 := by
  intro p hp
  have h : env35768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35767_35768 : H12AffineEnvironment.transform 14 8460 env35767 = env35768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env35767 == env35768) = true)

theorem identity35768 : scanCanonicalize (H12AffineFastState.compose env35768 (packedSelected [4,6,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound35768 : packedSelected [4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env35769 : List Nat := [2,4,8,16,32,64,8,256,512,20,2048,4096,8192,12361,8460,342,12296,10360,21,8461,4161,8492,17,8542,8192,64,2048,4436,12637,2340,272,112,257,8492,4421,8973]

theorem envBound35769 : H12AffineFastState.Bounded env35769 := by
  intro p hp
  have h : env35769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35768_35769 : H12AffineEnvironment.transform 9 20 env35768 = env35769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env35768 == env35769) = true)

theorem identity35769 : scanCanonicalize (H12AffineFastState.compose env35769 (packedSelected [1,3,4,5,6,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound35769 : packedSelected [1,3,4,5,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env35770 : List Nat := [2,4,8,16,32,64,8,256,512,20,2048,2405,8192,10540,8460,342,10605,10360,21,8461,2340,8492,17,8542,8192,64,2048,2097,10296,2340,272,112,257,8492,2080,8973]

theorem envBound35770 : H12AffineFastState.Bounded env35770 := by
  intro p hp
  have h : env35770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35769_35770 : H12AffineEnvironment.transform 11 2405 env35769 = env35770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env35769 == env35770) = true)

theorem identity35770 : scanCanonicalize (H12AffineFastState.compose env35770 (packedSelected [0,3,4,5,6,7,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound35770 : packedSelected [0,3,4,5,6,7,9,12] rootPS < 2^1333 := by decide +kernel

def env35771 : List Nat := [2,4,8,16,32,64,8,117,512,20,2048,2064,8192,10329,8313,35,10264,10360,21,8312,2129,8281,17,8235,8192,64,2048,2097,10296,2129,101,112,116,8281,2080,8824]

theorem envBound35771 : H12AffineFastState.Bounded env35771 := by
  intro p hp
  have h : env35771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35770_35771 : H12AffineEnvironment.transform 7 117 env35770 = env35771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env35770 == env35771) = true)

theorem identity35771 : scanCanonicalize (H12AffineFastState.compose env35771 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound35771 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env35772 : List Nat := [2,4,8,16,32,64,8,117,512,20,2048,2064,41,2160,80,35,2097,2129,21,81,2129,112,17,2,41,64,2048,2097,2065,2129,101,112,116,112,2080,593]

theorem envBound35772 : H12AffineFastState.Bounded env35772 := by
  intro p hp
  have h : env35772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35771_35772 : H12AffineEnvironment.transform 12 41 env35771 = env35772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env35771 == env35772) = true)

theorem identity35772 : scanCanonicalize (H12AffineFastState.compose env35772 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound35772 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env35773 : List Nat := [2,4,8,16,32,64,8,117,512,20,523,539,41,635,80,35,570,602,21,81,602,112,17,2,41,64,523,570,538,602,101,112,116,112,555,593]

theorem envBound35773 : H12AffineFastState.Bounded env35773 := by
  intro p hp
  have h : env35773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35772_35773 : H12AffineEnvironment.transform 10 523 env35772 = env35773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env35772 == env35773) = true)

theorem identity35773 : scanCanonicalize (H12AffineFastState.compose env35773 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound35773 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35774 : List Nat := [2,4,8,16,32,64,8,117,43,20,32,48,41,80,80,35,17,113,21,81,113,112,17,2,41,64,32,17,49,113,101,112,116,112,0,122]

theorem envBound35774 : H12AffineFastState.Bounded env35774 := by
  intro p hp
  have h : env35774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35773_35774 : H12AffineEnvironment.transform 8 43 env35773 = env35774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env35773 == env35774) = true)

theorem identity35774 : scanCanonicalize (H12AffineFastState.compose env35774 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound35774 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35775 : List Nat := [2,4,8,16,32,49,8,4,43,20,32,48,41,33,33,35,17,0,21,32,0,1,17,2,41,49,32,17,49,0,20,1,5,1,0,11]

theorem envBound35775 : H12AffineFastState.Bounded env35775 := by
  intro p hp
  have h : env35775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35774_35775 : H12AffineEnvironment.transform 5 49 env35774 = env35775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env35774 == env35775) = true)

theorem identity35775 : scanCanonicalize (H12AffineFastState.compose env35775 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35775 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0