import H12CloudChart0Data236

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound60135 : H12AffineFastState.Bounded env60135 := by
  intro p hp
  have h : env60135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60134_60135 : H12AffineEnvironment.transform 8 0 env60134 = env60135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env60134 == env60135) = true)

theorem identity60135 : scanCanonicalize (H12AffineFastState.compose env60135 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 6178) := by decide +kernel

theorem selectedBound60135 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60136 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,6178,10480,262144,1025,2129,2097152,1416,9665,3158,1288,9616,2365812,4177,10400,7536,6181,4572,256,6313,10480,9601]

theorem envBound60136 : H12AffineFastState.Bounded env60136 := by
  intro p hp
  have h : env60136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60135_60136 : H12AffineEnvironment.transform 15 6178 env60135 = env60136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6178 env60135 == env60136) = true)

def env60137 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,6178,3440,262144,1025,2129,2097152,1416,65,3158,1288,16,2365812,4177,3360,7536,6181,4572,256,6313,3440,1]

theorem envBound60137 : H12AffineFastState.Bounded env60137 := by
  intro p hp
  have h : env60137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60136_60137 : H12AffineEnvironment.transform 12 1408 env60136 = env60137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60136 == env60137) = true)

theorem identity60137 : scanCanonicalize (H12AffineFastState.compose env60137 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6653) := by decide +kernel

theorem selectedBound60137 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60138 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,6178,3440,262144,1025,2129,6653,1416,65,3158,1288,16,262281,4177,3360,7536,6181,4572,256,6313,3440,1]

theorem envBound60138 : H12AffineFastState.Bounded env60138 := by
  intro p hp
  have h : env60138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60137_60138 : H12AffineEnvironment.transform 20 6653 env60137 = env60138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6653 env60137 == env60138) = true)

theorem identity60138 : scanCanonicalize (H12AffineFastState.compose env60138 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound60138 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60139 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1408,4176,1448,5595,137,262144,1025,1448,5124,1416,65,431,1288,16,262281,4177,217,4233,5596,4572,256,5456,137,1]

theorem envBound60139 : H12AffineFastState.Bounded env60139 := by
  intro p hp
  have h : env60139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60138_60139 : H12AffineEnvironment.transform 10 1529 env60138 = env60139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env60138 == env60139) = true)

theorem identity60139 : scanCanonicalize (H12AffineFastState.compose env60139 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 17) := by decide +kernel

theorem selectedBound60139 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60140 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1408,4176,1448,5595,137,17,1025,1448,5124,1416,65,431,1288,16,152,4177,217,4233,5596,4572,256,5456,137,1]

theorem envBound60140 : H12AffineFastState.Bounded env60140 := by
  intro p hp
  have h : env60140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60139_60140 : H12AffineEnvironment.transform 17 17 env60139 = env60140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 17 env60139 == env60140) = true)

theorem identity60140 : scanCanonicalize (H12AffineFastState.compose env60140 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 509) := by decide +kernel

theorem selectedBound60140 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60141 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,509,1408,429,1448,1062,137,17,1025,1448,1529,1416,65,431,1288,16,152,428,217,372,1057,33,256,1197,137,1]

theorem envBound60141 : H12AffineFastState.Bounded env60141 := by
  intro p hp
  have h : env60141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60140_60141 : H12AffineEnvironment.transform 11 509 env60140 = env60141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 509 env60140 == env60141) = true)

theorem identity60141 : scanCanonicalize (H12AffineFastState.compose env60141 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound60141 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60142 : List Nat := [2,4,8,16,32,64,128,256,0,220,293,509,348,429,372,250,137,17,221,372,293,340,65,431,468,16,152,428,217,372,253,33,256,113,137,1]

theorem envBound60142 : H12AffineFastState.Bounded env60142 := by
  intro p hp
  have h : env60142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60141_60142 : H12AffineEnvironment.transform 9 220 env60141 = env60142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env60141 == env60142) = true)

theorem identity60142 : scanCanonicalize (H12AffineFastState.compose env60142 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound60142 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60143 : List Nat := [2,4,8,16,32,16,128,256,0,140,293,429,268,429,292,170,137,17,141,292,293,260,17,431,388,16,152,428,137,292,173,33,256,33,137,1]

theorem envBound60143 : H12AffineFastState.Bounded env60143 := by
  intro p hp
  have h : env60143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60142_60143 : H12AffineEnvironment.transform 5 16 env60142 = env60143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60142 == env60143) = true)

theorem identity60143 : scanCanonicalize (H12AffineFastState.compose env60143 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 55) := by decide +kernel

theorem selectedBound60143 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60144 : List Nat := [2,4,8,16,32,16,128,55,0,140,18,154,59,154,19,170,137,17,141,19,18,51,17,152,179,16,152,155,137,19,173,33,55,33,137,1]

theorem envBound60144 : H12AffineFastState.Bounded env60144 := by
  intro p hp
  have h : env60144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60143_60144 : H12AffineEnvironment.transform 7 55 env60143 = env60144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 55 env60143 == env60144) = true)

theorem identity60144 : scanCanonicalize (H12AffineFastState.compose env60144 (packedSelected [1,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 59) := by decide +kernel

theorem selectedBound60144 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env60145 : List Nat := [2,4,8,16,32,16,59,55,0,55,18,33,59,33,19,17,50,17,54,19,18,51,17,35,8,16,35,32,50,19,22,33,55,33,50,1]

theorem envBound60145 : H12AffineFastState.Bounded env60145 := by
  intro p hp
  have h : env60145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60144_60145 : H12AffineEnvironment.transform 6 59 env60144 = env60145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 59 env60144 == env60145) = true)

theorem identity60145 : scanCanonicalize (H12AffineFastState.compose env60145 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound60145 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60146 : List Nat := [2,4,2,16,32,16,49,55,0,55,18,33,49,33,19,17,50,17,54,19,18,51,17,35,2,16,35,32,50,19,22,33,55,33,50,1]

theorem envBound60146 : H12AffineFastState.Bounded env60146 := by
  intro p hp
  have h : env60146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60145_60146 : H12AffineEnvironment.transform 2 2 env60145 = env60146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env60145 == env60146) = true)

theorem identity60146 : scanCanonicalize (H12AffineFastState.compose env60146 (packedSelected [1,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound60146 : packedSelected [1,6] rootPS < 2^1333 := by decide +kernel

def env60147 : List Nat := [2,4,2,16,1,16,16,22,0,22,18,0,16,0,19,17,19,17,23,19,18,18,17,2,2,16,2,1,19,19,22,0,22,0,19,1]

theorem envBound60147 : H12AffineFastState.Bounded env60147 := by
  intro p hp
  have h : env60147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60146_60147 : H12AffineEnvironment.transform 4 1 env60146 = env60147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env60146 == env60147) = true)

theorem identity60147 : scanCanonicalize (H12AffineFastState.compose env60147 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound60147 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60148 : List Nat := [2,4,2,1,1,1,1,7,0,7,3,0,1,0,2,0,2,0,6,2,3,3,0,2,2,1,2,1,2,2,7,0,7,0,2,1]

theorem envBound60148 : H12AffineFastState.Bounded env60148 := by
  intro p hp
  have h : env60148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60147_60148 : H12AffineEnvironment.transform 3 1 env60147 = env60148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env60147 == env60148) = true)

theorem identity60148 : scanCanonicalize (H12AffineFastState.compose env60148 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60148 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60149 : List Nat := [0,4,0,1,1,1,1,5,0,5,1,0,1,0,0,0,0,0,4,0,1,1,0,0,0,1,0,1,0,0,5,0,5,0,0,1]

theorem envBound60149 : H12AffineFastState.Bounded env60149 := by
  intro p hp
  have h : env60149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60148_60149 : H12AffineEnvironment.transform 0 0 env60148 = env60149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60148 == env60149) = true)

def env60150 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,6178,3441,262144,1025,2129,2097152,1416,64,3158,1288,17,2365812,4177,3361,7536,6181,4572,256,6313,3441,0]

theorem envBound60150 : H12AffineFastState.Bounded env60150 := by
  intro p hp
  have h : env60150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60136_60150 : H12AffineEnvironment.transform 12 1409 env60136 = env60150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60136 == env60150) = true)

theorem identity60150 : scanCanonicalize (H12AffineFastState.compose env60150 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 217) := by decide +kernel

theorem selectedBound60150 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60151 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,6178,3441,262144,1025,2129,217,1416,64,3158,1288,17,268717,4177,3361,7536,6181,4572,256,6313,3441,0]

theorem envBound60151 : H12AffineFastState.Bounded env60151 := by
  intro p hp
  have h : env60151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60150_60151 : H12AffineEnvironment.transform 20 217 env60150 = env60151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 217 env60150 == env60151) = true)

theorem identity60151 : scanCanonicalize (H12AffineFastState.compose env60151 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6376) := by decide +kernel

theorem selectedBound60151 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60152 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,6178,3441,6376,1025,2129,217,1416,64,3158,1288,17,325,4177,3361,7536,6181,4572,256,6313,3441,0]

theorem envBound60152 : H12AffineFastState.Bounded env60152 := by
  intro p hp
  have h : env60152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60151_60152 : H12AffineEnvironment.transform 17 6376 env60151 = env60152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6376 env60151 == env60152) = true)

theorem identity60152 : scanCanonicalize (H12AffineFastState.compose env60152 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 460) := by decide +kernel

theorem selectedBound60152 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60153 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,460,1409,412,2129,2542,3441,2340,1025,2129,217,1416,64,3158,1288,17,325,413,3361,3260,2537,16,256,2405,3441,0]

theorem envBound60153 : H12AffineFastState.Bounded env60153 := by
  intro p hp
  have h : env60153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60152_60153 : H12AffineEnvironment.transform 11 460 env60152 = env60153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 460 env60152 == env60153) = true)

theorem identity60153 : scanCanonicalize (H12AffineFastState.compose env60153 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 324) := by decide +kernel

theorem selectedBound60153 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env60154 : List Nat := [2,4,8,16,32,64,128,256,0,1024,324,460,1409,412,277,170,1077,96,1025,277,217,1416,64,1298,1288,17,325,413,1125,1528,173,16,256,33,1077,0]

theorem envBound60154 : H12AffineFastState.Bounded env60154 := by
  intro p hp
  have h : env60154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60153_60154 : H12AffineEnvironment.transform 10 324 env60153 = env60154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 324 env60153 == env60154) = true)

theorem identity60154 : scanCanonicalize (H12AffineFastState.compose env60154 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound60154 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60155 : List Nat := [2,4,8,16,32,64,128,256,0,408,324,460,25,412,277,170,429,96,409,277,217,16,64,138,144,17,325,413,509,96,173,16,256,33,429,0]

theorem envBound60155 : H12AffineFastState.Bounded env60155 := by
  intro p hp
  have h : env60155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60154_60155 : H12AffineEnvironment.transform 9 408 env60154 = env60155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env60154 == env60155) = true)

theorem identity60155 : scanCanonicalize (H12AffineFastState.compose env60155 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound60155 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env60156 : List Nat := [2,4,8,16,32,64,128,110,0,246,42,162,25,242,123,170,195,96,247,123,217,16,64,138,144,17,43,243,147,96,173,16,110,33,195,0]

theorem envBound60156 : H12AffineFastState.Bounded env60156 := by
  intro p hp
  have h : env60156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60155_60156 : H12AffineEnvironment.transform 7 110 env60155 = env60156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env60155 == env60156) = true)

theorem identity60156 : scanCanonicalize (H12AffineFastState.compose env60156 (packedSelected [0,1,6,11] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60156 : packedSelected [0,1,6,11] rootPS < 2^1333 := by decide +kernel

def env60157 : List Nat := [2,4,8,16,16,64,128,94,0,198,26,146,25,194,75,154,195,80,199,75,217,16,64,138,144,17,27,195,147,80,157,16,94,17,195,0]

theorem envBound60157 : H12AffineFastState.Bounded env60157 := by
  intro p hp
  have h : env60157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60156_60157 : H12AffineEnvironment.transform 4 16 env60156 = env60157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60156 == env60157) = true)

def env60158 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9665,3159,1288,9616,2365813,4177,77954,66899,65543,68095,256,65675,78034,9600]

theorem envBound60158 : H12AffineFastState.Bounded env60158 := by
  intro p hp
  have h : env60158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60134_60158 : H12AffineEnvironment.transform 8 1 env60134 = env60158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env60134 == env60158) = true)

theorem identity60158 : scanCanonicalize (H12AffineFastState.compose env60158 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 15779) := by decide +kernel

theorem selectedBound60158 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60159 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,15779,3441,262144,1025,2128,2097152,1416,9665,3159,1288,9616,2365813,4177,3361,14576,15780,13404,256,15656,3441,9600]

theorem envBound60159 : H12AffineFastState.Bounded env60159 := by
  intro p hp
  have h : env60159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60158_60159 : H12AffineEnvironment.transform 15 15779 env60158 = env60159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 15779 env60158 == env60159) = true)

def env60160 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,6179,3441,262144,1025,2128,2097152,1416,65,3159,1288,16,2365813,4177,3361,7536,6180,4572,256,6312,3441,0]

theorem envBound60160 : H12AffineFastState.Bounded env60160 := by
  intro p hp
  have h : env60160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60159_60160 : H12AffineEnvironment.transform 12 1408 env60159 = env60160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60159 == env60160) = true)

theorem identity60160 : scanCanonicalize (H12AffineFastState.compose env60160 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6652) := by decide +kernel

theorem selectedBound60160 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60161 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,6179,3441,262144,1025,2128,6652,1416,65,3159,1288,16,262281,4177,3361,7536,6180,4572,256,6312,3441,0]

theorem envBound60161 : H12AffineFastState.Bounded env60161 := by
  intro p hp
  have h : env60161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60160_60161 : H12AffineEnvironment.transform 20 6652 env60160 = env60161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6652 env60160 == env60161) = true)

theorem identity60161 : scanCanonicalize (H12AffineFastState.compose env60161 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound60161 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60162 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1408,4176,1448,5595,137,262144,1025,1448,5124,1416,65,431,1288,16,262281,4177,217,4232,5596,4572,256,5456,137,0]

theorem envBound60162 : H12AffineFastState.Bounded env60162 := by
  intro p hp
  have h : env60162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60161_60162 : H12AffineEnvironment.transform 10 1528 env60161 = env60162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env60161 == env60162) = true)

theorem identity60162 : scanCanonicalize (H12AffineFastState.compose env60162 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 17) := by decide +kernel

theorem selectedBound60162 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60163 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1408,4176,1448,5595,137,17,1025,1448,5124,1416,65,431,1288,16,152,4177,217,4232,5596,4572,256,5456,137,0]

theorem envBound60163 : H12AffineFastState.Bounded env60163 := by
  intro p hp
  have h : env60163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60162_60163 : H12AffineEnvironment.transform 17 17 env60162 = env60163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 17 env60162 == env60163) = true)

theorem identity60163 : scanCanonicalize (H12AffineFastState.compose env60163 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 509) := by decide +kernel

theorem selectedBound60163 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60164 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,509,1408,429,1448,1062,137,17,1025,1448,1529,1416,65,431,1288,16,152,428,217,373,1057,33,256,1197,137,0]

theorem envBound60164 : H12AffineFastState.Bounded env60164 := by
  intro p hp
  have h : env60164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60163_60164 : H12AffineEnvironment.transform 11 509 env60163 = env60164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 509 env60163 == env60164) = true)

theorem identity60164 : scanCanonicalize (H12AffineFastState.compose env60164 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound60164 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60165 : List Nat := [2,4,8,16,32,64,128,256,1,221,293,509,349,429,373,251,137,17,220,373,292,341,65,431,469,16,152,428,217,373,252,33,256,112,137,0]

theorem envBound60165 : H12AffineFastState.Bounded env60165 := by
  intro p hp
  have h : env60165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60164_60165 : H12AffineEnvironment.transform 9 221 env60164 = env60165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env60164 == env60165) = true)

theorem identity60165 : scanCanonicalize (H12AffineFastState.compose env60165 (packedSelected [5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound60165 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60166 : List Nat := [2,4,8,16,32,64,128,172,1,221,137,81,241,1,217,251,137,17,220,217,136,249,65,3,121,16,152,0,217,217,252,33,172,112,137,0]

theorem envBound60166 : H12AffineFastState.Bounded env60166 := by
  intro p hp
  have h : env60166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60165_60166 : H12AffineEnvironment.transform 7 172 env60165 = env60166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env60165 == env60166) = true)

theorem identity60166 : scanCanonicalize (H12AffineFastState.compose env60166 (packedSelected [0,1,3,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound60166 : packedSelected [0,1,3,6,7] rootPS < 2^1333 := by decide +kernel

def env60167 : List Nat := [2,4,8,16,32,64,120,84,1,37,113,81,9,1,33,3,113,17,36,33,112,1,65,3,121,16,96,0,33,33,4,33,84,112,113,0]

theorem envBound60167 : H12AffineFastState.Bounded env60167 := by
  intro p hp
  have h : env60167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60166_60167 : H12AffineEnvironment.transform 6 120 env60166 = env60167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env60166 == env60167) = true)

theorem identity60167 : scanCanonicalize (H12AffineFastState.compose env60167 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound60167 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env60168 : List Nat := [2,4,8,16,32,58,2,46,1,37,11,43,9,1,33,3,11,17,36,33,10,1,59,3,3,16,26,0,33,33,4,33,46,10,11,0]

theorem envBound60168 : H12AffineFastState.Bounded env60168 := by
  intro p hp
  have h : env60168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60167_60168 : H12AffineEnvironment.transform 5 58 env60167 = env60168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env60167 == env60168) = true)

theorem identity60168 : scanCanonicalize (H12AffineFastState.compose env60168 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound60168 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env60169 : List Nat := [2,4,8,16,3,25,2,13,1,6,11,8,9,1,2,3,11,17,7,2,10,1,24,3,3,16,26,0,2,2,4,2,13,10,11,0]

theorem envBound60169 : H12AffineFastState.Bounded env60169 := by
  intro p hp
  have h : env60169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60168_60169 : H12AffineEnvironment.transform 4 3 env60168 = env60169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env60168 == env60169) = true)

theorem identity60169 : scanCanonicalize (H12AffineFastState.compose env60169 (packedSelected [0,1,6] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60169 : packedSelected [0,1,6] rootPS < 2^1333 := by decide +kernel

def env60170 : List Nat := [2,4,1,16,3,16,2,4,1,6,2,1,0,1,2,3,2,17,7,2,3,1,17,3,3,16,19,0,2,2,4,2,4,3,2,0]

theorem envBound60170 : H12AffineFastState.Bounded env60170 := by
  intro p hp
  have h : env60170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60169_60170 : H12AffineEnvironment.transform 2 1 env60169 = env60170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60169 == env60170) = true)

theorem identity60170 : scanCanonicalize (H12AffineFastState.compose env60170 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound60170 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60171 : List Nat := [2,4,1,0,3,0,2,4,1,6,2,1,0,1,2,3,2,1,7,2,3,1,1,3,3,0,3,0,2,2,4,2,4,3,2,0]

theorem envBound60171 : H12AffineFastState.Bounded env60171 := by
  intro p hp
  have h : env60171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60170_60171 : H12AffineEnvironment.transform 3 0 env60170 = env60171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env60170 == env60171) = true)

def env60172 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,6178,3441,262144,1025,2128,2097152,1416,64,3159,1288,17,2365813,4177,3361,7537,6181,4573,256,6313,3441,1]

theorem envBound60172 : H12AffineFastState.Bounded env60172 := by
  intro p hp
  have h : env60172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60159_60172 : H12AffineEnvironment.transform 12 1409 env60159 = env60172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60159 == env60172) = true)

theorem identity60172 : scanCanonicalize (H12AffineFastState.compose env60172 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 216) := by decide +kernel

theorem selectedBound60172 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60173 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,6178,3441,262144,1025,2128,216,1416,64,3159,1288,17,268717,4177,3361,7537,6181,4573,256,6313,3441,1]

theorem envBound60173 : H12AffineFastState.Bounded env60173 := by
  intro p hp
  have h : env60173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60172_60173 : H12AffineEnvironment.transform 20 216 env60172 = env60173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 216 env60172 == env60173) = true)

theorem identity60173 : scanCanonicalize (H12AffineFastState.compose env60173 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6377) := by decide +kernel

theorem selectedBound60173 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60174 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,6178,3441,6377,1025,2128,216,1416,64,3159,1288,17,324,4177,3361,7537,6181,4573,256,6313,3441,1]

theorem envBound60174 : H12AffineFastState.Bounded env60174 := by
  intro p hp
  have h : env60174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60173_60174 : H12AffineEnvironment.transform 17 6377 env60173 = env60174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6377 env60173 == env60174) = true)

theorem identity60174 : scanCanonicalize (H12AffineFastState.compose env60174 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 461) := by decide +kernel

theorem selectedBound60174 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60175 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,461,1409,413,2128,2543,3441,2340,1025,2128,216,1416,64,3159,1288,17,324,412,3361,3260,2536,16,256,2404,3441,1]

theorem envBound60175 : H12AffineFastState.Bounded env60175 := by
  intro p hp
  have h : env60175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60174_60175 : H12AffineEnvironment.transform 11 461 env60174 = env60175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 461 env60174 == env60175) = true)

theorem identity60175 : scanCanonicalize (H12AffineFastState.compose env60175 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound60175 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env60176 : List Nat := [2,4,8,16,32,64,128,256,1,408,2048,461,25,413,2128,2543,2281,2340,409,2128,216,16,64,2511,144,17,324,412,2233,2340,2536,16,256,2404,2281,1]

theorem envBound60176 : H12AffineFastState.Bounded env60176 := by
  intro p hp
  have h : env60176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60175_60176 : H12AffineEnvironment.transform 9 408 env60175 = env60176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env60175 == env60176) = true)

theorem identity60176 : scanCanonicalize (H12AffineFastState.compose env60176 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 325) := by decide +kernel

theorem selectedBound60176 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env60177 : List Nat := [2,4,8,16,32,64,128,256,1,408,325,461,25,413,277,170,428,97,409,277,216,16,64,138,144,17,324,412,508,97,173,16,256,33,428,1]

theorem envBound60177 : H12AffineFastState.Bounded env60177 := by
  intro p hp
  have h : env60177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60176_60177 : H12AffineEnvironment.transform 10 325 env60176 = env60177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 325 env60176 == env60177) = true)

theorem identity60177 : scanCanonicalize (H12AffineFastState.compose env60177 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound60177 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env60178 : List Nat := [2,4,8,16,32,64,128,94,1,198,27,147,25,195,75,170,242,97,199,75,216,16,64,138,144,17,26,194,162,97,173,16,94,33,242,1]

theorem envBound60178 : H12AffineFastState.Bounded env60178 := by
  intro p hp
  have h : env60178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60177_60178 : H12AffineEnvironment.transform 7 94 env60177 = env60178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env60177 == env60178) = true)

theorem identity60178 : scanCanonicalize (H12AffineFastState.compose env60178 (packedSelected [1,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60178 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env60179 : List Nat := [2,4,8,16,16,64,128,94,1,198,27,147,25,195,75,154,194,81,199,75,216,16,64,138,144,17,26,194,146,81,157,16,94,17,194,1]

theorem envBound60179 : H12AffineFastState.Bounded env60179 := by
  intro p hp
  have h : env60179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60178_60179 : H12AffineEnvironment.transform 4 16 env60178 = env60179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60178 == env60179) = true)

def env60180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1417,8388608,8399767,8397001,8388689,2366325,4177,77954,67411,8463814,8465983,256,65674,78034,8389184]

theorem envBound60180 : H12AffineFastState.Bounded env60180 := by
  intro p hp
  have h : env60180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60087_60180 : H12AffineEnvironment.transform 21 1417 env60087 = env60180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1417 env60087 == env60180) = true)

def env60181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1417,9664,3671,1289,9617,2366325,4177,77954,67411,65542,68607,256,65674,78034,10112]

theorem envBound60181 : H12AffineFastState.Bounded env60181 := by
  intro p hp
  have h : env60181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60180_60181 : H12AffineEnvironment.transform 22 9664 env60180 = env60181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env60180 == env60181) = true)

def env60182 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9664,3159,1289,9617,2365813,4177,77954,66899,65542,68095,256,65674,78034,9600]

theorem envBound60182 : H12AffineFastState.Bounded env60182 := by
  intro p hp
  have h : env60182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60181_60182 : H12AffineEnvironment.transform 8 0 env60181 = env60182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env60181 == env60182) = true)

theorem identity60182 : scanCanonicalize (H12AffineFastState.compose env60182 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 68782) := by decide +kernel

theorem selectedBound60182 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60183 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,68782,1417,9664,3159,1289,9617,333275,4177,77954,66899,65542,68095,256,65674,78034,9600]

theorem envBound60183 : H12AffineFastState.Bounded env60183 := by
  intro p hp
  have h : env60183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60182_60183 : H12AffineEnvironment.transform 20 68782 env60182 = env60183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 68782 env60182 == env60183) = true)

def env60184 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,68782,1417,64,3159,1289,17,333275,4177,70914,66899,65542,68095,256,65674,70994,0]

theorem envBound60184 : H12AffineFastState.Bounded env60184 := by
  intro p hp
  have h : env60184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60183_60184 : H12AffineEnvironment.transform 12 1408 env60183 = env60184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60183 == env60184) = true)

theorem identity60184 : scanCanonicalize (H12AffineFastState.compose env60184 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1108) := by decide +kernel

theorem selectedBound60184 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60185 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1108,1408,1028,2129,65536,65798,262144,1025,2129,68782,1417,64,3159,1289,17,328079,1029,65878,66899,65542,68095,256,65674,65798,0]

theorem envBound60185 : H12AffineFastState.Bounded env60185 := by
  intro p hp
  have h : env60185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60184_60185 : H12AffineEnvironment.transform 11 1108 env60184 = env60185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env60184 == env60185) = true)

theorem identity60185 : scanCanonicalize (H12AffineFastState.compose env60185 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3261) := by decide +kernel

theorem selectedBound60185 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60186 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1108,1408,1028,2129,65536,65798,3261,1025,2129,68782,1417,64,3159,1289,17,68914,1029,65878,66899,65542,68095,256,65674,65798,0]

theorem envBound60186 : H12AffineFastState.Bounded env60186 := by
  intro p hp
  have h : env60186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60185_60186 : H12AffineEnvironment.transform 17 3261 env60185 = env60186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3261 env60185 == env60186) = true)

theorem identity60186 : scanCanonicalize (H12AffineFastState.compose env60186 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 324) := by decide +kernel

theorem selectedBound60186 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60187 : List Nat := [2,4,8,16,32,64,128,256,0,1024,324,1108,1408,1028,277,65536,65798,1529,1025,277,67050,1417,64,1299,1289,17,66678,1029,65878,66899,65542,65723,256,65674,65798,0]

theorem envBound60187 : H12AffineFastState.Bounded env60187 := by
  intro p hp
  have h : env60187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60186_60187 : H12AffineEnvironment.transform 10 324 env60186 = env60187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 324 env60186 == env60187) = true)

theorem identity60187 : scanCanonicalize (H12AffineFastState.compose env60187 (packedSelected [0,1,4,5,7,9,11,17] rootPS)) = affineNative (2^(9+1) ^^^ 425) := by decide +kernel

theorem selectedBound60187 : packedSelected [0,1,4,5,7,9,11,17] rootPS < 2^1333 := by decide +kernel

def env60188 : List Nat := [2,4,8,16,32,64,128,256,0,425,324,509,41,429,277,65536,65798,80,424,277,65603,32,64,186,160,17,66015,428,65878,65786,65542,65723,256,65674,65798,0]

theorem envBound60188 : H12AffineFastState.Bounded env60188 := by
  intro p hp
  have h : env60188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60187_60188 : H12AffineEnvironment.transform 9 425 env60187 = env60188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 425 env60187 == env60188) = true)

theorem identity60188 : scanCanonicalize (H12AffineFastState.compose env60188 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound60188 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60189 : List Nat := [2,4,8,16,32,64,128,256,0,425,324,509,41,429,277,170,428,80,424,277,233,32,64,186,160,17,373,428,508,80,172,17,256,32,428,0]

theorem envBound60189 : H12AffineFastState.Bounded env60189 := by
  intro p hp
  have h : env60189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60188_60189 : H12AffineEnvironment.transform 15 170 env60188 = env60189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env60188 == env60189) = true)

theorem identity60189 : scanCanonicalize (H12AffineFastState.compose env60189 (packedSelected [1,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound60189 : packedSelected [1,4,6] rootPS < 2^1333 := by decide +kernel

def env60190 : List Nat := [2,4,8,16,17,64,128,256,0,408,324,460,24,412,277,155,413,80,409,277,216,17,64,139,145,17,324,413,461,80,157,17,256,17,413,0]

theorem envBound60190 : H12AffineFastState.Bounded env60190 := by
  intro p hp
  have h : env60190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60189_60190 : H12AffineEnvironment.transform 4 17 env60189 = env60190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env60189 == env60190) = true)

theorem identity60190 : scanCanonicalize (H12AffineFastState.compose env60190 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound60190 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60191 : List Nat := [2,4,8,16,17,64,128,20,0,140,80,216,24,136,1,155,137,80,141,1,216,17,64,139,145,17,80,137,217,80,157,17,20,17,137,0]

theorem envBound60191 : H12AffineFastState.Bounded env60191 := by
  intro p hp
  have h : env60191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60190_60191 : H12AffineEnvironment.transform 7 20 env60190 = env60191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env60190 == env60191) = true)

theorem identity60191 : scanCanonicalize (H12AffineFastState.compose env60191 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound60191 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60192 : List Nat := [2,4,8,16,17,64,19,20,0,31,80,75,24,27,1,8,26,80,30,1,75,17,64,24,2,17,80,26,74,80,14,17,20,17,26,0]

theorem envBound60192 : H12AffineFastState.Bounded env60192 := by
  intro p hp
  have h : env60192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60191_60192 : H12AffineEnvironment.transform 6 19 env60191 = env60192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env60191 == env60192) = true)

theorem identity60192 : scanCanonicalize (H12AffineFastState.compose env60192 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound60192 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60193 : List Nat := [2,4,8,16,17,11,19,20,0,31,27,0,24,27,1,8,26,27,30,1,0,17,11,24,2,17,27,26,1,27,14,17,20,17,26,0]

theorem envBound60193 : H12AffineFastState.Bounded env60193 := by
  intro p hp
  have h : env60193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60192_60193 : H12AffineEnvironment.transform 5 11 env60192 = env60193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env60192 == env60193) = true)

theorem identity60193 : scanCanonicalize (H12AffineFastState.compose env60193 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound60193 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60194 : List Nat := [2,4,8,10,11,11,9,14,0,5,1,0,2,1,1,8,0,1,4,1,0,11,11,2,2,11,1,0,1,1,14,11,14,11,0,0]

theorem envBound60194 : H12AffineFastState.Bounded env60194 := by
  intro p hp
  have h : env60194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60193_60194 : H12AffineEnvironment.transform 3 10 env60193 = env60194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env60193 == env60194) = true)

def env60195 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,68782,1417,65,3159,1289,16,333275,4177,70915,66899,65542,68095,256,65674,70995,1]

theorem envBound60195 : H12AffineFastState.Bounded env60195 := by
  intro p hp
  have h : env60195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60183_60195 : H12AffineEnvironment.transform 12 1409 env60183 = env60195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60183 == env60195) = true)

theorem identity60195 : scanCanonicalize (H12AffineFastState.compose env60195 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 5458) := by decide +kernel

theorem selectedBound60195 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60196 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,5458,1,262144,1025,2129,6652,1417,65,3159,1289,16,262281,4177,81,4097,5460,7341,256,5592,1,1]

theorem envBound60196 : H12AffineFastState.Bounded env60196 := by
  intro p hp
  have h : env60196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60195_60196 : H12AffineEnvironment.transform 15 5458 env60195 = env60196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5458 env60195 == env60196) = true)

theorem identity60196 : scanCanonicalize (H12AffineFastState.compose env60196 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound60196 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60197 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1409,4176,1448,5458,1,262144,1025,1448,5125,1417,65,430,1289,16,262281,4177,81,4097,5460,4436,256,5592,1,1]

theorem envBound60197 : H12AffineFastState.Bounded env60197 := by
  intro p hp
  have h : env60197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60196_60197 : H12AffineEnvironment.transform 10 1529 env60196 = env60197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env60196 == env60197) = true)

theorem identity60197 : scanCanonicalize (H12AffineFastState.compose env60197 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 153) := by decide +kernel

theorem selectedBound60197 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60198 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1409,4176,1448,5458,1,153,1025,1448,5125,1417,65,430,1289,16,16,4177,81,4097,5460,4436,256,5592,1,1]

theorem envBound60198 : H12AffineFastState.Bounded env60198 := by
  intro p hp
  have h : env60198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60197_60198 : H12AffineEnvironment.transform 17 153 env60197 = env60198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 153 env60197 == env60198) = true)

theorem identity60198 : scanCanonicalize (H12AffineFastState.compose env60198 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 372) := by decide +kernel

theorem selectedBound60198 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60199 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,372,1409,292,1448,1062,1,153,1025,1448,1393,1417,65,430,1289,16,16,293,81,373,1056,32,256,1196,1,1]

theorem envBound60199 : H12AffineFastState.Bounded env60199 := by
  intro p hp
  have h : env60199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60198_60199 : H12AffineEnvironment.transform 11 372 env60198 = env60199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 372 env60198 == env60199) = true)

theorem identity60199 : scanCanonicalize (H12AffineFastState.compose env60199 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound60199 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60200 : List Nat := [2,4,8,16,32,64,128,256,0,221,292,372,348,292,373,251,1,153,220,373,428,340,65,430,468,16,16,293,81,373,253,32,256,113,1,1]

theorem envBound60200 : H12AffineFastState.Bounded env60200 := by
  intro p hp
  have h : env60200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60199_60200 : H12AffineEnvironment.transform 9 221 env60199 = env60200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env60199 == env60200) = true)

theorem identity60200 : scanCanonicalize (H12AffineFastState.compose env60200 (packedSelected [5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound60200 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60201 : List Nat := [2,4,8,16,32,64,128,172,0,221,136,216,240,136,217,251,1,153,220,217,0,248,65,2,120,16,16,137,81,217,253,32,172,113,1,1]

theorem envBound60201 : H12AffineFastState.Bounded env60201 := by
  intro p hp
  have h : env60201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60200_60201 : H12AffineEnvironment.transform 7 172 env60200 = env60201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env60200 == env60201) = true)

theorem identity60201 : scanCanonicalize (H12AffineFastState.compose env60201 (packedSelected [0,1,3,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound60201 : packedSelected [0,1,3,6,7] rootPS < 2^1333 := by decide +kernel

def env60202 : List Nat := [2,4,8,16,32,33,128,172,0,188,136,185,145,136,184,154,1,153,189,184,0,153,32,2,25,16,16,137,48,184,156,32,172,16,1,1]

theorem envBound60202 : H12AffineFastState.Bounded env60202 := by
  intro p hp
  have h : env60202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60201_60202 : H12AffineEnvironment.transform 5 33 env60201 = env60202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env60201 == env60202) = true)

theorem identity60202 : scanCanonicalize (H12AffineFastState.compose env60202 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound60202 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60203 : List Nat := [2,4,8,16,2,3,128,142,0,158,136,155,145,136,154,154,1,153,159,154,0,153,2,2,25,16,16,137,18,154,156,2,142,16,1,1]

theorem envBound60203 : H12AffineFastState.Bounded env60203 := by
  intro p hp
  have h : env60203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60202_60203 : H12AffineEnvironment.transform 4 2 env60202 = env60203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env60202 == env60203) = true)

theorem identity60203 : scanCanonicalize (H12AffineFastState.compose env60203 (packedSelected [1,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound60203 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env60204 : List Nat := [2,4,8,16,2,3,19,29,0,13,27,8,2,27,9,9,1,10,12,9,0,10,2,2,25,16,16,26,18,9,15,2,29,16,1,1]

theorem envBound60204 : H12AffineFastState.Bounded env60204 := by
  intro p hp
  have h : env60204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60203_60204 : H12AffineEnvironment.transform 6 19 env60203 = env60204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env60203 == env60204) = true)

theorem identity60204 : scanCanonicalize (H12AffineFastState.compose env60204 (packedSelected [3,6] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60204 : packedSelected [3,6] rootPS < 2^1333 := by decide +kernel

def env60205 : List Nat := [2,4,1,16,2,3,19,20,0,4,18,1,2,18,0,0,1,3,5,0,0,3,2,2,16,16,16,19,18,0,6,2,20,16,1,1]

theorem envBound60205 : H12AffineFastState.Bounded env60205 := by
  intro p hp
  have h : env60205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60204_60205 : H12AffineEnvironment.transform 2 1 env60204 = env60205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60204 == env60205) = true)

theorem identity60205 : scanCanonicalize (H12AffineFastState.compose env60205 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60205 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60206 : List Nat := [0,4,1,16,0,1,17,20,0,4,16,1,0,16,0,0,1,1,5,0,0,1,0,0,16,16,16,17,16,0,4,0,20,16,1,1]

theorem envBound60206 : H12AffineFastState.Bounded env60206 := by
  intro p hp
  have h : env60206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60205_60206 : H12AffineEnvironment.transform 0 0 env60205 = env60206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60205 == env60206) = true)

theorem identity60206 : scanCanonicalize (H12AffineFastState.compose env60206 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound60206 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60207 : List Nat := [0,4,1,0,0,1,1,4,0,4,0,1,0,0,0,0,1,1,5,0,0,1,0,0,0,0,0,1,0,0,4,0,4,0,1,1]

theorem envBound60207 : H12AffineFastState.Bounded env60207 := by
  intro p hp
  have h : env60207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60206_60207 : H12AffineEnvironment.transform 3 0 env60206 = env60207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env60206 == env60207) = true)

def env60208 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9664,3158,1289,9617,2365812,4177,77954,66898,65542,68094,256,65674,78034,9601]

theorem envBound60208 : H12AffineFastState.Bounded env60208 := by
  intro p hp
  have h : env60208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60181_60208 : H12AffineEnvironment.transform 8 1 env60181 = env60208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env60181 == env60208) = true)

theorem identity60208 : scanCanonicalize (H12AffineFastState.compose env60208 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 76078) := by decide +kernel

theorem selectedBound60208 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60209 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,76078,1417,9664,3158,1289,9617,340058,4177,77954,66898,65542,68094,256,65674,78034,9601]

theorem envBound60209 : H12AffineFastState.Bounded env60209 := by
  intro p hp
  have h : env60209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60208_60209 : H12AffineEnvironment.transform 20 76078 env60208 = env60209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 76078 env60208 == env60209) = true)

def env60210 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,68782,1417,64,3158,1289,17,333274,4177,70914,66898,65542,68094,256,65674,70994,1]

theorem envBound60210 : H12AffineFastState.Bounded env60210 := by
  intro p hp
  have h : env60210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60209_60210 : H12AffineEnvironment.transform 12 1408 env60209 = env60210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60209 == env60210) = true)

theorem identity60210 : scanCanonicalize (H12AffineFastState.compose env60210 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1109) := by decide +kernel

theorem selectedBound60210 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60211 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1109,1408,1029,2128,65536,65799,262144,1025,2128,68782,1417,64,3158,1289,17,328079,1028,65879,66898,65542,68094,256,65674,65799,1]

theorem envBound60211 : H12AffineFastState.Bounded env60211 := by
  intro p hp
  have h : env60211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60210_60211 : H12AffineEnvironment.transform 11 1109 env60210 = env60211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1109 env60210 == env60211) = true)

theorem identity60211 : scanCanonicalize (H12AffineFastState.compose env60211 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3261) := by decide +kernel

theorem selectedBound60211 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60212 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1109,1408,1029,2128,65536,65799,3261,1025,2128,68782,1417,64,3158,1289,17,68914,1028,65879,66898,65542,68094,256,65674,65799,1]

theorem envBound60212 : H12AffineFastState.Bounded env60212 := by
  intro p hp
  have h : env60212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60211_60212 : H12AffineEnvironment.transform 17 3261 env60211 = env60212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3261 env60211 == env60212) = true)

theorem identity60212 : scanCanonicalize (H12AffineFastState.compose env60212 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 325) := by decide +kernel

theorem selectedBound60212 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60213 : List Nat := [2,4,8,16,32,64,128,256,1,1024,325,1109,1408,1029,277,65536,65799,1528,1025,277,67051,1417,64,1299,1289,17,66679,1028,65879,66898,65542,65723,256,65674,65799,1]

theorem envBound60213 : H12AffineFastState.Bounded env60213 := by
  intro p hp
  have h : env60213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60212_60213 : H12AffineEnvironment.transform 10 325 env60212 = env60213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 325 env60212 == env60213) = true)

theorem identity60213 : scanCanonicalize (H12AffineFastState.compose env60213 (packedSelected [0,1,4,5,7,9,11,17] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60213 : packedSelected [0,1,4,5,7,9,11,17] rootPS < 2^1333 := by decide +kernel

def env60214 : List Nat := [2,4,8,16,16,64,128,256,1,1024,325,1109,1408,1029,277,65536,65799,1480,1025,277,67035,1417,64,1299,1289,17,66631,1028,65879,66898,65542,65675,256,65674,65799,1]

theorem envBound60214 : H12AffineFastState.Bounded env60214 := by
  intro p hp
  have h : env60214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60213_60214 : H12AffineEnvironment.transform 4 16 env60213 = env60214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60213 == env60214) = true)

theorem identity60214 : scanCanonicalize (H12AffineFastState.compose env60214 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(15+1) ^^^ 154) := by decide +kernel

theorem selectedBound60214 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env60215 : List Nat := [2,4,8,16,16,64,128,256,1,1024,325,1109,1408,1029,277,154,413,1480,1025,277,1345,1417,64,1299,1289,17,1245,1028,461,1480,156,17,256,16,413,1]

theorem envBound60215 : H12AffineFastState.Bounded env60215 := by
  intro p hp
  have h : env60215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60214_60215 : H12AffineEnvironment.transform 15 154 env60214 = env60215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 154 env60214 == env60215) = true)

theorem identity60215 : scanCanonicalize (H12AffineFastState.compose env60215 (packedSelected [0,3,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound60215 : packedSelected [0,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env60216 : List Nat := [2,4,8,16,16,64,128,94,1,1024,27,1109,1246,1029,75,154,195,1174,1025,75,1055,1239,64,1101,1111,17,1245,1028,147,1174,156,17,94,16,195,1]

theorem envBound60216 : H12AffineFastState.Bounded env60216 := by
  intro p hp
  have h : env60216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60215_60216 : H12AffineEnvironment.transform 7 94 env60215 = env60216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env60215 == env60216) = true)

theorem identity60216 : scanCanonicalize (H12AffineFastState.compose env60216 (packedSelected [4,5] rootPS)) = affineNative (2^(9+1) ^^^ 198) := by decide +kernel

theorem selectedBound60216 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env60217 : List Nat := [2,4,8,16,16,64,128,94,1,198,27,147,24,195,75,154,195,80,199,75,217,17,64,139,145,17,27,194,147,80,156,17,94,16,195,1]

theorem envBound60217 : H12AffineFastState.Bounded env60217 := by
  intro p hp
  have h : env60217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60216_60217 : H12AffineEnvironment.transform 9 198 env60216 = env60217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 198 env60216 == env60217) = true)

theorem identity60217 : scanCanonicalize (H12AffineFastState.compose env60217 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound60217 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60218 : List Nat := [2,4,8,16,16,64,89,94,1,31,27,74,24,26,75,67,26,80,30,75,0,17,64,82,72,17,27,27,74,80,69,17,94,16,26,1]

theorem envBound60218 : H12AffineFastState.Bounded env60218 := by
  intro p hp
  have h : env60218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60217_60218 : H12AffineEnvironment.transform 6 89 env60217 = env60218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env60217 == env60218) = true)

theorem identity60218 : scanCanonicalize (H12AffineFastState.compose env60218 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound60218 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60219 : List Nat := [2,4,8,16,16,16,9,14,1,31,27,26,24,26,27,19,26,0,30,27,0,17,16,2,24,17,27,27,26,0,21,17,14,16,26,1]

theorem envBound60219 : H12AffineFastState.Bounded env60219 := by
  intro p hp
  have h : env60219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60218_60219 : H12AffineEnvironment.transform 5 16 env60218 = env60219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60218 == env60219) = true)

theorem identity60219 : scanCanonicalize (H12AffineFastState.compose env60219 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound60219 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60220 : List Nat := [2,4,8,11,11,11,9,14,1,4,0,1,3,1,0,8,1,0,5,0,0,10,11,2,3,10,0,0,1,0,14,10,14,11,1,1]

theorem envBound60220 : H12AffineFastState.Bounded env60220 := by
  intro p hp
  have h : env60220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60219_60220 : H12AffineEnvironment.transform 3 11 env60219 = env60220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env60219 == env60220) = true)

def env60221 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,68783,1417,65,3158,1289,16,333275,4177,70915,66898,65542,68094,256,65674,70995,0]

theorem envBound60221 : H12AffineFastState.Bounded env60221 := by
  intro p hp
  have h : env60221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60209_60221 : H12AffineEnvironment.transform 12 1409 env60209 = env60221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60209 == env60221) = true)

theorem identity60221 : scanCanonicalize (H12AffineFastState.compose env60221 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 5458) := by decide +kernel

theorem selectedBound60221 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60222 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,5458,1,262144,1025,2128,6653,1417,65,3158,1289,16,262281,4177,81,4096,5460,7340,256,5592,1,0]

theorem envBound60222 : H12AffineFastState.Bounded env60222 := by
  intro p hp
  have h : env60222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60221_60222 : H12AffineEnvironment.transform 15 5458 env60221 = env60222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5458 env60221 == env60222) = true)

theorem identity60222 : scanCanonicalize (H12AffineFastState.compose env60222 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound60222 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60223 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1409,4176,1448,5458,1,262144,1025,1448,5125,1417,65,430,1289,16,262281,4177,81,4096,5460,4436,256,5592,1,0]

theorem envBound60223 : H12AffineFastState.Bounded env60223 := by
  intro p hp
  have h : env60223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60222_60223 : H12AffineEnvironment.transform 10 1528 env60222 = env60223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env60222 == env60223) = true)

theorem identity60223 : scanCanonicalize (H12AffineFastState.compose env60223 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 153) := by decide +kernel

theorem selectedBound60223 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60224 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1409,4176,1448,5458,1,153,1025,1448,5125,1417,65,430,1289,16,16,4177,81,4096,5460,4436,256,5592,1,0]

theorem envBound60224 : H12AffineFastState.Bounded env60224 := by
  intro p hp
  have h : env60224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60223_60224 : H12AffineEnvironment.transform 17 153 env60223 = env60224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 153 env60223 == env60224) = true)

theorem identity60224 : scanCanonicalize (H12AffineFastState.compose env60224 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 372) := by decide +kernel

theorem selectedBound60224 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60225 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,372,1409,292,1448,1062,1,153,1025,1448,1393,1417,65,430,1289,16,16,293,81,372,1056,32,256,1196,1,0]

theorem envBound60225 : H12AffineFastState.Bounded env60225 := by
  intro p hp
  have h : env60225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60224_60225 : H12AffineEnvironment.transform 11 372 env60224 = env60225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 372 env60224 == env60225) = true)

theorem identity60225 : scanCanonicalize (H12AffineFastState.compose env60225 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound60225 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60226 : List Nat := [2,4,8,16,32,64,128,256,1,220,292,372,349,292,372,250,1,153,221,372,429,341,65,430,469,16,16,293,81,372,252,32,256,112,1,0]

theorem envBound60226 : H12AffineFastState.Bounded env60226 := by
  intro p hp
  have h : env60226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60225_60226 : H12AffineEnvironment.transform 9 220 env60225 = env60226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env60225 == env60226) = true)

theorem identity60226 : scanCanonicalize (H12AffineFastState.compose env60226 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound60226 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60227 : List Nat := [2,4,8,16,32,16,128,256,1,140,292,292,269,292,292,170,1,153,141,292,429,261,17,430,389,16,16,293,1,292,172,32,256,32,1,0]

theorem envBound60227 : H12AffineFastState.Bounded env60227 := by
  intro p hp
  have h : env60227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60226_60227 : H12AffineEnvironment.transform 5 16 env60226 = env60227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60226 == env60227) = true)

theorem identity60227 : scanCanonicalize (H12AffineFastState.compose env60227 (packedSelected [0,6] rootPS)) = affineNative (2^(7+1) ^^^ 174) := by decide +kernel

theorem selectedBound60227 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env60228 : List Nat := [2,4,8,16,32,16,128,174,1,140,138,138,163,138,138,170,1,153,141,138,3,171,17,0,43,16,16,139,1,138,172,32,174,32,1,0]

theorem envBound60228 : H12AffineFastState.Bounded env60228 := by
  intro p hp
  have h : env60228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60227_60228 : H12AffineEnvironment.transform 7 174 env60227 = env60228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 174 env60227 == env60228) = true)

theorem identity60228 : scanCanonicalize (H12AffineFastState.compose env60228 (packedSelected [1,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound60228 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env60229 : List Nat := [2,4,8,16,32,16,40,6,1,36,34,34,11,34,34,2,1,49,37,34,3,3,17,0,43,16,16,35,1,34,4,32,6,32,1,0]

theorem envBound60229 : H12AffineFastState.Bounded env60229 := by
  intro p hp
  have h : env60229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60228_60229 : H12AffineEnvironment.transform 6 40 env60228 = env60229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env60228 == env60229) = true)

theorem identity60229 : scanCanonicalize (H12AffineFastState.compose env60229 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound60229 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env60230 : List Nat := [2,4,8,16,10,16,2,6,1,14,8,8,11,8,8,2,1,27,15,8,3,3,17,0,1,16,16,9,1,8,4,10,6,10,1,0]

theorem envBound60230 : H12AffineFastState.Bounded env60230 := by
  intro p hp
  have h : env60230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60229_60230 : H12AffineEnvironment.transform 4 10 env60229 = env60230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env60229 == env60230) = true)

theorem identity60230 : scanCanonicalize (H12AffineFastState.compose env60230 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound60230 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env60231 : List Nat := [2,4,8,0,10,0,2,6,1,14,8,8,11,8,8,2,1,11,15,8,3,3,1,0,1,0,0,9,1,8,4,10,6,10,1,0]

theorem envBound60231 : H12AffineFastState.Bounded env60231 := by
  intro p hp
  have h : env60231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60230_60231 : H12AffineEnvironment.transform 3 0 env60230 = env60231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env60230 == env60231) = true)

def env60232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1417,9665,3670,1288,9616,2366325,4177,77954,67411,65543,68606,256,65674,78034,10113]

theorem envBound60232 : H12AffineFastState.Bounded env60232 := by
  intro p hp
  have h : env60232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60180_60232 : H12AffineEnvironment.transform 22 9665 env60180 = env60232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env60180 == env60232) = true)

def env60233 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9665,3158,1288,9616,2365813,4177,77954,66899,65543,68094,256,65674,78034,9601]

theorem envBound60233 : H12AffineFastState.Bounded env60233 := by
  intro p hp
  have h : env60233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60232_60233 : H12AffineEnvironment.transform 8 0 env60232 = env60233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env60232 == env60233) = true)

theorem identity60233 : scanCanonicalize (H12AffineFastState.compose env60233 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 12670) := by decide +kernel

theorem selectedBound60233 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60234 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,12670,428,262144,1025,2129,2097152,1417,9665,3158,1288,9616,2365813,4177,508,13357,12665,14464,256,12788,428,9601]

theorem envBound60234 : H12AffineFastState.Bounded env60234 := by
  intro p hp
  have h : env60234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60233_60234 : H12AffineEnvironment.transform 15 12670 env60233 = env60234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12670 env60233 == env60234) = true)

def env60235 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,5374,428,262144,1025,2129,2097152,1417,65,3158,1288,16,2365813,4177,508,4525,5369,7424,256,5236,428,1]

theorem envBound60235 : H12AffineFastState.Bounded env60235 := by
  intro p hp
  have h : env60235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60234_60235 : H12AffineEnvironment.transform 12 1408 env60234 = env60235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60234 == env60235) = true)

theorem identity60235 : scanCanonicalize (H12AffineFastState.compose env60235 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6652) := by decide +kernel

theorem selectedBound60235 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60236 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,5374,428,262144,1025,2129,6652,1417,65,3158,1288,16,262281,4177,508,4525,5369,7424,256,5236,428,1]

theorem envBound60236 : H12AffineFastState.Bounded env60236 := by
  intro p hp
  have h : env60236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60235_60236 : H12AffineEnvironment.transform 20 6652 env60235 = env60236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6652 env60235 == env60236) = true)

theorem identity60236 : scanCanonicalize (H12AffineFastState.compose env60236 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound60236 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60237 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1408,4176,1448,5374,428,262144,1025,1448,5125,1417,65,431,1288,16,262281,4177,508,4525,5369,4345,256,5236,428,1]

theorem envBound60237 : H12AffineFastState.Bounded env60237 := by
  intro p hp
  have h : env60237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60236_60237 : H12AffineEnvironment.transform 10 1529 env60236 = env60237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env60236 == env60237) = true)

theorem identity60237 : scanCanonicalize (H12AffineFastState.compose env60237 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 309) := by decide +kernel

theorem selectedBound60237 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60238 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1408,4176,1448,5374,428,309,1025,1448,5125,1417,65,431,1288,16,444,4177,508,4525,5369,4345,256,5236,428,1]

theorem envBound60238 : H12AffineFastState.Bounded env60238 := by
  intro p hp
  have h : env60238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60237_60238 : H12AffineEnvironment.transform 17 309 env60237 = env60238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 309 env60237 == env60238) = true)

theorem identity60238 : scanCanonicalize (H12AffineFastState.compose env60238 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 216) := by decide +kernel

theorem selectedBound60238 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60239 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,216,1408,136,1448,1062,428,309,1025,1448,1245,1417,65,431,1288,16,444,137,508,373,1057,33,256,1196,428,1]

theorem envBound60239 : H12AffineFastState.Bounded env60239 := by
  intro p hp
  have h : env60239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60238_60239 : H12AffineEnvironment.transform 11 216 env60238 = env60239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 216 env60238 == env60239) = true)

theorem identity60239 : scanCanonicalize (H12AffineFastState.compose env60239 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound60239 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60240 : List Nat := [2,4,8,16,32,64,128,256,0,221,292,216,349,136,373,251,428,309,220,373,0,340,65,431,469,16,444,137,508,373,252,33,256,113,428,1]

theorem envBound60240 : H12AffineFastState.Bounded env60240 := by
  intro p hp
  have h : env60240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60239_60240 : H12AffineEnvironment.transform 9 221 env60239 = env60240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env60239 == env60240) = true)

theorem identity60240 : scanCanonicalize (H12AffineFastState.compose env60240 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound60240 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60241 : List Nat := [2,4,8,16,32,16,128,256,0,141,292,136,269,136,293,171,428,309,140,293,0,260,17,431,389,16,444,137,428,293,172,33,256,33,428,1]

theorem envBound60241 : H12AffineFastState.Bounded env60241 := by
  intro p hp
  have h : env60241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60240_60241 : H12AffineEnvironment.transform 5 16 env60240 = env60241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60240 == env60241) = true)

theorem identity60241 : scanCanonicalize (H12AffineFastState.compose env60241 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 54) := by decide +kernel

theorem selectedBound60241 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60242 : List Nat := [2,4,8,16,32,16,128,54,0,141,18,136,59,136,19,171,154,3,140,19,0,50,17,153,179,16,138,137,154,19,172,33,54,33,154,1]

theorem envBound60242 : H12AffineFastState.Bounded env60242 := by
  intro p hp
  have h : env60242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60241_60242 : H12AffineEnvironment.transform 7 54 env60241 = env60242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 54 env60241 == env60242) = true)

theorem identity60242 : scanCanonicalize (H12AffineFastState.compose env60242 (packedSelected [3,4,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound60242 : packedSelected [3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env60243 : List Nat := [2,4,8,16,32,16,57,54,0,52,18,49,59,49,19,18,35,3,53,19,0,50,17,32,10,16,51,48,35,19,21,33,54,33,35,1]

theorem envBound60243 : H12AffineFastState.Bounded env60243 := by
  intro p hp
  have h : env60243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60242_60243 : H12AffineEnvironment.transform 6 57 env60242 = env60243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env60242 == env60243) = true)

theorem identity60243 : scanCanonicalize (H12AffineFastState.compose env60243 (packedSelected [1,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound60243 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env60244 : List Nat := [2,4,8,0,32,0,41,38,0,36,2,33,43,33,3,2,35,3,37,3,0,34,1,32,10,0,35,32,35,3,5,33,38,33,35,1]

theorem envBound60244 : H12AffineFastState.Bounded env60244 := by
  intro p hp
  have h : env60244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60243_60244 : H12AffineEnvironment.transform 3 0 env60243 = env60244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env60243 == env60244) = true)

theorem identity60244 : scanCanonicalize (H12AffineFastState.compose env60244 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound60244 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60245 : List Nat := [2,4,8,0,11,0,2,13,0,15,2,10,0,10,3,2,8,3,14,3,0,9,1,11,10,0,8,11,8,3,5,10,13,10,8,1]

theorem envBound60245 : H12AffineFastState.Bounded env60245 := by
  intro p hp
  have h : env60245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60244_60245 : H12AffineEnvironment.transform 4 11 env60244 = env60245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env60244 == env60245) = true)

theorem identity60245 : scanCanonicalize (H12AffineFastState.compose env60245 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60245 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60246 : List Nat := [0,4,8,0,9,0,0,13,0,13,0,8,0,8,1,0,8,1,12,1,0,9,1,9,8,0,8,9,8,1,5,8,13,8,8,1]

theorem envBound60246 : H12AffineFastState.Bounded env60246 := by
  intro p hp
  have h : env60246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60245_60246 : H12AffineEnvironment.transform 0 0 env60245 = env60246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60245 == env60246) = true)

theorem identity60246 : scanCanonicalize (H12AffineFastState.compose env60246 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60246 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60247 : List Nat := [0,4,1,0,0,0,0,4,0,4,0,1,0,1,1,0,1,1,5,1,0,0,1,0,1,0,1,0,1,1,5,1,4,1,1,1]

theorem envBound60247 : H12AffineFastState.Bounded env60247 := by
  intro p hp
  have h : env60247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60246_60247 : H12AffineEnvironment.transform 2 1 env60246 = env60247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60246 == env60247) = true)

def env60248 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,5375,428,262144,1025,2129,2097152,1417,64,3158,1288,17,2365813,4177,508,4524,5368,7425,256,5237,428,0]

theorem envBound60248 : H12AffineFastState.Bounded env60248 := by
  intro p hp
  have h : env60248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60234_60248 : H12AffineEnvironment.transform 12 1409 env60234 = env60248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60234 == env60248) = true)

theorem identity60248 : scanCanonicalize (H12AffineFastState.compose env60248 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 3076) := by decide +kernel

theorem selectedBound60248 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60249 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,5375,428,262144,1025,2129,3076,1417,64,3158,1288,17,267633,4177,508,4524,5368,7425,256,5237,428,0]

theorem envBound60249 : H12AffineFastState.Bounded env60249 := by
  intro p hp
  have h : env60249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60248_60249 : H12AffineEnvironment.transform 20 3076 env60248 = env60249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 3076 env60248 == env60249) = true)

theorem identity60249 : scanCanonicalize (H12AffineFastState.compose env60249 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6377) := by decide +kernel

theorem selectedBound60249 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60250 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,5375,428,6377,1025,2129,3076,1417,64,3158,1288,17,3480,4177,508,4524,5368,7425,256,5237,428,0]

theorem envBound60250 : H12AffineFastState.Bounded env60250 := by
  intro p hp
  have h : env60250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60249_60250 : H12AffineEnvironment.transform 17 6377 env60249 = env60250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6377 env60249 == env60250) = true)

theorem identity60250 : scanCanonicalize (H12AffineFastState.compose env60250 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 461) := by decide +kernel

theorem selectedBound60250 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60251 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,461,1409,413,2129,1330,428,2340,1025,2129,3076,1417,64,3158,1288,17,3480,412,508,97,1333,3276,256,1464,428,0]

theorem envBound60251 : H12AffineFastState.Bounded env60251 := by
  intro p hp
  have h : env60251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60250_60251 : H12AffineEnvironment.transform 11 461 env60250 = env60251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 461 env60250 == env60251) = true)

theorem identity60251 : scanCanonicalize (H12AffineFastState.compose env60251 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound60251 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env60252 : List Nat := [2,4,8,16,32,64,128,256,0,409,2048,461,24,413,2129,171,428,2340,408,2129,2461,16,64,2511,145,17,2049,412,508,97,172,2389,256,33,428,0]

theorem envBound60252 : H12AffineFastState.Bounded env60252 := by
  intro p hp
  have h : env60252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60251_60252 : H12AffineEnvironment.transform 9 409 env60251 = env60252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env60251 == env60252) = true)

theorem identity60252 : scanCanonicalize (H12AffineFastState.compose env60252 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 325) := by decide +kernel

theorem selectedBound60252 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60253 : List Nat := [2,4,8,16,32,64,128,256,0,409,325,461,24,413,276,171,428,97,408,276,216,16,64,138,145,17,324,412,508,97,172,16,256,33,428,0]

theorem envBound60253 : H12AffineFastState.Bounded env60253 := by
  intro p hp
  have h : env60253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60252_60253 : H12AffineEnvironment.transform 10 325 env60252 = env60253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 325 env60252 == env60253) = true)

theorem identity60253 : scanCanonicalize (H12AffineFastState.compose env60253 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound60253 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env60254 : List Nat := [2,4,8,16,32,64,128,110,0,247,43,163,24,243,122,171,194,97,246,122,216,16,64,138,145,17,42,242,146,97,172,16,110,33,194,0]

theorem envBound60254 : H12AffineFastState.Bounded env60254 := by
  intro p hp
  have h : env60254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60253_60254 : H12AffineEnvironment.transform 7 110 env60253 = env60254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env60253 == env60254) = true)

theorem identity60254 : scanCanonicalize (H12AffineFastState.compose env60254 (packedSelected [0,1,6,11] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60254 : packedSelected [0,1,6,11] rootPS < 2^1333 := by decide +kernel

def env60255 : List Nat := [2,4,8,16,16,64,128,94,0,199,27,147,24,195,74,155,194,81,198,74,216,16,64,138,145,17,26,194,146,81,156,16,94,17,194,0]

theorem envBound60255 : H12AffineFastState.Bounded env60255 := by
  intro p hp
  have h : env60255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60254_60255 : H12AffineEnvironment.transform 4 16 env60254 = env60255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60254 == env60255) = true)

def env60256 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9665,3159,1288,9616,2365812,4177,77954,66898,65543,68095,256,65674,78034,9600]

theorem envBound60256 : H12AffineFastState.Bounded env60256 := by
  intro p hp
  have h : env60256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60232_60256 : H12AffineEnvironment.transform 8 1 env60232 = env60256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env60232 == env60256) = true)

theorem identity60256 : scanCanonicalize (H12AffineFastState.compose env60256 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 5374) := by decide +kernel

theorem selectedBound60256 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60257 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,5374,9260,262144,1025,2128,2097152,1417,9665,3159,1288,9616,2365812,4177,9340,4524,5369,7425,256,5236,9260,9600]

theorem envBound60257 : H12AffineFastState.Bounded env60257 := by
  intro p hp
  have h : env60257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60256_60257 : H12AffineEnvironment.transform 15 5374 env60256 = env60257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5374 env60256 == env60257) = true)

def env60258 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,5374,428,262144,1025,2128,2097152,1417,65,3159,1288,16,2365812,4177,508,4524,5369,7425,256,5236,428,0]

theorem envBound60258 : H12AffineFastState.Bounded env60258 := by
  intro p hp
  have h : env60258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60257_60258 : H12AffineEnvironment.transform 12 1408 env60257 = env60258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60257 == env60258) = true)

theorem identity60258 : scanCanonicalize (H12AffineFastState.compose env60258 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6653) := by decide +kernel

theorem selectedBound60258 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60259 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,5374,428,262144,1025,2128,6653,1417,65,3159,1288,16,262281,4177,508,4524,5369,7425,256,5236,428,0]

theorem envBound60259 : H12AffineFastState.Bounded env60259 := by
  intro p hp
  have h : env60259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60258_60259 : H12AffineEnvironment.transform 20 6653 env60258 = env60259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6653 env60258 == env60259) = true)

theorem identity60259 : scanCanonicalize (H12AffineFastState.compose env60259 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound60259 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60260 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1408,4176,1448,5374,428,262144,1025,1448,5125,1417,65,431,1288,16,262281,4177,508,4524,5369,4345,256,5236,428,0]

theorem envBound60260 : H12AffineFastState.Bounded env60260 := by
  intro p hp
  have h : env60260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60259_60260 : H12AffineEnvironment.transform 10 1528 env60259 = env60260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env60259 == env60260) = true)

theorem identity60260 : scanCanonicalize (H12AffineFastState.compose env60260 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 309) := by decide +kernel

theorem selectedBound60260 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60261 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1408,4176,1448,5374,428,309,1025,1448,5125,1417,65,431,1288,16,444,4177,508,4524,5369,4345,256,5236,428,0]

theorem envBound60261 : H12AffineFastState.Bounded env60261 := by
  intro p hp
  have h : env60261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60260_60261 : H12AffineEnvironment.transform 17 309 env60260 = env60261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 309 env60260 == env60261) = true)

theorem identity60261 : scanCanonicalize (H12AffineFastState.compose env60261 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 216) := by decide +kernel

theorem selectedBound60261 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60262 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,216,1408,136,1448,1062,428,309,1025,1448,1245,1417,65,431,1288,16,444,137,508,372,1057,33,256,1196,428,0]

theorem envBound60262 : H12AffineFastState.Bounded env60262 := by
  intro p hp
  have h : env60262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60261_60262 : H12AffineEnvironment.transform 11 216 env60261 = env60262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 216 env60261 == env60262) = true)

theorem identity60262 : scanCanonicalize (H12AffineFastState.compose env60262 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound60262 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60263 : List Nat := [2,4,8,16,32,64,128,256,1,220,292,216,348,136,372,250,428,309,221,372,1,341,65,431,468,16,444,137,508,372,253,33,256,112,428,0]

theorem envBound60263 : H12AffineFastState.Bounded env60263 := by
  intro p hp
  have h : env60263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60262_60263 : H12AffineEnvironment.transform 9 220 env60262 = env60263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env60262 == env60263) = true)

theorem identity60263 : scanCanonicalize (H12AffineFastState.compose env60263 (packedSelected [5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound60263 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60264 : List Nat := [2,4,8,16,32,64,128,172,1,220,136,216,240,136,216,250,0,153,221,216,1,249,65,3,120,16,16,137,80,216,253,33,172,112,0,0]

theorem envBound60264 : H12AffineFastState.Bounded env60264 := by
  intro p hp
  have h : env60264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60263_60264 : H12AffineEnvironment.transform 7 172 env60263 = env60264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env60263 == env60264) = true)

theorem identity60264 : scanCanonicalize (H12AffineFastState.compose env60264 (packedSelected [0,1,3,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound60264 : packedSelected [0,1,3,6,7] rootPS < 2^1333 := by decide +kernel

def env60265 : List Nat := [2,4,8,16,32,49,128,172,1,173,136,169,129,136,169,139,0,153,172,169,1,136,48,3,9,16,16,137,33,169,140,33,172,1,0,0]

theorem envBound60265 : H12AffineFastState.Bounded env60265 := by
  intro p hp
  have h : env60265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60264_60265 : H12AffineEnvironment.transform 5 49 env60264 = env60265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env60264 == env60265) = true)

theorem identity60265 : scanCanonicalize (H12AffineFastState.compose env60265 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound60265 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env60266 : List Nat := [2,4,8,16,26,11,128,150,1,151,136,147,129,136,147,139,0,153,150,147,1,136,10,3,9,16,16,137,27,147,140,27,150,1,0,0]

theorem envBound60266 : H12AffineFastState.Bounded env60266 := by
  intro p hp
  have h : env60266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60265_60266 : H12AffineEnvironment.transform 4 26 env60265 = env60266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env60265 == env60266) = true)

theorem identity60266 : scanCanonicalize (H12AffineFastState.compose env60266 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 27) := by decide +kernel

theorem selectedBound60266 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60267 : List Nat := [2,4,8,16,26,11,27,13,1,12,19,8,26,19,8,16,0,2,13,8,1,19,10,3,9,16,16,18,27,8,23,27,13,1,0,0]

theorem envBound60267 : H12AffineFastState.Bounded env60267 := by
  intro p hp
  have h : env60267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60266_60267 : H12AffineEnvironment.transform 6 27 env60266 = env60267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 27 env60266 == env60267) = true)

theorem identity60267 : scanCanonicalize (H12AffineFastState.compose env60267 (packedSelected [3,5,6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound60267 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env60268 : List Nat := [2,4,8,1,11,11,10,13,1,12,2,8,11,2,8,1,0,2,13,8,1,2,10,3,9,1,1,3,10,8,6,10,13,1,0,0]

theorem envBound60268 : H12AffineFastState.Bounded env60268 := by
  intro p hp
  have h : env60268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60267_60268 : H12AffineEnvironment.transform 3 1 env60267 = env60268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env60267 == env60268) = true)

theorem identity60268 : scanCanonicalize (H12AffineFastState.compose env60268 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound60268 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60269 : List Nat := [2,4,3,1,0,0,1,6,1,7,2,3,0,2,3,1,0,2,6,3,1,2,1,3,2,1,1,3,1,3,6,1,6,1,0,0]

theorem envBound60269 : H12AffineFastState.Bounded env60269 := by
  intro p hp
  have h : env60269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60268_60269 : H12AffineEnvironment.transform 2 3 env60268 = env60269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env60268 == env60269) = true)

theorem identity60269 : scanCanonicalize (H12AffineFastState.compose env60269 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60269 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60270 : List Nat := [1,4,0,1,0,0,1,5,1,4,1,0,0,1,0,1,0,1,5,0,1,1,1,0,1,1,1,0,1,0,5,1,5,1,0,0]

theorem envBound60270 : H12AffineFastState.Bounded env60270 := by
  intro p hp
  have h : env60270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60269_60270 : H12AffineEnvironment.transform 0 1 env60269 = env60270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60269 == env60270) = true)

def env60271 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,5374,429,262144,1025,2128,2097152,1417,64,3159,1288,17,2365812,4177,509,4524,5369,7425,256,5236,429,1]

theorem envBound60271 : H12AffineFastState.Bounded env60271 := by
  intro p hp
  have h : env60271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60257_60271 : H12AffineEnvironment.transform 12 1409 env60257 = env60271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60257 == env60271) = true)

theorem identity60271 : scanCanonicalize (H12AffineFastState.compose env60271 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 3076) := by decide +kernel

theorem selectedBound60271 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60272 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,5374,429,262144,1025,2128,3076,1417,64,3159,1288,17,267632,4177,509,4524,5369,7425,256,5236,429,1]

theorem envBound60272 : H12AffineFastState.Bounded env60272 := by
  intro p hp
  have h : env60272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60271_60272 : H12AffineEnvironment.transform 20 3076 env60271 = env60272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 3076 env60271 == env60272) = true)

theorem identity60272 : scanCanonicalize (H12AffineFastState.compose env60272 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6376) := by decide +kernel

theorem selectedBound60272 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60273 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,5374,429,6376,1025,2128,3076,1417,64,3159,1288,17,3480,4177,509,4524,5369,7425,256,5236,429,1]

theorem envBound60273 : H12AffineFastState.Bounded env60273 := by
  intro p hp
  have h : env60273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60272_60273 : H12AffineEnvironment.transform 17 6376 env60272 = env60273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6376 env60272 == env60273) = true)

theorem identity60273 : scanCanonicalize (H12AffineFastState.compose env60273 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 460) := by decide +kernel

theorem selectedBound60273 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60274 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,460,1409,412,2128,1330,429,2340,1025,2128,3076,1417,64,3159,1288,17,3480,413,509,96,1333,3277,256,1464,429,1]

theorem envBound60274 : H12AffineFastState.Bounded env60274 := by
  intro p hp
  have h : env60274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60273_60274 : H12AffineEnvironment.transform 11 460 env60273 = env60274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 460 env60273 == env60274) = true)

theorem identity60274 : scanCanonicalize (H12AffineFastState.compose env60274 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 324) := by decide +kernel

theorem selectedBound60274 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env60275 : List Nat := [2,4,8,16,32,64,128,256,1,1024,324,460,1409,412,276,1330,429,96,1025,276,1344,1417,64,1299,1288,17,1244,413,509,96,1333,1417,256,1464,429,1]

theorem envBound60275 : H12AffineFastState.Bounded env60275 := by
  intro p hp
  have h : env60275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60274_60275 : H12AffineEnvironment.transform 10 324 env60274 = env60275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 324 env60274 == env60275) = true)

theorem identity60275 : scanCanonicalize (H12AffineFastState.compose env60275 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound60275 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env60276 : List Nat := [2,4,8,16,32,64,128,256,1,409,324,460,24,412,276,171,429,96,408,276,217,16,64,138,145,17,325,413,509,96,172,16,256,33,429,1]

theorem envBound60276 : H12AffineFastState.Bounded env60276 := by
  intro p hp
  have h : env60276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60275_60276 : H12AffineEnvironment.transform 9 409 env60275 = env60276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env60275 == env60276) = true)

theorem identity60276 : scanCanonicalize (H12AffineFastState.compose env60276 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound60276 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env60277 : List Nat := [2,4,8,16,32,64,128,94,1,199,26,146,24,194,74,171,243,96,198,74,217,16,64,138,145,17,27,195,163,96,172,16,94,33,243,1]

theorem envBound60277 : H12AffineFastState.Bounded env60277 := by
  intro p hp
  have h : env60277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60276_60277 : H12AffineEnvironment.transform 7 94 env60276 = env60277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env60276 == env60277) = true)

theorem identity60277 : scanCanonicalize (H12AffineFastState.compose env60277 (packedSelected [1,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60277 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env60278 : List Nat := [2,4,8,16,16,64,128,94,1,199,26,146,24,194,74,155,195,80,198,74,217,16,64,138,145,17,27,195,147,80,156,16,94,17,195,1]

theorem envBound60278 : H12AffineFastState.Bounded env60278 := by
  intro p hp
  have h : env60278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60277_60278 : H12AffineEnvironment.transform 4 16 env60277 = env60278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60277 == env60278) = true)

def env60279 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,4194304,8388608,8399767,8397001,8388689,6561533,4177,77954,4260570,8463814,8465982,256,4261122,78034,8389184]

theorem envBound60279 : H12AffineFastState.Bounded env60279 := by
  intro p hp
  have h : env60279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60086_60279 : H12AffineEnvironment.transform 26 6561533 env60086 = env60279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 6561533 env60086 == env60279) = true)

def env60280 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1416,8388608,8399767,8397001,8388689,2366325,4177,77954,67410,8463814,8465982,256,65674,78034,8389184]

theorem envBound60280 : H12AffineFastState.Bounded env60280 := by
  intro p hp
  have h : env60280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60279_60280 : H12AffineEnvironment.transform 21 1416 env60279 = env60280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1416 env60279 == env60280) = true)

def env60281 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1416,9664,3671,1289,9617,2366325,4177,77954,67410,65542,68606,256,65674,78034,10112]

theorem envBound60281 : H12AffineFastState.Bounded env60281 := by
  intro p hp
  have h : env60281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60280_60281 : H12AffineEnvironment.transform 22 9664 env60280 = env60281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env60280 == env60281) = true)

def env60282 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9664,3159,1289,9617,2365813,4177,77954,66898,65542,68094,256,65674,78034,9600]

theorem envBound60282 : H12AffineFastState.Bounded env60282 := by
  intro p hp
  have h : env60282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60281_60282 : H12AffineEnvironment.transform 8 0 env60281 = env60282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env60281 == env60282) = true)

theorem identity60282 : scanCanonicalize (H12AffineFastState.compose env60282 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 10628) := by decide +kernel

theorem selectedBound60282 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60283 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,10628,1416,9664,3159,1289,9617,274673,4177,77954,66898,65542,68094,256,65674,78034,9600]

theorem envBound60283 : H12AffineFastState.Bounded env60283 := by
  intro p hp
  have h : env60283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60282_60283 : H12AffineEnvironment.transform 20 10628 env60282 = env60283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 10628 env60282 == env60283) = true)

def env60284 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,3076,1416,64,3159,1289,17,267633,4177,70914,66898,65542,68094,256,65674,70994,0]

theorem envBound60284 : H12AffineFastState.Bounded env60284 := by
  intro p hp
  have h : env60284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60283_60284 : H12AffineEnvironment.transform 12 1408 env60283 = env60284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60283 == env60284) = true)

theorem identity60284 : scanCanonicalize (H12AffineFastState.compose env60284 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 5375) := by decide +kernel

theorem selectedBound60284 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60285 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,5375,429,262144,1025,2129,3076,1416,64,3159,1289,17,267633,4177,509,4525,5369,7425,256,5237,429,0]

theorem envBound60285 : H12AffineFastState.Bounded env60285 := by
  intro p hp
  have h : env60285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60284_60285 : H12AffineEnvironment.transform 15 5375 env60284 = env60285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5375 env60284 == env60285) = true)

theorem identity60285 : scanCanonicalize (H12AffineFastState.compose env60285 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6376) := by decide +kernel

theorem selectedBound60285 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60286 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,5375,429,6376,1025,2129,3076,1416,64,3159,1289,17,3481,4177,509,4525,5369,7425,256,5237,429,0]

theorem envBound60286 : H12AffineFastState.Bounded env60286 := by
  intro p hp
  have h : env60286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60285_60286 : H12AffineEnvironment.transform 17 6376 env60285 = env60286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6376 env60285 == env60286) = true)

theorem identity60286 : scanCanonicalize (H12AffineFastState.compose env60286 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 460) := by decide +kernel

theorem selectedBound60286 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60287 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,460,1408,412,2129,1331,429,2340,1025,2129,3076,1416,64,3159,1289,17,3481,413,509,97,1333,3277,256,1465,429,0]

theorem envBound60287 : H12AffineFastState.Bounded env60287 := by
  intro p hp
  have h : env60287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60286_60287 : H12AffineEnvironment.transform 11 460 env60286 = env60287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 460 env60286 == env60287) = true)

theorem identity60287 : scanCanonicalize (H12AffineFastState.compose env60287 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound60287 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env60288 : List Nat := [2,4,8,16,32,64,128,256,0,408,2048,460,24,412,2129,171,429,2340,409,2129,2460,16,64,2511,145,17,2049,413,509,97,173,2389,256,33,429,0]

theorem envBound60288 : H12AffineFastState.Bounded env60288 := by
  intro p hp
  have h : env60288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60287_60288 : H12AffineEnvironment.transform 9 408 env60287 = env60288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env60287 == env60288) = true)

theorem identity60288 : scanCanonicalize (H12AffineFastState.compose env60288 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 325) := by decide +kernel

theorem selectedBound60288 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60289 : List Nat := [2,4,8,16,32,64,128,256,0,408,325,460,24,412,276,171,429,97,409,276,217,16,64,138,145,17,324,413,509,97,173,16,256,33,429,0]

theorem envBound60289 : H12AffineFastState.Bounded env60289 := by
  intro p hp
  have h : env60289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60288_60289 : H12AffineEnvironment.transform 10 325 env60288 = env60289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 325 env60288 == env60289) = true)

theorem identity60289 : scanCanonicalize (H12AffineFastState.compose env60289 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound60289 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env60290 : List Nat := [2,4,8,16,32,64,128,110,0,246,43,162,24,242,122,171,195,97,247,122,217,16,64,138,145,17,42,243,147,97,173,16,110,33,195,0]

theorem envBound60290 : H12AffineFastState.Bounded env60290 := by
  intro p hp
  have h : env60290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60289_60290 : H12AffineEnvironment.transform 7 110 env60289 = env60290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env60289 == env60290) = true)

theorem identity60290 : scanCanonicalize (H12AffineFastState.compose env60290 (packedSelected [0,1,6,11] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60290 : packedSelected [0,1,6,11] rootPS < 2^1333 := by decide +kernel

def env60291 : List Nat := [2,4,8,16,16,64,128,94,0,198,27,146,24,194,74,155,195,81,199,74,217,16,64,138,145,17,26,195,147,81,157,16,94,17,195,0]

theorem envBound60291 : H12AffineFastState.Bounded env60291 := by
  intro p hp
  have h : env60291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60290_60291 : H12AffineEnvironment.transform 4 16 env60290 = env60291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60290 == env60291) = true)

def env60292 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,3077,1416,65,3159,1289,16,267632,4177,70915,66898,65542,68094,256,65674,70995,1]

theorem envBound60292 : H12AffineFastState.Bounded env60292 := by
  intro p hp
  have h : env60292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60283_60292 : H12AffineEnvironment.transform 12 1409 env60283 = env60292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60283 == env60292) = true)

theorem identity60292 : scanCanonicalize (H12AffineFastState.compose env60292 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1529) := by decide +kernel

theorem selectedBound60292 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60293 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1529,1409,1449,2129,65536,65706,262144,1025,2129,3077,1416,65,3159,1289,16,262281,1448,65786,66898,65542,68094,256,65674,65706,1]

theorem envBound60293 : H12AffineFastState.Bounded env60293 := by
  intro p hp
  have h : env60293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60292_60293 : H12AffineEnvironment.transform 11 1529 env60292 = env60293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1529 env60292 == env60293) = true)

theorem identity60293 : scanCanonicalize (H12AffineFastState.compose env60293 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound60293 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60294 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1529,1409,1449,1449,65536,65706,262144,1025,1449,509,1416,65,431,1289,16,262281,1448,65786,66898,65542,66566,256,65674,65706,1]

theorem envBound60294 : H12AffineFastState.Bounded env60294 := by
  intro p hp
  have h : env60294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60293_60294 : H12AffineEnvironment.transform 10 1528 env60293 = env60294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env60293 == env60294) = true)

theorem identity60294 : scanCanonicalize (H12AffineFastState.compose env60294 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 65586) := by decide +kernel

theorem selectedBound60294 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60295 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1529,1409,1449,1449,65536,65706,65586,1025,1449,509,1416,65,431,1289,16,65723,1448,65786,66898,65542,66566,256,65674,65706,1]

theorem envBound60295 : H12AffineFastState.Bounded env60295 := by
  intro p hp
  have h : env60295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60294_60295 : H12AffineEnvironment.transform 17 65586 env60294 = env60295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65586 env60294 == env60295) = true)

theorem identity60295 : scanCanonicalize (H12AffineFastState.compose env60295 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound60295 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60296 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1529,1409,1449,1449,1063,1165,1045,1025,1449,509,1416,65,431,1289,16,1180,1448,1245,373,1057,33,256,1197,1165,1]

theorem envBound60296 : H12AffineFastState.Bounded env60296 := by
  intro p hp
  have h : env60296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60295_60296 : H12AffineEnvironment.transform 15 1063 env60295 = env60296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env60295 == env60296) = true)

theorem identity60296 : scanCanonicalize (H12AffineFastState.compose env60296 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound60296 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60297 : List Nat := [2,4,8,16,32,64,128,256,0,220,292,293,349,373,373,251,81,201,221,373,509,340,65,431,469,16,64,372,1,373,253,33,256,113,81,1]

theorem envBound60297 : H12AffineFastState.Bounded env60297 := by
  intro p hp
  have h : env60297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60296_60297 : H12AffineEnvironment.transform 9 220 env60296 = env60297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env60296 == env60297) = true)

theorem identity60297 : scanCanonicalize (H12AffineFastState.compose env60297 (packedSelected [5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound60297 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60298 : List Nat := [2,4,8,16,32,64,128,172,0,220,136,137,241,217,217,251,81,201,221,217,81,248,65,3,121,16,64,216,1,217,253,33,172,113,81,1]

theorem envBound60298 : H12AffineFastState.Bounded env60298 := by
  intro p hp
  have h : env60298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60297_60298 : H12AffineEnvironment.transform 7 172 env60297 = env60298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env60297 == env60298) = true)

theorem identity60298 : scanCanonicalize (H12AffineFastState.compose env60298 (packedSelected [3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 50) := by decide +kernel

theorem selectedBound60298 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env60299 : List Nat := [2,4,8,16,32,50,128,172,0,174,136,137,131,171,171,137,35,187,175,171,35,138,51,3,11,16,50,170,1,171,143,33,172,3,35,1]

theorem envBound60299 : H12AffineFastState.Bounded env60299 := by
  intro p hp
  have h : env60299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60298_60299 : H12AffineEnvironment.transform 5 50 env60298 = env60299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 50 env60298 == env60299) = true)

theorem identity60299 : scanCanonicalize (H12AffineFastState.compose env60299 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60299 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env60300 : List Nat := [1,4,8,16,32,49,128,172,0,173,136,137,128,168,168,137,32,184,172,168,32,137,48,0,8,16,49,169,1,168,140,33,172,0,32,1]

theorem envBound60300 : H12AffineFastState.Bounded env60300 := by
  intro p hp
  have h : env60300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60299_60300 : H12AffineEnvironment.transform 0 1 env60299 = env60300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60299 == env60300) = true)

theorem identity60300 : scanCanonicalize (H12AffineFastState.compose env60300 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound60300 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env60301 : List Nat := [1,4,8,9,32,40,128,172,0,173,136,137,128,168,168,137,32,161,172,168,32,137,41,0,8,9,40,169,1,168,140,33,172,0,32,1]

theorem envBound60301 : H12AffineFastState.Bounded env60301 := by
  intro p hp
  have h : env60301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60300_60301 : H12AffineEnvironment.transform 3 9 env60300 = env60301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env60300 == env60301) = true)

theorem identity60301 : scanCanonicalize (H12AffineFastState.compose env60301 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound60301 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60302 : List Nat := [1,4,8,9,32,40,40,4,0,5,32,33,40,0,0,33,32,9,4,0,32,33,41,0,8,9,40,1,1,0,36,33,4,0,32,1]

theorem envBound60302 : H12AffineFastState.Bounded env60302 := by
  intro p hp
  have h : env60302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60301_60302 : H12AffineEnvironment.transform 6 40 env60301 = env60302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env60301 == env60302) = true)

theorem identity60302 : scanCanonicalize (H12AffineFastState.compose env60302 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound60302 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env60303 : List Nat := [1,4,8,9,0,8,8,4,0,5,0,1,8,0,0,1,0,9,4,0,0,1,9,0,8,9,8,1,1,0,4,1,4,0,0,1]

theorem envBound60303 : H12AffineFastState.Bounded env60303 := by
  intro p hp
  have h : env60303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60302_60303 : H12AffineEnvironment.transform 4 0 env60302 = env60303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env60302 == env60303) = true)

theorem identity60303 : scanCanonicalize (H12AffineFastState.compose env60303 (packedSelected [6] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60303 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60304 : List Nat := [1,4,1,0,0,1,1,4,0,5,0,1,1,0,0,1,0,0,4,0,0,1,0,0,1,0,1,1,1,0,4,1,4,0,0,1]

theorem envBound60304 : H12AffineFastState.Bounded env60304 := by
  intro p hp
  have h : env60304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60303_60304 : H12AffineEnvironment.transform 2 1 env60303 = env60304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60303 == env60304) = true)

def env60305 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9664,3158,1289,9617,2365812,4177,77954,66899,65542,68095,256,65674,78034,9601]

theorem envBound60305 : H12AffineFastState.Bounded env60305 := by
  intro p hp
  have h : env60305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60281_60305 : H12AffineEnvironment.transform 8 1 env60281 = env60305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env60281 == env60305) = true)

theorem identity60305 : scanCanonicalize (H12AffineFastState.compose env60305 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 3076) := by decide +kernel

theorem selectedBound60305 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60306 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,3076,1416,9664,3158,1289,9617,267632,4177,77954,66899,65542,68095,256,65674,78034,9601]

theorem envBound60306 : H12AffineFastState.Bounded env60306 := by
  intro p hp
  have h : env60306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60305_60306 : H12AffineEnvironment.transform 20 3076 env60305 = env60306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 3076 env60305 == env60306) = true)

def env60307 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,3076,1416,64,3158,1289,17,267632,4177,70914,66899,65542,68095,256,65674,70994,1]

theorem envBound60307 : H12AffineFastState.Bounded env60307 := by
  intro p hp
  have h : env60307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60306_60307 : H12AffineEnvironment.transform 12 1408 env60306 = env60307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60306 == env60307) = true)

theorem identity60307 : scanCanonicalize (H12AffineFastState.compose env60307 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 5374) := by decide +kernel

theorem selectedBound60307 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60308 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,5374,428,262144,1025,2128,3076,1416,64,3158,1289,17,267632,4177,508,4525,5368,7425,256,5236,428,1]

theorem envBound60308 : H12AffineFastState.Bounded env60308 := by
  intro p hp
  have h : env60308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60307_60308 : H12AffineEnvironment.transform 15 5374 env60307 = env60308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5374 env60307 == env60308) = true)

theorem identity60308 : scanCanonicalize (H12AffineFastState.compose env60308 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6377) := by decide +kernel

theorem selectedBound60308 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60309 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,5374,428,6377,1025,2128,3076,1416,64,3158,1289,17,3481,4177,508,4525,5368,7425,256,5236,428,1]

theorem envBound60309 : H12AffineFastState.Bounded env60309 := by
  intro p hp
  have h : env60309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60308_60309 : H12AffineEnvironment.transform 17 6377 env60308 = env60309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6377 env60308 == env60309) = true)

theorem identity60309 : scanCanonicalize (H12AffineFastState.compose env60309 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 461) := by decide +kernel

theorem selectedBound60309 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60310 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,461,1408,413,2128,1331,428,2340,1025,2128,3076,1416,64,3158,1289,17,3481,412,508,96,1333,3276,256,1465,428,1]

theorem envBound60310 : H12AffineFastState.Bounded env60310 := by
  intro p hp
  have h : env60310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60309_60310 : H12AffineEnvironment.transform 11 461 env60309 = env60310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 461 env60309 == env60310) = true)

theorem identity60310 : scanCanonicalize (H12AffineFastState.compose env60310 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 324) := by decide +kernel

theorem selectedBound60310 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env60311 : List Nat := [2,4,8,16,32,64,128,256,1,1024,324,461,1408,413,276,1331,428,96,1025,276,1344,1416,64,1298,1289,17,1245,412,508,96,1333,1416,256,1465,428,1]

theorem envBound60311 : H12AffineFastState.Bounded env60311 := by
  intro p hp
  have h : env60311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60310_60311 : H12AffineEnvironment.transform 10 324 env60310 = env60311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 324 env60310 == env60311) = true)

theorem identity60311 : scanCanonicalize (H12AffineFastState.compose env60311 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound60311 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env60312 : List Nat := [2,4,8,16,32,64,128,256,1,408,324,461,24,413,276,171,428,96,409,276,216,16,64,138,145,17,325,412,508,96,173,16,256,33,428,1]

theorem envBound60312 : H12AffineFastState.Bounded env60312 := by
  intro p hp
  have h : env60312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60311_60312 : H12AffineEnvironment.transform 9 408 env60311 = env60312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env60311 == env60312) = true)

theorem identity60312 : scanCanonicalize (H12AffineFastState.compose env60312 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound60312 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env60313 : List Nat := [2,4,8,16,32,64,128,94,1,198,26,147,24,195,74,171,242,96,199,74,216,16,64,138,145,17,27,194,162,96,173,16,94,33,242,1]

theorem envBound60313 : H12AffineFastState.Bounded env60313 := by
  intro p hp
  have h : env60313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60312_60313 : H12AffineEnvironment.transform 7 94 env60312 = env60313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env60312 == env60313) = true)

theorem identity60313 : scanCanonicalize (H12AffineFastState.compose env60313 (packedSelected [1,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60313 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env60314 : List Nat := [2,4,8,16,16,64,128,94,1,198,26,147,24,195,74,155,194,80,199,74,216,16,64,138,145,17,27,194,146,80,157,16,94,17,194,1]

theorem envBound60314 : H12AffineFastState.Bounded env60314 := by
  intro p hp
  have h : env60314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60313_60314 : H12AffineEnvironment.transform 4 16 env60313 = env60314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60313 == env60314) = true)

def env60315 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,3076,1416,65,3158,1289,16,267632,4177,70915,66899,65542,68095,256,65674,70995,0]

theorem envBound60315 : H12AffineFastState.Bounded env60315 := by
  intro p hp
  have h : env60315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60306_60315 : H12AffineEnvironment.transform 12 1409 env60306 = env60315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60306 == env60315) = true)

theorem identity60315 : scanCanonicalize (H12AffineFastState.compose env60315 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1529) := by decide +kernel

theorem selectedBound60315 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60316 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1529,1409,1449,2128,65536,65706,262144,1025,2128,3076,1416,65,3158,1289,16,262281,1448,65786,66899,65542,68095,256,65674,65706,0]

theorem envBound60316 : H12AffineFastState.Bounded env60316 := by
  intro p hp
  have h : env60316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60315_60316 : H12AffineEnvironment.transform 11 1529 env60315 = env60316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1529 env60315 == env60316) = true)

theorem identity60316 : scanCanonicalize (H12AffineFastState.compose env60316 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound60316 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60317 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1529,1409,1449,1449,65536,65706,262144,1025,1449,509,1416,65,431,1289,16,262281,1448,65786,66899,65542,66566,256,65674,65706,0]

theorem envBound60317 : H12AffineFastState.Bounded env60317 := by
  intro p hp
  have h : env60317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60316_60317 : H12AffineEnvironment.transform 10 1529 env60316 = env60317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env60316 == env60317) = true)

theorem identity60317 : scanCanonicalize (H12AffineFastState.compose env60317 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 65586) := by decide +kernel

theorem selectedBound60317 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60318 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1529,1409,1449,1449,65536,65706,65586,1025,1449,509,1416,65,431,1289,16,65723,1448,65786,66899,65542,66566,256,65674,65706,0]

theorem envBound60318 : H12AffineFastState.Bounded env60318 := by
  intro p hp
  have h : env60318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60317_60318 : H12AffineEnvironment.transform 17 65586 env60317 = env60318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65586 env60317 == env60318) = true)

theorem identity60318 : scanCanonicalize (H12AffineFastState.compose env60318 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound60318 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60319 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1529,1409,1449,1449,1063,1165,1045,1025,1449,509,1416,65,431,1289,16,1180,1448,1245,372,1057,33,256,1197,1165,0]

theorem envBound60319 : H12AffineFastState.Bounded env60319 := by
  intro p hp
  have h : env60319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60318_60319 : H12AffineEnvironment.transform 15 1063 env60318 = env60319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env60318 == env60319) = true)

theorem identity60319 : scanCanonicalize (H12AffineFastState.compose env60319 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound60319 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60320 : List Nat := [2,4,8,16,32,64,128,256,1,221,292,292,348,372,372,250,80,200,220,372,509,341,65,431,468,16,65,373,0,372,252,33,256,112,80,0]

theorem envBound60320 : H12AffineFastState.Bounded env60320 := by
  intro p hp
  have h : env60320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60319_60320 : H12AffineEnvironment.transform 9 221 env60319 = env60320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env60319 == env60320) = true)

theorem identity60320 : scanCanonicalize (H12AffineFastState.compose env60320 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound60320 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60321 : List Nat := [2,4,8,16,32,17,128,256,1,140,292,292,269,293,293,171,1,153,141,293,428,260,16,431,389,16,16,292,0,293,173,33,256,33,1,0]

theorem envBound60321 : H12AffineFastState.Bounded env60321 := by
  intro p hp
  have h : env60321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60320_60321 : H12AffineEnvironment.transform 5 17 env60320 = env60321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60320 == env60321) = true)

theorem identity60321 : scanCanonicalize (H12AffineFastState.compose env60321 (packedSelected [0,6] rootPS)) = affineNative (2^(6+1) ^^^ 59) := by decide +kernel

theorem selectedBound60321 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env60322 : List Nat := [2,4,8,16,32,17,59,256,1,55,292,292,269,293,293,16,1,34,54,293,279,260,16,276,318,16,16,292,0,293,22,33,256,33,1,0]

theorem envBound60322 : H12AffineFastState.Bounded env60322 := by
  intro p hp
  have h : env60322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60321_60322 : H12AffineEnvironment.transform 6 59 env60321 = env60322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 59 env60321 == env60322) = true)

theorem identity60322 : scanCanonicalize (H12AffineFastState.compose env60322 (packedSelected [1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound60322 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env60323 : List Nat := [2,4,8,16,32,17,59,4,1,55,32,32,9,33,33,16,1,34,54,33,19,0,16,16,58,16,16,32,0,33,22,33,4,33,1,0]

theorem envBound60323 : H12AffineFastState.Bounded env60323 := by
  intro p hp
  have h : env60323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60322_60323 : H12AffineEnvironment.transform 7 4 env60322 = env60323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env60322 == env60323) = true)

theorem identity60323 : scanCanonicalize (H12AffineFastState.compose env60323 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 24) := by decide +kernel

theorem selectedBound60323 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60324 : List Nat := [2,4,8,16,24,17,3,4,1,15,24,24,9,25,25,16,1,26,14,25,19,0,16,16,2,16,16,24,0,25,22,25,4,25,1,0]

theorem envBound60324 : H12AffineFastState.Bounded env60324 := by
  intro p hp
  have h : env60324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60323_60324 : H12AffineEnvironment.transform 4 24 env60323 = env60324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 24 env60323 == env60324) = true)

theorem identity60324 : scanCanonicalize (H12AffineFastState.compose env60324 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound60324 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60325 : List Nat := [2,4,8,8,0,9,3,4,1,15,0,0,9,1,1,8,1,2,14,1,11,0,8,8,2,8,8,0,0,1,14,1,4,1,1,0]

theorem envBound60325 : H12AffineFastState.Bounded env60325 := by
  intro p hp
  have h : env60325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60324_60325 : H12AffineEnvironment.transform 3 8 env60324 = env60325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env60324 == env60325) = true)

theorem identity60325 : scanCanonicalize (H12AffineFastState.compose env60325 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60325 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60326 : List Nat := [0,4,8,8,0,9,1,4,1,13,0,0,9,1,1,8,1,0,12,1,9,0,8,8,0,8,8,0,0,1,12,1,4,1,1,0]

theorem envBound60326 : H12AffineFastState.Bounded env60326 := by
  intro p hp
  have h : env60326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60325_60326 : H12AffineEnvironment.transform 0 0 env60325 = env60326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60325 == env60326) = true)

def env60327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1416,9665,3670,1288,9616,2366325,4177,77954,67410,65543,68607,256,65674,78034,10113]

theorem envBound60327 : H12AffineFastState.Bounded env60327 := by
  intro p hp
  have h : env60327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60280_60327 : H12AffineEnvironment.transform 22 9665 env60280 = env60327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env60280 == env60327) = true)

def env60328 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9665,3158,1288,9616,2365813,4177,77954,66898,65543,68095,256,65674,78034,9601]

theorem envBound60328 : H12AffineFastState.Bounded env60328 := by
  intro p hp
  have h : env60328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60327_60328 : H12AffineEnvironment.transform 8 0 env60327 = env60328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env60327 == env60328) = true)

theorem identity60328 : scanCanonicalize (H12AffineFastState.compose env60328 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1108) := by decide +kernel

theorem selectedBound60328 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60329 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1108,8192,1028,2129,65536,74886,262144,1025,2129,2097152,1416,9665,3158,1288,9616,2362657,1029,74966,66898,65543,68095,256,65674,74886,9601]

theorem envBound60329 : H12AffineFastState.Bounded env60329 := by
  intro p hp
  have h : env60329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60328_60329 : H12AffineEnvironment.transform 11 1108 env60328 = env60329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env60328 == env60329) = true)

def env60330 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1108,1408,1028,2129,65536,65798,262144,1025,2129,2097152,1416,65,3158,1288,16,2362657,1029,65878,66898,65543,68095,256,65674,65798,1]

theorem envBound60330 : H12AffineFastState.Bounded env60330 := by
  intro p hp
  have h : env60330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60329_60330 : H12AffineEnvironment.transform 12 1408 env60329 = env60330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60329 == env60330) = true)

theorem identity60330 : scanCanonicalize (H12AffineFastState.compose env60330 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 3496) := by decide +kernel

theorem selectedBound60330 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60331 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1108,1408,1028,2129,65536,65798,262144,1025,2129,3496,1416,65,3158,1288,16,262281,1029,65878,66898,65543,68095,256,65674,65798,1]

theorem envBound60331 : H12AffineFastState.Bounded env60331 := by
  intro p hp
  have h : env60331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60330_60331 : H12AffineEnvironment.transform 20 3496 env60330 = env60331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 3496 env60330 == env60331) = true)

theorem identity60331 : scanCanonicalize (H12AffineFastState.compose env60331 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound60331 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60332 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1108,1408,1028,1449,65536,65798,262144,1025,1449,80,1416,65,430,1288,16,262281,1029,65878,66898,65543,66567,256,65674,65798,1]

theorem envBound60332 : H12AffineFastState.Bounded env60332 := by
  intro p hp
  have h : env60332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60331_60332 : H12AffineEnvironment.transform 10 1528 env60331 = env60332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env60331 == env60332) = true)

theorem identity60332 : scanCanonicalize (H12AffineFastState.compose env60332 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 65951) := by decide +kernel

theorem selectedBound60332 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60333 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1108,1408,1028,1449,65536,65798,65951,1025,1449,80,1416,65,430,1288,16,65814,1029,65878,66898,65543,66567,256,65674,65798,1]

theorem envBound60333 : H12AffineFastState.Bounded env60333 := by
  intro p hp
  have h : env60333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60332_60333 : H12AffineEnvironment.transform 17 65951 env60332 = env60333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65951 env60332 == env60333) = true)

theorem identity60333 : scanCanonicalize (H12AffineFastState.compose env60333 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound60333 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60334 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1108,1408,1028,1449,1063,1313,1464,1025,1449,80,1416,65,430,1288,16,1329,1029,1393,373,1056,32,256,1197,1313,1]

theorem envBound60334 : H12AffineFastState.Bounded env60334 := by
  intro p hp
  have h : env60334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60333_60334 : H12AffineEnvironment.transform 15 1063 env60333 = env60334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env60333 == env60334) = true)

theorem identity60334 : scanCanonicalize (H12AffineFastState.compose env60334 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound60334 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60335 : List Nat := [2,4,8,16,32,64,128,256,0,220,292,136,348,216,373,251,509,356,221,373,80,340,65,430,468,16,493,217,429,373,252,32,256,113,509,1]

theorem envBound60335 : H12AffineFastState.Bounded env60335 := by
  intro p hp
  have h : env60335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60334_60335 : H12AffineEnvironment.transform 9 220 env60334 = env60335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env60334 == env60335) = true)

theorem identity60335 : scanCanonicalize (H12AffineFastState.compose env60335 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound60335 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env60336 : List Nat := [2,4,8,16,32,64,41,256,0,117,292,33,348,113,373,82,340,356,116,373,80,340,65,263,381,16,324,112,260,373,85,32,256,113,340,1]

theorem envBound60336 : H12AffineFastState.Bounded env60336 := by
  intro p hp
  have h : env60336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60335_60336 : H12AffineEnvironment.transform 6 41 env60335 = env60336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env60335 == env60336) = true)

theorem identity60336 : scanCanonicalize (H12AffineFastState.compose env60336 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound60336 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60337 : List Nat := [2,4,8,16,32,17,41,256,0,36,292,33,269,32,292,3,261,309,37,292,1,261,16,263,300,16,277,33,260,292,4,32,256,32,261,1]

theorem envBound60337 : H12AffineFastState.Bounded env60337 := by
  intro p hp
  have h : env60337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60336_60337 : H12AffineEnvironment.transform 5 17 env60336 = env60337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60336 == env60337) = true)

theorem identity60337 : scanCanonicalize (H12AffineFastState.compose env60337 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound60337 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60338 : List Nat := [2,4,8,16,2,17,11,256,0,6,262,3,269,2,262,3,261,279,7,262,1,261,16,263,270,16,277,3,260,262,4,2,256,2,261,1]

theorem envBound60338 : H12AffineFastState.Bounded env60338 := by
  intro p hp
  have h : env60338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60337_60338 : H12AffineEnvironment.transform 4 2 env60337 = env60338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env60337 == env60338) = true)

theorem identity60338 : scanCanonicalize (H12AffineFastState.compose env60338 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60338 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60339 : List Nat := [2,4,1,16,2,17,2,256,0,6,262,3,260,2,262,3,261,279,7,262,1,261,16,263,263,16,277,3,260,262,4,2,256,2,261,1]

theorem envBound60339 : H12AffineFastState.Bounded env60339 := by
  intro p hp
  have h : env60339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60338_60339 : H12AffineEnvironment.transform 2 1 env60338 = env60339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60338 == env60339) = true)

theorem identity60339 : scanCanonicalize (H12AffineFastState.compose env60339 (packedSelected [3,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound60339 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env60340 : List Nat := [2,4,1,16,2,17,2,4,0,6,2,3,0,2,2,3,1,19,7,2,1,1,16,3,3,16,17,3,0,2,4,2,4,2,1,1]

theorem envBound60340 : H12AffineFastState.Bounded env60340 := by
  intro p hp
  have h : env60340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60339_60340 : H12AffineEnvironment.transform 7 4 env60339 = env60340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env60339 == env60340) = true)

theorem identity60340 : scanCanonicalize (H12AffineFastState.compose env60340 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound60340 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60341 : List Nat := [2,4,1,2,2,3,2,4,0,6,2,3,0,2,2,3,1,1,7,2,1,1,2,3,3,2,3,3,0,2,4,2,4,2,1,1]

theorem envBound60341 : H12AffineFastState.Bounded env60341 := by
  intro p hp
  have h : env60341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60340_60341 : H12AffineEnvironment.transform 3 2 env60340 = env60341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env60340 == env60341) = true)

theorem identity60341 : scanCanonicalize (H12AffineFastState.compose env60341 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60341 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60342 : List Nat := [1,4,1,1,1,0,1,4,0,5,1,0,0,1,1,0,1,1,4,1,1,1,1,0,0,1,0,0,0,1,4,1,4,1,1,1]

theorem envBound60342 : H12AffineFastState.Bounded env60342 := by
  intro p hp
  have h : env60342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60341_60342 : H12AffineEnvironment.transform 0 1 env60341 = env60342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60341 == env60342) = true)

def env60343 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1108,1409,1028,2129,65536,65799,262144,1025,2129,2097152,1416,64,3158,1288,17,2362657,1029,65879,66898,65543,68095,256,65674,65799,0]

theorem envBound60343 : H12AffineFastState.Bounded env60343 := by
  intro p hp
  have h : env60343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60329_60343 : H12AffineEnvironment.transform 12 1409 env60329 = env60343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60329 == env60343) = true)

theorem identity60343 : scanCanonicalize (H12AffineFastState.compose env60343 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 68782) := by decide +kernel

theorem selectedBound60343 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60344 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1108,1409,1028,2129,65536,65799,262144,1025,2129,68782,1416,64,3158,1288,17,328079,1029,65879,66898,65543,68095,256,65674,65799,0]

theorem envBound60344 : H12AffineFastState.Bounded env60344 := by
  intro p hp
  have h : env60344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60343_60344 : H12AffineEnvironment.transform 20 68782 env60343 = env60344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 68782 env60343 == env60344) = true)

theorem identity60344 : scanCanonicalize (H12AffineFastState.compose env60344 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3260) := by decide +kernel

theorem selectedBound60344 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60345 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1108,1409,1028,2129,65536,65799,3260,1025,2129,68782,1416,64,3158,1288,17,68915,1029,65879,66898,65543,68095,256,65674,65799,0]

theorem envBound60345 : H12AffineFastState.Bounded env60345 := by
  intro p hp
  have h : env60345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60344_60345 : H12AffineEnvironment.transform 17 3260 env60344 = env60345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3260 env60344 == env60345) = true)

theorem identity60345 : scanCanonicalize (H12AffineFastState.compose env60345 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 324) := by decide +kernel

theorem selectedBound60345 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60346 : List Nat := [2,4,8,16,32,64,128,256,0,1024,324,1108,1409,1028,277,65536,65799,1528,1025,277,67050,1416,64,1298,1288,17,66679,1029,65879,66898,65543,65723,256,65674,65799,0]

theorem envBound60346 : H12AffineFastState.Bounded env60346 := by
  intro p hp
  have h : env60346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60345_60346 : H12AffineEnvironment.transform 10 324 env60345 = env60346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 324 env60345 == env60346) = true)

theorem identity60346 : scanCanonicalize (H12AffineFastState.compose env60346 (packedSelected [0,1,4,5,7,9,11,17] rootPS)) = affineNative (2^(9+1) ^^^ 424) := by decide +kernel

theorem selectedBound60346 : packedSelected [0,1,4,5,7,9,11,17] rootPS < 2^1333 := by decide +kernel

def env60347 : List Nat := [2,4,8,16,32,64,128,256,0,424,324,508,41,428,277,65536,65799,80,425,277,65602,32,64,186,160,17,66015,429,65879,65786,65543,65723,256,65674,65799,0]

theorem envBound60347 : H12AffineFastState.Bounded env60347 := by
  intro p hp
  have h : env60347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60346_60347 : H12AffineEnvironment.transform 9 424 env60346 = env60347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 424 env60346 == env60347) = true)

theorem identity60347 : scanCanonicalize (H12AffineFastState.compose env60347 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound60347 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60348 : List Nat := [2,4,8,16,32,64,128,256,0,424,324,508,41,428,277,170,429,80,425,277,232,32,64,186,160,17,373,429,509,80,173,17,256,32,429,0]

theorem envBound60348 : H12AffineFastState.Bounded env60348 := by
  intro p hp
  have h : env60348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60347_60348 : H12AffineEnvironment.transform 15 170 env60347 = env60348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env60347 == env60348) = true)

theorem identity60348 : scanCanonicalize (H12AffineFastState.compose env60348 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60348 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env60349 : List Nat := [2,4,8,16,16,64,128,256,0,408,324,460,25,412,277,154,413,80,409,277,216,16,64,138,144,17,325,413,461,80,157,17,256,16,413,0]

theorem envBound60349 : H12AffineFastState.Bounded env60349 := by
  intro p hp
  have h : env60349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60348_60349 : H12AffineEnvironment.transform 4 16 env60348 = env60349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60348 == env60349) = true)

def env60350 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9665,3159,1288,9616,2365812,4177,77954,66899,65543,68094,256,65674,78034,9600]

theorem envBound60350 : H12AffineFastState.Bounded env60350 := by
  intro p hp
  have h : env60350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60327_60350 : H12AffineEnvironment.transform 8 1 env60327 = env60350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env60327 == env60350) = true)

theorem identity60350 : scanCanonicalize (H12AffineFastState.compose env60350 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 4564) := by decide +kernel

theorem selectedBound60350 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60351 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,4564,4176,2128,65536,65798,262144,1025,2128,2097152,1416,5141,3159,1288,5188,2365812,4177,65878,66899,65543,68094,256,65674,65798,5204]

theorem envBound60351 : H12AffineFastState.Bounded env60351 := by
  intro p hp
  have h : env60351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60350_60351 : H12AffineEnvironment.transform 12 4564 env60350 = env60351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4564 env60350 == env60351) = true)

def env60352 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1108,1408,1028,2128,65536,65798,262144,1025,2128,2097152,1416,65,3159,1288,16,2362656,1029,65878,66899,65543,68094,256,65674,65798,0]

theorem envBound60352 : H12AffineFastState.Bounded env60352 := by
  intro p hp
  have h : env60352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60351_60352 : H12AffineEnvironment.transform 11 1108 env60351 = env60352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env60351 == env60352) = true)

theorem identity60352 : scanCanonicalize (H12AffineFastState.compose env60352 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 3497) := by decide +kernel

theorem selectedBound60352 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60353 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1108,1408,1028,2128,65536,65798,262144,1025,2128,3497,1416,65,3159,1288,16,262281,1029,65878,66899,65543,68094,256,65674,65798,0]

theorem envBound60353 : H12AffineFastState.Bounded env60353 := by
  intro p hp
  have h : env60353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60352_60353 : H12AffineEnvironment.transform 20 3497 env60352 = env60353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 3497 env60352 == env60353) = true)

theorem identity60353 : scanCanonicalize (H12AffineFastState.compose env60353 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound60353 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60354 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1108,1408,1028,1449,65536,65798,262144,1025,1449,80,1416,65,430,1288,16,262281,1029,65878,66899,65543,66567,256,65674,65798,0]

theorem envBound60354 : H12AffineFastState.Bounded env60354 := by
  intro p hp
  have h : env60354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60353_60354 : H12AffineEnvironment.transform 10 1529 env60353 = env60354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env60353 == env60354) = true)

theorem identity60354 : scanCanonicalize (H12AffineFastState.compose env60354 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 65951) := by decide +kernel

theorem selectedBound60354 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60355 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1108,1408,1028,1449,65536,65798,65951,1025,1449,80,1416,65,430,1288,16,65814,1029,65878,66899,65543,66567,256,65674,65798,0]

theorem envBound60355 : H12AffineFastState.Bounded env60355 := by
  intro p hp
  have h : env60355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60354_60355 : H12AffineEnvironment.transform 17 65951 env60354 = env60355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65951 env60354 == env60355) = true)

theorem identity60355 : scanCanonicalize (H12AffineFastState.compose env60355 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound60355 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60356 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1108,1408,1028,1449,1063,1313,1464,1025,1449,80,1416,65,430,1288,16,1329,1029,1393,372,1056,32,256,1197,1313,0]

theorem envBound60356 : H12AffineFastState.Bounded env60356 := by
  intro p hp
  have h : env60356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60355_60356 : H12AffineEnvironment.transform 15 1063 env60355 = env60356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env60355 == env60356) = true)

theorem identity60356 : scanCanonicalize (H12AffineFastState.compose env60356 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound60356 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60357 : List Nat := [2,4,8,16,32,64,128,256,1,221,292,137,349,217,372,250,508,357,220,372,80,341,65,430,469,16,492,216,428,372,253,32,256,112,508,0]

theorem envBound60357 : H12AffineFastState.Bounded env60357 := by
  intro p hp
  have h : env60357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60356_60357 : H12AffineEnvironment.transform 9 221 env60356 = env60357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env60356 == env60357) = true)

theorem identity60357 : scanCanonicalize (H12AffineFastState.compose env60357 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound60357 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env60358 : List Nat := [2,4,8,16,17,64,128,256,1,221,277,137,349,217,325,203,461,340,220,325,80,341,65,415,469,16,477,216,413,325,204,17,256,65,461,0]

theorem envBound60358 : H12AffineFastState.Bounded env60358 := by
  intro p hp
  have h : env60358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60357_60358 : H12AffineEnvironment.transform 4 17 env60357 = env60358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env60357 == env60358) = true)

theorem identity60358 : scanCanonicalize (H12AffineFastState.compose env60358 (packedSelected [0,3,4,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound60358 : packedSelected [0,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env60359 : List Nat := [2,4,8,16,17,0,128,256,1,157,277,137,285,153,261,139,397,276,156,261,16,277,1,415,405,16,413,152,413,261,140,17,256,1,397,0]

theorem envBound60359 : H12AffineFastState.Bounded env60359 := by
  intro p hp
  have h : env60359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60358_60359 : H12AffineEnvironment.transform 5 0 env60358 = env60359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env60358 == env60359) = true)

theorem identity60359 : scanCanonicalize (H12AffineFastState.compose env60359 (packedSelected [1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 28) := by decide +kernel

theorem selectedBound60359 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env60360 : List Nat := [2,4,8,16,17,0,128,28,1,157,9,137,1,153,25,139,145,8,156,25,16,9,1,131,137,16,129,152,129,25,140,17,28,1,145,0]

theorem envBound60360 : H12AffineFastState.Bounded env60360 := by
  intro p hp
  have h : env60360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60359_60360 : H12AffineEnvironment.transform 7 28 env60359 = env60360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 28 env60359 == env60360) = true)

theorem identity60360 : scanCanonicalize (H12AffineFastState.compose env60360 (packedSelected [0,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound60360 : packedSelected [0,3,5] rootPS < 2^1333 := by decide +kernel

def env60361 : List Nat := [2,4,8,16,17,0,24,28,1,5,9,17,1,1,25,19,9,8,4,25,16,9,1,27,17,16,25,0,25,25,20,17,28,1,9,0]

theorem envBound60361 : H12AffineFastState.Bounded env60361 := by
  intro p hp
  have h : env60361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60360_60361 : H12AffineEnvironment.transform 6 24 env60360 = env60361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env60360 == env60361) = true)

theorem identity60361 : scanCanonicalize (H12AffineFastState.compose env60361 (packedSelected [0,1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound60361 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env60362 : List Nat := [2,4,8,11,10,0,3,7,1,5,9,10,1,1,2,8,9,8,4,2,11,9,1,0,10,11,2,0,2,2,15,10,7,1,9,0]

theorem envBound60362 : H12AffineFastState.Bounded env60362 := by
  intro p hp
  have h : env60362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60361_60362 : H12AffineEnvironment.transform 3 11 env60361 = env60362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env60361 == env60362) = true)

theorem identity60362 : scanCanonicalize (H12AffineFastState.compose env60362 (packedSelected [0,1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60362 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60363 : List Nat := [0,4,8,9,8,0,1,5,1,5,9,8,1,1,0,8,9,8,4,0,9,9,1,0,8,9,0,0,0,0,13,8,5,1,9,0]

theorem envBound60363 : H12AffineFastState.Bounded env60363 := by
  intro p hp
  have h : env60363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60362_60363 : H12AffineEnvironment.transform 0 0 env60362 = env60363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60362 == env60363) = true)

theorem identity60363 : scanCanonicalize (H12AffineFastState.compose env60363 (packedSelected [10] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60363 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env60364 : List Nat := [0,4,1,0,1,0,1,5,1,5,0,1,1,1,0,1,0,1,4,0,0,0,1,0,1,0,0,0,0,0,4,1,5,1,0,0]

theorem envBound60364 : H12AffineFastState.Bounded env60364 := by
  intro p hp
  have h : env60364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60363_60364 : H12AffineEnvironment.transform 2 1 env60363 = env60364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60363 == env60364) = true)

def env60365 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1109,1409,1029,2128,65536,65798,262144,1025,2128,2097152,1416,64,3159,1288,17,2362657,1028,65878,66899,65543,68094,256,65674,65798,1]

theorem envBound60365 : H12AffineFastState.Bounded env60365 := by
  intro p hp
  have h : env60365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60351_60365 : H12AffineEnvironment.transform 11 1109 env60351 = env60365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1109 env60351 == env60365) = true)

theorem identity60365 : scanCanonicalize (H12AffineFastState.compose env60365 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 68782) := by decide +kernel

theorem selectedBound60365 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60366 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1109,1409,1029,2128,65536,65798,262144,1025,2128,68782,1416,64,3159,1288,17,328079,1028,65878,66899,65543,68094,256,65674,65798,1]

theorem envBound60366 : H12AffineFastState.Bounded env60366 := by
  intro p hp
  have h : env60366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60365_60366 : H12AffineEnvironment.transform 20 68782 env60365 = env60366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 68782 env60365 == env60366) = true)

theorem identity60366 : scanCanonicalize (H12AffineFastState.compose env60366 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3260) := by decide +kernel

theorem selectedBound60366 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60367 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1109,1409,1029,2128,65536,65798,3260,1025,2128,68782,1416,64,3159,1288,17,68915,1028,65878,66899,65543,68094,256,65674,65798,1]

theorem envBound60367 : H12AffineFastState.Bounded env60367 := by
  intro p hp
  have h : env60367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60366_60367 : H12AffineEnvironment.transform 17 3260 env60366 = env60367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3260 env60366 == env60367) = true)

theorem identity60367 : scanCanonicalize (H12AffineFastState.compose env60367 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 325) := by decide +kernel

theorem selectedBound60367 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60368 : List Nat := [2,4,8,16,32,64,128,256,1,1024,325,1109,1409,1029,277,65536,65798,1529,1025,277,67051,1416,64,1298,1288,17,66678,1028,65878,66899,65543,65723,256,65674,65798,1]

theorem envBound60368 : H12AffineFastState.Bounded env60368 := by
  intro p hp
  have h : env60368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60367_60368 : H12AffineEnvironment.transform 10 325 env60367 = env60368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 325 env60367 == env60368) = true)

theorem identity60368 : scanCanonicalize (H12AffineFastState.compose env60368 (packedSelected [0,1,4,5,7,9,11,17] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60368 : packedSelected [0,1,4,5,7,9,11,17] rootPS < 2^1333 := by decide +kernel

def env60369 : List Nat := [2,4,8,16,16,64,128,256,1,1024,325,1109,1409,1029,277,65536,65798,1481,1025,277,67035,1416,64,1298,1288,17,66630,1028,65878,66899,65543,65675,256,65674,65798,1]

theorem envBound60369 : H12AffineFastState.Bounded env60369 := by
  intro p hp
  have h : env60369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60368_60369 : H12AffineEnvironment.transform 4 16 env60368 = env60369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60368 == env60369) = true)

theorem identity60369 : scanCanonicalize (H12AffineFastState.compose env60369 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(15+1) ^^^ 154) := by decide +kernel

theorem selectedBound60369 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env60370 : List Nat := [2,4,8,16,16,64,128,256,1,1024,325,1109,1409,1029,277,154,412,1481,1025,277,1345,1416,64,1298,1288,17,1244,1028,460,1481,157,17,256,16,412,1]

theorem envBound60370 : H12AffineFastState.Bounded env60370 := by
  intro p hp
  have h : env60370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60369_60370 : H12AffineEnvironment.transform 15 154 env60369 = env60370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 154 env60369 == env60370) = true)

theorem identity60370 : scanCanonicalize (H12AffineFastState.compose env60370 (packedSelected [0,3,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound60370 : packedSelected [0,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env60371 : List Nat := [2,4,8,16,16,64,128,94,1,1024,27,1109,1247,1029,75,154,194,1175,1025,75,1055,1238,64,1100,1110,17,1244,1028,146,1175,157,17,94,16,194,1]

theorem envBound60371 : H12AffineFastState.Bounded env60371 := by
  intro p hp
  have h : env60371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60370_60371 : H12AffineEnvironment.transform 7 94 env60370 = env60371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env60370 == env60371) = true)

def env60372 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1417,8388608,8399767,8397001,8388689,2366324,4177,77954,67411,8463814,8465982,256,65675,78034,8389184]

theorem envBound60372 : H12AffineFastState.Bounded env60372 := by
  intro p hp
  have h : env60372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60279_60372 : H12AffineEnvironment.transform 21 1417 env60279 = env60372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1417 env60279 == env60372) = true)

def env60373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1417,9664,3671,1289,9617,2366324,4177,77954,67411,65542,68606,256,65675,78034,10112]

theorem envBound60373 : H12AffineFastState.Bounded env60373 := by
  intro p hp
  have h : env60373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60372_60373 : H12AffineEnvironment.transform 22 9664 env60372 = env60373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env60372 == env60373) = true)

def env60374 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9664,3159,1289,9617,2365812,4177,77954,66899,65542,68094,256,65675,78034,9600]

theorem envBound60374 : H12AffineFastState.Bounded env60374 := by
  intro p hp
  have h : env60374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60373_60374 : H12AffineEnvironment.transform 8 0 env60373 = env60374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env60373 == env60374) = true)

theorem identity60374 : scanCanonicalize (H12AffineFastState.compose env60374 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 216) := by decide +kernel

theorem selectedBound60374 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60375 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,216,1417,9664,3159,1289,9617,268716,4177,77954,66899,65542,68094,256,65675,78034,9600]

theorem envBound60375 : H12AffineFastState.Bounded env60375 := by
  intro p hp
  have h : env60375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60374_60375 : H12AffineEnvironment.transform 20 216 env60374 = env60375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 216 env60374 == env60375) = true)

def env60376 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,216,1417,64,3159,1289,17,268716,4177,70914,66899,65542,68094,256,65675,70994,0]

theorem envBound60376 : H12AffineFastState.Bounded env60376 := by
  intro p hp
  have h : env60376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60375_60376 : H12AffineEnvironment.transform 12 1408 env60375 = env60376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60375 == env60376) = true)

theorem identity60376 : scanCanonicalize (H12AffineFastState.compose env60376 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 6179) := by decide +kernel

theorem selectedBound60376 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60377 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,6179,3441,262144,1025,2129,216,1417,64,3159,1289,17,268716,4177,3361,7536,6181,4573,256,6312,3441,0]

theorem envBound60377 : H12AffineFastState.Bounded env60377 := by
  intro p hp
  have h : env60377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60376_60377 : H12AffineEnvironment.transform 15 6179 env60376 = env60377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6179 env60376 == env60377) = true)

theorem identity60377 : scanCanonicalize (H12AffineFastState.compose env60377 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6377) := by decide +kernel

theorem selectedBound60377 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60378 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,6179,3441,6377,1025,2129,216,1417,64,3159,1289,17,325,4177,3361,7536,6181,4573,256,6312,3441,0]

theorem envBound60378 : H12AffineFastState.Bounded env60378 := by
  intro p hp
  have h : env60378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60377_60378 : H12AffineEnvironment.transform 17 6377 env60377 = env60378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6377 env60377 == env60378) = true)

theorem identity60378 : scanCanonicalize (H12AffineFastState.compose env60378 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 461) := by decide +kernel

theorem selectedBound60378 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60379 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,461,1408,413,2129,2542,3441,2340,1025,2129,216,1417,64,3159,1289,17,325,412,3361,3261,2536,16,256,2405,3441,0]

theorem envBound60379 : H12AffineFastState.Bounded env60379 := by
  intro p hp
  have h : env60379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60378_60379 : H12AffineEnvironment.transform 11 461 env60378 = env60379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 461 env60378 == env60379) = true)

theorem identity60379 : scanCanonicalize (H12AffineFastState.compose env60379 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 324) := by decide +kernel

theorem selectedBound60379 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env60380 : List Nat := [2,4,8,16,32,64,128,256,0,1024,324,461,1408,413,277,170,1077,96,1025,277,216,1417,64,1299,1289,17,325,412,1125,1529,172,16,256,33,1077,0]

theorem envBound60380 : H12AffineFastState.Bounded env60380 := by
  intro p hp
  have h : env60380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60379_60380 : H12AffineEnvironment.transform 10 324 env60379 = env60380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 324 env60379 == env60380) = true)

theorem identity60380 : scanCanonicalize (H12AffineFastState.compose env60380 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound60380 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60381 : List Nat := [2,4,8,16,32,64,128,256,0,409,324,461,25,413,277,170,428,96,408,277,216,16,64,138,144,17,325,412,508,96,172,16,256,33,428,0]

theorem envBound60381 : H12AffineFastState.Bounded env60381 := by
  intro p hp
  have h : env60381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60380_60381 : H12AffineEnvironment.transform 9 409 env60380 = env60381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env60380 == env60381) = true)

theorem identity60381 : scanCanonicalize (H12AffineFastState.compose env60381 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound60381 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env60382 : List Nat := [2,4,8,16,32,64,128,110,0,247,42,163,25,243,123,170,194,96,246,123,216,16,64,138,144,17,43,242,146,96,172,16,110,33,194,0]

theorem envBound60382 : H12AffineFastState.Bounded env60382 := by
  intro p hp
  have h : env60382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60381_60382 : H12AffineEnvironment.transform 7 110 env60381 = env60382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env60381 == env60382) = true)

theorem identity60382 : scanCanonicalize (H12AffineFastState.compose env60382 (packedSelected [0,1,6,11] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60382 : packedSelected [0,1,6,11] rootPS < 2^1333 := by decide +kernel

def env60383 : List Nat := [2,4,8,16,16,64,128,94,0,199,26,147,25,195,75,154,194,80,198,75,216,16,64,138,144,17,27,194,146,80,156,16,94,17,194,0]

theorem envBound60383 : H12AffineFastState.Bounded env60383 := by
  intro p hp
  have h : env60383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60382_60383 : H12AffineEnvironment.transform 4 16 env60382 = env60383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60382 == env60383) = true)

def env60384 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,216,1417,65,3159,1289,16,268716,4177,70915,66899,65542,68094,256,65675,70995,1]

theorem envBound60384 : H12AffineFastState.Bounded env60384 := by
  intro p hp
  have h : env60384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60375_60384 : H12AffineEnvironment.transform 12 1409 env60375 = env60384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60375 == env60384) = true)

theorem identity60384 : scanCanonicalize (H12AffineFastState.compose env60384 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 2341) := by decide +kernel

theorem selectedBound60384 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60385 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2341,1409,2421,2129,65536,68726,262144,1025,2129,216,1417,65,3159,1289,16,262281,2420,68646,66899,65542,68094,256,65675,68726,1]

theorem envBound60385 : H12AffineFastState.Bounded env60385 := by
  intro p hp
  have h : env60385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60384_60385 : H12AffineEnvironment.transform 11 2341 env60384 = env60385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2341 env60384 == env60385) = true)

theorem identity60385 : scanCanonicalize (H12AffineFastState.compose env60385 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound60385 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60386 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1245,1409,1165,1449,65536,65934,262144,1025,1449,216,1417,65,431,1289,16,262281,1164,66014,66899,65542,66566,256,65675,65934,1]

theorem envBound60386 : H12AffineFastState.Bounded env60386 := by
  intro p hp
  have h : env60386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60385_60386 : H12AffineEnvironment.transform 10 1528 env60385 = env60386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env60385 == env60386) = true)

theorem identity60386 : scanCanonicalize (H12AffineFastState.compose env60386 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 65815) := by decide +kernel

theorem selectedBound60386 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60387 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1245,1409,1165,1449,65536,65934,65815,1025,1449,216,1417,65,431,1289,16,65950,1164,66014,66899,65542,66566,256,65675,65934,1]

theorem envBound60387 : H12AffineFastState.Bounded env60387 := by
  intro p hp
  have h : env60387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60386_60387 : H12AffineEnvironment.transform 17 65815 env60386 = env60387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65815 env60386 == env60387) = true)

theorem identity60387 : scanCanonicalize (H12AffineFastState.compose env60387 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound60387 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60388 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1245,1409,1165,1449,1063,1449,1328,1025,1449,216,1417,65,431,1289,16,1465,1164,1529,372,1057,33,256,1196,1449,1]

theorem envBound60388 : H12AffineFastState.Bounded env60388 := by
  intro p hp
  have h : env60388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60387_60388 : H12AffineEnvironment.transform 15 1063 env60387 = env60388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env60387 == env60388) = true)

theorem identity60388 : scanCanonicalize (H12AffineFastState.compose env60388 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound60388 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60389 : List Nat := [2,4,8,16,32,64,128,256,0,221,293,0,348,80,372,250,372,493,220,372,216,340,65,431,468,16,356,81,292,372,252,33,256,113,372,1]

theorem envBound60389 : H12AffineFastState.Bounded env60389 := by
  intro p hp
  have h : env60389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60388_60389 : H12AffineEnvironment.transform 9 221 env60388 = env60389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env60388 == env60389) = true)

theorem identity60389 : scanCanonicalize (H12AffineFastState.compose env60389 (packedSelected [5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound60389 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60390 : List Nat := [2,4,8,16,32,64,128,172,0,221,137,0,240,80,216,250,216,65,220,216,216,248,65,3,120,16,200,81,136,216,252,33,172,113,216,1]

theorem envBound60390 : H12AffineFastState.Bounded env60390 := by
  intro p hp
  have h : env60390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60389_60390 : H12AffineEnvironment.transform 7 172 env60389 = env60390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env60389 == env60390) = true)

theorem identity60390 : scanCanonicalize (H12AffineFastState.compose env60390 (packedSelected [1,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound60390 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env60391 : List Nat := [2,4,8,16,2,64,128,142,0,221,137,0,210,80,216,216,216,65,220,216,216,218,65,3,90,16,200,81,136,216,222,3,142,83,216,1]

theorem envBound60391 : H12AffineFastState.Bounded env60391 := by
  intro p hp
  have h : env60391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60390_60391 : H12AffineEnvironment.transform 4 2 env60390 = env60391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env60390 == env60391) = true)

end H12CloudChart0