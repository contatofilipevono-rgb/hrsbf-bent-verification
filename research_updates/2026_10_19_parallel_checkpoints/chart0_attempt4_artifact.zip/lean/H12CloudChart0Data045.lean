import H12CloudChart0Data044

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound11248 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11249 : List Nat := [2,4,8,16,0,17,8,5,512,1024,1044,17,8,1045,1,2,1028,1045,1024,0,0,0,16,2,8,17,1045,1029,16,1044,1024,1,5,0,1045,512]

theorem envBound11249 : H12AffineFastState.Bounded env11249 := by
  intro p hp
  have h : env11249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11248_11249 : H12AffineEnvironment.transform 10 1044 env11248 = env11249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env11248 == env11249) = true)

def env11250 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,17,8,1,1,2,16,1,20,0,0,0,16,2,8,17,1,17,16,0,20,1,5,0,1,512]

theorem envBound11250 : H12AffineFastState.Bounded env11250 := by
  intro p hp
  have h : env11250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11249_11250 : H12AffineEnvironment.transform 9 20 env11249 = env11250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env11249 == env11250) = true)

theorem identity11250 : scanCanonicalize (H12AffineFastState.compose env11250 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound11250 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11251 : List Nat := [2,4,8,16,0,17,8,5,30,20,0,17,8,1,1,2,16,1,20,0,0,0,16,2,8,17,1,17,16,0,20,1,5,0,1,30]

theorem envBound11251 : H12AffineFastState.Bounded env11251 := by
  intro p hp
  have h : env11251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11250_11251 : H12AffineEnvironment.transform 8 30 env11250 = env11251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env11250 == env11251) = true)

def leafEnv11251 : List Nat := [2,4,8,16,0,17,8,5,30,20,0,17,8,1,1,2,16,1,20,0,0,0,16,2,20,8,1,17,1,17,16,0,20,1,5,0,4,2,1,30,1,0,0]

def active11251 : List Nat := [0,1,2,3]

def tree11251 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11251 : H12WitnessSearch.Good tree11251 := H12GlobalWitnessIndex.good

theorem leafIdentity11251 : H12AffineFastState.composeSystem env11251 rootObs = leafEnv11251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11251 rootObs == leafEnv11251) = true)

theorem terminalChecked11251 : H12PackedTerminal.terminalCheckFast leafEnv11251 active11251 tree11251 = true := by decide +kernel

def env11252 : List Nat := [2,4,8,16,0,17,8,5,512,21,1,17,8,0,1,2,17,0,21,0,0,0,16,2,8,17,0,16,16,1,21,1,5,0,0,512]

theorem envBound11252 : H12AffineFastState.Bounded env11252 := by
  intro p hp
  have h : env11252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11249_11252 : H12AffineEnvironment.transform 9 21 env11249 = env11252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env11249 == env11252) = true)

theorem identity11252 : scanCanonicalize (H12AffineFastState.compose env11252 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound11252 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11253 : List Nat := [2,4,8,5,0,4,8,5,512,0,1,4,8,0,1,2,4,0,0,0,0,0,5,2,8,4,0,5,5,1,0,1,5,0,0,512]

theorem envBound11253 : H12AffineFastState.Bounded env11253 := by
  intro p hp
  have h : env11253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11252_11253 : H12AffineEnvironment.transform 3 5 env11252 = env11253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env11252 == env11253) = true)

def leafEnv11253 : List Nat := [2,4,8,5,0,4,8,5,512,0,1,4,8,0,1,2,4,0,0,0,0,0,5,2,0,8,1,4,0,5,5,1,0,1,5,0,4,2,0,512,1,0,0]

def active11253 : List Nat := [0,1,2,8]

def tree11253 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11253 : H12WitnessSearch.Good tree11253 := H12GlobalWitnessIndex.good

theorem leafIdentity11253 : H12AffineFastState.composeSystem env11253 rootObs = leafEnv11253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11253 rootObs == leafEnv11253) = true)

theorem terminalChecked11253 : H12PackedTerminal.terminalCheckFast leafEnv11253 active11253 tree11253 = true := by decide +kernel

def env11254 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,272392,16,95497,8193,64,171281,79131,102743,442385,61704,392287,256,95531,103430,120407]

theorem envBound11254 : H12AffineFastState.Bounded env11254 := by
  intro p hp
  have h : env11254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11231_11254 : H12AffineEnvironment.transform 6 9 env11231 = env11254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11231 == env11254) = true)

theorem identity11254 : scanCanonicalize (H12AffineFastState.compose env11254 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound11254 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11255 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4161,272392,16,41311,8193,64,171281,57677,17665,442385,61704,272393,256,41341,16464,513]

theorem envBound11255 : H12AffineFastState.Bounded env11255 := by
  intro p hp
  have h : env11255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11254_11255 : H12AffineEnvironment.transform 15 54358 env11254 = env11255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env11254 == env11255) = true)

def env11256 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,262144,1024,32769,4113,272392,16,41231,8193,16,171281,57629,17665,442385,61704,272393,256,41261,16384,513]

theorem envBound11256 : H12AffineFastState.Bounded env11256 := by
  intro p hp
  have h : env11256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11255_11256 : H12AffineEnvironment.transform 5 16 env11255 = env11256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11255 == env11256) = true)

theorem identity11256 : scanCanonicalize (H12AffineFastState.compose env11256 (packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 56357) := by decide +kernel

theorem selectedBound11256 : packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS < 2^1333 := by decide +kernel

def env11257 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,56357,1024,32769,4113,62509,16,41231,8193,16,171281,57629,17665,138292,61704,62508,256,41261,16384,513]

theorem envBound11257 : H12AffineFastState.Bounded env11257 := by
  intro p hp
  have h : env11257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11256_11257 : H12AffineEnvironment.transform 17 56357 env11256 = env11257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56357 env11256 == env11257) = true)

theorem identity11257 : scanCanonicalize (H12AffineFastState.compose env11257 (packedSelected [0,1,2,3,5,6,7,8,10,18,19,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound11257 : packedSelected [0,1,2,3,5,6,7,8,10,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env11258 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54278,49168,56357,1024,32769,4113,62509,16,41231,8193,16,23809,57629,17665,56356,61704,62508,256,41261,16384,513]

theorem envBound11258 : H12AffineFastState.Bounded env11258 := by
  intro p hp
  have h : env11258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11257_11258 : H12AffineEnvironment.transform 16 49168 env11257 = env11258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env11257 == env11258) = true)

theorem identity11258 : scanCanonicalize (H12AffineFastState.compose env11258 (packedSelected [0,1,2,4,6,7,8,9,12,14,15,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound11258 : packedSelected [0,1,2,4,6,7,8,9,12,14,15,19] rootPS < 2^1333 := by decide +kernel

def env11259 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,0,21510,16400,23589,1024,1,4113,29741,16,8463,8193,16,23809,24861,17665,23588,28936,29740,256,8493,16384,513]

theorem envBound11259 : H12AffineFastState.Bounded env11259 := by
  intro p hp
  have h : env11259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11258_11259 : H12AffineEnvironment.transform 14 0 env11258 = env11259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env11258 == env11259) = true)

def env11260 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,262144,1024,32769,4112,272392,16,41230,8193,17,171281,57628,17665,442385,61704,272393,256,41260,16385,513]

theorem envBound11260 : H12AffineFastState.Bounded env11260 := by
  intro p hp
  have h : env11260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11255_11260 : H12AffineEnvironment.transform 5 17 env11255 = env11260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11255 == env11260) = true)

theorem identity11260 : scanCanonicalize (H12AffineFastState.compose env11260 (packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound11260 : packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS < 2^1333 := by decide +kernel

def env11261 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54279,38160,262144,1024,32769,4112,272392,16,41230,8193,17,2049,57628,17665,283905,61704,272393,256,41260,16385,513]

theorem envBound11261 : H12AffineFastState.Bounded env11261 := by
  intro p hp
  have h : env11261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11260_11261 : H12AffineEnvironment.transform 16 38160 env11260 = env11261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env11260 == env11261) = true)

theorem identity11261 : scanCanonicalize (H12AffineFastState.compose env11261 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 35109) := by decide +kernel

theorem selectedBound11261 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11262 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54279,38160,35109,1024,32769,4112,41261,16,41230,8193,17,2049,57628,17665,56356,61704,41260,256,41260,16385,513]

theorem envBound11262 : H12AffineFastState.Bounded env11262 := by
  intro p hp
  have h : env11262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11261_11262 : H12AffineEnvironment.transform 17 35109 env11261 = env11262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35109 env11261 == env11262) = true)

theorem identity11262 : scanCanonicalize (H12AffineFastState.compose env11262 (packedSelected [3,5,10,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 3344) := by decide +kernel

theorem selectedBound11262 : packedSelected [3,5,10,11,15] rootPS < 2^1333 := by decide +kernel

def env11263 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,3344,32768,39191,38160,35109,1024,32769,4112,41261,16,41230,8193,17,2049,44044,2065,37172,48152,41260,256,41260,3345,513]

theorem envBound11263 : H12AffineFastState.Bounded env11263 := by
  intro p hp
  have h : env11263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11262_11263 : H12AffineEnvironment.transform 13 3344 env11262 = env11263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3344 env11262 == env11263) = true)

theorem identity11263 : scanCanonicalize (H12AffineFastState.compose env11263 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound11263 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env11264 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,3344,32768,39191,38160,35109,1024,32769,4112,32800,16,32771,268,17,2049,36097,2065,37172,40213,32801,256,32801,3345,513]

theorem envBound11264 : H12AffineFastState.Bounded env11264 := by
  intro p hp
  have h : env11264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11263_11264 : H12AffineEnvironment.transform 12 269 env11263 = env11264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env11263 == env11264) = true)

theorem identity11264 : scanCanonicalize (H12AffineFastState.compose env11264 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(14+1) ^^^ 7204) := by decide +kernel

theorem selectedBound11264 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env11265 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,3344,7204,1331,2356,5377,1024,7205,4112,7172,16,7207,268,17,2049,4389,2065,3344,305,7173,256,7173,3345,513]

theorem envBound11265 : H12AffineFastState.Bounded env11265 := by
  intro p hp
  have h : env11265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11264_11265 : H12AffineEnvironment.transform 14 7204 env11264 = env11265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7204 env11264 == env11265) = true)

theorem identity11265 : scanCanonicalize (H12AffineFastState.compose env11265 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound11265 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env11266 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2064,269,3344,1076,1331,2356,3345,1024,1077,2048,1044,16,1079,268,17,2049,2357,2065,3344,305,1045,256,1045,3345,513]

theorem envBound11266 : H12AffineFastState.Bounded env11266 := by
  intro p hp
  have h : env11266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11265_11266 : H12AffineEnvironment.transform 11 2064 env11265 = env11266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env11265 == env11266) = true)

theorem identity11266 : scanCanonicalize (H12AffineFastState.compose env11266 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound11266 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env11267 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,2064,269,2341,1,262,2356,2340,53,0,2048,33,16,2,268,17,2049,2357,2065,2341,305,32,256,32,2340,513]

theorem envBound11267 : H12AffineFastState.Bounded env11267 := by
  intro p hp
  have h : env11267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11266_11267 : H12AffineEnvironment.transform 9 53 env11266 = env11267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env11266 == env11267) = true)

theorem identity11267 : scanCanonicalize (H12AffineFastState.compose env11267 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound11267 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11268 : List Nat := [2,4,8,16,17,17,9,256,512,4,2048,2064,269,2324,1,262,2309,2325,4,0,2048,16,16,2,268,17,2049,2308,2065,2324,256,17,256,17,2325,513]

theorem envBound11268 : H12AffineFastState.Bounded env11268 := by
  intro p hp
  have h : env11268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11267_11268 : H12AffineEnvironment.transform 4 17 env11267 = env11268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env11267 == env11268) = true)

theorem identity11268 : scanCanonicalize (H12AffineFastState.compose env11268 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound11268 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11269 : List Nat := [2,4,8,16,17,17,9,256,276,4,2048,2064,269,2324,1,262,2309,2325,4,0,2048,16,16,2,268,17,2049,2308,2065,2324,256,17,256,17,2325,277]

theorem envBound11269 : H12AffineFastState.Bounded env11269 := by
  intro p hp
  have h : env11269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11268_11269 : H12AffineEnvironment.transform 8 276 env11268 = env11269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env11268 == env11269) = true)

theorem identity11269 : scanCanonicalize (H12AffineFastState.compose env11269 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound11269 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env11270 : List Nat := [2,4,8,16,17,17,9,5,17,4,2048,2064,8,2065,1,3,2048,2064,4,0,2048,16,16,2,9,17,2049,2049,2065,2065,5,17,5,17,2064,16]

theorem envBound11270 : H12AffineFastState.Bounded env11270 := by
  intro p hp
  have h : env11270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11269_11270 : H12AffineEnvironment.transform 7 5 env11269 = env11270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env11269 == env11270) = true)

theorem identity11270 : scanCanonicalize (H12AffineFastState.compose env11270 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound11270 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11271 : List Nat := [2,4,8,1,0,0,9,5,0,4,2048,2049,8,2048,1,3,2048,2049,4,0,2048,1,1,2,9,0,2049,2049,2048,2048,5,0,5,0,2049,1]

theorem envBound11271 : H12AffineFastState.Bounded env11271 := by
  intro p hp
  have h : env11271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11270_11271 : H12AffineEnvironment.transform 3 1 env11270 = env11271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env11270 == env11271) = true)

theorem identity11271 : scanCanonicalize (H12AffineFastState.compose env11271 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound11271 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11272 : List Nat := [2,4,3,1,0,0,2,5,0,4,2048,2049,3,2048,1,3,2048,2049,4,0,2048,1,1,2,2,0,2049,2049,2048,2048,5,0,5,0,2049,1]

theorem envBound11272 : H12AffineFastState.Bounded env11272 := by
  intro p hp
  have h : env11272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11271_11272 : H12AffineEnvironment.transform 2 3 env11271 = env11272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env11271 == env11272) = true)

def env11273 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830976,25265169,23160256,257,27378861,27337992,25207750]

theorem envBound11273 : H12AffineFastState.Bounded env11273 := by
  intro p hp
  have h : env11273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11050_11273 : H12AffineEnvironment.transform 18 1025 env11050 = env11273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env11050 == env11273) = true)

theorem identity11273 : scanCanonicalize (H12AffineFastState.compose env11273 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10626079) := by decide +kernel

theorem selectedBound11273 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env11274 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10626079,8328,64,6677534,8626322,10507600,8830976,2334734,12796383,257,254130,196887,2263001]

theorem envBound11274 : H12AffineFastState.Bounded env11274 := by
  intro p hp
  have h : env11274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11273_11274 : H12AffineEnvironment.transform 23 10626079 env11273 = env11274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10626079 env11273 == env11274) = true)

def env11275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,155996,2114883,8328,64,6677534,115150,2241548,303452,2334734,4268163,257,254130,196887,2263001]

theorem envBound11275 : H12AffineFastState.Bounded env11275 := by
  intro p hp
  have h : env11275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11274_11275 : H12AffineEnvironment.transform 22 155996 env11274 = env11275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 155996 env11274 == env11275) = true)

def env11276 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2534744,155996,2114883,8328,64,215366,115150,2241548,303452,2334734,2592219,257,254130,196887,2263001]

theorem envBound11276 : H12AffineFastState.Bounded env11276 := by
  intro p hp
  have h : env11276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11275_11276 : H12AffineEnvironment.transform 21 2534744 env11275 = env11276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2534744 env11275 == env11276) = true)

def env11277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441624,155996,21763,8328,64,215366,115150,140364,303452,241742,499099,257,254130,196887,169881]

theorem envBound11277 : H12AffineFastState.Bounded env11277 := by
  intro p hp
  have h : env11277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11276_11277 : H12AffineEnvironment.transform 20 4160 env11276 = env11277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env11276 == env11277) = true)

theorem identity11277 : scanCanonicalize (H12AffineFastState.compose env11277 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38296) := by decide +kernel

theorem selectedBound11277 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11278 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,4160,272512,62660,21763,8328,64,122078,115150,45524,303452,75222,329731,257,95530,103567,513]

theorem envBound11278 : H12AffineFastState.Bounded env11278 := by
  intro p hp
  have h : env11278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11277_11278 : H12AffineEnvironment.transform 16 38296 env11277 = env11278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env11277 == env11278) = true)

def env11279 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4160,272392,62540,21763,8192,64,121942,115014,45404,303452,75102,329731,257,95530,103431,513]

theorem envBound11279 : H12AffineFastState.Bounded env11279 := by
  intro p hp
  have h : env11279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11278_11279 : H12AffineEnvironment.transform 6 8 env11278 = env11279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11278 == env11279) = true)

def env11280 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1025,32769,4160,32,62540,21763,8192,64,121942,115014,45404,35188,75102,73771,257,95530,103431,513]

theorem envBound11280 : H12AffineFastState.Bounded env11280 := by
  intro p hp
  have h : env11280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11279_11280 : H12AffineEnvironment.transform 17 10280 env11279 = env11280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env11279 == env11280) = true)

theorem identity11280 : scanCanonicalize (H12AffineFastState.compose env11280 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound11280 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11281 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,24908,10280,1025,29789,4160,32,16,21763,8192,64,75786,79130,17664,32040,75102,73771,257,95530,90203,513]

theorem envBound11281 : H12AffineFastState.Bounded env11281 := by
  intro p hp
  have h : env11281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11280_11281 : H12AffineEnvironment.transform 14 29788 env11280 = env11281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env11280 == env11281) = true)

theorem identity11281 : scanCanonicalize (H12AffineFastState.compose env11281 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 4381) := by decide +kernel

theorem selectedBound11281 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env11282 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,4381,16384,17729,65536,20561,6453,1025,17728,4160,32,16,21763,4381,64,71959,66567,17664,19509,70723,69942,257,82999,86342,513]

theorem envBound11282 : H12AffineFastState.Bounded env11282 := by
  intro p hp
  have h : env11282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11281_11282 : H12AffineEnvironment.transform 12 4381 env11281 = env11282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4381 env11281 == env11282) = true)

theorem identity11282 : scanCanonicalize (H12AffineFastState.compose env11282 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound11282 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env11283 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,4381,16384,17729,342,20561,6453,1025,17728,4160,32,16,21763,4381,64,6209,1361,17664,19509,5397,4192,257,17761,20496,513]

theorem envBound11283 : H12AffineFastState.Bounded env11283 := by
  intro p hp
  have h : env11283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11282_11283 : H12AffineEnvironment.transform 15 342 env11282 = env11283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env11282 == env11283) = true)

theorem identity11283 : scanCanonicalize (H12AffineFastState.compose env11283 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 1344) := by decide +kernel

theorem selectedBound11283 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11284 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,4381,1344,1,342,5393,6453,1025,0,4160,32,16,4163,4381,64,6209,1361,64,2421,5397,4192,257,33,5456,513]

theorem envBound11284 : H12AffineFastState.Bounded env11284 := by
  intro p hp
  have h : env11284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11283_11284 : H12AffineEnvironment.transform 13 1344 env11283 = env11284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env11283 == env11284) = true)

theorem identity11284 : scanCanonicalize (H12AffineFastState.compose env11284 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 1361) := by decide +kernel

theorem selectedBound11284 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11285 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1361,1100,1344,1,342,64,3172,1025,0,1297,32,16,1298,1100,64,3344,1361,64,2421,68,1329,257,33,1,513]

theorem envBound11285 : H12AffineFastState.Bounded env11285 := by
  intro p hp
  have h : env11285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11284_11285 : H12AffineEnvironment.transform 11 1361 env11284 = env11285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1361 env11284 == env11285) = true)

theorem identity11285 : scanCanonicalize (H12AffineFastState.compose env11285 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound11285 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env11286 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1296,1361,1100,1344,1,342,64,372,1025,0,1297,32,16,1298,1100,64,0,1361,64,1125,68,1329,257,33,1,513]

theorem envBound11286 : H12AffineFastState.Bounded env11286 := by
  intro p hp
  have h : env11286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11285_11286 : H12AffineEnvironment.transform 10 1296 env11285 = env11286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env11285 == env11286) = true)

theorem identity11286 : scanCanonicalize (H12AffineFastState.compose env11286 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound11286 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env11287 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1124,1061,1100,1076,1,34,64,0,1025,0,1125,32,16,1126,1100,64,0,1061,64,1125,68,1093,117,33,1,513]

theorem envBound11287 : H12AffineFastState.Bounded env11287 := by
  intro p hp
  have h : env11287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11286_11287 : H12AffineEnvironment.transform 7 116 env11286 = env11287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env11286 == env11287) = true)

theorem identity11287 : scanCanonicalize (H12AffineFastState.compose env11287 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound11287 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env11288 : List Nat := [2,4,8,16,32,64,8,116,512,52,80,17,120,0,1,34,64,0,53,0,81,32,16,82,120,64,0,17,64,81,68,113,117,33,1,513]

theorem envBound11288 : H12AffineFastState.Bounded env11288 := by
  intro p hp
  have h : env11288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11287_11288 : H12AffineEnvironment.transform 9 52 env11287 = env11288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env11287 == env11288) = true)

theorem identity11288 : scanCanonicalize (H12AffineFastState.compose env11288 (packedSelected [0,2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound11288 : packedSelected [0,2,3,5] rootPS < 2^1333 := by decide +kernel

def env11289 : List Nat := [2,4,8,16,32,1,8,53,512,52,17,17,57,0,1,34,1,0,53,0,16,32,16,19,57,1,0,17,1,16,5,48,52,33,1,513]

theorem envBound11289 : H12AffineFastState.Bounded env11289 := by
  intro p hp
  have h : env11289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11288_11289 : H12AffineEnvironment.transform 5 1 env11288 = env11289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env11288 == env11289) = true)

def env11290 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1025,32769,4160,33,62540,21763,8192,64,121942,115014,45404,35189,75102,73770,257,95530,103431,513]

theorem envBound11290 : H12AffineFastState.Bounded env11290 := by
  intro p hp
  have h : env11290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11279_11290 : H12AffineEnvironment.transform 17 10281 env11279 = env11290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env11279 == env11290) = true)

theorem identity11290 : scanCanonicalize (H12AffineFastState.compose env11290 (packedSelected [1,2,3,4,5,6,8,9,11,12,14,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound11290 : packedSelected [1,2,3,4,5,6,8,9,11,12,14,18,20] rootPS < 2^1333 := by decide +kernel

def env11291 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,81,65536,5441,10281,1025,80,4160,33,29725,21763,8192,64,89095,82199,12557,2340,75102,73770,257,95530,70742,513]

theorem envBound11291 : H12AffineFastState.Bounded env11291 := by
  intro p hp
  have h : env11291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11290_11291 : H12AffineEnvironment.transform 14 81 env11290 = env11291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env11290 == env11291) = true)

theorem identity11291 : scanCanonicalize (H12AffineFastState.compose env11291 (packedSelected [1,2,3,4,5,6,8,9,12,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound11291 : packedSelected [1,2,3,4,5,6,8,9,12,14,16] rootPS < 2^1333 := by decide +kernel

def env11292 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,81,21510,5441,10281,1025,80,4160,33,29725,21763,8192,64,2049,5393,12557,2340,29016,29740,257,8492,16464,513]

theorem envBound11292 : H12AffineFastState.Bounded env11292 := by
  intro p hp
  have h : env11292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11291_11292 : H12AffineEnvironment.transform 15 21510 env11291 = env11292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env11291 == env11292) = true)

theorem identity11292 : scanCanonicalize (H12AffineFastState.compose env11292 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11292 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env11293 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,0,21510,5392,10281,1025,1,4113,33,29725,21763,8192,17,2049,5393,12557,2340,28937,29740,257,8492,16385,513]

theorem envBound11293 : H12AffineFastState.Bounded env11293 := by
  intro p hp
  have h : env11293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11292_11293 : H12AffineEnvironment.transform 5 17 env11292 = env11293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11292 == env11293) = true)

theorem identity11293 : scanCanonicalize (H12AffineFastState.compose env11293 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound11293 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env11294 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13324,0,8202,5392,10281,1025,1,4113,33,17,8463,8192,17,2049,5393,12557,2340,1285,32,257,8492,13325,513]

theorem envBound11294 : H12AffineFastState.Bounded env11294 := by
  intro p hp
  have h : env11294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11293_11294 : H12AffineEnvironment.transform 13 13324 env11293 = env11294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env11293 == env11294) = true)

theorem identity11294 : scanCanonicalize (H12AffineFastState.compose env11294 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound11294 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env11295 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1589,8192,8761,0,8202,805,10281,1025,1,1572,33,17,8463,8192,17,2049,804,10040,2340,1285,32,257,8492,8760,513]

theorem envBound11295 : H12AffineFastState.Bounded env11295 := by
  intro p hp
  have h : env11295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11294_11295 : H12AffineEnvironment.transform 11 1589 env11294 = env11295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env11294 == env11295) = true)

theorem identity11295 : scanCanonicalize (H12AffineFastState.compose env11295 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound11295 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11296 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1589,269,820,0,263,805,2340,1025,1,1572,33,17,2,269,17,2049,804,1589,2340,1285,32,257,33,821,513]

theorem envBound11296 : H12AffineFastState.Bounded env11296 := by
  intro p hp
  have h : env11296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11295_11296 : H12AffineEnvironment.transform 12 269 env11295 = env11296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env11295 == env11296) = true)

theorem identity11296 : scanCanonicalize (H12AffineFastState.compose env11296 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound11296 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11297 : List Nat := [2,4,8,16,32,17,8,20,512,1024,2048,1589,25,544,0,19,561,2096,1025,1,1572,33,17,2,25,17,2049,560,1589,2096,1041,32,21,33,545,513]

theorem envBound11297 : H12AffineFastState.Bounded env11297 := by
  intro p hp
  have h : env11297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11296_11297 : H12AffineEnvironment.transform 7 20 env11296 = env11297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env11296 == env11297) = true)

theorem identity11297 : scanCanonicalize (H12AffineFastState.compose env11297 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound11297 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11298 : List Nat := [2,4,8,16,32,17,8,20,512,1024,538,1589,25,544,0,19,561,554,1025,1,1572,33,17,2,25,17,539,560,1589,554,1041,32,21,33,545,513]

theorem envBound11298 : H12AffineFastState.Bounded env11298 := by
  intro p hp
  have h : env11298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11297_11298 : H12AffineEnvironment.transform 10 538 env11297 = env11298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env11297 == env11298) = true)

theorem identity11298 : scanCanonicalize (H12AffineFastState.compose env11298 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound11298 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11299 : List Nat := [2,4,8,16,32,17,8,20,16,1024,10,1061,25,48,0,19,33,58,1025,1,1076,33,17,2,25,17,11,32,1061,58,1041,32,21,33,49,17]

theorem envBound11299 : H12AffineFastState.Bounded env11299 := by
  intro p hp
  have h : env11299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11298_11299 : H12AffineEnvironment.transform 8 16 env11298 = env11299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env11298 == env11299) = true)

theorem identity11299 : scanCanonicalize (H12AffineFastState.compose env11299 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound11299 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env11300 : List Nat := [2,4,8,16,32,17,8,20,16,15,10,42,25,48,0,19,33,58,14,1,59,33,17,2,25,17,11,32,42,58,30,32,21,33,49,17]

theorem envBound11300 : H12AffineFastState.Bounded env11300 := by
  intro p hp
  have h : env11300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11299_11300 : H12AffineEnvironment.transform 9 15 env11299 = env11300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env11299 == env11300) = true)

theorem identity11300 : scanCanonicalize (H12AffineFastState.compose env11300 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound11300 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11301 : List Nat := [2,4,8,16,11,17,8,20,16,15,10,1,25,27,0,19,10,17,14,1,16,10,17,2,25,17,11,11,1,17,30,11,21,10,26,17]

theorem envBound11301 : H12AffineFastState.Bounded env11301 := by
  intro p hp
  have h : env11301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11300_11301 : H12AffineEnvironment.transform 4 11 env11300 = env11301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env11300 == env11301) = true)

theorem identity11301 : scanCanonicalize (H12AffineFastState.compose env11301 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound11301 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11302 : List Nat := [2,4,8,5,11,4,8,1,5,15,10,1,12,14,0,6,10,4,14,1,5,10,4,2,12,4,11,11,1,4,11,11,0,10,15,4]

theorem envBound11302 : H12AffineFastState.Bounded env11302 := by
  intro p hp
  have h : env11302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11301_11302 : H12AffineEnvironment.transform 3 5 env11301 = env11302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env11301 == env11302) = true)

theorem identity11302 : scanCanonicalize (H12AffineFastState.compose env11302 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound11302 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11303 : List Nat := [2,4,4,5,7,4,4,1,5,3,6,1,0,2,0,6,6,4,2,1,5,6,4,2,0,4,7,7,1,4,7,7,0,6,3,4]

theorem envBound11303 : H12AffineFastState.Bounded env11303 := by
  intro p hp
  have h : env11303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11302_11303 : H12AffineEnvironment.transform 2 4 env11302 = env11303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env11302 == env11303) = true)

theorem identity11303 : scanCanonicalize (H12AffineFastState.compose env11303 (packedSelected [9] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound11303 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env11304 : List Nat := [2,3,3,2,0,3,3,1,2,3,1,1,0,2,0,1,1,3,2,1,2,1,3,2,0,3,0,0,1,3,0,0,0,1,3,3]

theorem envBound11304 : H12AffineFastState.Bounded env11304 := by
  intro p hp
  have h : env11304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11303_11304 : H12AffineEnvironment.transform 1 3 env11303 = env11304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env11303 == env11304) = true)

def env11305 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4160,272393,62541,21763,8193,64,121943,115015,45405,303452,75103,329731,257,95530,103430,513]

theorem envBound11305 : H12AffineFastState.Bounded env11305 := by
  intro p hp
  have h : env11305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11278_11305 : H12AffineEnvironment.transform 6 9 env11278 = env11305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11278 == env11305) = true)

theorem identity11305 : scanCanonicalize (H12AffineFastState.compose env11305 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound11305 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env11306 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,38161,262144,1025,32769,4160,272393,62541,21763,8193,64,10588,13388,45405,303452,53332,326920,257,32801,24845,513]

theorem envBound11306 : H12AffineFastState.Bounded env11306 := by
  intro p hp
  have h : env11306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11305_11306 : H12AffineEnvironment.transform 15 62731 env11305 = env11306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env11305 == env11306) = true)

theorem identity11306 : scanCanonicalize (H12AffineFastState.compose env11306 (packedSelected [0,3,4,5,7,9,10,12,14,38] rootPS)) = affineNative (2^(14+1) ^^^ 1125) := by decide +kernel

theorem selectedBound11306 : packedSelected [0,3,4,5,7,9,10,12,14,38] rootPS < 2^1333 := by decide +kernel

def env11307 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1125,29038,4468,262144,1025,1124,4160,272393,28712,21763,8193,64,10588,13388,13624,271673,21553,293229,257,1092,24845,513]

theorem envBound11307 : H12AffineFastState.Bounded env11307 := by
  intro p hp
  have h : env11307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11306_11307 : H12AffineEnvironment.transform 14 1125 env11306 = env11307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1125 env11306 == env11307) = true)

theorem identity11307 : scanCanonicalize (H12AffineFastState.compose env11307 (packedSelected [4,8,9,10,11,14,17,20,23,28] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound11307 : packedSelected [4,8,9,10,11,14,17,20,23,28] rootPS < 2^1333 := by decide +kernel

def env11308 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,1125,8575,4468,262144,1025,1124,4160,272393,8249,1298,8193,64,10588,13388,13624,271673,1056,272764,257,1092,12572,513]

theorem envBound11308 : H12AffineFastState.Bounded env11308 := by
  intro p hp
  have h : env11308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11307_11308 : H12AffineEnvironment.transform 13 4113 env11307 = env11308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env11307 == env11308) = true)

theorem identity11308 : scanCanonicalize (H12AffineFastState.compose env11308 (packedSelected [2,6,7,14,20,23,27,32] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound11308 : packedSelected [2,6,7,14,20,23,27,32] rootPS < 2^1333 := by decide +kernel

def env11309 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,4113,1125,342,4468,262144,1025,1124,4160,264224,16,1298,40,64,2421,5221,5393,263440,1056,264533,257,1092,4405,513]

theorem envBound11309 : H12AffineFastState.Bounded env11309 := by
  intro p hp
  have h : env11309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11308_11309 : H12AffineEnvironment.transform 12 41 env11308 = env11309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env11308 == env11309) = true)

theorem identity11309 : scanCanonicalize (H12AffineFastState.compose env11309 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 3172) := by decide +kernel

theorem selectedBound11309 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11310 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,4113,1125,342,4468,3172,1025,1124,4160,1092,16,1298,40,64,2421,5221,5393,2420,1056,1329,257,1092,4405,513]

theorem envBound11310 : H12AffineFastState.Bounded env11310 := by
  intro p hp
  have h : env11310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11309_11310 : H12AffineEnvironment.transform 17 3172 env11309 = env11310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3172 env11309 == env11310) = true)

theorem identity11310 : scanCanonicalize (H12AffineFastState.compose env11310 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound11310 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11311 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,41,4113,372,342,4468,2421,272,373,4160,341,16,3,40,64,2421,4468,4096,2420,305,32,257,341,4405,513]

theorem envBound11311 : H12AffineFastState.Bounded env11311 := by
  intro p hp
  have h : env11311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11310_11311 : H12AffineEnvironment.transform 9 273 env11310 = env11311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env11310 == env11311) = true)

theorem identity11311 : scanCanonicalize (H12AffineFastState.compose env11311 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11311 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env11312 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,41,4113,293,263,4389,2340,272,292,4113,260,16,3,40,17,2340,4389,4096,2341,305,32,257,260,4405,513]

theorem envBound11312 : H12AffineFastState.Bounded env11312 := by
  intro p hp
  have h : env11312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11311_11312 : H12AffineEnvironment.transform 5 17 env11311 = env11312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11311 == env11312) = true)

theorem identity11312 : scanCanonicalize (H12AffineFastState.compose env11312 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound11312 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env11313 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,2357,41,2340,293,263,2064,2340,272,292,2340,260,16,3,40,17,2340,2064,2357,2341,305,32,257,260,2048,513]

theorem envBound11313 : H12AffineFastState.Bounded env11313 := by
  intro p hp
  have h : env11313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11312_11313 : H12AffineEnvironment.transform 11 2357 env11312 = env11313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env11312 == env11313) = true)

theorem identity11313 : scanCanonicalize (H12AffineFastState.compose env11313 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11313 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env11314 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2064,41,2049,0,34,2064,2049,53,1,2049,33,16,3,40,17,2049,2064,2064,2048,20,32,36,33,2048,513]

theorem envBound11314 : H12AffineFastState.Bounded env11314 := by
  intro p hp
  have h : env11314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11313_11314 : H12AffineEnvironment.transform 7 37 env11313 = env11314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11313 == env11314) = true)

theorem identity11314 : scanCanonicalize (H12AffineFastState.compose env11314 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound11314 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11315 : List Nat := [2,4,8,16,32,17,9,37,512,52,528,512,41,529,0,34,512,529,53,1,529,33,16,3,40,17,529,512,512,528,20,32,36,33,528,513]

theorem envBound11315 : H12AffineFastState.Bounded env11315 := by
  intro p hp
  have h : env11315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11314_11315 : H12AffineEnvironment.transform 10 528 env11314 = env11315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env11314 == env11315) = true)

theorem identity11315 : scanCanonicalize (H12AffineFastState.compose env11315 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound11315 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11316 : List Nat := [2,4,8,16,32,17,9,37,27,52,11,27,41,10,0,34,27,10,53,1,10,33,16,3,40,17,10,27,27,11,20,32,36,33,11,26]

theorem envBound11316 : H12AffineFastState.Bounded env11316 := by
  intro p hp
  have h : env11316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11315_11316 : H12AffineEnvironment.transform 8 27 env11315 = env11316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env11315 == env11316) = true)

def env11317 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441625,155996,21762,8328,64,215366,115150,140365,303452,241743,499098,257,254130,196887,169880]

theorem envBound11317 : H12AffineFastState.Bounded env11317 := by
  intro p hp
  have h : env11317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11276_11317 : H12AffineEnvironment.transform 20 4161 env11276 = env11317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env11276 == env11317) = true)

def env11318 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4161,169265,155996,21762,8328,64,215366,115150,140365,35188,241743,243122,257,254130,196887,169880]

theorem envBound11318 : H12AffineFastState.Bounded env11318 := by
  intro p hp
  have h : env11318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11317_11318 : H12AffineEnvironment.transform 17 10280 env11317 = env11318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env11317 == env11318) = true)

def env11319 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1025,32769,4161,21793,41292,21762,8328,64,100694,115150,58461,35188,94303,95650,257,73890,114951,22408]

theorem envBound11319 : H12AffineFastState.Bounded env11319 := by
  intro p hp
  have h : env11319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11318_11319 : H12AffineEnvironment.transform 16 49168 env11318 = env11319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env11318 == env11319) = true)

theorem identity11319 : scanCanonicalize (H12AffineFastState.compose env11319 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound11319 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11320 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,13389,10280,1025,29788,4161,21793,21777,21762,8328,64,97547,79251,4096,32041,94303,95650,257,73890,79194,22408]

theorem envBound11320 : H12AffineFastState.Bounded env11320 := by
  intro p hp
  have h : env11320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11319_11320 : H12AffineEnvironment.transform 14 29789 env11319 = env11320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env11319 == env11320) = true)

theorem identity11320 : scanCanonicalize (H12AffineFastState.compose env11320 (packedSelected [0,3,8,9,16,19,20,22,24,27,28] rootPS)) = affineNative (2^(12+1) ^^^ 1221) := by decide +kernel

theorem selectedBound11320 : packedSelected [0,3,8,9,16,19,20,22,24,27,28] rootPS < 2^1333 := by decide +kernel

def env11321 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1221,16384,20632,65536,4232,3309,1025,20633,4161,21793,21777,21762,1101,64,88526,69974,4096,23020,87194,86375,257,66663,70047,22408]

theorem envBound11321 : H12AffineFastState.Bounded env11321 := by
  intro p hp
  have h : env11321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11320_11321 : H12AffineEnvironment.transform 12 1221 env11320 = env11321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1221 env11320 == env11321) = true)

theorem identity11321 : scanCanonicalize (H12AffineFastState.compose env11321 (packedSelected [2,4,5,6,18,20,22,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 20759) := by decide +kernel

theorem selectedBound11321 : packedSelected [2,4,5,6,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env11322 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1221,16384,20632,20759,4232,3309,1025,20633,4161,21793,21777,21762,1101,64,2265,16449,4096,23020,1421,112,257,21872,16520,22408]

theorem envBound11322 : H12AffineFastState.Bounded env11322 := by
  intro p hp
  have h : env11322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11321_11322 : H12AffineEnvironment.transform 15 20759 env11321 = env11322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20759 env11321 == env11322) = true)

theorem identity11322 : scanCanonicalize (H12AffineFastState.compose env11322 (packedSelected [11,16,18,20] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound11322 : packedSelected [11,16,18,20] rootPS < 2^1333 := by decide +kernel

def env11323 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,1221,16384,20632,20579,4232,3309,1025,20633,4161,21589,21605,21622,1101,64,2265,16449,4096,22680,1273,112,117,21508,16520,22268]

theorem envBound11323 : H12AffineFastState.Bounded env11323 := by
  intro p hp
  have h : env11323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11322_11323 : H12AffineEnvironment.transform 7 116 env11322 = env11323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env11322 == env11323) = true)

theorem identity11323 : scanCanonicalize (H12AffineFastState.compose env11323 (packedSelected [1,3,5,8,11,14,16,18] rootPS)) = affineNative (2^(11+1) ^^^ 2249) := by decide +kernel

theorem selectedBound11323 : packedSelected [1,3,5,8,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env11324 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,2249,1221,16384,18513,18602,2113,3309,1025,18512,2184,19612,19628,19647,1101,64,2265,16449,2249,16465,1273,112,117,19661,16520,20021]

theorem envBound11324 : H12AffineFastState.Bounded env11324 := by
  intro p hp
  have h : env11324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11323_11324 : H12AffineEnvironment.transform 11 2249 env11323 = env11324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2249 env11323 == env11324) = true)

theorem identity11324 : scanCanonicalize (H12AffineFastState.compose env11324 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound11324 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env11325 : List Nat := [2,4,8,16,32,64,128,116,512,1024,0,201,1221,16384,16465,16554,65,1261,1025,16464,136,17564,17580,17599,1101,64,217,16449,201,16465,1273,112,117,17613,16520,17973]

theorem envBound11325 : H12AffineFastState.Bounded env11325 := by
  intro p hp
  have h : env11325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11324_11325 : H12AffineEnvironment.transform 10 0 env11324 = env11325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env11324 == env11325) = true)

theorem identity11325 : scanCanonicalize (H12AffineFastState.compose env11325 (packedSelected [0,3,5,7,10,11,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 80) := by decide +kernel

theorem selectedBound11325 : packedSelected [0,3,5,7,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env11326 : List Nat := [2,4,8,16,32,64,128,116,512,1024,0,201,1221,80,1,250,65,1261,1025,0,136,1228,1276,1263,1101,64,217,17,201,1,1273,112,117,1181,216,1637]

theorem envBound11326 : H12AffineFastState.Bounded env11326 := by
  intro p hp
  have h : env11326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11325_11326 : H12AffineEnvironment.transform 13 80 env11325 = env11326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 80 env11325 == env11326) = true)

theorem identity11326 : scanCanonicalize (H12AffineFastState.compose env11326 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound11326 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11327 : List Nat := [2,4,8,16,32,64,128,116,512,188,0,201,121,80,1,250,65,81,189,0,136,112,64,83,241,64,217,17,201,1,69,112,117,33,216,729]

theorem envBound11327 : H12AffineFastState.Bounded env11327 := by
  intro p hp
  have h : env11327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11326_11327 : H12AffineEnvironment.transform 9 188 env11326 = env11327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env11326 == env11327) = true)

theorem identity11327 : scanCanonicalize (H12AffineFastState.compose env11327 (packedSelected [1,2,3,5,6,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound11327 : packedSelected [1,2,3,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env11328 : List Nat := [2,4,8,16,32,64,88,116,512,100,0,17,121,80,1,34,65,81,101,0,80,112,64,83,41,64,1,17,17,1,69,112,117,33,0,513]

theorem envBound11328 : H12AffineFastState.Bounded env11328 := by
  intro p hp
  have h : env11328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11327_11328 : H12AffineEnvironment.transform 6 88 env11327 = env11328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env11327 == env11328) = true)

def env11329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1025,32769,4161,21792,41293,21762,8328,64,100695,115150,58460,35188,94302,95651,257,73891,114950,22409]

theorem envBound11329 : H12AffineFastState.Bounded env11329 := by
  intro p hp
  have h : env11329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11318_11329 : H12AffineEnvironment.transform 16 49169 env11318 = env11329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env11318 == env11329) = true)

theorem identity11329 : scanCanonicalize (H12AffineFastState.compose env11329 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound11329 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11330 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,13508,10280,1025,29908,4161,21792,21912,21762,8328,64,97666,79131,4233,32161,94302,95651,257,73891,79315,22409]

theorem envBound11330 : H12AffineFastState.Bounded env11330 := by
  intro p hp
  have h : env11330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11329_11330 : H12AffineEnvironment.transform 14 29909 env11329 = env11330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env11329 == env11330) = true)

theorem identity11330 : scanCanonicalize (H12AffineFastState.compose env11330 (packedSelected [0,1,4,7,8,16,19,20,22] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound11330 : packedSelected [0,1,4,7,8,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env11331 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,8192,16384,29004,65536,12637,10280,408,29005,4161,20665,20481,20635,8328,64,96283,77954,4233,30776,94302,94266,257,73891,77898,21008]

theorem envBound11331 : H12AffineFastState.Bounded env11331 := by
  intro p hp
  have h : env11331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11330_11331 : H12AffineEnvironment.transform 9 409 env11330 = env11331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env11330 == env11331) = true)

theorem identity11331 : scanCanonicalize (H12AffineFastState.compose env11331 (packedSelected [5,19,24] rootPS)) = affineNative (2^(15+1) ^^^ 8403) := by decide +kernel

theorem selectedBound11331 : packedSelected [5,19,24] rootPS < 2^1333 := by decide +kernel

def env11332 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,8192,16384,29004,8403,12637,10280,408,29005,4161,20665,20481,20635,8328,64,22728,4177,4233,30776,20621,20713,257,112,4249,21008]

theorem envBound11332 : H12AffineFastState.Bounded env11332 := by
  intro p hp
  have h : env11332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11331_11332 : H12AffineEnvironment.transform 15 8403 env11331 = env11332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8403 env11331 == env11332) = true)

theorem identity11332 : scanCanonicalize (H12AffineFastState.compose env11332 (packedSelected [0,2,6,7,16,18,23] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound11332 : packedSelected [0,2,6,7,16,18,23] rootPS < 2^1333 := by decide +kernel

def env11333 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,16384,29004,8282,12637,10280,273,29005,4161,20528,20481,20498,8193,64,22593,4177,4096,30776,20484,20576,257,112,4112,21008]

theorem envBound11333 : H12AffineFastState.Bounded env11333 := by
  intro p hp
  have h : env11333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11332_11333 : H12AffineEnvironment.transform 6 9 env11332 = env11333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11332 == env11333) = true)

theorem identity11333 : scanCanonicalize (H12AffineFastState.compose env11333 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 4452) := by decide +kernel

theorem selectedBound11333 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env11334 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,4452,8232,8282,12637,10280,273,8233,4161,340,357,374,8193,64,2341,4177,4096,10588,352,260,257,112,4112,884]

theorem envBound11334 : H12AffineFastState.Bounded env11334 := by
  intro p hp
  have h : env11334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11333_11334 : H12AffineEnvironment.transform 13 4452 env11333 = env11334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4452 env11333 == env11334) = true)

theorem identity11334 : scanCanonicalize (H12AffineFastState.compose env11334 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound11334 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env11335 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,268,4452,292,342,4177,2340,273,293,4161,340,357,374,269,64,2341,4177,4096,2128,352,260,257,112,4112,884]

theorem envBound11335 : H12AffineFastState.Bounded env11335 := by
  intro p hp
  have h : env11335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11334_11335 : H12AffineEnvironment.transform 12 268 env11334 = env11335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env11334 == env11335) = true)

theorem identity11335 : scanCanonicalize (H12AffineFastState.compose env11335 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11335 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env11336 : List Nat := [2,4,8,16,32,64,9,36,512,52,2048,4096,40,4160,0,114,4177,2048,53,1,4161,112,65,82,41,64,2049,4177,4096,2128,68,32,37,112,4112,592]

theorem envBound11336 : H12AffineFastState.Bounded env11336 := by
  intro p hp
  have h : env11336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11335_11336 : H12AffineEnvironment.transform 7 36 env11335 = env11336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11335 == env11336) = true)

theorem identity11336 : scanCanonicalize (H12AffineFastState.compose env11336 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound11336 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env11337 : List Nat := [2,4,8,16,32,64,9,36,512,52,2048,2064,40,2128,0,114,2113,2048,53,1,2129,112,65,82,41,64,2049,2113,2064,2128,68,32,37,112,2048,592]

theorem envBound11337 : H12AffineFastState.Bounded env11337 := by
  intro p hp
  have h : env11337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11336_11337 : H12AffineEnvironment.transform 11 2064 env11336 = env11337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env11336 == env11337) = true)

theorem identity11337 : scanCanonicalize (H12AffineFastState.compose env11337 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11337 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env11338 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,2064,40,2049,0,35,2064,2048,53,1,2048,33,16,3,41,17,2049,2064,2064,2049,21,32,37,33,2048,513]

theorem envBound11338 : H12AffineFastState.Bounded env11338 := by
  intro p hp
  have h : env11338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11337_11338 : H12AffineEnvironment.transform 5 17 env11337 = env11338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11337 == env11338) = true)

def env11339 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4161,169264,155996,21762,8328,64,215366,115150,140365,35189,241743,243123,257,254130,196887,169880]

theorem envBound11339 : H12AffineFastState.Bounded env11339 := by
  intro p hp
  have h : env11339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11317_11339 : H12AffineEnvironment.transform 17 10281 env11317 = env11339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env11317 == env11339) = true)

def env11340 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1025,32769,4161,21792,41292,21762,8328,64,100694,115150,58461,35189,94303,95651,257,73890,114951,22408]

theorem envBound11340 : H12AffineFastState.Bounded env11340 := by
  intro p hp
  have h : env11340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11339_11340 : H12AffineEnvironment.transform 16 49168 env11339 = env11340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env11339 == env11340) = true)

theorem identity11340 : scanCanonicalize (H12AffineFastState.compose env11340 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound11340 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11341 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,38161,10281,1025,32769,4161,33,41292,3,8328,64,100694,103631,45404,35189,75102,73890,257,73890,103430,649]

theorem envBound11341 : H12AffineFastState.Bounded env11341 := by
  intro p hp
  have h : env11341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11340_11341 : H12AffineEnvironment.transform 13 5377 env11340 = env11341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env11340 == env11341) = true)

theorem identity11341 : scanCanonicalize (H12AffineFastState.compose env11341 (packedSelected [0,1,3,4,5,7,8,9,12,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound11341 : packedSelected [0,1,3,4,5,7,8,9,12,18,20] rootPS < 2^1333 := by decide +kernel

def env11342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,80,65536,5441,10281,1025,81,4161,33,8476,3,8328,64,67846,70815,12556,2341,75102,73890,257,73890,70742,649]

theorem envBound11342 : H12AffineFastState.Bounded env11342 := by
  intro p hp
  have h : env11342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11341_11342 : H12AffineEnvironment.transform 14 80 env11341 = env11342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env11341 == env11342) = true)

theorem identity11342 : scanCanonicalize (H12AffineFastState.compose env11342 (packedSelected [0,3,4,5,7,9,10,11,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound11342 : packedSelected [0,3,4,5,7,9,10,11,16] rootPS < 2^1333 := by decide +kernel

def env11343 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,80,8203,5441,10281,1025,81,4161,33,8476,3,8328,64,10509,13460,12556,2341,1365,169,257,169,13405,649]

theorem envBound11343 : H12AffineFastState.Bounded env11343 := by
  intro p hp
  have h : env11343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11342_11343 : H12AffineEnvironment.transform 15 8203 env11342 = env11343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env11342 == env11343) = true)

theorem identity11343 : scanCanonicalize (H12AffineFastState.compose env11343 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound11343 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env11344 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5377,80,262,5441,2340,1025,81,4161,33,17,3,389,64,2048,5529,4097,2341,1365,169,257,169,5456,649]

theorem envBound11344 : H12AffineFastState.Bounded env11344 := by
  intro p hp
  have h : env11344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11343_11344 : H12AffineEnvironment.transform 12 269 env11343 = env11344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env11343 == env11344) = true)

theorem identity11344 : scanCanonicalize (H12AffineFastState.compose env11344 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound11344 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env11345 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,120,5236,80,115,5172,2129,1025,81,4161,33,17,3,240,64,2048,5356,4097,2128,1056,169,116,169,5157,649]

theorem envBound11345 : H12AffineFastState.Bounded env11345 := by
  intro p hp
  have h : env11345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11344_11345 : H12AffineEnvironment.transform 7 117 env11344 = env11345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env11344 == env11345) = true)

theorem identity11345 : scanCanonicalize (H12AffineFastState.compose env11345 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound11345 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env11346 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5236,80,115,5172,2129,1025,81,4161,33,17,3,121,64,2048,5221,4097,2128,1056,32,116,32,5157,512]

theorem envBound11346 : H12AffineFastState.Bounded env11346 := by
  intro p hp
  have h : env11346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11345_11346 : H12AffineEnvironment.transform 6 9 env11345 = env11346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11345 == env11346) = true)

theorem identity11346 : scanCanonicalize (H12AffineFastState.compose env11346 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3605) := by decide +kernel

theorem selectedBound11346 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env11347 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,3605,120,2657,80,115,2593,2129,1025,81,3668,33,17,3,121,64,2048,2672,3604,2128,1056,32,116,32,2608,512]

theorem envBound11347 : H12AffineFastState.Bounded env11347 := by
  intro p hp
  have h : env11347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11346_11347 : H12AffineEnvironment.transform 11 3605 env11346 = env11347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3605 env11346 == env11347) = true)

theorem identity11347 : scanCanonicalize (H12AffineFastState.compose env11347 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11347 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11348 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,3605,89,2624,80,82,2560,2129,1025,81,3668,0,17,3,88,64,2048,2641,3604,2128,1025,1,85,1,2577,512]

theorem envBound11348 : H12AffineFastState.Bounded env11348 := by
  intro p hp
  have h : env11348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11347_11348 : H12AffineEnvironment.transform 4 1 env11347 = env11348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11347 == env11348) = true)

theorem identity11348 : scanCanonicalize (H12AffineFastState.compose env11348 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound11348 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11349 : List Nat := [2,4,8,16,1,64,9,84,512,1024,65,1620,89,513,80,82,577,16,1025,81,1557,0,17,3,88,64,65,528,1621,17,1025,1,85,1,592,512]

theorem envBound11349 : H12AffineFastState.Bounded env11349 := by
  intro p hp
  have h : env11349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11348_11349 : H12AffineEnvironment.transform 10 65 env11348 = env11349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env11348 == env11349) = true)

theorem identity11349 : scanCanonicalize (H12AffineFastState.compose env11349 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 581) := by decide +kernel

theorem selectedBound11349 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env11350 : List Nat := [2,4,8,16,1,64,9,84,512,581,65,17,89,513,80,82,577,16,580,81,80,0,17,3,88,64,65,528,16,17,580,1,85,1,592,512]

theorem envBound11350 : H12AffineFastState.Bounded env11350 := by
  intro p hp
  have h : env11350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11349_11350 : H12AffineEnvironment.transform 9 581 env11349 = env11350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 581 env11349 == env11350) = true)

theorem identity11350 : scanCanonicalize (H12AffineFastState.compose env11350 (packedSelected [2,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11350 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env11351 : List Nat := [2,4,8,16,1,16,9,4,512,533,17,17,9,513,0,2,529,16,532,1,0,0,17,3,8,16,17,528,16,17,532,1,5,1,512,512]

theorem envBound11351 : H12AffineFastState.Bounded env11351 := by
  intro p hp
  have h : env11351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11350_11351 : H12AffineEnvironment.transform 5 16 env11350 = env11351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11350 == env11351) = true)

theorem identity11351 : scanCanonicalize (H12AffineFastState.compose env11351 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound11351 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11352 : List Nat := [2,4,8,16,1,16,9,4,0,21,17,17,9,1,0,2,17,16,20,1,0,0,17,3,8,16,17,16,16,17,20,1,5,1,0,0]

theorem envBound11352 : H12AffineFastState.Bounded env11352 := by
  intro p hp
  have h : env11352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11351_11352 : H12AffineEnvironment.transform 8 0 env11351 = env11352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env11351 == env11352) = true)

theorem identity11352 : scanCanonicalize (H12AffineFastState.compose env11352 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound11352 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11353 : List Nat := [2,4,8,5,1,5,9,4,0,0,4,4,9,1,0,2,4,5,1,1,0,0,4,3,8,5,4,5,5,4,1,1,5,1,0,0]

theorem envBound11353 : H12AffineFastState.Bounded env11353 := by
  intro p hp
  have h : env11353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11352_11353 : H12AffineEnvironment.transform 3 5 env11352 = env11353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env11352 == env11353) = true)

theorem identity11353 : scanCanonicalize (H12AffineFastState.compose env11353 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound11353 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11354 : List Nat := [2,0,8,1,1,1,9,0,0,0,0,0,9,1,0,2,0,1,1,1,0,0,0,3,8,1,0,1,1,0,1,1,1,1,0,0]

theorem envBound11354 : H12AffineFastState.Bounded env11354 := by
  intro p hp
  have h : env11354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11353_11354 : H12AffineEnvironment.transform 1 0 env11353 = env11354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env11353 == env11354) = true)

def env11355 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1025,32769,4161,21793,41293,21762,8328,64,100695,115150,58460,35189,94302,95650,257,73891,114950,22409]

theorem envBound11355 : H12AffineFastState.Bounded env11355 := by
  intro p hp
  have h : env11355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11339_11355 : H12AffineEnvironment.transform 16 49169 env11339 = env11355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env11339 == env11355) = true)

theorem identity11355 : scanCanonicalize (H12AffineFastState.compose env11355 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound11355 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11356 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,38297,10281,1025,32769,4161,169,41293,138,8328,64,100695,103494,45524,35189,75222,73770,257,73891,103566,513]

theorem envBound11356 : H12AffineFastState.Bounded env11356 := by
  intro p hp
  have h : env11356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11355_11356 : H12AffineEnvironment.transform 13 5512 env11355 = env11356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env11355 == env11356) = true)

theorem identity11356 : scanCanonicalize (H12AffineFastState.compose env11356 (packedSelected [0,1,7,8,9,14,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound11356 : packedSelected [0,1,7,8,9,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env11357 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33111,38297,10281,1025,32769,4161,169,41293,138,8328,64,2048,5393,45524,35189,42113,41341,257,41460,5593,513]

theorem envBound11357 : H12AffineFastState.Bounded env11357 := by
  intro p hp
  have h : env11357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11356_11357 : H12AffineEnvironment.transform 15 33111 env11356 = env11357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env11356 == env11357) = true)

theorem identity11357 : scanCanonicalize (H12AffineFastState.compose env11357 (packedSelected [2,3,4,5,6,9,10,14,20] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound11357 : packedSelected [2,3,4,5,6,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env11358 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,5456,32768,33111,38209,10281,1025,32769,4161,113,41293,82,8272,64,2048,5393,45324,35189,42073,41341,257,41260,5377,513]

theorem envBound11358 : H12AffineFastState.Bounded env11358 := by
  intro p hp
  have h : env11358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11357_11358 : H12AffineEnvironment.transform 6 88 env11357 = env11358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env11357 == env11358) = true)

theorem identity11358 : scanCanonicalize (H12AffineFastState.compose env11358 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound11358 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env11359 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,268,5456,32768,33111,38209,2341,1025,32769,4161,113,32833,82,348,64,2048,5393,36864,35189,34133,32881,257,32800,5377,513]

theorem envBound11359 : H12AffineFastState.Bounded env11359 := by
  intro p hp
  have h : env11359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11358_11359 : H12AffineEnvironment.transform 12 268 env11358 = env11359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env11358 == env11359) = true)

theorem identity11359 : scanCanonicalize (H12AffineFastState.compose env11359 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11359 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11360 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,32768,33030,38160,2341,1025,32769,4112,32,32784,3,269,17,2048,5393,36864,35108,34052,32800,257,32800,5377,513]

theorem envBound11360 : H12AffineFastState.Bounded env11360 := by
  intro p hp
  have h : env11360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11359_11360 : H12AffineEnvironment.transform 5 17 env11359 = env11360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11359 == env11360) = true)

theorem identity11360 : scanCanonicalize (H12AffineFastState.compose env11360 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 3647) := by decide +kernel

theorem selectedBound11360 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env11361 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,3647,3897,6959,2341,1025,3646,4112,32,3631,3,269,17,2048,5393,7743,1819,2875,3615,257,3615,5377,513]

theorem envBound11361 : H12AffineFastState.Bounded env11361 := by
  intro p hp
  have h : env11361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11360_11361 : H12AffineEnvironment.transform 14 3647 env11360 = env11361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3647 env11360 == env11361) = true)

def env11362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2534745,155996,2114883,8328,64,215367,115150,2241548,303452,2334734,2592218,257,254130,196887,2263001]

theorem envBound11362 : H12AffineFastState.Bounded env11362 := by
  intro p hp
  have h : env11362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11275_11362 : H12AffineEnvironment.transform 21 2534745 env11275 = env11362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2534745 env11275 == env11362) = true)

def env11363 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441625,155996,21763,8328,64,215367,115150,140364,303452,241742,499098,257,254130,196887,169881]

theorem envBound11363 : H12AffineFastState.Bounded env11363 := by
  intro p hp
  have h : env11363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11362_11363 : H12AffineEnvironment.transform 20 4160 env11362 = env11363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env11362 == env11363) = true)

theorem identity11363 : scanCanonicalize (H12AffineFastState.compose env11363 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound11363 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11364 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,4160,412108,155996,21763,8328,64,215367,79131,140364,284041,214171,485711,257,201831,196887,156492]

theorem envBound11364 : H12AffineFastState.Bounded env11364 := by
  intro p hp
  have h : env11364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11363_11364 : H12AffineEnvironment.transform 14 29909 env11363 = env11364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env11363 == env11364) = true)

def env11365 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,4160,411972,155996,21763,8192,64,215367,79131,140364,283905,214035,485711,257,201831,196887,156492]

theorem envBound11365 : H12AffineFastState.Bounded env11365 := by
  intro p hp
  have h : env11365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11364_11365 : H12AffineEnvironment.transform 6 8 env11364 = env11365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11364 == env11365) = true)

theorem identity11365 : scanCanonicalize (H12AffineFastState.compose env11365 (packedSelected [16,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound11365 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env11366 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,29963,131072,262144,1025,29788,4160,411972,155996,21763,8192,64,146508,16400,140364,283905,143640,400452,257,156012,160796,156492]

theorem envBound11366 : H12AffineFastState.Bounded env11366 := by
  intro p hp
  have h : env11366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11365_11366 : H12AffineEnvironment.transform 15 29963 env11365 = env11366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env11365 == env11366) = true)

theorem identity11366 : scanCanonicalize (H12AffineFastState.compose env11366 (packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 149860) := by decide +kernel

theorem selectedBound11366 : packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env11367 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,29963,131072,149860,1025,29788,4160,32,155996,21763,8192,64,146508,16400,140364,138341,143640,21792,257,156012,160796,156492]

theorem envBound11367 : H12AffineFastState.Bounded env11367 := by
  intro p hp
  have h : env11367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11366_11367 : H12AffineEnvironment.transform 17 149860 env11366 = env11367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149860 env11366 == env11367) = true)

theorem identity11367 : scanCanonicalize (H12AffineFastState.compose env11367 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11367 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env11368 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29708,29963,131072,149813,1025,29709,4113,32,155917,21763,8192,17,146461,16400,140317,138292,143640,21792,257,155965,160796,156445]

theorem envBound11368 : H12AffineFastState.Bounded env11368 := by
  intro p hp
  have h : env11368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11367_11368 : H12AffineEnvironment.transform 5 17 env11367 = env11368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11367 == env11368) = true)

theorem identity11368 : scanCanonicalize (H12AffineFastState.compose env11368 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound11368 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env11369 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8460,8203,131072,138293,1025,8461,4113,32,144397,3,8192,17,146461,5392,140317,138292,143640,32,257,144445,139548,144925]

theorem envBound11369 : H12AffineFastState.Bounded env11369 := by
  intro p hp
  have h : env11369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11368_11369 : H12AffineEnvironment.transform 13 5376 env11368 = env11369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env11368 == env11369) = true)

theorem identity11369 : scanCanonicalize (H12AffineFastState.compose env11369 (packedSelected [0,2,3,5,7,10,12] rootPS)) = affineNative (2^(16+1) ^^^ 12297) := by decide +kernel

theorem selectedBound11369 : packedSelected [0,2,3,5,7,10,12] rootPS < 2^1333 := by decide +kernel

def env11370 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8460,8203,12297,11324,1025,8461,4113,32,1028,3,8192,17,3092,5392,5140,11325,273,32,257,1076,4373,1556]

theorem envBound11370 : H12AffineFastState.Bounded env11370 := by
  intro p hp
  have h : env11370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11369_11370 : H12AffineEnvironment.transform 16 12297 env11369 = env11370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12297 env11369 == env11370) = true)

theorem identity11370 : scanCanonicalize (H12AffineFastState.compose env11370 (packedSelected [3,4,5,6,9,10,16] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound11370 : packedSelected [3,4,5,6,9,10,16] rootPS < 2^1333 := by decide +kernel

def env11371 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,300,5376,32,295,4389,3344,1025,33,4113,32,1028,3,300,17,3092,5392,5140,3345,273,32,257,1076,4373,1556]

theorem envBound11371 : H12AffineFastState.Bounded env11371 := by
  intro p hp
  have h : env11371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11370_11371 : H12AffineEnvironment.transform 12 300 env11370 = env11371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env11370 == env11371) = true)

theorem identity11371 : scanCanonicalize (H12AffineFastState.compose env11371 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11371 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11372 : List Nat := [2,4,8,16,1,17,8,256,512,1024,2048,4096,269,5376,1,262,4356,3344,1025,0,4113,1,1028,3,269,17,3092,5392,5140,3345,273,1,257,1045,4373,1556]

theorem envBound11372 : H12AffineFastState.Bounded env11372 := by
  intro p hp
  have h : env11372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11371_11372 : H12AffineEnvironment.transform 4 1 env11371 = env11372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11371 == env11372) = true)

theorem identity11372 : scanCanonicalize (H12AffineFastState.compose env11372 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound11372 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env11373 : List Nat := [2,4,8,16,1,17,8,256,512,1024,2048,2064,269,3344,1,262,2324,3344,1025,0,2049,1,1028,3,269,17,3092,3328,3076,3345,273,1,257,1045,2309,1556]

theorem envBound11373 : H12AffineFastState.Bounded env11373 := by
  intro p hp
  have h : env11373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11372_11373 : H12AffineEnvironment.transform 11 2064 env11372 = env11373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env11372 == env11373) = true)

theorem identity11373 : scanCanonicalize (H12AffineFastState.compose env11373 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound11373 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env11374 : List Nat := [2,4,8,16,1,17,8,256,512,1024,1044,1028,269,260,1,262,1280,260,1025,0,1045,1,1028,3,269,17,0,276,16,261,273,1,257,1045,1297,1556]

theorem envBound11374 : H12AffineFastState.Bounded env11374 := by
  intro p hp
  have h : env11374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11373_11374 : H12AffineEnvironment.transform 10 1044 env11373 = env11374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env11373 == env11374) = true)

theorem identity11374 : scanCanonicalize (H12AffineFastState.compose env11374 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound11374 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env11375 : List Nat := [2,4,8,16,1,17,8,256,512,21,1,17,269,260,1,262,277,260,20,0,0,1,17,3,269,17,0,276,16,261,273,1,257,0,260,513]

theorem envBound11375 : H12AffineFastState.Bounded env11375 := by
  intro p hp
  have h : env11375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11374_11375 : H12AffineEnvironment.transform 9 21 env11374 = env11375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env11374 == env11375) = true)

theorem identity11375 : scanCanonicalize (H12AffineFastState.compose env11375 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound11375 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11376 : List Nat := [2,4,8,0,1,1,8,256,512,5,1,1,269,260,1,262,261,260,4,0,0,1,1,3,269,1,0,260,0,261,257,1,257,0,260,513]

theorem envBound11376 : H12AffineFastState.Bounded env11376 := by
  intro p hp
  have h : env11376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11375_11376 : H12AffineEnvironment.transform 3 0 env11375 = env11376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env11375 == env11376) = true)

theorem identity11376 : scanCanonicalize (H12AffineFastState.compose env11376 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound11376 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11377 : List Nat := [2,4,8,0,1,1,8,256,261,5,1,1,269,260,1,262,261,260,4,0,0,1,1,3,269,1,0,260,0,261,257,1,257,0,260,260]

theorem envBound11377 : H12AffineFastState.Bounded env11377 := by
  intro p hp
  have h : env11377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11376_11377 : H12AffineEnvironment.transform 8 261 env11376 = env11377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env11376 == env11377) = true)

def env11378 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,4160,411973,155996,21763,8193,64,215367,79131,140364,283904,214034,485711,257,201831,196887,156492]

theorem envBound11378 : H12AffineFastState.Bounded env11378 := by
  intro p hp
  have h : env11378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11364_11378 : H12AffineEnvironment.transform 6 9 env11364 = env11378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11364 == env11378) = true)

def env11379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441624,155996,21762,8328,64,215367,115150,140365,303452,241743,499099,257,254130,196887,169880]

theorem envBound11379 : H12AffineFastState.Bounded env11379 := by
  intro p hp
  have h : env11379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11362_11379 : H12AffineEnvironment.transform 20 4161 env11362 = env11379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env11362 == env11379) = true)

theorem identity11379 : scanCanonicalize (H12AffineFastState.compose env11379 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound11379 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11380 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4161,318549,17,21762,8328,64,75786,115150,17664,303452,119042,392406,257,98815,90202,63189]

theorem envBound11380 : H12AffineFastState.Bounded env11380 := by
  intro p hp
  have h : env11380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11379_11380 : H12AffineEnvironment.transform 16 24909 env11379 = env11380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env11379 == env11380) = true)

def env11381 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4161,318549,17,21762,8192,64,75786,115014,17664,303452,119042,392286,257,98679,90202,63069]

theorem envBound11381 : H12AffineFastState.Bounded env11381 := by
  intro p hp
  have h : env11381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11380_11381 : H12AffineEnvironment.transform 6 8 env11380 = env11381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11380 == env11381) = true)

theorem identity11381 : scanCanonicalize (H12AffineFastState.compose env11381 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound11381 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11382 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,56437,1025,32769,4161,32,17,21762,8192,64,75786,115014,17664,32041,119042,73771,257,98679,90202,63069]

theorem envBound11382 : H12AffineFastState.Bounded env11382 := by
  intro p hp
  have h : env11382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11381_11382 : H12AffineEnvironment.transform 17 56437 env11381 = env11382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env11381 == env11382) = true)

theorem identity11382 : scanCanonicalize (H12AffineFastState.compose env11382 (packedSelected [0,3,7,11,12,14,16,20,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11382 : packedSelected [0,3,7,11,12,14,16,20,24] rootPS < 2^1333 := by decide +kernel

def env11383 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24861,56357,1025,32769,4113,32,17,21762,8192,16,75786,114966,17664,32041,119042,73771,257,98599,90122,62989]

theorem envBound11383 : H12AffineFastState.Bounded env11383 := by
  intro p hp
  have h : env11383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11382_11383 : H12AffineEnvironment.transform 5 16 env11382 = env11383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11382 == env11383) = true)

theorem identity11383 : scanCanonicalize (H12AffineFastState.compose env11383 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound11383 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env11384 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,21761,65536,24861,2340,1025,21760,4113,32,17,21762,8192,16,75786,70679,17664,32041,66563,73771,257,87078,90122,8972]

theorem envBound11384 : H12AffineFastState.Bounded env11384 := by
  intro p hp
  have h : env11384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11383_11384 : H12AffineEnvironment.transform 14 21761 env11383 = env11384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env11383 == env11384) = true)

theorem identity11384 : scanCanonicalize (H12AffineFastState.compose env11384 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound11384 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env11385 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,21761,29963,24861,2340,1025,21760,4113,32,17,21762,8192,16,23809,24860,17664,32041,28936,21792,257,8493,5377,8972]

theorem envBound11385 : H12AffineFastState.Bounded env11385 := by
  intro p hp
  have h : env11385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11384_11385 : H12AffineEnvironment.transform 15 29963 env11384 = env11385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env11384 == env11385) = true)

theorem identity11385 : scanCanonicalize (H12AffineFastState.compose env11385 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound11385 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env11386 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,8461,263,5393,2340,1025,8460,4113,32,17,8462,8192,16,10509,5392,12556,2341,1284,8492,257,8493,5377,8972]

theorem envBound11386 : H12AffineFastState.Bounded env11386 := by
  intro p hp
  have h : env11386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11385_11386 : H12AffineEnvironment.transform 13 13324 env11385 = env11386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env11385 == env11386) = true)

theorem identity11386 : scanCanonicalize (H12AffineFastState.compose env11386 (packedSelected [4,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound11386 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env11387 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,4096,8192,12345,8461,263,4388,2340,52,8460,4113,32,17,8462,8192,16,10509,4389,12556,2341,305,8492,257,8493,4404,8972]

theorem envBound11387 : H12AffineFastState.Bounded env11387 := by
  intro p hp
  have h : env11387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11386_11387 : H12AffineEnvironment.transform 9 53 env11386 = env11387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env11386 == env11387) = true)

theorem identity11387 : scanCanonicalize (H12AffineFastState.compose env11387 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound11387 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env11388 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,4096,41,4112,292,263,4388,2340,52,293,4113,32,17,295,41,16,2340,4389,4389,2341,305,261,257,260,4404,805]

theorem envBound11388 : H12AffineFastState.Bounded env11388 := by
  intro p hp
  have h : env11388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11387_11388 : H12AffineEnvironment.transform 12 41 env11387 = env11388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env11387 == env11388) = true)

theorem identity11388 : scanCanonicalize (H12AffineFastState.compose env11388 (packedSelected [1,2,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11388 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env11389 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,4096,41,4112,0,35,4096,2048,52,1,4113,32,17,3,41,16,2048,4097,4097,2049,21,33,37,32,4112,513]

theorem envBound11389 : H12AffineFastState.Bounded env11389 := by
  intro p hp
  have h : env11389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11388_11389 : H12AffineEnvironment.transform 7 36 env11388 = env11389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11388 == env11389) = true)

theorem identity11389 : scanCanonicalize (H12AffineFastState.compose env11389 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound11389 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11390 : List Nat := [2,4,8,16,17,16,8,21,512,4,2048,4096,24,4112,0,18,4096,2048,5,1,4113,17,17,3,24,16,2048,4097,4097,2049,21,16,20,17,4112,513]

theorem envBound11390 : H12AffineFastState.Bounded env11390 := by
  intro p hp
  have h : env11390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11389_11390 : H12AffineEnvironment.transform 4 17 env11389 = env11390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env11389 == env11390) = true)

theorem identity11390 : scanCanonicalize (H12AffineFastState.compose env11390 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound11390 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11391 : List Nat := [2,4,8,16,17,16,8,21,512,4,512,4096,24,4112,0,18,4096,512,5,1,4113,17,17,3,24,16,512,4097,4097,513,21,16,20,17,4112,513]

theorem envBound11391 : H12AffineFastState.Bounded env11391 := by
  intro p hp
  have h : env11391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11390_11391 : H12AffineEnvironment.transform 10 512 env11390 = env11391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env11390 == env11391) = true)

theorem identity11391 : scanCanonicalize (H12AffineFastState.compose env11391 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound11391 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11392 : List Nat := [2,4,8,16,17,16,8,21,512,4,512,16,24,0,0,18,16,512,5,1,1,17,17,3,24,16,512,17,17,513,21,16,20,17,0,513]

theorem envBound11392 : H12AffineFastState.Bounded env11392 := by
  intro p hp
  have h : env11392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11391_11392 : H12AffineEnvironment.transform 11 16 env11391 = env11392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env11391 == env11392) = true)

theorem identity11392 : scanCanonicalize (H12AffineFastState.compose env11392 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound11392 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env11393 : List Nat := [2,4,8,16,17,16,8,21,0,4,0,16,24,0,0,18,16,0,5,1,1,17,17,3,24,16,0,17,17,1,21,16,20,17,0,1]

theorem envBound11393 : H12AffineFastState.Bounded env11393 := by
  intro p hp
  have h : env11393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11392_11393 : H12AffineEnvironment.transform 8 0 env11392 = env11393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env11392 == env11393) = true)

def env11394 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4161,318549,17,21762,8193,64,75786,115015,17664,303452,119042,392287,257,98678,90202,63068]

theorem envBound11394 : H12AffineFastState.Bounded env11394 := by
  intro p hp
  have h : env11394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11380_11394 : H12AffineEnvironment.transform 6 9 env11380 = env11394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11380 == env11394) = true)

theorem identity11394 : scanCanonicalize (H12AffineFastState.compose env11394 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound11394 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11395 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,32040,1025,32769,4161,41341,17,21762,8193,64,75786,115015,17664,56436,119042,98679,257,98678,90202,63068]

theorem envBound11395 : H12AffineFastState.Bounded env11395 := by
  intro p hp
  have h : env11395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11394_11395 : H12AffineEnvironment.transform 17 32040 env11394 = env11395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env11394 == env11395) = true)

theorem identity11395 : scanCanonicalize (H12AffineFastState.compose env11395 (packedSelected [0,1,3,4,7,18,19,22,23,24,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 41050) := by decide +kernel

theorem selectedBound11395 : packedSelected [0,1,3,4,7,18,19,22,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env11396 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,41050,24909,32040,1025,32769,4161,41341,17,21762,8193,64,34896,24861,17664,56436,29016,8493,257,8492,49152,63068]

theorem envBound11396 : H12AffineFastState.Bounded env11396 := by
  intro p hp
  have h : env11396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11395_11396 : H12AffineEnvironment.transform 15 41050 env11395 = env11396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41050 env11395 == env11396) = true)

theorem identity11396 : scanCanonicalize (H12AffineFastState.compose env11396 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound11396 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env11397 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,263,24909,32040,1025,8540,4161,32,17,21762,8193,64,10509,24861,17664,32041,29016,8493,257,8492,24925,22273]

theorem envBound11397 : H12AffineFastState.Bounded env11397 := by
  intro p hp
  have h : env11397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11396_11397 : H12AffineEnvironment.transform 14 8541 env11396 = env11397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env11396 == env11397) = true)

theorem identity11397 : scanCanonicalize (H12AffineFastState.compose env11397 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound11397 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env11398 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5157,8541,263,13672,10509,1025,8540,4161,32,17,295,8193,64,10509,13624,4389,10508,9597,8493,257,8492,13688,804]

theorem envBound11398 : H12AffineFastState.Bounded env11398 := by
  intro p hp
  have h : env11398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11397_11398 : H12AffineEnvironment.transform 13 5157 env11397 = env11398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env11397 == env11398) = true)

theorem identity11398 : scanCanonicalize (H12AffineFastState.compose env11398 (packedSelected [0,3,4,5,7,9,11,15,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound11398 : packedSelected [0,3,4,5,7,9,11,15,19,20] rootPS < 2^1333 := by decide +kernel

def env11399 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,5157,8233,115,13340,10361,1025,8232,4161,32,17,83,8193,64,10361,13388,4177,10360,9225,8281,117,8280,13324,592]

theorem envBound11399 : H12AffineFastState.Bounded env11399 := by
  intro p hp
  have h : env11399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11398_11399 : H12AffineEnvironment.transform 7 116 env11398 = env11399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env11398 == env11399) = true)

def env11400 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,155997,2114882,8328,64,6677534,115151,2241549,303453,2334734,4268162,257,254130,196887,2263001]

theorem envBound11400 : H12AffineFastState.Bounded env11400 := by
  intro p hp
  have h : env11400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11274_11400 : H12AffineEnvironment.transform 22 155997 env11274 = env11400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 155997 env11274 == env11400) = true)

def env11401 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2534744,155997,2114882,8328,64,215366,115151,2241549,303453,2334734,2592218,257,254130,196887,2263001]

theorem envBound11401 : H12AffineFastState.Bounded env11401 := by
  intro p hp
  have h : env11401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11400_11401 : H12AffineEnvironment.transform 21 2534744 env11400 = env11401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2534744 env11400 == env11401) = true)

def env11402 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441624,155997,21762,8328,64,215366,115151,140365,303453,241742,499098,257,254130,196887,169881]

theorem envBound11402 : H12AffineFastState.Bounded env11402 := by
  intro p hp
  have h : env11402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11401_11402 : H12AffineEnvironment.transform 20 4160 env11401 = env11402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env11401 == env11402) = true)

theorem identity11402 : scanCanonicalize (H12AffineFastState.compose env11402 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound11402 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11403 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,4160,392286,73755,21762,8328,64,2048,115151,91403,303453,61704,318684,257,41460,16465,120543]

theorem envBound11403 : H12AffineFastState.Bounded env11403 := by
  intro p hp
  have h : env11403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11402_11403 : H12AffineEnvironment.transform 16 82246 env11402 = env11403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env11402 == env11403) = true)

def env11404 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82198,262144,1025,32769,4112,392206,73755,21762,8328,16,2048,115103,91403,303373,61704,318604,257,41380,16385,120463]

theorem envBound11404 : H12AffineFastState.Bounded env11404 := by
  intro p hp
  have h : env11404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11403_11404 : H12AffineEnvironment.transform 5 16 env11403 = env11404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11403 == env11404) = true)

theorem identity11404 : scanCanonicalize (H12AffineFastState.compose env11404 (packedSelected [3,4,7,9,15,19,24,27,31,38] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound11404 : packedSelected [3,4,7,9,15,19,24,27,31,38] rootPS < 2^1333 := by decide +kernel

def env11405 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,21510,5392,262144,1025,32769,4112,305160,29725,21762,8328,16,2048,38297,12557,303373,61704,318604,257,41380,16385,33417]

theorem envBound11405 : H12AffineFastState.Bounded env11405 := by
  intro p hp
  have h : env11405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11404_11405 : H12AffineEnvironment.transform 15 21510 env11404 = env11405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env11404 == env11405) = true)

theorem identity11405 : scanCanonicalize (H12AffineFastState.compose env11405 (packedSelected [0,3,4,7,16,18,20,22,23,24,26,31] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound11405 : packedSelected [0,3,4,7,16,18,20,22,23,24,26,31] rootPS < 2^1333 := by decide +kernel

def env11406 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,21510,5392,32040,1025,32769,4112,54560,29725,21762,8328,16,2048,38297,12557,56357,61704,41380,257,41380,16385,33417]

theorem envBound11406 : H12AffineFastState.Bounded env11406 := by
  intro p hp
  have h : env11406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11405_11406 : H12AffineEnvironment.transform 17 32040 env11405 = env11406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env11405 == env11406) = true)

theorem identity11406 : scanCanonicalize (H12AffineFastState.compose env11406 (packedSelected [0,4,7,16,18,20,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound11406 : packedSelected [0,4,7,16,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env11407 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,32768,263,5392,10281,1025,32769,4112,32801,8476,3,8328,16,2048,38297,12557,35108,41993,41380,257,41380,5376,33417]

theorem envBound11407 : H12AffineFastState.Bounded env11407 := by
  intro p hp
  have h : env11407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11406_11407 : H12AffineEnvironment.transform 13 5377 env11406 = env11407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env11406 == env11407) = true)

theorem identity11407 : scanCanonicalize (H12AffineFastState.compose env11407 (packedSelected [0,2,3,5,6,7,10,11,16,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound11407 : packedSelected [0,2,3,5,6,7,10,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env11408 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8460,263,5392,10281,1025,8461,4112,8493,8476,3,8328,16,2048,13461,12557,10280,1285,168,257,168,5376,9093]

theorem envBound11408 : H12AffineFastState.Bounded env11408 := by
  intro p hp
  have h : env11408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11407_11408 : H12AffineEnvironment.transform 14 8460 env11407 = env11408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env11407 == env11408) = true)

theorem identity11408 : scanCanonicalize (H12AffineFastState.compose env11408 (packedSelected [0,3,4,5,7,9,10,11,14] rootPS)) = affineNative (2^(12+1) ^^^ 3100) := by decide +kernel

theorem selectedBound11408 : packedSelected [0,3,4,5,7,9,10,11,14] rootPS < 2^1333 := by decide +kernel

def env11409 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,3100,5377,3344,263,5392,1077,1025,3345,4112,3377,3328,3,3220,16,2048,6281,7441,1076,1285,168,257,168,5376,3993]

theorem envBound11409 : H12AffineFastState.Bounded env11409 := by
  intro p hp
  have h : env11409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11408_11409 : H12AffineEnvironment.transform 12 3100 env11408 = env11409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3100 env11408 == env11409) = true)

theorem identity11409 : scanCanonicalize (H12AffineFastState.compose env11409 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 444) := by decide +kernel

theorem selectedBound11409 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env11410 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,444,3100,1213,3344,263,1196,1077,1025,3345,428,3377,3328,3,3220,16,2048,2357,3245,1076,1285,168,257,168,1212,3993]

theorem envBound11410 : H12AffineFastState.Bounded env11410 := by
  intro p hp
  have h : env11410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11409_11410 : H12AffineEnvironment.transform 11 444 env11409 = env11410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 444 env11409 == env11410) = true)

theorem identity11410 : scanCanonicalize (H12AffineFastState.compose env11410 (packedSelected [2,3,4,5,6,9,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1432) := by decide +kernel

theorem selectedBound11410 : packedSelected [2,3,4,5,6,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env11411 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1432,444,388,1213,136,263,1196,1077,1025,137,428,169,152,3,268,16,1432,1197,309,1076,1285,168,257,168,1212,513]

theorem envBound11411 : H12AffineFastState.Bounded env11411 := by
  intro p hp
  have h : env11411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11410_11411 : H12AffineEnvironment.transform 10 1432 env11410 = env11411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1432 env11410 == env11411) = true)

theorem identity11411 : scanCanonicalize (H12AffineFastState.compose env11411 (packedSelected [2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound11411 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env11412 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1076,16,40,1213,136,171,1196,1077,1025,137,0,169,152,3,160,16,1076,1197,153,1076,1193,168,173,168,1212,513]

theorem envBound11412 : H12AffineFastState.Bounded env11412 := by
  intro p hp
  have h : env11412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11411_11412 : H12AffineEnvironment.transform 7 172 env11411 = env11412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env11411 == env11412) = true)

theorem identity11412 : scanCanonicalize (H12AffineFastState.compose env11412 (packedSelected [4,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound11412 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env11413 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1076,16,40,1077,0,35,1060,1077,1025,1,0,33,16,3,40,16,1076,1061,17,1076,1057,32,37,32,1076,513]

theorem envBound11413 : H12AffineFastState.Bounded env11413 := by
  intro p hp
  have h : env11413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11412_11413 : H12AffineEnvironment.transform 6 8 env11412 = env11413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11412 == env11413) = true)

theorem identity11413 : scanCanonicalize (H12AffineFastState.compose env11413 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound11413 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11414 : List Nat := [2,4,8,16,32,16,8,36,512,52,0,16,40,1,0,35,16,1,53,1,0,33,16,3,40,16,0,17,17,0,21,32,37,32,0,513]

theorem envBound11414 : H12AffineFastState.Bounded env11414 := by
  intro p hp
  have h : env11414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11413_11414 : H12AffineEnvironment.transform 9 52 env11413 = env11414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env11413 == env11414) = true)

theorem identity11414 : scanCanonicalize (H12AffineFastState.compose env11414 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound11414 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11415 : List Nat := [2,4,8,16,32,16,8,36,0,52,0,16,40,1,0,35,16,1,53,1,0,33,16,3,40,16,0,17,17,0,21,32,37,32,0,1]

theorem envBound11415 : H12AffineFastState.Bounded env11415 := by
  intro p hp
  have h : env11415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11414_11415 : H12AffineEnvironment.transform 8 0 env11414 = env11415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env11414 == env11415) = true)

theorem identity11415 : scanCanonicalize (H12AffineFastState.compose env11415 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound11415 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11416 : List Nat := [2,4,3,16,32,16,3,36,0,52,0,16,35,1,0,35,16,1,53,1,0,33,16,3,35,16,0,17,17,0,21,32,37,32,0,1]

theorem envBound11416 : H12AffineFastState.Bounded env11416 := by
  intro p hp
  have h : env11416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11415_11416 : H12AffineEnvironment.transform 2 3 env11415 = env11416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env11415 == env11416) = true)

def env11417 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82199,262144,1025,32769,4113,392207,73755,21762,8328,17,2048,115102,91403,303372,61704,318605,257,41381,16384,120462]

theorem envBound11417 : H12AffineFastState.Bounded env11417 := by
  intro p hp
  have h : env11417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11403_11417 : H12AffineEnvironment.transform 5 17 env11403 = env11417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11403 == env11417) = true)

theorem identity11417 : scanCanonicalize (H12AffineFastState.compose env11417 (packedSelected [3,4,7,9,15,19,24,27,31,38] rootPS)) = affineNative (2^(17+1) ^^^ 23588) := by decide +kernel

theorem selectedBound11417 : packedSelected [3,4,7,9,15,19,24,27,31,38] rootPS < 2^1333 := by decide +kernel

def env11418 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82199,23588,1025,32769,4113,106539,73755,21762,8328,17,2048,115102,91403,64808,61704,32937,257,41381,16384,120462]

theorem envBound11418 : H12AffineFastState.Bounded env11418 := by
  intro p hp
  have h : env11418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11417_11418 : H12AffineEnvironment.transform 17 23588 env11417 = env11418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23588 env11417 == env11418) = true)

theorem identity11418 : scanCanonicalize (H12AffineFastState.compose env11418 (packedSelected [0,1,3,4,5,7,8,10,17,18,19,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 54279) := by decide +kernel

theorem selectedBound11418 : packedSelected [0,1,3,4,5,7,8,10,17,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env11419 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54279,38160,23588,1025,32769,4113,29740,62492,21762,8328,17,2048,5529,45324,64808,61704,32937,257,41381,16384,649]

theorem envBound11419 : H12AffineFastState.Bounded env11419 := by
  intro p hp
  have h : env11419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11418_11419 : H12AffineEnvironment.transform 15 54279 env11418 = env11419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54279 env11418 == env11419) = true)

theorem identity11419 : scanCanonicalize (H12AffineFastState.compose env11419 (packedSelected [1,2,4,6,8,12,15,16,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound11419 : packedSelected [1,2,4,6,8,12,15,16,19,22] rootPS < 2^1333 := by decide +kernel

def env11420 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,0,21511,5392,23588,1025,1,4113,29740,29724,21762,8328,17,2048,5529,12556,32040,28936,169,257,8613,16384,649]

theorem envBound11420 : H12AffineFastState.Bounded env11420 := by
  intro p hp
  have h : env11420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11419_11420 : H12AffineEnvironment.transform 14 0 env11419 = env11420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env11419 == env11420) = true)

theorem identity11420 : scanCanonicalize (H12AffineFastState.compose env11420 (packedSelected [0,2,3,5,6,7,10,12,15,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound11420 : packedSelected [0,2,3,5,6,7,10,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env11421 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,0,21511,5392,23588,1025,1,4113,29740,29724,21762,8192,17,2048,5393,12556,32040,28936,33,257,8493,16384,513]

theorem envBound11421 : H12AffineFastState.Bounded env11421 := by
  intro p hp
  have h : env11421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11420_11421 : H12AffineEnvironment.transform 6 8 env11420 = env11421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11420 == env11421) = true)

theorem identity11421 : scanCanonicalize (H12AffineFastState.compose env11421 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound11421 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11422 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13324,0,8203,5392,10280,1025,1,4113,32,16,8462,8192,17,2048,5393,12556,2340,1284,33,257,8493,13324,513]

theorem envBound11422 : H12AffineFastState.Bounded env11422 := by
  intro p hp
  have h : env11422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11421_11422 : H12AffineEnvironment.transform 13 13324 env11421 = env11422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env11421 == env11422) = true)

theorem identity11422 : scanCanonicalize (H12AffineFastState.compose env11422 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound11422 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11423 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,0,262,5392,2341,1025,1,4113,32,16,3,269,17,2048,5393,4097,2340,1284,33,257,32,5377,513]

theorem envBound11423 : H12AffineFastState.Bounded env11423 := by
  intro p hp
  have h : env11423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11422_11423 : H12AffineEnvironment.transform 12 269 env11422 = env11423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env11422 == env11423) = true)

theorem identity11423 : scanCanonicalize (H12AffineFastState.compose env11423 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound11423 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11424 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1060,269,293,0,262,308,2341,1025,1,1077,32,16,3,269,17,2048,309,1061,2340,1284,33,257,32,293,513]

theorem envBound11424 : H12AffineFastState.Bounded env11424 := by
  intro p hp
  have h : env11424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11423_11424 : H12AffineEnvironment.transform 11 1060 env11423 = env11424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env11423 == env11424) = true)

theorem identity11424 : scanCanonicalize (H12AffineFastState.compose env11424 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound11424 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11425 : List Nat := [2,4,8,16,32,17,8,256,512,1024,293,1060,269,293,0,262,308,0,1025,1,1077,32,16,3,269,17,293,309,1061,1,1284,33,257,32,293,513]

theorem envBound11425 : H12AffineFastState.Bounded env11425 := by
  intro p hp
  have h : env11425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11424_11425 : H12AffineEnvironment.transform 10 293 env11424 = env11425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env11424 == env11425) = true)

theorem identity11425 : scanCanonicalize (H12AffineFastState.compose env11425 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound11425 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env11426 : List Nat := [2,4,8,16,32,17,8,256,512,53,293,17,269,293,0,262,308,0,52,1,0,32,16,3,269,17,293,309,16,1,305,33,257,32,293,513]

theorem envBound11426 : H12AffineFastState.Bounded env11426 := by
  intro p hp
  have h : env11426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11425_11426 : H12AffineEnvironment.transform 9 53 env11425 = env11426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env11425 == env11426) = true)

def env11427 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441625,155997,21763,8328,64,215366,115151,140364,303453,241743,499099,257,254130,196887,169880]

theorem envBound11427 : H12AffineFastState.Bounded env11427 := by
  intro p hp
  have h : env11427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11401_11427 : H12AffineEnvironment.transform 20 4161 env11401 = env11427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env11401 == env11427) = true)

theorem identity11427 : scanCanonicalize (H12AffineFastState.compose env11427 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound11427 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11428 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,4161,441625,155997,21763,8328,64,171417,5392,140364,303453,156816,411972,257,144493,185800,169880]

theorem envBound11428 : H12AffineFastState.Bounded env11428 := by
  intro p hp
  have h : env11428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11427_11428 : H12AffineEnvironment.transform 15 54495 env11427 = env11428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env11427 == env11428) = true)

def env11429 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,262144,1025,32769,4113,441625,155917,21763,8328,16,171417,5392,140316,303373,156816,411924,257,144445,185752,169880]

theorem envBound11429 : H12AffineFastState.Bounded env11429 := by
  intro p hp
  have h : env11429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11428_11429 : H12AffineEnvironment.transform 5 16 env11428 = env11429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11428 == env11429) = true)

theorem identity11429 : scanCanonicalize (H12AffineFastState.compose env11429 (packedSelected [1,4,7,9,19,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 146744) := by decide +kernel

theorem selectedBound11429 : packedSelected [1,4,7,9,19,27,28,31] rootPS < 2^1333 := by decide +kernel

def env11430 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,146744,1025,32769,4113,32801,155917,21763,8328,16,171417,5392,140316,171061,156816,29740,257,144445,185752,169880]

theorem envBound11430 : H12AffineFastState.Bounded env11430 := by
  intro p hp
  have h : env11430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11429_11430 : H12AffineEnvironment.transform 17 146744 env11429 = env11430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146744 env11429 == env11430) = true)

theorem identity11430 : scanCanonicalize (H12AffineFastState.compose env11430 (packedSelected [0,1,3,4,7,19,22,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 46108) := by decide +kernel

theorem selectedBound11430 : packedSelected [0,1,3,4,7,19,22,24,26,28] rootPS < 2^1333 := by decide +kernel

def env11431 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,46108,35108,1025,32769,4113,32801,54545,21763,8328,16,10629,5392,36864,10281,53388,29740,257,32801,24964,9092]

theorem envBound11431 : H12AffineFastState.Bounded env11431 := by
  intro p hp
  have h : env11431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11430_11431 : H12AffineEnvironment.transform 16 46108 env11430 = env11431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46108 env11430 == env11431) = true)

theorem identity11431 : scanCanonicalize (H12AffineFastState.compose env11431 (packedSelected [0,1,4,5,7,8,16,18,20,22,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound11431 : packedSelected [0,1,4,5,7,8,16,18,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env11432 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,32768,41091,46108,35108,1025,32769,4113,32801,41245,8463,8328,16,10629,5392,36864,10281,42112,32,257,32801,5512,9092]

theorem envBound11432 : H12AffineFastState.Bounded env11432 := by
  intro p hp
  have h : env11432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11431_11432 : H12AffineEnvironment.transform 13 13324 env11431 = env11432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env11431 == env11432) = true)

theorem identity11432 : scanCanonicalize (H12AffineFastState.compose env11432 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound11432 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11433 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,136,8203,13460,2476,1025,137,4113,169,8597,8463,8328,16,10629,5392,4232,10281,9224,32,257,169,5512,9092]

theorem envBound11433 : H12AffineFastState.Bounded env11433 := by
  intro p hp
  have h : env11433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11432_11433 : H12AffineEnvironment.transform 14 136 env11432 = env11433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env11432 == env11433) = true)

theorem identity11433 : scanCanonicalize (H12AffineFastState.compose env11433 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound11433 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env11434 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,8192,12573,136,8203,12677,2476,272,137,4113,169,8597,8463,8328,16,10629,4097,4232,10281,8473,32,257,169,4249,9092]

theorem envBound11434 : H12AffineFastState.Bounded env11434 := by
  intro p hp
  have h : env11434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11433_11434 : H12AffineEnvironment.transform 9 273 env11433 = env11434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env11433 == env11434) = true)

theorem identity11434 : scanCanonicalize (H12AffineFastState.compose env11434 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound11434 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11435 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,388,4249,136,399,4097,2476,272,137,4113,169,17,139,268,16,2049,4097,4232,2477,157,32,257,169,4249,512]

theorem envBound11435 : H12AffineFastState.Bounded env11435 := by
  intro p hp
  have h : env11435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11434_11435 : H12AffineEnvironment.transform 12 388 env11434 = env11435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env11434 == env11435) = true)

theorem identity11435 : scanCanonicalize (H12AffineFastState.compose env11435 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11435 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11436 : List Nat := [2,4,8,16,0,16,128,256,512,273,2048,4096,388,4249,136,399,4097,2444,272,137,4113,137,17,139,268,16,2049,4097,4232,2445,157,0,257,137,4249,512]

theorem envBound11436 : H12AffineFastState.Bounded env11436 := by
  intro p hp
  have h : env11436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11435_11436 : H12AffineEnvironment.transform 4 0 env11435 = env11436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11435 == env11436) = true)

theorem identity11436 : scanCanonicalize (H12AffineFastState.compose env11436 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound11436 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env11437 : List Nat := [2,4,8,16,0,16,9,256,512,273,2048,4096,269,4112,1,262,4097,2309,272,0,4113,0,17,2,268,16,2049,4097,4097,2308,20,0,257,0,4112,512]

theorem envBound11437 : H12AffineFastState.Bounded env11437 := by
  intro p hp
  have h : env11437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11436_11437 : H12AffineEnvironment.transform 6 9 env11436 = env11437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11436 == env11437) = true)

def env11438 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,262144,1025,32769,4112,441625,155916,21763,8328,17,171417,5392,140317,303372,156816,411925,257,144444,185753,169880]

theorem envBound11438 : H12AffineFastState.Bounded env11438 := by
  intro p hp
  have h : env11438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11428_11438 : H12AffineEnvironment.transform 5 17 env11428 = env11438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11428 == env11438) = true)

theorem identity11438 : scanCanonicalize (H12AffineFastState.compose env11438 (packedSelected [1,4,7,9,19,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 182716) := by decide +kernel

theorem selectedBound11438 : packedSelected [1,4,7,9,19,27,28,31] rootPS < 2^1333 := by decide +kernel

def env11439 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,182716,1025,32769,4112,29861,155916,21763,8328,17,171417,5392,140317,157872,156816,32937,257,144444,185753,169880]

theorem envBound11439 : H12AffineFastState.Bounded env11439 := by
  intro p hp
  have h : env11439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11438_11439 : H12AffineEnvironment.transform 17 182716 env11438 = env11439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182716 env11438 == env11439) = true)

theorem identity11439 : scanCanonicalize (H12AffineFastState.compose env11439 (packedSelected [5,8,10,11,16,17,18,20,23,24,26,28,32] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound11439 : packedSelected [5,8,10,11,16,17,18,20,23,24,26,28,32] rootPS < 2^1333 := by decide +kernel

def env11440 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8460,30082,131072,157872,1025,8461,4112,29861,155916,21763,8328,17,146581,5392,140317,157872,156816,8613,257,144444,160917,145044]

theorem envBound11440 : H12AffineFastState.Bounded env11440 := by
  intro p hp
  have h : env11440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11439_11440 : H12AffineEnvironment.transform 14 8460 env11439 = env11440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env11439 == env11440) = true)

theorem identity11440 : scanCanonicalize (H12AffineFastState.compose env11440 (packedSelected [0,3,4,7,10,16,17,19,20,22,24] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound11440 : packedSelected [0,3,4,7,10,16,17,19,20,22,24] rootPS < 2^1333 := by decide +kernel

def env11441 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8460,30082,5392,32160,1025,8461,4112,29861,29724,21763,8328,17,10629,5392,12557,32160,29056,8613,257,8492,24965,9092]

theorem envBound11441 : H12AffineFastState.Bounded env11441 := by
  intro p hp
  have h : env11441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11440_11441 : H12AffineEnvironment.transform 16 5392 env11440 = env11441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env11440 == env11441) = true)

theorem identity11441 : scanCanonicalize (H12AffineFastState.compose env11441 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound11441 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env11442 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,16384,1,21647,5392,23725,1025,0,4112,21928,21777,21763,389,17,2184,5392,4096,23725,20621,168,257,33,16520,649]

theorem envBound11442 : H12AffineFastState.Bounded env11442 := by
  intro p hp
  have h : env11442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11441_11442 : H12AffineEnvironment.transform 12 269 env11441 = env11442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env11441 == env11442) = true)

theorem identity11442 : scanCanonicalize (H12AffineFastState.compose env11442 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound11442 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env11443 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,5376,1,399,5392,2477,1025,0,4112,168,17,3,389,17,2184,5392,4096,2477,1421,168,257,33,5512,649]

theorem envBound11443 : H12AffineFastState.Bounded env11443 := by
  intro p hp
  have h : env11443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11442_11443 : H12AffineEnvironment.transform 13 5376 env11442 = env11443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env11442 == env11443) = true)

theorem identity11443 : scanCanonicalize (H12AffineFastState.compose env11443 (packedSelected [2,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 1677) := by decide +kernel

theorem selectedBound11443 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env11444 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1677,269,909,1,399,925,2477,1025,0,1693,168,17,3,389,17,2184,925,1677,2477,1421,168,257,33,773,649]

theorem envBound11444 : H12AffineFastState.Bounded env11444 := by
  intro p hp
  have h : env11444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11443_11444 : H12AffineEnvironment.transform 11 1677 env11443 = env11444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1677 env11443 == env11444) = true)

theorem identity11444 : scanCanonicalize (H12AffineFastState.compose env11444 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound11444 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env11445 : List Nat := [2,4,8,16,32,17,128,157,512,1024,2048,1677,144,528,1,18,512,2096,1025,0,1693,168,17,3,24,17,2184,512,1677,2096,1040,168,156,33,664,649]

theorem envBound11445 : H12AffineFastState.Bounded env11445 := by
  intro p hp
  have h : env11445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11444_11445 : H12AffineEnvironment.transform 7 157 env11444 = env11445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env11444 == env11445) = true)

theorem identity11445 : scanCanonicalize (H12AffineFastState.compose env11445 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 700) := by decide +kernel

theorem selectedBound11445 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11446 : List Nat := [2,4,8,16,32,17,128,157,512,700,2048,49,144,528,1,18,512,2096,701,0,33,168,17,3,24,17,2184,512,49,2096,684,168,156,33,664,649]

theorem envBound11446 : H12AffineFastState.Bounded env11446 := by
  intro p hp
  have h : env11446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11445_11446 : H12AffineEnvironment.transform 9 700 env11445 = env11446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 700 env11445 == env11446) = true)

theorem identity11446 : scanCanonicalize (H12AffineFastState.compose env11446 (packedSelected [0,6,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound11446 : packedSelected [0,6,9] rootPS < 2^1333 := by decide +kernel

def env11447 : List Nat := [2,4,8,1,32,0,128,140,512,685,2048,32,129,513,1,3,512,2081,684,0,33,168,0,3,9,0,2184,512,32,2081,684,168,141,33,649,649]

theorem envBound11447 : H12AffineFastState.Bounded env11447 := by
  intro p hp
  have h : env11447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11446_11447 : H12AffineEnvironment.transform 3 1 env11446 = env11447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env11446 == env11447) = true)

theorem identity11447 : scanCanonicalize (H12AffineFastState.compose env11447 (packedSelected [3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 648) := by decide +kernel

theorem selectedBound11447 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env11448 : List Nat := [2,4,8,1,32,0,128,140,512,685,648,32,129,513,1,3,512,681,684,0,33,168,0,3,9,0,512,512,32,681,684,168,141,33,649,649]

theorem envBound11448 : H12AffineFastState.Bounded env11448 := by
  intro p hp
  have h : env11448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11447_11448 : H12AffineEnvironment.transform 10 648 env11447 = env11448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 648 env11447 == env11448) = true)

theorem identity11448 : scanCanonicalize (H12AffineFastState.compose env11448 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound11448 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env11449 : List Nat := [2,4,8,1,32,0,128,140,32,141,168,32,129,33,1,3,32,137,140,0,33,168,0,3,9,0,32,32,32,137,140,168,141,33,169,169]

theorem envBound11449 : H12AffineFastState.Bounded env11449 := by
  intro p hp
  have h : env11449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11448_11449 : H12AffineEnvironment.transform 8 32 env11448 = env11449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env11448 == env11449) = true)

theorem identity11449 : scanCanonicalize (H12AffineFastState.compose env11449 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11449 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11450 : List Nat := [2,4,8,1,0,0,128,140,0,141,136,0,129,1,1,3,0,137,140,0,1,136,0,3,9,0,0,0,0,137,140,136,141,1,137,137]

theorem envBound11450 : H12AffineFastState.Bounded env11450 := by
  intro p hp
  have h : env11450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11449_11450 : H12AffineEnvironment.transform 4 0 env11449 = env11450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11449 == env11450) = true)

theorem identity11450 : scanCanonicalize (H12AffineFastState.compose env11450 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound11450 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11451 : List Nat := [2,4,8,1,0,0,9,5,0,4,1,0,8,1,1,3,0,0,5,0,1,1,0,3,9,0,0,0,0,0,5,1,4,1,0,0]

theorem envBound11451 : H12AffineFastState.Bounded env11451 := by
  intro p hp
  have h : env11451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11450_11451 : H12AffineEnvironment.transform 6 9 env11450 = env11451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11450 == env11451) = true)

theorem identity11451 : scanCanonicalize (H12AffineFastState.compose env11451 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound11451 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11452 : List Nat := [2,1,8,1,0,0,9,0,0,1,1,0,8,1,1,3,0,0,0,0,1,1,0,3,9,0,0,0,0,0,0,1,1,1,0,0]

theorem envBound11452 : H12AffineFastState.Bounded env11452 := by
  intro p hp
  have h : env11452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11451_11452 : H12AffineEnvironment.transform 1 1 env11451 = env11452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env11451 == env11452) = true)

def env11453 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2534745,155997,2114882,8328,64,215367,115151,2241549,303453,2334734,2592219,257,254130,196887,2263001]

theorem envBound11453 : H12AffineFastState.Bounded env11453 := by
  intro p hp
  have h : env11453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11400_11453 : H12AffineEnvironment.transform 21 2534745 env11400 = env11453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2534745 env11400 == env11453) = true)

def env11454 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441625,155997,21762,8328,64,215367,115151,140365,303453,241742,499099,257,254130,196887,169881]

theorem envBound11454 : H12AffineFastState.Bounded env11454 := by
  intro p hp
  have h : env11454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11453_11454 : H12AffineEnvironment.transform 20 4160 env11453 = env11454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env11453 == env11454) = true)

theorem identity11454 : scanCanonicalize (H12AffineFastState.compose env11454 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound11454 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11455 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4160,441625,155997,21762,8328,64,158029,57797,140365,303453,168004,441745,257,180408,139549,169881]

theorem envBound11455 : H12AffineFastState.Bounded env11455 := by
  intro p hp
  have h : env11455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11454_11455 : H12AffineEnvironment.transform 15 8202 env11454 = env11455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env11454 == env11455) = true)

theorem identity11455 : scanCanonicalize (H12AffineFastState.compose env11455 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 38296) := by decide +kernel

theorem selectedBound11455 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env11456 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38296,262144,1025,32769,4160,272513,62661,21762,8328,64,64725,57797,45525,303453,1500,272393,257,21792,46213,513]

theorem envBound11456 : H12AffineFastState.Bounded env11456 := by
  intro p hp
  have h : env11456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11455_11456 : H12AffineEnvironment.transform 16 38296 env11455 = env11456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env11455 == env11456) = true)

theorem identity11456 : scanCanonicalize (H12AffineFastState.compose env11456 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2556) := by decide +kernel

theorem selectedBound11456 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env11457 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38296,2556,1025,32769,4160,8573,62661,21762,8328,64,64725,57797,45525,43169,1500,8693,257,21792,46213,513]

theorem envBound11457 : H12AffineFastState.Bounded env11457 := by
  intro p hp
  have h : env11457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11456_11457 : H12AffineEnvironment.transform 17 2556 env11456 = env11457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2556 env11456 == env11457) = true)

theorem identity11457 : scanCanonicalize (H12AffineFastState.compose env11457 (packedSelected [2,3,5,6,8,12,15,17,28,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound11457 : packedSelected [2,3,5,6,8,12,15,17,28,38,41] rootPS < 2^1333 := by decide +kernel

def env11458 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21841,8202,16585,2556,1025,21840,4160,8573,8596,21762,8328,64,10628,13460,25732,32240,1500,8693,257,21792,25044,513]

theorem envBound11458 : H12AffineFastState.Bounded env11458 := by
  intro p hp
  have h : env11458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11457_11458 : H12AffineEnvironment.transform 14 21841 env11457 = env11458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env11457 == env11458) = true)

theorem identity11458 : scanCanonicalize (H12AffineFastState.compose env11458 (packedSelected [1,2,5,6,7,8,14,16,17,24,27] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11458 : packedSelected [1,2,5,6,7,8,14,16,17,24,27] rootPS < 2^1333 := by decide +kernel

def env11459 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21761,8202,16537,2476,1025,21760,4112,8493,8596,21762,8328,16,10628,13460,25732,32160,1420,8613,257,21792,24964,513]

theorem envBound11459 : H12AffineFastState.Bounded env11459 := by
  intro p hp
  have h : env11459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11458_11459 : H12AffineEnvironment.transform 5 16 env11458 = env11459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11458 == env11459) = true)

theorem identity11459 : scanCanonicalize (H12AffineFastState.compose env11459 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound11459 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11460 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,21761,8202,16400,2341,1025,21760,4112,8493,8477,21762,8193,16,10509,13341,25613,32041,1285,8492,257,21792,24845,513]

theorem envBound11460 : H12AffineFastState.Bounded env11460 := by
  intro p hp
  have h : env11460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11459_11460 : H12AffineEnvironment.transform 6 9 env11459 = env11460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11459 == env11460) = true)

theorem identity11460 : scanCanonicalize (H12AffineFastState.compose env11460 (packedSelected [1,2,4,8,9,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 3101) := by decide +kernel

theorem selectedBound11460 : packedSelected [1,2,4,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env11461 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,3101,16384,21761,3095,16400,2341,1025,21760,4112,3376,3328,21762,3100,16,1296,6144,18448,20788,1285,3377,257,21792,19728,513]

theorem envBound11461 : H12AffineFastState.Bounded env11461 := by
  intro p hp
  have h : env11461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11460_11461 : H12AffineEnvironment.transform 12 3101 env11460 = env11461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3101 env11460 == env11461) = true)

theorem identity11461 : scanCanonicalize (H12AffineFastState.compose env11461 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound11461 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env11462 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2064,3101,16384,19729,3095,16400,2341,1025,19728,2048,3376,3328,19730,3100,16,1296,16,18448,18724,1285,3377,257,19760,19728,513]

theorem envBound11462 : H12AffineFastState.Bounded env11462 := by
  intro p hp
  have h : env11462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11461_11462 : H12AffineEnvironment.transform 11 2064 env11461 = env11462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env11461 == env11462) = true)

theorem identity11462 : scanCanonicalize (H12AffineFastState.compose env11462 (packedSelected [0,1,2,3,5,7,8,10] rootPS)) = affineNative (2^(13+1) ^^^ 292) := by decide +kernel

theorem selectedBound11462 : packedSelected [0,1,2,3,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env11463 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2064,3101,292,3125,3095,308,2341,1025,3124,2048,3376,3328,3126,3100,16,1296,16,2356,2048,1285,3377,257,3092,3124,513]

theorem envBound11463 : H12AffineFastState.Bounded env11463 := by
  intro p hp
  have h : env11463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11462_11463 : H12AffineEnvironment.transform 13 292 env11462 = env11463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 292 env11462 == env11463) = true)

def env11464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441624,155997,21763,8328,64,215367,115151,140364,303453,241743,499098,257,254130,196887,169880]

theorem envBound11464 : H12AffineFastState.Bounded env11464 := by
  intro p hp
  have h : env11464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11453_11464 : H12AffineEnvironment.transform 20 4161 env11453 = env11464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env11453 == env11464) = true)

theorem identity11464 : scanCanonicalize (H12AffineFastState.compose env11464 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 112019) := by decide +kernel

theorem selectedBound11464 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,112019,262144,1025,32769,4161,329867,120014,21763,8328,64,64724,115151,102879,303453,1500,272393,257,21793,46212,74251]

theorem envBound11465 : H12AffineFastState.Bounded env11465 := by
  intro p hp
  have h : env11465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11464_11465 : H12AffineEnvironment.transform 16 112019 env11464 = env11465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 112019 env11464 == env11465) = true)

def env11466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,112019,10400,1025,32769,4161,73771,120014,21763,8328,64,64724,115151,102879,35325,1500,169,257,21793,46212,74251]

theorem envBound11466 : H12AffineFastState.Bounded env11466 := by
  intro p hp
  have h : env11466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11465_11466 : H12AffineEnvironment.transform 17 10400 env11465 = env11466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env11465 == env11466) = true)

theorem identity11466 : scanCanonicalize (H12AffineFastState.compose env11466 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound11466 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env11467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,82246,10400,1025,29908,4161,73771,73755,21763,8328,64,2049,79130,91402,32040,1500,169,257,21793,16465,74251]

theorem envBound11467 : H12AffineFastState.Bounded env11467 := by
  intro p hp
  have h : env11467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11466_11467 : H12AffineEnvironment.transform 14 29909 env11466 = env11467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env11466 == env11467) = true)

theorem identity11467 : scanCanonicalize (H12AffineFastState.compose env11467 (packedSelected [11,16,17,18,20,23,32] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound11467 : packedSelected [11,16,17,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env11468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,1,65536,79250,10400,1025,0,4161,73771,73755,8663,8328,64,2049,79130,70110,2556,1500,169,257,8693,13445,74251]

theorem envBound11468 : H12AffineFastState.Bounded env11468 := by
  intro p hp
  have h : env11468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11467_11468 : H12AffineEnvironment.transform 13 13524 env11467 = env11468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env11467 == env11468) = true)

theorem identity11468 : scanCanonicalize (H12AffineFastState.compose env11468 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound11468 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env11469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5513,1,65536,70863,2557,1025,0,4161,65910,65862,138,469,64,2049,70727,70110,2556,1500,169,257,168,5592,66390]

theorem envBound11469 : H12AffineFastState.Bounded env11469 := by
  intro p hp
  have h : env11469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11468_11469 : H12AffineEnvironment.transform 12 349 env11468 = env11469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env11468 == env11469) = true)

theorem identity11469 : scanCanonicalize (H12AffineFastState.compose env11469 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound11469 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11470 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,65536,70726,2420,1025,0,4161,65910,65862,3,348,64,2049,70727,69975,2421,1365,32,257,33,5457,66390]

theorem envBound11470 : H12AffineFastState.Bounded env11470 := by
  intro p hp
  have h : env11470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11469_11470 : H12AffineEnvironment.transform 6 9 env11469 = env11470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11469 == env11470) = true)

theorem identity11470 : scanCanonicalize (H12AffineFastState.compose env11470 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound11470 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11471 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,342,5392,2420,1025,0,4161,32,16,3,348,64,2049,5393,4097,2421,1365,32,257,33,5457,512]

theorem envBound11471 : H12AffineFastState.Bounded env11471 := by
  intro p hp
  have h : env11471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11470_11471 : H12AffineEnvironment.transform 15 342 env11470 = env11471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env11470 == env11471) = true)

theorem identity11471 : scanCanonicalize (H12AffineFastState.compose env11471 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11471 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11472 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,349,5376,1,342,5392,2389,1025,0,4161,1,16,3,348,64,2049,5393,4097,2388,1365,1,257,0,5457,512]

theorem envBound11472 : H12AffineFastState.Bounded env11472 := by
  intro p hp
  have h : env11472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11471_11472 : H12AffineEnvironment.transform 4 1 env11471 = env11472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11471 == env11472) = true)

def env11473 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,112019,10401,1025,32769,4161,73770,120014,21763,8328,64,64724,115151,102879,35324,1500,168,257,21793,46212,74251]

theorem envBound11473 : H12AffineFastState.Bounded env11473 := by
  intro p hp
  have h : env11473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11465_11473 : H12AffineEnvironment.transform 17 10401 env11465 = env11473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env11465 == env11473) = true)

theorem identity11473 : scanCanonicalize (H12AffineFastState.compose env11473 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound11473 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env11474 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,343,46276,10401,1025,32769,4161,8573,54681,21763,8328,64,64724,49304,37000,35324,1500,168,257,21793,46212,9052]

theorem envBound11474 : H12AffineFastState.Bounded env11474 := by
  intro p hp
  have h : env11474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11473_11474 : H12AffineEnvironment.transform 15 343 env11473 = env11474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env11473 == env11474) = true)

theorem identity11474 : scanCanonicalize (H12AffineFastState.compose env11474 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound11474 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env11475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,343,38297,2556,1025,32769,4161,32,54681,21763,469,64,56713,49304,37000,35324,1500,168,257,21793,38361,513]

theorem envBound11475 : H12AffineFastState.Bounded env11475 := by
  intro p hp
  have h : env11475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11474_11475 : H12AffineEnvironment.transform 12 349 env11474 = env11475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env11474 == env11475) = true)

theorem identity11475 : scanCanonicalize (H12AffineFastState.compose env11475 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound11475 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env11476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5512,32768,343,38297,2556,1025,32769,4161,32,32785,139,469,64,34817,38160,37000,35324,1500,168,257,169,38361,513]

theorem envBound11476 : H12AffineFastState.Bounded env11476 := by
  intro p hp
  have h : env11476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11475_11476 : H12AffineEnvironment.transform 13 5512 env11475 = env11476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env11475 == env11476) = true)

theorem identity11476 : scanCanonicalize (H12AffineFastState.compose env11476 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound11476 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env11477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5512,136,343,5393,2556,1025,137,4161,32,153,139,469,64,2185,5528,4096,2420,1500,168,257,169,5457,513]

theorem envBound11477 : H12AffineFastState.Bounded env11477 := by
  intro p hp
  have h : env11477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11476_11477 : H12AffineEnvironment.transform 14 136 env11476 = env11477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env11476 == env11477) = true)

theorem identity11477 : scanCanonicalize (H12AffineFastState.compose env11477 (packedSelected [2,4,9] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound11477 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env11478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2048,349,3464,136,343,3345,2556,1025,137,2113,32,153,139,469,64,2185,3480,2048,2420,1500,168,257,169,3409,513]

theorem envBound11478 : H12AffineFastState.Bounded env11478 := by
  intro p hp
  have h : env11478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11477_11478 : H12AffineEnvironment.transform 11 2048 env11477 = env11478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env11477 == env11478) = true)

theorem identity11478 : scanCanonicalize (H12AffineFastState.compose env11478 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound11478 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env11479 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,2048,349,3408,80,343,3345,2340,1025,81,2113,32,65,83,269,64,2129,3392,2048,2420,1284,112,257,113,3409,513]

theorem envBound11479 : H12AffineFastState.Bounded env11479 := by
  intro p hp
  have h : env11479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11478_11479 : H12AffineEnvironment.transform 6 88 env11478 = env11479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env11478 == env11479) = true)

theorem identity11479 : scanCanonicalize (H12AffineFastState.compose env11479 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound11479 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env11480 : List Nat := [2,4,8,16,32,64,88,116,512,1024,2048,2048,41,3108,80,35,3173,2128,1025,81,2113,32,65,83,121,64,2129,3124,2048,2048,1136,112,117,113,3109,513]

theorem envBound11480 : H12AffineFastState.Bounded env11480 := by
  intro p hp
  have h : env11480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11479_11480 : H12AffineEnvironment.transform 7 116 env11479 = env11480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env11479 == env11480) = true)

def env11481 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507600,9356288,25265169,23160257,525568,27902125,27337992,25733063]

theorem envBound11481 : H12AffineFastState.Bounded env11481 := by
  intro p hp
  have h : env11481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11049_11481 : H12AffineEnvironment.transform 26 30393345 env11049 = env11481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env11049 == env11481) = true)

def env11482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830976,25265169,23160257,256,27378861,27337992,25207751]

theorem envBound11482 : H12AffineFastState.Bounded env11482 := by
  intro p hp
  have h : env11482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11481_11482 : H12AffineEnvironment.transform 18 1024 env11481 = env11482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env11481 == env11482) = true)

theorem identity11482 : scanCanonicalize (H12AffineFastState.compose env11482 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 41310) := by decide +kernel

theorem selectedBound11482 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env11483 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,41310,8328,64,13066591,2172370,10507600,8830976,8463695,6407327,256,10577395,10585174,8389273]

theorem envBound11483 : H12AffineFastState.Bounded env11483 := by
  intro p hp
  have h : env11483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11482_11483 : H12AffineEnvironment.transform 23 41310 env11482 = env11483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41310 env11482 == env11483) = true)

def env11484 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,41310,8192,64,13066591,2172250,10507600,8830976,8463695,6407191,256,10577275,10585174,8389137]

theorem envBound11484 : H12AffineFastState.Bounded env11484 := by
  intro p hp
  have h : env11484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11483_11484 : H12AffineEnvironment.transform 6 8 env11483 = env11484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11483 == env11484) = true)

def env11485 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,41310,8192,64,4677967,2172250,2118976,442384,75103,6407191,256,2188651,2196550,513]

theorem envBound11485 : H12AffineFastState.Bounded env11485 := by
  intro p hp
  have h : env11485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11484_11485 : H12AffineEnvironment.transform 22 16 env11484 = env11485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env11484 == env11485) = true)

def env11486 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41310,8192,64,4677967,115014,45404,442384,75103,4268043,256,98679,90202,513]

theorem envBound11486 : H12AffineFastState.Bounded env11486 := by
  intro p hp
  have h : env11486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11485_11486 : H12AffineEnvironment.transform 20 58396 env11485 = env11486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env11485 == env11486) = true)

theorem identity11486 : scanCanonicalize (H12AffineFastState.compose env11486 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound11486 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11487 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,58396,4194304,16,41310,8192,64,4604228,57677,45404,442384,1364,4194304,256,41340,16465,513]

theorem envBound11487 : H12AffineFastState.Bounded env11487 := by
  intro p hp
  have h : env11487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11486_11487 : H12AffineEnvironment.transform 15 8203 env11486 = env11487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env11486 == env11487) = true)

theorem identity11487 : scanCanonicalize (H12AffineFastState.compose env11487 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 419912) := by decide +kernel

theorem selectedBound11487 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env11488 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,58396,419912,16,41310,8192,64,10508,57677,45404,442384,1364,419912,256,41340,16465,513]

theorem envBound11488 : H12AffineFastState.Bounded env11488 := by
  intro p hp
  have h : env11488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11487_11488 : H12AffineEnvironment.transform 21 419912 env11487 = env11488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 419912 env11487 == env11488) = true)

def env11489 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16448,262144,1024,32769,58396,272392,16,41310,8192,64,10508,57677,45404,294992,1364,272392,256,41340,16465,513]

theorem envBound11489 : H12AffineFastState.Bounded env11489 := by
  intro p hp
  have h : env11489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11488_11489 : H12AffineEnvironment.transform 16 16448 env11488 = env11489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env11488 == env11489) = true)

theorem identity11489 : scanCanonicalize (H12AffineFastState.compose env11489 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound11489 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11490 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,8203,16448,262144,1024,1,25628,272392,16,8542,8192,64,10508,24909,12636,262224,1364,272392,256,8572,16465,513]

theorem envBound11490 : H12AffineFastState.Bounded env11490 := by
  intro p hp
  have h : env11490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11489_11490 : H12AffineEnvironment.transform 14 0 env11489 = env11490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env11489 == env11490) = true)

theorem identity11490 : scanCanonicalize (H12AffineFastState.compose env11490 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10361) := by decide +kernel

theorem selectedBound11490 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11491 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,8203,16448,10361,1024,1,25628,113,16,8542,8192,64,10508,24909,12636,10281,1364,113,256,8572,16465,513]

theorem envBound11491 : H12AffineFastState.Bounded env11491 := by
  intro p hp
  have h : env11491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11490_11491 : H12AffineEnvironment.transform 17 10361 env11490 = env11491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10361 env11490 == env11491) = true)

theorem identity11491 : scanCanonicalize (H12AffineFastState.compose env11491 (packedSelected [11,32] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound11491 : packedSelected [11,32] rootPS < 2^1333 := by decide +kernel

def env11492 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,0,262,16448,2420,1024,1,17681,113,16,83,269,64,2049,16448,4177,2340,1364,113,256,113,16465,513]

theorem envBound11492 : H12AffineFastState.Bounded env11492 := by
  intro p hp
  have h : env11492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11491_11492 : H12AffineEnvironment.transform 12 269 env11491 = env11492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env11491 == env11492) = true)

theorem identity11492 : scanCanonicalize (H12AffineFastState.compose env11492 (packedSelected [2,3,4,5,7,11] rootPS)) = affineNative (2^(13+1) ^^^ 0) := by decide +kernel

theorem selectedBound11492 : packedSelected [2,3,4,5,7,11] rootPS < 2^1333 := by decide +kernel

def env11493 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,0,0,262,64,2420,1024,1,1297,113,16,83,269,64,2049,64,4177,2340,1364,113,256,113,81,513]

theorem envBound11493 : H12AffineFastState.Bounded env11493 := by
  intro p hp
  have h : env11493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11492_11493 : H12AffineEnvironment.transform 13 0 env11492 = env11493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env11492 == env11493) = true)

theorem identity11493 : scanCanonicalize (H12AffineFastState.compose env11493 (packedSelected [0,1,2,4,7,8,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11493 : packedSelected [0,1,2,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env11494 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,0,0,262,16,2340,1024,1,1297,33,16,3,269,16,2049,16,4097,2340,1284,33,256,33,1,513]

theorem envBound11494 : H12AffineFastState.Bounded env11494 := by
  intro p hp
  have h : env11494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11493_11494 : H12AffineEnvironment.transform 5 16 env11493 = env11494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11493 == env11494) = true)

theorem identity11494 : scanCanonicalize (H12AffineFastState.compose env11494 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound11494 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11495 : List Nat := [2,4,8,1,32,1,8,256,512,1024,2048,4096,269,0,0,262,1,2340,1024,1,1280,33,1,3,269,1,2049,1,4097,2340,1284,33,256,33,1,513]

theorem envBound11495 : H12AffineFastState.Bounded env11495 := by
  intro p hp
  have h : env11495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11494_11495 : H12AffineEnvironment.transform 3 1 env11494 = env11495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env11494 == env11495) = true)

theorem identity11495 : scanCanonicalize (H12AffineFastState.compose env11495 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2350) := by decide +kernel

theorem selectedBound11495 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11496 : List Nat := [2,4,8,1,32,1,8,256,512,1024,2048,2350,269,0,0,262,1,2340,1024,1,1280,33,1,3,269,1,2049,1,2351,2340,1284,33,256,33,1,513]

theorem envBound11496 : H12AffineFastState.Bounded env11496 := by
  intro p hp
  have h : env11496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11495_11496 : H12AffineEnvironment.transform 11 2350 env11495 = env11496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2350 env11495 == env11496) = true)

theorem identity11496 : scanCanonicalize (H12AffineFastState.compose env11496 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound11496 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11497 : List Nat := [2,4,8,1,32,1,8,4,512,1024,2048,2090,9,0,0,2,1,2080,1024,1,1028,33,1,3,9,1,2049,1,2091,2080,1024,33,4,33,1,513]

theorem envBound11497 : H12AffineFastState.Bounded env11497 := by
  intro p hp
  have h : env11497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11496_11497 : H12AffineEnvironment.transform 7 4 env11496 = env11497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env11496 == env11497) = true)

theorem identity11497 : scanCanonicalize (H12AffineFastState.compose env11497 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound11497 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env11498 : List Nat := [2,4,8,1,32,1,8,4,512,1024,1038,1060,9,0,0,2,1,1070,1024,1,1028,33,1,3,9,1,1039,1,1061,1070,1024,33,4,33,1,513]

theorem envBound11498 : H12AffineFastState.Bounded env11498 := by
  intro p hp
  have h : env11498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11497_11498 : H12AffineEnvironment.transform 10 1038 env11497 = env11498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env11497 == env11498) = true)

theorem identity11498 : scanCanonicalize (H12AffineFastState.compose env11498 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound11498 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11499 : List Nat := [2,4,8,1,10,1,8,4,512,1024,1038,1038,9,0,0,2,1,1028,1024,1,1028,11,1,3,9,1,1039,1,1039,1028,1024,11,4,11,1,513]

theorem envBound11499 : H12AffineFastState.Bounded env11499 := by
  intro p hp
  have h : env11499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11498_11499 : H12AffineEnvironment.transform 4 10 env11498 = env11499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env11498 == env11499) = true)

def env11500 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16449,262144,1024,32769,58396,272393,16,41310,8192,64,10508,57677,45404,294993,1364,272393,256,41340,16465,513]

theorem envBound11500 : H12AffineFastState.Bounded env11500 := by
  intro p hp
  have h : env11500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11488_11500 : H12AffineEnvironment.transform 16 16449 env11488 = env11500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env11488 == env11500) = true)

theorem identity11500 : scanCanonicalize (H12AffineFastState.compose env11500 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound11500 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11501 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8460,8203,16449,262144,1024,8461,17680,272393,16,82,8192,64,10508,16449,4176,270685,1364,272393,256,112,16465,513]

theorem envBound11501 : H12AffineFastState.Bounded env11501 := by
  intro p hp
  have h : env11501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11500_11501 : H12AffineEnvironment.transform 14 8460 env11500 = env11501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env11500 == env11501) = true)

theorem identity11501 : scanCanonicalize (H12AffineFastState.compose env11501 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound11501 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env11502 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,81,342,16449,262144,1024,80,17680,264532,16,82,349,64,2129,16449,4176,262144,1364,264532,256,112,16465,513]

theorem envBound11502 : H12AffineFastState.Bounded env11502 := by
  intro p hp
  have h : env11502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11501_11502 : H12AffineEnvironment.transform 12 349 env11501 = env11502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env11501 == env11502) = true)

theorem identity11502 : scanCanonicalize (H12AffineFastState.compose env11502 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound11502 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11503 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,81,342,16449,2420,1024,80,17680,32,16,82,349,64,2129,16449,4176,2420,1364,32,256,112,16465,513]

theorem envBound11503 : H12AffineFastState.Bounded env11503 := by
  intro p hp
  have h : env11503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11502_11503 : H12AffineEnvironment.transform 17 2420 env11502 = env11503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env11502 == env11503) = true)

theorem identity11503 : scanCanonicalize (H12AffineFastState.compose env11503 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11503 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11504 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,1,262,16401,2340,1024,0,17680,32,16,2,269,16,2049,16401,4096,2340,1284,32,256,32,16385,513]

theorem envBound11504 : H12AffineFastState.Bounded env11504 := by
  intro p hp
  have h : env11504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11503_11504 : H12AffineEnvironment.transform 5 16 env11503 = env11504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11503 == env11504) = true)

theorem identity11504 : scanCanonicalize (H12AffineFastState.compose env11504 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11504 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11505 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,4096,269,16384,1,262,16401,2308,1024,0,17680,0,16,2,269,16,2049,16401,4096,2308,1284,0,256,0,16385,513]

end H12CloudChart0