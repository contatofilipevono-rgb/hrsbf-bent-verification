import H12CloudChart0Data068

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound17382 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env17383 : List Nat := [2,4,8,16,1,16,9,4,10,21,1,16,8,0,0,3,16,1,20,1,1,1,17,3,9,17,0,16,17,0,20,0,5,0,0,11]

theorem envBound17383 : H12AffineFastState.Bounded env17383 := by
  intro p hp
  have h : env17383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17382_17383 : H12AffineEnvironment.transform 4 1 env17382 = env17383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17382 == env17383) = true)

theorem identity17383 : scanCanonicalize (H12AffineFastState.compose env17383 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound17383 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17384 : List Nat := [2,0,8,16,1,16,9,0,10,17,1,16,8,0,0,3,16,1,16,1,1,1,17,3,9,17,0,16,17,0,16,0,1,0,0,11]

theorem envBound17384 : H12AffineFastState.Bounded env17384 := by
  intro p hp
  have h : env17384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17383_17384 : H12AffineEnvironment.transform 1 0 env17383 = env17384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env17383 == env17384) = true)

theorem identity17384 : scanCanonicalize (H12AffineFastState.compose env17384 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound17384 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17385 : List Nat := [2,0,8,2,1,2,9,0,10,3,1,2,8,0,0,3,2,1,2,1,1,1,3,3,9,3,0,2,3,0,2,0,1,0,0,11]

theorem envBound17385 : H12AffineFastState.Bounded env17385 := by
  intro p hp
  have h : env17385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17384_17385 : H12AffineEnvironment.transform 3 2 env17384 = env17385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env17384 == env17385) = true)

def env17386 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1076,4096,8192,16384,8461,65536,82198,9245,1025,8460,91418,4194304,17,3,8193,16,4195349,16400,77834,66583,75023,4194305,257,33,16385,513]

theorem envBound17386 : H12AffineFastState.Bounded env17386 := by
  intro p hp
  have h : env17386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17373_17386 : H12AffineEnvironment.transform 5 17 env17373 = env17386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17373 == env17386) = true)

theorem identity17386 : scanCanonicalize (H12AffineFastState.compose env17386 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound17386 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env17387 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1076,4096,8192,16384,8461,262,16400,9245,1025,8460,25628,4194304,17,3,8193,16,4195349,16400,12556,1297,9225,4194305,257,33,16385,513]

theorem envBound17387 : H12AffineFastState.Bounded env17387 := by
  intro p hp
  have h : env17387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17386_17387 : H12AffineEnvironment.transform 15 262 env17386 = env17387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env17386 == env17387) = true)

theorem identity17387 : scanCanonicalize (H12AffineFastState.compose env17387 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound17387 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env17388 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1076,4096,8192,16384,8461,262,16400,9245,1025,8460,25628,32,17,3,8193,16,1077,16400,12556,1297,9225,33,257,33,16385,513]

theorem envBound17388 : H12AffineFastState.Bounded env17388 := by
  intro p hp
  have h : env17388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17387_17388 : H12AffineEnvironment.transform 21 32 env17387 = env17388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env17387 == env17388) = true)

theorem identity17388 : scanCanonicalize (H12AffineFastState.compose env17388 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 9529) := by decide +kernel

theorem selectedBound17388 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env17389 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1076,4096,8192,9529,8461,262,9513,9245,1025,8460,293,32,17,3,8193,16,1077,9513,12556,1297,9225,33,257,33,9528,513]

theorem envBound17389 : H12AffineFastState.Bounded env17389 := by
  intro p hp
  have h : env17389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17388_17389 : H12AffineEnvironment.transform 13 9529 env17388 = env17389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9529 env17388 == env17389) = true)

theorem identity17389 : scanCanonicalize (H12AffineFastState.compose env17389 (packedSelected [12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound17389 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env17390 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1076,4096,269,1076,0,262,1060,1296,1025,1,293,32,17,3,268,16,1077,1060,4097,1297,1284,33,257,33,1077,513]

theorem envBound17390 : H12AffineFastState.Bounded env17390 := by
  intro p hp
  have h : env17390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17389_17390 : H12AffineEnvironment.transform 12 269 env17389 = env17390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env17389 == env17390) = true)

theorem identity17390 : scanCanonicalize (H12AffineFastState.compose env17390 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound17390 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17391 : List Nat := [2,4,8,16,32,17,9,256,512,52,0,4096,269,0,0,262,16,292,53,1,293,32,17,3,268,16,1,16,4097,293,304,33,257,33,1,513]

theorem envBound17391 : H12AffineFastState.Bounded env17391 := by
  intro p hp
  have h : env17391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17390_17391 : H12AffineEnvironment.transform 9 52 env17390 = env17391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env17390 == env17391) = true)

theorem identity17391 : scanCanonicalize (H12AffineFastState.compose env17391 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 302) := by decide +kernel

theorem selectedBound17391 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17392 : List Nat := [2,4,8,16,32,17,9,256,302,52,0,4096,269,0,0,262,16,292,53,1,293,32,17,3,268,16,1,16,4097,293,304,33,257,33,1,303]

theorem envBound17392 : H12AffineFastState.Bounded env17392 := by
  intro p hp
  have h : env17392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17391_17392 : H12AffineEnvironment.transform 8 302 env17391 = env17392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 302 env17391 == env17392) = true)

theorem identity17392 : scanCanonicalize (H12AffineFastState.compose env17392 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound17392 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17393 : List Nat := [2,4,8,16,32,17,9,256,302,52,0,276,269,0,0,262,16,292,53,1,293,32,17,3,268,16,1,16,277,293,304,33,257,33,1,303]

theorem envBound17393 : H12AffineFastState.Bounded env17393 := by
  intro p hp
  have h : env17393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17392_17393 : H12AffineEnvironment.transform 11 276 env17392 = env17393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env17392 == env17393) = true)

def env17394 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507600,9356288,25265168,23160257,525568,27902125,27337993,25733063]

theorem envBound17394 : H12AffineFastState.Bounded env17394 := by
  intro p hp
  have h : env17394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17123_17394 : H12AffineEnvironment.transform 26 30393345 env17123 = env17394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env17123 == env17394) = true)

def env17395 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830976,25265168,23160257,256,27378861,27337993,25207751]

theorem envBound17395 : H12AffineFastState.Bounded env17395 := by
  intro p hp
  have h : env17395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17394_17395 : H12AffineEnvironment.transform 18 1024 env17394 = env17395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env17394 == env17395) = true)

theorem identity17395 : scanCanonicalize (H12AffineFastState.compose env17395 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2534899) := by decide +kernel

theorem selectedBound17395 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env17396 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2534899,8328,65,14773746,469375,10507600,8830976,10955235,4704306,256,8874334,8882426,10882612]

theorem envBound17396 : H12AffineFastState.Bounded env17396 := by
  intro p hp
  have h : env17396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17395_17396 : H12AffineEnvironment.transform 23 2534899 env17395 = env17396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2534899 env17395 == env17396) = true)

def env17397 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,2097152,4194304,8388608,2114883,8328,65,14773746,115151,10507600,8399024,10600787,4268162,256,8487406,8478794,10544772]

theorem envBound17397 : H12AffineFastState.Bounded env17397 := by
  intro p hp
  have h : env17397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17396_17397 : H12AffineEnvironment.transform 17 190640 env17396 = env17397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190640 env17396 == env17397) = true)

def env17398 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,2097152,4194304,2101328,2114883,8328,65,4292002,115151,17664,2111712,119043,4268162,256,2199998,2191386,63188]

theorem envBound17398 : H12AffineFastState.Bounded env17398 := by
  intro p hp
  have h : env17398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17397_17398 : H12AffineEnvironment.transform 22 2101328 env17397 = env17398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env17397 == env17398) = true)

def env17399 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4160,4194304,16,21763,8328,65,4292002,115151,17664,10400,119043,4268162,256,98814,90202,63188]

theorem envBound17399 : H12AffineFastState.Bounded env17399 := by
  intro p hp
  have h : env17399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17398_17399 : H12AffineEnvironment.transform 20 4160 env17398 = env17399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env17398 == env17399) = true)

def env17400 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,4194304,16,21763,8192,65,4291882,115015,17664,10280,119043,4268042,256,98678,90202,63068]

theorem envBound17400 : H12AffineFastState.Bounded env17400 := by
  intro p hp
  have h : env17400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17399_17400 : H12AffineEnvironment.transform 6 8 env17399 = env17400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17399 == env17400) = true)

theorem identity17400 : scanCanonicalize (H12AffineFastState.compose env17400 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound17400 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17401 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,32040,1024,32769,4160,4194304,16,21763,8192,65,4291882,115015,17664,10280,119043,4268042,256,98678,90202,63068]

theorem envBound17401 : H12AffineFastState.Bounded env17401 := by
  intro p hp
  have h : env17401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17400_17401 : H12AffineEnvironment.transform 16 38160 env17400 = env17401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env17400 == env17401) = true)

theorem identity17401 : scanCanonicalize (H12AffineFastState.compose env17401 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound17401 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env17402 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62730,38160,32040,1024,32769,4160,4194304,16,21763,8192,65,4229152,13389,17664,10280,9225,4248832,256,29820,38224,63068]

theorem envBound17402 : H12AffineFastState.Bounded env17402 := by
  intro p hp
  have h : env17402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17401_17402 : H12AffineEnvironment.transform 15 62730 env17401 = env17402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env17401 == env17402) = true)

theorem identity17402 : scanCanonicalize (H12AffineFastState.compose env17402 (packedSelected [0,5,7,9,12,14,16,22,24,26,38] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound17402 : packedSelected [0,5,7,9,12,14,16,22,24,26,38] rootPS < 2^1333 := by decide +kernel

def env17403 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,62591,37989,31837,1024,32769,4160,4194304,16,21622,8192,65,4229152,13389,17525,10280,9225,4248693,117,29820,37925,63068]

theorem envBound17403 : H12AffineFastState.Bounded env17403 := by
  intro p hp
  have h : env17403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17402_17403 : H12AffineEnvironment.transform 7 117 env17402 = env17403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env17402 == env17403) = true)

theorem identity17403 : scanCanonicalize (H12AffineFastState.compose env17403 (packedSelected [0,2,4,6,7,8,9,10,12,14,15,18,28,32] rootPS)) = affineNative (2^(21+1) ^^^ 21588) := by decide +kernel

theorem selectedBound17403 : packedSelected [0,2,4,6,7,8,9,10,12,14,15,18,28,32] rootPS < 2^1333 := by decide +kernel

def env17404 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,62591,37989,31837,1024,32769,4160,21588,16,21622,8192,65,56436,13389,17525,10280,9225,32801,117,29820,37925,63068]

theorem envBound17404 : H12AffineFastState.Bounded env17404 := by
  intro p hp
  have h : env17404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17403_17404 : H12AffineEnvironment.transform 21 21588 env17403 = env17404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21588 env17403 == env17404) = true)

theorem identity17404 : scanCanonicalize (H12AffineFastState.compose env17404 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 21621) := by decide +kernel

theorem selectedBound17404 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env17405 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,21621,8202,16400,31837,1024,21620,4160,21588,16,21622,8192,65,2049,13389,17525,10280,9225,21588,117,29820,16464,8745]

theorem envBound17405 : H12AffineFastState.Bounded env17405 := by
  intro p hp
  have h : env17405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17404_17405 : H12AffineEnvironment.transform 14 21621 env17404 = env17405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21621 env17404 == env17405) = true)

theorem identity17405 : scanCanonicalize (H12AffineFastState.compose env17405 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound17405 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env17406 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,13325,8312,8202,13341,2128,1024,8313,4160,8281,16,8315,8192,65,2049,13389,12408,10280,9225,8281,117,113,13405,8745]

theorem envBound17406 : H12AffineFastState.Bounded env17406 := by
  intro p hp
  have h : env17406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17405_17406 : H12AffineEnvironment.transform 13 13325 env17405 = env17406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env17405 == env17406) = true)

theorem identity17406 : scanCanonicalize (H12AffineFastState.compose env17406 (packedSelected [0,1,4,8,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 6200) := by decide +kernel

theorem selectedBound17406 : packedSelected [0,1,4,8,11,12] rootPS < 2^1333 := by decide +kernel

def env17407 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,6200,3125,6208,6194,3109,2128,1024,6209,4160,6241,16,6211,6200,65,2049,3189,2112,4112,7217,6241,117,113,3173,6673]

theorem envBound17407 : H12AffineFastState.Bounded env17407 := by
  intro p hp
  have h : env17407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17406_17407 : H12AffineEnvironment.transform 12 6200 env17406 = env17407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6200 env17406 == env17407) = true)

theorem identity17407 : scanCanonicalize (H12AffineFastState.compose env17407 (packedSelected [0,1,6,7,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound17407 : packedSelected [0,1,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env17408 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,4096,6200,2048,6208,6194,2064,2128,53,6209,4160,6241,16,6211,6200,65,2049,2112,2112,4112,6148,6241,117,113,2128,6673]

theorem envBound17408 : H12AffineFastState.Bounded env17408 := by
  intro p hp
  have h : env17408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17407_17408 : H12AffineEnvironment.transform 9 53 env17407 = env17408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env17407 == env17408) = true)

theorem identity17408 : scanCanonicalize (H12AffineFastState.compose env17408 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound17408 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env17409 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,2113,121,2048,1,115,2064,2128,53,0,2049,32,16,2,121,65,2049,2112,2112,2129,69,32,117,113,2128,592]

theorem envBound17409 : H12AffineFastState.Bounded env17409 := by
  intro p hp
  have h : env17409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17408_17409 : H12AffineEnvironment.transform 11 2113 env17408 = env17409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env17408 == env17409) = true)

theorem identity17409 : scanCanonicalize (H12AffineFastState.compose env17409 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17409 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env17410 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,2064,40,2048,1,34,2064,2049,53,0,2049,32,16,2,40,16,2049,2065,2065,2048,20,32,36,32,2049,513]

theorem envBound17410 : H12AffineFastState.Bounded env17410 := by
  intro p hp
  have h : env17410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17409_17410 : H12AffineEnvironment.transform 5 17 env17409 = env17410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17409 == env17410) = true)

theorem identity17410 : scanCanonicalize (H12AffineFastState.compose env17410 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17410 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17411 : List Nat := [2,4,8,16,0,17,8,4,512,21,2048,2064,8,2048,1,2,2064,2049,21,0,2049,0,16,2,8,16,2049,2065,2065,2048,20,0,4,0,2049,513]

theorem envBound17411 : H12AffineFastState.Bounded env17411 := by
  intro p hp
  have h : env17411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17410_17411 : H12AffineEnvironment.transform 4 0 env17410 = env17411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17410 == env17411) = true)

theorem identity17411 : scanCanonicalize (H12AffineFastState.compose env17411 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound17411 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17412 : List Nat := [2,4,8,16,0,17,8,4,512,21,17,1,8,17,1,2,1,16,21,0,16,0,16,2,8,16,16,0,0,17,20,0,4,0,16,513]

theorem envBound17412 : H12AffineFastState.Bounded env17412 := by
  intro p hp
  have h : env17412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17411_17412 : H12AffineEnvironment.transform 10 17 env17411 = env17412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env17411 == env17412) = true)

theorem identity17412 : scanCanonicalize (H12AffineFastState.compose env17412 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound17412 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env17413 : List Nat := [2,4,8,16,0,17,8,4,0,21,17,1,8,17,1,2,1,16,21,0,16,0,16,2,8,16,16,0,0,17,20,0,4,0,16,1]

theorem envBound17413 : H12AffineFastState.Bounded env17413 := by
  intro p hp
  have h : env17413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17412_17413 : H12AffineEnvironment.transform 8 0 env17412 = env17413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env17412 == env17413) = true)

theorem identity17413 : scanCanonicalize (H12AffineFastState.compose env17413 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17413 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env17414 : List Nat := [2,4,8,1,0,0,8,4,0,4,0,1,8,0,1,2,1,1,4,0,1,0,1,2,8,1,1,0,0,0,5,0,4,0,1,1]

theorem envBound17414 : H12AffineFastState.Bounded env17414 := by
  intro p hp
  have h : env17414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17413_17414 : H12AffineEnvironment.transform 3 1 env17413 = env17414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17413 == env17414) = true)

def env17415 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,4194304,16,21763,8193,65,4291883,115014,17664,10281,119043,4268043,256,98679,90202,63069]

theorem envBound17415 : H12AffineFastState.Bounded env17415 := by
  intro p hp
  have h : env17415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17399_17415 : H12AffineEnvironment.transform 6 9 env17399 = env17415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17399 == env17415) = true)

theorem identity17415 : scanCanonicalize (H12AffineFastState.compose env17415 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound17415 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17416 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13388,56437,1024,32769,4160,4194304,16,21763,8193,65,4291883,115014,17664,10281,119043,4268043,256,98679,90202,63069]

theorem envBound17416 : H12AffineFastState.Bounded env17416 := by
  intro p hp
  have h : env17416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17415_17416 : H12AffineEnvironment.transform 16 13388 env17415 = env17416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env17415 == env17416) = true)

theorem identity17416 : scanCanonicalize (H12AffineFastState.compose env17416 (packedSelected [0,1,2,4,6,7,8,10,14,15,16,18,19,22,26] rootPS)) = affineNative (2^(21+1) ^^^ 87159) := by decide +kernel

theorem selectedBound17416 : packedSelected [0,1,2,4,6,7,8,10,14,15,16,18,19,22,26] rootPS < 2^1333 := by decide +kernel

def env17417 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13388,56437,1024,32769,4160,87159,16,21763,8193,65,10588,115014,17664,10281,119043,29820,256,98679,90202,63069]

theorem envBound17417 : H12AffineFastState.Bounded env17417 := by
  intro p hp
  have h : env17417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17416_17417 : H12AffineEnvironment.transform 21 87159 env17416 = env17417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 87159 env17416 == env17417) = true)

theorem identity17417 : scanCanonicalize (H12AffineFastState.compose env17417 (packedSelected [2,3,5,6,14,15,18,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound17417 : packedSelected [2,3,5,6,14,15,18,19,20] rootPS < 2^1333 := by decide +kernel

def env17418 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,65536,13388,23668,1024,0,4160,87159,16,21763,8193,65,10588,82247,17664,10281,86274,29820,256,65910,90202,30300]

theorem envBound17418 : H12AffineFastState.Bounded env17418 := by
  intro p hp
  have h : env17418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17417_17418 : H12AffineEnvironment.transform 14 1 env17417 = env17418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env17417 == env17418) = true)

theorem identity17418 : scanCanonicalize (H12AffineFastState.compose env17418 (packedSelected [1,4,8,9,11,14,16,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound17418 : packedSelected [1,4,8,9,11,14,16,18,19] rootPS < 2^1333 := by decide +kernel

def env17419 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,1,65536,5393,23668,1024,0,4160,87159,16,21763,348,65,2049,82247,17664,2420,86274,21793,256,65910,82183,22273]

theorem envBound17419 : H12AffineFastState.Bounded env17419 := by
  intro p hp
  have h : env17419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17418_17419 : H12AffineEnvironment.transform 12 349 env17418 = env17419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env17418 == env17419) = true)

theorem identity17419 : scanCanonicalize (H12AffineFastState.compose env17419 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound17419 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env17420 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,1,21590,5393,23668,1024,0,4160,33,16,21763,348,65,2049,5393,17664,2420,1364,21793,256,21792,5457,22273]

theorem envBound17420 : H12AffineFastState.Bounded env17420 := by
  intro p hp
  have h : env17420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17419_17420 : H12AffineEnvironment.transform 15 21590 env17419 = env17420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env17419 == env17420) = true)

theorem identity17420 : scanCanonicalize (H12AffineFastState.compose env17420 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5408) := by decide +kernel

theorem selectedBound17420 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env17421 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5408,1,374,5393,2388,1024,0,4160,33,16,35,348,65,2049,5393,4128,2420,1364,1,256,0,5457,545]

theorem envBound17421 : H12AffineFastState.Bounded env17421 := by
  intro p hp
  have h : env17421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17420_17421 : H12AffineEnvironment.transform 13 5408 env17420 = env17421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5408 env17420 == env17421) = true)

theorem identity17421 : scanCanonicalize (H12AffineFastState.compose env17421 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound17421 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env17422 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,300,5408,1,263,5393,2341,1024,0,4145,33,16,35,301,48,2049,5393,4128,2309,1317,1,256,0,5408,545]

theorem envBound17422 : H12AffineFastState.Bounded env17422 := by
  intro p hp
  have h : env17422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17421_17422 : H12AffineEnvironment.transform 5 49 env17421 = env17422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env17421 == env17422) = true)

theorem identity17422 : scanCanonicalize (H12AffineFastState.compose env17422 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17422 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17423 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,4096,269,5377,1,263,5393,2308,1024,0,4112,0,16,2,268,17,2049,5393,4097,2309,1284,1,256,0,5377,512]

theorem envBound17423 : H12AffineFastState.Bounded env17423 := by
  intro p hp
  have h : env17423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17422_17423 : H12AffineEnvironment.transform 4 1 env17422 = env17423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17422 == env17423) = true)

theorem identity17423 : scanCanonicalize (H12AffineFastState.compose env17423 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17423 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17424 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,4096,9,5125,1,3,5141,2048,1024,0,4112,0,16,2,8,17,2049,5141,4097,2049,1024,1,4,0,5125,512]

theorem envBound17424 : H12AffineFastState.Bounded env17424 := by
  intro p hp
  have h : env17424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17423_17424 : H12AffineEnvironment.transform 7 4 env17423 = env17424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17423 == env17424) = true)

theorem identity17424 : scanCanonicalize (H12AffineFastState.compose env17424 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1567) := by decide +kernel

theorem selectedBound17424 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17425 : List Nat := [2,4,8,16,1,16,9,4,512,1024,1567,4096,9,5125,1,3,5141,1567,1024,0,4112,0,16,2,8,17,1566,5141,4097,1566,1024,1,4,0,5125,512]

theorem envBound17425 : H12AffineFastState.Bounded env17425 := by
  intro p hp
  have h : env17425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17424_17425 : H12AffineEnvironment.transform 10 1567 env17424 = env17425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1567 env17424 == env17425) = true)

theorem identity17425 : scanCanonicalize (H12AffineFastState.compose env17425 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1541) := by decide +kernel

theorem selectedBound17425 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17426 : List Nat := [2,4,8,16,1,16,9,4,512,1024,1567,1541,9,512,1,3,528,1567,1024,0,1557,0,16,2,8,17,1566,528,1540,1566,1024,1,4,0,512,512]

theorem envBound17426 : H12AffineFastState.Bounded env17426 := by
  intro p hp
  have h : env17426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17425_17426 : H12AffineEnvironment.transform 11 1541 env17425 = env17426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1541 env17425 == env17426) = true)

theorem identity17426 : scanCanonicalize (H12AffineFastState.compose env17426 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound17426 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env17427 : List Nat := [2,4,8,16,1,16,9,4,512,15,528,522,9,512,1,3,528,528,15,0,538,0,16,2,8,17,529,528,523,529,15,1,4,0,512,512]

theorem envBound17427 : H12AffineFastState.Bounded env17427 := by
  intro p hp
  have h : env17427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17426_17427 : H12AffineEnvironment.transform 9 15 env17426 = env17427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env17426 == env17427) = true)

theorem identity17427 : scanCanonicalize (H12AffineFastState.compose env17427 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound17427 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17428 : List Nat := [2,4,8,11,1,11,9,4,512,15,523,522,9,512,1,3,523,523,15,0,513,0,11,2,8,10,522,523,523,522,15,1,4,0,512,512]

theorem envBound17428 : H12AffineFastState.Bounded env17428 := by
  intro p hp
  have h : env17428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17427_17428 : H12AffineEnvironment.transform 3 11 env17427 = env17428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env17427 == env17428) = true)

theorem identity17428 : scanCanonicalize (H12AffineFastState.compose env17428 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound17428 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17429 : List Nat := [2,4,8,11,1,11,9,4,4,15,15,14,9,4,1,3,15,15,15,0,5,0,11,2,8,10,14,15,15,14,15,1,4,0,4,4]

theorem envBound17429 : H12AffineFastState.Bounded env17429 := by
  intro p hp
  have h : env17429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17428_17429 : H12AffineEnvironment.transform 8 4 env17428 = env17429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env17428 == env17429) = true)

theorem identity17429 : scanCanonicalize (H12AffineFastState.compose env17429 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound17429 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17430 : List Nat := [1,4,8,8,1,8,9,4,4,12,12,13,9,4,1,0,12,12,12,0,5,0,8,1,8,9,13,12,12,13,12,1,4,0,4,4]

theorem envBound17430 : H12AffineFastState.Bounded env17430 := by
  intro p hp
  have h : env17430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17429_17430 : H12AffineEnvironment.transform 0 1 env17429 = env17430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env17429 == env17430) = true)

def env17431 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4161,4194304,17,21762,8328,65,4292002,115151,17664,10401,119043,4268162,256,98815,90203,63188]

theorem envBound17431 : H12AffineFastState.Bounded env17431 := by
  intro p hp
  have h : env17431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17398_17431 : H12AffineEnvironment.transform 20 4161 env17398 = env17431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env17398 == env17431) = true)

theorem identity17431 : scanCanonicalize (H12AffineFastState.compose env17431 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 180273) := by decide +kernel

theorem selectedBound17431 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17432 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4161,180273,17,21762,8328,65,245139,115151,17664,10401,119043,254131,256,98815,90203,63188]

theorem envBound17432 : H12AffineFastState.Bounded env17432 := by
  intro p hp
  have h : env17432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17431_17432 : H12AffineEnvironment.transform 21 180273 env17431 = env17432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180273 env17431 == env17432) = true)

def env17433 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,180273,17,21762,8192,65,245019,115015,17664,10281,119043,254011,256,98679,90203,63068]

theorem envBound17433 : H12AffineFastState.Bounded env17433 := by
  intro p hp
  have h : env17433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17432_17433 : H12AffineEnvironment.transform 6 8 env17432 = env17433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17432 == env17433) = true)

theorem identity17433 : scanCanonicalize (H12AffineFastState.compose env17433 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound17433 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17434 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,179512,1024,32769,4161,169265,17,2,8192,65,245019,103495,4096,10281,99331,243003,256,98679,79195,41820]

theorem envBound17434 : H12AffineFastState.Bounded env17434 := by
  intro p hp
  have h : env17434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17433_17434 : H12AffineEnvironment.transform 13 5376 env17433 = env17434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env17433 == env17434) = true)

theorem identity17434 : scanCanonicalize (H12AffineFastState.compose env17434 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17434 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env17435 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,179512,1024,32769,4113,169265,17,2,8192,17,245019,103447,4096,10281,99331,243003,256,98599,79115,41740]

theorem envBound17435 : H12AffineFastState.Bounded env17435 := by
  intro p hp
  have h : env17435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17434_17435 : H12AffineEnvironment.transform 5 16 env17434 = env17435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17434 == env17435) = true)

theorem identity17435 : scanCanonicalize (H12AffineFastState.compose env17435 (packedSelected [0,7,9,10,11,12,15,19,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound17435 : packedSelected [0,7,9,10,11,12,15,19,22,23] rootPS < 2^1333 := by decide +kernel

def env17436 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,32768,33031,131072,179512,1024,32769,4113,169265,17,2,8192,17,146460,5392,4096,10281,1284,144444,256,32,46092,41740]

theorem envBound17436 : H12AffineFastState.Bounded env17436 := by
  intro p hp
  have h : env17436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17435_17436 : H12AffineEnvironment.transform 15 33031 env17435 = env17436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env17435 == env17436) = true)

theorem identity17436 : scanCanonicalize (H12AffineFastState.compose env17436 (packedSelected [0,1,2,4,7,8,9,12,15,19] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound17436 : packedSelected [0,1,2,4,7,8,9,12,15,19] rootPS < 2^1333 := by decide +kernel

def env17437 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,32768,33031,5392,43048,1024,32769,4113,32801,17,2,8192,17,10508,5392,4096,10281,1284,8492,256,32,46092,41740]

theorem envBound17437 : H12AffineFastState.Bounded env17437 := by
  intro p hp
  have h : env17437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17436_17437 : H12AffineEnvironment.transform 16 5392 env17436 = env17437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env17436 == env17437) = true)

theorem identity17437 : scanCanonicalize (H12AffineFastState.compose env17437 (packedSelected [2,6,10,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound17437 : packedSelected [2,6,10,12,14] rootPS < 2^1333 := by decide +kernel

def env17438 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,1,262,5392,10281,1024,0,4113,32,17,2,8192,17,10508,5392,4096,10281,1284,8492,256,32,13325,8973]

theorem envBound17438 : H12AffineFastState.Bounded env17438 := by
  intro p hp
  have h : env17438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17437_17438 : H12AffineEnvironment.transform 14 1 env17437 = env17438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env17437 == env17438) = true)

theorem identity17438 : scanCanonicalize (H12AffineFastState.compose env17438 (packedSelected [3,7,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 7181) := by decide +kernel

theorem selectedBound17438 : packedSelected [3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env17439 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,7181,5376,1,262,5392,5156,1024,0,4113,32,17,2,7181,17,5377,5392,4096,5156,1284,7457,256,32,2048,7936]

theorem envBound17439 : H12AffineFastState.Bounded env17439 := by
  intro p hp
  have h : env17439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17438_17439 : H12AffineEnvironment.transform 12 7181 env17438 = env17439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7181 env17438 == env17439) = true)

def env17440 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,180273,17,21762,8193,65,245018,115014,17664,10280,119043,254010,256,98678,90203,63069]

theorem envBound17440 : H12AffineFastState.Bounded env17440 := by
  intro p hp
  have h : env17440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17432_17440 : H12AffineEnvironment.transform 6 9 env17432 = env17440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17432 == env17440) = true)

theorem identity17440 : scanCanonicalize (H12AffineFastState.compose env17440 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound17440 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17441 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,138341,1024,29789,4161,144493,17,21762,8193,65,215366,79130,17664,10280,75103,201830,256,95530,90203,513]

theorem envBound17441 : H12AffineFastState.Bounded env17441 := by
  intro p hp
  have h : env17441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17440_17441 : H12AffineEnvironment.transform 14 29788 env17440 = env17441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env17440 == env17441) = true)

theorem identity17441 : scanCanonicalize (H12AffineFastState.compose env17441 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound17441 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env17442 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90138,97407,1024,29789,4161,87159,17,21762,8193,65,10588,79130,17664,10280,75103,29820,256,95530,90203,513]

theorem envBound17442 : H12AffineFastState.Bounded env17442 := by
  intro p hp
  have h : env17442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17441_17442 : H12AffineEnvironment.transform 16 90138 env17441 = env17442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env17441 == env17442) = true)

theorem identity17442 : scanCanonicalize (H12AffineFastState.compose env17442 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound17442 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env17443 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29962,5392,2421,1024,29789,4161,8573,17,21762,8193,65,10588,16400,17664,10280,20565,29820,256,32,5457,513]

theorem envBound17443 : H12AffineFastState.Bounded env17443 := by
  intro p hp
  have h : env17443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17442_17443 : H12AffineEnvironment.transform 15 29962 env17442 = env17443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env17442 == env17443) = true)

theorem identity17443 : scanCanonicalize (H12AffineFastState.compose env17443 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound17443 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env17444 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,21591,5392,2421,1024,21760,4161,32,17,21762,348,65,2049,16400,17664,2421,20565,21793,256,32,5457,513]

theorem envBound17444 : H12AffineFastState.Bounded env17444 := by
  intro p hp
  have h : env17444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17443_17444 : H12AffineEnvironment.transform 12 349 env17443 = env17444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env17443 == env17444) = true)

theorem identity17444 : scanCanonicalize (H12AffineFastState.compose env17444 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound17444 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17445 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,4112,1297,1095,5392,2421,1024,1296,4161,32,17,1298,348,65,2049,4096,5392,2421,69,1329,256,32,5457,513]

theorem envBound17445 : H12AffineFastState.Bounded env17445 := by
  intro p hp
  have h : env17445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17444_17445 : H12AffineEnvironment.transform 13 4112 env17444 = env17445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env17444 == env17445) = true)

theorem identity17445 : scanCanonicalize (H12AffineFastState.compose env17445 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1344) := by decide +kernel

theorem selectedBound17445 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env17446 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1344,4096,349,4112,1297,1095,5392,1077,1024,1296,4161,32,17,1298,348,65,1345,4096,5392,1077,69,1329,256,32,5457,513]

theorem envBound17446 : H12AffineFastState.Bounded env17446 := by
  intro p hp
  have h : env17446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17445_17446 : H12AffineEnvironment.transform 10 1344 env17445 = env17446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env17445 == env17446) = true)

theorem identity17446 : scanCanonicalize (H12AffineFastState.compose env17446 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound17446 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env17447 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1344,1281,349,1297,1297,1095,17,1077,1024,1296,1344,32,17,1298,348,65,1345,1281,17,1077,69,1329,256,32,80,513]

theorem envBound17447 : H12AffineFastState.Bounded env17447 := by
  intro p hp
  have h : env17447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17446_17447 : H12AffineEnvironment.transform 11 1281 env17446 = env17447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env17446 == env17447) = true)

theorem identity17447 : scanCanonicalize (H12AffineFastState.compose env17447 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound17447 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env17448 : List Nat := [2,4,8,16,32,64,9,256,512,101,293,356,349,372,372,34,17,80,101,373,293,32,17,375,348,65,292,356,17,80,69,340,256,32,80,513]

theorem envBound17448 : H12AffineFastState.Bounded env17448 := by
  intro p hp
  have h : env17448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17447_17448 : H12AffineEnvironment.transform 9 101 env17447 = env17448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env17447 == env17448) = true)

def env17449 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,2097152,4194304,2101329,2114883,8328,65,4292003,115151,17665,2111713,119042,4268162,256,2199999,2191387,63189]

theorem envBound17449 : H12AffineFastState.Bounded env17449 := by
  intro p hp
  have h : env17449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17397_17449 : H12AffineEnvironment.transform 22 2101329 env17397 = env17449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env17397 == env17449) = true)

def env17450 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4160,4194304,17,21763,8328,65,4292003,115151,17665,10401,119042,4268162,256,98815,90203,63189]

theorem envBound17450 : H12AffineFastState.Bounded env17450 := by
  intro p hp
  have h : env17450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17449_17450 : H12AffineEnvironment.transform 20 4160 env17449 = env17450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env17449 == env17450) = true)

theorem identity17450 : scanCanonicalize (H12AffineFastState.compose env17450 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 144613) := by decide +kernel

theorem selectedBound17450 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17451 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4160,144613,17,21763,8328,65,215366,115151,17665,10401,119042,201831,256,98815,90203,63189]

theorem envBound17451 : H12AffineFastState.Bounded env17451 := by
  intro p hp
  have h : env17451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17450_17451 : H12AffineEnvironment.transform 21 144613 env17450 = env17451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144613 env17450 == env17451) = true)

def env17452 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,144493,17,21763,8192,65,215366,115015,17665,10281,119042,201831,256,98679,90203,63069]

theorem envBound17452 : H12AffineFastState.Bounded env17452 := by
  intro p hp
  have h : env17452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17451_17452 : H12AffineEnvironment.transform 6 8 env17451 = env17452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17451 == env17452) = true)

theorem identity17452 : scanCanonicalize (H12AffineFastState.compose env17452 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound17452 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17453 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,179513,1024,32769,4160,144493,17,2,8192,65,203847,103494,4096,10281,99331,201831,256,98679,79194,41820]

theorem envBound17453 : H12AffineFastState.Bounded env17453 := by
  intro p hp
  have h : env17453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17452_17453 : H12AffineEnvironment.transform 13 5377 env17452 = env17453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env17452 == env17453) = true)

theorem identity17453 : scanCanonicalize (H12AffineFastState.compose env17453 (packedSelected [0,4,8,10,12,14,15,18,20,22,23,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 8313) := by decide +kernel

theorem selectedBound17453 : packedSelected [0,4,8,10,12,14,15,18,20,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env17454 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8313,65536,131072,138560,1024,8312,4160,144493,17,2,8192,65,203847,78911,4096,10281,74874,201831,256,73998,79194,805]

theorem envBound17454 : H12AffineFastState.Bounded env17454 := by
  intro p hp
  have h : env17454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17453_17454 : H12AffineEnvironment.transform 14 8313 env17453 = env17454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8313 env17453 == env17454) = true)

theorem identity17454 : scanCanonicalize (H12AffineFastState.compose env17454 (packedSelected [2,3,4,5,6,10,11,12,15,16,18,22] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound17454 : packedSelected [2,3,4,5,6,10,11,12,15,16,18,22] rootPS < 2^1333 := by decide +kernel

def env17455 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8313,343,131072,138560,1024,8312,4160,144493,17,2,8192,65,138512,13672,4096,10281,9517,136496,256,8281,13325,805]

theorem envBound17455 : H12AffineFastState.Bounded env17455 := by
  intro p hp
  have h : env17455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17454_17455 : H12AffineEnvironment.transform 15 343 env17454 = env17455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env17454 == env17455) = true)

theorem identity17455 : scanCanonicalize (H12AffineFastState.compose env17455 (packedSelected [0,2,3,5,6,7,10,11,12,15,18,20] rootPS)) = affineNative (2^(16+1) ^^^ 13672) := by decide +kernel

theorem selectedBound17455 : packedSelected [0,2,3,5,6,7,10,11,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env17456 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8313,343,13672,10280,1024,8312,4160,261,17,2,8192,65,10360,13672,4096,10281,9517,8280,256,8281,13325,805]

theorem envBound17456 : H12AffineFastState.Bounded env17456 := by
  intro p hp
  have h : env17456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17455_17456 : H12AffineEnvironment.transform 16 13672 env17455 = env17456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13672 env17455 == env17456) = true)

theorem identity17456 : scanCanonicalize (H12AffineFastState.compose env17456 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound17456 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17457 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,8192,4404,8313,343,12637,10280,53,8312,4160,261,17,2,8192,65,10360,12637,4096,10281,8472,8280,256,8281,12344,805]

theorem envBound17457 : H12AffineFastState.Bounded env17457 := by
  intro p hp
  have h : env17457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17456_17457 : H12AffineEnvironment.transform 9 53 env17456 = env17457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env17456 == env17457) = true)

theorem identity17457 : scanCanonicalize (H12AffineFastState.compose env17457 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound17457 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env17458 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,121,4404,0,343,4388,2129,53,1,4160,261,17,2,121,65,2049,4388,4096,2128,353,33,256,32,4161,805]

theorem envBound17458 : H12AffineFastState.Bounded env17458 := by
  intro p hp
  have h : env17458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17457_17458 : H12AffineEnvironment.transform 12 121 env17457 = env17458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env17457 == env17458) = true)

theorem identity17458 : scanCanonicalize (H12AffineFastState.compose env17458 (packedSelected [0,2,4,7,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound17458 : packedSelected [0,2,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env17459 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,2357,121,2049,0,343,2065,2129,53,1,2421,261,17,2,121,65,2049,2065,2357,2128,353,33,256,32,2420,805]

theorem envBound17459 : H12AffineFastState.Bounded env17459 := by
  intro p hp
  have h : env17459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17458_17459 : H12AffineEnvironment.transform 11 2357 env17458 = env17459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env17458 == env17459) = true)

theorem identity17459 : scanCanonicalize (H12AffineFastState.compose env17459 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound17459 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env17460 : List Nat := [2,4,8,16,32,64,8,36,512,53,2048,2065,121,2049,0,115,2065,2129,53,1,2129,33,17,2,121,65,2049,2065,2065,2128,69,33,36,32,2128,513]

theorem envBound17460 : H12AffineFastState.Bounded env17460 := by
  intro p hp
  have h : env17460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17459_17460 : H12AffineEnvironment.transform 7 36 env17459 = env17460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17459 == env17460) = true)

theorem identity17460 : scanCanonicalize (H12AffineFastState.compose env17460 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17460 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17461 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,2065,41,2049,0,35,2065,2049,53,1,2049,33,17,2,41,17,2049,2065,2065,2048,21,33,36,32,2048,513]

theorem envBound17461 : H12AffineFastState.Bounded env17461 := by
  intro p hp
  have h : env17461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17460_17461 : H12AffineEnvironment.transform 5 16 env17460 = env17461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17460 == env17461) = true)

def env17462 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,144492,17,21763,8193,65,215366,115014,17665,10280,119042,201831,256,98678,90203,63068]

theorem envBound17462 : H12AffineFastState.Bounded env17462 := by
  intro p hp
  have h : env17462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17451_17462 : H12AffineEnvironment.transform 6 9 env17451 = env17462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17451 == env17462) = true)

theorem identity17462 : scanCanonicalize (H12AffineFastState.compose env17462 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound17462 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17463 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,138340,1024,29788,4160,144492,17,21763,8193,65,215366,79131,17665,10280,75103,201831,256,95531,90203,513]

theorem envBound17463 : H12AffineFastState.Bounded env17463 := by
  intro p hp
  have h : env17463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17462_17463 : H12AffineEnvironment.transform 14 29789 env17462 = env17463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env17462 == env17463) = true)

theorem identity17463 : scanCanonicalize (H12AffineFastState.compose env17463 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound17463 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env17464 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90138,97406,1024,29788,4160,87158,17,21763,8193,65,10588,79131,17665,10280,75103,29821,256,95531,90203,513]

theorem envBound17464 : H12AffineFastState.Bounded env17464 := by
  intro p hp
  have h : env17464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17463_17464 : H12AffineEnvironment.transform 16 90138 env17463 = env17464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env17463 == env17464) = true)

theorem identity17464 : scanCanonicalize (H12AffineFastState.compose env17464 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound17464 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env17465 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29963,5393,2421,1024,29788,4160,8573,17,21763,8193,65,10588,16400,17665,10280,20564,29821,256,32,5456,513]

theorem envBound17465 : H12AffineFastState.Bounded env17465 := by
  intro p hp
  have h : env17465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17464_17465 : H12AffineEnvironment.transform 15 29963 env17464 = env17465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env17464 == env17465) = true)

theorem identity17465 : scanCanonicalize (H12AffineFastState.compose env17465 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound17465 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env17466 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,21590,5393,2421,1024,21761,4160,32,17,21763,348,65,2049,16400,17665,2421,20564,21792,256,32,5456,513]

theorem envBound17466 : H12AffineFastState.Bounded env17466 := by
  intro p hp
  have h : env17466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17465_17466 : H12AffineEnvironment.transform 12 349 env17465 = env17466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env17465 == env17466) = true)

theorem identity17466 : scanCanonicalize (H12AffineFastState.compose env17466 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound17466 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17467 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,4112,1296,1094,5393,2421,1024,1297,4160,32,17,1299,348,65,2049,4096,5393,2421,68,1328,256,32,5456,513]

theorem envBound17467 : H12AffineFastState.Bounded env17467 := by
  intro p hp
  have h : env17467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17466_17467 : H12AffineEnvironment.transform 13 4112 env17466 = env17467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env17466 == env17467) = true)

theorem identity17467 : scanCanonicalize (H12AffineFastState.compose env17467 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1345) := by decide +kernel

theorem selectedBound17467 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env17468 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1345,4096,349,4112,1296,1094,5393,1076,1024,1297,4160,32,17,1299,348,65,1344,4096,5393,1076,68,1328,256,32,5456,513]

theorem envBound17468 : H12AffineFastState.Bounded env17468 := by
  intro p hp
  have h : env17468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17467_17468 : H12AffineEnvironment.transform 10 1345 env17467 = env17468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env17467 == env17468) = true)

theorem identity17468 : scanCanonicalize (H12AffineFastState.compose env17468 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound17468 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env17469 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1345,17,349,1,1296,1094,1280,1076,1024,1297,81,32,17,1299,348,65,1344,17,1280,1076,68,1328,256,32,1345,513]

theorem envBound17469 : H12AffineFastState.Bounded env17469 := by
  intro p hp
  have h : env17469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17468_17469 : H12AffineEnvironment.transform 11 17 env17468 = env17469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env17468 == env17469) = true)

theorem identity17469 : scanCanonicalize (H12AffineFastState.compose env17469 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound17469 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env17470 : List Nat := [2,4,8,16,32,64,9,256,512,53,372,17,349,1,293,115,309,1,53,292,81,32,17,294,348,65,373,17,309,1,68,261,256,32,372,513]

theorem envBound17470 : H12AffineFastState.Bounded env17470 := by
  intro p hp
  have h : env17470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17469_17470 : H12AffineEnvironment.transform 9 53 env17469 = env17470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env17469 == env17470) = true)

theorem identity17470 : scanCanonicalize (H12AffineFastState.compose env17470 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound17470 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env17471 : List Nat := [2,4,8,16,32,64,9,37,512,53,81,17,120,1,0,115,16,1,53,1,81,32,17,3,121,65,80,17,16,1,68,32,37,32,81,513]

theorem envBound17471 : H12AffineFastState.Bounded env17471 := by
  intro p hp
  have h : env17471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17470_17471 : H12AffineEnvironment.transform 7 37 env17470 = env17471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env17470 == env17471) = true)

theorem identity17471 : scanCanonicalize (H12AffineFastState.compose env17471 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound17471 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17472 : List Nat := [2,4,8,16,16,64,9,21,512,5,81,17,72,1,0,67,16,1,5,1,81,16,17,3,73,65,80,17,16,1,68,16,21,16,81,513]

theorem envBound17472 : H12AffineFastState.Bounded env17472 := by
  intro p hp
  have h : env17472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17471_17472 : H12AffineEnvironment.transform 4 16 env17471 = env17472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env17471 == env17472) = true)

theorem identity17472 : scanCanonicalize (H12AffineFastState.compose env17472 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound17472 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17473 : List Nat := [2,4,8,16,16,64,9,21,1,5,81,17,72,1,0,67,16,1,5,1,81,16,17,3,73,65,80,17,16,1,68,16,21,16,81,0]

theorem envBound17473 : H12AffineFastState.Bounded env17473 := by
  intro p hp
  have h : env17473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17472_17473 : H12AffineEnvironment.transform 8 1 env17472 = env17473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env17472 == env17473) = true)

theorem identity17473 : scanCanonicalize (H12AffineFastState.compose env17473 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17473 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17474 : List Nat := [2,4,8,1,1,64,9,4,1,5,64,0,72,1,0,67,1,1,5,1,64,1,0,3,73,65,65,0,1,1,68,1,4,1,64,0]

theorem envBound17474 : H12AffineFastState.Bounded env17474 := by
  intro p hp
  have h : env17474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17473_17474 : H12AffineEnvironment.transform 3 1 env17473 = env17474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17473 == env17474) = true)

def env17475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4161,4194304,16,21762,8328,65,4292003,115151,17665,10400,119042,4268162,256,98814,90202,63189]

theorem envBound17475 : H12AffineFastState.Bounded env17475 := by
  intro p hp
  have h : env17475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17449_17475 : H12AffineEnvironment.transform 20 4161 env17449 = env17475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env17449 == env17475) = true)

theorem identity17475 : scanCanonicalize (H12AffineFastState.compose env17475 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound17475 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,138340,1024,29909,4161,4194304,16,21762,8328,65,4292003,79131,17665,10400,75222,4268162,256,95530,90202,513]

theorem envBound17476 : H12AffineFastState.Bounded env17476 := by
  intro p hp
  have h : env17476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17475_17476 : H12AffineEnvironment.transform 14 29908 env17475 = env17476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env17475 == env17476) = true)

def env17477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,138340,1024,8661,4161,4194304,16,2,8328,65,4270243,79131,4097,10400,75222,4268162,256,73770,79194,513]

theorem envBound17477 : H12AffineFastState.Bounded env17477 := by
  intro p hp
  have h : env17477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17476_17477 : H12AffineEnvironment.transform 13 5376 env17476 = env17477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env17476 == env17477) = true)

theorem identity17477 : scanCanonicalize (H12AffineFastState.compose env17477 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound17477 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,13389,10281,1024,8661,4161,4194304,16,2,8328,65,4270243,79131,4097,10400,75222,4268162,256,73770,79194,513]

theorem envBound17478 : H12AffineFastState.Bounded env17478 := by
  intro p hp
  have h : env17478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17477_17478 : H12AffineEnvironment.transform 16 13389 env17477 = env17478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env17477 == env17478) = true)

theorem identity17478 : scanCanonicalize (H12AffineFastState.compose env17478 (packedSelected [2,6,7,14,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound17478 : packedSelected [2,6,7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env17479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8203,13389,10281,1024,8661,4161,4194304,16,2,8328,65,4196520,5392,4097,10400,1501,4194441,256,33,5457,513]

theorem envBound17479 : H12AffineFastState.Bounded env17479 := by
  intro p hp
  have h : env17479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17478_17479 : H12AffineEnvironment.transform 15 8203 env17478 = env17479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env17478 == env17479) = true)

theorem identity17479 : scanCanonicalize (H12AffineFastState.compose env17479 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 8692) := by decide +kernel

theorem selectedBound17479 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8203,13389,10281,1024,8661,4161,8692,16,2,8328,65,10588,5392,4097,10400,1501,8573,256,33,5457,513]

theorem envBound17480 : H12AffineFastState.Bounded env17480 := by
  intro p hp
  have h : env17480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17479_17480 : H12AffineEnvironment.transform 21 8692 env17479 = env17480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8692 env17479 == env17480) = true)

theorem identity17480 : scanCanonicalize (H12AffineFastState.compose env17480 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound17480 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env17481 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,0,479,5529,2557,1024,1,4161,32,16,2,348,65,2184,5392,4097,2420,1501,169,256,33,5457,513]

theorem envBound17481 : H12AffineFastState.Bounded env17481 := by
  intro p hp
  have h : env17481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17480_17481 : H12AffineEnvironment.transform 12 468 env17480 = env17481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env17480 == env17481) = true)

theorem identity17481 : scanCanonicalize (H12AffineFastState.compose env17481 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound17481 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17482 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,342,5392,2420,1024,1,4161,32,16,2,348,65,2049,5392,4097,2420,1364,32,256,33,5457,513]

theorem envBound17482 : H12AffineFastState.Bounded env17482 := by
  intro p hp
  have h : env17482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17481_17482 : H12AffineEnvironment.transform 6 9 env17481 = env17482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17481 == env17482) = true)

theorem identity17482 : scanCanonicalize (H12AffineFastState.compose env17482 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3419) := by decide +kernel

theorem selectedBound17482 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17483 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3419,349,2139,0,342,2123,2420,1024,1,3354,32,16,2,348,65,2049,2123,3418,2420,1364,32,256,33,2058,513]

theorem envBound17483 : H12AffineFastState.Bounded env17483 := by
  intro p hp
  have h : env17483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17482_17483 : H12AffineEnvironment.transform 11 3419 env17482 = env17483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3419 env17482 == env17483) = true)

theorem identity17483 : scanCanonicalize (H12AffineFastState.compose env17483 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 346) := by decide +kernel

theorem selectedBound17483 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17484 : List Nat := [2,4,8,16,32,64,9,256,512,346,2048,2049,349,2139,0,342,2123,2420,346,1,2112,32,16,2,348,65,2049,2123,2048,2420,14,32,256,33,2058,513]

theorem envBound17484 : H12AffineFastState.Bounded env17484 := by
  intro p hp
  have h : env17484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17483_17484 : H12AffineEnvironment.transform 9 346 env17483 = env17484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 346 env17483 == env17484) = true)

def env17485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,138340,1024,8660,4161,4194304,16,3,8328,65,4270242,79131,4096,10400,75222,4268162,256,73771,79195,513]

theorem envBound17485 : H12AffineFastState.Bounded env17485 := by
  intro p hp
  have h : env17485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17476_17485 : H12AffineEnvironment.transform 13 5377 env17476 = env17485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env17476 == env17485) = true)

theorem identity17485 : scanCanonicalize (H12AffineFastState.compose env17485 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound17485 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17486 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,13508,10400,1024,8660,4161,4194304,16,3,8328,65,4270242,79131,4096,10400,75222,4268162,256,73771,79195,513]

theorem envBound17486 : H12AffineFastState.Bounded env17486 := by
  intro p hp
  have h : env17486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17485_17486 : H12AffineEnvironment.transform 16 13508 env17485 = env17486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env17485 == env17486) = true)

theorem identity17486 : scanCanonicalize (H12AffineFastState.compose env17486 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound17486 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env17487 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8322,13508,10400,1024,8660,4161,4194304,16,3,8328,65,4196384,5529,4096,10400,1364,4194304,256,169,5593,513]

theorem envBound17487 : H12AffineFastState.Bounded env17487 := by
  intro p hp
  have h : env17487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17486_17487 : H12AffineEnvironment.transform 15 8322 env17486 = env17487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env17486 == env17487) = true)

theorem identity17487 : scanCanonicalize (H12AffineFastState.compose env17487 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound17487 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env17488 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,136,479,5529,2557,1024,137,4161,4194304,16,3,469,65,4196384,5529,4096,2557,1364,4194304,256,169,5593,513]

theorem envBound17488 : H12AffineFastState.Bounded env17488 := by
  intro p hp
  have h : env17488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17487_17488 : H12AffineEnvironment.transform 12 349 env17487 = env17488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env17487 == env17488) = true)

theorem identity17488 : scanCanonicalize (H12AffineFastState.compose env17488 (packedSelected [18,23] rootPS)) = affineNative (2^(21+1) ^^^ 168) := by decide +kernel

theorem selectedBound17488 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env17489 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,136,479,5529,2557,1024,137,4161,168,16,3,469,65,2184,5529,4096,2557,1364,168,256,169,5593,513]

theorem envBound17489 : H12AffineFastState.Bounded env17489 := by
  intro p hp
  have h : env17489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17488_17489 : H12AffineEnvironment.transform 21 168 env17488 = env17489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 168 env17488 == env17489) = true)

theorem identity17489 : scanCanonicalize (H12AffineFastState.compose env17489 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound17489 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env17490 : List Nat := [2,4,8,16,32,48,128,256,512,1024,2048,4096,301,5377,136,431,5529,2445,1024,137,4145,168,16,3,421,49,2184,5529,4096,2445,1316,168,256,169,5545,513]

theorem envBound17490 : H12AffineFastState.Bounded env17490 := by
  intro p hp
  have h : env17490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17489_17490 : H12AffineEnvironment.transform 5 48 env17489 = env17490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env17489 == env17490) = true)

theorem identity17490 : scanCanonicalize (H12AffineFastState.compose env17490 (packedSelected [0,2,3,4,5,7,9,10,11,18] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound17490 : packedSelected [0,2,3,4,5,7,9,10,11,18] rootPS < 2^1333 := by decide +kernel

def env17491 : List Nat := [2,4,8,16,32,48,40,256,512,1024,2048,4096,301,5377,32,263,5425,2341,1024,33,4145,0,16,3,269,49,2080,5425,4096,2341,1316,0,256,1,5377,513]

theorem envBound17491 : H12AffineFastState.Bounded env17491 := by
  intro p hp
  have h : env17491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17490_17491 : H12AffineEnvironment.transform 6 40 env17490 = env17491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env17490 == env17491) = true)

def env17492 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,2097152,4194304,8388608,2114882,8328,65,14773746,115150,10507600,8399025,10600786,4268163,256,8487407,8478795,10544773]

theorem envBound17492 : H12AffineFastState.Bounded env17492 := by
  intro p hp
  have h : env17492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17396_17492 : H12AffineEnvironment.transform 17 190641 env17396 = env17492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190641 env17396 == env17492) = true)

def env17493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,2097152,4194304,2101328,2114882,8328,65,4292002,115150,17664,2111713,119042,4268163,256,2199999,2191387,63189]

theorem envBound17493 : H12AffineFastState.Bounded env17493 := by
  intro p hp
  have h : env17493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17492_17493 : H12AffineEnvironment.transform 22 2101328 env17492 = env17493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env17492 == env17493) = true)

def env17494 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4160,4194304,16,21762,8328,65,4292002,115150,17664,10401,119042,4268163,256,98815,90203,63189]

theorem envBound17494 : H12AffineFastState.Bounded env17494 := by
  intro p hp
  have h : env17494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17493_17494 : H12AffineEnvironment.transform 20 4160 env17493 = env17494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env17493 == env17494) = true)

theorem identity17494 : scanCanonicalize (H12AffineFastState.compose env17494 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound17494 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17495 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,190641,1024,32769,4160,4194304,16,21762,8328,65,4237693,5393,17664,10401,1501,4256860,256,21792,46212,63189]

theorem envBound17495 : H12AffineFastState.Bounded env17495 := by
  intro p hp
  have h : env17495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17494_17495 : H12AffineEnvironment.transform 15 54495 env17494 = env17495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env17494 == env17495) = true)

def env17496 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,190521,1024,32769,4160,4194304,16,21762,8192,65,4237693,5393,17664,10281,1365,4256860,256,21792,46092,63069]

theorem envBound17496 : H12AffineFastState.Bounded env17496 := by
  intro p hp
  have h : env17496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17495_17496 : H12AffineEnvironment.transform 6 8 env17495 = env17496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17495 == env17496) = true)

theorem identity17496 : scanCanonicalize (H12AffineFastState.compose env17496 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound17496 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17497 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38160,32041,1024,32769,4160,4194304,16,21762,8192,65,4237693,5393,17664,10281,1365,4256860,256,21792,46092,63069]

theorem envBound17497 : H12AffineFastState.Bounded env17497 := by
  intro p hp
  have h : env17497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17496_17497 : H12AffineEnvironment.transform 16 38160 env17496 = env17497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env17496 == env17497) = true)

theorem identity17497 : scanCanonicalize (H12AffineFastState.compose env17497 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 29741) := by decide +kernel

theorem selectedBound17497 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env17498 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38160,32041,1024,32769,4160,29741,16,21762,8192,65,56656,5393,17664,10281,1365,32881,256,21792,46092,63069]

theorem envBound17498 : H12AffineFastState.Bounded env17498 := by
  intro p hp
  have h : env17498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17497_17498 : H12AffineEnvironment.transform 21 29741 env17497 = env17498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29741 env17497 == env17498) = true)

theorem identity17498 : scanCanonicalize (H12AffineFastState.compose env17498 (packedSelected [1,3,4,8,9,10,12,14,15,16,18,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound17498 : packedSelected [1,3,4,8,9,10,12,14,15,16,18,23,24] rootPS < 2^1333 := by decide +kernel

def env17499 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,32768,32802,38160,10588,1024,32769,4160,8280,16,375,8192,65,35109,5393,4469,10281,1365,32881,256,341,46092,41512]

theorem envBound17499 : H12AffineFastState.Bounded env17499 := by
  intro p hp
  have h : env17499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17498_17499 : H12AffineEnvironment.transform 13 5237 env17498 = env17499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env17498 == env17499) = true)

theorem identity17499 : scanCanonicalize (H12AffineFastState.compose env17499 (packedSelected [0,7,9,14,16,18,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound17499 : packedSelected [0,7,9,14,16,18,22,23] rootPS < 2^1333 := by decide +kernel

def env17500 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8233,8203,13625,10588,1024,8232,4160,8280,16,375,8192,65,10508,5393,4469,10281,1365,8280,256,341,5157,513]

theorem envBound17500 : H12AffineFastState.Bounded env17500 := by
  intro p hp
  have h : env17500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17499_17500 : H12AffineEnvironment.transform 14 8233 env17499 = env17500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env17499 == env17500) = true)

theorem identity17500 : scanCanonicalize (H12AffineFastState.compose env17500 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound17500 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env17501 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,8192,4112,8233,8203,12636,10588,101,8232,4160,8280,16,375,8192,65,10508,4468,4469,10281,304,8280,256,341,4160,513]

theorem envBound17501 : H12AffineFastState.Bounded env17501 := by
  intro p hp
  have h : env17501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17500_17501 : H12AffineEnvironment.transform 9 101 env17500 = env17501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env17500 == env17501) = true)

theorem identity17501 : scanCanonicalize (H12AffineFastState.compose env17501 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound17501 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17502 : List Nat := [2,4,8,16,32,64,8,117,512,101,2048,4096,8192,4112,8233,8203,12329,10281,101,8232,4160,8280,16,2,8192,65,10361,4097,4096,10281,69,8280,117,32,4160,513]

theorem envBound17502 : H12AffineFastState.Bounded env17502 := by
  intro p hp
  have h : env17502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17501_17502 : H12AffineEnvironment.transform 7 117 env17501 = env17502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env17501 == env17502) = true)

theorem identity17502 : scanCanonicalize (H12AffineFastState.compose env17502 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound17502 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env17503 : List Nat := [2,4,8,16,32,64,8,117,512,101,2048,17,8192,1,8233,8203,8248,10281,101,8232,81,8280,16,2,8192,65,10361,16,17,10281,69,8280,117,32,81,513]

theorem envBound17503 : H12AffineFastState.Bounded env17503 := by
  intro p hp
  have h : env17503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17502_17503 : H12AffineEnvironment.transform 11 17 env17502 = env17503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env17502 == env17503) = true)

theorem identity17503 : scanCanonicalize (H12AffineFastState.compose env17503 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound17503 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env17504 : List Nat := [2,4,8,16,32,64,8,117,512,101,0,17,8192,1,8233,8203,8248,8233,101,8232,81,8280,16,2,8192,65,8313,16,17,8233,69,8280,117,32,81,513]

theorem envBound17504 : H12AffineFastState.Bounded env17504 := by
  intro p hp
  have h : env17504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17503_17504 : H12AffineEnvironment.transform 10 0 env17503 = env17504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env17503 == env17504) = true)

def env17505 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,190520,1024,32769,4160,4194304,16,21762,8193,65,4237693,5393,17664,10280,1364,4256860,256,21792,46093,63068]

theorem envBound17505 : H12AffineFastState.Bounded env17505 := by
  intro p hp
  have h : env17505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17495_17505 : H12AffineEnvironment.transform 6 9 env17495 = env17505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17495 == env17505) = true)

theorem identity17505 : scanCanonicalize (H12AffineFastState.compose env17505 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound17505 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17506 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,13388,56436,1024,32769,4160,4194304,16,21762,8193,65,4237693,5393,17664,10280,1364,4256860,256,21792,46093,63068]

theorem envBound17506 : H12AffineFastState.Bounded env17506 := by
  intro p hp
  have h : env17506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17505_17506 : H12AffineEnvironment.transform 16 13388 env17505 = env17506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env17505 == env17506) = true)

theorem identity17506 : scanCanonicalize (H12AffineFastState.compose env17506 (packedSelected [16,20] rootPS)) = affineNative (2^(21+1) ^^^ 29820) := by decide +kernel

theorem selectedBound17506 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env17507 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,13388,56436,1024,32769,4160,29820,16,21762,8193,65,56577,5393,17664,10280,1364,32800,256,21792,46093,63068]

theorem envBound17507 : H12AffineFastState.Bounded env17507 := by
  intro p hp
  have h : env17507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17506_17507 : H12AffineEnvironment.transform 21 29820 env17506 = env17507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29820 env17506 == env17507) = true)

theorem identity17507 : scanCanonicalize (H12AffineFastState.compose env17507 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound17507 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env17508 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21840,262,13388,2340,1024,21841,4160,29820,16,21762,8193,65,2129,5393,17664,10280,1364,21872,256,21792,24925,8972]

theorem envBound17508 : H12AffineFastState.Bounded env17508 := by
  intro p hp
  have h : env17508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17507_17508 : H12AffineEnvironment.transform 14 21840 env17507 = env17508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env17507 == env17508) = true)

theorem identity17508 : scanCanonicalize (H12AffineFastState.compose env17508 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound17508 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env17509 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,81,262,13388,2340,1024,80,4160,8573,16,3,8193,65,2129,5393,4097,10280,1364,113,256,33,13404,8972]

theorem envBound17509 : H12AffineFastState.Bounded env17509 := by
  intro p hp
  have h : env17509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17508_17509 : H12AffineEnvironment.transform 13 5377 env17508 = env17509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env17508 == env17509) = true)

theorem identity17509 : scanCanonicalize (H12AffineFastState.compose env17509 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound17509 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env17510 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,81,262,5440,2340,1024,80,4160,113,16,3,269,65,2129,5393,4097,2340,1364,113,256,33,5456,512]

theorem envBound17510 : H12AffineFastState.Bounded env17510 := by
  intro p hp
  have h : env17510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17509_17510 : H12AffineEnvironment.transform 12 268 env17509 = env17510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env17509 == env17510) = true)

theorem identity17510 : scanCanonicalize (H12AffineFastState.compose env17510 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17510 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17511 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,268,5377,81,262,5440,2308,1024,80,4160,81,16,3,269,65,2129,5393,4097,2308,1364,81,256,1,5456,512]

theorem envBound17511 : H12AffineFastState.Bounded env17511 := by
  intro p hp
  have h : env17511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17510_17511 : H12AffineEnvironment.transform 4 0 env17510 = env17511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17510 == env17511) = true)

theorem identity17511 : scanCanonicalize (H12AffineFastState.compose env17511 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound17511 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17512 : List Nat := [2,4,8,16,0,64,9,256,512,273,2048,4096,268,4112,81,262,4177,2308,273,80,4160,81,16,3,269,65,2129,4096,4097,2308,69,81,256,1,4161,512]

theorem envBound17512 : H12AffineFastState.Bounded env17512 := by
  intro p hp
  have h : env17512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17511_17512 : H12AffineEnvironment.transform 9 273 env17511 = env17512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env17511 == env17512) = true)

theorem identity17512 : scanCanonicalize (H12AffineFastState.compose env17512 (packedSelected [0,1,4,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound17512 : packedSelected [0,1,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env17513 : List Nat := [2,4,8,16,0,64,9,256,512,273,2048,2065,268,2049,81,262,2112,2308,273,80,2129,81,16,3,269,65,2129,2065,2064,2308,69,81,256,1,2128,512]

theorem envBound17513 : H12AffineFastState.Bounded env17513 := by
  intro p hp
  have h : env17513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17512_17513 : H12AffineEnvironment.transform 11 2065 env17512 = env17513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env17512 == env17513) = true)

theorem identity17513 : scanCanonicalize (H12AffineFastState.compose env17513 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound17513 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env17514 : List Nat := [2,4,8,16,0,64,9,84,512,69,2048,2065,88,2049,81,82,2112,2128,69,80,2129,81,16,3,89,65,2129,2065,2064,2128,69,81,84,1,2128,512]

theorem envBound17514 : H12AffineFastState.Bounded env17514 := by
  intro p hp
  have h : env17514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17513_17514 : H12AffineEnvironment.transform 7 84 env17513 = env17514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env17513 == env17514) = true)

theorem identity17514 : scanCanonicalize (H12AffineFastState.compose env17514 (packedSelected [2,3,5,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17514 : packedSelected [2,3,5,11] rootPS < 2^1333 := by decide +kernel

def env17515 : List Nat := [2,4,8,16,0,17,9,5,512,20,2048,2065,9,2049,0,3,2065,2049,20,1,2048,0,16,3,8,16,2048,2065,2064,2049,20,0,5,1,2049,512]

theorem envBound17515 : H12AffineFastState.Bounded env17515 := by
  intro p hp
  have h : env17515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17514_17515 : H12AffineEnvironment.transform 5 17 env17514 = env17515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17514 == env17515) = true)

theorem identity17515 : scanCanonicalize (H12AffineFastState.compose env17515 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 5) := by decide +kernel

theorem selectedBound17515 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17516 : List Nat := [2,4,8,16,0,17,9,5,512,20,5,20,9,4,0,3,20,4,20,1,5,0,16,3,8,16,5,20,21,4,20,0,5,1,4,512]

theorem envBound17516 : H12AffineFastState.Bounded env17516 := by
  intro p hp
  have h : env17516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17515_17516 : H12AffineEnvironment.transform 10 5 env17515 = env17516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 5 env17515 == env17516) = true)

theorem identity17516 : scanCanonicalize (H12AffineFastState.compose env17516 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound17516 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17517 : List Nat := [2,4,8,16,0,17,9,5,12,20,5,20,9,4,0,3,20,4,20,1,5,0,16,3,8,16,5,20,21,4,20,0,5,1,4,12]

theorem envBound17517 : H12AffineFastState.Bounded env17517 := by
  intro p hp
  have h : env17517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17516_17517 : H12AffineEnvironment.transform 8 12 env17516 = env17517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env17516 == env17517) = true)

def env17518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4161,4194304,17,21763,8328,65,4292002,115150,17664,10400,119042,4268163,256,98814,90202,63189]

theorem envBound17518 : H12AffineFastState.Bounded env17518 := by
  intro p hp
  have h : env17518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17493_17518 : H12AffineEnvironment.transform 20 4161 env17493 = env17518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env17493 == env17518) = true)

theorem identity17518 : scanCanonicalize (H12AffineFastState.compose env17518 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 201966) := by decide +kernel

theorem selectedBound17518 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4161,201966,17,21763,8328,65,158028,115150,17664,10400,119042,144493,256,98814,90202,63189]

theorem envBound17519 : H12AffineFastState.Bounded env17519 := by
  intro p hp
  have h : env17519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17518_17519 : H12AffineEnvironment.transform 21 201966 env17518 = env17519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 201966 env17518 == env17519) = true)

theorem identity17519 : scanCanonicalize (H12AffineFastState.compose env17519 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound17519 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env17520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,138341,1024,29909,4161,201966,17,21763,8328,65,158028,79130,17664,10400,75222,144493,256,95530,90202,513]

theorem envBound17520 : H12AffineFastState.Bounded env17520 := by
  intro p hp
  have h : env17520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17519_17520 : H12AffineEnvironment.transform 14 29908 env17519 = env17520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env17519 == env17520) = true)

theorem identity17520 : scanCanonicalize (H12AffineFastState.compose env17520 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound17520 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env17521 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90138,97407,1024,29909,4161,29940,17,21763,8328,65,67926,79130,17664,10400,75222,87159,256,95530,90202,513]

theorem envBound17521 : H12AffineFastState.Bounded env17521 := by
  intro p hp
  have h : env17521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17520_17521 : H12AffineEnvironment.transform 16 90138 env17520 = env17521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env17520 == env17521) = true)

def env17522 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,79130,76159,1024,8661,4161,8692,17,3,8328,65,67926,79130,4096,10400,75222,65911,256,73770,79194,513]

theorem envBound17522 : H12AffineFastState.Bounded env17522 := by
  intro p hp
  have h : env17522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17521_17522 : H12AffineEnvironment.transform 13 5376 env17521 = env17522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env17521 == env17522) = true)

theorem identity17522 : scanCanonicalize (H12AffineFastState.compose env17522 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound17522 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17523 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,79130,76159,1024,8540,4161,8573,17,3,8193,65,67926,79130,4096,10281,75103,65911,256,73770,79194,513]

theorem envBound17523 : H12AffineFastState.Bounded env17523 := by
  intro p hp
  have h : env17523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17522_17523 : H12AffineEnvironment.transform 6 9 env17522 = env17523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17522 == env17523) = true)

theorem identity17523 : scanCanonicalize (H12AffineFastState.compose env17523 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound17523 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env17524 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8203,5393,2420,1024,8540,4161,8573,17,3,8193,65,10589,5393,4096,10281,1364,8572,256,33,5457,513]

theorem envBound17524 : H12AffineFastState.Bounded env17524 := by
  intro p hp
  have h : env17524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17523_17524 : H12AffineEnvironment.transform 15 8203 env17523 = env17524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env17523 == env17524) = true)

theorem identity17524 : scanCanonicalize (H12AffineFastState.compose env17524 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17524 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17525 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8460,8203,5393,2341,1024,8461,4112,8492,17,3,8193,16,10508,5393,4096,10281,1285,8493,256,33,5376,513]

theorem envBound17525 : H12AffineFastState.Bounded env17525 := by
  intro p hp
  have h : env17525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17524_17525 : H12AffineEnvironment.transform 5 17 env17524 = env17525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17524 == env17525) = true)

theorem identity17525 : scanCanonicalize (H12AffineFastState.compose env17525 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 285) := by decide +kernel

theorem selectedBound17525 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17526 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,285,5376,17,278,5393,2341,1024,16,4112,49,17,3,284,16,2065,5393,4096,2356,1285,48,256,33,5376,513]

theorem envBound17526 : H12AffineFastState.Bounded env17526 := by
  intro p hp
  have h : env17526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17525_17526 : H12AffineEnvironment.transform 12 285 env17525 = env17526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 285 env17525 == env17526) = true)

theorem identity17526 : scanCanonicalize (H12AffineFastState.compose env17526 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1793) := by decide +kernel

theorem selectedBound17526 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env17527 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,4096,285,5376,17,278,5393,1572,1024,16,4112,49,17,3,284,16,1808,5393,4096,1589,1285,48,256,33,5376,513]

theorem envBound17527 : H12AffineFastState.Bounded env17527 := by
  intro p hp
  have h : env17527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17526_17527 : H12AffineEnvironment.transform 10 1793 env17526 = env17527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env17526 == env17527) = true)

theorem identity17527 : scanCanonicalize (H12AffineFastState.compose env17527 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound17527 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env17528 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1572,4096,56,5157,17,51,5172,1572,1024,16,4112,49,17,3,57,16,1589,5172,4096,1589,1056,48,37,33,5157,513]

theorem envBound17528 : H12AffineFastState.Bounded env17528 := by
  intro p hp
  have h : env17528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17527_17528 : H12AffineEnvironment.transform 7 37 env17527 = env17528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env17527 == env17528) = true)

theorem identity17528 : scanCanonicalize (H12AffineFastState.compose env17528 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound17528 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17529 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1572,1076,56,17,17,51,0,1572,1024,16,1060,49,17,3,57,16,1589,0,1076,1589,1056,48,37,33,17,513]

theorem envBound17529 : H12AffineFastState.Bounded env17529 := by
  intro p hp
  have h : env17529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17528_17529 : H12AffineEnvironment.transform 11 1076 env17528 = env17529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env17528 == env17529) = true)

theorem identity17529 : scanCanonicalize (H12AffineFastState.compose env17529 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound17529 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env17530 : List Nat := [2,4,8,16,32,17,9,37,512,37,513,17,56,17,17,51,0,513,37,16,1,49,17,3,57,16,528,0,17,528,5,48,37,33,17,513]

theorem envBound17530 : H12AffineFastState.Bounded env17530 := by
  intro p hp
  have h : env17530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17529_17530 : H12AffineEnvironment.transform 9 37 env17529 = env17530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env17529 == env17530) = true)

theorem identity17530 : scanCanonicalize (H12AffineFastState.compose env17530 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound17530 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17531 : List Nat := [2,4,8,16,32,17,9,37,1,37,0,17,56,17,17,51,0,0,37,16,1,49,17,3,57,16,17,0,17,17,5,48,37,33,17,0]

theorem envBound17531 : H12AffineFastState.Bounded env17531 := by
  intro p hp
  have h : env17531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17530_17531 : H12AffineEnvironment.transform 8 1 env17530 = env17531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env17530 == env17531) = true)

def env17532 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,79131,76158,1024,8660,4161,8693,17,2,8328,65,67926,79130,4097,10400,75222,65910,256,73771,79195,513]

theorem envBound17532 : H12AffineFastState.Bounded env17532 := by
  intro p hp
  have h : env17532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17521_17532 : H12AffineEnvironment.transform 13 5377 env17521 = env17532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env17521 == env17532) = true)

theorem identity17532 : scanCanonicalize (H12AffineFastState.compose env17532 (packedSelected [1,2,3,4,6,9,11,14,20,24,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound17532 : packedSelected [1,2,3,4,6,9,11,14,20,24,28,32] rootPS < 2^1333 := by decide +kernel

def env17533 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,479,13508,10401,1024,8660,4161,8693,17,2,8328,65,2185,13509,4097,10400,9225,169,256,8692,13444,513]

theorem envBound17533 : H12AffineFastState.Bounded env17533 := by
  intro p hp
  have h : env17533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17532_17533 : H12AffineEnvironment.transform 15 479 env17532 = env17533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env17532 == env17533) = true)

theorem identity17533 : scanCanonicalize (H12AffineFastState.compose env17533 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 3545) := by decide +kernel

theorem selectedBound17533 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env17534 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3545,8192,2264,8661,479,10525,10401,1024,8660,3480,8693,17,2,8328,65,2185,10524,3544,10400,9225,169,256,8692,10589,513]

theorem envBound17534 : H12AffineFastState.Bounded env17534 := by
  intro p hp
  have h : env17534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17533_17534 : H12AffineEnvironment.transform 11 3545 env17533 = env17534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3545 env17533 == env17534) = true)

theorem identity17534 : scanCanonicalize (H12AffineFastState.compose env17534 (packedSelected [0,1,2,6,7,8,10,12,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound17534 : packedSelected [0,1,2,6,7,8,10,12,14,18] rootPS < 2^1333 := by decide +kernel

def env17535 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,3189,8192,2264,8313,115,10417,10401,1024,8312,3124,8281,17,2,8328,65,2185,10416,3188,10400,9225,169,172,8280,10481,513]

theorem envBound17535 : H12AffineFastState.Bounded env17535 := by
  intro p hp
  have h : env17535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17534_17535 : H12AffineEnvironment.transform 7 172 env17534 = env17535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env17534 == env17535) = true)

theorem identity17535 : scanCanonicalize (H12AffineFastState.compose env17535 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 240) := by decide +kernel

theorem selectedBound17535 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env17536 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,3189,240,2264,137,115,2113,2129,1024,136,3124,169,17,2,120,65,2185,2112,3188,2128,1273,169,172,168,2049,513]

theorem envBound17536 : H12AffineFastState.Bounded env17536 := by
  intro p hp
  have h : env17536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17535_17536 : H12AffineEnvironment.transform 12 240 env17535 = env17536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env17535 == env17536) = true)

theorem identity17536 : scanCanonicalize (H12AffineFastState.compose env17536 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound17536 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env17537 : List Nat := [2,4,8,16,32,64,128,172,512,1024,1125,16,240,1213,137,115,1060,1076,1024,136,81,169,17,2,120,65,1260,1061,17,1077,1273,169,172,168,1124,513]

theorem envBound17537 : H12AffineFastState.Bounded env17537 := by
  intro p hp
  have h : env17537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17536_17537 : H12AffineEnvironment.transform 10 1125 env17536 = env17537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env17536 == env17537) = true)

theorem identity17537 : scanCanonicalize (H12AffineFastState.compose env17537 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17537 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env17538 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1076,16,161,1213,137,34,1060,1076,1024,136,0,169,17,2,41,16,1213,1061,17,1077,1192,169,172,168,1077,513]

theorem envBound17538 : H12AffineFastState.Bounded env17538 := by
  intro p hp
  have h : env17538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17537_17538 : H12AffineEnvironment.transform 5 17 env17537 = env17538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17537 == env17538) = true)

def env17539 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,2097152,4194304,2101329,2114882,8328,65,4292003,115150,17665,2111712,119043,4268163,256,2199998,2191386,63188]

theorem envBound17539 : H12AffineFastState.Bounded env17539 := by
  intro p hp
  have h : env17539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17492_17539 : H12AffineEnvironment.transform 22 2101329 env17492 = env17539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env17492 == env17539) = true)

def env17540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4160,4194304,17,21762,8328,65,4292003,115150,17665,10400,119043,4268163,256,98814,90202,63188]

theorem envBound17540 : H12AffineFastState.Bounded env17540 := by
  intro p hp
  have h : env17540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17539_17540 : H12AffineEnvironment.transform 20 4160 env17539 = env17540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env17539 == env17540) = true)

theorem identity17540 : scanCanonicalize (H12AffineFastState.compose env17540 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 254010) := by decide +kernel

theorem selectedBound17540 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17541 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4160,254010,17,21762,8328,65,171417,115150,17665,10400,119043,180409,256,98814,90202,63188]

theorem envBound17541 : H12AffineFastState.Bounded env17541 := by
  intro p hp
  have h : env17541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17540_17541 : H12AffineEnvironment.transform 21 254010 env17540 = env17541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 254010 env17540 == env17541) = true)

def env17542 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,254010,17,21762,8192,65,171281,115014,17665,10280,119043,180273,256,98678,90202,63068]

theorem envBound17542 : H12AffineFastState.Bounded env17542 := by
  intro p hp
  have h : env17542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17541_17542 : H12AffineEnvironment.transform 6 8 env17541 = env17542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17541 == env17542) = true)

theorem identity17542 : scanCanonicalize (H12AffineFastState.compose env17542 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound17542 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17543 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,179513,1024,32769,4160,243002,17,2,8192,65,171281,103494,4097,10280,99331,169265,256,98678,79194,41820]

theorem envBound17543 : H12AffineFastState.Bounded env17543 := by
  intro p hp
  have h : env17543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17542_17543 : H12AffineEnvironment.transform 13 5376 env17542 = env17543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env17542 == env17543) = true)

theorem identity17543 : scanCanonicalize (H12AffineFastState.compose env17543 (packedSelected [0,1,4,8,10,12,14,15,18,19,20,22,23,27,31] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound17543 : packedSelected [0,1,4,8,10,12,14,15,18,19,20,22,23,27,31] rootPS < 2^1333 := by decide +kernel

def env17544 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,32768,65536,131072,179276,1024,32769,4160,242767,17,2,8192,65,171108,103494,4097,10280,99331,169028,117,98307,78895,41513]

theorem envBound17544 : H12AffineFastState.Bounded env17544 := by
  intro p hp
  have h : env17544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17543_17544 : H12AffineEnvironment.transform 7 117 env17543 = env17544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env17543 == env17544) = true)

theorem identity17544 : scanCanonicalize (H12AffineFastState.compose env17544 (packedSelected [0,1,3,4,6,7,8,9,10,12,15,16,18,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound17544 : packedSelected [0,1,3,4,6,7,8,9,10,12,15,16,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env17545 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,8232,65536,131072,138340,1024,8233,4160,201831,17,2,8192,65,146508,78958,4097,10280,74795,144492,117,73771,78895,513]

theorem envBound17545 : H12AffineFastState.Bounded env17545 := by
  intro p hp
  have h : env17545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17544_17545 : H12AffineEnvironment.transform 14 8232 env17544 = env17545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env17544 == env17545) = true)

theorem identity17545 : scanCanonicalize (H12AffineFastState.compose env17545 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 4097) := by decide +kernel

theorem selectedBound17545 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env17546 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,8232,65536,4097,3173,1024,8233,4160,66662,17,2,8192,65,11341,78958,4097,10280,74795,9325,117,73771,78895,513]

theorem envBound17546 : H12AffineFastState.Bounded env17546 := by
  intro p hp
  have h : env17546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17545_17546 : H12AffineEnvironment.transform 16 4097 env17545 = env17546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env17545 == env17546) = true)

theorem identity17546 : scanCanonicalize (H12AffineFastState.compose env17546 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound17546 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env17547 : List Nat := [2,4,8,16,32,64,8,117,512,52,2048,4096,8192,4161,8232,65536,4097,2129,52,8233,4160,65618,17,2,8192,65,10361,77914,4097,10280,73759,8281,117,73771,77851,513]

theorem envBound17547 : H12AffineFastState.Bounded env17547 := by
  intro p hp
  have h : env17547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17546_17547 : H12AffineEnvironment.transform 9 52 env17546 = env17547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env17546 == env17547) = true)

theorem identity17547 : scanCanonicalize (H12AffineFastState.compose env17547 (packedSelected [0,2,3,5,6,9,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound17547 : packedSelected [0,2,3,5,6,9,11,12] rootPS < 2^1333 := by decide +kernel

def env17548 : List Nat := [2,4,8,16,32,64,8,117,512,52,2048,4096,121,4161,81,65536,4097,2129,52,80,4160,65618,17,2,121,65,2048,69667,4097,2129,65638,32,117,65618,69730,513]

theorem envBound17548 : H12AffineFastState.Bounded env17548 := by
  intro p hp
  have h : env17548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17547_17548 : H12AffineEnvironment.transform 12 121 env17547 = env17548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env17547 == env17548) = true)

theorem identity17548 : scanCanonicalize (H12AffineFastState.compose env17548 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17548 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env17549 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,4096,41,4113,1,65536,4097,2049,52,0,4112,65538,17,2,41,17,2048,69667,4097,2049,65590,32,37,65538,69682,513]

theorem envBound17549 : H12AffineFastState.Bounded env17549 := by
  intro p hp
  have h : env17549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17548_17549 : H12AffineEnvironment.transform 5 16 env17548 = env17549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17548 == env17549) = true)

def env17550 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,254010,17,21762,8193,65,171280,115015,17665,10281,119043,180272,256,98679,90202,63069]

theorem envBound17550 : H12AffineFastState.Bounded env17550 := by
  intro p hp
  have h : env17550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17541_17550 : H12AffineEnvironment.transform 6 9 env17541 = env17550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17541 == env17550) = true)

theorem identity17550 : scanCanonicalize (H12AffineFastState.compose env17550 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound17550 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17551 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,138340,1024,29789,4160,201830,17,21762,8193,65,158028,79131,17665,10281,75103,144492,256,95531,90202,513]

theorem envBound17551 : H12AffineFastState.Bounded env17551 := by
  intro p hp
  have h : env17551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17550_17551 : H12AffineEnvironment.transform 14 29788 env17550 = env17551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env17550 == env17551) = true)

theorem identity17551 : scanCanonicalize (H12AffineFastState.compose env17551 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound17551 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env17552 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90138,97406,1024,29789,4160,29820,17,21762,8193,65,67926,79131,17665,10281,75103,87158,256,95531,90202,513]

theorem envBound17552 : H12AffineFastState.Bounded env17552 := by
  intro p hp
  have h : env17552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17551_17552 : H12AffineEnvironment.transform 16 90138 env17551 = env17552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env17551 == env17552) = true)

theorem identity17552 : scanCanonicalize (H12AffineFastState.compose env17552 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound17552 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env17553 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29962,5392,2420,1024,29789,4160,29820,17,21762,8193,65,31836,16401,17665,10281,20565,8572,256,33,5456,513]

theorem envBound17553 : H12AffineFastState.Bounded env17553 := by
  intro p hp
  have h : env17553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17552_17553 : H12AffineEnvironment.transform 15 29962 env17552 = env17553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env17552 == env17553) = true)

theorem identity17553 : scanCanonicalize (H12AffineFastState.compose env17553 (packedSelected [2,14] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound17553 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env17554 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5156,8312,8494,5392,2420,1024,8313,4160,8280,17,294,8193,65,10360,5173,4389,10281,1137,8572,256,33,5456,513]

theorem envBound17554 : H12AffineFastState.Bounded env17554 := by
  intro p hp
  have h : env17554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17553_17554 : H12AffineEnvironment.transform 13 5156 env17553 = env17554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env17553 == env17554) = true)

theorem identity17554 : scanCanonicalize (H12AffineFastState.compose env17554 (packedSelected [0,3,4,5,6,7,9,10,11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound17554 : packedSelected [0,3,4,5,6,7,9,10,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env17555 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5156,293,115,5392,2420,1024,292,4160,261,17,294,348,65,2341,5173,4389,2420,1137,33,256,33,5456,513]

theorem envBound17555 : H12AffineFastState.Bounded env17555 := by
  intro p hp
  have h : env17555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17554_17555 : H12AffineEnvironment.transform 12 349 env17554 = env17555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env17554 == env17555) = true)

theorem identity17555 : scanCanonicalize (H12AffineFastState.compose env17555 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound17555 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env17556 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,120,5156,0,115,5173,2129,1024,1,4160,32,17,3,121,65,2048,5173,4096,2129,1137,33,37,33,5237,513]

theorem envBound17556 : H12AffineFastState.Bounded env17556 := by
  intro p hp
  have h : env17556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17555_17556 : H12AffineEnvironment.transform 7 37 env17555 = env17556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env17555 == env17556) = true)

theorem identity17556 : scanCanonicalize (H12AffineFastState.compose env17556 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound17556 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17557 : List Nat := [2,4,8,16,32,64,9,37,512,565,2048,4096,120,4625,0,115,4608,2129,565,1,4160,32,17,3,121,65,2048,4608,4096,2129,580,33,37,33,4672,513]

theorem envBound17557 : H12AffineFastState.Bounded env17557 := by
  intro p hp
  have h : env17557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17556_17557 : H12AffineEnvironment.transform 9 565 env17556 = env17557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env17556 == env17557) = true)

theorem identity17557 : scanCanonicalize (H12AffineFastState.compose env17557 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17557 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17558 : List Nat := [2,4,8,16,32,17,9,37,512,565,2048,4096,41,4625,0,34,4608,2048,565,1,4113,32,17,3,40,16,2048,4608,4096,2048,533,33,37,33,4625,513]

theorem envBound17558 : H12AffineFastState.Bounded env17558 := by
  intro p hp
  have h : env17558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17557_17558 : H12AffineEnvironment.transform 5 17 env17557 = env17558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17557 == env17558) = true)

theorem identity17558 : scanCanonicalize (H12AffineFastState.compose env17558 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17558 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17559 : List Nat := [2,4,8,1,32,0,9,37,512,548,2048,4096,41,4608,0,34,4608,2048,548,1,4096,32,0,3,40,1,2048,4608,4096,2048,516,33,37,33,4608,513]

theorem envBound17559 : H12AffineFastState.Bounded env17559 := by
  intro p hp
  have h : env17559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17558_17559 : H12AffineEnvironment.transform 3 1 env17558 = env17559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17558 == env17559) = true)

def env17560 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4161,4194304,16,21763,8328,65,4292003,115150,17665,10401,119043,4268163,256,98815,90203,63188]

theorem envBound17560 : H12AffineFastState.Bounded env17560 := by
  intro p hp
  have h : env17560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17539_17560 : H12AffineEnvironment.transform 20 4161 env17539 = env17560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env17539 == env17560) = true)

theorem identity17560 : scanCanonicalize (H12AffineFastState.compose env17560 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound17560 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17561 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190641,1024,32769,4161,4194304,16,21763,8328,65,4218280,57797,17665,10401,61704,4194440,256,41460,16464,63188]

theorem envBound17561 : H12AffineFastState.Bounded env17561 := by
  intro p hp
  have h : env17561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17560_17561 : H12AffineEnvironment.transform 15 8203 env17560 = env17561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env17560 == env17561) = true)

theorem identity17561 : scanCanonicalize (H12AffineFastState.compose env17561 (packedSelected [1,4,7,9,11,12,15,18,19,23,27,28,31,32,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound17561 : packedSelected [1,4,7,9,11,12,15,18,19,23,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env17562 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8203,131072,157873,1024,1,4161,4194304,16,21763,8328,65,4218280,25029,17665,10401,28936,4194440,256,8692,16464,30420]

theorem envBound17562 : H12AffineFastState.Bounded env17562 := by
  intro p hp
  have h : env17562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17561_17562 : H12AffineEnvironment.transform 14 0 env17561 = env17562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env17561 == env17562) = true)

def env17563 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,8203,131072,157753,1024,1,4161,4194304,16,21763,8192,65,4218144,24909,17665,10281,28936,4194304,256,8572,16464,30300]

theorem envBound17563 : H12AffineFastState.Bounded env17563 := by
  intro p hp
  have h : env17563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17562_17563 : H12AffineEnvironment.transform 6 8 env17562 = env17563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17562 == env17563) = true)

theorem identity17563 : scanCanonicalize (H12AffineFastState.compose env17563 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound17563 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17564 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,8203,5393,32040,1024,1,4161,4194304,16,21763,8192,65,4218144,24909,17665,10281,28936,4194304,256,8572,16464,30300]

theorem envBound17564 : H12AffineFastState.Bounded env17564 := by
  intro p hp
  have h : env17564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17563_17564 : H12AffineEnvironment.transform 16 5393 env17563 = env17564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env17563 == env17564) = true)

theorem identity17564 : scanCanonicalize (H12AffineFastState.compose env17564 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound17564 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env17565 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,8203,5393,32040,1024,1,4161,8572,16,21763,8192,65,31836,24909,17665,10281,28936,8572,256,8572,16464,30300]

theorem envBound17565 : H12AffineFastState.Bounded env17565 := by
  intro p hp
  have h : env17565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17564_17565 : H12AffineEnvironment.transform 21 8572 env17564 = env17565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env17564 == env17565) = true)

theorem identity17565 : scanCanonicalize (H12AffineFastState.compose env17565 (packedSelected [4,6,9,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound17565 : packedSelected [4,6,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env17566 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,8192,16384,0,8203,5188,31869,1024,1,4161,8233,16,21590,8192,65,31836,24600,17492,10281,28765,8233,85,8233,16464,30300]

theorem envBound17566 : H12AffineFastState.Bounded env17566 := by
  intro p hp
  have h : env17566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17565_17566 : H12AffineEnvironment.transform 7 85 env17565 = env17566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env17565 == env17566) = true)

theorem identity17566 : scanCanonicalize (H12AffineFastState.compose env17566 (packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound17566 : packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env17567 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,9,16384,0,2,5188,23668,1024,1,4161,32,16,21590,9,65,23637,16401,17492,2080,20564,32,85,32,16464,22101]

theorem envBound17567 : H12AffineFastState.Bounded env17567 := by
  intro p hp
  have h : env17567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17566_17567 : H12AffineEnvironment.transform 12 9 env17566 = env17567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env17566 == env17567) = true)

theorem identity17567 : scanCanonicalize (H12AffineFastState.compose env17567 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 3141) := by decide +kernel

theorem selectedBound17567 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env17568 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,3141,9,16384,0,2,2049,16433,1024,1,3076,32,16,18451,9,65,16400,16401,17492,2080,19473,32,85,32,16464,18960]

theorem envBound17568 : H12AffineFastState.Bounded env17568 := by
  intro p hp
  have h : env17568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17567_17568 : H12AffineEnvironment.transform 11 3141 env17567 = env17568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3141 env17567 == env17568) = true)

def env17569 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,8203,131072,157752,1024,1,4161,4194304,16,21763,8193,65,4218145,24908,17665,10280,28936,4194305,256,8573,16464,30301]

theorem envBound17569 : H12AffineFastState.Bounded env17569 := by
  intro p hp
  have h : env17569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17562_17569 : H12AffineEnvironment.transform 6 9 env17562 = env17569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17562 == env17569) = true)

theorem identity17569 : scanCanonicalize (H12AffineFastState.compose env17569 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound17569 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17570 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,8203,13389,23669,1024,1,4161,4194304,16,21763,8193,65,4218145,24908,17665,10280,28936,4194305,256,8573,16464,30301]

theorem envBound17570 : H12AffineFastState.Bounded env17570 := by
  intro p hp
  have h : env17570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17569_17570 : H12AffineEnvironment.transform 16 13389 env17569 = env17570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env17569 == env17570) = true)

theorem identity17570 : scanCanonicalize (H12AffineFastState.compose env17570 (packedSelected [0,7,10,14,15,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound17570 : packedSelected [0,7,10,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env17571 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,0,8203,13389,2340,1024,1,4161,4194304,16,82,8193,65,4196464,13341,4176,10280,9305,4194305,256,8573,5377,8972]

theorem envBound17571 : H12AffineFastState.Bounded env17571 := by
  intro p hp
  have h : env17571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17570_17571 : H12AffineEnvironment.transform 13 5457 env17570 = env17571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env17570 == env17571) = true)

theorem identity17571 : scanCanonicalize (H12AffineFastState.compose env17571 (packedSelected [0,4,7,9,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 12361) := by decide +kernel

theorem selectedBound17571 : packedSelected [0,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env17572 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,0,8203,13389,2340,1024,1,4161,12361,16,82,8193,65,14393,13341,4176,10280,9305,12360,256,8573,5377,8972]

theorem envBound17572 : H12AffineFastState.Bounded env17572 := by
  intro p hp
  have h : env17572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17571_17572 : H12AffineEnvironment.transform 21 12361 env17571 = env17572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 12361 env17571 == env17572) = true)

theorem identity17572 : scanCanonicalize (H12AffineFastState.compose env17572 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17572 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env17573 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,0,8203,13341,2340,1024,1,4113,12313,16,2,8193,17,14393,13341,4096,10280,9225,12312,256,8493,5377,8972]

theorem envBound17573 : H12AffineFastState.Bounded env17573 := by
  intro p hp
  have h : env17573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17572_17573 : H12AffineEnvironment.transform 5 16 env17572 = env17573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17572 == env17573) = true)

theorem identity17573 : scanCanonicalize (H12AffineFastState.compose env17573 (packedSelected [0,2,4,5,6,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound17573 : packedSelected [0,2,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env17574 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2065,8192,3344,0,8203,11276,2340,1024,1,2048,10248,16,2,8193,17,8232,11276,2065,10280,9225,10249,256,8493,3344,8972]

theorem envBound17574 : H12AffineFastState.Bounded env17574 := by
  intro p hp
  have h : env17574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17573_17574 : H12AffineEnvironment.transform 11 2065 env17573 = env17574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env17573 == env17574) = true)

theorem identity17574 : scanCanonicalize (H12AffineFastState.compose env17574 (packedSelected [2,3,5,6,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound17574 : packedSelected [2,3,5,6,10,11] rootPS < 2^1333 := by decide +kernel

def env17575 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2065,2089,3344,0,2082,1061,2340,1024,1,2048,33,16,2,2088,17,2049,1061,2065,1,3104,32,256,2308,3344,2853]

theorem envBound17575 : H12AffineFastState.Bounded env17575 := by
  intro p hp
  have h : env17575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17574_17575 : H12AffineEnvironment.transform 12 2089 env17574 = env17575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env17574 == env17575) = true)

theorem identity17575 : scanCanonicalize (H12AffineFastState.compose env17575 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound17575 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env17576 : List Nat := [2,4,8,16,32,16,9,256,512,1024,32,49,9,1328,0,2,1061,260,1024,1,32,33,16,2,8,17,33,1061,49,1,1024,32,256,292,1328,773]

theorem envBound17576 : H12AffineFastState.Bounded env17576 := by
  intro p hp
  have h : env17576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17575_17576 : H12AffineEnvironment.transform 10 32 env17575 = env17576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env17575 == env17576) = true)

theorem identity17576 : scanCanonicalize (H12AffineFastState.compose env17576 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound17576 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env17577 : List Nat := [2,4,8,16,32,16,9,37,512,1024,32,49,9,1045,0,2,1061,33,1024,1,32,33,16,2,8,17,33,1061,49,1,1024,32,37,1,1045,544]

theorem envBound17577 : H12AffineFastState.Bounded env17577 := by
  intro p hp
  have h : env17577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17576_17577 : H12AffineEnvironment.transform 7 37 env17576 = env17577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env17576 == env17577) = true)

theorem identity17577 : scanCanonicalize (H12AffineFastState.compose env17577 (packedSelected [0,1,5] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound17577 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env17578 : List Nat := [2,4,8,16,32,16,9,37,512,565,32,49,9,544,0,2,528,33,565,1,32,33,16,2,8,17,33,528,49,1,565,32,37,1,544,544]

theorem envBound17578 : H12AffineFastState.Bounded env17578 := by
  intro p hp
  have h : env17578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17577_17578 : H12AffineEnvironment.transform 9 565 env17577 = env17578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env17577 == env17578) = true)

theorem identity17578 : scanCanonicalize (H12AffineFastState.compose env17578 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17578 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env17579 : List Nat := [2,4,8,16,1,16,9,4,512,532,1,16,9,513,0,2,528,0,532,1,1,0,16,2,8,17,0,528,16,1,532,1,4,1,513,513]

theorem envBound17579 : H12AffineFastState.Bounded env17579 := by
  intro p hp
  have h : env17579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17578_17579 : H12AffineEnvironment.transform 4 1 env17578 = env17579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17578 == env17579) = true)

theorem identity17579 : scanCanonicalize (H12AffineFastState.compose env17579 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound17579 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17580 : List Nat := [2,4,8,16,1,16,9,4,17,5,1,16,9,16,0,2,1,0,5,1,1,0,16,2,8,17,0,1,16,1,5,1,4,1,16,16]

theorem envBound17580 : H12AffineFastState.Bounded env17580 := by
  intro p hp
  have h : env17580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17579_17580 : H12AffineEnvironment.transform 8 17 env17579 = env17580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env17579 == env17580) = true)

def env17581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830977,25265168,23160257,257,27378860,27337993,25207750]

theorem envBound17581 : H12AffineFastState.Bounded env17581 := by
  intro p hp
  have h : env17581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17394_17581 : H12AffineEnvironment.transform 18 1025 env17394 = env17581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env17394 == env17581) = true)

theorem identity17581 : scanCanonicalize (H12AffineFastState.compose env17581 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2444659) := by decide +kernel

theorem selectedBound17581 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env17582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2444659,16777216,8328,65,23235955,18973837,333859,2329970,19188067,23160257,257,17074655,17066106,19263157]

theorem envBound17582 : H12AffineFastState.Bounded env17582 := by
  intro p hp
  have h : env17582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17581_17582 : H12AffineEnvironment.transform 22 2444659 env17581 = env17582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2444659 env17581 == env17582) = true)

def env17583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2115048,2444659,16777216,8328,65,16959643,18973837,333859,2329970,19188067,16850985,257,17074655,17066106,19263157]

theorem envBound17583 : H12AffineFastState.Bounded env17583 := by
  intro p hp
  have h : env17583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17582_17583 : H12AffineEnvironment.transform 21 2115048 env17582 = env17583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2115048 env17582 == env17583) = true)

def env17584 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2115048,2444659,2431072,8328,65,2609403,302317,333859,2329970,119043,2373705,257,2199999,2191386,63189]

theorem envBound17584 : H12AffineFastState.Bounded env17584 := by
  intro p hp
  have h : env17584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17583_17584 : H12AffineEnvironment.transform 23 2431072 env17583 = env17584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431072 env17583 == env17584) = true)

def env17585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21928,351539,329760,8328,65,508091,302317,333859,236850,119043,272393,257,98815,90202,63189]

theorem envBound17585 : H12AffineFastState.Bounded env17585 := by
  intro p hp
  have h : env17585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17584_17585 : H12AffineEnvironment.transform 20 4160 env17584 = env17585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env17584 == env17585) = true)

theorem identity17585 : scanCanonicalize (H12AffineFastState.compose env17585 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound17585 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,21928,73754,95497,8328,65,245138,57796,91402,236850,119043,21792,257,98815,90202,63189]

theorem envBound17586 : H12AffineFastState.Bounded env17586 := by
  intro p hp
  have h : env17586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17585_17586 : H12AffineEnvironment.transform 17 32041 env17585 = env17586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env17585 == env17586) = true)

def env17587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,10401,1025,32769,4160,32,73754,73857,8328,65,245138,46156,77954,236850,99467,168,257,98815,79314,41821]

theorem envBound17587 : H12AffineFastState.Bounded env17587 := by
  intro p hp
  have h : env17587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17586_17587 : H12AffineEnvironment.transform 13 5512 env17586 = env17587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env17586 == env17587) = true)

def env17588 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1025,32769,4160,32,73754,73737,8192,65,245018,46156,77834,236850,99331,32,257,98679,79194,41821]

theorem envBound17588 : H12AffineFastState.Bounded env17588 := by
  intro p hp
  have h : env17588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17587_17588 : H12AffineEnvironment.transform 6 8 env17587 = env17588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17587 == env17588) = true)

theorem identity17588 : scanCanonicalize (H12AffineFastState.compose env17588 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound17588 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17589 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10281,1025,8541,4160,32,73754,73737,8192,65,203846,5392,77834,212078,75103,32,257,73771,79194,513]

theorem envBound17589 : H12AffineFastState.Bounded env17589 := by
  intro p hp
  have h : env17589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17588_17589 : H12AffineEnvironment.transform 14 8540 env17588 = env17589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env17588 == env17589) = true)

theorem identity17589 : scanCanonicalize (H12AffineFastState.compose env17589 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound17589 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env17590 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8283,131072,10281,1025,8541,4160,32,65,82,8192,65,146461,5392,4177,138293,1284,32,257,112,5377,513]

theorem envBound17590 : H12AffineFastState.Bounded env17590 := by
  intro p hp
  have h : env17590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17589_17590 : H12AffineEnvironment.transform 15 8283 env17589 = env17590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env17589 == env17590) = true)

theorem identity17590 : scanCanonicalize (H12AffineFastState.compose env17590 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound17590 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env17591 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8283,5440,10281,1025,8541,4160,32,65,82,8192,65,10589,5392,4177,2421,1284,32,257,112,5377,513]

theorem envBound17591 : H12AffineFastState.Bounded env17591 := by
  intro p hp
  have h : env17591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17590_17591 : H12AffineEnvironment.transform 16 5440 env17590 = env17591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env17590 == env17591) = true)

theorem identity17591 : scanCanonicalize (H12AffineFastState.compose env17591 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound17591 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17592 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,80,343,5440,2341,1025,81,4160,32,65,82,268,65,2129,5392,4177,2421,1284,32,257,112,5377,513]

theorem envBound17592 : H12AffineFastState.Bounded env17592 := by
  intro p hp
  have h : env17592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17591_17592 : H12AffineEnvironment.transform 12 268 env17591 = env17592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env17591 == env17592) = true)

theorem identity17592 : scanCanonicalize (H12AffineFastState.compose env17592 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2414) := by decide +kernel

theorem selectedBound17592 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17593 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2414,268,3182,80,343,3118,2341,1025,81,2350,32,65,82,268,65,2129,3198,2367,2421,1284,32,257,112,3183,513]

theorem envBound17593 : H12AffineFastState.Bounded env17593 := by
  intro p hp
  have h : env17593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17592_17593 : H12AffineEnvironment.transform 11 2414 env17592 = env17593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2414 env17592 == env17593) = true)

def env17594 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1025,32769,4160,32,73754,73736,8193,65,245019,46156,77835,236850,99330,33,257,98678,79195,41821]

theorem envBound17594 : H12AffineFastState.Bounded env17594 := by
  intro p hp
  have h : env17594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17587_17594 : H12AffineEnvironment.transform 6 9 env17587 = env17594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17587 == env17594) = true)

theorem identity17594 : scanCanonicalize (H12AffineFastState.compose env17594 (packedSelected [0,1,2,4,5,6,8,9,10,11,16,18,24,27,31] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound17594 : packedSelected [0,1,2,4,5,6,8,9,10,11,16,18,24,27,31] rootPS < 2^1333 := by decide +kernel

def env17595 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,114,131072,10280,1025,32769,4160,32,8296,8314,8193,65,179561,46156,12409,171328,33904,33,257,33028,13609,41821]

theorem envBound17595 : H12AffineFastState.Bounded env17595 := by
  intro p hp
  have h : env17595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17594_17595 : H12AffineEnvironment.transform 15 114 env17594 = env17595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env17594 == env17595) = true)

theorem identity17595 : scanCanonicalize (H12AffineFastState.compose env17595 (packedSelected [0,2,6,7,11,12,15,16,23] rootPS)) = affineNative (2^(14+1) ^^^ 9529) := by decide +kernel

theorem selectedBound17595 : packedSelected [0,2,6,7,11,12,15,16,23] rootPS < 2^1333 := by decide +kernel

def env17596 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,9529,114,131072,10280,1025,9528,4160,32,8296,8314,8193,65,137296,4469,12409,145529,8521,33,257,9277,13609,1636]

theorem envBound17596 : H12AffineFastState.Bounded env17596 := by
  intro p hp
  have h : env17596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17595_17596 : H12AffineEnvironment.transform 14 9529 env17595 = env17596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9529 env17595 == env17596) = true)

theorem identity17596 : scanCanonicalize (H12AffineFastState.compose env17596 (packedSelected [0,2,4,5,6,7,8,9,10,14,16,19,20,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound17596 : packedSelected [0,2,4,5,6,7,8,9,10,14,16,19,20,24,28] rootPS < 2^1333 := by decide +kernel

def env17597 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,1076,114,131072,2341,1025,1077,4160,32,357,375,268,65,137296,4469,4468,137588,68,33,257,1328,5156,1636]

theorem envBound17597 : H12AffineFastState.Bounded env17597 := by
  intro p hp
  have h : env17597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17596_17597 : H12AffineEnvironment.transform 12 269 env17596 = env17597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env17596 == env17597) = true)

theorem identity17597 : scanCanonicalize (H12AffineFastState.compose env17597 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound17597 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env17598 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,1076,114,4096,2341,1025,1077,4160,32,357,375,268,65,2128,4469,4468,2420,68,33,257,1328,5156,1636]

theorem envBound17598 : H12AffineFastState.Bounded env17598 := by
  intro p hp
  have h : env17598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17597_17598 : H12AffineEnvironment.transform 16 4096 env17597 = env17598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env17597 == env17598) = true)

theorem identity17598 : scanCanonicalize (H12AffineFastState.compose env17598 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound17598 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17599 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,269,4405,0,114,4096,2341,53,1,4160,32,357,375,268,65,2128,4469,4468,2420,68,33,257,260,4112,592]

theorem envBound17599 : H12AffineFastState.Bounded env17599 := by
  intro p hp
  have h : env17599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17598_17599 : H12AffineEnvironment.transform 9 52 env17598 = env17599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env17598 == env17599) = true)

theorem identity17599 : scanCanonicalize (H12AffineFastState.compose env17599 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(11+1) ^^^ 2415) := by decide +kernel

theorem selectedBound17599 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env17600 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,2415,269,2138,0,114,2415,2341,53,1,2351,32,357,375,268,65,2128,2074,2075,2420,68,33,257,260,2431,592]

theorem envBound17600 : H12AffineFastState.Bounded env17600 := by
  intro p hp
  have h : env17600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17599_17600 : H12AffineEnvironment.transform 11 2415 env17599 = env17600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2415 env17599 == env17600) = true)

theorem identity17600 : scanCanonicalize (H12AffineFastState.compose env17600 (packedSelected [0,1,3,4,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17600 : packedSelected [0,1,3,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env17601 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,2366,269,2059,0,35,2366,2341,53,1,2351,32,308,294,268,16,2049,2074,2075,2341,21,33,257,260,2350,513]

theorem envBound17601 : H12AffineFastState.Bounded env17601 := by
  intro p hp
  have h : env17601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17600_17601 : H12AffineEnvironment.transform 5 17 env17600 = env17601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17600 == env17601) = true)

theorem identity17601 : scanCanonicalize (H12AffineFastState.compose env17601 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound17601 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17602 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,2074,41,2059,0,35,2074,2049,53,1,2059,32,16,2,40,16,2049,2074,2075,2049,21,33,37,32,2058,513]

theorem envBound17602 : H12AffineFastState.Bounded env17602 := by
  intro p hp
  have h : env17602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17601_17602 : H12AffineEnvironment.transform 7 36 env17601 = env17602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17601 == env17602) = true)

theorem identity17602 : scanCanonicalize (H12AffineFastState.compose env17602 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 543) := by decide +kernel

theorem selectedBound17602 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17603 : List Nat := [2,4,8,16,32,17,9,36,512,52,543,517,41,532,0,35,517,542,53,1,532,32,16,2,40,16,542,517,516,542,21,33,37,32,533,513]

theorem envBound17603 : H12AffineFastState.Bounded env17603 := by
  intro p hp
  have h : env17603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17602_17603 : H12AffineEnvironment.transform 10 543 env17602 = env17603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 543 env17602 == env17603) = true)

theorem identity17603 : scanCanonicalize (H12AffineFastState.compose env17603 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound17603 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17604 : List Nat := [2,4,8,6,32,7,9,36,512,34,521,517,41,514,0,35,517,520,35,1,514,32,6,2,40,6,520,517,516,520,3,33,37,32,515,513]

theorem envBound17604 : H12AffineFastState.Bounded env17604 := by
  intro p hp
  have h : env17604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17603_17604 : H12AffineEnvironment.transform 3 6 env17603 = env17604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env17603 == env17604) = true)

theorem identity17604 : scanCanonicalize (H12AffineFastState.compose env17604 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound17604 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17605 : List Nat := [2,3,8,1,32,0,9,35,512,34,521,514,41,514,0,35,514,520,35,1,514,32,1,2,40,1,520,514,515,520,3,33,34,32,515,513]

theorem envBound17605 : H12AffineFastState.Bounded env17605 := by
  intro p hp
  have h : env17605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17604_17605 : H12AffineEnvironment.transform 1 3 env17604 = env17605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env17604 == env17605) = true)

theorem identity17605 : scanCanonicalize (H12AffineFastState.compose env17605 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17605 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17606 : List Nat := [2,3,8,1,0,0,9,3,512,2,521,514,9,514,0,3,514,520,3,1,514,0,1,2,8,1,520,514,515,520,3,1,2,0,515,513]

theorem envBound17606 : H12AffineFastState.Bounded env17606 := by
  intro p hp
  have h : env17606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17605_17606 : H12AffineEnvironment.transform 4 0 env17605 = env17606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17605 == env17606) = true)

theorem identity17606 : scanCanonicalize (H12AffineFastState.compose env17606 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound17606 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env17607 : List Nat := [2,3,2,1,0,0,3,3,512,2,515,514,3,514,0,3,514,514,3,1,514,0,1,2,2,1,514,514,515,514,3,1,2,0,515,513]

theorem envBound17607 : H12AffineFastState.Bounded env17607 := by
  intro p hp
  have h : env17607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17606_17607 : H12AffineEnvironment.transform 2 2 env17606 = env17607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env17606 == env17607) = true)

def env17608 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,10400,1025,32769,4160,33,73754,73856,8328,65,245138,46157,77955,236850,99466,169,257,98815,79315,41820]

theorem envBound17608 : H12AffineFastState.Bounded env17608 := by
  intro p hp
  have h : env17608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17586_17608 : H12AffineEnvironment.transform 13 5513 env17586 = env17608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env17586 == env17608) = true)

theorem identity17608 : scanCanonicalize (H12AffineFastState.compose env17608 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound17608 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env17609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,5392,10400,1025,32769,4160,33,73754,73856,8328,65,108674,46157,77955,100386,99466,169,257,98815,79315,41820]

theorem envBound17609 : H12AffineFastState.Bounded env17609 := by
  intro p hp
  have h : env17609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17608_17609 : H12AffineEnvironment.transform 16 5392 env17608 = env17609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env17608 == env17609) = true)

theorem identity17609 : scanCanonicalize (H12AffineFastState.compose env17609 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound17609 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env17610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,40970,5392,10400,1025,32769,4160,33,32784,32906,8328,65,2184,46157,37001,10280,9344,169,257,8693,38361,41820]

theorem envBound17610 : H12AffineFastState.Bounded env17610 := by
  intro p hp
  have h : env17610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17609_17610 : H12AffineEnvironment.transform 15 40970 env17609 = env17610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env17609 == env17610) = true)

theorem identity17610 : scanCanonicalize (H12AffineFastState.compose env17610 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound17610 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env17611 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8661,479,5392,10400,1025,8660,4160,33,8645,8543,8328,65,2184,5528,12636,10280,9344,169,257,8693,13324,649]

theorem envBound17611 : H12AffineFastState.Bounded env17611 := by
  intro p hp
  have h : env17611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17610_17611 : H12AffineEnvironment.transform 14 8661 env17610 = env17611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env17610 == env17611) = true)

theorem identity17611 : scanCanonicalize (H12AffineFastState.compose env17611 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound17611 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17612 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5513,137,479,5392,2556,1025,136,4160,33,153,3,468,65,2184,5528,4096,2420,1500,169,257,169,5456,649]

theorem envBound17612 : H12AffineFastState.Bounded env17612 := by
  intro p hp
  have h : env17612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17611_17612 : H12AffineEnvironment.transform 12 348 env17611 = env17612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env17611 == env17612) = true)

theorem identity17612 : scanCanonicalize (H12AffineFastState.compose env17612 (packedSelected [3,5,6,10,12,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound17612 : packedSelected [3,5,6,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env17613 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,348,5409,33,375,5392,2388,1025,32,4160,33,49,3,380,65,2080,5424,4096,2420,1396,1,257,1,5456,545]

theorem envBound17613 : H12AffineFastState.Bounded env17613 := by
  intro p hp
  have h : env17613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17612_17613 : H12AffineEnvironment.transform 6 40 env17612 = env17613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env17612 == env17613) = true)

theorem identity17613 : scanCanonicalize (H12AffineFastState.compose env17613 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound17613 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17614 : List Nat := [2,4,8,16,32,49,40,256,512,1024,2048,4096,301,5409,33,262,5392,2341,1025,32,4145,33,49,3,269,48,2080,5424,4096,2309,1285,1,257,1,5409,545]

theorem envBound17614 : H12AffineFastState.Bounded env17614 := by
  intro p hp
  have h : env17614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17613_17614 : H12AffineEnvironment.transform 5 49 env17613 = env17614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env17613 == env17614) = true)

theorem identity17614 : scanCanonicalize (H12AffineFastState.compose env17614 (packedSelected [0,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound17614 : packedSelected [0,7,10] rootPS < 2^1333 := by decide +kernel

def env17615 : List Nat := [2,4,8,16,32,49,40,256,512,1024,2048,1044,301,309,33,262,260,2341,1025,32,1061,33,49,3,269,48,2080,292,1044,2309,1285,1,257,1,309,545]

theorem envBound17615 : H12AffineFastState.Bounded env17615 := by
  intro p hp
  have h : env17615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17614_17615 : H12AffineEnvironment.transform 11 1044 env17614 = env17615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env17614 == env17615) = true)

theorem identity17615 : scanCanonicalize (H12AffineFastState.compose env17615 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound17615 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env17616 : List Nat := [2,4,8,16,32,49,40,256,512,52,2048,32,301,309,33,262,260,2341,53,32,17,33,49,3,269,48,2080,292,32,2309,305,1,257,1,309,545]

theorem envBound17616 : H12AffineFastState.Bounded env17616 := by
  intro p hp
  have h : env17616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17615_17616 : H12AffineEnvironment.transform 9 52 env17615 = env17616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env17615 == env17616) = true)

theorem identity17616 : scanCanonicalize (H12AffineFastState.compose env17616 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17616 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env17617 : List Nat := [2,4,8,16,32,49,40,4,512,52,2048,32,41,49,33,2,0,2081,53,32,17,33,49,3,9,48,2080,32,32,2049,53,1,5,1,49,545]

theorem envBound17617 : H12AffineFastState.Bounded env17617 := by
  intro p hp
  have h : env17617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17616_17617 : H12AffineEnvironment.transform 7 4 env17616 = env17617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17616 == env17617) = true)

theorem identity17617 : scanCanonicalize (H12AffineFastState.compose env17617 (packedSelected [1,2,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound17617 : packedSelected [1,2,8,11] rootPS < 2^1333 := by decide +kernel

def env17618 : List Nat := [2,4,8,16,32,49,40,4,512,52,33,32,41,49,33,2,0,0,53,32,17,33,49,3,9,48,1,32,32,32,53,1,5,1,49,545]

theorem envBound17618 : H12AffineFastState.Bounded env17618 := by
  intro p hp
  have h : env17618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17617_17618 : H12AffineEnvironment.transform 10 33 env17617 = env17618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env17617 == env17618) = true)

theorem identity17618 : scanCanonicalize (H12AffineFastState.compose env17618 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17618 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env17619 : List Nat := [2,4,8,16,0,17,8,4,512,20,1,0,9,17,1,2,0,0,21,0,17,1,17,3,9,16,1,0,0,0,21,1,5,1,17,513]

theorem envBound17619 : H12AffineFastState.Bounded env17619 := by
  intro p hp
  have h : env17619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17618_17619 : H12AffineEnvironment.transform 4 0 env17618 = env17619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17618 == env17619) = true)

theorem identity17619 : scanCanonicalize (H12AffineFastState.compose env17619 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound17619 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17620 : List Nat := [2,4,8,16,0,17,8,4,17,20,1,0,9,17,1,2,0,0,21,0,17,1,17,3,9,16,1,0,0,0,21,1,5,1,17,16]

theorem envBound17620 : H12AffineFastState.Bounded env17620 := by
  intro p hp
  have h : env17620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17619_17620 : H12AffineEnvironment.transform 8 17 env17619 = env17620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env17619 == env17620) = true)

def env17621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21929,351538,329761,8328,65,508090,302317,333859,236851,119043,272392,257,98814,90203,63189]

theorem envBound17621 : H12AffineFastState.Bounded env17621 := by
  intro p hp
  have h : env17621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17584_17621 : H12AffineEnvironment.transform 20 4161 env17584 = env17621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env17584 == env17621) = true)

def env17622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,4161,21929,95634,73857,8328,65,256026,46157,77955,236851,119043,168,257,98814,90203,63189]

theorem envBound17622 : H12AffineFastState.Bounded env17622 := by
  intro p hp
  have h : env17622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17621_17622 : H12AffineEnvironment.transform 17 10400 env17621 = env17622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env17621 == env17622) = true)

theorem identity17622 : scanCanonicalize (H12AffineFastState.compose env17622 (packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,23,24,26,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 30082) := by decide +kernel

theorem selectedBound17622 : packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,23,24,26,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env17623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,30082,131072,10400,1025,32769,4161,21929,16,21763,8328,65,171416,46157,17665,190641,42113,168,257,62588,5593,63189]

theorem envBound17623 : H12AffineFastState.Bounded env17623 := by
  intro p hp
  have h : env17623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17622_17623 : H12AffineEnvironment.transform 15 30082 env17622 = env17623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30082 env17622 == env17623) = true)

theorem identity17623 : scanCanonicalize (H12AffineFastState.compose env17623 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8353) := by decide +kernel

theorem selectedBound17623 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env17624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,30082,131072,10400,1025,8352,4161,21929,16,21763,8328,65,146745,5356,17665,149520,1056,168,257,21725,5593,22132]

theorem envBound17624 : H12AffineFastState.Bounded env17624 := by
  intro p hp
  have h : env17624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17623_17624 : H12AffineEnvironment.transform 14 8353 env17623 = env17624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env17623 == env17624) = true)

theorem identity17624 : scanCanonicalize (H12AffineFastState.compose env17624 (packedSelected [4,6,7,16,20,22,27] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound17624 : packedSelected [4,6,7,16,20,22,27] rootPS < 2^1333 := by decide +kernel

def env17625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5236,8353,8694,131072,10400,1025,8352,4161,477,16,375,8328,65,146745,5356,4469,138340,1056,168,257,169,5593,512]

theorem envBound17625 : H12AffineFastState.Bounded env17625 := by
  intro p hp
  have h : env17625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17624_17625 : H12AffineEnvironment.transform 13 5236 env17624 = env17625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env17624 == env17625) = true)

theorem identity17625 : scanCanonicalize (H12AffineFastState.compose env17625 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound17625 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env17626 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,5236,8353,8322,131072,10400,1025,8352,4161,169,16,3,8328,65,146509,5356,4097,138340,1056,168,117,169,5293,512]

theorem envBound17626 : H12AffineFastState.Bounded env17626 := by
  intro p hp
  have h : env17626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17625_17626 : H12AffineEnvironment.transform 7 116 env17625 = env17626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env17625 == env17626) = true)

theorem identity17626 : scanCanonicalize (H12AffineFastState.compose env17626 (packedSelected [1,4,6,8,9,10,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound17626 : packedSelected [1,4,6,8,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env17627 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,120,5236,217,250,131072,2264,1025,216,4161,169,16,3,240,65,138293,5356,4097,138340,1056,168,117,169,5293,512]

theorem envBound17627 : H12AffineFastState.Bounded env17627 := by
  intro p hp
  have h : env17627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17626_17627 : H12AffineEnvironment.transform 12 120 env17626 = env17627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env17626 == env17627) = true)

theorem identity17627 : scanCanonicalize (H12AffineFastState.compose env17627 (packedSelected [0,4,6,10,14] rootPS)) = affineNative (2^(16+1) ^^^ 5357) := by decide +kernel

theorem selectedBound17627 : packedSelected [0,4,6,10,14] rootPS < 2^1333 := by decide +kernel

def env17628 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,120,5236,217,250,5357,2264,1025,216,4161,169,16,3,240,65,2264,5356,4097,2185,1056,168,117,169,5293,512]

theorem envBound17628 : H12AffineFastState.Bounded env17628 := by
  intro p hp
  have h : env17628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17627_17628 : H12AffineEnvironment.transform 16 5357 env17627 = env17628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5357 env17627 == env17628) = true)

theorem identity17628 : scanCanonicalize (H12AffineFastState.compose env17628 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17628 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17629 : List Nat := [2,4,8,16,0,64,128,84,512,1024,2048,4096,88,5204,217,218,5325,2264,1025,216,4161,137,16,3,208,65,2264,5324,4097,2185,1024,136,85,137,5261,512]

theorem envBound17629 : H12AffineFastState.Bounded env17629 := by
  intro p hp
  have h : env17629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17628_17629 : H12AffineEnvironment.transform 4 0 env17628 = env17629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17628 == env17629) = true)

theorem identity17629 : scanCanonicalize (H12AffineFastState.compose env17629 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound17629 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env17630 : List Nat := [2,4,8,16,0,64,128,84,512,69,2048,4096,88,4113,217,218,4232,2264,68,216,4161,137,16,3,208,65,2264,4233,4097,2185,69,136,85,137,4296,512]

theorem envBound17630 : H12AffineFastState.Bounded env17630 := by
  intro p hp
  have h : env17630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17629_17630 : H12AffineEnvironment.transform 9 69 env17629 = env17630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env17629 == env17630) = true)

theorem identity17630 : scanCanonicalize (H12AffineFastState.compose env17630 (packedSelected [11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound17630 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env17631 : List Nat := [2,4,8,16,0,64,9,84,512,69,2048,4096,88,4113,80,83,4097,2129,68,81,4161,0,16,3,89,65,2129,4096,4097,2048,69,1,85,0,4161,512]

theorem envBound17631 : H12AffineFastState.Bounded env17631 := by
  intro p hp
  have h : env17631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17630_17631 : H12AffineEnvironment.transform 6 9 env17630 = env17631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17630 == env17631) = true)

theorem identity17631 : scanCanonicalize (H12AffineFastState.compose env17631 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound17631 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17632 : List Nat := [2,4,8,16,0,64,9,84,512,69,2048,81,88,64,80,83,80,2129,68,81,16,0,16,3,89,65,2129,81,80,2048,69,1,85,0,16,512]

theorem envBound17632 : H12AffineFastState.Bounded env17632 := by
  intro p hp
  have h : env17632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17631_17632 : H12AffineEnvironment.transform 11 81 env17631 = env17632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env17631 == env17632) = true)

theorem identity17632 : scanCanonicalize (H12AffineFastState.compose env17632 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound17632 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17633 : List Nat := [2,4,8,16,0,64,9,84,81,69,2048,81,88,64,80,83,80,2129,68,81,16,0,16,3,89,65,2129,81,80,2048,69,1,85,0,16,81]

theorem envBound17633 : H12AffineFastState.Bounded env17633 := by
  intro p hp
  have h : env17633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17632_17633 : H12AffineEnvironment.transform 8 81 env17632 = env17633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env17632 == env17633) = true)

theorem identity17633 : scanCanonicalize (H12AffineFastState.compose env17633 (packedSelected [0,1,4] rootPS)) = affineNative (2^(10+1) ^^^ 68) := by decide +kernel

theorem selectedBound17633 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env17634 : List Nat := [2,4,8,16,0,64,9,84,81,69,68,81,88,64,80,83,80,21,68,81,16,0,16,3,89,65,21,81,80,68,69,1,85,0,16,81]

theorem envBound17634 : H12AffineFastState.Bounded env17634 := by
  intro p hp
  have h : env17634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17633_17634 : H12AffineEnvironment.transform 10 68 env17633 = env17634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 68 env17633 == env17634) = true)

theorem identity17634 : scanCanonicalize (H12AffineFastState.compose env17634 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17634 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env17635 : List Nat := [2,4,8,16,0,16,9,4,1,21,20,1,8,16,0,3,0,21,20,1,16,0,16,3,9,17,21,1,0,20,21,1,5,0,16,1]

theorem envBound17635 : H12AffineFastState.Bounded env17635 := by
  intro p hp
  have h : env17635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17634_17635 : H12AffineEnvironment.transform 5 16 env17634 = env17635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17634 == env17635) = true)

theorem identity17635 : scanCanonicalize (H12AffineFastState.compose env17635 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound17635 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17636 : List Nat := [2,4,8,5,0,5,9,4,1,0,1,1,8,5,0,3,0,0,1,1,5,0,5,3,9,4,0,1,0,1,0,1,5,0,5,1]

theorem envBound17636 : H12AffineFastState.Bounded env17636 := by
  intro p hp
  have h : env17636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17635_17636 : H12AffineEnvironment.transform 3 5 env17635 = env17636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env17635 == env17636) = true)

def env17637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,4161,21929,95635,73856,8328,65,256027,46156,77954,236851,119043,169,257,98814,90203,63189]

theorem envBound17637 : H12AffineFastState.Bounded env17637 := by
  intro p hp
  have h : env17637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17621_17637 : H12AffineEnvironment.transform 17 10401 env17621 = env17637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env17621 == env17637) = true)

theorem identity17637 : scanCanonicalize (H12AffineFastState.compose env17637 (packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,23,24,26,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound17637 : packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,23,24,26,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env17638 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10401,1025,29909,4161,21929,95635,73856,8328,65,203983,16536,77954,223719,75223,169,257,95530,90203,513]

theorem envBound17638 : H12AffineFastState.Bounded env17638 := by
  intro p hp
  have h : env17638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17637_17638 : H12AffineEnvironment.transform 14 29908 env17637 = env17638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env17637 == env17638) = true)

def env17639 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10401,1025,8661,4161,169,73875,73856,8328,65,203983,5528,77954,212199,75223,169,257,73770,79195,513]

theorem envBound17639 : H12AffineFastState.Bounded env17639 := by
  intro p hp
  have h : env17639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17638_17639 : H12AffineEnvironment.transform 13 5376 env17638 = env17639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env17638 == env17639) = true)

theorem identity17639 : scanCanonicalize (H12AffineFastState.compose env17639 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound17639 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17640 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10281,1025,8541,4161,33,73755,73736,8192,65,203847,5392,77834,212079,75103,33,257,73770,79195,513]

theorem envBound17640 : H12AffineFastState.Bounded env17640 := by
  intro p hp
  have h : env17640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17639_17640 : H12AffineEnvironment.transform 6 8 env17639 = env17640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17639 == env17640) = true)

theorem identity17640 : scanCanonicalize (H12AffineFastState.compose env17640 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

end H12CloudChart0