import H12CloudChart0Data072

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans18401_18402 : H12AffineEnvironment.transform 11 3109 env18401 = env18402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env18401 == env18402) = true)

theorem identity18402 : scanCanonicalize (H12AffineFastState.compose env18402 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound18402 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env18403 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,2064,268,16384,18724,263,16400,16384,52,18725,2048,32,18741,2,268,16,16676,16401,2065,16385,304,18692,257,18692,16384,513]

theorem envBound18403 : H12AffineFastState.Bounded env18403 := by
  intro p hp
  have h : env18403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18402_18403 : H12AffineEnvironment.transform 9 53 env18402 = env18403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env18402 == env18403) = true)

theorem identity18403 : scanCanonicalize (H12AffineFastState.compose env18403 (packedSelected [0,7,10] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound18403 : packedSelected [0,7,10] rootPS < 2^1333 := by decide +kernel

def env18404 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,2064,268,1,2341,263,17,1,52,2340,2048,32,2356,2,268,16,293,16,2065,0,304,2309,257,2309,1,513]

theorem envBound18404 : H12AffineFastState.Bounded env18404 := by
  intro p hp
  have h : env18404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18403_18404 : H12AffineEnvironment.transform 13 1 env18403 = env18404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env18403 == env18404) = true)

theorem identity18404 : scanCanonicalize (H12AffineFastState.compose env18404 (packedSelected [11] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound18404 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env18405 : List Nat := [2,4,8,16,32,16,8,256,512,53,292,308,268,1,1,263,17,1,52,0,292,32,16,2,268,16,293,16,309,0,304,33,257,33,1,513]

theorem envBound18405 : H12AffineFastState.Bounded env18405 := by
  intro p hp
  have h : env18405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18404_18405 : H12AffineEnvironment.transform 10 292 env18404 = env18405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env18404 == env18405) = true)

def env18406 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,4160,400453,201814,213316,8193,64,97547,139612,217415,335882,75103,272392,257,95530,90203,513]

theorem envBound18406 : H12AffineFastState.Bounded env18406 := by
  intro p hp
  have h : env18406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18395_18406 : H12AffineEnvironment.transform 6 9 env18395 = env18406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18395 == env18406) = true)

theorem identity18406 : scanCanonicalize (H12AffineFastState.compose env18406 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound18406 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env18407 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90139,262144,1025,29789,4160,359518,29773,8543,8193,64,97547,82247,12636,335882,75103,272392,257,95530,90203,513]

theorem envBound18407 : H12AffineFastState.Bounded env18407 := by
  intro p hp
  have h : env18407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18406_18407 : H12AffineEnvironment.transform 16 90139 env18406 = env18407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env18406 == env18407) = true)

theorem identity18407 : scanCanonicalize (H12AffineFastState.compose env18407 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 96623) := by decide +kernel

theorem selectedBound18407 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env18408 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90139,96623,1025,29789,4160,1329,29773,8543,8193,64,97547,82247,12636,22885,75103,86375,257,95530,90203,513]

theorem envBound18408 : H12AffineFastState.Bounded env18408 := by
  intro p hp
  have h : env18408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18407_18408 : H12AffineEnvironment.transform 17 96623 env18407 = env18408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 96623 env18407 == env18408) = true)

theorem identity18408 : scanCanonicalize (H12AffineFastState.compose env18408 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 20759) := by decide +kernel

theorem selectedBound18408 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env18409 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,20759,12556,10360,1025,29789,4160,1329,29773,8543,8193,64,11292,4176,12636,22885,29768,112,257,9277,12620,513]

theorem envBound18409 : H12AffineFastState.Bounded env18409 := by
  intro p hp
  have h : env18409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18408_18409 : H12AffineEnvironment.transform 15 20759 env18408 = env18409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20759 env18408 == env18409) = true)

theorem identity18409 : scanCanonicalize (H12AffineFastState.compose env18409 (packedSelected [2,4,6,7,9,12,15,17,18,23,27] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound18409 : packedSelected [2,4,6,7,9,12,15,17,18,23,27] rootPS < 2^1333 := by decide +kernel

def env18410 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,8192,16384,28729,20759,12556,10360,100,28728,4160,340,28712,8543,8193,64,10361,4176,12636,22885,28717,112,257,8280,12620,513]

theorem envBound18410 : H12AffineFastState.Bounded env18410 := by
  intro p hp
  have h : env18410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18409_18410 : H12AffineEnvironment.transform 9 101 env18409 = env18410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env18409 == env18410) = true)

theorem identity18410 : scanCanonicalize (H12AffineFastState.compose env18410 (packedSelected [3,5,10,11,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound18410 : packedSelected [3,5,10,11,17,18] rootPS < 2^1333 := by decide +kernel

def env18411 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,8192,4404,8461,35,12556,10360,100,8460,4160,340,8476,8543,8193,64,10361,4176,12636,2129,8473,112,257,8280,12620,513]

theorem envBound18411 : H12AffineFastState.Bounded env18411 := by
  intro p hp
  have h : env18411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18410_18411 : H12AffineEnvironment.transform 13 4404 env18410 = env18411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env18410 == env18411) = true)

theorem identity18411 : scanCanonicalize (H12AffineFastState.compose env18411 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound18411 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env18412 : List Nat := [2,4,8,16,32,64,9,37,512,101,2048,4096,8192,4113,8232,35,12329,10360,100,8233,4160,113,8249,8314,8193,64,10361,4176,12409,2129,8252,112,36,8280,12393,513]

theorem envBound18412 : H12AffineFastState.Bounded env18412 := by
  intro p hp
  have h : env18412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18411_18412 : H12AffineEnvironment.transform 7 37 env18411 = env18412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env18411 == env18412) = true)

theorem identity18412 : scanCanonicalize (H12AffineFastState.compose env18412 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound18412 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18413 : List Nat := [2,4,8,16,32,64,9,37,512,101,2048,4096,120,4113,80,35,4177,2048,100,81,4160,113,65,2,121,64,2049,4176,4097,2129,68,112,36,32,4113,513]

theorem envBound18413 : H12AffineFastState.Bounded env18413 := by
  intro p hp
  have h : env18413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18412_18413 : H12AffineEnvironment.transform 12 120 env18412 = env18413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env18412 == env18413) = true)

theorem identity18413 : scanCanonicalize (H12AffineFastState.compose env18413 (packedSelected [2,3] rootPS)) = affineNative (2^(8+1) ^^^ 90) := by decide +kernel

theorem selectedBound18413 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env18414 : List Nat := [2,4,8,16,32,64,9,37,90,101,2048,4096,120,4113,80,35,4177,2048,100,81,4160,113,65,2,121,64,2049,4176,4097,2129,68,112,36,32,4113,91]

theorem envBound18414 : H12AffineFastState.Bounded env18414 := by
  intro p hp
  have h : env18414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18413_18414 : H12AffineEnvironment.transform 8 90 env18413 = env18414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 90 env18413 == env18414) = true)

theorem identity18414 : scanCanonicalize (H12AffineFastState.compose env18414 (packedSelected [1,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound18414 : packedSelected [1,2,7] rootPS < 2^1333 := by decide +kernel

def env18415 : List Nat := [2,4,8,16,32,11,9,37,17,46,2048,4096,51,4113,27,35,4122,2048,47,26,4107,58,10,2,50,11,2049,4123,4097,2074,15,59,36,32,4113,16]

theorem envBound18415 : H12AffineFastState.Bounded env18415 := by
  intro p hp
  have h : env18415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18414_18415 : H12AffineEnvironment.transform 5 11 env18414 = env18415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env18414 == env18415) = true)

theorem identity18415 : scanCanonicalize (H12AffineFastState.compose env18415 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound18415 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env18416 : List Nat := [2,4,8,16,32,11,9,37,17,46,10,4096,51,4113,27,35,4122,10,47,26,4107,58,10,2,50,11,11,4123,4097,16,15,59,36,32,4113,16]

theorem envBound18416 : H12AffineFastState.Bounded env18416 := by
  intro p hp
  have h : env18416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18415_18416 : H12AffineEnvironment.transform 10 10 env18415 = env18416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env18415 == env18416) = true)

theorem identity18416 : scanCanonicalize (H12AffineFastState.compose env18416 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound18416 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18417 : List Nat := [2,4,8,11,32,11,9,37,10,46,10,4096,40,4106,0,35,4097,10,47,1,4107,33,10,2,41,11,11,4096,4097,11,15,32,36,32,4106,11]

theorem envBound18417 : H12AffineFastState.Bounded env18417 := by
  intro p hp
  have h : env18417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18416_18417 : H12AffineEnvironment.transform 3 11 env18416 = env18417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env18416 == env18417) = true)

theorem identity18417 : scanCanonicalize (H12AffineFastState.compose env18417 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 11) := by decide +kernel

theorem selectedBound18417 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18418 : List Nat := [2,4,8,11,32,11,9,37,10,46,10,11,40,1,0,35,10,10,47,1,0,33,10,2,41,11,11,11,10,11,15,32,36,32,1,11]

theorem envBound18418 : H12AffineFastState.Bounded env18418 := by
  intro p hp
  have h : env18418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18417_18418 : H12AffineEnvironment.transform 11 11 env18417 = env18418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 11 env18417 == env18418) = true)

theorem identity18418 : scanCanonicalize (H12AffineFastState.compose env18418 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound18418 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18419 : List Nat := [2,4,8,11,0,11,9,5,10,14,10,11,8,1,0,3,10,10,15,1,0,1,10,2,9,11,11,11,10,11,15,0,4,0,1,11]

theorem envBound18419 : H12AffineFastState.Bounded env18419 := by
  intro p hp
  have h : env18419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18418_18419 : H12AffineEnvironment.transform 4 0 env18418 = env18419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18418 == env18419) = true)

theorem identity18419 : scanCanonicalize (H12AffineFastState.compose env18419 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound18419 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18420 : List Nat := [2,4,2,1,0,1,3,5,0,4,0,1,2,1,0,3,0,0,5,1,0,1,0,2,3,1,1,1,0,1,5,0,4,0,1,1]

theorem envBound18420 : H12AffineFastState.Bounded env18420 := by
  intro p hp
  have h : env18420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18419_18420 : H12AffineEnvironment.transform 2 2 env18419 = env18420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env18419 == env18420) = true)

def env18421 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452752,253962,242968,8328,64,97666,139732,238874,335882,119043,272393,257,98814,90202,63188]

theorem envBound18421 : H12AffineFastState.Bounded env18421 := by
  intro p hp
  have h : env18421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18393_18421 : H12AffineEnvironment.transform 20 4161 env18393 = env18421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env18393 == env18421) = true)

theorem identity18421 : scanCanonicalize (H12AffineFastState.compose env18421 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound18421 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18422 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13508,262144,1025,32769,4161,318548,120014,98780,8328,64,97666,5392,102878,335882,119043,272393,257,98814,90202,63188]

theorem envBound18422 : H12AffineFastState.Bounded env18422 := by
  intro p hp
  have h : env18422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18421_18422 : H12AffineEnvironment.transform 16 13508 env18421 = env18422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env18421 == env18422) = true)

def env18423 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,262144,1025,32769,4161,318548,119878,98644,8192,64,97546,5392,102742,335882,119043,272393,257,98678,90202,63068]

theorem envBound18423 : H12AffineFastState.Bounded env18423 := by
  intro p hp
  have h : env18423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18422_18423 : H12AffineEnvironment.transform 6 8 env18422 = env18423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18422 == env18423) = true)

theorem identity18423 : scanCanonicalize (H12AffineFastState.compose env18423 (packedSelected [0,1,7,8,9,12,14,16,18,22,23,26,38] rootPS)) = affineNative (2^(17+1) ^^^ 89379) := by decide +kernel

theorem selectedBound18423 : packedSelected [0,1,7,8,9,12,14,16,18,22,23,26,38] rootPS < 2^1333 := by decide +kernel

def env18424 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,89379,1025,32769,4161,98679,119878,98644,8192,64,97546,5392,102742,32041,119043,95530,257,98678,90202,63068]

theorem envBound18424 : H12AffineFastState.Bounded env18424 := by
  intro p hp
  have h : env18424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18423_18424 : H12AffineEnvironment.transform 17 89379 env18423 = env18424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89379 env18423 == env18424) = true)

theorem identity18424 : scanCanonicalize (H12AffineFastState.compose env18424 (packedSelected [0,3,4,5,10,12,14,15,17,20,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound18424 : packedSelected [0,3,4,5,10,12,14,15,17,20,22,27] rootPS < 2^1333 := by decide +kernel

def env18425 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,263,13388,23588,1025,32769,4161,32880,54593,32851,8192,64,31757,5392,36945,32041,53252,29741,257,32881,24925,63068]

theorem envBound18425 : H12AffineFastState.Bounded env18425 := by
  intro p hp
  have h : env18425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18424_18425 : H12AffineEnvironment.transform 15 263 env18424 = env18425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env18424 == env18425) = true)

theorem identity18425 : scanCanonicalize (H12AffineFastState.compose env18425 (packedSelected [0,5,7,9,12,14,15,17,18,19,20,22,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound18425 : packedSelected [0,5,7,9,12,14,15,17,18,19,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env18426 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29708,263,13388,23588,1025,29709,4161,29820,8525,29791,8192,64,31757,5392,25693,32041,9224,29741,257,29821,24925,592]

theorem envBound18426 : H12AffineFastState.Bounded env18426 := by
  intro p hp
  have h : env18426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18425_18426 : H12AffineEnvironment.transform 14 29708 env18425 = env18426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env18425 == env18426) = true)

theorem identity18426 : scanCanonicalize (H12AffineFastState.compose env18426 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18426 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env18427 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29708,263,13341,23588,1025,29709,4112,29741,8476,29710,8192,17,31757,5392,25612,32041,9224,29741,257,29740,24844,513]

theorem envBound18427 : H12AffineFastState.Bounded env18427 := by
  intro p hp
  have h : env18427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18426_18427 : H12AffineEnvironment.transform 5 17 env18426 = env18427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18426 == env18427) = true)

theorem identity18427 : scanCanonicalize (H12AffineFastState.compose env18427 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound18427 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env18428 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,21761,263,5392,23588,1025,21760,4112,21792,17,21763,269,17,23808,5392,17665,23588,1285,21792,257,21793,16385,513]

theorem envBound18428 : H12AffineFastState.Bounded env18428 := by
  intro p hp
  have h : env18428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18427_18428 : H12AffineEnvironment.transform 12 269 env18427 = env18428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env18427 == env18428) = true)

theorem identity18428 : scanCanonicalize (H12AffineFastState.compose env18428 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound18428 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18429 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,0,263,5392,2341,1025,1,4112,33,17,2,269,17,2049,5392,4096,2341,1285,33,257,32,5376,513]

theorem envBound18429 : H12AffineFastState.Bounded env18429 := by
  intro p hp
  have h : env18429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18428_18429 : H12AffineEnvironment.transform 13 5377 env18428 = env18429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env18428 == env18429) = true)

theorem identity18429 : scanCanonicalize (H12AffineFastState.compose env18429 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound18429 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18430 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,277,269,1044,0,263,1029,2341,1025,1,261,33,17,2,269,17,2049,1029,277,2341,1285,33,257,32,1045,513]

theorem envBound18430 : H12AffineFastState.Bounded env18430 := by
  intro p hp
  have h : env18430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18429_18430 : H12AffineEnvironment.transform 11 277 env18429 = env18430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env18429 == env18430) = true)

theorem identity18430 : scanCanonicalize (H12AffineFastState.compose env18430 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound18430 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18431 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,277,269,293,0,263,308,2341,304,1,261,33,17,2,269,17,2049,308,277,2341,52,33,257,32,292,513]

theorem envBound18431 : H12AffineFastState.Bounded env18431 := by
  intro p hp
  have h : env18431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18430_18431 : H12AffineEnvironment.transform 9 305 env18430 = env18431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env18430 == env18431) = true)

theorem identity18431 : scanCanonicalize (H12AffineFastState.compose env18431 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound18431 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18432 : List Nat := [2,4,8,16,32,17,8,256,292,305,2048,277,269,293,0,263,308,2341,304,1,261,33,17,2,269,17,2049,308,277,2341,52,33,257,32,292,293]

theorem envBound18432 : H12AffineFastState.Bounded env18432 := by
  intro p hp
  have h : env18432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18431_18432 : H12AffineEnvironment.transform 8 292 env18431 = env18432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env18431 == env18432) = true)

theorem identity18432 : scanCanonicalize (H12AffineFastState.compose env18432 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound18432 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18433 : List Nat := [2,4,8,16,17,17,8,256,277,256,2048,277,269,276,0,263,261,2324,257,1,261,16,17,2,269,17,2049,261,277,2324,5,16,257,17,277,276]

theorem envBound18433 : H12AffineFastState.Bounded env18433 := by
  intro p hp
  have h : env18433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18432_18433 : H12AffineEnvironment.transform 4 17 env18432 = env18433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env18432 == env18433) = true)

theorem identity18433 : scanCanonicalize (H12AffineFastState.compose env18433 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound18433 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18434 : List Nat := [2,4,8,16,17,17,8,256,277,256,17,277,269,276,0,263,261,261,257,1,261,16,17,2,269,17,16,261,277,261,5,16,257,17,277,276]

theorem envBound18434 : H12AffineFastState.Bounded env18434 := by
  intro p hp
  have h : env18434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18433_18434 : H12AffineEnvironment.transform 10 17 env18433 = env18434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env18433 == env18434) = true)

def env18435 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13389,262144,1025,32769,4161,318548,119879,98645,8193,64,97547,5392,102743,335882,119043,272393,257,98679,90202,63069]

theorem envBound18435 : H12AffineFastState.Bounded env18435 := by
  intro p hp
  have h : env18435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18422_18435 : H12AffineEnvironment.transform 6 9 env18422 = env18435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18422 == env18435) = true)

theorem identity18435 : scanCanonicalize (H12AffineFastState.compose env18435 (packedSelected [0,1,7,8,9,12,14,16,18,22,23,26,38] rootPS)) = affineNative (2^(17+1) ^^^ 10508) := by decide +kernel

theorem selectedBound18435 : packedSelected [0,1,7,8,9,12,14,16,18,22,23,26,38] rootPS < 2^1333 := by decide +kernel

def env18436 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13389,10508,1025,32769,4161,62808,119879,98645,8193,64,97547,5392,102743,67846,119043,261,257,98679,90202,63069]

theorem envBound18436 : H12AffineFastState.Bounded env18436 := by
  intro p hp
  have h : env18436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18435_18436 : H12AffineEnvironment.transform 17 10508 env18435 = env18436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10508 env18435 == env18436) = true)

theorem identity18436 : scanCanonicalize (H12AffineFastState.compose env18436 (packedSelected [0,1,2,4,5,6,7,9,10,12,15,16,17,18,19,20,24,26,28,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 29743) := by decide +kernel

theorem selectedBound18436 : packedSelected [0,1,2,4,5,6,7,9,10,12,15,16,17,18,19,20,24,26,28,32,35] rootPS < 2^1333 := by decide +kernel

def env18437 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29743,13389,10508,1025,32769,4161,62808,41064,62842,8193,64,2340,5392,58744,32041,42284,261,257,62808,5237,63069]

theorem envBound18437 : H12AffineFastState.Bounded env18437 := by
  intro p hp
  have h : env18437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18436_18437 : H12AffineEnvironment.transform 15 29743 env18436 = env18437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29743 env18436 == env18437) = true)

theorem identity18437 : scanCanonicalize (H12AffineFastState.compose env18437 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21541) := by decide +kernel

theorem selectedBound18437 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env18438 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21541,29743,13389,10508,1025,21540,4161,8573,29773,8543,8193,64,2340,5392,12637,32041,28937,261,257,8573,5237,8824]

theorem envBound18438 : H12AffineFastState.Bounded env18438 := by
  intro p hp
  have h : env18438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18437_18438 : H12AffineEnvironment.transform 14 21541 env18437 = env18438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21541 env18437 == env18438) = true)

theorem identity18438 : scanCanonicalize (H12AffineFastState.compose env18438 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound18438 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env18439 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5156,1,8203,13389,10508,1025,0,4161,8573,8297,8543,8193,64,2340,5392,12637,10509,9517,261,257,8573,5237,8824]

theorem envBound18439 : H12AffineFastState.Bounded env18439 := by
  intro p hp
  have h : env18439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18438_18439 : H12AffineEnvironment.transform 13 5156 env18438 = env18439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env18438 == env18439) = true)

theorem identity18439 : scanCanonicalize (H12AffineFastState.compose env18439 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound18439 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env18440 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5156,1,343,5393,2128,1025,0,4161,33,309,3,349,64,2340,5392,4097,2129,1137,261,257,33,5237,804]

theorem envBound18440 : H12AffineFastState.Bounded env18440 := by
  intro p hp
  have h : env18440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18439_18440 : H12AffineEnvironment.transform 12 348 env18439 = env18440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env18439 == env18440) = true)

theorem identity18440 : scanCanonicalize (H12AffineFastState.compose env18440 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound18440 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env18441 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5156,1,34,5220,2128,1025,0,4161,33,64,3,40,64,2129,5221,4097,2129,1137,112,116,33,5237,593]

theorem envBound18441 : H12AffineFastState.Bounded env18441 := by
  intro p hp
  have h : env18441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18440_18441 : H12AffineEnvironment.transform 7 117 env18440 = env18441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env18440 == env18441) = true)

theorem identity18441 : scanCanonicalize (H12AffineFastState.compose env18441 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound18441 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env18442 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,2113,41,3173,1,34,3109,2128,1025,0,2048,33,64,3,40,64,2129,3108,2112,2129,1137,112,116,33,3124,593]

theorem envBound18442 : H12AffineFastState.Bounded env18442 := by
  intro p hp
  have h : env18442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18441_18442 : H12AffineEnvironment.transform 11 2113 env18441 = env18442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env18441 == env18442) = true)

theorem identity18442 : scanCanonicalize (H12AffineFastState.compose env18442 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18442 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env18443 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,2064,41,3124,1,34,3109,2049,1025,0,2048,33,17,3,40,17,2048,3108,2065,2048,1056,33,37,33,3124,512]

theorem envBound18443 : H12AffineFastState.Bounded env18443 := by
  intro p hp
  have h : env18443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18442_18443 : H12AffineEnvironment.transform 5 17 env18442 = env18443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18442 == env18443) = true)

theorem identity18443 : scanCanonicalize (H12AffineFastState.compose env18443 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1061) := by decide +kernel

theorem selectedBound18443 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18444 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1061,1077,41,17,1,34,0,1060,1025,0,1061,33,17,3,40,17,1061,1,1076,1061,1056,33,37,33,17,512]

theorem envBound18444 : H12AffineFastState.Bounded env18444 := by
  intro p hp
  have h : env18444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18443_18444 : H12AffineEnvironment.transform 10 1061 env18443 = env18444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1061 env18443 == env18444) = true)

theorem identity18444 : scanCanonicalize (H12AffineFastState.compose env18444 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound18444 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18445 : List Nat := [2,4,8,16,32,17,9,36,512,517,544,560,41,17,1,34,0,545,516,0,544,33,17,3,40,17,544,1,561,544,549,33,37,33,17,512]

theorem envBound18445 : H12AffineFastState.Bounded env18445 := by
  intro p hp
  have h : env18445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18444_18445 : H12AffineEnvironment.transform 9 517 env18444 = env18445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env18444 == env18445) = true)

theorem identity18445 : scanCanonicalize (H12AffineFastState.compose env18445 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound18445 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18446 : List Nat := [2,4,8,16,32,17,9,36,33,36,1,17,41,17,1,34,0,0,37,0,1,33,17,3,40,17,1,1,16,1,4,33,37,33,17,33]

theorem envBound18446 : H12AffineFastState.Bounded env18446 := by
  intro p hp
  have h : env18446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18445_18446 : H12AffineEnvironment.transform 8 33 env18445 = env18446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env18445 == env18446) = true)

theorem identity18446 : scanCanonicalize (H12AffineFastState.compose env18446 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18446 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18447 : List Nat := [2,4,8,1,32,0,9,36,33,36,1,0,41,0,1,34,0,0,37,0,1,33,0,3,40,0,1,1,1,1,4,33,37,33,0,33]

theorem envBound18447 : H12AffineFastState.Bounded env18447 := by
  intro p hp
  have h : env18447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18446_18447 : H12AffineEnvironment.transform 3 1 env18446 = env18447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18446 == env18447) = true)

theorem identity18447 : scanCanonicalize (H12AffineFastState.compose env18447 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18447 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18448 : List Nat := [2,4,8,1,1,0,9,5,0,5,1,0,8,0,1,3,0,0,4,0,1,0,0,3,9,0,1,1,1,1,4,0,4,0,0,0]

theorem envBound18448 : H12AffineFastState.Bounded env18448 := by
  intro p hp
  have h : env18448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18447_18448 : H12AffineEnvironment.transform 4 1 env18447 = env18448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18447 == env18448) = true)

theorem identity18448 : scanCanonicalize (H12AffineFastState.compose env18448 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound18448 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18449 : List Nat := [2,0,8,1,1,0,9,1,0,1,1,0,8,0,1,3,0,0,0,0,1,0,0,3,9,0,1,1,1,1,0,0,0,0,0,0]

theorem envBound18449 : H12AffineFastState.Bounded env18449 := by
  intro p hp
  have h : env18449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18448_18449 : H12AffineEnvironment.transform 1 0 env18448 = env18449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env18448 == env18449) = true)

def env18450 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452752,253962,242969,8328,64,97667,2240916,2340187,335882,119042,2373705,257,2199998,2191386,63189]

theorem envBound18450 : H12AffineFastState.Bounded env18450 := by
  intro p hp
  have h : env18450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18392_18450 : H12AffineEnvironment.transform 23 242969 env18392 = env18450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 242969 env18392 == env18450) = true)

def env18451 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452752,253962,242969,8328,64,97667,139732,238875,335882,119042,272393,257,98814,90202,63189]

theorem envBound18451 : H12AffineFastState.Bounded env18451 := by
  intro p hp
  have h : env18451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18450_18451 : H12AffineEnvironment.transform 20 4160 env18450 = env18451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env18450 == env18451) = true)

theorem identity18451 : scanCanonicalize (H12AffineFastState.compose env18451 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound18451 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18452 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272513,73755,95496,8328,64,97667,57797,91402,335882,119042,272393,257,98814,90202,63189]

theorem envBound18452 : H12AffineFastState.Bounded env18452 := by
  intro p hp
  have h : env18452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18451_18452 : H12AffineEnvironment.transform 16 49169 env18451 = env18452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env18451 == env18452) = true)

def env18453 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10400,1025,32769,4160,33,73755,95496,8328,64,97667,57797,91402,67754,119042,169,257,98814,90202,63189]

theorem envBound18453 : H12AffineFastState.Bounded env18453 := by
  intro p hp
  have h : env18453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18452_18453 : H12AffineEnvironment.transform 17 10400 env18452 = env18453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env18452 == env18453) = true)

theorem identity18453 : scanCanonicalize (H12AffineFastState.compose env18453 (packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound18453 : packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS < 2^1333 := by decide +kernel

def env18454 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,65536,46157,10400,1025,32769,4160,33,73755,65876,8328,64,68063,38297,69974,67754,107870,169,257,98814,70662,33417]

theorem envBound18454 : H12AffineFastState.Bounded env18454 := by
  intro p hp
  have h : env18454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18453_18454 : H12AffineEnvironment.transform 13 13404 env18453 = env18454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env18453 == env18454) = true)

theorem identity18454 : scanCanonicalize (H12AffineFastState.compose env18454 (packedSelected [0,3,5,8,9,10,14,22,27,28,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound18454 : packedSelected [0,3,5,8,9,10,14,22,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env18455 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,136,65536,13509,10400,1025,137,4160,33,73755,65876,8328,64,68063,5393,69974,67754,75222,169,257,65910,70662,513]

theorem envBound18455 : H12AffineFastState.Bounded env18455 := by
  intro p hp
  have h : env18455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18454_18455 : H12AffineEnvironment.transform 14 136 env18454 = env18455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env18454 == env18455) = true)

theorem identity18455 : scanCanonicalize (H12AffineFastState.compose env18455 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound18455 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env18456 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,136,65536,5393,2420,1025,137,4160,33,65999,65876,348,64,68063,5393,69974,67754,66562,169,257,65910,70662,513]

theorem envBound18456 : H12AffineFastState.Bounded env18456 := by
  intro p hp
  have h : env18456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18455_18456 : H12AffineEnvironment.transform 12 468 env18455 = env18456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env18455 == env18456) = true)

theorem identity18456 : scanCanonicalize (H12AffineFastState.compose env18456 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound18456 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env18457 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,136,478,5393,2420,1025,137,4160,33,17,138,348,64,2049,5393,4232,2420,1500,169,257,168,5592,513]

theorem envBound18457 : H12AffineFastState.Bounded env18457 := by
  intro p hp
  have h : env18457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18456_18457 : H12AffineEnvironment.transform 15 478 env18456 = env18457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env18456 == env18457) = true)

theorem identity18457 : scanCanonicalize (H12AffineFastState.compose env18457 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18457 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18458 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,0,342,5393,2420,1025,1,4160,33,17,2,348,64,2049,5393,4096,2420,1364,33,257,32,5456,513]

theorem envBound18458 : H12AffineFastState.Bounded env18458 := by
  intro p hp
  have h : env18458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18457_18458 : H12AffineEnvironment.transform 6 8 env18457 = env18458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18457 == env18458) = true)

theorem identity18458 : scanCanonicalize (H12AffineFastState.compose env18458 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound18458 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18459 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1061,348,293,0,342,308,2420,1025,1,1125,33,17,2,348,64,2049,308,1061,2420,1364,33,257,32,373,513]

theorem envBound18459 : H12AffineFastState.Bounded env18459 := by
  intro p hp
  have h : env18459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18458_18459 : H12AffineEnvironment.transform 11 1061 env18458 = env18459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env18458 == env18459) = true)

theorem identity18459 : scanCanonicalize (H12AffineFastState.compose env18459 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound18459 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18460 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1297,1061,348,293,0,342,308,1125,1025,1,1125,33,17,2,348,64,1296,308,1061,1125,1364,33,257,32,373,513]

theorem envBound18460 : H12AffineFastState.Bounded env18460 := by
  intro p hp
  have h : env18460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18459_18460 : H12AffineEnvironment.transform 10 1297 env18459 = env18460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env18459 == env18460) = true)

theorem identity18460 : scanCanonicalize (H12AffineFastState.compose env18460 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound18460 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env18461 : List Nat := [2,4,8,16,32,32,8,256,512,1024,1297,1061,316,293,0,310,308,1029,1025,1,1029,33,17,2,316,32,1296,308,1061,1029,1332,33,257,32,277,513]

theorem envBound18461 : H12AffineFastState.Bounded env18461 := by
  intro p hp
  have h : env18461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18460_18461 : H12AffineEnvironment.transform 5 32 env18460 = env18461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env18460 == env18461) = true)

theorem identity18461 : scanCanonicalize (H12AffineFastState.compose env18461 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound18461 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env18462 : List Nat := [2,4,8,16,32,32,8,256,277,1024,1297,1061,316,293,0,310,308,1029,1025,1,1029,33,17,2,316,32,1296,308,1061,1029,1332,33,257,32,277,276]

theorem envBound18462 : H12AffineFastState.Bounded env18462 := by
  intro p hp
  have h : env18462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18461_18462 : H12AffineEnvironment.transform 8 277 env18461 = env18462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env18461 == env18462) = true)

theorem identity18462 : scanCanonicalize (H12AffineFastState.compose env18462 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound18462 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env18463 : List Nat := [2,4,8,16,0,0,8,256,277,1024,1297,1029,284,261,0,278,276,1029,1025,1,1029,1,17,2,284,0,1296,276,1029,1029,1300,1,257,0,277,276]

theorem envBound18463 : H12AffineFastState.Bounded env18463 := by
  intro p hp
  have h : env18463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18462_18463 : H12AffineEnvironment.transform 4 0 env18462 = env18463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18462 == env18463) = true)

theorem identity18463 : scanCanonicalize (H12AffineFastState.compose env18463 (packedSelected [0,4,12] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18463 : packedSelected [0,4,12] rootPS < 2^1333 := by decide +kernel

def env18464 : List Nat := [2,4,8,1,0,0,8,256,260,1024,1280,1029,269,261,0,263,261,1029,1025,1,1029,1,0,2,269,0,1281,261,1029,1029,1285,1,257,0,260,261]

theorem envBound18464 : H12AffineFastState.Bounded env18464 := by
  intro p hp
  have h : env18464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18463_18464 : H12AffineEnvironment.transform 3 1 env18463 = env18464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18463 == env18464) = true)

theorem identity18464 : scanCanonicalize (H12AffineFastState.compose env18464 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound18464 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18465 : List Nat := [2,4,8,1,0,0,8,256,260,256,0,261,269,261,0,263,261,261,257,1,261,1,0,2,269,0,1,261,261,261,5,1,257,0,260,261]

theorem envBound18465 : H12AffineFastState.Bounded env18465 := by
  intro p hp
  have h : env18465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18464_18465 : H12AffineEnvironment.transform 9 256 env18464 = env18465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env18464 == env18465) = true)

theorem identity18465 : scanCanonicalize (H12AffineFastState.compose env18465 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound18465 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18466 : List Nat := [2,4,8,1,0,0,8,4,0,4,0,1,9,1,0,3,1,1,5,1,1,1,0,2,9,0,1,1,1,1,5,1,5,0,0,1]

theorem envBound18466 : H12AffineFastState.Bounded env18466 := by
  intro p hp
  have h : env18466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18465_18466 : H12AffineEnvironment.transform 7 4 env18465 = env18466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env18465 == env18466) = true)

def env18467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10401,1025,32769,4160,32,73755,95496,8328,64,97667,57797,91402,67755,119042,168,257,98814,90202,63189]

theorem envBound18467 : H12AffineFastState.Bounded env18467 := by
  intro p hp
  have h : env18467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18452_18467 : H12AffineEnvironment.transform 17 10401 env18452 = env18467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env18452 == env18467) = true)

theorem identity18467 : scanCanonicalize (H12AffineFastState.compose env18467 (packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 22010) := by decide +kernel

theorem selectedBound18467 : packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS < 2^1333 := by decide +kernel

def env18468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,22010,49169,10401,1025,32769,4160,32,30177,8434,8328,64,10361,57797,12528,23889,34040,168,257,54276,13728,63189]

theorem envBound18468 : H12AffineFastState.Bounded env18468 := by
  intro p hp
  have h : env18468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18467_18468 : H12AffineEnvironment.transform 15 22010 env18467 = env18468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 22010 env18467 == env18468) = true)

theorem identity18468 : scanCanonicalize (H12AffineFastState.compose env18468 (packedSelected [1,3,4,8,9,10,14,15,18,20,23,24,41] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound18468 : packedSelected [1,3,4,8,9,10,14,15,18,20,23,24,41] rootPS < 2^1333 := by decide +kernel

def env18469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,115,38296,10401,1025,32769,4160,32,8296,8434,8328,64,10361,46156,12528,2264,34040,168,257,33165,13728,41820]

theorem envBound18469 : H12AffineFastState.Bounded env18469 := by
  intro p hp
  have h : env18469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18468_18469 : H12AffineEnvironment.transform 13 5513 env18468 = env18469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env18468 == env18469) = true)

theorem identity18469 : scanCanonicalize (H12AffineFastState.compose env18469 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound18469 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env18470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5513,32768,115,38296,2557,1025,32769,4160,32,308,430,468,64,2341,38160,4524,2264,34040,168,257,33165,5372,33280]

theorem envBound18470 : H12AffineFastState.Bounded env18470 := by
  intro p hp
  have h : env18470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18469_18470 : H12AffineEnvironment.transform 12 348 env18469 = env18470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env18469 == env18470) = true)

theorem identity18470 : scanCanonicalize (H12AffineFastState.compose env18470 (packedSelected [1,4,8,9,12,14,15,16,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 508) := by decide +kernel

theorem selectedBound18470 : packedSelected [1,4,8,9,12,14,15,16,17,19] rootPS < 2^1333 := by decide +kernel

def env18471 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5513,508,115,5220,2557,1025,509,4160,32,308,430,468,64,2341,5356,4524,2264,1284,168,257,113,5372,1020]

theorem envBound18471 : H12AffineFastState.Bounded env18471 := by
  intro p hp
  have h : env18471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18470_18471 : H12AffineEnvironment.transform 14 508 env18470 = env18471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 508 env18470 == env18471) = true)

theorem identity18471 : scanCanonicalize (H12AffineFastState.compose env18471 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound18471 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env18472 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,120,5293,216,115,5220,2265,1025,217,4160,32,16,138,240,64,2049,5356,4232,2264,1056,168,37,113,5372,728]

theorem envBound18472 : H12AffineFastState.Bounded env18472 := by
  intro p hp
  have h : env18472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18471_18472 : H12AffineEnvironment.transform 7 36 env18471 = env18472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env18471 == env18472) = true)

theorem identity18472 : scanCanonicalize (H12AffineFastState.compose env18472 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18472 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env18473 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,120,5156,81,115,5220,2128,1025,80,4160,32,16,3,121,64,2049,5221,4097,2129,1056,33,37,113,5237,593]

theorem envBound18473 : H12AffineFastState.Bounded env18473 := by
  intro p hp
  have h : env18473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18472_18473 : H12AffineEnvironment.transform 6 9 env18472 = env18473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18472 == env18473) = true)

theorem identity18473 : scanCanonicalize (H12AffineFastState.compose env18473 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18473 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env18474 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5156,0,34,5173,2049,1025,1,4113,32,16,3,40,17,2049,5172,4097,2048,1056,33,37,32,5156,512]

theorem envBound18474 : H12AffineFastState.Bounded env18474 := by
  intro p hp
  have h : env18474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18473_18474 : H12AffineEnvironment.transform 5 17 env18473 = env18474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18473 == env18474) = true)

theorem identity18474 : scanCanonicalize (H12AffineFastState.compose env18474 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18474 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18475 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,8,5125,0,3,5140,2049,1025,1,4113,1,16,3,9,17,2049,5141,4097,2048,1025,0,4,1,5125,512]

theorem envBound18475 : H12AffineFastState.Bounded env18475 := by
  intro p hp
  have h : env18475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18474_18475 : H12AffineEnvironment.transform 4 1 env18474 = env18475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18474 == env18475) = true)

def env18476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452752,253962,242969,8328,64,97667,139733,238874,335882,119042,272392,257,98815,90203,63189]

theorem envBound18476 : H12AffineFastState.Bounded env18476 := by
  intro p hp
  have h : env18476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18450_18476 : H12AffineEnvironment.transform 20 4161 env18450 = env18476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env18450 == env18476) = true)

def env18477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,4161,180272,253962,242969,8328,64,97667,139733,238874,67754,119042,168,257,98815,90203,63189]

theorem envBound18477 : H12AffineFastState.Bounded env18477 := by
  intro p hp
  have h : env18477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18476_18477 : H12AffineEnvironment.transform 17 10400 env18476 = env18477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env18476 == env18477) = true)

def env18478 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4161,180272,253962,242969,8192,64,97547,139613,238874,67618,119042,32,257,98679,90203,63069]

theorem envBound18478 : H12AffineFastState.Bounded env18478 := by
  intro p hp
  have h : env18478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18477_18478 : H12AffineEnvironment.transform 6 8 env18477 = env18478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18477 == env18478) = true)

theorem identity18478 : scanCanonicalize (H12AffineFastState.compose env18478 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound18478 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18479 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10280,1025,29789,4161,144492,201814,213317,8192,64,97547,139613,217414,67618,75102,32,257,95531,90203,513]

theorem envBound18479 : H12AffineFastState.Bounded env18479 := by
  intro p hp
  have h : env18479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18478_18479 : H12AffineEnvironment.transform 14 29788 env18478 = env18479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env18478 == env18479) = true)

theorem identity18479 : scanCanonicalize (H12AffineFastState.compose env18479 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound18479 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env18480 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,29962,131072,10280,1025,29789,4161,144492,155996,144463,8192,64,2049,139613,140364,32040,20564,32,257,33,5457,513]

theorem envBound18480 : H12AffineFastState.Bounded env18480 := by
  intro p hp
  have h : env18480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18479_18480 : H12AffineEnvironment.transform 15 29962 env18479 = env18480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env18479 == env18480) = true)

theorem identity18480 : scanCanonicalize (H12AffineFastState.compose env18480 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound18480 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env18481 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,21591,131072,2421,1025,21760,4161,136497,147457,136466,349,64,2049,131072,132369,23669,20564,32,257,33,5457,513]

theorem envBound18481 : H12AffineFastState.Bounded env18481 := by
  intro p hp
  have h : env18481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18480_18481 : H12AffineEnvironment.transform 12 349 env18480 = env18481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env18480 == env18481) = true)

theorem identity18481 : scanCanonicalize (H12AffineFastState.compose env18481 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound18481 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env18482 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,1,343,131072,2421,1025,0,4161,136497,136449,136466,349,64,2049,131072,132369,2421,1364,32,257,33,5457,513]

theorem envBound18482 : H12AffineFastState.Bounded env18482 := by
  intro p hp
  have h : env18482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18481_18482 : H12AffineEnvironment.transform 13 5376 env18481 = env18482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env18481 == env18482) = true)

theorem identity18482 : scanCanonicalize (H12AffineFastState.compose env18482 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound18482 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18483 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,1,343,5392,2421,1025,0,4161,33,17,2,349,64,2049,5392,4097,2421,1364,32,257,33,5457,513]

theorem envBound18483 : H12AffineFastState.Bounded env18483 := by
  intro p hp
  have h : env18483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18482_18483 : H12AffineEnvironment.transform 16 5392 env18482 = env18483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env18482 == env18483) = true)

theorem identity18483 : scanCanonicalize (H12AffineFastState.compose env18483 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3418) := by decide +kernel

theorem selectedBound18483 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18484 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3418,349,2138,1,343,2122,2421,1025,0,3355,33,17,2,349,64,2049,2122,3419,2421,1364,32,257,33,2059,513]

theorem envBound18484 : H12AffineFastState.Bounded env18484 := by
  intro p hp
  have h : env18484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18483_18484 : H12AffineEnvironment.transform 11 3418 env18483 = env18484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3418 env18483 == env18484) = true)

theorem identity18484 : scanCanonicalize (H12AffineFastState.compose env18484 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound18484 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18485 : List Nat := [2,4,8,16,32,10,8,256,512,1024,2048,3344,279,2064,1,285,2048,2367,1025,0,3355,33,17,2,279,10,2049,2048,3345,2367,1310,32,257,33,2059,513]

theorem envBound18485 : H12AffineFastState.Bounded env18485 := by
  intro p hp
  have h : env18485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18484_18485 : H12AffineEnvironment.transform 5 10 env18484 = env18485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env18484 == env18485) = true)

theorem identity18485 : scanCanonicalize (H12AffineFastState.compose env18485 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound18485 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env18486 : List Nat := [2,4,8,16,0,10,8,256,512,1024,2048,3344,279,2064,1,285,2048,2335,1025,0,3355,1,17,2,279,10,2049,2048,3345,2335,1310,0,257,1,2059,513]

theorem envBound18486 : H12AffineFastState.Bounded env18486 := by
  intro p hp
  have h : env18486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18485_18486 : H12AffineEnvironment.transform 4 0 env18485 = env18486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18485 == env18486) = true)

theorem identity18486 : scanCanonicalize (H12AffineFastState.compose env18486 (packedSelected [5,8,15] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound18486 : packedSelected [5,8,15] rootPS < 2^1333 := by decide +kernel

def env18487 : List Nat := [2,4,8,10,0,10,8,256,512,1024,2048,3338,269,2058,1,263,2048,2309,1025,0,3329,1,11,2,269,10,2049,2048,3339,2309,1284,0,257,1,2059,513]

theorem envBound18487 : H12AffineFastState.Bounded env18487 := by
  intro p hp
  have h : env18487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18486_18487 : H12AffineEnvironment.transform 3 10 env18486 = env18487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env18486 == env18487) = true)

theorem identity18487 : scanCanonicalize (H12AffineFastState.compose env18487 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound18487 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18488 : List Nat := [2,4,8,10,0,10,8,15,512,1024,2048,3077,2,2058,1,8,2048,2058,1025,0,3086,1,11,2,2,10,2049,2048,3076,2058,1035,0,14,1,2059,513]

theorem envBound18488 : H12AffineFastState.Bounded env18488 := by
  intro p hp
  have h : env18488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18487_18488 : H12AffineEnvironment.transform 7 15 env18487 = env18488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env18487 == env18488) = true)

theorem identity18488 : scanCanonicalize (H12AffineFastState.compose env18488 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound18488 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18489 : List Nat := [2,4,8,10,0,10,8,15,11,1024,2048,3077,2,2058,1,8,2048,2058,1025,0,3086,1,11,2,2,10,2049,2048,3076,2058,1035,0,14,1,2059,10]

theorem envBound18489 : H12AffineFastState.Bounded env18489 := by
  intro p hp
  have h : env18489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18488_18489 : H12AffineEnvironment.transform 8 11 env18488 = env18489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env18488 == env18489) = true)

theorem identity18489 : scanCanonicalize (H12AffineFastState.compose env18489 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 12) := by decide +kernel

theorem selectedBound18489 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18490 : List Nat := [2,4,8,10,0,10,8,15,11,12,2048,2057,2,2058,1,8,2048,2058,13,0,2050,1,11,2,2,10,2049,2048,2056,2058,7,0,14,1,2059,10]

theorem envBound18490 : H12AffineFastState.Bounded env18490 := by
  intro p hp
  have h : env18490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18489_18490 : H12AffineEnvironment.transform 9 12 env18489 = env18490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 12 env18489 == env18490) = true)

theorem identity18490 : scanCanonicalize (H12AffineFastState.compose env18490 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 3) := by decide +kernel

theorem selectedBound18490 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18491 : List Nat := [2,4,8,10,0,10,8,15,11,12,3,10,2,9,1,8,3,9,13,0,1,1,11,2,2,10,2,3,11,9,7,0,14,1,8,10]

theorem envBound18491 : H12AffineFastState.Bounded env18491 := by
  intro p hp
  have h : env18491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18490_18491 : H12AffineEnvironment.transform 10 3 env18490 = env18491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 3 env18490 == env18491) = true)

theorem identity18491 : scanCanonicalize (H12AffineFastState.compose env18491 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound18491 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18492 : List Nat := [2,4,6,4,0,4,6,1,5,2,3,4,2,7,1,6,3,7,3,0,1,1,5,2,2,4,2,3,5,7,7,0,0,1,6,4]

theorem envBound18492 : H12AffineFastState.Bounded env18492 := by
  intro p hp
  have h : env18492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18491_18492 : H12AffineEnvironment.transform 2 6 env18491 = env18492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env18491 == env18492) = true)

theorem identity18492 : scanCanonicalize (H12AffineFastState.compose env18492 (packedSelected [8] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound18492 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env18493 : List Nat := [2,2,0,2,0,2,0,1,3,2,3,2,2,1,1,0,3,1,3,0,1,1,3,2,2,2,2,3,3,1,1,0,0,1,0,2]

theorem envBound18493 : H12AffineFastState.Bounded env18493 := by
  intro p hp
  have h : env18493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18492_18493 : H12AffineEnvironment.transform 1 2 env18492 = env18493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env18492 == env18493) = true)

def env18494 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4161,180272,253962,242969,8193,64,97546,139612,238874,67619,119042,33,257,98678,90203,63068]

theorem envBound18494 : H12AffineFastState.Bounded env18494 := by
  intro p hp
  have h : env18494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18477_18494 : H12AffineEnvironment.transform 6 9 env18477 = env18494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18477 == env18494) = true)

theorem identity18494 : scanCanonicalize (H12AffineFastState.compose env18494 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound18494 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18495 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1025,32769,4161,169264,242954,242969,8193,64,75786,139612,238874,67619,99330,33,257,98678,79195,41820]

theorem envBound18495 : H12AffineFastState.Bounded env18495 := by
  intro p hp
  have h : env18495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18494_18495 : H12AffineEnvironment.transform 13 5376 env18494 = env18495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env18494 == env18495) = true)

theorem identity18495 : scanCanonicalize (H12AffineFastState.compose env18495 (packedSelected [1,3,8,10,18,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 12556) := by decide +kernel

theorem selectedBound18495 : packedSelected [1,3,8,10,18,23,24] rootPS < 2^1333 := by decide +kernel

def env18496 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,12556,10281,1025,32769,4161,42044,99334,99349,8193,64,75786,4176,103446,67619,99330,33,257,98678,79195,41820]

theorem envBound18496 : H12AffineFastState.Bounded env18496 := by
  intro p hp
  have h : env18496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18495_18496 : H12AffineEnvironment.transform 16 12556 env18495 = env18496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12556 env18495 == env18496) = true)

theorem identity18496 : scanCanonicalize (H12AffineFastState.compose env18496 (packedSelected [0,3,4,5,7,10,16,18,19,20,22,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound18496 : packedSelected [0,3,4,5,7,10,16,18,19,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env18497 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,12556,10281,1025,8540,4161,1377,75099,75080,8193,64,75786,4176,79179,67619,75103,33,257,73771,79195,513]

theorem envBound18497 : H12AffineFastState.Bounded env18497 := by
  intro p hp
  have h : env18497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18496_18497 : H12AffineEnvironment.transform 14 8541 env18496 = env18497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env18496 == env18497) = true)

theorem identity18497 : scanCanonicalize (H12AffineFastState.compose env18497 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 6248) := by decide +kernel

theorem selectedBound18497 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env18498 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,6248,5376,6453,65536,2404,4161,1025,6452,4161,1377,73011,72992,6249,64,69730,4176,68899,67619,73015,33,257,71747,68915,513]

theorem envBound18498 : H12AffineFastState.Bounded env18498 := by
  intro p hp
  have h : env18498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18497_18498 : H12AffineEnvironment.transform 12 6248 env18497 = env18498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6248 env18497 == env18498) = true)

theorem identity18498 : scanCanonicalize (H12AffineFastState.compose env18498 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound18498 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env18499 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3188,1052,2420,1345,65536,2404,3125,1025,1344,3125,1377,65863,65876,1053,64,68630,3108,68899,67619,65859,33,257,66615,68915,513]

theorem envBound18499 : H12AffineFastState.Bounded env18499 := by
  intro p hp
  have h : env18499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18498_18499 : H12AffineEnvironment.transform 11 3188 env18498 = env18499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env18498 == env18499) = true)

theorem identity18499 : scanCanonicalize (H12AffineFastState.compose env18499 (packedSelected [1,3,5,8,15] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound18499 : packedSelected [1,3,5,8,15] rootPS < 2^1333 := by decide +kernel

def env18500 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3188,1052,2420,1345,115,2404,3125,1025,1344,3125,1377,308,295,1053,64,3173,3108,3408,2128,304,33,257,1092,3392,513]

theorem envBound18500 : H12AffineFastState.Bounded env18500 := by
  intro p hp
  have h : env18500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18499_18500 : H12AffineEnvironment.transform 15 115 env18499 = env18500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env18499 == env18500) = true)

theorem identity18500 : scanCanonicalize (H12AffineFastState.compose env18500 (packedSelected [1,2,3,5,6,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound18500 : packedSelected [1,2,3,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env18501 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,2112,40,2420,373,115,2404,2049,53,372,2049,341,308,295,41,64,2129,2064,2404,2128,304,33,257,112,2420,513]

theorem envBound18501 : H12AffineFastState.Bounded env18501 := by
  intro p hp
  have h : env18501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18500_18501 : H12AffineEnvironment.transform 9 52 env18500 = env18501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env18500 == env18501) = true)

theorem identity18501 : scanCanonicalize (H12AffineFastState.compose env18501 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18501 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env18502 : List Nat := [2,4,8,16,32,16,9,256,512,52,2048,2064,40,2340,293,35,2356,2049,53,292,2049,261,308,295,41,16,2049,2064,2356,2048,304,33,257,32,2340,513]

theorem envBound18502 : H12AffineFastState.Bounded env18502 := by
  intro p hp
  have h : env18502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18501_18502 : H12AffineEnvironment.transform 5 16 env18501 = env18502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18501 == env18502) = true)

theorem identity18502 : scanCanonicalize (H12AffineFastState.compose env18502 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound18502 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18503 : List Nat := [2,4,8,16,32,16,9,256,16,52,2048,2064,40,2340,293,35,2356,2049,53,292,2049,261,308,295,41,16,2049,2064,2356,2048,304,33,257,32,2340,17]

theorem envBound18503 : H12AffineFastState.Bounded env18503 := by
  intro p hp
  have h : env18503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18502_18503 : H12AffineEnvironment.transform 8 16 env18502 = env18503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env18502 == env18503) = true)

theorem identity18503 : scanCanonicalize (H12AffineFastState.compose env18503 (packedSelected [1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound18503 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env18504 : List Nat := [2,4,8,16,32,16,9,256,16,52,1,17,40,293,293,35,309,0,53,292,0,261,308,295,41,16,0,17,309,1,304,33,257,32,293,17]

theorem envBound18504 : H12AffineFastState.Bounded env18504 := by
  intro p hp
  have h : env18504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18503_18504 : H12AffineEnvironment.transform 10 1 env18503 = env18504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env18503 == env18504) = true)

theorem identity18504 : scanCanonicalize (H12AffineFastState.compose env18504 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound18504 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env18505 : List Nat := [2,4,3,16,32,16,2,256,16,52,1,17,35,293,293,35,309,0,53,292,0,261,308,295,34,16,0,17,309,1,304,33,257,32,293,17]

theorem envBound18505 : H12AffineFastState.Bounded env18505 := by
  intro p hp
  have h : env18505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18504_18505 : H12AffineEnvironment.transform 2 3 env18504 = env18505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env18504 == env18505) = true)

theorem identity18505 : scanCanonicalize (H12AffineFastState.compose env18505 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound18505 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18506 : List Nat := [2,4,3,16,32,16,2,36,16,52,1,17,35,1,1,35,17,0,53,0,0,33,16,3,34,16,0,17,17,1,20,33,37,32,1,17]

theorem envBound18506 : H12AffineFastState.Bounded env18506 := by
  intro p hp
  have h : env18506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18505_18506 : H12AffineEnvironment.transform 7 36 env18505 = env18506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env18505 == env18506) = true)

def env18507 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,4161,180273,253962,242969,8328,64,97667,139733,238874,67755,119042,169,257,98815,90203,63189]

theorem envBound18507 : H12AffineFastState.Bounded env18507 := by
  intro p hp
  have h : env18507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18476_18507 : H12AffineEnvironment.transform 17 10401 env18476 = env18507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env18476 == env18507) = true)

def env18508 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4161,180273,253962,242969,8192,64,97547,139613,238874,67619,119042,33,257,98679,90203,63069]

theorem envBound18508 : H12AffineFastState.Bounded env18508 := by
  intro p hp
  have h : env18508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18507_18508 : H12AffineEnvironment.transform 6 8 env18507 = env18508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18507 == env18508) = true)

theorem identity18508 : scanCanonicalize (H12AffineFastState.compose env18508 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound18508 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18509 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70726,10281,1025,32769,4161,119927,62540,41311,8192,64,97547,79131,45404,67619,119042,33,257,98679,90203,63069]

theorem envBound18509 : H12AffineFastState.Bounded env18509 := by
  intro p hp
  have h : env18509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18508_18509 : H12AffineEnvironment.transform 16 70726 env18508 = env18509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env18508 == env18509) = true)

theorem identity18509 : scanCanonicalize (H12AffineFastState.compose env18509 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound18509 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env18510 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,70726,10281,1025,29789,4161,73771,16,21763,8192,64,97547,79131,17664,67619,75102,33,257,95531,90203,513]

theorem envBound18510 : H12AffineFastState.Bounded env18510 := by
  intro p hp
  have h : env18510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18509_18510 : H12AffineEnvironment.transform 14 29788 env18509 = env18510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env18509 == env18510) = true)

theorem identity18510 : scanCanonicalize (H12AffineFastState.compose env18510 (packedSelected [0,1,4,7,8,9,10,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 16647) := by decide +kernel

theorem selectedBound18510 : packedSelected [0,1,4,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env18511 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,16647,21825,10281,1025,29789,4161,24876,16,21763,8192,64,15372,29724,17664,18724,25689,33,257,13356,8540,513]

theorem envBound18511 : H12AffineFastState.Bounded env18511 := by
  intro p hp
  have h : env18511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18510_18511 : H12AffineEnvironment.transform 15 16647 env18510 = env18511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 16647 env18510 == env18511) = true)

theorem identity18511 : scanCanonicalize (H12AffineFastState.compose env18511 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound18511 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env18512 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,1,13658,8476,10281,1025,0,4161,5489,16,8542,8192,64,15372,65,12637,15737,4100,33,257,13356,8540,513]

theorem envBound18512 : H12AffineFastState.Bounded env18512 := by
  intro p hp
  have h : env18512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18511_18512 : H12AffineEnvironment.transform 13 13405 env18511 = env18512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env18511 == env18512) = true)

theorem identity18512 : scanCanonicalize (H12AffineFastState.compose env18512 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 5133) := by decide +kernel

theorem selectedBound18512 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env18513 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,5133,80,1,343,5393,7204,1025,0,4161,5489,16,5459,5133,64,2049,65,1360,2420,4100,33,257,33,5457,513]

theorem envBound18513 : H12AffineFastState.Bounded env18513 := by
  intro p hp
  have h : env18513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18512_18513 : H12AffineEnvironment.transform 12 5133 env18512 = env18513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5133 env18512 == env18513) = true)

theorem identity18513 : scanCanonicalize (H12AffineFastState.compose env18513 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18513 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18514 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,5133,1,1,262,5393,7204,1025,0,4112,5408,16,5378,5133,17,2049,16,1281,2341,4100,33,257,33,5376,513]

theorem envBound18514 : H12AffineFastState.Bounded env18514 := by
  intro p hp
  have h : env18514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18513_18514 : H12AffineEnvironment.transform 5 17 env18513 = env18514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18513 == env18514) = true)

theorem identity18514 : scanCanonicalize (H12AffineFastState.compose env18514 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound18514 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env18515 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,16,1053,1,1,262,1281,3124,1025,0,0,1328,16,1298,1053,17,2049,16,1281,2341,20,33,257,33,1296,513]

theorem envBound18515 : H12AffineFastState.Bounded env18515 := by
  intro p hp
  have h : env18515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18514_18515 : H12AffineEnvironment.transform 11 16 env18514 = env18515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env18514 == env18515) = true)

theorem identity18515 : scanCanonicalize (H12AffineFastState.compose env18515 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound18515 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env18516 : List Nat := [2,4,8,16,32,17,8,256,512,1024,293,16,1053,1,1,262,1281,1297,1025,0,0,1328,16,1298,1053,17,292,16,1281,0,20,33,257,33,1296,513]

theorem envBound18516 : H12AffineFastState.Bounded env18516 := by
  intro p hp
  have h : env18516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18515_18516 : H12AffineEnvironment.transform 10 293 env18515 = env18516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env18515 == env18516) = true)

theorem identity18516 : scanCanonicalize (H12AffineFastState.compose env18516 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound18516 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18517 : List Nat := [2,4,8,16,32,17,8,37,512,1024,0,16,1053,1,1,35,1060,1076,1025,0,0,1045,16,1079,1053,17,1,16,1060,0,20,33,36,33,1077,513]

theorem envBound18517 : H12AffineFastState.Bounded env18517 := by
  intro p hp
  have h : env18517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18516_18517 : H12AffineEnvironment.transform 7 37 env18516 = env18517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env18516 == env18517) = true)

theorem identity18517 : scanCanonicalize (H12AffineFastState.compose env18517 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound18517 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env18518 : List Nat := [2,4,8,16,32,17,8,37,512,52,0,16,41,1,1,35,16,0,53,0,0,33,16,3,41,17,1,16,16,0,20,33,36,33,1,513]

theorem envBound18518 : H12AffineFastState.Bounded env18518 := by
  intro p hp
  have h : env18518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18517_18518 : H12AffineEnvironment.transform 9 52 env18517 = env18518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env18517 == env18518) = true)

theorem identity18518 : scanCanonicalize (H12AffineFastState.compose env18518 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound18518 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18519 : List Nat := [2,4,8,16,32,17,8,37,0,52,0,16,41,1,1,35,16,0,53,0,0,33,16,3,41,17,1,16,16,0,20,33,36,33,1,1]

theorem envBound18519 : H12AffineFastState.Bounded env18519 := by
  intro p hp
  have h : env18519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18518_18519 : H12AffineEnvironment.transform 8 0 env18518 = env18519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env18518 == env18519) = true)

theorem identity18519 : scanCanonicalize (H12AffineFastState.compose env18519 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound18519 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18520 : List Nat := [2,4,8,10,32,11,8,37,0,46,0,10,41,1,1,35,10,0,47,0,0,33,10,3,41,11,1,10,10,0,14,33,36,33,1,1]

theorem envBound18520 : H12AffineFastState.Bounded env18520 := by
  intro p hp
  have h : env18520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18519_18520 : H12AffineEnvironment.transform 3 10 env18519 = env18520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env18519 == env18520) = true)

theorem identity18520 : scanCanonicalize (H12AffineFastState.compose env18520 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound18520 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18521 : List Nat := [2,4,3,1,32,0,3,37,0,37,0,1,34,1,1,35,1,0,36,0,0,33,1,3,34,0,1,1,1,0,5,33,36,33,1,1]

theorem envBound18521 : H12AffineFastState.Bounded env18521 := by
  intro p hp
  have h : env18521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18520_18521 : H12AffineEnvironment.transform 2 3 env18520 = env18521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env18520 == env18521) = true)

def env18522 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4161,180273,253962,242969,8193,64,97546,139612,238874,67618,119042,32,257,98678,90203,63068]

theorem envBound18522 : H12AffineFastState.Bounded env18522 := by
  intro p hp
  have h : env18522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18507_18522 : H12AffineEnvironment.transform 6 9 env18507 = env18522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18507 == env18522) = true)

theorem identity18522 : scanCanonicalize (H12AffineFastState.compose env18522 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 111898) := by decide +kernel

theorem selectedBound18522 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18523 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10280,1025,32769,4161,95531,21776,3,8193,64,97546,103494,4096,67618,119042,32,257,98678,90203,63068]

theorem envBound18523 : H12AffineFastState.Bounded env18523 := by
  intro p hp
  have h : env18523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18522_18523 : H12AffineEnvironment.transform 16 111898 env18522 = env18523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111898 env18522 == env18523) = true)

theorem identity18523 : scanCanonicalize (H12AffineFastState.compose env18523 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound18523 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env18524 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,65536,103494,2420,1025,32769,4161,87159,21776,3,349,64,89174,103494,4096,67618,119042,32,257,98678,82183,55040]

theorem envBound18524 : H12AffineFastState.Bounded env18524 := by
  intro p hp
  have h : env18524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18523_18524 : H12AffineEnvironment.transform 12 348 env18523 = env18524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env18523 == env18524) = true)

theorem identity18524 : scanCanonicalize (H12AffineFastState.compose env18524 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18524 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env18525 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,32768,65536,103446,2340,1025,32769,4113,87079,21776,3,269,16,89094,103446,4096,67618,119042,32,257,98598,82183,55040]

theorem envBound18525 : H12AffineFastState.Bounded env18525 := by
  intro p hp
  have h : env18525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18524_18525 : H12AffineEnvironment.transform 5 16 env18524 = env18525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18524 == env18525) = true)

theorem identity18525 : scanCanonicalize (H12AffineFastState.compose env18525 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound18525 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env18526 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,32768,35,37941,2340,1025,32769,4113,21508,21776,3,269,16,23589,37941,4096,2049,53537,32,257,33029,16676,55040]

theorem envBound18526 : H12AffineFastState.Bounded env18526 := by
  intro p hp
  have h : env18526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18525_18526 : H12AffineEnvironment.transform 15 35 env18525 = env18526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env18525 == env18526) = true)

theorem identity18526 : scanCanonicalize (H12AffineFastState.compose env18526 (packedSelected [0,2,6,7,11,12,15,16,23] rootPS)) = affineNative (2^(14+1) ^^^ 21540) := by decide +kernel

theorem selectedBound18526 : packedSelected [0,2,6,7,11,12,15,16,23] rootPS < 2^1333 := by decide +kernel

def env18527 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,21540,35,16401,2340,1025,21541,4113,21508,21776,3,269,16,23589,16401,4096,2049,1285,32,257,21793,16676,804]

theorem envBound18527 : H12AffineFastState.Bounded env18527 := by
  intro p hp
  have h : env18527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18526_18527 : H12AffineEnvironment.transform 14 21540 env18526 = env18527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21540 env18526 == env18527) = true)

theorem identity18527 : scanCanonicalize (H12AffineFastState.compose env18527 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound18527 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18528 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5156,0,35,5173,2340,1025,1,4113,32,308,3,269,16,2049,5173,4096,2049,1285,32,257,261,5376,804]

theorem envBound18528 : H12AffineFastState.Bounded env18528 := by
  intro p hp
  have h : env18528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18527_18528 : H12AffineEnvironment.transform 13 5156 env18527 = env18528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env18527 == env18528) = true)

theorem identity18528 : scanCanonicalize (H12AffineFastState.compose env18528 (packedSelected [1,3,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound18528 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env18529 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,4096,8,5156,0,35,5173,2080,1025,1,4113,32,48,3,9,16,2049,5173,4096,2049,1025,32,5,1,5124,544]

theorem envBound18529 : H12AffineFastState.Bounded env18529 := by
  intro p hp
  have h : env18529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18528_18529 : H12AffineEnvironment.transform 7 4 env18528 = env18529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env18528 == env18529) = true)

def env18530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452753,253962,16777216,8328,64,16959643,18973837,2340187,335882,16933915,19369297,257,19014823,19055875,16991180]

theorem envBound18530 : H12AffineFastState.Bounded env18530 := by
  intro p hp
  have h : env18530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18391_18530 : H12AffineEnvironment.transform 21 452753 env18391 = env18530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452753 env18391 == env18530) = true)

def env18531 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452753,253962,242968,8328,64,97667,2240917,2340187,335882,119043,2373705,257,2199999,2191387,63188]

theorem envBound18531 : H12AffineFastState.Bounded env18531 := by
  intro p hp
  have h : env18531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18530_18531 : H12AffineEnvironment.transform 23 242968 env18530 = env18531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 242968 env18530 == env18531) = true)

def env18532 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452753,253962,242968,8328,64,97667,139733,238875,335882,119043,272393,257,98815,90203,63188]

theorem envBound18532 : H12AffineFastState.Bounded env18532 := by
  intro p hp
  have h : env18532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18531_18532 : H12AffineEnvironment.transform 20 4160 env18531 = env18532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env18531 == env18532) = true)

theorem identity18532 : scanCanonicalize (H12AffineFastState.compose env18532 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70862) := by decide +kernel

theorem selectedBound18532 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18533 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70862,262144,1025,32769,4160,392287,62660,41430,8328,64,97667,79131,45525,335882,119043,272393,257,98815,90203,63188]

theorem envBound18533 : H12AffineFastState.Bounded env18533 := by
  intro p hp
  have h : env18533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18532_18533 : H12AffineEnvironment.transform 16 70862 env18532 = env18533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70862 env18532 == env18533) = true)

theorem identity18533 : scanCanonicalize (H12AffineFastState.compose env18533 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound18533 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env18534 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,70862,262144,1025,29908,4160,329866,17,21763,8328,64,97667,79131,17664,335882,75222,272393,257,95530,90203,513]

theorem envBound18534 : H12AffineFastState.Bounded env18534 := by
  intro p hp
  have h : env18534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18533_18534 : H12AffineEnvironment.transform 14 29909 env18533 = env18534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env18533 == env18534) = true)

theorem identity18534 : scanCanonicalize (H12AffineFastState.compose env18534 (packedSelected [1,2,5,6,8,24] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound18534 : packedSelected [1,2,5,6,8,24] rootPS < 2^1333 := by decide +kernel

def env18535 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,137,65536,70862,262144,1025,136,4160,329866,17,8543,8328,64,68063,79131,12636,335882,75222,272393,257,65910,70663,513]

theorem envBound18535 : H12AffineFastState.Bounded env18535 := by
  intro p hp
  have h : env18535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18534_18535 : H12AffineEnvironment.transform 13 13404 env18534 = env18535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env18534 == env18535) = true)

theorem identity18535 : scanCanonicalize (H12AffineFastState.compose env18535 (packedSelected [1,2,3,4,5,6,8,9,10,14,20,26] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound18535 : packedSelected [1,2,3,4,5,6,8,9,10,14,20,26] rootPS < 2^1333 := by decide +kernel

def env18536 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,137,65536,70862,2421,1025,136,4160,66047,17,8543,8328,64,68063,79131,12636,76159,75222,8572,257,65910,70663,513]

theorem envBound18536 : H12AffineFastState.Bounded env18536 := by
  intro p hp
  have h : env18536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18535_18536 : H12AffineEnvironment.transform 17 2421 env18535 = env18536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env18535 == env18536) = true)

theorem identity18536 : scanCanonicalize (H12AffineFastState.compose env18536 (packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18536 : packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS < 2^1333 := by decide +kernel

def env18537 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,1,65536,70726,2421,1025,0,4160,65911,17,8543,8192,64,67927,79131,12636,76159,75102,8572,257,65910,70663,513]

theorem envBound18537 : H12AffineFastState.Bounded env18537 := by
  intro p hp
  have h : env18537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18536_18537 : H12AffineEnvironment.transform 6 8 env18536 = env18537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18536 == env18537) = true)

theorem identity18537 : scanCanonicalize (H12AffineFastState.compose env18537 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound18537 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env18538 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1,65536,70726,2421,1025,0,4160,65911,17,2,349,64,67927,70726,4097,67618,66563,33,257,65910,70663,513]

theorem envBound18538 : H12AffineFastState.Bounded env18538 := by
  intro p hp
  have h : env18538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18537_18538 : H12AffineEnvironment.transform 12 349 env18537 = env18538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env18537 == env18538) = true)

def env18539 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452753,253962,242968,8328,64,97667,139732,238874,335882,119043,272392,257,98814,90202,63188]

theorem envBound18539 : H12AffineFastState.Bounded env18539 := by
  intro p hp
  have h : env18539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18531_18539 : H12AffineEnvironment.transform 20 4161 env18531 = env18539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env18531 == env18539) = true)

theorem identity18539 : scanCanonicalize (H12AffineFastState.compose env18539 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound18539 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,4161,452753,144597,156103,8328,64,43356,139732,160197,324821,1500,272392,257,21793,46213,63188]

theorem envBound18540 : H12AffineFastState.Bounded env18540 := by
  intro p hp
  have h : env18540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18539_18540 : H12AffineEnvironment.transform 15 54495 env18539 = env18540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env18539 == env18540) = true)

def env18541 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,16448,262144,1025,32769,4161,305361,29845,8583,8328,64,43356,24980,12677,324821,1500,272392,257,21793,46213,63188]

theorem envBound18541 : H12AffineFastState.Bounded env18541 := by
  intro p hp
  have h : env18541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18540_18541 : H12AffineEnvironment.transform 16 16448 env18540 = env18541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env18540 == env18541) = true)

theorem identity18541 : scanCanonicalize (H12AffineFastState.compose env18541 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5593) := by decide +kernel

theorem selectedBound18541 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env18542 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5593,32768,33030,5529,262144,1025,32769,4161,305361,8524,8583,8328,64,43356,13389,12677,303372,1500,272392,257,248,46213,41741]

theorem envBound18542 : H12AffineFastState.Bounded env18542 := by
  intro p hp
  have h : env18542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18541_18542 : H12AffineEnvironment.transform 13 5593 env18541 = env18542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5593 env18541 == env18542) = true)

theorem identity18542 : scanCanonicalize (H12AffineFastState.compose env18542 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 35244) := by decide +kernel

theorem selectedBound18542 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env18543 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5593,32768,33030,5529,35244,1025,32769,4161,8573,8524,8583,8328,64,43356,13389,12677,10400,1500,41380,257,248,46213,41741]

theorem envBound18543 : H12AffineFastState.Bounded env18543 := by
  intro p hp
  have h : env18543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18542_18543 : H12AffineEnvironment.transform 17 35244 env18542 = env18543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35244 env18542 == env18543) = true)

theorem identity18543 : scanCanonicalize (H12AffineFastState.compose env18543 (packedSelected [0,1,2,6,7,8,17,19,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18543 : packedSelected [0,1,2,6,7,8,17,19,20] rootPS < 2^1333 := by decide +kernel

def env18544 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,32768,33030,5392,35109,1025,32769,4161,8573,8524,8462,8193,64,43356,13389,12556,10281,1365,41261,257,113,46092,41741]

theorem envBound18544 : H12AffineFastState.Bounded env18544 := by
  intro p hp
  have h : env18544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18543_18544 : H12AffineEnvironment.transform 6 9 env18543 = env18544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18543 == env18544) = true)

theorem identity18544 : scanCanonicalize (H12AffineFastState.compose env18544 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 8312) := by decide +kernel

theorem selectedBound18544 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env18545 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8312,8574,5392,10589,1025,8313,4161,8573,8524,8462,8193,64,2340,13389,12556,10281,1365,341,257,113,5236,885]

theorem envBound18545 : H12AffineFastState.Bounded env18545 := by
  intro p hp
  have h : env18545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18544_18545 : H12AffineEnvironment.transform 14 8312 env18544 = env18545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8312 env18544 == env18545) = true)

theorem identity18545 : scanCanonicalize (H12AffineFastState.compose env18545 (packedSelected [0,1,7,8,10,11,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound18545 : packedSelected [0,1,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env18546 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,5237,8312,8283,5173,10360,1025,8313,4161,8280,8297,8235,8193,64,2049,13389,12329,10281,1136,112,36,113,5236,592]

theorem envBound18546 : H12AffineFastState.Bounded env18546 := by
  intro p hp
  have h : env18546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18545_18546 : H12AffineEnvironment.transform 7 37 env18545 = env18546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env18545 == env18546) = true)

theorem identity18546 : scanCanonicalize (H12AffineFastState.compose env18546 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound18546 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env18547 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,5237,80,115,5173,2128,1025,81,4161,112,65,3,41,64,2049,5221,4097,2049,1136,112,36,113,5236,592]

theorem envBound18547 : H12AffineFastState.Bounded env18547 := by
  intro p hp
  have h : env18547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18546_18547 : H12AffineEnvironment.transform 12 40 env18546 = env18547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env18546 == env18547) = true)

theorem identity18547 : scanCanonicalize (H12AffineFastState.compose env18547 (packedSelected [3,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound18547 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env18548 : List Nat := [2,4,8,16,0,64,9,5,512,1024,2048,4096,8,5205,80,83,5141,2128,1025,81,4161,80,65,3,9,64,2049,5189,4097,2049,1104,80,4,81,5204,592]

theorem envBound18548 : H12AffineFastState.Bounded env18548 := by
  intro p hp
  have h : env18548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18547_18548 : H12AffineEnvironment.transform 4 0 env18547 = env18548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18547 == env18548) = true)

theorem identity18548 : scanCanonicalize (H12AffineFastState.compose env18548 (packedSelected [18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18548 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env18549 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,4096,8,5125,0,3,5141,2048,1025,1,4113,0,17,3,9,16,2049,5141,4097,2049,1024,0,4,1,5124,512]

theorem envBound18549 : H12AffineFastState.Bounded env18549 := by
  intro p hp
  have h : env18549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18548_18549 : H12AffineEnvironment.transform 5 16 env18548 = env18549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18548 == env18549) = true)

def env18550 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,16449,262144,1025,32769,4161,305360,29844,8582,8328,64,43356,24981,12676,324821,1500,272392,257,21793,46213,63188]

theorem envBound18550 : H12AffineFastState.Bounded env18550 := by
  intro p hp
  have h : env18550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18540_18550 : H12AffineEnvironment.transform 16 16449 env18540 = env18550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env18540 == env18550) = true)

theorem identity18550 : scanCanonicalize (H12AffineFastState.compose env18550 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound18550 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env18551 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,32768,33167,5393,262144,1025,32769,4161,305360,8644,8582,8328,64,43356,13509,12676,303493,1500,272392,257,113,46213,41860]

theorem envBound18551 : H12AffineFastState.Bounded env18551 := by
  intro p hp
  have h : env18551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18550_18551 : H12AffineEnvironment.transform 13 5456 env18550 = env18551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env18550 == env18551) = true)

theorem identity18551 : scanCanonicalize (H12AffineFastState.compose env18551 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound18551 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env18552 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,32768,33167,5393,10280,1025,32769,4161,33016,8644,8582,8328,64,43356,13509,12676,35245,1500,32,257,113,46213,41860]

theorem envBound18552 : H12AffineFastState.Bounded env18552 := by
  intro p hp
  have h : env18552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18551_18552 : H12AffineEnvironment.transform 17 10280 env18551 = env18552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env18551 == env18552) = true)

theorem identity18552 : scanCanonicalize (H12AffineFastState.compose env18552 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18552 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env18553 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,32768,33167,5393,10280,1025,32769,4112,32937,8597,8582,8328,17,43277,13460,12676,35245,1421,32,257,32,46213,41860]

theorem envBound18553 : H12AffineFastState.Bounded env18553 := by
  intro p hp
  have h : env18553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18552_18553 : H12AffineEnvironment.transform 5 17 env18552 = env18553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18552 == env18553) = true)

theorem identity18553 : scanCanonicalize (H12AffineFastState.compose env18553 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound18553 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env18554 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,1,398,5393,10280,1025,0,4112,168,8597,8582,8328,17,10508,13460,12676,2476,1421,32,257,32,13444,9093]

theorem envBound18554 : H12AffineFastState.Bounded env18554 := by
  intro p hp
  have h : env18554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18553_18554 : H12AffineEnvironment.transform 14 1 env18553 = env18554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env18553 == env18554) = true)

theorem identity18554 : scanCanonicalize (H12AffineFastState.compose env18554 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound18554 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env18555 : List Nat := [2,4,8,16,32,17,128,36,512,1024,2048,4096,8192,5157,1,170,5173,10280,1025,0,4112,168,8369,8354,8328,17,10280,13460,12448,2184,1193,32,37,32,13444,8865]

theorem envBound18555 : H12AffineFastState.Bounded env18555 := by
  intro p hp
  have h : env18555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18554_18555 : H12AffineEnvironment.transform 7 36 env18554 = env18555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env18554 == env18555) = true)

theorem identity18555 : scanCanonicalize (H12AffineFastState.compose env18555 (packedSelected [1,3,4,9,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 130) := by decide +kernel

theorem selectedBound18555 : packedSelected [1,3,4,9,12,14] rootPS < 2^1333 := by decide +kernel

def env18556 : List Nat := [2,4,8,16,32,17,128,36,512,1024,2048,130,8192,1191,1,170,1207,10280,1025,0,146,168,8369,8354,8328,17,10280,9238,8226,2184,1193,32,37,32,9222,8865]

theorem envBound18556 : H12AffineFastState.Bounded env18556 := by
  intro p hp
  have h : env18556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18555_18556 : H12AffineEnvironment.transform 11 130 env18555 = env18556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 130 env18555 == env18556) = true)

theorem identity18556 : scanCanonicalize (H12AffineFastState.compose env18556 (packedSelected [0,2,4,7,9,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18556 : packedSelected [0,2,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env18557 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,10,8192,1071,1,34,1087,10280,1025,0,26,32,8249,8234,8192,17,10280,9238,8226,2048,1057,32,37,32,9222,8745]

theorem envBound18557 : H12AffineFastState.Bounded env18557 := by
  intro p hp
  have h : env18557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18556_18557 : H12AffineEnvironment.transform 6 8 env18556 = env18557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18556 == env18557) = true)

theorem identity18557 : scanCanonicalize (H12AffineFastState.compose env18557 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(10+1) ^^^ 1087) := by decide +kernel

theorem selectedBound18557 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env18558 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1087,10,8192,1071,1,34,1087,9239,1025,0,26,32,8249,8234,8192,17,9239,9238,8226,1087,1057,32,37,32,9222,8745]

theorem envBound18558 : H12AffineFastState.Bounded env18558 := by
  intro p hp
  have h : env18558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18557_18558 : H12AffineEnvironment.transform 10 1087 env18557 = env18558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1087 env18557 == env18558) = true)

theorem identity18558 : scanCanonicalize (H12AffineFastState.compose env18558 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 1047) := by decide +kernel

theorem selectedBound18558 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18559 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1087,10,1047,1071,1,34,1087,0,1025,0,26,32,1070,1085,1047,17,0,1,1077,1087,1057,32,37,32,17,1598]

theorem envBound18559 : H12AffineFastState.Bounded env18559 := by
  intro p hp
  have h : env18559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18558_18559 : H12AffineEnvironment.transform 12 1047 env18558 = env18559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1047 env18558 == env18559) = true)

theorem identity18559 : scanCanonicalize (H12AffineFastState.compose env18559 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound18559 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env18560 : List Nat := [2,4,8,16,11,17,8,15,512,1024,1044,10,1047,1028,1,9,1044,0,1025,0,26,11,1029,1046,1047,17,0,1,1054,1044,1034,11,14,11,17,1557]

theorem envBound18560 : H12AffineFastState.Bounded env18560 := by
  intro p hp
  have h : env18560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18559_18560 : H12AffineEnvironment.transform 4 11 env18559 = env18560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env18559 == env18560) = true)

theorem identity18560 : scanCanonicalize (H12AffineFastState.compose env18560 (packedSelected [1,3,11] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18560 : packedSelected [1,3,11] rootPS < 2^1333 := by decide +kernel

def env18561 : List Nat := [2,4,8,1,11,0,8,15,512,1024,1029,10,1030,1028,1,9,1029,0,1025,0,11,11,1029,1031,1030,0,0,1,1039,1029,1034,11,14,11,0,1540]

theorem envBound18561 : H12AffineFastState.Bounded env18561 := by
  intro p hp
  have h : env18561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18560_18561 : H12AffineEnvironment.transform 3 1 env18560 = env18561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18560 == env18561) = true)

theorem identity18561 : scanCanonicalize (H12AffineFastState.compose env18561 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 10) := by decide +kernel

theorem selectedBound18561 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18562 : List Nat := [2,4,8,1,11,0,8,15,512,10,15,10,12,14,1,9,15,0,11,0,11,11,15,13,12,0,0,1,5,15,0,11,14,11,0,526]

theorem envBound18562 : H12AffineFastState.Bounded env18562 := by
  intro p hp
  have h : env18562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18561_18562 : H12AffineEnvironment.transform 9 10 env18561 = env18562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 10 env18561 == env18562) = true)

def env18563 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452753,253962,242969,8328,64,97666,2240916,2340187,335882,119042,2373704,257,2199998,2191386,63189]

theorem envBound18563 : H12AffineFastState.Bounded env18563 := by
  intro p hp
  have h : env18563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18530_18563 : H12AffineEnvironment.transform 23 242969 env18530 = env18563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 242969 env18530 == env18563) = true)

def env18564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452753,253962,242969,8328,64,97666,139732,238875,335882,119042,272392,257,98814,90202,63189]

theorem envBound18564 : H12AffineFastState.Bounded env18564 := by
  intro p hp
  have h : env18564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18563_18564 : H12AffineEnvironment.transform 20 4160 env18563 = env18564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env18563 == env18564) = true)

theorem identity18564 : scanCanonicalize (H12AffineFastState.compose env18564 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound18564 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4160,452753,180224,169235,8328,64,23944,139732,165137,262144,61704,272392,257,41460,16464,63189]

theorem envBound18565 : H12AffineFastState.Bounded env18565 := by
  intro p hp
  have h : env18565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18564_18565 : H12AffineEnvironment.transform 15 8202 env18564 = env18565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env18564 == env18565) = true)

def env18566 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4160,452681,180224,169235,8272,64,23888,139532,165137,262144,61704,272392,257,41260,16464,62989]

theorem envBound18566 : H12AffineFastState.Bounded env18566 := by
  intro p hp
  have h : env18566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18565_18566 : H12AffineEnvironment.transform 6 88 env18565 = env18566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env18565 == env18566) = true)

theorem identity18566 : scanCanonicalize (H12AffineFastState.compose env18566 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound18566 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env18567 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,8202,57676,262144,1025,32769,4160,264453,8524,29791,8272,64,23888,49216,25693,262144,61704,272392,257,41260,16464,62989]

theorem envBound18567 : H12AffineFastState.Bounded env18567 := by
  intro p hp
  have h : env18567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18566_18567 : H12AffineEnvironment.transform 16 57676 env18566 = env18567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env18566 == env18567) = true)

theorem identity18567 : scanCanonicalize (H12AffineFastState.compose env18567 (packedSelected [0,1,3,4,7,18,22,23,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound18567 : packedSelected [0,1,3,4,7,18,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env18568 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,8202,57676,2421,1025,32769,4160,112,8524,29791,8272,64,23888,49216,25693,2421,61704,8573,257,41260,16464,62989]

theorem envBound18568 : H12AffineFastState.Bounded env18568 := by
  intro p hp
  have h : env18568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18567_18568 : H12AffineEnvironment.transform 17 2421 env18567 = env18568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env18567 == env18568) = true)

theorem identity18568 : scanCanonicalize (H12AffineFastState.compose env18568 (packedSelected [1,4,5,7,8,9,16,20,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound18568 : packedSelected [1,4,5,7,8,9,16,20,24,27] rootPS < 2^1333 := by decide +kernel

def env18569 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,16384,32768,263,49217,2421,1025,32769,4160,112,65,21842,349,64,23888,49216,17744,2421,53253,112,257,32801,16464,55040]

theorem envBound18569 : H12AffineFastState.Bounded env18569 := by
  intro p hp
  have h : env18569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18568_18569 : H12AffineEnvironment.transform 12 269 env18568 = env18569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env18568 == env18569) = true)

def env18570 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4160,452680,180224,169235,8273,64,23889,139533,165137,262144,61704,272392,257,41261,16464,62988]

theorem envBound18570 : H12AffineFastState.Bounded env18570 := by
  intro p hp
  have h : env18570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18565_18570 : H12AffineEnvironment.transform 6 89 env18565 = env18570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env18565 == env18570) = true)

theorem identity18570 : scanCanonicalize (H12AffineFastState.compose env18570 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound18570 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env18571 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,8202,5392,262144,1025,32769,4160,327000,54544,32771,8273,64,23889,13341,36865,262144,61704,272392,257,41261,16464,62988]

theorem envBound18571 : H12AffineFastState.Bounded env18571 := by
  intro p hp
  have h : env18571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18570_18571 : H12AffineEnvironment.transform 16 5392 env18570 = env18571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env18570 == env18571) = true)

theorem identity18571 : scanCanonicalize (H12AffineFastState.compose env18571 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound18571 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env18572 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,8202,5392,10280,1025,32769,4160,54640,54544,32771,8273,64,23889,13341,36865,10280,61704,32,257,41261,16464,62988]

theorem envBound18572 : H12AffineFastState.Bounded env18572 := by
  intro p hp
  have h : env18572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18571_18572 : H12AffineEnvironment.transform 17 10280 env18571 = env18572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env18571 == env18572) = true)

theorem identity18572 : scanCanonicalize (H12AffineFastState.compose env18572 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound18572 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env18573 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,13404,32768,8202,5392,10280,1025,32769,4160,41260,41292,32771,8273,64,10509,13341,36865,10280,34132,32,257,41261,13324,33360]

theorem envBound18573 : H12AffineFastState.Bounded env18573 := by
  intro p hp
  have h : env18573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18572_18573 : H12AffineEnvironment.transform 13 13404 env18572 = env18573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env18572 == env18573) = true)

theorem identity18573 : scanCanonicalize (H12AffineFastState.compose env18573 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound18573 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18574 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,13404,0,8202,5392,10280,1025,1,4160,8492,8524,3,8273,64,10509,13341,4097,10280,1364,32,257,8493,13324,592]

theorem envBound18574 : H12AffineFastState.Bounded env18574 := by
  intro p hp
  have h : env18574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18573_18574 : H12AffineEnvironment.transform 14 0 env18573 = env18574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env18573 == env18574) = true)

theorem identity18574 : scanCanonicalize (H12AffineFastState.compose env18574 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound18574 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18575 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5456,0,262,5392,2340,1025,1,4160,32,64,3,349,64,2049,5393,4097,2340,1364,32,257,33,5376,592]

theorem envBound18575 : H12AffineFastState.Bounded env18575 := by
  intro p hp
  have h : env18575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18574_18575 : H12AffineEnvironment.transform 12 268 env18574 = env18575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env18574 == env18575) = true)

def env18576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452753,253962,242969,8328,64,97666,139733,238874,335882,119042,272393,257,98815,90203,63189]

theorem envBound18576 : H12AffineFastState.Bounded env18576 := by
  intro p hp
  have h : env18576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18563_18576 : H12AffineEnvironment.transform 20 4161 env18563 = env18576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env18563 == env18576) = true)

theorem identity18576 : scanCanonicalize (H12AffineFastState.compose env18576 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound18576 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,4161,329866,17,21762,8328,64,97666,115150,17665,335882,119042,272393,257,98815,90203,63189]

theorem envBound18577 : H12AffineFastState.Bounded env18577 := by
  intro p hp
  have h : env18577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18576_18577 : H12AffineEnvironment.transform 16 122907 env18576 = env18577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env18576 == env18577) = true)

def env18578 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,4161,329730,17,21762,8192,64,97546,115014,17665,335882,119042,272393,257,98679,90203,63069]

theorem envBound18578 : H12AffineFastState.Bounded env18578 := by
  intro p hp
  have h : env18578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18577_18578 : H12AffineEnvironment.transform 6 8 env18577 = env18578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18577 == env18578) = true)

theorem identity18578 : scanCanonicalize (H12AffineFastState.compose env18578 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound18578 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18579 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,56436,1025,32769,4161,119926,17,21762,8192,64,97546,115014,17665,130174,119042,62589,257,98679,90203,63069]

theorem envBound18579 : H12AffineFastState.Bounded env18579 := by
  intro p hp
  have h : env18579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18578_18579 : H12AffineEnvironment.transform 17 56436 env18578 = env18579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env18578 == env18579) = true)

theorem identity18579 : scanCanonicalize (H12AffineFastState.compose env18579 (packedSelected [1,2,3,6,8,14,15,16,19,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound18579 : packedSelected [1,2,3,6,8,14,15,16,19,23,24] rootPS < 2^1333 := by decide +kernel

def env18580 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,263,57628,56436,1025,32769,4161,54641,17,21762,8192,64,31757,49217,17665,64889,53253,62589,257,32880,24924,63069]

theorem envBound18580 : H12AffineFastState.Bounded env18580 := by
  intro p hp
  have h : env18580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18579_18580 : H12AffineEnvironment.transform 15 263 env18579 = env18580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env18579 == env18580) = true)

theorem identity18580 : scanCanonicalize (H12AffineFastState.compose env18580 (packedSelected [4,10,11,12,14,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound18580 : packedSelected [4,10,11,12,14,19,22] rootPS < 2^1333 := by decide +kernel

def env18581 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,263,24860,23668,1025,1,4161,21873,17,21762,8192,64,31757,16449,17665,32121,20485,29821,257,112,24924,30301]

theorem envBound18581 : H12AffineFastState.Bounded env18581 := by
  intro p hp
  have h : env18581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18580_18581 : H12AffineEnvironment.transform 14 0 env18580 = env18581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env18580 == env18581) = true)

theorem identity18581 : scanCanonicalize (H12AffineFastState.compose env18581 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18581 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env18582 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,0,263,24860,23589,1025,1,4112,21792,17,21762,8192,17,31757,16400,17665,32040,20485,29740,257,33,24845,30220]

theorem envBound18582 : H12AffineFastState.Bounded env18582 := by
  intro p hp
  have h : env18582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18581_18582 : H12AffineEnvironment.transform 5 17 env18581 = env18582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18581 == env18582) = true)

theorem identity18582 : scanCanonicalize (H12AffineFastState.compose env18582 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 12345) := by decide +kernel

theorem selectedBound18582 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env18583 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,12345,0,263,4389,11292,1025,1,4112,9497,17,9531,8192,17,3124,12329,13624,3345,8252,1045,257,33,4404,1589]

theorem envBound18583 : H12AffineFastState.Bounded env18583 := by
  intro p hp
  have h : env18583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18582_18583 : H12AffineEnvironment.transform 13 12345 env18582 = env18583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12345 env18582 == env18583) = true)

theorem identity18583 : scanCanonicalize (H12AffineFastState.compose env18583 (packedSelected [0,1,2,3,5,7,8,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound18583 : packedSelected [0,1,2,3,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env18584 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,1052,5157,0,263,4389,2048,1025,1,4112,261,17,295,1052,17,3124,5173,4388,3345,1056,1045,257,33,4404,1589]

theorem envBound18584 : H12AffineFastState.Bounded env18584 := by
  intro p hp
  have h : env18584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18583_18584 : H12AffineEnvironment.transform 12 1052 env18583 = env18584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env18583 == env18584) = true)

theorem identity18584 : scanCanonicalize (H12AffineFastState.compose env18584 (packedSelected [1,2,3,5,6,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound18584 : packedSelected [1,2,3,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env18585 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2065,1052,3124,0,263,2356,2048,1025,1,2049,261,17,295,1052,17,3124,3108,2357,3345,1056,1045,257,33,2341,1589]

theorem envBound18585 : H12AffineFastState.Bounded env18585 := by
  intro p hp
  have h : env18585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18584_18585 : H12AffineEnvironment.transform 11 2065 env18584 = env18585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env18584 == env18585) = true)

theorem identity18585 : scanCanonicalize (H12AffineFastState.compose env18585 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound18585 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env18586 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,2065,1052,3124,0,35,2064,2048,1025,1,2049,33,17,3,1052,17,3124,3108,2065,3125,1056,1045,37,33,2049,1589]

theorem envBound18586 : H12AffineFastState.Bounded env18586 := by
  intro p hp
  have h : env18586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18585_18586 : H12AffineEnvironment.transform 7 36 env18585 = env18586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env18585 == env18586) = true)

def env18587 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,4161,329731,17,21762,8193,64,97547,115015,17665,335882,119042,272393,257,98678,90203,63068]

theorem envBound18587 : H12AffineFastState.Bounded env18587 := by
  intro p hp
  have h : env18587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18577_18587 : H12AffineEnvironment.transform 6 9 env18577 = env18587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18577 == env18587) = true)

theorem identity18587 : scanCanonicalize (H12AffineFastState.compose env18587 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound18587 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18588 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,32041,1025,32769,4161,95530,17,21762,8193,64,97547,115015,17665,89379,119042,21792,257,98678,90203,63068]

theorem envBound18588 : H12AffineFastState.Bounded env18588 := by
  intro p hp
  have h : env18588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18587_18588 : H12AffineEnvironment.transform 17 32041 env18587 = env18588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env18587 == env18588) = true)

theorem identity18588 : scanCanonicalize (H12AffineFastState.compose env18588 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound18588 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env18589 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,65536,90139,32041,1025,1,4161,95530,17,21762,8193,64,97547,82247,17665,89379,86274,21792,257,65910,90203,30300]

theorem envBound18589 : H12AffineFastState.Bounded env18589 := by
  intro p hp
  have h : env18589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18588_18589 : H12AffineEnvironment.transform 14 0 env18588 = env18589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env18588 == env18589) = true)

theorem identity18589 : scanCanonicalize (H12AffineFastState.compose env18589 (packedSelected [0,1,4,5,7,8,18,22,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound18589 : packedSelected [0,1,4,5,7,8,18,22,23,24] rootPS < 2^1333 := by decide +kernel

def env18590 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,8282,16449,32041,1025,1,4161,21872,17,21762,8193,64,23889,24861,17665,32121,29016,21792,257,8492,16385,30300]

theorem envBound18590 : H12AffineFastState.Bounded env18590 := by
  intro p hp
  have h : env18590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18589_18590 : H12AffineEnvironment.transform 15 8282 env18589 = env18590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env18589 == env18590) = true)

theorem identity18590 : scanCanonicalize (H12AffineFastState.compose env18590 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound18590 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env18591 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,0,263,16449,23668,1025,1,4161,21872,17,21762,348,64,23889,16448,17665,23588,20485,21792,257,113,16385,22273]

theorem envBound18591 : H12AffineFastState.Bounded env18591 := by
  intro p hp
  have h : env18591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18590_18591 : H12AffineEnvironment.transform 12 349 env18590 = env18591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env18590 == env18591) = true)

theorem identity18591 : scanCanonicalize (H12AffineFastState.compose env18591 (packedSelected [0,4,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound18591 : packedSelected [0,4,10,11] rootPS < 2^1333 := by decide +kernel

def env18592 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,263,5441,2420,1025,1,4161,112,17,2,348,64,2129,5440,4097,2340,1285,32,257,113,5377,513]

theorem envBound18592 : H12AffineFastState.Bounded env18592 := by
  intro p hp
  have h : env18592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18591_18592 : H12AffineEnvironment.transform 13 5376 env18591 = env18592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env18591 == env18592) = true)

def env18593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507600,155254784,25265168,145662401,525568,140903597,27337993,25733063]

theorem envBound18593 : H12AffineFastState.Bounded env18593 := by
  intro p hp
  have h : env18593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17796_18593 : H12AffineEnvironment.transform 25 65 env17796 = env18593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env17796 == env18593) = true)

def env18594 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507600,9356288,25265168,23160257,525568,27902125,27337993,25733063]

theorem envBound18594 : H12AffineFastState.Bounded env18594 := by
  intro p hp
  have h : env18594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18593_18594 : H12AffineEnvironment.transform 26 30393344 env18593 = env18594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env18593 == env18594) = true)

def env18595 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830976,25265168,23160257,256,27378861,27337993,25207751]

theorem envBound18595 : H12AffineFastState.Bounded env18595 := by
  intro p hp
  have h : env18595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18594_18595 : H12AffineEnvironment.transform 18 1024 env18594 = env18595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env18594 == env18595) = true)

theorem identity18595 : scanCanonicalize (H12AffineFastState.compose env18595 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10923371) := by decide +kernel

theorem selectedBound18595 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env18596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10923371,8328,65,6385003,8858087,10507600,8830976,2566523,13093034,256,485830,493666,2494124]

theorem envBound18596 : H12AffineFastState.Bounded env18596 := by
  intro p hp
  have h : env18596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18595_18596 : H12AffineEnvironment.transform 23 10923371 env18595 = env18596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10923371 env18595 == env18596) = true)

def env18597 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,452648,2114883,8328,65,6385003,115151,2538872,10280,2566523,4268162,256,485830,493666,2494124]

theorem envBound18597 : H12AffineFastState.Bounded env18597 := by
  intro p hp
  have h : env18597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18596_18597 : H12AffineEnvironment.transform 22 452648 env18596 = env18597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452648 env18596 == env18597) = true)

def env18598 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,4194304,452648,441659,8328,65,4691219,115151,17664,10280,119043,4268162,256,485830,493666,63188]

theorem envBound18598 : H12AffineFastState.Bounded env18598 := by
  intro p hp
  have h : env18598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18597_18598 : H12AffineEnvironment.transform 20 456824 env18597 = env18598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456824 env18597 == env18598) = true)

def env18599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272512,452648,441659,8328,65,245139,115151,17664,10280,119043,329730,256,485830,493666,63188]

theorem envBound18599 : H12AffineFastState.Bounded env18599 := by
  intro p hp
  have h : env18599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18598_18599 : H12AffineEnvironment.transform 21 272512 env18598 = env18599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env18598 == env18599) = true)

theorem identity18599 : scanCanonicalize (H12AffineFastState.compose env18599 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound18599 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,456824,272512,452648,441659,8328,65,171417,57797,17664,10280,61705,272392,256,412108,436328,63188]

theorem envBound18600 : H12AffineFastState.Bounded env18600 := by
  intro p hp
  have h : env18600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18599_18600 : H12AffineEnvironment.transform 15 8202 env18599 = env18600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env18599 == env18600) = true)

def env18601 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,456824,272392,452648,441659,8192,65,171281,57677,17664,10280,61705,272392,256,411972,436328,63068]

theorem envBound18601 : H12AffineFastState.Bounded env18601 := by
  intro p hp
  have h : env18601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18600_18601 : H12AffineEnvironment.transform 6 8 env18600 = env18601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18600 == env18601) = true)

theorem identity18601 : scanCanonicalize (H12AffineFastState.compose env18601 (packedSelected [0,1,7,8,9,10,11,12,14,15,17,19,20,22,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound18601 : packedSelected [0,1,7,8,9,10,11,12,14,15,17,19,20,22,31,32] rootPS < 2^1333 := by decide +kernel

def env18602 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,46156,262144,1024,32769,281652,272392,285796,264567,8192,65,10589,57677,17664,10280,61705,272392,256,326920,269348,63068]

theorem envBound18602 : H12AffineFastState.Bounded env18602 := by
  intro p hp
  have h : env18602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18601_18602 : H12AffineEnvironment.transform 16 46156 env18601 = env18602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env18601 == env18602) = true)

theorem identity18602 : scanCanonicalize (H12AffineFastState.compose env18602 (packedSelected [0,1,3,4,5,12,14,15,17,18,19,20,22,23,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound18602 : packedSelected [0,1,3,4,5,12,14,15,17,18,19,20,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env18603 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,46156,32041,1024,32769,12573,21793,8525,29790,8192,65,10589,57677,17664,10280,61705,21793,256,32801,24845,63068]

theorem envBound18603 : H12AffineFastState.Bounded env18603 := by
  intro p hp
  have h : env18603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18602_18603 : H12AffineEnvironment.transform 17 32041 env18602 = env18603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env18602 == env18603) = true)

theorem identity18603 : scanCanonicalize (H12AffineFastState.compose env18603 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound18603 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env18604 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,5393,32041,1024,8540,12573,21793,8525,29790,8192,65,10589,16400,17664,10280,20564,21793,256,8572,24845,22273]

theorem envBound18604 : H12AffineFastState.Bounded env18604 := by
  intro p hp
  have h : env18604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18603_18604 : H12AffineEnvironment.transform 14 8541 env18603 = env18604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env18603 == env18604) = true)

theorem identity18604 : scanCanonicalize (H12AffineFastState.compose env18604 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound18604 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env18605 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,16384,1297,1094,5393,22885,1024,1296,5457,21793,1281,20498,1100,65,3345,16400,17664,3172,20564,21793,256,1328,17729,22273]

theorem envBound18605 : H12AffineFastState.Bounded env18605 := by
  intro p hp
  have h : env18605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18604_18605 : H12AffineEnvironment.transform 12 1100 env18604 = env18605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env18604 == env18605) = true)

theorem identity18605 : scanCanonicalize (H12AffineFastState.compose env18605 (packedSelected [0,1,7,8,10,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound18605 : packedSelected [0,1,7,8,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env18606 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3329,1100,16384,1297,1094,2064,17508,1024,1296,2128,18464,1281,19731,1100,65,3345,16400,17664,3172,19797,18464,256,1328,17729,18944]

theorem envBound18606 : H12AffineFastState.Bounded env18606 := by
  intro p hp
  have h : env18606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18605_18606 : H12AffineEnvironment.transform 11 3329 env18605 = env18606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env18605 == env18606) = true)

theorem identity18606 : scanCanonicalize (H12AffineFastState.compose env18606 (packedSelected [1,6,7,8,9,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound18606 : packedSelected [1,6,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env18607 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,3108,1100,16384,1076,1094,2064,17508,1024,1077,2128,18464,1060,19510,1100,65,3124,16400,17445,3172,19568,18464,37,1045,17508,18944]

theorem envBound18607 : H12AffineFastState.Bounded env18607 := by
  intro p hp
  have h : env18607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18606_18607 : H12AffineEnvironment.transform 7 37 env18606 = env18607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env18606 == env18607) = true)

theorem identity18607 : scanCanonicalize (H12AffineFastState.compose env18607 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 2128) := by decide +kernel

theorem selectedBound18607 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env18608 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,3108,1100,2128,1076,1094,2064,3124,1024,1077,2128,112,1060,1126,1100,65,3124,2112,3189,3172,1056,112,37,1045,3124,592]

theorem envBound18608 : H12AffineFastState.Bounded env18608 := by
  intro p hp
  have h : env18608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18607_18608 : H12AffineEnvironment.transform 13 2128 env18607 = env18608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2128 env18607 == env18608) = true)

theorem identity18608 : scanCanonicalize (H12AffineFastState.compose env18608 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 17) := by decide +kernel

theorem selectedBound18608 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18609 : List Nat := [2,4,8,16,32,64,8,37,512,17,2048,2101,93,2128,37,87,2064,2085,17,36,2128,112,53,119,93,65,2085,2112,2148,2165,49,112,37,4,2085,592]

theorem envBound18609 : H12AffineFastState.Bounded env18609 := by
  intro p hp
  have h : env18609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18608_18609 : H12AffineEnvironment.transform 9 17 env18608 = env18609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 17 env18608 == env18609) = true)

theorem identity18609 : scanCanonicalize (H12AffineFastState.compose env18609 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 113) := by decide +kernel

theorem selectedBound18609 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env18610 : List Nat := [2,4,8,16,32,64,8,37,512,17,113,68,93,33,37,87,97,84,17,36,33,112,53,119,93,65,84,49,21,4,49,112,37,4,84,592]

theorem envBound18610 : H12AffineFastState.Bounded env18610 := by
  intro p hp
  have h : env18610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18609_18610 : H12AffineEnvironment.transform 10 113 env18609 = env18610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 113 env18609 == env18610) = true)

theorem identity18610 : scanCanonicalize (H12AffineFastState.compose env18610 (packedSelected [1,2,4,6,8,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18610 : packedSelected [1,2,4,6,8,10] rootPS < 2^1333 := by decide +kernel

def env18611 : List Nat := [2,4,8,16,32,17,8,37,512,17,32,21,12,33,37,6,48,5,17,36,33,33,53,38,12,16,5,49,21,4,49,33,37,4,5,513]

theorem envBound18611 : H12AffineFastState.Bounded env18611 := by
  intro p hp
  have h : env18611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18610_18611 : H12AffineEnvironment.transform 5 17 env18610 = env18611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18610 == env18611) = true)

theorem identity18611 : scanCanonicalize (H12AffineFastState.compose env18611 (packedSelected [2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 19) := by decide +kernel

theorem selectedBound18611 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env18612 : List Nat := [2,4,8,16,19,17,8,22,512,17,19,21,12,18,22,6,3,5,17,23,18,18,6,21,12,16,5,2,21,4,2,18,22,4,5,513]

theorem envBound18612 : H12AffineFastState.Bounded env18612 := by
  intro p hp
  have h : env18612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18611_18612 : H12AffineEnvironment.transform 4 19 env18611 = env18612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 19 env18611 == env18612) = true)

def env18613 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,456824,272393,452648,441659,8193,65,171280,57676,17664,10280,61705,272392,256,411973,436328,63069]

theorem envBound18613 : H12AffineFastState.Bounded env18613 := by
  intro p hp
  have h : env18613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18600_18613 : H12AffineEnvironment.transform 6 9 env18600 = env18613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18600 == env18613) = true)

theorem identity18613 : scanCanonicalize (H12AffineFastState.compose env18613 (packedSelected [0,1,7,8,9,10,11,12,14,15,17,19,20,22,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 182336) := by decide +kernel

theorem selectedBound18613 : packedSelected [0,1,7,8,9,10,11,12,14,15,17,19,20,22,31,32] rootPS < 2^1333 := by decide +kernel

def env18614 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,182336,1024,32769,12344,188489,8296,30075,8193,65,171280,57676,17664,10280,61705,188488,256,33029,24616,63069]

theorem envBound18614 : H12AffineFastState.Bounded env18614 := by
  intro p hp
  have h : env18614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18613_18614 : H12AffineEnvironment.transform 17 182336 env18613 = env18614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182336 env18613 == env18614) = true)

theorem identity18614 : scanCanonicalize (H12AffineFastState.compose env18614 (packedSelected [2,7,8,11,12,15,18,20,27,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound18614 : packedSelected [2,7,8,11,12,15,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env18615 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,32768,8202,131072,171280,1024,32769,12344,177433,8296,8235,8193,65,171280,46108,4176,10280,42073,177432,256,33029,13688,41741]

theorem envBound18615 : H12AffineFastState.Bounded env18615 := by
  intro p hp
  have h : env18615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18614_18615 : H12AffineEnvironment.transform 13 5456 env18614 = env18615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env18614 == env18615) = true)

theorem identity18615 : scanCanonicalize (H12AffineFastState.compose env18615 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound18615 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env18616 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,292,8202,131072,138292,1024,293,12344,144445,8296,8235,8193,65,138292,13624,4176,10280,9597,144444,256,33,13688,8745]

theorem envBound18616 : H12AffineFastState.Bounded env18616 := by
  intro p hp
  have h : env18616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18615_18616 : H12AffineEnvironment.transform 14 292 env18615 = env18616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env18615 == env18616) = true)

theorem identity18616 : scanCanonicalize (H12AffineFastState.compose env18616 (packedSelected [16,20] rootPS)) = affineNative (2^(16+1) ^^^ 13673) := by decide +kernel

theorem selectedBound18616 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env18617 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,292,8202,13673,10589,1024,293,12344,340,8296,8235,8193,65,10589,13624,4176,10280,9597,341,256,33,13688,8745]

theorem envBound18617 : H12AffineFastState.Bounded env18617 := by
  intro p hp
  have h : env18617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18616_18617 : H12AffineEnvironment.transform 16 13673 env18616 = env18617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13673 env18616 == env18617) = true)

theorem identity18617 : scanCanonicalize (H12AffineFastState.compose env18617 (packedSelected [0,1,2,4,6,7,8,9,12,14] rootPS)) = affineNative (2^(10+1) ^^^ 1093) := by decide +kernel

theorem selectedBound18617 : packedSelected [0,1,2,4,6,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env18618 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1093,4096,8192,5456,292,8202,13673,9496,1024,293,12344,340,8296,8235,8193,65,9496,13624,4176,9325,9597,341,256,33,13688,8745]

theorem envBound18618 : H12AffineFastState.Bounded env18618 := by
  intro p hp
  have h : env18618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18617_18618 : H12AffineEnvironment.transform 10 1093 env18617 = env18618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1093 env18617 == env18618) = true)

theorem identity18618 : scanCanonicalize (H12AffineFastState.compose env18618 (packedSelected [2,4,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 1304) := by decide +kernel

theorem selectedBound18618 : packedSelected [2,4,7,11] rootPS < 2^1333 := by decide +kernel

def env18619 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1093,4096,1304,5456,292,1298,4209,0,1024,293,5408,340,1392,1331,1305,65,0,4128,4176,373,101,341,256,33,4192,1841]

theorem envBound18619 : H12AffineFastState.Bounded env18619 := by
  intro p hp
  have h : env18619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18618_18619 : H12AffineEnvironment.transform 12 1304 env18618 = env18619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1304 env18618 == env18619) = true)

theorem identity18619 : scanCanonicalize (H12AffineFastState.compose env18619 (packedSelected [0,1,2,4,7,8,9,12] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound18619 : packedSelected [0,1,2,4,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env18620 : List Nat := [2,4,8,16,32,64,9,256,512,52,113,4096,300,4452,292,294,4209,0,52,293,4372,340,324,263,301,65,0,4128,4176,373,101,341,256,33,4192,773]

theorem envBound18620 : H12AffineFastState.Bounded env18620 := by
  intro p hp
  have h : env18620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18619_18620 : H12AffineEnvironment.transform 9 52 env18619 = env18620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env18619 == env18620) = true)

theorem identity18620 : scanCanonicalize (H12AffineFastState.compose env18620 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound18620 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env18621 : List Nat := [2,4,8,16,32,64,9,256,512,52,113,17,300,373,292,294,96,0,52,293,261,340,324,263,301,65,0,49,65,373,101,341,256,33,113,773]

theorem envBound18621 : H12AffineFastState.Bounded env18621 := by
  intro p hp
  have h : env18621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18620_18621 : H12AffineEnvironment.transform 11 17 env18620 = env18621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env18620 == env18621) = true)

theorem identity18621 : scanCanonicalize (H12AffineFastState.compose env18621 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound18621 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18622 : List Nat := [2,4,8,16,32,64,9,36,512,52,113,17,8,81,0,2,96,0,52,1,33,112,96,35,9,65,0,49,65,81,101,113,36,33,113,545]

theorem envBound18622 : H12AffineFastState.Bounded env18622 := by
  intro p hp
  have h : env18622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18621_18622 : H12AffineEnvironment.transform 7 36 env18621 = env18622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env18621 == env18622) = true)

theorem identity18622 : scanCanonicalize (H12AffineFastState.compose env18622 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 21) := by decide +kernel

theorem selectedBound18622 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env18623 : List Nat := [2,4,8,16,32,64,9,36,21,52,113,17,8,81,0,2,96,0,52,1,33,112,96,35,9,65,0,49,65,81,101,113,36,33,113,52]

theorem envBound18623 : H12AffineFastState.Bounded env18623 := by
  intro p hp
  have h : env18623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18622_18623 : H12AffineEnvironment.transform 8 21 env18622 = env18623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 21 env18622 == env18623) = true)

def env18624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272513,452648,441659,8328,65,245138,115151,17664,10280,119043,329731,256,485830,493666,63188]

theorem envBound18624 : H12AffineFastState.Bounded env18624 := by
  intro p hp
  have h : env18624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18598_18624 : H12AffineEnvironment.transform 21 272513 env18598 = env18624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env18598 == env18624) = true)

theorem identity18624 : scanCanonicalize (H12AffineFastState.compose env18624 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247858) := by decide +kernel

theorem selectedBound18624 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,77898,254131,73754,95497,8328,65,245138,115151,17664,10280,119043,180273,256,41460,16464,63188]

theorem envBound18625 : H12AffineFastState.Bounded env18625 := by
  intro p hp
  have h : env18625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18624_18625 : H12AffineEnvironment.transform 17 247858 env18624 = env18625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247858 env18624 == env18625) = true)

def env18626 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,77850,254131,73754,95497,8328,17,245138,115103,17664,10280,119043,180273,256,41380,16384,63108]

theorem envBound18626 : H12AffineFastState.Bounded env18626 := by
  intro p hp
  have h : env18626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18625_18626 : H12AffineEnvironment.transform 5 16 env18625 = env18626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18625 == env18626) = true)

theorem identity18626 : scanCanonicalize (H12AffineFastState.compose env18626 (packedSelected [1,3,4,7,9,10,12,15,17,18,19,23,24,26,27,28,31,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound18626 : packedSelected [1,3,4,7,9,10,12,15,17,18,19,23,24,26,27,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env18627 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29709,65536,131072,212031,1024,29708,77850,201918,73754,95497,8328,17,215455,79250,17664,10280,75022,144444,256,21929,16384,649]

theorem envBound18627 : H12AffineFastState.Bounded env18627 := by
  intro p hp
  have h : env18627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18626_18627 : H12AffineEnvironment.transform 14 29709 env18626 = env18627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env18626 == env18627) = true)

theorem identity18627 : scanCanonicalize (H12AffineFastState.compose env18627 (packedSelected [1,8,12,15,16,18,19,20,23] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18627 : packedSelected [1,8,12,15,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env18628 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,65536,131072,212031,1024,29708,77850,201783,73754,95497,8193,17,215318,79131,17664,10280,75022,144444,256,21792,16384,512]

theorem envBound18628 : H12AffineFastState.Bounded env18628 := by
  intro p hp
  have h : env18628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18627_18628 : H12AffineEnvironment.transform 6 9 env18627 = env18628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18627 == env18628) = true)

theorem identity18628 : scanCanonicalize (H12AffineFastState.compose env18628 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(16+1) ^^^ 16692) := by decide +kernel

theorem selectedBound18628 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env18629 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,65536,16692,97547,1024,29708,77850,87299,73754,95497,8193,17,67618,79131,17664,10280,75022,29960,256,21792,16384,512]

theorem envBound18629 : H12AffineFastState.Bounded env18629 := by
  intro p hp
  have h : env18629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18628_18629 : H12AffineEnvironment.transform 16 16692 env18628 = env18629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16692 env18628 == env18629) = true)

theorem identity18629 : scanCanonicalize (H12AffineFastState.compose env18629 (packedSelected [0,2,6,7,11,16,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound18629 : packedSelected [0,2,6,7,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env18630 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,8202,16692,23809,1024,29708,4112,29961,16,21763,8193,17,10280,5393,17664,10280,1284,29960,256,21792,16384,512]

theorem envBound18630 : H12AffineFastState.Bounded env18630 := by
  intro p hp
  have h : env18630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18629_18630 : H12AffineEnvironment.transform 15 8202 env18629 = env18630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env18629 == env18630) = true)

theorem identity18630 : scanCanonicalize (H12AffineFastState.compose env18630 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound18630 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env18631 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,4096,8192,16384,29709,8202,16433,23556,1024,29708,4112,29708,16,21510,8193,17,10280,5140,17413,10280,1025,29709,5,21541,16384,512]

theorem envBound18631 : H12AffineFastState.Bounded env18631 := by
  intro p hp
  have h : env18631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18630_18631 : H12AffineEnvironment.transform 7 5 env18630 = env18631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env18630 == env18631) = true)

theorem identity18631 : scanCanonicalize (H12AffineFastState.compose env18631 (packedSelected [2,14] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound18631 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env18632 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,4096,40,16384,21541,34,16433,23556,1024,21540,4112,21540,16,21510,41,17,2048,5140,17413,2048,1025,21541,5,21541,16384,512]

theorem envBound18632 : H12AffineFastState.Bounded env18632 := by
  intro p hp
  have h : env18632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18631_18632 : H12AffineEnvironment.transform 12 40 env18631 = env18632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env18631 == env18632) = true)

theorem identity18632 : scanCanonicalize (H12AffineFastState.compose env18632 (packedSelected [11] rootPS)) = affineNative (2^(13+1) ^^^ 1076) := by decide +kernel

theorem selectedBound18632 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env18633 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,4096,40,1076,4113,34,1029,6192,1024,4112,4112,4112,16,4146,41,17,2048,5140,49,2048,1025,4113,5,4113,1076,512]

theorem envBound18633 : H12AffineFastState.Bounded env18633 := by
  intro p hp
  have h : env18633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18632_18633 : H12AffineEnvironment.transform 13 1076 env18632 = env18633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1076 env18632 == env18633) = true)

theorem identity18633 : scanCanonicalize (H12AffineFastState.compose env18633 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound18633 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env18634 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,2096,40,1076,2081,34,1029,0,1024,2080,2080,2080,16,2050,41,17,2048,3108,49,2048,1025,2081,5,2081,1076,512]

theorem envBound18634 : H12AffineFastState.Bounded env18634 := by
  intro p hp
  have h : env18634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18633_18634 : H12AffineEnvironment.transform 11 2096 env18633 = env18634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env18633 == env18634) = true)

theorem identity18634 : scanCanonicalize (H12AffineFastState.compose env18634 (packedSelected [0,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound18634 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env18635 : List Nat := [2,4,8,16,32,16,9,5,512,1024,0,48,40,1076,33,34,1029,0,1024,32,32,32,16,2,41,17,0,1060,49,0,1025,33,5,33,1076,512]

theorem envBound18635 : H12AffineFastState.Bounded env18635 := by
  intro p hp
  have h : env18635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18634_18635 : H12AffineEnvironment.transform 10 0 env18634 = env18635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env18634 == env18635) = true)

theorem identity18635 : scanCanonicalize (H12AffineFastState.compose env18635 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound18635 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env18636 : List Nat := [2,4,8,16,32,16,9,5,512,37,0,48,40,17,33,34,32,0,37,32,32,32,16,2,41,17,0,1,49,0,36,33,5,33,17,512]

theorem envBound18636 : H12AffineFastState.Bounded env18636 := by
  intro p hp
  have h : env18636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18635_18636 : H12AffineEnvironment.transform 9 37 env18635 = env18636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env18635 == env18636) = true)

theorem identity18636 : scanCanonicalize (H12AffineFastState.compose env18636 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound18636 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env18637 : List Nat := [2,4,8,16,32,16,9,5,17,37,0,48,40,17,33,34,32,0,37,32,32,32,16,2,41,17,0,1,49,0,36,33,5,33,17,17]

theorem envBound18637 : H12AffineFastState.Bounded env18637 := by
  intro p hp
  have h : env18637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18636_18637 : H12AffineEnvironment.transform 8 17 env18636 = env18637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env18636 == env18637) = true)

def env18638 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,77851,254131,73754,95497,8328,16,245138,115102,17664,10280,119043,180273,256,41381,16385,63109]

theorem envBound18638 : H12AffineFastState.Bounded env18638 := by
  intro p hp
  have h : env18638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18625_18638 : H12AffineEnvironment.transform 5 17 env18625 = env18638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18625 == env18638) = true)

def env18639 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,77851,254011,73754,95497,8192,16,245018,114966,17664,10280,119043,180273,256,41261,16385,62989]

theorem envBound18639 : H12AffineFastState.Bounded env18639 := by
  intro p hp
  have h : env18639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18638_18639 : H12AffineEnvironment.transform 6 8 env18638 = env18639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18638 == env18639) = true)

theorem identity18639 : scanCanonicalize (H12AffineFastState.compose env18639 (packedSelected [0,1,3,7,8,9,10,12,14,15,16,18,19,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound18639 : packedSelected [0,1,3,7,8,9,10,12,14,15,16,18,19,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env18640 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,89379,1024,32769,77851,95530,73754,95497,8192,16,75787,114966,17664,10280,119043,21792,256,41261,16385,62989]

theorem envBound18640 : H12AffineFastState.Bounded env18640 := by
  intro p hp
  have h : env18640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18639_18640 : H12AffineEnvironment.transform 16 38161 env18639 = env18640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env18639 == env18640) = true)

theorem identity18640 : scanCanonicalize (H12AffineFastState.compose env18640 (packedSelected [0,1,7,8,9,12,14,15,16,17,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound18640 : packedSelected [0,1,7,8,9,12,14,15,16,17,19,22] rootPS < 2^1333 := by decide +kernel

def env18641 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,32768,65536,38161,89379,1024,32769,69910,87079,65815,87044,269,16,67846,114966,17664,2341,119043,21792,256,32800,16385,55040]

theorem envBound18641 : H12AffineFastState.Bounded env18641 := by
  intro p hp
  have h : env18641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18640_18641 : H12AffineEnvironment.transform 12 269 env18640 = env18641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env18640 == env18641) = true)

theorem identity18641 : scanCanonicalize (H12AffineFastState.compose env18641 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound18641 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env18642 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,32768,21510,38161,2341,1024,32769,17680,33,21777,2,269,16,23808,38160,17664,2341,34053,21792,256,32800,16385,55040]

theorem envBound18642 : H12AffineFastState.Bounded env18642 := by
  intro p hp
  have h : env18642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18641_18642 : H12AffineEnvironment.transform 15 21510 env18641 = env18642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env18641 == env18642) = true)

theorem identity18642 : scanCanonicalize (H12AffineFastState.compose env18642 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound18642 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18643 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,21761,21510,16400,2341,1024,21760,17680,33,21777,2,269,16,23808,16401,17664,2341,20484,21792,256,21793,16385,513]

theorem envBound18643 : H12AffineFastState.Bounded env18643 := by
  intro p hp
  have h : env18643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18642_18643 : H12AffineEnvironment.transform 14 21761 env18642 = env18643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env18642 == env18643) = true)

theorem identity18643 : scanCanonicalize (H12AffineFastState.compose env18643 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound18643 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18644 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,0,263,5393,2341,1024,1,4113,33,16,2,269,16,2049,5392,4097,2341,1285,33,256,32,5376,513]

theorem envBound18644 : H12AffineFastState.Bounded env18644 := by
  intro p hp
  have h : env18644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18643_18644 : H12AffineEnvironment.transform 13 5377 env18643 = env18644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env18643 == env18644) = true)

theorem identity18644 : scanCanonicalize (H12AffineFastState.compose env18644 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound18644 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18645 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,277,269,1044,0,263,1028,2341,1024,1,260,33,16,2,269,16,2049,1029,276,2341,1285,33,256,32,1045,513]

theorem envBound18645 : H12AffineFastState.Bounded env18645 := by
  intro p hp
  have h : env18645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18644_18645 : H12AffineEnvironment.transform 11 277 env18644 = env18645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env18644 == env18645) = true)

theorem identity18645 : scanCanonicalize (H12AffineFastState.compose env18645 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound18645 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18646 : List Nat := [2,4,8,16,32,17,8,256,512,20,2048,277,269,0,0,263,16,2341,20,1,260,33,16,2,269,16,2049,17,276,2341,273,33,256,32,1,513]

theorem envBound18646 : H12AffineFastState.Bounded env18646 := by
  intro p hp
  have h : env18646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18645_18646 : H12AffineEnvironment.transform 9 20 env18645 = env18646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env18645 == env18646) = true)

theorem identity18646 : scanCanonicalize (H12AffineFastState.compose env18646 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound18646 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18647 : List Nat := [2,4,8,16,32,17,8,256,0,20,2048,277,269,0,0,263,16,2341,20,1,260,33,16,2,269,16,2049,17,276,2341,273,33,256,32,1,1]

theorem envBound18647 : H12AffineFastState.Bounded env18647 := by
  intro p hp
  have h : env18647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18646_18647 : H12AffineEnvironment.transform 8 0 env18646 = env18647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env18646 == env18647) = true)

theorem identity18647 : scanCanonicalize (H12AffineFastState.compose env18647 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound18647 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18648 : List Nat := [2,4,8,16,17,17,8,256,0,20,2048,277,269,0,0,263,16,2324,20,1,260,16,16,2,269,16,2049,17,276,2324,273,16,256,17,1,1]

theorem envBound18648 : H12AffineFastState.Bounded env18648 := by
  intro p hp
  have h : env18648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18647_18648 : H12AffineEnvironment.transform 4 17 env18647 = env18648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env18647 == env18648) = true)

theorem identity18648 : scanCanonicalize (H12AffineFastState.compose env18648 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound18648 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18649 : List Nat := [2,4,8,16,17,17,8,256,0,20,260,277,269,0,0,263,16,16,20,1,260,16,16,2,269,16,261,17,276,16,273,16,256,17,1,1]

theorem envBound18649 : H12AffineFastState.Bounded env18649 := by
  intro p hp
  have h : env18649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18648_18649 : H12AffineEnvironment.transform 10 260 env18648 = env18649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env18648 == env18649) = true)

theorem identity18649 : scanCanonicalize (H12AffineFastState.compose env18649 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound18649 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env18650 : List Nat := [2,4,8,16,17,17,8,20,0,20,16,1,25,0,0,19,16,16,20,1,16,16,16,2,25,16,17,17,0,16,5,16,20,17,1,1]

theorem envBound18650 : H12AffineFastState.Bounded env18650 := by
  intro p hp
  have h : env18650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18649_18650 : H12AffineEnvironment.transform 7 20 env18649 = env18650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env18649 == env18650) = true)

theorem identity18650 : scanCanonicalize (H12AffineFastState.compose env18650 (packedSelected [9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18650 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env18651 : List Nat := [2,4,8,1,0,0,8,5,0,5,1,1,8,0,0,2,1,1,5,1,1,1,1,2,8,1,0,0,0,1,5,1,5,0,1,1]

theorem envBound18651 : H12AffineFastState.Bounded env18651 := by
  intro p hp
  have h : env18651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18650_18651 : H12AffineEnvironment.transform 3 1 env18650 = env18651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18650 == env18651) = true)

def env18652 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,77851,254010,73754,95497,8193,16,245019,114967,17664,10280,119043,180273,256,41260,16385,62988]

theorem envBound18652 : H12AffineFastState.Bounded env18652 := by
  intro p hp
  have h : env18652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18638_18652 : H12AffineEnvironment.transform 6 9 env18638 = env18652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18638 == env18652) = true)

theorem identity18652 : scanCanonicalize (H12AffineFastState.compose env18652 (packedSelected [0,1,3,7,8,9,10,12,14,15,16,18,19,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound18652 : packedSelected [0,1,3,7,8,9,10,12,14,15,16,18,19,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env18653 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,293,65536,131072,215319,1024,292,77851,221471,73754,95497,8193,16,212030,81970,17664,10280,86054,147732,256,8201,16385,30505]

theorem envBound18653 : H12AffineFastState.Bounded env18653 := by
  intro p hp
  have h : env18653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18652_18653 : H12AffineEnvironment.transform 14 293 env18652 = env18653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env18652 == env18653) = true)

theorem identity18653 : scanCanonicalize (H12AffineFastState.compose env18653 (packedSelected [0,1,4,7,8,12,15,18,19,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound18653 : packedSelected [0,1,4,7,8,12,15,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env18654 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13608,293,65536,131072,212031,1024,292,77851,201783,73754,65569,8193,16,212030,79130,12328,10280,75022,144444,256,8201,13609,513]

theorem envBound18654 : H12AffineFastState.Bounded env18654 := by
  intro p hp
  have h : env18654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18653_18654 : H12AffineEnvironment.transform 13 13608 env18653 = env18654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env18653 == env18654) = true)

theorem identity18654 : scanCanonicalize (H12AffineFastState.compose env18654 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound18654 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env18655 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,40,5376,293,65536,131072,203799,1024,292,69683,201783,65586,65569,41,16,203798,70962,4096,2048,66854,136212,256,33,5377,513]

theorem envBound18655 : H12AffineFastState.Bounded env18655 := by
  intro p hp
  have h : env18655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18654_18655 : H12AffineEnvironment.transform 12 40 env18654 = env18655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env18654 == env18655) = true)

theorem identity18655 : scanCanonicalize (H12AffineFastState.compose env18655 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 69894) := by decide +kernel

theorem selectedBound18655 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env18656 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,40,5376,293,65536,69894,3345,1024,292,69683,1329,65586,65569,41,16,3344,70962,4096,2048,66854,66834,256,33,5377,513]

theorem envBound18656 : H12AffineFastState.Bounded env18656 := by
  intro p hp
  have h : env18656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18655_18656 : H12AffineEnvironment.transform 16 69894 env18655 = env18656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 69894 env18655 == env18656) = true)

theorem identity18656 : scanCanonicalize (H12AffineFastState.compose env18656 (packedSelected [12,15] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound18656 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env18657 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,40,5376,293,35,4389,3345,1024,292,4112,1329,17,2,41,16,3344,5393,4096,2048,1285,1329,256,33,5377,513]

theorem envBound18657 : H12AffineFastState.Bounded env18657 := by
  intro p hp
  have h : env18657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18656_18657 : H12AffineEnvironment.transform 15 35 env18656 = env18657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env18656 == env18657) = true)

theorem identity18657 : scanCanonicalize (H12AffineFastState.compose env18657 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound18657 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env18658 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1296,4096,40,5376,293,35,4389,1,1024,292,4112,1329,17,2,41,16,0,5393,4096,1296,1285,1329,256,33,5377,513]

theorem envBound18658 : H12AffineFastState.Bounded env18658 := by
  intro p hp
  have h : env18658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18657_18658 : H12AffineEnvironment.transform 10 1296 env18657 = env18658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env18657 == env18658) = true)

def env18659 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,4194304,452648,441658,8328,65,4691218,115151,17665,10280,119042,4268162,256,485830,493666,63189]

end H12CloudChart0