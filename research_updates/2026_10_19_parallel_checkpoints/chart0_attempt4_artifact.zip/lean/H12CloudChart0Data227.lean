import H12CloudChart0Data226

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env57536 : List Nat := [2,4,2,16,32,49,128,5,512,37,643,544,35,512,130,3,675,690,37,130,643,32,146,128,160,178,659,512,642,675,36,162,4,163,674,512]

theorem envBound57536 : H12AffineFastState.Bounded env57536 := by
  intro p hp
  have h : env57536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57535_57536 : H12AffineEnvironment.transform 2 2 env57535 = env57536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57535 == env57536) = true)

theorem identity57536 : scanCanonicalize (H12AffineFastState.compose env57536 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound57536 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env57537 : List Nat := [2,4,2,16,32,49,50,5,512,37,561,544,35,512,48,3,529,512,37,48,561,32,32,50,18,0,545,512,560,529,36,16,4,17,528,512]

theorem envBound57537 : H12AffineFastState.Bounded env57537 := by
  intro p hp
  have h : env57537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57536_57537 : H12AffineEnvironment.transform 6 50 env57536 = env57537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env57536 == env57537) = true)

theorem identity57537 : scanCanonicalize (H12AffineFastState.compose env57537 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound57537 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57538 : List Nat := [2,4,2,16,0,17,18,5,512,5,529,512,3,512,16,3,529,512,5,16,529,0,0,18,18,0,513,512,528,529,4,16,4,17,528,512]

theorem envBound57538 : H12AffineFastState.Bounded env57538 := by
  intro p hp
  have h : env57538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57537_57538 : H12AffineEnvironment.transform 4 0 env57537 = env57538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env57537 == env57538) = true)

def env57539 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,4194304,6336705,6295814,4247641,6348993,4273309,16384,77954,4315354,6395142,4292870,257,6406394,78035,4256464]

theorem envBound57539 : H12AffineFastState.Bounded env57539 := by
  intro p hp
  have h : env57539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57471_57539 : H12AffineEnvironment.transform 17 82113 env57471 = env57539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82113 env57471 == env57539) = true)

def env57540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41088,2101313,2142598,28889,2113601,103453,16384,77954,96346,2176390,74118,257,2187386,78035,21072]

theorem envBound57540 : H12AffineFastState.Bounded env57540 := by
  intro p hp
  have h : env57540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57539_57540 : H12AffineEnvironment.transform 21 41088 env57539 = env57540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env57539 == env57540) = true)

theorem identity57540 : scanCanonicalize (H12AffineFastState.compose env57540 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 107882) := by decide +kernel

theorem selectedBound57540 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57541 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,107882,41088,111915,70892,28889,124203,103453,16384,77954,96346,37100,74118,257,50448,78035,21072]

theorem envBound57541 : H12AffineFastState.Bounded env57541 := by
  intro p hp
  have h : env57541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57540_57541 : H12AffineEnvironment.transform 20 107882 env57540 = env57541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 107882 env57540 == env57541) = true)

theorem identity57541 : scanCanonicalize (H12AffineFastState.compose env57541 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13657) := by decide +kernel

theorem selectedBound57541 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57542 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13657,32768,65536,78034,79256,1024,32768,107882,41088,111915,70892,1408,102514,103453,13657,77954,68867,37100,74118,257,45129,78035,9993]

theorem envBound57542 : H12AffineFastState.Bounded env57542 := by
  intro p hp
  have h : env57542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57541_57542 : H12AffineEnvironment.transform 13 13657 env57541 = env57542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13657 env57541 == env57542) = true)

theorem identity57542 : scanCanonicalize (H12AffineFastState.compose env57542 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 12513) := by decide +kernel

theorem selectedBound57542 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env57543 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13657,12513,65536,78034,79256,1024,12513,71051,4193,67018,70892,1408,73875,75004,13657,77954,68867,8205,74118,257,168,78035,9993]

theorem envBound57543 : H12AffineFastState.Bounded env57543 := by
  intro p hp
  have h : env57543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57542_57543 : H12AffineEnvironment.transform 14 12513 env57542 = env57543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12513 env57542 == env57543) = true)

theorem identity57543 : scanCanonicalize (H12AffineFastState.compose env57543 (packedSelected [1,3,4,9,13,16,17,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 1418) := by decide +kernel

theorem selectedBound57543 : packedSelected [1,3,4,9,13,16,17,24,28] rootPS < 2^1333 := by decide +kernel

def env57544 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13657,12513,1418,13656,12306,1024,12513,4097,4193,64,4454,1408,9497,8566,13657,13576,2185,8205,9228,257,168,13657,9993]

theorem envBound57544 : H12AffineFastState.Bounded env57544 := by
  intro p hp
  have h : env57544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57543_57544 : H12AffineEnvironment.transform 15 1418 env57543 = env57544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1418 env57543 == env57544) = true)

theorem identity57544 : scanCanonicalize (H12AffineFastState.compose env57544 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 1288) := by decide +kernel

theorem selectedBound57544 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57545 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1288,4177,5609,1418,4176,5402,1024,5609,4097,4193,64,4454,1408,17,1150,4177,4096,2185,1285,260,257,168,4177,513]

theorem envBound57545 : H12AffineFastState.Bounded env57545 := by
  intro p hp
  have h : env57545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57544_57545 : H12AffineEnvironment.transform 12 1288 env57544 = env57545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env57544 == env57545) = true)

theorem identity57545 : scanCanonicalize (H12AffineFastState.compose env57545 (packedSelected [5,8] rootPS)) = affineNative (2^(11+1) ^^^ 3814) := by decide +kernel

theorem selectedBound57545 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57546 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3814,1288,3767,2831,1418,3766,3068,1024,2831,3815,3719,64,3968,1408,17,1150,3767,3814,2185,1285,260,257,168,3767,513]

theorem envBound57546 : H12AffineFastState.Bounded env57546 := by
  intro p hp
  have h : env57546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57545_57546 : H12AffineEnvironment.transform 11 3814 env57545 = env57546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3814 env57545 == env57546) = true)

theorem identity57546 : scanCanonicalize (H12AffineFastState.compose env57546 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 904) := by decide +kernel

theorem selectedBound57546 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57547 : List Nat := [2,4,8,16,32,64,128,256,512,904,2048,2414,640,2367,2831,514,2366,3068,904,2831,2415,2319,64,2056,520,17,1014,2367,2414,2185,653,260,257,168,2367,513]

theorem envBound57547 : H12AffineFastState.Bounded env57547 := by
  intro p hp
  have h : env57547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57546_57547 : H12AffineEnvironment.transform 9 904 env57546 = env57547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 904 env57546 == env57547) = true)

theorem identity57547 : scanCanonicalize (H12AffineFastState.compose env57547 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound57547 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env57548 : List Nat := [2,4,8,16,32,64,128,256,373,253,2048,2414,501,2367,2170,375,2366,2185,253,2170,2415,2319,64,2056,381,17,131,2367,2414,2185,504,260,257,168,2367,372]

theorem envBound57548 : H12AffineFastState.Bounded env57548 := by
  intro p hp
  have h : env57548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57547_57548 : H12AffineEnvironment.transform 8 373 env57547 = env57548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env57547 == env57548) = true)

theorem identity57548 : scanCanonicalize (H12AffineFastState.compose env57548 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound57548 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57549 : List Nat := [2,4,8,16,32,64,128,256,373,253,131,493,501,444,249,375,445,10,253,249,492,396,64,139,381,17,131,444,493,10,504,260,257,168,444,372]

theorem envBound57549 : H12AffineFastState.Bounded env57549 := by
  intro p hp
  have h : env57549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57548_57549 : H12AffineEnvironment.transform 10 131 env57548 = env57549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env57548 == env57549) = true)

theorem identity57549 : scanCanonicalize (H12AffineFastState.compose env57549 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 198) := by decide +kernel

theorem selectedBound57549 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env57550 : List Nat := [2,4,8,16,32,64,128,198,179,253,131,43,51,122,249,177,123,10,253,249,42,74,64,139,187,17,131,122,43,10,62,194,199,168,122,178]

theorem envBound57550 : H12AffineFastState.Bounded env57550 := by
  intro p hp
  have h : env57550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57549_57550 : H12AffineEnvironment.transform 7 198 env57549 = env57550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 198 env57549 == env57550) = true)

def env57551 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41089,2101312,2142599,28888,2113600,103452,16384,77954,96347,2176391,74119,257,2187387,78035,21073]

theorem envBound57551 : H12AffineFastState.Bounded env57551 := by
  intro p hp
  have h : env57551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57539_57551 : H12AffineEnvironment.transform 21 41089 env57539 = env57551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env57539 == env57551) = true)

theorem identity57551 : scanCanonicalize (H12AffineFastState.compose env57551 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 122922) := by decide +kernel

theorem selectedBound57551 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57552 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,122922,41089,127082,86445,28888,106602,103452,16384,77954,96347,54701,74119,257,32849,78035,21073]

theorem envBound57552 : H12AffineFastState.Bounded env57552 := by
  intro p hp
  have h : env57552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57551_57552 : H12AffineEnvironment.transform 20 122922 env57551 = env57552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 122922 env57551 == env57552) = true)

theorem identity57552 : scanCanonicalize (H12AffineFastState.compose env57552 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 9713) := by decide +kernel

theorem selectedBound57552 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57553 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9713,65536,78034,82113,1024,9713,83419,1392,87451,86445,28888,66971,78317,16384,77954,96347,28764,74119,257,9632,78035,21073]

theorem envBound57553 : H12AffineFastState.Bounded env57553 := by
  intro p hp
  have h : env57553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57552_57553 : H12AffineEnvironment.transform 14 9713 env57552 = env57553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9713 env57552 == env57553) = true)

theorem identity57553 : scanCanonicalize (H12AffineFastState.compose env57553 (packedSelected [25] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound57553 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57554 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,9713,65536,78034,69776,1024,9713,71050,1392,67018,66044,8329,66971,78317,4177,77954,75786,8205,74119,257,9632,78035,512]

theorem envBound57554 : H12AffineFastState.Bounded env57554 := by
  intro p hp
  have h : env57554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57553_57554 : H12AffineEnvironment.transform 13 4177 env57553 = env57554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env57553 == env57554) = true)

theorem identity57554 : scanCanonicalize (H12AffineFastState.compose env57554 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 9343) := by decide +kernel

theorem selectedBound57554 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57555 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,9713,9343,5293,13551,1024,9713,12789,1392,8629,9603,8329,8676,5522,4177,5373,3189,8205,1528,257,9632,5292,512]

theorem envBound57555 : H12AffineFastState.Bounded env57555 := by
  intro p hp
  have h : env57555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57554_57555 : H12AffineEnvironment.transform 15 9343 env57554 = env57555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9343 env57554 == env57555) = true)

theorem identity57555 : scanCanonicalize (H12AffineFastState.compose env57555 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 3839) := by decide +kernel

theorem selectedBound57555 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57556 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3839,4177,2830,2688,5293,6672,1024,2830,7946,1392,3914,2940,3702,3867,5522,4177,5373,3189,3826,1528,257,2911,5292,512]

theorem envBound57556 : H12AffineFastState.Bounded env57556 := by
  intro p hp
  have h : env57556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57555_57556 : H12AffineEnvironment.transform 12 3839 env57555 = env57556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3839 env57555 == env57556) = true)

theorem identity57556 : scanCanonicalize (H12AffineFastState.compose env57556 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(9+1) ^^^ 336) := by decide +kernel

theorem selectedBound57556 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env57557 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,4096,2991,4177,2830,2688,4605,6672,336,2830,6746,32,2586,2940,2854,2635,4290,4177,4525,2341,2978,168,257,2911,4604,512]

theorem envBound57557 : H12AffineFastState.Bounded env57557 := by
  intro p hp
  have h : env57557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57556_57557 : H12AffineEnvironment.transform 9 336 env57556 = env57557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env57556 == env57557) = true)

def env57558 : List Nat := [2,4,8,16,32,64,128,4,512,84,2048,4096,2731,4177,2570,2688,4345,6672,84,2570,6746,32,2586,2680,2594,2635,4290,4177,4265,2081,2726,168,5,2651,4344,512]

theorem envBound57558 : H12AffineFastState.Bounded env57558 := by
  intro p hp
  have h : env57558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57557_57558 : H12AffineEnvironment.transform 7 4 env57557 = env57558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env57557 == env57558) = true)

def env57559 : List Nat := [2,4,8,16,32,48,128,4,512,36,2048,4096,2731,4129,2570,2688,4233,6672,36,2570,6698,32,2586,2568,2594,2619,4274,4129,4265,2081,2726,168,5,2603,4232,512]

theorem envBound57559 : H12AffineFastState.Bounded env57559 := by
  intro p hp
  have h : env57559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57558_57559 : H12AffineEnvironment.transform 5 48 env57558 = env57559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env57558 == env57559) = true)

theorem identity57559 : scanCanonicalize (H12AffineFastState.compose env57559 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2216) := by decide +kernel

theorem selectedBound57559 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57560 : List Nat := [2,4,8,16,32,48,128,4,512,36,2048,2216,2731,2185,2570,2688,2081,696,36,2570,642,32,2586,2568,2594,2619,2074,2185,2049,2081,2726,168,5,2603,2080,512]

theorem envBound57560 : H12AffineFastState.Bounded env57560 := by
  intro p hp
  have h : env57560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57559_57560 : H12AffineEnvironment.transform 11 2216 env57559 = env57560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2216 env57559 == env57560) = true)

def env57561 : List Nat := [2,4,8,16,32,48,128,4,512,36,648,544,35,513,130,8,681,696,36,130,642,32,146,128,170,179,658,513,649,681,46,168,5,163,680,512]

theorem envBound57561 : H12AffineFastState.Bounded env57561 := by
  intro p hp
  have h : env57561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57560_57561 : H12AffineEnvironment.transform 10 648 env57560 = env57561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 648 env57560 == env57561) = true)

theorem identity57561 : scanCanonicalize (H12AffineFastState.compose env57561 (packedSelected [1,3,4,5,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound57561 : packedSelected [1,3,4,5,10,13] rootPS < 2^1333 := by decide +kernel

def env57562 : List Nat := [2,4,8,16,32,48,2,4,512,36,522,544,35,513,0,8,555,570,36,0,512,32,16,2,40,49,528,513,523,555,46,42,5,33,554,512]

theorem envBound57562 : H12AffineFastState.Bounded env57562 := by
  intro p hp
  have h : env57562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57561_57562 : H12AffineEnvironment.transform 6 2 env57561 = env57562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env57561 == env57562) = true)

theorem identity57562 : scanCanonicalize (H12AffineFastState.compose env57562 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound57562 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env57563 : List Nat := [2,4,8,16,17,1,2,4,512,21,522,529,18,513,0,8,538,523,21,0,512,17,16,2,25,0,528,513,523,538,31,27,5,16,539,512]

theorem envBound57563 : H12AffineFastState.Bounded env57563 := by
  intro p hp
  have h : env57563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57562_57563 : H12AffineEnvironment.transform 4 17 env57562 = env57563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env57562 == env57563) = true)

theorem identity57563 : scanCanonicalize (H12AffineFastState.compose env57563 (packedSelected [1,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57563 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env57564 : List Nat := [2,4,2,16,17,1,2,4,512,21,512,529,18,513,0,2,528,513,21,0,512,17,16,2,19,0,528,513,513,528,21,17,5,16,529,512]

theorem envBound57564 : H12AffineFastState.Bounded env57564 := by
  intro p hp
  have h : env57564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57563_57564 : H12AffineEnvironment.transform 2 2 env57563 = env57564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57563 == env57564) = true)

def env57565 : List Nat := [2,4,8,16,32,48,128,4,512,36,649,545,34,512,131,9,680,696,36,131,642,32,147,129,171,178,659,512,648,680,47,168,5,162,681,512]

theorem envBound57565 : H12AffineFastState.Bounded env57565 := by
  intro p hp
  have h : env57565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57560_57565 : H12AffineEnvironment.transform 10 649 env57560 = env57565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 649 env57560 == env57565) = true)

theorem identity57565 : scanCanonicalize (H12AffineFastState.compose env57565 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57565 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env57566 : List Nat := [2,4,3,16,32,48,128,4,512,36,642,545,34,512,131,2,675,691,36,131,642,32,147,129,160,178,659,512,643,675,36,163,5,162,674,512]

theorem envBound57566 : H12AffineFastState.Bounded env57566 := by
  intro p hp
  have h : env57566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57565_57566 : H12AffineEnvironment.transform 2 3 env57565 = env57566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57565 == env57566) = true)

theorem identity57566 : scanCanonicalize (H12AffineFastState.compose env57566 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound57566 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env57567 : List Nat := [2,4,3,16,32,48,51,4,512,36,561,545,34,512,48,2,528,512,36,48,561,32,32,50,19,1,544,512,560,528,36,16,5,17,529,512]

theorem envBound57567 : H12AffineFastState.Bounded env57567 := by
  intro p hp
  have h : env57567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57566_57567 : H12AffineEnvironment.transform 6 51 env57566 = env57567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env57566 == env57567) = true)

theorem identity57567 : scanCanonicalize (H12AffineFastState.compose env57567 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound57567 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57568 : List Nat := [2,4,3,16,1,17,18,4,512,5,528,512,3,512,17,2,528,512,5,17,528,1,1,19,19,1,513,512,529,528,5,16,5,17,529,512]

theorem envBound57568 : H12AffineFastState.Bounded env57568 := by
  intro p hp
  have h : env57568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57567_57568 : H12AffineEnvironment.transform 4 1 env57567 = env57568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env57567 == env57568) = true)

def env57569 : List Nat := [2,4,8,16,32,49,128,4,512,37,2048,4096,2731,4128,2570,2688,4232,6672,37,2570,6699,32,2586,2569,2594,2618,4275,4128,4265,2081,2726,168,5,2602,4233,512]

theorem envBound57569 : H12AffineFastState.Bounded env57569 := by
  intro p hp
  have h : env57569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57558_57569 : H12AffineEnvironment.transform 5 49 env57558 = env57569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env57558 == env57569) = true)

theorem identity57569 : scanCanonicalize (H12AffineFastState.compose env57569 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound57569 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57570 : List Nat := [2,4,8,16,32,49,128,4,512,37,2048,2048,2731,2080,2570,2688,2184,528,37,2570,555,32,2586,2569,2594,2618,2227,2080,2217,2081,2726,168,5,2602,2185,512]

theorem envBound57570 : H12AffineFastState.Bounded env57570 := by
  intro p hp
  have h : env57570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57569_57570 : H12AffineEnvironment.transform 11 2048 env57569 = env57570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env57569 == env57570) = true)

def env57571 : List Nat := [2,4,8,16,0,17,128,4,512,5,2048,2048,2699,2048,2570,2688,2184,528,5,2570,523,0,2586,2569,2562,2586,2195,2048,2185,2049,2694,136,5,2570,2185,512]

theorem envBound57571 : H12AffineFastState.Bounded env57571 := by
  intro p hp
  have h : env57571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57570_57571 : H12AffineEnvironment.transform 4 0 env57570 = env57571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env57570 == env57571) = true)

theorem identity57571 : scanCanonicalize (H12AffineFastState.compose env57571 (packedSelected [0,4,5,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 664) := by decide +kernel

theorem selectedBound57571 : packedSelected [0,4,5,9,11] rootPS < 2^1333 := by decide +kernel

def env57572 : List Nat := [2,4,8,16,0,17,128,4,512,5,664,664,19,664,146,24,528,528,5,146,523,0,130,145,154,130,523,664,529,665,30,136,5,146,529,512]

theorem envBound57572 : H12AffineFastState.Bounded env57572 := by
  intro p hp
  have h : env57572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57571_57572 : H12AffineEnvironment.transform 10 664 env57571 = env57572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 664 env57571 == env57572) = true)

theorem identity57572 : scanCanonicalize (H12AffineFastState.compose env57572 (packedSelected [4,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound57572 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env57573 : List Nat := [2,4,8,16,0,17,128,4,0,5,152,152,19,152,146,24,16,16,5,146,11,0,130,145,154,130,11,152,17,153,30,136,5,146,17,0]

theorem envBound57573 : H12AffineFastState.Bounded env57573 := by
  intro p hp
  have h : env57573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57572_57573 : H12AffineEnvironment.transform 8 0 env57572 = env57573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env57572 == env57573) = true)

theorem identity57573 : scanCanonicalize (H12AffineFastState.compose env57573 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound57573 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57574 : List Nat := [2,4,8,16,0,17,2,4,0,5,26,26,19,26,16,24,16,16,5,16,11,0,0,19,24,0,11,26,17,27,30,10,5,16,17,0]

theorem envBound57574 : H12AffineFastState.Bounded env57574 := by
  intro p hp
  have h : env57574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57573_57574 : H12AffineEnvironment.transform 6 2 env57573 = env57574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env57573 == env57574) = true)

theorem identity57574 : scanCanonicalize (H12AffineFastState.compose env57574 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound57574 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57575 : List Nat := [2,4,8,0,0,1,2,4,0,5,10,10,3,10,0,8,0,0,5,0,11,0,0,3,8,0,11,10,1,11,14,10,5,0,1,0]

theorem envBound57575 : H12AffineFastState.Bounded env57575 := by
  intro p hp
  have h : env57575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57574_57575 : H12AffineEnvironment.transform 3 0 env57574 = env57575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57574 == env57575) = true)

theorem identity57575 : scanCanonicalize (H12AffineFastState.compose env57575 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57575 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57576 : List Nat := [2,4,2,0,0,1,2,4,0,5,0,0,3,0,0,2,0,0,5,0,1,0,0,3,2,0,1,0,1,1,4,0,5,0,1,0]

theorem envBound57576 : H12AffineFastState.Bounded env57576 := by
  intro p hp
  have h : env57576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57575_57576 : H12AffineEnvironment.transform 2 2 env57575 = env57576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57575 == env57576) = true)

def env57577 : List Nat := [2,4,8,16,1,16,128,4,512,4,2048,2048,2698,2049,2570,2688,2184,528,4,2570,522,1,2586,2569,2563,2587,2194,2049,2184,2048,2695,137,5,2571,2185,512]

theorem envBound57577 : H12AffineFastState.Bounded env57577 := by
  intro p hp
  have h : env57577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57570_57577 : H12AffineEnvironment.transform 4 1 env57570 = env57577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env57570 == env57577) = true)

theorem identity57577 : scanCanonicalize (H12AffineFastState.compose env57577 (packedSelected [0,4,5,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 659) := by decide +kernel

theorem selectedBound57577 : packedSelected [0,4,5,9,11] rootPS < 2^1333 := by decide +kernel

def env57578 : List Nat := [2,4,8,16,1,16,128,4,512,4,659,659,25,658,153,19,539,528,4,153,522,1,137,154,144,136,513,658,539,659,20,137,5,152,538,512]

theorem envBound57578 : H12AffineFastState.Bounded env57578 := by
  intro p hp
  have h : env57578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57577_57578 : H12AffineEnvironment.transform 10 659 env57577 = env57578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 659 env57577 == env57578) = true)

theorem identity57578 : scanCanonicalize (H12AffineFastState.compose env57578 (packedSelected [3,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57578 : packedSelected [3,9] rootPS < 2^1333 := by decide +kernel

def env57579 : List Nat := [2,4,8,11,1,11,128,4,512,4,648,648,2,649,130,8,512,523,4,130,522,1,137,129,139,136,513,649,512,648,15,137,5,131,513,512]

theorem envBound57579 : H12AffineFastState.Bounded env57579 := by
  intro p hp
  have h : env57579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57578_57579 : H12AffineEnvironment.transform 3 11 env57578 = env57579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57578 == env57579) = true)

theorem identity57579 : scanCanonicalize (H12AffineFastState.compose env57579 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound57579 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env57580 : List Nat := [2,4,8,11,1,11,128,4,0,4,136,136,2,137,130,8,0,11,4,130,10,1,137,129,139,136,1,137,0,136,15,137,5,131,1,0]

theorem envBound57580 : H12AffineFastState.Bounded env57580 := by
  intro p hp
  have h : env57580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57579_57580 : H12AffineEnvironment.transform 8 0 env57579 = env57580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env57579 == env57580) = true)

def env57581 : List Nat := [2,4,8,16,32,64,128,5,512,85,2048,4096,2730,4177,2571,2688,4344,6672,85,2571,6746,32,2586,2681,2595,2635,4290,4177,4264,2080,2727,168,4,2650,4345,512]

theorem envBound57581 : H12AffineFastState.Bounded env57581 := by
  intro p hp
  have h : env57581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57557_57581 : H12AffineEnvironment.transform 7 5 env57557 = env57581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env57557 == env57581) = true)

def env57582 : List Nat := [2,4,8,16,32,48,128,5,512,37,2048,4096,2730,4129,2571,2688,4232,6672,37,2571,6698,32,2586,2569,2595,2619,4274,4129,4264,2080,2727,168,4,2602,4233,512]

theorem envBound57582 : H12AffineFastState.Bounded env57582 := by
  intro p hp
  have h : env57582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57581_57582 : H12AffineEnvironment.transform 5 48 env57581 = env57582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env57581 == env57582) = true)

theorem identity57582 : scanCanonicalize (H12AffineFastState.compose env57582 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 643) := by decide +kernel

theorem selectedBound57582 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57583 : List Nat := [2,4,8,16,32,48,128,5,512,37,2048,643,2730,674,2571,2688,523,2195,37,2571,2217,32,2586,2569,2595,2619,561,674,555,2080,2727,168,4,2602,522,512]

theorem envBound57583 : H12AffineFastState.Bounded env57583 := by
  intro p hp
  have h : env57583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57582_57583 : H12AffineEnvironment.transform 11 643 env57582 = env57583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 643 env57582 == env57583) = true)

def env57584 : List Nat := [2,4,8,0,32,32,128,5,512,37,2048,643,2730,674,2571,2688,523,2179,37,2571,2217,32,2570,2569,2595,2603,545,674,555,2080,2727,168,4,2602,522,512]

theorem envBound57584 : H12AffineFastState.Bounded env57584 := by
  intro p hp
  have h : env57584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57583_57584 : H12AffineEnvironment.transform 3 0 env57583 = env57584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57583 == env57584) = true)

theorem identity57584 : scanCanonicalize (H12AffineFastState.compose env57584 (packedSelected [0,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound57584 : packedSelected [0,3,4,7] rootPS < 2^1333 := by decide +kernel

def env57585 : List Nat := [2,4,8,0,32,32,8,5,512,37,2048,523,2594,554,2571,2568,523,2059,37,2571,2081,32,2570,2569,2595,2603,545,554,555,2080,2607,32,4,2602,522,512]

theorem envBound57585 : H12AffineFastState.Bounded env57585 := by
  intro p hp
  have h : env57585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57584_57585 : H12AffineEnvironment.transform 6 8 env57584 = env57585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env57584 == env57585) = true)

theorem identity57585 : scanCanonicalize (H12AffineFastState.compose env57585 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound57585 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env57586 : List Nat := [2,4,8,0,32,32,8,5,512,37,513,523,35,554,10,9,523,522,37,10,544,32,11,8,34,42,545,554,555,545,46,32,4,43,522,512]

theorem envBound57586 : H12AffineFastState.Bounded env57586 := by
  intro p hp
  have h : env57586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57585_57586 : H12AffineEnvironment.transform 10 513 env57585 = env57586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env57585 == env57586) = true)

theorem identity57586 : scanCanonicalize (H12AffineFastState.compose env57586 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57586 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57587 : List Nat := [2,4,3,0,32,32,3,5,512,37,513,512,35,545,1,2,512,513,37,1,544,32,0,3,34,33,545,545,544,545,37,32,4,32,513,512]

theorem envBound57587 : H12AffineFastState.Bounded env57587 := by
  intro p hp
  have h : env57587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57586_57587 : H12AffineEnvironment.transform 2 3 env57586 = env57587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57586 == env57587) = true)

theorem identity57587 : scanCanonicalize (H12AffineFastState.compose env57587 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound57587 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57588 : List Nat := [2,4,3,0,32,32,3,5,0,37,1,0,35,33,1,2,0,1,37,1,32,32,0,3,34,33,33,33,32,33,37,32,4,32,1,0]

theorem envBound57588 : H12AffineFastState.Bounded env57588 := by
  intro p hp
  have h : env57588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57587_57588 : H12AffineEnvironment.transform 8 0 env57587 = env57588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env57587 == env57588) = true)

def env57589 : List Nat := [2,4,8,1,32,33,128,5,512,37,2048,643,2730,674,2571,2688,523,2178,37,2571,2217,32,2571,2569,2595,2602,544,674,555,2080,2727,168,4,2602,522,512]

theorem envBound57589 : H12AffineFastState.Bounded env57589 := by
  intro p hp
  have h : env57589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57583_57589 : H12AffineEnvironment.transform 3 1 env57583 = env57589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57583 == env57589) = true)

theorem identity57589 : scanCanonicalize (H12AffineFastState.compose env57589 (packedSelected [0,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 642) := by decide +kernel

theorem selectedBound57589 : packedSelected [0,3,4,7] rootPS < 2^1333 := by decide +kernel

def env57590 : List Nat := [2,4,8,1,32,33,128,5,512,37,642,643,40,674,137,2,523,512,37,137,555,32,137,139,161,168,544,674,555,674,37,168,4,168,522,512]

theorem envBound57590 : H12AffineFastState.Bounded env57590 := by
  intro p hp
  have h : env57590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57589_57590 : H12AffineEnvironment.transform 10 642 env57589 = env57590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 642 env57589 == env57590) = true)

theorem identity57590 : scanCanonicalize (H12AffineFastState.compose env57590 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound57590 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env57591 : List Nat := [2,4,8,1,32,33,2,5,512,37,512,513,40,544,11,2,523,512,37,11,555,32,11,9,35,42,544,544,555,544,37,42,4,42,522,512]

theorem envBound57591 : H12AffineFastState.Bounded env57591 := by
  intro p hp
  have h : env57591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57590_57591 : H12AffineEnvironment.transform 6 2 env57590 = env57591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env57590 == env57591) = true)

theorem identity57591 : scanCanonicalize (H12AffineFastState.compose env57591 (packedSelected [3,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound57591 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env57592 : List Nat := [2,4,8,1,32,33,2,5,1,37,1,0,40,33,11,2,10,1,37,11,42,32,11,9,35,42,33,33,42,33,37,42,4,42,11,1]

theorem envBound57592 : H12AffineFastState.Bounded env57592 := by
  intro p hp
  have h : env57592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57591_57592 : H12AffineEnvironment.transform 8 1 env57591 = env57592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env57591 == env57592) = true)

theorem identity57592 : scanCanonicalize (H12AffineFastState.compose env57592 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound57592 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57593 : List Nat := [2,4,8,1,1,0,2,5,1,4,1,0,9,0,11,2,10,1,4,11,11,1,11,9,2,11,0,0,11,0,4,11,4,11,11,1]

theorem envBound57593 : H12AffineFastState.Bounded env57593 := by
  intro p hp
  have h : env57593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57592_57593 : H12AffineEnvironment.transform 4 1 env57592 = env57593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env57592 == env57593) = true)

def env57594 : List Nat := [2,4,8,16,32,49,128,5,512,36,2048,4096,2730,4128,2571,2688,4233,6672,36,2571,6699,32,2586,2568,2595,2618,4275,4128,4264,2080,2727,168,4,2603,4232,512]

theorem envBound57594 : H12AffineFastState.Bounded env57594 := by
  intro p hp
  have h : env57594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57581_57594 : H12AffineEnvironment.transform 5 49 env57581 = env57594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env57581 == env57594) = true)

theorem identity57594 : scanCanonicalize (H12AffineFastState.compose env57594 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 555) := by decide +kernel

theorem selectedBound57594 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57595 : List Nat := [2,4,8,16,32,49,128,5,512,36,2048,555,2730,523,2571,2688,674,2107,36,2571,2048,32,2586,2568,2595,2618,664,523,643,2080,2727,168,4,2603,675,512]

theorem envBound57595 : H12AffineFastState.Bounded env57595 := by
  intro p hp
  have h : env57595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57594_57595 : H12AffineEnvironment.transform 11 555 env57594 = env57595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 555 env57594 == env57595) = true)

def env57596 : List Nat := [2,4,8,16,16,1,128,5,512,20,2048,539,2714,523,2571,2688,658,2059,20,2571,2048,16,2586,2568,2579,2570,664,523,643,2064,2711,152,4,2587,659,512]

theorem envBound57596 : H12AffineFastState.Bounded env57596 := by
  intro p hp
  have h : env57596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57595_57596 : H12AffineEnvironment.transform 4 16 env57595 = env57596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57595 == env57596) = true)

theorem identity57596 : scanCanonicalize (H12AffineFastState.compose env57596 (packedSelected [1,4] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound57596 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env57597 : List Nat := [2,4,8,16,16,1,3,5,512,20,2048,539,2585,523,2571,2563,529,2059,20,2571,2048,16,2586,2568,2579,2570,539,523,512,2064,2580,27,4,2587,528,512]

theorem envBound57597 : H12AffineFastState.Bounded env57597 := by
  intro p hp
  have h : env57597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57596_57597 : H12AffineEnvironment.transform 6 3 env57596 = env57597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env57596 == env57597) = true)

theorem identity57597 : scanCanonicalize (H12AffineFastState.compose env57597 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound57597 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env57598 : List Nat := [2,4,8,16,16,1,3,5,512,20,17,539,520,523,538,530,529,26,20,538,17,16,523,537,514,539,539,523,512,1,517,27,4,522,528,512]

theorem envBound57598 : H12AffineFastState.Bounded env57598 := by
  intro p hp
  have h : env57598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57597_57598 : H12AffineEnvironment.transform 10 17 env57597 = env57598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env57597 == env57598) = true)

theorem identity57598 : scanCanonicalize (H12AffineFastState.compose env57598 (packedSelected [0,1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57598 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env57599 : List Nat := [2,4,8,10,10,1,3,5,512,14,11,513,520,523,512,520,523,0,14,512,11,10,523,515,514,513,513,523,512,1,517,1,4,522,522,512]

theorem envBound57599 : H12AffineFastState.Bounded env57599 := by
  intro p hp
  have h : env57599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57598_57599 : H12AffineEnvironment.transform 3 10 env57598 = env57599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57598 == env57599) = true)

theorem identity57599 : scanCanonicalize (H12AffineFastState.compose env57599 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound57599 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57600 : List Nat := [2,4,8,10,10,1,3,5,10,14,11,11,2,1,10,2,1,0,14,10,11,10,1,9,8,11,11,1,10,1,15,1,4,0,0,10]

theorem envBound57600 : H12AffineFastState.Bounded env57600 := by
  intro p hp
  have h : env57600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57599_57600 : H12AffineEnvironment.transform 8 10 env57599 = env57600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env57599 == env57600) = true)

def env57601 : List Nat := [2,4,8,16,17,0,128,5,512,21,2048,538,2715,523,2571,2688,659,2058,21,2571,2048,17,2586,2568,2578,2571,664,523,643,2065,2710,153,4,2586,658,512]

theorem envBound57601 : H12AffineFastState.Bounded env57601 := by
  intro p hp
  have h : env57601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57595_57601 : H12AffineEnvironment.transform 4 17 env57595 = env57601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env57595 == env57601) = true)

theorem identity57601 : scanCanonicalize (H12AffineFastState.compose env57601 (packedSelected [1,4] rootPS)) = affineNative (2^(10+1) ^^^ 649) := by decide +kernel

theorem selectedBound57601 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env57602 : List Nat := [2,4,8,16,17,0,128,5,512,21,649,538,18,523,130,9,659,643,21,130,649,17,147,129,155,130,664,523,643,664,31,153,4,147,658,512]

theorem envBound57602 : H12AffineFastState.Bounded env57602 := by
  intro p hp
  have h : env57602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57601_57602 : H12AffineEnvironment.transform 10 649 env57601 = env57602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 649 env57601 == env57602) = true)

theorem identity57602 : scanCanonicalize (H12AffineFastState.compose env57602 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound57602 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env57603 : List Nat := [2,4,8,16,17,0,3,5,512,21,522,538,18,523,1,9,528,512,21,1,522,17,16,2,24,1,539,523,512,539,31,26,4,16,529,512]

theorem envBound57603 : H12AffineFastState.Bounded env57603 := by
  intro p hp
  have h : env57603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57602_57603 : H12AffineEnvironment.transform 6 3 env57602 = env57603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env57602 == env57603) = true)

theorem identity57603 : scanCanonicalize (H12AffineFastState.compose env57603 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57603 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57604 : List Nat := [2,4,2,16,17,0,3,5,512,21,512,528,18,513,1,3,528,512,21,1,512,17,16,2,18,1,529,513,512,529,21,16,4,16,529,512]

theorem envBound57604 : H12AffineFastState.Bounded env57604 := by
  intro p hp
  have h : env57604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57603_57604 : H12AffineEnvironment.transform 2 2 env57603 = env57604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57603 == env57604) = true)

theorem identity57604 : scanCanonicalize (H12AffineFastState.compose env57604 (packedSelected [0,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound57604 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57605 : List Nat := [2,4,2,16,17,0,3,5,0,21,0,16,18,1,1,3,16,0,21,1,0,17,16,2,18,1,17,1,0,17,21,16,4,16,17,0]

theorem envBound57605 : H12AffineFastState.Bounded env57605 := by
  intro p hp
  have h : env57605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57604_57605 : H12AffineEnvironment.transform 8 0 env57604 = env57605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env57604 == env57605) = true)

def env57606 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8409088,134217728,16384,131153,4315355,8463815,4294967296,256,4307611965,34359738368,33563273]

theorem envBound57606 : H12AffineFastState.Bounded env57606 := by
  intro p hp
  have h : env57606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56660_57606 : H12AffineEnvironment.transform 18 1025 env56660 = env57606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env56660 == env57606) = true)

def env57607 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8409088,134217728,16384,131153,4315355,8463815,4294967296,256,4307611965,131072,33563273]

theorem envBound57607 : H12AffineFastState.Bounded env57607 := by
  intro p hp
  have h : env57607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57606_57607 : H12AffineEnvironment.transform 34 131072 env57606 = env57607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env57606 == env57607) = true)

theorem identity57607 : scanCanonicalize (H12AffineFastState.compose env57607 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 91335) := by decide +kernel

theorem selectedBound57607 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env57608 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8409088,134217728,16384,131153,4315355,8463815,91335,256,12686842,131072,33563273]

theorem envBound57608 : H12AffineFastState.Bounded env57608 := by
  intro p hp
  have h : env57608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57607_57608 : H12AffineEnvironment.transform 31 91335 env57607 = env57608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 91335 env57607 == env57608) = true)

theorem identity57608 : scanCanonicalize (H12AffineFastState.compose env57608 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(26+1) ^^^ 12919239) := by decide +kernel

theorem selectedBound57608 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env57609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8409088,12919239,16384,131153,4315355,8463815,91335,256,12686842,131072,33563273]

theorem envBound57609 : H12AffineFastState.Bounded env57609 := by
  intro p hp
  have h : env57609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57608_57609 : H12AffineEnvironment.transform 26 12919239 env57608 = env57609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 12919239 env57608 == env57609) = true)

theorem identity57609 : scanCanonicalize (H12AffineFastState.compose env57609 (packedSelected [6,13,17,21,25,33] rootPS)) = affineNative (2^(24+1) ^^^ 28889) := by decide +kernel

theorem selectedBound57609 : packedSelected [6,13,17,21,25,33] rootPS < 2^1333 := by decide +kernel

def env57610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,28889,8409088,12919239,16384,131153,4315355,8463815,91335,256,12686842,131072,21072]

theorem envBound57610 : H12AffineFastState.Bounded env57610 := by
  intro p hp
  have h : env57610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57609_57610 : H12AffineEnvironment.transform 24 28889 env57609 = env57610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 28889 env57609 == env57610) = true)

def env57611 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,8329,8388688,12919239,4176,131153,4294795,8463815,78999,256,12686842,131072,512]

theorem envBound57611 : H12AffineFastState.Bounded env57611 := by
  intro p hp
  have h : env57611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57610_57611 : H12AffineEnvironment.transform 13 4176 env57610 = env57611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env57610 == env57611) = true)

theorem identity57611 : scanCanonicalize (H12AffineFastState.compose env57611 (packedSelected [4,9,16] rootPS)) = affineNative (2^(16+1) ^^^ 78034) := by decide +kernel

theorem selectedBound57611 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57612 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78034,262144,1025,32768,2097152,4194304,8388608,8430022,8329,8388688,12919239,4176,77955,4294795,8463815,78999,256,12686842,78034,512]

theorem envBound57612 : H12AffineFastState.Bounded env57612 := by
  intro p hp
  have h : env57612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57611_57612 : H12AffineEnvironment.transform 16 78034 env57611 = env57612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78034 env57611 == env57612) = true)

theorem identity57612 : scanCanonicalize (H12AffineFastState.compose env57612 (packedSelected [13,21] rootPS)) = affineNative (2^(22+1) ^^^ 4240768) := by decide +kernel

theorem selectedBound57612 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57613 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78034,262144,1025,32768,2097152,4194304,4240768,4199494,8329,4240848,365639,4176,77955,4294795,4296775,78999,256,73850,78034,512]

theorem envBound57613 : H12AffineFastState.Bounded env57613 := by
  intro p hp
  have h : env57613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57612_57613 : H12AffineEnvironment.transform 22 4240768 env57612 = env57613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4240768 env57612 == env57613) = true)

theorem identity57613 : scanCanonicalize (H12AffineFastState.compose env57613 (packedSelected [1,3,13,17,24,28] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound57613 : packedSelected [1,3,13,17,24,28] rootPS < 2^1333 := by decide +kernel

def env57614 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78034,262144,1025,32768,2097152,33,46497,5223,8329,46577,365639,4176,77955,100522,102502,78999,256,73850,78034,512]

theorem envBound57614 : H12AffineFastState.Bounded env57614 := by
  intro p hp
  have h : env57614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57613_57614 : H12AffineEnvironment.transform 21 33 env57613 = env57614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env57613 == env57614) = true)

def env57615 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1260,8192,1212,32768,65536,74814,262144,1025,32768,2097152,33,41293,139,8329,41245,360619,1212,74863,100522,99466,73851,256,73850,74814,512]

theorem envBound57615 : H12AffineFastState.Bounded env57615 := by
  intro p hp
  have h : env57615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57614_57615 : H12AffineEnvironment.transform 11 1260 env57614 = env57615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1260 env57614 == env57615) = true)

theorem identity57615 : scanCanonicalize (H12AffineFastState.compose env57615 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(20+1) ^^^ 265916) := by decide +kernel

theorem selectedBound57615 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env57616 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1260,8192,1212,32768,65536,74814,262144,1025,32768,265916,33,41293,139,8329,41245,360619,1212,74863,100522,99466,73851,256,73850,74814,512]

theorem envBound57616 : H12AffineFastState.Bounded env57616 := by
  intro p hp
  have h : env57616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57615_57616 : H12AffineEnvironment.transform 20 265916 env57615 = env57616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 265916 env57615 == env57616) = true)

theorem identity57616 : scanCanonicalize (H12AffineFastState.compose env57616 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound57616 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env57617 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1260,8192,1212,32768,65536,74814,43049,1025,32768,42645,33,41293,139,8329,41245,75906,1212,74863,100522,99466,73851,256,73850,74814,512]

theorem envBound57617 : H12AffineFastState.Bounded env57617 := by
  intro p hp
  have h : env57617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57616_57617 : H12AffineEnvironment.transform 17 43049 env57616 = env57617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env57616 == env57617) = true)

theorem identity57617 : scanCanonicalize (H12AffineFastState.compose env57617 (packedSelected [0,2,4,6,11] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound57617 : packedSelected [0,2,4,6,11] rootPS < 2^1333 := by decide +kernel

def env57618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1260,8192,1212,32768,33166,42416,43049,1025,32768,42645,33,41293,139,8329,41245,43276,1212,42465,2340,1284,41461,256,41460,42416,512]

theorem envBound57618 : H12AffineFastState.Bounded env57618 := by
  intro p hp
  have h : env57618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57617_57618 : H12AffineEnvironment.transform 15 33166 env57617 = env57618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env57617 == env57618) = true)

def env57619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1260,8192,1212,8312,8694,1480,2129,1025,8312,1773,33,309,139,8329,357,2420,1212,1433,2340,1284,397,256,396,1480,512]

theorem envBound57619 : H12AffineFastState.Bounded env57619 := by
  intro p hp
  have h : env57619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57618_57619 : H12AffineEnvironment.transform 14 8312 env57618 = env57619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8312 env57618 == env57619) = true)

theorem identity57619 : scanCanonicalize (H12AffineFastState.compose env57619 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2516) := by decide +kernel

theorem selectedBound57619 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1260,2516,1212,2476,2082,1480,2129,1025,2476,1773,33,309,139,2397,357,2420,1212,1433,2340,1284,397,256,396,1480,512]

theorem envBound57620 : H12AffineFastState.Bounded env57620 := by
  intro p hp
  have h : env57620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57619_57620 : H12AffineEnvironment.transform 12 2516 env57619 = env57620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2516 env57619 == env57620) = true)

def env57621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1260,8192,1212,8313,8695,1481,2128,1025,8313,1772,33,308,139,8329,356,2421,1212,1432,2340,1284,396,256,397,1481,512]

theorem envBound57621 : H12AffineFastState.Bounded env57621 := by
  intro p hp
  have h : env57621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57618_57621 : H12AffineEnvironment.transform 14 8313 env57618 = env57621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8313 env57618 == env57621) = true)

theorem identity57621 : scanCanonicalize (H12AffineFastState.compose env57621 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2209) := by decide +kernel

theorem selectedBound57621 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1260,2209,1212,2264,2390,1481,2128,1025,2264,1772,33,308,139,2088,356,2421,1212,1432,2340,1284,396,256,397,1481,512]

theorem envBound57622 : H12AffineFastState.Bounded env57622 := by
  intro p hp
  have h : env57622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57621_57622 : H12AffineEnvironment.transform 12 2209 env57621 = env57622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2209 env57621 == env57622) = true)

def env57623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,8192,1213,32768,65536,74815,262144,1025,32768,2097152,33,41292,138,8329,41244,360618,1213,74862,100522,99467,73850,256,73850,74815,512]

theorem envBound57623 : H12AffineFastState.Bounded env57623 := by
  intro p hp
  have h : env57623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57614_57623 : H12AffineEnvironment.transform 11 1261 env57614 = env57623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1261 env57614 == env57623) = true)

theorem identity57623 : scanCanonicalize (H12AffineFastState.compose env57623 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(20+1) ^^^ 75547) := by decide +kernel

theorem selectedBound57623 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env57624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,8192,1213,32768,65536,74815,262144,1025,32768,75547,33,41292,138,8329,41244,360618,1213,74862,100522,99467,73850,256,73850,74815,512]

theorem envBound57624 : H12AffineFastState.Bounded env57624 := by
  intro p hp
  have h : env57624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57623_57624 : H12AffineEnvironment.transform 20 75547 env57623 = env57624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 75547 env57623 == env57624) = true)

theorem identity57624 : scanCanonicalize (H12AffineFastState.compose env57624 (packedSelected [3,8,10] rootPS)) = affineNative (2^(17+1) ^^^ 100523) := by decide +kernel

theorem selectedBound57624 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env57625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,8192,1213,32768,65536,74815,100523,1025,32768,75547,33,41292,138,8329,41244,2049,1213,74862,100522,99467,73850,256,73850,74815,512]

theorem envBound57625 : H12AffineFastState.Bounded env57625 := by
  intro p hp
  have h : env57625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57624_57625 : H12AffineEnvironment.transform 17 100523 env57624 = env57625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100523 env57624 == env57625) = true)

theorem identity57625 : scanCanonicalize (H12AffineFastState.compose env57625 (packedSelected [0,1,3,7,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound57625 : packedSelected [0,1,3,7,12,15] rootPS < 2^1333 := by decide +kernel

def env57626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,8192,1213,0,65536,74815,67755,1025,0,75547,33,8524,138,8329,8476,2049,1213,74862,67754,66699,73850,256,73850,74815,512]

theorem envBound57626 : H12AffineFastState.Bounded env57626 := by
  intro p hp
  have h : env57626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57625_57626 : H12AffineEnvironment.transform 14 0 env57625 = env57626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env57625 == env57626) = true)

def env57627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,8328,8388689,12919239,4177,131153,4294794,8463815,78998,256,12686842,131072,513]

theorem envBound57627 : H12AffineFastState.Bounded env57627 := by
  intro p hp
  have h : env57627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57610_57627 : H12AffineEnvironment.transform 13 4177 env57610 = env57627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env57610 == env57627) = true)

theorem identity57627 : scanCanonicalize (H12AffineFastState.compose env57627 (packedSelected [4,9,16] rootPS)) = affineNative (2^(21+1) ^^^ 396) := by decide +kernel

theorem selectedBound57627 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57628 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,2097152,396,8388608,8430022,8328,8388689,8724555,4177,131153,100614,8463815,78998,256,8492150,131072,513]

theorem envBound57628 : H12AffineFastState.Bounded env57628 := by
  intro p hp
  have h : env57628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57627_57628 : H12AffineEnvironment.transform 21 396 env57627 = env57628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 396 env57627 == env57628) = true)

theorem identity57628 : scanCanonicalize (H12AffineFastState.compose env57628 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound57628 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,4097,396,8388608,8430022,8328,8388689,8724555,4177,131153,100614,8463815,78998,256,8492150,131072,513]

theorem envBound57629 : H12AffineFastState.Bounded env57629 := by
  intro p hp
  have h : env57629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57628_57629 : H12AffineEnvironment.transform 20 4097 env57628 = env57629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env57628 == env57629) = true)

theorem identity57629 : scanCanonicalize (H12AffineFastState.compose env57629 (packedSelected [13,21] rootPS)) = affineNative (2^(22+1) ^^^ 176413) := by decide +kernel

theorem selectedBound57629 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,4097,396,176413,135387,8328,176460,495958,4177,131153,100614,234714,78998,256,206187,131072,513]

theorem envBound57630 : H12AffineFastState.Bounded env57630 := by
  intro p hp
  have h : env57630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57629_57630 : H12AffineEnvironment.transform 22 176413 env57629 = env57630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 176413 env57629 == env57630) = true)

theorem identity57630 : scanCanonicalize (H12AffineFastState.compose env57630 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound57630 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env57631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8460,65536,131072,262144,1025,8460,4097,396,135185,135387,8328,135232,471130,4177,131153,75786,210390,78998,256,206187,131072,513]

theorem envBound57631 : H12AffineFastState.Bounded env57631 := by
  intro p hp
  have h : env57631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57630_57631 : H12AffineEnvironment.transform 14 8460 env57630 = env57631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env57630 == env57631) = true)

theorem identity57631 : scanCanonicalize (H12AffineFastState.compose env57631 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 1212) := by decide +kernel

theorem selectedBound57631 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env57632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8460,65536,1212,262144,1025,8460,4097,396,5293,5223,8328,5372,341222,4177,1261,75786,78186,78998,256,74199,1212,513]

theorem envBound57632 : H12AffineFastState.Bounded env57632 := by
  intro p hp
  have h : env57632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57631_57632 : H12AffineEnvironment.transform 16 1212 env57631 = env57632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1212 env57631 == env57632) = true)

theorem identity57632 : scanCanonicalize (H12AffineFastState.compose env57632 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 81127) := by decide +kernel

theorem selectedBound57632 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env57633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8460,65536,1212,81127,1025,8460,4097,396,5293,5223,8328,5372,2049,4177,1261,75786,78186,78998,256,74199,1212,513]

theorem envBound57633 : H12AffineFastState.Bounded env57633 := by
  intro p hp
  have h : env57633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57632_57633 : H12AffineEnvironment.transform 17 81127 env57632 = env57633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 81127 env57632 == env57633) = true)

theorem identity57633 : scanCanonicalize (H12AffineFastState.compose env57633 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound57633 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env57634 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,4177,8353,65536,1212,81127,1025,8353,4097,33,5293,5223,8328,5372,2049,4177,1261,75786,78023,78998,173,73850,1212,513]

theorem envBound57634 : H12AffineFastState.Bounded env57634 := by
  intro p hp
  have h : env57634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57633_57634 : H12AffineEnvironment.transform 7 173 env57633 = env57634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env57633 == env57634) = true)

theorem identity57634 : scanCanonicalize (H12AffineFastState.compose env57634 (packedSelected [0,2,5,7,8,11,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 1782) := by decide +kernel

theorem selectedBound57634 : packedSelected [0,2,5,7,8,11,12,13] rootPS < 2^1333 := by decide +kernel

def env57635 : List Nat := [2,4,8,16,32,64,128,173,512,1024,1782,4096,8192,4177,8353,65536,1212,78353,1025,8353,4097,33,5293,5223,8328,5372,1783,4177,1261,75516,78023,78998,173,73850,1212,513]

theorem envBound57635 : H12AffineFastState.Bounded env57635 := by
  intro p hp
  have h : env57635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57634_57635 : H12AffineEnvironment.transform 10 1782 env57634 = env57635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1782 env57634 == env57635) = true)

theorem identity57635 : scanCanonicalize (H12AffineFastState.compose env57635 (packedSelected [0,2,5,6,7,8,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 1790) := by decide +kernel

theorem selectedBound57635 : packedSelected [0,2,5,6,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env57636 : List Nat := [2,4,8,16,32,64,128,173,512,1024,1782,4096,8192,4177,8353,1790,1212,13551,1025,8353,4097,33,5293,5223,8328,5372,1783,4177,1261,8194,13881,12904,173,9860,1212,513]

theorem envBound57636 : H12AffineFastState.Bounded env57636 := by
  intro p hp
  have h : env57636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57635_57636 : H12AffineEnvironment.transform 15 1790 env57635 = env57636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1790 env57635 == env57636) = true)

theorem identity57636 : scanCanonicalize (H12AffineFastState.compose env57636 (packedSelected [0,2,3,6,7,8,10,11,12,17] rootPS)) = affineNative (2^(11+1) ^^^ 1212) := by decide +kernel

theorem selectedBound57636 : packedSelected [0,2,3,6,7,8,10,11,12,17] rootPS < 2^1333 := by decide +kernel

def env57637 : List Nat := [2,4,8,16,32,64,128,173,512,1024,1782,1212,8192,1261,8353,1790,1212,8275,1025,8353,1213,33,17,219,8328,64,1783,1261,1261,8194,8837,9940,173,9860,1212,513]

theorem envBound57637 : H12AffineFastState.Bounded env57637 := by
  intro p hp
  have h : env57637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57636_57637 : H12AffineEnvironment.transform 11 1212 env57636 = env57637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1212 env57636 == env57637) = true)

theorem identity57637 : scanCanonicalize (H12AffineFastState.compose env57637 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound57637 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57638 : List Nat := [2,4,8,16,32,64,128,173,512,1024,1782,1212,8,1261,169,1790,1212,91,1025,169,1213,33,17,219,128,64,1783,1261,1261,10,653,1756,173,1676,1212,513]

theorem envBound57638 : H12AffineFastState.Bounded env57638 := by
  intro p hp
  have h : env57638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57637_57638 : H12AffineEnvironment.transform 12 8 env57637 = env57638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env57637 == env57638) = true)

theorem identity57638 : scanCanonicalize (H12AffineFastState.compose env57638 (packedSelected [0,1,2,3,4,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound57638 : packedSelected [0,1,2,3,4,5,10] rootPS < 2^1333 := by decide +kernel

def env57639 : List Nat := [2,4,8,16,32,64,18,63,512,1024,1636,1070,8,1151,59,1644,1070,91,1025,59,1071,33,17,73,18,64,1637,1151,1151,10,543,1614,63,1566,1070,513]

theorem envBound57639 : H12AffineFastState.Bounded env57639 := by
  intro p hp
  have h : env57639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57638_57639 : H12AffineEnvironment.transform 6 18 env57638 = env57639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env57638 == env57639) = true)

theorem identity57639 : scanCanonicalize (H12AffineFastState.compose env57639 (packedSelected [3,4,5,7,8,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound57639 : packedSelected [3,4,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env57640 : List Nat := [2,4,8,16,32,17,18,63,512,1024,1589,1070,8,1070,59,1597,1070,10,1025,59,1071,33,17,24,18,17,1588,1070,1070,10,543,1567,63,1566,1070,513]

theorem envBound57640 : H12AffineFastState.Bounded env57640 := by
  intro p hp
  have h : env57640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57639_57640 : H12AffineEnvironment.transform 5 17 env57639 = env57640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env57639 == env57640) = true)

theorem identity57640 : scanCanonicalize (H12AffineFastState.compose env57640 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound57640 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env57641 : List Nat := [2,4,8,16,32,17,18,63,512,37,528,11,8,11,59,536,11,10,36,59,10,33,17,24,18,17,529,11,11,10,543,570,63,571,11,513]

theorem envBound57641 : H12AffineFastState.Bounded env57641 := by
  intro p hp
  have h : env57641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57640_57641 : H12AffineEnvironment.transform 9 37 env57640 = env57641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env57640 == env57641) = true)

def env57642 : List Nat := [2,4,8,16,32,17,18,63,0,37,16,11,8,11,59,24,11,10,36,59,10,33,17,24,18,17,17,11,11,10,31,58,63,59,11,1]

theorem envBound57642 : H12AffineFastState.Bounded env57642 := by
  intro p hp
  have h : env57642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57641_57642 : H12AffineEnvironment.transform 8 0 env57641 = env57642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env57641 == env57642) = true)

def env57643 : List Nat := [2,4,8,16,32,17,18,63,1,37,17,11,8,11,59,25,11,10,36,59,10,33,17,24,18,17,16,11,11,10,30,59,63,58,11,0]

theorem envBound57643 : H12AffineFastState.Bounded env57643 := by
  intro p hp
  have h : env57643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57641_57643 : H12AffineEnvironment.transform 8 1 env57641 = env57643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env57641 == env57643) = true)

theorem identity57643 : scanCanonicalize (H12AffineFastState.compose env57643 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound57643 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57644 : List Nat := [2,4,8,16,11,17,18,20,1,14,17,11,8,11,16,25,11,10,15,16,10,10,17,24,18,17,16,11,11,10,30,16,20,17,11,0]

theorem envBound57644 : H12AffineFastState.Bounded env57644 := by
  intro p hp
  have h : env57644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57643_57644 : H12AffineEnvironment.transform 4 11 env57643 = env57644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env57643 == env57644) = true)

theorem identity57644 : scanCanonicalize (H12AffineFastState.compose env57644 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound57644 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57645 : List Nat := [2,4,8,8,11,9,10,12,1,14,9,11,8,11,8,1,11,10,15,8,10,10,9,0,10,9,8,11,11,10,6,8,12,9,11,0]

theorem envBound57645 : H12AffineFastState.Bounded env57645 := by
  intro p hp
  have h : env57645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57644_57645 : H12AffineEnvironment.transform 3 8 env57644 = env57645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env57644 == env57645) = true)

def leafEnv57645 : List Nat := [2,4,8,8,11,9,10,12,1,14,9,11,8,11,8,1,11,10,15,8,10,10,9,0,6,10,1,9,8,11,11,10,6,8,12,9,5,3,11,0,1,11,0]

def active57645 : List Nat := [0,1,2]

def tree57645 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood57645 : H12WitnessSearch.Good tree57645 := H12GlobalWitnessIndex.good

theorem leafIdentity57645 : H12AffineFastState.composeSystem env57645 rootObs = leafEnv57645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env57645 rootObs == leafEnv57645) = true)

theorem terminalChecked57645 : H12PackedTerminal.terminalCheckFast leafEnv57645 active57645 tree57645 = true := by decide +kernel

def env57646 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8409088,134217728,16384,131153,4315355,8463815,4294967296,256,4307611965,131073,33563273]

theorem envBound57646 : H12AffineFastState.Bounded env57646 := by
  intro p hp
  have h : env57646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57606_57646 : H12AffineEnvironment.transform 34 131073 env57606 = env57646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env57606 == env57646) = true)

theorem identity57646 : scanCanonicalize (H12AffineFastState.compose env57646 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 2192583) := by decide +kernel

theorem selectedBound57646 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env57647 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8409088,134217728,16384,131153,4315355,8463815,2192583,256,14779898,131073,33563273]

theorem envBound57647 : H12AffineFastState.Bounded env57647 := by
  intro p hp
  have h : env57647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57646_57647 : H12AffineEnvironment.transform 31 2192583 env57646 = env57647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 2192583 env57646 == env57647) = true)

theorem identity57647 : scanCanonicalize (H12AffineFastState.compose env57647 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound57647 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env57648 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8388689,134217728,4177,131153,4294794,8463815,2172054,256,14779898,131073,33563273]

theorem envBound57648 : H12AffineFastState.Bounded env57648 := by
  intro p hp
  have h : env57648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57647_57648 : H12AffineEnvironment.transform 13 4177 env57647 = env57648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env57647 == env57648) = true)

theorem identity57648 : scanCanonicalize (H12AffineFastState.compose env57648 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound57648 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env57649 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,8328,8388689,134217728,4177,131153,4294794,8463815,2172054,256,14779898,131073,513]

theorem envBound57649 : H12AffineFastState.Bounded env57649 := by
  intro p hp
  have h : env57649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57648_57649 : H12AffineEnvironment.transform 24 8328 env57648 = env57649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env57648 == env57649) = true)

theorem identity57649 : scanCanonicalize (H12AffineFastState.compose env57649 (packedSelected [4,9,16] rootPS)) = affineNative (2^(26+1) ^^^ 8724555) := by decide +kernel

theorem selectedBound57649 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57650 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,8328,8388689,8724555,4177,131153,4294794,8463815,2172054,256,14779898,131073,513]

theorem envBound57650 : H12AffineFastState.Bounded env57650 := by
  intro p hp
  have h : env57650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57649_57650 : H12AffineEnvironment.transform 26 8724555 env57649 = env57650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 8724555 env57649 == env57650) = true)

theorem identity57650 : scanCanonicalize (H12AffineFastState.compose env57650 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound57650 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57651 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,4097,4194304,8388608,8430022,8328,8388689,8724555,4177,131153,4294794,8463815,78999,256,12686843,131073,513]

theorem envBound57651 : H12AffineFastState.Bounded env57651 := by
  intro p hp
  have h : env57651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57650_57651 : H12AffineEnvironment.transform 20 4097 env57650 = env57651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env57650 == env57651) = true)

theorem identity57651 : scanCanonicalize (H12AffineFastState.compose env57651 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 4370577) := by decide +kernel

theorem selectedBound57651 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env57652 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,4097,4194304,4370577,4329815,8328,4370624,4690138,4177,131153,4294794,4429142,78999,256,206186,131073,513]

theorem envBound57652 : H12AffineFastState.Bounded env57652 := by
  intro p hp
  have h : env57652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57651_57652 : H12AffineEnvironment.transform 22 4370577 env57651 = env57652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4370577 env57651 == env57652) = true)

theorem identity57652 : scanCanonicalize (H12AffineFastState.compose env57652 (packedSelected [6,25] rootPS)) = affineNative (2^(21+1) ^^^ 396) := by decide +kernel

theorem selectedBound57652 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env57653 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,4097,396,176413,135387,8328,176460,495958,4177,131153,100614,234714,78999,256,206186,131073,513]

theorem envBound57653 : H12AffineFastState.Bounded env57653 := by
  intro p hp
  have h : env57653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57652_57653 : H12AffineEnvironment.transform 21 396 env57652 = env57653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 396 env57652 == env57653) = true)

theorem identity57653 : scanCanonicalize (H12AffineFastState.compose env57653 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound57653 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env57654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8461,65536,131072,262144,1025,8461,4097,396,135184,135387,8328,135233,471131,4177,131153,75787,210391,78999,256,206186,131073,513]

theorem envBound57654 : H12AffineFastState.Bounded env57654 := by
  intro p hp
  have h : env57654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57653_57654 : H12AffineEnvironment.transform 14 8461 env57653 = env57654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env57653 == env57654) = true)

theorem identity57654 : scanCanonicalize (H12AffineFastState.compose env57654 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 1212) := by decide +kernel

theorem selectedBound57654 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env57655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8461,65536,1212,262144,1025,8461,4097,396,5292,5223,8328,5373,341223,4177,1261,75787,78187,78999,256,74198,1213,513]

theorem envBound57655 : H12AffineFastState.Bounded env57655 := by
  intro p hp
  have h : env57655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57654_57655 : H12AffineEnvironment.transform 16 1212 env57654 = env57655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1212 env57654 == env57655) = true)

theorem identity57655 : scanCanonicalize (H12AffineFastState.compose env57655 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 75786) := by decide +kernel

theorem selectedBound57655 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env57656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8461,65536,1212,75786,1025,8461,4097,396,5292,5223,8328,5373,7405,4177,1261,75787,78187,78999,256,74198,1213,513]

theorem envBound57656 : H12AffineFastState.Bounded env57656 := by
  intro p hp
  have h : env57656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57655_57656 : H12AffineEnvironment.transform 17 75786 env57655 = env57656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 75786 env57655 == env57656) = true)

theorem identity57656 : scanCanonicalize (H12AffineFastState.compose env57656 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound57656 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env57657 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,4177,8352,65536,1212,75786,1025,8352,4097,33,5292,5223,8328,5373,7405,4177,1261,75787,78022,78999,173,73851,1213,513]

theorem envBound57657 : H12AffineFastState.Bounded env57657 := by
  intro p hp
  have h : env57657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57656_57657 : H12AffineEnvironment.transform 7 173 env57656 = env57657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env57656 == env57657) = true)

theorem identity57657 : scanCanonicalize (H12AffineFastState.compose env57657 (packedSelected [0,5,6,7,8,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 1711) := by decide +kernel

theorem selectedBound57657 : packedSelected [0,5,6,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env57658 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,4177,8352,1711,1212,11941,1025,8352,4097,33,5292,5223,8328,5373,7405,4177,1261,11940,13929,12856,173,9940,1213,513]

theorem envBound57658 : H12AffineFastState.Bounded env57658 := by
  intro p hp
  have h : env57658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57657_57658 : H12AffineEnvironment.transform 15 1711 env57657 = env57658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1711 env57657 == env57658) = true)

theorem identity57658 : scanCanonicalize (H12AffineFastState.compose env57658 (packedSelected [0,3,6,7,8,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1702) := by decide +kernel

theorem selectedBound57658 : packedSelected [0,3,6,7,8,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env57659 : List Nat := [2,4,8,16,32,64,128,173,512,1024,1702,4096,8192,4177,8352,1711,1212,8195,1025,8352,4097,33,5292,5223,8328,5373,4683,4177,1261,8194,13929,12856,173,9940,1213,513]

theorem envBound57659 : H12AffineFastState.Bounded env57659 := by
  intro p hp
  have h : env57659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57658_57659 : H12AffineEnvironment.transform 10 1702 env57658 = env57659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1702 env57658 == env57659) = true)

theorem identity57659 : scanCanonicalize (H12AffineFastState.compose env57659 (packedSelected [3,5,6,10,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 1261) := by decide +kernel

theorem selectedBound57659 : packedSelected [3,5,6,10,13,17] rootPS < 2^1333 := by decide +kernel

def env57660 : List Nat := [2,4,8,16,32,64,128,173,512,1024,1702,1261,8192,1212,8352,1711,1212,8195,1025,8352,1260,33,65,138,8328,16,1702,1212,1261,8194,8836,9941,173,9940,1213,513]

theorem envBound57660 : H12AffineFastState.Bounded env57660 := by
  intro p hp
  have h : env57660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57659_57660 : H12AffineEnvironment.transform 11 1261 env57659 = env57660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1261 env57659 == env57660) = true)

theorem identity57660 : scanCanonicalize (H12AffineFastState.compose env57660 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound57660 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env57661 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1702,1212,8192,1212,8352,1711,1212,8195,1025,8352,1213,33,16,138,8328,16,1702,1212,1212,8194,8836,9860,173,9861,1213,513]

theorem envBound57661 : H12AffineFastState.Bounded env57661 := by
  intro p hp
  have h : env57661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57660_57661 : H12AffineEnvironment.transform 5 17 env57660 = env57661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env57660 == env57661) = true)

theorem identity57661 : scanCanonicalize (H12AffineFastState.compose env57661 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound57661 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env57662 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1702,1212,8,1212,168,1711,1212,11,1025,168,1213,33,16,138,128,16,1702,1212,1212,10,652,1676,173,1677,1213,513]

theorem envBound57662 : H12AffineFastState.Bounded env57662 := by
  intro p hp
  have h : env57662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57661_57662 : H12AffineEnvironment.transform 12 8 env57661 = env57662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env57661 == env57662) = true)

theorem identity57662 : scanCanonicalize (H12AffineFastState.compose env57662 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound57662 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env57663 : List Nat := [2,4,8,16,32,17,128,173,26,1024,1212,1212,8,1212,168,1205,1212,11,1025,168,1213,33,16,138,128,16,1212,1212,1212,10,150,1174,173,1175,1213,27]

theorem envBound57663 : H12AffineFastState.Bounded env57663 := by
  intro p hp
  have h : env57663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57662_57663 : H12AffineEnvironment.transform 8 26 env57662 = env57663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env57662 == env57663) = true)

theorem identity57663 : scanCanonicalize (H12AffineFastState.compose env57663 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 62) := by decide +kernel

theorem selectedBound57663 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env57664 : List Nat := [2,4,8,16,32,17,128,173,26,62,130,130,8,130,168,139,130,11,63,168,131,33,16,138,128,16,130,130,130,10,150,168,173,169,131,27]

theorem envBound57664 : H12AffineFastState.Bounded env57664 := by
  intro p hp
  have h : env57664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57663_57664 : H12AffineEnvironment.transform 9 62 env57663 = env57664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 62 env57663 == env57664) = true)

theorem identity57664 : scanCanonicalize (H12AffineFastState.compose env57664 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound57664 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57665 : List Nat := [2,4,8,16,32,17,57,20,26,62,59,59,8,59,17,50,59,11,63,17,58,33,16,51,57,16,59,59,59,10,47,17,20,16,58,27]

theorem envBound57665 : H12AffineFastState.Bounded env57665 := by
  intro p hp
  have h : env57665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57664_57665 : H12AffineEnvironment.transform 6 57 env57664 = env57665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env57664 == env57665) = true)

theorem identity57665 : scanCanonicalize (H12AffineFastState.compose env57665 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57665 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57666 : List Nat := [2,4,8,11,32,10,34,15,1,37,32,32,8,32,10,41,32,11,36,10,33,33,11,40,34,11,32,32,32,10,47,10,15,11,33,0]

theorem envBound57666 : H12AffineFastState.Bounded env57666 := by
  intro p hp
  have h : env57666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57665_57666 : H12AffineEnvironment.transform 3 11 env57665 = env57666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57665 == env57666) = true)

theorem identity57666 : scanCanonicalize (H12AffineFastState.compose env57666 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound57666 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57667 : List Nat := [2,4,8,11,8,10,10,15,1,13,8,8,8,8,10,1,8,11,12,10,9,9,11,0,10,11,8,8,8,10,7,10,15,11,9,0]

theorem envBound57667 : H12AffineFastState.Bounded env57667 := by
  intro p hp
  have h : env57667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57666_57667 : H12AffineEnvironment.transform 4 8 env57666 = env57667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env57666 == env57667) = true)

def leafEnv57667 : List Nat := [2,4,8,11,8,10,10,15,1,13,8,8,8,8,10,1,8,11,12,10,9,9,11,0,7,10,1,11,8,8,8,10,7,10,15,11,5,3,9,0,1,9,0]

def active57667 : List Nat := [0,1,2]

def tree57667 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood57667 : H12WitnessSearch.Good tree57667 := H12GlobalWitnessIndex.good

theorem leafIdentity57667 : H12AffineFastState.composeSystem env57667 rootObs = leafEnv57667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env57667 rootObs == leafEnv57667) = true)

theorem terminalChecked57667 : H12PackedTerminal.terminalCheckFast leafEnv57667 active57667 tree57667 = true := by decide +kernel

def env57668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8955335,33554432,8409089,134217728,16384,656465,4840667,8463815,4294967296,525569,4307611964,34359738368,33563273]

theorem envBound57668 : H12AffineFastState.Bounded env57668 := by
  intro p hp
  have h : env57668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56659_57668 : H12AffineEnvironment.transform 25 8409089 env56659 = env57668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8409089 env56659 == env57668) = true)

def env57669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8409089,134217728,16384,131153,4315355,8463815,4294967296,257,4307611964,34359738368,33563273]

theorem envBound57669 : H12AffineFastState.Bounded env57669 := by
  intro p hp
  have h : env57669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57668_57669 : H12AffineEnvironment.transform 18 1024 env57668 = env57669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env57668 == env57669) = true)

def env57670 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8409089,134217728,16384,131153,4315355,8463815,4294967296,257,4307611964,131072,33563273]

theorem envBound57670 : H12AffineFastState.Bounded env57670 := by
  intro p hp
  have h : env57670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57669_57670 : H12AffineEnvironment.transform 34 131072 env57669 = env57670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env57669 == env57670) = true)

theorem identity57670 : scanCanonicalize (H12AffineFastState.compose env57670 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 221575) := by decide +kernel

theorem selectedBound57670 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env57671 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8409089,134217728,16384,131153,4315355,8463815,221575,257,12816571,131072,33563273]

theorem envBound57671 : H12AffineFastState.Bounded env57671 := by
  intro p hp
  have h : env57671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57670_57671 : H12AffineEnvironment.transform 31 221575 env57670 = env57671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 221575 env57670 == env57671) = true)

theorem identity57671 : scanCanonicalize (H12AffineFastState.compose env57671 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(26+1) ^^^ 12992837) := by decide +kernel

theorem selectedBound57671 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env57672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8409089,12992837,16384,131153,4315355,8463815,221575,257,12816571,131072,33563273]

theorem envBound57672 : H12AffineFastState.Bounded env57672 := by
  intro p hp
  have h : env57672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57671_57672 : H12AffineEnvironment.transform 26 12992837 env57671 = env57672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 12992837 env57671 == env57672) = true)

def env57673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,6329752,6304863,33554432,6342041,2544861,16384,131153,4315355,6402143,221575,257,2295075,131072,33563273]

theorem envBound57673 : H12AffineFastState.Bounded env57673 := by
  intro p hp
  have h : env57673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57672_57673 : H12AffineEnvironment.transform 22 6329752 env57672 = env57673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6329752 env57672 == env57673) = true)

def env57674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,6329752,6304863,4247640,6342041,2544861,16384,131153,4315355,6402143,221575,257,2295075,131072,4256465]

theorem envBound57674 : H12AffineFastState.Bounded env57674 := by
  intro p hp
  have h : env57674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57673_57674 : H12AffineEnvironment.transform 24 4247640 env57673 = env57674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4247640 env57673 == env57674) = true)

def env57675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,2269392,144712,169103,2257032,157001,2544861,16384,131153,2324491,200847,221575,257,2295075,131072,2249217]

theorem envBound57675 : H12AffineFastState.Bounded env57675 := by
  intro p hp
  have h : env57675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57674_57675 : H12AffineEnvironment.transform 21 2269392 env57674 = env57675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2269392 env57674 == env57675) = true)

def env57676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136512,46480,144712,169103,26056,157001,311709,16384,131153,93515,200847,221575,257,69731,131072,18241]

theorem envBound57676 : H12AffineFastState.Bounded env57676 := by
  intro p hp
  have h : env57676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57675_57676 : H12AffineEnvironment.transform 20 136512 env57675 = env57676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136512 env57675 == env57676) = true)

def env57677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136512,46480,144712,169103,26056,157001,103453,16384,131153,93515,200847,221575,257,69731,131072,18241]

theorem envBound57677 : H12AffineFastState.Bounded env57677 := by
  intro p hp
  have h : env57677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57676_57677 : H12AffineEnvironment.transform 17 87424 env57676 = env57677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env57676 == env57677) = true)

theorem identity57677 : scanCanonicalize (H12AffineFastState.compose env57677 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 20728) := by decide +kernel

theorem selectedBound57677 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,20728,65536,131072,87424,1024,20728,136512,25960,144712,148599,26056,157001,83173,16384,131153,93515,200847,221575,257,69731,131072,18241]

theorem envBound57678 : H12AffineFastState.Bounded env57678 := by
  intro p hp
  have h : env57678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57677_57678 : H12AffineEnvironment.transform 14 20728 env57677 = env57678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20728 env57677 == env57678) = true)

def env57679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,5560,65536,131072,69824,1024,5560,136512,8232,144712,131383,8328,139273,65957,1344,131153,75787,200847,206023,257,69731,131072,513]

theorem envBound57679 : H12AffineFastState.Bounded env57679 := by
  intro p hp
  have h : env57679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57678_57679 : H12AffineEnvironment.transform 13 1344 env57678 = env57679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env57678 == env57679) = true)

theorem identity57679 : scanCanonicalize (H12AffineFastState.compose env57679 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 294) := by decide +kernel

theorem selectedBound57679 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57680 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,5560,294,131072,4582,1024,5560,136512,8232,144712,131383,8328,139273,131,1344,131153,10541,135593,140769,257,4421,131072,513]

theorem envBound57680 : H12AffineFastState.Bounded env57680 := by
  intro p hp
  have h : env57680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57679_57680 : H12AffineEnvironment.transform 15 294 env57679 = env57680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 294 env57679 == env57680) = true)

theorem identity57680 : scanCanonicalize (H12AffineFastState.compose env57680 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 8216) := by decide +kernel

theorem selectedBound57680 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env57681 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,5560,294,8216,4582,1024,5560,13656,8232,5456,8495,8328,17,131,1344,8265,10541,12721,1529,257,4421,8216,513]

theorem envBound57681 : H12AffineFastState.Bounded env57681 := by
  intro p hp
  have h : env57681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57680_57681 : H12AffineEnvironment.transform 16 8216 env57680 = env57681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8216 env57680 == env57681) = true)

theorem identity57681 : scanCanonicalize (H12AffineFastState.compose env57681 (packedSelected [25] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound57681 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57682 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,1344,1108,294,8216,10,1024,1108,9396,8232,1212,8495,8328,17,131,1344,8265,10541,8285,1529,257,169,8216,513]

theorem envBound57682 : H12AffineFastState.Bounded env57682 := by
  intro p hp
  have h : env57682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57681_57682 : H12AffineEnvironment.transform 11 492 env57681 = env57682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env57681 == env57682) = true)

theorem identity57682 : scanCanonicalize (H12AffineFastState.compose env57682 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound57682 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57683 : List Nat := [2,4,8,16,32,64,128,256,512,1024,522,492,8192,1344,1108,294,8216,10,1024,1108,9396,8232,1212,8495,8328,17,131,1344,8265,8999,8285,1529,257,169,8216,513]

theorem envBound57683 : H12AffineFastState.Bounded env57683 := by
  intro p hp
  have h : env57683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57682_57683 : H12AffineEnvironment.transform 10 522 env57682 = env57683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env57682 == env57683) = true)

theorem identity57683 : scanCanonicalize (H12AffineFastState.compose env57683 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound57683 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57684 : List Nat := [2,4,8,16,32,64,128,256,512,1024,522,492,420,1344,1108,294,444,10,1024,1108,1296,396,1212,139,300,17,131,1344,493,643,505,1529,257,169,444,513]

theorem envBound57684 : H12AffineFastState.Bounded env57684 := by
  intro p hp
  have h : env57684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57683_57684 : H12AffineEnvironment.transform 12 420 env57683 = env57684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env57683 == env57684) = true)

theorem identity57684 : scanCanonicalize (H12AffineFastState.compose env57684 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound57684 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57685 : List Nat := [2,4,8,16,32,64,128,256,372,1024,382,492,420,1344,1108,294,444,10,1024,1108,1296,396,1212,139,300,17,131,1344,493,503,505,1529,257,169,444,373]

theorem envBound57685 : H12AffineFastState.Bounded env57685 := by
  intro p hp
  have h : env57685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57684_57685 : H12AffineEnvironment.transform 8 372 env57684 = env57685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env57684 == env57685) = true)

theorem identity57685 : scanCanonicalize (H12AffineFastState.compose env57685 (packedSelected [0,3,4,7,8,9,12] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound57685 : packedSelected [0,3,4,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env57686 : List Nat := [2,4,8,16,32,64,128,256,372,15,382,492,420,335,91,294,444,10,15,91,287,396,179,139,300,17,131,335,493,503,505,502,257,169,444,373]

theorem envBound57686 : H12AffineFastState.Bounded env57686 := by
  intro p hp
  have h : env57686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57685_57686 : H12AffineEnvironment.transform 9 15 env57685 = env57686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env57685 == env57686) = true)

theorem identity57686 : scanCanonicalize (H12AffineFastState.compose env57686 (packedSelected [0,1,3,4,5,7,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound57686 : packedSelected [0,1,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env57687 : List Nat := [2,4,8,16,32,64,128,14,122,15,112,226,170,65,91,40,178,10,15,91,17,130,179,139,34,17,131,65,227,249,247,248,15,169,178,123]

theorem envBound57687 : H12AffineFastState.Bounded env57687 := by
  intro p hp
  have h : env57687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57686_57687 : H12AffineEnvironment.transform 7 14 env57686 = env57687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env57686 == env57687) = true)

theorem identity57687 : scanCanonicalize (H12AffineFastState.compose env57687 (packedSelected [0,2,8] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound57687 : packedSelected [0,2,8] rootPS < 2^1333 := by decide +kernel

def env57688 : List Nat := [2,4,8,16,9,64,128,14,83,15,89,203,131,65,91,1,155,10,15,91,17,130,154,139,11,17,131,65,202,208,222,209,15,128,155,82]

theorem envBound57688 : H12AffineFastState.Bounded env57688 := by
  intro p hp
  have h : env57688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57687_57688 : H12AffineEnvironment.transform 4 9 env57687 = env57688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env57687 == env57688) = true)

theorem identity57688 : scanCanonicalize (H12AffineFastState.compose env57688 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(6+1) ^^^ 91) := by decide +kernel

theorem selectedBound57688 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env57689 : List Nat := [2,4,8,16,9,64,91,14,83,15,89,16,88,65,91,1,64,10,15,91,17,89,65,80,11,17,88,65,17,11,5,10,15,91,64,82]

theorem envBound57689 : H12AffineFastState.Bounded env57689 := by
  intro p hp
  have h : env57689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57688_57689 : H12AffineEnvironment.transform 6 91 env57688 = env57689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 91 env57688 == env57689) = true)

theorem identity57689 : scanCanonicalize (H12AffineFastState.compose env57689 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 9) := by decide +kernel

theorem selectedBound57689 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env57690 : List Nat := [2,4,8,16,9,9,18,14,26,15,16,16,17,8,18,1,9,10,15,18,17,16,8,25,11,17,17,8,17,11,5,10,15,18,9,27]

theorem envBound57690 : H12AffineFastState.Bounded env57690 := by
  intro p hp
  have h : env57690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57689_57690 : H12AffineEnvironment.transform 5 9 env57689 = env57690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 9 env57689 == env57690) = true)

theorem identity57690 : scanCanonicalize (H12AffineFastState.compose env57690 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57690 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57691 : List Nat := [2,4,8,11,9,9,9,14,1,15,11,11,10,8,9,1,9,10,15,9,10,11,8,2,11,10,10,8,10,11,5,10,15,9,9,0]

theorem envBound57691 : H12AffineFastState.Bounded env57691 := by
  intro p hp
  have h : env57691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57690_57691 : H12AffineEnvironment.transform 3 11 env57690 = env57691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57690 == env57691) = true)

theorem identity57691 : scanCanonicalize (H12AffineFastState.compose env57691 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound57691 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57692 : List Nat := [0,4,8,9,9,9,9,12,1,13,9,9,8,8,9,1,9,8,13,9,8,9,8,0,9,8,8,8,8,9,5,8,13,9,9,0]

theorem envBound57692 : H12AffineFastState.Bounded env57692 := by
  intro p hp
  have h : env57692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57691_57692 : H12AffineEnvironment.transform 0 0 env57691 = env57692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env57691 == env57692) = true)

theorem identity57692 : scanCanonicalize (H12AffineFastState.compose env57692 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound57692 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57693 : List Nat := [0,4,0,1,1,1,1,4,1,5,1,1,0,0,1,1,1,0,5,1,0,1,0,0,1,0,0,0,0,1,5,0,5,1,1,0]

theorem envBound57693 : H12AffineFastState.Bounded env57693 := by
  intro p hp
  have h : env57693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57692_57693 : H12AffineEnvironment.transform 2 0 env57692 = env57693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env57692 == env57693) = true)

def env57694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,5561,65536,131072,69825,1024,5561,136512,8233,144712,131382,8329,139272,65956,1345,131153,75786,200847,206022,257,69731,131072,512]

theorem envBound57694 : H12AffineFastState.Bounded env57694 := by
  intro p hp
  have h : env57694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57678_57694 : H12AffineEnvironment.transform 13 1345 env57678 = env57694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env57678 == env57694) = true)

theorem identity57694 : scanCanonicalize (H12AffineFastState.compose env57694 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound57694 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,168,65536,131072,67024,1024,168,131153,8233,139353,131382,8329,139272,65956,1345,131153,75786,198046,206022,257,66930,131072,512]

theorem envBound57695 : H12AffineFastState.Bounded env57695 := by
  intro p hp
  have h : env57695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57694_57695 : H12AffineEnvironment.transform 11 1297 env57694 = env57695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env57694 == env57695) = true)

def env57696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1024,32768,136512,46480,144712,169103,26056,157001,103452,16384,131153,93515,200847,221575,257,69731,131072,18241]

theorem envBound57696 : H12AffineFastState.Bounded env57696 := by
  intro p hp
  have h : env57696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57676_57696 : H12AffineEnvironment.transform 17 87425 env57676 = env57696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env57676 == env57696) = true)

theorem identity57696 : scanCanonicalize (H12AffineFastState.compose env57696 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 5560) := by decide +kernel

theorem selectedBound57696 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,5560,65536,131072,87425,1024,5560,136512,8232,144712,131383,26056,157001,65956,16384,131153,93515,200847,221575,257,69731,131072,18241]

theorem envBound57697 : H12AffineFastState.Bounded env57697 := by
  intro p hp
  have h : env57697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57696_57697 : H12AffineEnvironment.transform 14 5560 env57696 = env57697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5560 env57696 == env57697) = true)

def env57698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,5560,65536,131072,69825,1024,5560,136512,8232,144712,131383,8328,139273,65956,1344,131153,75787,200847,206023,257,69731,131072,513]

theorem envBound57698 : H12AffineFastState.Bounded env57698 := by
  intro p hp
  have h : env57698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57697_57698 : H12AffineEnvironment.transform 13 1344 env57697 = env57698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env57697 == env57698) = true)

theorem identity57698 : scanCanonicalize (H12AffineFastState.compose env57698 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 294) := by decide +kernel

theorem selectedBound57698 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,5560,294,131072,4583,1024,5560,136512,8232,144712,131383,8328,139273,130,1344,131153,10541,135593,140769,257,4421,131072,513]

theorem envBound57699 : H12AffineFastState.Bounded env57699 := by
  intro p hp
  have h : env57699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57698_57699 : H12AffineEnvironment.transform 15 294 env57698 = env57699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 294 env57698 == env57699) = true)

theorem identity57699 : scanCanonicalize (H12AffineFastState.compose env57699 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 8216) := by decide +kernel

theorem selectedBound57699 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env57700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,5560,294,8216,4583,1024,5560,13656,8232,5456,8495,8328,17,130,1344,8265,10541,12721,1529,257,4421,8216,513]

theorem envBound57700 : H12AffineFastState.Bounded env57700 := by
  intro p hp
  have h : env57700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57699_57700 : H12AffineEnvironment.transform 16 8216 env57699 = env57700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8216 env57699 == env57700) = true)

theorem identity57700 : scanCanonicalize (H12AffineFastState.compose env57700 (packedSelected [25] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound57700 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,1344,1108,294,8216,11,1024,1108,9396,8232,1212,8495,8328,17,130,1344,8265,10541,8285,1529,257,169,8216,513]

theorem envBound57701 : H12AffineFastState.Bounded env57701 := by
  intro p hp
  have h : env57701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57700_57701 : H12AffineEnvironment.transform 11 492 env57700 = env57701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env57700 == env57701) = true)

theorem identity57701 : scanCanonicalize (H12AffineFastState.compose env57701 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound57701 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,522,492,8192,1344,1108,294,8216,11,1024,1108,9396,8232,1212,8495,8328,17,130,1344,8265,8999,8285,1529,257,169,8216,513]

theorem envBound57702 : H12AffineFastState.Bounded env57702 := by
  intro p hp
  have h : env57702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57701_57702 : H12AffineEnvironment.transform 10 522 env57701 = env57702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env57701 == env57702) = true)

theorem identity57702 : scanCanonicalize (H12AffineFastState.compose env57702 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound57702 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,522,492,420,1344,1108,294,444,11,1024,1108,1296,396,1212,139,300,17,130,1344,493,643,505,1529,257,169,444,513]

theorem envBound57703 : H12AffineFastState.Bounded env57703 := by
  intro p hp
  have h : env57703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57702_57703 : H12AffineEnvironment.transform 12 420 env57702 = env57703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env57702 == env57703) = true)

theorem identity57703 : scanCanonicalize (H12AffineFastState.compose env57703 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound57703 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57704 : List Nat := [2,4,8,16,32,64,128,256,372,1024,382,492,420,1344,1108,294,444,11,1024,1108,1296,396,1212,139,300,17,130,1344,493,503,505,1529,257,169,444,373]

theorem envBound57704 : H12AffineFastState.Bounded env57704 := by
  intro p hp
  have h : env57704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57703_57704 : H12AffineEnvironment.transform 8 372 env57703 = env57704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env57703 == env57704) = true)

theorem identity57704 : scanCanonicalize (H12AffineFastState.compose env57704 (packedSelected [0,3,4,7,8,9,12] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound57704 : packedSelected [0,3,4,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env57705 : List Nat := [2,4,8,16,32,64,35,256,372,1024,382,335,263,1344,1108,294,287,11,1024,1108,1296,303,1055,40,300,17,33,1344,334,340,346,1370,257,10,287,373]

theorem envBound57705 : H12AffineFastState.Bounded env57705 := by
  intro p hp
  have h : env57705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57704_57705 : H12AffineEnvironment.transform 6 35 env57704 = env57705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env57704 == env57705) = true)

theorem identity57705 : scanCanonicalize (H12AffineFastState.compose env57705 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 94) := by decide +kernel

theorem selectedBound57705 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env57706 : List Nat := [2,4,8,16,32,64,35,256,372,94,382,335,263,286,10,294,287,11,94,10,334,303,65,40,300,17,33,286,334,340,346,260,257,10,287,373]

theorem envBound57706 : H12AffineFastState.Bounded env57706 := by
  intro p hp
  have h : env57706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57705_57706 : H12AffineEnvironment.transform 9 94 env57705 = env57706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 94 env57705 == env57706) = true)

theorem identity57706 : scanCanonicalize (H12AffineFastState.compose env57706 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound57706 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57707 : List Nat := [2,4,8,16,32,58,35,256,270,36,260,309,263,286,10,294,287,11,36,10,308,303,59,40,300,17,33,286,308,302,288,260,257,10,287,271]

theorem envBound57707 : H12AffineFastState.Bounded env57707 := by
  intro p hp
  have h : env57707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57706_57707 : H12AffineEnvironment.transform 5 58 env57706 = env57707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env57706 == env57707) = true)

theorem identity57707 : scanCanonicalize (H12AffineFastState.compose env57707 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 22) := by decide +kernel

theorem selectedBound57707 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env57708 : List Nat := [2,4,8,16,32,58,35,22,24,36,18,35,17,8,10,48,9,11,36,10,34,57,59,40,58,17,33,8,34,56,54,18,23,10,9,25]

theorem envBound57708 : H12AffineFastState.Bounded env57708 := by
  intro p hp
  have h : env57708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57707_57708 : H12AffineEnvironment.transform 7 22 env57707 = env57708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 22 env57707 == env57708) = true)

theorem identity57708 : scanCanonicalize (H12AffineFastState.compose env57708 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound57708 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env57709 : List Nat := [2,4,8,16,17,11,18,22,24,21,18,18,17,8,10,1,9,11,21,10,19,8,10,25,11,17,16,8,19,9,7,18,23,10,9,25]

theorem envBound57709 : H12AffineFastState.Bounded env57709 := by
  intro p hp
  have h : env57709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57708_57709 : H12AffineEnvironment.transform 4 17 env57708 = env57709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env57708 == env57709) = true)

theorem identity57709 : scanCanonicalize (H12AffineFastState.compose env57709 (packedSelected [1,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57709 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env57710 : List Nat := [2,4,8,10,11,11,8,12,2,15,8,8,11,8,10,1,9,11,15,10,9,8,10,3,11,11,10,8,9,9,7,8,13,10,9,3]

theorem envBound57710 : H12AffineFastState.Bounded env57710 := by
  intro p hp
  have h : env57710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57709_57710 : H12AffineEnvironment.transform 3 10 env57709 = env57710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57709 == env57710) = true)

def env57711 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,5560,65536,131072,69824,1024,5560,136512,8232,144712,131383,8329,139272,65956,1345,131153,75786,200847,206022,257,69731,131072,512]

theorem envBound57711 : H12AffineFastState.Bounded env57711 := by
  intro p hp
  have h : env57711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57697_57711 : H12AffineEnvironment.transform 13 1345 env57697 = env57711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env57697 == env57711) = true)

theorem identity57711 : scanCanonicalize (H12AffineFastState.compose env57711 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound57711 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57712 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,169,65536,131072,67025,1024,169,131153,8232,139353,131383,8329,139272,65956,1345,131153,75786,198046,206022,257,66930,131072,512]

theorem envBound57712 : H12AffineFastState.Bounded env57712 := by
  intro p hp
  have h : env57712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57711_57712 : H12AffineEnvironment.transform 11 1297 env57711 = env57712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env57711 == env57712) = true)

def env57713 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136513,46481,144712,169103,26057,157001,311708,16384,131153,93514,200847,221575,257,69730,131072,18240]

theorem envBound57713 : H12AffineFastState.Bounded env57713 := by
  intro p hp
  have h : env57713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57675_57713 : H12AffineEnvironment.transform 20 136513 env57675 = env57713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136513 env57675 == env57713) = true)

def env57714 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136513,46481,144712,169103,26057,157001,103452,16384,131153,93514,200847,221575,257,69730,131072,18240]

theorem envBound57714 : H12AffineFastState.Bounded env57714 := by
  intro p hp
  have h : env57714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57713_57714 : H12AffineEnvironment.transform 17 87424 env57713 = env57714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env57713 == env57714) = true)

theorem identity57714 : scanCanonicalize (H12AffineFastState.compose env57714 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 169) := by decide +kernel

theorem selectedBound57714 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,169,65536,131072,87424,1024,169,136513,13624,144712,136230,26057,157001,70837,16384,131153,93514,200847,221575,257,69730,131072,18240]

theorem envBound57715 : H12AffineFastState.Bounded env57715 := by
  intro p hp
  have h : env57715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57714_57715 : H12AffineEnvironment.transform 14 169 env57714 = env57715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 169 env57714 == env57715) = true)

def env57716 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,169,65536,131072,69824,1024,169,136513,13624,144712,136230,8329,139273,70837,1344,131153,75786,200847,206023,257,69730,131072,512]

theorem envBound57716 : H12AffineFastState.Bounded env57716 := by
  intro p hp
  have h : env57716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57715_57716 : H12AffineEnvironment.transform 13 1344 env57715 = env57716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env57715 == env57716) = true)

theorem identity57716 : scanCanonicalize (H12AffineFastState.compose env57716 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound57716 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,169,65536,131072,67024,1024,169,131153,8232,139352,131382,8329,139273,65957,1344,131153,75786,198047,206023,257,66930,131072,512]

theorem envBound57717 : H12AffineFastState.Bounded env57717 := by
  intro p hp
  have h : env57717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57716_57717 : H12AffineEnvironment.transform 11 1296 env57716 = env57717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env57716 == env57717) = true)

def env57718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,169,65536,131072,69825,1024,169,136513,13624,144712,136230,8328,139272,70837,1345,131153,75787,200847,206022,257,69730,131072,513]

theorem envBound57718 : H12AffineFastState.Bounded env57718 := by
  intro p hp
  have h : env57718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57715_57718 : H12AffineEnvironment.transform 13 1345 env57715 = env57718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env57715 == env57718) = true)

theorem identity57718 : scanCanonicalize (H12AffineFastState.compose env57718 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 5174) := by decide +kernel

theorem selectedBound57718 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,169,5174,131072,1271,1024,169,136513,13624,144712,136230,8328,139272,131,1345,131153,15421,132281,143600,257,1108,131072,513]

theorem envBound57719 : H12AffineFastState.Bounded env57719 := by
  intro p hp
  have h : env57719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57718_57719 : H12AffineEnvironment.transform 15 5174 env57718 = env57719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5174 env57718 == env57719) = true)

theorem identity57719 : scanCanonicalize (H12AffineFastState.compose env57719 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 8217) := by decide +kernel

theorem selectedBound57719 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env57720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,169,5174,8217,1271,1024,169,13656,13624,5457,13375,8328,17,131,1345,8264,15421,9376,4329,257,1108,8217,513]

theorem envBound57720 : H12AffineFastState.Bounded env57720 := by
  intro p hp
  have h : env57720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57719_57720 : H12AffineEnvironment.transform 16 8217 env57719 = env57720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8217 env57719 == env57720) = true)

theorem identity57720 : scanCanonicalize (H12AffineFastState.compose env57720 (packedSelected [25] rootPS)) = affineNative (2^(9+1) ^^^ 253) := by decide +kernel

theorem selectedBound57720 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57721 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,444,169,4299,8217,10,253,169,12709,12741,4524,12482,8328,17,131,444,8264,14528,8285,4329,257,169,8217,513]

theorem envBound57721 : H12AffineFastState.Bounded env57721 := by
  intro p hp
  have h : env57721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57720_57721 : H12AffineEnvironment.transform 9 253 env57720 = env57721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 253 env57720 == env57721) = true)

theorem identity57721 : scanCanonicalize (H12AffineFastState.compose env57721 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 3047) := by decide +kernel

theorem selectedBound57721 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57722 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,3047,8192,444,169,2860,8217,10,253,169,10818,10786,2635,11045,8328,17,131,444,8264,8999,8285,2830,257,169,8217,513]

theorem envBound57722 : H12AffineFastState.Bounded env57722 := by
  intro p hp
  have h : env57722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57721_57722 : H12AffineEnvironment.transform 11 3047 env57721 = env57722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3047 env57721 == env57722) = true)

theorem identity57722 : scanCanonicalize (H12AffineFastState.compose env57722 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 2990) := by decide +kernel

theorem selectedBound57722 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57723 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,3047,2990,444,169,2860,2999,10,253,169,492,396,2635,139,2854,17,131,444,3046,2185,3059,2830,257,169,2999,513]

theorem envBound57723 : H12AffineFastState.Bounded env57723 := by
  intro p hp
  have h : env57723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57722_57723 : H12AffineEnvironment.transform 12 2990 env57722 = env57723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2990 env57722 == env57723) = true)

theorem identity57723 : scanCanonicalize (H12AffineFastState.compose env57723 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound57723 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57724 : List Nat := [2,4,8,16,32,64,128,256,373,253,2048,2194,2267,444,169,2137,2242,10,253,169,492,396,2366,139,2131,17,131,444,2195,2185,2182,2171,257,169,2242,372]

theorem envBound57724 : H12AffineFastState.Bounded env57724 := by
  intro p hp
  have h : env57724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57723_57724 : H12AffineEnvironment.transform 8 373 env57723 = env57724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env57723 == env57724) = true)

theorem identity57724 : scanCanonicalize (H12AffineFastState.compose env57724 (packedSelected [3,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound57724 : packedSelected [3,8,12] rootPS < 2^1333 := by decide +kernel

def env57725 : List Nat := [2,4,8,16,32,64,128,95,42,253,2048,2194,2267,227,169,2137,2242,10,253,169,179,211,2145,139,2131,17,131,227,2195,2185,2182,2171,94,169,2242,43]

theorem envBound57725 : H12AffineFastState.Bounded env57725 := by
  intro p hp
  have h : env57725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57724_57725 : H12AffineEnvironment.transform 7 95 env57724 = env57725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env57724 == env57725) = true)

theorem identity57725 : scanCanonicalize (H12AffineFastState.compose env57725 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound57725 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env57726 : List Nat := [2,4,8,16,32,17,128,14,42,172,2048,2194,2186,178,169,2056,2195,10,172,169,179,130,2096,139,2050,17,131,178,2195,2185,2182,2090,15,169,2195,43]

theorem envBound57726 : H12AffineFastState.Bounded env57726 := by
  intro p hp
  have h : env57726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57725_57726 : H12AffineEnvironment.transform 5 17 env57725 = env57726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env57725 == env57726) = true)

theorem identity57726 : scanCanonicalize (H12AffineFastState.compose env57726 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 0) := by decide +kernel

theorem selectedBound57726 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57727 : List Nat := [2,4,8,16,32,17,0,14,42,44,2048,2066,2058,50,41,2056,2067,10,44,41,51,2,2096,11,2050,17,3,50,2067,2057,2054,2090,15,41,2067,43]

theorem envBound57727 : H12AffineFastState.Bounded env57727 := by
  intro p hp
  have h : env57727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57726_57727 : H12AffineEnvironment.transform 6 0 env57726 = env57727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 0 env57726 == env57727) = true)

theorem identity57727 : scanCanonicalize (H12AffineFastState.compose env57727 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound57727 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env57728 : List Nat := [2,4,8,16,32,17,0,14,42,44,42,56,32,50,41,34,57,10,44,41,51,2,26,11,40,17,3,50,57,35,44,0,15,41,57,43]

theorem envBound57728 : H12AffineFastState.Bounded env57728 := by
  intro p hp
  have h : env57728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57727_57728 : H12AffineEnvironment.transform 10 42 env57727 = env57728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env57727 == env57728) = true)

theorem identity57728 : scanCanonicalize (H12AffineFastState.compose env57728 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound57728 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env57729 : List Nat := [0,4,8,16,32,17,0,12,40,44,40,56,32,48,41,32,57,8,44,41,49,0,24,9,40,17,1,48,57,33,44,0,13,41,57,41]

theorem envBound57729 : H12AffineFastState.Bounded env57729 := by
  intro p hp
  have h : env57729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57728_57729 : H12AffineEnvironment.transform 0 0 env57728 = env57729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env57728 == env57729) = true)

theorem identity57729 : scanCanonicalize (H12AffineFastState.compose env57729 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound57729 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57730 : List Nat := [0,4,0,16,32,17,0,4,32,36,32,48,32,48,33,32,49,0,36,33,49,0,16,1,32,17,1,48,49,33,36,0,5,33,49,33]

theorem envBound57730 : H12AffineFastState.Bounded env57730 := by
  intro p hp
  have h : env57730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57729_57730 : H12AffineEnvironment.transform 2 0 env57729 = env57730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env57729 == env57730) = true)

theorem identity57730 : scanCanonicalize (H12AffineFastState.compose env57730 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound57730 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57731 : List Nat := [0,4,0,1,32,0,0,4,32,36,32,33,32,33,33,32,32,0,36,33,32,0,1,1,32,0,1,33,32,33,36,0,5,33,32,33]

theorem envBound57731 : H12AffineFastState.Bounded env57731 := by
  intro p hp
  have h : env57731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57730_57731 : H12AffineEnvironment.transform 3 1 env57730 = env57731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57730 == env57731) = true)

def env57732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1024,32768,136513,46481,144712,169103,26057,157001,103453,16384,131153,93514,200847,221575,257,69730,131072,18240]

theorem envBound57732 : H12AffineFastState.Bounded env57732 := by
  intro p hp
  have h : env57732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57713_57732 : H12AffineEnvironment.transform 17 87425 env57713 = env57732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env57713 == env57732) = true)

theorem identity57732 : scanCanonicalize (H12AffineFastState.compose env57732 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 17896) := by decide +kernel

theorem selectedBound57732 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,17896,65536,131072,87425,1024,17896,136513,28793,144712,151911,26057,157001,86517,16384,131153,93514,200847,221575,257,69730,131072,18240]

theorem envBound57733 : H12AffineFastState.Bounded env57733 := by
  intro p hp
  have h : env57733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57732_57733 : H12AffineEnvironment.transform 14 17896 env57732 = env57733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17896 env57732 == env57733) = true)

def env57734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,168,65536,131072,69825,1024,168,136513,13625,144712,136231,8329,139273,70837,1344,131153,75786,200847,206023,257,69730,131072,512]

theorem envBound57734 : H12AffineFastState.Bounded env57734 := by
  intro p hp
  have h : env57734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57733_57734 : H12AffineEnvironment.transform 13 1344 env57733 = env57734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env57733 == env57734) = true)

theorem identity57734 : scanCanonicalize (H12AffineFastState.compose env57734 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound57734 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,168,65536,131072,67025,1024,168,131153,8233,139352,131383,8329,139273,65957,1344,131153,75786,198047,206023,257,66930,131072,512]

theorem envBound57735 : H12AffineFastState.Bounded env57735 := by
  intro p hp
  have h : env57735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57734_57735 : H12AffineEnvironment.transform 11 1296 env57734 = env57735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env57734 == env57735) = true)

def env57736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,169,65536,131072,69824,1024,169,136513,13624,144712,136230,8328,139272,70836,1345,131153,75787,200847,206022,257,69730,131072,513]

theorem envBound57736 : H12AffineFastState.Bounded env57736 := by
  intro p hp
  have h : env57736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57733_57736 : H12AffineEnvironment.transform 13 1345 env57733 = env57736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env57733 == env57736) = true)

theorem identity57736 : scanCanonicalize (H12AffineFastState.compose env57736 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 5174) := by decide +kernel

theorem selectedBound57736 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,169,5174,131072,1270,1024,169,136513,13624,144712,136230,8328,139272,130,1345,131153,15421,132281,143600,257,1108,131072,513]

theorem envBound57737 : H12AffineFastState.Bounded env57737 := by
  intro p hp
  have h : env57737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57736_57737 : H12AffineEnvironment.transform 15 5174 env57736 = env57737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5174 env57736 == env57737) = true)

theorem identity57737 : scanCanonicalize (H12AffineFastState.compose env57737 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 8217) := by decide +kernel

theorem selectedBound57737 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env57738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,169,5174,8217,1270,1024,169,13656,13624,5457,13375,8328,17,130,1345,8264,15421,9376,4329,257,1108,8217,513]

theorem envBound57738 : H12AffineFastState.Bounded env57738 := by
  intro p hp
  have h : env57738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57737_57738 : H12AffineEnvironment.transform 16 8217 env57737 = env57738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8217 env57737 == env57738) = true)

theorem identity57738 : scanCanonicalize (H12AffineFastState.compose env57738 (packedSelected [25] rootPS)) = affineNative (2^(9+1) ^^^ 253) := by decide +kernel

theorem selectedBound57738 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57739 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,444,169,4299,8217,11,253,169,12709,12741,4524,12482,8328,17,130,444,8264,14528,8285,4329,257,169,8217,513]

theorem envBound57739 : H12AffineFastState.Bounded env57739 := by
  intro p hp
  have h : env57739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57738_57739 : H12AffineEnvironment.transform 9 253 env57738 = env57739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 253 env57738 == env57739) = true)

theorem identity57739 : scanCanonicalize (H12AffineFastState.compose env57739 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 3047) := by decide +kernel

theorem selectedBound57739 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57740 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,3047,8192,444,169,2860,8217,11,253,169,10818,10786,2635,11045,8328,17,130,444,8264,8999,8285,2830,257,169,8217,513]

theorem envBound57740 : H12AffineFastState.Bounded env57740 := by
  intro p hp
  have h : env57740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57739_57740 : H12AffineEnvironment.transform 11 3047 env57739 = env57740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3047 env57739 == env57740) = true)

theorem identity57740 : scanCanonicalize (H12AffineFastState.compose env57740 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 2990) := by decide +kernel

theorem selectedBound57740 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57741 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,3047,2990,444,169,2860,2999,11,253,169,492,396,2635,139,2854,17,130,444,3046,2185,3059,2830,257,169,2999,513]

theorem envBound57741 : H12AffineFastState.Bounded env57741 := by
  intro p hp
  have h : env57741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57740_57741 : H12AffineEnvironment.transform 12 2990 env57740 = env57741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2990 env57740 == env57741) = true)

theorem identity57741 : scanCanonicalize (H12AffineFastState.compose env57741 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound57741 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57742 : List Nat := [2,4,8,16,32,64,128,256,373,253,2048,2194,2267,444,169,2137,2242,11,253,169,492,396,2366,139,2131,17,130,444,2195,2185,2182,2171,257,169,2242,372]

theorem envBound57742 : H12AffineFastState.Bounded env57742 := by
  intro p hp
  have h : env57742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57741_57742 : H12AffineEnvironment.transform 8 373 env57741 = env57742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env57741 == env57742) = true)

theorem identity57742 : scanCanonicalize (H12AffineFastState.compose env57742 (packedSelected [3,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 113) := by decide +kernel

theorem selectedBound57742 : packedSelected [3,8,12] rootPS < 2^1333 := by decide +kernel

def env57743 : List Nat := [2,4,8,16,32,64,128,256,373,253,113,227,170,444,169,40,179,11,253,169,492,396,335,139,34,17,130,444,226,248,247,10,257,169,179,372]

theorem envBound57743 : H12AffineFastState.Bounded env57743 := by
  intro p hp
  have h : env57743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57742_57743 : H12AffineEnvironment.transform 10 113 env57742 = env57743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 113 env57742 == env57743) = true)

theorem identity57743 : scanCanonicalize (H12AffineFastState.compose env57743 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound57743 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env57744 : List Nat := [2,4,8,16,32,16,128,256,293,173,33,179,170,444,169,40,179,11,173,169,444,396,287,139,34,17,130,444,178,168,167,10,257,169,179,292]

theorem envBound57744 : H12AffineFastState.Bounded env57744 := by
  intro p hp
  have h : env57744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57743_57744 : H12AffineEnvironment.transform 5 16 env57743 = env57744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57743 == env57744) = true)

theorem identity57744 : scanCanonicalize (H12AffineFastState.compose env57744 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 44) := by decide +kernel

theorem selectedBound57744 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57745 : List Nat := [2,4,8,16,32,16,128,44,9,173,33,179,170,144,169,40,179,11,173,169,144,160,51,139,34,17,130,144,178,168,167,10,45,169,179,8]

theorem envBound57745 : H12AffineFastState.Bounded env57745 := by
  intro p hp
  have h : env57745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57744_57745 : H12AffineEnvironment.transform 7 44 env57744 = env57745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 44 env57744 == env57745) = true)

theorem identity57745 : scanCanonicalize (H12AffineFastState.compose env57745 (packedSelected [2,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound57745 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env57746 : List Nat := [2,4,8,16,32,16,57,44,9,20,33,10,19,41,16,40,10,11,20,16,41,25,51,50,34,17,59,41,11,17,30,10,45,16,10,8]

theorem envBound57746 : H12AffineFastState.Bounded env57746 := by
  intro p hp
  have h : env57746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57745_57746 : H12AffineEnvironment.transform 6 57 env57745 = env57746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env57745 == env57746) = true)

theorem identity57746 : scanCanonicalize (H12AffineFastState.compose env57746 (packedSelected [2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound57746 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env57747 : List Nat := [2,4,8,9,32,9,32,44,9,13,33,10,10,41,9,40,10,11,13,9,41,0,42,43,34,8,34,41,11,8,7,10,45,9,10,8]

theorem envBound57747 : H12AffineFastState.Bounded env57747 := by
  intro p hp
  have h : env57747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57746_57747 : H12AffineEnvironment.transform 3 9 env57746 = env57747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env57746 == env57747) = true)

theorem identity57747 : scanCanonicalize (H12AffineFastState.compose env57747 (packedSelected [2,3,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57747 : packedSelected [2,3,7] rootPS < 2^1333 := by decide +kernel

def env57748 : List Nat := [2,4,3,2,32,2,32,39,2,6,33,1,1,34,2,35,1,0,6,2,34,0,33,32,34,3,34,34,0,3,7,1,38,2,1,3]

theorem envBound57748 : H12AffineFastState.Bounded env57748 := by
  intro p hp
  have h : env57748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57747_57748 : H12AffineEnvironment.transform 2 3 env57747 = env57748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57747 == env57748) = true)

theorem identity57748 : scanCanonicalize (H12AffineFastState.compose env57748 (packedSelected [0,2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound57748 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env57749 : List Nat := [0,4,1,0,32,0,32,37,0,4,33,1,1,32,0,33,1,0,4,0,32,0,33,32,32,1,32,32,0,1,5,1,36,0,1,1]

theorem envBound57749 : H12AffineFastState.Bounded env57749 := by
  intro p hp
  have h : env57749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57748_57749 : H12AffineEnvironment.transform 0 0 env57748 = env57749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env57748 == env57749) = true)

theorem identity57749 : scanCanonicalize (H12AffineFastState.compose env57749 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound57749 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env57750 : List Nat := [0,4,1,0,0,0,0,5,0,4,1,1,1,0,0,1,1,0,4,0,0,0,1,0,0,1,0,0,0,1,5,1,4,0,1,1]

theorem envBound57750 : H12AffineFastState.Bounded env57750 := by
  intro p hp
  have h : env57750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57749_57750 : H12AffineEnvironment.transform 4 0 env57749 = env57750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env57749 == env57750) = true)

def env57751 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,2269393,144713,169102,2257033,157000,2544861,16384,131153,2324490,200846,221575,257,2295075,131072,2249216]

theorem envBound57751 : H12AffineFastState.Bounded env57751 := by
  intro p hp
  have h : env57751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57674_57751 : H12AffineEnvironment.transform 21 2269393 env57674 = env57751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2269393 env57674 == env57751) = true)

def env57752 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136512,46481,144713,169102,26057,157000,311709,16384,131153,93514,200846,221575,257,69731,131072,18240]

theorem envBound57752 : H12AffineFastState.Bounded env57752 := by
  intro p hp
  have h : env57752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57751_57752 : H12AffineEnvironment.transform 20 136512 env57751 = env57752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136512 env57751 == env57752) = true)

def env57753 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136512,46481,144713,169102,26057,157000,103453,16384,131153,93514,200846,221575,257,69731,131072,18240]

theorem envBound57753 : H12AffineFastState.Bounded env57753 := by
  intro p hp
  have h : env57753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57752_57753 : H12AffineEnvironment.transform 17 87424 env57752 = env57753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env57752 == env57753) = true)

theorem identity57753 : scanCanonicalize (H12AffineFastState.compose env57753 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 24753) := by decide +kernel

theorem selectedBound57753 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,24753,65536,131072,87424,1024,24753,136512,21792,144713,160831,26057,157000,95404,16384,131153,93514,200846,221575,257,69731,131072,18240]

theorem envBound57754 : H12AffineFastState.Bounded env57754 := by
  intro p hp
  have h : env57754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57753_57754 : H12AffineEnvironment.transform 14 24753 env57753 = env57754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24753 env57753 == env57754) = true)

def env57755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,9713,65536,131072,69824,1024,9713,136512,4192,144713,143743,8329,139272,78316,1344,131153,75786,200846,206023,257,69731,131072,512]

theorem envBound57755 : H12AffineFastState.Bounded env57755 := by
  intro p hp
  have h : env57755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57754_57755 : H12AffineEnvironment.transform 13 1344 env57754 = env57755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env57754 == env57755) = true)

theorem identity57755 : scanCanonicalize (H12AffineFastState.compose env57755 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound57755 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,9713,65536,131072,67024,1024,9713,131152,1392,139353,140399,8329,139272,75004,1344,131153,75786,198046,206023,257,66931,131072,512]

theorem envBound57756 : H12AffineFastState.Bounded env57756 := by
  intro p hp
  have h : env57756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57755_57756 : H12AffineEnvironment.transform 11 1296 env57755 = env57756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env57755 == env57756) = true)

def env57757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,9712,65536,131072,69825,1024,9712,136512,4193,144713,143742,8328,139273,78317,1345,131153,75787,200846,206022,257,69731,131072,513]

theorem envBound57757 : H12AffineFastState.Bounded env57757 := by
  intro p hp
  have h : env57757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57754_57757 : H12AffineEnvironment.transform 13 1345 env57754 = env57757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env57754 == env57757) = true)

theorem identity57757 : scanCanonicalize (H12AffineFastState.compose env57757 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 12654) := by decide +kernel

theorem selectedBound57757 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57758 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,9712,12654,131072,8623,1024,9712,136512,4193,144713,143742,8328,139273,131,1345,131153,6501,139744,136616,257,8461,131072,513]

theorem envBound57758 : H12AffineFastState.Bounded env57758 := by
  intro p hp
  have h : env57758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57757_57758 : H12AffineEnvironment.transform 15 12654 env57757 = env57758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12654 env57757 == env57758) = true)

theorem identity57758 : scanCanonicalize (H12AffineFastState.compose env57758 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 8217) := by decide +kernel

theorem selectedBound57758 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env57759 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,9712,12654,8217,8623,1024,9712,13657,4193,5456,4455,8328,16,131,1345,8264,6501,505,13745,257,8461,8217,513]

theorem envBound57759 : H12AffineFastState.Bounded env57759 := by
  intro p hp
  have h : env57759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57758_57759 : H12AffineEnvironment.transform 16 8217 env57758 = env57759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8217 env57758 == env57759) = true)

theorem identity57759 : scanCanonicalize (H12AffineFastState.compose env57759 (packedSelected [25] rootPS)) = affineNative (2^(12+1) ^^^ 421) := by decide +kernel

theorem selectedBound57759 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,1345,1109,4299,444,10,1024,1109,5372,4193,5456,4455,301,16,131,1345,493,6501,505,5140,257,168,444,513]

theorem envBound57760 : H12AffineFastState.Bounded env57760 := by
  intro p hp
  have h : env57760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57759_57760 : H12AffineEnvironment.transform 12 421 env57759 = env57760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 421 env57759 == env57760) = true)

theorem identity57760 : scanCanonicalize (H12AffineFastState.compose env57760 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 2634) := by decide +kernel

theorem selectedBound57760 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2634,421,1345,1109,2689,444,10,1024,1109,3766,2603,3866,2861,301,16,131,1345,493,815,505,3678,257,168,444,513]

theorem envBound57761 : H12AffineFastState.Bounded env57761 := by
  intro p hp
  have h : env57761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57760_57761 : H12AffineEnvironment.transform 11 2634 env57760 = env57761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2634 env57760 == env57761) = true)

theorem identity57761 : scanCanonicalize (H12AffineFastState.compose env57761 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 173) := by decide +kernel

theorem selectedBound57761 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env57762 : List Nat := [2,4,8,16,32,64,128,256,512,173,2048,2634,421,492,248,2689,444,10,173,248,2587,2603,2999,2861,301,16,131,492,493,815,505,2803,257,168,444,513]

theorem envBound57762 : H12AffineFastState.Bounded env57762 := by
  intro p hp
  have h : env57762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57761_57762 : H12AffineEnvironment.transform 9 173 env57761 = env57762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env57761 == env57762) = true)

theorem identity57762 : scanCanonicalize (H12AffineFastState.compose env57762 (packedSelected [1,4,5,9,10,13,20] rootPS)) = affineNative (2^(10+1) ^^^ 602) := by decide +kernel

theorem selectedBound57762 : packedSelected [1,4,5,9,10,13,20] rootPS < 2^1333 := by decide +kernel

def env57763 : List Nat := [2,4,8,16,32,64,128,256,512,173,602,16,421,492,248,219,444,10,173,248,65,113,493,375,301,16,131,492,493,815,505,169,257,168,444,513]

theorem envBound57763 : H12AffineFastState.Bounded env57763 := by
  intro p hp
  have h : env57763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57762_57763 : H12AffineEnvironment.transform 10 602 env57762 = env57763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 602 env57762 == env57763) = true)

theorem identity57763 : scanCanonicalize (H12AffineFastState.compose env57763 (packedSelected [0,1,3,4,7,9,13] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound57763 : packedSelected [0,1,3,4,7,9,13] rootPS < 2^1333 := by decide +kernel

def env57764 : List Nat := [2,4,8,16,32,64,128,256,217,173,131,16,421,492,248,219,444,10,173,248,65,113,493,375,301,16,131,492,493,502,505,169,257,168,444,216]

theorem envBound57764 : H12AffineFastState.Bounded env57764 := by
  intro p hp
  have h : env57764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57763_57764 : H12AffineEnvironment.transform 8 217 env57763 = env57764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env57763 == env57764) = true)

theorem identity57764 : scanCanonicalize (H12AffineFastState.compose env57764 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 205) := by decide +kernel

theorem selectedBound57764 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env57765 : List Nat := [2,4,8,16,32,64,128,205,217,173,131,16,104,33,248,219,113,10,173,248,65,113,32,186,224,16,131,33,32,59,52,169,204,168,113,216]

theorem envBound57765 : H12AffineFastState.Bounded env57765 := by
  intro p hp
  have h : env57765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57764_57765 : H12AffineEnvironment.transform 7 205 env57764 = env57765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 205 env57764 == env57765) = true)

theorem identity57765 : scanCanonicalize (H12AffineFastState.compose env57765 (packedSelected [1,2,4,5,9] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound57765 : packedSelected [1,2,4,5,9] rootPS < 2^1333 := by decide +kernel

def env57766 : List Nat := [2,4,8,16,17,64,128,205,217,156,131,16,89,16,201,219,64,10,156,201,65,64,17,139,209,16,131,16,17,10,5,152,204,153,64,216]

theorem envBound57766 : H12AffineFastState.Bounded env57766 := by
  intro p hp
  have h : env57766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57765_57766 : H12AffineEnvironment.transform 4 17 env57765 = env57766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env57765 == env57766) = true)

theorem identity57766 : scanCanonicalize (H12AffineFastState.compose env57766 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound57766 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57767 : List Nat := [2,4,8,16,17,64,8,69,81,20,11,16,89,16,65,83,64,10,20,65,65,64,17,3,89,16,11,16,17,10,5,16,68,17,64,80]

theorem envBound57767 : H12AffineFastState.Bounded env57767 := by
  intro p hp
  have h : env57767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57766_57767 : H12AffineEnvironment.transform 6 8 env57766 = env57767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env57766 == env57767) = true)

theorem identity57767 : scanCanonicalize (H12AffineFastState.compose env57767 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 9) := by decide +kernel

theorem selectedBound57767 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57768 : List Nat := [2,4,8,16,17,9,8,12,24,20,11,16,16,16,8,26,9,10,20,8,8,9,17,3,16,16,11,16,17,10,5,16,13,17,9,25]

theorem envBound57768 : H12AffineFastState.Bounded env57768 := by
  intro p hp
  have h : env57768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57767_57768 : H12AffineEnvironment.transform 5 9 env57767 = env57768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 9 env57767 == env57768) = true)

theorem identity57768 : scanCanonicalize (H12AffineFastState.compose env57768 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound57768 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env57769 : List Nat := [2,4,8,9,8,9,8,12,1,13,11,9,9,9,8,3,9,10,13,8,8,9,8,3,9,9,11,9,8,10,5,9,13,8,9,0]

theorem envBound57769 : H12AffineFastState.Bounded env57769 := by
  intro p hp
  have h : env57769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57768_57769 : H12AffineEnvironment.transform 3 9 env57768 = env57769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env57768 == env57769) = true)

theorem identity57769 : scanCanonicalize (H12AffineFastState.compose env57769 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57769 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57770 : List Nat := [2,4,3,2,3,2,3,7,1,6,0,2,2,2,3,3,2,1,6,3,3,2,3,3,2,2,0,2,3,1,5,2,6,3,2,0]

theorem envBound57770 : H12AffineFastState.Bounded env57770 := by
  intro p hp
  have h : env57770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57769_57770 : H12AffineEnvironment.transform 2 3 env57769 = env57770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57769 == env57770) = true)

theorem identity57770 : scanCanonicalize (H12AffineFastState.compose env57770 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound57770 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57771 : List Nat := [1,4,0,1,0,1,0,4,1,5,0,1,1,1,0,0,1,1,5,0,0,1,0,0,1,1,0,1,0,1,5,1,5,0,1,0]

theorem envBound57771 : H12AffineFastState.Bounded env57771 := by
  intro p hp
  have h : env57771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57770_57771 : H12AffineEnvironment.transform 0 1 env57770 = env57771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env57770 == env57771) = true)

def env57772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1024,32768,136512,46481,144713,169102,26057,157000,103452,16384,131153,93514,200846,221575,257,69731,131072,18240]

theorem envBound57772 : H12AffineFastState.Bounded env57772 := by
  intro p hp
  have h : env57772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57752_57772 : H12AffineEnvironment.transform 17 87425 env57752 = env57772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env57752 == env57772) = true)

theorem identity57772 : scanCanonicalize (H12AffineFastState.compose env57772 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9712) := by decide +kernel

theorem selectedBound57772 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9712,65536,131072,87425,1024,9712,136512,4193,144713,143742,26057,157000,78316,16384,131153,93514,200846,221575,257,69731,131072,18240]

theorem envBound57773 : H12AffineFastState.Bounded env57773 := by
  intro p hp
  have h : env57773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57772_57773 : H12AffineEnvironment.transform 14 9712 env57772 = env57773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9712 env57772 == env57773) = true)

def env57774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,9712,65536,131072,69825,1024,9712,136512,4193,144713,143742,8329,139272,78316,1344,131153,75786,200846,206023,257,69731,131072,512]

theorem envBound57774 : H12AffineFastState.Bounded env57774 := by
  intro p hp
  have h : env57774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57773_57774 : H12AffineEnvironment.transform 13 1344 env57773 = env57774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env57773 == env57774) = true)

theorem identity57774 : scanCanonicalize (H12AffineFastState.compose env57774 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound57774 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,9712,65536,131072,67025,1024,9712,131152,1393,139353,140398,8329,139272,75004,1344,131153,75786,198046,206023,257,66931,131072,512]

theorem envBound57775 : H12AffineFastState.Bounded env57775 := by
  intro p hp
  have h : env57775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57774_57775 : H12AffineEnvironment.transform 11 1296 env57774 = env57775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env57774 == env57775) = true)

def env57776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,9712,65536,131072,69824,1024,9712,136512,4193,144713,143742,8328,139273,78316,1345,131153,75787,200846,206022,257,69731,131072,513]

theorem envBound57776 : H12AffineFastState.Bounded env57776 := by
  intro p hp
  have h : env57776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57773_57776 : H12AffineEnvironment.transform 13 1345 env57773 = env57776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env57773 == env57776) = true)

theorem identity57776 : scanCanonicalize (H12AffineFastState.compose env57776 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 12654) := by decide +kernel

theorem selectedBound57776 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,9712,12654,131072,8622,1024,9712,136512,4193,144713,143742,8328,139273,130,1345,131153,6501,139744,136616,257,8461,131072,513]

theorem envBound57777 : H12AffineFastState.Bounded env57777 := by
  intro p hp
  have h : env57777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57776_57777 : H12AffineEnvironment.transform 15 12654 env57776 = env57777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12654 env57776 == env57777) = true)

theorem identity57777 : scanCanonicalize (H12AffineFastState.compose env57777 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 8217) := by decide +kernel

theorem selectedBound57777 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env57778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,9712,12654,8217,8622,1024,9712,13657,4193,5456,4455,8328,16,130,1345,8264,6501,505,13745,257,8461,8217,513]

theorem envBound57778 : H12AffineFastState.Bounded env57778 := by
  intro p hp
  have h : env57778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57777_57778 : H12AffineEnvironment.transform 16 8217 env57777 = env57778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8217 env57777 == env57778) = true)

theorem identity57778 : scanCanonicalize (H12AffineFastState.compose env57778 (packedSelected [25] rootPS)) = affineNative (2^(12+1) ^^^ 421) := by decide +kernel

theorem selectedBound57778 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,1345,1109,4299,444,11,1024,1109,5372,4193,5456,4455,301,16,130,1345,493,6501,505,5140,257,168,444,513]

theorem envBound57779 : H12AffineFastState.Bounded env57779 := by
  intro p hp
  have h : env57779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57778_57779 : H12AffineEnvironment.transform 12 421 env57778 = env57779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 421 env57778 == env57779) = true)

theorem identity57779 : scanCanonicalize (H12AffineFastState.compose env57779 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 2634) := by decide +kernel

theorem selectedBound57779 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2634,421,1345,1109,2689,444,11,1024,1109,3766,2603,3866,2861,301,16,130,1345,493,815,505,3678,257,168,444,513]

theorem envBound57780 : H12AffineFastState.Bounded env57780 := by
  intro p hp
  have h : env57780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57779_57780 : H12AffineEnvironment.transform 11 2634 env57779 = env57780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2634 env57779 == env57780) = true)

theorem identity57780 : scanCanonicalize (H12AffineFastState.compose env57780 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1015) := by decide +kernel

theorem selectedBound57780 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env57781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1015,445,421,1345,1109,374,444,11,1024,1109,1345,476,1261,218,301,16,130,1345,493,815,505,1449,257,168,444,513]

theorem envBound57781 : H12AffineFastState.Bounded env57781 := by
  intro p hp
  have h : env57781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57780_57781 : H12AffineEnvironment.transform 10 1015 env57780 = env57781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1015 env57780 == env57781) = true)

theorem identity57781 : scanCanonicalize (H12AffineFastState.compose env57781 (packedSelected [1,4,5,9,10,13,20] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound57781 : packedSelected [1,4,5,9,10,13,20] rootPS < 2^1333 := by decide +kernel

def env57782 : List Nat := [2,4,8,16,32,64,128,256,512,256,1015,445,421,65,341,374,444,11,256,341,65,476,493,218,301,16,130,65,493,815,505,169,257,168,444,513]

theorem envBound57782 : H12AffineFastState.Bounded env57782 := by
  intro p hp
  have h : env57782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57781_57782 : H12AffineEnvironment.transform 9 256 env57781 = env57782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env57781 == env57782) = true)

theorem identity57782 : scanCanonicalize (H12AffineFastState.compose env57782 (packedSelected [0,1,3,4,7,9,13] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound57782 : packedSelected [0,1,3,4,7,9,13] rootPS < 2^1333 := by decide +kernel

def env57783 : List Nat := [2,4,8,16,32,64,128,256,217,256,302,445,421,65,341,374,444,11,256,341,65,476,493,218,301,16,130,65,493,502,505,169,257,168,444,216]

theorem envBound57783 : H12AffineFastState.Bounded env57783 := by
  intro p hp
  have h : env57783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57782_57783 : H12AffineEnvironment.transform 8 217 env57782 = env57783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env57782 == env57783) = true)

theorem identity57783 : scanCanonicalize (H12AffineFastState.compose env57783 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound57783 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env57784 : List Nat := [2,4,8,16,32,64,128,252,217,252,210,65,89,65,169,138,64,11,252,169,65,32,17,218,209,16,130,65,17,10,5,169,253,168,64,216]

theorem envBound57784 : H12AffineFastState.Bounded env57784 := by
  intro p hp
  have h : env57784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57783_57784 : H12AffineEnvironment.transform 7 252 env57783 = env57784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env57783 == env57784) = true)

theorem identity57784 : scanCanonicalize (H12AffineFastState.compose env57784 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound57784 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57785 : List Nat := [2,4,8,16,32,64,51,79,106,79,97,65,89,65,26,57,64,11,79,26,65,32,17,105,98,16,49,65,17,10,5,26,78,27,64,107]

theorem envBound57785 : H12AffineFastState.Bounded env57785 := by
  intro p hp
  have h : env57785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57784_57785 : H12AffineEnvironment.transform 6 51 env57784 = env57785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env57784 == env57785) = true)

theorem identity57785 : scanCanonicalize (H12AffineFastState.compose env57785 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound57785 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57786 : List Nat := [2,4,8,16,32,42,51,37,0,37,11,43,51,43,26,57,42,11,37,26,43,32,17,3,8,16,49,43,17,10,5,26,36,27,42,1]

theorem envBound57786 : H12AffineFastState.Bounded env57786 := by
  intro p hp
  have h : env57786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57785_57786 : H12AffineEnvironment.transform 5 42 env57785 = env57786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env57785 == env57786) = true)

theorem identity57786 : scanCanonicalize (H12AffineFastState.compose env57786 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 25) := by decide +kernel

theorem selectedBound57786 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57787 : List Nat := [2,4,8,16,25,19,10,28,0,28,11,18,10,18,26,0,19,11,28,26,18,25,17,3,8,16,8,18,17,10,5,26,29,27,19,1]

theorem envBound57787 : H12AffineFastState.Bounded env57787 := by
  intro p hp
  have h : env57787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57786_57787 : H12AffineEnvironment.transform 4 25 env57786 = env57787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 25 env57786 == env57787) = true)

theorem identity57787 : scanCanonicalize (H12AffineFastState.compose env57787 (packedSelected [2,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound57787 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env57788 : List Nat := [2,4,8,8,1,11,10,4,0,4,11,10,10,10,2,0,11,11,4,2,10,1,9,3,8,8,8,10,9,10,5,2,5,3,11,1]

theorem envBound57788 : H12AffineFastState.Bounded env57788 := by
  intro p hp
  have h : env57788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57787_57788 : H12AffineEnvironment.transform 3 8 env57787 = env57788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env57787 == env57788) = true)

theorem identity57788 : scanCanonicalize (H12AffineFastState.compose env57788 (packedSelected [2,7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound57788 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env57789 : List Nat := [1,4,8,8,1,8,9,4,0,4,8,9,9,9,1,0,8,8,4,1,9,1,9,0,8,8,8,9,9,9,5,1,5,0,8,1]

theorem envBound57789 : H12AffineFastState.Bounded env57789 := by
  intro p hp
  have h : env57789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57788_57789 : H12AffineEnvironment.transform 0 1 env57788 = env57789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env57788 == env57789) = true)

theorem identity57789 : scanCanonicalize (H12AffineFastState.compose env57789 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound57789 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57790 : List Nat := [1,4,1,1,1,1,0,4,0,4,1,0,0,0,1,0,1,1,4,1,0,1,0,0,1,1,1,0,0,0,5,1,5,0,1,1]

theorem envBound57790 : H12AffineFastState.Bounded env57790 := by
  intro p hp
  have h : env57790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57789_57790 : H12AffineEnvironment.transform 2 1 env57789 = env57790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env57789 == env57790) = true)

def env57791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136513,46480,144713,169102,26056,157000,311708,16384,131153,93515,200846,221575,257,69730,131072,18241]

theorem envBound57791 : H12AffineFastState.Bounded env57791 := by
  intro p hp
  have h : env57791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57751_57791 : H12AffineEnvironment.transform 20 136513 env57751 = env57791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136513 env57751 == env57791) = true)

def env57792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136513,46480,144713,169102,26056,157000,103452,16384,131153,93515,200846,221575,257,69730,131072,18241]

theorem envBound57792 : H12AffineFastState.Bounded env57792 := by
  intro p hp
  have h : env57792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57791_57792 : H12AffineEnvironment.transform 17 87424 env57791 = env57792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env57791 == env57792) = true)

theorem identity57792 : scanCanonicalize (H12AffineFastState.compose env57792 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 12513) := by decide +kernel

theorem selectedBound57792 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,12513,65536,131072,87424,1024,12513,136513,1393,144713,140399,26056,157000,75005,16384,131153,93515,200846,221575,257,69730,131072,18241]

theorem envBound57793 : H12AffineFastState.Bounded env57793 := by
  intro p hp
  have h : env57793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57792_57793 : H12AffineEnvironment.transform 14 12513 env57792 = env57793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12513 env57792 == env57793) = true)

def env57794 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,12513,65536,131072,69824,1024,12513,136513,1393,144713,140399,8328,139272,75005,1344,131153,75787,200846,206023,257,69730,131072,513]

theorem envBound57794 : H12AffineFastState.Bounded env57794 := by
  intro p hp
  have h : env57794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57793_57794 : H12AffineEnvironment.transform 13 1344 env57793 = env57794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env57793 == env57794) = true)

theorem identity57794 : scanCanonicalize (H12AffineFastState.compose env57794 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 9342) := by decide +kernel

theorem selectedBound57794 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,12513,9342,131072,13502,1024,12513,136513,1393,144713,140399,8328,139272,131,1344,131153,3189,144624,131257,257,13340,131072,513]

theorem envBound57795 : H12AffineFastState.Bounded env57795 := by
  intro p hp
  have h : env57795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57794_57795 : H12AffineEnvironment.transform 15 9342 env57794 = env57795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9342 env57794 == env57795) = true)

theorem identity57795 : scanCanonicalize (H12AffineFastState.compose env57795 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 8216) := by decide +kernel

theorem selectedBound57795 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env57796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,12513,9342,8216,13502,1024,12513,13657,1393,5457,1143,8328,16,131,1344,8265,3189,5352,8353,257,13340,8216,513]

theorem envBound57796 : H12AffineFastState.Bounded env57796 := by
  intro p hp
  have h : env57796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57795_57796 : H12AffineEnvironment.transform 16 8216 env57795 = env57796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8216 env57795 == env57796) = true)

theorem identity57796 : scanCanonicalize (H12AffineFastState.compose env57796 (packedSelected [25] rootPS)) = affineNative (2^(12+1) ^^^ 5300) := by decide +kernel

theorem selectedBound57796 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5300,1344,1109,4298,5292,10,1024,1109,493,1393,5457,1143,5180,16,131,1344,5373,3189,5352,5141,257,168,5292,513]

end H12CloudChart0