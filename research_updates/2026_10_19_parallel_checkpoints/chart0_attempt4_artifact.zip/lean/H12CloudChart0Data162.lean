import H12CloudChart0Data161

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env41066 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,3100,16384,32768,3094,16401,1077,1024,32769,51201,16644,16,36114,3100,16,17460,52481,40208,33844,1285,16644,256,36144,16385,513]

theorem envBound41066 : H12AffineFastState.Bounded env41066 := by
  intro p hp
  have h : env41066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41065_41066 : H12AffineEnvironment.transform 15 3094 env41065 = env41066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3094 env41065 == env41066) = true)

theorem identity41066 : scanCanonicalize (H12AffineFastState.compose env41066 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound41066 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41067 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,3100,4113,32768,3094,4096,1077,1024,32769,38928,4373,16,36114,3100,16,5157,40208,40208,33844,1285,4373,256,36144,4112,513]

theorem envBound41067 : H12AffineFastState.Bounded env41067 := by
  intro p hp
  have h : env41067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41066_41067 : H12AffineEnvironment.transform 13 4113 env41066 = env41067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env41066 == env41067) = true)

theorem identity41067 : scanCanonicalize (H12AffineFastState.compose env41067 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound41067 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env41068 : List Nat := [2,4,8,16,32,16,8,256,512,1024,0,4096,1052,4113,32768,1046,4096,1077,1024,32769,36880,4373,16,34066,1052,16,5157,38160,38160,33844,1285,4373,256,34096,4112,513]

theorem envBound41068 : H12AffineFastState.Bounded env41068 := by
  intro p hp
  have h : env41068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41067_41068 : H12AffineEnvironment.transform 10 0 env41067 = env41068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env41067 == env41068) = true)

theorem identity41068 : scanCanonicalize (H12AffineFastState.compose env41068 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound41068 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env41069 : List Nat := [2,4,8,16,32,16,8,256,512,1024,0,16,1052,1,32768,1046,16,1077,1024,32769,32768,261,16,34066,1052,16,1077,34048,34048,33844,1285,261,256,34096,0,513]

theorem envBound41069 : H12AffineFastState.Bounded env41069 := by
  intro p hp
  have h : env41069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41068_41069 : H12AffineEnvironment.transform 11 16 env41068 = env41069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env41068 == env41069) = true)

theorem identity41069 : scanCanonicalize (H12AffineFastState.compose env41069 (packedSelected [5,8] rootPS)) = affineNative (2^(14+1) ^^^ 1588) := by decide +kernel

theorem selectedBound41069 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env41070 : List Nat := [2,4,8,16,32,16,8,256,512,1024,0,16,1052,1,1588,1046,16,1077,1024,1589,1588,261,16,806,1052,16,1077,820,820,512,1285,261,256,772,0,513]

theorem envBound41070 : H12AffineFastState.Bounded env41070 := by
  intro p hp
  have h : env41070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41069_41070 : H12AffineEnvironment.transform 14 1588 env41069 = env41070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1588 env41069 == env41070) = true)

theorem identity41070 : scanCanonicalize (H12AffineFastState.compose env41070 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound41070 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41071 : List Nat := [2,4,8,16,32,16,8,256,0,1024,0,16,1052,1,1076,1046,16,1077,1024,1077,1076,261,16,294,1052,16,1077,308,308,0,1285,261,256,260,0,1]

theorem envBound41071 : H12AffineFastState.Bounded env41071 := by
  intro p hp
  have h : env41071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41070_41071 : H12AffineEnvironment.transform 8 0 env41070 = env41071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env41070 == env41071) = true)

theorem identity41071 : scanCanonicalize (H12AffineFastState.compose env41071 (packedSelected [1,2] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound41071 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env41072 : List Nat := [2,4,8,16,32,16,8,256,0,305,0,16,301,1,261,295,16,260,305,260,261,261,16,294,301,16,260,308,308,0,52,261,256,260,0,1]

theorem envBound41072 : H12AffineFastState.Bounded env41072 := by
  intro p hp
  have h : env41072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41071_41072 : H12AffineEnvironment.transform 9 305 env41071 = env41072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env41071 == env41072) = true)

theorem identity41072 : scanCanonicalize (H12AffineFastState.compose env41072 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41072 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41073 : List Nat := [2,4,8,16,1,16,8,256,0,272,0,16,268,1,261,262,16,260,272,260,261,261,16,263,268,16,260,277,277,0,21,261,256,260,0,1]

theorem envBound41073 : H12AffineFastState.Bounded env41073 := by
  intro p hp
  have h : env41073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41072_41073 : H12AffineEnvironment.transform 4 1 env41072 = env41073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41072 == env41073) = true)

theorem identity41073 : scanCanonicalize (H12AffineFastState.compose env41073 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound41073 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41074 : List Nat := [2,4,8,16,1,16,8,21,0,5,0,16,25,1,16,19,16,17,5,17,16,16,16,18,25,16,17,0,0,0,21,16,21,17,0,1]

theorem envBound41074 : H12AffineFastState.Bounded env41074 := by
  intro p hp
  have h : env41074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41073_41074 : H12AffineEnvironment.transform 7 21 env41073 = env41074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env41073 == env41074) = true)

theorem identity41074 : scanCanonicalize (H12AffineFastState.compose env41074 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound41074 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env41075 : List Nat := [2,4,8,0,1,0,8,5,0,5,0,0,9,1,0,3,0,1,5,1,0,0,0,2,9,0,1,0,0,0,5,0,5,1,0,1]

theorem envBound41075 : H12AffineFastState.Bounded env41075 := by
  intro p hp
  have h : env41075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41074_41075 : H12AffineEnvironment.transform 3 0 env41074 = env41075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env41074 == env41075) = true)

def env41076 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41231,8192,17,4677919,114966,45325,442384,75022,4268042,256,98599,90122,513]

theorem envBound41076 : H12AffineFastState.Bounded env41076 := by
  intro p hp
  have h : env41076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41055_41076 : H12AffineEnvironment.transform 5 17 env41055 = env41076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41055 == env41076) = true)

theorem identity41076 : scanCanonicalize (H12AffineFastState.compose env41076 (packedSelected [1,3,12,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound41076 : packedSelected [1,3,12,24,28,41] rootPS < 2^1333 := by decide +kernel

def env41077 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58397,4194304,16,41231,8192,17,4409655,114966,45325,190520,75022,4268042,256,98599,90122,513]

theorem envBound41077 : H12AffineFastState.Bounded env41077 := by
  intro p hp
  have h : env41077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41076_41077 : H12AffineEnvironment.transform 17 10280 env41076 = env41077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env41076 == env41077) = true)

theorem identity41077 : scanCanonicalize (H12AffineFastState.compose env41077 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound41077 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env41078 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,58397,4194304,16,41231,8192,17,4204844,114966,45325,100387,75022,4268042,256,98599,90122,513]

theorem envBound41078 : H12AffineFastState.Bounded env41078 := by
  intro p hp
  have h : env41078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41077_41078 : H12AffineEnvironment.transform 16 90139 env41077 = env41078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env41077 == env41078) = true)

theorem identity41078 : scanCanonicalize (H12AffineFastState.compose env41078 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound41078 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env41079 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,58397,32,16,41231,8192,17,10508,114966,45325,100387,75022,73770,256,98599,90122,513]

theorem envBound41079 : H12AffineFastState.Bounded env41079 := by
  intro p hp
  have h : env41079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41078_41079 : H12AffineEnvironment.transform 21 32 env41078 = env41079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env41078 == env41079) = true)

theorem identity41079 : scanCanonicalize (H12AffineFastState.compose env41079 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound41079 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env41080 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,0,65536,90139,10280,1024,1,25629,32,16,8463,8192,17,10508,82198,12557,67619,75022,73770,256,65831,90122,513]

theorem envBound41080 : H12AffineFastState.Bounded env41080 := by
  intro p hp
  have h : env41080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41079_41080 : H12AffineEnvironment.transform 14 0 env41079 = env41080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env41079 == env41080) = true)

theorem identity41080 : scanCanonicalize (H12AffineFastState.compose env41080 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound41080 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41081 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,0,8202,16401,10280,1024,1,25629,32,16,8463,8192,17,10508,24860,12557,10281,1284,32,256,8493,16384,513]

theorem envBound41081 : H12AffineFastState.Bounded env41081 := by
  intro p hp
  have h : env41081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41080_41081 : H12AffineEnvironment.transform 15 8202 env41080 = env41081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env41080 == env41081) = true)

theorem identity41081 : scanCanonicalize (H12AffineFastState.compose env41081 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound41081 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env41082 : List Nat := [2,4,8,16,32,17,8,256,512,1024,529,4096,8192,16384,0,8202,16401,8761,1024,1,25629,32,16,8463,8192,17,8989,24860,12557,8760,1284,32,256,8493,16384,513]

theorem envBound41082 : H12AffineFastState.Bounded env41082 := by
  intro p hp
  have h : env41082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41081_41082 : H12AffineEnvironment.transform 10 529 env41081 = env41082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env41081 == env41082) = true)

theorem identity41082 : scanCanonicalize (H12AffineFastState.compose env41082 (packedSelected [0,1,4,5,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 8460) := by decide +kernel

theorem selectedBound41082 : packedSelected [0,1,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env41083 : List Nat := [2,4,8,16,32,17,8,256,512,1024,529,4096,8192,8460,0,8202,8477,8761,1024,1,1297,32,16,8463,8192,17,8989,16,12557,8760,1284,32,256,8493,8460,513]

theorem envBound41083 : H12AffineFastState.Bounded env41083 := by
  intro p hp
  have h : env41083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41082_41083 : H12AffineEnvironment.transform 13 8460 env41082 = env41083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8460 env41082 == env41083) = true)

theorem identity41083 : scanCanonicalize (H12AffineFastState.compose env41083 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound41083 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env41084 : List Nat := [2,4,8,16,32,17,8,256,512,36,529,4096,8192,8460,0,8202,8477,8761,36,1,309,32,16,8463,8192,17,8989,16,12557,8760,288,32,256,8493,8460,513]

theorem envBound41084 : H12AffineFastState.Bounded env41084 := by
  intro p hp
  have h : env41084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41083_41084 : H12AffineEnvironment.transform 9 36 env41083 = env41084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env41083 == env41084) = true)

theorem identity41084 : scanCanonicalize (H12AffineFastState.compose env41084 (packedSelected [0,1,5,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound41084 : packedSelected [0,1,5,7,11] rootPS < 2^1333 := by decide +kernel

def env41085 : List Nat := [2,4,8,16,32,17,8,256,512,36,529,4096,268,0,0,262,17,821,36,1,309,32,16,3,268,17,529,16,4097,820,288,32,256,33,0,513]

theorem envBound41085 : H12AffineFastState.Bounded env41085 := by
  intro p hp
  have h : env41085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41084_41085 : H12AffineEnvironment.transform 12 268 env41084 = env41085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env41084 == env41085) = true)

theorem identity41085 : scanCanonicalize (H12AffineFastState.compose env41085 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound41085 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41086 : List Nat := [2,4,8,16,32,17,8,256,512,36,529,17,268,0,0,262,17,821,36,1,309,32,16,3,268,17,529,16,16,820,288,32,256,33,0,513]

theorem envBound41086 : H12AffineFastState.Bounded env41086 := by
  intro p hp
  have h : env41086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41085_41086 : H12AffineEnvironment.transform 11 17 env41085 = env41086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env41085 == env41086) = true)

theorem identity41086 : scanCanonicalize (H12AffineFastState.compose env41086 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound41086 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41087 : List Nat := [2,4,8,16,32,17,8,4,512,36,529,17,8,0,0,2,17,561,36,1,49,32,16,3,8,17,529,16,16,560,36,32,4,33,0,513]

theorem envBound41087 : H12AffineFastState.Bounded env41087 := by
  intro p hp
  have h : env41087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41086_41087 : H12AffineEnvironment.transform 7 4 env41086 = env41087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env41086 == env41087) = true)

theorem identity41087 : scanCanonicalize (H12AffineFastState.compose env41087 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound41087 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41088 : List Nat := [2,4,8,16,32,17,8,4,49,36,32,17,8,0,0,2,17,0,36,1,49,32,16,3,8,17,32,16,16,1,36,32,4,33,0,48]

theorem envBound41088 : H12AffineFastState.Bounded env41088 := by
  intro p hp
  have h : env41088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41087_41088 : H12AffineEnvironment.transform 8 49 env41087 = env41088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env41087 == env41088) = true)

theorem identity41088 : scanCanonicalize (H12AffineFastState.compose env41088 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41088 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env41089 : List Nat := [2,4,8,16,1,17,8,4,16,5,1,17,8,0,0,2,17,0,5,1,16,1,16,3,8,17,1,16,16,1,5,1,4,0,0,17]

theorem envBound41089 : H12AffineFastState.Bounded env41089 := by
  intro p hp
  have h : env41089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41088_41089 : H12AffineEnvironment.transform 4 1 env41088 = env41089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41088 == env41089) = true)

def env41090 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,17,41311,8192,64,4677966,2172251,2118976,442385,75103,6407190,256,2188651,2196550,513]

theorem envBound41090 : H12AffineFastState.Bounded env41090 := by
  intro p hp
  have h : env41090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41017_41090 : H12AffineEnvironment.transform 22 17 env41017 = env41090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env41017 == env41090) = true)

theorem identity41090 : scanCanonicalize (H12AffineFastState.compose env41090 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound41090 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env41091 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1024,32769,2097152,4194304,17,41311,8192,64,4456789,2172251,2118976,368650,75103,6407190,256,2188651,2196550,513]

theorem envBound41091 : H12AffineFastState.Bounded env41091 := by
  intro p hp
  have h : env41091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41090_41091 : H12AffineEnvironment.transform 16 90139 env41090 = env41091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env41090 == env41091) = true)

theorem identity41091 : scanCanonicalize (H12AffineFastState.compose env41091 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound41091 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env41092 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,57676,262144,1024,32769,2097152,4194304,17,41311,8192,64,4456789,2139148,2118976,270685,41992,6309185,256,2155580,2098449,513]

theorem envBound41092 : H12AffineFastState.Bounded env41092 := by
  intro p hp
  have h : env41092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41091_41092 : H12AffineEnvironment.transform 15 33111 env41091 = env41092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env41091 == env41092) = true)

theorem identity41092 : scanCanonicalize (H12AffineFastState.compose env41092 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound41092 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env41093 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,57676,10280,1024,32769,2097152,4194304,17,41311,8192,64,4204925,2139148,2118976,2421,41992,6309185,256,2155580,2098449,513]

theorem envBound41093 : H12AffineFastState.Bounded env41093 := by
  intro p hp
  have h : env41093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41092_41093 : H12AffineEnvironment.transform 17 10280 env41092 = env41093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env41092 == env41093) = true)

theorem identity41093 : scanCanonicalize (H12AffineFastState.compose env41093 (packedSelected [4,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound41093 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env41094 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,57676,10280,1024,32769,2097152,32,17,41311,8192,64,10589,2139148,2118976,2421,41992,2114913,256,2155580,2098449,513]

theorem envBound41094 : H12AffineFastState.Bounded env41094 := by
  intro p hp
  have h : env41094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41093_41094 : H12AffineEnvironment.transform 21 32 env41093 = env41094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env41093 == env41094) = true)

theorem identity41094 : scanCanonicalize (H12AffineFastState.compose env41094 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(20+1) ^^^ 25629) := by decide +kernel

theorem selectedBound41094 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env41095 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,57676,10280,1024,32769,25629,32,17,41311,8192,64,10589,49169,12637,2421,41992,8572,256,32801,24844,513]

theorem envBound41095 : H12AffineFastState.Bounded env41095 := by
  intro p hp
  have h : env41095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41094_41095 : H12AffineEnvironment.transform 20 25629 env41094 = env41095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25629 env41094 == env41095) = true)

theorem identity41095 : scanCanonicalize (H12AffineFastState.compose env41095 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound41095 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env41096 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,342,24909,10280,1024,0,25629,32,17,8542,8192,64,10589,16400,12637,2421,9225,8572,256,32,24844,513]

theorem envBound41096 : H12AffineFastState.Bounded env41096 := by
  intro p hp
  have h : env41096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41095_41096 : H12AffineEnvironment.transform 14 1 env41095 = env41096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env41095 == env41096) = true)

theorem identity41096 : scanCanonicalize (H12AffineFastState.compose env41096 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound41096 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41097 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1,342,16400,2421,1024,0,17728,32,17,3,349,64,2048,16400,4096,2421,1364,33,256,32,16465,513]

theorem envBound41097 : H12AffineFastState.Bounded env41097 := by
  intro p hp
  have h : env41097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41096_41097 : H12AffineEnvironment.transform 12 349 env41096 = env41097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env41096 == env41097) = true)

theorem identity41097 : scanCanonicalize (H12AffineFastState.compose env41097 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 5748) := by decide +kernel

theorem selectedBound41097 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41098 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5748,1,342,5732,2421,1024,0,4916,32,17,3,349,64,2048,5732,4096,2421,1364,33,256,32,5669,513]

theorem envBound41098 : H12AffineFastState.Bounded env41098 := by
  intro p hp
  have h : env41098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41097_41098 : H12AffineEnvironment.transform 13 5748 env41097 = env41098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5748 env41097 == env41098) = true)

def env41099 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8429902,8193,64,4677966,10560843,10507601,8830976,75103,14795782,256,2188650,2196550,512]

theorem envBound41099 : H12AffineFastState.Bounded env41099 := by
  intro p hp
  have h : env41099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41016_41099 : H12AffineEnvironment.transform 6 9 env41016 = env41099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41016 == env41099) = true)

theorem identity41099 : scanCanonicalize (H12AffineFastState.compose env41099 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 4235629) := by decide +kernel

theorem selectedBound41099 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env41100 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,4235629,4194339,8193,64,4677966,6390822,6353980,4612461,75103,2188651,256,2188650,2196550,512]

theorem envBound41100 : H12AffineFastState.Bounded env41100 := by
  intro p hp
  have h : env41100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41099_41100 : H12AffineEnvironment.transform 22 4235629 env41099 = env41100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235629 env41099 == env41100) = true)

theorem identity41100 : scanCanonicalize (H12AffineFastState.compose env41100 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(21+1) ^^^ 188780) := by decide +kernel

theorem selectedBound41100 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env41101 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,188780,147457,188751,8193,64,360482,2319690,2233680,294913,75103,2188651,256,2188650,2196550,512]

theorem envBound41101 : H12AffineFastState.Bounded env41101 := by
  intro p hp
  have h : env41101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41100_41101 : H12AffineEnvironment.transform 21 188780 env41100 = env41101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 188780 env41100 == env41101) = true)

theorem identity41101 : scanCanonicalize (H12AffineFastState.compose env41101 (packedSelected [1,5,8,11,17,18,19,21,23,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound41101 : packedSelected [1,5,8,11,17,18,19,21,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env41102 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,2097152,188780,147457,188751,8193,64,108554,2319690,2233680,43049,75103,2188651,256,2188650,2196550,512]

theorem envBound41102 : H12AffineFastState.Bounded env41102 := by
  intro p hp
  have h : env41102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41101_41102 : H12AffineEnvironment.transform 17 10280 env41101 = env41102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env41101 == env41102) = true)

theorem identity41102 : scanCanonicalize (H12AffineFastState.compose env41102 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound41102 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env41103 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,2097152,33,41292,2,8193,64,108554,2196487,2159645,43049,75103,2188651,256,2188650,2196550,512]

theorem envBound41103 : H12AffineFastState.Bounded env41103 := by
  intro p hp
  have h : env41103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41102_41103 : H12AffineEnvironment.transform 16 57677 env41102 = env41103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env41102 == env41103) = true)

theorem identity41103 : scanCanonicalize (H12AffineFastState.compose env41103 (packedSelected [0,3,4,5,7,9,10,12,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound41103 : packedSelected [0,3,4,5,7,9,10,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env41104 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,65536,49168,2421,1024,32769,2097152,33,32785,2,348,64,100695,2196487,2151744,35188,66562,2180150,256,2180151,2196550,512]

theorem envBound41104 : H12AffineFastState.Bounded env41104 := by
  intro p hp
  have h : env41104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41103_41104 : H12AffineEnvironment.transform 12 349 env41103 = env41104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env41103 == env41104) = true)

theorem identity41104 : scanCanonicalize (H12AffineFastState.compose env41104 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(20+1) ^^^ 50448) := by decide +kernel

theorem selectedBound41104 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env41105 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,65536,49168,2421,1024,32769,50448,33,32785,2,348,64,100695,82199,4176,35188,66562,98598,256,98599,82262,512]

theorem envBound41105 : H12AffineFastState.Bounded env41105 := by
  intro p hp
  have h : env41105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41104_41105 : H12AffineEnvironment.transform 20 50448 env41104 = env41105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50448 env41104 == env41105) = true)

theorem identity41105 : scanCanonicalize (H12AffineFastState.compose env41105 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound41105 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env41106 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,21510,49168,2421,1024,32769,50448,33,32785,2,348,64,56657,5393,4176,35188,20484,54560,256,54561,5456,512]

theorem envBound41106 : H12AffineFastState.Bounded env41106 := by
  intro p hp
  have h : env41106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41105_41106 : H12AffineEnvironment.transform 15 21510 env41105 = env41106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env41105 == env41106) = true)

theorem identity41106 : scanCanonicalize (H12AffineFastState.compose env41106 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5205) := by decide +kernel

theorem selectedBound41106 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env41107 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5205,32768,83,37957,2421,1024,32769,37189,33,32785,2,348,64,35076,5393,4176,35188,1105,33141,256,33140,5456,512]

theorem envBound41107 : H12AffineFastState.Bounded env41107 := by
  intro p hp
  have h : env41107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41106_41107 : H12AffineEnvironment.transform 13 5205 env41106 = env41107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5205 env41106 == env41107) = true)

theorem identity41107 : scanCanonicalize (H12AffineFastState.compose env41107 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound41107 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env41108 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,120,5205,32768,83,37957,2128,1024,32769,36960,33,32785,2,121,64,34849,5172,4176,34897,1105,32848,37,32849,5237,512]

theorem envBound41108 : H12AffineFastState.Bounded env41108 := by
  intro p hp
  have h : env41108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41107_41108 : H12AffineEnvironment.transform 7 37 env41107 = env41108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env41107 == env41108) = true)

theorem identity41108 : scanCanonicalize (H12AffineFastState.compose env41108 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound41108 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env41109 : List Nat := [2,4,8,16,32,48,9,37,512,1024,2048,4096,8,5157,32768,35,37941,2080,1024,32769,36880,33,32785,2,9,48,34849,5172,4128,34849,1057,32800,37,32801,5125,512]

theorem envBound41109 : H12AffineFastState.Bounded env41109 := by
  intro p hp
  have h : env41109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41108_41109 : H12AffineEnvironment.transform 5 48 env41108 = env41109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env41108 == env41109) = true)

theorem identity41109 : scanCanonicalize (H12AffineFastState.compose env41109 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41109 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env41110 : List Nat := [2,4,8,16,1,17,9,4,512,1024,2048,4096,8,5124,32768,2,37908,2049,1024,32769,36880,0,32785,2,9,17,34816,5141,4097,34816,1024,32769,4,32768,5125,512]

theorem envBound41110 : H12AffineFastState.Bounded env41110 := by
  intro p hp
  have h : env41110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41109_41110 : H12AffineEnvironment.transform 4 1 env41109 = env41110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41109 == env41110) = true)

theorem identity41110 : scanCanonicalize (H12AffineFastState.compose env41110 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound41110 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env41111 : List Nat := [2,4,8,16,1,17,9,4,512,1024,2048,4096,8,5124,0,2,5140,2049,1024,1,4112,0,17,2,9,17,2048,5141,4097,2048,1024,1,4,0,5125,512]

theorem envBound41111 : H12AffineFastState.Bounded env41111 := by
  intro p hp
  have h : env41111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41110_41111 : H12AffineEnvironment.transform 14 0 env41110 = env41111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env41110 == env41111) = true)

theorem identity41111 : scanCanonicalize (H12AffineFastState.compose env41111 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound41111 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41112 : List Nat := [2,4,8,16,1,17,9,4,512,1024,2048,1028,8,0,0,2,16,2049,1024,1,1044,0,17,2,9,17,2048,17,1029,2048,1024,1,4,0,1,512]

theorem envBound41112 : H12AffineFastState.Bounded env41112 := by
  intro p hp
  have h : env41112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41111_41112 : H12AffineEnvironment.transform 11 1028 env41111 = env41112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env41111 == env41112) = true)

theorem identity41112 : scanCanonicalize (H12AffineFastState.compose env41112 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound41112 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41113 : List Nat := [2,4,8,16,1,17,9,4,512,1024,16,1028,8,0,0,2,16,17,1024,1,1044,0,17,2,9,17,16,17,1029,16,1024,1,4,0,1,512]

theorem envBound41113 : H12AffineFastState.Bounded env41113 := by
  intro p hp
  have h : env41113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41112_41113 : H12AffineEnvironment.transform 10 16 env41112 = env41113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env41112 == env41113) = true)

def env41114 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830977,25265169,23160257,257,27378860,27337992,25207750]

theorem envBound41114 : H12AffineFastState.Bounded env41114 := by
  intro p hp
  have h : env41114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41014_41114 : H12AffineEnvironment.transform 18 1025 env41014 = env41114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env41014 == env41114) = true)

theorem identity41114 : scanCanonicalize (H12AffineFastState.compose env41114 (packedSelected [13] rootPS)) = affineNative (2^(16+1) ^^^ 82382) := by decide +kernel

theorem selectedBound41114 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env41115 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29655503,18973837,10507601,8749519,25265169,23160257,257,27378860,27337992,25207750]

theorem envBound41115 : H12AffineFastState.Bounded env41115 := by
  intro p hp
  have h : env41115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41114_41115 : H12AffineEnvironment.transform 16 82382 env41114 = env41115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82382 env41114 == env41115) = true)

def env41116 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,2097152,4194304,8388608,10588556,8328,64,6623299,8393985,10507601,8749519,2102685,12645453,257,21792,46212,2175562]

theorem envBound41116 : H12AffineFastState.Bounded env41116 := by
  intro p hp
  have h : env41116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41115_41116 : H12AffineEnvironment.transform 23 10588556 env41115 = env41116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588556 env41115 == env41116) = true)

def env41117 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6623299,2098513,17665,2462111,2102685,6349853,257,21792,46212,2175562]

theorem envBound41117 : H12AffineFastState.Bounded env41117 := by
  intro p hp
  have h : env41117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41116_41117 : H12AffineEnvironment.transform 22 2101328 env41116 = env41117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env41116 == env41117) = true)

def env41118 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2177219,2098513,17665,2462111,2102685,2411677,257,21792,46212,2175562]

theorem envBound41118 : H12AffineFastState.Bounded env41118 := by
  intro p hp
  have h : env41118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41117_41118 : H12AffineEnvironment.transform 21 272512 env41117 = env41118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env41117 == env41118) = true)

theorem identity41118 : scanCanonicalize (H12AffineFastState.compose env41118 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound41118 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41119 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,82382,262144,1025,29909,2097152,272512,2101328,95496,8328,64,2177219,2098513,17665,2450763,2102685,2373705,257,21792,16464,2175562]

theorem envBound41119 : H12AffineFastState.Bounded env41119 := by
  intro p hp
  have h : env41119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41118_41119 : H12AffineEnvironment.transform 14 29908 env41118 = env41119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env41118 == env41119) = true)

def env41120 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,82334,262144,1025,29829,2097152,272512,2101248,95496,8328,16,2177171,2098433,17665,2450715,2102685,2373657,257,21792,16384,2175514]

theorem envBound41120 : H12AffineFastState.Bounded env41120 := by
  intro p hp
  have h : env41120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41119_41120 : H12AffineEnvironment.transform 5 16 env41119 = env41120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41119 == env41120) = true)

theorem identity41120 : scanCanonicalize (H12AffineFastState.compose env41120 (packedSelected [4,5,7,8,9,11,16,19,20,24,27,28,31,32] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound41120 : packedSelected [4,5,7,8,9,11,16,19,20,24,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env41121 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,136,65536,79250,262144,1025,137,2097152,272512,2101248,65796,8328,16,2177171,2098433,12557,2429207,2102685,2373657,257,8492,13324,2175514]

theorem envBound41121 : H12AffineFastState.Bounded env41121 := by
  intro p hp
  have h : env41121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41120_41121 : H12AffineEnvironment.transform 13 13324 env41120 = env41121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env41120 == env41121) = true)

theorem identity41121 : scanCanonicalize (H12AffineFastState.compose env41121 (packedSelected [18,19,23,26] rootPS)) = affineNative (2^(20+1) ^^^ 268597) := by decide +kernel

theorem selectedBound41121 : packedSelected [18,19,23,26] rootPS < 2^1333 := by decide +kernel

def env41122 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,136,65536,79250,262144,1025,137,268597,272512,264501,65796,8328,16,336294,269364,12557,67618,265384,8492,257,8492,13324,338735]

theorem envBound41122 : H12AffineFastState.Bounded env41122 := by
  intro p hp
  have h : env41122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41121_41122 : H12AffineEnvironment.transform 20 268597 env41121 = env41122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 268597 env41121 == env41122) = true)

theorem identity41122 : scanCanonicalize (H12AffineFastState.compose env41122 (packedSelected [0,1,4,5,7,8,16,17,20,22,24] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound41122 : packedSelected [0,1,4,5,7,8,16,17,20,22,24] rootPS < 2^1333 := by decide +kernel

def env41123 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,136,8322,5392,262144,1025,137,268597,272512,264501,8582,8328,16,262436,269364,12557,10400,265384,8492,257,8492,13324,265133]

theorem envBound41123 : H12AffineFastState.Bounded env41123 := by
  intro p hp
  have h : env41123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41122_41123 : H12AffineEnvironment.transform 15 8322 env41122 = env41123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env41122 == env41123) = true)

theorem identity41123 : scanCanonicalize (H12AffineFastState.compose env41123 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound41123 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env41124 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,136,8322,5392,10281,1025,137,12572,169,8476,8582,8328,16,10509,13341,12557,10400,9345,8492,257,8492,13324,9092]

theorem envBound41124 : H12AffineFastState.Bounded env41124 := by
  intro p hp
  have h : env41124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41123_41124 : H12AffineEnvironment.transform 17 10281 env41123 = env41124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env41123 == env41124) = true)

theorem identity41124 : scanCanonicalize (H12AffineFastState.compose env41124 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound41124 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41125 : List Nat := [2,4,8,16,32,16,128,256,512,408,2048,4096,8192,12692,136,8322,4232,10281,409,137,12572,169,8476,8582,8328,16,10509,12677,12557,10400,8473,8492,257,8492,12692,9092]

theorem envBound41125 : H12AffineFastState.Bounded env41125 := by
  intro p hp
  have h : env41125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41124_41125 : H12AffineEnvironment.transform 9 408 env41124 = env41125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env41124 == env41125) = true)

theorem identity41125 : scanCanonicalize (H12AffineFastState.compose env41125 (packedSelected [0,4,7,9,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 2493) := by decide +kernel

theorem selectedBound41125 : packedSelected [0,4,7,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env41126 : List Nat := [2,4,8,16,32,16,128,256,512,408,2048,2493,8192,10281,136,8322,2357,10281,409,137,10401,169,8476,8582,8328,16,10509,10296,10416,10400,8473,8492,257,8492,10281,9092]

theorem envBound41126 : H12AffineFastState.Bounded env41126 := by
  intro p hp
  have h : env41126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41125_41126 : H12AffineEnvironment.transform 11 2493 env41125 = env41126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2493 env41125 == env41126) = true)

theorem identity41126 : scanCanonicalize (H12AffineFastState.compose env41126 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound41126 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env41127 : List Nat := [2,4,8,16,32,16,128,173,512,53,2048,2064,8192,10281,136,8322,2200,10281,52,137,10401,169,8369,8235,8328,16,10400,10296,10416,10400,8372,8321,172,8321,10281,8745]

theorem envBound41127 : H12AffineFastState.Bounded env41127 := by
  intro p hp
  have h : env41127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41126_41127 : H12AffineEnvironment.transform 7 173 env41126 = env41127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env41126 == env41127) = true)

theorem identity41127 : scanCanonicalize (H12AffineFastState.compose env41127 (packedSelected [0,2,4,6,9] rootPS)) = affineNative (2^(10+1) ^^^ 697) := by decide +kernel

theorem selectedBound41127 : packedSelected [0,2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env41128 : List Nat := [2,4,8,16,32,16,128,173,512,53,697,681,8192,8848,136,8322,545,8848,52,137,8728,169,8369,8235,8328,16,8729,8833,8713,8729,8372,8321,172,8321,8848,8745]

theorem envBound41128 : H12AffineFastState.Bounded env41128 := by
  intro p hp
  have h : env41128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41127_41128 : H12AffineEnvironment.transform 10 697 env41127 = env41128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 697 env41127 == env41128) = true)

theorem identity41128 : scanCanonicalize (H12AffineFastState.compose env41128 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound41128 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env41129 : List Nat := [2,4,8,16,32,16,128,173,512,53,697,681,9,665,136,139,545,665,52,137,529,169,184,34,129,16,528,648,512,528,189,136,172,136,665,544]

theorem envBound41129 : H12AffineFastState.Bounded env41129 := by
  intro p hp
  have h : env41129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41128_41129 : H12AffineEnvironment.transform 12 9 env41128 = env41129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env41128 == env41129) = true)

theorem identity41129 : scanCanonicalize (H12AffineFastState.compose env41129 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound41129 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env41130 : List Nat := [2,4,8,16,32,16,40,5,512,53,529,513,9,561,32,35,545,561,52,33,529,1,16,34,41,16,528,544,512,528,21,32,4,32,561,544]

theorem envBound41130 : H12AffineFastState.Bounded env41130 := by
  intro p hp
  have h : env41130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41129_41130 : H12AffineEnvironment.transform 6 40 env41129 = env41130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env41129 == env41130) = true)

theorem identity41130 : scanCanonicalize (H12AffineFastState.compose env41130 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41130 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41131 : List Nat := [2,4,8,16,0,16,8,5,512,21,529,513,9,529,0,3,513,529,20,1,529,1,16,2,9,16,528,512,512,528,21,0,4,0,529,512]

theorem envBound41131 : H12AffineFastState.Bounded env41131 := by
  intro p hp
  have h : env41131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41130_41131 : H12AffineEnvironment.transform 4 0 env41130 = env41131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41130 == env41131) = true)

theorem identity41131 : scanCanonicalize (H12AffineFastState.compose env41131 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound41131 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41132 : List Nat := [2,4,8,16,0,16,8,5,15,21,30,14,9,30,0,3,14,30,20,1,30,1,16,2,9,16,31,15,15,31,21,0,4,0,30,15]

theorem envBound41132 : H12AffineFastState.Bounded env41132 := by
  intro p hp
  have h : env41132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41131_41132 : H12AffineEnvironment.transform 8 15 env41131 = env41132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env41131 == env41132) = true)

def env41133 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,82335,262144,1025,29828,2097152,272512,2101249,95496,8328,17,2177170,2098432,17665,2450714,2102685,2373656,257,21792,16385,2175515]

theorem envBound41133 : H12AffineFastState.Bounded env41133 := by
  intro p hp
  have h : env41133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41119_41133 : H12AffineEnvironment.transform 5 17 env41119 = env41133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41119 == env41133) = true)

theorem identity41133 : scanCanonicalize (H12AffineFastState.compose env41133 (packedSelected [4,5,7,8,9,11,16,19,20,24,27,28,31,32] rootPS)) = affineNative (2^(20+1) ^^^ 70046) := by decide +kernel

theorem selectedBound41133 : packedSelected [4,5,7,8,9,11,16,19,20,24,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env41134 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,82335,262144,1025,29828,70046,272512,65951,95496,8328,17,10508,70814,17665,291972,66563,338310,257,21792,16385,9093]

theorem envBound41134 : H12AffineFastState.Bounded env41134 := by
  intro p hp
  have h : env41134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41133_41134 : H12AffineEnvironment.transform 20 70046 env41133 = env41134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 70046 env41133 == env41134) = true)

theorem identity41134 : scanCanonicalize (H12AffineFastState.compose env41134 (packedSelected [0,9,15,22,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 76079) := by decide +kernel

theorem selectedBound41134 : packedSelected [0,9,15,22,27,38] rootPS < 2^1333 := by decide +kernel

def env41135 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,82335,76079,1025,29828,70046,65967,65951,95496,8328,17,10508,70814,17665,89515,66563,169,257,21792,16385,9093]

theorem envBound41135 : H12AffineFastState.Bounded env41135 := by
  intro p hp
  have h : env41135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41134_41135 : H12AffineEnvironment.transform 17 76079 env41134 = env41135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76079 env41134 == env41135) = true)

theorem identity41135 : scanCanonicalize (H12AffineFastState.compose env41135 (packedSelected [3,10,17,19,24] rootPS)) = affineNative (2^(15+1) ^^^ 30082) := by decide +kernel

theorem selectedBound41135 : packedSelected [3,10,17,19,24] rootPS < 2^1333 := by decide +kernel

def env41136 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,30082,13341,23725,1025,29828,25628,29741,29725,138,8328,17,10508,24860,17665,10281,29057,169,257,21792,16385,9093]

theorem envBound41136 : H12AffineFastState.Bounded env41136 := by
  intro p hp
  have h : env41136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41135_41136 : H12AffineEnvironment.transform 15 30082 env41135 = env41136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30082 env41135 == env41136) = true)

theorem identity41136 : scanCanonicalize (H12AffineFastState.compose env41136 (packedSelected [10,12,14,15,19,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound41136 : packedSelected [10,12,14,15,19,20] rootPS < 2^1333 := by decide +kernel

def env41137 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,8192,16384,29076,28819,12556,22972,272,29077,24845,28988,28940,138,8328,17,10508,24860,16400,10281,29057,169,257,20529,16385,9093]

theorem envBound41137 : H12AffineFastState.Bounded env41137 := by
  intro p hp
  have h : env41137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41136_41137 : H12AffineEnvironment.transform 9 273 env41136 = env41137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env41136 == env41137) = true)

theorem identity41137 : scanCanonicalize (H12AffineFastState.compose env41137 (packedSelected [0,1,2,6,7,8,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound41137 : packedSelected [0,1,2,6,7,8,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env41138 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,389,16384,20497,20758,4233,22972,272,20496,16520,20665,20617,138,269,17,2185,16537,16400,2476,20484,169,257,20529,16385,512]

theorem envBound41138 : H12AffineFastState.Bounded env41138 := by
  intro p hp
  have h : env41138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41137_41138 : H12AffineEnvironment.transform 12 389 env41137 = env41138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env41137 == env41138) = true)

theorem identity41138 : scanCanonicalize (H12AffineFastState.compose env41138 (packedSelected [0,2,5,6,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 4541) := by decide +kernel

theorem selectedBound41138 : packedSelected [0,2,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env41139 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,389,4541,428,171,4233,2049,272,429,4405,260,308,138,269,17,2185,4388,4525,2476,441,169,257,396,4540,512]

theorem envBound41139 : H12AffineFastState.Bounded env41139 := by
  intro p hp
  have h : env41139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41138_41139 : H12AffineEnvironment.transform 13 4541 env41138 = env41139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4541 env41138 == env41139) = true)

theorem identity41139 : scanCanonicalize (H12AffineFastState.compose env41139 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound41139 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env41140 : List Nat := [2,4,8,16,32,17,128,5,512,20,2048,4096,128,4280,169,171,4233,2049,21,168,4144,1,49,138,8,17,2185,4129,4264,2217,188,169,4,137,4281,512]

theorem envBound41140 : H12AffineFastState.Bounded env41140 := by
  intro p hp
  have h : env41140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41139_41140 : H12AffineEnvironment.transform 7 5 env41139 = env41140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env41139 == env41140) = true)

theorem identity41140 : scanCanonicalize (H12AffineFastState.compose env41140 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound41140 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env41141 : List Nat := [2,4,8,16,32,17,40,5,512,20,2048,4096,40,4112,1,3,4129,2049,21,0,4144,1,49,34,8,17,2081,4129,4096,2049,20,1,4,33,4113,512]

theorem envBound41141 : H12AffineFastState.Bounded env41141 := by
  intro p hp
  have h : env41141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41140_41141 : H12AffineEnvironment.transform 6 40 env41140 = env41141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env41140 == env41141) = true)

theorem identity41141 : scanCanonicalize (H12AffineFastState.compose env41141 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 2591) := by decide +kernel

theorem selectedBound41141 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env41142 : List Nat := [2,4,8,16,32,17,40,5,512,20,2048,2591,40,2575,1,3,2622,2049,21,0,2607,1,49,34,8,17,2081,2622,2591,2049,20,1,4,33,2574,512]

theorem envBound41142 : H12AffineFastState.Bounded env41142 := by
  intro p hp
  have h : env41142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41141_41142 : H12AffineEnvironment.transform 11 2591 env41141 = env41142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2591 env41141 == env41142) = true)

theorem identity41142 : scanCanonicalize (H12AffineFastState.compose env41142 (packedSelected [0,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 47) := by decide +kernel

theorem selectedBound41142 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env41143 : List Nat := [2,4,8,16,32,17,40,5,47,20,2048,2096,40,2080,1,3,2065,2049,21,0,2048,1,49,34,8,17,2081,2065,2096,2049,20,1,4,33,2081,47]

theorem envBound41143 : H12AffineFastState.Bounded env41143 := by
  intro p hp
  have h : env41143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41142_41143 : H12AffineEnvironment.transform 8 47 env41142 = env41143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 47 env41142 == env41143) = true)

theorem identity41143 : scanCanonicalize (H12AffineFastState.compose env41143 (packedSelected [2,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41143 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env41144 : List Nat := [2,4,8,16,1,17,9,5,14,20,2048,2065,9,2049,1,3,2065,2049,21,0,2048,1,16,3,8,17,2048,2065,2065,2049,20,1,4,0,2048,14]

theorem envBound41144 : H12AffineFastState.Bounded env41144 := by
  intro p hp
  have h : env41144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41143_41144 : H12AffineEnvironment.transform 4 1 env41143 = env41144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41143 == env41144) = true)

def env41145 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2177218,2098513,17665,2462111,2102685,2411676,257,21792,46212,2175562]

theorem envBound41145 : H12AffineFastState.Bounded env41145 := by
  intro p hp
  have h : env41145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41117_41145 : H12AffineEnvironment.transform 21 272513 env41117 = env41145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env41117 == env41145) = true)

theorem identity41145 : scanCanonicalize (H12AffineFastState.compose env41145 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58517) := by decide +kernel

theorem selectedBound41145 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41146 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,58517,272513,62661,98780,8328,64,121943,57796,17665,357642,61704,272393,257,21792,46212,120543]

theorem envBound41146 : H12AffineFastState.Bounded env41146 := by
  intro p hp
  have h : env41146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41145_41146 : H12AffineEnvironment.transform 20 58517 env41145 = env41146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58517 env41145 == env41146) = true)

def env41147 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,10280,1025,32769,58517,169,62661,98780,8328,64,121943,57796,17665,89378,61704,33,257,21792,46212,120543]

theorem envBound41147 : H12AffineFastState.Bounded env41147 := by
  intro p hp
  have h : env41147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41146_41147 : H12AffineEnvironment.transform 17 10280 env41146 = env41147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env41146 == env41147) = true)

theorem identity41147 : scanCanonicalize (H12AffineFastState.compose env41147 (packedSelected [0,2,3,4,6,8,9,10,17,20,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound41147 : packedSelected [0,2,3,4,6,8,9,10,17,20,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env41148 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,82382,10280,1025,8661,17729,169,21777,73736,8328,64,97667,16400,17665,89378,20700,33,257,21792,5456,96011]

theorem envBound41148 : H12AffineFastState.Bounded env41148 := by
  intro p hp
  have h : env41148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41147_41148 : H12AffineEnvironment.transform 14 8660 env41147 = env41148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env41147 == env41148) = true)

theorem identity41148 : scanCanonicalize (H12AffineFastState.compose env41148 (packedSelected [16,19,20,26] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound41148 : packedSelected [16,19,20,26] rootPS < 2^1333 := by decide +kernel

def env41149 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8323,24909,10280,1025,8661,17729,169,21777,139,8328,64,23808,16400,17665,32161,20700,33,257,21792,5456,22408]

theorem envBound41149 : H12AffineFastState.Bounded env41149 := by
  intro p hp
  have h : env41149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41148_41149 : H12AffineEnvironment.transform 15 8323 env41148 = env41149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env41148 == env41149) = true)

theorem identity41149 : scanCanonicalize (H12AffineFastState.compose env41149 (packedSelected [1,8,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound41149 : packedSelected [1,8,17,19] rootPS < 2^1333 := by decide +kernel

def env41150 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8660,8323,13508,10280,1025,8661,4296,169,152,139,8328,64,2185,5529,4232,10280,1365,33,257,169,5456,513]

theorem envBound41150 : H12AffineFastState.Bounded env41150 := by
  intro p hp
  have h : env41150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41149_41150 : H12AffineEnvironment.transform 13 5513 env41149 = env41150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env41149 == env41150) = true)

theorem identity41150 : scanCanonicalize (H12AffineFastState.compose env41150 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound41150 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41151 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8202,13389,10280,1025,8540,4161,32,17,2,8193,64,2048,5392,4097,10280,1365,33,257,32,5456,513]

theorem envBound41151 : H12AffineFastState.Bounded env41151 := by
  intro p hp
  have h : env41151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41150_41151 : H12AffineEnvironment.transform 6 9 env41150 = env41151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41150 == env41151) = true)

theorem identity41151 : scanCanonicalize (H12AffineFastState.compose env41151 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound41151 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41152 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,81,262,5441,2340,1025,80,4161,32,17,2,269,64,2048,5392,4097,2340,1365,33,257,32,5456,513]

theorem envBound41152 : H12AffineFastState.Bounded env41152 := by
  intro p hp
  have h : env41152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41151_41152 : H12AffineEnvironment.transform 12 268 env41151 = env41152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env41151 == env41152) = true)

theorem identity41152 : scanCanonicalize (H12AffineFastState.compose env41152 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 804) := by decide +kernel

theorem selectedBound41152 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env41153 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,804,268,1572,81,262,1637,2340,1025,80,869,32,17,2,269,64,2048,1588,805,2340,1365,33,257,32,1652,513]

theorem envBound41153 : H12AffineFastState.Bounded env41153 := by
  intro p hp
  have h : env41153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41152_41153 : H12AffineEnvironment.transform 11 804 env41152 = env41153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 804 env41152 == env41153) = true)

theorem identity41153 : scanCanonicalize (H12AffineFastState.compose env41153 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41153 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env41154 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,772,268,1540,81,262,1605,2308,1025,80,837,0,17,2,269,64,2048,1556,773,2308,1365,1,257,0,1620,513]

theorem envBound41154 : H12AffineFastState.Bounded env41154 := by
  intro p hp
  have h : env41154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41153_41154 : H12AffineEnvironment.transform 4 0 env41153 = env41154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41153 == env41154) = true)

theorem identity41154 : scanCanonicalize (H12AffineFastState.compose env41154 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 340) := by decide +kernel

theorem selectedBound41154 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env41155 : List Nat := [2,4,8,16,0,64,9,256,340,1024,2048,80,268,1360,81,262,1297,2308,1025,80,17,0,17,2,269,64,2048,1344,81,2308,1365,1,257,0,1280,341]

theorem envBound41155 : H12AffineFastState.Bounded env41155 := by
  intro p hp
  have h : env41155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41154_41155 : H12AffineEnvironment.transform 8 340 env41154 = env41155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env41154 == env41155) = true)

theorem identity41155 : scanCanonicalize (H12AffineFastState.compose env41155 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound41155 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env41156 : List Nat := [2,4,8,16,0,64,9,256,340,20,2048,80,268,324,81,262,261,2308,21,80,17,0,17,2,269,64,2048,340,81,2308,321,1,257,0,276,341]

theorem envBound41156 : H12AffineFastState.Bounded env41156 := by
  intro p hp
  have h : env41156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41155_41156 : H12AffineEnvironment.transform 9 20 env41155 = env41156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env41155 == env41156) = true)

def env41157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,10281,1025,32769,58517,168,62661,98780,8328,64,121943,57796,17665,89379,61704,32,257,21792,46212,120543]

theorem envBound41157 : H12AffineFastState.Bounded env41157 := by
  intro p hp
  have h : env41157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41146_41157 : H12AffineEnvironment.transform 17 10281 env41146 = env41157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env41146 == env41157) = true)

theorem identity41157 : scanCanonicalize (H12AffineFastState.compose env41157 (packedSelected [0,2,3,4,6,8,9,10,17,20,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound41157 : packedSelected [0,2,3,4,6,8,9,10,17,20,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env41158 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,4096,8192,16384,32768,65536,82382,10281,236,32769,57464,168,61480,98780,8328,64,121018,57796,16876,88526,61704,32,257,20941,45161,119346]

theorem envBound41158 : H12AffineFastState.Bounded env41158 := by
  intro p hp
  have h : env41158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41157_41158 : H12AffineEnvironment.transform 9 237 env41157 = env41158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env41157 == env41158) = true)

theorem identity41158 : scanCanonicalize (H12AffineFastState.compose env41158 (packedSelected [1,3,5,15,26,28,38] rootPS)) = affineNative (2^(13+1) ^^^ 4296) := by decide +kernel

theorem selectedBound41158 : packedSelected [1,3,5,15,26,28,38] rootPS < 2^1333 := by decide +kernel

def env41159 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,4096,8192,4296,32768,65536,69894,10281,236,32769,45232,168,41184,98780,8328,64,100466,45324,4388,67846,41408,32,257,261,45161,99066]

theorem envBound41159 : H12AffineFastState.Bounded env41159 := by
  intro p hp
  have h : env41159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41158_41159 : H12AffineEnvironment.transform 13 4296 env41158 = env41159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4296 env41158 == env41159) = true)

theorem identity41159 : scanCanonicalize (H12AffineFastState.compose env41159 (packedSelected [2,4,6,10,11,12,15,16,19,22,23,26,31] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound41159 : packedSelected [2,4,6,10,11,12,15,16,19,22,23,26,31] rootPS < 2^1333 := by decide +kernel

def env41160 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,4096,160,4296,32768,65536,69894,2185,236,32769,36880,168,32832,98780,40,64,100466,37292,4388,67846,33120,32,257,261,37065,99066]

theorem envBound41160 : H12AffineFastState.Bounded env41160 := by
  intro p hp
  have h : env41160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41159_41160 : H12AffineEnvironment.transform 12 160 env41159 = env41160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env41159 == env41160) = true)

theorem identity41160 : scanCanonicalize (H12AffineFastState.compose env41160 (packedSelected [0,1,2,3,5,6,7,8,10,17,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound41160 : packedSelected [0,1,2,3,5,6,7,8,10,17,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env41161 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,4096,160,4296,32768,343,4177,2185,236,32769,36880,168,32832,32907,40,64,35109,37292,4388,2129,33120,32,257,261,37065,33709]

theorem envBound41161 : H12AffineFastState.Bounded env41161 := by
  intro p hp
  have h : env41161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41160_41161 : H12AffineEnvironment.transform 15 343 env41160 = env41161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env41160 == env41161) = true)

theorem identity41161 : scanCanonicalize (H12AffineFastState.compose env41161 (packedSelected [3,5,10,11,12,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 428) := by decide +kernel

theorem selectedBound41161 : packedSelected [3,5,10,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env41162 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,4096,160,4296,428,343,4177,2185,236,429,4540,168,492,295,40,64,2185,4096,4388,2129,204,32,257,261,4453,513]

theorem envBound41162 : H12AffineFastState.Bounded env41162 := by
  intro p hp
  have h : env41162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41161_41162 : H12AffineEnvironment.transform 14 428 env41161 = env41162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 428 env41161 == env41162) = true)

theorem identity41162 : scanCanonicalize (H12AffineFastState.compose env41162 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound41162 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41163 : List Nat := [2,4,8,16,32,64,128,36,512,237,2048,4096,160,4296,136,115,4177,2185,236,137,4248,168,200,3,40,64,2185,4096,4096,2129,204,32,37,33,4161,513]

theorem envBound41163 : H12AffineFastState.Bounded env41163 := by
  intro p hp
  have h : env41163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41162_41163 : H12AffineEnvironment.transform 7 36 env41162 = env41163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env41162 == env41163) = true)

theorem identity41163 : scanCanonicalize (H12AffineFastState.compose env41163 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound41163 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41164 : List Nat := [2,4,8,16,32,64,89,36,512,52,2048,4096,121,4113,81,115,4177,2128,53,80,4161,113,17,3,40,64,2128,4096,4096,2129,21,32,37,33,4161,513]

theorem envBound41164 : H12AffineFastState.Bounded env41164 := by
  intro p hp
  have h : env41164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41163_41164 : H12AffineEnvironment.transform 6 89 env41163 = env41164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env41163 == env41164) = true)

theorem identity41164 : scanCanonicalize (H12AffineFastState.compose env41164 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 593) := by decide +kernel

theorem selectedBound41164 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env41165 : List Nat := [2,4,8,16,32,64,89,36,512,52,2048,593,121,576,81,115,512,2128,53,80,528,113,17,3,40,64,2128,593,593,2129,21,32,37,33,528,513]

theorem envBound41165 : H12AffineFastState.Bounded env41165 := by
  intro p hp
  have h : env41165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41164_41165 : H12AffineEnvironment.transform 11 593 env41164 = env41165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 593 env41164 == env41165) = true)

theorem identity41165 : scanCanonicalize (H12AffineFastState.compose env41165 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound41165 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env41166 : List Nat := [2,4,8,16,32,49,40,36,512,52,2048,544,8,561,32,2,512,2081,53,33,528,0,17,3,40,49,2081,544,544,2080,21,32,37,33,528,513]

theorem envBound41166 : H12AffineFastState.Bounded env41166 := by
  intro p hp
  have h : env41166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41165_41166 : H12AffineEnvironment.transform 5 49 env41165 = env41166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env41165 == env41166) = true)

theorem identity41166 : scanCanonicalize (H12AffineFastState.compose env41166 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound41166 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41167 : List Nat := [2,4,8,16,32,49,40,36,512,52,16,544,8,561,32,2,512,49,53,33,528,0,17,3,40,49,49,544,544,48,21,32,37,33,528,513]

theorem envBound41167 : H12AffineFastState.Bounded env41167 := by
  intro p hp
  have h : env41167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41166_41167 : H12AffineEnvironment.transform 10 16 env41166 = env41167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env41166 == env41167) = true)

theorem identity41167 : scanCanonicalize (H12AffineFastState.compose env41167 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound41167 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env41168 : List Nat := [2,4,8,16,32,49,40,36,1,52,16,33,8,48,32,2,1,49,53,33,17,0,17,3,40,49,49,33,33,48,21,32,37,33,17,0]

theorem envBound41168 : H12AffineFastState.Bounded env41168 := by
  intro p hp
  have h : env41168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41167_41168 : H12AffineEnvironment.transform 8 1 env41167 = env41168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env41167 == env41168) = true)

def env41169 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6623299,2098512,17664,2462110,2102685,6349852,257,21792,46212,2175562]

theorem envBound41169 : H12AffineFastState.Bounded env41169 := by
  intro p hp
  have h : env41169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41116_41169 : H12AffineEnvironment.transform 22 2101329 env41116 = env41169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env41116 == env41169) = true)

def env41170 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2177219,2098512,17664,2462110,2102685,2411676,257,21792,46212,2175562]

theorem envBound41170 : H12AffineFastState.Bounded env41170 := by
  intro p hp
  have h : env41170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41169_41170 : H12AffineEnvironment.transform 21 272512 env41169 = env41170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env41169 == env41170) = true)

def env41171 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,272392,2101329,98645,8192,64,2177099,2098512,17664,2461974,2102549,2411540,257,21792,46092,2175562]

theorem envBound41171 : H12AffineFastState.Bounded env41171 := by
  intro p hp
  have h : env41171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41170_41171 : H12AffineEnvironment.transform 6 8 env41170 = env41171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41170 == env41171) = true)

theorem identity41171 : scanCanonicalize (H12AffineFastState.compose env41171 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 12572) := by decide +kernel

theorem selectedBound41171 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env41172 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,12572,272392,8525,98645,8192,64,67927,13388,17664,368650,9225,326920,257,21792,46092,66390]

theorem envBound41172 : H12AffineFastState.Bounded env41172 := by
  intro p hp
  have h : env41172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41171_41172 : H12AffineEnvironment.transform 20 12572 env41171 = env41172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12572 env41171 == env41172) = true)

theorem identity41172 : scanCanonicalize (H12AffineFastState.compose env41172 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound41172 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env41173 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40970,57676,262144,1025,32769,12572,272392,8525,8543,8192,64,43357,13388,17664,262144,9225,326920,257,21792,46092,41820]

theorem envBound41173 : H12AffineFastState.Bounded env41173 := by
  intro p hp
  have h : env41173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41172_41173 : H12AffineEnvironment.transform 15 40970 env41172 = env41173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env41172 == env41173) = true)

theorem identity41173 : scanCanonicalize (H12AffineFastState.compose env41173 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound41173 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env41174 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40970,57676,43048,1025,32769,12572,32800,8525,8543,8192,64,43357,13388,17664,43048,9225,21792,257,21792,46092,41820]

theorem envBound41174 : H12AffineFastState.Bounded env41174 := by
  intro p hp
  have h : env41174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41173_41174 : H12AffineEnvironment.transform 17 43048 env41173 = env41174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env41173 == env41174) = true)

theorem identity41174 : scanCanonicalize (H12AffineFastState.compose env41174 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound41174 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env41175 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,33111,49169,35189,1025,32769,4161,32800,16,2,349,64,34816,5393,17664,35189,1364,21792,257,21792,38225,33281]

theorem envBound41175 : H12AffineFastState.Bounded env41175 := by
  intro p hp
  have h : env41175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41174_41175 : H12AffineEnvironment.transform 12 349 env41174 = env41175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env41174 == env41175) = true)

theorem identity41175 : scanCanonicalize (H12AffineFastState.compose env41175 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21541) := by decide +kernel

theorem selectedBound41175 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env41176 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21541,21874,5172,23888,1025,21540,4161,21509,16,2,349,64,23589,5393,17664,23888,1364,21792,257,21792,16756,22052]

theorem envBound41176 : H12AffineFastState.Bounded env41176 := by
  intro p hp
  have h : env41176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41175_41176 : H12AffineEnvironment.transform 14 21541 env41175 = env41176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21541 env41175 == env41176) = true)

theorem identity41176 : scanCanonicalize (H12AffineFastState.compose env41176 (packedSelected [0,1,3,5,6,7,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound41176 : packedSelected [0,1,3,5,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env41177 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1280,349,16384,16677,16498,308,18512,1025,16676,1345,16645,16,2,349,64,18725,17,17664,18512,1364,16416,257,16416,16756,17188]

theorem envBound41177 : H12AffineFastState.Bounded env41177 := by
  intro p hp
  have h : env41177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41176_41177 : H12AffineEnvironment.transform 11 1280 env41176 = env41177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env41176 == env41177) = true)

theorem identity41177 : scanCanonicalize (H12AffineFastState.compose env41177 (packedSelected [0,1,7,8,10] rootPS)) = affineNative (2^(13+1) ^^^ 292) := by decide +kernel

theorem selectedBound41177 : packedSelected [0,1,7,8,10] rootPS < 2^1333 := by decide +kernel

def env41178 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1280,349,292,1,342,308,2420,1025,0,1345,33,16,2,349,64,2049,17,1060,2420,1364,260,257,260,80,512]

theorem envBound41178 : H12AffineFastState.Bounded env41178 := by
  intro p hp
  have h : env41178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41177_41178 : H12AffineEnvironment.transform 13 292 env41177 = env41178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 292 env41177 == env41178) = true)

theorem identity41178 : scanCanonicalize (H12AffineFastState.compose env41178 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 885) := by decide +kernel

theorem selectedBound41178 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41179 : List Nat := [2,4,8,16,32,64,8,256,512,1024,885,1280,349,292,1,342,308,513,1025,0,1345,33,16,2,349,64,884,17,1060,513,1364,260,257,260,80,512]

theorem envBound41179 : H12AffineFastState.Bounded env41179 := by
  intro p hp
  have h : env41179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41178_41179 : H12AffineEnvironment.transform 10 885 env41178 = env41179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 885 env41178 == env41179) = true)

theorem identity41179 : scanCanonicalize (H12AffineFastState.compose env41179 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound41179 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41180 : List Nat := [2,4,8,16,32,49,8,256,512,1024,772,1280,300,292,1,295,308,513,1025,0,1328,33,16,2,300,49,773,17,1060,513,1317,260,257,260,33,512]

theorem envBound41180 : H12AffineFastState.Bounded env41180 := by
  intro p hp
  have h : env41180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41179_41180 : H12AffineEnvironment.transform 5 49 env41179 = env41180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env41179 == env41180) = true)

theorem identity41180 : scanCanonicalize (H12AffineFastState.compose env41180 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound41180 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env41181 : List Nat := [2,4,8,16,32,49,8,256,512,565,772,821,300,292,1,295,308,513,564,0,773,33,16,2,300,49,773,17,529,513,784,260,257,260,33,512]

theorem envBound41181 : H12AffineFastState.Bounded env41181 := by
  intro p hp
  have h : env41181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41180_41181 : H12AffineEnvironment.transform 9 565 env41180 = env41181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env41180 == env41181) = true)

theorem identity41181 : scanCanonicalize (H12AffineFastState.compose env41181 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound41181 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env41182 : List Nat := [2,4,8,11,32,42,8,256,512,558,772,814,300,292,1,295,303,513,559,0,773,33,11,2,300,42,773,10,522,513,779,260,257,260,33,512]

theorem envBound41182 : H12AffineFastState.Bounded env41182 := by
  intro p hp
  have h : env41182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41181_41182 : H12AffineEnvironment.transform 3 11 env41181 = env41182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env41181 == env41182) = true)

theorem identity41182 : scanCanonicalize (H12AffineFastState.compose env41182 (packedSelected [2,3,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound41182 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env41183 : List Nat := [2,4,8,11,32,42,8,256,1,47,261,303,300,292,1,295,303,0,46,0,260,33,11,2,300,42,260,10,11,0,266,260,257,260,33,1]

theorem envBound41183 : H12AffineFastState.Bounded env41183 := by
  intro p hp
  have h : env41183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41182_41183 : H12AffineEnvironment.transform 8 1 env41182 = env41183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env41182 == env41183) = true)

theorem identity41183 : scanCanonicalize (H12AffineFastState.compose env41183 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound41183 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env41184 : List Nat := [2,4,8,11,11,1,8,256,1,4,261,260,263,271,1,268,260,0,5,0,260,10,11,2,263,1,260,10,11,0,266,260,257,260,10,1]

theorem envBound41184 : H12AffineFastState.Bounded env41184 := by
  intro p hp
  have h : env41184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41183_41184 : H12AffineEnvironment.transform 4 11 env41183 = env41184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env41183 == env41184) = true)

theorem identity41184 : scanCanonicalize (H12AffineFastState.compose env41184 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound41184 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env41185 : List Nat := [2,4,1,2,2,1,1,256,1,4,261,260,263,262,1,261,260,0,5,0,260,3,2,2,263,1,260,3,2,0,259,260,257,260,3,1]

theorem envBound41185 : H12AffineFastState.Bounded env41185 := by
  intro p hp
  have h : env41185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41184_41185 : H12AffineEnvironment.transform 2 1 env41184 = env41185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env41184 == env41185) = true)

theorem identity41185 : scanCanonicalize (H12AffineFastState.compose env41185 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound41185 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env41186 : List Nat := [2,4,1,2,2,1,1,3,1,4,6,7,4,5,1,6,7,0,5,0,7,3,2,2,4,1,7,3,2,0,0,7,2,7,3,1]

theorem envBound41186 : H12AffineFastState.Bounded env41186 := by
  intro p hp
  have h : env41186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41185_41186 : H12AffineEnvironment.transform 7 3 env41185 = env41186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env41185 == env41186) = true)

theorem identity41186 : scanCanonicalize (H12AffineFastState.compose env41186 (packedSelected [9] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound41186 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env41187 : List Nat := [0,4,1,0,0,1,1,1,1,4,4,5,4,5,1,4,5,0,5,0,5,1,0,0,4,1,5,1,0,0,0,5,0,5,1,1]

theorem envBound41187 : H12AffineFastState.Bounded env41187 := by
  intro p hp
  have h : env41187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41186_41187 : H12AffineEnvironment.transform 0 0 env41186 = env41187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env41186 == env41187) = true)

def env41188 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,272393,2101329,98644,8193,64,2177098,2098512,17664,2461975,2102548,2411541,257,21792,46093,2175562]

theorem envBound41188 : H12AffineFastState.Bounded env41188 := by
  intro p hp
  have h : env41188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41170_41188 : H12AffineEnvironment.transform 6 9 env41170 = env41188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41170 == env41188) = true)

def env41189 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,4160,272393,17,98644,8193,64,75786,5392,17664,360791,1364,318549,257,21792,46093,74250]

theorem envBound41189 : H12AffineFastState.Bounded env41189 := by
  intro p hp
  have h : env41189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41188_41189 : H12AffineEnvironment.transform 20 4160 env41188 = env41189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env41188 == env41189) = true)

theorem identity41189 : scanCanonicalize (H12AffineFastState.compose env41189 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound41189 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41190 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10280,1025,32769,4160,33,17,98644,8193,64,75786,5392,17664,108927,1364,62589,257,21792,46093,74250]

theorem envBound41190 : H12AffineFastState.Bounded env41190 := by
  intro p hp
  have h : env41190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41189_41190 : H12AffineEnvironment.transform 17 10280 env41189 = env41190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env41189 == env41190) = true)

theorem identity41190 : scanCanonicalize (H12AffineFastState.compose env41190 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound41190 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env41191 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,65536,82247,2420,1025,32769,4160,33,17,98644,349,64,67926,5392,17664,100387,1364,54561,257,21792,38225,66390]

theorem envBound41191 : H12AffineFastState.Bounded env41191 := by
  intro p hp
  have h : env41191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41190_41191 : H12AffineEnvironment.transform 12 348 env41190 = env41191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env41190 == env41191) = true)

theorem identity41191 : scanCanonicalize (H12AffineFastState.compose env41191 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound41191 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env41192 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,343,16400,2420,1025,32769,4160,33,17,32771,349,64,2049,5392,17664,35188,1364,54561,257,21792,38225,513]

theorem envBound41192 : H12AffineFastState.Bounded env41192 := by
  intro p hp
  have h : env41192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41191_41192 : H12AffineEnvironment.transform 15 343 env41191 = env41192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env41191 == env41192) = true)

theorem identity41192 : scanCanonicalize (H12AffineFastState.compose env41192 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound41192 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env41193 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,343,16400,2420,1025,21760,4160,33,17,21762,349,64,2049,5392,17664,23669,1364,32,257,21792,16464,513]

theorem envBound41193 : H12AffineFastState.Bounded env41193 := by
  intro p hp
  have h : env41193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41192_41193 : H12AffineEnvironment.transform 14 21761 env41192 = env41193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env41192 == env41193) = true)

theorem identity41193 : scanCanonicalize (H12AffineFastState.compose env41193 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound41193 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env41194 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,21761,263,16400,2340,1025,21760,4112,33,17,21762,269,16,2049,5392,17664,23589,1284,32,257,21792,16384,513]

theorem envBound41194 : H12AffineFastState.Bounded env41194 := by
  intro p hp
  have h : env41194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41193_41194 : H12AffineEnvironment.transform 5 16 env41193 = env41194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41193 == env41194) = true)

theorem identity41194 : scanCanonicalize (H12AffineFastState.compose env41194 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound41194 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env41195 : List Nat := [2,4,8,16,32,16,9,256,309,1024,2048,4096,268,16384,21761,263,16400,2340,1025,21760,4112,33,17,21762,269,16,2049,5392,17664,23589,1284,32,257,21792,16384,308]

theorem envBound41195 : H12AffineFastState.Bounded env41195 := by
  intro p hp
  have h : env41195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41194_41195 : H12AffineEnvironment.transform 8 309 env41194 = env41195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env41194 == env41195) = true)

theorem identity41195 : scanCanonicalize (H12AffineFastState.compose env41195 (packedSelected [2,5,8] rootPS)) = affineNative (2^(13+1) ^^^ 2308) := by decide +kernel

theorem selectedBound41195 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env41196 : List Nat := [2,4,8,16,32,16,9,256,309,1024,2048,4096,268,2308,7173,263,2324,2340,1025,7172,4112,33,17,7174,269,16,2049,5392,3076,5409,1284,32,257,7204,2308,308]

theorem envBound41196 : H12AffineFastState.Bounded env41196 := by
  intro p hp
  have h : env41196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41195_41196 : H12AffineEnvironment.transform 13 2308 env41195 = env41196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2308 env41195 == env41196) = true)

theorem identity41196 : scanCanonicalize (H12AffineFastState.compose env41196 (packedSelected [0,2,9] rootPS)) = affineNative (2^(10+1) ^^^ 1029) := by decide +kernel

theorem selectedBound41196 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env41197 : List Nat := [2,4,8,16,32,16,9,256,309,1024,1029,4096,268,1281,4096,263,1297,1313,1025,4097,4112,33,17,4099,269,16,1028,5392,1,5409,1284,32,257,4129,1281,308]

theorem envBound41197 : H12AffineFastState.Bounded env41197 := by
  intro p hp
  have h : env41197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41196_41197 : H12AffineEnvironment.transform 10 1029 env41196 = env41197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1029 env41196 == env41197) = true)

theorem identity41197 : scanCanonicalize (H12AffineFastState.compose env41197 (packedSelected [1,2,3,15] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound41197 : packedSelected [1,2,3,15] rootPS < 2^1333 := by decide +kernel

def env41198 : List Nat := [2,4,8,16,32,16,9,256,309,1024,1029,0,268,1281,0,263,1297,1313,1025,1,16,33,17,3,269,16,1028,1296,1,1313,1284,32,257,33,1281,308]

theorem envBound41198 : H12AffineFastState.Bounded env41198 := by
  intro p hp
  have h : env41198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41197_41198 : H12AffineEnvironment.transform 11 0 env41197 = env41198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env41197 == env41198) = true)

theorem identity41198 : scanCanonicalize (H12AffineFastState.compose env41198 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound41198 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41199 : List Nat := [2,4,8,16,32,16,9,21,32,1024,1029,0,25,1044,0,18,1028,1076,1025,1,16,33,17,3,24,16,1028,1029,1,1076,1041,32,20,33,1044,33]

theorem envBound41199 : H12AffineFastState.Bounded env41199 := by
  intro p hp
  have h : env41199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41198_41199 : H12AffineEnvironment.transform 7 21 env41198 = env41199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env41198 == env41199) = true)

theorem identity41199 : scanCanonicalize (H12AffineFastState.compose env41199 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound41199 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41200 : List Nat := [2,4,8,16,32,16,9,21,32,21,16,0,25,1,0,18,17,33,20,1,16,33,17,3,24,16,17,16,1,33,4,32,20,33,1,33]

theorem envBound41200 : H12AffineFastState.Bounded env41200 := by
  intro p hp
  have h : env41200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41199_41200 : H12AffineEnvironment.transform 9 21 env41199 = env41200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env41199 == env41200) = true)

theorem identity41200 : scanCanonicalize (H12AffineFastState.compose env41200 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound41200 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41201 : List Nat := [2,4,8,1,32,1,9,4,32,4,1,0,8,1,0,3,0,33,5,1,1,33,0,3,9,1,0,1,1,33,4,32,5,33,1,33]

theorem envBound41201 : H12AffineFastState.Bounded env41201 := by
  intro p hp
  have h : env41201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41200_41201 : H12AffineEnvironment.transform 3 1 env41200 = env41201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env41200 == env41201) = true)

theorem identity41201 : scanCanonicalize (H12AffineFastState.compose env41201 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41201 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env41202 : List Nat := [2,4,8,1,0,1,9,4,0,4,1,0,8,1,0,3,0,1,5,1,1,1,0,3,9,1,0,1,1,1,4,0,5,1,1,1]

theorem envBound41202 : H12AffineFastState.Bounded env41202 := by
  intro p hp
  have h : env41202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41201_41202 : H12AffineEnvironment.transform 4 0 env41201 = env41202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41201 == env41202) = true)

def env41203 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,4161,272393,16,98644,8193,64,75787,5393,17664,360790,1365,318548,257,21792,46093,74251]

theorem envBound41203 : H12AffineFastState.Bounded env41203 := by
  intro p hp
  have h : env41203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41188_41203 : H12AffineEnvironment.transform 20 4161 env41188 = env41203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env41188 == env41203) = true)

theorem identity41203 : scanCanonicalize (H12AffineFastState.compose env41203 (packedSelected [0,1,3,4,7,10,11,16,19,20,22,24,26,28,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 56356) := by decide +kernel

theorem selectedBound41203 : packedSelected [0,1,3,4,7,10,11,16,19,20,22,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env41204 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,56356,1025,32769,4161,62509,16,98644,8193,64,75787,5393,17664,89458,1365,112,257,21792,46093,74251]

theorem envBound41204 : H12AffineFastState.Bounded env41204 := by
  intro p hp
  have h : env41204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41203_41204 : H12AffineEnvironment.transform 17 56356 env41203 = env41204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56356 env41203 == env41204) = true)

theorem identity41204 : scanCanonicalize (H12AffineFastState.compose env41204 (packedSelected [1,4,7,9,16,19,20,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 62811) := by decide +kernel

theorem selectedBound41204 : packedSelected [1,4,7,9,16,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env41205 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62811,46108,56356,1025,32769,4161,62509,16,29711,8193,64,56656,5393,17664,43049,1365,112,257,21792,46093,55120]

theorem envBound41205 : H12AffineFastState.Bounded env41205 := by
  intro p hp
  have h : env41205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41204_41205 : H12AffineEnvironment.transform 15 62811 env41204 = env41205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62811 env41204 == env41205) = true)

theorem identity41205 : scanCanonicalize (H12AffineFastState.compose env41205 (packedSelected [3,10,16,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound41205 : packedSelected [3,10,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env41206 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21841,8202,24909,2421,1025,21840,4161,8572,16,29711,8193,64,2049,5393,17664,32120,1365,112,257,21792,24924,513]

theorem envBound41206 : H12AffineFastState.Bounded env41206 := by
  intro p hp
  have h : env41206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41205_41206 : H12AffineEnvironment.transform 14 21841 env41205 = env41206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env41205 == env41206) = true)

theorem identity41206 : scanCanonicalize (H12AffineFastState.compose env41206 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound41206 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env41207 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21841,342,16401,2421,1025,21840,4161,32,16,21843,349,64,2049,5393,17664,23588,1365,112,257,21792,16384,513]

theorem envBound41207 : H12AffineFastState.Bounded env41207 := by
  intro p hp
  have h : env41207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41206_41207 : H12AffineEnvironment.transform 12 348 env41206 = env41207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env41206 == env41207) = true)

theorem identity41207 : scanCanonicalize (H12AffineFastState.compose env41207 (packedSelected [3,4,6,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound41207 : packedSelected [3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env41208 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2356,348,16384,19557,342,16401,2421,1025,19556,2421,32,16,19559,349,64,2049,3109,17664,17680,1365,112,257,19476,16384,513]

theorem envBound41208 : H12AffineFastState.Bounded env41208 := by
  intro p hp
  have h : env41208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41207_41208 : H12AffineEnvironment.transform 11 2356 env41207 = env41208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env41207 == env41208) = true)

theorem identity41208 : scanCanonicalize (H12AffineFastState.compose env41208 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound41208 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env41209 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,2356,348,16384,18512,342,16401,2421,52,18513,2421,32,16,18514,349,64,2049,2064,16693,16677,352,112,257,18465,16384,513]

theorem envBound41209 : H12AffineFastState.Bounded env41209 := by
  intro p hp
  have h : env41209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41208_41209 : H12AffineEnvironment.transform 9 53 env41208 = env41209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env41208 == env41209) = true)

theorem identity41209 : scanCanonicalize (H12AffineFastState.compose env41209 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 2341) := by decide +kernel

theorem selectedBound41209 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41210 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,2356,348,2341,373,342,2356,2421,52,372,2421,32,16,375,349,64,2049,2064,2064,2048,352,112,257,260,2341,513]

theorem envBound41210 : H12AffineFastState.Bounded env41210 := by
  intro p hp
  have h : env41210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41209_41210 : H12AffineEnvironment.transform 13 2341 env41209 = env41210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2341 env41209 == env41210) = true)

theorem identity41210 : scanCanonicalize (H12AffineFastState.compose env41210 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound41210 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env41211 : List Nat := [2,4,8,16,32,64,9,256,512,53,292,16,348,1,373,342,16,81,52,372,81,32,16,375,349,64,293,308,308,292,352,112,257,260,1,513]

theorem envBound41211 : H12AffineFastState.Bounded env41211 := by
  intro p hp
  have h : env41211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41210_41211 : H12AffineEnvironment.transform 10 292 env41210 = env41211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env41210 == env41211) = true)

theorem identity41211 : scanCanonicalize (H12AffineFastState.compose env41211 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound41211 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41212 : List Nat := [2,4,8,16,32,64,9,37,512,53,1,16,121,1,80,115,16,81,52,81,81,32,16,82,120,64,0,17,17,1,69,112,36,33,1,513]

theorem envBound41212 : H12AffineFastState.Bounded env41212 := by
  intro p hp
  have h : env41212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41211_41212 : H12AffineEnvironment.transform 7 37 env41211 = env41212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env41211 == env41212) = true)

theorem identity41212 : scanCanonicalize (H12AffineFastState.compose env41212 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound41212 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env41213 : List Nat := [2,4,8,16,32,64,9,37,10,53,1,16,121,1,80,115,16,81,52,81,81,32,16,82,120,64,0,17,17,1,69,112,36,33,1,11]

theorem envBound41213 : H12AffineFastState.Bounded env41213 := by
  intro p hp
  have h : env41213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41212_41213 : H12AffineEnvironment.transform 8 10 env41212 = env41213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env41212 == env41213) = true)

def env41214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2177218,2098512,17664,2462110,2102685,2411677,257,21792,46212,2175562]

theorem envBound41214 : H12AffineFastState.Bounded env41214 := by
  intro p hp
  have h : env41214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41169_41214 : H12AffineEnvironment.transform 21 272513 env41169 = env41214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env41169 == env41214) = true)

theorem identity41214 : scanCanonicalize (H12AffineFastState.compose env41214 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound41214 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41215 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,4160,272513,17,98781,8328,64,75906,5392,17664,360926,1501,318685,257,21792,46212,74250]

theorem envBound41215 : H12AffineFastState.Bounded env41215 := by
  intro p hp
  have h : env41215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41214_41215 : H12AffineEnvironment.transform 20 4160 env41214 = env41215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env41214 == env41215) = true)

theorem identity41215 : scanCanonicalize (H12AffineFastState.compose env41215 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound41215 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env41216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,25029,262144,1025,32769,4160,272513,17,41430,8328,64,2185,5392,17664,303573,1501,318685,257,21792,46212,513]

theorem envBound41216 : H12AffineFastState.Bounded env41216 := by
  intro p hp
  have h : env41216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41215_41216 : H12AffineEnvironment.transform 15 8203 env41215 = env41216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env41215 == env41216) = true)

theorem identity41216 : scanCanonicalize (H12AffineFastState.compose env41216 (packedSelected [3,4,9,10,14,17,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound41216 : packedSelected [3,4,9,10,14,17,20,24,26] rootPS < 2^1333 := by decide +kernel

def env41217 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8203,25029,262144,1025,8541,4160,272513,17,138,8328,64,2185,5392,17664,262281,1501,294273,257,21792,5592,513]

theorem envBound41217 : H12AffineFastState.Bounded env41217 := by
  intro p hp
  have h : env41217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41216_41217 : H12AffineEnvironment.transform 14 8540 env41216 = env41217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env41216 == env41217) = true)

theorem identity41217 : scanCanonicalize (H12AffineFastState.compose env41217 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound41217 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41218 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8203,25029,10280,1025,8541,4160,169,17,138,8328,64,2185,5392,17664,10401,1501,21929,257,21792,5592,513]

theorem envBound41218 : H12AffineFastState.Bounded env41218 := by
  intro p hp
  have h : env41218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41217_41218 : H12AffineEnvironment.transform 17 10280 env41217 = env41218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env41217 == env41218) = true)

theorem identity41218 : scanCanonicalize (H12AffineFastState.compose env41218 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound41218 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41219 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,8203,13389,10280,1025,8541,4160,169,17,138,8328,64,2185,5392,4232,10401,1501,33,257,168,5592,513]

theorem envBound41219 : H12AffineFastState.Bounded env41219 := by
  intro p hp
  have h : env41219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41218_41219 : H12AffineEnvironment.transform 13 5512 env41218 = env41219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env41218 == env41219) = true)

theorem identity41219 : scanCanonicalize (H12AffineFastState.compose env41219 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound41219 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env41220 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,160,5512,508,171,5357,2184,1025,509,4160,169,17,138,40,64,2185,5392,4232,2049,1501,33,257,168,5592,513]

theorem envBound41220 : H12AffineFastState.Bounded env41220 := by
  intro p hp
  have h : env41220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41219_41220 : H12AffineEnvironment.transform 12 160 env41219 = env41220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env41219 == env41220) = true)

theorem identity41220 : scanCanonicalize (H12AffineFastState.compose env41220 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound41220 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env41221 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5377,373,34,5220,2049,1025,372,4160,32,17,3,40,64,2048,5392,4097,2049,1364,33,257,33,5457,513]

theorem envBound41221 : H12AffineFastState.Bounded env41221 := by
  intro p hp
  have h : env41221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41220_41221 : H12AffineEnvironment.transform 6 9 env41220 = env41221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41220 == env41221) = true)

theorem identity41221 : scanCanonicalize (H12AffineFastState.compose env41221 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound41221 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41222 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,41,5237,1,34,5220,2049,1025,0,4160,32,17,3,40,64,2048,5220,4097,2049,1056,33,117,33,5157,513]

theorem envBound41222 : H12AffineFastState.Bounded env41222 := by
  intro p hp
  have h : env41222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41221_41222 : H12AffineEnvironment.transform 7 116 env41221 = env41222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env41221 == env41222) = true)

theorem identity41222 : scanCanonicalize (H12AffineFastState.compose env41222 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1134) := by decide +kernel

theorem selectedBound41222 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41223 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1134,4096,41,5237,1,34,5220,1135,1025,0,4160,32,17,3,40,64,1134,5220,4097,1135,1056,33,117,33,5157,513]

theorem envBound41223 : H12AffineFastState.Bounded env41223 := by
  intro p hp
  have h : env41223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41222_41223 : H12AffineEnvironment.transform 10 1134 env41222 = env41223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1134 env41222 == env41223) = true)

theorem identity41223 : scanCanonicalize (H12AffineFastState.compose env41223 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound41223 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env41224 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1134,0,41,1141,1,34,1124,1135,1025,0,64,32,17,3,40,64,1134,1124,1,1135,1056,33,117,33,1061,513]

theorem envBound41224 : H12AffineFastState.Bounded env41224 := by
  intro p hp
  have h : env41224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41223_41224 : H12AffineEnvironment.transform 11 0 env41223 = env41224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env41223 == env41224) = true)

theorem identity41224 : scanCanonicalize (H12AffineFastState.compose env41224 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 62) := by decide +kernel

theorem selectedBound41224 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env41225 : List Nat := [2,4,8,16,32,64,9,116,512,62,80,0,41,75,1,34,90,81,63,0,64,32,17,3,40,64,80,90,1,81,30,33,117,33,27,513]

theorem envBound41225 : H12AffineFastState.Bounded env41225 := by
  intro p hp
  have h : env41225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41224_41225 : H12AffineEnvironment.transform 9 62 env41224 = env41225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 62 env41224 == env41225) = true)

theorem identity41225 : scanCanonicalize (H12AffineFastState.compose env41225 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound41225 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env41226 : List Nat := [2,4,8,16,32,58,9,14,512,62,42,0,41,49,1,34,32,43,63,0,58,32,17,3,40,58,42,32,1,43,30,33,15,33,27,513]

theorem envBound41226 : H12AffineFastState.Bounded env41226 := by
  intro p hp
  have h : env41226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41225_41226 : H12AffineEnvironment.transform 5 58 env41225 = env41226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env41225 == env41226) = true)

theorem identity41226 : scanCanonicalize (H12AffineFastState.compose env41226 (packedSelected [2,11] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound41226 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env41227 : List Nat := [2,4,8,16,10,16,9,14,512,20,0,0,3,27,1,8,10,1,21,0,16,10,17,3,2,16,0,10,1,1,30,11,15,11,27,513]

theorem envBound41227 : H12AffineFastState.Bounded env41227 := by
  intro p hp
  have h : env41227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41226_41227 : H12AffineEnvironment.transform 4 10 env41226 = env41227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env41226 == env41227) = true)

theorem identity41227 : scanCanonicalize (H12AffineFastState.compose env41227 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound41227 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41228 : List Nat := [2,4,8,1,10,1,9,14,512,5,0,0,3,10,1,8,10,1,4,0,1,10,0,3,2,1,0,10,1,1,15,11,15,11,10,513]

theorem envBound41228 : H12AffineFastState.Bounded env41228 := by
  intro p hp
  have h : env41228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41227_41228 : H12AffineEnvironment.transform 3 1 env41227 = env41228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env41227 == env41228) = true)

theorem identity41228 : scanCanonicalize (H12AffineFastState.compose env41228 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound41228 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41229 : List Nat := [2,4,6,1,4,1,7,0,512,5,0,0,3,4,1,6,4,1,4,0,1,4,0,3,2,1,0,4,1,1,1,5,1,5,4,513]

theorem envBound41229 : H12AffineFastState.Bounded env41229 := by
  intro p hp
  have h : env41229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41228_41229 : H12AffineEnvironment.transform 2 6 env41228 = env41229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env41228 == env41229) = true)

theorem identity41229 : scanCanonicalize (H12AffineFastState.compose env41229 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound41229 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env41230 : List Nat := [2,0,2,1,0,1,3,0,512,1,0,0,3,0,1,2,0,1,0,0,1,0,0,3,2,1,0,0,1,1,1,1,1,1,0,513]

theorem envBound41230 : H12AffineFastState.Bounded env41230 := by
  intro p hp
  have h : env41230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41229_41230 : H12AffineEnvironment.transform 1 0 env41229 = env41230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env41229 == env41230) = true)

theorem identity41230 : scanCanonicalize (H12AffineFastState.compose env41230 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound41230 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41231 : List Nat := [2,0,2,1,0,1,3,0,3,1,0,0,3,0,1,2,0,1,0,0,1,0,0,3,2,1,0,0,1,1,1,1,1,1,0,2]

theorem envBound41231 : H12AffineFastState.Bounded env41231 := by
  intro p hp
  have h : env41231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41230_41231 : H12AffineEnvironment.transform 8 3 env41230 = env41231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env41230 == env41231) = true)

def env41232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,2097152,4194304,8388608,10588557,8328,64,6623298,8393984,10507601,8749519,2102684,12645452,257,21793,46213,2175563]

theorem envBound41232 : H12AffineFastState.Bounded env41232 := by
  intro p hp
  have h : env41232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41115_41232 : H12AffineEnvironment.transform 23 10588557 env41115 = env41232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588557 env41115 == env41232) = true)

def env41233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6623298,2098512,17665,2462111,2102684,6349852,257,21793,46213,2175563]

theorem envBound41233 : H12AffineFastState.Bounded env41233 := by
  intro p hp
  have h : env41233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41232_41233 : H12AffineEnvironment.transform 22 2101328 env41232 = env41233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env41232 == env41233) = true)

def env41234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2177218,2098512,17665,2462111,2102684,2411676,257,21793,46213,2175563]

theorem envBound41234 : H12AffineFastState.Bounded env41234 := by
  intro p hp
  have h : env41234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41233_41234 : H12AffineEnvironment.transform 21 272512 env41233 = env41234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env41233 == env41234) = true)

theorem identity41234 : scanCanonicalize (H12AffineFastState.compose env41234 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound41234 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41235 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,77898,272512,73754,98781,8328,64,2184,79130,17665,303573,75222,392406,257,21793,46213,513]

theorem envBound41235 : H12AffineFastState.Bounded env41235 := by
  intro p hp
  have h : env41235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41234_41235 : H12AffineEnvironment.transform 20 77898 env41234 = env41235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env41234 == env41235) = true)

def env41236 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,77898,272392,73754,98645,8192,64,2048,79130,17665,303453,75102,392286,257,21793,46093,513]

theorem envBound41236 : H12AffineFastState.Bounded env41236 := by
  intro p hp
  have h : env41236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41235_41236 : H12AffineEnvironment.transform 6 8 env41235 = env41236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41235 == env41236) = true)

theorem identity41236 : scanCanonicalize (H12AffineFastState.compose env41236 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound41236 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env41237 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,82246,262144,1025,32769,69911,264533,65863,98645,349,64,2048,70727,17665,294912,66563,384259,257,21793,38224,513]

theorem envBound41237 : H12AffineFastState.Bounded env41237 := by
  intro p hp
  have h : env41237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41236_41237 : H12AffineEnvironment.transform 12 349 env41236 = env41237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env41236 == env41237) = true)

theorem identity41237 : scanCanonicalize (H12AffineFastState.compose env41237 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound41237 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env41238 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,82246,35189,1025,32769,69911,32800,65863,98645,349,64,2048,70727,17665,2421,66563,87158,257,21793,38224,513]

theorem envBound41238 : H12AffineFastState.Bounded env41238 := by
  intro p hp
  have h : env41238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41237_41238 : H12AffineEnvironment.transform 17 35189 env41237 = env41238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env41237 == env41238) = true)

theorem identity41238 : scanCanonicalize (H12AffineFastState.compose env41238 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound41238 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41239 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,32768,65536,70727,35189,1025,32769,69911,32800,65863,98645,349,64,2048,70727,4096,2421,66563,65911,257,32,38224,513]

theorem envBound41239 : H12AffineFastState.Bounded env41239 := by
  intro p hp
  have h : env41239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41238_41239 : H12AffineEnvironment.transform 13 5377 env41238 = env41239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env41238 == env41239) = true)

theorem identity41239 : scanCanonicalize (H12AffineFastState.compose env41239 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1296) := by decide +kernel

theorem selectedBound41239 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env41240 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1296,65536,70727,3173,1025,1297,69911,1328,65863,66629,349,64,2048,70727,4096,2421,66563,65911,257,32,4160,513]

theorem envBound41240 : H12AffineFastState.Bounded env41240 := by
  intro p hp
  have h : env41240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41239_41240 : H12AffineEnvironment.transform 14 1296 env41239 = env41240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1296 env41239 == env41240) = true)

theorem identity41240 : scanCanonicalize (H12AffineFastState.compose env41240 (packedSelected [12,15] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound41240 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env41241 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1296,34,5221,3173,1025,1297,4405,1328,357,1127,349,64,2048,5221,4096,2421,1057,341,257,32,4160,513]

theorem envBound41241 : H12AffineFastState.Bounded env41241 := by
  intro p hp
  have h : env41241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41240_41241 : H12AffineEnvironment.transform 15 34 env41240 = env41241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env41240 == env41241) = true)

def env41242 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,77898,272393,73754,98644,8193,64,2049,79130,17665,303452,75103,392287,257,21793,46092,513]

theorem envBound41242 : H12AffineFastState.Bounded env41242 := by
  intro p hp
  have h : env41242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41235_41242 : H12AffineEnvironment.transform 6 9 env41235 = env41242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41235 == env41242) = true)

theorem identity41242 : scanCanonicalize (H12AffineFastState.compose env41242 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound41242 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env41243 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,67619,1025,32769,77898,73770,73754,98644,8193,64,2049,79130,17665,108927,75103,62588,257,21793,46092,513]

theorem envBound41243 : H12AffineFastState.Bounded env41243 := by
  intro p hp
  have h : env41243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41242_41243 : H12AffineEnvironment.transform 17 67619 env41242 = env41243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env41242 == env41243) = true)

theorem identity41243 : scanCanonicalize (H12AffineFastState.compose env41243 (packedSelected [1,2,3,4,6,7,8,9,10,12,15,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound41243 : packedSelected [1,2,3,4,6,7,8,9,10,12,15,24,27] rootPS < 2^1333 := by decide +kernel

def env41244 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,32768,65536,79178,67619,1025,32769,77898,73770,73754,98644,8193,64,2049,79130,12556,108927,75103,32881,257,8492,46092,513]

theorem envBound41244 : H12AffineFastState.Bounded env41244 := by
  intro p hp
  have h : env41244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41243_41244 : H12AffineEnvironment.transform 13 13325 env41243 = env41244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env41243 == env41244) = true)

theorem identity41244 : scanCanonicalize (H12AffineFastState.compose env41244 (packedSelected [0,1,2,6,7,8,12,15,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound41244 : packedSelected [0,1,2,6,7,8,12,15,16,19] rootPS < 2^1333 := by decide +kernel

def env41245 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5456,32768,65536,70679,67619,1025,32769,69911,65911,65863,98644,348,64,2049,70727,4177,100386,66562,32881,257,113,38225,513]

theorem envBound41245 : H12AffineFastState.Bounded env41245 := by
  intro p hp
  have h : env41245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41244_41245 : H12AffineEnvironment.transform 12 349 env41244 = env41245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env41244 == env41245) = true)

theorem identity41245 : scanCanonicalize (H12AffineFastState.compose env41245 (packedSelected [1,2,6,8,10,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound41245 : packedSelected [1,2,6,8,10,12,14] rootPS < 2^1333 := by decide +kernel

def env41246 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5456,32768,99,5236,2112,1025,32769,4468,276,292,33079,348,64,2049,5156,4177,34881,1121,32881,257,113,38225,513]

theorem envBound41246 : H12AffineFastState.Bounded env41246 := by
  intro p hp
  have h : env41246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41245_41246 : H12AffineEnvironment.transform 15 99 env41245 = env41246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env41245 == env41246) = true)

theorem identity41246 : scanCanonicalize (H12AffineFastState.compose env41246 (packedSelected [0,1,3,4,5,7,8,9,15] rootPS)) = affineNative (2^(14+1) ^^^ 356) := by decide +kernel

theorem selectedBound41246 : packedSelected [0,1,3,4,5,7,8,9,15] rootPS < 2^1333 := by decide +kernel

def env41247 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5456,356,99,5236,2112,1025,357,4468,276,292,83,348,64,2049,5156,4177,2341,1121,277,257,113,5173,513]

theorem envBound41247 : H12AffineFastState.Bounded env41247 := by
  intro p hp
  have h : env41247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41246_41247 : H12AffineEnvironment.transform 14 356 env41246 = env41247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 356 env41246 == env41247) = true)

theorem identity41247 : scanCanonicalize (H12AffineFastState.compose env41247 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound41247 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41248 : List Nat := [2,4,8,16,32,64,9,100,512,1024,2048,4096,57,5172,0,99,5236,2112,1025,1,4112,112,64,83,56,64,2049,5156,4177,2113,1121,113,101,113,5173,513]

theorem envBound41248 : H12AffineFastState.Bounded env41248 := by
  intro p hp
  have h : env41248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41247_41248 : H12AffineEnvironment.transform 7 100 env41247 = env41248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env41247 == env41248) = true)

theorem identity41248 : scanCanonicalize (H12AffineFastState.compose env41248 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 3135) := by decide +kernel

theorem selectedBound41248 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env41249 : List Nat := [2,4,8,16,32,64,9,100,512,1024,2048,3135,57,2059,0,99,2123,2112,1025,1,3119,112,64,83,56,64,2049,2075,3182,2113,1121,113,101,113,2058,513]

theorem envBound41249 : H12AffineFastState.Bounded env41249 := by
  intro p hp
  have h : env41249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41248_41249 : H12AffineEnvironment.transform 11 3135 env41248 = env41249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3135 env41248 == env41249) = true)

theorem identity41249 : scanCanonicalize (H12AffineFastState.compose env41249 (packedSelected [1,4,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1118) := by decide +kernel

theorem selectedBound41249 : packedSelected [1,4,8,9] rootPS < 2^1333 := by decide +kernel

def env41250 : List Nat := [2,4,8,16,32,64,9,100,512,1024,1118,97,57,1109,0,99,1045,1054,1025,1,113,112,64,83,56,64,1119,1093,48,1055,1121,113,101,113,1108,513]

theorem envBound41250 : H12AffineFastState.Bounded env41250 := by
  intro p hp
  have h : env41250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41249_41250 : H12AffineEnvironment.transform 10 1118 env41249 = env41250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1118 env41249 == env41250) = true)

theorem identity41250 : scanCanonicalize (H12AffineFastState.compose env41250 (packedSelected [1,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound41250 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env41251 : List Nat := [2,4,8,16,32,64,9,100,512,20,74,97,57,65,0,99,1,10,21,1,113,112,64,83,56,64,75,81,48,11,117,113,101,113,64,513]

theorem envBound41251 : H12AffineFastState.Bounded env41251 := by
  intro p hp
  have h : env41251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41250_41251 : H12AffineEnvironment.transform 9 20 env41250 = env41251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env41250 == env41251) = true)

theorem identity41251 : scanCanonicalize (H12AffineFastState.compose env41251 (packedSelected [1,2,8] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound41251 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env41252 : List Nat := [2,4,8,16,32,32,9,4,512,20,42,1,57,33,0,3,1,10,21,1,17,16,32,51,56,32,43,49,48,11,21,17,5,17,32,513]

theorem envBound41252 : H12AffineFastState.Bounded env41252 := by
  intro p hp
  have h : env41252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41251_41252 : H12AffineEnvironment.transform 5 32 env41251 = env41252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env41251 == env41252) = true)

theorem identity41252 : scanCanonicalize (H12AffineFastState.compose env41252 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound41252 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41253 : List Nat := [2,4,8,2,32,32,9,4,512,6,42,1,43,33,0,3,1,10,7,1,3,2,32,33,42,32,43,35,34,11,7,3,5,3,32,513]

theorem envBound41253 : H12AffineFastState.Bounded env41253 := by
  intro p hp
  have h : env41253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41252_41253 : H12AffineEnvironment.transform 3 2 env41252 = env41253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env41252 == env41253) = true)

theorem identity41253 : scanCanonicalize (H12AffineFastState.compose env41253 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound41253 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env41254 : List Nat := [2,4,8,2,3,3,9,4,512,6,9,1,8,2,0,3,1,10,7,1,3,2,3,2,9,3,8,0,1,11,7,3,5,3,3,513]

theorem envBound41254 : H12AffineFastState.Bounded env41254 := by
  intro p hp
  have h : env41254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41253_41254 : H12AffineEnvironment.transform 4 3 env41253 = env41254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env41253 == env41254) = true)

def env41255 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2177219,2098512,17665,2462111,2102684,2411677,257,21793,46213,2175563]

theorem envBound41255 : H12AffineFastState.Bounded env41255 := by
  intro p hp
  have h : env41255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41233_41255 : H12AffineEnvironment.transform 21 272513 env41233 = env41255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env41233 == env41255) = true)

theorem identity41255 : scanCanonicalize (H12AffineFastState.compose env41255 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound41255 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41256 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,25029,262144,1025,32769,2097152,272513,2101328,41430,8328,64,2103496,2098512,17665,2404756,2102684,2411677,257,21793,46213,2101824]

theorem envBound41256 : H12AffineFastState.Bounded env41256 := by
  intro p hp
  have h : env41256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41255_41256 : H12AffineEnvironment.transform 15 8203 env41255 = env41256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env41255 == env41256) = true)

theorem identity41256 : scanCanonicalize (H12AffineFastState.compose env41256 (packedSelected [3,10,16,17,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound41256 : packedSelected [3,10,16,17,20,24,26] rootPS < 2^1333 := by decide +kernel

def env41257 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8203,25029,262144,1025,8541,2097152,272513,2101328,138,8328,64,2103496,2098512,17665,2363592,2102684,2387393,257,21793,5593,2101824]

theorem envBound41257 : H12AffineFastState.Bounded env41257 := by
  intro p hp
  have h : env41257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41256_41257 : H12AffineEnvironment.transform 14 8540 env41256 = env41257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env41256 == env41257) = true)

theorem identity41257 : scanCanonicalize (H12AffineFastState.compose env41257 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound41257 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env41258 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,24908,262144,1025,8541,2097152,272392,2101328,3,8193,64,2103361,2098512,17665,2363457,2102549,2387272,257,21793,5456,2101824]

theorem envBound41258 : H12AffineFastState.Bounded env41258 := by
  intro p hp
  have h : env41258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41257_41258 : H12AffineEnvironment.transform 6 9 env41257 = env41258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41257 == env41258) = true)

theorem identity41258 : scanCanonicalize (H12AffineFastState.compose env41258 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 31837) := by decide +kernel

theorem selectedBound41258 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env41259 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,24908,31837,1025,8541,2097152,21589,2101328,3,8193,64,2103361,2098512,17665,2124828,2102549,2101525,257,21793,5456,2101824]

theorem envBound41259 : H12AffineFastState.Bounded env41259 := by
  intro p hp
  have h : env41259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41258_41259 : H12AffineEnvironment.transform 17 31837 env41258 = env41259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 31837 env41258 == env41259) = true)

theorem identity41259 : scanCanonicalize (H12AffineFastState.compose env41259 (packedSelected [0,1,2,3,4,5,7,8,10,11,14,18,19,22] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound41259 : packedSelected [0,1,2,3,4,5,7,8,10,11,14,18,19,22] rootPS < 2^1333 := by decide +kernel

def env41260 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,8233,8203,24633,31837,1025,8232,2097152,21589,2101328,3,8193,64,2103361,2098213,17524,2124828,2102368,2101344,116,21588,5157,2101824]

theorem envBound41260 : H12AffineFastState.Bounded env41260 := by
  intro p hp
  have h : env41260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41259_41260 : H12AffineEnvironment.transform 7 117 env41259 = env41260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env41259 == env41260) = true)

theorem identity41260 : scanCanonicalize (H12AffineFastState.compose env41260 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound41260 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env41261 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5237,8233,8203,13388,10280,1025,8232,2097152,32,2101328,3,8193,64,2103361,2098213,4097,2111593,2102368,2101344,116,33,5157,2101824]

theorem envBound41261 : H12AffineFastState.Bounded env41261 := by
  intro p hp
  have h : env41261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41260_41261 : H12AffineEnvironment.transform 13 5237 env41260 = env41261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env41260 == env41261) = true)

theorem identity41261 : scanCanonicalize (H12AffineFastState.compose env41261 (packedSelected [12,15] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound41261 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env41262 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5237,8233,8203,13388,10280,1025,8232,4161,32,17,3,8193,64,2048,5220,4097,10280,1057,33,116,33,5157,513]

theorem envBound41262 : H12AffineFastState.Bounded env41262 := by
  intro p hp
  have h : env41262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41261_41262 : H12AffineEnvironment.transform 20 4161 env41261 = env41262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env41261 == env41262) = true)

theorem identity41262 : scanCanonicalize (H12AffineFastState.compose env41262 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound41262 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41263 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,5237,1,35,5220,2048,1025,0,4161,32,17,3,41,64,2048,5220,4097,2048,1057,33,116,33,5157,513]

theorem envBound41263 : H12AffineFastState.Bounded env41263 := by
  intro p hp
  have h : env41263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41262_41263 : H12AffineEnvironment.transform 12 40 env41262 = env41263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env41262 == env41263) = true)

theorem identity41263 : scanCanonicalize (H12AffineFastState.compose env41263 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1135) := by decide +kernel

theorem selectedBound41263 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41264 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1135,4096,40,5237,1,35,5220,1135,1025,0,4161,32,17,3,41,64,1135,5220,4097,1135,1057,33,116,33,5157,513]

theorem envBound41264 : H12AffineFastState.Bounded env41264 := by
  intro p hp
  have h : env41264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41263_41264 : H12AffineEnvironment.transform 10 1135 env41263 = env41264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1135 env41263 == env41264) = true)

theorem identity41264 : scanCanonicalize (H12AffineFastState.compose env41264 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound41264 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env41265 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1135,0,40,1141,1,35,1124,1135,1025,0,65,32,17,3,41,64,1135,1124,1,1135,1057,33,116,33,1061,513]

theorem envBound41265 : H12AffineFastState.Bounded env41265 := by
  intro p hp
  have h : env41265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41264_41265 : H12AffineEnvironment.transform 11 0 env41264 = env41265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env41264 == env41265) = true)

theorem identity41265 : scanCanonicalize (H12AffineFastState.compose env41265 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 111) := by decide +kernel

theorem selectedBound41265 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env41266 : List Nat := [2,4,8,16,32,64,9,117,512,111,0,0,40,26,1,35,11,0,110,0,65,32,17,3,41,64,0,11,1,0,78,33,116,33,74,513]

theorem envBound41266 : H12AffineFastState.Bounded env41266 := by
  intro p hp
  have h : env41266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41265_41266 : H12AffineEnvironment.transform 9 111 env41265 = env41266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 111 env41265 == env41266) = true)

theorem identity41266 : scanCanonicalize (H12AffineFastState.compose env41266 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound41266 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env41267 : List Nat := [2,4,8,16,32,58,9,15,512,21,0,0,40,26,1,35,11,0,20,0,59,32,17,3,41,58,0,11,1,0,52,33,14,33,48,513]

theorem envBound41267 : H12AffineFastState.Bounded env41267 := by
  intro p hp
  have h : env41267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41266_41267 : H12AffineEnvironment.transform 5 58 env41266 = env41267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env41266 == env41267) = true)

theorem identity41267 : scanCanonicalize (H12AffineFastState.compose env41267 (packedSelected [2,11] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound41267 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env41268 : List Nat := [2,4,8,16,10,16,9,15,512,21,0,0,2,26,1,9,11,0,20,0,17,10,17,3,3,16,0,11,1,0,30,11,14,11,26,513]

theorem envBound41268 : H12AffineFastState.Bounded env41268 := by
  intro p hp
  have h : env41268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41267_41268 : H12AffineEnvironment.transform 4 10 env41267 = env41268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env41267 == env41268) = true)

theorem identity41268 : scanCanonicalize (H12AffineFastState.compose env41268 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound41268 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41269 : List Nat := [2,4,8,1,10,1,9,15,512,4,0,0,2,11,1,9,11,0,5,0,0,10,0,3,3,1,0,11,1,0,15,11,14,11,11,513]

theorem envBound41269 : H12AffineFastState.Bounded env41269 := by
  intro p hp
  have h : env41269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41268_41269 : H12AffineEnvironment.transform 3 1 env41268 = env41269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env41268 == env41269) = true)

theorem identity41269 : scanCanonicalize (H12AffineFastState.compose env41269 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound41269 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41270 : List Nat := [2,4,8,1,10,1,9,15,14,4,0,0,2,11,1,9,11,0,5,0,0,10,0,3,3,1,0,11,1,0,15,11,14,11,11,15]

theorem envBound41270 : H12AffineFastState.Bounded env41270 := by
  intro p hp
  have h : env41270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41269_41270 : H12AffineEnvironment.transform 8 14 env41269 = env41270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env41269 == env41270) = true)

theorem identity41270 : scanCanonicalize (H12AffineFastState.compose env41270 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound41270 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env41271 : List Nat := [2,4,3,1,1,1,2,4,5,4,0,0,2,0,1,2,0,0,5,0,0,1,0,3,3,1,0,0,1,0,4,0,5,0,0,4]

theorem envBound41271 : H12AffineFastState.Bounded env41271 := by
  intro p hp
  have h : env41271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41270_41271 : H12AffineEnvironment.transform 2 3 env41270 = env41271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env41270 == env41271) = true)

theorem identity41271 : scanCanonicalize (H12AffineFastState.compose env41271 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound41271 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41272 : List Nat := [1,4,0,1,1,1,1,4,5,4,0,0,1,0,1,1,0,0,5,0,0,1,0,0,0,1,0,0,1,0,4,0,5,0,0,4]

theorem envBound41272 : H12AffineFastState.Bounded env41272 := by
  intro p hp
  have h : env41272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41271_41272 : H12AffineEnvironment.transform 0 1 env41271 = env41272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env41271 == env41272) = true)

def env41273 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6623298,2098513,17664,2462110,2102684,6349853,257,21793,46213,2175563]

theorem envBound41273 : H12AffineFastState.Bounded env41273 := by
  intro p hp
  have h : env41273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41232_41273 : H12AffineEnvironment.transform 22 2101329 env41232 = env41273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env41232 == env41273) = true)

def env41274 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2177218,2098513,17664,2462110,2102684,2411677,257,21793,46213,2175563]

theorem envBound41274 : H12AffineFastState.Bounded env41274 := by
  intro p hp
  have h : env41274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41273_41274 : H12AffineEnvironment.transform 21 272512 env41273 = env41274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env41273 == env41274) = true)

theorem identity41274 : scanCanonicalize (H12AffineFastState.compose env41274 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115871) := by decide +kernel

theorem selectedBound41274 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,115871,272512,120014,98780,8328,64,64605,115150,17664,283905,119043,329730,257,21793,46213,63188]

theorem envBound41275 : H12AffineFastState.Bounded env41275 := by
  intro p hp
  have h : env41275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41274_41275 : H12AffineEnvironment.transform 20 115871 env41274 = env41275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115871 env41274 == env41275) = true)

def env41276 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82334,262144,1025,32769,115871,272512,119966,98700,8328,16,64525,115102,17664,283905,119043,329730,257,21793,46213,63108]

theorem envBound41276 : H12AffineFastState.Bounded env41276 := by
  intro p hp
  have h : env41276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41275_41276 : H12AffineEnvironment.transform 5 16 env41275 = env41276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41275 == env41276) = true)

theorem identity41276 : scanCanonicalize (H12AffineFastState.compose env41276 (packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 76078) := by decide +kernel

theorem selectedBound41276 : packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env41277 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82334,76078,1025,32769,115871,65966,119966,98700,8328,16,64525,115102,17664,97327,119043,8492,257,21793,46213,63108]

theorem envBound41277 : H12AffineFastState.Bounded env41277 := by
  intro p hp
  have h : env41277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41276_41277 : H12AffineEnvironment.transform 17 76078 env41276 = env41277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76078 env41276 == env41277) = true)

theorem identity41277 : scanCanonicalize (H12AffineFastState.compose env41277 (packedSelected [0,1,4,7,11,19,22,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound41277 : packedSelected [0,1,4,7,11,19,22,28,31,32] rootPS < 2^1333 := by decide +kernel

def env41278 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,29963,13461,23589,1025,32769,45460,29861,41365,62599,8328,16,64525,46229,17664,2340,41992,8492,257,21793,46213,63108]

theorem envBound41278 : H12AffineFastState.Bounded env41278 := by
  intro p hp
  have h : env41278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41277_41278 : H12AffineEnvironment.transform 15 29963 env41277 = env41278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env41277 == env41278) = true)

theorem identity41278 : scanCanonicalize (H12AffineFastState.compose env41278 (packedSelected [3,10,17,19,24] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound41278 : packedSelected [3,10,17,19,24] rootPS < 2^1333 := by decide +kernel

def env41279 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,32768,263,13461,10281,1025,32769,45460,169,41365,32907,8328,16,34817,46229,12556,2340,41992,8492,257,8493,46213,33416]

theorem envBound41279 : H12AffineFastState.Bounded env41279 := by
  intro p hp
  have h : env41279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41278_41279 : H12AffineEnvironment.transform 13 13324 env41278 = env41279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env41278 == env41279) = true)

theorem identity41279 : scanCanonicalize (H12AffineFastState.compose env41279 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound41279 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41280 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,8581,263,13461,10281,1025,8580,4113,169,16,8462,8328,16,10628,5392,12556,2340,1421,8492,257,8493,5376,8973]

theorem envBound41280 : H12AffineFastState.Bounded env41280 := by
  intro p hp
  have h : env41280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41279_41280 : H12AffineEnvironment.transform 14 8581 env41279 = env41280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env41279 == env41280) = true)

theorem identity41280 : scanCanonicalize (H12AffineFastState.compose env41280 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 1425) := by decide +kernel

theorem selectedBound41280 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env41281 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1425,4509,1044,263,4356,3512,1025,1045,4113,169,16,1183,1305,16,3093,5392,5277,2340,1421,1213,257,1212,5376,1692]

theorem envBound41281 : H12AffineFastState.Bounded env41281 := by
  intro p hp
  have h : env41281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41280_41281 : H12AffineEnvironment.transform 12 1425 env41280 = env41281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1425 env41280 == env41281) = true)

theorem identity41281 : scanCanonicalize (H12AffineFastState.compose env41281 (packedSelected [0,4,6,7,9,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 441) := by decide +kernel

theorem selectedBound41281 : packedSelected [0,4,6,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env41282 : List Nat := [2,4,8,16,32,16,128,256,512,441,2048,4096,40,4509,429,263,4356,2049,440,428,4113,169,16,294,160,16,2476,4265,4388,2340,52,260,257,261,4281,805]

theorem envBound41282 : H12AffineFastState.Bounded env41282 := by
  intro p hp
  have h : env41282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41281_41282 : H12AffineEnvironment.transform 9 441 env41281 = env41282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 441 env41281 == env41282) = true)

theorem identity41282 : scanCanonicalize (H12AffineFastState.compose env41282 (packedSelected [2,6,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound41282 : packedSelected [2,6,11,15] rootPS < 2^1333 := by decide +kernel

def env41283 : List Nat := [2,4,8,16,32,16,128,173,512,20,2048,4096,40,4144,0,170,4265,2049,21,1,4113,169,16,139,160,16,2049,4265,4233,2185,52,169,172,168,4281,648]

theorem envBound41283 : H12AffineFastState.Bounded env41283 := by
  intro p hp
  have h : env41283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41282_41283 : H12AffineEnvironment.transform 7 173 env41282 = env41283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env41282 == env41283) = true)

theorem identity41283 : scanCanonicalize (H12AffineFastState.compose env41283 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2200) := by decide +kernel

theorem selectedBound41283 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env41284 : List Nat := [2,4,8,16,32,16,128,173,512,20,2048,2200,40,2216,0,170,2097,2049,21,1,2185,169,16,139,160,16,2049,2097,2065,2185,52,169,172,168,2081,648]

theorem envBound41284 : H12AffineFastState.Bounded env41284 := by
  intro p hp
  have h : env41284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41283_41284 : H12AffineEnvironment.transform 11 2200 env41283 = env41284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2200 env41283 == env41284) = true)

theorem identity41284 : scanCanonicalize (H12AffineFastState.compose env41284 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound41284 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env41285 : List Nat := [2,4,8,16,32,16,128,173,512,20,136,16,40,32,0,170,185,137,21,1,1,169,16,139,160,16,137,185,153,1,52,169,172,168,169,648]

theorem envBound41285 : H12AffineFastState.Bounded env41285 := by
  intro p hp
  have h : env41285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41284_41285 : H12AffineEnvironment.transform 10 136 env41284 = env41285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env41284 == env41285) = true)

theorem identity41285 : scanCanonicalize (H12AffineFastState.compose env41285 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound41285 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41286 : List Nat := [2,4,8,16,32,16,56,21,512,20,48,16,40,32,0,18,1,49,21,1,1,17,16,51,24,16,49,1,33,1,52,17,20,16,17,560]

theorem envBound41286 : H12AffineFastState.Bounded env41286 := by
  intro p hp
  have h : env41286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41285_41286 : H12AffineEnvironment.transform 6 56 env41285 = env41286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env41285 == env41286) = true)

theorem identity41286 : scanCanonicalize (H12AffineFastState.compose env41286 (packedSelected [2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound41286 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env41287 : List Nat := [2,4,8,0,32,0,40,5,512,4,32,0,40,32,0,2,1,33,5,1,1,1,0,35,8,0,33,1,33,1,36,1,4,0,1,544]

theorem envBound41287 : H12AffineFastState.Bounded env41287 := by
  intro p hp
  have h : env41287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41286_41287 : H12AffineEnvironment.transform 3 0 env41286 = env41287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env41286 == env41287) = true)

theorem identity41287 : scanCanonicalize (H12AffineFastState.compose env41287 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41287 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41288 : List Nat := [2,4,8,0,1,0,9,5,512,4,1,0,9,1,0,2,1,0,5,1,1,1,0,2,8,0,0,1,0,1,5,1,4,0,1,513]

theorem envBound41288 : H12AffineFastState.Bounded env41288 := by
  intro p hp
  have h : env41288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41287_41288 : H12AffineEnvironment.transform 4 1 env41287 = env41288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41287 == env41288) = true)

theorem identity41288 : scanCanonicalize (H12AffineFastState.compose env41288 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound41288 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41289 : List Nat := [2,4,8,0,1,0,9,5,1,4,1,0,9,1,0,2,1,0,5,1,1,1,0,2,8,0,0,1,0,1,5,1,4,0,1,0]

theorem envBound41289 : H12AffineFastState.Bounded env41289 := by
  intro p hp
  have h : env41289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41288_41289 : H12AffineEnvironment.transform 8 1 env41288 = env41289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env41288 == env41289) = true)

def env41290 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82335,262144,1025,32769,115871,272512,119967,98701,8328,17,64524,115103,17664,283905,119043,329730,257,21793,46213,63109]

theorem envBound41290 : H12AffineFastState.Bounded env41290 := by
  intro p hp
  have h : env41290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41275_41290 : H12AffineEnvironment.transform 5 17 env41275 = env41290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41275 == env41290) = true)

theorem identity41290 : scanCanonicalize (H12AffineFastState.compose env41290 (packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 23724) := by decide +kernel

theorem selectedBound41290 : packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env41291 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82335,23724,1025,32769,115871,29740,119967,98701,8328,17,64524,115103,17664,2477,119043,87214,257,21793,46213,63109]

theorem envBound41291 : H12AffineFastState.Bounded env41291 := by
  intro p hp
  have h : env41291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41290_41291 : H12AffineEnvironment.transform 17 23724 env41290 = env41291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23724 env41290 == env41291) = true)

theorem identity41291 : scanCanonicalize (H12AffineFastState.compose env41291 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound41291 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env41292 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,21760,65536,82335,23724,1025,21761,70047,29740,65951,87181,8328,17,10508,70815,17664,2477,66563,87214,257,21793,24965,9093]

theorem envBound41292 : H12AffineFastState.Bounded env41292 := by
  intro p hp
  have h : env41292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41291_41292 : H12AffineEnvironment.transform 14 21760 env41291 = env41292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env41291 == env41292) = true)

theorem identity41292 : scanCanonicalize (H12AffineFastState.compose env41292 (packedSelected [3,4,7,9,10,16,19,20,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound41292 : packedSelected [3,4,7,9,10,16,19,20,24,27] rootPS < 2^1333 := by decide +kernel

def env41293 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13325,8461,65536,79250,10401,1025,8460,70047,33,65951,73856,8328,17,10508,70815,12557,2477,66563,73891,257,8492,5512,9093]

theorem envBound41293 : H12AffineFastState.Bounded env41293 := by
  intro p hp
  have h : env41293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41292_41293 : H12AffineEnvironment.transform 13 13325 env41292 = env41293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env41292 == env41293) = true)

theorem identity41293 : scanCanonicalize (H12AffineFastState.compose env41293 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound41293 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41294 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,8461,65536,79131,10280,1025,8460,69910,33,65814,73737,8193,17,10508,70678,12557,2340,66563,73770,257,8492,5377,8972]

theorem envBound41294 : H12AffineFastState.Bounded env41294 := by
  intro p hp
  have h : env41294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41293_41294 : H12AffineEnvironment.transform 6 9 env41293 = env41294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41293 == env41294) = true)

theorem identity41294 : scanCanonicalize (H12AffineFastState.compose env41294 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound41294 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env41295 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,1,65536,70679,2340,1025,0,69910,33,65814,65797,269,17,2048,70678,4097,2340,66563,65830,257,32,5377,512]

theorem envBound41295 : H12AffineFastState.Bounded env41295 := by
  intro p hp
  have h : env41295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41294_41295 : H12AffineEnvironment.transform 12 268 env41294 = env41295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env41294 == env41295) = true)

theorem identity41295 : scanCanonicalize (H12AffineFastState.compose env41295 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 294) := by decide +kernel

theorem selectedBound41295 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41296 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,1,294,5425,2340,1025,0,4144,33,48,35,269,17,2048,5424,4097,2340,1317,0,257,32,5377,512]

theorem envBound41296 : H12AffineFastState.Bounded env41296 := by
  intro p hp
  have h : env41296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41295_41296 : H12AffineEnvironment.transform 15 294 env41295 = env41296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 294 env41295 == env41296) = true)

theorem identity41296 : scanCanonicalize (H12AffineFastState.compose env41296 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound41296 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env41297 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,268,4112,1,294,4128,2340,272,0,4144,33,48,35,269,17,2048,4129,4097,2340,52,0,257,32,4112,512]

theorem envBound41297 : H12AffineFastState.Bounded env41297 := by
  intro p hp
  have h : env41297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41296_41297 : H12AffineEnvironment.transform 9 273 env41296 = env41297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env41296 == env41297) = true)

theorem identity41297 : scanCanonicalize (H12AffineFastState.compose env41297 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound41297 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env41298 : List Nat := [2,4,8,16,32,17,9,5,512,20,2048,4096,9,4112,1,35,4128,2081,21,0,4144,33,48,35,8,17,2048,4129,4097,2081,52,0,4,32,4112,512]

theorem envBound41298 : H12AffineFastState.Bounded env41298 := by
  intro p hp
  have h : env41298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41297_41298 : H12AffineEnvironment.transform 7 5 env41297 = env41298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env41297 == env41298) = true)

theorem identity41298 : scanCanonicalize (H12AffineFastState.compose env41298 (packedSelected [1,2] rootPS)) = affineNative (2^(11+1) ^^^ 543) := by decide +kernel

theorem selectedBound41298 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env41299 : List Nat := [2,4,8,16,32,17,9,5,512,20,2048,543,9,527,1,35,575,2081,21,0,559,33,48,35,8,17,2048,574,542,2081,52,0,4,32,527,512]

theorem envBound41299 : H12AffineFastState.Bounded env41299 := by
  intro p hp
  have h : env41299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41298_41299 : H12AffineEnvironment.transform 11 543 env41298 = env41299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 543 env41298 == env41299) = true)

theorem identity41299 : scanCanonicalize (H12AffineFastState.compose env41299 (packedSelected [4,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound41299 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env41300 : List Nat := [2,4,8,16,32,17,9,5,512,20,0,543,9,527,1,35,575,33,21,0,559,33,48,35,8,17,0,574,542,33,52,0,4,32,527,512]

theorem envBound41300 : H12AffineFastState.Bounded env41300 := by
  intro p hp
  have h : env41300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41299_41300 : H12AffineEnvironment.transform 10 0 env41299 = env41300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env41299 == env41300) = true)

theorem identity41300 : scanCanonicalize (H12AffineFastState.compose env41300 (packedSelected [4,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41300 : packedSelected [4,8] rootPS < 2^1333 := by decide +kernel

def env41301 : List Nat := [2,4,8,16,0,17,9,5,512,20,0,543,9,527,1,3,543,1,21,0,527,1,16,3,8,17,0,542,542,1,20,0,4,0,527,512]

theorem envBound41301 : H12AffineFastState.Bounded env41301 := by
  intro p hp
  have h : env41301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41300_41301 : H12AffineEnvironment.transform 4 0 env41300 = env41301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41300 == env41301) = true)

theorem identity41301 : scanCanonicalize (H12AffineFastState.compose env41301 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound41301 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41302 : List Nat := [2,4,8,16,0,17,9,5,14,20,0,17,9,1,1,3,17,1,21,0,1,1,16,3,8,17,0,16,16,1,20,0,4,0,1,14]

theorem envBound41302 : H12AffineFastState.Bounded env41302 := by
  intro p hp
  have h : env41302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41301_41302 : H12AffineEnvironment.transform 8 14 env41301 = env41302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env41301 == env41302) = true)

def env41303 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2177219,2098513,17664,2462110,2102684,2411676,257,21793,46213,2175563]

theorem envBound41303 : H12AffineFastState.Bounded env41303 := by
  intro p hp
  have h : env41303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41273_41303 : H12AffineEnvironment.transform 21 272513 env41273 = env41303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env41273 == env41303) = true)

theorem identity41303 : scanCanonicalize (H12AffineFastState.compose env41303 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound41303 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41304 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,38161,262144,1025,32769,2097152,272513,2101329,21763,8328,64,2157596,2098513,17664,2377025,2102684,2411676,257,21793,46213,2156180]

theorem envBound41304 : H12AffineFastState.Bounded env41304 := by
  intro p hp
  have h : env41304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41303_41304 : H12AffineEnvironment.transform 15 54495 env41303 = env41304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env41303 == env41304) = true)

def env41305 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38161,262144,1025,32769,2097152,272393,2101329,21763,8192,64,2157596,2098513,17664,2377025,2102548,2411540,257,21793,46093,2156060]

theorem envBound41305 : H12AffineFastState.Bounded env41305 := by
  intro p hp
  have h : env41305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41304_41305 : H12AffineEnvironment.transform 6 8 env41304 = env41305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41304 == env41305) = true)

theorem identity41305 : scanCanonicalize (H12AffineFastState.compose env41305 (packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 314689) := by decide +kernel

theorem selectedBound41305 : packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS < 2^1333 := by decide +kernel

def env41306 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38161,262144,1025,32769,314689,272393,318736,21763,8192,64,270685,313360,17664,34816,317525,341,257,21793,46093,273245]

theorem envBound41306 : H12AffineFastState.Bounded env41306 := by
  intro p hp
  have h : env41306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41305_41306 : H12AffineEnvironment.transform 20 314689 env41305 = env41306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 314689 env41305 == env41306) = true)

def env41307 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38161,262144,1025,32769,2097152,272392,2101329,21763,8193,64,2157596,2098513,17664,2377025,2102549,2411541,257,21793,46092,2156061]

theorem envBound41307 : H12AffineFastState.Bounded env41307 := by
  intro p hp
  have h : env41307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41304_41307 : H12AffineEnvironment.transform 6 9 env41304 = env41307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41304 == env41307) = true)

theorem identity41307 : scanCanonicalize (H12AffineFastState.compose env41307 (packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 25628) := by decide +kernel

theorem selectedBound41307 : packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS < 2^1333 := by decide +kernel

def env41308 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38161,262144,1025,32769,25628,272392,29773,21763,8193,64,34816,24909,17664,270685,28937,305161,257,21793,46092,33281]

theorem envBound41308 : H12AffineFastState.Bounded env41308 := by
  intro p hp
  have h : env41308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41307_41308 : H12AffineEnvironment.transform 20 25628 env41307 = env41308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25628 env41307 == env41308) = true)

theorem identity41308 : scanCanonicalize (H12AffineFastState.compose env41308 (packedSelected [1,3,5,8,19,31] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound41308 : packedSelected [1,3,5,8,19,31] rootPS < 2^1333 := by decide +kernel

def env41309 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38161,35188,1025,32769,25628,41340,29773,21763,8193,64,34816,24909,17664,43049,28937,8573,257,21793,46092,33281]

theorem envBound41309 : H12AffineFastState.Bounded env41309 := by
  intro p hp
  have h : env41309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41308_41309 : H12AffineEnvironment.transform 17 35188 env41308 = env41309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env41308 == env41309) = true)

theorem identity41309 : scanCanonicalize (H12AffineFastState.compose env41309 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound41309 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env41310 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,81,21511,5440,2341,1025,80,25628,8493,29773,21763,8193,64,2129,24909,17664,10360,28937,8573,257,21793,13405,592]

theorem envBound41310 : H12AffineFastState.Bounded env41310 := by
  intro p hp
  have h : env41310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41309_41310 : H12AffineEnvironment.transform 14 81 env41309 = env41310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env41309 == env41310) = true)

theorem identity41310 : scanCanonicalize (H12AffineFastState.compose env41310 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound41310 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env41311 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,81,262,5440,2341,1025,80,12573,8493,8524,2,8193,64,2129,13388,4097,10360,9224,8573,257,32,13405,592]

theorem envBound41311 : H12AffineFastState.Bounded env41311 := by
  intro p hp
  have h : env41311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41310_41311 : H12AffineEnvironment.transform 13 5377 env41310 = env41311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env41310 == env41311) = true)

theorem identity41311 : scanCanonicalize (H12AffineFastState.compose env41311 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41311 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env41312 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,0,262,5393,2341,1025,1,12573,8493,8477,2,8193,17,2048,13341,4097,10281,9224,8492,257,32,13324,513]

theorem envBound41312 : H12AffineFastState.Bounded env41312 := by
  intro p hp
  have h : env41312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41311_41312 : H12AffineEnvironment.transform 5 17 env41311 = env41312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41311 == env41312) = true)

theorem identity41312 : scanCanonicalize (H12AffineFastState.compose env41312 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound41312 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41313 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,0,262,5393,2341,1025,1,4113,33,17,2,269,17,2048,5393,4097,2341,1284,32,257,32,5376,513]

theorem envBound41313 : H12AffineFastState.Bounded env41313 := by
  intro p hp
  have h : env41313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41312_41313 : H12AffineEnvironment.transform 12 268 env41312 = env41313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env41312 == env41313) = true)

theorem identity41313 : scanCanonicalize (H12AffineFastState.compose env41313 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound41313 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41314 : List Nat := [2,4,8,16,32,17,9,256,512,20,2048,4096,268,4373,0,262,4357,2341,21,1,4113,33,17,2,269,17,2048,4357,4097,2341,272,32,257,32,4372,513]

theorem envBound41314 : H12AffineFastState.Bounded env41314 := by
  intro p hp
  have h : env41314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41313_41314 : H12AffineEnvironment.transform 9 20 env41313 = env41314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env41313 == env41314) = true)

theorem identity41314 : scanCanonicalize (H12AffineFastState.compose env41314 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound41314 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41315 : List Nat := [2,4,8,16,32,17,9,256,512,20,522,4096,268,4373,0,262,4357,815,21,1,4113,33,17,2,269,17,522,4357,4097,815,272,32,257,32,4372,513]

theorem envBound41315 : H12AffineFastState.Bounded env41315 := by
  intro p hp
  have h : env41315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41314_41315 : H12AffineEnvironment.transform 10 522 env41314 = env41315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env41314 == env41315) = true)

theorem identity41315 : scanCanonicalize (H12AffineFastState.compose env41315 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound41315 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41316 : List Nat := [2,4,8,16,32,17,9,256,0,20,10,4096,268,4373,0,262,4357,303,21,1,4113,33,17,2,269,17,10,4357,4097,303,272,32,257,32,4372,1]

theorem envBound41316 : H12AffineFastState.Bounded env41316 := by
  intro p hp
  have h : env41316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41315_41316 : H12AffineEnvironment.transform 8 0 env41315 = env41316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env41315 == env41316) = true)

theorem identity41316 : scanCanonicalize (H12AffineFastState.compose env41316 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound41316 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env41317 : List Nat := [2,4,8,16,32,17,9,256,0,20,10,261,268,16,0,262,0,303,21,1,276,33,17,2,269,17,10,0,260,303,272,32,257,32,17,1]

theorem envBound41317 : H12AffineFastState.Bounded env41317 := by
  intro p hp
  have h : env41317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41316_41317 : H12AffineEnvironment.transform 11 261 env41316 = env41317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env41316 == env41317) = true)

theorem identity41317 : scanCanonicalize (H12AffineFastState.compose env41317 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41317 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env41318 : List Nat := [2,4,8,16,0,17,9,256,0,20,10,261,268,16,0,262,0,271,21,1,276,1,17,2,269,17,10,0,260,271,272,0,257,0,17,1]

theorem envBound41318 : H12AffineFastState.Bounded env41318 := by
  intro p hp
  have h : env41318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41317_41318 : H12AffineEnvironment.transform 4 0 env41317 = env41318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41317 == env41318) = true)

theorem identity41318 : scanCanonicalize (H12AffineFastState.compose env41318 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

end H12CloudChart0