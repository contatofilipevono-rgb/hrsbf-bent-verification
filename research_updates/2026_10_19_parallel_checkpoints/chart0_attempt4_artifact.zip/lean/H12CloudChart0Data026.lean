import H12CloudChart0Data025

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity6445 : scanCanonicalize (H12AffineFastState.compose env6445 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound6445 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6446 : List Nat := [2,4,8,11,0,10,8,4,1,15,1,4096,4104,4097,1,4099,4096,1,14,1,4097,4096,10,4099,4105,10,4097,4096,4097,0,14,1,5,0,4096,1]

theorem envBound6446 : H12AffineFastState.Bounded env6446 := by
  intro p hp
  have h : env6446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6445_6446 : H12AffineEnvironment.transform 3 11 env6445 = env6446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env6445 == env6446) = true)

def env6447 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41002,8329,8914001,2942160,16384,16892,2641008,598058,14737724,525568,2638929,6332545,8914925]

theorem envBound6447 : H12AffineFastState.Bounded env6447 := by
  intro p hp
  have h : env6447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6241_6447 : H12AffineEnvironment.transform 25 8914001 env6241 = env6447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914001 env6241 == env6447) = true)

def env6448 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4096,4194304,8388608,41002,8329,8914001,849104,16384,16892,547952,598058,12644668,525568,545873,4239489,8914925]

theorem envBound6448 : H12AffineFastState.Bounded env6448 := by
  intro p hp
  have h : env6448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6447_6448 : H12AffineEnvironment.transform 20 4096 env6447 = env6448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env6447 == env6448) = true)

def env6449 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4096,4194304,8388608,41002,8329,8388689,323792,16384,16892,22640,74794,12644668,256,20561,4239489,8389613]

theorem envBound6449 : H12AffineFastState.Bounded env6449 := by
  intro p hp
  have h : env6449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6448_6449 : H12AffineEnvironment.transform 18 1024 env6448 = env6449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env6448 == env6449) = true)

theorem identity6449 : scanCanonicalize (H12AffineFastState.compose env6449 (packedSelected [14] rootPS)) = affineNative (2^(15+1) ^^^ 8495) := by decide +kernel

theorem selectedBound6449 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env6450 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8495,4605,262144,1024,32768,4096,4194304,8388608,41002,8329,8388689,323792,16384,16892,22640,1285,12644668,256,20561,4239489,8389613]

theorem envBound6450 : H12AffineFastState.Bounded env6450 := by
  intro p hp
  have h : env6450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6449_6450 : H12AffineEnvironment.transform 15 8495 env6449 = env6450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8495 env6449 == env6450) = true)

def env6451 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8495,4525,262144,1024,32768,4096,4194304,8388608,41002,8329,8388609,323712,16384,16812,22560,1285,12644668,256,20481,4239489,8389565]

theorem envBound6451 : H12AffineFastState.Bounded env6451 := by
  intro p hp
  have h : env6451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6450_6451 : H12AffineEnvironment.transform 5 16 env6450 = env6451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env6450 == env6451) = true)

def env6452 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8495,4525,262144,1024,32768,4096,136,8388608,41002,8329,8388609,323712,16384,16812,22560,1285,8450484,256,20481,45065,8389565]

theorem envBound6452 : H12AffineFastState.Bounded env6452 := by
  intro p hp
  have h : env6452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6451_6452 : H12AffineEnvironment.transform 21 136 env6451 = env6452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136 env6451 == env6452) = true)

theorem identity6452 : scanCanonicalize (H12AffineFastState.compose env6452 (packedSelected [7,9,13,17,20,22,27] rootPS)) = affineNative (2^(22+1) ^^^ 323084) := by decide +kernel

theorem selectedBound6452 : packedSelected [7,9,13,17,20,22,27] rootPS < 2^1333 := by decide +kernel

def env6453 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8495,4525,262144,1024,32768,4096,136,323084,41002,8329,323085,323712,16384,16812,22560,1285,270264,256,20481,45065,322993]

theorem envBound6453 : H12AffineFastState.Bounded env6453 := by
  intro p hp
  have h : env6453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6452_6453 : H12AffineEnvironment.transform 22 323084 env6452 = env6453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 323084 env6452 == env6453) = true)

def env6454 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8495,4525,8120,1024,32768,4096,136,61876,41002,8329,61877,61240,16384,16812,22560,1285,0,256,20481,45065,61961]

theorem envBound6454 : H12AffineFastState.Bounded env6454 := by
  intro p hp
  have h : env6454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6453_6454 : H12AffineEnvironment.transform 17 8120 env6453 = env6454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8120 env6453 == env6454) = true)

theorem identity6454 : scanCanonicalize (H12AffineFastState.compose env6454 (packedSelected [0,1,3,4,7,9,11,17,21,24,28,32] rootPS)) = affineNative (2^(14+1) ^^^ 28833) := by decide +kernel

theorem selectedBound6454 : packedSelected [0,1,3,4,7,9,11,17,21,24,28,32] rootPS < 2^1333 := by decide +kernel

def env6455 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,28833,8495,4525,8120,1024,28833,4096,136,277,20619,8329,276,8089,16384,16812,22560,1285,0,256,20481,16552,680]

theorem envBound6455 : H12AffineFastState.Bounded env6455 := by
  intro p hp
  have h : env6455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6454_6455 : H12AffineEnvironment.transform 14 28833 env6454 = env6455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28833 env6454 == env6455) = true)

theorem identity6455 : scanCanonicalize (H12AffineFastState.compose env6455 (packedSelected [1,3,4,9,13,18,20,21,23,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 1945) := by decide +kernel

theorem selectedBound6455 : packedSelected [1,3,4,9,13,18,20,21,23,24,28] rootPS < 2^1333 := by decide +kernel

def env6456 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1945,14136,8495,4525,8120,1024,14136,4096,136,277,5906,8329,276,8089,1945,1589,8121,1285,0,256,6040,1841,680]

theorem envBound6456 : H12AffineFastState.Bounded env6456 := by
  intro p hp
  have h : env6456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6455_6456 : H12AffineEnvironment.transform 13 1945 env6455 = env6456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1945 env6455 == env6456) = true)

theorem identity6456 : scanCanonicalize (H12AffineFastState.compose env6456 (packedSelected [0,1,5,7,8,13,17,20,24] rootPS)) = affineNative (2^(11+1) ^^^ 1693) := by decide +kernel

theorem selectedBound6456 : packedSelected [0,1,5,7,8,13,17,20,24] rootPS < 2^1333 := by decide +kernel

def env6457 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1693,8192,1945,8613,8495,1840,2341,1024,8613,1693,136,277,399,8329,276,2308,1945,1589,2340,1285,0,256,261,1841,680]

theorem envBound6457 : H12AffineFastState.Bounded env6457 := by
  intro p hp
  have h : env6457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6456_6457 : H12AffineEnvironment.transform 11 1693 env6456 = env6457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1693 env6456 == env6457) = true)

theorem identity6457 : scanCanonicalize (H12AffineFastState.compose env6457 (packedSelected [0,2,3,6,7,8,10,13] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound6457 : packedSelected [0,2,3,6,7,8,10,13] rootPS < 2^1333 := by decide +kernel

def env6458 : List Nat := [2,4,8,16,32,16,128,62,512,1024,2048,1693,8192,1703,8347,8209,1550,2075,1024,8347,1693,136,43,177,8329,42,2106,1703,1589,2074,1083,0,62,59,1551,680]

theorem envBound6458 : H12AffineFastState.Bounded env6458 := by
  intro p hp
  have h : env6458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6457_6458 : H12AffineEnvironment.transform 7 62 env6457 = env6458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env6457 == env6458) = true)

theorem identity6458 : scanCanonicalize (H12AffineFastState.compose env6458 (packedSelected [0,2,3,4,5,6,11,12,17] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound6458 : packedSelected [0,2,3,4,5,6,11,12,17] rootPS < 2^1333 := by decide +kernel

def env6459 : List Nat := [2,4,8,16,32,16,18,62,512,1024,2048,1551,8192,1589,8201,8209,1550,2075,1024,8201,1551,26,43,35,8219,42,2106,1589,1589,2074,1083,0,62,59,1551,570]

theorem envBound6459 : H12AffineFastState.Bounded env6459 := by
  intro p hp
  have h : env6459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6458_6459 : H12AffineEnvironment.transform 6 18 env6458 = env6459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env6458 == env6459) = true)

theorem identity6459 : scanCanonicalize (H12AffineFastState.compose env6459 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 2569) := by decide +kernel

theorem selectedBound6459 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env6460 : List Nat := [2,4,8,16,32,16,18,62,512,1024,2048,1551,2569,1589,2560,2584,1550,2075,1024,2560,1551,26,43,35,2578,42,2106,1589,1589,2074,1083,0,62,59,1551,570]

theorem envBound6460 : H12AffineFastState.Bounded env6460 := by
  intro p hp
  have h : env6460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6459_6460 : H12AffineEnvironment.transform 12 2569 env6459 = env6460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2569 env6459 == env6460) = true)

theorem identity6460 : scanCanonicalize (H12AffineFastState.compose env6460 (packedSelected [0,1,2,3,4,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound6460 : packedSelected [0,1,2,3,4,10] rootPS < 2^1333 := by decide +kernel

def env6461 : List Nat := [2,4,8,1,32,1,3,47,512,1024,2048,1551,2569,1572,2560,2569,1550,2058,1024,2560,1551,11,43,35,2563,42,2091,1572,1572,2059,1066,0,47,42,1551,555]

theorem envBound6461 : H12AffineFastState.Bounded env6461 := by
  intro p hp
  have h : env6461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6460_6461 : H12AffineEnvironment.transform 3 1 env6460 = env6461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6460 == env6461) = true)

def env6462 : List Nat := [2,4,8,1,32,1,3,47,512,1024,1572,1551,1069,1572,1060,1069,1550,1582,1024,1060,1551,11,43,35,1063,42,1551,1572,1572,1583,1066,0,47,42,1551,555]

theorem envBound6462 : H12AffineFastState.Bounded env6462 := by
  intro p hp
  have h : env6462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6461_6462 : H12AffineEnvironment.transform 10 1572 env6461 = env6462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1572 env6461 == env6462) = true)

def env6463 : List Nat := [2,4,8,1,32,1,3,47,32,1024,1028,1071,1069,1028,1060,1069,1070,1038,1024,1060,1071,11,43,35,1063,42,1071,1028,1028,1039,1066,0,47,42,1071,11]

theorem envBound6463 : H12AffineFastState.Bounded env6463 := by
  intro p hp
  have h : env6463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6462_6463 : H12AffineEnvironment.transform 8 32 env6462 = env6463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env6462 == env6463) = true)

theorem identity6463 : scanCanonicalize (H12AffineFastState.compose env6463 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound6463 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env6464 : List Nat := [2,4,8,1,32,1,3,47,32,4,0,43,41,0,32,41,42,10,4,32,43,11,43,35,35,42,43,0,0,11,46,0,47,42,43,11]

theorem envBound6464 : H12AffineFastState.Bounded env6464 := by
  intro p hp
  have h : env6464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6463_6464 : H12AffineEnvironment.transform 9 4 env6463 = env6464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env6463 == env6464) = true)

theorem identity6464 : scanCanonicalize (H12AffineFastState.compose env6464 (packedSelected [11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound6464 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env6465 : List Nat := [2,4,8,1,0,1,3,15,0,4,0,11,9,0,0,9,10,10,4,0,11,11,11,3,3,10,11,0,0,11,14,0,15,10,11,11]

theorem envBound6465 : H12AffineFastState.Bounded env6465 := by
  intro p hp
  have h : env6465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6464_6465 : H12AffineEnvironment.transform 4 0 env6464 = env6465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env6464 == env6465) = true)

def env6466 : List Nat := [2,0,8,1,0,1,3,11,0,0,0,11,9,0,0,9,10,10,0,0,11,11,11,3,3,10,11,0,0,11,10,0,11,10,11,11]

theorem envBound6466 : H12AffineFastState.Bounded env6466 := by
  intro p hp
  have h : env6466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6465_6466 : H12AffineEnvironment.transform 1 0 env6465 = env6466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env6465 == env6466) = true)

def leafEnv6466 : List Nat := [2,0,8,1,0,1,3,11,0,0,0,11,9,0,0,9,10,10,0,0,11,11,11,3,10,3,1,10,11,0,0,11,10,0,11,10,0,9,11,11,1,10,0]

def active6466 : List Nat := [0,2]

def tree6466 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6466 : H12WitnessSearch.Good tree6466 := H12GlobalWitnessIndex.good

theorem leafIdentity6466 : H12AffineFastState.composeSystem env6466 rootObs = leafEnv6466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6466 rootObs == leafEnv6466) = true)

theorem terminalChecked6466 : H12PackedTerminal.terminalCheckFast leafEnv6466 active6466 tree6466 = true := by decide +kernel

def env6467 : List Nat := [2,1,8,1,0,1,3,10,0,1,0,11,9,0,0,9,10,10,1,0,11,11,11,3,3,10,11,0,0,11,11,0,10,10,11,11]

theorem envBound6467 : H12AffineFastState.Bounded env6467 := by
  intro p hp
  have h : env6467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6465_6467 : H12AffineEnvironment.transform 1 1 env6465 = env6467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6465 == env6467) = true)

theorem identity6467 : scanCanonicalize (H12AffineFastState.compose env6467 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound6467 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6468 : List Nat := [2,1,3,1,0,1,3,1,0,1,0,0,2,0,0,2,1,1,1,0,0,0,0,3,3,1,0,0,0,0,0,0,1,1,0,0]

theorem envBound6468 : H12AffineFastState.Bounded env6468 := by
  intro p hp
  have h : env6468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6467_6468 : H12AffineEnvironment.transform 2 3 env6467 = env6468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env6467 == env6468) = true)

def leafEnv6468 : List Nat := [2,1,3,1,0,1,3,1,0,1,0,0,2,0,0,2,1,1,1,0,0,0,0,3,0,3,1,1,0,0,0,0,0,0,1,1,1,2,0,0,1,1,0]

def active6468 : List Nat := [0]

def tree6468 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6468 : H12WitnessSearch.Good tree6468 := H12GlobalWitnessIndex.good

theorem leafIdentity6468 : H12AffineFastState.composeSystem env6468 rootObs = leafEnv6468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6468 rootObs == leafEnv6468) = true)

theorem terminalChecked6468 : H12PackedTerminal.terminalCheckFast leafEnv6468 active6468 tree6468 = true := by decide +kernel

def env6469 : List Nat := [2,4,8,1,32,1,3,47,33,1024,1029,1070,1069,1029,1060,1069,1071,1039,1024,1060,1070,11,43,35,1063,42,1070,1029,1029,1038,1066,0,47,42,1070,10]

theorem envBound6469 : H12AffineFastState.Bounded env6469 := by
  intro p hp
  have h : env6469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6462_6469 : H12AffineEnvironment.transform 8 33 env6462 = env6469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env6462 == env6469) = true)

theorem identity6469 : scanCanonicalize (H12AffineFastState.compose env6469 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound6469 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env6470 : List Nat := [2,4,8,1,32,1,3,47,33,14,11,32,35,11,42,35,33,1,14,42,32,11,43,35,41,42,32,11,11,0,36,0,47,42,32,10]

theorem envBound6470 : H12AffineFastState.Bounded env6470 := by
  intro p hp
  have h : env6470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6469_6470 : H12AffineEnvironment.transform 9 14 env6469 = env6470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env6469 == env6470) = true)

theorem identity6470 : scanCanonicalize (H12AffineFastState.compose env6470 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound6470 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6471 : List Nat := [2,4,8,1,10,1,3,5,11,14,11,10,9,11,0,9,11,1,14,0,10,11,1,9,3,0,10,11,11,0,14,0,5,0,10,10]

theorem envBound6471 : H12AffineFastState.Bounded env6471 := by
  intro p hp
  have h : env6471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6470_6471 : H12AffineEnvironment.transform 4 10 env6470 = env6471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env6470 == env6471) = true)

theorem identity6471 : scanCanonicalize (H12AffineFastState.compose env6471 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound6471 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6472 : List Nat := [2,0,8,1,10,1,3,1,11,10,11,10,9,11,0,9,11,1,10,0,10,11,1,9,3,0,10,11,11,0,10,0,1,0,10,10]

theorem envBound6472 : H12AffineFastState.Bounded env6472 := by
  intro p hp
  have h : env6472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6471_6472 : H12AffineEnvironment.transform 1 0 env6471 = env6472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env6471 == env6472) = true)

theorem identity6472 : scanCanonicalize (H12AffineFastState.compose env6472 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound6472 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env6473 : List Nat := [2,0,3,1,1,1,3,1,0,1,0,1,2,0,0,2,0,1,1,0,1,0,1,2,3,0,1,0,0,0,1,0,1,0,1,1]

theorem envBound6473 : H12AffineFastState.Bounded env6473 := by
  intro p hp
  have h : env6473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6472_6473 : H12AffineEnvironment.transform 2 3 env6472 = env6473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env6472 == env6473) = true)

def leafEnv6473 : List Nat := [2,0,3,1,1,1,3,1,0,1,0,1,2,0,0,2,0,1,1,0,1,0,1,2,1,3,1,0,1,0,0,0,1,0,1,0,0,3,1,1,1,0,0]

def active6473 : List Nat := [0]

def tree6473 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6473 : H12WitnessSearch.Good tree6473 := H12GlobalWitnessIndex.good

theorem leafIdentity6473 : H12AffineFastState.composeSystem env6473 rootObs = leafEnv6473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6473 rootObs == leafEnv6473) = true)

theorem terminalChecked6473 : H12PackedTerminal.terminalCheckFast leafEnv6473 active6473 tree6473 = true := by decide +kernel

def env6474 : List Nat := [2,4,8,1,32,1,3,47,512,1024,1573,1551,1068,1572,1061,1068,1550,1583,1024,1061,1551,11,43,35,1062,42,1550,1572,1572,1582,1066,0,47,42,1551,555]

theorem envBound6474 : H12AffineFastState.Bounded env6474 := by
  intro p hp
  have h : env6474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6461_6474 : H12AffineEnvironment.transform 10 1573 env6461 = env6474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1573 env6461 == env6474) = true)

theorem identity6474 : scanCanonicalize (H12AffineFastState.compose env6474 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound6474 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6475 : List Nat := [2,4,8,1,11,1,3,4,512,1024,1550,1551,1031,1551,1038,1031,1550,1540,1024,1038,1551,11,0,8,1037,1,1550,1551,1551,1541,1025,0,4,1,1551,512]

theorem envBound6475 : H12AffineFastState.Bounded env6475 := by
  intro p hp
  have h : env6475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6474_6475 : H12AffineEnvironment.transform 4 11 env6474 = env6475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env6474 == env6475) = true)

theorem identity6475 : scanCanonicalize (H12AffineFastState.compose env6475 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound6475 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env6476 : List Nat := [2,4,3,1,0,1,3,4,512,1024,1541,1540,1031,1540,1029,1031,1541,1540,1024,1029,1540,0,0,3,1030,1,1541,1540,1540,1541,1025,0,4,1,1540,512]

theorem envBound6476 : H12AffineFastState.Bounded env6476 := by
  intro p hp
  have h : env6476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6475_6476 : H12AffineEnvironment.transform 2 3 env6475 = env6476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env6475 == env6476) = true)

theorem identity6476 : scanCanonicalize (H12AffineFastState.compose env6476 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound6476 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6477 : List Nat := [2,4,3,1,0,1,3,4,0,1024,1029,1028,1031,1028,1029,1031,1029,1028,1024,1029,1028,0,0,3,1030,1,1029,1028,1028,1029,1025,0,4,1,1028,0]

theorem envBound6477 : H12AffineFastState.Bounded env6477 := by
  intro p hp
  have h : env6477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6476_6477 : H12AffineEnvironment.transform 8 0 env6476 = env6477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env6476 == env6477) = true)

theorem identity6477 : scanCanonicalize (H12AffineFastState.compose env6477 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound6477 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env6478 : List Nat := [2,4,3,1,0,1,3,4,0,5,0,1,2,1,0,2,0,1,5,0,1,0,0,3,3,1,0,1,1,0,4,0,4,1,1,0]

theorem envBound6478 : H12AffineFastState.Bounded env6478 := by
  intro p hp
  have h : env6478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6477_6478 : H12AffineEnvironment.transform 9 5 env6477 = env6478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env6477 == env6478) = true)

def leafEnv6478 : List Nat := [2,4,3,1,0,1,3,4,0,5,0,1,2,1,0,2,0,1,5,0,1,0,0,3,4,3,1,1,0,1,1,0,4,0,4,1,4,2,1,0,1,0,0]

def active6478 : List Nat := [0,1]

def tree6478 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6478 : H12WitnessSearch.Good tree6478 := H12GlobalWitnessIndex.good

theorem leafIdentity6478 : H12AffineFastState.composeSystem env6478 rootObs = leafEnv6478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6478 rootObs == leafEnv6478) = true)

theorem terminalChecked6478 : H12PackedTerminal.terminalCheckFast leafEnv6478 active6478 tree6478 = true := by decide +kernel

def env6479 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8495,4525,8121,1024,32768,4096,136,61877,41002,8329,61876,61241,16384,16812,22560,1285,1,256,20481,45065,61960]

theorem envBound6479 : H12AffineFastState.Bounded env6479 := by
  intro p hp
  have h : env6479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6453_6479 : H12AffineEnvironment.transform 17 8121 env6453 = env6479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8121 env6453 == env6479) = true)

theorem identity6479 : scanCanonicalize (H12AffineFastState.compose env6479 (packedSelected [0,7,9,13,20,21,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound6479 : packedSelected [0,7,9,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env6480 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,16384,32768,8235,4265,7869,1024,32768,4096,136,61617,41002,8329,61616,60989,16384,16552,22560,1025,1,4,20481,45065,61960]

theorem envBound6480 : H12AffineFastState.Bounded env6480 := by
  intro p hp
  have h : env6480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6479_6480 : H12AffineEnvironment.transform 7 4 env6479 = env6480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env6479 == env6480) = true)

theorem identity6480 : scanCanonicalize (H12AffineFastState.compose env6480 (packedSelected [6,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 2106) := by decide +kernel

theorem selectedBound6480 : packedSelected [6,13,17] rootPS < 2^1333 := by decide +kernel

def env6481 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,2106,32768,8235,4265,7869,1024,32768,4096,136,47243,41002,8329,47242,42503,2106,2194,4122,1025,1,4,6203,45065,47666]

theorem envBound6481 : H12AffineFastState.Bounded env6481 := by
  intro p hp
  have h : env6481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6480_6481 : H12AffineEnvironment.transform 13 2106 env6480 = env6481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2106 env6480 == env6481) = true)

theorem identity6481 : scanCanonicalize (H12AffineFastState.compose env6481 (packedSelected [2,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound6481 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env6482 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1589,8192,2106,32768,8235,1692,2184,1024,32768,1589,136,44734,41002,8329,44735,42503,2106,2194,1583,1025,1,4,3598,42556,44039]

theorem envBound6482 : H12AffineFastState.Bounded env6482 := by
  intro p hp
  have h : env6482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6481_6482 : H12AffineEnvironment.transform 11 1589 env6481 = env6482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env6481 == env6482) = true)

theorem identity6482 : scanCanonicalize (H12AffineFastState.compose env6482 (packedSelected [0,4,6,7,9,13,21] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound6482 : packedSelected [0,4,6,7,9,13,21] rootPS < 2^1333 := by decide +kernel

def env6483 : List Nat := [2,4,8,16,32,16,128,4,512,1024,1703,1589,8192,1693,32768,8235,1692,1583,1024,32768,1589,136,40985,41002,8329,40984,42503,1693,1589,1583,1025,1,4,169,42556,41632]

theorem envBound6483 : H12AffineFastState.Bounded env6483 := by
  intro p hp
  have h : env6483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6482_6483 : H12AffineEnvironment.transform 10 1703 env6482 = env6483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env6482 == env6483) = true)

theorem identity6483 : scanCanonicalize (H12AffineFastState.compose env6483 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound6483 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env6484 : List Nat := [2,4,8,16,32,16,128,4,512,1024,1703,1589,8192,1693,8201,8235,1692,1583,1024,8201,1589,136,16,35,8329,17,1550,1693,1589,1583,1025,1,4,169,1589,681]

theorem envBound6484 : H12AffineFastState.Bounded env6484 := by
  intro p hp
  have h : env6484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6483_6484 : H12AffineEnvironment.transform 14 8201 env6483 = env6484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env6483 == env6484) = true)

theorem identity6484 : scanCanonicalize (H12AffineFastState.compose env6484 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6484 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6485 : List Nat := [2,4,8,16,32,16,41,4,512,1024,1550,1589,8192,1588,8201,8235,1589,1583,1024,8201,1589,33,16,35,8224,17,1550,1588,1589,1583,1025,1,4,0,1589,512]

theorem envBound6485 : H12AffineFastState.Bounded env6485 := by
  intro p hp
  have h : env6485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6484_6485 : H12AffineEnvironment.transform 6 41 env6484 = env6485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6484 == env6485) = true)

theorem identity6485 : scanCanonicalize (H12AffineFastState.compose env6485 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound6485 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6486 : List Nat := [2,4,8,10,32,10,41,4,512,1024,1550,1583,8192,1582,8201,8235,1583,1583,1024,8201,1583,33,10,35,8224,11,1550,1582,1583,1583,1025,1,4,0,1583,512]

theorem envBound6486 : H12AffineFastState.Bounded env6486 := by
  intro p hp
  have h : env6486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6485_6486 : H12AffineEnvironment.transform 3 10 env6485 = env6486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env6485 == env6486) = true)

theorem identity6486 : scanCanonicalize (H12AffineFastState.compose env6486 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound6486 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env6487 : List Nat := [2,4,8,10,1,10,8,4,512,1024,1550,1550,8192,1551,8201,8202,1550,1550,1024,8201,1550,0,10,2,8193,11,1550,1551,1550,1550,1025,1,4,0,1550,512]

theorem envBound6487 : H12AffineFastState.Bounded env6487 := by
  intro p hp
  have h : env6487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6486_6487 : H12AffineEnvironment.transform 4 1 env6486 = env6487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env6486 == env6487) = true)

theorem identity6487 : scanCanonicalize (H12AffineFastState.compose env6487 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 526) := by decide +kernel

theorem selectedBound6487 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6488 : List Nat := [2,4,8,10,1,10,8,4,512,526,0,0,8192,1,8201,8202,0,0,526,8201,0,0,10,2,8193,11,0,1,0,0,527,1,4,0,0,512]

theorem envBound6488 : H12AffineFastState.Bounded env6488 := by
  intro p hp
  have h : env6488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6487_6488 : H12AffineEnvironment.transform 9 526 env6487 = env6488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 526 env6487 == env6488) = true)

def env6489 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8495,4525,262144,1024,32768,4096,137,8388608,41002,8329,8388609,323712,16384,16812,22560,1285,8450485,256,20481,45064,8389565]

theorem envBound6489 : H12AffineFastState.Bounded env6489 := by
  intro p hp
  have h : env6489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6451_6489 : H12AffineEnvironment.transform 21 137 env6451 = env6489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 137 env6451 == env6489) = true)

theorem identity6489 : scanCanonicalize (H12AffineFastState.compose env6489 (packedSelected [7,9,13,17,20,22,27] rootPS)) = affineNative (2^(22+1) ^^^ 323488) := by decide +kernel

theorem selectedBound6489 : packedSelected [7,9,13,17,20,22,27] rootPS < 2^1333 := by decide +kernel

def env6490 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8495,4525,262144,1024,32768,4096,137,323488,41002,8329,323489,323712,16384,16812,22560,1285,269845,256,20481,45064,322589]

theorem envBound6490 : H12AffineFastState.Bounded env6490 := by
  intro p hp
  have h : env6490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6489_6490 : H12AffineEnvironment.transform 22 323488 env6489 = env6490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 323488 env6489 == env6490) = true)

def env6491 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8495,4525,7952,1024,32768,4096,137,61616,41002,8329,61617,61328,16384,16812,22560,1285,261,256,20481,45064,62221]

theorem envBound6491 : H12AffineFastState.Bounded env6491 := by
  intro p hp
  have h : env6491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6490_6491 : H12AffineEnvironment.transform 17 7952 env6490 = env6491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7952 env6490 == env6491) = true)

theorem identity6491 : scanCanonicalize (H12AffineFastState.compose env6491 (packedSelected [2,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 28680) := by decide +kernel

theorem selectedBound6491 : packedSelected [2,23,32] rootPS < 2^1333 := by decide +kernel

def env6492 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,28680,8495,4525,7952,1024,28680,4096,137,184,20514,8329,185,8088,16384,16812,22560,1285,261,256,20481,16384,773]

theorem envBound6492 : H12AffineFastState.Bounded env6492 := by
  intro p hp
  have h : env6492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6491_6492 : H12AffineEnvironment.transform 14 28680 env6491 = env6492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28680 env6491 == env6492) = true)

theorem identity6492 : scanCanonicalize (H12AffineFastState.compose env6492 (packedSelected [6,17,21] rootPS)) = affineNative (2^(11+1) ^^^ 2194) := by decide +kernel

theorem selectedBound6492 : packedSelected [6,17,21] rootPS < 2^1333 := by decide +kernel

def env6493 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2194,8192,16384,26778,8495,2367,1922,1024,26778,2194,137,184,18608,8329,185,1802,16384,16812,16562,1285,261,256,18579,16384,773]

theorem envBound6493 : H12AffineFastState.Bounded env6493 := by
  intro p hp
  have h : env6493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6492_6493 : H12AffineEnvironment.transform 11 2194 env6492 = env6493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2194 env6492 == env6493) = true)

theorem identity6493 : scanCanonicalize (H12AffineFastState.compose env6493 (packedSelected [1,2,5,6,8,11,18,24] rootPS)) = affineNative (2^(13+1) ^^^ 1841) := by decide +kernel

theorem selectedBound6493 : packedSelected [1,2,5,6,8,11,18,24] rootPS < 2^1333 := by decide +kernel

def env6494 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2194,8192,1841,12203,8495,2367,1922,1024,12203,2194,137,184,3969,8329,185,1802,1841,1693,1923,1285,261,256,4002,1841,773]

theorem envBound6494 : H12AffineFastState.Bounded env6494 := by
  intro p hp
  have h : env6494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6493_6494 : H12AffineEnvironment.transform 13 1841 env6493 = env6494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1841 env6493 == env6494) = true)

theorem identity6494 : scanCanonicalize (H12AffineFastState.compose env6494 (packedSelected [3,5,6,10,12,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound6494 : packedSelected [3,5,6,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env6495 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1703,1589,8192,1841,8460,8495,1944,1922,1024,8460,1589,137,184,294,8329,185,1802,1841,1693,1923,1285,261,256,261,1841,773]

theorem envBound6495 : H12AffineFastState.Bounded env6495 := by
  intro p hp
  have h : env6495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6494_6495 : H12AffineEnvironment.transform 10 1703 env6494 = env6495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env6494 == env6495) = true)

theorem identity6495 : scanCanonicalize (H12AffineFastState.compose env6495 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6495 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env6496 : List Nat := [2,4,8,16,32,16,41,256,512,1024,1550,1589,8192,1841,8460,8495,1841,1835,1024,8460,1589,32,17,294,8224,16,1802,1841,1588,1834,1285,261,256,261,1841,773]

theorem envBound6496 : H12AffineFastState.Bounded env6496 := by
  intro p hp
  have h : env6496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6495_6496 : H12AffineEnvironment.transform 6 41 env6495 = env6496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6495 == env6496) = true)

theorem identity6496 : scanCanonicalize (H12AffineFastState.compose env6496 (packedSelected [3,5] rootPS)) = affineNative (2^(12+1) ^^^ 1030) := by decide +kernel

theorem selectedBound6496 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env6497 : List Nat := [2,4,8,16,32,16,41,256,512,1024,1550,1589,1030,1841,1290,1321,1841,1835,1024,1290,1589,32,17,294,1062,16,1802,1841,1588,1834,1285,261,256,261,1841,773]

theorem envBound6497 : H12AffineFastState.Bounded env6497 := by
  intro p hp
  have h : env6497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6496_6497 : H12AffineEnvironment.transform 12 1030 env6496 = env6497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1030 env6496 == env6497) = true)

theorem identity6497 : scanCanonicalize (H12AffineFastState.compose env6497 (packedSelected [3,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound6497 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env6498 : List Nat := [2,4,8,16,32,16,41,5,512,1024,1550,1589,1030,1588,1039,1068,1588,1582,1024,1039,1589,32,17,35,1062,16,1551,1588,1588,1583,1024,0,5,0,1588,512]

theorem envBound6498 : H12AffineFastState.Bounded env6498 := by
  intro p hp
  have h : env6498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6497_6498 : H12AffineEnvironment.transform 7 5 env6497 = env6498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env6497 == env6498) = true)

theorem identity6498 : scanCanonicalize (H12AffineFastState.compose env6498 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound6498 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env6499 : List Nat := [2,4,8,16,32,16,41,5,0,1024,1038,1077,1030,1076,1039,1068,1076,1070,1024,1039,1077,32,17,35,1062,16,1039,1076,1076,1071,1024,0,5,0,1076,0]

theorem envBound6499 : H12AffineFastState.Bounded env6499 := by
  intro p hp
  have h : env6499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6498_6499 : H12AffineEnvironment.transform 8 0 env6498 = env6499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env6498 == env6499) = true)

theorem identity6499 : scanCanonicalize (H12AffineFastState.compose env6499 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound6499 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6500 : List Nat := [2,4,8,16,32,16,41,5,0,52,58,1,50,0,59,24,0,26,52,59,1,32,17,35,18,16,59,0,0,27,52,0,5,0,0,0]

theorem envBound6500 : H12AffineFastState.Bounded env6500 := by
  intro p hp
  have h : env6500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6499_6500 : H12AffineEnvironment.transform 9 52 env6499 = env6500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env6499 == env6500) = true)

theorem identity6500 : scanCanonicalize (H12AffineFastState.compose env6500 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound6500 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6501 : List Nat := [2,4,8,11,32,11,41,5,0,47,33,1,41,0,32,3,0,1,47,32,1,32,10,35,9,11,32,0,0,0,47,0,5,0,0,0]

theorem envBound6501 : H12AffineFastState.Bounded env6501 := by
  intro p hp
  have h : env6501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6500_6501 : H12AffineEnvironment.transform 3 11 env6500 = env6501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env6500 == env6501) = true)

def env6502 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8495,4525,7953,1024,32768,4096,137,61617,41002,8329,61616,61329,16384,16812,22560,1285,260,256,20481,45064,62220]

theorem envBound6502 : H12AffineFastState.Bounded env6502 := by
  intro p hp
  have h : env6502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6490_6502 : H12AffineEnvironment.transform 17 7953 env6490 = env6502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7953 env6490 == env6502) = true)

theorem identity6502 : scanCanonicalize (H12AffineFastState.compose env6502 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 8612) := by decide +kernel

theorem selectedBound6502 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env6503 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8612,8495,4525,7953,1024,8612,4096,137,20757,398,8329,20756,20021,16384,16812,22560,1285,260,256,20481,4524,21160]

theorem envBound6503 : H12AffineFastState.Bounded env6503 := by
  intro p hp
  have h : env6503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6502_6503 : H12AffineEnvironment.transform 14 8612 env6502 = env6503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8612 env6502 == env6503) = true)

theorem identity6503 : scanCanonicalize (H12AffineFastState.compose env6503 (packedSelected [2,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 1677) := by decide +kernel

theorem selectedBound6503 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env6504 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1677,8192,16384,8612,8495,1824,2460,1024,8612,1677,137,18328,398,8329,18329,20021,16384,16812,20141,1285,260,256,18060,1825,17445]

theorem envBound6504 : H12AffineFastState.Bounded env6504 := by
  intro p hp
  have h : env6504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6503_6504 : H12AffineEnvironment.transform 11 1677 env6503 = env6504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1677 env6503 == env6504) = true)

theorem identity6504 : scanCanonicalize (H12AffineFastState.compose env6504 (packedSelected [9,17,21,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound6504 : packedSelected [9,17,21,22] rootPS < 2^1333 := by decide +kernel

def env6505 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1677,8192,16384,8353,8234,1573,2201,1024,8353,1677,137,18077,139,8329,18076,20021,16384,16553,20141,1024,1,5,18060,1572,17445]

theorem envBound6505 : H12AffineFastState.Bounded env6505 := by
  intro p hp
  have h : env6505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6504_6505 : H12AffineEnvironment.transform 7 5 env6504 = env6505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env6504 == env6505) = true)

theorem identity6505 : scanCanonicalize (H12AffineFastState.compose env6505 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 11397) := by decide +kernel

theorem selectedBound6505 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6506 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1677,8192,11397,8353,8234,1573,2201,1024,8353,1677,137,10776,139,8329,10777,8880,11397,11308,8744,1024,1,5,10761,1572,10400]

theorem envBound6506 : H12AffineFastState.Bounded env6506 := by
  intro p hp
  have h : env6506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6505_6506 : H12AffineEnvironment.transform 13 11397 env6505 = env6506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11397 env6505 == env6506) = true)

theorem identity6506 : scanCanonicalize (H12AffineFastState.compose env6506 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 171) := by decide +kernel

theorem selectedBound6506 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6507 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1677,171,3118,10,129,1573,2201,1024,10,1677,137,2739,139,34,2738,539,3118,3207,643,1024,1,5,2722,1572,2059]

theorem envBound6507 : H12AffineFastState.Bounded env6507 := by
  intro p hp
  have h : env6507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6506_6507 : H12AffineEnvironment.transform 12 171 env6506 = env6507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 171 env6506 == env6507) = true)

theorem identity6507 : scanCanonicalize (H12AffineFastState.compose env6507 (packedSelected [1,3,7,9,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound6507 : packedSelected [1,3,7,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env6508 : List Nat := [2,4,8,16,32,16,128,5,512,1024,529,1677,171,1599,10,129,1573,648,1024,10,1677,137,162,139,34,163,539,1599,1686,643,1024,1,5,179,1572,538]

theorem envBound6508 : H12AffineFastState.Bounded env6508 := by
  intro p hp
  have h : env6508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6507_6508 : H12AffineEnvironment.transform 10 529 env6507 = env6508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env6507 == env6508) = true)

theorem identity6508 : scanCanonicalize (H12AffineFastState.compose env6508 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound6508 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env6509 : List Nat := [2,4,8,16,32,16,51,5,512,1024,529,1598,24,1599,10,50,1573,571,1024,10,1598,58,17,56,34,16,539,1599,1573,560,1024,1,5,0,1572,538]

theorem envBound6509 : H12AffineFastState.Bounded env6509 := by
  intro p hp
  have h : env6509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6508_6509 : H12AffineEnvironment.transform 6 51 env6508 = env6509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env6508 == env6509) = true)

theorem identity6509 : scanCanonicalize (H12AffineFastState.compose env6509 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound6509 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env6510 : List Nat := [2,4,8,16,17,16,2,5,512,1024,529,1551,24,1550,10,3,1556,522,1024,10,1551,11,17,9,19,16,539,1550,1556,513,1024,1,5,0,1557,538]

theorem envBound6510 : H12AffineFastState.Bounded env6510 := by
  intro p hp
  have h : env6510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6509_6510 : H12AffineEnvironment.transform 4 17 env6509 = env6510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env6509 == env6510) = true)

theorem identity6510 : scanCanonicalize (H12AffineFastState.compose env6510 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound6510 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env6511 : List Nat := [2,4,8,0,1,0,2,5,512,1024,513,1551,8,1550,10,3,1540,522,1024,10,1551,11,1,9,3,0,523,1550,1540,513,1024,1,5,0,1541,522]

theorem envBound6511 : H12AffineFastState.Bounded env6511 := by
  intro p hp
  have h : env6511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6510_6511 : H12AffineEnvironment.transform 3 0 env6510 = env6511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env6510 == env6511) = true)

theorem identity6511 : scanCanonicalize (H12AffineFastState.compose env6511 (packedSelected [0,1,5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound6511 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env6512 : List Nat := [2,4,8,0,1,0,2,5,1,1024,0,1038,8,1039,10,3,1029,11,1024,10,1038,11,1,9,3,0,10,1039,1029,0,1024,1,5,0,1028,11]

theorem envBound6512 : H12AffineFastState.Bounded env6512 := by
  intro p hp
  have h : env6512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6511_6512 : H12AffineEnvironment.transform 8 1 env6511 = env6512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env6511 == env6512) = true)

theorem identity6512 : scanCanonicalize (H12AffineFastState.compose env6512 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound6512 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env6513 : List Nat := [2,4,3,0,1,0,2,5,1,1024,0,1029,3,1028,1,3,1029,0,1024,1,1029,0,1,2,3,0,1,1028,1029,0,1024,1,5,0,1028,0]

theorem envBound6513 : H12AffineFastState.Bounded env6513 := by
  intro p hp
  have h : env6513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6512_6513 : H12AffineEnvironment.transform 2 3 env6512 = env6513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env6512 == env6513) = true)

theorem identity6513 : scanCanonicalize (H12AffineFastState.compose env6513 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 1) := by decide +kernel

theorem selectedBound6513 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6514 : List Nat := [2,4,3,0,1,0,2,5,1,1,0,4,3,5,1,3,4,0,1,1,4,0,1,2,3,0,1,5,4,0,1,1,5,0,5,0]

theorem envBound6514 : H12AffineFastState.Bounded env6514 := by
  intro p hp
  have h : env6514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6513_6514 : H12AffineEnvironment.transform 9 1 env6513 = env6514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env6513 == env6514) = true)

def env6515 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8495,4524,262144,1024,32768,4096,4194304,8388608,41002,8329,8388608,323713,16384,16813,22561,1285,12644668,256,20480,4239489,8389564]

theorem envBound6515 : H12AffineFastState.Bounded env6515 := by
  intro p hp
  have h : env6515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6450_6515 : H12AffineEnvironment.transform 5 17 env6450 = env6515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env6450 == env6515) = true)

theorem identity6515 : scanCanonicalize (H12AffineFastState.compose env6515 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound6515 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env6516 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8495,4524,262144,1024,32768,4096,4194304,444,41002,8329,444,323713,16384,16813,22561,1285,4255872,256,20480,4239489,512]

theorem envBound6516 : H12AffineFastState.Bounded env6516 := by
  intro p hp
  have h : env6516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6515_6516 : H12AffineEnvironment.transform 22 444 env6515 = env6516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env6515 == env6516) = true)

theorem identity6516 : scanCanonicalize (H12AffineFastState.compose env6516 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound6516 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6517 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8495,4524,262144,1024,32768,4096,41349,444,41002,8329,444,323713,16384,16813,22561,1285,20741,256,20480,4356,512]

theorem envBound6517 : H12AffineFastState.Bounded env6517 := by
  intro p hp
  have h : env6517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6516_6517 : H12AffineEnvironment.transform 21 41349 env6516 = env6517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env6516 == env6517) = true)

theorem identity6517 : scanCanonicalize (H12AffineFastState.compose env6517 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26261) := by decide +kernel

theorem selectedBound6517 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6518 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,26261,8495,4524,262144,1024,26261,4096,18192,444,18111,8329,444,267796,16384,16813,22561,1285,20741,256,20480,4356,512]

theorem envBound6518 : H12AffineFastState.Bounded env6518 := by
  intro p hp
  have h : env6518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6517_6518 : H12AffineEnvironment.transform 14 26261 env6517 = env6518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26261 env6517 == env6518) = true)

theorem identity6518 : scanCanonicalize (H12AffineFastState.compose env6518 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4524) := by decide +kernel

theorem selectedBound6518 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env6519 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4524,14137,8495,4524,262144,1024,14137,4096,5820,444,5907,8329,444,267796,4524,4097,2445,1285,169,256,428,4356,512]

theorem envBound6519 : H12AffineFastState.Bounded env6519 := by
  intro p hp
  have h : env6519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6518_6519 : H12AffineEnvironment.transform 13 4524 env6518 = env6519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4524 env6518 == env6519) = true)

theorem identity6519 : scanCanonicalize (H12AffineFastState.compose env6519 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound6519 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env6520 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4524,14137,8495,4524,2185,1024,14137,4096,5820,444,5907,8329,444,7837,4524,4097,2445,1285,169,256,428,4356,512]

theorem envBound6520 : H12AffineFastState.Bounded env6520 := by
  intro p hp
  have h : env6520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6519_6520 : H12AffineEnvironment.transform 17 2185 env6519 = env6520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env6519 == env6520) = true)

theorem identity6520 : scanCanonicalize (H12AffineFastState.compose env6520 (packedSelected [18,23] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound6520 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env6521 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4097,13972,8322,4097,2185,1024,13972,4096,5820,17,5822,8329,17,7837,4097,4097,2080,1192,169,173,1,4265,512]

theorem envBound6521 : H12AffineFastState.Bounded env6521 := by
  intro p hp
  have h : env6521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6520_6521 : H12AffineEnvironment.transform 7 173 env6520 = env6521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env6520 == env6521) = true)

theorem identity6521 : scanCanonicalize (H12AffineFastState.compose env6521 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound6521 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env6522 : List Nat := [2,4,8,16,32,17,128,173,512,1024,674,4096,8192,4097,13972,8322,4097,555,1024,13972,4096,5820,17,5822,8329,17,5183,4097,4097,642,1192,169,173,1,4265,512]

theorem envBound6522 : H12AffineFastState.Bounded env6522 := by
  intro p hp
  have h : env6522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6521_6522 : H12AffineEnvironment.transform 10 674 env6521 = env6522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env6521 == env6522) = true)

theorem identity6522 : scanCanonicalize (H12AffineFastState.compose env6522 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 1692) := by decide +kernel

theorem selectedBound6522 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env6523 : List Nat := [2,4,8,16,32,17,128,173,512,1024,674,1692,8192,1693,8200,8322,1693,555,1024,8200,1692,32,17,34,8329,17,675,1693,1693,642,1192,169,173,1,1589,512]

theorem envBound6523 : H12AffineFastState.Bounded env6523 := by
  intro p hp
  have h : env6523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6522_6523 : H12AffineEnvironment.transform 11 1692 env6522 = env6523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1692 env6522 == env6523) = true)

theorem identity6523 : scanCanonicalize (H12AffineFastState.compose env6523 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6523 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6524 : List Nat := [2,4,8,16,32,17,41,4,512,1024,523,1589,8192,1588,8200,8235,1588,555,1024,8200,1589,32,17,34,8224,17,522,1588,1588,555,1025,0,4,1,1589,512]

theorem envBound6524 : H12AffineFastState.Bounded env6524 := by
  intro p hp
  have h : env6524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6523_6524 : H12AffineEnvironment.transform 6 41 env6523 = env6524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6523 == env6524) = true)

theorem identity6524 : scanCanonicalize (H12AffineFastState.compose env6524 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 51) := by decide +kernel

theorem selectedBound6524 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6525 : List Nat := [2,4,8,16,32,17,41,4,512,1024,523,1589,51,1588,59,24,1588,555,1024,59,1589,32,17,34,19,17,522,1588,1588,555,1025,0,4,1,1589,512]

theorem envBound6525 : H12AffineFastState.Bounded env6525 := by
  intro p hp
  have h : env6525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6524_6525 : H12AffineEnvironment.transform 12 51 env6524 = env6525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 51 env6524 == env6525) = true)

theorem identity6525 : scanCanonicalize (H12AffineFastState.compose env6525 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound6525 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env6526 : List Nat := [2,4,8,16,17,17,24,4,512,1024,523,1540,2,1541,10,24,1541,538,1024,10,1540,17,17,19,19,17,522,1541,1541,538,1025,0,4,1,1540,512]

theorem envBound6526 : H12AffineFastState.Bounded env6526 := by
  intro p hp
  have h : env6526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6525_6526 : H12AffineEnvironment.transform 4 17 env6525 = env6526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env6525 == env6526) = true)

theorem identity6526 : scanCanonicalize (H12AffineFastState.compose env6526 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound6526 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env6527 : List Nat := [2,4,8,1,0,0,9,4,512,1024,523,1540,2,1541,10,9,1541,523,1024,10,1540,0,0,2,2,0,522,1541,1541,523,1025,0,4,1,1540,512]

theorem envBound6527 : H12AffineFastState.Bounded env6527 := by
  intro p hp
  have h : env6527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6526_6527 : H12AffineEnvironment.transform 3 1 env6526 = env6527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6526 == env6527) = true)

theorem identity6527 : scanCanonicalize (H12AffineFastState.compose env6527 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound6527 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6528 : List Nat := [2,4,8,1,0,0,9,4,10,1024,1,1038,2,1039,10,9,1039,1,1024,10,1038,0,0,2,2,0,0,1039,1039,1,1025,0,4,1,1038,10]

theorem envBound6528 : H12AffineFastState.Bounded env6528 := by
  intro p hp
  have h : env6528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6527_6528 : H12AffineEnvironment.transform 8 10 env6527 = env6528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env6527 == env6528) = true)

theorem identity6528 : scanCanonicalize (H12AffineFastState.compose env6528 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6528 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env6529 : List Nat := [2,4,2,1,0,0,3,4,0,1024,1,1028,2,1029,0,3,1029,1,1024,0,1028,0,0,2,2,0,0,1029,1029,1,1025,0,4,1,1028,0]

theorem envBound6529 : H12AffineFastState.Bounded env6529 := by
  intro p hp
  have h : env6529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6528_6529 : H12AffineEnvironment.transform 2 2 env6528 = env6529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6528 == env6529) = true)

def leafEnv6529 : List Nat := [2,4,2,1,0,0,3,4,0,1024,1,1028,2,1029,0,3,1029,1,1024,0,1028,0,0,2,1025,2,1,0,0,1029,1029,1,1025,0,4,1,4,2,1028,0,1,1028,0]

def active6529 : List Nat := [0,1,9]

def tree6529 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6529 : H12WitnessSearch.Good tree6529 := H12GlobalWitnessIndex.good

theorem leafIdentity6529 : H12AffineFastState.composeSystem env6529 rootObs = leafEnv6529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6529 rootObs == leafEnv6529) = true)

theorem terminalChecked6529 : H12PackedTerminal.terminalCheckFast leafEnv6529 active6529 tree6529 = true := by decide +kernel

def env6530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4096,4194304,8388608,41002,8329,8388688,323793,16384,16892,22641,74795,12644668,257,20560,4239489,8389612]

theorem envBound6530 : H12AffineFastState.Bounded env6530 := by
  intro p hp
  have h : env6530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6448_6530 : H12AffineEnvironment.transform 18 1025 env6448 = env6530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env6448 == env6530) = true)

theorem identity6530 : scanCanonicalize (H12AffineFastState.compose env6530 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 91183) := by decide +kernel

theorem selectedBound6530 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env6531 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4096,4194304,91183,41002,8329,91263,323793,16384,16892,22641,74795,4298003,257,20560,4239489,92099]

theorem envBound6531 : H12AffineFastState.Bounded env6531 := by
  intro p hp
  have h : env6531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6530_6531 : H12AffineEnvironment.transform 22 91183 env6530 = env6531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 91183 env6530 == env6531) = true)

def env6532 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4096,4194304,91183,41002,8329,91183,323713,16384,16812,22561,74795,4298003,257,20480,4239489,92051]

theorem envBound6532 : H12AffineFastState.Bounded env6532 := by
  intro p hp
  have h : env6532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6531_6532 : H12AffineEnvironment.transform 5 16 env6531 = env6532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env6531 == env6532) = true)

theorem identity6532 : scanCanonicalize (H12AffineFastState.compose env6532 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 26003) := by decide +kernel

theorem selectedBound6532 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env6533 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,26003,4525,262144,1025,32768,4096,4194304,444,41002,8329,444,323713,16384,16812,22561,16824,4255872,257,20480,4239489,512]

theorem envBound6533 : H12AffineFastState.Bounded env6533 := by
  intro p hp
  have h : env6533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6532_6533 : H12AffineEnvironment.transform 15 26003 env6532 = env6533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26003 env6532 == env6533) = true)

theorem identity6533 : scanCanonicalize (H12AffineFastState.compose env6533 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound6533 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6534 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,26003,4525,262144,1025,32768,4096,41348,444,41002,8329,444,323713,16384,16812,22561,16824,20740,257,20480,4357,512]

theorem envBound6534 : H12AffineFastState.Bounded env6534 := by
  intro p hp
  have h : env6534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6533_6534 : H12AffineEnvironment.transform 21 41348 env6533 = env6534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env6533 == env6534) = true)

theorem identity6534 : scanCanonicalize (H12AffineFastState.compose env6534 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26260) := by decide +kernel

theorem selectedBound6534 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6535 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,26260,26003,4525,262144,1025,26260,4096,18192,444,18110,8329,444,267797,16384,16812,22561,16824,20740,257,20480,4357,512]

theorem envBound6535 : H12AffineFastState.Bounded env6535 := by
  intro p hp
  have h : env6535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6534_6535 : H12AffineEnvironment.transform 14 26260 env6534 = env6535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26260 env6534 == env6535) = true)

theorem identity6535 : scanCanonicalize (H12AffineFastState.compose env6535 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound6535 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env6536 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,16384,26260,26003,1213,262144,1025,26260,1296,18192,444,18110,8329,444,262917,16384,16812,19761,16824,17428,257,17680,1045,512]

theorem envBound6536 : H12AffineFastState.Bounded env6536 := by
  intro p hp
  have h : env6536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6535_6536 : H12AffineEnvironment.transform 11 1296 env6535 = env6536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env6535 == env6536) = true)

theorem identity6536 : scanCanonicalize (H12AffineFastState.compose env6536 (packedSelected [0,1,3,8,10,11,12,15,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound6536 : packedSelected [0,1,3,8,10,11,12,15,27,28,32] rootPS < 2^1333 := by decide +kernel

def env6537 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,16384,26260,26003,1213,2341,1025,26260,1296,18192,444,18110,8329,444,2592,16384,16812,19761,16824,17428,257,17680,1045,512]

theorem envBound6537 : H12AffineFastState.Bounded env6537 := by
  intro p hp
  have h : env6537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6536_6537 : H12AffineEnvironment.transform 17 2341 env6536 = env6537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env6536 == env6537) = true)

def env6538 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,4194304,91183,41002,8329,91182,323712,16384,16813,22560,74795,4298003,257,20481,4239489,92050]

theorem envBound6538 : H12AffineFastState.Bounded env6538 := by
  intro p hp
  have h : env6538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6531_6538 : H12AffineEnvironment.transform 5 17 env6531 = env6538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env6531 == env6538) = true)

def env6539 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,46392,91183,41002,8329,91182,323712,16384,16813,22560,74795,73771,257,20481,1465,92050]

theorem envBound6539 : H12AffineFastState.Bounded env6539 := by
  intro p hp
  have h : env6539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6538_6539 : H12AffineEnvironment.transform 21 46392 env6538 = env6539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46392 env6538 == env6539) = true)

theorem identity6539 : scanCanonicalize (H12AffineFastState.compose env6539 (packedSelected [0,7,9,13,20,21,22] rootPS)) = affineNative (2^(15+1) ^^^ 38299) := by decide +kernel

theorem selectedBound6539 : packedSelected [0,7,9,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env6540 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,38299,4524,262144,1025,32768,4096,46392,61876,41002,8329,61877,323712,16384,16813,22560,45488,46512,257,20481,1465,61961]

theorem envBound6540 : H12AffineFastState.Bounded env6540 := by
  intro p hp
  have h : env6540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6539_6540 : H12AffineEnvironment.transform 15 38299 env6539 = env6540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38299 env6539 == env6540) = true)

theorem identity6540 : scanCanonicalize (H12AffineFastState.compose env6540 (packedSelected [2,11,18] rootPS)) = affineNative (2^(17+1) ^^^ 63544) := by decide +kernel

theorem selectedBound6540 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env6541 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,38299,4524,63544,1025,32768,4096,46392,61876,41002,8329,61877,2232,16384,16813,22560,45488,46512,257,20481,1465,61961]

theorem envBound6541 : H12AffineFastState.Bounded env6541 := by
  intro p hp
  have h : env6541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6540_6541 : H12AffineEnvironment.transform 17 63544 env6540 = env6541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 63544 env6540 == env6541) = true)

theorem identity6541 : scanCanonicalize (H12AffineFastState.compose env6541 (packedSelected [7,13,20,21,27] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound6541 : packedSelected [7,13,20,21,27] rootPS < 2^1333 := by decide +kernel

def env6542 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1213,8192,16384,32768,33062,1297,60549,1025,32768,1213,41349,58633,41002,8329,58632,2232,16384,16813,19613,42253,41229,257,17596,1465,59060]

theorem envBound6542 : H12AffineFastState.Bounded env6542 := by
  intro p hp
  have h : env6542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6541_6542 : H12AffineEnvironment.transform 11 1213 env6541 = env6542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env6541 == env6542) = true)

theorem identity6542 : scanCanonicalize (H12AffineFastState.compose env6542 (packedSelected [0,1,3,6,7,13,17,20,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 28351) := by decide +kernel

theorem selectedBound6542 : packedSelected [0,1,3,6,7,13,17,20,24,28] rootPS < 2^1333 := by decide +kernel

def env6543 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1213,8192,16384,28351,28569,1297,570,1025,28351,1213,20282,2998,20117,8329,2999,2232,16384,16813,19613,19378,20402,257,17596,1465,2059]

theorem envBound6543 : H12AffineFastState.Bounded env6543 := by
  intro p hp
  have h : env6543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6542_6543 : H12AffineEnvironment.transform 14 28351 env6542 = env6543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28351 env6542 == env6543) = true)

theorem identity6543 : scanCanonicalize (H12AffineFastState.compose env6543 (packedSelected [0,1,5,6,7,8,10,17,20,21,24,31] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound6543 : packedSelected [0,1,5,6,7,8,10,17,20,21,24,31] rootPS < 2^1333 := by decide +kernel

def env6544 : List Nat := [2,4,8,16,32,17,128,256,512,1024,523,1213,8192,16384,25780,26002,1297,570,1025,25780,1213,17713,445,17566,8329,444,691,16384,16813,18070,16825,17849,257,17596,1465,512]

theorem envBound6544 : H12AffineFastState.Bounded env6544 := by
  intro p hp
  have h : env6544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6543_6544 : H12AffineEnvironment.transform 10 523 env6543 = env6544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env6543 == env6544) = true)

theorem identity6544 : scanCanonicalize (H12AffineFastState.compose env6544 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound6544 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env6545 : List Nat := [2,4,8,16,32,17,128,173,512,1024,523,1213,8192,16384,25780,25663,1212,570,1025,25780,1213,17564,16,17566,8329,17,691,16384,16384,18070,16404,17428,172,17596,1044,512]

theorem envBound6545 : H12AffineFastState.Bounded env6545 := by
  intro p hp
  have h : env6545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6544_6545 : H12AffineEnvironment.transform 7 173 env6544 = env6545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env6544 == env6545) = true)

theorem identity6545 : scanCanonicalize (H12AffineFastState.compose env6545 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound6545 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env6546 : List Nat := [2,4,8,16,32,17,128,173,136,1024,131,1213,8192,16384,25780,25663,1212,178,1025,25780,1213,17564,16,17566,8329,17,59,16384,16384,17438,16404,17428,172,17596,1044,136]

theorem envBound6546 : H12AffineFastState.Bounded env6546 := by
  intro p hp
  have h : env6546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6545_6546 : H12AffineEnvironment.transform 8 136 env6545 = env6546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env6545 == env6546) = true)

theorem identity6546 : scanCanonicalize (H12AffineFastState.compose env6546 (packedSelected [0,7,20] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound6546 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6547 : List Nat := [2,4,8,16,32,17,40,5,32,1024,43,1045,8192,16384,25628,25663,1044,26,1025,25628,1045,17460,16,17462,8225,17,59,16384,16384,17438,16404,17428,4,17428,1044,32]

theorem envBound6547 : H12AffineFastState.Bounded env6547 := by
  intro p hp
  have h : env6547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6546_6547 : H12AffineEnvironment.transform 6 40 env6546 = env6547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env6546 == env6547) = true)

theorem identity6547 : scanCanonicalize (H12AffineFastState.compose env6547 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 1029) := by decide +kernel

theorem selectedBound6547 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6548 : List Nat := [2,4,8,16,32,17,40,5,32,1024,43,1045,8192,1029,8217,8250,1044,26,1025,8217,1045,49,16,51,8225,17,59,1029,1029,27,1041,17,4,17,1044,32]

theorem envBound6548 : H12AffineFastState.Bounded env6548 := by
  intro p hp
  have h : env6548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6547_6548 : H12AffineEnvironment.transform 13 1029 env6547 = env6548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1029 env6547 == env6548) = true)

theorem identity6548 : scanCanonicalize (H12AffineFastState.compose env6548 (packedSelected [0,1,2,3,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6548 : packedSelected [0,1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env6549 : List Nat := [2,4,2,16,32,17,34,5,32,1024,33,1045,8192,1029,8211,8240,1044,16,1025,8211,1045,49,16,51,8225,17,49,1029,1029,17,1041,17,4,17,1044,32]

theorem envBound6549 : H12AffineFastState.Bounded env6549 := by
  intro p hp
  have h : env6549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6548_6549 : H12AffineEnvironment.transform 2 2 env6548 = env6549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6548 == env6549) = true)

theorem identity6549 : scanCanonicalize (H12AffineFastState.compose env6549 (packedSelected [0,1,4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound6549 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env6550 : List Nat := [2,4,2,16,32,17,34,5,32,5,33,16,8192,0,8211,8240,17,16,4,8211,16,49,16,51,8225,17,49,0,0,17,20,17,4,17,17,32]

theorem envBound6550 : H12AffineFastState.Bounded env6550 := by
  intro p hp
  have h : env6550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6549_6550 : H12AffineEnvironment.transform 9 5 env6549 = env6550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env6549 == env6550) = true)

theorem identity6550 : scanCanonicalize (H12AffineFastState.compose env6550 (packedSelected [2,3] rootPS)) = affineNative (2^(12+1) ^^^ 19) := by decide +kernel

theorem selectedBound6550 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env6551 : List Nat := [2,4,2,16,32,17,34,5,32,5,33,16,19,0,0,35,17,16,4,0,16,49,16,51,50,17,49,0,0,17,20,17,4,17,17,32]

theorem envBound6551 : H12AffineFastState.Bounded env6551 := by
  intro p hp
  have h : env6551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6550_6551 : H12AffineEnvironment.transform 12 19 env6550 = env6551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 19 env6550 == env6551) = true)

theorem identity6551 : scanCanonicalize (H12AffineFastState.compose env6551 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound6551 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env6552 : List Nat := [2,4,2,16,0,17,2,5,0,5,1,16,19,0,0,3,17,16,4,0,16,17,16,19,18,17,17,0,0,17,20,17,4,17,17,0]

theorem envBound6552 : H12AffineFastState.Bounded env6552 := by
  intro p hp
  have h : env6552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6551_6552 : H12AffineEnvironment.transform 4 0 env6551 = env6552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env6551 == env6552) = true)

theorem identity6552 : scanCanonicalize (H12AffineFastState.compose env6552 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound6552 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6553 : List Nat := [2,4,2,0,0,1,2,5,0,5,1,0,3,0,0,3,1,0,4,0,0,1,0,3,2,1,1,0,0,1,4,1,4,1,1,0]

theorem envBound6553 : H12AffineFastState.Bounded env6553 := by
  intro p hp
  have h : env6553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6552_6553 : H12AffineEnvironment.transform 3 0 env6552 = env6553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env6552 == env6553) = true)

def env6554 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,46393,91183,41002,8329,91182,323712,16384,16813,22560,74795,73770,257,20481,1464,92050]

theorem envBound6554 : H12AffineFastState.Bounded env6554 := by
  intro p hp
  have h : env6554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6538_6554 : H12AffineEnvironment.transform 21 46393 env6538 = env6554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46393 env6538 == env6554) = true)

theorem identity6554 : scanCanonicalize (H12AffineFastState.compose env6554 (packedSelected [7,13,20,21,27] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound6554 : packedSelected [7,13,20,21,27] rootPS < 2^1333 := by decide +kernel

def env6555 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,16384,32768,65536,4356,262144,1025,32768,4096,46393,91183,41002,8225,91182,323624,16384,16645,22560,74795,73770,257,20481,1296,91962]

theorem envBound6555 : H12AffineFastState.Bounded env6555 := by
  intro p hp
  have h : env6555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6554_6555 : H12AffineEnvironment.transform 6 40 env6554 = env6555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env6554 == env6555) = true)

theorem identity6555 : scanCanonicalize (H12AffineFastState.compose env6555 (packedSelected [1,3,13,17,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound6555 : packedSelected [1,3,13,17,24,28] rootPS < 2^1333 := by decide +kernel

def env6556 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,16384,8201,65536,4356,262144,1025,8201,4096,5424,91183,35,8225,91182,282657,16384,16645,22560,74795,73770,257,20481,1296,91962]

theorem envBound6556 : H12AffineFastState.Bounded env6556 := by
  intro p hp
  have h : env6556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6555_6556 : H12AffineEnvironment.transform 14 8201 env6555 = env6556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env6555 == env6556) = true)

theorem identity6556 : scanCanonicalize (H12AffineFastState.compose env6556 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound6556 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env6557 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,16384,8201,65536,4356,2081,1025,8201,4096,5424,91183,35,8225,91182,22528,16384,16645,22560,74795,73770,257,20481,1296,91962]

theorem envBound6557 : H12AffineFastState.Bounded env6557 := by
  intro p hp
  have h : env6557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6556_6557 : H12AffineEnvironment.transform 17 2081 env6556 = env6557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env6556 == env6557) = true)

theorem identity6557 : scanCanonicalize (H12AffineFastState.compose env6557 (packedSelected [2,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 4129) := by decide +kernel

theorem selectedBound6557 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env6558 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,4129,8201,65536,4356,2081,1025,8201,4096,5424,78862,35,8225,78863,2081,4129,4388,2049,74795,73770,257,32,1296,79643]

theorem envBound6558 : H12AffineFastState.Bounded env6558 := by
  intro p hp
  have h : env6558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6557_6558 : H12AffineEnvironment.transform 13 4129 env6557 = env6558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4129 env6557 == env6558) = true)

theorem identity6558 : scanCanonicalize (H12AffineFastState.compose env6558 (packedSelected [4,6,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound6558 : packedSelected [4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env6559 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,2089,4129,2080,65536,4356,2081,1025,2080,4096,5424,72743,35,2056,72742,2081,4129,4388,2049,68610,67587,257,32,1296,73522]

theorem envBound6559 : H12AffineFastState.Bounded env6559 := by
  intro p hp
  have h : env6559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6558_6559 : H12AffineEnvironment.transform 12 2089 env6558 = env6559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env6558 == env6559) = true)

theorem identity6559 : scanCanonicalize (H12AffineFastState.compose env6559 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1809) := by decide +kernel

theorem selectedBound6559 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env6560 : List Nat := [2,4,8,16,32,17,40,256,512,1024,1809,4096,1848,4129,1841,65536,4356,1840,1025,1841,4096,5424,70454,35,1817,70455,1840,4129,4388,1808,66323,67346,257,32,1296,69667]

theorem envBound6560 : H12AffineFastState.Bounded env6560 := by
  intro p hp
  have h : env6560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6559_6560 : H12AffineEnvironment.transform 10 1809 env6559 = env6560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1809 env6559 == env6560) = true)

theorem identity6560 : scanCanonicalize (H12AffineFastState.compose env6560 (packedSelected [2,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound6560 : packedSelected [2,10,12] rootPS < 2^1333 := by decide +kernel

def env6561 : List Nat := [2,4,8,16,32,17,40,5,512,1024,1556,4096,1597,4129,1588,65536,4097,1589,1025,1588,4096,5173,70195,35,1564,70194,1589,4129,4129,1557,66070,67095,4,32,1045,69667]

theorem envBound6561 : H12AffineFastState.Bounded env6561 := by
  intro p hp
  have h : env6561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6560_6561 : H12AffineEnvironment.transform 7 5 env6560 = env6561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env6560 == env6561) = true)

theorem identity6561 : scanCanonicalize (H12AffineFastState.compose env6561 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound6561 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env6562 : List Nat := [2,4,8,16,26,17,18,5,512,1024,1556,4096,1543,4123,1550,65536,4097,1551,1025,1550,4096,5135,70153,25,1564,70152,1551,4123,4123,1557,66070,67095,4,26,1045,69657]

theorem envBound6562 : H12AffineFastState.Bounded env6562 := by
  intro p hp
  have h : env6562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6561_6562 : H12AffineEnvironment.transform 4 26 env6561 = env6562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env6561 == env6562) = true)

theorem identity6562 : scanCanonicalize (H12AffineFastState.compose env6562 (packedSelected [10,15] rootPS)) = affineNative (2^(15+1) ^^^ 1549) := by decide +kernel

theorem selectedBound6562 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env6563 : List Nat := [2,4,8,16,26,17,18,5,512,1024,1556,4096,1543,4123,1550,1549,4097,1551,1025,1550,4096,5135,5124,25,1564,5125,1551,4123,4123,1557,1051,26,4,26,1045,5652]

theorem envBound6563 : H12AffineFastState.Bounded env6563 := by
  intro p hp
  have h : env6563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6562_6563 : H12AffineEnvironment.transform 15 1549 env6562 = env6563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1549 env6562 == env6563) = true)

def env6564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4097,4194304,8388608,41002,8329,8914001,849105,16384,16892,547953,598058,12644669,525568,545872,4239488,8914925]

theorem envBound6564 : H12AffineFastState.Bounded env6564 := by
  intro p hp
  have h : env6564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6447_6564 : H12AffineEnvironment.transform 20 4097 env6447 = env6564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env6447 == env6564) = true)

def env6565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,4194304,8388608,41002,8329,8388689,323793,16384,16892,22641,74794,12644669,256,20560,4239488,8389613]

theorem envBound6565 : H12AffineFastState.Bounded env6565 := by
  intro p hp
  have h : env6565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6564_6565 : H12AffineEnvironment.transform 18 1024 env6564 = env6565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env6564 == env6565) = true)

theorem identity6565 : scanCanonicalize (H12AffineFastState.compose env6565 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4293055) := by decide +kernel

theorem selectedBound6565 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env6566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,4194304,4293055,41002,8329,4293102,323793,16384,16892,22641,74794,94338,256,20560,4239488,4293202]

theorem envBound6566 : H12AffineFastState.Bounded env6566 := by
  intro p hp
  have h : env6566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6565_6566 : H12AffineEnvironment.transform 22 4293055 env6565 = env6566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4293055 env6565 == env6566) = true)

def env6567 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,4194304,4293055,41002,8329,4293054,323713,16384,16812,22561,74794,94338,256,20480,4239488,4293122]

theorem envBound6567 : H12AffineFastState.Bounded env6567 := by
  intro p hp
  have h : env6567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6566_6567 : H12AffineEnvironment.transform 5 16 env6566 = env6567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env6566 == env6567) = true)

theorem identity6567 : scanCanonicalize (H12AffineFastState.compose env6567 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 98306) := by decide +kernel

theorem selectedBound6567 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env6568 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,98306,445,41002,8329,444,323713,16384,16812,22561,74794,94338,256,20480,77954,512]

theorem envBound6568 : H12AffineFastState.Bounded env6568 := by
  intro p hp
  have h : env6568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6567_6568 : H12AffineEnvironment.transform 21 98306 env6567 = env6568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98306 env6567 == env6568) = true)

theorem identity6568 : scanCanonicalize (H12AffineFastState.compose env6568 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8582) := by decide +kernel

theorem selectedBound6568 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6569 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8582,4525,262144,1024,32768,4097,41348,445,41002,8329,444,323713,16384,16812,22561,1452,20740,256,20480,4356,512]

theorem envBound6569 : H12AffineFastState.Bounded env6569 := by
  intro p hp
  have h : env6569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6568_6569 : H12AffineEnvironment.transform 15 8582 env6568 = env6569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8582 env6568 == env6569) = true)

theorem identity6569 : scanCanonicalize (H12AffineFastState.compose env6569 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26260) := by decide +kernel

theorem selectedBound6569 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6570 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,26260,8582,4525,262144,1024,26260,4097,18192,445,18110,8329,444,267797,16384,16812,22561,1452,20740,256,20480,4356,512]

theorem envBound6570 : H12AffineFastState.Bounded env6570 := by
  intro p hp
  have h : env6570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6569_6570 : H12AffineEnvironment.transform 14 26260 env6569 = env6570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26260 env6569 == env6570) = true)

theorem identity6570 : scanCanonicalize (H12AffineFastState.compose env6570 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4357) := by decide +kernel

theorem selectedBound6570 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env6571 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4357,14225,8582,4525,262144,1024,14225,4097,5653,445,6075,8329,444,267797,4357,4265,2340,1452,1,256,261,4356,512]

theorem envBound6571 : H12AffineFastState.Bounded env6571 := by
  intro p hp
  have h : env6571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6570_6571 : H12AffineEnvironment.transform 13 4357 env6570 = env6571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4357 env6570 == env6571) = true)

def env6572 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,4194304,4293055,41002,8329,4293055,323712,16384,16813,22560,74794,94338,256,20481,4239488,4293123]

theorem envBound6572 : H12AffineFastState.Bounded env6572 := by
  intro p hp
  have h : env6572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6566_6572 : H12AffineEnvironment.transform 5 17 env6566 = env6572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env6566 == env6572) = true)

def env6573 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4264,32768,65536,4524,262144,1024,32768,4097,4194304,4293055,41002,8329,4293055,303144,4264,4357,2184,74794,73770,256,169,4239488,4293123]

theorem envBound6573 : H12AffineFastState.Bounded env6573 := by
  intro p hp
  have h : env6573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6572_6573 : H12AffineEnvironment.transform 13 4264 env6572 = env6573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4264 env6572 == env6573) = true)

theorem identity6573 : scanCanonicalize (H12AffineFastState.compose env6573 (packedSelected [2,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound6573 : packedSelected [2,23,32] rootPS < 2^1333 := by decide +kernel

def env6574 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4264,32768,33166,4524,262144,1024,32768,4097,4194304,4194353,41002,8329,4194353,303144,4264,4357,2184,42404,41380,256,169,4239488,4195213]

theorem envBound6574 : H12AffineFastState.Bounded env6574 := by
  intro p hp
  have h : env6574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6573_6574 : H12AffineEnvironment.transform 15 33166 env6573 = env6574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env6573 == env6574) = true)

theorem identity6574 : scanCanonicalize (H12AffineFastState.compose env6574 (packedSelected [0,2,6,7,11,17,18,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 1922) := by decide +kernel

theorem selectedBound6574 : packedSelected [0,2,6,7,11,17,18,20,21] rootPS < 2^1333 := by decide +kernel

def env6575 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4264,32768,33166,4524,1922,1024,32768,4097,4194304,4194353,41002,8329,4194353,42922,4264,4357,2184,42404,41380,256,169,4239488,4195213]

theorem envBound6575 : H12AffineFastState.Bounded env6575 := by
  intro p hp
  have h : env6575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6574_6575 : H12AffineEnvironment.transform 17 1922 env6574 = env6575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1922 env6574 == env6575) = true)

def env6576 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4264,32768,33166,4524,1922,1024,32768,4097,41088,41137,41002,8329,41137,42922,4264,4357,2184,42404,41380,256,169,4096,41741]

theorem envBound6576 : H12AffineFastState.Bounded env6576 := by
  intro p hp
  have h : env6576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6575_6576 : H12AffineEnvironment.transform 21 41088 env6575 = env6576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env6575 == env6576) = true)

theorem identity6576 : scanCanonicalize (H12AffineFastState.compose env6576 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 11950) := by decide +kernel

theorem selectedBound6576 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env6577 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4264,11950,12064,4524,1922,1024,11950,4097,3630,3615,3716,8329,3615,2308,4264,4357,2184,2826,3850,256,169,4096,3491]

theorem envBound6577 : H12AffineFastState.Bounded env6577 := by
  intro p hp
  have h : env6577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6576_6577 : H12AffineEnvironment.transform 14 11950 env6576 = env6577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11950 env6576 == env6577) = true)

theorem identity6577 : scanCanonicalize (H12AffineFastState.compose env6577 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(11+1) ^^^ 1693) := by decide +kernel

theorem selectedBound6577 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env6578 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1693,8192,1589,11950,12064,1841,1922,1024,11950,1692,3630,3615,3716,8329,3615,2308,1589,1944,2184,2826,3850,256,169,1693,3491]

theorem envBound6578 : H12AffineFastState.Bounded env6578 := by
  intro p hp
  have h : env6578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6577_6578 : H12AffineEnvironment.transform 11 1693 env6577 = env6578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1693 env6577 == env6578) = true)

theorem identity6578 : scanCanonicalize (H12AffineFastState.compose env6578 (packedSelected [3,4,5,6,9,10,12,13,15,20] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound6578 : packedSelected [3,4,5,6,9,10,12,13,15,20] rootPS < 2^1333 := by decide +kernel

def env6579 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,1693,8192,1589,11950,11812,1589,1670,1024,11950,1692,3630,3615,3716,8329,3615,2048,1589,1692,2184,2574,3598,4,169,1693,3239]

theorem envBound6579 : H12AffineFastState.Bounded env6579 := by
  intro p hp
  have h : env6579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6578_6579 : H12AffineEnvironment.transform 7 4 env6578 = env6579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env6578 == env6579) = true)

theorem identity6579 : scanCanonicalize (H12AffineFastState.compose env6579 (packedSelected [3,5,10,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1550) := by decide +kernel

theorem selectedBound6579 : packedSelected [3,5,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env6580 : List Nat := [2,4,8,16,32,17,128,4,512,1024,1550,1693,8192,1589,8352,8234,1589,1670,1024,8352,1692,32,17,138,8329,17,1550,1589,1692,1670,1024,0,4,169,1693,681]

theorem envBound6580 : H12AffineFastState.Bounded env6580 := by
  intro p hp
  have h : env6580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6579_6580 : H12AffineEnvironment.transform 10 1550 env6579 = env6580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1550 env6579 == env6580) = true)

theorem identity6580 : scanCanonicalize (H12AffineFastState.compose env6580 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound6580 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env6581 : List Nat := [2,4,8,10,32,11,128,4,512,1024,1550,1671,8192,1583,8352,8234,1583,1670,1024,8352,1670,32,11,138,8329,11,1550,1583,1670,1670,1024,0,4,169,1671,681]

theorem envBound6581 : H12AffineFastState.Bounded env6581 := by
  intro p hp
  have h : env6581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6580_6581 : H12AffineEnvironment.transform 3 10 env6580 = env6581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env6580 == env6581) = true)

theorem identity6581 : scanCanonicalize (H12AffineFastState.compose env6581 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 1166) := by decide +kernel

theorem selectedBound6581 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env6582 : List Nat := [2,4,8,10,32,11,128,4,512,1024,1550,1671,1166,1583,1070,1188,1583,1670,1024,1070,1670,32,11,138,1031,11,1550,1583,1670,1670,1024,0,4,169,1671,681]

theorem envBound6582 : H12AffineFastState.Bounded env6582 := by
  intro p hp
  have h : env6582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6581_6582 : H12AffineEnvironment.transform 12 1166 env6581 = env6582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1166 env6581 == env6582) = true)

theorem identity6582 : scanCanonicalize (H12AffineFastState.compose env6582 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6582 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env6583 : List Nat := [2,4,8,10,32,11,41,4,512,1024,1550,1582,1063,1583,1070,1037,1583,1583,1024,1070,1583,32,11,35,1031,11,1550,1583,1583,1583,1024,0,4,0,1582,512]

theorem envBound6583 : H12AffineFastState.Bounded env6583 := by
  intro p hp
  have h : env6583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6582_6583 : H12AffineEnvironment.transform 6 41 env6582 = env6583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6582 == env6583) = true)

def env6584 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4264,32768,33166,4524,1922,1024,32768,4097,41089,41136,41002,8329,41136,42922,4264,4357,2184,42404,41380,256,169,4097,41740]

theorem envBound6584 : H12AffineFastState.Bounded env6584 := by
  intro p hp
  have h : env6584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6575_6584 : H12AffineEnvironment.transform 21 41089 env6575 = env6584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env6575 == env6584) = true)

theorem identity6584 : scanCanonicalize (H12AffineFastState.compose env6584 (packedSelected [13,17] rootPS)) = affineNative (2^(10+1) ^^^ 1550) := by decide +kernel

theorem selectedBound6584 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env6585 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1550,4096,8192,4264,32768,33166,4524,1922,1024,32768,4097,41089,41136,41002,8329,41136,42922,4264,4357,1670,42404,41380,256,169,4097,41740]

theorem envBound6585 : H12AffineFastState.Bounded env6585 := by
  intro p hp
  have h : env6585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6584_6585 : H12AffineEnvironment.transform 10 1550 env6584 = env6585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1550 env6584 == env6585) = true)

theorem identity6585 : scanCanonicalize (H12AffineFastState.compose env6585 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 14225) := by decide +kernel

theorem selectedBound6585 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env6586 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1550,4096,8192,4264,14225,13855,4524,1922,1024,14225,4097,5904,5921,6075,8329,5921,4155,4264,4357,1670,4661,5685,256,169,4097,5277]

theorem envBound6586 : H12AffineFastState.Bounded env6586 := by
  intro p hp
  have h : env6586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6585_6586 : H12AffineEnvironment.transform 14 14225 env6585 = env6586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14225 env6585 == env6586) = true)

theorem identity6586 : scanCanonicalize (H12AffineFastState.compose env6586 (packedSelected [3,4,5,6,9,10,12,13,15,20] rootPS)) = affineNative (2^(11+1) ^^^ 1944) := by decide +kernel

theorem selectedBound6586 : packedSelected [3,4,5,6,9,10,12,13,15,20] rootPS < 2^1333 := by decide +kernel

def env6587 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1550,1944,8192,1840,8201,8583,1588,1922,1024,8201,1945,136,185,35,8329,185,1955,1840,1693,1670,1453,429,256,169,1945,773]

theorem envBound6587 : H12AffineFastState.Bounded env6587 := by
  intro p hp
  have h : env6587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6586_6587 : H12AffineEnvironment.transform 11 1944 env6586 = env6587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1944 env6586 == env6587) = true)

theorem identity6587 : scanCanonicalize (H12AffineFastState.compose env6587 (packedSelected [3,5,10,12,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6587 : packedSelected [3,5,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env6588 : List Nat := [2,4,8,16,32,17,41,256,512,1024,1550,1841,8192,1840,8201,8494,1588,1835,1024,8201,1840,33,16,35,8224,16,1802,1840,1588,1583,1284,260,256,0,1840,773]

theorem envBound6588 : H12AffineFastState.Bounded env6588 := by
  intro p hp
  have h : env6588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6587_6588 : H12AffineEnvironment.transform 6 41 env6587 = env6588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6587 == env6588) = true)

theorem identity6588 : scanCanonicalize (H12AffineFastState.compose env6588 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound6588 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env6589 : List Nat := [2,4,8,16,27,17,18,256,512,1024,1550,1802,8192,1803,8201,8469,1551,1808,1024,8201,1803,26,16,24,8219,16,1802,1803,1551,1556,1284,260,256,0,1803,773]

theorem envBound6589 : H12AffineFastState.Bounded env6589 := by
  intro p hp
  have h : env6589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6588_6589 : H12AffineEnvironment.transform 4 27 env6588 = env6589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env6588 == env6589) = true)

theorem identity6589 : scanCanonicalize (H12AffineFastState.compose env6589 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound6589 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env6590 : List Nat := [2,4,8,16,27,17,18,256,512,1024,1550,1802,1053,1803,1044,1288,1551,1808,1024,1044,1803,26,16,24,1030,16,1802,1803,1551,1556,1284,260,256,0,1803,773]

theorem envBound6590 : H12AffineFastState.Bounded env6590 := by
  intro p hp
  have h : env6590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6589_6590 : H12AffineEnvironment.transform 12 1053 env6589 = env6590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env6589 == env6590) = true)

theorem identity6590 : scanCanonicalize (H12AffineFastState.compose env6590 (packedSelected [2,11,23] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound6590 : packedSelected [2,11,23] rootPS < 2^1333 := by decide +kernel

def env6591 : List Nat := [2,4,8,16,27,17,18,4,512,1024,1550,1550,1053,1551,1044,1036,1551,1556,1024,1044,1551,26,16,24,1030,16,1550,1551,1551,1556,1024,0,4,0,1551,513]

theorem envBound6591 : H12AffineFastState.Bounded env6591 := by
  intro p hp
  have h : env6591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6590_6591 : H12AffineEnvironment.transform 7 4 env6590 = env6591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env6590 == env6591) = true)

theorem identity6591 : scanCanonicalize (H12AffineFastState.compose env6591 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 20) := by decide +kernel

theorem selectedBound6591 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env6592 : List Nat := [2,4,8,16,27,17,18,4,20,1024,1050,1050,1053,1051,1044,1036,1051,1024,1024,1044,1051,26,16,24,1030,16,1050,1051,1051,1024,1024,0,4,0,1051,21]

theorem envBound6592 : H12AffineFastState.Bounded env6592 := by
  intro p hp
  have h : env6592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6591_6592 : H12AffineEnvironment.transform 8 20 env6591 = env6592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 20 env6591 == env6592) = true)

theorem identity6592 : scanCanonicalize (H12AffineFastState.compose env6592 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound6592 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env6593 : List Nat := [2,4,8,1,10,0,3,4,5,1024,1035,1035,1036,1034,1029,1036,1034,1024,1024,1029,1034,11,1,9,1030,1,1035,1034,1034,1024,1024,0,4,0,1034,4]

theorem envBound6593 : H12AffineFastState.Bounded env6593 := by
  intro p hp
  have h : env6593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6592_6593 : H12AffineEnvironment.transform 3 1 env6592 = env6593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6592 == env6593) = true)

theorem identity6593 : scanCanonicalize (H12AffineFastState.compose env6593 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound6593 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env6594 : List Nat := [2,1,8,1,10,0,3,1,0,1024,1035,1035,1033,1034,1024,1033,1034,1024,1024,1024,1034,11,1,9,1027,1,1035,1034,1034,1024,1024,0,1,0,1034,1]

theorem envBound6594 : H12AffineFastState.Bounded env6594 := by
  intro p hp
  have h : env6594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6593_6594 : H12AffineEnvironment.transform 1 1 env6593 = env6594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6593 == env6594) = true)

theorem identity6594 : scanCanonicalize (H12AffineFastState.compose env6594 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 10) := by decide +kernel

theorem selectedBound6594 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6595 : List Nat := [2,1,8,1,10,0,3,1,0,10,1,1,3,0,10,3,0,10,10,10,0,11,1,9,9,1,1,0,0,10,10,0,1,0,0,1]

theorem envBound6595 : H12AffineFastState.Bounded env6595 := by
  intro p hp
  have h : env6595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6594_6595 : H12AffineEnvironment.transform 9 10 env6594 = env6595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 10 env6594 == env6595) = true)

def leafEnv6595 : List Nat := [2,1,8,1,10,0,3,1,0,10,1,1,3,0,10,3,0,10,10,10,0,11,1,9,10,9,1,1,1,0,0,10,10,0,1,0,1,9,0,1,1,0,0]

def active6595 : List Nat := [0,2]

def tree6595 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6595 : H12WitnessSearch.Good tree6595 := H12GlobalWitnessIndex.good

theorem leafIdentity6595 : H12AffineFastState.composeSystem env6595 rootObs = leafEnv6595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6595 rootObs == leafEnv6595) = true)

theorem terminalChecked6595 : H12PackedTerminal.terminalCheckFast leafEnv6595 active6595 tree6595 = true := by decide +kernel

def env6596 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4265,32768,65536,4524,262144,1024,32768,4097,4194304,4293055,41002,8329,4293055,303145,4265,4356,2185,74794,73771,256,168,4239488,4293123]

theorem envBound6596 : H12AffineFastState.Bounded env6596 := by
  intro p hp
  have h : env6596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6572_6596 : H12AffineEnvironment.transform 13 4265 env6572 = env6596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4265 env6572 == env6596) = true)

theorem identity6596 : scanCanonicalize (H12AffineFastState.compose env6596 (packedSelected [0,7,9,13,20,21,22] rootPS)) = affineNative (2^(21+1) ^^^ 73891) := by decide +kernel

theorem selectedBound6596 : packedSelected [0,7,9,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env6597 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4265,32768,65536,4524,262144,1024,32768,4097,73891,41244,41002,8329,41244,303145,4265,4356,2185,74794,73771,256,168,102435,41632]

theorem envBound6597 : H12AffineFastState.Bounded env6597 := by
  intro p hp
  have h : env6597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6596_6597 : H12AffineEnvironment.transform 21 73891 env6596 = env6597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73891 env6596 == env6597) = true)

theorem identity6597 : scanCanonicalize (H12AffineFastState.compose env6597 (packedSelected [2,11,18] rootPS)) = affineNative (2^(17+1) ^^^ 75954) := by decide +kernel

theorem selectedBound6597 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env6598 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4265,32768,65536,4524,75954,1024,32768,4097,73891,41244,41002,8329,41244,100507,4265,4356,2185,74794,73771,256,168,102435,41632]

theorem envBound6598 : H12AffineFastState.Bounded env6598 := by
  intro p hp
  have h : env6598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6597_6598 : H12AffineEnvironment.transform 17 75954 env6597 = env6598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 75954 env6597 == env6598) = true)

theorem identity6598 : scanCanonicalize (H12AffineFastState.compose env6598 (packedSelected [3,4,5,9,10,13,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 8495) := by decide +kernel

theorem selectedBound6598 : packedSelected [3,4,5,9,10,13,17,20] rootPS < 2^1333 := by decide +kernel

def env6599 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4265,32768,8495,4524,2461,1024,32768,4097,396,41244,41002,8329,41244,43444,4265,4356,2185,1285,260,256,168,45324,41632]

theorem envBound6599 : H12AffineFastState.Bounded env6599 := by
  intro p hp
  have h : env6599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6598_6599 : H12AffineEnvironment.transform 15 8495 env6598 = env6599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8495 env6598 == env6599) = true)

theorem identity6599 : scanCanonicalize (H12AffineFastState.compose env6599 (packedSelected [0,3,4,5,6,7,9,10,13,17] rootPS)) = affineNative (2^(14+1) ^^^ 11030) := by decide +kernel

theorem selectedBound6599 : packedSelected [0,3,4,5,6,7,9,10,13,17] rootPS < 2^1333 := by decide +kernel

def env6600 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4265,11030,8495,4524,2461,1024,11030,4097,396,2570,2876,8329,2570,674,4265,4356,2185,1285,260,256,168,6682,2486]

theorem envBound6600 : H12AffineFastState.Bounded env6600 := by
  intro p hp
  have h : env6600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6599_6600 : H12AffineEnvironment.transform 14 11030 env6599 = env6600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11030 env6599 == env6600) = true)

theorem identity6600 : scanCanonicalize (H12AffineFastState.compose env6600 (packedSelected [0,3,4,5,6,7,9,10,13,21] rootPS)) = affineNative (2^(10+1) ^^^ 783) := by decide +kernel

theorem selectedBound6600 : packedSelected [0,3,4,5,6,7,9,10,13,21] rootPS < 2^1333 := by decide +kernel

def env6601 : List Nat := [2,4,8,16,32,17,128,256,512,1024,783,4096,8192,4265,8217,8495,4524,658,1024,8217,4097,396,261,51,8329,261,674,4265,4356,902,1285,260,256,168,4373,697]

theorem envBound6601 : H12AffineFastState.Bounded env6601 := by
  intro p hp
  have h : env6601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6600_6601 : H12AffineEnvironment.transform 10 783 env6600 = env6601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 783 env6600 == env6601) = true)

theorem identity6601 : scanCanonicalize (H12AffineFastState.compose env6601 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 188) := by decide +kernel

theorem selectedBound6601 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env6602 : List Nat := [2,4,8,16,32,17,128,188,512,1024,691,4096,8192,4265,8217,8339,4112,658,1024,8217,4097,48,185,51,8329,185,674,4265,4280,570,1209,184,188,168,4265,697]

theorem envBound6602 : H12AffineFastState.Bounded env6602 := by
  intro p hp
  have h : env6602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6601_6602 : H12AffineEnvironment.transform 7 188 env6601 = env6602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env6601 == env6602) = true)

theorem identity6602 : scanCanonicalize (H12AffineFastState.compose env6602 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1692) := by decide +kernel

theorem selectedBound6602 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6603 : List Nat := [2,4,8,16,32,17,128,188,512,1024,691,1692,8192,1589,8217,8339,1676,658,1024,8217,1693,48,185,51,8329,185,674,1589,1572,570,1209,184,188,168,1589,697]

theorem envBound6603 : H12AffineFastState.Bounded env6603 := by
  intro p hp
  have h : env6603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6602_6603 : H12AffineEnvironment.transform 11 1692 env6602 = env6603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1692 env6602 == env6603) = true)

theorem identity6603 : scanCanonicalize (H12AffineFastState.compose env6603 (packedSelected [0,3,5,7,11,13] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound6603 : packedSelected [0,3,5,7,11,13] rootPS < 2^1333 := by decide +kernel

def env6604 : List Nat := [2,4,8,16,32,17,128,188,512,543,691,131,8192,42,8217,8339,147,658,543,8217,130,48,185,51,8329,185,674,42,59,570,678,184,188,168,42,697]

theorem envBound6604 : H12AffineFastState.Bounded env6604 := by
  intro p hp
  have h : env6604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6603_6604 : H12AffineEnvironment.transform 9 543 env6603 = env6604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env6603 == env6604) = true)

theorem identity6604 : scanCanonicalize (H12AffineFastState.compose env6604 (packedSelected [3,5,11] rootPS)) = affineNative (2^(12+1) ^^^ 177) := by decide +kernel

theorem selectedBound6604 : packedSelected [3,5,11] rootPS < 2^1333 := by decide +kernel

def env6605 : List Nat := [2,4,8,16,32,17,128,188,512,543,691,131,177,42,168,34,147,658,543,168,130,48,185,51,56,185,674,42,59,570,678,184,188,168,42,697]

theorem envBound6605 : H12AffineFastState.Bounded env6605 := by
  intro p hp
  have h : env6605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6604_6605 : H12AffineEnvironment.transform 12 177 env6604 = env6605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 177 env6604 == env6605) = true)

theorem identity6605 : scanCanonicalize (H12AffineFastState.compose env6605 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound6605 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6606 : List Nat := [2,4,8,16,32,17,51,15,512,543,512,48,2,42,27,34,32,545,543,27,49,48,10,51,56,10,529,42,59,570,533,11,15,27,42,522]

theorem envBound6606 : H12AffineFastState.Bounded env6606 := by
  intro p hp
  have h : env6606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6605_6606 : H12AffineEnvironment.transform 6 51 env6605 = env6606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env6605 == env6606) = true)

theorem identity6606 : scanCanonicalize (H12AffineFastState.compose env6606 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound6606 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env6607 : List Nat := [2,4,8,16,32,17,51,15,48,47,48,48,2,42,27,34,32,17,47,27,49,48,10,51,56,10,33,42,59,10,37,11,15,27,42,58]

theorem envBound6607 : H12AffineFastState.Bounded env6607 := by
  intro p hp
  have h : env6607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6606_6607 : H12AffineEnvironment.transform 8 48 env6606 = env6607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env6606 == env6607) = true)

def env6608 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,4194304,8388608,41002,8329,8388688,323792,16384,16892,22640,74795,12644669,257,20561,4239488,8389612]

theorem envBound6608 : H12AffineFastState.Bounded env6608 := by
  intro p hp
  have h : env6608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6564_6608 : H12AffineEnvironment.transform 18 1025 env6564 = env6608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env6564 == env6608) = true)

theorem identity6608 : scanCanonicalize (H12AffineFastState.compose env6608 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 115902) := by decide +kernel

theorem selectedBound6608 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env6609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,115902,8388608,41002,8329,8388688,323792,16384,16892,22640,74795,8467843,257,20561,95294,8389612]

theorem envBound6609 : H12AffineFastState.Bounded env6609 := by
  intro p hp
  have h : env6609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6608_6609 : H12AffineEnvironment.transform 21 115902 env6608 = env6609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 115902 env6608 == env6609) = true)

def env6610 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,115902,8388608,41002,8329,8388608,323712,16384,16812,22560,74795,8467843,257,20481,95294,8389564]

theorem envBound6610 : H12AffineFastState.Bounded env6610 := by
  intro p hp
  have h : env6610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6609_6610 : H12AffineEnvironment.transform 5 16 env6609 = env6610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env6609 == env6610) = true)

def env6611 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,115902,5544,41002,8329,5544,323712,16384,16812,22560,74795,73771,257,20481,95294,5652]

theorem envBound6611 : H12AffineFastState.Bounded env6611 := by
  intro p hp
  have h : env6611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6610_6611 : H12AffineEnvironment.transform 22 5544 env6610 = env6611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5544 env6610 == env6611) = true)

theorem identity6611 : scanCanonicalize (H12AffineFastState.compose env6611 (packedSelected [0,7,9,13,20,21,22] rootPS)) = affineNative (2^(14+1) ^^^ 25629) := by decide +kernel

theorem selectedBound6611 : packedSelected [0,7,9,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env6612 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,25629,65536,4525,262144,1025,25629,4097,73891,5544,17463,8329,5544,267421,16384,16812,22560,74795,73771,257,20481,95294,5652]

theorem envBound6612 : H12AffineFastState.Bounded env6612 := by
  intro p hp
  have h : env6612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6611_6612 : H12AffineEnvironment.transform 14 25629 env6611 = env6612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25629 env6611 == env6612) = true)

theorem identity6612 : scanCanonicalize (H12AffineFastState.compose env6612 (packedSelected [2,11,18] rootPS)) = affineNative (2^(17+1) ^^^ 7204) := by decide +kernel

theorem selectedBound6612 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env6613 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,25629,65536,4525,7204,1025,25629,4097,73891,5544,17463,8329,5544,2233,16384,16812,22560,74795,73771,257,20481,95294,5652]

theorem envBound6613 : H12AffineFastState.Bounded env6613 := by
  intro p hp
  have h : env6613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6612_6613 : H12AffineEnvironment.transform 17 7204 env6612 = env6613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7204 env6612 == env6613) = true)

theorem identity6613 : scanCanonicalize (H12AffineFastState.compose env6613 (packedSelected [7,13,20,21,27] rootPS)) = affineNative (2^(15+1) ^^^ 25914) := by decide +kernel

theorem selectedBound6613 : packedSelected [7,13,20,21,27] rootPS < 2^1333 := by decide +kernel

def env6614 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,25629,25914,4525,7204,1025,25629,4097,17817,5544,17463,8329,5544,2233,16384,16812,22560,16657,17681,257,20481,4356,5652]

theorem envBound6614 : H12AffineFastState.Bounded env6614 := by
  intro p hp
  have h : env6614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6613_6614 : H12AffineEnvironment.transform 15 25914 env6613 = env6614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25914 env6613 == env6614) = true)

theorem identity6614 : scanCanonicalize (H12AffineFastState.compose env6614 (packedSelected [0,1,5,7,10,12,15,17,20,21] rootPS)) = affineNative (2^(11+1) ^^^ 1465) := by decide +kernel

theorem selectedBound6614 : packedSelected [0,1,5,7,10,12,15,17,20,21] rootPS < 2^1333 := by decide +kernel

def env6615 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1465,8192,16384,25629,25914,1044,2461,1025,25629,1464,17817,17,17463,8329,17,2233,16384,16812,19865,16657,17681,257,17848,1213,941]

theorem envBound6615 : H12AffineFastState.Bounded env6615 := by
  intro p hp
  have h : env6615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6614_6615 : H12AffineEnvironment.transform 11 1465 env6614 = env6615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1465 env6614 == env6615) = true)

theorem identity6615 : scanCanonicalize (H12AffineFastState.compose env6615 (packedSelected [1,5,10,12,13,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound6615 : packedSelected [1,5,10,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env6616 : List Nat := [2,4,8,16,32,16,128,256,293,1024,2048,1465,8192,16384,25629,25914,1044,2461,1025,25629,1464,17817,17,17463,8329,17,2233,16384,16812,19865,16657,17681,257,17848,1213,136]

theorem envBound6616 : H12AffineFastState.Bounded env6616 := by
  intro p hp
  have h : env6616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6615_6616 : H12AffineEnvironment.transform 8 293 env6615 = env6616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env6615 == env6616) = true)

theorem identity6616 : scanCanonicalize (H12AffineFastState.compose env6616 (packedSelected [0,1,5,6,7,10,12,15,20] rootPS)) = affineNative (2^(13+1) ^^^ 3222) := by decide +kernel

theorem selectedBound6616 : packedSelected [0,1,5,6,7,10,12,15,20] rootPS < 2^1333 := by decide +kernel

def env6617 : List Nat := [2,4,8,16,32,16,128,256,293,1024,2048,1465,8192,3222,10379,10668,1044,2461,1025,10379,1464,2319,17,2209,8329,17,2233,3222,3386,271,3463,2439,257,2350,1213,136]

theorem envBound6617 : H12AffineFastState.Bounded env6617 := by
  intro p hp
  have h : env6617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6616_6617 : H12AffineEnvironment.transform 13 3222 env6616 = env6617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3222 env6616 == env6617) = true)

theorem identity6617 : scanCanonicalize (H12AffineFastState.compose env6617 (packedSelected [0,2,4,6,7,9,11,23] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound6617 : packedSelected [0,2,4,6,7,9,11,23] rootPS < 2^1333 := by decide +kernel

def env6618 : List Nat := [2,4,8,1,32,1,128,256,293,1024,2048,1448,8192,3207,10379,10668,1029,2444,1025,10379,1449,2319,0,2209,8329,0,2216,3207,3371,271,3463,2439,257,2350,1196,136]

theorem envBound6618 : H12AffineFastState.Bounded env6618 := by
  intro p hp
  have h : env6618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6617_6618 : H12AffineEnvironment.transform 3 1 env6617 = env6618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6617 == env6618) = true)

theorem identity6618 : scanCanonicalize (H12AffineFastState.compose env6618 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound6618 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env6619 : List Nat := [2,4,8,1,32,1,128,172,137,1024,2048,1028,8192,3207,10379,10240,1029,2080,1025,10379,1029,2211,0,2209,8329,0,2216,3207,3207,163,3115,2091,173,2178,1196,136]

theorem envBound6619 : H12AffineFastState.Bounded env6619 := by
  intro p hp
  have h : env6619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6618_6619 : H12AffineEnvironment.transform 7 172 env6618 = env6619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env6618 == env6619) = true)

theorem identity6619 : scanCanonicalize (H12AffineFastState.compose env6619 (packedSelected [0,3,4,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 167) := by decide +kernel

theorem selectedBound6619 : packedSelected [0,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env6620 : List Nat := [2,4,8,1,32,1,128,172,137,1024,167,1028,8192,1056,8236,8359,1029,135,1025,8236,1029,4,0,6,8329,0,15,1056,1056,163,1164,140,173,37,1196,136]

theorem envBound6620 : H12AffineFastState.Bounded env6620 := by
  intro p hp
  have h : env6620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6619_6620 : H12AffineEnvironment.transform 10 167 env6619 = env6620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 167 env6619 == env6620) = true)

theorem identity6620 : scanCanonicalize (H12AffineFastState.compose env6620 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound6620 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env6621 : List Nat := [2,4,8,1,4,1,128,136,137,1024,131,1028,8192,1028,8200,8323,1029,135,1025,8200,1029,4,0,6,8329,0,15,1028,1028,135,1164,140,137,1,1160,136]

theorem envBound6621 : H12AffineFastState.Bounded env6621 := by
  intro p hp
  have h : env6621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6620_6621 : H12AffineEnvironment.transform 4 4 env6620 = env6621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env6620 == env6621) = true)

theorem identity6621 : scanCanonicalize (H12AffineFastState.compose env6621 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 6) := by decide +kernel

theorem selectedBound6621 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env6622 : List Nat := [2,4,8,1,4,1,6,14,15,1024,5,1028,8192,1028,8200,8197,1029,1,1025,8200,1029,4,0,6,8207,0,15,1028,1028,1,1034,10,15,1,1038,14]

theorem envBound6622 : H12AffineFastState.Bounded env6622 := by
  intro p hp
  have h : env6622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6621_6622 : H12AffineEnvironment.transform 6 6 env6621 = env6622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 6 env6621 == env6622) = true)

theorem identity6622 : scanCanonicalize (H12AffineFastState.compose env6622 (packedSelected [6] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6622 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6623 : List Nat := [2,4,2,1,4,1,6,4,5,1024,5,1028,8192,1028,8194,8197,1029,1,1025,8194,1029,4,0,6,8197,0,5,1028,1028,1,1024,0,5,1,1028,4]

theorem envBound6623 : H12AffineFastState.Bounded env6623 := by
  intro p hp
  have h : env6623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6622_6623 : H12AffineEnvironment.transform 2 2 env6622 = env6623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6622 == env6623) = true)

theorem identity6623 : scanCanonicalize (H12AffineFastState.compose env6623 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound6623 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6624 : List Nat := [2,4,2,1,4,1,6,4,5,5,5,1,8192,1,8194,8197,0,1,4,8194,0,4,0,6,8197,0,5,1,1,1,5,0,5,1,1,4]

theorem envBound6624 : H12AffineFastState.Bounded env6624 := by
  intro p hp
  have h : env6624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6623_6624 : H12AffineEnvironment.transform 9 5 env6623 = env6624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env6623 == env6624) = true)

theorem identity6624 : scanCanonicalize (H12AffineFastState.compose env6624 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound6624 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env6625 : List Nat := [2,1,2,1,1,1,3,1,0,0,0,1,8192,1,8194,8192,0,1,1,8194,0,1,0,3,8192,0,0,1,1,1,0,0,0,1,1,1]

theorem envBound6625 : H12AffineFastState.Bounded env6625 := by
  intro p hp
  have h : env6625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6624_6625 : H12AffineEnvironment.transform 1 1 env6624 = env6625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6624 == env6625) = true)

theorem identity6625 : scanCanonicalize (H12AffineFastState.compose env6625 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 3) := by decide +kernel

theorem selectedBound6625 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6626 : List Nat := [2,1,2,1,1,1,3,1,0,0,0,1,3,1,1,3,0,1,1,1,0,1,0,3,3,0,0,1,1,1,0,0,0,1,1,1]

theorem envBound6626 : H12AffineFastState.Bounded env6626 := by
  intro p hp
  have h : env6626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6625_6626 : H12AffineEnvironment.transform 12 3 env6625 = env6626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3 env6625 == env6626) = true)

def env6627 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,115902,5545,41002,8329,5545,323712,16384,16812,22560,74795,73770,257,20481,95294,5653]

theorem envBound6627 : H12AffineFastState.Bounded env6627 := by
  intro p hp
  have h : env6627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6610_6627 : H12AffineEnvironment.transform 22 5545 env6610 = env6627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5545 env6610 == env6627) = true)

theorem identity6627 : scanCanonicalize (H12AffineFastState.compose env6627 (packedSelected [7,13,20,21,27] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6627 : packedSelected [7,13,20,21,27] rootPS < 2^1333 := by decide +kernel

def env6628 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,16384,32768,65536,4356,262144,1025,32768,4097,115735,5376,41002,8224,5376,323625,16384,16645,22560,74795,73770,257,20481,95294,5653]

theorem envBound6628 : H12AffineFastState.Bounded env6628 := by
  intro p hp
  have h : env6628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6627_6628 : H12AffineEnvironment.transform 6 41 env6627 = env6628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6627 == env6628) = true)

theorem identity6628 : scanCanonicalize (H12AffineFastState.compose env6628 (packedSelected [1,3,13,17,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound6628 : packedSelected [1,3,13,17,24,28] rootPS < 2^1333 := by decide +kernel

def env6629 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,16384,8200,65536,4356,262144,1025,8200,4097,91167,5376,34,8224,5376,282657,16384,16645,22560,74795,73770,257,20481,95294,5653]

theorem envBound6629 : H12AffineFastState.Bounded env6629 := by
  intro p hp
  have h : env6629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6628_6629 : H12AffineEnvironment.transform 14 8200 env6628 = env6629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env6628 == env6629) = true)

theorem identity6629 : scanCanonicalize (H12AffineFastState.compose env6629 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound6629 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env6630 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,16384,8200,65536,4356,2080,1025,8200,4097,91167,5376,34,8224,5376,22529,16384,16645,22560,74795,73770,257,20481,95294,5653]

theorem envBound6630 : H12AffineFastState.Bounded env6630 := by
  intro p hp
  have h : env6630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6629_6630 : H12AffineEnvironment.transform 17 2080 env6629 = env6630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env6629 == env6630) = true)

theorem identity6630 : scanCanonicalize (H12AffineFastState.compose env6630 (packedSelected [2,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 4129) := by decide +kernel

theorem selectedBound6630 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env6631 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,4129,8200,65536,4356,2080,1025,8200,4097,78910,5376,34,8224,5376,2080,4129,4388,2049,74795,73770,257,32,74783,5653]

theorem envBound6631 : H12AffineFastState.Bounded env6631 := by
  intro p hp
  have h : env6631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6630_6631 : H12AffineEnvironment.transform 13 4129 env6630 = env6631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4129 env6630 == env6631) = true)

theorem identity6631 : scanCanonicalize (H12AffineFastState.compose env6631 (packedSelected [4,6,7,11] rootPS)) = affineNative (2^(15+1) ^^^ 2342) := by decide +kernel

theorem selectedBound6631 : packedSelected [4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env6632 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,4129,8200,2342,4356,2080,1025,8200,4097,15640,5376,34,8224,5376,2080,4129,4388,2049,11533,10508,257,32,11577,5653]

theorem envBound6632 : H12AffineFastState.Bounded env6632 := by
  intro p hp
  have h : env6632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6631_6632 : H12AffineEnvironment.transform 15 2342 env6631 = env6632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2342 env6631 == env6632) = true)

theorem identity6632 : scanCanonicalize (H12AffineFastState.compose env6632 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 1808) := by decide +kernel

theorem selectedBound6632 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env6633 : List Nat := [2,4,8,16,32,16,41,256,512,1024,1808,4096,8192,4129,8200,1590,4356,1840,1025,8200,4097,12808,5376,34,8224,5376,1840,4129,4388,1809,8733,9756,257,32,8745,5653]

theorem envBound6633 : H12AffineFastState.Bounded env6633 := by
  intro p hp
  have h : env6633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6632_6633 : H12AffineEnvironment.transform 10 1808 env6632 = env6633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1808 env6632 == env6633) = true)

theorem identity6633 : scanCanonicalize (H12AffineFastState.compose env6633 (packedSelected [2,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound6633 : packedSelected [2,10,12] rootPS < 2^1333 := by decide +kernel

def env6634 : List Nat := [2,4,8,16,32,16,41,5,512,1024,1557,4096,8192,4129,8200,1590,4097,1589,1025,8200,4097,12808,5125,34,8224,5125,1589,4129,4129,1556,8733,9756,4,32,8745,5653]

theorem envBound6634 : H12AffineFastState.Bounded env6634 := by
  intro p hp
  have h : env6634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6633_6634 : H12AffineEnvironment.transform 7 5 env6633 = env6634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env6633 == env6634) = true)

theorem identity6634 : scanCanonicalize (H12AffineFastState.compose env6634 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound6634 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env6635 : List Nat := [2,4,8,16,26,16,19,5,512,1024,1557,4096,8192,4123,8200,1548,4097,1551,1025,8200,4097,12808,5125,24,8218,5125,1551,4123,4123,1556,8733,9756,4,26,8723,5653]

theorem envBound6635 : H12AffineFastState.Bounded env6635 := by
  intro p hp
  have h : env6635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6634_6635 : H12AffineEnvironment.transform 4 26 env6634 = env6635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env6634 == env6635) = true)

theorem identity6635 : scanCanonicalize (H12AffineFastState.compose env6635 (packedSelected [10,15] rootPS)) = affineNative (2^(12+1) ^^^ 1542) := by decide +kernel

theorem selectedBound6635 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env6636 : List Nat := [2,4,8,16,26,16,19,5,512,1024,1557,4096,1542,4123,1550,1548,4097,1551,1025,1550,4097,5134,5125,24,1564,5125,1551,4123,4123,1556,1051,26,4,26,1045,5653]

theorem envBound6636 : H12AffineFastState.Bounded env6636 := by
  intro p hp
  have h : env6636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6635_6636 : H12AffineEnvironment.transform 12 1542 env6635 = env6636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1542 env6635 == env6636) = true)

def env6637 : List Nat := [2,4,8,16,26,16,19,5,512,1024,1557,1556,1542,1551,1550,1548,1557,1551,1025,1550,1557,538,529,24,1564,529,1551,1551,1551,1556,1051,26,4,26,1045,1]

theorem envBound6637 : H12AffineFastState.Bounded env6637 := by
  intro p hp
  have h : env6637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6636_6637 : H12AffineEnvironment.transform 11 1556 env6636 = env6637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env6636 == env6637) = true)

theorem identity6637 : scanCanonicalize (H12AffineFastState.compose env6637 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound6637 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6638 : List Nat := [2,4,8,16,26,16,19,5,512,21,512,513,531,538,539,537,512,538,20,539,512,538,529,24,521,529,538,538,538,513,14,26,4,26,0,1]

theorem envBound6638 : H12AffineFastState.Bounded env6638 := by
  intro p hp
  have h : env6638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6637_6638 : H12AffineEnvironment.transform 9 21 env6637 = env6638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env6637 == env6638) = true)

def env6639 : List Nat := [2,4,8,16,26,16,19,5,0,21,0,1,19,26,27,25,0,26,20,27,0,26,17,24,9,17,26,26,26,1,14,26,4,26,0,1]

theorem envBound6639 : H12AffineFastState.Bounded env6639 := by
  intro p hp
  have h : env6639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6638_6639 : H12AffineEnvironment.transform 8 0 env6638 = env6639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env6638 == env6639) = true)

theorem identity6639 : scanCanonicalize (H12AffineFastState.compose env6639 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound6639 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6640 : List Nat := [2,4,6,16,20,16,19,5,0,21,0,1,19,20,21,23,0,20,20,21,0,20,17,22,7,17,20,20,20,1,0,20,4,20,0,1]

theorem envBound6640 : H12AffineFastState.Bounded env6640 := by
  intro p hp
  have h : env6640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6639_6640 : H12AffineEnvironment.transform 2 6 env6639 = env6640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env6639 == env6640) = true)

theorem identity6640 : scanCanonicalize (H12AffineFastState.compose env6640 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound6640 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env6641 : List Nat := [2,4,6,5,1,5,6,5,0,0,0,1,6,1,0,2,0,1,1,0,0,1,4,3,7,4,1,1,1,1,0,1,4,1,0,1]

theorem envBound6641 : H12AffineFastState.Bounded env6641 := by
  intro p hp
  have h : env6641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6640_6641 : H12AffineEnvironment.transform 3 5 env6640 = env6641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env6640 == env6641) = true)

theorem identity6641 : scanCanonicalize (H12AffineFastState.compose env6641 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound6641 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env6642 : List Nat := [2,1,3,0,1,0,3,0,0,0,0,1,3,1,0,2,0,1,1,0,0,1,1,3,2,1,1,1,1,1,0,1,1,1,0,1]

theorem envBound6642 : H12AffineFastState.Bounded env6642 := by
  intro p hp
  have h : env6642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6641_6642 : H12AffineEnvironment.transform 1 1 env6641 = env6642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6641 == env6642) = true)

def leafEnv6642 : List Nat := [2,1,3,0,1,0,3,0,0,0,0,1,3,1,0,2,0,1,1,0,0,1,1,3,0,2,1,1,1,1,1,1,0,1,1,1,1,2,0,1,1,0,0]

def active6642 : List Nat := [0]

def tree6642 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6642 : H12WitnessSearch.Good tree6642 := H12GlobalWitnessIndex.good

theorem leafIdentity6642 : H12AffineFastState.composeSystem env6642 rootObs = leafEnv6642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6642 rootObs == leafEnv6642) = true)

theorem terminalChecked6642 : H12PackedTerminal.terminalCheckFast leafEnv6642 active6642 tree6642 = true := by decide +kernel

def env6643 : List Nat := [2,4,8,16,26,16,19,5,1,21,1,0,18,27,26,24,1,27,20,26,1,27,16,24,8,16,27,27,27,0,14,26,4,26,0,1]

theorem envBound6643 : H12AffineFastState.Bounded env6643 := by
  intro p hp
  have h : env6643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6638_6643 : H12AffineEnvironment.transform 8 1 env6638 = env6643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env6638 == env6643) = true)

theorem identity6643 : scanCanonicalize (H12AffineFastState.compose env6643 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound6643 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6644 : List Nat := [2,4,8,10,0,10,9,5,1,15,1,0,8,1,0,2,1,1,14,0,1,1,10,2,8,10,1,1,1,0,14,0,4,0,0,1]

theorem envBound6644 : H12AffineFastState.Bounded env6644 := by
  intro p hp
  have h : env6644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6643_6644 : H12AffineEnvironment.transform 3 10 env6643 = env6644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env6643 == env6644) = true)

def env6645 : List Nat := [2,4,8,16,26,16,19,5,512,1024,1557,1557,1542,1550,1550,1548,1556,1551,1025,1550,1556,539,528,24,1564,528,1551,1550,1550,1556,1051,26,4,26,1045,0]

theorem envBound6645 : H12AffineFastState.Bounded env6645 := by
  intro p hp
  have h : env6645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6636_6645 : H12AffineEnvironment.transform 11 1557 env6636 = env6645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env6636 == env6645) = true)

theorem identity6645 : scanCanonicalize (H12AffineFastState.compose env6645 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound6645 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6646 : List Nat := [2,4,8,16,26,16,19,5,512,14,539,539,520,512,512,514,538,513,15,512,538,539,528,24,530,528,513,512,512,538,21,26,4,26,27,0]

theorem envBound6646 : H12AffineFastState.Bounded env6646 := by
  intro p hp
  have h : env6646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6645_6646 : H12AffineEnvironment.transform 9 14 env6645 = env6646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env6645 == env6646) = true)

def env6647 : List Nat := [2,4,8,16,26,16,19,5,0,14,27,27,8,0,0,2,26,1,15,0,26,27,16,24,18,16,1,0,0,26,21,26,4,26,27,0]

theorem envBound6647 : H12AffineFastState.Bounded env6647 := by
  intro p hp
  have h : env6647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6646_6647 : H12AffineEnvironment.transform 8 0 env6646 = env6647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env6646 == env6647) = true)

def env6648 : List Nat := [2,4,8,16,26,16,19,5,1,14,26,26,9,1,1,3,27,0,15,1,27,26,17,24,19,17,0,1,1,27,21,26,4,26,27,0]

theorem envBound6648 : H12AffineFastState.Bounded env6648 := by
  intro p hp
  have h : env6648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6646_6648 : H12AffineEnvironment.transform 8 1 env6646 = env6648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env6646 == env6648) = true)

theorem identity6648 : scanCanonicalize (H12AffineFastState.compose env6648 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound6648 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6649 : List Nat := [2,4,8,4,14,4,7,5,1,14,14,14,9,1,1,3,15,0,15,1,15,14,5,12,7,5,0,1,1,15,1,14,4,14,15,0]

theorem envBound6649 : H12AffineFastState.Bounded env6649 := by
  intro p hp
  have h : env6649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6648_6649 : H12AffineEnvironment.transform 3 4 env6648 = env6649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env6648 == env6649) = true)

theorem identity6649 : scanCanonicalize (H12AffineFastState.compose env6649 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound6649 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env6650 : List Nat := [2,4,6,4,0,4,7,5,1,0,0,0,7,1,1,3,1,0,1,1,1,0,5,2,7,5,0,1,1,1,1,0,4,0,1,0]

theorem envBound6650 : H12AffineFastState.Bounded env6650 := by
  intro p hp
  have h : env6650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6649_6650 : H12AffineEnvironment.transform 2 6 env6649 = env6650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env6649 == env6650) = true)

theorem identity6650 : scanCanonicalize (H12AffineFastState.compose env6650 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound6650 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env6651 : List Nat := [2,0,2,0,0,0,3,1,1,0,0,0,3,1,1,3,1,0,1,1,1,0,1,2,3,1,0,1,1,1,1,0,0,0,1,0]

theorem envBound6651 : H12AffineFastState.Bounded env6651 := by
  intro p hp
  have h : env6651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6650_6651 : H12AffineEnvironment.transform 1 0 env6650 = env6651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env6650 == env6651) = true)

def leafEnv6651 : List Nat := [2,0,2,0,0,0,3,1,1,0,0,0,3,1,1,3,1,0,1,1,1,0,1,2,1,3,1,1,0,1,1,1,1,0,0,0,0,2,1,0,1,0,0]

def active6651 : List Nat := [0]

def tree6651 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6651 : H12WitnessSearch.Good tree6651 := H12GlobalWitnessIndex.good

theorem leafIdentity6651 : H12AffineFastState.composeSystem env6651 rootObs = leafEnv6651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6651 rootObs == leafEnv6651) = true)

theorem terminalChecked6651 : H12PackedTerminal.terminalCheckFast leafEnv6651 active6651 tree6651 = true := by decide +kernel

def env6652 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,115902,8388608,41002,8329,8388609,323713,16384,16813,22561,74795,8467843,257,20480,95294,8389565]

theorem envBound6652 : H12AffineFastState.Bounded env6652 := by
  intro p hp
  have h : env6652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6609_6652 : H12AffineEnvironment.transform 5 17 env6609 = env6652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env6609 == env6652) = true)

theorem identity6652 : scanCanonicalize (H12AffineFastState.compose env6652 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound6652 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env6653 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,115902,445,41002,8329,444,323713,16384,16813,22561,74795,78910,257,20480,95294,512]

theorem envBound6653 : H12AffineFastState.Bounded env6653 := by
  intro p hp
  have h : env6653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6652_6653 : H12AffineEnvironment.transform 22 445 env6652 = env6653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env6652 == env6653) = true)

theorem identity6653 : scanCanonicalize (H12AffineFastState.compose env6653 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 25915) := by decide +kernel

theorem selectedBound6653 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6654 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,25915,4524,262144,1025,32768,4097,41349,445,41002,8329,444,323713,16384,16813,22561,16656,20741,257,20480,4357,512]

theorem envBound6654 : H12AffineFastState.Bounded env6654 := by
  intro p hp
  have h : env6654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6653_6654 : H12AffineEnvironment.transform 15 25915 env6653 = env6654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25915 env6653 == env6654) = true)

theorem identity6654 : scanCanonicalize (H12AffineFastState.compose env6654 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26261) := by decide +kernel

theorem selectedBound6654 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6655 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,26261,25915,4524,262144,1025,26261,4097,18192,445,18111,8329,444,267796,16384,16813,22561,16656,20741,257,20480,4357,512]

theorem envBound6655 : H12AffineFastState.Bounded env6655 := by
  intro p hp
  have h : env6655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6654_6655 : H12AffineEnvironment.transform 14 26261 env6654 = env6655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26261 env6654 == env6655) = true)

theorem identity6655 : scanCanonicalize (H12AffineFastState.compose env6655 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1464) := by decide +kernel

theorem selectedBound6655 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env6656 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1464,8192,16384,26261,25915,1044,262144,1025,26261,1465,18192,445,18111,8329,444,263084,16384,16813,19865,16656,17597,257,17848,1213,512]

theorem envBound6656 : H12AffineFastState.Bounded env6656 := by
  intro p hp
  have h : env6656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6655_6656 : H12AffineEnvironment.transform 11 1464 env6655 = env6656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1464 env6655 == env6656) = true)

theorem identity6656 : scanCanonicalize (H12AffineFastState.compose env6656 (packedSelected [12,13,15,17,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound6656 : packedSelected [12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env6657 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1464,8192,16384,26261,25915,1044,2341,1025,26261,1465,18192,445,18111,8329,444,2697,16384,16813,19865,16656,17597,257,17848,1213,512]

theorem envBound6657 : H12AffineFastState.Bounded env6657 := by
  intro p hp
  have h : env6657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6656_6657 : H12AffineEnvironment.transform 17 2341 env6656 = env6657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env6656 == env6657) = true)

theorem identity6657 : scanCanonicalize (H12AffineFastState.compose env6657 (packedSelected [0,4,7,8,9,10,12,13,15,17,18,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 1840) := by decide +kernel

theorem selectedBound6657 : packedSelected [0,4,7,8,9,10,12,13,15,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env6658 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1464,8192,1840,8613,8715,1044,2341,1025,8613,1465,32,445,399,8329,444,2697,1840,1693,2729,1568,909,257,648,1213,512]

theorem envBound6658 : H12AffineFastState.Bounded env6658 := by
  intro p hp
  have h : env6658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6657_6658 : H12AffineEnvironment.transform 13 1840 env6657 = env6658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1840 env6657 == env6658) = true)

theorem identity6658 : scanCanonicalize (H12AffineFastState.compose env6658 (packedSelected [0,1,3,4,7,9,12,13,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound6658 : packedSelected [0,1,3,4,7,9,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env6659 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1044,8192,1692,8201,8715,1044,2185,1025,8201,1045,32,17,35,8329,16,2697,1692,1693,2729,1568,545,173,648,1213,512]

theorem envBound6659 : H12AffineFastState.Bounded env6659 := by
  intro p hp
  have h : env6659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6658_6659 : H12AffineEnvironment.transform 7 172 env6658 = env6659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env6658 == env6659) = true)

theorem identity6659 : scanCanonicalize (H12AffineFastState.compose env6659 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1702) := by decide +kernel

theorem selectedBound6659 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6660 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1702,1044,8192,1692,8201,8715,1044,1583,1025,8201,1045,32,17,35,8329,16,1071,1692,1693,1039,1568,545,173,648,1213,512]

theorem envBound6660 : H12AffineFastState.Bounded env6660 := by
  intro p hp
  have h : env6660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6659_6660 : H12AffineEnvironment.transform 10 1702 env6659 = env6660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1702 env6659 == env6660) = true)

theorem identity6660 : scanCanonicalize (H12AffineFastState.compose env6660 (packedSelected [2,3,7,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 1710) := by decide +kernel

theorem selectedBound6660 : packedSelected [2,3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env6661 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1702,1044,1710,1692,1703,1189,1044,1583,1025,1703,1045,32,17,35,1575,16,1071,1692,1693,1039,1568,545,173,648,1213,512]

theorem envBound6661 : H12AffineFastState.Bounded env6661 := by
  intro p hp
  have h : env6661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6660_6661 : H12AffineEnvironment.transform 12 1710 env6660 = env6661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1710 env6660 == env6661) = true)

theorem identity6661 : scanCanonicalize (H12AffineFastState.compose env6661 (packedSelected [2,3] rootPS)) = affineNative (2^(9+1) ^^^ 647) := by decide +kernel

theorem selectedBound6661 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env6662 : List Nat := [2,4,8,16,32,17,128,172,512,647,33,659,41,27,32,546,659,168,646,32,658,32,17,35,160,16,680,27,26,648,167,545,173,648,570,512]

theorem envBound6662 : H12AffineFastState.Bounded env6662 := by
  intro p hp
  have h : env6662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6661_6662 : H12AffineEnvironment.transform 9 647 env6661 = env6662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 647 env6661 == env6662) = true)

theorem identity6662 : scanCanonicalize (H12AffineFastState.compose env6662 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound6662 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env6663 : List Nat := [2,4,8,16,32,17,19,63,512,532,33,512,41,27,32,546,512,59,533,32,513,32,17,35,51,16,571,27,26,539,52,545,62,539,570,512]

theorem envBound6663 : H12AffineFastState.Bounded env6663 := by
  intro p hp
  have h : env6663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6662_6663 : H12AffineEnvironment.transform 6 19 env6662 = env6663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env6662 == env6663) = true)

theorem identity6663 : scanCanonicalize (H12AffineFastState.compose env6663 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound6663 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env6664 : List Nat := [2,4,8,16,32,17,19,63,1,21,33,1,41,27,32,35,1,59,20,32,0,32,17,35,51,16,58,27,26,26,52,32,62,26,59,1]

theorem envBound6664 : H12AffineFastState.Bounded env6664 := by
  intro p hp
  have h : env6664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6663_6664 : H12AffineEnvironment.transform 8 1 env6663 = env6664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env6663 == env6664) = true)

theorem identity6664 : scanCanonicalize (H12AffineFastState.compose env6664 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound6664 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6665 : List Nat := [2,4,8,16,26,17,19,5,1,21,27,1,19,27,26,25,1,1,20,26,0,26,17,25,9,16,0,27,26,26,14,26,4,26,1,1]

theorem envBound6665 : H12AffineFastState.Bounded env6665 := by
  intro p hp
  have h : env6665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6664_6665 : H12AffineEnvironment.transform 4 26 env6664 = env6665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env6664 == env6665) = true)

theorem identity6665 : scanCanonicalize (H12AffineFastState.compose env6665 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound6665 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6666 : List Nat := [2,4,8,11,1,10,8,5,1,14,0,1,8,0,1,2,1,1,15,1,0,1,10,2,9,11,0,0,1,1,14,1,4,1,1,1]

theorem envBound6666 : H12AffineFastState.Bounded env6666 := by
  intro p hp
  have h : env6666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6665_6666 : H12AffineEnvironment.transform 3 11 env6665 = env6666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env6665 == env6666) = true)

def env6667 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,33554432,67108864,134217728,268435456,536870912,1073741824,2147483648,3343452565,525568,1107306665,34359738368,59279182]

theorem envBound6667 : H12AffineFastState.Bounded env6667 := by
  intro p hp
  have h : env6667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4_6667 : H12AffineEnvironment.transform 31 3343452565 env4 = env6667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 3343452565 env4 == env6667) = true)

def env6668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,536870912,1073741824,2147483648,3309906205,525568,1073743905,34359738368,25733062]

theorem envBound6668 : H12AffineFastState.Bounded env6668 := by
  intro p hp
  have h : env6668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6667_6668 : H12AffineEnvironment.transform 24 8328 env6667 = env6668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env6667 == env6668) = true)

theorem identity6668 : scanCanonicalize (H12AffineFastState.compose env6668 (packedSelected [6,25] rootPS)) = affineNative (2^(30+1) ^^^ 92374096) := by decide +kernel

theorem selectedBound6668 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env6669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,536870912,1073741824,92374096,1086893389,525568,1073743905,34359738368,25733062]

theorem envBound6669 : H12AffineFastState.Bounded env6669 := by
  intro p hp
  have h : env6669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6668_6669 : H12AffineEnvironment.transform 30 92374096 env6668 = env6669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 30 92374096 env6668 == env6669) = true)

def env6670 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,268570624,1073741824,92374096,1086893389,525568,1073743905,34359738368,25733062]

theorem envBound6670 : H12AffineFastState.Bounded env6670 := by
  intro p hp
  have h : env6670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6669_6670 : H12AffineEnvironment.transform 28 268570624 env6669 = env6670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 268570624 env6669 == env6670) = true)

theorem identity6670 : scanCanonicalize (H12AffineFastState.compose env6670 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(26+1) ^^^ 25994575) := by decide +kernel

theorem selectedBound6670 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env6671 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,25994575,268435456,268570624,1073741824,92374096,1086893389,525568,1073743905,34359738368,25733062]

theorem envBound6671 : H12AffineFastState.Bounded env6671 := by
  intro p hp
  have h : env6671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6670_6671 : H12AffineEnvironment.transform 26 25994575 env6670 = env6671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 25994575 env6670 == env6671) = true)

def env6672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988132,8328,67108864,360619,268435456,268570624,1073741824,67674548,1086893389,525568,1073743905,34359738368,98850]

theorem envBound6672 : H12AffineFastState.Bounded env6672 := by
  intro p hp
  have h : env6672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6671_6672 : H12AffineEnvironment.transform 23 8988132 env6671 = env6672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8988132 env6671 == env6672) = true)

theorem identity6672 : scanCanonicalize (H12AffineFastState.compose env6672 (packedSelected [0,1,3,7,9,10,14,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(29+1) ^^^ 13208935) := by decide +kernel

theorem selectedBound6672 : packedSelected [0,1,3,7,9,10,14,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env6673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988132,8328,67108864,360619,268435456,268570624,13208935,67674548,73770,525568,13206854,34359738368,98850]

theorem envBound6673 : H12AffineFastState.Bounded env6673 := by
  intro p hp
  have h : env6673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6672_6673 : H12AffineEnvironment.transform 29 13208935 env6672 = env6673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 13208935 env6672 == env6673) = true)

def env6674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988132,8328,67108864,360619,77615104,77742080,13208935,67674548,73770,525568,13206854,34359738368,98850]

theorem envBound6674 : H12AffineFastState.Bounded env6674 := by
  intro p hp
  have h : env6674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6673_6674 : H12AffineEnvironment.transform 27 77615104 env6673 = env6674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 77615104 env6673 == env6674) = true)

theorem identity6674 : scanCanonicalize (H12AffineFastState.compose env6674 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(25+1) ^^^ 566496) := by decide +kernel

theorem selectedBound6674 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env6675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988132,8328,566496,360619,11072736,11199712,13208935,1364,73770,525568,13206854,34359738368,98850]

theorem envBound6675 : H12AffineFastState.Bounded env6675 := by
  intro p hp
  have h : env6675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6674_6675 : H12AffineEnvironment.transform 25 566496 env6674 = env6675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 566496 env6674 == env6675) = true)

def env6676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,4194304,8388608,8988132,8328,525376,335883,11031616,11158592,13184455,1364,73770,525568,13182438,34359738368,74370]

theorem envBound6676 : H12AffineFastState.Bounded env6676 := by
  intro p hp
  have h : env6676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6675_6676 : H12AffineEnvironment.transform 14 8352 env6675 = env6676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env6675 == env6676) = true)

theorem identity6676 : scanCanonicalize (H12AffineFastState.compose env6676 (packedSelected [11,18,23,32] rootPS)) = affineNative (2^(21+1) ^^^ 477) := by decide +kernel

theorem selectedBound6676 : packedSelected [11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env6677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,477,8388608,8988132,8328,525376,335883,11031616,11158592,8989722,1364,73770,525568,8987707,34359738368,74370]

theorem envBound6677 : H12AffineFastState.Bounded env6677 := by
  intro p hp
  have h : env6677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6676_6677 : H12AffineEnvironment.transform 21 477 env6676 = env6677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 477 env6676 == env6677) = true)

def env6678 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,524288,8200,2097152,373,8388608,8987980,8224,525376,335883,11031616,11158592,8989722,1364,73770,525568,8987707,34359738368,74282]

theorem envBound6678 : H12AffineFastState.Bounded env6678 := by
  intro p hp
  have h : env6678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6677_6678 : H12AffineEnvironment.transform 6 40 env6677 = env6678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env6677 == env6678) = true)

theorem identity6678 : scanCanonicalize (H12AffineFastState.compose env6678 (packedSelected [0,4,7,9,14,18,23] rootPS)) = affineNative (2^(34+1) ^^^ 82294) := by decide +kernel

theorem selectedBound6678 : packedSelected [0,4,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env6679 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,524288,8200,2097152,373,8388608,8987980,8224,525376,335883,11031616,11158592,8989722,1364,73770,525568,8987707,82294,74282]

theorem envBound6679 : H12AffineFastState.Bounded env6679 := by
  intro p hp
  have h : env6679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6678_6679 : H12AffineEnvironment.transform 34 82294 env6678 = env6679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 82294 env6678 == env6679) = true)

theorem identity6679 : scanCanonicalize (H12AffineFastState.compose env6679 (packedSelected [11,18] rootPS)) = affineNative (2^(15+1) ^^^ 374) := by decide +kernel

theorem selectedBound6679 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env6680 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8200,374,131072,262144,524288,8200,2097152,373,8388608,8922170,8224,525376,270717,11031616,11158592,8924524,1364,8540,525568,8922445,16384,9052]

theorem envBound6680 : H12AffineFastState.Bounded env6680 := by
  intro p hp
  have h : env6680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6679_6680 : H12AffineEnvironment.transform 15 374 env6679 = env6680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 374 env6679 == env6680) = true)

theorem identity6680 : scanCanonicalize (H12AffineFastState.compose env6680 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound6680 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env6681 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8200,374,5393,262144,524288,8200,2097152,373,8388608,8922170,8224,525376,270717,11031616,11030865,8924524,1364,8540,525568,8922445,16384,9052]

theorem envBound6681 : H12AffineFastState.Bounded env6681 := by
  intro p hp
  have h : env6681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6680_6681 : H12AffineEnvironment.transform 16 5393 env6680 = env6681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env6680 == env6681) = true)

theorem identity6681 : scanCanonicalize (H12AffineFastState.compose env6681 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(22+1) ^^^ 525328) := by decide +kernel

theorem selectedBound6681 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env6682 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8200,374,5393,262144,524288,8200,2097152,373,525328,8234,8224,525376,270717,2117712,2118977,10620,1364,8540,525568,8541,16384,9052]

theorem envBound6682 : H12AffineFastState.Bounded env6682 := by
  intro p hp
  have h : env6682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6681_6682 : H12AffineEnvironment.transform 22 525328 env6681 = env6682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 525328 env6681 == env6682) = true)

theorem identity6682 : scanCanonicalize (H12AffineFastState.compose env6682 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 549145) := by decide +kernel

theorem selectedBound6682 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env6683 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8200,374,5393,262144,524288,8200,549145,373,525328,8234,8224,525376,270717,536905,537688,10620,1364,8540,525568,8541,16384,9052]

theorem envBound6683 : H12AffineFastState.Bounded env6683 := by
  intro p hp
  have h : env6683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6682_6683 : H12AffineEnvironment.transform 20 549145 env6682 = env6683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 549145 env6682 == env6683) = true)

theorem identity6683 : scanCanonicalize (H12AffineFastState.compose env6683 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound6683 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env6684 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,349,16384,341,374,5393,262144,524288,341,540740,373,525328,375,381,525376,262176,528404,529669,2081,1364,1,525568,0,16384,513]

theorem envBound6684 : H12AffineFastState.Bounded env6684 := by
  intro p hp
  have h : env6684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6683_6684 : H12AffineEnvironment.transform 12 349 env6683 = env6684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env6683 == env6684) = true)

theorem identity6684 : scanCanonicalize (H12AffineFastState.compose env6684 (packedSelected [2,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound6684 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env6685 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8,16384,0,35,5188,262144,524288,0,540740,32,525328,34,40,525376,262176,528404,529488,2081,1025,1,525397,0,16384,513]

theorem envBound6685 : H12AffineFastState.Bounded env6685 := by
  intro p hp
  have h : env6685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6684_6685 : H12AffineEnvironment.transform 7 85 env6684 = env6685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env6684 == env6685) = true)

theorem identity6685 : scanCanonicalize (H12AffineFastState.compose env6685 (packedSelected [3,5,10] rootPS)) = affineNative (2^(18+1) ^^^ 20565) := by decide +kernel

theorem selectedBound6685 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env6686 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8,16384,0,35,5188,262144,20565,0,4113,32,21573,34,40,21525,262176,16449,17413,2081,1025,1,21504,0,16384,513]

theorem envBound6686 : H12AffineFastState.Bounded env6686 := by
  intro p hp
  have h : env6686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6685_6686 : H12AffineEnvironment.transform 18 20565 env6685 = env6686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 20565 env6685 == env6686) = true)

def env6687 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,524288,8201,2097152,372,8388608,8987981,8225,525376,335883,11031616,11158592,8989722,1364,73770,525568,8987707,34359738368,74283]

theorem envBound6687 : H12AffineFastState.Bounded env6687 := by
  intro p hp
  have h : env6687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6677_6687 : H12AffineEnvironment.transform 6 41 env6677 = env6687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6677 == env6687) = true)

theorem identity6687 : scanCanonicalize (H12AffineFastState.compose env6687 (packedSelected [0,4,7,9,14,18,23] rootPS)) = affineNative (2^(34+1) ^^^ 24924) := by decide +kernel

theorem selectedBound6687 : packedSelected [0,4,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env6688 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,524288,8201,2097152,372,8388608,8987981,8225,525376,335883,11031616,11158592,8989722,1364,73770,525568,8987707,24924,74283]

theorem envBound6688 : H12AffineFastState.Bounded env6688 := by
  intro p hp
  have h : env6688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6687_6688 : H12AffineEnvironment.transform 34 24924 env6687 = env6688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 24924 env6687 == env6688) = true)

theorem identity6688 : scanCanonicalize (H12AffineFastState.compose env6688 (packedSelected [11,13,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 375) := by decide +kernel

theorem selectedBound6688 : packedSelected [11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env6689 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8201,375,131072,262144,524288,8201,2097152,372,8388608,8922170,8225,525376,270716,11031616,11158592,8924525,1364,8541,525568,8922444,24924,9052]

theorem envBound6689 : H12AffineFastState.Bounded env6689 := by
  intro p hp
  have h : env6689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6688_6689 : H12AffineEnvironment.transform 15 375 env6688 = env6689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 375 env6688 == env6689) = true)

theorem identity6689 : scanCanonicalize (H12AffineFastState.compose env6689 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound6689 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env6690 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8201,375,5393,262144,524288,8201,2097152,372,8388608,8922170,8225,525376,270716,11031616,11030865,8924525,1364,8541,525568,8922444,24924,9052]

theorem envBound6690 : H12AffineFastState.Bounded env6690 := by
  intro p hp
  have h : env6690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6689_6690 : H12AffineEnvironment.transform 16 5393 env6689 = env6690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env6689 == env6690) = true)

theorem identity6690 : scanCanonicalize (H12AffineFastState.compose env6690 (packedSelected [11,14,17,20,21] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound6690 : packedSelected [11,14,17,20,21] rootPS < 2^1333 := by decide +kernel

def env6691 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,348,16384,341,375,5393,262144,524288,341,2097152,372,8388608,8914278,381,525376,262176,11031616,11030865,8916017,1364,1,525568,8913936,16384,512]

theorem envBound6691 : H12AffineFastState.Bounded env6691 := by
  intro p hp
  have h : env6691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6690_6691 : H12AffineEnvironment.transform 12 348 env6690 = env6691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env6690 == env6691) = true)

theorem identity6691 : scanCanonicalize (H12AffineFastState.compose env6691 (packedSelected [1,3,8,10,24] rootPS)) = affineNative (2^(22+1) ^^^ 2114816) := by decide +kernel

theorem selectedBound6691 : packedSelected [1,3,8,10,24] rootPS < 2^1333 := by decide +kernel

def env6692 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,348,16384,341,375,5393,262144,524288,341,2097152,372,2114816,2637926,381,525376,262176,528704,529489,2640177,1364,1,525568,2638096,16384,512]

theorem envBound6692 : H12AffineFastState.Bounded env6692 := by
  intro p hp
  have h : env6692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6691_6692 : H12AffineEnvironment.transform 22 2114816 env6691 = env6692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2114816 env6691 == env6692) = true)

theorem identity6692 : scanCanonicalize (H12AffineFastState.compose env6692 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound6692 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env6693 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8,16384,1,35,5189,262144,524288,1,2097152,32,2114644,2637926,41,525376,262176,528404,529489,2639973,1024,1,525396,2637892,16384,512]

theorem envBound6693 : H12AffineFastState.Bounded env6693 := by
  intro p hp
  have h : env6693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6692_6693 : H12AffineEnvironment.transform 7 84 env6692 = env6693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env6692 == env6693) = true)

theorem identity6693 : scanCanonicalize (H12AffineFastState.compose env6693 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 17428) := by decide +kernel

theorem selectedBound6693 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env6694 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8,16384,1,35,5189,262144,524288,1,17428,32,64,525426,41,525376,262176,528404,529489,527473,1024,1,525396,525392,16384,512]

theorem envBound6694 : H12AffineFastState.Bounded env6694 := by
  intro p hp
  have h : env6694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6693_6694 : H12AffineEnvironment.transform 20 17428 env6693 = env6694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17428 env6693 == env6694) = true)

def env6695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,65536,131072,262144,524288,8353,2097152,4194304,8388608,8988132,8328,525377,335882,11031617,11158593,13184454,1364,73770,525568,13182439,34359738368,74371]

theorem envBound6695 : H12AffineFastState.Bounded env6695 := by
  intro p hp
  have h : env6695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6675_6695 : H12AffineEnvironment.transform 14 8353 env6675 = env6695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env6675 == env6695) = true)

def env6696 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,65536,131072,262144,524288,8353,2097152,4194304,8388608,8987672,8328,525377,335882,11031617,11158593,13184058,1192,73770,525564,13181979,34359738368,74371]

theorem envBound6696 : H12AffineFastState.Bounded env6696 := by
  intro p hp
  have h : env6696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0