import H12CloudChart0Data034

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans8699_8700 : H12AffineEnvironment.transform 12 25 env8699 = env8700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env8699 == env8700) = true)

theorem identity8700 : scanCanonicalize (H12AffineFastState.compose env8700 (packedSelected [0,1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8700 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env8701 : List Nat := [2,4,3,16,1,16,19,4,16,4,2048,2049,18,1,1,19,2065,17,2052,1,16,17,2048,3,3,2049,1,2065,2048,2049,21,17,2052,0,2048,0]

theorem envBound8701 : H12AffineFastState.Bounded env8701 := by
  intro p hp
  have h : env8701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8700_8701 : H12AffineEnvironment.transform 2 3 env8700 = env8701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8700 == env8701) = true)

def env8702 : List Nat := [2,4,8,16,32,64,128,256,217,256,2048,4096,8192,232,8693,8235,4605,502,4537,8693,64,477,4436,34,8329,4097,382,4605,4097,2080,504,168,4537,0,4096,292]

theorem envBound8702 : H12AffineFastState.Bounded env8702 := by
  intro p hp
  have h : env8702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8693_8702 : H12AffineEnvironment.transform 8 217 env8693 = env8702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env8693 == env8702) = true)

theorem identity8702 : scanCanonicalize (H12AffineFastState.compose env8702 (packedSelected [7,20,27] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound8702 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8703 : List Nat := [2,4,8,16,32,16,128,256,137,256,2048,4096,8192,184,8613,8235,4525,422,4537,8613,16,397,4356,34,8329,4097,302,4525,4097,2080,424,168,4537,0,4096,292]

theorem envBound8703 : H12AffineFastState.Bounded env8703 := by
  intro p hp
  have h : env8703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8702_8703 : H12AffineEnvironment.transform 5 16 env8702 = env8703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8702 == env8703) = true)

theorem identity8703 : scanCanonicalize (H12AffineFastState.compose env8703 (packedSelected [13,14,17] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound8703 : packedSelected [13,14,17] rootPS < 2^1333 := by decide +kernel

def env8704 : List Nat := [2,4,8,16,32,16,128,256,137,256,130,4096,8192,184,8613,8235,4525,422,4537,8613,16,397,4356,34,8329,4097,302,4525,4097,162,424,168,4537,0,4096,292]

theorem envBound8704 : H12AffineFastState.Bounded env8704 := by
  intro p hp
  have h : env8704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8703_8704 : H12AffineEnvironment.transform 10 130 env8703 = env8704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env8703 == env8704) = true)

theorem identity8704 : scanCanonicalize (H12AffineFastState.compose env8704 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound8704 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env8705 : List Nat := [2,4,8,16,32,16,128,256,137,256,130,185,8192,184,8613,8235,276,422,256,8613,16,397,445,34,8329,184,302,276,184,162,424,168,256,0,185,292]

theorem envBound8705 : H12AffineFastState.Bounded env8705 := by
  intro p hp
  have h : env8705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8704_8705 : H12AffineEnvironment.transform 11 185 env8704 = env8705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env8704 == env8705) = true)

theorem identity8705 : scanCanonicalize (H12AffineFastState.compose env8705 (packedSelected [0,4,5,7,8,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound8705 : packedSelected [0,4,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env8706 : List Nat := [2,4,8,16,11,16,128,256,137,256,130,146,8192,147,8590,8192,276,397,256,8590,16,397,406,9,8329,147,261,276,147,137,387,131,256,0,146,271]

theorem envBound8706 : H12AffineFastState.Bounded env8706 := by
  intro p hp
  have h : env8706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8705_8706 : H12AffineEnvironment.transform 4 11 env8705 = env8706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env8705 == env8706) = true)

theorem identity8706 : scanCanonicalize (H12AffineFastState.compose env8706 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 138) := by decide +kernel

theorem selectedBound8706 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env8707 : List Nat := [2,4,8,16,11,16,128,256,137,256,130,146,138,147,260,138,276,397,256,260,16,397,406,9,3,147,261,276,147,137,387,131,256,0,146,271]

theorem envBound8707 : H12AffineFastState.Bounded env8707 := by
  intro p hp
  have h : env8707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8706_8707 : H12AffineEnvironment.transform 12 138 env8706 = env8707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 138 env8706 == env8707) = true)

theorem identity8707 : scanCanonicalize (H12AffineFastState.compose env8707 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound8707 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env8708 : List Nat := [2,4,8,16,11,16,128,31,137,31,130,146,138,147,27,138,11,146,31,27,16,146,137,9,3,147,26,11,147,137,156,131,31,0,146,16]

theorem envBound8708 : H12AffineFastState.Bounded env8708 := by
  intro p hp
  have h : env8708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8707_8708 : H12AffineEnvironment.transform 7 31 env8707 = env8708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env8707 == env8708) = true)

theorem identity8708 : scanCanonicalize (H12AffineFastState.compose env8708 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8708 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8709 : List Nat := [2,4,8,1,11,1,128,14,137,14,130,131,138,130,10,138,11,131,14,10,1,131,137,9,3,130,11,11,130,137,141,131,14,0,131,1]

theorem envBound8709 : H12AffineFastState.Bounded env8709 := by
  intro p hp
  have h : env8709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8708_8709 : H12AffineEnvironment.transform 3 1 env8708 = env8709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8708 == env8709) = true)

theorem identity8709 : scanCanonicalize (H12AffineFastState.compose env8709 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound8709 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env8710 : List Nat := [2,4,8,1,11,1,8,14,1,14,10,11,2,10,10,2,11,11,14,10,1,11,1,9,3,10,11,11,10,1,5,11,14,0,11,1]

theorem envBound8710 : H12AffineFastState.Bounded env8710 := by
  intro p hp
  have h : env8710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8709_8710 : H12AffineEnvironment.transform 6 8 env8709 = env8710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env8709 == env8710) = true)

theorem identity8710 : scanCanonicalize (H12AffineFastState.compose env8710 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8710 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env8711 : List Nat := [2,4,2,1,1,1,2,4,1,4,0,1,2,0,0,2,1,1,4,0,1,1,1,3,3,0,1,1,0,1,5,1,4,0,1,1]

theorem envBound8711 : H12AffineFastState.Bounded env8711 := by
  intro p hp
  have h : env8711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8710_8711 : H12AffineEnvironment.transform 2 2 env8710 = env8711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8710 == env8711) = true)

def leafEnv8711 : List Nat := [2,4,2,1,1,1,2,4,1,4,0,1,2,0,0,2,1,1,4,0,1,1,1,3,5,3,1,0,1,1,0,1,5,1,4,0,4,2,1,1,1,1,0]

def active8711 : List Nat := [0,1]

def tree8711 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8711 : H12WitnessSearch.Good tree8711 := H12GlobalWitnessIndex.good

theorem leafIdentity8711 : H12AffineFastState.composeSystem env8711 rootObs = leafEnv8711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8711 rootObs == leafEnv8711) = true)

theorem terminalChecked8711 : H12PackedTerminal.terminalCheckFast leafEnv8711 active8711 tree8711 = true := by decide +kernel

def env8712 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,233,8693,8234,4605,814,4960,8693,64,4194304,5005,34,8329,4825,935,4198433,4198877,2081,504,4194676,4960,1,4824,1021]

theorem envBound8712 : H12AffineFastState.Bounded env8712 := by
  intro p hp
  have h : env8712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8691_8712 : H12AffineEnvironment.transform 13 233 env8691 = env8712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 233 env8691 == env8712) = true)

theorem identity8712 : scanCanonicalize (H12AffineFastState.compose env8712 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound8712 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8713 : List Nat := [2,4,8,16,32,64,128,84,512,84,2048,4096,8192,233,8353,8234,4265,634,4660,8353,64,4194304,4825,34,8329,4825,755,4198433,4198537,2081,172,4194336,4660,1,4824,681]

theorem envBound8713 : H12AffineFastState.Bounded env8713 := by
  intro p hp
  have h : env8713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8712_8713 : H12AffineEnvironment.transform 7 84 env8712 = env8713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env8712 == env8713) = true)

theorem identity8713 : scanCanonicalize (H12AffineFastState.compose env8713 (packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS)) = affineNative (2^(11+1) ^^^ 2195) := by decide +kernel

theorem selectedBound8713 : packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env8714 : List Nat := [2,4,8,16,32,64,128,84,512,84,2048,2195,8192,233,8353,8234,2106,634,2727,8353,64,4194304,2634,34,8329,2634,755,4196530,4196378,2081,172,4194336,2727,1,2635,681]

theorem envBound8714 : H12AffineFastState.Bounded env8714 := by
  intro p hp
  have h : env8714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8713_8714 : H12AffineEnvironment.transform 11 2195 env8713 = env8714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2195 env8713 == env8714) = true)

theorem identity8714 : scanCanonicalize (H12AffineFastState.compose env8714 (packedSelected [3,4,7,9,10,18,19,23,24,27] rootPS)) = affineNative (2^(10+1) ^^^ 602) := by decide +kernel

theorem selectedBound8714 : packedSelected [3,4,7,9,10,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env8715 : List Nat := [2,4,8,16,32,64,128,84,512,84,602,713,8192,233,8353,8234,608,634,253,8353,64,4194304,16,34,8329,16,755,4195048,4194880,635,172,4194336,253,1,17,681]

theorem envBound8715 : H12AffineFastState.Bounded env8715 := by
  intro p hp
  have h : env8715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8714_8715 : H12AffineEnvironment.transform 10 602 env8714 = env8715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 602 env8714 == env8715) = true)

theorem identity8715 : scanCanonicalize (H12AffineFastState.compose env8715 (packedSelected [13,15,17,38] rootPS)) = affineNative (2^(21+1) ^^^ 216) := by decide +kernel

theorem selectedBound8715 : packedSelected [13,15,17,38] rootPS < 2^1333 := by decide +kernel

def env8716 : List Nat := [2,4,8,16,32,64,128,84,512,84,602,713,8192,233,8353,8234,608,634,253,8353,64,216,16,34,8329,16,755,560,664,635,172,248,253,1,17,681]

theorem envBound8716 : H12AffineFastState.Bounded env8716 := by
  intro p hp
  have h : env8716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8715_8716 : H12AffineEnvironment.transform 21 216 env8715 = env8716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 216 env8715 == env8716) = true)

theorem identity8716 : scanCanonicalize (H12AffineFastState.compose env8716 (packedSelected [10,11,12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 626) := by decide +kernel

theorem selectedBound8716 : packedSelected [10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env8717 : List Nat := [2,4,8,16,32,64,128,84,512,84,602,713,626,233,723,600,608,634,253,723,64,216,16,34,763,16,755,560,664,635,172,248,253,1,17,681]

theorem envBound8717 : H12AffineFastState.Bounded env8717 := by
  intro p hp
  have h : env8717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8716_8717 : H12AffineEnvironment.transform 12 626 env8716 = env8717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 626 env8716 == env8717) = true)

theorem identity8717 : scanCanonicalize (H12AffineFastState.compose env8717 (packedSelected [1,5,7,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound8717 : packedSelected [1,5,7,9,11] rootPS < 2^1333 := by decide +kernel

def env8718 : List Nat := [2,4,8,16,32,11,128,31,512,31,529,642,569,162,664,531,555,561,182,664,11,147,16,34,688,16,696,560,664,560,172,179,182,1,17,681]

theorem envBound8718 : H12AffineFastState.Bounded env8718 := by
  intro p hp
  have h : env8718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8717_8718 : H12AffineEnvironment.transform 5 11 env8717 = env8718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env8717 == env8718) = true)

theorem identity8718 : scanCanonicalize (H12AffineFastState.compose env8718 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound8718 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env8719 : List Nat := [2,4,8,16,32,11,2,31,512,31,529,512,569,32,538,531,555,561,52,538,11,17,16,34,562,16,570,560,538,560,46,49,52,1,17,555]

theorem envBound8719 : H12AffineFastState.Bounded env8719 := by
  intro p hp
  have h : env8719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8718_8719 : H12AffineEnvironment.transform 6 2 env8718 = env8719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env8718 == env8719) = true)

theorem identity8719 : scanCanonicalize (H12AffineFastState.compose env8719 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(8+1) ^^^ 58) := by decide +kernel

theorem selectedBound8719 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env8720 : List Nat := [2,4,8,16,32,11,2,31,58,31,43,58,3,32,32,41,17,11,52,32,11,17,16,34,8,16,0,10,32,10,46,49,52,1,17,17]

theorem envBound8720 : H12AffineFastState.Bounded env8720 := by
  intro p hp
  have h : env8720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8719_8720 : H12AffineEnvironment.transform 8 58 env8719 = env8720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 58 env8719 == env8720) = true)

theorem identity8720 : scanCanonicalize (H12AffineFastState.compose env8720 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8720 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env8721 : List Nat := [2,4,8,1,32,11,2,14,43,14,43,43,3,32,32,41,0,11,37,32,11,0,1,34,8,1,0,10,32,10,46,32,37,1,0,0]

theorem envBound8721 : H12AffineFastState.Bounded env8721 := by
  intro p hp
  have h : env8721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8720_8721 : H12AffineEnvironment.transform 3 1 env8720 = env8721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8720 == env8721) = true)

theorem identity8721 : scanCanonicalize (H12AffineFastState.compose env8721 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8721 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8722 : List Nat := [2,4,3,1,32,0,2,5,32,5,32,32,3,32,32,34,0,0,37,32,0,0,1,34,3,1,0,1,32,1,37,32,37,1,0,0]

theorem envBound8722 : H12AffineFastState.Bounded env8722 := by
  intro p hp
  have h : env8722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8721_8722 : H12AffineEnvironment.transform 2 3 env8721 = env8722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8721 == env8722) = true)

theorem identity8722 : scanCanonicalize (H12AffineFastState.compose env8722 (packedSelected [9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8722 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env8723 : List Nat := [2,4,3,1,0,0,2,5,0,5,0,0,3,0,0,2,0,0,5,0,0,0,1,2,3,1,0,1,0,1,5,0,5,1,0,0]

theorem envBound8723 : H12AffineFastState.Bounded env8723 := by
  intro p hp
  have h : env8723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8722_8723 : H12AffineEnvironment.transform 4 0 env8722 = env8723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8722 == env8723) = true)

def leafEnv8723 : List Nat := [2,4,3,1,0,0,2,5,0,5,0,0,3,0,0,2,0,0,5,0,0,0,1,2,5,3,1,1,0,1,0,1,5,0,5,1,4,3,0,0,1,1,0]

def active8723 : List Nat := [0,1]

def tree8723 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8723 : H12WitnessSearch.Good tree8723 := H12GlobalWitnessIndex.good

theorem leafIdentity8723 : H12AffineFastState.composeSystem env8723 rootObs = leafEnv8723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8723 rootObs == leafEnv8723) = true)

theorem terminalChecked8723 : H12PackedTerminal.terminalCheckFast leafEnv8723 active8723 tree8723 = true := by decide +kernel

def env8724 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,24771,4605,262144,4960,8693,65,4194304,5005,34,8329,21040,278624,4214984,4215092,18632,504,4211101,4960,16616,21040,1021]

theorem envBound8724 : H12AffineFastState.Bounded env8724 := by
  intro p hp
  have h : env8724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8689_8724 : H12AffineEnvironment.transform 20 65 env8689 = env8724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env8689 == env8724) = true)

theorem identity8724 : scanCanonicalize (H12AffineFastState.compose env8724 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 20903) := by decide +kernel

theorem selectedBound8724 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8725 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,24771,4605,20903,4960,8693,65,4194304,5005,34,8329,21040,4551,4214984,4215092,18632,504,4211101,4960,16616,21040,1021]

theorem envBound8725 : H12AffineFastState.Bounded env8725 := by
  intro p hp
  have h : env8725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8724_8725 : H12AffineEnvironment.transform 17 20903 env8724 = env8725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20903 env8724 == env8725) = true)

def env8726 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,232,8693,8235,4605,4431,4960,8693,65,4194304,5005,34,8329,4824,4551,4198432,4198876,2080,504,4194677,4960,0,4824,1021]

theorem envBound8726 : H12AffineFastState.Bounded env8726 := by
  intro p hp
  have h : env8726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8725_8726 : H12AffineEnvironment.transform 13 232 env8725 = env8726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 232 env8725 == env8726) = true)

theorem identity8726 : scanCanonicalize (H12AffineFastState.compose env8726 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(21+1) ^^^ 476) := by decide +kernel

theorem selectedBound8726 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8727 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,232,8693,8235,4605,4431,4960,8693,65,476,5005,34,8329,4824,4551,4604,4096,2080,504,169,4960,0,4824,1021]

theorem envBound8727 : H12AffineFastState.Bounded env8727 := by
  intro p hp
  have h : env8727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8726_8727 : H12AffineEnvironment.transform 21 476 env8726 = env8727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 476 env8726 == env8727) = true)

theorem identity8727 : scanCanonicalize (H12AffineFastState.compose env8727 (packedSelected [1,3,4,7,9,12,14,18,23,27,38] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound8727 : packedSelected [1,3,4,7,9,12,14,18,23,27,38] rootPS < 2^1333 := by decide +kernel

def env8728 : List Nat := [2,4,8,16,32,17,128,256,512,256,2048,4096,8192,185,8612,8235,4524,4382,4913,8612,16,397,5005,34,8329,4745,4502,4525,4096,2080,425,169,4913,0,4745,940]

theorem envBound8728 : H12AffineFastState.Bounded env8728 := by
  intro p hp
  have h : env8728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8727_8728 : H12AffineEnvironment.transform 5 17 env8727 = env8728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8727 == env8728) = true)

theorem identity8728 : scanCanonicalize (H12AffineFastState.compose env8728 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(10+1) ^^^ 935) := by decide +kernel

theorem selectedBound8728 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env8729 : List Nat := [2,4,8,16,32,17,128,256,512,256,935,4096,8192,185,8612,8235,4524,4382,4913,8612,16,397,5005,34,8329,4745,4502,4525,4096,903,425,169,4913,0,4745,940]

theorem envBound8729 : H12AffineFastState.Bounded env8729 := by
  intro p hp
  have h : env8729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8728_8729 : H12AffineEnvironment.transform 10 935 env8728 = env8729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 935 env8728 == env8729) = true)

theorem identity8729 : scanCanonicalize (H12AffineFastState.compose env8729 (packedSelected [0,1,3,4,7,9,12,13,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 821) := by decide +kernel

theorem selectedBound8729 : packedSelected [0,1,3,4,7,9,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env8730 : List Nat := [2,4,8,16,32,17,128,256,512,256,935,821,8192,185,8612,8235,665,555,4,8612,16,397,184,34,8329,444,675,664,821,903,425,169,4,0,444,940]

theorem envBound8730 : H12AffineFastState.Bounded env8730 := by
  intro p hp
  have h : env8730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8729_8730 : H12AffineEnvironment.transform 11 821 env8729 = env8730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 821 env8729 == env8730) = true)

theorem identity8730 : scanCanonicalize (H12AffineFastState.compose env8730 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound8730 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env8731 : List Nat := [2,4,8,16,32,17,128,36,512,36,643,529,8192,185,8320,8235,665,555,4,8320,16,169,184,34,8329,152,675,664,529,675,141,169,4,0,152,648]

theorem envBound8731 : H12AffineFastState.Bounded env8731 := by
  intro p hp
  have h : env8731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8730_8731 : H12AffineEnvironment.transform 7 36 env8730 = env8731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env8730 == env8731) = true)

theorem identity8731 : scanCanonicalize (H12AffineFastState.compose env8731 (packedSelected [3,4,8] rootPS)) = affineNative (2^(12+1) ^^^ 129) := by decide +kernel

theorem selectedBound8731 : packedSelected [3,4,8] rootPS < 2^1333 := by decide +kernel

def env8732 : List Nat := [2,4,8,16,32,17,128,36,512,36,643,529,129,185,1,170,665,555,4,1,16,169,184,34,8,152,675,664,529,675,141,169,4,0,152,648]

theorem envBound8732 : H12AffineFastState.Bounded env8732 := by
  intro p hp
  have h : env8732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8731_8732 : H12AffineEnvironment.transform 12 129 env8731 = env8732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env8731 == env8732) = true)

theorem identity8732 : scanCanonicalize (H12AffineFastState.compose env8732 (packedSelected [7,11] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound8732 : packedSelected [7,11] rootPS < 2^1333 := by decide +kernel

def env8733 : List Nat := [2,4,8,16,32,17,19,36,512,36,528,529,18,42,1,57,522,555,4,1,16,58,43,34,8,11,560,523,529,560,30,58,4,0,11,539]

theorem envBound8733 : H12AffineFastState.Bounded env8733 := by
  intro p hp
  have h : env8733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8732_8733 : H12AffineEnvironment.transform 6 19 env8732 = env8733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env8732 == env8733) = true)

theorem identity8733 : scanCanonicalize (H12AffineFastState.compose env8733 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound8733 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env8734 : List Nat := [2,4,8,16,32,17,19,36,48,36,32,33,18,42,1,57,58,27,4,1,16,58,43,34,8,11,0,59,33,0,30,58,4,0,11,43]

theorem envBound8734 : H12AffineFastState.Bounded env8734 := by
  intro p hp
  have h : env8734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8733_8734 : H12AffineEnvironment.transform 8 48 env8733 = env8734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env8733 == env8734) = true)

theorem identity8734 : scanCanonicalize (H12AffineFastState.compose env8734 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound8734 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env8735 : List Nat := [2,4,8,16,26,17,19,30,10,30,26,27,18,16,1,3,0,27,4,1,16,0,17,24,8,11,0,1,27,0,30,0,4,0,11,17]

theorem envBound8735 : H12AffineFastState.Bounded env8735 := by
  intro p hp
  have h : env8735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8734_8735 : H12AffineEnvironment.transform 4 26 env8734 = env8735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env8734 == env8735) = true)

theorem identity8735 : scanCanonicalize (H12AffineFastState.compose env8735 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8735 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8736 : List Nat := [2,4,3,16,17,17,19,21,1,21,17,16,18,16,1,3,0,16,4,1,16,0,17,19,3,0,0,1,16,0,21,0,4,0,0,17]

theorem envBound8736 : H12AffineFastState.Bounded env8736 := by
  intro p hp
  have h : env8736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8735_8736 : H12AffineEnvironment.transform 2 3 env8735 = env8736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8735 == env8736) = true)

def env8737 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,233,8693,8234,4605,4430,4960,8693,65,4194304,5005,34,8329,4825,4551,4198433,4198877,2081,504,4194676,4960,1,4825,1021]

theorem envBound8737 : H12AffineFastState.Bounded env8737 := by
  intro p hp
  have h : env8737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8725_8737 : H12AffineEnvironment.transform 13 233 env8725 = env8737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 233 env8725 == env8737) = true)

theorem identity8737 : scanCanonicalize (H12AffineFastState.compose env8737 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound8737 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8738 : List Nat := [2,4,8,16,32,64,128,85,512,85,2048,4096,8192,233,8352,8234,4264,4123,4661,8352,65,4194304,4824,34,8329,4825,4242,4198433,4198536,2081,173,4194337,4661,1,4825,680]

theorem envBound8738 : H12AffineFastState.Bounded env8738 := by
  intro p hp
  have h : env8738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8737_8738 : H12AffineEnvironment.transform 7 85 env8737 = env8738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env8737 == env8738) = true)

theorem identity8738 : scanCanonicalize (H12AffineFastState.compose env8738 (packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound8738 : packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env8739 : List Nat := [2,4,8,16,32,64,128,85,512,85,675,4096,8192,233,8352,8234,4264,4123,4661,8352,65,4194304,4824,34,8329,4825,4242,4198433,4198536,642,173,4194337,4661,1,4825,680]

theorem envBound8739 : H12AffineFastState.Bounded env8739 := by
  intro p hp
  have h : env8739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8738_8739 : H12AffineEnvironment.transform 10 675 env8738 = env8739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env8738 == env8739) = true)

theorem identity8739 : scanCanonicalize (H12AffineFastState.compose env8739 (packedSelected [1,3,4,7,9,12,14,15,27] rootPS)) = affineNative (2^(21+1) ^^^ 112) := by decide +kernel

theorem selectedBound8739 : packedSelected [1,3,4,7,9,12,14,15,27] rootPS < 2^1333 := by decide +kernel

def env8740 : List Nat := [2,4,8,16,32,64,128,85,512,85,675,4096,8192,233,8352,8234,4264,4123,4661,8352,65,112,4824,34,8329,4825,4242,4177,4344,642,173,81,4661,1,4825,680]

theorem envBound8740 : H12AffineFastState.Bounded env8740 := by
  intro p hp
  have h : env8740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8739_8740 : H12AffineEnvironment.transform 21 112 env8739 = env8740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 112 env8739 == env8740) = true)

theorem identity8740 : scanCanonicalize (H12AffineFastState.compose env8740 (packedSelected [3,10,19,24] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound8740 : packedSelected [3,10,19,24] rootPS < 2^1333 := by decide +kernel

def env8741 : List Nat := [2,4,8,16,32,64,40,85,512,85,523,4096,8192,65,8200,8234,4096,4123,4661,8200,65,112,4720,34,8225,4721,4154,4177,4176,554,5,81,4661,1,4721,512]

theorem envBound8741 : H12AffineFastState.Bounded env8741 := by
  intro p hp
  have h : env8741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8740_8741 : H12AffineEnvironment.transform 6 40 env8740 = env8741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env8740 == env8741) = true)

theorem identity8741 : scanCanonicalize (H12AffineFastState.compose env8741 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 523) := by decide +kernel

theorem selectedBound8741 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env8742 : List Nat := [2,4,8,16,32,64,40,85,512,85,523,523,8192,65,8200,8234,523,528,62,8200,65,112,123,34,8225,122,561,602,603,554,5,81,62,1,122,512]

theorem envBound8742 : H12AffineFastState.Bounded env8742 := by
  intro p hp
  have h : env8742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8741_8742 : H12AffineEnvironment.transform 11 523 env8741 = env8742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 523 env8741 == env8742) = true)

theorem identity8742 : scanCanonicalize (H12AffineFastState.compose env8742 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound8742 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env8743 : List Nat := [2,4,8,16,32,64,40,85,26,85,17,17,8192,65,8200,8234,17,10,62,8200,65,112,123,34,8225,122,43,64,65,48,5,81,62,1,122,26]

theorem envBound8743 : H12AffineFastState.Bounded env8743 := by
  intro p hp
  have h : env8743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8742_8743 : H12AffineEnvironment.transform 8 26 env8742 = env8743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env8742 == env8743) = true)

theorem identity8743 : scanCanonicalize (H12AffineFastState.compose env8743 (packedSelected [0,4,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound8743 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env8744 : List Nat := [2,4,8,16,32,17,40,4,26,4,17,17,8192,16,8200,8234,17,10,62,8200,16,33,42,34,8225,43,43,17,16,48,5,0,62,1,43,26]

theorem envBound8744 : H12AffineFastState.Bounded env8744 := by
  intro p hp
  have h : env8744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8743_8744 : H12AffineEnvironment.transform 5 17 env8743 = env8744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8743 == env8744) = true)

theorem identity8744 : scanCanonicalize (H12AffineFastState.compose env8744 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound8744 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8745 : List Nat := [2,4,8,16,17,17,25,4,26,4,17,17,8192,16,8200,8219,17,10,15,8200,16,16,27,19,8208,26,26,17,16,1,5,0,15,1,26,26]

theorem envBound8745 : H12AffineFastState.Bounded env8745 := by
  intro p hp
  have h : env8745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8744_8745 : H12AffineEnvironment.transform 4 17 env8744 = env8745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env8744 == env8745) = true)

theorem identity8745 : scanCanonicalize (H12AffineFastState.compose env8745 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8745 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8746 : List Nat := [2,4,2,16,17,17,19,4,16,4,17,17,8192,16,8194,8209,17,0,5,8194,16,16,17,19,8208,16,16,17,16,1,5,0,5,1,16,16]

theorem envBound8746 : H12AffineFastState.Bounded env8746 := by
  intro p hp
  have h : env8746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8745_8746 : H12AffineEnvironment.transform 2 2 env8745 = env8746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8745 == env8746) = true)

theorem identity8746 : scanCanonicalize (H12AffineFastState.compose env8746 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 3) := by decide +kernel

theorem selectedBound8746 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8747 : List Nat := [2,4,2,16,17,17,19,4,16,4,17,17,3,16,1,18,17,0,5,1,16,16,17,19,19,16,16,17,16,1,5,0,5,1,16,16]

theorem envBound8747 : H12AffineFastState.Bounded env8747 := by
  intro p hp
  have h : env8747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8746_8747 : H12AffineEnvironment.transform 12 3 env8746 = env8747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3 env8746 == env8747) = true)

theorem identity8747 : scanCanonicalize (H12AffineFastState.compose env8747 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8747 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8748 : List Nat := [2,4,2,1,0,0,2,4,1,4,0,0,3,1,1,3,0,0,5,1,1,1,0,2,2,1,1,0,1,1,5,0,5,1,1,1]

theorem envBound8748 : H12AffineFastState.Bounded env8748 := by
  intro p hp
  have h : env8748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8747_8748 : H12AffineEnvironment.transform 3 1 env8747 = env8748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8747 == env8748) = true)

def env8749 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,262144,4961,8693,2097152,4194304,5004,90337,8329,21040,278625,4214985,4215093,75786,505,4268383,4961,73770,2175667,90942]

theorem envBound8749 : H12AffineFastState.Bounded env8749 := by
  intro p hp
  have h : env8749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8687_8749 : H12AffineEnvironment.transform 18 4961 env8687 = env8749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4961 env8687 == env8749) = true)

theorem identity8749 : scanCanonicalize (H12AffineFastState.compose env8749 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound8749 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8750 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8200,65536,4096,262144,4764,8200,2097152,4194304,4721,90337,8329,21040,278625,4214985,4214984,75786,4,4268194,4764,73770,2175667,90819]

theorem envBound8750 : H12AffineFastState.Bounded env8750 := by
  intro p hp
  have h : env8750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8749_8750 : H12AffineEnvironment.transform 7 253 env8749 = env8750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env8749 == env8750) = true)

def env8751 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8200,65536,4096,262144,4764,8200,64,4194304,4721,90337,8329,21040,278625,4214985,4214984,75786,4,4268194,4764,73770,78579,90819]

theorem envBound8751 : H12AffineFastState.Bounded env8751 := by
  intro p hp
  have h : env8751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8750_8751 : H12AffineEnvironment.transform 20 64 env8750 = env8751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env8750 == env8751) = true)

theorem identity8751 : scanCanonicalize (H12AffineFastState.compose env8751 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 336520) := by decide +kernel

theorem selectedBound8751 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8752 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8200,65536,4096,262144,4764,8200,64,336520,4721,90337,8329,21040,278625,356929,356928,75786,4,262698,4764,73770,78579,90819]

theorem envBound8752 : H12AffineFastState.Bounded env8752 := by
  intro p hp
  have h : env8752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8751_8752 : H12AffineEnvironment.transform 21 336520 env8751 = env8752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 336520 env8751 == env8752) = true)

def env8753 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,4096,8192,16384,8200,65536,4096,262144,4644,8200,64,336432,4721,90201,8241,21040,278625,356929,356928,75786,4,262698,4644,73770,78411,90747]

theorem envBound8753 : H12AffineFastState.Bounded env8753 := by
  intro p hp
  have h : env8753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8752_8753 : H12AffineEnvironment.transform 6 56 env8752 = env8753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env8752 == env8753) = true)

theorem identity8753 : scanCanonicalize (H12AffineFastState.compose env8753 (packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS)) = affineNative (2^(15+1) ^^^ 8730) := by decide +kernel

theorem selectedBound8753 : packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS < 2^1333 := by decide +kernel

def env8754 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,4096,8192,16384,8200,8730,4096,262144,4644,8200,64,262186,4721,16963,8241,21040,278625,282715,282714,2576,4,262698,4644,560,4177,16481]

theorem envBound8754 : H12AffineFastState.Bounded env8754 := by
  intro p hp
  have h : env8754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8753_8754 : H12AffineEnvironment.transform 15 8730 env8753 = env8754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8730 env8753 == env8754) = true)

theorem identity8754 : scanCanonicalize (H12AffineFastState.compose env8754 (packedSelected [1,8,13,19,21] rootPS)) = affineNative (2^(17+1) ^^^ 26) := by decide +kernel

theorem selectedBound8754 : packedSelected [1,8,13,19,21] rootPS < 2^1333 := by decide +kernel

def env8755 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,4096,8192,16384,8200,8730,4096,26,4644,8200,64,48,4721,16963,8241,21040,16507,20545,20544,2576,4,560,4644,560,4177,16481]

theorem envBound8755 : H12AffineFastState.Bounded env8755 := by
  intro p hp
  have h : env8755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8754_8755 : H12AffineEnvironment.transform 17 26 env8754 = env8755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 26 env8754 == env8755) = true)

theorem identity8755 : scanCanonicalize (H12AffineFastState.compose env8755 (packedSelected [1,2,8,11,13,14,17,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound8755 : packedSelected [1,2,8,11,13,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env8756 : List Nat := [2,4,8,16,32,64,56,69,97,69,2048,4096,8192,16384,8200,8315,4096,26,4165,8200,64,48,4112,16418,8241,20561,16507,20545,20544,2161,4,81,4165,81,4177,16481]

theorem envBound8756 : H12AffineFastState.Bounded env8756 := by
  intro p hp
  have h : env8756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8755_8756 : H12AffineEnvironment.transform 8 97 env8755 = env8756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env8755 == env8756) = true)

theorem identity8756 : scanCanonicalize (H12AffineFastState.compose env8756 (packedSelected [13,17] rootPS)) = affineNative (2^(13+1) ^^^ 6250) := by decide +kernel

theorem selectedBound8756 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8757 : List Nat := [2,4,8,16,32,64,56,69,97,69,2048,4096,8192,6250,8200,8315,4096,26,4165,8200,64,48,4112,6216,8241,2107,6161,2091,2090,2161,4,81,4165,81,4177,6155]

theorem envBound8757 : H12AffineFastState.Bounded env8757 := by
  intro p hp
  have h : env8757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8756_8757 : H12AffineEnvironment.transform 13 6250 env8756 = env8757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6250 env8756 == env8757) = true)

theorem identity8757 : scanCanonicalize (H12AffineFastState.compose env8757 (packedSelected [0,1,2,3,4,7,9,11,14,18,24,28] rootPS)) = affineNative (2^(11+1) ^^^ 2155) := by decide +kernel

theorem selectedBound8757 : packedSelected [0,1,2,3,4,7,9,11,14,18,24,28] rootPS < 2^1333 := by decide +kernel

def env8758 : List Nat := [2,4,8,16,32,64,56,69,97,69,2048,2155,8192,1,8200,8315,2155,26,2094,8200,64,48,2171,35,8241,2107,122,2091,2090,2161,4,81,2094,81,2106,96]

theorem envBound8758 : H12AffineFastState.Bounded env8758 := by
  intro p hp
  have h : env8758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8757_8758 : H12AffineEnvironment.transform 11 2155 env8757 = env8758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2155 env8757 == env8758) = true)

def env8759 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,4096,8192,16384,8200,65536,4096,262144,4645,8200,64,336433,4721,90200,8240,21040,278625,356929,356928,75786,4,262698,4645,73770,78410,90746]

theorem envBound8759 : H12AffineFastState.Bounded env8759 := by
  intro p hp
  have h : env8759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8752_8759 : H12AffineEnvironment.transform 6 57 env8752 = env8759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env8752 == env8759) = true)

theorem identity8759 : scanCanonicalize (H12AffineFastState.compose env8759 (packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS)) = affineNative (2^(17+1) ^^^ 90208) := by decide +kernel

theorem selectedBound8759 : packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS < 2^1333 := by decide +kernel

def env8760 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,4096,8192,16384,8200,65536,4096,90208,4645,8200,64,16977,4721,90200,8240,21040,73729,4641,4640,75786,4,90698,4645,73770,78410,90746]

theorem envBound8760 : H12AffineFastState.Bounded env8760 := by
  intro p hp
  have h : env8760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8759_8760 : H12AffineEnvironment.transform 17 90208 env8759 = env8760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 90208 env8759 == env8760) = true)

theorem identity8760 : scanCanonicalize (H12AffineFastState.compose env8760 (packedSelected [0,1,7,8,13,19,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 8730) := by decide +kernel

theorem selectedBound8760 : packedSelected [0,1,7,8,13,19,20,21] rootPS < 2^1333 := by decide +kernel

def env8761 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,4096,8192,16384,8200,8730,4096,17018,4645,8200,64,16977,4721,16962,8240,21040,539,4641,4640,2576,4,16464,4645,560,4176,16480]

theorem envBound8761 : H12AffineFastState.Bounded env8761 := by
  intro p hp
  have h : env8761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8760_8761 : H12AffineEnvironment.transform 15 8730 env8760 = env8761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8730 env8760 == env8761) = true)

theorem identity8761 : scanCanonicalize (H12AffineFastState.compose env8761 (packedSelected [1,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 624) := by decide +kernel

theorem selectedBound8761 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env8762 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,4096,8192,624,8200,8730,4096,10,4645,8200,64,33,4721,50,8240,4160,539,4641,4640,2576,4,544,4645,560,4176,528]

theorem envBound8762 : H12AffineFastState.Bounded env8762 := by
  intro p hp
  have h : env8762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8761_8762 : H12AffineEnvironment.transform 13 624 env8761 = env8762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 624 env8761 == env8762) = true)

theorem identity8762 : scanCanonicalize (H12AffineFastState.compose env8762 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 587) := by decide +kernel

theorem selectedBound8762 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env8763 : List Nat := [2,4,8,16,32,64,57,68,512,68,587,4096,8192,624,8200,8730,4096,10,4645,8200,64,33,4721,50,8240,4160,539,4641,4640,91,4,544,4645,560,4176,528]

theorem envBound8763 : H12AffineFastState.Bounded env8763 := by
  intro p hp
  have h : env8763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8762_8763 : H12AffineEnvironment.transform 10 587 env8762 = env8763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 587 env8762 == env8763) = true)

theorem identity8763 : scanCanonicalize (H12AffineFastState.compose env8763 (packedSelected [0,7,20] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8763 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env8764 : List Nat := [2,4,8,0,32,64,41,68,512,68,587,4096,8192,608,8200,8714,4096,10,4645,8200,64,33,4705,34,8224,4160,523,4641,4640,75,4,544,4645,544,4160,512]

theorem envBound8764 : H12AffineFastState.Bounded env8764 := by
  intro p hp
  have h : env8764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8763_8764 : H12AffineEnvironment.transform 3 0 env8763 = env8764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8763 == env8764) = true)

theorem identity8764 : scanCanonicalize (H12AffineFastState.compose env8764 (packedSelected [3,4,5,7,8,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 4680) := by decide +kernel

theorem selectedBound8764 : packedSelected [3,4,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env8765 : List Nat := [2,4,8,0,32,64,41,68,512,68,587,4096,4680,608,4672,4162,4096,10,4645,4672,64,33,4705,34,4712,4160,523,4641,4640,75,4,544,4645,544,4160,512]

theorem envBound8765 : H12AffineFastState.Bounded env8765 := by
  intro p hp
  have h : env8765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8764_8765 : H12AffineEnvironment.transform 12 4680 env8764 = env8765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4680 env8764 == env8765) = true)

theorem identity8765 : scanCanonicalize (H12AffineFastState.compose env8765 (packedSelected [0,2,3,5,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound8765 : packedSelected [0,2,3,5,8,9] rootPS < 2^1333 := by decide +kernel

def env8766 : List Nat := [2,4,8,0,32,64,41,68,96,68,43,4096,4136,0,4128,4162,4096,10,4165,4128,64,33,4097,34,4104,4160,107,4161,4160,75,4,64,4165,64,4160,96]

theorem envBound8766 : H12AffineFastState.Bounded env8766 := by
  intro p hp
  have h : env8766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8765_8766 : H12AffineEnvironment.transform 8 96 env8765 = env8766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env8765 == env8766) = true)

theorem identity8766 : scanCanonicalize (H12AffineFastState.compose env8766 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound8766 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env8767 : List Nat := [2,4,8,0,32,33,41,37,1,37,43,4096,4136,0,4128,4131,4096,10,4132,4128,33,33,4097,34,4104,4129,10,4128,4129,42,4,33,4132,33,4129,1]

theorem envBound8767 : H12AffineFastState.Bounded env8767 := by
  intro p hp
  have h : env8767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8766_8767 : H12AffineEnvironment.transform 5 33 env8766 = env8767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env8766 == env8767) = true)

theorem identity8767 : scanCanonicalize (H12AffineFastState.compose env8767 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8767 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8768 : List Nat := [2,4,8,0,1,0,8,4,1,4,10,4096,4105,0,4097,4098,4096,10,4101,4097,0,0,4097,3,4104,4096,10,4097,4096,11,4,0,4101,0,4096,1]

theorem envBound8768 : H12AffineFastState.Bounded env8768 := by
  intro p hp
  have h : env8768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8767_8768 : H12AffineEnvironment.transform 4 1 env8767 = env8768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8767 == env8768) = true)

theorem identity8768 : scanCanonicalize (H12AffineFastState.compose env8768 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8768 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8769 : List Nat := [2,4,3,0,1,0,3,4,1,4,1,4096,4098,0,4097,4098,4096,1,4101,4097,0,0,4097,3,4099,4096,1,4097,4096,0,4,0,4101,0,4096,1]

theorem envBound8769 : H12AffineFastState.Bounded env8769 := by
  intro p hp
  have h : env8769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8768_8769 : H12AffineEnvironment.transform 2 3 env8768 = env8769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8768 == env8769) = true)

def env8770 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8200,65536,4096,262144,4764,8200,65,4194304,4721,90337,8329,21040,278625,4214985,4214984,75786,4,4268194,4764,73770,78578,90819]

theorem envBound8770 : H12AffineFastState.Bounded env8770 := by
  intro p hp
  have h : env8770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8750_8770 : H12AffineEnvironment.transform 20 65 env8750 = env8770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env8750 == env8770) = true)

theorem identity8770 : scanCanonicalize (H12AffineFastState.compose env8770 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 340201) := by decide +kernel

theorem selectedBound8770 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8771 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8200,65536,4096,262144,4764,8200,65,340201,4721,90337,8329,21040,278625,352288,352289,75786,4,266315,4764,73770,78578,90819]

theorem envBound8771 : H12AffineFastState.Bounded env8771 := by
  intro p hp
  have h : env8771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8770_8771 : H12AffineEnvironment.transform 21 340201 env8770 = env8771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 340201 env8770 == env8771) = true)

def env8772 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8200,65536,4096,94888,4764,8200,65,16961,4721,90337,8329,21040,78537,4744,4745,75786,4,90851,4764,73770,78578,90819]

theorem envBound8772 : H12AffineFastState.Bounded env8772 := by
  intro p hp
  have h : env8772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8771_8772 : H12AffineEnvironment.transform 17 94888 env8771 = env8772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 94888 env8771 == env8772) = true)

def env8773 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,560,8200,65536,4096,77976,4764,8200,65,113,4721,74449,8329,4096,78537,4744,4745,75786,4,73939,4764,73770,78578,73971]

theorem envBound8773 : H12AffineFastState.Bounded env8773 := by
  intro p hp
  have h : env8773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8772_8773 : H12AffineEnvironment.transform 13 560 env8772 = env8773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env8772 == env8773) = true)

theorem identity8773 : scanCanonicalize (H12AffineFastState.compose env8773 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 12875) := by decide +kernel

theorem selectedBound8773 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8774 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,560,8200,12875,4096,723,4764,8200,65,113,4721,4250,8329,4096,130,4744,4745,6721,4,4760,4764,4705,185,4792]

theorem envBound8774 : H12AffineFastState.Bounded env8774 := by
  intro p hp
  have h : env8774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8773_8774 : H12AffineEnvironment.transform 15 12875 env8773 = env8774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12875 env8773 == env8774) = true)

theorem identity8774 : scanCanonicalize (H12AffineFastState.compose env8774 (packedSelected [1,3,5,8,10,13,14,17,19] rootPS)) = affineNative (2^(11+1) ^^^ 2194) := by decide +kernel

theorem selectedBound8774 : packedSelected [1,3,5,8,10,13,14,17,19] rootPS < 2^1333 := by decide +kernel

def env8775 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,2194,8192,560,8200,10969,2194,723,2574,8200,65,113,2787,2056,8329,2194,130,2586,2587,723,4,2570,2574,2803,185,2602]

theorem envBound8775 : H12AffineFastState.Bounded env8775 := by
  intro p hp
  have h : env8775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8774_8775 : H12AffineEnvironment.transform 11 2194 env8774 = env8775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2194 env8774 == env8775) = true)

theorem identity8775 : scanCanonicalize (H12AffineFastState.compose env8775 (packedSelected [0,1,3,4,7,9,12,14,15,17,21] rootPS)) = affineNative (2^(8+1) ^^^ 113) := by decide +kernel

theorem selectedBound8775 : packedSelected [0,1,3,4,7,9,12,14,15,17,21] rootPS < 2^1333 := by decide +kernel

def env8776 : List Nat := [2,4,8,16,32,64,128,253,113,253,2048,2194,8192,65,8200,10408,2194,162,2175,8200,65,113,2194,2056,8329,2194,130,2155,2154,162,4,2171,2175,2178,185,2139]

theorem envBound8776 : H12AffineFastState.Bounded env8776 := by
  intro p hp
  have h : env8776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8775_8776 : H12AffineEnvironment.transform 8 113 env8775 = env8776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 113 env8775 == env8776) = true)

theorem identity8776 : scanCanonicalize (H12AffineFastState.compose env8776 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound8776 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env8777 : List Nat := [2,4,8,16,32,16,128,173,33,173,2048,2194,8192,17,8200,10408,2194,162,2095,8200,17,33,2194,2056,8329,2194,130,2107,2106,162,4,2091,2095,2178,185,2059]

theorem envBound8777 : H12AffineFastState.Bounded env8777 := by
  intro p hp
  have h : env8777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8776_8777 : H12AffineEnvironment.transform 5 16 env8776 = env8777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8776 == env8777) = true)

theorem identity8777 : scanCanonicalize (H12AffineFastState.compose env8777 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 153) := by decide +kernel

theorem selectedBound8777 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env8778 : List Nat := [2,4,8,16,32,16,128,173,33,173,153,11,8192,17,8200,8241,11,162,182,8200,17,33,11,145,8329,11,130,162,163,162,4,178,182,27,185,146]

theorem envBound8778 : H12AffineFastState.Bounded env8778 := by
  intro p hp
  have h : env8778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8777_8778 : H12AffineEnvironment.transform 10 153 env8777 = env8778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 153 env8777 == env8778) = true)

theorem identity8778 : scanCanonicalize (H12AffineFastState.compose env8778 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound8778 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env8779 : List Nat := [2,4,8,16,32,16,24,53,33,53,1,11,8192,17,8200,8241,11,58,46,8200,17,33,11,9,8209,11,26,58,59,58,4,42,46,27,33,10]

theorem envBound8779 : H12AffineFastState.Bounded env8779 := by
  intro p hp
  have h : env8779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8778_8779 : H12AffineEnvironment.transform 6 24 env8778 = env8779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env8778 == env8779) = true)

theorem identity8779 : scanCanonicalize (H12AffineFastState.compose env8779 (packedSelected [2,3,8] rootPS)) = affineNative (2^(12+1) ^^^ 51) := by decide +kernel

theorem selectedBound8779 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env8780 : List Nat := [2,4,8,16,32,16,24,53,33,53,1,11,51,17,59,2,11,58,46,59,17,33,11,9,34,11,26,58,59,58,4,42,46,27,33,10]

theorem envBound8780 : H12AffineFastState.Bounded env8780 := by
  intro p hp
  have h : env8780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8779_8780 : H12AffineEnvironment.transform 12 51 env8779 = env8780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 51 env8779 == env8780) = true)

theorem identity8780 : scanCanonicalize (H12AffineFastState.compose env8780 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound8780 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env8781 : List Nat := [2,4,8,16,27,16,24,14,26,14,1,11,8,17,0,2,11,1,21,0,17,26,11,9,25,11,26,1,0,1,4,17,21,27,26,10]

theorem envBound8781 : H12AffineFastState.Bounded env8781 := by
  intro p hp
  have h : env8781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8780_8781 : H12AffineEnvironment.transform 4 27 env8780 = env8781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env8780 == env8781) = true)

theorem identity8781 : scanCanonicalize (H12AffineFastState.compose env8781 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8781 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8782 : List Nat := [2,4,8,0,11,0,8,14,10,14,1,11,8,1,0,2,11,1,5,0,1,10,11,9,9,11,10,1,0,1,4,1,5,11,10,10]

theorem envBound8782 : H12AffineFastState.Bounded env8782 := by
  intro p hp
  have h : env8782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8781_8782 : H12AffineEnvironment.transform 3 0 env8781 = env8782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8781 == env8782) = true)

theorem identity8782 : scanCanonicalize (H12AffineFastState.compose env8782 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8782 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8783 : List Nat := [2,4,2,0,1,0,2,4,0,4,1,1,2,1,0,2,1,1,5,0,1,0,1,3,3,1,0,1,0,1,4,1,5,1,0,0]

theorem envBound8783 : H12AffineFastState.Bounded env8783 := by
  intro p hp
  have h : env8783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8782_8783 : H12AffineEnvironment.transform 2 2 env8782 = env8783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8782 == env8783) = true)

def env8784 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,561,8200,65536,4096,77977,4764,8200,65,112,4721,74448,8329,4097,78537,4744,4745,75786,4,73938,4764,73770,78578,73970]

theorem envBound8784 : H12AffineFastState.Bounded env8784 := by
  intro p hp
  have h : env8784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8772_8784 : H12AffineEnvironment.transform 13 561 env8772 = env8784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env8772 == env8784) = true)

theorem identity8784 : scanCanonicalize (H12AffineFastState.compose env8784 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 12978) := by decide +kernel

theorem selectedBound8784 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8785 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,561,8200,12978,4096,555,4764,8200,65,112,4721,4194,8329,4097,123,4744,4745,6840,4,4704,4764,4760,64,4672]

theorem envBound8785 : H12AffineFastState.Bounded env8785 := by
  intro p hp
  have h : env8785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8784_8785 : H12AffineEnvironment.transform 15 12978 env8784 = env8785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12978 env8784 == env8785) = true)

theorem identity8785 : scanCanonicalize (H12AffineFastState.compose env8785 (packedSelected [14] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound8785 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env8786 : List Nat := [2,4,8,16,32,64,128,253,33,253,2048,4096,8192,16,8200,12435,4096,10,4285,8200,65,112,4176,4194,8329,4097,123,4265,4264,6297,4,4161,4285,4281,64,4193]

theorem envBound8786 : H12AffineFastState.Bounded env8786 := by
  intro p hp
  have h : env8786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8785_8786 : H12AffineEnvironment.transform 8 33 env8785 = env8786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env8785 == env8786) = true)

theorem identity8786 : scanCanonicalize (H12AffineFastState.compose env8786 (packedSelected [5,8,10,12,15,19] rootPS)) = affineNative (2^(10+1) ^^^ 210) := by decide +kernel

theorem selectedBound8786 : packedSelected [5,8,10,12,15,19] rootPS < 2^1333 := by decide +kernel

def env8787 : List Nat := [2,4,8,16,32,64,128,253,33,253,210,4096,8192,16,8200,12435,4096,10,4285,8200,65,112,4176,4194,8329,4097,123,4265,4264,4171,4,4161,4285,4281,64,4193]

theorem envBound8787 : H12AffineFastState.Bounded env8787 := by
  intro p hp
  have h : env8787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8786_8787 : H12AffineEnvironment.transform 10 210 env8786 = env8787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 210 env8786 == env8787) = true)

theorem identity8787 : scanCanonicalize (H12AffineFastState.compose env8787 (packedSelected [0,1,3,7,12,13,15,17,20] rootPS)) = affineNative (2^(11+1) ^^^ 233) := by decide +kernel

theorem selectedBound8787 : packedSelected [0,1,3,7,12,13,15,17,20] rootPS < 2^1333 := by decide +kernel

def env8788 : List Nat := [2,4,8,16,32,64,128,253,33,253,210,233,8192,16,8200,8314,233,10,84,8200,65,112,185,139,8329,232,123,64,65,162,4,168,84,80,64,136]

theorem envBound8788 : H12AffineFastState.Bounded env8788 := by
  intro p hp
  have h : env8788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8787_8788 : H12AffineEnvironment.transform 11 233 env8787 = env8788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 233 env8787 == env8788) = true)

theorem identity8788 : scanCanonicalize (H12AffineFastState.compose env8788 (packedSelected [0,1,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 114) := by decide +kernel

theorem selectedBound8788 : packedSelected [0,1,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env8789 : List Nat := [2,4,8,16,32,64,128,253,33,253,210,233,114,16,122,8,233,10,84,122,65,112,185,139,251,232,123,64,65,162,4,168,84,80,64,136]

theorem envBound8789 : H12AffineFastState.Bounded env8789 := by
  intro p hp
  have h : env8789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8788_8789 : H12AffineEnvironment.transform 12 114 env8788 = env8789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 114 env8788 == env8789) = true)

theorem identity8789 : scanCanonicalize (H12AffineFastState.compose env8789 (packedSelected [1,2,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8789 : packedSelected [1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env8790 : List Nat := [2,4,8,1,32,64,128,236,33,236,195,233,99,1,107,8,233,10,69,107,65,97,168,139,234,232,106,64,65,162,4,168,69,65,64,136]

theorem envBound8790 : H12AffineFastState.Bounded env8790 := by
  intro p hp
  have h : env8790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8789_8790 : H12AffineEnvironment.transform 3 1 env8789 = env8790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8789 == env8790) = true)

theorem identity8790 : scanCanonicalize (H12AffineFastState.compose env8790 (packedSelected [2,7] rootPS)) = affineNative (2^(6+1) ^^^ 99) := by decide +kernel

theorem selectedBound8790 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env8791 : List Nat := [2,4,8,1,32,64,99,15,33,15,32,10,99,1,107,8,10,10,69,107,65,97,75,104,9,11,106,64,65,65,4,75,69,65,64,107]

theorem envBound8791 : H12AffineFastState.Bounded env8791 := by
  intro p hp
  have h : env8791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8790_8791 : H12AffineEnvironment.transform 6 99 env8790 = env8791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 99 env8790 == env8791) = true)

theorem identity8791 : scanCanonicalize (H12AffineFastState.compose env8791 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound8791 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env8792 : List Nat := [2,4,8,1,32,42,9,15,33,15,32,10,9,1,1,8,10,10,47,1,43,11,33,2,9,11,0,42,43,43,4,33,47,43,42,1]

theorem envBound8792 : H12AffineFastState.Bounded env8792 := by
  intro p hp
  have h : env8792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8791_8792 : H12AffineEnvironment.transform 5 42 env8791 = env8792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env8791 == env8792) = true)

theorem identity8792 : scanCanonicalize (H12AffineFastState.compose env8792 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8792 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8793 : List Nat := [2,4,8,1,1,11,9,15,0,15,1,10,9,1,1,8,10,10,14,1,10,11,0,2,9,11,0,11,10,10,4,0,14,10,11,1]

theorem envBound8793 : H12AffineFastState.Bounded env8793 := by
  intro p hp
  have h : env8793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8792_8793 : H12AffineEnvironment.transform 4 1 env8792 = env8793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8792 == env8793) = true)

theorem identity8793 : scanCanonicalize (H12AffineFastState.compose env8793 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound8793 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8794 : List Nat := [2,4,7,1,1,4,6,0,0,0,1,5,6,1,1,7,5,5,1,1,5,4,0,2,6,4,0,4,5,5,4,0,1,5,4,1]

theorem envBound8794 : H12AffineFastState.Bounded env8794 := by
  intro p hp
  have h : env8794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8793_8794 : H12AffineEnvironment.transform 2 7 env8793 = env8794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env8793 == env8794) = true)

theorem identity8794 : scanCanonicalize (H12AffineFastState.compose env8794 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound8794 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8795 : List Nat := [2,0,3,1,1,0,2,0,0,0,1,1,2,1,1,3,1,1,1,1,1,0,0,2,2,0,0,0,1,1,0,0,1,1,0,1]

theorem envBound8795 : H12AffineFastState.Bounded env8795 := by
  intro p hp
  have h : env8795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8794_8795 : H12AffineEnvironment.transform 1 0 env8794 = env8795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env8794 == env8795) = true)

def env8796 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8200,65536,4096,94889,4764,8200,65,16960,4721,90337,8329,21040,78536,4745,4744,75786,4,90850,4764,73770,78578,90819]

theorem envBound8796 : H12AffineFastState.Bounded env8796 := by
  intro p hp
  have h : env8796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8771_8796 : H12AffineEnvironment.transform 17 94889 env8771 = env8796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 94889 env8771 == env8796) = true)

def env8797 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,560,8200,65536,4096,77977,4764,8200,65,112,4721,74449,8329,4096,78536,4745,4744,75786,4,73938,4764,73770,78578,73971]

theorem envBound8797 : H12AffineFastState.Bounded env8797 := by
  intro p hp
  have h : env8797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8796_8797 : H12AffineEnvironment.transform 13 560 env8796 = env8797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env8796 == env8797) = true)

theorem identity8797 : scanCanonicalize (H12AffineFastState.compose env8797 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound8797 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8798 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,185,8192,560,8200,65536,185,73760,549,8200,65,112,712,74449,8329,185,74353,560,561,75786,4,73938,549,73770,74315,73971]

theorem envBound8798 : H12AffineFastState.Bounded env8798 := by
  intro p hp
  have h : env8798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8797_8798 : H12AffineEnvironment.transform 11 185 env8797 = env8798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env8797 == env8798) = true)

theorem identity8798 : scanCanonicalize (H12AffineFastState.compose env8798 (packedSelected [13,14,21] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound8798 : packedSelected [13,14,21] rootPS < 2^1333 := by decide +kernel

def env8799 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,185,8192,560,8200,8323,185,163,549,8200,65,112,712,594,8329,185,754,560,561,2185,4,81,549,169,712,112]

theorem envBound8799 : H12AffineFastState.Bounded env8799 := by
  intro p hp
  have h : env8799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8798_8799 : H12AffineEnvironment.transform 15 8323 env8798 = env8799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env8798 == env8799) = true)

theorem identity8799 : scanCanonicalize (H12AffineFastState.compose env8799 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound8799 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env8800 : List Nat := [2,4,8,16,32,64,128,253,512,253,523,185,8192,560,8200,8323,185,163,549,8200,65,112,712,594,8329,185,754,560,561,642,4,81,549,169,712,112]

theorem envBound8800 : H12AffineFastState.Bounded env8800 := by
  intro p hp
  have h : env8800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8799_8800 : H12AffineEnvironment.transform 10 523 env8799 = env8800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env8799 == env8800) = true)

theorem identity8800 : scanCanonicalize (H12AffineFastState.compose env8800 (packedSelected [4,5,8,9,11,12,13,18] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound8800 : packedSelected [4,5,8,9,11,12,13,18] rootPS < 2^1333 := by decide +kernel

def env8801 : List Nat := [2,4,8,16,11,64,128,214,512,214,523,146,8192,539,8200,8323,146,136,526,8200,65,91,712,594,8329,146,729,539,538,642,4,81,526,130,712,91]

theorem envBound8801 : H12AffineFastState.Bounded env8801 := by
  intro p hp
  have h : env8801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8800_8801 : H12AffineEnvironment.transform 4 11 env8800 = env8801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env8800 == env8801) = true)

theorem identity8801 : scanCanonicalize (H12AffineFastState.compose env8801 (packedSelected [2,3,4,7,8,11,13,14] rootPS)) = affineNative (2^(12+1) ^^^ 145) := by decide +kernel

theorem selectedBound8801 : packedSelected [2,3,4,7,8,11,13,14] rootPS < 2^1333 := by decide +kernel

def env8802 : List Nat := [2,4,8,16,11,64,128,214,512,214,523,146,145,539,153,18,146,136,526,153,65,91,712,594,24,146,729,539,538,642,4,81,526,130,712,91]

theorem envBound8802 : H12AffineFastState.Bounded env8802 := by
  intro p hp
  have h : env8802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8801_8802 : H12AffineEnvironment.transform 12 145 env8801 = env8802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 145 env8801 == env8802) = true)

theorem identity8802 : scanCanonicalize (H12AffineFastState.compose env8802 (packedSelected [1,4,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound8802 : packedSelected [1,4,7,8] rootPS < 2^1333 := by decide +kernel

def env8803 : List Nat := [2,4,8,16,11,64,128,214,0,214,11,146,145,27,153,18,146,136,14,153,65,91,200,82,24,146,217,27,26,130,4,81,14,130,200,91]

theorem envBound8803 : H12AffineFastState.Bounded env8803 := by
  intro p hp
  have h : env8803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8802_8803 : H12AffineEnvironment.transform 8 0 env8802 = env8803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env8802 == env8803) = true)

theorem identity8803 : scanCanonicalize (H12AffineFastState.compose env8803 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8803 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env8804 : List Nat := [2,4,3,16,0,64,128,214,0,214,0,146,145,16,146,18,146,131,5,146,65,80,195,82,19,146,210,16,17,130,4,81,5,130,195,80]

theorem envBound8804 : H12AffineFastState.Bounded env8804 := by
  intro p hp
  have h : env8804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8803_8804 : H12AffineEnvironment.transform 2 3 env8803 = env8804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8803 == env8804) = true)

theorem identity8804 : scanCanonicalize (H12AffineFastState.compose env8804 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 82) := by decide +kernel

theorem selectedBound8804 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env8805 : List Nat := [2,4,3,16,0,64,82,4,0,4,0,64,67,16,64,18,64,81,5,64,65,80,17,82,19,64,0,16,17,80,4,81,5,80,17,80]

theorem envBound8805 : H12AffineFastState.Bounded env8805 := by
  intro p hp
  have h : env8805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8804_8805 : H12AffineEnvironment.transform 6 82 env8804 = env8805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 82 env8804 == env8805) = true)

def env8806 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,561,8200,65536,4096,77976,4764,8200,65,113,4721,74448,8329,4097,78536,4745,4744,75786,4,73939,4764,73770,78578,73970]

theorem envBound8806 : H12AffineFastState.Bounded env8806 := by
  intro p hp
  have h : env8806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8796_8806 : H12AffineEnvironment.transform 13 561 env8796 = env8806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env8796 == env8806) = true)

theorem identity8806 : scanCanonicalize (H12AffineFastState.compose env8806 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound8806 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8807 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,64,8192,561,8200,65536,64,73944,732,8200,65,113,561,74448,8329,65,74376,713,712,75786,4,73939,732,73770,74418,73970]

theorem envBound8807 : H12AffineFastState.Bounded env8807 := by
  intro p hp
  have h : env8807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8806_8807 : H12AffineEnvironment.transform 11 64 env8806 = env8807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env8806 == env8807) = true)

theorem identity8807 : scanCanonicalize (H12AffineFastState.compose env8807 (packedSelected [1,3,5,8,10,14,17,19,21] rootPS)) = affineNative (2^(15+1) ^^^ 10865) := by decide +kernel

theorem selectedBound8807 : packedSelected [1,3,5,8,10,14,17,19,21] rootPS < 2^1333 := by decide +kernel

def env8808 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,64,8192,561,8200,10865,64,2729,732,8200,65,113,561,2209,8329,65,2297,713,712,635,4,2722,732,2651,2243,2691]

theorem envBound8808 : H12AffineFastState.Bounded env8808 := by
  intro p hp
  have h : env8808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8807_8808 : H12AffineEnvironment.transform 15 10865 env8807 = env8808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10865 env8807 == env8808) = true)

theorem identity8808 : scanCanonicalize (H12AffineFastState.compose env8808 (packedSelected [1,3,4,9,12,14,15,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound8808 : packedSelected [1,3,4,9,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env8809 : List Nat := [2,4,8,16,32,17,128,172,512,172,2048,17,8192,561,8200,10784,17,2729,653,8200,16,32,561,2209,8329,16,2216,664,665,554,4,2722,653,2570,2194,2691]

theorem envBound8809 : H12AffineFastState.Bounded env8809 := by
  intro p hp
  have h : env8809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8808_8809 : H12AffineEnvironment.transform 5 17 env8808 = env8809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8808 == env8809) = true)

theorem identity8809 : scanCanonicalize (H12AffineFastState.compose env8809 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound8809 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env8810 : List Nat := [2,4,8,16,32,17,128,172,512,172,42,17,8192,561,8200,8714,17,643,653,8200,16,32,561,139,8329,16,130,664,665,554,4,648,653,544,184,681]

theorem envBound8810 : H12AffineFastState.Bounded env8810 := by
  intro p hp
  have h : env8810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8809_8810 : H12AffineEnvironment.transform 10 42 env8809 = env8810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env8809 == env8810) = true)

theorem identity8810 : scanCanonicalize (H12AffineFastState.compose env8810 (packedSelected [3,7,8,9,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound8810 : packedSelected [3,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env8811 : List Nat := [2,4,8,16,32,17,128,172,512,172,42,17,656,561,664,154,17,643,653,664,16,32,561,139,537,16,130,664,665,554,4,648,653,544,184,681]

theorem envBound8811 : H12AffineFastState.Bounded env8811 := by
  intro p hp
  have h : env8811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8810_8811 : H12AffineEnvironment.transform 12 656 env8810 = env8811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env8810 == env8811) = true)

theorem identity8811 : scanCanonicalize (H12AffineFastState.compose env8811 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound8811 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env8812 : List Nat := [2,4,8,16,32,17,128,172,32,172,42,17,176,17,184,154,17,163,173,184,16,32,17,139,57,16,130,184,185,10,4,168,173,0,184,137]

theorem envBound8812 : H12AffineFastState.Bounded env8812 := by
  intro p hp
  have h : env8812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8811_8812 : H12AffineEnvironment.transform 8 32 env8811 = env8812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env8811 == env8812) = true)

theorem identity8812 : scanCanonicalize (H12AffineFastState.compose env8812 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound8812 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8813 : List Nat := [2,4,8,16,32,17,18,62,32,62,42,17,34,17,42,8,17,49,63,42,16,32,17,25,57,16,16,42,43,10,4,58,63,0,42,27]

theorem envBound8813 : H12AffineFastState.Bounded env8813 := by
  intro p hp
  have h : env8813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8812_8813 : H12AffineEnvironment.transform 6 18 env8812 = env8813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env8812 == env8813) = true)

theorem identity8813 : scanCanonicalize (H12AffineFastState.compose env8813 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound8813 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env8814 : List Nat := [2,4,8,16,16,17,18,14,16,14,26,17,18,17,26,8,17,1,15,26,16,16,17,25,9,16,16,26,27,10,4,10,15,0,26,27]

theorem envBound8814 : H12AffineFastState.Bounded env8814 := by
  intro p hp
  have h : env8814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8813_8814 : H12AffineEnvironment.transform 4 16 env8813 = env8814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env8813 == env8814) = true)

theorem identity8814 : scanCanonicalize (H12AffineFastState.compose env8814 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8814 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8815 : List Nat := [2,4,2,16,16,17,18,4,16,4,16,17,18,17,16,2,17,1,5,16,16,16,17,19,3,16,16,16,17,0,4,0,5,0,16,17]

theorem envBound8815 : H12AffineFastState.Bounded env8815 := by
  intro p hp
  have h : env8815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8814_8815 : H12AffineEnvironment.transform 2 2 env8814 = env8815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8814 == env8815) = true)

def env8816 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,4194304,524525,16777216,8329,16855761,807681,4735913,4735573,17324939,529048,21517022,524288,17322923,19415346,16778207]

theorem envBound8816 : H12AffineFastState.Bounded env8816 := by
  intro p hp
  have h : env8816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8530_8816 : H12AffineEnvironment.transform 26 807681 env8530 = env8816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 807681 env8530 == env8816) = true)

def env8817 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,4194304,524525,90336,8329,21041,807681,4735913,4735573,605035,529048,4796990,524288,602955,2695634,90943]

theorem envBound8817 : H12AffineFastState.Bounded env8817 := by
  intro p hp
  have h : env8817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8816_8817 : H12AffineEnvironment.transform 23 90336 env8816 = env8817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90336 env8816 == env8817) = true)

def env8818 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,262144,4960,8693,2097152,4194304,5005,90336,8329,21041,278625,4214985,4215093,75787,504,4268382,4960,73771,2175666,90943]

theorem envBound8818 : H12AffineFastState.Bounded env8818 := by
  intro p hp
  have h : env8818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8817_8818 : H12AffineEnvironment.transform 18 4960 env8817 = env8818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4960 env8817 == env8818) = true)

theorem identity8818 : scanCanonicalize (H12AffineFastState.compose env8818 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 24770) := by decide +kernel

theorem selectedBound8818 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8819 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,24770,4605,262144,4960,8693,2097152,4194304,5005,34,8329,21041,278625,4214985,4215093,18633,504,4211100,4960,16617,2118256,1021]

theorem envBound8819 : H12AffineFastState.Bounded env8819 := by
  intro p hp
  have h : env8819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8818_8819 : H12AffineEnvironment.transform 15 24770 env8818 = env8819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24770 env8818 == env8819) = true)

def env8820 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,24770,4605,262144,4960,8693,64,4194304,5005,34,8329,21041,278625,4214985,4215093,18633,504,4211100,4960,16617,21040,1021]

theorem envBound8820 : H12AffineFastState.Bounded env8820 := by
  intro p hp
  have h : env8820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8819_8820 : H12AffineEnvironment.transform 20 64 env8819 = env8820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env8819 == env8820) = true)

theorem identity8820 : scanCanonicalize (H12AffineFastState.compose env8820 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 4171) := by decide +kernel

theorem selectedBound8820 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8821 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,24770,4605,4171,4960,8693,64,4194304,5005,34,8329,21041,20522,4214985,4215093,18633,504,4211100,4960,16617,21040,1021]

theorem envBound8821 : H12AffineFastState.Bounded env8821 := by
  intro p hp
  have h : env8821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8820_8821 : H12AffineEnvironment.transform 17 4171 env8820 = env8821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4171 env8820 == env8821) = true)

def env8822 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,232,8693,8234,4605,4171,4960,8693,64,4194304,5005,34,8329,4825,4290,4198433,4198877,2081,504,4194676,4960,1,4824,1021]

theorem envBound8822 : H12AffineFastState.Bounded env8822 := by
  intro p hp
  have h : env8822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8821_8822 : H12AffineEnvironment.transform 13 232 env8821 = env8822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 232 env8821 == env8822) = true)

theorem identity8822 : scanCanonicalize (H12AffineFastState.compose env8822 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound8822 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8823 : List Nat := [2,4,8,16,32,64,128,85,512,85,2048,4096,8192,232,8352,8234,4264,4171,4661,8352,64,4194304,4824,34,8329,4825,4290,4198433,4198536,2081,173,4194337,4661,1,4824,680]

theorem envBound8823 : H12AffineFastState.Bounded env8823 := by
  intro p hp
  have h : env8823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8822_8823 : H12AffineEnvironment.transform 7 85 env8822 = env8823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env8822 == env8823) = true)

theorem identity8823 : scanCanonicalize (H12AffineFastState.compose env8823 (packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS)) = affineNative (2^(10+1) ^^^ 755) := by decide +kernel

theorem selectedBound8823 : packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env8824 : List Nat := [2,4,8,16,32,64,128,85,512,85,755,4096,8192,232,8352,8234,4264,4171,4661,8352,64,4194304,4824,34,8329,4825,4290,4198433,4198536,722,173,4194337,4661,1,4824,680]

theorem envBound8824 : H12AffineFastState.Bounded env8824 := by
  intro p hp
  have h : env8824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8823_8824 : H12AffineEnvironment.transform 10 755 env8823 = env8824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 755 env8823 == env8824) = true)

theorem identity8824 : scanCanonicalize (H12AffineFastState.compose env8824 (packedSelected [3,10,12,13,14,15,17,19,28] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound8824 : packedSelected [3,10,12,13,14,15,17,19,28] rootPS < 2^1333 := by decide +kernel

def env8825 : List Nat := [2,4,8,16,32,16,128,5,512,5,675,4096,8192,184,8352,8234,4264,4123,4661,8352,16,4194304,4744,34,8329,4745,4242,4198433,4198536,642,173,4194337,4661,1,4744,680]

theorem envBound8825 : H12AffineFastState.Bounded env8825 := by
  intro p hp
  have h : env8825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8824_8825 : H12AffineEnvironment.transform 5 16 env8824 = env8825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8824 == env8825) = true)

theorem identity8825 : scanCanonicalize (H12AffineFastState.compose env8825 (packedSelected [0,2,5,7,8,11,12,13] rootPS)) = affineNative (2^(21+1) ^^^ 4248) := by decide +kernel

theorem selectedBound8825 : packedSelected [0,2,5,7,8,11,12,13] rootPS < 2^1333 := by decide +kernel

def env8826 : List Nat := [2,4,8,16,32,16,128,5,512,5,675,4096,8192,184,8352,8234,4264,4123,4661,8352,16,4248,4744,34,8329,4745,4242,185,16,642,173,4281,4661,1,4744,680]

theorem envBound8826 : H12AffineFastState.Bounded env8826 := by
  intro p hp
  have h : env8826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8825_8826 : H12AffineEnvironment.transform 21 4248 env8825 = env8826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 4248 env8825 == env8826) = true)

def env8827 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,233,8693,8235,4605,4171,4960,8693,64,4194304,5005,34,8329,4824,4291,4198432,4198876,2080,504,4194677,4960,0,4825,1021]

theorem envBound8827 : H12AffineFastState.Bounded env8827 := by
  intro p hp
  have h : env8827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8821_8827 : H12AffineEnvironment.transform 13 233 env8821 = env8827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 233 env8821 == env8827) = true)

theorem identity8827 : scanCanonicalize (H12AffineFastState.compose env8827 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(21+1) ^^^ 476) := by decide +kernel

theorem selectedBound8827 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8828 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,233,8693,8235,4605,4171,4960,8693,64,476,5005,34,8329,4824,4291,4604,4096,2080,504,169,4960,0,4825,1021]

theorem envBound8828 : H12AffineFastState.Bounded env8828 := by
  intro p hp
  have h : env8828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8827_8828 : H12AffineEnvironment.transform 21 476 env8827 = env8828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 476 env8827 == env8828) = true)

theorem identity8828 : scanCanonicalize (H12AffineFastState.compose env8828 (packedSelected [1,3,4,7,9,12,14,18,23,27,38] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound8828 : packedSelected [1,3,4,7,9,12,14,18,23,27,38] rootPS < 2^1333 := by decide +kernel

def env8829 : List Nat := [2,4,8,16,32,64,41,256,512,256,2048,4096,8192,64,8540,8235,4436,4171,4960,8540,64,373,4900,34,8224,4721,4202,4437,4096,2080,337,0,4960,0,4720,852]

theorem envBound8829 : H12AffineFastState.Bounded env8829 := by
  intro p hp
  have h : env8829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8828_8829 : H12AffineEnvironment.transform 6 41 env8828 = env8829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env8828 == env8829) = true)

theorem identity8829 : scanCanonicalize (H12AffineFastState.compose env8829 (packedSelected [0,4,7,9,13,14,17] rootPS)) = affineNative (2^(11+1) ^^^ 2367) := by decide +kernel

theorem selectedBound8829 : packedSelected [0,4,7,9,13,14,17] rootPS < 2^1333 := by decide +kernel

def env8830 : List Nat := [2,4,8,16,32,64,41,256,512,256,2048,2367,8192,64,8540,8235,2155,2420,2655,8540,64,373,2587,34,8224,2894,2389,2154,2367,2080,337,0,2655,0,2895,852]

theorem envBound8830 : H12AffineFastState.Bounded env8830 := by
  intro p hp
  have h : env8830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8829_8830 : H12AffineEnvironment.transform 11 2367 env8829 = env8830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2367 env8829 == env8830) = true)

theorem identity8830 : scanCanonicalize (H12AffineFastState.compose env8830 (packedSelected [0,2,3,4,5,7,9,10,11,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound8830 : packedSelected [0,2,3,4,5,7,9,10,11,18] rootPS < 2^1333 := by decide +kernel

def env8831 : List Nat := [2,4,8,16,32,16,41,256,512,256,2048,2367,8192,16,8460,8235,2107,2340,2575,8460,16,293,2587,34,8224,2846,2309,2106,2367,2080,257,0,2575,0,2847,772]

theorem envBound8831 : H12AffineFastState.Bounded env8831 := by
  intro p hp
  have h : env8831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8830_8831 : H12AffineEnvironment.transform 5 16 env8830 = env8831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8830 == env8831) = true)

theorem identity8831 : scanCanonicalize (H12AffineFastState.compose env8831 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 791) := by decide +kernel

theorem selectedBound8831 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env8832 : List Nat := [2,4,8,16,32,16,41,256,512,256,2048,2367,791,16,539,828,2107,2340,2575,539,16,293,2587,34,823,2846,2309,2106,2367,2080,257,0,2575,0,2847,772]

theorem envBound8832 : H12AffineFastState.Bounded env8832 := by
  intro p hp
  have h : env8832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8831_8832 : H12AffineEnvironment.transform 12 791 env8831 = env8832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 791 env8831 == env8832) = true)

theorem identity8832 : scanCanonicalize (H12AffineFastState.compose env8832 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound8832 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env8833 : List Nat := [2,4,8,16,32,16,41,256,43,256,2048,2367,316,16,48,279,2107,2340,2084,48,16,293,2096,34,284,2357,2309,2106,2367,2080,257,0,2084,0,2356,303]

theorem envBound8833 : H12AffineFastState.Bounded env8833 := by
  intro p hp
  have h : env8833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8832_8833 : H12AffineEnvironment.transform 8 43 env8832 = env8833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env8832 == env8833) = true)

theorem identity8833 : scanCanonicalize (H12AffineFastState.compose env8833 (packedSelected [0,4,11] rootPS)) = affineNative (2^(10+1) ^^^ 319) := by decide +kernel

theorem selectedBound8833 : packedSelected [0,4,11] rootPS < 2^1333 := by decide +kernel

def env8834 : List Nat := [2,4,8,16,32,16,41,256,43,256,319,0,316,16,48,279,260,27,283,48,16,293,271,34,284,10,58,261,0,287,257,0,283,0,11,303]

theorem envBound8834 : H12AffineFastState.Bounded env8834 := by
  intro p hp
  have h : env8834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8833_8834 : H12AffineEnvironment.transform 10 319 env8833 = env8834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 319 env8833 == env8834) = true)

theorem identity8834 : scanCanonicalize (H12AffineFastState.compose env8834 (packedSelected [3,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound8834 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env8835 : List Nat := [2,4,8,16,11,16,2,256,0,256,276,0,279,16,27,279,260,27,283,27,16,270,271,9,284,10,17,261,0,287,257,0,283,0,11,260]

theorem envBound8835 : H12AffineFastState.Bounded env8835 := by
  intro p hp
  have h : env8835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8834_8835 : H12AffineEnvironment.transform 4 11 env8834 = env8835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env8834 == env8835) = true)

theorem identity8835 : scanCanonicalize (H12AffineFastState.compose env8835 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound8835 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8836 : List Nat := [2,4,8,16,11,16,2,21,0,21,1,0,2,16,27,2,17,27,14,27,16,27,26,9,9,10,17,16,0,10,20,0,14,0,11,17]

theorem envBound8836 : H12AffineFastState.Bounded env8836 := by
  intro p hp
  have h : env8836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8835_8836 : H12AffineEnvironment.transform 7 21 env8835 = env8836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env8835 == env8836) = true)

theorem identity8836 : scanCanonicalize (H12AffineFastState.compose env8836 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8836 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8837 : List Nat := [2,4,8,1,11,1,2,4,0,4,1,0,2,1,10,2,0,10,14,10,1,10,11,9,9,10,0,1,0,10,5,0,14,0,11,0]

theorem envBound8837 : H12AffineFastState.Bounded env8837 := by
  intro p hp
  have h : env8837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8836_8837 : H12AffineEnvironment.transform 3 1 env8836 = env8837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8836 == env8837) = true)

def env8838 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,24770,4605,262144,4960,8693,65,4194304,5005,34,8329,21041,278625,4214985,4215093,18633,504,4211100,4960,16617,21041,1021]

theorem envBound8838 : H12AffineFastState.Bounded env8838 := by
  intro p hp
  have h : env8838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8819_8838 : H12AffineEnvironment.transform 20 65 env8819 = env8838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env8819 == env8838) = true)

theorem identity8838 : scanCanonicalize (H12AffineFastState.compose env8838 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 555) := by decide +kernel

theorem selectedBound8838 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8839 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,24770,4605,555,4960,8693,65,4194304,5005,34,8329,21041,16970,4214985,4215093,18633,504,4211100,4960,16617,21041,1021]

theorem envBound8839 : H12AffineFastState.Bounded env8839 := by
  intro p hp
  have h : env8839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8838_8839 : H12AffineEnvironment.transform 17 555 env8838 = env8839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 555 env8838 == env8839) = true)

def env8840 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,232,8693,8234,4605,555,4960,8693,65,4194304,5005,34,8329,4825,674,4198433,4198877,2081,504,4194676,4960,1,4825,1021]

theorem envBound8840 : H12AffineFastState.Bounded env8840 := by
  intro p hp
  have h : env8840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8839_8840 : H12AffineEnvironment.transform 13 232 env8839 = env8840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 232 env8839 == env8840) = true)

theorem identity8840 : scanCanonicalize (H12AffineFastState.compose env8840 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound8840 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8841 : List Nat := [2,4,8,16,32,64,128,84,512,84,2048,4096,8192,232,8353,8234,4265,555,4660,8353,65,4194304,4825,34,8329,4825,674,4198433,4198537,2081,172,4194336,4660,1,4825,681]

theorem envBound8841 : H12AffineFastState.Bounded env8841 := by
  intro p hp
  have h : env8841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8840_8841 : H12AffineEnvironment.transform 7 84 env8840 = env8841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env8840 == env8841) = true)

theorem identity8841 : scanCanonicalize (H12AffineFastState.compose env8841 (packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS)) = affineNative (2^(11+1) ^^^ 2242) := by decide +kernel

theorem selectedBound8841 : packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env8842 : List Nat := [2,4,8,16,32,64,128,84,512,84,2048,2242,8192,232,8353,8234,2155,555,2806,8353,65,4194304,2587,34,8329,2587,674,4196579,4196427,2081,172,4194336,2806,1,2587,681]

theorem envBound8842 : H12AffineFastState.Bounded env8842 := by
  intro p hp
  have h : env8842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8841_8842 : H12AffineEnvironment.transform 11 2242 env8841 = env8842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2242 env8841 == env8842) = true)

theorem identity8842 : scanCanonicalize (H12AffineFastState.compose env8842 (packedSelected [3,4,7,9,10,18,19,23,24,27] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound8842 : packedSelected [3,4,7,9,10,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env8843 : List Nat := [2,4,8,16,32,64,128,84,512,84,523,713,8192,232,8353,8234,608,555,253,8353,65,4194304,16,34,8329,16,674,4195048,4194880,554,172,4194336,253,1,16,681]

theorem envBound8843 : H12AffineFastState.Bounded env8843 := by
  intro p hp
  have h : env8843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8842_8843 : H12AffineEnvironment.transform 10 523 env8842 = env8843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env8842 == env8843) = true)

theorem identity8843 : scanCanonicalize (H12AffineFastState.compose env8843 (packedSelected [0,3,4,7,9,10,12,15,19,28] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound8843 : packedSelected [0,3,4,7,9,10,12,15,19,28] rootPS < 2^1333 := by decide +kernel

def env8844 : List Nat := [2,4,8,16,32,64,128,84,512,84,523,713,8192,232,8353,8234,608,555,253,8353,65,113,16,34,8329,16,674,665,561,554,172,81,253,1,16,681]

theorem envBound8844 : H12AffineFastState.Bounded env8844 := by
  intro p hp
  have h : env8844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8843_8844 : H12AffineEnvironment.transform 21 113 env8843 = env8844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env8843 == env8844) = true)

theorem identity8844 : scanCanonicalize (H12AffineFastState.compose env8844 (packedSelected [1,2,4,5,7,11,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound8844 : packedSelected [1,2,4,5,7,11,12,13] rootPS < 2^1333 := by decide +kernel

def env8845 : List Nat := [2,4,8,16,32,64,88,84,512,84,523,529,8192,48,8313,8234,608,555,37,8313,65,113,16,34,8273,16,634,577,561,554,116,81,37,1,16,625]

theorem envBound8845 : H12AffineFastState.Bounded env8845 := by
  intro p hp
  have h : env8845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8844_8845 : H12AffineEnvironment.transform 6 88 env8844 = env8845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env8844 == env8845) = true)

theorem identity8845 : scanCanonicalize (H12AffineFastState.compose env8845 (packedSelected [0,2,4,5,7,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 552) := by decide +kernel

theorem selectedBound8845 : packedSelected [0,2,4,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env8846 : List Nat := [2,4,8,16,32,64,88,84,512,84,523,529,552,48,593,514,608,555,37,593,65,113,16,34,633,16,634,577,561,554,116,81,37,1,16,625]

theorem envBound8846 : H12AffineFastState.Bounded env8846 := by
  intro p hp
  have h : env8846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8845_8846 : H12AffineEnvironment.transform 12 552 env8845 = env8846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 552 env8845 == env8846) = true)

theorem identity8846 : scanCanonicalize (H12AffineFastState.compose env8846 (packedSelected [0,2,3,5,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound8846 : packedSelected [0,2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env8847 : List Nat := [2,4,8,16,32,64,88,84,81,84,90,64,121,48,0,83,49,122,37,0,65,113,16,34,40,16,43,16,96,123,116,81,37,1,16,32]

theorem envBound8847 : H12AffineFastState.Bounded env8847 := by
  intro p hp
  have h : env8847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8846_8847 : H12AffineEnvironment.transform 8 81 env8846 = env8847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env8846 == env8847) = true)

theorem identity8847 : scanCanonicalize (H12AffineFastState.compose env8847 (packedSelected [4,7] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound8847 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env8848 : List Nat := [2,4,8,16,32,43,51,63,58,63,49,43,18,48,0,56,49,17,37,0,42,26,16,34,40,16,43,16,11,16,31,58,37,1,16,32]

theorem envBound8848 : H12AffineFastState.Bounded env8848 := by
  intro p hp
  have h : env8848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8847_8848 : H12AffineEnvironment.transform 5 43 env8847 = env8848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env8847 == env8848) = true)

theorem identity8848 : scanCanonicalize (H12AffineFastState.compose env8848 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound8848 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env8849 : List Nat := [2,4,8,16,16,27,3,15,10,15,1,27,18,0,0,8,1,17,21,0,26,26,16,18,24,16,27,16,11,16,31,10,21,1,16,16]

theorem envBound8849 : H12AffineFastState.Bounded env8849 := by
  intro p hp
  have h : env8849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8848_8849 : H12AffineEnvironment.transform 4 16 env8848 = env8849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env8848 == env8849) = true)

theorem identity8849 : scanCanonicalize (H12AffineFastState.compose env8849 (packedSelected [0,1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound8849 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env8850 : List Nat := [2,4,8,10,10,1,3,15,10,15,1,1,8,0,0,8,1,11,15,0,0,0,10,8,2,10,1,10,11,10,5,10,15,1,10,10]

theorem envBound8850 : H12AffineFastState.Bounded env8850 := by
  intro p hp
  have h : env8850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8849_8850 : H12AffineEnvironment.transform 3 10 env8849 = env8850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env8849 == env8850) = true)

theorem identity8850 : scanCanonicalize (H12AffineFastState.compose env8850 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8850 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8851 : List Nat := [2,4,2,0,0,1,3,5,0,5,1,1,2,0,0,2,1,1,5,0,0,0,0,2,2,0,1,0,1,0,5,0,5,1,0,0]

theorem envBound8851 : H12AffineFastState.Bounded env8851 := by
  intro p hp
  have h : env8851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8850_8851 : H12AffineEnvironment.transform 2 2 env8850 = env8851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8850 == env8851) = true)

def leafEnv8851 : List Nat := [2,4,2,0,0,1,3,5,0,5,1,1,2,0,0,2,1,1,5,0,0,0,0,2,5,2,1,0,1,0,1,0,5,0,5,1,4,3,0,0,1,1,0]

def active8851 : List Nat := [0,1]

def tree8851 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8851 : H12WitnessSearch.Good tree8851 := H12GlobalWitnessIndex.good

theorem leafIdentity8851 : H12AffineFastState.composeSystem env8851 rootObs = leafEnv8851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8851 rootObs == leafEnv8851) = true)

theorem terminalChecked8851 : H12PackedTerminal.terminalCheckFast leafEnv8851 active8851 tree8851 = true := by decide +kernel

def env8852 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,233,8693,8235,4605,555,4960,8693,65,4194304,5005,34,8329,4824,675,4198432,4198876,2080,504,4194677,4960,0,4824,1021]

theorem envBound8852 : H12AffineFastState.Bounded env8852 := by
  intro p hp
  have h : env8852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8839_8852 : H12AffineEnvironment.transform 13 233 env8839 = env8852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 233 env8839 == env8852) = true)

theorem identity8852 : scanCanonicalize (H12AffineFastState.compose env8852 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(21+1) ^^^ 477) := by decide +kernel

theorem selectedBound8852 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8853 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,233,8693,8235,4605,555,4960,8693,65,477,5005,34,8329,4824,675,4605,4097,2080,504,168,4960,0,4824,1021]

theorem envBound8853 : H12AffineFastState.Bounded env8853 := by
  intro p hp
  have h : env8853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8852_8853 : H12AffineEnvironment.transform 21 477 env8852 = env8853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 477 env8852 == env8853) = true)

theorem identity8853 : scanCanonicalize (H12AffineFastState.compose env8853 (packedSelected [1,3,4,7,9,12,14,18,23,27,38] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound8853 : packedSelected [1,3,4,7,9,12,14,18,23,27,38] rootPS < 2^1333 := by decide +kernel

def env8854 : List Nat := [2,4,8,16,32,64,121,256,512,256,2048,4096,8192,16,8460,8235,4356,555,4960,8460,65,292,4980,34,8304,4641,602,4356,4097,2080,257,81,4960,0,4641,772]

theorem envBound8854 : H12AffineFastState.Bounded env8854 := by
  intro p hp
  have h : env8854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8853_8854 : H12AffineEnvironment.transform 6 121 env8853 = env8854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env8853 == env8854) = true)

theorem identity8854 : scanCanonicalize (H12AffineFastState.compose env8854 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2367) := by decide +kernel

theorem selectedBound8854 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8855 : List Nat := [2,4,8,16,32,64,121,256,512,256,2048,2367,8192,16,8460,8235,2107,555,2655,8460,65,292,2635,34,8304,2846,602,2107,2366,2080,257,81,2655,0,2846,772]

theorem envBound8855 : H12AffineFastState.Bounded env8855 := by
  intro p hp
  have h : env8855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8854_8855 : H12AffineEnvironment.transform 11 2367 env8854 = env8855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2367 env8854 == env8855) = true)

theorem identity8855 : scanCanonicalize (H12AffineFastState.compose env8855 (packedSelected [2,3,5,7,9,11,12,13,14] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound8855 : packedSelected [2,3,5,7,9,11,12,13,14] rootPS < 2^1333 := by decide +kernel

def env8856 : List Nat := [2,4,8,16,32,64,121,4,512,4,2048,2107,8192,16,8200,8235,2107,555,2655,8200,65,32,2635,34,8304,2586,602,2107,2106,2080,5,81,2655,0,2586,512]

theorem envBound8856 : H12AffineFastState.Bounded env8856 := by
  intro p hp
  have h : env8856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8855_8856 : H12AffineEnvironment.transform 7 4 env8855 = env8856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env8855 == env8856) = true)

theorem identity8856 : scanCanonicalize (H12AffineFastState.compose env8856 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound8856 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8857 : List Nat := [2,4,8,16,32,16,41,4,512,4,2048,2107,8192,16,8200,8235,2107,555,2575,8200,17,32,2587,34,8224,2586,522,2107,2106,2080,5,1,2575,0,2586,512]

theorem envBound8857 : H12AffineFastState.Bounded env8857 := by
  intro p hp
  have h : env8857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8856_8857 : H12AffineEnvironment.transform 5 16 env8856 = env8857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8856 == env8857) = true)

theorem identity8857 : scanCanonicalize (H12AffineFastState.compose env8857 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2617) := by decide +kernel

theorem selectedBound8857 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8858 : List Nat := [2,4,8,16,32,16,41,4,512,4,2048,2107,2617,16,2609,2578,2107,555,2575,2609,17,32,2587,34,2585,2586,522,2107,2106,2080,5,1,2575,0,2586,512]

theorem envBound8858 : H12AffineFastState.Bounded env8858 := by
  intro p hp
  have h : env8858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8857_8858 : H12AffineEnvironment.transform 12 2617 env8857 = env8858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2617 env8857 == env8858) = true)

theorem identity8858 : scanCanonicalize (H12AffineFastState.compose env8858 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound8858 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8859 : List Nat := [2,4,8,16,32,16,41,4,17,4,2048,2107,2088,16,2080,2051,2107,58,2078,2080,17,32,2058,34,2056,2059,27,2107,2106,2080,5,1,2078,0,2059,17]

theorem envBound8859 : H12AffineFastState.Bounded env8859 := by
  intro p hp
  have h : env8859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8858_8859 : H12AffineEnvironment.transform 8 17 env8858 = env8859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env8858 == env8859) = true)

theorem identity8859 : scanCanonicalize (H12AffineFastState.compose env8859 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound8859 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8860 : List Nat := [2,4,8,16,32,16,41,4,17,4,48,11,24,16,16,51,11,58,46,16,17,32,58,34,56,59,27,11,10,16,5,1,46,0,59,17]

theorem envBound8860 : H12AffineFastState.Bounded env8860 := by
  intro p hp
  have h : env8860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8859_8860 : H12AffineEnvironment.transform 10 48 env8859 = env8860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env8859 == env8860) = true)

theorem identity8860 : scanCanonicalize (H12AffineFastState.compose env8860 (packedSelected [4,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8860 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env8861 : List Nat := [2,4,8,0,32,0,41,4,1,4,32,11,8,0,0,35,11,42,46,0,1,32,42,34,40,43,11,11,10,0,5,1,46,0,43,1]

theorem envBound8861 : H12AffineFastState.Bounded env8861 := by
  intro p hp
  have h : env8861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8860_8861 : H12AffineEnvironment.transform 3 0 env8860 = env8861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8860 == env8861) = true)

theorem identity8861 : scanCanonicalize (H12AffineFastState.compose env8861 (packedSelected [4,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound8861 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env8862 : List Nat := [2,4,8,0,10,0,3,4,1,4,10,11,8,0,0,9,11,0,4,0,1,10,0,8,2,1,11,11,10,0,5,1,4,0,1,1]

theorem envBound8862 : H12AffineFastState.Bounded env8862 := by
  intro p hp
  have h : env8862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8861_8862 : H12AffineEnvironment.transform 4 10 env8861 = env8862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env8861 == env8862) = true)

theorem identity8862 : scanCanonicalize (H12AffineFastState.compose env8862 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8862 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env8863 : List Nat := [2,4,3,0,1,0,3,4,1,4,1,0,3,0,0,2,0,0,4,0,1,1,0,3,2,1,0,0,1,0,5,1,4,0,1,1]

theorem envBound8863 : H12AffineFastState.Bounded env8863 := by
  intro p hp
  have h : env8863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8862_8863 : H12AffineEnvironment.transform 2 3 env8862 = env8863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8862 == env8863) = true)

def leafEnv8863 : List Nat := [2,4,3,0,1,0,3,4,1,4,1,0,3,0,0,2,0,0,4,0,1,1,0,3,5,2,1,1,0,0,1,0,5,1,4,0,4,2,1,1,1,1,0]

def active8863 : List Nat := [0,1]

def tree8863 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8863 : H12WitnessSearch.Good tree8863 := H12GlobalWitnessIndex.good

theorem leafIdentity8863 : H12AffineFastState.composeSystem env8863 rootObs = leafEnv8863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8863 rootObs == leafEnv8863) = true)

theorem terminalChecked8863 : H12PackedTerminal.terminalCheckFast leafEnv8863 active8863 tree8863 = true := by decide +kernel

def env8864 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,262144,4961,8693,2097152,4194304,5004,90336,8329,21041,278624,4214984,4215092,75786,505,4268383,4961,73770,2175667,90943]

theorem envBound8864 : H12AffineFastState.Bounded env8864 := by
  intro p hp
  have h : env8864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8817_8864 : H12AffineEnvironment.transform 18 4961 env8817 = env8864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4961 env8817 == env8864) = true)

theorem identity8864 : scanCanonicalize (H12AffineFastState.compose env8864 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound8864 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8865 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8200,65536,4096,262144,4764,8200,2097152,4194304,4721,90336,8329,21041,278624,4214984,4214985,75786,4,4268194,4764,73770,2175667,90818]

theorem envBound8865 : H12AffineFastState.Bounded env8865 := by
  intro p hp
  have h : env8865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8864_8865 : H12AffineEnvironment.transform 7 253 env8864 = env8865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env8864 == env8865) = true)

def env8866 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8200,65536,4096,262144,4764,8200,64,4194304,4721,90336,8329,21041,278624,4214984,4214985,75786,4,4268194,4764,73770,78579,90818]

theorem envBound8866 : H12AffineFastState.Bounded env8866 := by
  intro p hp
  have h : env8866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8865_8866 : H12AffineEnvironment.transform 20 64 env8865 = env8866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env8865 == env8866) = true)

theorem identity8866 : scanCanonicalize (H12AffineFastState.compose env8866 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 356600) := by decide +kernel

theorem selectedBound8866 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8867 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8200,65536,4096,262144,4764,8200,64,356600,4721,90336,8329,21041,278624,335920,335921,75786,4,282714,4764,73770,78579,90818]

theorem envBound8867 : H12AffineFastState.Bounded env8867 := by
  intro p hp
  have h : env8867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8866_8867 : H12AffineEnvironment.transform 21 356600 env8866 = env8867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 356600 env8866 == env8867) = true)

def env8868 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,4096,8192,16384,8200,65536,4096,262144,4644,8200,64,356416,4721,90200,8241,21041,278624,335920,335921,75786,4,282714,4644,73770,78411,90746]

theorem envBound8868 : H12AffineFastState.Bounded env8868 := by
  intro p hp
  have h : env8868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8867_8868 : H12AffineEnvironment.transform 6 56 env8867 = env8868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env8867 == env8868) = true)

theorem identity8868 : scanCanonicalize (H12AffineFastState.compose env8868 (packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS)) = affineNative (2^(17+1) ^^^ 90209) := by decide +kernel

theorem selectedBound8868 : packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS < 2^1333 := by decide +kernel

def env8869 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,4096,8192,16384,8200,65536,4096,90209,4644,8200,64,4129,4721,90200,8241,21041,73729,16465,16464,75786,4,77883,4644,73770,78411,90746]

theorem envBound8869 : H12AffineFastState.Bounded env8869 := by
  intro p hp
  have h : env8869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8868_8869 : H12AffineEnvironment.transform 17 90209 env8868 = env8869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 90209 env8868 == env8869) = true)

def env8870 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,4096,8192,4704,8200,65536,4096,78337,4644,8200,64,4129,4721,78392,8241,81,73729,4657,4656,75786,4,77883,4644,73770,78411,77850]

theorem envBound8870 : H12AffineFastState.Bounded env8870 := by
  intro p hp
  have h : env8870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8869_8870 : H12AffineEnvironment.transform 13 4704 env8869 = env8870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4704 env8869 == env8870) = true)

theorem identity8870 : scanCanonicalize (H12AffineFastState.compose env8870 (packedSelected [1,3,11,12,14,15,18,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 8715) := by decide +kernel

theorem selectedBound8870 : packedSelected [1,3,11,12,14,15,18,23,32] rootPS < 2^1333 := by decide +kernel

def env8871 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,4096,8192,4704,8200,8715,4096,4106,4644,8200,64,4129,4721,4147,8241,81,522,4657,4656,2561,4,4656,4644,545,4160,4625]

theorem envBound8871 : H12AffineFastState.Bounded env8871 := by
  intro p hp
  have h : env8871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8870_8871 : H12AffineEnvironment.transform 15 8715 env8870 = env8871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8715 env8870 == env8871) = true)

theorem identity8871 : scanCanonicalize (H12AffineFastState.compose env8871 (packedSelected [2,5,8,10,11,12,15,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 112) := by decide +kernel

theorem selectedBound8871 : packedSelected [2,5,8,10,11,12,15,18,19] rootPS < 2^1333 := by decide +kernel

def env8872 : List Nat := [2,4,8,16,32,64,56,69,112,69,2048,4096,8192,4112,8200,8315,4096,4106,4180,8200,64,4129,4097,4147,8241,81,122,4161,4160,2161,4,4160,4180,81,4160,4193]

theorem envBound8872 : H12AffineFastState.Bounded env8872 := by
  intro p hp
  have h : env8872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8871_8872 : H12AffineEnvironment.transform 8 112 env8871 = env8872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 112 env8871 == env8872) = true)

theorem identity8872 : scanCanonicalize (H12AffineFastState.compose env8872 (packedSelected [1,5,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2171) := by decide +kernel

theorem selectedBound8872 : packedSelected [1,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env8873 : List Nat := [2,4,8,16,32,64,56,69,112,69,2048,2171,8192,2155,8200,8315,2171,2161,2095,8200,64,2138,2170,2120,8241,81,122,2106,2107,2161,4,2107,2095,81,2107,2074]

theorem envBound8873 : H12AffineFastState.Bounded env8873 := by
  intro p hp
  have h : env8873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8872_8873 : H12AffineEnvironment.transform 11 2171 env8872 = env8873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2171 env8872 == env8873) = true)

theorem identity8873 : scanCanonicalize (H12AffineFastState.compose env8873 (packedSelected [0,1,8,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound8873 : packedSelected [0,1,8,9,11] rootPS < 2^1333 := by decide +kernel

def env8874 : List Nat := [2,4,8,16,32,64,56,69,112,69,2048,2171,9,2155,1,114,2171,2161,2095,1,64,2138,2170,2120,56,81,122,2106,2107,2161,4,2107,2095,81,2107,2074]

theorem envBound8874 : H12AffineFastState.Bounded env8874 := by
  intro p hp
  have h : env8874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8873_8874 : H12AffineEnvironment.transform 12 9 env8873 = env8874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env8873 == env8874) = true)

theorem identity8874 : scanCanonicalize (H12AffineFastState.compose env8874 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8874 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env8875 : List Nat := [2,4,8,0,32,64,40,69,96,69,2048,2155,9,2155,1,98,2155,2145,2095,1,64,2122,2154,2120,40,65,106,2090,2091,2145,4,2091,2095,65,2091,2058]

theorem envBound8875 : H12AffineFastState.Bounded env8875 := by
  intro p hp
  have h : env8875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8874_8875 : H12AffineEnvironment.transform 3 0 env8874 = env8875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8874 == env8875) = true)

theorem identity8875 : scanCanonicalize (H12AffineFastState.compose env8875 (packedSelected [0,1,2,3,4,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound8875 : packedSelected [0,1,2,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env8876 : List Nat := [2,4,8,0,32,10,40,15,42,15,2048,2081,9,2081,1,40,2081,2091,2095,1,10,2048,2080,2050,40,11,32,2090,2091,2091,4,2091,2095,11,2091,2058]

theorem envBound8876 : H12AffineFastState.Bounded env8876 := by
  intro p hp
  have h : env8876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8875_8876 : H12AffineEnvironment.transform 5 10 env8875 = env8876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env8875 == env8876) = true)

theorem identity8876 : scanCanonicalize (H12AffineFastState.compose env8876 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8876 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env8877 : List Nat := [2,4,8,0,1,10,9,15,11,15,2048,2048,9,2048,1,9,2048,2058,2062,1,10,2048,2049,2050,9,11,1,2059,2058,2058,4,2058,2062,11,2058,2058]

theorem envBound8877 : H12AffineFastState.Bounded env8877 := by
  intro p hp
  have h : env8877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8876_8877 : H12AffineEnvironment.transform 4 1 env8876 = env8877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8876 == env8877) = true)

def env8878 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,4096,8192,4705,8200,65536,4096,78336,4644,8200,64,4129,4721,78393,8241,80,73729,4656,4657,75786,4,77883,4644,73770,78411,77851]

theorem envBound8878 : H12AffineFastState.Bounded env8878 := by
  intro p hp
  have h : env8878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8869_8878 : H12AffineEnvironment.transform 13 4705 env8869 = env8878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4705 env8869 == env8878) = true)

theorem identity8878 : scanCanonicalize (H12AffineFastState.compose env8878 (packedSelected [1,3,11,12,14,15,18,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 8314) := by decide +kernel

theorem selectedBound8878 : packedSelected [1,3,11,12,14,15,18,23,32] rootPS < 2^1333 := by decide +kernel

def env8879 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,4096,8192,4705,8200,8314,4096,4730,4644,8200,64,4129,4721,4675,8241,80,123,4656,4657,2160,4,4161,4644,80,4657,4193]

theorem envBound8879 : H12AffineFastState.Bounded env8879 := by
  intro p hp
  have h : env8879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8878_8879 : H12AffineEnvironment.transform 15 8314 env8878 = env8879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8314 env8878 == env8879) = true)

theorem identity8879 : scanCanonicalize (H12AffineFastState.compose env8879 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 586) := by decide +kernel

theorem selectedBound8879 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env8880 : List Nat := [2,4,8,16,32,64,56,69,512,69,586,4096,8192,4705,8200,8314,4096,4730,4644,8200,64,4129,4721,4675,8241,80,123,4656,4657,570,4,4161,4644,80,4657,4193]

theorem envBound8880 : H12AffineFastState.Bounded env8880 := by
  intro p hp
  have h : env8880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8879_8880 : H12AffineEnvironment.transform 10 586 env8879 = env8880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 586 env8879 == env8880) = true)

theorem identity8880 : scanCanonicalize (H12AffineFastState.compose env8880 (packedSelected [1,3,4,5,8,9,10,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound8880 : packedSelected [1,3,4,5,8,9,10,19,20] rootPS < 2^1333 := by decide +kernel

def env8881 : List Nat := [2,4,8,16,32,64,56,69,512,69,586,17,8192,624,8200,8314,17,619,565,8200,64,48,608,594,8241,80,123,545,544,570,4,80,565,80,544,112]

theorem envBound8881 : H12AffineFastState.Bounded env8881 := by
  intro p hp
  have h : env8881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8880_8881 : H12AffineEnvironment.transform 11 17 env8880 = env8881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env8880 == env8881) = true)

theorem identity8881 : scanCanonicalize (H12AffineFastState.compose env8881 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8881 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8882 : List Nat := [2,4,8,0,32,64,40,69,512,69,586,1,8192,608,8200,8298,1,619,549,8200,64,32,608,578,8225,64,107,545,544,554,4,64,549,64,544,96]

theorem envBound8882 : H12AffineFastState.Bounded env8882 := by
  intro p hp
  have h : env8882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8881_8882 : H12AffineEnvironment.transform 3 0 env8881 = env8882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8881 == env8882) = true)

theorem identity8882 : scanCanonicalize (H12AffineFastState.compose env8882 (packedSelected [0,1,2,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 617) := by decide +kernel

theorem selectedBound8882 : packedSelected [0,1,2,8,9] rootPS < 2^1333 := by decide +kernel

def env8883 : List Nat := [2,4,8,0,32,64,40,69,512,69,586,1,617,608,609,515,1,619,549,609,64,32,608,578,584,64,107,545,544,554,4,64,549,64,544,96]

theorem envBound8883 : H12AffineFastState.Bounded env8883 := by
  intro p hp
  have h : env8883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8882_8883 : H12AffineEnvironment.transform 12 617 env8882 = env8883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 617 env8882 == env8883) = true)

theorem identity8883 : scanCanonicalize (H12AffineFastState.compose env8883 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound8883 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env8884 : List Nat := [2,4,8,0,11,64,3,69,512,69,586,1,578,587,586,515,1,576,526,586,64,11,587,578,584,64,64,522,523,513,4,64,526,64,523,75]

theorem envBound8884 : H12AffineFastState.Bounded env8884 := by
  intro p hp
  have h : env8884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8883_8884 : H12AffineEnvironment.transform 4 11 env8883 = env8884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env8883 == env8884) = true)

theorem identity8884 : scanCanonicalize (H12AffineFastState.compose env8884 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound8884 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env8885 : List Nat := [2,4,8,0,11,64,3,69,0,69,74,1,66,75,74,3,1,64,14,74,64,11,75,66,72,64,64,10,11,1,4,64,14,64,11,75]

theorem envBound8885 : H12AffineFastState.Bounded env8885 := by
  intro p hp
  have h : env8885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8884_8885 : H12AffineEnvironment.transform 8 0 env8884 = env8885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env8884 == env8885) = true)

theorem identity8885 : scanCanonicalize (H12AffineFastState.compose env8885 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8885 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8886 : List Nat := [2,4,2,0,1,64,3,69,0,69,64,1,66,65,64,3,1,64,4,64,64,1,65,66,66,64,64,0,1,1,4,64,4,64,1,65]

theorem envBound8886 : H12AffineFastState.Bounded env8886 := by
  intro p hp
  have h : env8886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8885_8886 : H12AffineEnvironment.transform 2 2 env8885 = env8886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8885 == env8886) = true)

theorem identity8886 : scanCanonicalize (H12AffineFastState.compose env8886 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound8886 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8887 : List Nat := [2,4,2,0,1,0,3,5,0,5,0,1,2,1,0,3,1,0,4,0,0,1,1,2,2,0,0,0,1,1,4,0,4,0,1,1]

theorem envBound8887 : H12AffineFastState.Bounded env8887 := by
  intro p hp
  have h : env8887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8886_8887 : H12AffineEnvironment.transform 5 0 env8886 = env8887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env8886 == env8887) = true)

theorem identity8887 : scanCanonicalize (H12AffineFastState.compose env8887 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound8887 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8888 : List Nat := [2,0,2,0,1,0,3,1,0,1,0,1,2,1,0,3,1,0,0,0,0,1,1,2,2,0,0,0,1,1,0,0,0,0,1,1]

theorem envBound8888 : H12AffineFastState.Bounded env8888 := by
  intro p hp
  have h : env8888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8887_8888 : H12AffineEnvironment.transform 1 0 env8887 = env8888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env8887 == env8888) = true)

def env8889 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,4096,8192,16384,8200,65536,4096,262144,4645,8200,64,356417,4721,90201,8240,21041,278624,335920,335921,75786,4,282714,4645,73770,78410,90747]

theorem envBound8889 : H12AffineFastState.Bounded env8889 := by
  intro p hp
  have h : env8889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8867_8889 : H12AffineEnvironment.transform 6 57 env8867 = env8889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env8867 == env8889) = true)

theorem identity8889 : scanCanonicalize (H12AffineFastState.compose env8889 (packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS)) = affineNative (2^(15+1) ^^^ 28779) := by decide +kernel

theorem selectedBound8889 : packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS < 2^1333 := by decide +kernel

def env8890 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,4096,8192,16384,8200,28779,4096,262144,4645,8200,64,262186,4721,4146,8240,21041,278624,282715,282714,22625,4,282714,4645,20545,16929,4624]

theorem envBound8890 : H12AffineFastState.Bounded env8890 := by
  intro p hp
  have h : env8890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8889_8890 : H12AffineEnvironment.transform 15 28779 env8889 = env8890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28779 env8889 == env8890) = true)

def env8891 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,4096,8192,4640,8200,8779,4096,262144,4645,8200,64,262186,4721,4146,8240,17,266816,262779,262778,2625,4,262778,4645,609,4097,4624]

theorem envBound8891 : H12AffineFastState.Bounded env8891 := by
  intro p hp
  have h : env8891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8890_8891 : H12AffineEnvironment.transform 13 4640 env8890 = env8891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4640 env8890 == env8891) = true)

def env8892 : List Nat := [2,4,8,16,32,0,57,4,512,4,2048,4096,8192,4640,8200,8715,4096,262144,4645,8200,0,262186,4657,4146,8240,17,266752,262715,262714,2561,4,262714,4645,545,4097,4624]

theorem envBound8892 : H12AffineFastState.Bounded env8892 := by
  intro p hp
  have h : env8892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8891_8892 : H12AffineEnvironment.transform 5 0 env8891 = env8892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env8891 == env8892) = true)

theorem identity8892 : scanCanonicalize (H12AffineFastState.compose env8892 (packedSelected [2,3,8,11,12,13,15,17,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound8892 : packedSelected [2,3,8,11,12,13,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env8893 : List Nat := [2,4,8,16,32,0,57,4,512,4,58,4096,8192,4640,8200,8715,4096,262144,4645,8200,0,262186,4657,4146,8240,17,266752,262715,262714,571,4,262714,4645,545,4097,4624]

theorem envBound8893 : H12AffineFastState.Bounded env8893 := by
  intro p hp
  have h : env8893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8892_8893 : H12AffineEnvironment.transform 10 58 env8892 = env8893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env8892 == env8893) = true)

theorem identity8893 : scanCanonicalize (H12AffineFastState.compose env8893 (packedSelected [0,1,5,7,10,12,14,15,20] rootPS)) = affineNative (2^(17+1) ^^^ 4666) := by decide +kernel

theorem selectedBound8893 : packedSelected [0,1,5,7,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env8894 : List Nat := [2,4,8,16,32,0,57,4,512,4,58,4096,8192,4640,8200,8715,4096,4666,4645,8200,0,4624,4657,4146,8240,17,58,4097,4096,571,4,4096,4645,545,4097,4624]

theorem envBound8894 : H12AffineFastState.Bounded env8894 := by
  intro p hp
  have h : env8894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8893_8894 : H12AffineEnvironment.transform 17 4666 env8893 = env8894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4666 env8893 == env8894) = true)

theorem identity8894 : scanCanonicalize (H12AffineFastState.compose env8894 (packedSelected [14] rootPS)) = affineNative (2^(11+1) ^^^ 561) := by decide +kernel

theorem selectedBound8894 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env8895 : List Nat := [2,4,8,16,32,0,57,4,512,4,58,561,8192,17,8200,8715,561,11,20,8200,0,33,0,515,8240,17,58,560,561,571,4,561,20,545,560,33]

theorem envBound8895 : H12AffineFastState.Bounded env8895 := by
  intro p hp
  have h : env8895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8894_8895 : H12AffineEnvironment.transform 11 561 env8894 = env8895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 561 env8894 == env8895) = true)

theorem identity8895 : scanCanonicalize (H12AffineFastState.compose env8895 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound8895 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env8896 : List Nat := [2,4,8,16,32,0,57,4,1,4,58,48,8192,17,8200,8202,48,11,20,8200,0,33,0,2,8240,17,58,49,48,58,4,48,20,32,49,33]

theorem envBound8896 : H12AffineFastState.Bounded env8896 := by
  intro p hp
  have h : env8896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8895_8896 : H12AffineEnvironment.transform 8 1 env8895 = env8896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env8895 == env8896) = true)

theorem identity8896 : scanCanonicalize (H12AffineFastState.compose env8896 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound8896 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env8897 : List Nat := [2,4,8,16,26,0,3,4,1,4,0,10,8192,17,8200,8202,10,11,20,8200,0,27,0,2,8202,17,0,11,10,0,4,10,20,26,11,27]

theorem envBound8897 : H12AffineFastState.Bounded env8897 := by
  intro p hp
  have h : env8897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8896_8897 : H12AffineEnvironment.transform 4 26 env8896 = env8897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env8896 == env8897) = true)

theorem identity8897 : scanCanonicalize (H12AffineFastState.compose env8897 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound8897 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env8898 : List Nat := [2,4,8,16,26,0,3,4,1,4,0,10,9,17,1,3,10,11,20,1,0,27,0,2,3,17,0,11,10,0,4,10,20,26,11,27]

theorem envBound8898 : H12AffineFastState.Bounded env8898 := by
  intro p hp
  have h : env8898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8897_8898 : H12AffineEnvironment.transform 12 9 env8897 = env8898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env8897 == env8898) = true)

theorem identity8898 : scanCanonicalize (H12AffineFastState.compose env8898 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound8898 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8899 : List Nat := [2,4,8,10,0,0,3,4,1,4,0,10,9,11,1,3,10,11,14,1,0,1,0,2,3,11,0,11,10,0,4,10,14,0,11,1]

theorem envBound8899 : H12AffineFastState.Bounded env8899 := by
  intro p hp
  have h : env8899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8898_8899 : H12AffineEnvironment.transform 3 10 env8898 = env8899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env8898 == env8899) = true)

def env8900 : List Nat := [2,4,8,16,32,1,57,5,512,5,2048,4096,8192,4640,8200,8714,4096,262144,4645,8200,1,262186,4656,4146,8240,17,266753,262714,262715,2560,4,262715,4645,544,4097,4624]

theorem envBound8900 : H12AffineFastState.Bounded env8900 := by
  intro p hp
  have h : env8900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8891_8900 : H12AffineEnvironment.transform 5 1 env8891 = env8900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env8891 == env8900) = true)

theorem identity8900 : scanCanonicalize (H12AffineFastState.compose env8900 (packedSelected [2,3,8,11,12,13,15,17,18,19] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound8900 : packedSelected [2,3,8,11,12,13,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env8901 : List Nat := [2,4,8,16,32,1,57,5,512,5,2048,4096,8192,4640,8200,8714,4096,2081,4645,8200,1,2059,4656,4146,8240,17,6688,2587,2586,2560,4,2586,4645,544,4097,4624]

theorem envBound8901 : H12AffineFastState.Bounded env8901 := by
  intro p hp
  have h : env8901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8900_8901 : H12AffineEnvironment.transform 17 2081 env8900 = env8901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env8900 == env8901) = true)

theorem identity8901 : scanCanonicalize (H12AffineFastState.compose env8901 (packedSelected [0,1,5,7,10,12,14,15,20] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound8901 : packedSelected [0,1,5,7,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env8902 : List Nat := [2,4,8,16,32,1,57,5,512,5,522,4096,8192,4640,8200,8714,4096,555,4645,8200,1,513,4656,4146,8240,17,4138,17,16,10,4,16,4645,544,4097,4624]

theorem envBound8902 : H12AffineFastState.Bounded env8902 := by
  intro p hp
  have h : env8902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8901_8902 : H12AffineEnvironment.transform 10 522 env8901 = env8902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env8901 == env8902) = true)

theorem identity8902 : scanCanonicalize (H12AffineFastState.compose env8902 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 545) := by decide +kernel

theorem selectedBound8902 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env8903 : List Nat := [2,4,8,16,32,1,57,5,512,5,522,545,8192,1,8200,8714,545,555,4,8200,1,513,17,531,8240,17,523,17,16,10,4,16,4,544,544,49]

theorem envBound8903 : H12AffineFastState.Bounded env8903 := by
  intro p hp
  have h : env8903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8902_8903 : H12AffineEnvironment.transform 11 545 env8902 = env8903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env8902 == env8903) = true)

theorem identity8903 : scanCanonicalize (H12AffineFastState.compose env8903 (packedSelected [0,3,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound8903 : packedSelected [0,3,7,8] rootPS < 2^1333 := by decide +kernel

def env8904 : List Nat := [2,4,8,16,32,1,57,5,11,5,1,42,8192,1,8200,8193,42,32,4,8200,1,10,17,24,8240,17,0,17,16,10,4,16,4,43,43,49]

theorem envBound8904 : H12AffineFastState.Bounded env8904 := by
  intro p hp
  have h : env8904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8903_8904 : H12AffineEnvironment.transform 8 11 env8903 = env8904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env8903 == env8904) = true)

theorem identity8904 : scanCanonicalize (H12AffineFastState.compose env8904 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 57) := by decide +kernel

theorem selectedBound8904 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env8905 : List Nat := [2,4,8,16,32,1,57,5,11,5,1,42,57,1,49,56,42,32,4,49,1,10,17,24,9,17,0,17,16,10,4,16,4,43,43,49]

theorem envBound8905 : H12AffineFastState.Bounded env8905 := by
  intro p hp
  have h : env8905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8904_8905 : H12AffineEnvironment.transform 12 57 env8904 = env8905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 57 env8904 == env8905) = true)

theorem identity8905 : scanCanonicalize (H12AffineFastState.compose env8905 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound8905 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8906 : List Nat := [2,4,8,16,16,1,9,5,11,5,1,26,9,1,1,8,26,16,4,1,1,10,17,24,9,17,0,17,16,10,4,16,4,27,27,1]

theorem envBound8906 : H12AffineFastState.Bounded env8906 := by
  intro p hp
  have h : env8906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8905_8906 : H12AffineEnvironment.transform 4 16 env8905 = env8906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env8905 == env8906) = true)

theorem identity8906 : scanCanonicalize (H12AffineFastState.compose env8906 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound8906 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8907 : List Nat := [2,4,8,10,10,1,9,5,11,5,1,0,9,1,1,8,0,10,4,1,1,10,11,2,9,11,0,11,10,10,4,10,4,1,1,1]

theorem envBound8907 : H12AffineFastState.Bounded env8907 := by
  intro p hp
  have h : env8907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8906_8907 : H12AffineEnvironment.transform 3 10 env8906 = env8907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env8906 == env8907) = true)

theorem identity8907 : scanCanonicalize (H12AffineFastState.compose env8907 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8907 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8908 : List Nat := [2,4,2,0,0,1,3,5,1,5,1,0,3,1,1,2,0,0,4,1,1,0,1,2,3,1,0,1,0,0,4,0,4,1,1,1]

theorem envBound8908 : H12AffineFastState.Bounded env8908 := by
  intro p hp
  have h : env8908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8907_8908 : H12AffineEnvironment.transform 2 2 env8907 = env8908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8907 == env8908) = true)

def env8909 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,4096,8192,4641,8200,8778,4096,262144,4645,8200,64,262186,4721,4146,8240,16,266817,262778,262779,2624,4,262779,4645,608,4096,4624]

theorem envBound8909 : H12AffineFastState.Bounded env8909 := by
  intro p hp
  have h : env8909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8890_8909 : H12AffineEnvironment.transform 13 4641 env8890 = env8909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4641 env8890 == env8909) = true)

def env8910 : List Nat := [2,4,8,16,32,0,57,4,512,4,2048,4096,8192,4641,8200,8714,4096,262144,4645,8200,0,262186,4657,4146,8240,16,266753,262714,262715,2560,4,262715,4645,544,4096,4624]

theorem envBound8910 : H12AffineFastState.Bounded env8910 := by
  intro p hp
  have h : env8910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8909_8910 : H12AffineEnvironment.transform 5 0 env8909 = env8910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env8909 == env8910) = true)

theorem identity8910 : scanCanonicalize (H12AffineFastState.compose env8910 (packedSelected [2,3,8,11,12,13,15,17,18,19] rootPS)) = affineNative (2^(11+1) ^^^ 2586) := by decide +kernel

theorem selectedBound8910 : packedSelected [2,3,8,11,12,13,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env8911 : List Nat := [2,4,8,16,32,0,57,4,512,4,2048,2586,8192,2107,8200,8714,2586,262144,2111,8200,0,262186,2091,2600,8240,16,264219,262714,262715,2560,4,262715,2111,544,2586,2058]

theorem envBound8911 : H12AffineFastState.Bounded env8911 := by
  intro p hp
  have h : env8911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8910_8911 : H12AffineEnvironment.transform 11 2586 env8910 = env8911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2586 env8910 == env8911) = true)

theorem identity8911 : scanCanonicalize (H12AffineFastState.compose env8911 (packedSelected [0,1,5,7,10,12,14,15,20] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound8911 : packedSelected [0,1,5,7,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env8912 : List Nat := [2,4,8,16,32,0,57,4,49,4,2048,2091,8192,2107,8200,8251,2091,262144,2111,8200,0,262186,2091,2073,8240,16,264219,262155,262154,2097,4,262154,2111,17,2091,2058]

theorem envBound8912 : H12AffineFastState.Bounded env8912 := by
  intro p hp
  have h : env8912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8911_8912 : H12AffineEnvironment.transform 8 49 env8911 = env8912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env8911 == env8912) = true)

theorem identity8912 : scanCanonicalize (H12AffineFastState.compose env8912 (packedSelected [0,2,4,5,8] rootPS)) = affineNative (2^(17+1) ^^^ 10) := by decide +kernel

theorem selectedBound8912 : packedSelected [0,2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env8913 : List Nat := [2,4,8,16,32,0,57,4,49,4,2048,2091,8192,2107,8200,8251,2091,10,2111,8200,0,32,2091,2073,8240,16,2065,1,0,2097,4,0,2111,17,2091,2058]

theorem envBound8913 : H12AffineFastState.Bounded env8913 := by
  intro p hp
  have h : env8913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8912_8913 : H12AffineEnvironment.transform 17 10 env8912 = env8913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10 env8912 == env8913) = true)

theorem identity8913 : scanCanonicalize (H12AffineFastState.compose env8913 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound8913 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env8914 : List Nat := [2,4,8,16,32,0,57,4,49,4,43,0,8192,16,8200,8251,0,10,20,8200,0,32,0,50,8240,16,58,1,0,26,4,0,20,17,0,33]

theorem envBound8914 : H12AffineFastState.Bounded env8914 := by
  intro p hp
  have h : env8914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8913_8914 : H12AffineEnvironment.transform 10 43 env8913 = env8914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env8913 == env8914) = true)

theorem identity8914 : scanCanonicalize (H12AffineFastState.compose env8914 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 50) := by decide +kernel

theorem selectedBound8914 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8915 : List Nat := [2,4,8,16,32,0,57,4,49,4,43,0,50,16,58,9,0,10,20,58,0,32,0,50,2,16,58,1,0,26,4,0,20,17,0,33]

theorem envBound8915 : H12AffineFastState.Bounded env8915 := by
  intro p hp
  have h : env8915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8914_8915 : H12AffineEnvironment.transform 12 50 env8914 = env8915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 50 env8914 == env8915) = true)

theorem identity8915 : scanCanonicalize (H12AffineFastState.compose env8915 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound8915 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8916 : List Nat := [2,4,8,16,10,0,19,4,27,4,1,0,24,16,16,9,0,10,20,16,0,10,0,24,2,16,16,1,0,26,4,0,20,17,0,11]

theorem envBound8916 : H12AffineFastState.Bounded env8916 := by
  intro p hp
  have h : env8916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8915_8916 : H12AffineEnvironment.transform 4 10 env8915 = env8916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env8915 == env8916) = true)

theorem identity8916 : scanCanonicalize (H12AffineFastState.compose env8916 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8916 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env8917 : List Nat := [2,4,2,16,0,0,19,4,17,4,1,0,18,16,16,3,0,0,20,16,0,0,0,18,2,16,16,1,0,16,4,0,20,17,0,1]

theorem envBound8917 : H12AffineFastState.Bounded env8917 := by
  intro p hp
  have h : env8917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8916_8917 : H12AffineEnvironment.transform 2 2 env8916 = env8917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8916 == env8917) = true)

theorem identity8917 : scanCanonicalize (H12AffineFastState.compose env8917 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8917 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8918 : List Nat := [2,4,2,0,0,0,3,4,1,4,1,0,2,0,0,3,0,0,4,0,0,0,0,2,2,0,0,1,0,0,4,0,4,1,0,1]

theorem envBound8918 : H12AffineFastState.Bounded env8918 := by
  intro p hp
  have h : env8918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8917_8918 : H12AffineEnvironment.transform 3 0 env8917 = env8918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8917 == env8918) = true)

def env8919 : List Nat := [2,4,8,16,32,1,57,5,512,5,2048,4096,8192,4641,8200,8715,4096,262144,4645,8200,1,262186,4656,4146,8240,16,266752,262715,262714,2561,4,262714,4645,545,4096,4624]

theorem envBound8919 : H12AffineFastState.Bounded env8919 := by
  intro p hp
  have h : env8919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8909_8919 : H12AffineEnvironment.transform 5 1 env8909 = env8919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env8909 == env8919) = true)

theorem identity8919 : scanCanonicalize (H12AffineFastState.compose env8919 (packedSelected [2,3,8,11,12,13,15,17,18,19] rootPS)) = affineNative (2^(17+1) ^^^ 6657) := by decide +kernel

theorem selectedBound8919 : packedSelected [2,3,8,11,12,13,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env8920 : List Nat := [2,4,8,16,32,1,57,5,512,5,2048,4096,8192,4641,8200,8715,4096,6657,4645,8200,1,6699,4656,4146,8240,16,2049,6202,6203,2561,4,6203,4645,545,4096,4624]

theorem envBound8920 : H12AffineFastState.Bounded env8920 := by
  intro p hp
  have h : env8920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8919_8920 : H12AffineEnvironment.transform 17 6657 env8919 = env8920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6657 env8919 == env8920) = true)

theorem identity8920 : scanCanonicalize (H12AffineFastState.compose env8920 (packedSelected [0,1,5,7,10,12,14,15,20] rootPS)) = affineNative (2^(11+1) ^^^ 544) := by decide +kernel

theorem selectedBound8920 : packedSelected [0,1,5,7,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env8921 : List Nat := [2,4,8,16,32,1,57,5,512,5,2048,544,8192,1,8200,8715,544,2081,5,8200,1,2059,16,530,8240,16,2049,2586,2587,2561,4,2587,5,545,544,48]

theorem envBound8921 : H12AffineFastState.Bounded env8921 := by
  intro p hp
  have h : env8921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8920_8921 : H12AffineEnvironment.transform 11 544 env8920 = env8921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env8920 == env8921) = true)

theorem identity8921 : scanCanonicalize (H12AffineFastState.compose env8921 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound8921 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env8922 : List Nat := [2,4,8,16,32,1,57,5,512,5,523,544,8192,1,8200,8715,544,554,5,8200,1,512,16,530,8240,16,522,17,16,10,4,16,5,545,544,48]

theorem envBound8922 : H12AffineFastState.Bounded env8922 := by
  intro p hp
  have h : env8922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8921_8922 : H12AffineEnvironment.transform 10 523 env8921 = env8922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env8921 == env8922) = true)

theorem identity8922 : scanCanonicalize (H12AffineFastState.compose env8922 (packedSelected [0,3,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8922 : packedSelected [0,3,7,8] rootPS < 2^1333 := by decide +kernel

def env8923 : List Nat := [2,4,8,16,1,1,24,5,512,5,523,513,8192,1,8200,8715,513,523,5,8200,1,512,16,530,8209,16,522,17,16,10,4,16,5,512,513,17]

theorem envBound8923 : H12AffineFastState.Bounded env8923 := by
  intro p hp
  have h : env8923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8922_8923 : H12AffineEnvironment.transform 4 1 env8922 = env8923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8922 == env8923) = true)

theorem identity8923 : scanCanonicalize (H12AffineFastState.compose env8923 (packedSelected [2,3,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound8923 : packedSelected [2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env8924 : List Nat := [2,4,8,16,1,1,24,5,512,5,523,513,24,1,16,531,513,523,5,16,1,512,16,530,9,16,522,17,16,10,4,16,5,512,513,17]

theorem envBound8924 : H12AffineFastState.Bounded env8924 := by
  intro p hp
  have h : env8924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8923_8924 : H12AffineEnvironment.transform 12 24 env8923 = env8924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env8923 == env8924) = true)

theorem identity8924 : scanCanonicalize (H12AffineFastState.compose env8924 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8924 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8925 : List Nat := [2,4,2,16,1,1,18,5,512,5,513,513,18,1,16,531,513,513,5,16,1,512,16,530,3,16,512,17,16,0,4,16,5,512,513,17]

theorem envBound8925 : H12AffineFastState.Bounded env8925 := by
  intro p hp
  have h : env8925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8924_8925 : H12AffineEnvironment.transform 2 2 env8924 = env8925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8924 == env8925) = true)

theorem identity8925 : scanCanonicalize (H12AffineFastState.compose env8925 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound8925 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8926 : List Nat := [2,4,2,16,1,1,18,5,0,5,1,1,18,1,16,19,1,1,5,16,1,0,16,18,3,16,0,17,16,0,4,16,5,0,1,17]

theorem envBound8926 : H12AffineFastState.Bounded env8926 := by
  intro p hp
  have h : env8926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8925_8926 : H12AffineEnvironment.transform 8 0 env8925 = env8926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env8925 == env8926) = true)

def env8927 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8200,65536,4096,262144,4764,8200,65,4194304,4721,90336,8329,21041,278624,4214984,4214985,75786,4,4268194,4764,73770,78578,90818]

theorem envBound8927 : H12AffineFastState.Bounded env8927 := by
  intro p hp
  have h : env8927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8865_8927 : H12AffineEnvironment.transform 20 65 env8865 = env8927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env8865 == env8927) = true)

theorem identity8927 : scanCanonicalize (H12AffineFastState.compose env8927 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 352921) := by decide +kernel

theorem selectedBound8927 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8928 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8200,65536,4096,262144,4764,8200,65,352921,4721,90336,8329,21041,278624,340561,340560,75786,4,279099,4764,73770,78578,90818]

theorem envBound8928 : H12AffineFastState.Bounded env8928 := by
  intro p hp
  have h : env8928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8927_8928 : H12AffineEnvironment.transform 21 352921 env8927 = env8928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 352921 env8927 == env8928) = true)

def env8929 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8200,65536,4096,73944,4764,8200,65,16961,4721,90336,8329,21041,90296,4745,4744,75786,4,90851,4764,73770,78578,90818]

theorem envBound8929 : H12AffineFastState.Bounded env8929 := by
  intro p hp
  have h : env8929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8928_8929 : H12AffineEnvironment.transform 17 73944 env8928 = env8929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 73944 env8928 == env8929) = true)

def env8930 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,560,8200,65536,4096,73944,4764,8200,65,113,4721,74448,8329,4097,74376,4745,4744,75786,4,73939,4764,73770,78578,73970]

theorem envBound8930 : H12AffineFastState.Bounded env8930 := by
  intro p hp
  have h : env8930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8929_8930 : H12AffineEnvironment.transform 13 560 env8929 = env8930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env8929 == env8930) = true)

theorem identity8930 : scanCanonicalize (H12AffineFastState.compose env8930 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8947) := by decide +kernel

theorem selectedBound8930 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8931 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,560,8200,8947,4096,555,4764,8200,65,113,4721,35,8329,4097,123,4745,4744,2809,4,544,4764,729,4097,513]

theorem envBound8931 : H12AffineFastState.Bounded env8931 := by
  intro p hp
  have h : env8931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8930_8931 : H12AffineEnvironment.transform 15 8947 env8930 = env8931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8947 env8930 == env8931) = true)

theorem identity8931 : scanCanonicalize (H12AffineFastState.compose env8931 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2090) := by decide +kernel

theorem selectedBound8931 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env8932 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,2090,8192,560,8200,8947,2090,555,2742,8200,65,113,2651,35,8329,2091,123,2723,2722,2809,4,544,2742,729,2091,513]

theorem envBound8932 : H12AffineFastState.Bounded env8932 := by
  intro p hp
  have h : env8932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8931_8932 : H12AffineEnvironment.transform 11 2090 env8931 = env8932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2090 env8931 == env8932) = true)

theorem identity8932 : scanCanonicalize (H12AffineFastState.compose env8932 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound8932 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env8933 : List Nat := [2,4,8,16,32,64,128,253,136,253,2048,2090,8192,184,8200,8315,2090,163,2110,8200,65,113,2259,35,8329,2091,123,2091,2090,2161,4,168,2110,81,2091,137]

theorem envBound8933 : H12AffineFastState.Bounded env8933 := by
  intro p hp
  have h : env8933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8932_8933 : H12AffineEnvironment.transform 8 136 env8932 = env8933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env8932 == env8933) = true)

theorem identity8933 : scanCanonicalize (H12AffineFastState.compose env8933 (packedSelected [2,13,14] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8933 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env8934 : List Nat := [2,4,8,0,32,64,128,237,136,237,2048,2090,8192,168,8200,8299,2090,163,2094,8200,65,97,2243,35,8329,2091,107,2091,2090,2145,4,168,2094,65,2091,137]

theorem envBound8934 : H12AffineFastState.Bounded env8934 := by
  intro p hp
  have h : env8934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8933_8934 : H12AffineEnvironment.transform 3 0 env8933 = env8934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8933 == env8934) = true)

theorem identity8934 : scanCanonicalize (H12AffineFastState.compose env8934 (packedSelected [0,1,2,3,5,7,8,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 2187) := by decide +kernel

theorem selectedBound8934 : packedSelected [0,1,2,3,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env8935 : List Nat := [2,4,8,0,32,64,128,237,136,237,2048,2090,2187,168,2179,2272,2090,163,2094,2179,65,97,2243,35,2050,2091,107,2091,2090,2145,4,168,2094,65,2091,137]

theorem envBound8935 : H12AffineFastState.Bounded env8935 := by
  intro p hp
  have h : env8935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8934_8935 : H12AffineEnvironment.transform 12 2187 env8934 = env8935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2187 env8934 == env8935) = true)

theorem identity8935 : scanCanonicalize (H12AffineFastState.compose env8935 (packedSelected [0,1,2,4,5,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound8935 : packedSelected [0,1,2,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env8936 : List Nat := [2,4,8,0,32,64,40,69,32,69,2048,2090,2083,0,2091,2120,2090,11,2094,2091,65,97,2155,35,2050,2091,107,2091,2090,2145,4,0,2094,65,2091,33]

theorem envBound8936 : H12AffineFastState.Bounded env8936 := by
  intro p hp
  have h : env8936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8935_8936 : H12AffineEnvironment.transform 6 40 env8935 = env8936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env8935 == env8936) = true)

theorem identity8936 : scanCanonicalize (H12AffineFastState.compose env8936 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound8936 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8937 : List Nat := [2,4,8,0,32,64,40,69,32,69,1,43,34,0,42,73,43,11,47,42,65,97,106,35,3,42,107,42,43,96,4,0,47,65,42,33]

theorem envBound8937 : H12AffineFastState.Bounded env8937 := by
  intro p hp
  have h : env8937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8936_8937 : H12AffineEnvironment.transform 10 1 env8936 = env8937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env8936 == env8937) = true)

theorem identity8937 : scanCanonicalize (H12AffineFastState.compose env8937 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound8937 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8938 : List Nat := [2,4,8,0,15,64,7,69,15,69,1,4,13,0,5,73,4,11,0,5,65,78,69,12,3,5,68,5,4,79,4,0,0,65,5,14]

theorem envBound8938 : H12AffineFastState.Bounded env8938 := by
  intro p hp
  have h : env8938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8937_8938 : H12AffineEnvironment.transform 4 15 env8937 = env8938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env8937 == env8938) = true)

theorem identity8938 : scanCanonicalize (H12AffineFastState.compose env8938 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 15) := by decide +kernel

theorem selectedBound8938 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env8939 : List Nat := [2,4,8,0,15,15,7,10,15,10,1,4,13,0,5,6,4,11,0,5,14,1,10,12,3,5,11,5,4,0,4,0,0,14,5,14]

theorem envBound8939 : H12AffineFastState.Bounded env8939 := by
  intro p hp
  have h : env8939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8938_8939 : H12AffineEnvironment.transform 5 15 env8938 = env8939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 15 env8938 == env8939) = true)

theorem identity8939 : scanCanonicalize (H12AffineFastState.compose env8939 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8939 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8940 : List Nat := [2,4,2,0,5,5,7,0,5,0,1,4,7,0,5,6,4,1,0,5,4,1,0,6,3,5,1,5,4,0,4,0,0,4,5,4]

theorem envBound8940 : H12AffineFastState.Bounded env8940 := by
  intro p hp
  have h : env8940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8939_8940 : H12AffineEnvironment.transform 2 2 env8939 = env8940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8939 == env8940) = true)

def env8941 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,561,8200,65536,4096,73944,4764,8200,65,112,4721,74449,8329,4096,74377,4745,4744,75786,4,73938,4764,73770,78578,73971]

theorem envBound8941 : H12AffineFastState.Bounded env8941 := by
  intro p hp
  have h : env8941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8929_8941 : H12AffineEnvironment.transform 13 561 env8929 = env8941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env8929 == env8941) = true)

theorem identity8941 : scanCanonicalize (H12AffineFastState.compose env8941 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8714) := by decide +kernel

theorem selectedBound8941 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8942 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,561,8200,8714,4096,722,4764,8200,65,112,4721,219,8329,4096,131,4745,4744,2560,4,728,4764,544,4344,761]

theorem envBound8942 : H12AffineFastState.Bounded env8942 := by
  intro p hp
  have h : env8942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8941_8942 : H12AffineEnvironment.transform 15 8714 env8941 = env8942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8714 env8941 == env8942) = true)

theorem identity8942 : scanCanonicalize (H12AffineFastState.compose env8942 (packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound8942 : packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env8943 : List Nat := [2,4,8,16,32,64,128,253,137,253,2048,4096,8192,184,8200,8323,4096,91,4117,8200,65,112,4344,219,8329,4096,131,4096,4097,2185,4,81,4117,169,4344,112]

theorem envBound8943 : H12AffineFastState.Bounded env8943 := by
  intro p hp
  have h : env8943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8942_8943 : H12AffineEnvironment.transform 8 137 env8942 = env8943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env8942 == env8943) = true)

theorem identity8943 : scanCanonicalize (H12AffineFastState.compose env8943 (packedSelected [2,11,13,14,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound8943 : packedSelected [2,11,13,14,17,18] rootPS < 2^1333 := by decide +kernel

def env8944 : List Nat := [2,4,8,16,32,64,121,4,112,4,2048,4096,8192,65,8200,8314,4096,91,4117,8200,65,112,4097,34,8304,4096,122,4096,4097,2160,4,81,4117,80,4097,112]

theorem envBound8944 : H12AffineFastState.Bounded env8944 := by
  intro p hp
  have h : env8944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8943_8944 : H12AffineEnvironment.transform 6 121 env8943 = env8944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env8943 == env8944) = true)

theorem identity8944 : scanCanonicalize (H12AffineFastState.compose env8944 (packedSelected [1,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound8944 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env8945 : List Nat := [2,4,8,16,32,64,121,4,112,4,2048,4096,25,65,17,99,4096,91,4117,17,65,112,4097,34,105,4096,122,4096,4097,2160,4,81,4117,80,4097,112]

theorem envBound8945 : H12AffineFastState.Bounded env8945 := by
  intro p hp
  have h : env8945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8944_8945 : H12AffineEnvironment.transform 12 25 env8944 = env8945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env8944 == env8945) = true)

theorem identity8945 : scanCanonicalize (H12AffineFastState.compose env8945 (packedSelected [2,13,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound8945 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env8946 : List Nat := [2,4,8,16,32,17,40,4,33,4,2048,4096,25,16,17,50,4096,10,4117,17,16,33,4097,34,56,4096,43,4096,4097,2081,4,0,4117,1,4097,33]

theorem envBound8946 : H12AffineFastState.Bounded env8946 := by
  intro p hp
  have h : env8946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8945_8946 : H12AffineEnvironment.transform 5 17 env8945 = env8946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8945 == env8946) = true)

theorem identity8946 : scanCanonicalize (H12AffineFastState.compose env8946 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound8946 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8947 : List Nat := [2,4,8,16,32,17,40,4,33,4,2048,2064,25,16,17,50,2064,10,2053,17,16,33,2065,34,56,2064,43,2064,2065,2081,4,0,2053,1,2065,33]

theorem envBound8947 : H12AffineFastState.Bounded env8947 := by
  intro p hp
  have h : env8947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8946_8947 : H12AffineEnvironment.transform 11 2064 env8946 = env8947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env8946 == env8947) = true)

theorem identity8947 : scanCanonicalize (H12AffineFastState.compose env8947 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound8947 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env8948 : List Nat := [2,4,8,16,32,17,40,4,33,4,42,58,25,16,17,50,58,10,47,17,16,33,59,34,56,58,43,58,59,11,4,0,47,1,59,33]

theorem envBound8948 : H12AffineFastState.Bounded env8948 := by
  intro p hp
  have h : env8948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8947_8948 : H12AffineEnvironment.transform 10 42 env8947 = env8948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env8947 == env8948) = true)

theorem identity8948 : scanCanonicalize (H12AffineFastState.compose env8948 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound8948 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env8949 : List Nat := [2,4,8,11,32,10,40,4,33,4,42,33,2,11,10,41,33,10,47,10,11,33,32,34,35,33,43,33,32,11,4,0,47,1,32,33]

theorem envBound8949 : H12AffineFastState.Bounded env8949 := by
  intro p hp
  have h : env8949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8948_8949 : H12AffineEnvironment.transform 3 11 env8948 = env8949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env8948 == env8949) = true)

theorem identity8949 : scanCanonicalize (H12AffineFastState.compose env8949 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8949 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8950 : List Nat := [2,4,8,11,0,10,8,4,1,4,10,1,2,11,10,9,1,10,15,10,11,1,0,2,3,1,11,1,0,11,4,0,15,1,0,1]

theorem envBound8950 : H12AffineFastState.Bounded env8950 := by
  intro p hp
  have h : env8950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8949_8950 : H12AffineEnvironment.transform 4 0 env8949 = env8950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8949 == env8950) = true)

theorem identity8950 : scanCanonicalize (H12AffineFastState.compose env8950 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8950 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env8951 : List Nat := [2,4,3,0,0,1,3,4,1,4,1,1,2,0,1,2,1,1,4,1,0,1,0,2,3,1,0,1,0,0,4,0,4,1,0,1]

theorem envBound8951 : H12AffineFastState.Bounded env8951 := by
  intro p hp
  have h : env8951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8950_8951 : H12AffineEnvironment.transform 2 3 env8950 = env8951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8950 == env8951) = true)

def env8952 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8200,65536,4096,73945,4764,8200,65,16960,4721,90336,8329,21041,90297,4744,4745,75786,4,90850,4764,73770,78578,90818]

theorem envBound8952 : H12AffineFastState.Bounded env8952 := by
  intro p hp
  have h : env8952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0