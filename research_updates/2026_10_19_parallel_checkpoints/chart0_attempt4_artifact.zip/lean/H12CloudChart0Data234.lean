import H12CloudChart0Data233

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans59361_59362 : H12AffineEnvironment.transform 17 308 env59361 = env59362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 308 env59361 == env59362) = true)

theorem identity59362 : scanCanonicalize (H12AffineFastState.compose env59362 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound59362 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59363 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1529,1409,1449,1449,1063,1165,308,1025,1449,509,1416,65,431,1289,16,445,1448,1245,372,1057,33,256,1197,1165,1]

theorem envBound59363 : H12AffineFastState.Bounded env59363 := by
  intro p hp
  have h : env59363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59362_59363 : H12AffineEnvironment.transform 15 1063 env59362 = env59363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env59362 == env59363) = true)

theorem identity59363 : scanCanonicalize (H12AffineFastState.compose env59363 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound59363 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59364 : List Nat := [2,4,8,16,32,64,128,252,0,1024,1029,1029,1149,1109,1109,1063,1165,200,1025,1109,1,1140,65,83,1269,16,65,1108,1245,136,1057,33,252,1197,1165,1]

theorem envBound59364 : H12AffineFastState.Bounded env59364 := by
  intro p hp
  have h : env59364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59363_59364 : H12AffineEnvironment.transform 7 252 env59363 = env59364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env59363 == env59364) = true)

theorem identity59364 : scanCanonicalize (H12AffineFastState.compose env59364 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound59364 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59365 : List Nat := [2,4,8,16,32,64,128,252,0,140,137,137,241,217,217,171,1,200,141,217,1,248,65,83,121,16,65,216,81,136,173,33,252,33,1,1]

theorem envBound59365 : H12AffineFastState.Bounded env59365 := by
  intro p hp
  have h : env59365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59364_59365 : H12AffineEnvironment.transform 9 140 env59364 = env59365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env59364 == env59365) = true)

theorem identity59365 : scanCanonicalize (H12AffineFastState.compose env59365 (packedSelected [0,3,4,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound59365 : packedSelected [0,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env59366 : List Nat := [2,4,8,16,32,32,128,156,0,140,137,137,145,185,185,171,1,168,141,185,1,152,33,51,25,16,33,184,49,136,173,33,156,33,1,1]

theorem envBound59366 : H12AffineFastState.Bounded env59366 := by
  intro p hp
  have h : env59366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59365_59366 : H12AffineEnvironment.transform 5 32 env59365 = env59366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env59365 == env59366) = true)

theorem identity59366 : scanCanonicalize (H12AffineFastState.compose env59366 (packedSelected [3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 11) := by decide +kernel

theorem selectedBound59366 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env59367 : List Nat := [2,4,8,16,32,32,11,23,0,7,2,2,26,50,50,32,1,35,6,50,1,19,33,51,25,16,33,51,49,3,38,33,23,33,1,1]

theorem envBound59367 : H12AffineFastState.Bounded env59367 := by
  intro p hp
  have h : env59367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59366_59367 : H12AffineEnvironment.transform 6 11 env59366 = env59367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 11 env59366 == env59367) = true)

theorem identity59367 : scanCanonicalize (H12AffineFastState.compose env59367 (packedSelected [4,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound59367 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env59368 : List Nat := [2,4,8,16,11,11,11,23,0,7,2,2,26,25,25,11,1,8,6,25,1,19,10,24,25,16,10,24,26,3,13,10,23,10,1,1]

theorem envBound59368 : H12AffineFastState.Bounded env59368 := by
  intro p hp
  have h : env59368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59367_59368 : H12AffineEnvironment.transform 4 11 env59367 = env59368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env59367 == env59368) = true)

theorem identity59368 : scanCanonicalize (H12AffineFastState.compose env59368 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound59368 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env59369 : List Nat := [2,4,8,2,11,11,11,5,0,7,2,2,8,11,11,11,1,8,6,11,1,1,10,10,11,2,10,10,8,3,13,10,5,10,1,1]

theorem envBound59369 : H12AffineFastState.Bounded env59369 := by
  intro p hp
  have h : env59369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59368_59369 : H12AffineEnvironment.transform 3 2 env59368 = env59369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env59368 == env59369) = true)

theorem identity59369 : scanCanonicalize (H12AffineFastState.compose env59369 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59369 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59370 : List Nat := [1,4,8,1,8,8,8,5,0,4,1,1,8,8,8,8,1,8,5,8,1,1,9,9,8,1,9,9,8,0,13,9,5,9,1,1]

theorem envBound59370 : H12AffineFastState.Bounded env59370 := by
  intro p hp
  have h : env59370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59369_59370 : H12AffineEnvironment.transform 0 1 env59369 = env59370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59369 == env59370) = true)

def env59371 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9664,3159,1289,9617,2365813,4177,77954,66898,65542,68094,256,65674,78034,9601]

theorem envBound59371 : H12AffineFastState.Bounded env59371 := by
  intro p hp
  have h : env59371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59348_59371 : H12AffineEnvironment.transform 8 1 env59348 = env59371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59348 == env59371) = true)

theorem identity59371 : scanCanonicalize (H12AffineFastState.compose env59371 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 10628) := by decide +kernel

theorem selectedBound59371 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59372 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,10628,1416,9664,3159,1289,9617,274673,4177,77954,66898,65542,68094,256,65674,78034,9601]

theorem envBound59372 : H12AffineFastState.Bounded env59372 := by
  intro p hp
  have h : env59372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59371_59372 : H12AffineEnvironment.transform 20 10628 env59371 = env59372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 10628 env59371 == env59372) = true)

def env59373 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,3076,1416,64,3159,1289,17,267633,4177,70914,66898,65542,68094,256,65674,70994,1]

theorem envBound59373 : H12AffineFastState.Bounded env59373 := by
  intro p hp
  have h : env59373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59372_59373 : H12AffineEnvironment.transform 12 1408 env59372 = env59373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59372 == env59373) = true)

theorem identity59373 : scanCanonicalize (H12AffineFastState.compose env59373 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 5375) := by decide +kernel

theorem selectedBound59373 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59374 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,5375,429,262144,1025,2129,3076,1416,64,3159,1289,17,267633,4177,509,4525,5369,7425,256,5237,429,1]

theorem envBound59374 : H12AffineFastState.Bounded env59374 := by
  intro p hp
  have h : env59374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59373_59374 : H12AffineEnvironment.transform 15 5375 env59373 = env59374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5375 env59373 == env59374) = true)

theorem identity59374 : scanCanonicalize (H12AffineFastState.compose env59374 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6377) := by decide +kernel

theorem selectedBound59374 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59375 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,5375,429,6377,1025,2129,3076,1416,64,3159,1289,17,3480,4177,509,4525,5369,7425,256,5237,429,1]

theorem envBound59375 : H12AffineFastState.Bounded env59375 := by
  intro p hp
  have h : env59375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59374_59375 : H12AffineEnvironment.transform 17 6377 env59374 = env59375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6377 env59374 == env59375) = true)

theorem identity59375 : scanCanonicalize (H12AffineFastState.compose env59375 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 461) := by decide +kernel

theorem selectedBound59375 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59376 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,461,1408,413,2129,1330,429,2340,1025,2129,3076,1416,64,3159,1289,17,3480,412,509,96,1332,3276,256,1464,429,1]

theorem envBound59376 : H12AffineFastState.Bounded env59376 := by
  intro p hp
  have h : env59376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59375_59376 : H12AffineEnvironment.transform 11 461 env59375 = env59376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 461 env59375 == env59376) = true)

theorem identity59376 : scanCanonicalize (H12AffineFastState.compose env59376 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1260) := by decide +kernel

theorem selectedBound59376 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env59377 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1260,461,1408,413,1213,1330,429,1480,1025,1213,232,1416,64,187,1289,17,372,412,509,96,1332,32,256,1464,429,1]

theorem envBound59377 : H12AffineFastState.Bounded env59377 := by
  intro p hp
  have h : env59377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59376_59377 : H12AffineEnvironment.transform 10 1260 env59376 = env59377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1260 env59376 == env59377) = true)

theorem identity59377 : scanCanonicalize (H12AffineFastState.compose env59377 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59377 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59378 : List Nat := [2,4,8,16,17,64,128,256,1,1024,1245,461,1408,413,1164,1283,412,1480,1025,1164,217,1416,64,138,1289,17,325,412,460,81,1285,17,256,1417,412,1]

theorem envBound59378 : H12AffineFastState.Bounded env59378 := by
  intro p hp
  have h : env59378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59377_59378 : H12AffineEnvironment.transform 4 17 env59377 = env59378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59377 == env59378) = true)

theorem identity59378 : scanCanonicalize (H12AffineFastState.compose env59378 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound59378 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59379 : List Nat := [2,4,8,16,17,64,128,95,1,1024,1245,146,1247,194,1164,1116,195,1175,1025,1164,217,1239,64,138,1110,17,26,195,147,81,1114,17,95,1238,195,1]

theorem envBound59379 : H12AffineFastState.Bounded env59379 := by
  intro p hp
  have h : env59379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59378_59379 : H12AffineEnvironment.transform 7 95 env59378 = env59379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env59378 == env59379) = true)

theorem identity59379 : scanCanonicalize (H12AffineFastState.compose env59379 (packedSelected [0,5] rootPS)) = affineNative (2^(9+1) ^^^ 198) := by decide +kernel

theorem selectedBound59379 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59380 : List Nat := [2,4,8,16,17,64,128,95,1,198,27,146,25,194,74,154,195,81,199,74,217,17,64,138,144,17,26,195,147,81,156,17,95,16,195,1]

theorem envBound59380 : H12AffineFastState.Bounded env59380 := by
  intro p hp
  have h : env59380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59379_59380 : H12AffineEnvironment.transform 9 198 env59379 = env59380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 198 env59379 == env59380) = true)

def env59381 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,3077,1416,65,3159,1289,16,267632,4177,70915,66898,65542,68094,256,65674,70995,0]

theorem envBound59381 : H12AffineFastState.Bounded env59381 := by
  intro p hp
  have h : env59381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59372_59381 : H12AffineEnvironment.transform 12 1409 env59372 = env59381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59372 == env59381) = true)

theorem identity59381 : scanCanonicalize (H12AffineFastState.compose env59381 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59381 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59382 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1529,1409,1449,2129,65536,65706,262144,1025,2129,3077,1416,65,3159,1289,16,262281,1448,65786,66898,65542,68094,256,65674,65706,0]

theorem envBound59382 : H12AffineFastState.Bounded env59382 := by
  intro p hp
  have h : env59382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59381_59382 : H12AffineEnvironment.transform 11 1529 env59381 = env59382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1529 env59381 == env59382) = true)

theorem identity59382 : scanCanonicalize (H12AffineFastState.compose env59382 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59382 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59383 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1529,1409,1449,1449,65536,65706,262144,1025,1449,509,1416,65,431,1289,16,262281,1448,65786,66898,65542,66566,256,65674,65706,0]

theorem envBound59383 : H12AffineFastState.Bounded env59383 := by
  intro p hp
  have h : env59383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59382_59383 : H12AffineEnvironment.transform 10 1528 env59382 = env59383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59382 == env59383) = true)

theorem identity59383 : scanCanonicalize (H12AffineFastState.compose env59383 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 308) := by decide +kernel

theorem selectedBound59383 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59384 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1529,1409,1449,1449,65536,65706,308,1025,1449,509,1416,65,431,1289,16,445,1448,65786,66898,65542,66566,256,65674,65706,0]

theorem envBound59384 : H12AffineFastState.Bounded env59384 := by
  intro p hp
  have h : env59384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59383_59384 : H12AffineEnvironment.transform 17 308 env59383 = env59384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 308 env59383 == env59384) = true)

theorem identity59384 : scanCanonicalize (H12AffineFastState.compose env59384 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound59384 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59385 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1529,1409,1449,1449,1063,1165,308,1025,1449,509,1416,65,431,1289,16,445,1448,1245,373,1057,33,256,1197,1165,0]

theorem envBound59385 : H12AffineFastState.Bounded env59385 := by
  intro p hp
  have h : env59385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59384_59385 : H12AffineEnvironment.transform 15 1063 env59384 = env59385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env59384 == env59385) = true)

theorem identity59385 : scanCanonicalize (H12AffineFastState.compose env59385 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound59385 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59386 : List Nat := [2,4,8,16,32,64,128,253,1,1024,1029,1028,1148,1108,1108,1063,1165,201,1025,1108,0,1141,65,82,1268,16,64,1109,1245,136,1057,33,253,1197,1165,0]

theorem envBound59386 : H12AffineFastState.Bounded env59386 := by
  intro p hp
  have h : env59386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59385_59386 : H12AffineEnvironment.transform 7 253 env59385 = env59386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env59385 == env59386) = true)

theorem identity59386 : scanCanonicalize (H12AffineFastState.compose env59386 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59386 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59387 : List Nat := [2,4,8,16,32,17,128,172,1,1024,1029,1028,1069,1029,1029,1063,1165,152,1025,1029,0,1060,16,3,1189,16,17,1028,1164,136,1057,33,172,1197,1165,0]

theorem envBound59387 : H12AffineFastState.Bounded env59387 := by
  intro p hp
  have h : env59387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59386_59387 : H12AffineEnvironment.transform 5 17 env59386 = env59387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59386 == env59387) = true)

theorem identity59387 : scanCanonicalize (H12AffineFastState.compose env59387 (packedSelected [0,6] rootPS)) = affineNative (2^(9+1) ^^^ 55) := by decide +kernel

theorem selectedBound59387 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env59388 : List Nat := [2,4,8,16,32,17,128,172,1,55,50,51,26,50,50,16,186,152,54,50,0,19,16,3,146,16,17,51,187,136,22,33,172,154,186,0]

theorem envBound59388 : H12AffineFastState.Bounded env59388 := by
  intro p hp
  have h : env59388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59387_59388 : H12AffineEnvironment.transform 9 55 env59387 = env59388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 55 env59387 == env59388) = true)

theorem identity59388 : scanCanonicalize (H12AffineFastState.compose env59388 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound59388 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59389 : List Nat := [2,4,8,3,32,2,128,172,1,36,33,32,9,33,33,3,169,139,37,33,0,0,3,3,129,3,2,32,168,136,5,33,172,137,169,0]

theorem envBound59389 : H12AffineFastState.Bounded env59389 := by
  intro p hp
  have h : env59389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59388_59389 : H12AffineEnvironment.transform 3 3 env59388 = env59389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env59388 == env59389) = true)

def env59390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1416,9665,3671,1288,9616,2366324,4177,77954,67411,65543,68606,256,65674,78034,10113]

theorem envBound59390 : H12AffineFastState.Bounded env59390 := by
  intro p hp
  have h : env59390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59347_59390 : H12AffineEnvironment.transform 22 9665 env59347 = env59390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env59347 == env59390) = true)

def env59391 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9665,3159,1288,9616,2365812,4177,77954,66899,65543,68094,256,65674,78034,9601]

theorem envBound59391 : H12AffineFastState.Bounded env59391 := by
  intro p hp
  have h : env59391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59390_59391 : H12AffineEnvironment.transform 8 0 env59390 = env59391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59390 == env59391) = true)

theorem identity59391 : scanCanonicalize (H12AffineFastState.compose env59391 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 4564) := by decide +kernel

theorem selectedBound59391 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59392 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,4564,4176,2128,65536,65798,262144,1025,2128,2097152,1416,5141,3159,1288,5188,2365812,4177,65878,66899,65543,68094,256,65674,65798,5205]

theorem envBound59392 : H12AffineFastState.Bounded env59392 := by
  intro p hp
  have h : env59392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59391_59392 : H12AffineEnvironment.transform 12 4564 env59391 = env59392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4564 env59391 == env59392) = true)

def env59393 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1108,1408,1028,2128,65536,65798,262144,1025,2128,2097152,1416,65,3159,1288,16,2362656,1029,65878,66899,65543,68094,256,65674,65798,1]

theorem envBound59393 : H12AffineFastState.Bounded env59393 := by
  intro p hp
  have h : env59393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59392_59393 : H12AffineEnvironment.transform 11 1108 env59392 = env59393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env59392 == env59393) = true)

theorem identity59393 : scanCanonicalize (H12AffineFastState.compose env59393 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 3497) := by decide +kernel

theorem selectedBound59393 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59394 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1108,1408,1028,2128,65536,65798,262144,1025,2128,3497,1416,65,3159,1288,16,262281,1029,65878,66899,65543,68094,256,65674,65798,1]

theorem envBound59394 : H12AffineFastState.Bounded env59394 := by
  intro p hp
  have h : env59394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59393_59394 : H12AffineEnvironment.transform 20 3497 env59393 = env59394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 3497 env59393 == env59394) = true)

theorem identity59394 : scanCanonicalize (H12AffineFastState.compose env59394 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59394 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59395 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1108,1408,1028,1449,65536,65798,262144,1025,1449,80,1416,65,430,1288,16,262281,1029,65878,66899,65543,66567,256,65674,65798,1]

theorem envBound59395 : H12AffineFastState.Bounded env59395 := by
  intro p hp
  have h : env59395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59394_59395 : H12AffineEnvironment.transform 10 1529 env59394 = env59395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59394 == env59395) = true)

theorem identity59395 : scanCanonicalize (H12AffineFastState.compose env59395 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 152) := by decide +kernel

theorem selectedBound59395 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59396 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1108,1408,1028,1449,65536,65798,152,1025,1449,80,1416,65,430,1288,16,17,1029,65878,66899,65543,66567,256,65674,65798,1]

theorem envBound59396 : H12AffineFastState.Bounded env59396 := by
  intro p hp
  have h : env59396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59395_59396 : H12AffineEnvironment.transform 17 152 env59395 = env59396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 152 env59395 == env59396) = true)

theorem identity59396 : scanCanonicalize (H12AffineFastState.compose env59396 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound59396 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59397 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1108,1408,1028,1449,1063,1313,152,1025,1449,80,1416,65,430,1288,16,17,1029,1393,372,1056,32,256,1197,1313,1]

theorem envBound59397 : H12AffineFastState.Bounded env59397 := by
  intro p hp
  have h : env59397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59396_59397 : H12AffineEnvironment.transform 15 1063 env59396 = env59397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env59396 == env59397) = true)

theorem identity59397 : scanCanonicalize (H12AffineFastState.compose env59397 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound59397 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59398 : List Nat := [2,4,8,16,32,64,128,253,0,1024,1028,1108,1149,1028,1108,1063,1244,152,1025,1108,80,1141,65,83,1269,16,17,1029,1164,137,1056,32,253,1197,1244,1]

theorem envBound59398 : H12AffineFastState.Bounded env59398 := by
  intro p hp
  have h : env59398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59397_59398 : H12AffineEnvironment.transform 7 253 env59397 = env59398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env59397 == env59398) = true)

theorem identity59398 : scanCanonicalize (H12AffineFastState.compose env59398 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59398 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59399 : List Nat := [2,4,8,16,32,17,128,172,0,1024,1028,1029,1068,1028,1029,1063,1165,152,1025,1029,1,1060,16,2,1188,16,17,1029,1164,137,1056,32,172,1197,1165,1]

theorem envBound59399 : H12AffineFastState.Bounded env59399 := by
  intro p hp
  have h : env59399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59398_59399 : H12AffineEnvironment.transform 5 17 env59398 = env59399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59398 == env59399) = true)

theorem identity59399 : scanCanonicalize (H12AffineFastState.compose env59399 (packedSelected [0,6] rootPS)) = affineNative (2^(9+1) ^^^ 190) := by decide +kernel

theorem selectedBound59399 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env59400 : List Nat := [2,4,8,16,32,17,128,172,0,190,186,187,146,186,187,153,51,152,191,187,1,154,16,2,26,16,17,187,50,137,158,32,172,19,51,1]

theorem envBound59400 : H12AffineFastState.Bounded env59400 := by
  intro p hp
  have h : env59400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59399_59400 : H12AffineEnvironment.transform 9 190 env59399 = env59400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 190 env59399 == env59400) = true)

theorem identity59400 : scanCanonicalize (H12AffineFastState.compose env59400 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 27) := by decide +kernel

theorem selectedBound59400 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59401 : List Nat := [2,4,8,16,32,17,27,55,0,37,33,32,9,33,32,2,51,3,36,32,1,1,16,2,26,16,17,32,50,18,5,32,55,19,51,1]

theorem envBound59401 : H12AffineFastState.Bounded env59401 := by
  intro p hp
  have h : env59401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59400_59401 : H12AffineEnvironment.transform 6 27 env59400 = env59401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 27 env59400 == env59401) = true)

theorem identity59401 : scanCanonicalize (H12AffineFastState.compose env59401 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound59401 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env59402 : List Nat := [2,4,8,16,1,17,27,22,0,4,0,1,9,0,1,2,18,3,5,1,1,1,16,2,26,16,17,1,19,18,5,1,22,19,18,1]

theorem envBound59402 : H12AffineFastState.Bounded env59402 := by
  intro p hp
  have h : env59402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59401_59402 : H12AffineEnvironment.transform 4 1 env59401 = env59402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env59401 == env59402) = true)

theorem identity59402 : scanCanonicalize (H12AffineFastState.compose env59402 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound59402 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59403 : List Nat := [2,4,8,0,1,1,11,6,0,4,0,1,9,0,1,2,2,3,5,1,1,1,0,2,10,0,1,1,3,2,5,1,6,3,2,1]

theorem envBound59403 : H12AffineFastState.Bounded env59403 := by
  intro p hp
  have h : env59403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59402_59403 : H12AffineEnvironment.transform 3 0 env59402 = env59403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env59402 == env59403) = true)

theorem identity59403 : scanCanonicalize (H12AffineFastState.compose env59403 (packedSelected [1,3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59403 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59404 : List Nat := [0,4,8,0,1,1,9,4,0,4,0,1,9,0,1,0,0,1,5,1,1,1,0,0,8,0,1,1,1,0,5,1,4,1,0,1]

theorem envBound59404 : H12AffineFastState.Bounded env59404 := by
  intro p hp
  have h : env59404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59403_59404 : H12AffineEnvironment.transform 0 0 env59403 = env59404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59403 == env59404) = true)

theorem identity59404 : scanCanonicalize (H12AffineFastState.compose env59404 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound59404 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59405 : List Nat := [0,4,0,0,1,1,1,4,0,4,0,1,1,0,1,0,0,1,5,1,1,1,0,0,0,0,1,1,1,0,5,1,4,1,0,1]

theorem envBound59405 : H12AffineFastState.Bounded env59405 := by
  intro p hp
  have h : env59405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59404_59405 : H12AffineEnvironment.transform 2 0 env59404 = env59405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env59404 == env59405) = true)

def env59406 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1109,1409,1029,2128,65536,65798,262144,1025,2128,2097152,1416,64,3159,1288,17,2362657,1028,65878,66899,65543,68094,256,65674,65798,0]

theorem envBound59406 : H12AffineFastState.Bounded env59406 := by
  intro p hp
  have h : env59406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59392_59406 : H12AffineEnvironment.transform 11 1109 env59392 = env59406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1109 env59392 == env59406) = true)

theorem identity59406 : scanCanonicalize (H12AffineFastState.compose env59406 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 68782) := by decide +kernel

theorem selectedBound59406 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59407 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1109,1409,1029,2128,65536,65798,262144,1025,2128,68782,1416,64,3159,1288,17,328079,1028,65878,66899,65543,68094,256,65674,65798,0]

theorem envBound59407 : H12AffineFastState.Bounded env59407 := by
  intro p hp
  have h : env59407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59406_59407 : H12AffineEnvironment.transform 20 68782 env59406 = env59407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 68782 env59406 == env59407) = true)

theorem identity59407 : scanCanonicalize (H12AffineFastState.compose env59407 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3261) := by decide +kernel

theorem selectedBound59407 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59408 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1109,1409,1029,2128,65536,65798,3261,1025,2128,68782,1416,64,3159,1288,17,68914,1028,65878,66899,65543,68094,256,65674,65798,0]

theorem envBound59408 : H12AffineFastState.Bounded env59408 := by
  intro p hp
  have h : env59408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59407_59408 : H12AffineEnvironment.transform 17 3261 env59407 = env59408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3261 env59407 == env59408) = true)

theorem identity59408 : scanCanonicalize (H12AffineFastState.compose env59408 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1245) := by decide +kernel

theorem selectedBound59408 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env59409 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1245,1109,1409,1029,1165,65536,65798,96,1025,1165,65651,1416,64,138,1288,17,66031,1028,65878,66899,65543,66851,256,65674,65798,0]

theorem envBound59409 : H12AffineFastState.Bounded env59409 := by
  intro p hp
  have h : env59409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59408_59409 : H12AffineEnvironment.transform 10 1245 env59408 = env59409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1245 env59408 == env59409) = true)

theorem identity59409 : scanCanonicalize (H12AffineFastState.compose env59409 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound59409 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59410 : List Nat := [2,4,8,16,32,64,128,256,0,409,324,460,24,412,276,65536,65798,96,408,276,65651,17,64,138,145,17,66031,413,65878,65738,65543,65722,256,65674,65798,0]

theorem envBound59410 : H12AffineFastState.Bounded env59410 := by
  intro p hp
  have h : env59410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59409_59410 : H12AffineEnvironment.transform 9 409 env59409 = env59410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env59409 == env59410) = true)

theorem identity59410 : scanCanonicalize (H12AffineFastState.compose env59410 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59410 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env59411 : List Nat := [2,4,8,16,17,64,128,256,0,409,324,460,24,412,276,65536,65798,81,408,276,65602,17,64,138,145,17,66014,413,65878,65738,65543,65675,256,65674,65798,0]

theorem envBound59411 : H12AffineFastState.Bounded env59411 := by
  intro p hp
  have h : env59411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59410_59411 : H12AffineEnvironment.transform 4 17 env59410 = env59411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59410 == env59411) = true)

theorem identity59411 : scanCanonicalize (H12AffineFastState.compose env59411 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 154) := by decide +kernel

theorem selectedBound59411 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59412 : List Nat := [2,4,8,16,17,64,128,256,0,409,324,460,24,412,276,154,412,81,408,276,216,17,64,138,145,17,324,413,460,80,157,17,256,16,412,0]

theorem envBound59412 : H12AffineFastState.Bounded env59412 := by
  intro p hp
  have h : env59412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59411_59412 : H12AffineEnvironment.transform 15 154 env59411 = env59412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 154 env59411 == env59412) = true)

theorem identity59412 : scanCanonicalize (H12AffineFastState.compose env59412 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 214) := by decide +kernel

theorem selectedBound59412 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59413 : List Nat := [2,4,8,16,17,64,128,214,0,79,146,26,24,74,194,154,74,81,78,194,216,17,64,138,145,17,146,75,26,80,157,17,214,16,74,0]

theorem envBound59413 : H12AffineFastState.Bounded env59413 := by
  intro p hp
  have h : env59413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59412_59413 : H12AffineEnvironment.transform 7 214 env59412 = env59413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 214 env59412 == env59413) = true)

theorem identity59413 : scanCanonicalize (H12AffineFastState.compose env59413 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound59413 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59414 : List Nat := [2,4,8,16,17,64,89,15,0,79,75,26,24,74,27,67,74,81,78,27,1,17,64,83,72,17,75,75,26,80,68,17,15,16,74,0]

theorem envBound59414 : H12AffineFastState.Bounded env59414 := by
  intro p hp
  have h : env59414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59413_59414 : H12AffineEnvironment.transform 6 89 env59413 = env59414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env59413 == env59414) = true)

theorem identity59414 : scanCanonicalize (H12AffineFastState.compose env59414 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59414 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59415 : List Nat := [2,4,8,16,17,17,8,15,0,30,26,26,24,27,27,18,27,0,31,27,1,17,17,2,25,17,26,26,26,1,21,17,15,16,27,0]

theorem envBound59415 : H12AffineFastState.Bounded env59415 := by
  intro p hp
  have h : env59415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59414_59415 : H12AffineEnvironment.transform 5 17 env59414 = env59415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59414 == env59415) = true)

def env59416 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9665,3158,1288,9616,2365813,4177,77954,66898,65543,68095,256,65674,78034,9600]

theorem envBound59416 : H12AffineFastState.Bounded env59416 := by
  intro p hp
  have h : env59416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59390_59416 : H12AffineEnvironment.transform 8 1 env59390 = env59416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59390 == env59416) = true)

theorem identity59416 : scanCanonicalize (H12AffineFastState.compose env59416 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1108) := by decide +kernel

theorem selectedBound59416 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59417 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1108,8192,1028,2129,65536,74886,262144,1025,2129,2097152,1416,9665,3158,1288,9616,2362657,1029,74966,66898,65543,68095,256,65674,74886,9600]

theorem envBound59417 : H12AffineFastState.Bounded env59417 := by
  intro p hp
  have h : env59417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59416_59417 : H12AffineEnvironment.transform 11 1108 env59416 = env59417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env59416 == env59417) = true)

def env59418 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1108,1408,1028,2129,65536,65798,262144,1025,2129,2097152,1416,65,3158,1288,16,2362657,1029,65878,66898,65543,68095,256,65674,65798,0]

theorem envBound59418 : H12AffineFastState.Bounded env59418 := by
  intro p hp
  have h : env59418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59417_59418 : H12AffineEnvironment.transform 12 1408 env59417 = env59418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59417 == env59418) = true)

theorem identity59418 : scanCanonicalize (H12AffineFastState.compose env59418 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 3496) := by decide +kernel

theorem selectedBound59418 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59419 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1108,1408,1028,2129,65536,65798,262144,1025,2129,3496,1416,65,3158,1288,16,262281,1029,65878,66898,65543,68095,256,65674,65798,0]

theorem envBound59419 : H12AffineFastState.Bounded env59419 := by
  intro p hp
  have h : env59419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59418_59419 : H12AffineEnvironment.transform 20 3496 env59418 = env59419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 3496 env59418 == env59419) = true)

theorem identity59419 : scanCanonicalize (H12AffineFastState.compose env59419 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59419 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59420 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1108,1408,1028,1449,65536,65798,262144,1025,1449,80,1416,65,430,1288,16,262281,1029,65878,66898,65543,66567,256,65674,65798,0]

theorem envBound59420 : H12AffineFastState.Bounded env59420 := by
  intro p hp
  have h : env59420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59419_59420 : H12AffineEnvironment.transform 10 1528 env59419 = env59420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59419 == env59420) = true)

theorem identity59420 : scanCanonicalize (H12AffineFastState.compose env59420 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 152) := by decide +kernel

theorem selectedBound59420 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59421 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1108,1408,1028,1449,65536,65798,152,1025,1449,80,1416,65,430,1288,16,17,1029,65878,66898,65543,66567,256,65674,65798,0]

theorem envBound59421 : H12AffineFastState.Bounded env59421 := by
  intro p hp
  have h : env59421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59420_59421 : H12AffineEnvironment.transform 17 152 env59420 = env59421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 152 env59420 == env59421) = true)

theorem identity59421 : scanCanonicalize (H12AffineFastState.compose env59421 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound59421 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59422 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1108,1408,1028,1449,1063,1313,152,1025,1449,80,1416,65,430,1288,16,17,1029,1393,373,1056,32,256,1197,1313,0]

theorem envBound59422 : H12AffineFastState.Bounded env59422 := by
  intro p hp
  have h : env59422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59421_59422 : H12AffineEnvironment.transform 15 1063 env59421 = env59422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env59421 == env59422) = true)

theorem identity59422 : scanCanonicalize (H12AffineFastState.compose env59422 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound59422 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59423 : List Nat := [2,4,8,16,32,64,128,252,1,1024,1028,1108,1148,1028,1109,1063,1245,152,1025,1109,80,1140,65,82,1268,16,17,1029,1165,137,1056,32,252,1197,1245,0]

theorem envBound59423 : H12AffineFastState.Bounded env59423 := by
  intro p hp
  have h : env59423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59422_59423 : H12AffineEnvironment.transform 7 252 env59422 = env59423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env59422 == env59423) = true)

theorem identity59423 : scanCanonicalize (H12AffineFastState.compose env59423 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound59423 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59424 : List Nat := [2,4,8,16,32,64,128,252,1,141,137,217,241,137,216,170,80,152,140,216,80,249,65,82,121,16,17,136,0,137,173,32,252,32,80,0]

theorem envBound59424 : H12AffineFastState.Bounded env59424 := by
  intro p hp
  have h : env59424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59423_59424 : H12AffineEnvironment.transform 9 141 env59423 = env59424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env59423 == env59424) = true)

def env59425 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1108,1409,1028,2129,65536,65799,262144,1025,2129,2097152,1416,64,3158,1288,17,2362657,1029,65879,66898,65543,68095,256,65674,65799,1]

theorem envBound59425 : H12AffineFastState.Bounded env59425 := by
  intro p hp
  have h : env59425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59417_59425 : H12AffineEnvironment.transform 12 1409 env59417 = env59425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59417 == env59425) = true)

theorem identity59425 : scanCanonicalize (H12AffineFastState.compose env59425 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 68782) := by decide +kernel

theorem selectedBound59425 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59426 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1108,1409,1028,2129,65536,65799,262144,1025,2129,68782,1416,64,3158,1288,17,328079,1029,65879,66898,65543,68095,256,65674,65799,1]

theorem envBound59426 : H12AffineFastState.Bounded env59426 := by
  intro p hp
  have h : env59426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59425_59426 : H12AffineEnvironment.transform 20 68782 env59425 = env59426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 68782 env59425 == env59426) = true)

theorem identity59426 : scanCanonicalize (H12AffineFastState.compose env59426 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3261) := by decide +kernel

theorem selectedBound59426 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59427 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1108,1409,1028,2129,65536,65799,3261,1025,2129,68782,1416,64,3158,1288,17,68914,1029,65879,66898,65543,68095,256,65674,65799,1]

theorem envBound59427 : H12AffineFastState.Bounded env59427 := by
  intro p hp
  have h : env59427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59426_59427 : H12AffineEnvironment.transform 17 3261 env59426 = env59427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3261 env59426 == env59427) = true)

theorem identity59427 : scanCanonicalize (H12AffineFastState.compose env59427 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1244) := by decide +kernel

theorem selectedBound59427 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env59428 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1244,1108,1409,1028,1165,65536,65799,97,1025,1165,65650,1416,64,138,1288,17,66030,1029,65879,66898,65543,66851,256,65674,65799,1]

theorem envBound59428 : H12AffineFastState.Bounded env59428 := by
  intro p hp
  have h : env59428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59427_59428 : H12AffineEnvironment.transform 10 1244 env59427 = env59428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1244 env59427 == env59428) = true)

theorem identity59428 : scanCanonicalize (H12AffineFastState.compose env59428 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound59428 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59429 : List Nat := [2,4,8,16,32,64,128,256,1,409,325,461,24,413,276,65536,65799,97,408,276,65650,17,64,138,145,17,66030,412,65879,65739,65543,65722,256,65674,65799,1]

theorem envBound59429 : H12AffineFastState.Bounded env59429 := by
  intro p hp
  have h : env59429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59428_59429 : H12AffineEnvironment.transform 9 409 env59428 = env59429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env59428 == env59429) = true)

theorem identity59429 : scanCanonicalize (H12AffineFastState.compose env59429 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59429 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env59430 : List Nat := [2,4,8,16,17,64,128,256,1,409,325,461,24,413,276,65536,65799,80,408,276,65603,17,64,138,145,17,66015,412,65879,65739,65543,65675,256,65674,65799,1]

theorem envBound59430 : H12AffineFastState.Bounded env59430 := by
  intro p hp
  have h : env59430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59429_59430 : H12AffineEnvironment.transform 4 17 env59429 = env59430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59429 == env59430) = true)

theorem identity59430 : scanCanonicalize (H12AffineFastState.compose env59430 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 154) := by decide +kernel

theorem selectedBound59430 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59431 : List Nat := [2,4,8,16,17,64,128,256,1,409,325,461,24,413,276,154,413,80,408,276,217,17,64,138,145,17,325,412,461,81,157,17,256,16,413,1]

theorem envBound59431 : H12AffineFastState.Bounded env59431 := by
  intro p hp
  have h : env59431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59430_59431 : H12AffineEnvironment.transform 15 154 env59430 = env59431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 154 env59430 == env59431) = true)

theorem identity59431 : scanCanonicalize (H12AffineFastState.compose env59431 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 215) := by decide +kernel

theorem selectedBound59431 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59432 : List Nat := [2,4,8,16,17,64,128,215,1,78,146,26,24,74,195,154,74,80,79,195,217,17,64,138,145,17,146,75,26,81,157,17,215,16,74,1]

theorem envBound59432 : H12AffineFastState.Bounded env59432 := by
  intro p hp
  have h : env59432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59431_59432 : H12AffineEnvironment.transform 7 215 env59431 = env59432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 215 env59431 == env59432) = true)

def env59433 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1417,8388608,8399766,8397001,8388689,2366325,4177,77954,67410,8463814,8465983,256,65675,78034,8389184]

theorem envBound59433 : H12AffineFastState.Bounded env59433 := by
  intro p hp
  have h : env59433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59346_59433 : H12AffineEnvironment.transform 21 1417 env59346 = env59433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1417 env59346 == env59433) = true)

def env59434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1417,9664,3670,1289,9617,2366325,4177,77954,67410,65542,68607,256,65675,78034,10112]

theorem envBound59434 : H12AffineFastState.Bounded env59434 := by
  intro p hp
  have h : env59434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59433_59434 : H12AffineEnvironment.transform 22 9664 env59433 = env59434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env59433 == env59434) = true)

def env59435 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9664,3158,1289,9617,2365813,4177,77954,66898,65542,68095,256,65675,78034,9600]

theorem envBound59435 : H12AffineFastState.Bounded env59435 := by
  intro p hp
  have h : env59435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59434_59435 : H12AffineEnvironment.transform 8 0 env59434 = env59435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59434 == env59435) = true)

theorem identity59435 : scanCanonicalize (H12AffineFastState.compose env59435 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 9561) := by decide +kernel

theorem selectedBound59435 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59436 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,9561,1417,9664,3158,1289,9617,277548,4177,77954,66898,65542,68095,256,65675,78034,9600]

theorem envBound59436 : H12AffineFastState.Bounded env59436 := by
  intro p hp
  have h : env59436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59435_59436 : H12AffineEnvironment.transform 20 9561 env59435 = env59436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 9561 env59435 == env59436) = true)

def env59437 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,217,1417,64,3158,1289,17,268716,4177,70914,66898,65542,68095,256,65675,70994,0]

theorem envBound59437 : H12AffineFastState.Bounded env59437 := by
  intro p hp
  have h : env59437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59436_59437 : H12AffineEnvironment.transform 12 1408 env59436 = env59437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59436 == env59437) = true)

theorem identity59437 : scanCanonicalize (H12AffineFastState.compose env59437 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 6179) := by decide +kernel

theorem selectedBound59437 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59438 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,6179,3441,262144,1025,2128,217,1417,64,3158,1289,17,268716,4177,3361,7537,6181,4572,256,6312,3441,0]

theorem envBound59438 : H12AffineFastState.Bounded env59438 := by
  intro p hp
  have h : env59438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59437_59438 : H12AffineEnvironment.transform 15 6179 env59437 = env59438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6179 env59437 == env59438) = true)

theorem identity59438 : scanCanonicalize (H12AffineFastState.compose env59438 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6377) := by decide +kernel

theorem selectedBound59438 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59439 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,6179,3441,6377,1025,2128,217,1417,64,3158,1289,17,325,4177,3361,7537,6181,4572,256,6312,3441,0]

theorem envBound59439 : H12AffineFastState.Bounded env59439 := by
  intro p hp
  have h : env59439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59438_59439 : H12AffineEnvironment.transform 17 6377 env59438 = env59439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6377 env59438 == env59439) = true)

theorem identity59439 : scanCanonicalize (H12AffineFastState.compose env59439 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 461) := by decide +kernel

theorem selectedBound59439 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59440 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,461,1408,413,2128,2542,3441,2340,1025,2128,217,1417,64,3158,1289,17,325,412,3361,3260,2536,17,256,2405,3441,0]

theorem envBound59440 : H12AffineFastState.Bounded env59440 := by
  intro p hp
  have h : env59440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59439_59440 : H12AffineEnvironment.transform 11 461 env59439 = env59440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 461 env59439 == env59440) = true)

theorem identity59440 : scanCanonicalize (H12AffineFastState.compose env59440 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1261) := by decide +kernel

theorem selectedBound59440 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env59441 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1261,461,1408,413,1213,1283,412,1481,1025,1213,217,1417,64,187,1289,17,325,412,460,81,1285,17,256,1416,412,0]

theorem envBound59441 : H12AffineFastState.Bounded env59441 := by
  intro p hp
  have h : env59441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59440_59441 : H12AffineEnvironment.transform 10 1261 env59440 = env59441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1261 env59440 == env59441) = true)

theorem identity59441 : scanCanonicalize (H12AffineFastState.compose env59441 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59441 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59442 : List Nat := [2,4,8,16,17,64,128,256,0,1024,1244,461,1408,413,1164,1283,412,1481,1025,1164,217,1417,64,138,1289,17,325,412,460,81,1285,17,256,1416,412,0]

theorem envBound59442 : H12AffineFastState.Bounded env59442 := by
  intro p hp
  have h : env59442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59441_59442 : H12AffineEnvironment.transform 4 17 env59441 = env59442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59441 == env59442) = true)

theorem identity59442 : scanCanonicalize (H12AffineFastState.compose env59442 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound59442 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59443 : List Nat := [2,4,8,16,17,64,128,95,0,1024,1244,146,1247,194,1164,1116,195,1174,1025,1164,217,1238,64,138,1110,17,26,195,147,81,1114,17,95,1239,195,0]

theorem envBound59443 : H12AffineFastState.Bounded env59443 := by
  intro p hp
  have h : env59443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59442_59443 : H12AffineEnvironment.transform 7 95 env59442 = env59443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env59442 == env59443) = true)

theorem identity59443 : scanCanonicalize (H12AffineFastState.compose env59443 (packedSelected [0,5] rootPS)) = affineNative (2^(9+1) ^^^ 199) := by decide +kernel

theorem selectedBound59443 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59444 : List Nat := [2,4,8,16,17,64,128,95,0,199,27,146,24,194,75,155,195,81,198,75,217,17,64,138,145,17,26,195,147,81,157,17,95,16,195,0]

theorem envBound59444 : H12AffineFastState.Bounded env59444 := by
  intro p hp
  have h : env59444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59443_59444 : H12AffineEnvironment.transform 9 199 env59443 = env59444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 199 env59443 == env59444) = true)

def env59445 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,216,1417,65,3158,1289,16,268717,4177,70915,66898,65542,68095,256,65675,70995,1]

theorem envBound59445 : H12AffineFastState.Bounded env59445 := by
  intro p hp
  have h : env59445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59436_59445 : H12AffineEnvironment.transform 12 1409 env59436 = env59445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59436 == env59445) = true)

theorem identity59445 : scanCanonicalize (H12AffineFastState.compose env59445 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 2340) := by decide +kernel

theorem selectedBound59445 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59446 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2340,1409,2420,2128,65536,68727,262144,1025,2128,216,1417,65,3158,1289,16,262281,2421,68647,66898,65542,68095,256,65675,68727,1]

theorem envBound59446 : H12AffineFastState.Bounded env59446 := by
  intro p hp
  have h : env59446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59445_59446 : H12AffineEnvironment.transform 11 2340 env59445 = env59446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2340 env59445 == env59446) = true)

theorem identity59446 : scanCanonicalize (H12AffineFastState.compose env59446 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59446 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59447 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1245,1409,1165,1449,65536,65934,262144,1025,1449,216,1417,65,431,1289,16,262281,1164,66014,66898,65542,66566,256,65675,65934,1]

theorem envBound59447 : H12AffineFastState.Bounded env59447 := by
  intro p hp
  have h : env59447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59446_59447 : H12AffineEnvironment.transform 10 1529 env59446 = env59447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59446 == env59447) = true)

theorem identity59447 : scanCanonicalize (H12AffineFastState.compose env59447 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 16) := by decide +kernel

theorem selectedBound59447 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59448 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1245,1409,1165,1449,65536,65934,16,1025,1449,216,1417,65,431,1289,16,153,1164,66014,66898,65542,66566,256,65675,65934,1]

theorem envBound59448 : H12AffineFastState.Bounded env59448 := by
  intro p hp
  have h : env59448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59447_59448 : H12AffineEnvironment.transform 17 16 env59447 = env59448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 16 env59447 == env59448) = true)

theorem identity59448 : scanCanonicalize (H12AffineFastState.compose env59448 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound59448 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59449 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1245,1409,1165,1449,1063,1449,16,1025,1449,216,1417,65,431,1289,16,153,1164,1529,373,1057,33,256,1196,1449,1]

theorem envBound59449 : H12AffineFastState.Bounded env59449 := by
  intro p hp
  have h : env59449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59448_59449 : H12AffineEnvironment.transform 15 1063 env59448 = env59449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env59448 == env59449) = true)

theorem identity59449 : scanCanonicalize (H12AffineFastState.compose env59449 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound59449 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59450 : List Nat := [2,4,8,16,32,64,128,252,0,1024,1029,1245,1149,1165,1109,1063,1109,16,1025,1109,216,1141,65,83,1269,16,153,1164,1029,137,1057,33,252,1196,1109,1]

theorem envBound59450 : H12AffineFastState.Bounded env59450 := by
  intro p hp
  have h : env59450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59449_59450 : H12AffineEnvironment.transform 7 252 env59449 = env59450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env59449 == env59450) = true)

theorem identity59450 : scanCanonicalize (H12AffineFastState.compose env59450 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound59450 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59451 : List Nat := [2,4,8,16,32,64,128,252,0,141,136,80,240,0,216,170,216,16,140,216,216,248,65,83,120,16,153,1,136,137,172,33,252,33,216,1]

theorem envBound59451 : H12AffineFastState.Bounded env59451 := by
  intro p hp
  have h : env59451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59450_59451 : H12AffineEnvironment.transform 9 141 env59450 = env59451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env59450 == env59451) = true)

theorem identity59451 : scanCanonicalize (H12AffineFastState.compose env59451 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound59451 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env59452 : List Nat := [2,4,8,16,16,64,128,204,0,141,136,80,192,0,216,154,216,16,140,216,216,200,65,83,72,16,153,1,136,137,156,17,204,17,216,1]

theorem envBound59452 : H12AffineFastState.Bounded env59452 := by
  intro p hp
  have h : env59452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59451_59452 : H12AffineEnvironment.transform 4 16 env59451 = env59452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env59451 == env59452) = true)

theorem identity59452 : scanCanonicalize (H12AffineFastState.compose env59452 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 27) := by decide +kernel

theorem selectedBound59452 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59453 : List Nat := [2,4,8,16,16,64,27,87,0,22,19,80,91,0,67,1,67,16,23,67,67,83,65,83,72,16,2,1,19,18,7,17,87,17,67,1]

theorem envBound59453 : H12AffineFastState.Bounded env59453 := by
  intro p hp
  have h : env59453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59452_59453 : H12AffineEnvironment.transform 6 27 env59452 = env59453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 27 env59452 == env59453) = true)

theorem identity59453 : scanCanonicalize (H12AffineFastState.compose env59453 (packedSelected [4,7] rootPS)) = affineNative (2^(5+1) ^^^ 8) := by decide +kernel

theorem selectedBound59453 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env59454 : List Nat := [2,4,8,16,16,8,27,31,0,22,19,24,19,0,11,1,11,16,23,11,11,27,9,27,0,16,2,1,19,18,7,17,31,17,11,1]

theorem envBound59454 : H12AffineFastState.Bounded env59454 := by
  intro p hp
  have h : env59454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59453_59454 : H12AffineEnvironment.transform 5 8 env59453 = env59454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 8 env59453 == env59454) = true)

theorem identity59454 : scanCanonicalize (H12AffineFastState.compose env59454 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound59454 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59455 : List Nat := [2,4,8,2,2,8,9,13,0,4,1,10,1,0,11,1,11,2,5,11,11,9,9,9,0,2,2,1,1,0,7,3,13,3,11,1]

theorem envBound59455 : H12AffineFastState.Bounded env59455 := by
  intro p hp
  have h : env59455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59454_59455 : H12AffineEnvironment.transform 3 2 env59454 = env59455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env59454 == env59455) = true)

def env59456 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9664,3159,1289,9617,2365812,4177,77954,66899,65542,68094,256,65675,78034,9601]

theorem envBound59456 : H12AffineFastState.Bounded env59456 := by
  intro p hp
  have h : env59456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59434_59456 : H12AffineEnvironment.transform 8 1 env59434 = env59456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59434 == env59456) = true)

theorem identity59456 : scanCanonicalize (H12AffineFastState.compose env59456 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 216) := by decide +kernel

theorem selectedBound59456 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59457 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,216,1417,9664,3159,1289,9617,268716,4177,77954,66899,65542,68094,256,65675,78034,9601]

theorem envBound59457 : H12AffineFastState.Bounded env59457 := by
  intro p hp
  have h : env59457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59456_59457 : H12AffineEnvironment.transform 20 216 env59456 = env59457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 216 env59456 == env59457) = true)

def env59458 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,216,1417,64,3159,1289,17,268716,4177,70914,66899,65542,68094,256,65675,70994,1]

theorem envBound59458 : H12AffineFastState.Bounded env59458 := by
  intro p hp
  have h : env59458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59457_59458 : H12AffineEnvironment.transform 12 1408 env59457 = env59458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59457 == env59458) = true)

theorem identity59458 : scanCanonicalize (H12AffineFastState.compose env59458 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 6179) := by decide +kernel

theorem selectedBound59458 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59459 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,6179,3441,262144,1025,2129,216,1417,64,3159,1289,17,268716,4177,3361,7536,6181,4573,256,6312,3441,1]

theorem envBound59459 : H12AffineFastState.Bounded env59459 := by
  intro p hp
  have h : env59459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59458_59459 : H12AffineEnvironment.transform 15 6179 env59458 = env59459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6179 env59458 == env59459) = true)

theorem identity59459 : scanCanonicalize (H12AffineFastState.compose env59459 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6376) := by decide +kernel

theorem selectedBound59459 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59460 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,6179,3441,6376,1025,2129,216,1417,64,3159,1289,17,324,4177,3361,7536,6181,4573,256,6312,3441,1]

theorem envBound59460 : H12AffineFastState.Bounded env59460 := by
  intro p hp
  have h : env59460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59459_59460 : H12AffineEnvironment.transform 17 6376 env59459 = env59460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6376 env59459 == env59460) = true)

theorem identity59460 : scanCanonicalize (H12AffineFastState.compose env59460 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 460) := by decide +kernel

theorem selectedBound59460 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59461 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,460,1408,412,2129,2543,3441,2340,1025,2129,216,1417,64,3159,1289,17,324,413,3361,3260,2537,17,256,2404,3441,1]

theorem envBound59461 : H12AffineFastState.Bounded env59461 := by
  intro p hp
  have h : env59461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59460_59461 : H12AffineEnvironment.transform 11 460 env59460 = env59461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 460 env59460 == env59461) = true)

theorem identity59461 : scanCanonicalize (H12AffineFastState.compose env59461 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59461 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env59462 : List Nat := [2,4,8,16,17,64,128,256,1,1024,2048,460,1408,412,2129,2526,3392,2325,1025,2129,216,1417,64,3159,1289,17,324,413,3344,3213,2520,17,256,2389,3392,1]

theorem envBound59462 : H12AffineFastState.Bounded env59462 := by
  intro p hp
  have h : env59462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59461_59462 : H12AffineEnvironment.transform 4 17 env59461 = env59462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59461 == env59462) = true)

theorem identity59462 : scanCanonicalize (H12AffineFastState.compose env59462 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 1245) := by decide +kernel

theorem selectedBound59462 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59463 : List Nat := [2,4,8,16,17,64,128,256,1,1024,1245,460,1408,412,1164,1283,413,1480,1025,1164,216,1417,64,138,1289,17,324,413,461,80,1285,17,256,1416,413,1]

theorem envBound59463 : H12AffineFastState.Bounded env59463 := by
  intro p hp
  have h : env59463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59462_59463 : H12AffineEnvironment.transform 10 1245 env59462 = env59463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1245 env59462 == env59463) = true)

theorem identity59463 : scanCanonicalize (H12AffineFastState.compose env59463 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound59463 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59464 : List Nat := [2,4,8,16,17,64,128,95,1,1024,1245,147,1247,195,1164,1116,194,1175,1025,1164,216,1238,64,138,1110,17,27,194,146,80,1114,17,95,1239,194,1]

theorem envBound59464 : H12AffineFastState.Bounded env59464 := by
  intro p hp
  have h : env59464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59463_59464 : H12AffineEnvironment.transform 7 95 env59463 = env59464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env59463 == env59464) = true)

theorem identity59464 : scanCanonicalize (H12AffineFastState.compose env59464 (packedSelected [0,5] rootPS)) = affineNative (2^(9+1) ^^^ 199) := by decide +kernel

theorem selectedBound59464 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59465 : List Nat := [2,4,8,16,17,64,128,95,1,199,26,147,24,195,75,155,194,80,198,75,216,17,64,138,145,17,27,194,146,80,157,17,95,16,194,1]

theorem envBound59465 : H12AffineFastState.Bounded env59465 := by
  intro p hp
  have h : env59465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59464_59465 : H12AffineEnvironment.transform 9 199 env59464 = env59465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 199 env59464 == env59465) = true)

def env59466 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,216,1417,65,3159,1289,16,268716,4177,70915,66899,65542,68094,256,65675,70995,0]

theorem envBound59466 : H12AffineFastState.Bounded env59466 := by
  intro p hp
  have h : env59466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59457_59466 : H12AffineEnvironment.transform 12 1409 env59457 = env59466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59457 == env59466) = true)

theorem identity59466 : scanCanonicalize (H12AffineFastState.compose env59466 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 2341) := by decide +kernel

theorem selectedBound59466 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59467 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2341,1409,2421,2129,65536,68726,262144,1025,2129,216,1417,65,3159,1289,16,262281,2420,68646,66899,65542,68094,256,65675,68726,0]

theorem envBound59467 : H12AffineFastState.Bounded env59467 := by
  intro p hp
  have h : env59467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59466_59467 : H12AffineEnvironment.transform 11 2341 env59466 = env59467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2341 env59466 == env59467) = true)

theorem identity59467 : scanCanonicalize (H12AffineFastState.compose env59467 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59467 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59468 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1245,1409,1165,1449,65536,65934,262144,1025,1449,216,1417,65,431,1289,16,262281,1164,66014,66899,65542,66566,256,65675,65934,0]

theorem envBound59468 : H12AffineFastState.Bounded env59468 := by
  intro p hp
  have h : env59468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59467_59468 : H12AffineEnvironment.transform 10 1528 env59467 = env59468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59467 == env59468) = true)

theorem identity59468 : scanCanonicalize (H12AffineFastState.compose env59468 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 16) := by decide +kernel

theorem selectedBound59468 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59469 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1245,1409,1165,1449,65536,65934,16,1025,1449,216,1417,65,431,1289,16,153,1164,66014,66899,65542,66566,256,65675,65934,0]

theorem envBound59469 : H12AffineFastState.Bounded env59469 := by
  intro p hp
  have h : env59469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59468_59469 : H12AffineEnvironment.transform 17 16 env59468 = env59469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 16 env59468 == env59469) = true)

theorem identity59469 : scanCanonicalize (H12AffineFastState.compose env59469 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound59469 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59470 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1245,1409,1165,1449,1063,1449,16,1025,1449,216,1417,65,431,1289,16,153,1164,1529,372,1057,33,256,1196,1449,0]

theorem envBound59470 : H12AffineFastState.Bounded env59470 := by
  intro p hp
  have h : env59470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59469_59470 : H12AffineEnvironment.transform 15 1063 env59469 = env59470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env59469 == env59470) = true)

theorem identity59470 : scanCanonicalize (H12AffineFastState.compose env59470 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound59470 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59471 : List Nat := [2,4,8,16,32,64,128,253,1,1024,1029,1245,1148,1165,1108,1063,1108,16,1025,1108,216,1140,65,82,1268,16,153,1164,1028,137,1057,33,253,1196,1108,0]

theorem envBound59471 : H12AffineFastState.Bounded env59471 := by
  intro p hp
  have h : env59471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59470_59471 : H12AffineEnvironment.transform 7 253 env59470 = env59471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env59470 == env59471) = true)

theorem identity59471 : scanCanonicalize (H12AffineFastState.compose env59471 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59471 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59472 : List Nat := [2,4,8,16,32,17,128,172,1,1024,1029,1164,1069,1165,1029,1063,1029,16,1025,1029,137,1061,16,3,1189,16,153,1164,1028,137,1057,33,172,1196,1029,0]

theorem envBound59472 : H12AffineFastState.Bounded env59472 := by
  intro p hp
  have h : env59472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59471_59472 : H12AffineEnvironment.transform 5 17 env59471 = env59472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59471 == env59472) = true)

theorem identity59472 : scanCanonicalize (H12AffineFastState.compose env59472 (packedSelected [0,6] rootPS)) = affineNative (2^(9+1) ^^^ 54) := by decide +kernel

theorem selectedBound59472 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env59473 : List Nat := [2,4,8,16,32,17,128,172,1,54,51,186,27,187,51,17,51,16,55,51,137,19,16,3,147,16,153,186,50,137,23,33,172,154,51,0]

theorem envBound59473 : H12AffineFastState.Bounded env59473 := by
  intro p hp
  have h : env59473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59472_59473 : H12AffineEnvironment.transform 9 54 env59472 = env59473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 54 env59472 == env59473) = true)

theorem identity59473 : scanCanonicalize (H12AffineFastState.compose env59473 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound59473 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59474 : List Nat := [2,4,8,16,3,17,128,143,1,21,16,153,27,152,16,17,16,16,20,16,137,19,16,3,147,16,153,153,17,137,23,2,143,154,16,0]

theorem envBound59474 : H12AffineFastState.Bounded env59474 := by
  intro p hp
  have h : env59474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59473_59474 : H12AffineEnvironment.transform 4 3 env59473 = env59474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env59473 == env59474) = true)

theorem identity59474 : scanCanonicalize (H12AffineFastState.compose env59474 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound59474 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env59475 : List Nat := [2,4,8,3,3,2,128,143,1,6,3,138,8,139,3,2,3,3,7,3,137,0,3,3,128,3,138,138,2,137,4,2,143,137,3,0]

theorem envBound59475 : H12AffineFastState.Bounded env59475 := by
  intro p hp
  have h : env59475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59474_59475 : H12AffineEnvironment.transform 3 3 env59474 = env59475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env59474 == env59475) = true)

theorem identity59475 : scanCanonicalize (H12AffineFastState.compose env59475 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound59475 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59476 : List Nat := [2,4,2,3,3,2,128,133,1,6,3,128,2,129,3,2,3,3,7,3,131,0,3,3,128,3,128,128,2,131,4,2,133,131,3,0]

theorem envBound59476 : H12AffineFastState.Bounded env59476 := by
  intro p hp
  have h : env59476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59475_59476 : H12AffineEnvironment.transform 2 2 env59475 = env59476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env59475 == env59476) = true)

theorem identity59476 : scanCanonicalize (H12AffineFastState.compose env59476 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59476 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59477 : List Nat := [1,4,1,0,0,1,128,133,1,5,0,128,1,129,0,1,0,0,4,0,128,0,0,0,128,0,128,128,1,128,4,1,133,128,0,0]

theorem envBound59477 : H12AffineFastState.Bounded env59477 := by
  intro p hp
  have h : env59477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59476_59477 : H12AffineEnvironment.transform 0 1 env59476 = env59477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59476 == env59477) = true)

theorem identity59477 : scanCanonicalize (H12AffineFastState.compose env59477 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 1) := by decide +kernel

theorem selectedBound59477 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59478 : List Nat := [1,4,1,0,0,1,1,4,1,5,0,1,1,0,0,1,0,0,4,0,1,0,0,0,1,0,1,1,1,1,4,1,4,1,0,0]

theorem envBound59478 : H12AffineFastState.Bounded env59478 := by
  intro p hp
  have h : env59478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59477_59478 : H12AffineEnvironment.transform 6 1 env59477 = env59478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 1 env59477 == env59478) = true)

def env59479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1417,9665,3671,1288,9616,2366325,4177,77954,67410,65543,68606,256,65675,78034,10113]

theorem envBound59479 : H12AffineFastState.Bounded env59479 := by
  intro p hp
  have h : env59479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59433_59479 : H12AffineEnvironment.transform 22 9665 env59433 = env59479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env59433 == env59479) = true)

def env59480 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9665,3159,1288,9616,2365813,4177,77954,66898,65543,68094,256,65675,78034,9601]

theorem envBound59480 : H12AffineFastState.Bounded env59480 := by
  intro p hp
  have h : env59480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59479_59480 : H12AffineEnvironment.transform 8 0 env59479 = env59480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59479 == env59480) = true)

theorem identity59480 : scanCanonicalize (H12AffineFastState.compose env59480 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2184) := by decide +kernel

theorem selectedBound59480 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59481 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2184,8192,2264,2128,65536,75866,262144,1025,2128,2097152,1417,9665,3159,1288,9616,2359805,2265,75786,66898,65543,68094,256,65675,75866,9601]

theorem envBound59481 : H12AffineFastState.Bounded env59481 := by
  intro p hp
  have h : env59481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59480_59481 : H12AffineEnvironment.transform 11 2184 env59480 = env59481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2184 env59480 == env59481) = true)

def env59482 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2184,1408,2264,2128,65536,69082,262144,1025,2128,2097152,1417,65,3159,1288,16,2359805,2265,69002,66898,65543,68094,256,65675,69082,1]

theorem envBound59482 : H12AffineFastState.Bounded env59482 := by
  intro p hp
  have h : env59482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59481_59482 : H12AffineEnvironment.transform 12 1408 env59481 = env59482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59481 == env59482) = true)

theorem identity59482 : scanCanonicalize (H12AffineFastState.compose env59482 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 372) := by decide +kernel

theorem selectedBound59482 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59483 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2184,1408,2264,2128,65536,69082,262144,1025,2128,372,1417,65,3159,1288,16,262281,2265,69002,66898,65543,68094,256,65675,69082,1]

theorem envBound59483 : H12AffineFastState.Bounded env59483 := by
  intro p hp
  have h : env59483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59482_59483 : H12AffineEnvironment.transform 20 372 env59482 = env59483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 372 env59482 == env59483) = true)

theorem identity59483 : scanCanonicalize (H12AffineFastState.compose env59483 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59483 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59484 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1393,1408,1313,1449,65536,65571,262144,1025,1449,372,1417,65,430,1288,16,262281,1312,65651,66898,65543,66567,256,65675,65571,1]

theorem envBound59484 : H12AffineFastState.Bounded env59484 := by
  intro p hp
  have h : env59484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59483_59484 : H12AffineEnvironment.transform 10 1529 env59483 = env59484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59483 == env59484) = true)

theorem identity59484 : scanCanonicalize (H12AffineFastState.compose env59484 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 445) := by decide +kernel

theorem selectedBound59484 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59485 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1393,1408,1313,1449,65536,65571,445,1025,1449,372,1417,65,430,1288,16,308,1312,65651,66898,65543,66567,256,65675,65571,1]

theorem envBound59485 : H12AffineFastState.Bounded env59485 := by
  intro p hp
  have h : env59485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59484_59485 : H12AffineEnvironment.transform 17 445 env59484 = env59485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 445 env59484 == env59485) = true)

theorem identity59485 : scanCanonicalize (H12AffineFastState.compose env59485 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound59485 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59486 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1393,1408,1313,1449,1063,1028,445,1025,1449,372,1417,65,430,1288,16,308,1312,1108,373,1056,32,256,1196,1028,1]

theorem envBound59486 : H12AffineFastState.Bounded env59486 := by
  intro p hp
  have h : env59486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59485_59486 : H12AffineEnvironment.transform 15 1063 env59485 = env59486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env59485 == env59486) = true)

theorem identity59486 : scanCanonicalize (H12AffineFastState.compose env59486 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound59486 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59487 : List Nat := [2,4,8,16,32,64,128,253,0,1024,1028,1164,1149,1244,1108,1063,1028,64,1025,1108,137,1140,65,83,1269,16,201,1245,1108,136,1056,32,253,1196,1028,1]

theorem envBound59487 : H12AffineFastState.Bounded env59487 := by
  intro p hp
  have h : env59487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59486_59487 : H12AffineEnvironment.transform 7 253 env59486 = env59487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env59486 == env59487) = true)

theorem identity59487 : scanCanonicalize (H12AffineFastState.compose env59487 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59487 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59488 : List Nat := [2,4,8,16,32,17,128,172,0,1024,1028,1164,1068,1165,1029,1063,1028,17,1025,1029,137,1061,16,2,1188,16,152,1164,1029,136,1056,32,172,1196,1028,1]

theorem envBound59488 : H12AffineFastState.Bounded env59488 := by
  intro p hp
  have h : env59488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59487_59488 : H12AffineEnvironment.transform 5 17 env59487 = env59488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59487 == env59488) = true)

theorem identity59488 : scanCanonicalize (H12AffineFastState.compose env59488 (packedSelected [0,6] rootPS)) = affineNative (2^(9+1) ^^^ 191) := by decide +kernel

theorem selectedBound59488 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env59489 : List Nat := [2,4,8,16,32,17,128,172,0,191,187,51,147,50,186,152,187,17,190,186,137,154,16,2,27,16,152,51,186,136,159,32,172,19,187,1]

theorem envBound59489 : H12AffineFastState.Bounded env59489 := by
  intro p hp
  have h : env59489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59488_59489 : H12AffineEnvironment.transform 9 191 env59488 = env59489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 191 env59488 == env59489) = true)

theorem identity59489 : scanCanonicalize (H12AffineFastState.compose env59489 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 43) := by decide +kernel

theorem selectedBound59489 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59490 : List Nat := [2,4,8,16,32,17,43,7,0,20,16,51,56,50,17,51,16,17,21,17,34,49,16,2,27,16,51,51,17,35,52,32,7,19,16,1]

theorem envBound59490 : H12AffineFastState.Bounded env59490 := by
  intro p hp
  have h : env59490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59489_59490 : H12AffineEnvironment.transform 6 43 env59489 = env59490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 43 env59489 == env59490) = true)

theorem identity59490 : scanCanonicalize (H12AffineFastState.compose env59490 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59490 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env59491 : List Nat := [2,4,8,16,17,17,26,7,0,20,16,2,9,3,17,2,16,17,21,17,19,0,16,2,27,16,2,2,17,18,5,17,7,19,16,1]

theorem envBound59491 : H12AffineFastState.Bounded env59491 := by
  intro p hp
  have h : env59491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59490_59491 : H12AffineEnvironment.transform 4 17 env59490 = env59491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59490 == env59491) = true)

theorem identity59491 : scanCanonicalize (H12AffineFastState.compose env59491 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound59491 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59492 : List Nat := [2,4,2,16,17,17,16,7,0,20,16,2,3,3,17,2,16,17,21,17,19,0,16,2,17,16,2,2,17,18,5,17,7,19,16,1]

theorem envBound59492 : H12AffineFastState.Bounded env59492 := by
  intro p hp
  have h : env59492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59491_59492 : H12AffineEnvironment.transform 2 2 env59491 = env59492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env59491 == env59492) = true)

theorem identity59492 : scanCanonicalize (H12AffineFastState.compose env59492 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound59492 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59493 : List Nat := [2,4,2,1,0,0,1,7,0,5,1,2,3,3,0,2,1,0,4,0,2,0,1,2,0,1,2,2,0,3,5,0,7,2,1,1]

theorem envBound59493 : H12AffineFastState.Bounded env59493 := by
  intro p hp
  have h : env59493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59492_59493 : H12AffineEnvironment.transform 3 1 env59492 = env59493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env59492 == env59493) = true)

theorem identity59493 : scanCanonicalize (H12AffineFastState.compose env59493 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59493 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59494 : List Nat := [0,4,0,1,0,0,1,5,0,5,1,0,1,1,0,0,1,0,4,0,0,0,1,0,0,1,0,0,0,1,5,0,5,0,1,1]

theorem envBound59494 : H12AffineFastState.Bounded env59494 := by
  intro p hp
  have h : env59494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59493_59494 : H12AffineEnvironment.transform 0 0 env59493 = env59494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59493 == env59494) = true)

def env59495 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2184,1409,2264,2128,65536,69083,262144,1025,2128,2097152,1417,64,3159,1288,17,2359805,2265,69003,66898,65543,68094,256,65675,69083,0]

theorem envBound59495 : H12AffineFastState.Bounded env59495 := by
  intro p hp
  have h : env59495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59481_59495 : H12AffineEnvironment.transform 12 1409 env59481 = env59495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59481 == env59495) = true)

theorem identity59495 : scanCanonicalize (H12AffineFastState.compose env59495 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 65651) := by decide +kernel

theorem selectedBound59495 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59496 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2184,1409,2264,2128,65536,69083,262144,1025,2128,65651,1417,64,3159,1288,17,328078,2265,69003,66898,65543,68094,256,65675,69083,0]

theorem envBound59496 : H12AffineFastState.Bounded env59496 := by
  intro p hp
  have h : env59496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59495_59496 : H12AffineEnvironment.transform 20 65651 env59495 = env59496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65651 env59495 == env59496) = true)

theorem identity59496 : scanCanonicalize (H12AffineFastState.compose env59496 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 97) := by decide +kernel

theorem selectedBound59496 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59497 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2184,1409,2264,2128,65536,69083,97,1025,2128,65651,1417,64,3159,1288,17,66031,2265,69003,66898,65543,68094,256,65675,69083,0]

theorem envBound59497 : H12AffineFastState.Bounded env59497 := by
  intro p hp
  have h : env59497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59496_59497 : H12AffineEnvironment.transform 17 97 env59496 = env59497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97 env59496 == env59497) = true)

theorem identity59497 : scanCanonicalize (H12AffineFastState.compose env59497 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1245) := by decide +kernel

theorem selectedBound59497 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env59498 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1245,1109,1409,1029,1165,65536,65798,97,1025,1165,65651,1417,64,138,1288,17,66031,1028,65878,66898,65543,66851,256,65675,65798,0]

theorem envBound59498 : H12AffineFastState.Bounded env59498 := by
  intro p hp
  have h : env59498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59497_59498 : H12AffineEnvironment.transform 10 1245 env59497 = env59498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1245 env59497 == env59498) = true)

theorem identity59498 : scanCanonicalize (H12AffineFastState.compose env59498 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound59498 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59499 : List Nat := [2,4,8,16,32,64,128,256,0,408,325,461,25,413,277,65536,65798,97,409,277,65651,17,64,138,144,17,66031,412,65878,65738,65543,65723,256,65675,65798,0]

theorem envBound59499 : H12AffineFastState.Bounded env59499 := by
  intro p hp
  have h : env59499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59498_59499 : H12AffineEnvironment.transform 9 408 env59498 = env59499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env59498 == env59499) = true)

theorem identity59499 : scanCanonicalize (H12AffineFastState.compose env59499 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59499 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env59500 : List Nat := [2,4,8,16,17,64,128,256,0,408,325,461,25,413,277,65536,65798,80,409,277,65602,17,64,138,144,17,66014,412,65878,65738,65543,65674,256,65675,65798,0]

theorem envBound59500 : H12AffineFastState.Bounded env59500 := by
  intro p hp
  have h : env59500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59499_59500 : H12AffineEnvironment.transform 4 17 env59499 = env59500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59499 == env59500) = true)

theorem identity59500 : scanCanonicalize (H12AffineFastState.compose env59500 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 155) := by decide +kernel

theorem selectedBound59500 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59501 : List Nat := [2,4,8,16,17,64,128,256,0,408,325,461,25,413,277,155,413,80,409,277,217,17,64,138,144,17,325,412,461,81,156,17,256,16,413,0]

theorem envBound59501 : H12AffineFastState.Bounded env59501 := by
  intro p hp
  have h : env59501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59500_59501 : H12AffineEnvironment.transform 15 155 env59500 = env59501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 155 env59500 == env59501) = true)

theorem identity59501 : scanCanonicalize (H12AffineFastState.compose env59501 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 214) := by decide +kernel

theorem selectedBound59501 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59502 : List Nat := [2,4,8,16,17,64,128,214,0,78,147,27,25,75,195,155,75,80,79,195,217,17,64,138,144,17,147,74,27,81,156,17,214,16,75,0]

theorem envBound59502 : H12AffineFastState.Bounded env59502 := by
  intro p hp
  have h : env59502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59501_59502 : H12AffineEnvironment.transform 7 214 env59501 = env59502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 214 env59501 == env59502) = true)

theorem identity59502 : scanCanonicalize (H12AffineFastState.compose env59502 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound59502 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59503 : List Nat := [2,4,8,16,17,64,89,15,0,78,74,27,25,75,26,66,75,80,79,26,0,17,64,83,73,17,74,74,27,81,69,17,15,16,75,0]

theorem envBound59503 : H12AffineFastState.Bounded env59503 := by
  intro p hp
  have h : env59503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59502_59503 : H12AffineEnvironment.transform 6 89 env59502 = env59503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env59502 == env59503) = true)

theorem identity59503 : scanCanonicalize (H12AffineFastState.compose env59503 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound59503 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59504 : List Nat := [2,4,8,16,17,16,9,15,0,30,26,27,25,27,26,18,27,0,31,26,0,17,16,3,25,17,26,26,27,1,21,17,15,16,27,0]

theorem envBound59504 : H12AffineFastState.Bounded env59504 := by
  intro p hp
  have h : env59504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59503_59504 : H12AffineEnvironment.transform 5 16 env59503 = env59504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59503 == env59504) = true)

def env59505 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9665,3158,1288,9616,2365812,4177,77954,66899,65543,68095,256,65675,78034,9600]

theorem envBound59505 : H12AffineFastState.Bounded env59505 := by
  intro p hp
  have h : env59505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59479_59505 : H12AffineEnvironment.transform 8 1 env59479 = env59505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59479 == env59505) = true)

theorem identity59505 : scanCanonicalize (H12AffineFastState.compose env59505 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 7433) := by decide +kernel

theorem selectedBound59505 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59506 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,7433,4176,2129,65536,69083,262144,1025,2129,2097152,1417,6344,3158,1288,6297,2365812,4177,69003,66899,65543,68095,256,65675,69083,6281]

theorem envBound59506 : H12AffineFastState.Bounded env59506 := by
  intro p hp
  have h : env59506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59505_59506 : H12AffineEnvironment.transform 12 7433 env59505 = env59506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7433 env59505 == env59506) = true)

def env59507 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2184,1409,2264,2129,65536,69083,262144,1025,2129,2097152,1417,64,3158,1288,17,2359804,2265,69003,66899,65543,68095,256,65675,69083,1]

theorem envBound59507 : H12AffineFastState.Bounded env59507 := by
  intro p hp
  have h : env59507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59506_59507 : H12AffineEnvironment.transform 11 2184 env59506 = env59507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2184 env59506 == env59507) = true)

theorem identity59507 : scanCanonicalize (H12AffineFastState.compose env59507 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 65650) := by decide +kernel

theorem selectedBound59507 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59508 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2184,1409,2264,2129,65536,69083,262144,1025,2129,65650,1417,64,3158,1288,17,328078,2265,69003,66899,65543,68095,256,65675,69083,1]

theorem envBound59508 : H12AffineFastState.Bounded env59508 := by
  intro p hp
  have h : env59508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59507_59508 : H12AffineEnvironment.transform 20 65650 env59507 = env59508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65650 env59507 == env59508) = true)

theorem identity59508 : scanCanonicalize (H12AffineFastState.compose env59508 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 96) := by decide +kernel

theorem selectedBound59508 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59509 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2184,1409,2264,2129,65536,69083,96,1025,2129,65650,1417,64,3158,1288,17,66030,2265,69003,66899,65543,68095,256,65675,69083,1]

theorem envBound59509 : H12AffineFastState.Bounded env59509 := by
  intro p hp
  have h : env59509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59508_59509 : H12AffineEnvironment.transform 17 96 env59508 = env59509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 96 env59508 == env59509) = true)

theorem identity59509 : scanCanonicalize (H12AffineFastState.compose env59509 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1244) := by decide +kernel

theorem selectedBound59509 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env59510 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1244,1108,1409,1028,1165,65536,65799,96,1025,1165,65650,1417,64,138,1288,17,66030,1029,65879,66899,65543,66851,256,65675,65799,1]

theorem envBound59510 : H12AffineFastState.Bounded env59510 := by
  intro p hp
  have h : env59510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59509_59510 : H12AffineEnvironment.transform 10 1244 env59509 = env59510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1244 env59509 == env59510) = true)

theorem identity59510 : scanCanonicalize (H12AffineFastState.compose env59510 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound59510 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59511 : List Nat := [2,4,8,16,32,64,128,256,1,408,324,460,25,412,277,65536,65799,96,409,277,65650,17,64,138,144,17,66030,413,65879,65739,65543,65723,256,65675,65799,1]

theorem envBound59511 : H12AffineFastState.Bounded env59511 := by
  intro p hp
  have h : env59511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59510_59511 : H12AffineEnvironment.transform 9 408 env59510 = env59511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env59510 == env59511) = true)

theorem identity59511 : scanCanonicalize (H12AffineFastState.compose env59511 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59511 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env59512 : List Nat := [2,4,8,16,17,64,128,256,1,408,324,460,25,412,277,65536,65799,81,409,277,65603,17,64,138,144,17,66015,413,65879,65739,65543,65674,256,65675,65799,1]

theorem envBound59512 : H12AffineFastState.Bounded env59512 := by
  intro p hp
  have h : env59512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59511_59512 : H12AffineEnvironment.transform 4 17 env59511 = env59512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59511 == env59512) = true)

theorem identity59512 : scanCanonicalize (H12AffineFastState.compose env59512 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 155) := by decide +kernel

theorem selectedBound59512 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59513 : List Nat := [2,4,8,16,17,64,128,256,1,408,324,460,25,412,277,155,412,81,409,277,216,17,64,138,144,17,324,413,460,80,156,17,256,16,412,1]

theorem envBound59513 : H12AffineFastState.Bounded env59513 := by
  intro p hp
  have h : env59513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59512_59513 : H12AffineEnvironment.transform 15 155 env59512 = env59513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 155 env59512 == env59513) = true)

theorem identity59513 : scanCanonicalize (H12AffineFastState.compose env59513 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 215) := by decide +kernel

theorem selectedBound59513 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59514 : List Nat := [2,4,8,16,17,64,128,215,1,79,147,27,25,75,194,155,75,81,78,194,216,17,64,138,144,17,147,74,27,80,156,17,215,16,75,1]

theorem envBound59514 : H12AffineFastState.Bounded env59514 := by
  intro p hp
  have h : env59514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59513_59514 : H12AffineEnvironment.transform 7 215 env59513 = env59514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 215 env59513 == env59514) = true)

def env59515 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2185,1408,2265,2129,65536,69083,262144,1025,2129,2097152,1417,65,3158,1288,16,2359805,2264,69003,66899,65543,68095,256,65675,69083,0]

theorem envBound59515 : H12AffineFastState.Bounded env59515 := by
  intro p hp
  have h : env59515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59506_59515 : H12AffineEnvironment.transform 11 2185 env59506 = env59515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2185 env59506 == env59515) = true)

theorem identity59515 : scanCanonicalize (H12AffineFastState.compose env59515 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 372) := by decide +kernel

theorem selectedBound59515 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59516 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2185,1408,2265,2129,65536,69083,262144,1025,2129,372,1417,65,3158,1288,16,262281,2264,69003,66899,65543,68095,256,65675,69083,0]

theorem envBound59516 : H12AffineFastState.Bounded env59516 := by
  intro p hp
  have h : env59516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59515_59516 : H12AffineEnvironment.transform 20 372 env59515 = env59516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 372 env59515 == env59516) = true)

theorem identity59516 : scanCanonicalize (H12AffineFastState.compose env59516 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59516 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59517 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1393,1408,1313,1449,65536,65571,262144,1025,1449,372,1417,65,430,1288,16,262281,1312,65651,66899,65543,66567,256,65675,65571,0]

theorem envBound59517 : H12AffineFastState.Bounded env59517 := by
  intro p hp
  have h : env59517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59516_59517 : H12AffineEnvironment.transform 10 1528 env59516 = env59517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59516 == env59517) = true)

theorem identity59517 : scanCanonicalize (H12AffineFastState.compose env59517 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 445) := by decide +kernel

theorem selectedBound59517 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59518 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1393,1408,1313,1449,65536,65571,445,1025,1449,372,1417,65,430,1288,16,308,1312,65651,66899,65543,66567,256,65675,65571,0]

theorem envBound59518 : H12AffineFastState.Bounded env59518 := by
  intro p hp
  have h : env59518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59517_59518 : H12AffineEnvironment.transform 17 445 env59517 = env59518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 445 env59517 == env59518) = true)

theorem identity59518 : scanCanonicalize (H12AffineFastState.compose env59518 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound59518 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59519 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1393,1408,1313,1449,1063,1028,445,1025,1449,372,1417,65,430,1288,16,308,1312,1108,372,1056,32,256,1196,1028,0]

theorem envBound59519 : H12AffineFastState.Bounded env59519 := by
  intro p hp
  have h : env59519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59518_59519 : H12AffineEnvironment.transform 15 1063 env59518 = env59519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env59518 == env59519) = true)

theorem identity59519 : scanCanonicalize (H12AffineFastState.compose env59519 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound59519 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59520 : List Nat := [2,4,8,16,32,64,128,252,1,1024,1028,1165,1148,1245,1109,1063,1028,65,1025,1109,136,1141,65,82,1268,16,200,1244,1108,136,1056,32,252,1196,1028,0]

theorem envBound59520 : H12AffineFastState.Bounded env59520 := by
  intro p hp
  have h : env59520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59519_59520 : H12AffineEnvironment.transform 7 252 env59519 = env59520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env59519 == env59520) = true)

theorem identity59520 : scanCanonicalize (H12AffineFastState.compose env59520 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound59520 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59521 : List Nat := [2,4,8,16,32,64,128,252,1,140,136,1,240,81,217,171,136,65,141,217,136,249,65,82,120,16,200,80,216,136,172,32,252,32,136,0]

theorem envBound59521 : H12AffineFastState.Bounded env59521 := by
  intro p hp
  have h : env59521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59520_59521 : H12AffineEnvironment.transform 9 140 env59520 = env59521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env59520 == env59521) = true)

theorem identity59521 : scanCanonicalize (H12AffineFastState.compose env59521 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 73) := by decide +kernel

theorem selectedBound59521 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env59522 : List Nat := [2,4,8,16,32,64,73,53,1,69,65,1,57,81,16,98,65,65,68,16,65,48,65,82,120,16,1,80,17,65,101,32,53,32,65,0]

theorem envBound59522 : H12AffineFastState.Bounded env59522 := by
  intro p hp
  have h : env59522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59521_59522 : H12AffineEnvironment.transform 6 73 env59521 = env59522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env59521 == env59522) = true)

theorem identity59522 : scanCanonicalize (H12AffineFastState.compose env59522 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound59522 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env59523 : List Nat := [2,4,8,16,0,64,73,21,1,69,65,1,25,81,16,66,65,65,68,16,65,16,65,82,88,16,1,80,17,65,69,0,21,0,65,0]

theorem envBound59523 : H12AffineFastState.Bounded env59523 := by
  intro p hp
  have h : env59523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59522_59523 : H12AffineEnvironment.transform 4 0 env59522 = env59523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env59522 == env59523) = true)

theorem identity59523 : scanCanonicalize (H12AffineFastState.compose env59523 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound59523 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59524 : List Nat := [2,4,8,2,0,64,73,7,1,69,65,1,11,67,2,66,65,65,68,2,65,2,65,64,74,2,1,66,3,65,69,0,7,0,65,0]

theorem envBound59524 : H12AffineFastState.Bounded env59524 := by
  intro p hp
  have h : env59524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59523_59524 : H12AffineEnvironment.transform 3 2 env59523 = env59524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env59523 == env59524) = true)

theorem identity59524 : scanCanonicalize (H12AffineFastState.compose env59524 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 8) := by decide +kernel

theorem selectedBound59524 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59525 : List Nat := [2,4,8,2,0,8,1,7,1,13,9,1,11,11,2,10,9,9,12,2,9,2,9,8,2,2,1,10,3,9,13,0,7,0,9,0]

theorem envBound59525 : H12AffineFastState.Bounded env59525 := by
  intro p hp
  have h : env59525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59524_59525 : H12AffineEnvironment.transform 5 8 env59524 = env59525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 8 env59524 == env59525) = true)

theorem identity59525 : scanCanonicalize (H12AffineFastState.compose env59525 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59525 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59526 : List Nat := [1,4,8,1,0,8,1,4,1,13,9,1,8,8,1,9,9,9,12,1,9,1,9,8,1,1,1,9,0,9,13,0,4,0,9,0]

theorem envBound59526 : H12AffineFastState.Bounded env59526 := by
  intro p hp
  have h : env59526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59525_59526 : H12AffineEnvironment.transform 0 1 env59525 = env59526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59525 == env59526) = true)

theorem identity59526 : scanCanonicalize (H12AffineFastState.compose env59526 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound59526 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59527 : List Nat := [1,4,1,1,0,1,1,4,1,4,0,1,1,1,1,0,0,0,5,1,0,1,0,1,1,1,1,0,0,0,4,0,4,0,0,0]

theorem envBound59527 : H12AffineFastState.Bounded env59527 := by
  intro p hp
  have h : env59527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59526_59527 : H12AffineEnvironment.transform 2 1 env59526 = env59527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env59526 == env59527) = true)

def env59528 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,4194304,8388608,8399766,8397001,8388689,6561533,4177,77954,4260571,8463814,8465982,256,4261123,78034,8389184]

theorem envBound59528 : H12AffineFastState.Bounded env59528 := by
  intro p hp
  have h : env59528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59345_59528 : H12AffineEnvironment.transform 26 6561533 env59345 = env59528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 6561533 env59345 == env59528) = true)

def env59529 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1416,8388608,8399766,8397001,8388689,2366325,4177,77954,67411,8463814,8465982,256,65675,78034,8389184]

theorem envBound59529 : H12AffineFastState.Bounded env59529 := by
  intro p hp
  have h : env59529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59528_59529 : H12AffineEnvironment.transform 21 1416 env59528 = env59529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1416 env59528 == env59529) = true)

def env59530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1416,9664,3670,1289,9617,2366325,4177,77954,67411,65542,68606,256,65675,78034,10112]

theorem envBound59530 : H12AffineFastState.Bounded env59530 := by
  intro p hp
  have h : env59530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59529_59530 : H12AffineEnvironment.transform 22 9664 env59529 = env59530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env59529 == env59530) = true)

def env59531 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9664,3158,1289,9617,2365813,4177,77954,66899,65542,68094,256,65675,78034,9600]

theorem envBound59531 : H12AffineFastState.Bounded env59531 := by
  intro p hp
  have h : env59531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59530_59531 : H12AffineEnvironment.transform 8 0 env59530 = env59531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59530 == env59531) = true)

theorem identity59531 : scanCanonicalize (H12AffineFastState.compose env59531 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 65650) := by decide +kernel

theorem selectedBound59531 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59532 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,65650,1416,9664,3158,1289,9617,334087,4177,77954,66899,65542,68094,256,65675,78034,9600]

theorem envBound59532 : H12AffineFastState.Bounded env59532 := by
  intro p hp
  have h : env59532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59531_59532 : H12AffineEnvironment.transform 20 65650 env59531 = env59532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65650 env59531 == env59532) = true)

def env59533 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,65650,1416,64,3158,1289,17,334087,4177,70914,66899,65542,68094,256,65675,70994,0]

theorem envBound59533 : H12AffineFastState.Bounded env59533 := by
  intro p hp
  have h : env59533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59532_59533 : H12AffineEnvironment.transform 12 1408 env59532 = env59533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59532 == env59533) = true)

theorem identity59533 : scanCanonicalize (H12AffineFastState.compose env59533 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 2185) := by decide +kernel

theorem selectedBound59533 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59534 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2185,1408,2265,2128,65536,69083,262144,1025,2128,65650,1416,64,3158,1289,17,328078,2264,69003,66899,65542,68094,256,65675,69083,0]

theorem envBound59534 : H12AffineFastState.Bounded env59534 := by
  intro p hp
  have h : env59534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59533_59534 : H12AffineEnvironment.transform 11 2185 env59533 = env59534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2185 env59533 == env59534) = true)

theorem identity59534 : scanCanonicalize (H12AffineFastState.compose env59534 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 97) := by decide +kernel

theorem selectedBound59534 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59535 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2185,1408,2265,2128,65536,69083,97,1025,2128,65650,1416,64,3158,1289,17,66031,2264,69003,66899,65542,68094,256,65675,69083,0]

theorem envBound59535 : H12AffineFastState.Bounded env59535 := by
  intro p hp
  have h : env59535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59534_59535 : H12AffineEnvironment.transform 17 97 env59534 = env59535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97 env59534 == env59535) = true)

theorem identity59535 : scanCanonicalize (H12AffineFastState.compose env59535 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1244) := by decide +kernel

theorem selectedBound59535 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env59536 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1244,1109,1408,1029,1164,65536,65799,97,1025,1164,65650,1416,64,138,1289,17,66031,1028,65879,66899,65542,66850,256,65675,65799,0]

theorem envBound59536 : H12AffineFastState.Bounded env59536 := by
  intro p hp
  have h : env59536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59535_59536 : H12AffineEnvironment.transform 10 1244 env59535 = env59536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1244 env59535 == env59536) = true)

theorem identity59536 : scanCanonicalize (H12AffineFastState.compose env59536 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound59536 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59537 : List Nat := [2,4,8,16,32,64,128,256,0,409,325,460,25,412,277,65536,65799,97,408,277,65650,17,64,138,144,17,66031,413,65879,65738,65542,65723,256,65675,65799,0]

theorem envBound59537 : H12AffineFastState.Bounded env59537 := by
  intro p hp
  have h : env59537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59536_59537 : H12AffineEnvironment.transform 9 409 env59536 = env59537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env59536 == env59537) = true)

theorem identity59537 : scanCanonicalize (H12AffineFastState.compose env59537 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59537 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env59538 : List Nat := [2,4,8,16,17,64,128,256,0,409,325,460,25,412,277,65536,65799,80,408,277,65603,17,64,138,144,17,66014,413,65879,65738,65542,65674,256,65675,65799,0]

theorem envBound59538 : H12AffineFastState.Bounded env59538 := by
  intro p hp
  have h : env59538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59537_59538 : H12AffineEnvironment.transform 4 17 env59537 = env59538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59537 == env59538) = true)

theorem identity59538 : scanCanonicalize (H12AffineFastState.compose env59538 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 155) := by decide +kernel

theorem selectedBound59538 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59539 : List Nat := [2,4,8,16,17,64,128,256,0,409,325,460,25,412,277,155,412,80,408,277,216,17,64,138,144,17,325,413,460,81,157,17,256,16,412,0]

theorem envBound59539 : H12AffineFastState.Bounded env59539 := by
  intro p hp
  have h : env59539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59538_59539 : H12AffineEnvironment.transform 15 155 env59538 = env59539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 155 env59538 == env59539) = true)

theorem identity59539 : scanCanonicalize (H12AffineFastState.compose env59539 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 214) := by decide +kernel

theorem selectedBound59539 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59540 : List Nat := [2,4,8,16,17,64,128,214,0,79,147,26,25,74,195,155,74,80,78,195,216,17,64,138,144,17,147,75,26,81,157,17,214,16,74,0]

theorem envBound59540 : H12AffineFastState.Bounded env59540 := by
  intro p hp
  have h : env59540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59539_59540 : H12AffineEnvironment.transform 7 214 env59539 = env59540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 214 env59539 == env59540) = true)

theorem identity59540 : scanCanonicalize (H12AffineFastState.compose env59540 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound59540 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59541 : List Nat := [2,4,8,16,17,64,89,15,0,79,74,26,25,74,26,66,74,80,78,26,1,17,64,83,73,17,74,75,26,81,68,17,15,16,74,0]

theorem envBound59541 : H12AffineFastState.Bounded env59541 := by
  intro p hp
  have h : env59541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59540_59541 : H12AffineEnvironment.transform 6 89 env59540 = env59541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env59540 == env59541) = true)

theorem identity59541 : scanCanonicalize (H12AffineFastState.compose env59541 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound59541 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59542 : List Nat := [2,4,8,16,17,16,9,15,0,31,26,26,25,26,26,18,26,0,30,26,1,17,16,3,25,17,26,27,26,1,20,17,15,16,26,0]

theorem envBound59542 : H12AffineFastState.Bounded env59542 := by
  intro p hp
  have h : env59542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59541_59542 : H12AffineEnvironment.transform 5 16 env59541 = env59542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59541 == env59542) = true)

def env59543 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,65650,1416,65,3158,1289,16,334087,4177,70915,66899,65542,68094,256,65675,70995,1]

theorem envBound59543 : H12AffineFastState.Bounded env59543 := by
  intro p hp
  have h : env59543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59532_59543 : H12AffineEnvironment.transform 12 1409 env59532 = env59543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59532 == env59543) = true)

theorem identity59543 : scanCanonicalize (H12AffineFastState.compose env59543 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 6542) := by decide +kernel

theorem selectedBound59543 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59544 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,6542,3293,262144,1025,2128,6652,1416,65,3158,1289,16,262281,4177,3213,7389,6536,4208,256,6405,3293,1]

theorem envBound59544 : H12AffineFastState.Bounded env59544 := by
  intro p hp
  have h : env59544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59543_59544 : H12AffineEnvironment.transform 15 6542 env59543 = env59544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6542 env59543 == env59544) = true)

theorem identity59544 : scanCanonicalize (H12AffineFastState.compose env59544 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59544 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59545 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1409,4176,1448,5238,293,262144,1025,1448,5124,1416,65,430,1289,16,262281,4177,373,4389,5232,4208,256,5373,293,1]

theorem envBound59545 : H12AffineFastState.Bounded env59545 := by
  intro p hp
  have h : env59545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59544_59545 : H12AffineEnvironment.transform 10 1528 env59544 = env59545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59544 == env59545) = true)

theorem identity59545 : scanCanonicalize (H12AffineFastState.compose env59545 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5324) := by decide +kernel

theorem selectedBound59545 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59546 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1409,4176,1448,5238,293,5324,1025,1448,5124,1416,65,430,1289,16,5189,4177,373,4389,5232,4208,256,5373,293,1]

theorem envBound59546 : H12AffineFastState.Bounded env59546 := by
  intro p hp
  have h : env59546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59545_59546 : H12AffineEnvironment.transform 17 5324 env59545 = env59546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5324 env59545 == env59546) = true)

theorem identity59546 : scanCanonicalize (H12AffineFastState.compose env59546 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound59546 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59547 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,80,1409,0,1448,1062,293,1180,1025,1448,1108,1416,65,430,1289,16,1045,1,373,373,1056,32,256,1197,293,1]

theorem envBound59547 : H12AffineFastState.Bounded env59547 := by
  intro p hp
  have h : env59547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59546_59547 : H12AffineEnvironment.transform 11 80 env59546 = env59547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env59546 == env59547) = true)

theorem identity59547 : scanCanonicalize (H12AffineFastState.compose env59547 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound59547 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59548 : List Nat := [2,4,8,16,32,64,128,253,0,1024,1029,80,1148,0,1109,1062,216,1180,1025,1109,1108,1141,65,83,1268,16,1045,1,136,136,1056,32,253,1197,216,1]

theorem envBound59548 : H12AffineFastState.Bounded env59548 := by
  intro p hp
  have h : env59548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59547_59548 : H12AffineEnvironment.transform 7 253 env59547 = env59548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env59547 == env59548) = true)

theorem identity59548 : scanCanonicalize (H12AffineFastState.compose env59548 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound59548 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59549 : List Nat := [2,4,8,16,32,64,128,253,0,141,136,80,241,0,216,171,216,17,140,216,217,248,65,83,121,16,152,1,136,136,173,32,253,32,216,1]

theorem envBound59549 : H12AffineFastState.Bounded env59549 := by
  intro p hp
  have h : env59549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59548_59549 : H12AffineEnvironment.transform 9 141 env59548 = env59549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env59548 == env59549) = true)

theorem identity59549 : scanCanonicalize (H12AffineFastState.compose env59549 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound59549 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env59550 : List Nat := [2,4,8,16,16,64,128,205,0,141,136,80,193,0,216,155,216,17,140,216,217,200,65,83,73,16,152,1,136,136,157,16,205,16,216,1]

theorem envBound59550 : H12AffineFastState.Bounded env59550 := by
  intro p hp
  have h : env59550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59549_59550 : H12AffineEnvironment.transform 4 16 env59549 = env59550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env59549 == env59550) = true)

theorem identity59550 : scanCanonicalize (H12AffineFastState.compose env59550 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 27) := by decide +kernel

theorem selectedBound59550 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59551 : List Nat := [2,4,8,16,16,64,27,86,0,22,19,80,90,0,67,0,67,17,23,67,66,83,65,83,73,16,3,1,19,19,6,16,86,16,67,1]

theorem envBound59551 : H12AffineFastState.Bounded env59551 := by
  intro p hp
  have h : env59551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59550_59551 : H12AffineEnvironment.transform 6 27 env59550 = env59551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 27 env59550 == env59551) = true)

theorem identity59551 : scanCanonicalize (H12AffineFastState.compose env59551 (packedSelected [4,7] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound59551 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env59552 : List Nat := [2,4,8,9,9,64,2,79,0,15,10,73,67,0,67,0,67,8,14,67,66,74,65,74,73,9,3,1,10,10,6,9,79,9,67,1]

theorem envBound59552 : H12AffineFastState.Bounded env59552 := by
  intro p hp
  have h : env59552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59551_59552 : H12AffineEnvironment.transform 3 9 env59551 = env59552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env59551 == env59552) = true)

def env59553 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9664,3159,1289,9617,2365812,4177,77954,66898,65542,68095,256,65675,78034,9601]

theorem envBound59553 : H12AffineFastState.Bounded env59553 := by
  intro p hp
  have h : env59553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59530_59553 : H12AffineEnvironment.transform 8 1 env59530 = env59553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59530 == env59553) = true)

theorem identity59553 : scanCanonicalize (H12AffineFastState.compose env59553 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 75251) := by decide +kernel

theorem selectedBound59553 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59554 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,75251,1416,9664,3159,1289,9617,343175,4177,77954,66898,65542,68095,256,65675,78034,9601]

theorem envBound59554 : H12AffineFastState.Bounded env59554 := by
  intro p hp
  have h : env59554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59553_59554 : H12AffineEnvironment.transform 20 75251 env59553 = env59554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 75251 env59553 == env59554) = true)

def env59555 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,65651,1416,64,3159,1289,17,334087,4177,70914,66898,65542,68095,256,65675,70994,1]

theorem envBound59555 : H12AffineFastState.Bounded env59555 := by
  intro p hp
  have h : env59555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59554_59555 : H12AffineEnvironment.transform 12 1408 env59554 = env59555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59554 == env59555) = true)

theorem identity59555 : scanCanonicalize (H12AffineFastState.compose env59555 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 2185) := by decide +kernel

theorem selectedBound59555 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59556 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2185,1408,2265,2129,65536,69083,262144,1025,2129,65651,1416,64,3159,1289,17,328078,2264,69003,66898,65542,68095,256,65675,69083,1]

theorem envBound59556 : H12AffineFastState.Bounded env59556 := by
  intro p hp
  have h : env59556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59555_59556 : H12AffineEnvironment.transform 11 2185 env59555 = env59556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2185 env59555 == env59556) = true)

theorem identity59556 : scanCanonicalize (H12AffineFastState.compose env59556 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 96) := by decide +kernel

theorem selectedBound59556 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59557 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2185,1408,2265,2129,65536,69083,96,1025,2129,65651,1416,64,3159,1289,17,66030,2264,69003,66898,65542,68095,256,65675,69083,1]

theorem envBound59557 : H12AffineFastState.Bounded env59557 := by
  intro p hp
  have h : env59557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59556_59557 : H12AffineEnvironment.transform 17 96 env59556 = env59557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 96 env59556 == env59557) = true)

theorem identity59557 : scanCanonicalize (H12AffineFastState.compose env59557 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1245) := by decide +kernel

theorem selectedBound59557 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env59558 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1245,1108,1408,1028,1164,65536,65798,96,1025,1164,65651,1416,64,138,1289,17,66030,1029,65878,66898,65542,66850,256,65675,65798,1]

theorem envBound59558 : H12AffineFastState.Bounded env59558 := by
  intro p hp
  have h : env59558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59557_59558 : H12AffineEnvironment.transform 10 1245 env59557 = env59558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1245 env59557 == env59558) = true)

theorem identity59558 : scanCanonicalize (H12AffineFastState.compose env59558 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound59558 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59559 : List Nat := [2,4,8,16,32,64,128,256,1,409,324,461,25,413,277,65536,65798,96,408,277,65651,17,64,138,144,17,66030,412,65878,65739,65542,65723,256,65675,65798,1]

theorem envBound59559 : H12AffineFastState.Bounded env59559 := by
  intro p hp
  have h : env59559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59558_59559 : H12AffineEnvironment.transform 9 409 env59558 = env59559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env59558 == env59559) = true)

theorem identity59559 : scanCanonicalize (H12AffineFastState.compose env59559 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59559 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env59560 : List Nat := [2,4,8,16,17,64,128,256,1,409,324,461,25,413,277,65536,65798,81,408,277,65602,17,64,138,144,17,66015,412,65878,65739,65542,65674,256,65675,65798,1]

theorem envBound59560 : H12AffineFastState.Bounded env59560 := by
  intro p hp
  have h : env59560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59559_59560 : H12AffineEnvironment.transform 4 17 env59559 = env59560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59559 == env59560) = true)

theorem identity59560 : scanCanonicalize (H12AffineFastState.compose env59560 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 155) := by decide +kernel

theorem selectedBound59560 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59561 : List Nat := [2,4,8,16,17,64,128,256,1,409,324,461,25,413,277,155,413,81,408,277,217,17,64,138,144,17,324,412,461,80,157,17,256,16,413,1]

theorem envBound59561 : H12AffineFastState.Bounded env59561 := by
  intro p hp
  have h : env59561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59560_59561 : H12AffineEnvironment.transform 15 155 env59560 = env59561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 155 env59560 == env59561) = true)

theorem identity59561 : scanCanonicalize (H12AffineFastState.compose env59561 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 215) := by decide +kernel

theorem selectedBound59561 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59562 : List Nat := [2,4,8,16,17,64,128,215,1,78,147,26,25,74,194,155,74,81,79,194,217,17,64,138,144,17,147,75,26,80,157,17,215,16,74,1]

theorem envBound59562 : H12AffineFastState.Bounded env59562 := by
  intro p hp
  have h : env59562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59561_59562 : H12AffineEnvironment.transform 7 215 env59561 = env59562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 215 env59561 == env59562) = true)

def env59563 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,65650,1416,65,3159,1289,16,334086,4177,70915,66898,65542,68095,256,65675,70995,0]

theorem envBound59563 : H12AffineFastState.Bounded env59563 := by
  intro p hp
  have h : env59563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59554_59563 : H12AffineEnvironment.transform 12 1409 env59554 = env59563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59554 == env59563) = true)

theorem identity59563 : scanCanonicalize (H12AffineFastState.compose env59563 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 6543) := by decide +kernel

theorem selectedBound59563 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59564 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,6543,3292,262144,1025,2129,6653,1416,65,3159,1289,16,262281,4177,3212,7389,6537,4208,256,6404,3292,0]

theorem envBound59564 : H12AffineFastState.Bounded env59564 := by
  intro p hp
  have h : env59564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59563_59564 : H12AffineEnvironment.transform 15 6543 env59563 = env59564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6543 env59563 == env59564) = true)

theorem identity59564 : scanCanonicalize (H12AffineFastState.compose env59564 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59564 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59565 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1409,4176,1448,5238,293,262144,1025,1448,5124,1416,65,430,1289,16,262281,4177,373,4388,5232,4208,256,5373,293,0]

theorem envBound59565 : H12AffineFastState.Bounded env59565 := by
  intro p hp
  have h : env59565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59564_59565 : H12AffineEnvironment.transform 10 1529 env59564 = env59565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59564 == env59565) = true)

theorem identity59565 : scanCanonicalize (H12AffineFastState.compose env59565 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5324) := by decide +kernel

theorem selectedBound59565 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59566 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1409,4176,1448,5238,293,5324,1025,1448,5124,1416,65,430,1289,16,5189,4177,373,4388,5232,4208,256,5373,293,0]

theorem envBound59566 : H12AffineFastState.Bounded env59566 := by
  intro p hp
  have h : env59566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59565_59566 : H12AffineEnvironment.transform 17 5324 env59565 = env59566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5324 env59565 == env59566) = true)

theorem identity59566 : scanCanonicalize (H12AffineFastState.compose env59566 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound59566 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59567 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,80,1409,0,1448,1062,293,1180,1025,1448,1108,1416,65,430,1289,16,1045,1,373,372,1056,32,256,1197,293,0]

theorem envBound59567 : H12AffineFastState.Bounded env59567 := by
  intro p hp
  have h : env59567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59566_59567 : H12AffineEnvironment.transform 11 80 env59566 = env59567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env59566 == env59567) = true)

theorem identity59567 : scanCanonicalize (H12AffineFastState.compose env59567 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound59567 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59568 : List Nat := [2,4,8,16,32,64,128,252,1,1024,1029,80,1149,0,1108,1062,217,1180,1025,1108,1108,1140,65,82,1269,16,1045,1,137,136,1056,32,252,1197,217,0]

theorem envBound59568 : H12AffineFastState.Bounded env59568 := by
  intro p hp
  have h : env59568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59567_59568 : H12AffineEnvironment.transform 7 252 env59567 = env59568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env59567 == env59568) = true)

theorem identity59568 : scanCanonicalize (H12AffineFastState.compose env59568 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound59568 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59569 : List Nat := [2,4,8,16,32,16,128,172,1,1024,1029,0,1069,0,1028,1062,137,1180,1025,1028,1028,1060,17,2,1189,16,1045,1,137,136,1056,32,172,1197,137,0]

theorem envBound59569 : H12AffineFastState.Bounded env59569 := by
  intro p hp
  have h : env59569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59568_59569 : H12AffineEnvironment.transform 5 16 env59568 = env59569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59568 == env59569) = true)

theorem identity59569 : scanCanonicalize (H12AffineFastState.compose env59569 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 159) := by decide +kernel

theorem selectedBound59569 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59570 : List Nat := [2,4,8,16,32,16,128,172,1,159,154,0,178,0,155,185,137,3,158,155,155,187,17,2,58,16,138,1,137,136,191,32,172,50,137,0]

theorem envBound59570 : H12AffineFastState.Bounded env59570 := by
  intro p hp
  have h : env59570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59569_59570 : H12AffineEnvironment.transform 9 159 env59569 = env59570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 159 env59569 == env59570) = true)

theorem identity59570 : scanCanonicalize (H12AffineFastState.compose env59570 (packedSelected [1,3,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound59570 : packedSelected [1,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env59571 : List Nat := [2,4,8,16,32,16,24,52,1,7,2,0,42,0,3,33,17,3,6,3,3,35,17,2,58,16,18,1,17,16,39,32,52,50,17,0]

theorem envBound59571 : H12AffineFastState.Bounded env59571 := by
  intro p hp
  have h : env59571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59570_59571 : H12AffineEnvironment.transform 6 24 env59570 = env59571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env59570 == env59571) = true)

theorem identity59571 : scanCanonicalize (H12AffineFastState.compose env59571 (packedSelected [6,7] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound59571 : packedSelected [6,7] rootPS < 2^1333 := by decide +kernel

def env59572 : List Nat := [2,4,8,16,2,16,24,22,1,7,2,0,8,0,3,3,17,3,6,3,3,1,17,2,24,16,18,1,17,16,5,2,22,16,17,0]

theorem envBound59572 : H12AffineFastState.Bounded env59572 := by
  intro p hp
  have h : env59572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59571_59572 : H12AffineEnvironment.transform 4 2 env59571 = env59572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env59571 == env59572) = true)

theorem identity59572 : scanCanonicalize (H12AffineFastState.compose env59572 (packedSelected [4,6] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound59572 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env59573 : List Nat := [2,4,8,8,2,8,0,14,1,7,2,0,8,0,3,3,9,3,6,3,3,1,9,2,0,8,10,1,9,8,5,2,14,8,9,0]

theorem envBound59573 : H12AffineFastState.Bounded env59573 := by
  intro p hp
  have h : env59573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59572_59573 : H12AffineEnvironment.transform 3 8 env59572 = env59573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env59572 == env59573) = true)

def env59574 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1416,9665,3671,1288,9616,2366325,4177,77954,67411,65543,68607,256,65675,78034,10113]

theorem envBound59574 : H12AffineFastState.Bounded env59574 := by
  intro p hp
  have h : env59574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59529_59574 : H12AffineEnvironment.transform 22 9665 env59529 = env59574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env59529 == env59574) = true)

def env59575 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9665,3159,1288,9616,2365813,4177,77954,66899,65543,68095,256,65675,78034,9601]

theorem envBound59575 : H12AffineFastState.Bounded env59575 := by
  intro p hp
  have h : env59575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59574_59575 : H12AffineEnvironment.transform 8 0 env59574 = env59575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59574 == env59575) = true)

theorem identity59575 : scanCanonicalize (H12AffineFastState.compose env59575 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 15779) := by decide +kernel

theorem selectedBound59575 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59576 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,15779,3441,262144,1025,2128,2097152,1416,9665,3159,1288,9616,2365813,4177,3361,14576,15780,13404,256,15656,3441,9601]

theorem envBound59576 : H12AffineFastState.Bounded env59576 := by
  intro p hp
  have h : env59576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59575_59576 : H12AffineEnvironment.transform 15 15779 env59575 = env59576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 15779 env59575 == env59576) = true)

def env59577 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,6179,3441,262144,1025,2128,2097152,1416,65,3159,1288,16,2365813,4177,3361,7536,6180,4572,256,6312,3441,1]

theorem envBound59577 : H12AffineFastState.Bounded env59577 := by
  intro p hp
  have h : env59577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59576_59577 : H12AffineEnvironment.transform 12 1408 env59576 = env59577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59576 == env59577) = true)

theorem identity59577 : scanCanonicalize (H12AffineFastState.compose env59577 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6652) := by decide +kernel

theorem selectedBound59577 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59578 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,6179,3441,262144,1025,2128,6652,1416,65,3159,1288,16,262281,4177,3361,7536,6180,4572,256,6312,3441,1]

theorem envBound59578 : H12AffineFastState.Bounded env59578 := by
  intro p hp
  have h : env59578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59577_59578 : H12AffineEnvironment.transform 20 6652 env59577 = env59578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6652 env59577 == env59578) = true)

theorem identity59578 : scanCanonicalize (H12AffineFastState.compose env59578 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59578 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59579 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1408,4176,1448,5595,137,262144,1025,1448,5124,1416,65,431,1288,16,262281,4177,217,4232,5596,4572,256,5456,137,1]

theorem envBound59579 : H12AffineFastState.Bounded env59579 := by
  intro p hp
  have h : env59579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59578_59579 : H12AffineEnvironment.transform 10 1528 env59578 = env59579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59578 == env59579) = true)

theorem identity59579 : scanCanonicalize (H12AffineFastState.compose env59579 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5325) := by decide +kernel

theorem selectedBound59579 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59580 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1408,4176,1448,5595,137,5325,1025,1448,5124,1416,65,431,1288,16,5188,4177,217,4232,5596,4572,256,5456,137,1]

theorem envBound59580 : H12AffineFastState.Bounded env59580 := by
  intro p hp
  have h : env59580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59579_59580 : H12AffineEnvironment.transform 17 5325 env59579 = env59580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5325 env59579 == env59580) = true)

theorem identity59580 : scanCanonicalize (H12AffineFastState.compose env59580 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 509) := by decide +kernel

theorem selectedBound59580 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59581 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,509,1408,429,1448,1062,137,1328,1025,1448,1529,1416,65,431,1288,16,1465,428,217,373,1057,33,256,1197,137,1]

theorem envBound59581 : H12AffineFastState.Bounded env59581 := by
  intro p hp
  have h : env59581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59580_59581 : H12AffineEnvironment.transform 11 509 env59580 = env59581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 509 env59580 == env59581) = true)

theorem identity59581 : scanCanonicalize (H12AffineFastState.compose env59581 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound59581 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59582 : List Nat := [2,4,8,16,32,64,128,252,0,1024,1028,1,1148,81,1108,1062,137,1228,1025,1108,1029,1140,65,83,1268,16,1093,80,217,137,1057,33,252,1197,137,1]

theorem envBound59582 : H12AffineFastState.Bounded env59582 := by
  intro p hp
  have h : env59582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59581_59582 : H12AffineEnvironment.transform 7 252 env59581 = env59582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env59581 == env59582) = true)

theorem identity59582 : scanCanonicalize (H12AffineFastState.compose env59582 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound59582 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59583 : List Nat := [2,4,8,16,32,16,128,172,0,1024,1028,1,1068,1,1028,1062,137,1180,1025,1028,1029,1060,17,3,1188,16,1045,0,137,137,1057,33,172,1197,137,1]

theorem envBound59583 : H12AffineFastState.Bounded env59583 := by
  intro p hp
  have h : env59583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59582_59583 : H12AffineEnvironment.transform 5 16 env59582 = env59583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59582 == env59583) = true)

theorem identity59583 : scanCanonicalize (H12AffineFastState.compose env59583 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 23) := by decide +kernel

theorem selectedBound59583 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59584 : List Nat := [2,4,8,16,32,16,128,172,0,23,19,1,59,1,19,49,137,139,22,19,18,51,17,3,179,16,2,0,137,137,54,33,172,186,137,1]

theorem envBound59584 : H12AffineFastState.Bounded env59584 := by
  intro p hp
  have h : env59584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59583_59584 : H12AffineEnvironment.transform 9 23 env59583 = env59584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 23 env59583 == env59584) = true)

theorem identity59584 : scanCanonicalize (H12AffineFastState.compose env59584 (packedSelected [1,3,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound59584 : packedSelected [1,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env59585 : List Nat := [2,4,8,16,32,16,24,52,0,23,19,1,59,1,19,49,17,19,22,19,18,51,17,3,43,16,2,0,17,17,54,33,52,34,17,1]

theorem envBound59585 : H12AffineFastState.Bounded env59585 := by
  intro p hp
  have h : env59585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59584_59585 : H12AffineEnvironment.transform 6 24 env59584 = env59585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env59584 == env59585) = true)

theorem identity59585 : scanCanonicalize (H12AffineFastState.compose env59585 (packedSelected [6,7] rootPS)) = affineNative (2^(4+1) ^^^ 18) := by decide +kernel

theorem selectedBound59585 : packedSelected [6,7] rootPS < 2^1333 := by decide +kernel

def env59586 : List Nat := [2,4,8,16,18,16,24,6,0,23,19,1,9,1,19,3,17,19,22,19,18,1,17,3,25,16,2,0,17,17,4,19,6,16,17,1]

theorem envBound59586 : H12AffineFastState.Bounded env59586 := by
  intro p hp
  have h : env59586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59585_59586 : H12AffineEnvironment.transform 4 18 env59585 = env59586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 18 env59585 == env59586) = true)

theorem identity59586 : scanCanonicalize (H12AffineFastState.compose env59586 (packedSelected [1,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound59586 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env59587 : List Nat := [2,4,8,0,2,0,8,6,0,7,3,1,9,1,3,3,1,3,6,3,2,1,1,3,9,0,2,0,1,1,4,3,6,0,1,1]

theorem envBound59587 : H12AffineFastState.Bounded env59587 := by
  intro p hp
  have h : env59587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59586_59587 : H12AffineEnvironment.transform 3 0 env59586 = env59587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env59586 == env59587) = true)

theorem identity59587 : scanCanonicalize (H12AffineFastState.compose env59587 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound59587 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59588 : List Nat := [2,4,3,0,2,0,3,6,0,7,3,1,2,1,3,3,1,3,6,3,2,1,1,3,2,0,2,0,1,1,4,3,6,0,1,1]

theorem envBound59588 : H12AffineFastState.Bounded env59588 := by
  intro p hp
  have h : env59588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59587_59588 : H12AffineEnvironment.transform 2 3 env59587 = env59588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env59587 == env59588) = true)

def env59589 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,6178,3441,262144,1025,2128,2097152,1416,64,3159,1288,17,2365813,4177,3361,7537,6181,4573,256,6313,3441,0]

theorem envBound59589 : H12AffineFastState.Bounded env59589 := by
  intro p hp
  have h : env59589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59576_59589 : H12AffineEnvironment.transform 12 1409 env59576 = env59589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59576 == env59589) = true)

theorem identity59589 : scanCanonicalize (H12AffineFastState.compose env59589 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 216) := by decide +kernel

theorem selectedBound59589 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59590 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,6178,3441,262144,1025,2128,216,1416,64,3159,1288,17,268717,4177,3361,7537,6181,4573,256,6313,3441,0]

theorem envBound59590 : H12AffineFastState.Bounded env59590 := by
  intro p hp
  have h : env59590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59589_59590 : H12AffineEnvironment.transform 20 216 env59589 = env59590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 216 env59589 == env59590) = true)

theorem identity59590 : scanCanonicalize (H12AffineFastState.compose env59590 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6376) := by decide +kernel

theorem selectedBound59590 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59591 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,6178,3441,6376,1025,2128,216,1416,64,3159,1288,17,325,4177,3361,7537,6181,4573,256,6313,3441,0]

theorem envBound59591 : H12AffineFastState.Bounded env59591 := by
  intro p hp
  have h : env59591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59590_59591 : H12AffineEnvironment.transform 17 6376 env59590 = env59591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6376 env59590 == env59591) = true)

theorem identity59591 : scanCanonicalize (H12AffineFastState.compose env59591 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 460) := by decide +kernel

theorem selectedBound59591 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59592 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,460,1409,412,2128,2542,3441,2340,1025,2128,216,1416,64,3159,1288,17,325,413,3361,3261,2537,17,256,2405,3441,0]

theorem envBound59592 : H12AffineFastState.Bounded env59592 := by
  intro p hp
  have h : env59592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59591_59592 : H12AffineEnvironment.transform 11 460 env59591 = env59592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 460 env59591 == env59592) = true)

theorem identity59592 : scanCanonicalize (H12AffineFastState.compose env59592 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1260) := by decide +kernel

theorem selectedBound59592 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env59593 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1260,460,1409,412,1212,1282,413,1480,1025,1212,216,1416,64,187,1288,17,325,413,461,81,1285,17,256,1417,413,0]

theorem envBound59593 : H12AffineFastState.Bounded env59593 := by
  intro p hp
  have h : env59593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59592_59593 : H12AffineEnvironment.transform 10 1260 env59592 = env59593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1260 env59592 == env59593) = true)

theorem identity59593 : scanCanonicalize (H12AffineFastState.compose env59593 (packedSelected [1,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59593 : packedSelected [1,4,6] rootPS < 2^1333 := by decide +kernel

def env59594 : List Nat := [2,4,8,16,17,64,128,256,0,1024,1245,460,1409,412,1165,1282,413,1480,1025,1165,216,1416,64,138,1288,17,325,413,461,81,1285,17,256,1417,413,0]

theorem envBound59594 : H12AffineFastState.Bounded env59594 := by
  intro p hp
  have h : env59594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59593_59594 : H12AffineEnvironment.transform 4 17 env59593 = env59594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59593 == env59594) = true)

theorem identity59594 : scanCanonicalize (H12AffineFastState.compose env59594 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound59594 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59595 : List Nat := [2,4,8,16,17,64,128,95,0,1024,1245,147,1246,195,1165,1117,194,1175,1025,1165,216,1239,64,138,1111,17,26,194,146,81,1114,17,95,1238,194,0]

theorem envBound59595 : H12AffineFastState.Bounded env59595 := by
  intro p hp
  have h : env59595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59594_59595 : H12AffineEnvironment.transform 7 95 env59594 = env59595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env59594 == env59595) = true)

theorem identity59595 : scanCanonicalize (H12AffineFastState.compose env59595 (packedSelected [0,5] rootPS)) = affineNative (2^(9+1) ^^^ 198) := by decide +kernel

theorem selectedBound59595 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59596 : List Nat := [2,4,8,16,17,64,128,95,0,198,27,147,24,195,75,155,194,81,199,75,216,17,64,138,145,17,26,194,146,81,156,17,95,16,194,0]

theorem envBound59596 : H12AffineFastState.Bounded env59596 := by
  intro p hp
  have h : env59596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59595_59596 : H12AffineEnvironment.transform 9 198 env59595 = env59596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 198 env59595 == env59596) = true)

def env59597 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9665,3158,1288,9616,2365812,4177,77954,66898,65543,68094,256,65675,78034,9600]

theorem envBound59597 : H12AffineFastState.Bounded env59597 := by
  intro p hp
  have h : env59597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59574_59597 : H12AffineEnvironment.transform 8 1 env59574 = env59597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59574 == env59597) = true)

theorem identity59597 : scanCanonicalize (H12AffineFastState.compose env59597 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 6178) := by decide +kernel

theorem selectedBound59597 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59598 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,6178,10480,262144,1025,2129,2097152,1416,9665,3158,1288,9616,2365812,4177,10400,7536,6181,4572,256,6313,10480,9600]

theorem envBound59598 : H12AffineFastState.Bounded env59598 := by
  intro p hp
  have h : env59598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59597_59598 : H12AffineEnvironment.transform 15 6178 env59597 = env59598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6178 env59597 == env59598) = true)

def env59599 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,6178,3440,262144,1025,2129,2097152,1416,65,3158,1288,16,2365812,4177,3360,7536,6181,4572,256,6313,3440,0]

theorem envBound59599 : H12AffineFastState.Bounded env59599 := by
  intro p hp
  have h : env59599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59598_59599 : H12AffineEnvironment.transform 12 1408 env59598 = env59599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59598 == env59599) = true)

theorem identity59599 : scanCanonicalize (H12AffineFastState.compose env59599 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6653) := by decide +kernel

theorem selectedBound59599 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59600 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,6178,3440,262144,1025,2129,6653,1416,65,3158,1288,16,262281,4177,3360,7536,6181,4572,256,6313,3440,0]

theorem envBound59600 : H12AffineFastState.Bounded env59600 := by
  intro p hp
  have h : env59600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59599_59600 : H12AffineEnvironment.transform 20 6653 env59599 = env59600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6653 env59599 == env59600) = true)

theorem identity59600 : scanCanonicalize (H12AffineFastState.compose env59600 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59600 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59601 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1408,4176,1448,5595,137,262144,1025,1448,5124,1416,65,431,1288,16,262281,4177,217,4233,5596,4572,256,5456,137,0]

theorem envBound59601 : H12AffineFastState.Bounded env59601 := by
  intro p hp
  have h : env59601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59600_59601 : H12AffineEnvironment.transform 10 1529 env59600 = env59601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59600 == env59601) = true)

theorem identity59601 : scanCanonicalize (H12AffineFastState.compose env59601 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5325) := by decide +kernel

theorem selectedBound59601 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59602 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1408,4176,1448,5595,137,5325,1025,1448,5124,1416,65,431,1288,16,5188,4177,217,4233,5596,4572,256,5456,137,0]

theorem envBound59602 : H12AffineFastState.Bounded env59602 := by
  intro p hp
  have h : env59602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59601_59602 : H12AffineEnvironment.transform 17 5325 env59601 = env59602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5325 env59601 == env59602) = true)

theorem identity59602 : scanCanonicalize (H12AffineFastState.compose env59602 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 509) := by decide +kernel

theorem selectedBound59602 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59603 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,509,1408,429,1448,1062,137,1328,1025,1448,1529,1416,65,431,1288,16,1465,428,217,372,1057,33,256,1197,137,0]

theorem envBound59603 : H12AffineFastState.Bounded env59603 := by
  intro p hp
  have h : env59603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59602_59603 : H12AffineEnvironment.transform 11 509 env59602 = env59603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 509 env59602 == env59603) = true)

theorem identity59603 : scanCanonicalize (H12AffineFastState.compose env59603 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound59603 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59604 : List Nat := [2,4,8,16,32,64,128,253,1,1024,1028,0,1149,80,1109,1062,137,1229,1025,1109,1028,1141,65,82,1269,16,1092,81,217,137,1057,33,253,1197,137,0]

theorem envBound59604 : H12AffineFastState.Bounded env59604 := by
  intro p hp
  have h : env59604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59603_59604 : H12AffineEnvironment.transform 7 253 env59603 = env59604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env59603 == env59604) = true)

theorem identity59604 : scanCanonicalize (H12AffineFastState.compose env59604 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound59604 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59605 : List Nat := [2,4,8,16,32,64,128,253,1,140,136,0,241,80,217,170,137,65,141,217,136,249,65,82,121,16,200,81,217,137,173,33,253,33,137,0]

theorem envBound59605 : H12AffineFastState.Bounded env59605 := by
  intro p hp
  have h : env59605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59604_59605 : H12AffineEnvironment.transform 9 140 env59604 = env59605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env59604 == env59605) = true)

theorem identity59605 : scanCanonicalize (H12AffineFastState.compose env59605 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound59605 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env59606 : List Nat := [2,4,8,16,32,64,25,100,1,21,17,0,104,80,64,51,16,65,20,64,17,96,65,82,121,16,81,81,64,16,52,33,100,33,16,0]

theorem envBound59606 : H12AffineFastState.Bounded env59606 := by
  intro p hp
  have h : env59606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59605_59606 : H12AffineEnvironment.transform 6 25 env59605 = env59606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env59605 == env59606) = true)

def env59607 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,6178,3441,262144,1025,2129,2097152,1416,64,3158,1288,17,2365812,4177,3361,7536,6181,4572,256,6313,3441,1]

theorem envBound59607 : H12AffineFastState.Bounded env59607 := by
  intro p hp
  have h : env59607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59598_59607 : H12AffineEnvironment.transform 12 1409 env59598 = env59607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59598 == env59607) = true)

theorem identity59607 : scanCanonicalize (H12AffineFastState.compose env59607 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 217) := by decide +kernel

theorem selectedBound59607 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59608 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,6178,3441,262144,1025,2129,217,1416,64,3158,1288,17,268717,4177,3361,7536,6181,4572,256,6313,3441,1]

theorem envBound59608 : H12AffineFastState.Bounded env59608 := by
  intro p hp
  have h : env59608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59607_59608 : H12AffineEnvironment.transform 20 217 env59607 = env59608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 217 env59607 == env59608) = true)

theorem identity59608 : scanCanonicalize (H12AffineFastState.compose env59608 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6377) := by decide +kernel

theorem selectedBound59608 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59609 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,6178,3441,6377,1025,2129,217,1416,64,3158,1288,17,324,4177,3361,7536,6181,4572,256,6313,3441,1]

theorem envBound59609 : H12AffineFastState.Bounded env59609 := by
  intro p hp
  have h : env59609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59608_59609 : H12AffineEnvironment.transform 17 6377 env59608 = env59609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6377 env59608 == env59609) = true)

theorem identity59609 : scanCanonicalize (H12AffineFastState.compose env59609 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 461) := by decide +kernel

theorem selectedBound59609 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59610 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,461,1409,413,2129,2543,3441,2340,1025,2129,217,1416,64,3158,1288,17,324,412,3361,3261,2536,17,256,2404,3441,1]

theorem envBound59610 : H12AffineFastState.Bounded env59610 := by
  intro p hp
  have h : env59610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59609_59610 : H12AffineEnvironment.transform 11 461 env59609 = env59610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 461 env59609 == env59610) = true)

theorem identity59610 : scanCanonicalize (H12AffineFastState.compose env59610 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59610 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env59611 : List Nat := [2,4,8,16,17,64,128,256,1,1024,2048,461,1409,413,2129,2526,3392,2325,1025,2129,217,1416,64,3158,1288,17,324,412,3344,3212,2521,17,256,2389,3392,1]

theorem envBound59611 : H12AffineFastState.Bounded env59611 := by
  intro p hp
  have h : env59611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59610_59611 : H12AffineEnvironment.transform 4 17 env59610 = env59611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59610 == env59611) = true)

theorem identity59611 : scanCanonicalize (H12AffineFastState.compose env59611 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 1244) := by decide +kernel

theorem selectedBound59611 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59612 : List Nat := [2,4,8,16,17,64,128,256,1,1024,1244,461,1409,413,1165,1282,412,1481,1025,1165,217,1416,64,138,1288,17,324,412,460,80,1285,17,256,1417,412,1]

theorem envBound59612 : H12AffineFastState.Bounded env59612 := by
  intro p hp
  have h : env59612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59611_59612 : H12AffineEnvironment.transform 10 1244 env59611 = env59612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1244 env59611 == env59612) = true)

theorem identity59612 : scanCanonicalize (H12AffineFastState.compose env59612 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound59612 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59613 : List Nat := [2,4,8,16,17,64,128,95,1,1024,1244,146,1246,194,1165,1117,195,1174,1025,1165,217,1239,64,138,1111,17,27,195,147,80,1114,17,95,1238,195,1]

theorem envBound59613 : H12AffineFastState.Bounded env59613 := by
  intro p hp
  have h : env59613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59612_59613 : H12AffineEnvironment.transform 7 95 env59612 = env59613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env59612 == env59613) = true)

theorem identity59613 : scanCanonicalize (H12AffineFastState.compose env59613 (packedSelected [0,5] rootPS)) = affineNative (2^(9+1) ^^^ 198) := by decide +kernel

theorem selectedBound59613 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59614 : List Nat := [2,4,8,16,17,64,128,95,1,198,26,146,24,194,75,155,195,80,199,75,217,17,64,138,145,17,27,195,147,80,156,17,95,16,195,1]

theorem envBound59614 : H12AffineFastState.Bounded env59614 := by
  intro p hp
  have h : env59614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59613_59614 : H12AffineEnvironment.transform 9 198 env59613 = env59614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 198 env59613 == env59614) = true)

def env59615 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1417,8388608,8399766,8397001,8388689,2366324,4177,77954,67410,8463814,8465982,256,65674,78034,8389184]

theorem envBound59615 : H12AffineFastState.Bounded env59615 := by
  intro p hp
  have h : env59615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59528_59615 : H12AffineEnvironment.transform 21 1417 env59528 = env59615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1417 env59528 == env59615) = true)

def env59616 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1417,9664,3670,1289,9617,2366324,4177,77954,67410,65542,68606,256,65674,78034,10112]

theorem envBound59616 : H12AffineFastState.Bounded env59616 := by
  intro p hp
  have h : env59616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59615_59616 : H12AffineEnvironment.transform 22 9664 env59615 = env59616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env59615 == env59616) = true)

def env59617 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9664,3158,1289,9617,2365812,4177,77954,66898,65542,68094,256,65674,78034,9600]

theorem envBound59617 : H12AffineFastState.Bounded env59617 := by
  intro p hp
  have h : env59617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59616_59617 : H12AffineEnvironment.transform 8 0 env59616 = env59617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59616 == env59617) = true)

theorem identity59617 : scanCanonicalize (H12AffineFastState.compose env59617 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 76078) := by decide +kernel

theorem selectedBound59617 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59618 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,76078,1417,9664,3158,1289,9617,340058,4177,77954,66898,65542,68094,256,65674,78034,9600]

theorem envBound59618 : H12AffineFastState.Bounded env59618 := by
  intro p hp
  have h : env59618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59617_59618 : H12AffineEnvironment.transform 20 76078 env59617 = env59618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 76078 env59617 == env59618) = true)

def env59619 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,68782,1417,64,3158,1289,17,333274,4177,70914,66898,65542,68094,256,65674,70994,0]

theorem envBound59619 : H12AffineFastState.Bounded env59619 := by
  intro p hp
  have h : env59619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59618_59619 : H12AffineEnvironment.transform 12 1408 env59618 = env59619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59618 == env59619) = true)

theorem identity59619 : scanCanonicalize (H12AffineFastState.compose env59619 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1109) := by decide +kernel

theorem selectedBound59619 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59620 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1109,1408,1029,2128,65536,65799,262144,1025,2128,68782,1417,64,3158,1289,17,328079,1028,65879,66898,65542,68094,256,65674,65799,0]

theorem envBound59620 : H12AffineFastState.Bounded env59620 := by
  intro p hp
  have h : env59620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0