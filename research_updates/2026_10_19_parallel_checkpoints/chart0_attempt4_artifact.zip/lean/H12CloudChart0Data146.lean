import H12CloudChart0Data145

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity37029 : scanCanonicalize (H12AffineFastState.compose env37029 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound37029 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env37030 : List Nat := [2,4,8,16,32,16,128,37,512,1024,523,4096,40,5157,137,171,5309,642,1025,136,4248,33,153,138,160,16,523,5309,4097,522,1056,33,36,32,5156,513]

theorem envBound37030 : H12AffineFastState.Bounded env37030 := by
  intro p hp
  have h : env37030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37029_37030 : H12AffineEnvironment.transform 10 523 env37029 = env37030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env37029 == env37030) = true)

def env37031 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,13509,10401,1025,8660,2097152,33,2101329,2101315,8328,64,75906,79131,4096,2111713,75222,73890,257,2175082,2172187,513]

theorem envBound37031 : H12AffineFastState.Bounded env37031 := by
  intro p hp
  have h : env37031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37023_37031 : H12AffineEnvironment.transform 13 5377 env37023 = env37031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env37023 == env37031) = true)

theorem identity37031 : scanCanonicalize (H12AffineFastState.compose env37031 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37031 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37032 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,13389,10281,1025,8540,2097152,33,2101329,2101315,8192,64,75786,79131,4096,2111593,75102,73770,257,2175082,2172187,513]

theorem envBound37032 : H12AffineFastState.Bounded env37032 := by
  intro p hp
  have h : env37032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37031_37032 : H12AffineEnvironment.transform 6 8 env37031 = env37032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37031 == env37032) = true)

theorem identity37032 : scanCanonicalize (H12AffineFastState.compose env37032 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(20+1) ^^^ 69910) := by decide +kernel

theorem selectedBound37032 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env37033 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,13389,10281,1025,8540,69910,33,65863,65877,8192,64,75786,79131,4096,76159,75102,73770,257,8572,13325,513]

theorem envBound37033 : H12AffineFastState.Bounded env37033 := by
  intro p hp
  have h : env37033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37032_37033 : H12AffineEnvironment.transform 20 69910 env37032 = env37033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 69910 env37032 == env37033) = true)

theorem identity37033 : scanCanonicalize (H12AffineFastState.compose env37033 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound37033 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37034 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,13389,10281,1025,8540,12573,33,8524,8542,8192,64,2049,5392,4096,2420,1365,33,257,8572,13325,513]

theorem envBound37034 : H12AffineFastState.Bounded env37034 := by
  intro p hp
  have h : env37034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37033_37034 : H12AffineEnvironment.transform 15 8203 env37033 = env37034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env37033 == env37034) = true)

theorem identity37034 : scanCanonicalize (H12AffineFastState.compose env37034 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound37034 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env37035 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,0,342,5392,2420,1025,1,4160,33,17,3,349,64,2049,5392,4096,2420,1365,33,257,33,5456,513]

theorem envBound37035 : H12AffineFastState.Bounded env37035 := by
  intro p hp
  have h : env37035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37034_37035 : H12AffineEnvironment.transform 12 349 env37034 = env37035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env37034 == env37035) = true)

theorem identity37035 : scanCanonicalize (H12AffineFastState.compose env37035 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 820) := by decide +kernel

theorem selectedBound37035 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37036 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,820,349,1589,0,342,1572,2420,1025,1,884,33,17,3,349,64,2049,1572,820,2420,1365,33,257,33,1636,513]

theorem envBound37036 : H12AffineFastState.Bounded env37036 := by
  intro p hp
  have h : env37036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37035_37036 : H12AffineEnvironment.transform 11 820 env37035 = env37036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 820 env37035 == env37036) = true)

theorem identity37036 : scanCanonicalize (H12AffineFastState.compose env37036 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37036 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37037 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,820,268,1589,0,263,1572,2341,1025,1,805,33,17,3,268,17,2049,1572,820,2341,1284,33,257,33,1589,513]

theorem envBound37037 : H12AffineFastState.Bounded env37037 := by
  intro p hp
  have h : env37037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37036_37037 : H12AffineEnvironment.transform 5 17 env37036 = env37037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37036 == env37037) = true)

theorem identity37037 : scanCanonicalize (H12AffineFastState.compose env37037 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound37037 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37038 : List Nat := [2,4,8,16,32,17,8,256,309,1024,2048,1,268,1280,0,263,1297,2341,1025,1,16,33,17,3,268,17,2049,1297,1,2341,1284,33,257,33,1280,308]

theorem envBound37038 : H12AffineFastState.Bounded env37038 := by
  intro p hp
  have h : env37038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37037_37038 : H12AffineEnvironment.transform 8 309 env37037 = env37038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env37037 == env37038) = true)

theorem identity37038 : scanCanonicalize (H12AffineFastState.compose env37038 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound37038 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37039 : List Nat := [2,4,8,16,32,17,8,256,309,273,2048,1,268,17,0,263,0,2341,272,1,16,33,17,3,268,17,2049,0,1,2341,21,33,257,33,17,308]

theorem envBound37039 : H12AffineFastState.Bounded env37039 := by
  intro p hp
  have h : env37039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37038_37039 : H12AffineEnvironment.transform 9 273 env37038 = env37039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env37038 == env37039) = true)

theorem identity37039 : scanCanonicalize (H12AffineFastState.compose env37039 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound37039 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env37040 : List Nat := [2,4,8,16,32,17,8,52,1,37,2048,1,56,17,0,51,0,2065,36,1,16,33,17,3,56,17,2049,0,1,2065,21,33,53,33,17,0]

theorem envBound37040 : H12AffineFastState.Bounded env37040 := by
  intro p hp
  have h : env37040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37039_37040 : H12AffineEnvironment.transform 7 52 env37039 = env37040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env37039 == env37040) = true)

theorem identity37040 : scanCanonicalize (H12AffineFastState.compose env37040 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound37040 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37041 : List Nat := [2,4,8,16,27,17,8,15,1,30,2048,1,3,17,0,8,0,2065,31,1,16,26,17,3,3,17,2049,0,1,2065,21,26,14,26,17,0]

theorem envBound37041 : H12AffineFastState.Bounded env37041 := by
  intro p hp
  have h : env37041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37040_37041 : H12AffineEnvironment.transform 4 27 env37040 = env37041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env37040 == env37041) = true)

theorem identity37041 : scanCanonicalize (H12AffineFastState.compose env37041 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound37041 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env37042 : List Nat := [2,4,8,16,27,17,8,15,1,30,0,1,3,17,0,8,0,17,31,1,16,26,17,3,3,17,1,0,1,17,21,26,14,26,17,0]

theorem envBound37042 : H12AffineFastState.Bounded env37042 := by
  intro p hp
  have h : env37042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37041_37042 : H12AffineEnvironment.transform 10 0 env37041 = env37042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env37041 == env37042) = true)

theorem identity37042 : scanCanonicalize (H12AffineFastState.compose env37042 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound37042 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env37043 : List Nat := [2,4,8,0,11,1,8,15,1,14,0,1,3,1,0,8,0,1,15,1,0,10,1,3,3,1,1,0,1,1,5,10,14,10,1,0]

theorem envBound37043 : H12AffineFastState.Bounded env37043 := by
  intro p hp
  have h : env37043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37042_37043 : H12AffineEnvironment.transform 3 0 env37042 = env37043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env37042 == env37043) = true)

def env37044 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272513,2101329,2114882,8328,64,97666,115151,17665,2363456,119042,329730,257,2199999,2191386,63189]

theorem envBound37044 : H12AffineFastState.Bounded env37044 := by
  intro p hp
  have h : env37044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37011_37044 : H12AffineEnvironment.transform 21 272513 env37011 = env37044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env37011 == env37044) = true)

theorem identity37044 : scanCanonicalize (H12AffineFastState.compose env37044 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58516) := by decide +kernel

theorem selectedBound37044 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37045 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58516,272513,62661,41430,8328,64,97666,115151,17665,324820,119042,329730,257,95531,103566,63189]

theorem envBound37045 : H12AffineFastState.Bounded env37045 := by
  intro p hp
  have h : env37045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37044_37045 : H12AffineEnvironment.transform 20 58516 env37044 = env37045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58516 env37044 == env37045) = true)

def env37046 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58516,272513,62613,41350,8328,16,97666,115103,17665,324740,119042,329730,257,95531,103566,63109]

theorem envBound37046 : H12AffineFastState.Bounded env37046 := by
  intro p hp
  have h : env37046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37045_37046 : H12AffineEnvironment.transform 5 16 env37045 = env37046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37045 == env37046) = true)

theorem identity37046 : scanCanonicalize (H12AffineFastState.compose env37046 (packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 64809) := by decide +kernel

theorem selectedBound37046 : packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env37047 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,64809,1025,32769,58516,54696,62613,41350,8328,16,97666,115103,17665,2477,119042,128299,257,95531,103566,63109]

theorem envBound37047 : H12AffineFastState.Bounded env37047 := by
  intro p hp
  have h : env37047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37046_37047 : H12AffineEnvironment.transform 17 64809 env37046 = env37047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64809 env37046 == env37047) = true)

theorem identity37047 : scanCanonicalize (H12AffineFastState.compose env37047 (packedSelected [0,5,8,9,10,16,18,19,20,22,23,24,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound37047 : packedSelected [0,5,8,9,10,16,18,19,20,22,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env37048 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29709,65536,13340,2340,1025,29708,4249,8613,152,21899,8328,16,97666,79250,17665,2477,75023,65830,257,95531,90243,648]

theorem envBound37048 : H12AffineFastState.Bounded env37048 := by
  intro p hp
  have h : env37048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37047_37048 : H12AffineEnvironment.transform 14 29709 env37047 = env37048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env37047 == env37048) = true)

theorem identity37048 : scanCanonicalize (H12AffineFastState.compose env37048 (packedSelected [0,2,3,5,6,7,10,12,15,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound37048 : packedSelected [0,2,3,5,6,7,10,12,15,17,20] rootPS < 2^1333 := by decide +kernel

def env37049 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4405,9528,65536,13340,2340,1025,9529,4249,8613,152,1214,8328,16,76983,79250,5172,2477,75023,65830,257,74782,78262,648]

theorem envBound37049 : H12AffineFastState.Bounded env37049 := by
  intro p hp
  have h : env37049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37048_37049 : H12AffineEnvironment.transform 13 4405 env37048 = env37049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env37048 == env37049) = true)

theorem identity37049 : scanCanonicalize (H12AffineFastState.compose env37049 (packedSelected [2,3,4,5,6,10,12,15,16,22] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound37049 : packedSelected [2,3,4,5,6,10,12,15,16,22] rootPS < 2^1333 := by decide +kernel

def env37050 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4405,9528,8323,13340,2340,1025,9529,4249,8613,152,1214,8328,16,3124,5393,5172,2477,1420,8613,257,1181,4405,648]

theorem envBound37050 : H12AffineFastState.Bounded env37050 := by
  intro p hp
  have h : env37050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37049_37050 : H12AffineEnvironment.transform 15 8323 env37049 = env37050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env37049 == env37050) = true)

def env37051 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58516,272513,62612,41351,8328,17,97666,115102,17665,324741,119042,329730,257,95531,103566,63108]

theorem envBound37051 : H12AffineFastState.Bounded env37051 := by
  intro p hp
  have h : env37051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37045_37051 : H12AffineEnvironment.transform 5 17 env37045 = env37051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37045 == env37051) = true)

theorem identity37051 : scanCanonicalize (H12AffineFastState.compose env37051 (packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 122147) := by decide +kernel

theorem selectedBound37051 : packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env37052 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,122147,1025,32769,58516,128418,62612,41351,8328,17,97666,115102,17665,76198,119042,54561,257,95531,103566,63108]

theorem envBound37052 : H12AffineFastState.Bounded env37052 := by
  intro p hp
  have h : env37052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37051_37052 : H12AffineEnvironment.transform 17 122147 env37051 = env37052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122147 env37051 == env37052) = true)

theorem identity37052 : scanCanonicalize (H12AffineFastState.compose env37052 (packedSelected [0,3,5,8,9,16,18,19,20,22,23,26,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound37052 : packedSelected [0,3,5,8,9,16,18,19,20,22,23,26,27,28] rootPS < 2^1333 := by decide +kernel

def env37053 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,263,49169,56356,1025,32769,58516,62629,62612,41351,8328,17,31877,49305,17665,10401,53253,54561,257,29740,38281,63108]

theorem envBound37053 : H12AffineFastState.Bounded env37053 := by
  intro p hp
  have h : env37053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37052_37053 : H12AffineEnvironment.transform 15 263 env37052 = env37053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env37052 == env37053) = true)

theorem identity37053 : scanCanonicalize (H12AffineFastState.compose env37053 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound37053 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env37054 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,32768,263,38161,35108,1025,32769,45460,41381,41364,41351,8328,17,10629,38297,4097,10401,34053,32801,257,8492,38281,41860]

theorem envBound37054 : H12AffineFastState.Bounded env37054 := by
  intro p hp
  have h : env37054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37053_37054 : H12AffineEnvironment.transform 13 5376 env37053 = env37054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env37053 == env37054) = true)

theorem identity37054 : scanCanonicalize (H12AffineFastState.compose env37054 (packedSelected [0,1,3,4,5,7,8,9,11,12,14,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 15776) := by decide +kernel

theorem selectedBound37054 : packedSelected [0,1,3,4,5,7,8,9,11,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env37055 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,15776,263,10417,13444,1025,15777,3124,7173,7220,7207,8328,17,10629,10297,4097,10401,14501,15745,257,8492,10281,7716]

theorem envBound37055 : H12AffineFastState.Bounded env37055 := by
  intro p hp
  have h : env37055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37054_37055 : H12AffineEnvironment.transform 14 15776 env37054 = env37055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 15776 env37054 == env37055) = true)

theorem identity37055 : scanCanonicalize (H12AffineFastState.compose env37055 (packedSelected [0,1,2,3,5,6,7,8,12,16] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound37055 : packedSelected [0,1,2,3,5,6,7,8,12,16] rootPS < 2^1333 := by decide +kernel

def env37056 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3109,8192,2341,8581,263,10417,10401,1025,8580,3124,32,17,2,8328,17,10629,10297,3108,10401,9344,8612,257,8492,10281,513]

theorem envBound37056 : H12AffineFastState.Bounded env37056 := by
  intro p hp
  have h : env37056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37055_37056 : H12AffineEnvironment.transform 11 3109 env37055 = env37056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env37055 == env37056) = true)

theorem identity37056 : scanCanonicalize (H12AffineFastState.compose env37056 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound37056 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env37057 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3109,389,2341,0,263,2356,2340,1025,1,3124,32,17,2,269,17,2048,2492,3108,2340,1285,33,257,169,2476,513]

theorem envBound37057 : H12AffineFastState.Bounded env37057 := by
  intro p hp
  have h : env37057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37056_37057 : H12AffineEnvironment.transform 12 389 env37056 = env37057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env37056 == env37057) = true)

theorem identity37057 : scanCanonicalize (H12AffineFastState.compose env37057 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound37057 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37058 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3109,268,2341,0,263,2356,2340,1025,1,3124,32,17,2,269,17,2048,2357,3108,2340,1285,33,257,32,2341,513]

theorem envBound37058 : H12AffineFastState.Bounded env37058 := by
  intro p hp
  have h : env37058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37057_37058 : H12AffineEnvironment.transform 6 9 env37057 = env37058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37057 == env37058) = true)

theorem identity37058 : scanCanonicalize (H12AffineFastState.compose env37058 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1029) := by decide +kernel

theorem selectedBound37058 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37059 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1029,32,268,1312,0,263,1329,1313,1025,1,49,32,17,2,269,17,1029,1328,33,1313,1285,33,257,32,1312,513]

theorem envBound37059 : H12AffineFastState.Bounded env37059 := by
  intro p hp
  have h : env37059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37058_37059 : H12AffineEnvironment.transform 10 1029 env37058 = env37059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1029 env37058 == env37059) = true)

theorem identity37059 : scanCanonicalize (H12AffineFastState.compose env37059 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound37059 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37060 : List Nat := [2,4,8,16,32,17,9,256,512,784,789,32,268,560,0,263,545,561,785,1,49,32,17,2,269,17,789,544,33,561,533,33,257,32,560,513]

theorem envBound37060 : H12AffineFastState.Bounded env37060 := by
  intro p hp
  have h : env37060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37059_37060 : H12AffineEnvironment.transform 9 784 env37059 = env37060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env37059 == env37060) = true)

theorem identity37060 : scanCanonicalize (H12AffineFastState.compose env37060 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound37060 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37061 : List Nat := [2,4,8,16,32,17,9,256,1,273,276,32,268,49,0,263,32,48,272,1,49,32,17,2,269,17,276,33,33,48,20,33,257,32,49,0]

theorem envBound37061 : H12AffineFastState.Bounded env37061 := by
  intro p hp
  have h : env37061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37060_37061 : H12AffineEnvironment.transform 8 1 env37060 = env37061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env37060 == env37061) = true)

theorem identity37061 : scanCanonicalize (H12AffineFastState.compose env37061 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound37061 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env37062 : List Nat := [2,4,8,16,32,17,9,4,1,21,16,32,8,49,0,3,32,48,20,1,49,32,17,2,9,17,16,33,33,48,20,33,5,32,49,0]

theorem envBound37062 : H12AffineFastState.Bounded env37062 := by
  intro p hp
  have h : env37062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37061_37062 : H12AffineEnvironment.transform 7 4 env37061 = env37062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env37061 == env37062) = true)

theorem identity37062 : scanCanonicalize (H12AffineFastState.compose env37062 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound37062 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env37063 : List Nat := [2,4,8,1,32,0,9,4,1,4,1,32,8,32,0,3,32,33,5,1,32,32,0,2,9,0,1,33,33,33,5,33,5,32,32,0]

theorem envBound37063 : H12AffineFastState.Bounded env37063 := by
  intro p hp
  have h : env37063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37062_37063 : H12AffineEnvironment.transform 3 1 env37062 = env37063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env37062 == env37063) = true)

theorem identity37063 : scanCanonicalize (H12AffineFastState.compose env37063 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound37063 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37064 : List Nat := [2,4,8,1,0,0,9,4,1,4,1,0,8,0,0,3,0,1,5,1,0,0,0,2,9,0,1,1,1,1,5,1,5,0,0,0]

theorem envBound37064 : H12AffineFastState.Bounded env37064 := by
  intro p hp
  have h : env37064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37063_37064 : H12AffineEnvironment.transform 4 0 env37063 = env37064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37063 == env37064) = true)

def env37065 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507600,9356288,25265169,23160256,525568,27902124,27337993,25733063]

theorem envBound37065 : H12AffineFastState.Bounded env37065 := by
  intro p hp
  have h : env37065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36620_37065 : H12AffineEnvironment.transform 26 30393345 env36620 = env37065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env36620 == env37065) = true)

def env37066 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830976,25265169,23160256,256,27378860,27337993,25207751]

theorem envBound37066 : H12AffineFastState.Bounded env37066 := by
  intro p hp
  have h : env37066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37065_37066 : H12AffineEnvironment.transform 18 1024 env37065 = env37066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env37065 == env37066) = true)

theorem identity37066 : scanCanonicalize (H12AffineFastState.compose env37066 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8388626) := by decide +kernel

theorem selectedBound37066 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env37067 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8388626,8328,64,4702227,10585246,10507600,8830976,99331,14771666,256,2213054,2172187,41941]

theorem envBound37067 : H12AffineFastState.Bounded env37067 := by
  intro p hp
  have h : env37067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37066_37067 : H12AffineEnvironment.transform 23 8388626 env37066 = env37067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8388626 env37066 == env37067) = true)

def env37068 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147592,147610,8328,64,4702227,2343958,2233816,295048,99331,6497626,256,2213054,2172187,41941]

theorem envBound37068 : H12AffineFastState.Bounded env37068 := by
  intro p hp
  have h : env37068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37067_37068 : H12AffineEnvironment.transform 22 147592 env37067 = env37068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147592 env37067 == env37068) = true)

def env37069 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1024,32769,2097152,4194304,147592,147610,8328,64,4450483,2343958,2233816,43048,99331,6497626,256,2213054,2172187,41941]

theorem envBound37069 : H12AffineFastState.Bounded env37069 := by
  intro p hp
  have h : env37069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37068_37069 : H12AffineEnvironment.transform 17 10400 env37068 = env37069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env37068 == env37069) = true)

theorem identity37069 : scanCanonicalize (H12AffineFastState.compose env37069 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound37069 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env37070 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10400,1024,32769,2097152,4194304,152,138,8328,64,4303011,2196486,2119112,43048,99331,6382922,256,2213054,2172187,41941]

theorem envBound37070 : H12AffineFastState.Bounded env37070 := by
  intro p hp
  have h : env37070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37069_37070 : H12AffineEnvironment.transform 16 16400 env37069 = env37070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env37069 == env37070) = true)

theorem identity37070 : scanCanonicalize (H12AffineFastState.compose env37070 (packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound37070 : packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env37071 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,16400,10400,1024,32769,2097152,4194304,152,138,8328,64,4204925,2098648,2119112,43048,1501,6349972,256,2114912,2139333,41941]

theorem envBound37071 : H12AffineFastState.Bounded env37071 := by
  intro p hp
  have h : env37071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37070_37071 : H12AffineEnvironment.transform 15 33246 env37070 = env37071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env37070 == env37071) = true)

theorem identity37071 : scanCanonicalize (H12AffineFastState.compose env37071 (packedSelected [0,4,7,11,12,15,16,17,18,20,21,22,23,32,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound37071 : packedSelected [0,4,7,11,12,15,16,17,18,20,21,22,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env37072 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,16400,10400,1024,32769,2097152,32,152,138,8328,64,10589,2098648,2119112,43048,1501,2155700,256,2114912,2139333,41941]

theorem envBound37072 : H12AffineFastState.Bounded env37072 := by
  intro p hp
  have h : env37072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37071_37072 : H12AffineEnvironment.transform 21 32 env37071 = env37072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env37071 == env37072) = true)

theorem identity37072 : scanCanonicalize (H12AffineFastState.compose env37072 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 50585) := by decide +kernel

theorem selectedBound37072 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env37073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,16400,10400,1024,32769,50585,32,152,138,8328,64,10589,49217,36945,43048,1501,8493,256,33017,24924,41941]

theorem envBound37073 : H12AffineFastState.Bounded env37073 := by
  intro p hp
  have h : env37073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37072_37073 : H12AffineEnvironment.transform 20 50585 env37072 = env37073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50585 env37072 == env37073) = true)

theorem identity37073 : scanCanonicalize (H12AffineFastState.compose env37073 (packedSelected [0,1,2,3,5,7,8,11,17,18,21] rootPS)) = affineNative (2^(14+1) ^^^ 20665) := by decide +kernel

theorem selectedBound37073 : packedSelected [0,1,2,3,5,7,8,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env37074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,20665,20839,16400,10400,1024,20664,5408,32,152,138,8328,64,10589,4344,16616,30865,1501,8493,256,20544,24924,29548]

theorem envBound37074 : H12AffineFastState.Bounded env37074 := by
  intro p hp
  have h : env37074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37073_37074 : H12AffineEnvironment.transform 14 20665 env37073 = env37074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20665 env37073 == env37074) = true)

theorem identity37074 : scanCanonicalize (H12AffineFastState.compose env37074 (packedSelected [0,1,3,4,5,7,8,9,11,12,15,16,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound37074 : packedSelected [0,1,3,4,5,7,8,9,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env37075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,16384,20665,20839,16400,2477,1024,20664,5408,32,152,138,389,64,2128,4344,16616,22940,1501,32,256,20544,16465,21089]

theorem envBound37075 : H12AffineFastState.Bounded env37075 := by
  intro p hp
  have h : env37075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37074_37075 : H12AffineEnvironment.transform 12 269 env37074 = env37075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env37074 == env37075) = true)

theorem identity37075 : scanCanonicalize (H12AffineFastState.compose env37075 (packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 4249) := by decide +kernel

theorem selectedBound37075 : packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env37076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,4249,32,510,4233,2477,1024,33,5408,32,152,138,389,64,2128,4344,4209,2309,1501,32,256,217,4296,760]

theorem envBound37076 : H12AffineFastState.Bounded env37076 := by
  intro p hp
  have h : env37076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37075_37076 : H12AffineEnvironment.transform 13 4249 env37075 = env37076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4249 env37075 == env37076) = true)

theorem identity37076 : scanCanonicalize (H12AffineFastState.compose env37076 (packedSelected [0,7,16] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound37076 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env37077 : List Nat := [2,4,8,16,32,48,128,256,512,1024,2048,4096,269,4249,32,398,4233,2477,1024,33,5408,32,152,138,389,48,2080,4232,4097,2309,1453,32,256,169,4280,648]

theorem envBound37077 : H12AffineFastState.Bounded env37077 := by
  intro p hp
  have h : env37077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37076_37077 : H12AffineEnvironment.transform 5 48 env37076 = env37077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env37076 == env37077) = true)

theorem identity37077 : scanCanonicalize (H12AffineFastState.compose env37077 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound37077 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env37078 : List Nat := [2,4,8,16,32,48,128,256,512,273,2048,4096,269,4249,32,398,4233,2477,273,33,4145,32,152,138,389,48,2080,4232,4097,2309,188,32,256,169,4280,648]

theorem envBound37078 : H12AffineFastState.Bounded env37078 := by
  intro p hp
  have h : env37078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37077_37078 : H12AffineEnvironment.transform 9 273 env37077 = env37078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env37077 == env37078) = true)

theorem identity37078 : scanCanonicalize (H12AffineFastState.compose env37078 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound37078 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env37079 : List Nat := [2,4,8,16,32,48,128,4,512,21,2048,4096,9,4249,32,138,4233,2217,21,33,4145,32,152,138,129,48,2080,4232,4097,2049,188,32,4,169,4280,648]

theorem envBound37079 : H12AffineFastState.Bounded env37079 := by
  intro p hp
  have h : env37079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37078_37079 : H12AffineEnvironment.transform 7 4 env37078 = env37079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env37078 == env37079) = true)

theorem identity37079 : scanCanonicalize (H12AffineFastState.compose env37079 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37079 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env37080 : List Nat := [2,4,8,16,32,48,8,4,512,21,2048,4096,9,4113,32,2,4097,2081,21,33,4145,32,16,2,9,48,2080,4096,4097,2049,52,32,4,33,4144,512]

theorem envBound37080 : H12AffineFastState.Bounded env37080 := by
  intro p hp
  have h : env37080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37079_37080 : H12AffineEnvironment.transform 6 8 env37079 = env37080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37079 == env37080) = true)

theorem identity37080 : scanCanonicalize (H12AffineFastState.compose env37080 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound37080 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37081 : List Nat := [2,4,8,16,0,16,8,4,512,21,2048,4096,9,4113,0,2,4097,2049,21,1,4113,0,16,2,9,16,2048,4096,4097,2049,20,0,4,1,4112,512]

theorem envBound37081 : H12AffineFastState.Bounded env37081 := by
  intro p hp
  have h : env37081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37080_37081 : H12AffineEnvironment.transform 4 0 env37080 = env37081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37080 == env37081) = true)

theorem identity37081 : scanCanonicalize (H12AffineFastState.compose env37081 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound37081 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37082 : List Nat := [2,4,8,16,0,16,8,4,0,21,2048,4096,9,4113,0,2,4097,2049,21,1,4113,0,16,2,9,16,2048,4096,4097,2049,20,0,4,1,4112,0]

theorem envBound37082 : H12AffineFastState.Bounded env37082 := by
  intro p hp
  have h : env37082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37081_37082 : H12AffineEnvironment.transform 8 0 env37081 = env37082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env37081 == env37082) = true)

theorem identity37082 : scanCanonicalize (H12AffineFastState.compose env37082 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 31) := by decide +kernel

theorem selectedBound37082 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37083 : List Nat := [2,4,8,16,0,16,8,4,0,21,31,4096,9,4113,0,2,4097,30,21,1,4113,0,16,2,9,16,31,4096,4097,30,20,0,4,1,4112,0]

theorem envBound37083 : H12AffineFastState.Bounded env37083 := by
  intro p hp
  have h : env37083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37082_37083 : H12AffineEnvironment.transform 10 31 env37082 = env37083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 31 env37082 == env37083) = true)

theorem identity37083 : scanCanonicalize (H12AffineFastState.compose env37083 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 15) := by decide +kernel

theorem selectedBound37083 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env37084 : List Nat := [2,4,8,16,0,16,8,4,0,21,31,15,9,30,0,2,14,30,21,1,30,0,16,2,9,16,31,15,14,30,20,0,4,1,31,0]

theorem envBound37084 : H12AffineFastState.Bounded env37084 := by
  intro p hp
  have h : env37084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37083_37084 : H12AffineEnvironment.transform 11 15 env37083 = env37084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 15 env37083 == env37084) = true)

def leafEnv37084 : List Nat := [2,4,8,16,0,16,8,4,0,21,31,15,9,30,0,2,14,30,21,1,30,0,16,2,20,9,1,16,31,15,14,30,20,0,4,1,4,2,31,0,1,31,0]

def active37084 : List Nat := [0,1,2,3]

def tree37084 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37084 : H12WitnessSearch.Good tree37084 := H12GlobalWitnessIndex.good

theorem leafIdentity37084 : H12AffineFastState.composeSystem env37084 rootObs = leafEnv37084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37084 rootObs == leafEnv37084) = true)

theorem terminalChecked37084 : H12PackedTerminal.terminalCheckFast leafEnv37084 active37084 tree37084 = true := by decide +kernel

def env37085 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1024,32769,2097152,4194304,147592,147610,8328,64,4450482,2343958,2233816,43049,99331,6497626,256,2213054,2172187,41941]

theorem envBound37085 : H12AffineFastState.Bounded env37085 := by
  intro p hp
  have h : env37085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37068_37085 : H12AffineEnvironment.transform 17 10401 env37068 = env37085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env37068 == env37085) = true)

theorem identity37085 : scanCanonicalize (H12AffineFastState.compose env37085 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37085 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env37086 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,2097152,4194304,147456,147474,8192,64,4450362,2343958,2233680,43049,99331,6497626,256,2212918,2172187,41821]

theorem envBound37086 : H12AffineFastState.Bounded env37086 := by
  intro p hp
  have h : env37086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37085_37086 : H12AffineEnvironment.transform 6 8 env37085 = env37086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37085 == env37086) = true)

theorem identity37086 : scanCanonicalize (H12AffineFastState.compose env37086 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound37086 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env37087 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1024,8541,2097152,4194304,147456,147474,8192,64,4409702,2319690,2233680,2421,75103,6497626,256,2188650,2172187,513]

theorem envBound37087 : H12AffineFastState.Bounded env37087 := by
  intro p hp
  have h : env37087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37086_37087 : H12AffineEnvironment.transform 14 8540 env37086 = env37087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env37086 == env37087) = true)

theorem identity37087 : scanCanonicalize (H12AffineFastState.compose env37087 (packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound37087 : packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS < 2^1333 := by decide +kernel

def env37088 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,343,131072,10281,1024,8541,2097152,4194304,147456,147474,8192,64,4343857,2253853,2233680,2421,9224,6431757,256,2122813,2106444,513]

theorem envBound37088 : H12AffineFastState.Bounded env37088 := by
  intro p hp
  have h : env37088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37087_37088 : H12AffineEnvironment.transform 15 343 env37087 = env37088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env37087 == env37088) = true)

theorem identity37088 : scanCanonicalize (H12AffineFastState.compose env37088 (packedSelected [1,4,8,9,14,16,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 25629) := by decide +kernel

theorem selectedBound37088 : packedSelected [1,4,8,9,14,16,17,19] rootPS < 2^1333 := by decide +kernel

def env37089 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,343,131072,10281,1024,8541,25629,4194304,147456,147474,8192,64,4343857,131072,160077,2421,9224,4341776,256,32,16465,513]

theorem envBound37089 : H12AffineFastState.Bounded env37089 := by
  intro p hp
  have h : env37089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37088_37089 : H12AffineEnvironment.transform 20 25629 env37088 = env37089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25629 env37088 == env37089) = true)

theorem identity37089 : scanCanonicalize (H12AffineFastState.compose env37089 (packedSelected [1,3,5,8,11,14,15,16] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound37089 : packedSelected [1,3,5,8,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env37090 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,343,131072,10281,1024,8541,25629,8493,147456,147474,8192,64,157980,131072,160077,2421,9224,155965,256,32,16465,513]

theorem envBound37090 : H12AffineFastState.Bounded env37090 := by
  intro p hp
  have h : env37090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37089_37090 : H12AffineEnvironment.transform 21 8493 env37089 = env37090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env37089 == env37090) = true)

theorem identity37090 : scanCanonicalize (H12AffineFastState.compose env37090 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37090 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env37091 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8460,263,131072,10281,1024,8461,25629,8493,147456,147474,8192,16,157980,131072,160029,2341,9224,155965,256,32,16385,513]

theorem envBound37091 : H12AffineFastState.Bounded env37091 := by
  intro p hp
  have h : env37091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37090_37091 : H12AffineEnvironment.transform 5 16 env37090 = env37091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37090 == env37091) = true)

theorem identity37091 : scanCanonicalize (H12AffineFastState.compose env37091 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound37091 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env37092 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,1,263,131072,2340,1024,0,17680,32,147456,147474,269,16,149521,131072,151568,2341,1285,147504,256,32,16385,513]

theorem envBound37092 : H12AffineFastState.Bounded env37092 := by
  intro p hp
  have h : env37092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37091_37092 : H12AffineEnvironment.transform 12 269 env37091 = env37092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env37091 == env37092) = true)

theorem identity37092 : scanCanonicalize (H12AffineFastState.compose env37092 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(16+1) ^^^ 3109) := by decide +kernel

theorem selectedBound37092 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env37093 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,1,263,3109,2340,1024,0,17680,32,19493,19511,269,16,17460,3109,23605,2341,1285,19477,256,32,16385,513]

theorem envBound37093 : H12AffineFastState.Bounded env37093 := by
  intro p hp
  have h : env37093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37092_37093 : H12AffineEnvironment.transform 16 3109 env37092 = env37093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 3109 env37092 == env37093) = true)

theorem identity37093 : scanCanonicalize (H12AffineFastState.compose env37093 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound37093 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env37094 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,269,16384,1,263,2065,2340,52,0,16676,32,18449,18435,269,16,16384,2065,22529,2341,305,18465,256,32,16385,513]

theorem envBound37094 : H12AffineFastState.Bounded env37094 := by
  intro p hp
  have h : env37094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37093_37094 : H12AffineEnvironment.transform 9 52 env37093 = env37094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env37093 == env37094) = true)

theorem identity37094 : scanCanonicalize (H12AffineFastState.compose env37094 (packedSelected [0,3,4,5,12] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound37094 : packedSelected [0,3,4,5,12] rootPS < 2^1333 := by decide +kernel

def env37095 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,269,2048,1,263,2065,2340,52,0,2340,32,17,3,269,16,2048,2065,4097,2341,305,33,256,32,2049,513]

theorem envBound37095 : H12AffineFastState.Bounded env37095 := by
  intro p hp
  have h : env37095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37094_37095 : H12AffineEnvironment.transform 13 2048 env37094 = env37095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env37094 == env37095) = true)

theorem identity37095 : scanCanonicalize (H12AffineFastState.compose env37095 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound37095 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37096 : List Nat := [2,4,8,16,32,16,8,52,512,52,2048,4096,57,2048,1,51,2065,2064,52,0,2064,32,17,3,57,16,2048,2065,4097,2065,5,33,52,32,2049,513]

theorem envBound37096 : H12AffineFastState.Bounded env37096 := by
  intro p hp
  have h : env37096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37095_37096 : H12AffineEnvironment.transform 7 52 env37095 = env37096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env37095 == env37096) = true)

theorem identity37096 : scanCanonicalize (H12AffineFastState.compose env37096 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound37096 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37097 : List Nat := [2,4,8,10,32,10,8,46,512,46,2048,4096,35,2048,1,41,2059,2058,46,0,2058,32,11,3,35,10,2048,2059,4097,2059,5,33,46,32,2049,513]

theorem envBound37097 : H12AffineFastState.Bounded env37097 := by
  intro p hp
  have h : env37097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37096_37097 : H12AffineEnvironment.transform 3 10 env37096 = env37097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env37096 == env37097) = true)

theorem identity37097 : scanCanonicalize (H12AffineFastState.compose env37097 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound37097 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37098 : List Nat := [2,4,8,10,32,10,8,46,512,46,43,4096,35,43,1,41,32,33,46,0,33,32,11,3,35,10,43,32,4097,32,5,33,46,32,42,513]

theorem envBound37098 : H12AffineFastState.Bounded env37098 := by
  intro p hp
  have h : env37098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37097_37098 : H12AffineEnvironment.transform 10 43 env37097 = env37098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env37097 == env37098) = true)

theorem identity37098 : scanCanonicalize (H12AffineFastState.compose env37098 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 42) := by decide +kernel

theorem selectedBound37098 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env37099 : List Nat := [2,4,8,10,32,10,8,46,512,46,43,42,35,43,1,41,32,33,46,0,33,32,11,3,35,10,43,32,43,32,5,33,46,32,42,513]

theorem envBound37099 : H12AffineFastState.Bounded env37099 := by
  intro p hp
  have h : env37099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37098_37099 : H12AffineEnvironment.transform 11 42 env37098 = env37099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 42 env37098 == env37099) = true)

theorem identity37099 : scanCanonicalize (H12AffineFastState.compose env37099 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound37099 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env37100 : List Nat := [2,4,4,6,32,6,4,34,512,34,39,38,35,39,1,37,32,33,34,0,33,32,7,3,35,6,39,32,39,32,5,33,34,32,38,513]

theorem envBound37100 : H12AffineFastState.Bounded env37100 := by
  intro p hp
  have h : env37100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37099_37100 : H12AffineEnvironment.transform 2 4 env37099 = env37100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env37099 == env37100) = true)

def env37101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147593,147611,8328,64,4702227,2343959,2233817,295049,99331,6497627,256,2213054,2172187,41941]

theorem envBound37101 : H12AffineFastState.Bounded env37101 := by
  intro p hp
  have h : env37101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37067_37101 : H12AffineEnvironment.transform 22 147593 env37067 = env37101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147593 env37067 == env37101) = true)

def env37102 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1024,32769,2097152,4194304,147593,147611,8328,64,4450483,2343959,2233817,43049,99331,6497627,256,2213054,2172187,41941]

theorem envBound37102 : H12AffineFastState.Bounded env37102 := by
  intro p hp
  have h : env37102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37101_37102 : H12AffineEnvironment.transform 17 10400 env37101 = env37102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env37101 == env37102) = true)

theorem identity37102 : scanCanonicalize (H12AffineFastState.compose env37102 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 57797) := by decide +kernel

theorem selectedBound37102 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env37103 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57797,10400,1024,32769,2097152,4194304,41292,41310,8328,64,4262262,2172370,2159644,43049,99331,6407326,256,2213054,2172187,41941]

theorem envBound37103 : H12AffineFastState.Bounded env37103 := by
  intro p hp
  have h : env37103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37102_37103 : H12AffineEnvironment.transform 16 57797 env37102 = env37103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57797 env37102 == env37103) = true)

theorem identity37103 : scanCanonicalize (H12AffineFastState.compose env37103 (packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound37103 : packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env37104 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,57797,10400,1024,32769,2097152,4194304,41292,41310,8328,64,4229289,2139149,2159644,43049,1500,6309185,256,2114913,2139332,41941]

theorem envBound37104 : H12AffineFastState.Bounded env37104 := by
  intro p hp
  have h : env37104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37103_37104 : H12AffineEnvironment.transform 15 33247 env37103 = env37104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env37103 == env37104) = true)

theorem identity37104 : scanCanonicalize (H12AffineFastState.compose env37104 (packedSelected [0,4,7,11,12,15,16,18,20,22,23,32,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 41460) := by decide +kernel

theorem selectedBound37104 : packedSelected [0,4,7,11,12,15,16,18,20,22,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env37105 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,57797,10400,1024,32769,2097152,41460,41292,41310,8328,64,10589,2139149,2159644,43049,1500,2155701,256,2114913,2139332,41941]

theorem envBound37105 : H12AffineFastState.Bounded env37105 := by
  intro p hp
  have h : env37105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37104_37105 : H12AffineEnvironment.transform 21 41460 env37104 = env37105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41460 env37104 == env37105) = true)

theorem identity37105 : scanCanonicalize (H12AffineFastState.compose env37105 (packedSelected [1,2,3,5,8,10,11,14,17,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound37105 : packedSelected [1,2,3,5,8,10,11,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env37106 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8233,8694,16876,10400,1024,8232,2097152,477,357,375,8328,64,10589,2098212,2118709,2048,1500,2114716,256,2114913,2098413,1020]

theorem envBound37106 : H12AffineFastState.Bounded env37106 := by
  intro p hp
  have h : env37106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37105_37106 : H12AffineEnvironment.transform 14 8233 env37105 = env37106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env37105 == env37106) = true)

theorem identity37106 : scanCanonicalize (H12AffineFastState.compose env37106 (packedSelected [1,3,4,7,9,17,21,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 25676) := by decide +kernel

theorem selectedBound37106 : packedSelected [1,3,4,7,9,17,21,24,27,28] rootPS < 2^1333 := by decide +kernel

def env37107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8233,8694,16876,10400,1024,8232,25676,477,357,375,8328,64,10589,24680,12409,2048,1500,8400,256,8493,24737,1020]

theorem envBound37107 : H12AffineFastState.Bounded env37107 := by
  intro p hp
  have h : env37107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37106_37107 : H12AffineEnvironment.transform 20 25676 env37106 = env37107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25676 env37106 == env37107) = true)

theorem identity37107 : scanCanonicalize (H12AffineFastState.compose env37107 (packedSelected [1,2,8,10,11,16,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound37107 : packedSelected [1,2,8,10,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env37108 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,8233,8694,13625,10400,1024,8232,4249,477,357,375,8328,64,10589,5309,12409,2048,1500,8400,256,8493,5236,1020]

theorem envBound37108 : H12AffineFastState.Bounded env37108 := by
  intro p hp
  have h : env37108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37107_37108 : H12AffineEnvironment.transform 13 13525 env37107 = env37108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env37107 == env37108) = true)

theorem identity37108 : scanCanonicalize (H12AffineFastState.compose env37108 (packedSelected [1,3,5,8,12,14,15,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound37108 : packedSelected [1,3,5,8,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env37109 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,13525,8233,8323,13388,10400,1024,8232,4249,168,16,2,8328,64,10280,5309,12409,2048,1193,8400,117,8280,5236,649]

theorem envBound37109 : H12AffineFastState.Bounded env37109 := by
  intro p hp
  have h : env37109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37108_37109 : H12AffineEnvironment.transform 7 117 env37108 = env37109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env37108 == env37109) = true)

theorem identity37109 : scanCanonicalize (H12AffineFastState.compose env37109 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 241) := by decide +kernel

theorem selectedBound37109 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env37110 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,241,5156,216,114,5309,2129,1024,217,4249,168,16,2,121,64,2265,5309,4232,2048,1193,33,117,169,5236,649]

theorem envBound37110 : H12AffineFastState.Bounded env37110 := by
  intro p hp
  have h : env37110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37109_37110 : H12AffineEnvironment.transform 12 241 env37109 = env37110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env37109 == env37110) = true)

theorem identity37110 : scanCanonicalize (H12AffineFastState.compose env37110 (packedSelected [2,11] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound37110 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env37111 : List Nat := [2,4,8,16,32,64,128,117,512,1024,81,4096,241,5156,216,114,5309,0,1024,217,4249,168,16,2,121,64,136,5309,4232,81,1193,33,117,169,5236,649]

theorem envBound37111 : H12AffineFastState.Bounded env37111 := by
  intro p hp
  have h : env37111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37110_37111 : H12AffineEnvironment.transform 10 81 env37110 = env37111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env37110 == env37111) = true)

theorem identity37111 : scanCanonicalize (H12AffineFastState.compose env37111 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound37111 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env37112 : List Nat := [2,4,8,16,32,64,88,117,512,1024,81,4096,41,5156,0,114,5221,0,1024,1,4161,112,16,2,121,64,80,5221,4176,81,1137,33,117,113,5236,593]

theorem envBound37112 : H12AffineFastState.Bounded env37112 := by
  intro p hp
  have h : env37112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37111_37112 : H12AffineEnvironment.transform 6 88 env37111 = env37112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env37111 == env37112) = true)

theorem identity37112 : scanCanonicalize (H12AffineFastState.compose env37112 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound37112 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env37113 : List Nat := [2,4,8,16,32,64,88,117,512,1024,81,17,41,1077,0,114,1140,0,1024,1,80,112,16,2,121,64,80,1140,65,81,1137,33,117,113,1125,593]

theorem envBound37113 : H12AffineFastState.Bounded env37113 := by
  intro p hp
  have h : env37113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37112_37113 : H12AffineEnvironment.transform 11 17 env37112 = env37113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env37112 == env37113) = true)

theorem identity37113 : scanCanonicalize (H12AffineFastState.compose env37113 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37113 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37114 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1,17,41,1077,0,34,1060,0,1024,1,0,32,16,2,41,16,0,1060,17,1,1057,33,37,33,1077,513]

theorem envBound37114 : H12AffineFastState.Bounded env37114 := by
  intro p hp
  have h : env37114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37113_37114 : H12AffineEnvironment.transform 5 16 env37113 = env37114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37113 == env37114) = true)

def env37115 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1024,32769,2097152,4194304,147593,147611,8328,64,4450482,2343959,2233817,43048,99331,6497627,256,2213054,2172187,41941]

theorem envBound37115 : H12AffineFastState.Bounded env37115 := by
  intro p hp
  have h : env37115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37101_37115 : H12AffineEnvironment.transform 17 10401 env37101 = env37115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env37101 == env37115) = true)

theorem identity37115 : scanCanonicalize (H12AffineFastState.compose env37115 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound37115 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env37116 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10401,1024,8541,2097152,4194304,147593,147611,8328,64,4409838,2319691,2233817,2420,75103,6497627,256,2188770,2172187,649]

theorem envBound37116 : H12AffineFastState.Bounded env37116 := by
  intro p hp
  have h : env37116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37115_37116 : H12AffineEnvironment.transform 14 8540 env37115 = env37116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env37115 == env37116) = true)

theorem identity37116 : scanCanonicalize (H12AffineFastState.compose env37116 (packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37116 : packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env37117 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1024,8541,2097152,4194304,147457,147475,8192,64,4409702,2319691,2233681,2420,75103,6497627,256,2188650,2172187,513]

theorem envBound37117 : H12AffineFastState.Bounded env37117 := by
  intro p hp
  have h : env37117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37116_37117 : H12AffineEnvironment.transform 6 8 env37116 = env37117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37116 == env37117) = true)

theorem identity37117 : scanCanonicalize (H12AffineFastState.compose env37117 (packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 91466) := by decide +kernel

theorem selectedBound37117 : packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS < 2^1333 := by decide +kernel

def env37118 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1024,8541,91466,4194304,147457,147475,8192,64,4409702,131073,225307,2420,75103,4341777,256,32,16465,513]

theorem envBound37118 : H12AffineFastState.Bounded env37118 := by
  intro p hp
  have h : env37118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37117_37118 : H12AffineEnvironment.transform 20 91466 env37117 = env37118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91466 env37117 == env37118) = true)

theorem identity37118 : scanCanonicalize (H12AffineFastState.compose env37118 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound37118 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env37119 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10281,1024,8541,91466,4194304,16,2,8192,64,4262263,16400,77834,2420,75103,4194304,256,32,16465,513]

theorem envBound37119 : H12AffineFastState.Bounded env37119 := by
  intro p hp
  have h : env37119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37118_37119 : H12AffineEnvironment.transform 16 16401 env37118 = env37119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env37118 == env37119) = true)

theorem identity37119 : scanCanonicalize (H12AffineFastState.compose env37119 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound37119 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env37120 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10281,1024,8541,91466,73770,16,2,8192,64,10589,16400,77834,2420,75103,73770,256,32,16465,513]

theorem envBound37120 : H12AffineFastState.Bounded env37120 := by
  intro p hp
  have h : env37120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37119_37120 : H12AffineEnvironment.transform 21 73770 env37119 = env37120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env37119 == env37120) = true)

theorem identity37120 : scanCanonicalize (H12AffineFastState.compose env37120 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound37120 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env37121 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8282,16401,10281,1024,8541,17680,112,16,2,8192,64,10589,16400,4176,2420,1285,112,256,32,16465,513]

theorem envBound37121 : H12AffineFastState.Bounded env37121 := by
  intro p hp
  have h : env37121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37120_37121 : H12AffineEnvironment.transform 15 8282 env37120 = env37121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env37120 == env37121) = true)

theorem identity37121 : scanCanonicalize (H12AffineFastState.compose env37121 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound37121 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env37122 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1,263,16401,2420,1024,0,17680,112,16,2,349,64,2048,16400,4176,2420,1285,112,256,32,16465,513]

theorem envBound37122 : H12AffineFastState.Bounded env37122 := by
  intro p hp
  have h : env37122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37121_37122 : H12AffineEnvironment.transform 12 349 env37121 = env37122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env37121 == env37122) = true)

theorem identity37122 : scanCanonicalize (H12AffineFastState.compose env37122 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound37122 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env37123 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5156,1,263,5173,2420,1024,0,4404,112,16,2,349,64,2048,5172,4176,2420,1285,112,256,32,5237,513]

theorem envBound37123 : H12AffineFastState.Bounded env37123 := by
  intro p hp
  have h : env37123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37122_37123 : H12AffineEnvironment.transform 13 5156 env37122 = env37123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env37122 == env37123) = true)

theorem identity37123 : scanCanonicalize (H12AffineFastState.compose env37123 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37123 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env37124 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5156,1,263,5173,2341,1024,0,4404,33,16,2,268,17,2048,5172,4097,2341,1285,33,256,32,5156,513]

theorem envBound37124 : H12AffineFastState.Bounded env37124 := by
  intro p hp
  have h : env37124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37123_37124 : H12AffineEnvironment.transform 5 17 env37123 = env37124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37123 == env37124) = true)

def env37125 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3888,268,2836,1,263,2821,2341,1024,0,3588,33,16,2,268,17,2048,2820,3889,2341,1285,33,256,32,2836,513]

theorem envBound37125 : H12AffineFastState.Bounded env37125 := by
  intro p hp
  have h : env37125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37124_37125 : H12AffineEnvironment.transform 11 3888 env37124 = env37125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env37124 == env37125) = true)

def env37126 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,48,268,1044,1,263,1029,1573,1024,0,260,33,16,2,268,17,1792,1028,49,1573,1285,33,256,32,1044,513]

theorem envBound37126 : H12AffineFastState.Bounded env37126 := by
  intro p hp
  have h : env37126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37125_37126 : H12AffineEnvironment.transform 10 1792 env37125 = env37126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env37125 == env37126) = true)

theorem identity37126 : scanCanonicalize (H12AffineFastState.compose env37126 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound37126 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37127 : List Nat := [2,4,8,16,32,17,8,256,512,549,293,48,268,561,1,263,544,0,549,0,260,33,16,2,268,17,293,545,49,0,800,33,256,32,561,513]

theorem envBound37127 : H12AffineFastState.Bounded env37127 := by
  intro p hp
  have h : env37127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37126_37127 : H12AffineEnvironment.transform 9 549 env37126 = env37127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env37126 == env37127) = true)

def env37128 : List Nat := [2,4,8,16,32,17,8,256,16,53,293,48,268,33,1,263,48,0,53,0,260,33,16,2,268,17,293,49,49,0,304,33,256,32,33,17]

theorem envBound37128 : H12AffineFastState.Bounded env37128 := by
  intro p hp
  have h : env37128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37127_37128 : H12AffineEnvironment.transform 8 16 env37127 = env37128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env37127 == env37128) = true)

theorem identity37128 : scanCanonicalize (H12AffineFastState.compose env37128 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound37128 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37129 : List Nat := [2,4,8,16,32,17,8,5,16,53,32,48,9,33,1,2,48,0,53,0,1,33,16,2,9,17,32,49,49,0,53,33,5,32,33,17]

theorem envBound37129 : H12AffineFastState.Bounded env37129 := by
  intro p hp
  have h : env37129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37128_37129 : H12AffineEnvironment.transform 7 5 env37128 = env37129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env37128 == env37129) = true)

def leafEnv37129 : List Nat := [2,4,8,16,32,17,8,5,16,53,32,48,9,33,1,2,48,0,53,0,1,33,16,2,53,9,1,17,32,49,49,0,53,33,5,32,4,2,33,17,1,1,0]

def active37129 : List Nat := [0,1,2,3,4]

def tree37129 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37129 : H12WitnessSearch.Good tree37129 := H12GlobalWitnessIndex.good

theorem leafIdentity37129 : H12AffineFastState.composeSystem env37129 rootObs = leafEnv37129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37129 rootObs == leafEnv37129) = true)

theorem terminalChecked37129 : H12PackedTerminal.terminalCheckFast leafEnv37129 active37129 tree37129 = true := by decide +kernel

def env37130 : List Nat := [2,4,8,16,32,17,8,256,17,52,293,48,268,32,1,263,49,0,52,0,260,33,16,2,268,17,293,48,49,0,305,33,256,32,32,16]

theorem envBound37130 : H12AffineFastState.Bounded env37130 := by
  intro p hp
  have h : env37130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37127_37130 : H12AffineEnvironment.transform 8 17 env37127 = env37130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env37127 == env37130) = true)

theorem identity37130 : scanCanonicalize (H12AffineFastState.compose env37130 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound37130 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37131 : List Nat := [2,4,8,10,32,11,8,256,11,46,293,42,268,32,1,263,43,0,46,0,260,33,10,2,268,11,293,42,43,0,299,33,256,32,32,10]

theorem envBound37131 : H12AffineFastState.Bounded env37131 := by
  intro p hp
  have h : env37131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37130_37131 : H12AffineEnvironment.transform 3 10 env37130 = env37131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env37130 == env37131) = true)

def leafEnv37131 : List Nat := [2,4,8,10,32,11,8,256,11,46,293,42,268,32,1,263,43,0,46,0,260,33,10,2,299,268,1,11,293,42,43,0,299,33,256,32,4,263,32,10,1,260,0]

def active37131 : List Nat := [0,1,2,4,7]

def tree37131 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37131 : H12WitnessSearch.Good tree37131 := H12GlobalWitnessIndex.good

theorem leafIdentity37131 : H12AffineFastState.composeSystem env37131 rootObs = leafEnv37131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37131 rootObs == leafEnv37131) = true)

theorem terminalChecked37131 : H12PackedTerminal.terminalCheckFast leafEnv37131 active37131 tree37131 = true := by decide +kernel

def env37132 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,49,268,1045,1,263,1028,1572,1024,0,261,33,16,2,268,17,1793,1029,48,1572,1285,33,256,32,1045,513]

theorem envBound37132 : H12AffineFastState.Bounded env37132 := by
  intro p hp
  have h : env37132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37125_37132 : H12AffineEnvironment.transform 10 1793 env37125 = env37132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env37125 == env37132) = true)

theorem identity37132 : scanCanonicalize (H12AffineFastState.compose env37132 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound37132 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37133 : List Nat := [2,4,8,16,32,17,8,256,309,1024,1076,49,268,1045,1,263,1028,1297,1024,0,261,33,16,2,268,17,1076,1029,48,1297,1285,33,256,32,1045,308]

theorem envBound37133 : H12AffineFastState.Bounded env37133 := by
  intro p hp
  have h : env37133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37132_37133 : H12AffineEnvironment.transform 8 309 env37132 = env37133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env37132 == env37133) = true)

def env37134 : List Nat := [2,4,8,16,32,17,8,256,309,52,0,49,268,33,1,263,48,293,52,0,261,33,16,2,268,17,0,49,48,293,305,33,256,32,33,308]

theorem envBound37134 : H12AffineFastState.Bounded env37134 := by
  intro p hp
  have h : env37134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37133_37134 : H12AffineEnvironment.transform 9 52 env37133 = env37134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env37133 == env37134) = true)

theorem identity37134 : scanCanonicalize (H12AffineFastState.compose env37134 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound37134 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37135 : List Nat := [2,4,8,11,32,10,8,256,302,47,0,42,268,33,1,263,43,293,47,0,261,33,11,2,268,10,0,42,43,293,298,33,256,32,33,303]

theorem envBound37135 : H12AffineFastState.Bounded env37135 := by
  intro p hp
  have h : env37135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37134_37135 : H12AffineEnvironment.transform 3 11 env37134 = env37135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env37134 == env37135) = true)

def leafEnv37135 : List Nat := [2,4,8,11,32,10,8,256,302,47,0,42,268,33,1,263,43,293,47,0,261,33,11,2,298,268,1,10,0,42,43,293,298,33,256,32,4,263,33,303,1,261,0]

def active37135 : List Nat := [0,1,2,4,7]

def tree37135 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37135 : H12WitnessSearch.Good tree37135 := H12GlobalWitnessIndex.good

theorem leafIdentity37135 : H12AffineFastState.composeSystem env37135 rootObs = leafEnv37135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37135 rootObs == leafEnv37135) = true)

theorem terminalChecked37135 : H12PackedTerminal.terminalCheckFast leafEnv37135 active37135 tree37135 = true := by decide +kernel

def env37136 : List Nat := [2,4,8,16,32,17,8,256,309,53,1,49,268,32,1,263,49,292,53,0,261,33,16,2,268,17,1,48,48,292,304,33,256,32,32,308]

theorem envBound37136 : H12AffineFastState.Bounded env37136 := by
  intro p hp
  have h : env37136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37133_37136 : H12AffineEnvironment.transform 9 53 env37133 = env37136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env37133 == env37136) = true)

theorem identity37136 : scanCanonicalize (H12AffineFastState.compose env37136 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound37136 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37137 : List Nat := [2,4,8,16,0,17,8,256,277,21,1,17,268,0,1,263,17,260,21,0,261,1,16,2,268,17,1,16,16,260,272,1,256,0,0,276]

theorem envBound37137 : H12AffineFastState.Bounded env37137 := by
  intro p hp
  have h : env37137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37136_37137 : H12AffineEnvironment.transform 4 0 env37136 = env37137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37136 == env37137) = true)

def leafEnv37137 : List Nat := [2,4,8,16,0,17,8,256,277,21,1,17,268,0,1,263,17,260,21,0,261,1,16,2,272,268,1,17,1,16,16,260,272,1,256,0,4,263,0,276,1,261,0]

def active37137 : List Nat := [0,1,2,3,7]

def tree37137 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37137 : H12WitnessSearch.Good tree37137 := H12GlobalWitnessIndex.good

theorem leafIdentity37137 : H12AffineFastState.composeSystem env37137 rootObs = leafEnv37137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37137 rootObs == leafEnv37137) = true)

theorem terminalChecked37137 : H12PackedTerminal.terminalCheckFast leafEnv37137 active37137 tree37137 = true := by decide +kernel

def env37138 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3889,268,2837,1,263,2820,2341,1024,0,3589,33,16,2,268,17,2048,2821,3888,2341,1285,33,256,32,2837,513]

theorem envBound37138 : H12AffineFastState.Bounded env37138 := by
  intro p hp
  have h : env37138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37124_37138 : H12AffineEnvironment.transform 11 3889 env37124 = env37138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env37124 == env37138) = true)

def env37139 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,49,268,1045,1,263,1028,1573,1024,0,261,33,16,2,268,17,1792,1029,48,1573,1285,33,256,32,1045,513]

theorem envBound37139 : H12AffineFastState.Bounded env37139 := by
  intro p hp
  have h : env37139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37138_37139 : H12AffineEnvironment.transform 10 1792 env37138 = env37139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env37138 == env37139) = true)

theorem identity37139 : scanCanonicalize (H12AffineFastState.compose env37139 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound37139 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37140 : List Nat := [2,4,8,16,32,17,8,256,17,1024,1297,49,268,1045,1,263,1028,1076,1024,0,261,33,16,2,268,17,1297,1029,48,1076,1285,33,256,32,1045,16]

theorem envBound37140 : H12AffineFastState.Bounded env37140 := by
  intro p hp
  have h : env37140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37139_37140 : H12AffineEnvironment.transform 8 17 env37139 = env37140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env37139 == env37140) = true)

def env37141 : List Nat := [2,4,8,16,32,17,8,256,17,52,293,49,268,33,1,263,48,0,52,0,261,33,16,2,268,17,293,49,48,0,305,33,256,32,33,16]

theorem envBound37141 : H12AffineFastState.Bounded env37141 := by
  intro p hp
  have h : env37141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37140_37141 : H12AffineEnvironment.transform 9 52 env37140 = env37141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env37140 == env37141) = true)

theorem identity37141 : scanCanonicalize (H12AffineFastState.compose env37141 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound37141 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37142 : List Nat := [2,4,8,10,32,11,8,256,11,46,293,43,268,33,1,263,42,0,46,0,261,33,10,2,268,11,293,43,42,0,299,33,256,32,33,10]

theorem envBound37142 : H12AffineFastState.Bounded env37142 := by
  intro p hp
  have h : env37142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37141_37142 : H12AffineEnvironment.transform 3 10 env37141 = env37142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env37141 == env37142) = true)

def leafEnv37142 : List Nat := [2,4,8,10,32,11,8,256,11,46,293,43,268,33,1,263,42,0,46,0,261,33,10,2,299,268,1,11,293,43,42,0,299,33,256,32,4,263,33,10,1,261,0]

def active37142 : List Nat := [0,1,2,4,7]

def tree37142 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37142 : H12WitnessSearch.Good tree37142 := H12GlobalWitnessIndex.good

theorem leafIdentity37142 : H12AffineFastState.composeSystem env37142 rootObs = leafEnv37142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37142 rootObs == leafEnv37142) = true)

theorem terminalChecked37142 : H12PackedTerminal.terminalCheckFast leafEnv37142 active37142 tree37142 = true := by decide +kernel

def env37143 : List Nat := [2,4,8,16,32,17,8,256,17,53,292,49,268,32,1,263,49,1,53,0,261,33,16,2,268,17,292,48,48,1,304,33,256,32,32,16]

theorem envBound37143 : H12AffineFastState.Bounded env37143 := by
  intro p hp
  have h : env37143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37140_37143 : H12AffineEnvironment.transform 9 53 env37140 = env37143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env37140 == env37143) = true)

theorem identity37143 : scanCanonicalize (H12AffineFastState.compose env37143 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound37143 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37144 : List Nat := [2,4,8,16,32,17,8,5,17,53,33,49,9,32,1,2,49,1,53,0,0,33,16,2,9,17,33,48,48,1,53,33,5,32,32,16]

theorem envBound37144 : H12AffineFastState.Bounded env37144 := by
  intro p hp
  have h : env37144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37143_37144 : H12AffineEnvironment.transform 7 5 env37143 = env37144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env37143 == env37144) = true)

def leafEnv37144 : List Nat := [2,4,8,16,32,17,8,5,17,53,33,49,9,32,1,2,49,1,53,0,0,33,16,2,53,9,1,17,33,48,48,1,53,33,5,32,4,2,32,16,1,0,0]

def active37144 : List Nat := [0,1,2,3,4]

def tree37144 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37144 : H12WitnessSearch.Good tree37144 := H12GlobalWitnessIndex.good

theorem leafIdentity37144 : H12AffineFastState.composeSystem env37144 rootObs = leafEnv37144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37144 rootObs == leafEnv37144) = true)

theorem terminalChecked37144 : H12PackedTerminal.terminalCheckFast leafEnv37144 active37144 tree37144 = true := by decide +kernel

def env37145 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,48,268,1044,1,263,1029,1572,1024,0,260,33,16,2,268,17,1793,1028,49,1572,1285,33,256,32,1044,513]

theorem envBound37145 : H12AffineFastState.Bounded env37145 := by
  intro p hp
  have h : env37145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37138_37145 : H12AffineEnvironment.transform 10 1793 env37138 = env37145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env37138 == env37145) = true)

theorem identity37145 : scanCanonicalize (H12AffineFastState.compose env37145 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 769) := by decide +kernel

theorem selectedBound37145 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37146 : List Nat := [2,4,8,16,32,17,8,256,512,769,0,48,268,789,1,263,772,293,769,0,260,33,16,2,268,17,0,773,49,293,516,33,256,32,789,513]

theorem envBound37146 : H12AffineFastState.Bounded env37146 := by
  intro p hp
  have h : env37146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37145_37146 : H12AffineEnvironment.transform 9 769 env37145 = env37146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env37145 == env37146) = true)

def env37147 : List Nat := [2,4,8,16,32,17,8,256,308,53,0,48,268,33,1,263,48,293,53,0,260,33,16,2,268,17,0,49,49,293,304,33,256,32,33,309]

theorem envBound37147 : H12AffineFastState.Bounded env37147 := by
  intro p hp
  have h : env37147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37146_37147 : H12AffineEnvironment.transform 8 308 env37146 = env37147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env37146 == env37147) = true)

theorem identity37147 : scanCanonicalize (H12AffineFastState.compose env37147 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound37147 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37148 : List Nat := [2,4,8,16,0,17,8,256,276,21,0,16,268,1,1,263,16,261,21,0,260,1,16,2,268,17,0,17,17,261,272,1,256,0,1,277]

theorem envBound37148 : H12AffineFastState.Bounded env37148 := by
  intro p hp
  have h : env37148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37147_37148 : H12AffineEnvironment.transform 4 0 env37147 = env37148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37147 == env37148) = true)

def leafEnv37148 : List Nat := [2,4,8,16,0,17,8,256,276,21,0,16,268,1,1,263,16,261,21,0,260,1,16,2,272,268,1,17,0,17,17,261,272,1,256,0,4,263,1,277,1,260,0]

def active37148 : List Nat := [0,1,2,3,7]

def tree37148 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37148 : H12WitnessSearch.Good tree37148 := H12GlobalWitnessIndex.good

theorem leafIdentity37148 : H12AffineFastState.composeSystem env37148 rootObs = leafEnv37148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37148 rootObs == leafEnv37148) = true)

theorem terminalChecked37148 : H12PackedTerminal.terminalCheckFast leafEnv37148 active37148 tree37148 = true := by decide +kernel

def env37149 : List Nat := [2,4,8,16,32,17,8,256,309,52,0,48,268,32,1,263,49,293,52,0,260,33,16,2,268,17,0,48,49,293,305,33,256,32,32,308]

theorem envBound37149 : H12AffineFastState.Bounded env37149 := by
  intro p hp
  have h : env37149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37146_37149 : H12AffineEnvironment.transform 8 309 env37146 = env37149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env37146 == env37149) = true)

theorem identity37149 : scanCanonicalize (H12AffineFastState.compose env37149 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound37149 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37150 : List Nat := [2,4,8,11,32,10,8,256,302,47,0,43,268,32,1,263,42,293,47,0,260,33,11,2,268,10,0,43,42,293,298,33,256,32,32,303]

theorem envBound37150 : H12AffineFastState.Bounded env37150 := by
  intro p hp
  have h : env37150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37149_37150 : H12AffineEnvironment.transform 3 11 env37149 = env37150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env37149 == env37150) = true)

def leafEnv37150 : List Nat := [2,4,8,11,32,10,8,256,302,47,0,43,268,32,1,263,42,293,47,0,260,33,11,2,298,268,1,10,0,43,42,293,298,33,256,32,4,263,32,303,1,260,0]

def active37150 : List Nat := [0,1,2,4,7]

def tree37150 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37150 : H12WitnessSearch.Good tree37150 := H12GlobalWitnessIndex.good

theorem leafIdentity37150 : H12AffineFastState.composeSystem env37150 rootObs = leafEnv37150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37150 rootObs == leafEnv37150) = true)

theorem terminalChecked37150 : H12PackedTerminal.terminalCheckFast leafEnv37150 active37150 tree37150 = true := by decide +kernel

def env37151 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830977,25265169,23160256,257,27378861,27337993,25207750]

theorem envBound37151 : H12AffineFastState.Bounded env37151 := by
  intro p hp
  have h : env37151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37065_37151 : H12AffineEnvironment.transform 18 1025 env37065 = env37151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env37065 == env37151) = true)

theorem identity37151 : scanCanonicalize (H12AffineFastState.compose env37151 (packedSelected [13] rootPS)) = affineNative (2^(16+1) ^^^ 123027) := by decide +kernel

theorem selectedBound37151 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env37152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29630611,18973837,10507600,8724626,25265169,23160256,257,27378861,27337993,25207750]

theorem envBound37152 : H12AffineFastState.Bounded env37152 := by
  intro p hp
  have h : env37152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37151_37152 : H12AffineEnvironment.transform 16 123027 env37151 = env37152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 123027 env37151 == env37152) = true)

def env37153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,2097152,4194304,8388608,10588556,8328,64,6664479,8393985,10507600,8724626,2102685,12645452,257,21793,46213,2175562]

theorem envBound37153 : H12AffineFastState.Bounded env37153 := by
  intro p hp
  have h : env37153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37152_37153 : H12AffineEnvironment.transform 23 10588556 env37152 = env37153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588556 env37152 == env37153) = true)

def env37154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6664479,2098513,17664,2437314,2102685,6349852,257,21793,46213,2175562]

theorem envBound37154 : H12AffineFastState.Bounded env37154 := by
  intro p hp
  have h : env37154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37153_37154 : H12AffineEnvironment.transform 22 2101328 env37153 = env37154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env37153 == env37154) = true)

def env37155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2202015,2098513,17664,2437314,2102685,2411676,257,21793,46213,2175562]

theorem envBound37155 : H12AffineFastState.Bounded env37155 := by
  intro p hp
  have h : env37155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37154_37155 : H12AffineEnvironment.transform 21 272512 env37154 = env37155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env37154 == env37155) = true)

theorem identity37155 : scanCanonicalize (H12AffineFastState.compose env37155 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound37155 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,13388,262144,1025,32769,2097152,272512,2101328,21763,8328,64,2116928,2098513,17664,2417693,2102685,2411676,257,21793,46213,2156181]

theorem envBound37156 : H12AffineFastState.Bounded env37156 := by
  intro p hp
  have h : env37156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37155_37156 : H12AffineEnvironment.transform 15 54495 env37155 = env37156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env37155 == env37156) = true)

def env37157 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,13340,262144,1025,32769,2097152,272512,2101248,21763,8328,16,2116880,2098433,17664,2417693,2102685,2411676,257,21793,46213,2156181]

theorem envBound37157 : H12AffineFastState.Bounded env37157 := by
  intro p hp
  have h : env37157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37156_37157 : H12AffineEnvironment.transform 5 16 env37156 = env37157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37156 == env37157) = true)

theorem identity37157 : scanCanonicalize (H12AffineFastState.compose env37157 (packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS)) = affineNative (2^(17+1) ^^^ 35244) := by decide +kernel

theorem selectedBound37157 : packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS < 2^1333 := by decide +kernel

def env37158 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,13340,35244,1025,32769,2097152,41260,2101248,21763,8328,16,2116880,2098433,17664,2125233,2102685,2114864,257,21793,46213,2156181]

theorem envBound37158 : H12AffineFastState.Bounded env37158 := by
  intro p hp
  have h : env37158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37157_37158 : H12AffineEnvironment.transform 17 35244 env37157 = env37158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35244 env37157 == env37158) = true)

theorem identity37158 : scanCanonicalize (H12AffineFastState.compose env37158 (packedSelected [1,4,5,7,8,9,10,16,19,20,24,26,27,31] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound37158 : packedSelected [1,4,5,7,8,9,10,16,19,20,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env37159 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8581,29962,13340,10281,1025,8580,2097152,169,2101248,21763,8328,16,2116880,2098433,17664,2125233,2102685,2114864,257,21793,5376,2115344]

theorem envBound37159 : H12AffineFastState.Bounded env37159 := by
  intro p hp
  have h : env37159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37158_37159 : H12AffineEnvironment.transform 14 8581 env37158 = env37159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env37158 == env37159) = true)

theorem identity37159 : scanCanonicalize (H12AffineFastState.compose env37159 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 17681) := by decide +kernel

theorem selectedBound37159 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env37160 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8581,29962,13340,10281,1025,8580,17681,169,21777,21763,8328,16,2049,16400,17664,10400,20620,33,257,21793,5376,513]

theorem envBound37160 : H12AffineFastState.Bounded env37160 := by
  intro p hp
  have h : env37160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37159_37160 : H12AffineEnvironment.transform 20 17681 env37159 = env37160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17681 env37159 == env37160) = true)

theorem identity37160 : scanCanonicalize (H12AffineFastState.compose env37160 (packedSelected [2,4,6,9,14,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound37160 : packedSelected [2,4,6,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env37161 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8581,8203,13340,10281,1025,8580,4112,169,16,2,8328,16,2049,5393,4097,10400,1421,33,257,32,5376,513]

theorem envBound37161 : H12AffineFastState.Bounded env37161 := by
  intro p hp
  have h : env37161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37160_37161 : H12AffineEnvironment.transform 13 5377 env37160 = env37161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env37160 == env37161) = true)

theorem identity37161 : scanCanonicalize (H12AffineFastState.compose env37161 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound37161 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37162 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5377,137,263,5392,2341,1025,136,4112,169,16,2,388,16,2049,5393,4097,2476,1421,33,257,32,5376,513]

theorem envBound37162 : H12AffineFastState.Bounded env37162 := by
  intro p hp
  have h : env37162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37161_37162 : H12AffineEnvironment.transform 12 268 env37161 = env37162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env37161 == env37162) = true)

theorem identity37162 : scanCanonicalize (H12AffineFastState.compose env37162 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound37162 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env37163 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2049,268,3328,137,263,3345,2341,1025,136,2065,169,16,2,388,16,2049,3344,2048,2476,1421,33,257,32,3329,513]

theorem envBound37163 : H12AffineFastState.Bounded env37163 := by
  intro p hp
  have h : env37163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37162_37163 : H12AffineEnvironment.transform 11 2049 env37162 = env37163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env37162 == env37163) = true)

theorem identity37163 : scanCanonicalize (H12AffineFastState.compose env37163 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound37163 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env37164 : List Nat := [2,4,8,16,32,16,128,256,512,1024,513,512,268,1793,137,263,1808,804,1025,136,528,169,16,2,388,16,512,1809,513,941,1421,33,257,32,1792,513]

theorem envBound37164 : H12AffineFastState.Bounded env37164 := by
  intro p hp
  have h : env37164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37163_37164 : H12AffineEnvironment.transform 10 513 env37163 = env37164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env37163 == env37164) = true)

theorem identity37164 : scanCanonicalize (H12AffineFastState.compose env37164 (packedSelected [0,2,3,5,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound37164 : packedSelected [0,2,3,5,9] rootPS < 2^1333 := by decide +kernel

def env37165 : List Nat := [2,4,8,16,32,16,9,256,512,1024,513,512,268,1793,0,263,1808,804,1025,1,528,32,16,2,269,16,512,1809,513,804,1284,33,257,32,1792,513]

theorem envBound37165 : H12AffineFastState.Bounded env37165 := by
  intro p hp
  have h : env37165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37164_37165 : H12AffineEnvironment.transform 6 9 env37164 = env37165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37164 == env37165) = true)

theorem identity37165 : scanCanonicalize (H12AffineFastState.compose env37165 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound37165 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37166 : List Nat := [2,4,8,16,32,16,9,256,512,37,513,512,268,804,0,263,821,804,36,1,528,32,16,2,269,16,512,820,513,804,289,33,257,32,805,513]

theorem envBound37166 : H12AffineFastState.Bounded env37166 := by
  intro p hp
  have h : env37166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37165_37166 : H12AffineEnvironment.transform 9 37 env37165 = env37166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env37165 == env37166) = true)

def env37167 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,13341,262144,1025,32769,2097152,272512,2101249,21763,8328,17,2116881,2098432,17664,2417693,2102685,2411676,257,21793,46213,2156181]

theorem envBound37167 : H12AffineFastState.Bounded env37167 := by
  intro p hp
  have h : env37167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37156_37167 : H12AffineEnvironment.transform 5 17 env37156 = env37167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37156 == env37167) = true)

theorem identity37167 : scanCanonicalize (H12AffineFastState.compose env37167 (packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound37167 : packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS < 2^1333 := by decide +kernel

def env37168 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,32768,33167,13341,262144,1025,32769,2097152,272512,2101249,2,8328,17,2103312,2098432,4097,2404636,2102685,2398621,257,32,46213,2143124]

theorem envBound37168 : H12AffineFastState.Bounded env37168 := by
  intro p hp
  have h : env37168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37167_37168 : H12AffineEnvironment.transform 13 5377 env37167 = env37168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env37167 == env37168) = true)

theorem identity37168 : scanCanonicalize (H12AffineFastState.compose env37168 (packedSelected [0,4,5,7,8,11,16,17,18,19,20,22,23,24,28,31,32] rootPS)) = affineNative (2^(20+1) ^^^ 37016) := by decide +kernel

theorem selectedBound37168 : packedSelected [0,4,5,7,8,11,16,17,18,19,20,22,23,24,28,31,32] rootPS < 2^1333 := by decide +kernel

def env37169 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,32768,33167,13341,262144,1025,32769,37016,272512,32921,2,8328,17,34952,38296,4097,270724,34053,264453,257,32,46213,8972]

theorem envBound37169 : H12AffineFastState.Bounded env37169 := by
  intro p hp
  have h : env37169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37168_37169 : H12AffineEnvironment.transform 20 37016 env37168 = env37169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 37016 env37168 == env37169) = true)

theorem identity37169 : scanCanonicalize (H12AffineFastState.compose env37169 (packedSelected [3,4,7,9,10,17,18,19,23,24,27] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound37169 : packedSelected [3,4,7,9,10,17,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env37170 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,32768,33030,13341,262144,1025,32769,36881,272393,32784,2,8193,17,34817,38161,4097,270605,34053,264453,257,32,46092,8972]

theorem envBound37170 : H12AffineFastState.Bounded env37170 := by
  intro p hp
  have h : env37170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37169_37170 : H12AffineEnvironment.transform 6 9 env37169 = env37170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37169 == env37170) = true)

theorem identity37170 : scanCanonicalize (H12AffineFastState.compose env37170 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound37170 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env37171 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,32768,33030,13341,43048,1025,32769,36881,32801,32784,2,8193,17,34817,38161,4097,35109,34053,41261,257,32,46092,8972]

theorem envBound37171 : H12AffineFastState.Bounded env37171 := by
  intro p hp
  have h : env37171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37170_37171 : H12AffineEnvironment.transform 17 43048 env37170 = env37171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env37170 == env37171) = true)

theorem identity37171 : scanCanonicalize (H12AffineFastState.compose env37171 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 9529) := by decide +kernel

theorem selectedBound37171 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env37172 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,9529,9279,13341,3345,1025,9528,13608,9496,9513,2,8193,17,11576,12328,4097,11292,8252,1044,257,32,4405,8972]

theorem envBound37172 : H12AffineFastState.Bounded env37172 := by
  intro p hp
  have h : env37172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37171_37172 : H12AffineEnvironment.transform 14 9529 env37171 = env37172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9529 env37171 == env37172) = true)

theorem identity37172 : scanCanonicalize (H12AffineFastState.compose env37172 (packedSelected [0,7,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound37172 : packedSelected [0,7,11,14,15] rootPS < 2^1333 := by decide +kernel

def env37173 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,1076,1330,5392,3345,1025,1077,5157,1045,1060,2,268,17,3125,4389,4097,3345,305,1044,257,32,4405,513]

theorem envBound37173 : H12AffineFastState.Bounded env37173 := by
  intro p hp
  have h : env37173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37172_37173 : H12AffineEnvironment.transform 12 269 env37172 = env37173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env37172 == env37173) = true)

theorem identity37173 : scanCanonicalize (H12AffineFastState.compose env37173 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound37173 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37174 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,4096,269,4404,1,263,4389,2340,52,0,4112,32,17,2,268,17,2048,4389,4097,2340,305,33,257,32,4405,513]

theorem envBound37174 : H12AffineFastState.Bounded env37174 := by
  intro p hp
  have h : env37174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37173_37174 : H12AffineEnvironment.transform 9 53 env37173 = env37174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env37173 == env37174) = true)

theorem identity37174 : scanCanonicalize (H12AffineFastState.compose env37174 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37174 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37175 : List Nat := [2,4,8,16,1,17,9,256,512,20,2048,4096,269,4373,1,263,4356,2309,21,0,4112,1,17,2,268,17,2048,4356,4097,2309,272,0,257,1,4372,513]

theorem envBound37175 : H12AffineFastState.Bounded env37175 := by
  intro p hp
  have h : env37175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37174_37175 : H12AffineEnvironment.transform 4 1 env37174 = env37175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37174 == env37175) = true)

theorem identity37175 : scanCanonicalize (H12AffineFastState.compose env37175 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound37175 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37176 : List Nat := [2,4,8,16,1,17,9,256,512,20,523,4096,269,4373,1,263,4356,782,21,0,4112,1,17,2,268,17,523,4356,4097,782,272,0,257,1,4372,513]

theorem envBound37176 : H12AffineFastState.Bounded env37176 := by
  intro p hp
  have h : env37176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37175_37176 : H12AffineEnvironment.transform 10 523 env37175 = env37176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env37175 == env37176) = true)

theorem identity37176 : scanCanonicalize (H12AffineFastState.compose env37176 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound37176 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37177 : List Nat := [2,4,8,16,1,17,9,256,261,20,270,4096,269,4373,1,263,4356,11,21,0,4112,1,17,2,268,17,270,4356,4097,11,272,0,257,1,4372,260]

theorem envBound37177 : H12AffineFastState.Bounded env37177 := by
  intro p hp
  have h : env37177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37176_37177 : H12AffineEnvironment.transform 8 261 env37176 = env37177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env37176 == env37177) = true)

theorem identity37177 : scanCanonicalize (H12AffineFastState.compose env37177 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound37177 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env37178 : List Nat := [2,4,8,16,1,17,9,256,261,20,270,0,269,277,1,263,260,11,21,0,16,1,17,2,268,17,270,260,1,11,272,0,257,1,276,260]

theorem envBound37178 : H12AffineFastState.Bounded env37178 := by
  intro p hp
  have h : env37178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37177_37178 : H12AffineEnvironment.transform 11 0 env37177 = env37178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env37177 == env37178) = true)

theorem identity37178 : scanCanonicalize (H12AffineFastState.compose env37178 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound37178 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env37179 : List Nat := [2,4,8,6,1,7,9,256,261,2,270,0,269,259,1,263,260,11,3,0,6,1,7,2,268,7,270,260,1,11,262,0,257,1,258,260]

theorem envBound37179 : H12AffineFastState.Bounded env37179 := by
  intro p hp
  have h : env37179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37178_37179 : H12AffineEnvironment.transform 3 6 env37178 = env37179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env37178 == env37179) = true)

def env37180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2202014,2098513,17664,2437314,2102685,2411677,257,21793,46213,2175562]

theorem envBound37180 : H12AffineFastState.Bounded env37180 := by
  intro p hp
  have h : env37180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37154_37180 : H12AffineEnvironment.transform 21 272513 env37154 = env37180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env37154 == env37180) = true)

theorem identity37180 : scanCanonicalize (H12AffineFastState.compose env37180 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound37180 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,115870,272513,120014,98780,8328,64,23808,115151,17664,324700,119043,329731,257,21793,46213,63188]

theorem envBound37181 : H12AffineFastState.Bounded env37181 := by
  intro p hp
  have h : env37181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37180_37181 : H12AffineEnvironment.transform 20 115870 env37180 = env37181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env37180 == env37181) = true)

def env37182 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,10400,1025,32769,115870,33,120014,98780,8328,64,23808,115151,17664,56572,119043,73891,257,21793,46213,63188]

theorem envBound37182 : H12AffineFastState.Bounded env37182 := by
  intro p hp
  have h : env37182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37181_37182 : H12AffineEnvironment.transform 17 10400 env37181 = env37182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env37181 == env37182) = true)

theorem identity37182 : scanCanonicalize (H12AffineFastState.compose env37182 (packedSelected [4,7,9,11,14,18,23,27,32,35] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound37182 : packedSelected [4,7,9,11,14,18,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env37183 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,32768,65536,103630,10400,1025,32769,110787,33,106643,98780,8328,64,10589,112018,12637,43169,107870,73891,257,8572,46213,33417]

theorem envBound37183 : H12AffineFastState.Bounded env37183 := by
  intro p hp
  have h : env37183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37182_37183 : H12AffineEnvironment.transform 13 13405 env37182 = env37183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env37182 == env37183) = true)

theorem identity37183 : scanCanonicalize (H12AffineFastState.compose env37183 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound37183 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env37184 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,32768,8202,46276,10400,1025,32769,37065,33,32921,41430,8328,64,10589,38296,12637,43169,34132,169,257,8572,46213,33417]

theorem envBound37184 : H12AffineFastState.Bounded env37184 := by
  intro p hp
  have h : env37184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37183_37184 : H12AffineEnvironment.transform 15 8202 env37183 = env37184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env37183 == env37184) = true)

theorem identity37184 : scanCanonicalize (H12AffineFastState.compose env37184 (packedSelected [16,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound37184 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env37185 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,8202,46157,10281,1025,32769,36928,33,32784,41311,8193,64,10589,38161,12637,43048,34132,32,257,8572,46092,33280]

theorem envBound37185 : H12AffineFastState.Bounded env37185 := by
  intro p hp
  have h : env37185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37184_37185 : H12AffineEnvironment.transform 6 9 env37184 = env37185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37184 == env37185) = true)

theorem identity37185 : scanCanonicalize (H12AffineFastState.compose env37185 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound37185 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env37186 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8461,8202,5440,10281,1025,8460,12621,33,8477,82,8193,64,10589,13340,12637,2341,9305,32,257,8572,5377,8973]

theorem envBound37186 : H12AffineFastState.Bounded env37186 := by
  intro p hp
  have h : env37186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37185_37186 : H12AffineEnvironment.transform 14 8461 env37185 = env37186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env37185 == env37186) = true)

theorem identity37186 : scanCanonicalize (H12AffineFastState.compose env37186 (packedSelected [0,1,2,4,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound37186 : packedSelected [0,1,2,4,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env37187 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5457,1,262,5440,2341,1025,0,4161,33,17,82,269,64,2129,5392,4177,2341,1365,32,257,112,5377,513]

theorem envBound37187 : H12AffineFastState.Bounded env37187 := by
  intro p hp
  have h : env37187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37186_37187 : H12AffineEnvironment.transform 12 268 env37186 = env37187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env37186 == env37187) = true)

theorem identity37187 : scanCanonicalize (H12AffineFastState.compose env37187 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 783) := by decide +kernel

theorem selectedBound37187 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env37188 : List Nat := [2,4,8,16,32,64,9,256,512,1024,783,4096,268,5457,1,262,5440,554,1025,0,4161,33,17,82,269,64,862,5392,4177,554,1365,32,257,112,5377,513]

theorem envBound37188 : H12AffineFastState.Bounded env37188 := by
  intro p hp
  have h : env37188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37187_37188 : H12AffineEnvironment.transform 10 783 env37187 = env37188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 783 env37187 == env37188) = true)

theorem identity37188 : scanCanonicalize (H12AffineFastState.compose env37188 (packedSelected [0,2,3,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound37188 : packedSelected [0,2,3,5,9] rootPS < 2^1333 := by decide +kernel

def env37189 : List Nat := [2,4,8,16,32,64,9,116,512,1024,635,4096,120,5157,1,114,5172,554,1025,0,4161,33,17,82,121,64,554,5220,4177,554,1057,32,117,112,5237,513]

theorem envBound37189 : H12AffineFastState.Bounded env37189 := by
  intro p hp
  have h : env37189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37188_37189 : H12AffineEnvironment.transform 7 116 env37188 = env37189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env37188 == env37189) = true)

theorem identity37189 : scanCanonicalize (H12AffineFastState.compose env37189 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37189 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37190 : List Nat := [2,4,8,16,32,17,9,37,512,1024,554,4096,41,5157,1,35,5172,554,1025,0,4112,33,17,3,40,17,554,5173,4096,554,1057,32,36,33,5156,513]

theorem envBound37190 : H12AffineFastState.Bounded env37190 := by
  intro p hp
  have h : env37190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37189_37190 : H12AffineEnvironment.transform 5 17 env37189 = env37190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37189 == env37190) = true)

theorem identity37190 : scanCanonicalize (H12AffineFastState.compose env37190 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37190 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37191 : List Nat := [2,4,8,16,1,17,9,4,512,1024,523,4096,8,5124,1,2,5141,523,1025,0,4112,0,17,3,9,17,523,5140,4096,523,1024,1,5,0,5125,513]

theorem envBound37191 : H12AffineFastState.Bounded env37191 := by
  intro p hp
  have h : env37191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37190_37191 : H12AffineEnvironment.transform 4 1 env37190 = env37191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37190 == env37191) = true)

def env37192 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,10401,1025,32769,115870,32,120014,98780,8328,64,23808,115151,17664,56573,119043,73890,257,21793,46213,63188]

theorem envBound37192 : H12AffineFastState.Bounded env37192 := by
  intro p hp
  have h : env37192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37181_37192 : H12AffineEnvironment.transform 17 10401 env37181 = env37192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env37181 == env37192) = true)

theorem identity37192 : scanCanonicalize (H12AffineFastState.compose env37192 (packedSelected [4,7,9,11,14,18,23,27,32,35] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound37192 : packedSelected [4,7,9,11,14,18,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env37193 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,32768,65536,115014,2420,1025,32769,115870,32,120014,98780,349,64,23808,115151,17664,56573,119043,65911,257,21793,38224,55041]

theorem envBound37193 : H12AffineFastState.Bounded env37193 := by
  intro p hp
  have h : env37193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37192_37193 : H12AffineEnvironment.transform 12 469 env37192 = env37193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env37192 == env37193) = true)

theorem identity37193 : scanCanonicalize (H12AffineFastState.compose env37193 (packedSelected [0,2,5,6,10,11,12,14,15,16,17,18,20,24,26,27,31] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound37193 : packedSelected [0,2,5,6,10,11,12,14,15,16,17,18,20,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env37194 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,241,16384,32768,65536,114786,2128,1025,32769,115870,32,120014,98552,121,64,23588,114923,17444,56573,118823,65619,37,21509,38004,54821]

theorem envBound37194 : H12AffineFastState.Bounded env37194 := by
  intro p hp
  have h : env37194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37193_37194 : H12AffineEnvironment.transform 7 36 env37193 = env37194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env37193 == env37194) = true)

theorem identity37194 : scanCanonicalize (H12AffineFastState.compose env37194 (packedSelected [0,2,4,6,7,9,11,14,16,17,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 32802) := by decide +kernel

theorem selectedBound37194 : packedSelected [0,2,4,6,7,9,11,14,16,17,20,23] rootPS < 2^1333 := by decide +kernel

def env37195 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,241,16384,32768,32802,16448,2128,1025,32769,17596,32,21740,218,121,64,23588,16585,17444,56573,20485,32881,37,21509,38004,54821]

theorem envBound37195 : H12AffineFastState.Bounded env37195 := by
  intro p hp
  have h : env37195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37194_37195 : H12AffineEnvironment.transform 15 32802 env37194 = env37195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32802 env37194 == env37195) = true)

theorem identity37195 : scanCanonicalize (H12AffineFastState.compose env37195 (packedSelected [1,2,3,4,5,6,8,10,11,16,17,18,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound37195 : packedSelected [1,2,3,4,5,6,8,10,11,16,17,18,19,22] rootPS < 2^1333 := by decide +kernel

def env37196 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,241,5236,32768,32802,5172,2128,1025,32769,4296,32,152,218,121,64,2128,5309,4176,34953,1137,32881,37,113,38004,33361]

theorem envBound37196 : H12AffineFastState.Bounded env37196 := by
  intro p hp
  have h : env37196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37195_37196 : H12AffineEnvironment.transform 13 5236 env37195 = env37196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env37195 == env37196) = true)

def env37197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6664479,2098512,17665,2437315,2102685,6349853,257,21793,46213,2175562]

theorem envBound37197 : H12AffineFastState.Bounded env37197 := by
  intro p hp
  have h : env37197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37153_37197 : H12AffineEnvironment.transform 22 2101329 env37153 = env37197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env37153 == env37197) = true)

def env37198 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2202015,2098512,17665,2437315,2102685,2411677,257,21793,46213,2175562]

theorem envBound37198 : H12AffineFastState.Bounded env37198 := by
  intro p hp
  have h : env37198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37197_37198 : H12AffineEnvironment.transform 21 272512 env37197 = env37198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env37197 == env37198) = true)

theorem identity37198 : scanCanonicalize (H12AffineFastState.compose env37198 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound37198 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37199 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49304,262144,1025,32769,2097152,272512,2101329,41430,8328,64,2144660,2098512,17665,2363592,2102685,2411677,257,21793,46213,2101825]

theorem envBound37199 : H12AffineFastState.Bounded env37199 := by
  intro p hp
  have h : env37199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37198_37199 : H12AffineEnvironment.transform 15 8203 env37198 = env37199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env37198 == env37199) = true)

def env37200 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2202014,2098512,17665,2437315,2102685,2411676,257,21793,46213,2175562]

theorem envBound37200 : H12AffineFastState.Bounded env37200 := by
  intro p hp
  have h : env37200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37197_37200 : H12AffineEnvironment.transform 21 272513 env37197 = env37200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env37197 == env37200) = true)

theorem identity37200 : scanCanonicalize (H12AffineFastState.compose env37200 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound37200 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37201 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,77899,272513,73754,98781,8328,64,43477,79131,17665,262280,75222,392407,257,21793,46213,513]

theorem envBound37201 : H12AffineFastState.Bounded env37201 := by
  intro p hp
  have h : env37201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37200_37201 : H12AffineEnvironment.transform 20 77899 env37200 = env37201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env37200 == env37201) = true)

def env37202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,65536,90259,262144,1025,1,77899,272513,73754,66013,8328,64,10709,79131,17665,262280,75222,359639,257,21793,13445,513]

theorem envBound37202 : H12AffineFastState.Bounded env37202 := by
  intro p hp
  have h : env37202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37201_37202 : H12AffineEnvironment.transform 14 0 env37201 = env37202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env37201 == env37202) = true)

theorem identity37202 : scanCanonicalize (H12AffineFastState.compose env37202 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound37202 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env37203 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,65536,90138,262144,1025,1,77899,272392,73754,65876,8193,64,10588,79131,17665,262145,75103,359518,257,21793,13324,513]

theorem envBound37203 : H12AffineFastState.Bounded env37203 := by
  intro p hp
  have h : env37203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37202_37203 : H12AffineEnvironment.transform 6 9 env37202 = env37203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37202 == env37203) = true)

theorem identity37203 : scanCanonicalize (H12AffineFastState.compose env37203 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound37203 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env37204 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,65536,90138,67618,1025,1,77899,73770,73754,65876,8193,64,10588,79131,17665,67619,75103,29820,257,21793,13324,513]

theorem envBound37204 : H12AffineFastState.Bounded env37204 := by
  intro p hp
  have h : env37204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37203_37204 : H12AffineEnvironment.transform 17 67618 env37203 = env37204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env37203 == env37204) = true)

def env37205 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,65536,90258,262144,1025,0,77899,272513,73754,66012,8328,64,10708,79131,17665,262280,75222,359638,257,21793,13444,513]

theorem envBound37205 : H12AffineFastState.Bounded env37205 := by
  intro p hp
  have h : env37205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37201_37205 : H12AffineEnvironment.transform 14 1 env37201 = env37205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env37201 == env37205) = true)

theorem identity37205 : scanCanonicalize (H12AffineFastState.compose env37205 (packedSelected [4,9,12,14,15,16,17,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound37205 : packedSelected [4,9,12,14,15,16,17,38,41] rootPS < 2^1333 := by decide +kernel

def env37206 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8322,16400,262144,1025,0,4297,272513,152,8542,8328,64,10708,5529,17665,262280,1364,285780,257,21793,13444,513]

theorem envBound37206 : H12AffineFastState.Bounded env37206 := by
  intro p hp
  have h : env37206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37205_37206 : H12AffineEnvironment.transform 15 8322 env37205 = env37206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env37205 == env37206) = true)

theorem identity37206 : scanCanonicalize (H12AffineFastState.compose env37206 (packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound37206 : packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS < 2^1333 := by decide +kernel

def env37207 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8322,16400,10281,1025,0,4297,168,152,8542,8328,64,10708,5529,17665,10401,1364,29821,257,21793,13444,513]

theorem envBound37207 : H12AffineFastState.Bounded env37207 := by
  intro p hp
  have h : env37207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37206_37207 : H12AffineEnvironment.transform 17 10281 env37206 = env37207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env37206 == env37207) = true)

theorem identity37207 : scanCanonicalize (H12AffineFastState.compose env37207 (packedSelected [2,3,5,6,10,17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound37207 : packedSelected [2,3,5,6,10,17] rootPS < 2^1333 := by decide +kernel

def env37208 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,1,8322,5392,10281,1025,0,4297,168,152,8542,8328,64,10708,5529,4097,10401,1364,8573,257,33,13444,513]

theorem envBound37208 : H12AffineFastState.Bounded env37208 := by
  intro p hp
  have h : env37208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37207_37208 : H12AffineEnvironment.transform 13 5376 env37207 = env37208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env37207 == env37208) = true)

theorem identity37208 : scanCanonicalize (H12AffineFastState.compose env37208 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound37208 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37209 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,1,479,5392,2420,1025,0,4297,168,152,3,469,64,2185,5529,4097,2556,1364,32,257,33,5593,513]

theorem envBound37209 : H12AffineFastState.Bounded env37209 := by
  intro p hp
  have h : env37209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37208_37209 : H12AffineEnvironment.transform 12 349 env37208 = env37209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env37208 == env37209) = true)

theorem identity37209 : scanCanonicalize (H12AffineFastState.compose env37209 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound37209 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37210 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,342,5392,2420,1025,0,4160,33,17,3,348,64,2048,5392,4097,2421,1364,32,257,33,5456,513]

theorem envBound37210 : H12AffineFastState.Bounded env37210 := by
  intro p hp
  have h : env37210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37209_37210 : H12AffineEnvironment.transform 6 9 env37209 = env37210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37209 == env37210) = true)

theorem identity37210 : scanCanonicalize (H12AffineFastState.compose env37210 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2074) := by decide +kernel

theorem selectedBound37210 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37211 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2074,349,3354,1,342,3338,2420,1025,0,2138,33,17,3,348,64,2048,3338,2075,2421,1364,32,257,33,3402,513]

theorem envBound37211 : H12AffineFastState.Bounded env37211 := by
  intro p hp
  have h : env37211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37210_37211 : H12AffineEnvironment.transform 11 2074 env37210 = env37211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2074 env37210 == env37211) = true)

theorem identity37211 : scanCanonicalize (H12AffineFastState.compose env37211 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 111) := by decide +kernel

theorem selectedBound37211 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env37212 : List Nat := [2,4,8,16,32,64,9,111,512,1024,2048,2074,50,3189,1,57,3173,2075,1025,0,2138,33,17,3,51,64,2048,3173,2075,2074,1083,32,110,33,3109,513]

theorem envBound37212 : H12AffineFastState.Bounded env37212 := by
  intro p hp
  have h : env37212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37211_37212 : H12AffineEnvironment.transform 7 111 env37211 = env37212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 111 env37211 == env37212) = true)

theorem identity37212 : scanCanonicalize (H12AffineFastState.compose env37212 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37212 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env37213 : List Nat := [2,4,8,16,1,64,9,78,512,1024,2048,2074,19,3156,1,24,3140,2075,1025,0,2138,0,17,3,18,64,2048,3140,2075,2074,1050,1,79,0,3076,513]

theorem envBound37213 : H12AffineFastState.Bounded env37213 := by
  intro p hp
  have h : env37213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37212_37213 : H12AffineEnvironment.transform 4 1 env37212 = env37213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37212 == env37213) = true)

def env37214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,2097152,4194304,8388608,10588557,8328,64,6664478,8393984,10507600,8724626,2102684,12645453,257,21792,46212,2175563]

theorem envBound37214 : H12AffineFastState.Bounded env37214 := by
  intro p hp
  have h : env37214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37152_37214 : H12AffineEnvironment.transform 23 10588557 env37152 = env37214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588557 env37152 == env37214) = true)

def env37215 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6664478,2098512,17664,2437314,2102684,6349853,257,21792,46212,2175563]

theorem envBound37215 : H12AffineFastState.Bounded env37215 := by
  intro p hp
  have h : env37215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37214_37215 : H12AffineEnvironment.transform 22 2101328 env37214 = env37215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env37214 == env37215) = true)

def env37216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2202014,2098512,17664,2437314,2102684,2411677,257,21792,46212,2175563]

theorem envBound37216 : H12AffineFastState.Bounded env37216 := by
  intro p hp
  have h : env37216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37215_37216 : H12AffineEnvironment.transform 21 272512 env37215 = env37216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env37215 == env37216) = true)

theorem identity37216 : scanCanonicalize (H12AffineFastState.compose env37216 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound37216 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37217 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,4161,272512,17,98781,8328,64,100831,5393,17664,336003,1501,318684,257,21792,46212,74250]

theorem envBound37217 : H12AffineFastState.Bounded env37217 := by
  intro p hp
  have h : env37217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37216_37217 : H12AffineEnvironment.transform 20 4161 env37216 = env37217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env37216 == env37217) = true)

theorem identity37217 : scanCanonicalize (H12AffineFastState.compose env37217 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound37217 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env37218 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49304,262144,1025,32769,4161,272512,17,41430,8328,64,43476,5393,17664,262280,1501,318684,257,21792,46212,513]

theorem envBound37218 : H12AffineFastState.Bounded env37218 := by
  intro p hp
  have h : env37218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37217_37218 : H12AffineEnvironment.transform 15 8203 env37217 = env37218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env37217 == env37218) = true)

def env37219 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2202015,2098512,17664,2437314,2102684,2411676,257,21792,46212,2175563]

theorem envBound37219 : H12AffineFastState.Bounded env37219 := by
  intro p hp
  have h : env37219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37215_37219 : H12AffineEnvironment.transform 21 272513 env37215 = env37219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env37215 == env37219) = true)

def env37220 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,272393,2101328,98645,8192,64,2201879,2098512,17664,2437194,2102548,2411540,257,21792,46092,2175563]

theorem envBound37220 : H12AffineFastState.Bounded env37220 := by
  intro p hp
  have h : env37220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37219_37220 : H12AffineEnvironment.transform 6 8 env37219 = env37220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37219 == env37220) = true)

theorem identity37220 : scanCanonicalize (H12AffineFastState.compose env37220 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 36929) := by decide +kernel

theorem selectedBound37220 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env37221 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,36929,272393,32785,98645,8192,64,67926,38161,17664,368651,34133,285781,257,21792,46092,107018]

theorem envBound37221 : H12AffineFastState.Bounded env37221 := by
  intro p hp
  have h : env37221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37220_37221 : H12AffineEnvironment.transform 20 36929 env37220 = env37221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 36929 env37220 == env37221) = true)

theorem identity37221 : scanCanonicalize (H12AffineFastState.compose env37221 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound37221 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env37222 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,342,57677,262144,1025,32769,36929,272393,32785,32771,8192,64,2048,38161,17664,303453,34133,285781,257,21792,46092,41820]

theorem envBound37222 : H12AffineFastState.Bounded env37222 := by
  intro p hp
  have h : env37222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37221_37222 : H12AffineEnvironment.transform 15 342 env37221 = env37222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env37221 == env37222) = true)

theorem identity37222 : scanCanonicalize (H12AffineFastState.compose env37222 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound37222 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env37223 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,342,57677,2421,1025,32769,36929,8572,32785,32771,8192,64,2048,38161,17664,43048,34133,21792,257,21792,46092,41820]

theorem envBound37223 : H12AffineFastState.Bounded env37223 := by
  intro p hp
  have h : env37223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37222_37223 : H12AffineEnvironment.transform 17 2421 env37222 = env37223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env37222 == env37223) = true)

theorem identity37223 : scanCanonicalize (H12AffineFastState.compose env37223 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound37223 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env37224 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,342,24908,2421,1025,0,4160,8572,16,2,8192,64,2048,5392,17664,10281,1364,21792,257,21792,13325,9053]

theorem envBound37224 : H12AffineFastState.Bounded env37224 := by
  intro p hp
  have h : env37224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37223_37224 : H12AffineEnvironment.transform 14 1 env37223 = env37224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env37223 == env37224) = true)

theorem identity37224 : scanCanonicalize (H12AffineFastState.compose env37224 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound37224 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env37225 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,1,342,5173,2421,1025,0,4160,8572,16,2,8192,64,2048,5392,12409,10281,1364,8281,257,8281,13325,9053]

theorem envBound37225 : H12AffineFastState.Bounded env37225 := by
  intro p hp
  have h : env37225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37224_37225 : H12AffineEnvironment.transform 13 13689 env37224 = env37225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env37224 == env37225) = true)

theorem identity37225 : scanCanonicalize (H12AffineFastState.compose env37225 (packedSelected [1,2,4,6,8,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound37225 : packedSelected [1,2,4,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env37226 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1141,8192,8460,1,342,64,2421,1025,0,1077,8572,16,2,8192,64,2048,357,9228,10281,1364,8281,257,8281,8312,9053]

theorem envBound37226 : H12AffineFastState.Bounded env37226 := by
  intro p hp
  have h : env37226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37225_37226 : H12AffineEnvironment.transform 11 1141 env37225 = env37226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env37225 == env37226) = true)

theorem identity37226 : scanCanonicalize (H12AffineFastState.compose env37226 (packedSelected [6,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound37226 : packedSelected [6,12,14,15] rootPS < 2^1333 := by decide +kernel

def env37227 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1141,1337,1077,1,342,64,2421,1025,0,1077,1093,16,2,1337,64,2048,357,309,3344,1364,1376,257,1376,1345,1636]

theorem envBound37227 : H12AffineFastState.Bounded env37227 := by
  intro p hp
  have h : env37227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37226_37227 : H12AffineEnvironment.transform 12 1337 env37226 = env37227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env37226 == env37227) = true)

def env37228 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,272392,2101328,98644,8193,64,2201878,2098512,17664,2437195,2102549,2411541,257,21792,46093,2175563]

theorem envBound37228 : H12AffineFastState.Bounded env37228 := by
  intro p hp
  have h : env37228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37219_37228 : H12AffineEnvironment.transform 6 9 env37219 = env37228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37219 == env37228) = true)

def env37229 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,4160,272392,16,98644,8193,64,100694,5392,17664,335883,1365,318549,257,21792,46093,74251]

theorem envBound37229 : H12AffineFastState.Bounded env37229 := by
  intro p hp
  have h : env37229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37228_37229 : H12AffineEnvironment.transform 20 4160 env37228 = env37229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env37228 == env37229) = true)

theorem identity37229 : scanCanonicalize (H12AffineFastState.compose env37229 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 130095) := by decide +kernel

theorem selectedBound37229 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env37230 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,130095,1025,32769,4160,119847,16,98644,8193,64,100694,5392,17664,56356,1365,73850,257,21792,46093,74251]

theorem envBound37230 : H12AffineFastState.Bounded env37230 := by
  intro p hp
  have h : env37230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37229_37230 : H12AffineEnvironment.transform 17 130095 env37229 = env37230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130095 env37229 == env37230) = true)

theorem identity37230 : scanCanonicalize (H12AffineFastState.compose env37230 (packedSelected [0,3,9,10,18,22,23,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound37230 : packedSelected [0,3,9,10,18,22,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env37231 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,32768,65536,103447,100386,1025,32769,4160,106538,16,98644,8193,64,100694,5392,12557,43049,1365,73850,257,8493,46093,74251]

theorem envBound37231 : H12AffineFastState.Bounded env37231 := by
  intro p hp
  have h : env37231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37230_37231 : H12AffineEnvironment.transform 13 13325 env37230 = env37231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env37230 == env37231) = true)

theorem identity37231 : scanCanonicalize (H12AffineFastState.compose env37231 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound37231 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env37232 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,32768,8202,46109,43048,1025,32769,4160,32800,16,41310,8193,64,43356,5392,12557,43049,1365,112,257,8493,46093,513]

theorem envBound37232 : H12AffineFastState.Bounded env37232 := by
  intro p hp
  have h : env37232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37231_37232 : H12AffineEnvironment.transform 15 8202 env37231 = env37232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env37231 == env37232) = true)

theorem identity37232 : scanCanonicalize (H12AffineFastState.compose env37232 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound37232 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env37233 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,8540,8202,5441,2420,1025,8541,4160,8572,16,2,8193,64,2048,5392,12557,2421,1365,112,257,8493,5457,513]

theorem envBound37233 : H12AffineFastState.Bounded env37233 := by
  intro p hp
  have h : env37233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37232_37233 : H12AffineEnvironment.transform 14 8540 env37232 = env37233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env37232 == env37233) = true)

def env37234 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,4161,272392,17,98644,8193,64,100695,5393,17664,335882,1364,318548,257,21792,46093,74250]

theorem envBound37234 : H12AffineFastState.Bounded env37234 := by
  intro p hp
  have h : env37234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37228_37234 : H12AffineEnvironment.transform 20 4161 env37228 = env37234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env37228 == env37234) = true)

theorem identity37234 : scanCanonicalize (H12AffineFastState.compose env37234 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound37234 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37235 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10281,1025,32769,4161,33,17,98644,8193,64,100695,5393,17664,67619,1364,62589,257,21792,46093,74250]

theorem envBound37235 : H12AffineFastState.Bounded env37235 := by
  intro p hp
  have h : env37235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37234_37235 : H12AffineEnvironment.transform 17 10281 env37234 = env37235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env37234 == env37235) = true)

theorem identity37235 : scanCanonicalize (H12AffineFastState.compose env37235 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound37235 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env37236 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,65536,90138,10281,1025,1,4161,33,17,65876,8193,64,67927,5393,17664,67619,1364,29821,257,21792,13325,74250]

theorem envBound37236 : H12AffineFastState.Bounded env37236 := by
  intro p hp
  have h : env37236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37235_37236 : H12AffineEnvironment.transform 14 0 env37235 = env37236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env37235 == env37236) = true)

theorem identity37236 : scanCanonicalize (H12AffineFastState.compose env37236 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound37236 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env37237 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,8203,16401,10281,1025,1,4161,33,17,8543,8193,64,10588,5393,17664,10280,1364,29821,257,21792,13325,513]

theorem envBound37237 : H12AffineFastState.Bounded env37237 := by
  intro p hp
  have h : env37237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37236_37237 : H12AffineEnvironment.transform 15 8203 env37236 = env37237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env37236 == env37237) = true)

theorem identity37237 : scanCanonicalize (H12AffineFastState.compose env37237 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound37237 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env37238 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,0,342,16401,2420,1025,1,4161,33,17,2,348,64,2049,5393,17664,2421,1364,21792,257,21792,5456,513]

theorem envBound37238 : H12AffineFastState.Bounded env37238 := by
  intro p hp
  have h : env37238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37237_37238 : H12AffineEnvironment.transform 12 349 env37237 = env37238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env37237 == env37238) = true)

theorem identity37238 : scanCanonicalize (H12AffineFastState.compose env37238 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound37238 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env37239 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,4112,0,342,4097,2420,1025,1,4161,33,17,2,348,64,2049,5393,5392,2421,1364,1328,257,1328,5456,513]

theorem envBound37239 : H12AffineFastState.Bounded env37239 := by
  intro p hp
  have h : env37239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37238_37239 : H12AffineEnvironment.transform 13 4112 env37238 = env37239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env37238 == env37239) = true)

theorem identity37239 : scanCanonicalize (H12AffineFastState.compose env37239 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound37239 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env37240 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,8,4112,0,3,4097,2081,1025,1,4161,33,17,2,9,64,2049,5188,5189,2080,1025,1125,84,1125,5125,513]

theorem envBound37240 : H12AffineFastState.Bounded env37240 := by
  intro p hp
  have h : env37240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37239_37240 : H12AffineEnvironment.transform 7 85 env37239 = env37240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env37239 == env37240) = true)

theorem identity37240 : scanCanonicalize (H12AffineFastState.compose env37240 (packedSelected [2,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37240 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env37241 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,4096,8,4112,0,3,4097,2081,1025,1,4112,33,17,2,9,17,2049,5141,5140,2080,1025,1076,5,1076,5125,513]

theorem envBound37241 : H12AffineFastState.Bounded env37241 := by
  intro p hp
  have h : env37241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37240_37241 : H12AffineEnvironment.transform 5 17 env37240 = env37241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37240 == env37241) = true)

theorem identity37241 : scanCanonicalize (H12AffineFastState.compose env37241 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound37241 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37242 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,48,8,32,0,3,49,2081,1025,1,32,33,17,2,9,17,2049,1061,1060,2080,1025,1076,5,1076,1077,513]

theorem envBound37242 : H12AffineFastState.Bounded env37242 := by
  intro p hp
  have h : env37242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37241_37242 : H12AffineEnvironment.transform 11 48 env37241 = env37242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env37241 == env37242) = true)

theorem identity37242 : scanCanonicalize (H12AffineFastState.compose env37242 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1588) := by decide +kernel

theorem selectedBound37242 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env37243 : List Nat := [2,4,8,16,32,17,9,4,512,1024,1588,48,8,32,0,3,49,1557,1025,1,32,33,17,2,9,17,1589,1061,1060,1556,1025,1076,5,1076,1077,513]

theorem envBound37243 : H12AffineFastState.Bounded env37243 := by
  intro p hp
  have h : env37243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37242_37243 : H12AffineEnvironment.transform 10 1588 env37242 = env37243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1588 env37242 == env37243) = true)

theorem identity37243 : scanCanonicalize (H12AffineFastState.compose env37243 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound37243 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env37244 : List Nat := [2,4,8,16,32,17,9,4,512,564,0,48,8,32,0,3,49,33,565,1,32,33,17,2,9,17,1,529,528,32,565,512,5,512,513,513]

theorem envBound37244 : H12AffineFastState.Bounded env37244 := by
  intro p hp
  have h : env37244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37243_37244 : H12AffineEnvironment.transform 9 564 env37243 = env37244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env37243 == env37244) = true)

theorem identity37244 : scanCanonicalize (H12AffineFastState.compose env37244 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound37244 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env37245 : List Nat := [2,4,8,16,16,17,9,4,512,516,0,0,8,16,0,3,1,17,517,1,16,17,17,2,9,17,1,529,528,16,517,512,5,512,513,513]

theorem envBound37245 : H12AffineFastState.Bounded env37245 := by
  intro p hp
  have h : env37245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37244_37245 : H12AffineEnvironment.transform 4 16 env37244 = env37245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env37244 == env37245) = true)

theorem identity37245 : scanCanonicalize (H12AffineFastState.compose env37245 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound37245 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env37246 : List Nat := [2,4,8,16,16,17,9,4,26,30,0,0,8,16,0,3,1,17,31,1,16,17,17,2,9,17,1,11,10,16,31,26,5,26,27,27]

theorem envBound37246 : H12AffineFastState.Bounded env37246 := by
  intro p hp
  have h : env37246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37245_37246 : H12AffineEnvironment.transform 8 26 env37245 = env37246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env37245 == env37246) = true)

theorem identity37246 : scanCanonicalize (H12AffineFastState.compose env37246 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound37246 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37247 : List Nat := [2,4,8,0,0,1,9,4,10,14,0,0,8,0,0,3,1,1,15,1,0,1,1,2,9,1,1,11,10,0,15,10,5,10,11,11]

theorem envBound37247 : H12AffineFastState.Bounded env37247 := by
  intro p hp
  have h : env37247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37246_37247 : H12AffineEnvironment.transform 3 0 env37246 = env37247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env37246 == env37247) = true)

def env37248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6664478,2098513,17665,2437315,2102684,6349852,257,21792,46212,2175563]

theorem envBound37248 : H12AffineFastState.Bounded env37248 := by
  intro p hp
  have h : env37248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37214_37248 : H12AffineEnvironment.transform 22 2101329 env37214 = env37248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env37214 == env37248) = true)

def env37249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2202014,2098513,17665,2437315,2102684,2411676,257,21792,46212,2175563]

theorem envBound37249 : H12AffineFastState.Bounded env37249 := by
  intro p hp
  have h : env37249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37248_37249 : H12AffineEnvironment.transform 21 272512 env37248 = env37249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env37248 == env37249) = true)

theorem identity37249 : scanCanonicalize (H12AffineFastState.compose env37249 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58516) := by decide +kernel

theorem selectedBound37249 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,58516,272512,62661,98780,8328,64,97546,57797,17665,382039,61704,272392,257,21792,46212,120543]

theorem envBound37250 : H12AffineFastState.Bounded env37250 := by
  intro p hp
  have h : env37250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37249_37250 : H12AffineEnvironment.transform 20 58516 env37249 = env37250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58516 env37249 == env37250) = true)

def env37251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,10280,1025,32769,58516,168,62661,98780,8328,64,97546,57797,17665,130175,61704,32,257,21792,46212,120543]

theorem envBound37251 : H12AffineFastState.Bounded env37251 := by
  intro p hp
  have h : env37251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37250_37251 : H12AffineEnvironment.transform 17 10280 env37250 = env37251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env37250 == env37251) = true)

theorem identity37251 : scanCanonicalize (H12AffineFastState.compose env37251 (packedSelected [1,5,8,11,12,15,17,18,19,23,24,26,32,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 62850) := by decide +kernel

theorem selectedBound37251 : packedSelected [1,5,8,11,12,15,17,18,19,23,24,26,32,38,41] rootPS < 2^1333 := by decide +kernel

def env37252 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62850,5393,10280,1025,32769,58516,168,62661,29790,8328,64,34952,57797,17665,2557,61704,32,257,21792,46212,9053]

theorem envBound37252 : H12AffineFastState.Bounded env37252 := by
  intro p hp
  have h : env37252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37251_37252 : H12AffineEnvironment.transform 15 62850 env37251 = env37252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62850 env37251 == env37252) = true)

theorem identity37252 : scanCanonicalize (H12AffineFastState.compose env37252 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound37252 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env37253 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,137,29963,5393,10280,1025,136,25629,168,29772,29790,8328,64,2049,24908,17665,2557,29057,32,257,21792,13325,9053]

theorem envBound37253 : H12AffineFastState.Bounded env37253 := by
  intro p hp
  have h : env37253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37252_37253 : H12AffineEnvironment.transform 14 137 env37252 = env37253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env37252 == env37253) = true)

theorem identity37253 : scanCanonicalize (H12AffineFastState.compose env37253 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound37253 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37254 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,16384,137,28698,4096,10280,272,136,24844,168,29021,29007,8328,64,2049,24908,16400,2557,29057,32,257,20529,12572,9053]

theorem envBound37254 : H12AffineFastState.Bounded env37254 := by
  intro p hp
  have h : env37254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37253_37254 : H12AffineEnvironment.transform 9 273 env37253 = env37254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env37253 == env37254) = true)

theorem identity37254 : scanCanonicalize (H12AffineFastState.compose env37254 (packedSelected [16,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound37254 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env37255 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,349,16384,137,20807,4096,2421,272,136,16465,168,20480,20498,469,64,2049,16401,16400,2557,20700,32,257,20529,4161,512]

theorem envBound37255 : H12AffineFastState.Bounded env37255 := by
  intro p hp
  have h : env37255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37254_37255 : H12AffineEnvironment.transform 12 349 env37254 = env37255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env37254 == env37255) = true)

theorem identity37255 : scanCanonicalize (H12AffineFastState.compose env37255 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4589) := by decide +kernel

theorem selectedBound37255 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env37256 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,349,4589,137,170,4096,2421,272,136,4540,168,493,511,469,64,2049,4604,4605,2557,305,32,257,476,4161,512]

theorem envBound37256 : H12AffineFastState.Bounded env37256 := by
  intro p hp
  have h : env37256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37255_37256 : H12AffineEnvironment.transform 13 4589 env37255 = env37256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4589 env37255 == env37256) = true)

theorem identity37256 : scanCanonicalize (H12AffineFastState.compose env37256 (packedSelected [1,3,6,9,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 119) := by decide +kernel

theorem selectedBound37256 : packedSelected [1,3,6,9,11,12] rootPS < 2^1333 := by decide +kernel

def env37257 : List Nat := [2,4,8,16,32,64,119,256,512,273,2048,4096,349,4378,126,93,4096,2421,272,127,4427,95,282,264,290,64,2049,4363,4362,2314,305,32,257,299,4161,512]

theorem envBound37257 : H12AffineFastState.Bounded env37257 := by
  intro p hp
  have h : env37257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37256_37257 : H12AffineEnvironment.transform 6 119 env37256 = env37257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 119 env37256 == env37257) = true)

theorem identity37257 : scanCanonicalize (H12AffineFastState.compose env37257 (packedSelected [0,2,4,5,6,7,8,9,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 2170) := by decide +kernel

theorem selectedBound37257 : packedSelected [0,2,4,5,6,7,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env37258 : List Nat := [2,4,8,16,32,64,119,256,512,273,2048,2170,349,2400,126,93,2170,2421,272,127,2353,95,282,264,290,64,2049,2417,2416,2314,305,32,257,299,2107,512]

theorem envBound37258 : H12AffineFastState.Bounded env37258 := by
  intro p hp
  have h : env37258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37257_37258 : H12AffineEnvironment.transform 11 2170 env37257 = env37258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2170 env37257 == env37258) = true)

theorem identity37258 : scanCanonicalize (H12AffineFastState.compose env37258 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(7+1) ^^^ 10) := by decide +kernel

theorem selectedBound37258 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env37259 : List Nat := [2,4,8,16,32,64,119,10,512,27,2048,2170,87,2154,126,93,2170,2175,26,127,2107,95,16,2,40,64,2049,2171,2170,2048,59,32,11,33,2107,512]

theorem envBound37259 : H12AffineFastState.Bounded env37259 := by
  intro p hp
  have h : env37259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37258_37259 : H12AffineEnvironment.transform 7 10 env37258 = env37259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 10 env37258 == env37259) = true)

theorem identity37259 : scanCanonicalize (H12AffineFastState.compose env37259 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 85) := by decide +kernel

theorem selectedBound37259 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37260 : List Nat := [2,4,8,16,32,64,119,10,512,27,85,47,87,63,126,93,47,42,26,127,110,95,16,2,40,64,84,46,47,85,59,32,11,33,110,512]

theorem envBound37260 : H12AffineFastState.Bounded env37260 := by
  intro p hp
  have h : env37260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37259_37260 : H12AffineEnvironment.transform 10 85 env37259 = env37260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 85 env37259 == env37260) = true)

theorem identity37260 : scanCanonicalize (H12AffineFastState.compose env37260 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37260 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37261 : List Nat := [2,4,8,16,1,64,86,10,512,27,85,14,87,30,95,93,14,11,26,94,79,95,16,2,9,64,84,15,14,85,26,1,11,0,79,512]

theorem envBound37261 : H12AffineFastState.Bounded env37261 := by
  intro p hp
  have h : env37261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37260_37261 : H12AffineEnvironment.transform 4 1 env37260 = env37261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37260 == env37261) = true)

theorem identity37261 : scanCanonicalize (H12AffineFastState.compose env37261 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 67) := by decide +kernel

theorem selectedBound37261 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env37262 : List Nat := [2,4,8,16,1,64,86,10,67,27,85,14,87,30,95,93,14,11,26,94,79,95,16,2,9,64,84,15,14,85,26,1,11,0,79,67]

theorem envBound37262 : H12AffineFastState.Bounded env37262 := by
  intro p hp
  have h : env37262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37261_37262 : H12AffineEnvironment.transform 8 67 env37261 = env37262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 67 env37261 == env37262) = true)

def env37263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,10281,1025,32769,58516,169,62661,98780,8328,64,97546,57797,17665,130174,61704,33,257,21792,46212,120543]

theorem envBound37263 : H12AffineFastState.Bounded env37263 := by
  intro p hp
  have h : env37263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37250_37263 : H12AffineEnvironment.transform 17 10281 env37250 = env37263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env37250 == env37263) = true)

theorem identity37263 : scanCanonicalize (H12AffineFastState.compose env37263 (packedSelected [1,5,8,11,12,15,17,18,19,23,24,26,32,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound37263 : packedSelected [1,5,8,11,12,15,17,18,19,23,24,26,32,38,41] rootPS < 2^1333 := by decide +kernel

def env37264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54359,13508,10281,1025,32769,58516,169,62661,21899,8328,64,43357,57797,17665,10281,61704,33,257,21792,46212,648]

theorem envBound37264 : H12AffineFastState.Bounded env37264 := by
  intro p hp
  have h : env37264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37263_37264 : H12AffineEnvironment.transform 15 54359 env37263 = env37264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env37263 == env37264) = true)

theorem identity37264 : scanCanonicalize (H12AffineFastState.compose env37264 (packedSelected [10,11,12,19,23] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound37264 : packedSelected [10,11,12,19,23] rootPS < 2^1333 := by decide +kernel

def env37265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,40971,13508,10281,1025,32769,37064,169,32921,8663,8328,64,43357,38297,12637,10281,34132,33,257,8572,46212,648]

theorem envBound37265 : H12AffineFastState.Bounded env37265 := by
  intro p hp
  have h : env37265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37264_37265 : H12AffineEnvironment.transform 13 13404 env37264 = env37265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env37264 == env37265) = true)

theorem identity37265 : scanCanonicalize (H12AffineFastState.compose env37265 (packedSelected [0,1,2,6,7,8,10,12,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound37265 : packedSelected [0,1,2,6,7,8,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env37266 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5376,32768,33111,5528,2421,1025,32769,37064,169,32921,139,468,64,34817,38297,4097,2421,34132,33,257,32,38360,648]

theorem envBound37266 : H12AffineFastState.Bounded env37266 := by
  intro p hp
  have h : env37266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37265_37266 : H12AffineEnvironment.transform 12 348 env37265 = env37266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env37265 == env37266) = true)

theorem identity37266 : scanCanonicalize (H12AffineFastState.compose env37266 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37266 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37267 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,32768,33111,5392,2421,1025,32769,36928,33,32785,3,348,64,34817,38161,4097,2421,34132,33,257,32,38224,512]

theorem envBound37267 : H12AffineFastState.Bounded env37267 := by
  intro p hp
  have h : env37267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37266_37267 : H12AffineEnvironment.transform 6 8 env37266 = env37267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37266 == env37267) = true)

theorem identity37267 : scanCanonicalize (H12AffineFastState.compose env37267 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 32) := by decide +kernel

theorem selectedBound37267 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37268 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,32,375,5392,2421,1025,33,4192,33,49,3,348,64,2081,5425,4097,2421,1396,33,257,32,5488,512]

theorem envBound37268 : H12AffineFastState.Bounded env37268 := by
  intro p hp
  have h : env37268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37267_37268 : H12AffineEnvironment.transform 14 32 env37267 = env37268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 32 env37267 == env37268) = true)

theorem identity37268 : scanCanonicalize (H12AffineFastState.compose env37268 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37268 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env37269 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,348,5376,1,342,5392,2388,1025,0,4161,0,16,3,348,64,2048,5392,4097,2388,1365,0,257,1,5457,512]

theorem envBound37269 : H12AffineFastState.Bounded env37269 := by
  intro p hp
  have h : env37269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37268_37269 : H12AffineEnvironment.transform 4 1 env37268 = env37269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37268 == env37269) = true)

theorem identity37269 : scanCanonicalize (H12AffineFastState.compose env37269 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1355) := by decide +kernel

theorem selectedBound37269 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37270 : List Nat := [2,4,8,16,1,64,8,256,512,1024,1355,4096,348,5376,1,342,5392,1055,1025,0,4161,0,16,3,348,64,1355,5392,4097,1055,1365,0,257,1,5457,512]

theorem envBound37270 : H12AffineFastState.Bounded env37270 := by
  intro p hp
  have h : env37270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37269_37270 : H12AffineEnvironment.transform 10 1355 env37269 = env37270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1355 env37269 == env37270) = true)

theorem identity37270 : scanCanonicalize (H12AffineFastState.compose env37270 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound37270 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env37271 : List Nat := [2,4,8,16,1,64,8,256,512,1024,1355,261,348,1029,1,342,1045,1055,1025,0,324,0,16,3,348,64,1355,1045,260,1055,1365,0,257,1,1108,512]

theorem envBound37271 : H12AffineFastState.Bounded env37271 := by
  intro p hp
  have h : env37271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37270_37271 : H12AffineEnvironment.transform 11 261 env37270 = env37271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env37270 == env37271) = true)

theorem identity37271 : scanCanonicalize (H12AffineFastState.compose env37271 (packedSelected [2,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37271 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env37272 : List Nat := [2,4,8,16,1,17,8,256,512,1024,1306,261,269,1029,1,263,1045,1055,1025,0,277,0,16,3,269,17,1306,1045,260,1055,1284,0,257,1,1029,512]

theorem envBound37272 : H12AffineFastState.Bounded env37272 := by
  intro p hp
  have h : env37272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37271_37272 : H12AffineEnvironment.transform 5 17 env37271 = env37272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37271 == env37272) = true)

theorem identity37272 : scanCanonicalize (H12AffineFastState.compose env37272 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound37272 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37273 : List Nat := [2,4,8,16,1,17,8,4,512,1024,1054,1,9,1029,1,3,1045,1055,1025,0,17,0,16,3,9,17,1054,1045,0,1055,1024,0,5,1,1029,512]

theorem envBound37273 : H12AffineFastState.Bounded env37273 := by
  intro p hp
  have h : env37273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37272_37273 : H12AffineEnvironment.transform 7 4 env37272 = env37273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env37272 == env37273) = true)

theorem identity37273 : scanCanonicalize (H12AffineFastState.compose env37273 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound37273 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37274 : List Nat := [2,4,8,16,1,17,8,4,26,1024,1054,1,9,1029,1,3,1045,1055,1025,0,17,0,16,3,9,17,1054,1045,0,1055,1024,0,5,1,1029,26]

theorem envBound37274 : H12AffineFastState.Bounded env37274 := by
  intro p hp
  have h : env37274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37273_37274 : H12AffineEnvironment.transform 8 26 env37273 = env37274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env37273 == env37274) = true)

theorem identity37274 : scanCanonicalize (H12AffineFastState.compose env37274 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound37274 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env37275 : List Nat := [2,4,8,3,1,2,8,4,9,1024,1037,1,9,1029,1,3,1030,1036,1025,0,2,0,3,3,9,2,1037,1030,0,1036,1024,0,5,1,1029,9]

theorem envBound37275 : H12AffineFastState.Bounded env37275 := by
  intro p hp
  have h : env37275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37274_37275 : H12AffineEnvironment.transform 3 3 env37274 = env37275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env37274 == env37275) = true)

theorem identity37275 : scanCanonicalize (H12AffineFastState.compose env37275 (packedSelected [0,5] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound37275 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env37276 : List Nat := [2,4,8,3,1,2,8,4,9,14,3,1,9,11,1,3,8,2,15,0,2,0,3,3,9,2,3,8,0,2,14,0,5,1,11,9]

theorem envBound37276 : H12AffineFastState.Bounded env37276 := by
  intro p hp
  have h : env37276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37275_37276 : H12AffineEnvironment.transform 9 14 env37275 = env37276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env37275 == env37276) = true)

def env37277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2202015,2098513,17665,2437315,2102684,2411677,257,21792,46212,2175563]

theorem envBound37277 : H12AffineFastState.Bounded env37277 := by
  intro p hp
  have h : env37277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37248_37277 : H12AffineEnvironment.transform 21 272513 env37248 = env37277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env37248 == env37277) = true)

theorem identity37277 : scanCanonicalize (H12AffineFastState.compose env37277 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound37277 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37278 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,70727,262144,1025,29909,2097152,272513,2101329,95496,8328,64,2190667,2098513,17665,2437315,2102684,2373705,257,21792,16464,2175563]

theorem envBound37278 : H12AffineFastState.Bounded env37278 := by
  intro p hp
  have h : env37278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37277_37278 : H12AffineEnvironment.transform 14 29908 env37277 = env37278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env37277 == env37278) = true)

def env37279 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,70679,262144,1025,29829,2097152,272513,2101249,95496,8328,16,2190619,2098433,17665,2437267,2102684,2373657,257,21792,16384,2175515]

theorem envBound37279 : H12AffineFastState.Bounded env37279 := by
  intro p hp
  have h : env37279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37278_37279 : H12AffineEnvironment.transform 5 16 env37278 = env37279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37278 == env37279) = true)

theorem identity37279 : scanCanonicalize (H12AffineFastState.compose env37279 (packedSelected [3,14,15,16,19,20,24,31,35,38] rootPS)) = affineNative (2^(17+1) ^^^ 76079) := by decide +kernel

theorem selectedBound37279 : packedSelected [3,14,15,16,19,20,24,31,35,38] rootPS < 2^1333 := by decide +kernel

def env37280 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,70679,76079,1025,29829,2097152,65966,2101249,95496,8328,16,2190619,2098433,17665,2103740,2102684,2167094,257,21792,16384,2175515]

theorem envBound37280 : H12AffineFastState.Bounded env37280 := by
  intro p hp
  have h : env37280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0