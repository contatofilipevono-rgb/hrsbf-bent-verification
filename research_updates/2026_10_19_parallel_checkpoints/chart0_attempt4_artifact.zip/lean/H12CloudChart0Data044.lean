import H12CloudChart0Data043

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env10994 : List Nat := [2,4,8,16,1,16,9,256,512,273,261,16,269,260,0,263,277,0,272,1,260,1,17,3,268,17,261,277,17,0,20,1,257,0,261,512]

theorem envBound10994 : H12AffineFastState.Bounded env10994 := by
  intro p hp
  have h : env10994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10993_10994 : H12AffineEnvironment.transform 10 261 env10993 = env10994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env10993 == env10994) = true)

theorem identity10994 : scanCanonicalize (H12AffineFastState.compose env10994 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound10994 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10995 : List Nat := [2,4,8,0,1,0,9,256,512,257,261,0,269,260,0,263,261,0,256,1,260,1,1,3,268,1,261,261,1,0,4,1,257,0,261,512]

theorem envBound10995 : H12AffineFastState.Bounded env10995 := by
  intro p hp
  have h : env10995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10994_10995 : H12AffineEnvironment.transform 3 0 env10994 = env10995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env10994 == env10995) = true)

theorem identity10995 : scanCanonicalize (H12AffineFastState.compose env10995 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound10995 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10996 : List Nat := [2,4,2,0,1,0,3,256,512,257,261,0,263,260,0,263,261,0,256,1,260,1,1,3,262,1,261,261,1,0,4,1,257,0,261,512]

theorem envBound10996 : H12AffineFastState.Bounded env10996 := by
  intro p hp
  have h : env10996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10995_10996 : H12AffineEnvironment.transform 2 2 env10995 = env10996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env10995 == env10996) = true)

theorem identity10996 : scanCanonicalize (H12AffineFastState.compose env10996 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound10996 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10997 : List Nat := [2,4,2,0,1,0,3,3,512,2,6,0,4,7,0,4,6,0,3,1,7,1,1,3,5,1,6,6,1,0,4,1,2,0,6,512]

theorem envBound10997 : H12AffineFastState.Bounded env10997 := by
  intro p hp
  have h : env10997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10996_10997 : H12AffineEnvironment.transform 7 3 env10996 = env10997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env10996 == env10997) = true)

theorem identity10997 : scanCanonicalize (H12AffineFastState.compose env10997 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound10997 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env10998 : List Nat := [2,2,2,0,1,0,3,3,512,2,0,0,2,1,0,2,0,0,3,1,1,1,1,3,3,1,0,0,1,0,2,1,2,0,0,512]

theorem envBound10998 : H12AffineFastState.Bounded env10998 := by
  intro p hp
  have h : env10998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10997_10998 : H12AffineEnvironment.transform 1 2 env10997 = env10998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env10997 == env10998) = true)

theorem identity10998 : scanCanonicalize (H12AffineFastState.compose env10998 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound10998 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10999 : List Nat := [2,2,2,0,1,0,3,3,2,2,0,0,2,1,0,2,0,0,3,1,1,1,1,3,3,1,0,0,1,0,2,1,2,0,0,2]

theorem envBound10999 : H12AffineFastState.Bounded env10999 := by
  intro p hp
  have h : env10999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10998_10999 : H12AffineEnvironment.transform 8 2 env10998 = env10999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env10998 == env10999) = true)

def env11000 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,262144,304,32769,2097152,4194304,8388608,8685878,8193,17,4262183,10815491,10506288,8683537,329751,15067423,257,2443298,2468111,272937]

theorem envBound11000 : H12AffineFastState.Bounded env11000 := by
  intro p hp
  have h : env11000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10975_11000 : H12AffineEnvironment.transform 9 305 env10975 = env11000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env10975 == env11000) = true)

theorem identity11000 : scanCanonicalize (H12AffineFastState.compose env11000 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4194352) := by decide +kernel

theorem selectedBound11000 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env11001 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,262144,304,32769,2097152,4194304,4194352,4491526,8193,17,4262183,6621235,6311936,4489249,329751,2484527,257,2443298,2468111,272937]

theorem envBound11001 : H12AffineFastState.Bounded env11001 := by
  intro p hp
  have h : env11001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11000_11001 : H12AffineEnvironment.transform 22 4194352 env11000 = env11001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4194352 env11000 == env11001) = true)

theorem identity11001 : scanCanonicalize (H12AffineFastState.compose env11001 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound11001 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env11002 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,10280,304,32769,2097152,4194304,4194352,4235566,8193,17,4262183,6365211,6311936,4237321,73791,2212103,257,2187274,2195751,513]

theorem envBound11002 : H12AffineFastState.Bounded env11002 := by
  intro p hp
  have h : env11002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11001_11002 : H12AffineEnvironment.transform 17 10280 env11001 = env11002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env11001 == env11002) = true)

theorem identity11002 : scanCanonicalize (H12AffineFastState.compose env11002 (packedSelected [1,2,4,6,8,9,10,14,15,16,17] rootPS)) = affineNative (2^(21+1) ^^^ 106538) := by decide +kernel

theorem selectedBound11002 : packedSelected [1,2,4,6,8,9,10,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env11003 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,10280,304,32769,2097152,106538,106522,65796,8193,17,43277,2129969,2224170,67619,73791,2212103,257,2187274,2195751,513]

theorem envBound11003 : H12AffineFastState.Bounded env11003 := by
  intro p hp
  have h : env11003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11002_11003 : H12AffineEnvironment.transform 21 106538 env11002 = env11003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 106538 env11002 == env11003) = true)

theorem identity11003 : scanCanonicalize (H12AffineFastState.compose env11003 (packedSelected [0,1,3,5,7,8,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound11003 : packedSelected [0,1,3,5,7,8,15,16] rootPS < 2^1333 := by decide +kernel

def env11004 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,269,16384,32768,65536,16401,2341,304,32769,2097152,98599,98583,65796,268,17,34816,2129969,2216231,67619,65842,2212103,257,2179335,2195751,513]

theorem envBound11004 : H12AffineFastState.Bounded env11004 := by
  intro p hp
  have h : env11004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11003_11004 : H12AffineEnvironment.transform 12 269 env11003 = env11004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env11003 == env11004) = true)

theorem identity11004 : scanCanonicalize (H12AffineFastState.compose env11004 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound11004 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11005 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,269,16384,32768,262,16401,2341,304,32769,2097152,32801,32785,2,268,17,34816,2129969,2150433,2341,52,2146305,257,2113537,2129953,513]

theorem envBound11005 : H12AffineFastState.Bounded env11005 := by
  intro p hp
  have h : env11005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11004_11005 : H12AffineEnvironment.transform 15 262 env11004 = env11005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env11004 == env11005) = true)

theorem identity11005 : scanCanonicalize (H12AffineFastState.compose env11005 (packedSelected [4,9,11] rootPS)) = affineNative (2^(20+1) ^^^ 16416) := by decide +kernel

theorem selectedBound11005 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env11006 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,269,16384,32768,262,16401,2341,304,32769,16416,32801,32785,2,268,17,34816,49169,36865,2341,52,32801,257,33,49153,513]

theorem envBound11006 : H12AffineFastState.Bounded env11006 := by
  intro p hp
  have h : env11006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11005_11006 : H12AffineEnvironment.transform 20 16416 env11005 = env11006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 16416 env11005 == env11006) = true)

theorem identity11006 : scanCanonicalize (H12AffineFastState.compose env11006 (packedSelected [1,2,3,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 2059) := by decide +kernel

theorem selectedBound11006 : packedSelected [1,2,3,7,9] rootPS < 2^1333 := by decide +kernel

def env11007 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,269,16384,2059,262,16401,2341,304,2058,16416,2090,2074,2,268,17,11,18458,6154,2341,52,2090,257,33,18442,513]

theorem envBound11007 : H12AffineFastState.Bounded env11007 := by
  intro p hp
  have h : env11007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11006_11007 : H12AffineEnvironment.transform 14 2059 env11006 = env11007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2059 env11006 == env11007) = true)

def env11008 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,8685879,8193,16,4262182,10816819,10507520,8683537,331047,15068206,257,2444562,2468927,272937]

theorem envBound11008 : H12AffineFastState.Bounded env11008 := by
  intro p hp
  have h : env11008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10974_11008 : H12AffineEnvironment.transform 5 17 env10974 = env11008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10974 == env11008) = true)

def env11009 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,262144,305,32769,2097152,4194304,8388608,8685879,8193,16,4262182,10815491,10506288,8683537,329751,15067422,257,2443298,2468111,272937]

theorem envBound11009 : H12AffineFastState.Bounded env11009 := by
  intro p hp
  have h : env11009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11008_11009 : H12AffineEnvironment.transform 9 304 env11008 = env11009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env11008 == env11009) = true)

theorem identity11009 : scanCanonicalize (H12AffineFastState.compose env11009 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4524051) := by decide +kernel

theorem selectedBound11009 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env11010 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,262144,305,32769,2097152,4194304,4524051,4292900,8193,16,4262182,6291472,6641699,4294658,329751,2154765,257,2443298,2468111,272937]

theorem envBound11010 : H12AffineFastState.Bounded env11010 := by
  intro p hp
  have h : env11010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11009_11010 : H12AffineEnvironment.transform 22 4524051 env11009 = env11010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4524051 env11009 == env11010) = true)

def env11011 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,10280,305,32769,2097152,4194304,4268091,4292900,8193,16,4262182,6291472,6385675,4294658,73791,2154765,257,2187274,2195751,513]

theorem envBound11011 : H12AffineFastState.Bounded env11011 := by
  intro p hp
  have h : env11011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11010_11011 : H12AffineEnvironment.transform 17 10280 env11010 = env11011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env11010 == env11011) = true)

theorem identity11011 : scanCanonicalize (H12AffineFastState.compose env11011 (packedSelected [0,3,4,5,7,9,12,14,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound11011 : packedSelected [0,3,4,5,7,9,12,14,19] rootPS < 2^1333 := by decide +kernel

def env11012 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,0,65536,16401,10280,305,1,2097152,4194304,4268091,4260132,8193,16,4262182,6291472,6385675,4261890,73791,2121997,257,2187274,2162983,513]

theorem envBound11012 : H12AffineFastState.Bounded env11012 := by
  intro p hp
  have h : env11012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11011_11012 : H12AffineEnvironment.transform 14 0 env11011 = env11012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env11011 == env11012) = true)

theorem identity11012 : scanCanonicalize (H12AffineFastState.compose env11012 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound11012 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env11013 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,0,8202,16401,10280,305,1,2097152,4194304,4194353,4202798,8193,16,4204844,6291472,6311937,4204552,53,2121997,257,2113536,2105645,513]

theorem envBound11013 : H12AffineFastState.Bounded env11013 := by
  intro p hp
  have h : env11013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11012_11013 : H12AffineEnvironment.transform 15 8202 env11012 = env11013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env11012 == env11013) = true)

theorem identity11013 : scanCanonicalize (H12AffineFastState.compose env11013 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(21+1) ^^^ 2113537) := by decide +kernel

theorem selectedBound11013 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env11014 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,0,8202,16401,10280,305,1,2097152,2113537,2113584,2122031,8193,16,2124077,16401,4096,2123785,53,2121997,257,2113536,2105645,513]

theorem envBound11014 : H12AffineFastState.Bounded env11014 := by
  intro p hp
  have h : env11014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11013_11014 : H12AffineEnvironment.transform 21 2113537 env11013 = env11014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2113537 env11013 == env11014) = true)

theorem identity11014 : scanCanonicalize (H12AffineFastState.compose env11014 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 24876) := by decide +kernel

theorem selectedBound11014 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11015 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,0,8202,16401,10280,305,1,24876,8493,8476,3,8193,16,2049,16401,4096,2341,53,33,257,8492,16385,513]

theorem envBound11015 : H12AffineFastState.Bounded env11015 := by
  intro p hp
  have h : env11015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11014_11015 : H12AffineEnvironment.transform 20 24876 env11014 = env11015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 24876 env11014 == env11015) = true)

theorem identity11015 : scanCanonicalize (H12AffineFastState.compose env11015 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound11015 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11016 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,269,16384,0,263,16401,2341,305,1,16417,32,17,3,268,16,2049,16401,4096,2341,53,33,257,33,16385,513]

theorem envBound11016 : H12AffineFastState.Bounded env11016 := by
  intro p hp
  have h : env11016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11015_11016 : H12AffineEnvironment.transform 12 269 env11015 = env11016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env11015 == env11016) = true)

theorem identity11016 : scanCanonicalize (H12AffineFastState.compose env11016 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11016 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11017 : List Nat := [2,4,8,16,1,17,9,256,512,273,2048,4096,269,16384,0,263,16401,2308,272,1,16384,1,17,3,268,16,2049,16401,4096,2308,20,0,257,0,16385,513]

theorem envBound11017 : H12AffineFastState.Bounded env11017 := by
  intro p hp
  have h : env11017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11016_11017 : H12AffineEnvironment.transform 4 1 env11016 = env11017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11016 == env11017) = true)

theorem identity11017 : scanCanonicalize (H12AffineFastState.compose env11017 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound11017 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11018 : List Nat := [2,4,8,16,1,17,9,256,512,273,2048,16,269,16384,0,263,16401,2308,272,1,16384,1,17,3,268,16,2049,16401,16,2308,20,0,257,0,16385,513]

theorem envBound11018 : H12AffineFastState.Bounded env11018 := by
  intro p hp
  have h : env11018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11017_11018 : H12AffineEnvironment.transform 11 16 env11017 = env11018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env11017 == env11018) = true)

theorem identity11018 : scanCanonicalize (H12AffineFastState.compose env11018 (packedSelected [0,4] rootPS)) = affineNative (2^(13+1) ^^^ 512) := by decide +kernel

theorem selectedBound11018 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11019 : List Nat := [2,4,8,16,1,17,9,256,512,273,2048,16,269,512,0,263,529,2308,272,1,512,1,17,3,268,16,2049,529,16,2308,20,0,257,0,513,513]

theorem envBound11019 : H12AffineFastState.Bounded env11019 := by
  intro p hp
  have h : env11019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11018_11019 : H12AffineEnvironment.transform 13 512 env11018 = env11019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 512 env11018 == env11019) = true)

theorem identity11019 : scanCanonicalize (H12AffineFastState.compose env11019 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound11019 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env11020 : List Nat := [2,4,8,16,1,17,9,256,512,273,528,16,269,512,0,263,529,788,272,1,512,1,17,3,268,16,529,529,16,788,20,0,257,0,513,513]

theorem envBound11020 : H12AffineFastState.Bounded env11020 := by
  intro p hp
  have h : env11020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11019_11020 : H12AffineEnvironment.transform 10 528 env11019 = env11020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env11019 == env11020) = true)

theorem identity11020 : scanCanonicalize (H12AffineFastState.compose env11020 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound11020 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11021 : List Nat := [2,4,8,1,1,0,9,256,512,256,513,1,269,512,0,263,512,773,257,1,512,1,0,3,268,1,512,512,1,773,5,0,257,0,513,513]

theorem envBound11021 : H12AffineFastState.Bounded env11021 := by
  intro p hp
  have h : env11021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11020_11021 : H12AffineEnvironment.transform 3 1 env11020 = env11021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env11020 == env11021) = true)

theorem identity11021 : scanCanonicalize (H12AffineFastState.compose env11021 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound11021 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env11022 : List Nat := [2,4,8,1,1,0,9,256,260,256,261,1,269,260,0,263,260,1,257,1,260,1,0,3,268,1,260,260,1,1,5,0,257,0,261,261]

theorem envBound11022 : H12AffineFastState.Bounded env11022 := by
  intro p hp
  have h : env11022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11021_11022 : H12AffineEnvironment.transform 8 260 env11021 = env11022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env11021 == env11022) = true)

def env11023 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,10281,305,32769,2097152,4194304,4268090,4292900,8193,16,4262182,6291472,6385674,4294658,73790,2154765,257,2187275,2195750,512]

theorem envBound11023 : H12AffineFastState.Bounded env11023 := by
  intro p hp
  have h : env11023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11010_11023 : H12AffineEnvironment.transform 17 10281 env11010 = env11023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env11010 == env11023) = true)

theorem identity11023 : scanCanonicalize (H12AffineFastState.compose env11023 (packedSelected [0,3,4,5,7,9,12,14,19] rootPS)) = affineNative (2^(21+1) ^^^ 2226234) := by decide +kernel

theorem selectedBound11023 : packedSelected [0,3,4,5,7,9,12,14,19] rootPS < 2^1333 := by decide +kernel

def env11024 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,10281,305,32769,2097152,2226234,2152448,2128158,8193,16,2158876,129066,34864,2125880,73790,2154765,257,2187275,2195750,512]

theorem envBound11024 : H12AffineFastState.Bounded env11024 := by
  intro p hp
  have h : env11024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11023_11024 : H12AffineEnvironment.transform 21 2226234 env11023 = env11024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2226234 env11023 == env11024) = true)

theorem identity11024 : scanCanonicalize (H12AffineFastState.compose env11024 (packedSelected [1,2,4,6,8,9,10,11,14,15,17,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 47131) := by decide +kernel

theorem selectedBound11024 : packedSelected [1,2,4,6,8,9,10,11,14,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env11025 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,47131,16401,10281,305,32769,2097152,2113569,2152448,2128158,8193,16,2158876,16433,34864,2125880,38949,2154765,257,2152464,2111805,512]

theorem envBound11025 : H12AffineFastState.Bounded env11025 := by
  intro p hp
  have h : env11025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11024_11025 : H12AffineEnvironment.transform 15 47131 env11024 = env11025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 47131 env11024 == env11025) = true)

theorem identity11025 : scanCanonicalize (H12AffineFastState.compose env11025 (packedSelected [17,21] rootPS)) = affineNative (2^(20+1) ^^^ 55312) := by decide +kernel

theorem selectedBound11025 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env11026 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,47131,16401,10281,305,32769,55312,38961,16,41230,8193,16,10508,16433,34864,43048,38949,14621,257,0,57645,512]

theorem envBound11026 : H12AffineFastState.Bounded env11026 := by
  intro p hp
  have h : env11026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11025_11026 : H12AffineEnvironment.transform 20 55312 env11025 = env11026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 55312 env11025 == env11026) = true)

theorem identity11026 : scanCanonicalize (H12AffineFastState.compose env11026 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 26665) := by decide +kernel

theorem selectedBound11026 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env11027 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,26665,20530,16401,10281,305,26664,12345,28696,16,18727,8193,16,10508,16433,24601,16385,28684,14621,257,0,2308,512]

theorem envBound11027 : H12AffineFastState.Bounded env11027 := by
  intro p hp
  have h : env11027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11026_11027 : H12AffineEnvironment.transform 14 26665 env11026 = env11027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26665 env11026 == env11027) = true)

theorem identity11027 : scanCanonicalize (H12AffineFastState.compose env11027 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 6168) := by decide +kernel

theorem selectedBound11027 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env11028 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,6168,16384,20529,20530,16401,4145,305,20528,2081,18432,16,18727,6169,16,4372,16433,22529,16385,18452,261,257,0,2308,512]

theorem envBound11028 : H12AffineFastState.Bounded env11028 := by
  intro p hp
  have h : env11028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11027_11028 : H12AffineEnvironment.transform 12 6168 env11027 = env11028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6168 env11027 == env11028) = true)

theorem identity11028 : scanCanonicalize (H12AffineFastState.compose env11028 (packedSelected [2,14] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound11028 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env11029 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,6168,4404,261,262,4389,4145,305,260,2081,6452,16,6163,6169,16,4372,4357,2357,4405,6432,261,257,0,2308,512]

theorem envBound11029 : H12AffineFastState.Bounded env11029 := by
  intro p hp
  have h : env11029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11028_11029 : H12AffineEnvironment.transform 13 4404 env11028 = env11029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env11028 == env11029) = true)

theorem identity11029 : scanCanonicalize (H12AffineFastState.compose env11029 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound11029 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env11030 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,2097,41,2309,261,262,2324,2048,305,260,2081,261,16,34,40,16,2341,2356,2357,2308,273,261,257,0,2308,512]

theorem envBound11030 : H12AffineFastState.Bounded env11030 := by
  intro p hp
  have h : env11030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11029_11030 : H12AffineEnvironment.transform 11 2097 env11029 = env11030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env11029 == env11030) = true)

theorem identity11030 : scanCanonicalize (H12AffineFastState.compose env11030 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound11030 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env11031 : List Nat := [2,4,8,16,32,17,9,256,512,304,261,308,41,0,261,262,17,261,305,260,292,261,16,34,40,16,32,49,48,1,273,261,257,0,1,512]

theorem envBound11031 : H12AffineFastState.Bounded env11031 := by
  intro p hp
  have h : env11031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11030_11031 : H12AffineEnvironment.transform 10 261 env11030 = env11031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env11030 == env11031) = true)

theorem identity11031 : scanCanonicalize (H12AffineFastState.compose env11031 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11031 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11032 : List Nat := [2,4,8,16,0,17,9,256,512,272,261,276,9,0,261,262,17,261,273,260,260,261,16,2,8,16,0,17,16,1,273,261,257,0,1,512]

theorem envBound11032 : H12AffineFastState.Bounded env11032 := by
  intro p hp
  have h : env11032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11031_11032 : H12AffineEnvironment.transform 4 0 env11031 = env11032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11031 == env11032) = true)

def env11033 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,262144,304,32769,2097152,4194304,8388608,8685879,8193,16,4262182,10815490,10506289,8683537,329750,15067423,257,2443299,2468110,272937]

theorem envBound11033 : H12AffineFastState.Bounded env11033 := by
  intro p hp
  have h : env11033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11008_11033 : H12AffineEnvironment.transform 9 305 env11008 = env11033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env11008 == env11033) = true)

theorem identity11033 : scanCanonicalize (H12AffineFastState.compose env11033 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4268091) := by decide +kernel

theorem selectedBound11033 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env11034 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,262144,304,32769,2097152,4194304,4268091,4565260,8193,16,4262182,6563897,6385674,4562986,329750,2410788,257,2443299,2468110,272937]

theorem envBound11034 : H12AffineFastState.Bounded env11034 := by
  intro p hp
  have h : env11034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11033_11034 : H12AffineEnvironment.transform 22 4268091 env11033 = env11034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4268091 env11033 == env11034) = true)

theorem identity11034 : scanCanonicalize (H12AffineFastState.compose env11034 (packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound11034 : packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env11035 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,10280,304,32769,2097152,4194304,4268091,4292900,8193,16,4262182,6291473,6385674,4294658,73790,2154764,257,2187275,2195750,513]

theorem envBound11035 : H12AffineFastState.Bounded env11035 := by
  intro p hp
  have h : env11035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11034_11035 : H12AffineEnvironment.transform 17 10280 env11034 = env11035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env11034 == env11035) = true)

theorem identity11035 : scanCanonicalize (H12AffineFastState.compose env11035 (packedSelected [0,3,4,5,7,9,12,14,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound11035 : packedSelected [0,3,4,5,7,9,12,14,19] rootPS < 2^1333 := by decide +kernel

def env11036 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,0,65536,16401,10280,304,1,2097152,4194304,4268091,4260132,8193,16,4262182,6291473,6385674,4261890,73790,2121996,257,2187275,2162982,513]

theorem envBound11036 : H12AffineFastState.Bounded env11036 := by
  intro p hp
  have h : env11036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11035_11036 : H12AffineEnvironment.transform 14 0 env11035 = env11036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env11035 == env11036) = true)

theorem identity11036 : scanCanonicalize (H12AffineFastState.compose env11036 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound11036 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env11037 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,0,8202,16401,10280,304,1,2097152,4194304,4194353,4202798,8193,16,4204844,6291473,6311936,4204552,52,2121996,257,2113537,2105644,513]

theorem envBound11037 : H12AffineFastState.Bounded env11037 := by
  intro p hp
  have h : env11037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11036_11037 : H12AffineEnvironment.transform 15 8202 env11036 = env11037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env11036 == env11037) = true)

theorem identity11037 : scanCanonicalize (H12AffineFastState.compose env11037 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(21+1) ^^^ 2113536) := by decide +kernel

theorem selectedBound11037 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env11038 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,0,8202,16401,10280,304,1,2097152,2113536,2113585,2122030,8193,16,2124076,16401,4096,2123784,52,2121996,257,2113537,2105644,513]

theorem envBound11038 : H12AffineFastState.Bounded env11038 := by
  intro p hp
  have h : env11038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11037_11038 : H12AffineEnvironment.transform 21 2113536 env11037 = env11038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2113536 env11037 == env11038) = true)

theorem identity11038 : scanCanonicalize (H12AffineFastState.compose env11038 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 24877) := by decide +kernel

theorem selectedBound11038 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11039 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,0,8202,16401,10280,304,1,24877,8493,8476,3,8193,16,2049,16401,4096,2341,52,33,257,8492,16385,513]

theorem envBound11039 : H12AffineFastState.Bounded env11039 := by
  intro p hp
  have h : env11039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11038_11039 : H12AffineEnvironment.transform 20 24877 env11038 = env11039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 24877 env11038 == env11039) = true)

theorem identity11039 : scanCanonicalize (H12AffineFastState.compose env11039 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound11039 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11040 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,269,16384,0,263,16401,2341,304,1,16416,32,17,3,268,16,2049,16401,4096,2341,52,33,257,33,16385,513]

theorem envBound11040 : H12AffineFastState.Bounded env11040 := by
  intro p hp
  have h : env11040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11039_11040 : H12AffineEnvironment.transform 12 269 env11039 = env11040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env11039 == env11040) = true)

theorem identity11040 : scanCanonicalize (H12AffineFastState.compose env11040 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11040 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11041 : List Nat := [2,4,8,16,1,17,9,256,512,272,2048,4096,269,16384,0,263,16401,2308,273,1,16385,1,17,3,268,16,2049,16401,4096,2308,21,0,257,0,16385,513]

theorem envBound11041 : H12AffineFastState.Bounded env11041 := by
  intro p hp
  have h : env11041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11040_11041 : H12AffineEnvironment.transform 4 1 env11040 = env11041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11040 == env11041) = true)

theorem identity11041 : scanCanonicalize (H12AffineFastState.compose env11041 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound11041 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11042 : List Nat := [2,4,8,16,1,17,9,256,512,272,2048,16,269,16384,0,263,16401,2308,273,1,16385,1,17,3,268,16,2049,16401,16,2308,21,0,257,0,16385,513]

theorem envBound11042 : H12AffineFastState.Bounded env11042 := by
  intro p hp
  have h : env11042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11041_11042 : H12AffineEnvironment.transform 11 16 env11041 = env11042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env11041 == env11042) = true)

theorem identity11042 : scanCanonicalize (H12AffineFastState.compose env11042 (packedSelected [0,4] rootPS)) = affineNative (2^(13+1) ^^^ 513) := by decide +kernel

theorem selectedBound11042 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11043 : List Nat := [2,4,8,16,1,17,9,256,512,272,2048,16,269,513,0,263,528,2308,273,1,512,1,17,3,268,16,2049,528,16,2308,21,0,257,0,512,513]

theorem envBound11043 : H12AffineFastState.Bounded env11043 := by
  intro p hp
  have h : env11043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11042_11043 : H12AffineEnvironment.transform 13 513 env11042 = env11043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 513 env11042 == env11043) = true)

theorem identity11043 : scanCanonicalize (H12AffineFastState.compose env11043 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound11043 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env11044 : List Nat := [2,4,8,16,1,17,9,256,512,272,528,16,269,513,0,263,528,788,273,1,512,1,17,3,268,16,529,528,16,788,21,0,257,0,512,513]

theorem envBound11044 : H12AffineFastState.Bounded env11044 := by
  intro p hp
  have h : env11044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11043_11044 : H12AffineEnvironment.transform 10 528 env11043 = env11044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env11043 == env11044) = true)

theorem identity11044 : scanCanonicalize (H12AffineFastState.compose env11044 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound11044 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11045 : List Nat := [2,4,8,0,1,1,9,256,512,256,512,0,269,513,0,263,512,772,257,1,512,1,1,3,268,0,513,512,0,772,5,0,257,0,512,513]

theorem envBound11045 : H12AffineFastState.Bounded env11045 := by
  intro p hp
  have h : env11045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11044_11045 : H12AffineEnvironment.transform 3 0 env11044 = env11045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env11044 == env11045) = true)

theorem identity11045 : scanCanonicalize (H12AffineFastState.compose env11045 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound11045 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env11046 : List Nat := [2,4,8,0,1,1,9,256,260,256,260,0,269,261,0,263,260,0,257,1,260,1,1,3,268,0,261,260,0,0,5,0,257,0,260,261]

theorem envBound11046 : H12AffineFastState.Bounded env11046 := by
  intro p hp
  have h : env11046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11045_11046 : H12AffineEnvironment.transform 8 260 env11045 = env11046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env11045 == env11046) = true)

theorem identity11046 : scanCanonicalize (H12AffineFastState.compose env11046 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound11046 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11047 : List Nat := [2,4,8,0,1,1,9,4,0,4,0,0,9,1,0,3,0,0,5,1,0,1,1,3,8,0,1,0,0,0,5,0,5,0,0,1]

theorem envBound11047 : H12AffineFastState.Bounded env11047 := by
  intro p hp
  have h : env11047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11046_11047 : H12AffineEnvironment.transform 7 4 env11046 = env11047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env11046 == env11047) = true)

def env11048 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616400,155254785,92374097,145662400,525568,140903596,27337992,25733063]

theorem envBound11048 : H12AffineFastState.Bounded env11048 := by
  intro p hp
  have h : env11048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9858_11048 : H12AffineEnvironment.transform 29 155254785 env9858 = env11048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env9858 == env11048) = true)

def env11049 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507600,155254785,25265169,145662400,525568,140903596,27337992,25733063]

theorem envBound11049 : H12AffineFastState.Bounded env11049 := by
  intro p hp
  have h : env11049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11048_11049 : H12AffineEnvironment.transform 25 64 env11048 = env11049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env11048 == env11049) = true)

def env11050 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507600,9356289,25265169,23160256,525568,27902124,27337992,25733063]

theorem envBound11050 : H12AffineFastState.Bounded env11050 := by
  intro p hp
  have h : env11050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11049_11050 : H12AffineEnvironment.transform 26 30393344 env11049 = env11050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env11049 == env11050) = true)

def env11051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830977,25265169,23160256,256,27378860,27337992,25207751]

theorem envBound11051 : H12AffineFastState.Bounded env11051 := by
  intro p hp
  have h : env11051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11050_11051 : H12AffineEnvironment.transform 18 1024 env11050 = env11051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env11050 == env11051) = true)

theorem identity11051 : scanCanonicalize (H12AffineFastState.compose env11051 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound11051 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env11052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115870,4194304,8388608,16777216,8328,64,29868032,16793618,8491470,8830977,25265169,21012830,256,25165874,25223574,25207751]

theorem envBound11052 : H12AffineFastState.Bounded env11052 := by
  intro p hp
  have h : env11052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11051_11052 : H12AffineEnvironment.transform 20 115870 env11051 = env11052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env11051 == env11052) = true)

def env11053 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115870,4194304,8388608,95496,8328,64,13022472,79130,8491470,8830977,8450329,4314198,256,8484154,8492190,8509135]

theorem envBound11053 : H12AffineFastState.Bounded env11053 := by
  intro p hp
  have h : env11053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11052_11053 : H12AffineEnvironment.transform 23 95496 env11052 = env11053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env11052 == env11053) = true)

def env11054 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115870,272512,8388608,95496,8328,64,8560008,79130,8491470,8830977,8450329,392406,256,8484154,8492190,8509135]

theorem envBound11054 : H12AffineFastState.Bounded env11054 := by
  intro p hp
  have h : env11054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11053_11054 : H12AffineEnvironment.transform 21 272512 env11053 = env11054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env11053 == env11054) = true)

theorem identity11054 : scanCanonicalize (H12AffineFastState.compose env11054 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 120014) := by decide +kernel

theorem selectedBound11054 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11055 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115870,272512,120014,95496,8328,64,215366,79130,17664,464079,75223,392406,256,41460,16464,513]

theorem envBound11055 : H12AffineFastState.Bounded env11055 := by
  intro p hp
  have h : env11055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11054_11055 : H12AffineEnvironment.transform 22 120014 env11054 = env11055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 120014 env11054 == env11055) = true)

def env11056 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,272392,119878,95496,8192,64,215366,79130,17664,463943,75103,392286,256,41340,16464,513]

theorem envBound11056 : H12AffineFastState.Bounded env11056 := by
  intro p hp
  have h : env11056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11055_11056 : H12AffineEnvironment.transform 6 8 env11055 = env11056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11055 == env11056) = true)

theorem identity11056 : scanCanonicalize (H12AffineFastState.compose env11056 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound11056 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env11057 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1024,32769,115734,272392,119878,95496,8192,64,10588,79130,17664,291933,75103,392286,256,41340,16464,513]

theorem envBound11057 : H12AffineFastState.Bounded env11057 := by
  intro p hp
  have h : env11057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11056_11057 : H12AffineEnvironment.transform 16 90138 env11056 = env11057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env11056 == env11057) = true)

def env11058 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10280,1024,32769,115734,32,119878,95496,8192,64,10588,79130,17664,23669,75103,119926,256,41340,16464,513]

theorem envBound11058 : H12AffineFastState.Bounded env11058 := by
  intro p hp
  have h : env11058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11057_11058 : H12AffineEnvironment.transform 17 10280 env11057 = env11058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env11057 == env11058) = true)

theorem identity11058 : scanCanonicalize (H12AffineFastState.compose env11058 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound11058 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11059 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90138,10280,1024,8541,91466,32,95514,95496,8192,64,10588,79130,17664,23669,75103,95530,256,32,16464,513]

theorem envBound11059 : H12AffineFastState.Bounded env11059 := by
  intro p hp
  have h : env11059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11058_11059 : H12AffineEnvironment.transform 14 8540 env11058 = env11059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env11058 == env11059) = true)

theorem identity11059 : scanCanonicalize (H12AffineFastState.compose env11059 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 1378) := by decide +kernel

theorem selectedBound11059 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env11060 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,1378,25976,10280,1024,8541,24616,32,28792,28778,8192,64,10588,12408,17664,23669,8253,28744,256,32,16464,513]

theorem envBound11060 : H12AffineFastState.Bounded env11060 := by
  intro p hp
  have h : env11060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11059_11060 : H12AffineEnvironment.transform 15 1378 env11059 = env11060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1378 env11059 == env11060) = true)

theorem identity11060 : scanCanonicalize (H12AffineFastState.compose env11060 (packedSelected [0,1,4,7,8,9,10,11,12,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 7180) := by decide +kernel

theorem selectedBound11060 : packedSelected [0,1,4,7,8,9,10,11,12,14,18] rootPS < 2^1333 := by decide +kernel

def env11061 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7180,16384,7504,1378,22900,5156,1024,7505,23588,32,19572,19558,7180,64,5456,3188,17664,23669,7217,19524,256,32,16464,513]

theorem envBound11061 : H12AffineFastState.Bounded env11061 := by
  intro p hp
  have h : env11061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11060_11061 : H12AffineEnvironment.transform 12 7180 env11060 = env11061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7180 env11060 == env11061) = true)

theorem identity11061 : scanCanonicalize (H12AffineFastState.compose env11061 (packedSelected [0,1,7,8,10,12,14,23] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound11061 : packedSelected [0,1,7,8,10,12,14,23] rootPS < 2^1333 := by decide +kernel

def env11062 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,6201,16384,6501,343,22900,4113,53,6500,22545,32,18497,18515,6201,64,4453,2113,16693,22592,6148,18545,256,32,16464,513]

theorem envBound11062 : H12AffineFastState.Bounded env11062 := by
  intro p hp
  have h : env11062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11061_11062 : H12AffineEnvironment.transform 9 53 env11061 = env11062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env11061 == env11062) = true)

theorem identity11062 : scanCanonicalize (H12AffineFastState.compose env11062 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11062 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env11063 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,4096,6201,16384,6452,262,22821,4113,53,6453,22545,32,18448,18434,6201,17,4404,2064,16693,22545,6148,18464,256,32,16385,513]

theorem envBound11063 : H12AffineFastState.Bounded env11063 := by
  intro p hp
  have h : env11063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11062_11063 : H12AffineEnvironment.transform 5 17 env11062 = env11063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11062 == env11063) = true)

theorem identity11063 : scanCanonicalize (H12AffineFastState.compose env11063 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound11063 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11064 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,4096,6201,2048,6452,262,4389,4113,53,6453,4113,32,16,2,6201,17,4404,2064,2357,4113,6148,32,256,32,2049,513]

theorem envBound11064 : H12AffineFastState.Bounded env11064 := by
  intro p hp
  have h : env11064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11063_11064 : H12AffineEnvironment.transform 13 2048 env11063 = env11064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env11063 == env11064) = true)

theorem identity11064 : scanCanonicalize (H12AffineFastState.compose env11064 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2560) := by decide +kernel

theorem selectedBound11064 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env11065 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,2560,569,2048,820,262,2853,2577,53,821,2577,32,16,2,569,17,2868,2064,2357,2577,516,32,256,32,2049,513]

theorem envBound11065 : H12AffineFastState.Bounded env11065 := by
  intro p hp
  have h : env11065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11064_11065 : H12AffineEnvironment.transform 11 2560 env11064 = env11065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2560 env11064 == env11065) = true)

theorem identity11065 : scanCanonicalize (H12AffineFastState.compose env11065 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 308) := by decide +kernel

theorem selectedBound11065 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env11066 : List Nat := [2,4,8,16,32,17,8,256,512,53,308,820,569,308,820,262,529,805,53,821,805,32,16,2,569,17,512,292,1,805,516,32,256,32,309,513]

theorem envBound11066 : H12AffineFastState.Bounded env11066 := by
  intro p hp
  have h : env11066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11065_11066 : H12AffineEnvironment.transform 10 308 env11065 = env11066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 308 env11065 == env11066) = true)

theorem identity11066 : scanCanonicalize (H12AffineFastState.compose env11066 (packedSelected [10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11066 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env11067 : List Nat := [2,4,8,16,32,17,8,37,512,53,17,529,569,17,529,35,529,512,53,528,512,32,16,2,569,17,512,1,1,512,516,32,37,32,16,513]

theorem envBound11067 : H12AffineFastState.Bounded env11067 := by
  intro p hp
  have h : env11067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11066_11067 : H12AffineEnvironment.transform 7 37 env11066 = env11067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11066 == env11067) = true)

theorem identity11067 : scanCanonicalize (H12AffineFastState.compose env11067 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11067 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11068 : List Nat := [2,4,8,16,1,17,8,4,512,20,17,529,536,17,529,2,529,512,20,528,512,1,16,2,536,17,512,1,1,512,516,1,4,1,16,513]

theorem envBound11068 : H12AffineFastState.Bounded env11068 := by
  intro p hp
  have h : env11068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11067_11068 : H12AffineEnvironment.transform 4 1 env11067 = env11068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11067 == env11068) = true)

theorem identity11068 : scanCanonicalize (H12AffineFastState.compose env11068 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound11068 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env11069 : List Nat := [2,4,8,0,1,1,8,4,512,4,1,513,520,1,513,2,513,512,4,512,512,1,0,2,520,1,512,1,1,512,516,1,4,1,0,513]

theorem envBound11069 : H12AffineFastState.Bounded env11069 := by
  intro p hp
  have h : env11069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11068_11069 : H12AffineEnvironment.transform 3 0 env11068 = env11069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env11068 == env11069) = true)

def env11070 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10281,1024,32769,115734,33,119878,95496,8192,64,10588,79130,17664,23668,75103,119927,256,41340,16464,513]

theorem envBound11070 : H12AffineFastState.Bounded env11070 := by
  intro p hp
  have h : env11070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11057_11070 : H12AffineEnvironment.transform 17 10281 env11057 = env11070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env11057 == env11070) = true)

theorem identity11070 : scanCanonicalize (H12AffineFastState.compose env11070 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound11070 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11071 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,5392,10281,1024,32769,45340,33,41292,2,8192,64,10588,16400,17664,23668,20565,41341,256,41340,16464,513]

theorem envBound11071 : H12AffineFastState.Bounded env11071 := by
  intro p hp
  have h : env11071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11070_11071 : H12AffineEnvironment.transform 15 29962 env11070 = env11071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env11070 == env11071) = true)

theorem identity11071 : scanCanonicalize (H12AffineFastState.compose env11071 (packedSelected [0,2,3,5,6,7,10,11,14] rootPS)) = affineNative (2^(14+1) ^^^ 17680) := by decide +kernel

theorem selectedBound11071 : packedSelected [0,2,3,5,6,7,10,11,14] rootPS < 2^1333 := by decide +kernel

def env11072 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,17680,29962,5392,10281,1024,17681,29708,33,25692,2,8192,64,10588,16400,17664,23668,20565,25709,256,25708,16464,513]

theorem envBound11072 : H12AffineFastState.Bounded env11072 := by
  intro p hp
  have h : env11072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11071_11072 : H12AffineEnvironment.transform 14 17680 env11071 = env11072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17680 env11071 == env11072) = true)

theorem identity11072 : scanCanonicalize (H12AffineFastState.compose env11072 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound11072 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env11073 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,8192,16384,17680,27930,3328,10281,1024,17681,27676,33,25692,2,8192,64,10588,16400,17664,17508,18501,25709,256,25708,16464,513]

theorem envBound11073 : H12AffineFastState.Bounded env11073 := by
  intro p hp
  have h : env11073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11072_11073 : H12AffineEnvironment.transform 11 2064 env11072 = env11073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env11072 == env11073) = true)

theorem identity11073 : scanCanonicalize (H12AffineFastState.compose env11073 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(13+1) ^^^ 8540) := by decide +kernel

theorem selectedBound11073 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env11074 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,8192,8540,9292,3142,3328,10281,1024,9293,3392,33,1280,2,8192,64,10588,8524,9308,9528,10521,1329,256,1328,8460,513]

theorem envBound11074 : H12AffineFastState.Bounded env11074 := by
  intro p hp
  have h : env11074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11073_11074 : H12AffineEnvironment.transform 13 8540 env11073 = env11074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8540 env11073 == env11074) = true)

theorem identity11074 : scanCanonicalize (H12AffineFastState.compose env11074 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound11074 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env11075 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,1053,1345,81,3142,3328,3124,1024,80,3392,33,1280,2,1053,64,3393,1361,65,293,3332,1329,256,1328,1297,513]

theorem envBound11075 : H12AffineFastState.Bounded env11075 := by
  intro p hp
  have h : env11075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11074_11075 : H12AffineEnvironment.transform 12 1053 env11074 = env11075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env11074 == env11075) = true)

theorem identity11075 : scanCanonicalize (H12AffineFastState.compose env11075 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound11075 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env11076 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,2064,40,372,81,2163,2357,2049,53,80,2421,33,309,2,40,64,2420,356,65,293,2353,260,256,261,292,513]

theorem envBound11076 : H12AffineFastState.Bounded env11076 := by
  intro p hp
  have h : env11076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11075_11076 : H12AffineEnvironment.transform 9 53 env11075 = env11076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env11075 == env11076) = true)

theorem identity11076 : scanCanonicalize (H12AffineFastState.compose env11076 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound11076 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env11077 : List Nat := [2,4,8,16,32,64,8,256,512,53,292,308,40,372,81,343,17,293,53,80,81,33,309,2,40,64,80,356,65,293,21,260,256,261,292,513]

theorem envBound11077 : H12AffineFastState.Bounded env11077 := by
  intro p hp
  have h : env11077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11076_11077 : H12AffineEnvironment.transform 10 292 env11076 = env11077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env11076 == env11077) = true)

theorem identity11077 : scanCanonicalize (H12AffineFastState.compose env11077 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 113) := by decide +kernel

theorem selectedBound11077 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env11078 : List Nat := [2,4,8,16,32,64,8,256,113,53,292,308,40,372,81,343,17,293,53,80,81,33,309,2,40,64,80,356,65,293,21,260,256,261,292,112]

theorem envBound11078 : H12AffineFastState.Bounded env11078 := by
  intro p hp
  have h : env11078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11077_11078 : H12AffineEnvironment.transform 8 113 env11077 = env11078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 113 env11077 == env11078) = true)

theorem identity11078 : scanCanonicalize (H12AffineFastState.compose env11078 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11078 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11079 : List Nat := [2,4,8,16,32,16,8,256,33,53,292,308,40,292,1,263,17,293,53,0,1,33,309,2,40,16,0,308,17,293,21,260,256,261,292,32]

theorem envBound11079 : H12AffineFastState.Bounded env11079 := by
  intro p hp
  have h : env11079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11078_11079 : H12AffineEnvironment.transform 5 16 env11078 = env11079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11078 == env11079) = true)

theorem identity11079 : scanCanonicalize (H12AffineFastState.compose env11079 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11079 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env11080 : List Nat := [2,4,8,16,32,16,8,37,33,53,1,17,40,1,1,34,17,0,53,0,1,33,16,2,40,16,0,17,17,0,21,33,37,32,1,32]

theorem envBound11080 : H12AffineFastState.Bounded env11080 := by
  intro p hp
  have h : env11080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11079_11080 : H12AffineEnvironment.transform 7 37 env11079 = env11080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11079 == env11080) = true)

theorem identity11080 : scanCanonicalize (H12AffineFastState.compose env11080 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11080 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11081 : List Nat := [2,4,8,16,0,16,8,5,1,21,1,17,8,1,1,2,17,0,21,0,1,1,16,2,8,16,0,17,17,0,21,1,5,0,1,0]

theorem envBound11081 : H12AffineFastState.Bounded env11081 := by
  intro p hp
  have h : env11081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11080_11081 : H12AffineEnvironment.transform 4 0 env11080 = env11081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11080 == env11081) = true)

def env11082 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,272393,119879,95496,8193,64,215366,79130,17664,463942,75102,392287,256,41341,16464,513]

theorem envBound11082 : H12AffineFastState.Bounded env11082 := by
  intro p hp
  have h : env11082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11055_11082 : H12AffineEnvironment.transform 6 9 env11055 = env11082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11055 == env11082) = true)

def env11083 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,115735,33,119879,95496,8193,64,215366,79130,17664,212078,75102,119927,256,41341,16464,513]

theorem envBound11083 : H12AffineFastState.Bounded env11083 := by
  intro p hp
  have h : env11083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11082_11083 : H12AffineEnvironment.transform 17 10280 env11082 = env11083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env11082 == env11083) = true)

theorem identity11083 : scanCanonicalize (H12AffineFastState.compose env11083 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound11083 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11084 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10280,1024,32769,4160,33,16,41311,8193,64,171281,57677,17664,190521,61705,32,256,41341,16464,513]

theorem envBound11084 : H12AffineFastState.Bounded env11084 := by
  intro p hp
  have h : env11084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11083_11084 : H12AffineEnvironment.transform 15 54359 env11083 = env11084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env11083 == env11084) = true)

theorem identity11084 : scanCanonicalize (H12AffineFastState.compose env11084 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound11084 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env11085 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,46157,10280,1024,32769,4160,33,16,41311,8193,64,10588,57677,17664,23668,61705,32,256,41341,16464,513]

theorem envBound11085 : H12AffineFastState.Bounded env11085 := by
  intro p hp
  have h : env11085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11084_11085 : H12AffineEnvironment.transform 16 46157 env11084 = env11085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env11084 == env11085) = true)

theorem identity11085 : scanCanonicalize (H12AffineFastState.compose env11085 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound11085 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11086 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,9293,28698,4096,10280,1024,9292,4160,33,16,1298,8193,64,10588,17664,17664,23668,21828,32,256,1328,16464,513]

theorem envBound11086 : H12AffineFastState.Bounded env11086 := by
  intro p hp
  have h : env11086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11085_11086 : H12AffineEnvironment.transform 14 9293 env11085 = env11086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env11085 == env11086) = true)

theorem identity11086 : scanCanonicalize (H12AffineFastState.compose env11086 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 7425) := by decide +kernel

theorem selectedBound11086 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env11087 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,7425,9293,11547,4096,10280,1024,9292,4160,33,16,1298,8193,64,10588,6145,6145,373,2117,32,256,1328,7505,513]

theorem envBound11087 : H12AffineFastState.Bounded env11087 := by
  intro p hp
  have h : env11087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11086_11087 : H12AffineEnvironment.transform 13 7425 env11086 = env11087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7425 env11086 == env11087) = true)

theorem identity11087 : scanCanonicalize (H12AffineFastState.compose env11087 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound11087 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env11088 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,2089,7425,3172,1330,4096,1,1024,3173,4160,33,16,1298,2088,64,373,6145,6145,373,2117,32,256,1328,7505,513]

theorem envBound11088 : H12AffineFastState.Bounded env11088 := by
  intro p hp
  have h : env11088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11087_11088 : H12AffineEnvironment.transform 12 2089 env11087 = env11088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env11087 == env11088) = true)

theorem identity11088 : scanCanonicalize (H12AffineFastState.compose env11088 (packedSelected [0,11,14,23,27] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound11088 : packedSelected [0,11,14,23,27] rootPS < 2^1333 := by decide +kernel

def env11089 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,2089,7284,3172,1095,4096,1,1024,3173,4160,33,16,1127,2088,64,0,6145,6145,0,2117,32,117,1093,7204,513]

theorem envBound11089 : H12AffineFastState.Bounded env11089 := by
  intro p hp
  have h : env11089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11088_11089 : H12AffineEnvironment.transform 7 117 env11088 = env11089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env11088 == env11089) = true)

theorem identity11089 : scanCanonicalize (H12AffineFastState.compose env11089 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1061) := by decide +kernel

theorem selectedBound11089 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env11090 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1061,4096,1036,4177,65,1095,4096,1,1024,64,4160,33,16,1127,1037,64,0,5156,5156,0,1120,32,117,1093,4097,513]

theorem envBound11090 : H12AffineFastState.Bounded env11090 := by
  intro p hp
  have h : env11090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11089_11090 : H12AffineEnvironment.transform 10 1061 env11089 = env11090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1061 env11089 == env11090) = true)

theorem identity11090 : scanCanonicalize (H12AffineFastState.compose env11090 (packedSelected [1,2,3,4,6,11] rootPS)) = affineNative (2^(11+1) ^^^ 1620) := by decide +kernel

theorem selectedBound11090 : packedSelected [1,2,3,4,6,11] rootPS < 2^1333 := by decide +kernel

def env11091 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1061,1620,1036,1541,65,1095,1620,1,1024,64,1556,33,16,1127,1037,64,0,624,624,0,1120,32,117,1093,1621,513]

theorem envBound11091 : H12AffineFastState.Bounded env11091 := by
  intro p hp
  have h : env11091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11090_11091 : H12AffineEnvironment.transform 11 1620 env11090 = env11091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1620 env11090 == env11091) = true)

theorem identity11091 : scanCanonicalize (H12AffineFastState.compose env11091 (packedSelected [0,2,3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound11091 : packedSelected [0,2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env11092 : List Nat := [2,4,8,16,32,64,9,117,512,85,112,513,89,592,65,18,513,1,85,64,577,33,16,50,88,64,0,624,624,0,53,32,117,16,512,513]

theorem envBound11092 : H12AffineFastState.Bounded env11092 := by
  intro p hp
  have h : env11092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11091_11092 : H12AffineEnvironment.transform 9 85 env11091 = env11092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env11091 == env11092) = true)

theorem identity11092 : scanCanonicalize (H12AffineFastState.compose env11092 (packedSelected [3,4] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound11092 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env11093 : List Nat := [2,4,8,16,32,32,9,21,512,53,16,513,57,560,33,18,513,1,53,32,545,33,16,50,56,32,0,528,528,0,53,32,21,16,512,513]

theorem envBound11093 : H12AffineFastState.Bounded env11093 := by
  intro p hp
  have h : env11093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11092_11093 : H12AffineEnvironment.transform 5 32 env11092 = env11093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env11092 == env11093) = true)

theorem identity11093 : scanCanonicalize (H12AffineFastState.compose env11093 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound11093 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env11094 : List Nat := [2,4,8,16,32,32,9,21,1,53,16,0,57,49,33,18,0,1,53,32,32,33,16,50,56,32,0,17,17,0,53,32,21,16,1,0]

theorem envBound11094 : H12AffineFastState.Bounded env11094 := by
  intro p hp
  have h : env11094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11093_11094 : H12AffineEnvironment.transform 8 1 env11093 = env11094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env11093 == env11094) = true)

theorem identity11094 : scanCanonicalize (H12AffineFastState.compose env11094 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11094 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11095 : List Nat := [2,4,8,16,1,1,9,21,1,20,16,0,24,16,0,18,0,1,20,1,1,0,16,19,25,1,0,17,17,0,20,1,21,16,1,0]

theorem envBound11095 : H12AffineFastState.Bounded env11095 := by
  intro p hp
  have h : env11095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11094_11095 : H12AffineEnvironment.transform 4 1 env11094 = env11095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11094 == env11095) = true)

theorem identity11095 : scanCanonicalize (H12AffineFastState.compose env11095 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound11095 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11096 : List Nat := [2,4,8,1,1,1,9,4,1,5,1,0,9,1,0,3,0,1,5,1,1,0,1,2,8,1,0,0,0,0,5,1,4,1,1,0]

theorem envBound11096 : H12AffineFastState.Bounded env11096 := by
  intro p hp
  have h : env11096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11095_11096 : H12AffineEnvironment.transform 3 1 env11095 = env11096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env11095 == env11096) = true)

def env11097 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,115735,32,119879,95496,8193,64,215366,79130,17664,212079,75102,119926,256,41341,16464,513]

theorem envBound11097 : H12AffineFastState.Bounded env11097 := by
  intro p hp
  have h : env11097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11082_11097 : H12AffineEnvironment.transform 17 10281 env11082 = env11097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env11082 == env11097) = true)

theorem identity11097 : scanCanonicalize (H12AffineFastState.compose env11097 (packedSelected [1,2,3,4,6,9,11,16,18,20,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 57629) := by decide +kernel

theorem selectedBound11097 : packedSelected [1,2,3,4,6,9,11,16,18,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env11098 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57629,10281,1024,32769,115735,32,119879,95496,8193,64,108635,79130,17664,122226,75102,119926,256,41341,16464,513]

theorem envBound11098 : H12AffineFastState.Bounded env11098 := by
  intro p hp
  have h : env11098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11097_11098 : H12AffineEnvironment.transform 16 57629 env11097 = env11098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57629 env11097 == env11098) = true)

theorem identity11098 : scanCanonicalize (H12AffineFastState.compose env11098 (packedSelected [1,2,4,6,8,9,10,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 41050) := by decide +kernel

theorem selectedBound11098 : packedSelected [1,2,4,6,8,9,10,14,15,16] rootPS < 2^1333 := by decide +kernel

def env11099 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,41050,57629,10281,1024,32769,25677,32,29725,54610,8193,64,2049,38208,17664,32040,34052,29740,256,41341,16464,513]

theorem envBound11099 : H12AffineFastState.Bounded env11099 := by
  intro p hp
  have h : env11099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11098_11099 : H12AffineEnvironment.transform 15 41050 env11098 = env11099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41050 env11098 == env11099) = true)

theorem identity11099 : scanCanonicalize (H12AffineFastState.compose env11099 (packedSelected [0,1,2,6,7,8,10,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound11099 : packedSelected [0,1,2,6,7,8,10,14,15,18] rootPS < 2^1333 := by decide +kernel

def env11100 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8460,342,16401,10281,1024,8461,25677,32,29725,29790,8193,64,2049,13388,17664,32040,9224,29740,256,113,16464,513]

theorem envBound11100 : H12AffineFastState.Bounded env11100 := by
  intro p hp
  have h : env11100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11099_11100 : H12AffineEnvironment.transform 14 8460 env11099 = env11100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env11099 == env11100) = true)

theorem identity11100 : scanCanonicalize (H12AffineFastState.compose env11100 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound11100 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env11101 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,81,342,16401,2420,1024,80,17680,32,21824,21763,348,64,2049,5393,17664,23669,1365,21873,256,113,16464,513]

theorem envBound11101 : H12AffineFastState.Bounded env11101 := by
  intro p hp
  have h : env11101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11100_11101 : H12AffineEnvironment.transform 12 349 env11100 = env11101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env11100 == env11101) = true)

theorem identity11101 : scanCanonicalize (H12AffineFastState.compose env11101 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound11101 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env11102 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5456,81,342,5441,2420,1024,80,4160,32,16,83,348,64,2049,5393,4176,2341,1365,33,256,113,5376,513]

theorem envBound11102 : H12AffineFastState.Bounded env11102 := by
  intro p hp
  have h : env11102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11101_11102 : H12AffineEnvironment.transform 13 5456 env11101 = env11102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env11101 == env11102) = true)

theorem identity11102 : scanCanonicalize (H12AffineFastState.compose env11102 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 3636) := by decide +kernel

theorem selectedBound11102 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env11103 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3636,349,2916,81,342,2933,2420,1024,80,3700,32,16,83,348,64,2049,2853,3684,2341,1365,33,256,113,2868,513]

theorem envBound11103 : H12AffineFastState.Bounded env11103 := by
  intro p hp
  have h : env11103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11102_11103 : H12AffineEnvironment.transform 11 3636 env11102 = env11103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3636 env11102 == env11103) = true)

theorem identity11103 : scanCanonicalize (H12AffineFastState.compose env11103 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound11103 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env11104 : List Nat := [2,4,8,16,32,64,9,256,372,1024,2048,3392,349,2064,81,342,2049,2420,1024,80,3328,32,16,83,348,64,2049,2129,3344,2341,1365,33,256,113,2112,373]

theorem envBound11104 : H12AffineFastState.Bounded env11104 := by
  intro p hp
  have h : env11104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11103_11104 : H12AffineEnvironment.transform 8 372 env11103 = env11104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env11103 == env11104) = true)

theorem identity11104 : scanCanonicalize (H12AffineFastState.compose env11104 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound11104 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env11105 : List Nat := [2,4,8,16,32,64,9,53,65,1024,2048,3189,104,2064,81,99,2049,2113,1024,80,3125,32,16,83,105,64,2049,2129,3109,2064,1120,33,53,113,2112,64]

theorem envBound11105 : H12AffineFastState.Bounded env11105 := by
  intro p hp
  have h : env11105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11104_11105 : H12AffineEnvironment.transform 7 53 env11104 = env11105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env11104 == env11105) = true)

theorem identity11105 : scanCanonicalize (H12AffineFastState.compose env11105 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound11105 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env11106 : List Nat := [2,4,8,16,32,64,9,53,65,36,2048,2129,104,2064,81,99,2049,2113,36,80,2065,32,16,83,105,64,2049,2129,2049,2064,68,33,53,113,2112,64]

theorem envBound11106 : H12AffineFastState.Bounded env11106 := by
  intro p hp
  have h : env11106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11105_11106 : H12AffineEnvironment.transform 9 36 env11105 = env11106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env11105 == env11106) = true)

theorem identity11106 : scanCanonicalize (H12AffineFastState.compose env11106 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound11106 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11107 : List Nat := [2,4,8,16,32,64,9,53,65,36,17,64,104,1,81,99,16,80,36,80,0,32,16,83,105,64,16,64,16,1,68,33,53,113,81,64]

theorem envBound11107 : H12AffineFastState.Bounded env11107 := by
  intro p hp
  have h : env11107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11106_11107 : H12AffineEnvironment.transform 10 17 env11106 = env11107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env11106 == env11107) = true)

theorem identity11107 : scanCanonicalize (H12AffineFastState.compose env11107 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11107 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env11108 : List Nat := [2,4,8,16,32,16,9,53,17,36,17,16,56,1,1,51,16,0,36,0,0,32,16,3,57,16,16,16,16,1,20,33,53,33,1,16]

theorem envBound11108 : H12AffineFastState.Bounded env11108 := by
  intro p hp
  have h : env11108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11107_11108 : H12AffineEnvironment.transform 5 16 env11107 = env11108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11107 == env11108) = true)

theorem identity11108 : scanCanonicalize (H12AffineFastState.compose env11108 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound11108 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11109 : List Nat := [2,4,8,16,17,16,9,4,17,21,17,16,9,1,1,2,16,0,21,0,0,17,16,3,8,16,16,16,16,1,20,16,4,16,1,16]

theorem envBound11109 : H12AffineFastState.Bounded env11109 := by
  intro p hp
  have h : env11109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11108_11109 : H12AffineEnvironment.transform 4 17 env11108 = env11109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env11108 == env11109) = true)

theorem identity11109 : scanCanonicalize (H12AffineFastState.compose env11109 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound11109 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11110 : List Nat := [2,4,8,0,1,0,9,4,1,5,1,0,9,1,1,2,0,0,5,0,0,1,0,3,8,0,0,0,0,1,4,0,4,0,1,0]

theorem envBound11110 : H12AffineFastState.Bounded env11110 := by
  intro p hp
  have h : env11110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11109_11110 : H12AffineEnvironment.transform 3 0 env11109 = env11110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env11109 == env11110) = true)

def env11111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115870,272513,8388608,95496,8328,64,8560009,79130,8491470,8830977,8450329,392407,256,8484154,8492190,8509135]

theorem envBound11111 : H12AffineFastState.Bounded env11111 := by
  intro p hp
  have h : env11111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11053_11111 : H12AffineEnvironment.transform 21 272513 env11053 = env11111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env11053 == env11111) = true)

theorem identity11111 : scanCanonicalize (H12AffineFastState.compose env11111 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound11111 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,4160,272513,8388608,41430,8328,64,8560009,57796,8406288,8830977,8450329,272393,256,8430052,8405056,8389137]

theorem envBound11112 : H12AffineFastState.Bounded env11112 := by
  intro p hp
  have h : env11112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11111_11112 : H12AffineEnvironment.transform 15 54494 env11111 = env11112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env11111 == env11112) = true)

def env11113 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4160,272393,8388608,41310,8192,64,8559873,57676,8406288,8830977,8450329,272393,256,8429932,8405056,8389137]

theorem envBound11113 : H12AffineFastState.Bounded env11113 := by
  intro p hp
  have h : env11113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11112_11113 : H12AffineEnvironment.transform 6 8 env11112 = env11113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11112 == env11113) = true)

def env11114 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4160,272393,16,41310,8192,64,171281,57676,17664,442385,61705,272393,256,41340,16464,513]

theorem envBound11114 : H12AffineFastState.Bounded env11114 := by
  intro p hp
  have h : env11114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11113_11114 : H12AffineEnvironment.transform 22 16 env11113 = env11114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env11113 == env11114) = true)

theorem identity11114 : scanCanonicalize (H12AffineFastState.compose env11114 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound11114 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11115 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,29962,131072,262144,1024,8541,4160,272393,16,2,8192,64,146509,16400,17664,418125,20565,272393,256,32,16464,513]

theorem envBound11115 : H12AffineFastState.Bounded env11115 := by
  intro p hp
  have h : env11115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11114_11115 : H12AffineEnvironment.transform 14 8540 env11114 = env11115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env11114 == env11115) = true)

theorem identity11115 : scanCanonicalize (H12AffineFastState.compose env11115 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound11115 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env11116 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8540,28698,131072,262144,272,8541,4160,272393,16,2,8192,64,145757,16400,16400,418125,20565,272393,256,32,16464,513]

theorem envBound11116 : H12AffineFastState.Bounded env11116 := by
  intro p hp
  have h : env11116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11115_11116 : H12AffineEnvironment.transform 9 272 env11115 = env11116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env11115 == env11116) = true)

theorem identity11116 : scanCanonicalize (H12AffineFastState.compose env11116 (packedSelected [9,14,22] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound11116 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env11117 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8540,28698,4096,262144,272,8541,4160,272393,16,2,8192,64,10589,16400,16400,291149,20565,272393,256,32,16464,513]

theorem envBound11117 : H12AffineFastState.Bounded env11117 := by
  intro p hp
  have h : env11117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11116_11117 : H12AffineEnvironment.transform 16 4096 env11116 = env11117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env11116 == env11117) = true)

theorem identity11117 : scanCanonicalize (H12AffineFastState.compose env11117 (packedSelected [0,2,6,14,27] rootPS)) = affineNative (2^(17+1) ^^^ 30777) := by decide +kernel

theorem selectedBound11117 : packedSelected [0,2,6,14,27] rootPS < 2^1333 := by decide +kernel

def env11118 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8540,28698,4096,30777,272,8541,4160,20528,16,2,8192,64,10589,16400,16400,2420,20565,20528,256,32,16464,513]

theorem envBound11118 : H12AffineFastState.Bounded env11118 := by
  intro p hp
  have h : env11118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11117_11118 : H12AffineEnvironment.transform 17 30777 env11117 = env11118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 30777 env11117 == env11118) = true)

theorem identity11118 : scanCanonicalize (H12AffineFastState.compose env11118 (packedSelected [12,15] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound11118 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env11119 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,41,16384,373,20531,4096,22544,272,372,4160,20528,16,2,41,64,2420,16400,16400,2420,20565,20528,256,32,16464,513]

theorem envBound11119 : H12AffineFastState.Bounded env11119 := by
  intro p hp
  have h : env11119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11118_11119 : H12AffineEnvironment.transform 12 41 env11118 = env11119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env11118 == env11119) = true)

theorem identity11119 : scanCanonicalize (H12AffineFastState.compose env11119 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound11119 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env11120 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,41,2048,373,6195,4096,4112,272,372,4160,6192,16,2,41,64,2420,2064,2064,2420,6229,6192,256,32,2128,513]

theorem envBound11120 : H12AffineFastState.Bounded env11120 := by
  intro p hp
  have h : env11120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11119_11120 : H12AffineEnvironment.transform 13 2048 env11119 = env11120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env11119 == env11120) = true)

theorem identity11120 : scanCanonicalize (H12AffineFastState.compose env11120 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound11120 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env11121 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2404,41,2048,373,343,2404,2420,272,372,2340,340,16,2,41,64,2420,2064,2064,2420,305,340,256,32,2128,513]

theorem envBound11121 : H12AffineFastState.Bounded env11121 := by
  intro p hp
  have h : env11121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11120_11121 : H12AffineEnvironment.transform 11 2404 env11120 = env11121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env11120 == env11121) = true)

theorem identity11121 : scanCanonicalize (H12AffineFastState.compose env11121 (packedSelected [1,2,3,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 340) := by decide +kernel

theorem selectedBound11121 : packedSelected [1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env11122 : List Nat := [2,4,8,16,32,64,8,256,512,272,340,48,41,340,373,343,48,32,272,372,112,340,16,2,41,64,32,324,324,32,305,340,256,32,260,513]

theorem envBound11122 : H12AffineFastState.Bounded env11122 := by
  intro p hp
  have h : env11122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11121_11122 : H12AffineEnvironment.transform 10 340 env11121 = env11122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 340 env11121 == env11122) = true)

theorem identity11122 : scanCanonicalize (H12AffineFastState.compose env11122 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound11122 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env11123 : List Nat := [2,4,8,16,32,64,8,53,512,37,97,48,41,97,64,98,48,32,37,65,112,97,16,2,41,64,32,113,113,32,4,97,53,32,49,513]

theorem envBound11123 : H12AffineFastState.Bounded env11123 := by
  intro p hp
  have h : env11123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11122_11123 : H12AffineEnvironment.transform 7 53 env11122 = env11123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env11122 == env11123) = true)

theorem identity11123 : scanCanonicalize (H12AffineFastState.compose env11123 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound11123 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env11124 : List Nat := [2,4,8,0,32,64,8,37,512,37,97,32,41,97,64,98,32,32,37,65,96,97,0,2,41,64,32,97,97,32,4,97,37,32,33,513]

theorem envBound11124 : H12AffineFastState.Bounded env11124 := by
  intro p hp
  have h : env11124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11123_11124 : H12AffineEnvironment.transform 3 0 env11123 = env11124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env11123 == env11124) = true)

theorem identity11124 : scanCanonicalize (H12AffineFastState.compose env11124 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound11124 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11125 : List Nat := [2,4,8,0,32,33,8,37,512,37,0,32,41,0,33,3,32,32,37,32,1,0,0,2,41,33,32,0,0,32,4,0,37,32,33,513]

theorem envBound11125 : H12AffineFastState.Bounded env11125 := by
  intro p hp
  have h : env11125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11124_11125 : H12AffineEnvironment.transform 5 33 env11124 = env11125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env11124 == env11125) = true)

def env11126 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4160,272393,17,41310,8192,64,171280,57676,17665,442384,61704,272393,256,41341,16465,512]

theorem envBound11126 : H12AffineFastState.Bounded env11126 := by
  intro p hp
  have h : env11126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11113_11126 : H12AffineEnvironment.transform 22 17 env11113 = env11126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env11113 == env11126) = true)

theorem identity11126 : scanCanonicalize (H12AffineFastState.compose env11126 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 56576) := by decide +kernel

theorem selectedBound11126 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env11127 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,56576,1024,32769,4160,62729,17,41310,8192,64,171280,57676,17665,138512,61704,62729,256,41341,16465,512]

theorem envBound11127 : H12AffineFastState.Bounded env11127 := by
  intro p hp
  have h : env11127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11126_11127 : H12AffineEnvironment.transform 17 56576 env11126 = env11127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56576 env11126 == env11127) = true)

theorem identity11127 : scanCanonicalize (H12AffineFastState.compose env11127 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound11127 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11128 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,32768,32803,131072,35189,1024,32769,4160,41340,17,41310,8192,64,171280,46393,4468,138512,42365,41340,256,41341,5156,512]

theorem envBound11128 : H12AffineFastState.Bounded env11128 := by
  intro p hp
  have h : env11128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11127_11128 : H12AffineEnvironment.transform 13 5237 env11127 = env11128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env11127 == env11128) = true)

theorem identity11128 : scanCanonicalize (H12AffineFastState.compose env11128 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 46360) := by decide +kernel

theorem selectedBound11128 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env11129 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,32768,32803,46360,35189,1024,32769,4160,41340,17,41310,8192,64,10248,46393,4468,43016,42365,41340,256,41341,5156,512]

theorem envBound11129 : H12AffineFastState.Bounded env11129 := by
  intro p hp
  have h : env11129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11128_11129 : H12AffineEnvironment.transform 16 46360 env11128 = env11129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46360 env11128 == env11129) = true)

theorem identity11129 : scanCanonicalize (H12AffineFastState.compose env11129 (packedSelected [6,14,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 341) := by decide +kernel

theorem selectedBound11129 : packedSelected [6,14,18,23] rootPS < 2^1333 := by decide +kernel

def env11130 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,341,374,13389,2080,1024,340,4160,8233,17,8203,8192,64,10248,13420,4468,10589,9256,8233,256,8232,5156,512]

theorem envBound11130 : H12AffineFastState.Bounded env11130 := by
  intro p hp
  have h : env11130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11129_11130 : H12AffineEnvironment.transform 14 341 env11129 = env11130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 341 env11129 == env11130) = true)

theorem identity11130 : scanCanonicalize (H12AffineFastState.compose env11130 (packedSelected [3,5,6,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound11130 : packedSelected [3,5,6,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env11131 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5237,341,374,5440,2080,1024,340,4160,292,17,262,269,64,2309,5473,4468,2128,1317,292,256,293,5156,512]

theorem envBound11131 : H12AffineFastState.Bounded env11131 := by
  intro p hp
  have h : env11131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11130_11131 : H12AffineEnvironment.transform 12 269 env11130 = env11131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env11130 == env11131) = true)

theorem identity11131 : scanCanonicalize (H12AffineFastState.compose env11131 (packedSelected [2,6,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound11131 : packedSelected [2,6,11,18] rootPS < 2^1333 := by decide +kernel

def env11132 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,120,5237,32,3,5173,2080,1024,33,4160,81,17,115,120,64,2160,5140,4097,2128,1104,81,117,80,5156,512]

theorem envBound11132 : H12AffineFastState.Bounded env11132 := by
  intro p hp
  have h : env11132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11131_11132 : H12AffineEnvironment.transform 7 117 env11131 = env11132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env11131 == env11132) = true)

theorem identity11132 : scanCanonicalize (H12AffineFastState.compose env11132 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11132 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env11133 : List Nat := [2,4,8,16,1,64,8,84,512,1024,2048,4096,89,5204,1,3,5140,2049,1024,0,4160,81,17,82,89,64,2129,5140,4097,2128,1104,81,84,80,5125,512]

theorem envBound11133 : H12AffineFastState.Bounded env11133 := by
  intro p hp
  have h : env11133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11132_11133 : H12AffineEnvironment.transform 4 1 env11132 = env11133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11132 == env11133) = true)

theorem identity11133 : scanCanonicalize (H12AffineFastState.compose env11133 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11133 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11134 : List Nat := [2,4,8,16,1,16,8,4,512,1024,2048,4096,9,5124,1,3,5140,2049,1024,0,4112,1,17,2,9,16,2049,5140,4097,2048,1024,1,4,0,5125,512]

theorem envBound11134 : H12AffineFastState.Bounded env11134 := by
  intro p hp
  have h : env11134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11133_11134 : H12AffineEnvironment.transform 5 16 env11133 = env11134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11133 == env11134) = true)

def env11135 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4160,272392,8388608,41311,8193,64,8559872,57677,8406288,8830977,8450329,272393,256,8429933,8405056,8389137]

theorem envBound11135 : H12AffineFastState.Bounded env11135 := by
  intro p hp
  have h : env11135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11112_11135 : H12AffineEnvironment.transform 6 9 env11112 = env11135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11112 == env11135) = true)

def env11136 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4160,272392,16,41311,8193,64,171280,57677,17664,442385,61705,272393,256,41341,16464,513]

theorem envBound11136 : H12AffineFastState.Bounded env11136 := by
  intro p hp
  have h : env11136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11135_11136 : H12AffineEnvironment.transform 22 16 env11135 = env11136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env11135 == env11136) = true)

def env11137 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,262144,1024,32769,4112,272392,16,41231,8193,16,171280,57629,17664,442385,61705,272393,256,41261,16384,513]

theorem envBound11137 : H12AffineFastState.Bounded env11137 := by
  intro p hp
  have h : env11137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11136_11137 : H12AffineEnvironment.transform 5 16 env11136 = env11137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11136 == env11137) = true)

theorem identity11137 : scanCanonicalize (H12AffineFastState.compose env11137 (packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound11137 : packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS < 2^1333 := by decide +kernel

def env11138 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,8202,131072,262144,1024,29708,4112,272392,16,21762,8193,16,157981,5392,17664,406556,1284,272393,256,21792,16384,513]

theorem envBound11138 : H12AffineFastState.Bounded env11138 := by
  intro p hp
  have h : env11138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11137_11138 : H12AffineEnvironment.transform 14 29709 env11137 = env11138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env11137 == env11138) = true)

theorem identity11138 : scanCanonicalize (H12AffineFastState.compose env11138 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 138292) := by decide +kernel

theorem selectedBound11138 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11139 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,8202,131072,138292,1024,29708,4112,144444,16,21762,8193,16,157981,5392,17664,10280,1284,144445,256,21792,16384,513]

theorem envBound11139 : H12AffineFastState.Bounded env11139 := by
  intro p hp
  have h : env11139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11138_11139 : H12AffineEnvironment.transform 17 138292 env11138 = env11139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138292 env11138 == env11139) = true)

theorem identity11139 : scanCanonicalize (H12AffineFastState.compose env11139 (packedSelected [1,8,12,15,19] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound11139 : packedSelected [1,8,12,15,19] rootPS < 2^1333 := by decide +kernel

def env11140 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,8202,16400,23588,1024,29708,4112,29740,16,21762,8193,16,10509,5392,17664,10280,1284,29741,256,21792,16384,513]

theorem envBound11140 : H12AffineFastState.Bounded env11140 := by
  intro p hp
  have h : env11140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11139_11140 : H12AffineEnvironment.transform 16 16400 env11139 = env11140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env11139 == env11140) = true)

theorem identity11140 : scanCanonicalize (H12AffineFastState.compose env11140 (packedSelected [5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound11140 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env11141 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,1052,16384,20497,1046,16400,23588,1024,20496,4112,20528,16,21762,1053,16,3345,5392,17664,3124,1284,20529,256,21792,16384,513]

theorem envBound11141 : H12AffineFastState.Bounded env11141 := by
  intro p hp
  have h : env11141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11140_11141 : H12AffineEnvironment.transform 12 1052 env11140 = env11141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env11140 == env11141) = true)

theorem identity11141 : scanCanonicalize (H12AffineFastState.compose env11141 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound11141 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env11142 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,1052,5156,1077,1046,5172,2048,1024,1076,4112,1044,16,294,1053,16,3345,5392,4388,3124,1284,1045,256,260,5156,513]

theorem envBound11142 : H12AffineFastState.Bounded env11142 := by
  intro p hp
  have h : env11142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11141_11142 : H12AffineEnvironment.transform 13 5156 env11141 = env11142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env11141 == env11142) = true)

theorem identity11142 : scanCanonicalize (H12AffineFastState.compose env11142 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound11142 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env11143 : List Nat := [2,4,8,16,32,16,9,256,512,52,2048,4096,40,4112,1,34,4096,2048,52,0,4112,32,16,294,41,16,2341,4388,4388,2048,304,33,256,260,4112,513]

theorem envBound11143 : H12AffineFastState.Bounded env11143 := by
  intro p hp
  have h : env11143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11142_11143 : H12AffineEnvironment.transform 9 52 env11142 = env11143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env11142 == env11143) = true)

theorem identity11143 : scanCanonicalize (H12AffineFastState.compose env11143 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11143 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11144 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,4096,40,4112,1,34,4096,2048,52,0,4112,32,16,2,41,16,2049,4096,4096,2048,20,33,36,32,4112,513]

theorem envBound11144 : H12AffineFastState.Bounded env11144 := by
  intro p hp
  have h : env11144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11143_11144 : H12AffineEnvironment.transform 7 36 env11143 = env11144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11143 == env11144) = true)

theorem identity11144 : scanCanonicalize (H12AffineFastState.compose env11144 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound11144 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11145 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,2096,40,2080,1,34,2096,2048,52,0,2080,32,16,2,41,16,2049,2096,2096,2048,20,33,36,32,2080,513]

theorem envBound11145 : H12AffineFastState.Bounded env11145 := by
  intro p hp
  have h : env11145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11144_11145 : H12AffineEnvironment.transform 11 2096 env11144 = env11145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env11144 == env11145) = true)

theorem identity11145 : scanCanonicalize (H12AffineFastState.compose env11145 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound11145 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11146 : List Nat := [2,4,8,16,32,16,9,36,512,52,48,0,40,16,1,34,0,48,52,0,16,32,16,2,41,16,49,0,0,48,20,33,36,32,16,513]

theorem envBound11146 : H12AffineFastState.Bounded env11146 := by
  intro p hp
  have h : env11146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11145_11146 : H12AffineEnvironment.transform 10 48 env11145 = env11146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env11145 == env11146) = true)

theorem identity11146 : scanCanonicalize (H12AffineFastState.compose env11146 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound11146 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11147 : List Nat := [2,4,8,0,32,0,9,36,512,36,32,0,40,0,1,34,0,32,36,0,0,32,0,2,41,0,33,0,0,32,4,33,36,32,0,513]

theorem envBound11147 : H12AffineFastState.Bounded env11147 := by
  intro p hp
  have h : env11147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11146_11147 : H12AffineEnvironment.transform 3 0 env11146 = env11147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env11146 == env11147) = true)

theorem identity11147 : scanCanonicalize (H12AffineFastState.compose env11147 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11147 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env11148 : List Nat := [2,4,8,0,1,0,9,5,512,5,1,0,9,0,1,3,0,1,5,0,0,1,0,2,8,0,0,0,0,1,4,0,5,1,0,513]

theorem envBound11148 : H12AffineFastState.Bounded env11148 := by
  intro p hp
  have h : env11148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11147_11148 : H12AffineEnvironment.transform 4 1 env11147 = env11148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11147 == env11148) = true)

def env11149 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,262144,1024,32769,4113,272392,16,41230,8193,17,171280,57628,17664,442385,61705,272393,256,41260,16385,513]

theorem envBound11149 : H12AffineFastState.Bounded env11149 := by
  intro p hp
  have h : env11149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11136_11149 : H12AffineEnvironment.transform 5 17 env11136 = env11149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11136 == env11149) = true)

theorem identity11149 : scanCanonicalize (H12AffineFastState.compose env11149 (packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 179512) := by decide +kernel

theorem selectedBound11149 : packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS < 2^1333 := by decide +kernel

def env11150 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,179512,1024,32769,4113,169264,16,41230,8193,17,171280,57628,17664,32041,61705,169265,256,41260,16385,513]

theorem envBound11150 : H12AffineFastState.Bounded env11150 := by
  intro p hp
  have h : env11150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11149_11150 : H12AffineEnvironment.transform 17 179512 env11149 = env11150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env11149 == env11150) = true)

theorem identity11150 : scanCanonicalize (H12AffineFastState.compose env11150 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound11150 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env11151 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54278,38161,10281,1024,32769,4113,33,16,41230,8193,17,2049,57628,17664,32041,61705,32,256,41260,16385,513]

theorem envBound11151 : H12AffineFastState.Bounded env11151 := by
  intro p hp
  have h : env11151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11150_11151 : H12AffineEnvironment.transform 16 38161 env11150 = env11151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env11150 == env11151) = true)

theorem identity11151 : scanCanonicalize (H12AffineFastState.compose env11151 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound11151 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11152 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,32768,54278,38161,2340,1024,32769,4113,33,16,32771,268,17,2049,49169,17664,23588,53252,32,256,32801,16385,513]

theorem envBound11152 : H12AffineFastState.Bounded env11152 := by
  intro p hp
  have h : env11152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11151_11152 : H12AffineEnvironment.transform 12 269 env11151 = env11152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env11151 == env11152) = true)

theorem identity11152 : scanCanonicalize (H12AffineFastState.compose env11152 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound11152 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env11153 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,0,21510,5393,2340,1024,1,4113,33,16,3,268,17,2049,16401,17664,23588,20484,32,256,33,16385,513]

theorem envBound11153 : H12AffineFastState.Bounded env11153 := by
  intro p hp
  have h : env11153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11152_11153 : H12AffineEnvironment.transform 14 0 env11152 = env11153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env11152 == env11153) = true)

theorem identity11153 : scanCanonicalize (H12AffineFastState.compose env11153 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound11153 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11154 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,0,263,5393,2340,1024,1,4113,33,16,3,268,17,2049,5392,4097,2341,1285,32,256,33,5376,513]

theorem envBound11154 : H12AffineFastState.Bounded env11154 := by
  intro p hp
  have h : env11154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11153_11154 : H12AffineEnvironment.transform 13 5377 env11153 = env11154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env11153 == env11154) = true)

theorem identity11154 : scanCanonicalize (H12AffineFastState.compose env11154 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11154 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11155 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5157,0,35,5173,2048,1024,1,4113,33,16,3,40,17,2049,5172,4097,2049,1057,32,36,33,5156,513]

theorem envBound11155 : H12AffineFastState.Bounded env11155 := by
  intro p hp
  have h : env11155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11154_11155 : H12AffineEnvironment.transform 7 36 env11154 = env11155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11154 == env11155) = true)

theorem identity11155 : scanCanonicalize (H12AffineFastState.compose env11155 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound11155 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11156 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,4096,41,4112,0,35,4096,2048,53,1,4113,33,16,3,40,17,2049,4097,4097,2049,20,32,36,33,4113,513]

theorem envBound11156 : H12AffineFastState.Bounded env11156 := by
  intro p hp
  have h : env11156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11155_11156 : H12AffineEnvironment.transform 9 53 env11155 = env11156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env11155 == env11156) = true)

theorem identity11156 : scanCanonicalize (H12AffineFastState.compose env11156 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound11156 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11157 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,32,41,48,0,35,32,2048,53,1,49,33,16,3,40,17,2049,33,33,2049,20,32,36,33,49,513]

theorem envBound11157 : H12AffineFastState.Bounded env11157 := by
  intro p hp
  have h : env11157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11156_11157 : H12AffineEnvironment.transform 11 32 env11156 = env11157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env11156 == env11157) = true)

theorem identity11157 : scanCanonicalize (H12AffineFastState.compose env11157 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound11157 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11158 : List Nat := [2,4,8,16,32,17,9,36,512,53,33,32,41,48,0,35,32,33,53,1,49,33,16,3,40,17,32,33,33,32,20,32,36,33,49,513]

theorem envBound11158 : H12AffineFastState.Bounded env11158 := by
  intro p hp
  have h : env11158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11157_11158 : H12AffineEnvironment.transform 10 33 env11157 = env11158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env11157 == env11158) = true)

theorem identity11158 : scanCanonicalize (H12AffineFastState.compose env11158 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound11158 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env11159 : List Nat := [2,4,8,0,32,1,9,36,512,37,33,32,41,32,0,35,32,33,37,1,33,33,0,3,40,1,32,33,33,32,4,32,36,33,33,513]

theorem envBound11159 : H12AffineFastState.Bounded env11159 := by
  intro p hp
  have h : env11159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11158_11159 : H12AffineEnvironment.transform 3 0 env11158 = env11159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env11158 == env11159) = true)

def env11160 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4160,272392,17,41311,8193,64,171281,57677,17665,442384,61704,272393,256,41340,16465,512]

theorem envBound11160 : H12AffineFastState.Bounded env11160 := by
  intro p hp
  have h : env11160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11135_11160 : H12AffineEnvironment.transform 22 17 env11135 = env11160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env11135 == env11160) = true)

theorem identity11160 : scanCanonicalize (H12AffineFastState.compose env11160 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 56576) := by decide +kernel

theorem selectedBound11160 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env11161 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,56576,1024,32769,4160,62728,17,41311,8193,64,171281,57677,17665,138512,61704,62729,256,41340,16465,512]

theorem envBound11161 : H12AffineFastState.Bounded env11161 := by
  intro p hp
  have h : env11161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11160_11161 : H12AffineEnvironment.transform 17 56576 env11160 = env11161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56576 env11160 == env11161) = true)

theorem identity11161 : scanCanonicalize (H12AffineFastState.compose env11161 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29992) := by decide +kernel

theorem selectedBound11161 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11162 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29992,8575,131072,10280,1024,29993,4160,32,17,21623,8193,64,157753,5221,17665,138512,1056,33,256,21588,16465,512]

theorem envBound11162 : H12AffineFastState.Bounded env11162 := by
  intro p hp
  have h : env11162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11161_11162 : H12AffineEnvironment.transform 14 29992 env11161 = env11162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29992 env11161 == env11162) = true)

theorem identity11162 : scanCanonicalize (H12AffineFastState.compose env11162 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound11162 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env11163 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,8540,8575,131072,10280,1024,8541,4160,32,17,3,8193,64,146509,5221,4469,138512,1056,33,256,32,5157,512]

theorem envBound11163 : H12AffineFastState.Bounded env11163 := by
  intro p hp
  have h : env11163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11162_11163 : H12AffineEnvironment.transform 13 5236 env11162 = env11163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env11162 == env11163) = true)

theorem identity11163 : scanCanonicalize (H12AffineFastState.compose env11163 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(16+1) ^^^ 3441) := by decide +kernel

theorem selectedBound11163 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env11164 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,8540,8575,3441,10280,1024,8541,4160,32,17,3,8193,64,12604,5221,4469,4193,1056,33,256,32,5157,512]

theorem envBound11164 : H12AffineFastState.Bounded env11164 := by
  intro p hp
  have h : env11164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11163_11164 : H12AffineEnvironment.transform 16 3441 env11163 = env11164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 3441 env11163 == env11164) = true)

theorem identity11164 : scanCanonicalize (H12AffineFastState.compose env11164 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11164 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env11165 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,5236,8312,8283,3157,10280,1024,8313,4160,32,17,3,8193,64,12312,5221,4177,4193,1056,33,36,32,5157,512]

theorem envBound11165 : H12AffineFastState.Bounded env11165 := by
  intro p hp
  have h : env11165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11164_11165 : H12AffineEnvironment.transform 7 36 env11164 = env11165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11164 == env11165) = true)

theorem identity11165 : scanCanonicalize (H12AffineFastState.compose env11165 (packedSelected [0,2,3,5,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound11165 : packedSelected [0,2,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env11166 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,89,5236,33,2,3157,2161,1024,32,4160,32,17,3,88,64,4161,5221,4177,4193,1056,33,36,32,5157,512]

theorem envBound11166 : H12AffineFastState.Bounded env11166 := by
  intro p hp
  have h : env11166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11165_11166 : H12AffineEnvironment.transform 12 89 env11165 = env11166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env11165 == env11166) = true)

theorem identity11166 : scanCanonicalize (H12AffineFastState.compose env11166 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound11166 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env11167 : List Nat := [2,4,8,16,32,64,9,36,512,20,2048,4096,89,4192,33,2,2113,2161,20,32,4160,32,17,3,88,64,4161,4209,4177,4193,52,33,36,32,4145,512]

theorem envBound11167 : H12AffineFastState.Bounded env11167 := by
  intro p hp
  have h : env11167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11166_11167 : H12AffineEnvironment.transform 9 20 env11166 = env11167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env11166 == env11167) = true)

theorem identity11167 : scanCanonicalize (H12AffineFastState.compose env11167 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound11167 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env11168 : List Nat := [2,4,8,16,32,64,9,36,512,20,2048,2113,89,2081,33,2,2113,2161,20,32,2049,32,17,3,88,64,2048,2096,2064,2080,52,33,36,32,2160,512]

theorem envBound11168 : H12AffineFastState.Bounded env11168 := by
  intro p hp
  have h : env11168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11167_11168 : H12AffineEnvironment.transform 11 2113 env11167 = env11168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env11167 == env11168) = true)

theorem identity11168 : scanCanonicalize (H12AffineFastState.compose env11168 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound11168 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env11169 : List Nat := [2,4,8,16,32,48,9,36,512,20,2048,2097,41,2081,33,2,2097,2049,20,32,2049,32,17,3,40,48,2048,2096,2064,2080,52,33,36,32,2048,512]

theorem envBound11169 : H12AffineFastState.Bounded env11169 := by
  intro p hp
  have h : env11169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11168_11169 : H12AffineEnvironment.transform 5 48 env11168 = env11169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env11168 == env11169) = true)

theorem identity11169 : scanCanonicalize (H12AffineFastState.compose env11169 (packedSelected [4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11169 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env11170 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,2064,8,2048,0,2,2064,2049,20,1,2049,1,17,3,9,17,2048,2065,2064,2049,21,0,5,1,2048,512]

theorem envBound11170 : H12AffineFastState.Bounded env11170 := by
  intro p hp
  have h : env11170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11169_11170 : H12AffineEnvironment.transform 4 1 env11169 = env11170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11169 == env11170) = true)

theorem identity11170 : scanCanonicalize (H12AffineFastState.compose env11170 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 21) := by decide +kernel

theorem selectedBound11170 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11171 : List Nat := [2,4,8,16,1,17,9,5,512,20,21,5,8,21,0,2,5,20,20,1,20,1,17,3,9,17,21,4,5,20,21,0,5,1,21,512]

theorem envBound11171 : H12AffineFastState.Bounded env11171 := by
  intro p hp
  have h : env11171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11170_11171 : H12AffineEnvironment.transform 10 21 env11170 = env11171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 21 env11170 == env11171) = true)

theorem identity11171 : scanCanonicalize (H12AffineFastState.compose env11171 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound11171 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11172 : List Nat := [2,4,8,16,1,17,9,5,7,20,21,5,8,21,0,2,5,20,20,1,20,1,17,3,9,17,21,4,5,20,21,0,5,1,21,7]

theorem envBound11172 : H12AffineFastState.Bounded env11172 := by
  intro p hp
  have h : env11172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11171_11172 : H12AffineEnvironment.transform 8 7 env11171 = env11172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env11171 == env11172) = true)

theorem identity11172 : scanCanonicalize (H12AffineFastState.compose env11172 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound11172 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11173 : List Nat := [2,4,8,8,1,9,9,5,7,12,13,5,8,13,0,2,5,12,12,1,12,1,9,3,9,9,13,4,5,12,13,0,5,1,13,7]

theorem envBound11173 : H12AffineFastState.Bounded env11173 := by
  intro p hp
  have h : env11173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11172_11173 : H12AffineEnvironment.transform 3 8 env11172 = env11173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env11172 == env11173) = true)

def env11174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115870,4194304,8388608,95497,8328,64,13022473,79131,8491470,8830977,8450328,4314199,256,8484155,8492191,8509134]

theorem envBound11174 : H12AffineFastState.Bounded env11174 := by
  intro p hp
  have h : env11174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11052_11174 : H12AffineEnvironment.transform 23 95497 env11052 = env11174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env11052 == env11174) = true)

def env11175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115870,272512,8388608,95497,8328,64,8560009,79131,8491470,8830977,8450328,392407,256,8484155,8492191,8509134]

theorem envBound11175 : H12AffineFastState.Bounded env11175 := by
  intro p hp
  have h : env11175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11174_11175 : H12AffineEnvironment.transform 21 272512 env11174 = env11175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env11174 == env11175) = true)

def env11176 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,272392,8388608,95497,8192,64,8559873,79131,8491334,8830977,8450328,392287,256,8484155,8492055,8508998]

theorem envBound11176 : H12AffineFastState.Bounded env11176 := by
  intro p hp
  have h : env11176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11175_11176 : H12AffineEnvironment.transform 6 8 env11175 = env11176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11175 == env11176) = true)

def env11177 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,272392,16,95497,8192,64,171281,79131,102742,442385,61704,392287,256,95531,103431,120406]

theorem envBound11177 : H12AffineFastState.Bounded env11177 := by
  intro p hp
  have h : env11177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11176_11177 : H12AffineEnvironment.transform 22 16 env11176 = env11177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env11176 == env11177) = true)

theorem identity11177 : scanCanonicalize (H12AffineFastState.compose env11177 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound11177 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11178 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,262144,1024,32769,45341,272392,16,2,8192,64,171281,16400,58461,442385,61704,297300,256,32,57612,41821]

theorem envBound11178 : H12AffineFastState.Bounded env11178 := by
  intro p hp
  have h : env11178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11177_11178 : H12AffineEnvironment.transform 15 29963 env11177 = env11178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env11177 == env11178) = true)

theorem identity11178 : scanCanonicalize (H12AffineFastState.compose env11178 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound11178 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env11179 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,35189,1024,32769,45341,41341,16,2,8192,64,171281,16400,58461,149860,61704,33,256,32,57612,41821]

theorem envBound11179 : H12AffineFastState.Bounded env11179 := by
  intro p hp
  have h : env11179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11178_11179 : H12AffineEnvironment.transform 17 35189 env11178 = env11179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env11178 == env11179) = true)

theorem identity11179 : scanCanonicalize (H12AffineFastState.compose env11179 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound11179 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env11180 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,46157,35189,1024,32769,45341,41341,16,2,8192,64,10588,16400,58461,64809,61704,33,256,32,57612,41821]

theorem envBound11180 : H12AffineFastState.Bounded env11180 := by
  intro p hp
  have h : env11180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11179_11180 : H12AffineEnvironment.transform 16 46157 env11179 = env11180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env11179 == env11180) = true)

theorem identity11180 : scanCanonicalize (H12AffineFastState.compose env11180 (packedSelected [11,12,15,23] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound11180 : packedSelected [11,12,15,23] rootPS < 2^1333 := by decide +kernel

def env11181 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,8192,16384,32768,28990,45176,35189,53,32769,45341,41341,16,2,8192,64,10588,16400,57448,63772,61704,33,256,32,57612,41821]

theorem envBound11181 : H12AffineFastState.Bounded env11181 := by
  intro p hp
  have h : env11181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11180_11181 : H12AffineEnvironment.transform 9 53 env11180 = env11181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env11180 == env11181) = true)

theorem identity11181 : scanCanonicalize (H12AffineFastState.compose env11181 (packedSelected [0,4,7,9,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound11181 : packedSelected [0,4,7,9,11,14,15] rootPS < 2^1333 := by decide +kernel

def env11182 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,41,16384,32768,20759,36945,35189,53,32769,37172,33108,16,2,41,64,2421,16400,49217,55605,53537,33,256,32,49445,33652]

theorem envBound11182 : H12AffineFastState.Bounded env11182 := by
  intro p hp
  have h : env11182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11181_11182 : H12AffineEnvironment.transform 12 41 env11181 = env11182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env11181 == env11182) = true)

theorem identity11182 : scanCanonicalize (H12AffineFastState.compose env11182 (packedSelected [2,4,6,9,12,14,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 20788) := by decide +kernel

theorem selectedBound11182 : packedSelected [2,4,6,9,12,14,16,18] rootPS < 2^1333 := by decide +kernel

def env11183 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,41,16384,20788,20759,16741,22593,53,20789,16384,20576,16,2,41,64,2421,16400,4469,2049,21,33,256,32,4113,21056]

theorem envBound11183 : H12AffineFastState.Bounded env11183 := by
  intro p hp
  have h : env11183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11182_11183 : H12AffineEnvironment.transform 14 20788 env11182 = env11183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20788 env11182 == env11183) = true)

theorem identity11183 : scanCanonicalize (H12AffineFastState.compose env11183 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound11183 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env11184 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,2357,41,16384,18433,18466,16741,16756,53,18432,16384,18773,16,2,41,64,2421,16400,2112,2049,21,33,256,32,2340,19317]

theorem envBound11184 : H12AffineFastState.Bounded env11184 := by
  intro p hp
  have h : env11184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11183_11184 : H12AffineEnvironment.transform 11 2357 env11183 = env11184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env11183 == env11184) = true)

theorem identity11184 : scanCanonicalize (H12AffineFastState.compose env11184 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 2624) := by decide +kernel

theorem selectedBound11184 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env11185 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,2357,41,2624,577,610,2853,2868,53,576,2624,789,16,2,41,64,2421,2640,2112,2049,21,33,256,32,2340,309]

theorem envBound11185 : H12AffineFastState.Bounded env11185 := by
  intro p hp
  have h : env11185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11184_11185 : H12AffineEnvironment.transform 13 2624 env11184 = env11185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2624 env11184 == env11185) = true)

theorem identity11185 : scanCanonicalize (H12AffineFastState.compose env11185 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound11185 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env11186 : List Nat := [2,4,8,16,32,64,8,256,512,53,373,64,41,821,577,610,592,577,53,576,821,789,16,2,41,64,0,805,309,372,21,33,256,32,81,309]

theorem envBound11186 : H12AffineFastState.Bounded env11186 := by
  intro p hp
  have h : env11186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11185_11186 : H12AffineEnvironment.transform 10 373 env11185 = env11186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env11185 == env11186) = true)

theorem identity11186 : scanCanonicalize (H12AffineFastState.compose env11186 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound11186 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env11187 : List Nat := [2,4,8,16,32,64,8,256,0,53,373,64,41,309,65,98,80,65,53,64,309,277,16,2,41,64,0,293,309,372,21,33,256,32,81,309]

theorem envBound11187 : H12AffineFastState.Bounded env11187 := by
  intro p hp
  have h : env11187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11186_11187 : H12AffineEnvironment.transform 8 0 env11186 = env11187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env11186 == env11187) = true)

theorem identity11187 : scanCanonicalize (H12AffineFastState.compose env11187 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound11187 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env11188 : List Nat := [2,4,8,1,32,64,8,256,0,36,356,64,41,292,65,98,65,65,36,64,292,260,1,2,41,64,0,293,292,357,4,33,256,32,64,292]

theorem envBound11188 : H12AffineFastState.Bounded env11188 := by
  intro p hp
  have h : env11188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11187_11188 : H12AffineEnvironment.transform 3 1 env11187 = env11188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env11187 == env11188) = true)

theorem identity11188 : scanCanonicalize (H12AffineFastState.compose env11188 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11188 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11189 : List Nat := [2,4,8,1,32,64,8,36,0,36,64,64,41,0,65,98,65,65,36,64,0,32,1,2,41,64,0,1,0,65,4,33,36,32,64,0]

theorem envBound11189 : H12AffineFastState.Bounded env11189 := by
  intro p hp
  have h : env11189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11188_11189 : H12AffineEnvironment.transform 7 36 env11188 = env11189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11188 == env11189) = true)

theorem identity11189 : scanCanonicalize (H12AffineFastState.compose env11189 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound11189 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11190 : List Nat := [2,4,8,1,14,64,8,10,0,10,64,64,7,0,65,76,65,65,10,64,0,14,1,2,7,64,0,1,0,65,4,15,10,14,64,0]

theorem envBound11190 : H12AffineFastState.Bounded env11190 := by
  intro p hp
  have h : env11190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11189_11190 : H12AffineEnvironment.transform 4 14 env11189 = env11190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env11189 == env11190) = true)

theorem identity11190 : scanCanonicalize (H12AffineFastState.compose env11190 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 14) := by decide +kernel

theorem selectedBound11190 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11191 : List Nat := [2,4,8,1,14,14,8,10,0,10,14,14,7,0,15,2,15,15,10,14,0,14,1,2,7,14,0,1,0,15,4,15,10,14,14,0]

theorem envBound11191 : H12AffineFastState.Bounded env11191 := by
  intro p hp
  have h : env11191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11190_11191 : H12AffineEnvironment.transform 5 14 env11190 = env11191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 14 env11190 == env11191) = true)

theorem identity11191 : scanCanonicalize (H12AffineFastState.compose env11191 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound11191 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11192 : List Nat := [2,4,6,1,0,0,6,4,0,4,0,0,7,0,1,2,1,1,4,0,0,0,1,2,7,0,0,1,0,1,4,1,4,0,0,0]

theorem envBound11192 : H12AffineFastState.Bounded env11192 := by
  intro p hp
  have h : env11192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11191_11192 : H12AffineEnvironment.transform 2 6 env11191 = env11192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env11191 == env11192) = true)

def env11193 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,272392,17,95497,8192,64,171280,79131,102743,442384,61705,392287,256,95530,103430,120407]

theorem envBound11193 : H12AffineFastState.Bounded env11193 := by
  intro p hp
  have h : env11193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11176_11193 : H12AffineEnvironment.transform 22 17 env11176 = env11193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env11176 == env11193) = true)

theorem identity11193 : scanCanonicalize (H12AffineFastState.compose env11193 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound11193 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11194 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89378,1024,32769,115734,95530,17,95497,8192,64,171280,79131,102743,236850,61705,41341,256,95530,103430,120407]

theorem envBound11194 : H12AffineFastState.Bounded env11194 := by
  intro p hp
  have h : env11194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11193_11194 : H12AffineEnvironment.transform 17 89378 env11193 = env11194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env11193 == env11194) = true)

theorem identity11194 : scanCanonicalize (H12AffineFastState.compose env11194 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound11194 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env11195 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,46156,89378,1024,32769,115734,95530,17,95497,8192,64,10588,79131,102743,76158,61705,41341,256,95530,103430,120407]

theorem envBound11195 : H12AffineFastState.Bounded env11195 := by
  intro p hp
  have h : env11195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11194_11195 : H12AffineEnvironment.transform 16 46156 env11194 = env11195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env11194 == env11195) = true)

theorem identity11195 : scanCanonicalize (H12AffineFastState.compose env11195 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound11195 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env11196 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,46156,35188,1024,32769,4160,41340,17,41311,8192,64,10588,57677,17665,64808,61705,41341,256,41340,16464,513]

theorem envBound11196 : H12AffineFastState.Bounded env11196 := by
  intro p hp
  have h : env11196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11195_11196 : H12AffineEnvironment.transform 15 54358 env11195 = env11196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env11195 == env11196) = true)

theorem identity11196 : scanCanonicalize (H12AffineFastState.compose env11196 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29005) := by decide +kernel

theorem selectedBound11196 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env11197 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29005,9499,17665,30777,1024,29004,4160,20529,17,20498,8192,64,10588,4096,17665,3173,68,20528,256,20529,16464,513]

theorem envBound11197 : H12AffineFastState.Bounded env11197 := by
  intro p hp
  have h : env11197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11196_11197 : H12AffineEnvironment.transform 14 29005 env11196 = env11197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29005 env11196 == env11197) = true)

def env11198 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,272393,8388608,95497,8193,64,8559872,79131,8491335,8830977,8450328,392286,256,8484155,8492054,8508999]

theorem envBound11198 : H12AffineFastState.Bounded env11198 := by
  intro p hp
  have h : env11198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11175_11198 : H12AffineEnvironment.transform 6 9 env11175 = env11198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11175 == env11198) = true)

def env11199 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,272393,16,95497,8193,64,171280,79131,102743,442385,61704,392286,256,95531,103430,120407]

theorem envBound11199 : H12AffineFastState.Bounded env11199 := by
  intro p hp
  have h : env11199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11198_11199 : H12AffineEnvironment.transform 22 16 env11198 = env11199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env11198 == env11199) = true)

theorem identity11199 : scanCanonicalize (H12AffineFastState.compose env11199 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound11199 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11200 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4161,272393,16,41311,8193,64,171280,57677,17665,442385,61704,272392,256,41341,16464,513]

theorem envBound11200 : H12AffineFastState.Bounded env11200 := by
  intro p hp
  have h : env11200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11199_11200 : H12AffineEnvironment.transform 15 54358 env11199 = env11200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env11199 == env11200) = true)

def env11201 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,262144,1024,32769,4113,272393,16,41231,8193,16,171280,57629,17665,442385,61704,272392,256,41261,16384,513]

theorem envBound11201 : H12AffineFastState.Bounded env11201 := by
  intro p hp
  have h : env11201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11200_11201 : H12AffineEnvironment.transform 5 16 env11200 = env11201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11200 == env11201) = true)

theorem identity11201 : scanCanonicalize (H12AffineFastState.compose env11201 (packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 171060) := by decide +kernel

theorem selectedBound11201 : packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS < 2^1333 := by decide +kernel

def env11202 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,171060,1024,32769,4113,177213,16,41231,8193,16,171280,57629,17665,23589,61704,177212,256,41261,16384,513]

theorem envBound11202 : H12AffineFastState.Bounded env11202 := by
  intro p hp
  have h : env11202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11201_11202 : H12AffineEnvironment.transform 17 171060 env11201 = env11202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171060 env11201 == env11202) = true)

theorem identity11202 : scanCanonicalize (H12AffineFastState.compose env11202 (packedSelected [1,2,3,4,6,9,14,20,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound11202 : packedSelected [1,2,3,4,6,9,14,20,24,28] rootPS < 2^1333 := by decide +kernel

def env11203 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,32768,33030,131072,171060,1024,32769,4113,177213,16,41231,8193,16,171280,46109,4097,2341,41992,177212,256,41261,5376,513]

theorem envBound11203 : H12AffineFastState.Bounded env11203 := by
  intro p hp
  have h : env11203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11202_11203 : H12AffineEnvironment.transform 13 5376 env11202 = env11203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env11202 == env11203) = true)

def env11204 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,262144,1024,32769,4112,272393,16,41230,8193,17,171280,57628,17665,442385,61704,272392,256,41260,16385,513]

theorem envBound11204 : H12AffineFastState.Bounded env11204 := by
  intro p hp
  have h : env11204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11200_11204 : H12AffineEnvironment.transform 5 17 env11200 = env11204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11200 == env11204) = true)

theorem identity11204 : scanCanonicalize (H12AffineFastState.compose env11204 (packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound11204 : packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS < 2^1333 := by decide +kernel

def env11205 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,21760,263,131072,262144,1024,21761,4112,272393,16,29710,8193,17,149520,13340,17665,398609,9224,272392,256,29740,16385,513]

theorem envBound11205 : H12AffineFastState.Bounded env11205 := by
  intro p hp
  have h : env11205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11204_11205 : H12AffineEnvironment.transform 14 21760 env11204 = env11205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env11204 == env11205) = true)

theorem identity11205 : scanCanonicalize (H12AffineFastState.compose env11205 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 138292) := by decide +kernel

theorem selectedBound11205 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11206 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,21760,263,131072,138292,1024,21761,4112,144445,16,29710,8193,17,149520,13340,17665,2341,9224,144444,256,29740,16385,513]

theorem envBound11206 : H12AffineFastState.Bounded env11206 := by
  intro p hp
  have h : env11206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11205_11206 : H12AffineEnvironment.transform 17 138292 env11205 = env11206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138292 env11205 == env11206) = true)

theorem identity11206 : scanCanonicalize (H12AffineFastState.compose env11206 (packedSelected [0,3,5,7,10,12,15,20] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound11206 : packedSelected [0,3,5,7,10,12,15,20] rootPS < 2^1333 := by decide +kernel

def env11207 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,21760,263,24861,32041,1024,21761,4112,21792,16,29710,8193,17,10509,13340,17665,2341,9224,21793,256,29740,16385,513]

theorem envBound11207 : H12AffineFastState.Bounded env11207 := by
  intro p hp
  have h : env11207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11206_11207 : H12AffineEnvironment.transform 16 24861 env11206 = env11207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env11206 == env11207) = true)

theorem identity11207 : scanCanonicalize (H12AffineFastState.compose env11207 (packedSelected [18,23] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound11207 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env11208 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,0,263,13341,10281,1024,1,4112,32,16,8462,8193,17,10509,13340,4097,2341,9224,33,256,8492,5377,513]

theorem envBound11208 : H12AffineFastState.Bounded env11208 := by
  intro p hp
  have h : env11208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11207_11208 : H12AffineEnvironment.transform 13 5376 env11207 = env11208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env11207 == env11208) = true)

theorem identity11208 : scanCanonicalize (H12AffineFastState.compose env11208 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 6940) := by decide +kernel

theorem selectedBound11208 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env11209 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,6940,5376,0,263,3841,4917,1024,1,4112,32,16,6674,6941,17,4625,3840,4097,2341,7956,33,256,6704,5377,513]

theorem envBound11209 : H12AffineFastState.Bounded env11209 := by
  intro p hp
  have h : env11209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11208_11209 : H12AffineEnvironment.transform 12 6940 env11208 = env11209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6940 env11208 == env11209) = true)

theorem identity11209 : scanCanonicalize (H12AffineFastState.compose env11209 (packedSelected [0,1,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound11209 : packedSelected [0,1,5,7] rootPS < 2^1333 := by decide +kernel

def env11210 : List Nat := [2,4,8,16,32,17,9,256,512,36,2048,4096,6940,4388,0,263,2853,4917,36,1,4112,32,16,6674,6941,17,4625,2852,4097,2341,6960,33,256,6704,4389,513]

theorem envBound11210 : H12AffineFastState.Bounded env11210 := by
  intro p hp
  have h : env11210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11209_11210 : H12AffineEnvironment.transform 9 36 env11209 = env11210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env11209 == env11210) = true)

theorem identity11210 : scanCanonicalize (H12AffineFastState.compose env11210 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound11210 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env11211 : List Nat := [2,4,8,16,32,17,9,256,512,36,16,4096,4876,4388,0,263,821,4917,36,1,4112,32,16,4610,4877,17,4625,820,4097,309,4896,33,256,4640,4389,513]

theorem envBound11211 : H12AffineFastState.Bounded env11211 := by
  intro p hp
  have h : env11211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11210_11211 : H12AffineEnvironment.transform 10 16 env11210 = env11211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env11210 == env11211) = true)

theorem identity11211 : scanCanonicalize (H12AffineFastState.compose env11211 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound11211 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env11212 : List Nat := [2,4,8,16,32,17,9,256,292,36,16,4096,4136,4388,0,263,17,4113,36,1,4112,32,16,4390,4137,17,4405,16,4097,309,4100,33,256,4356,4389,293]

theorem envBound11212 : H12AffineFastState.Bounded env11212 := by
  intro p hp
  have h : env11212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11211_11212 : H12AffineEnvironment.transform 8 292 env11211 = env11212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env11211 == env11212) = true)

theorem identity11212 : scanCanonicalize (H12AffineFastState.compose env11212 (packedSelected [1,3,11] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound11212 : packedSelected [1,3,11] rootPS < 2^1333 := by decide +kernel

def env11213 : List Nat := [2,4,8,16,32,17,9,256,292,36,16,292,268,0,0,263,17,309,36,1,308,32,16,2,269,17,17,16,293,309,288,33,256,32,1,293]

theorem envBound11213 : H12AffineFastState.Bounded env11213 := by
  intro p hp
  have h : env11213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11212_11213 : H12AffineEnvironment.transform 11 292 env11212 = env11213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env11212 == env11213) = true)

theorem identity11213 : scanCanonicalize (H12AffineFastState.compose env11213 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound11213 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11214 : List Nat := [2,4,8,16,32,17,9,52,16,36,16,16,56,0,0,51,17,1,36,1,0,32,16,2,57,17,17,16,17,1,20,33,52,32,1,17]

theorem envBound11214 : H12AffineFastState.Bounded env11214 := by
  intro p hp
  have h : env11214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11213_11214 : H12AffineEnvironment.transform 7 52 env11213 = env11214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env11213 == env11214) = true)

theorem identity11214 : scanCanonicalize (H12AffineFastState.compose env11214 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound11214 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11215 : List Nat := [2,4,8,16,26,17,9,14,16,30,16,16,2,0,0,9,17,1,30,1,0,26,16,2,3,17,17,16,17,1,20,27,14,26,1,17]

theorem envBound11215 : H12AffineFastState.Bounded env11215 := by
  intro p hp
  have h : env11215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11214_11215 : H12AffineEnvironment.transform 4 26 env11214 = env11215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env11214 == env11215) = true)

def env11216 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,272393,17,95497,8193,64,171281,79131,102742,442384,61705,392286,256,95530,103431,120406]

theorem envBound11216 : H12AffineFastState.Bounded env11216 := by
  intro p hp
  have h : env11216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11198_11216 : H12AffineEnvironment.transform 22 17 env11198 = env11216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env11198 == env11216) = true)

theorem identity11216 : scanCanonicalize (H12AffineFastState.compose env11216 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130174) := by decide +kernel

theorem selectedBound11216 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11217 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,130174,1024,32769,115735,119927,17,95497,8193,64,171281,79131,102742,212078,61705,32,256,95530,103431,120406]

theorem envBound11217 : H12AffineFastState.Bounded env11217 := by
  intro p hp
  have h : env11217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11216_11217 : H12AffineEnvironment.transform 17 130174 env11216 = env11217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130174 env11216 == env11217) = true)

theorem identity11217 : scanCanonicalize (H12AffineFastState.compose env11217 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound11217 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env11218 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,46157,130174,1024,32769,115735,119927,17,95497,8193,64,10588,79131,102742,100387,61705,32,256,95530,103431,120406]

theorem envBound11218 : H12AffineFastState.Bounded env11218 := by
  intro p hp
  have h : env11218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11217_11218 : H12AffineEnvironment.transform 16 46157 env11217 = env11218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env11217 == env11218) = true)

theorem identity11218 : scanCanonicalize (H12AffineFastState.compose env11218 (packedSelected [1,3,4,8,9,10,11,14,18,19,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound11218 : packedSelected [1,3,4,8,9,10,11,14,18,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env11219 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21841,65536,24860,76079,1024,21840,69958,65830,17,95497,8193,64,10588,79131,82951,89458,9304,32,256,95530,82262,66311]

theorem envBound11219 : H12AffineFastState.Bounded env11219 := by
  intro p hp
  have h : env11219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11218_11219 : H12AffineEnvironment.transform 14 21841 env11218 = env11219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env11218 == env11219) = true)

theorem identity11219 : scanCanonicalize (H12AffineFastState.compose env11219 (packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound11219 : packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS < 2^1333 := by decide +kernel

def env11220 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21841,263,24860,10280,1024,21840,4161,33,17,29710,8193,64,10588,13340,17664,23669,9304,32,256,29741,16465,512]

theorem envBound11220 : H12AffineFastState.Bounded env11220 := by
  intro p hp
  have h : env11220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11219_11220 : H12AffineEnvironment.transform 15 263 env11219 = env11220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env11219 == env11220) = true)

theorem identity11220 : scanCanonicalize (H12AffineFastState.compose env11220 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound11220 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11221 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1053,16384,21841,263,17665,3125,1024,21840,4161,33,17,20499,1052,64,3393,4097,17664,23669,69,32,256,20528,16465,512]

theorem envBound11221 : H12AffineFastState.Bounded env11221 := by
  intro p hp
  have h : env11221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11220_11221 : H12AffineEnvironment.transform 12 1053 env11220 = env11221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env11220 == env11221) = true)

theorem identity11221 : scanCanonicalize (H12AffineFastState.compose env11221 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4453) := by decide +kernel

theorem selectedBound11221 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11222 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1053,4453,1076,263,5220,3125,1024,1077,4161,33,17,374,1052,64,3393,4097,5221,3344,69,32,256,341,4404,512]

theorem envBound11222 : H12AffineFastState.Bounded env11222 := by
  intro p hp
  have h : env11222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11221_11222 : H12AffineEnvironment.transform 13 4453 env11221 = env11222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4453 env11221 == env11222) = true)

theorem identity11222 : scanCanonicalize (H12AffineFastState.compose env11222 (packedSelected [2,4,6,9,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound11222 : packedSelected [2,4,6,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env11223 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3188,1053,3345,1076,263,2064,3125,1024,1077,3125,33,17,374,1052,64,3393,3189,2065,3344,69,32,256,341,3392,512]

theorem envBound11223 : H12AffineFastState.Bounded env11223 := by
  intro p hp
  have h : env11223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11222_11223 : H12AffineEnvironment.transform 11 3188 env11222 = env11223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env11222 == env11223) = true)

theorem identity11223 : scanCanonicalize (H12AffineFastState.compose env11223 (packedSelected [1,4,5,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound11223 : packedSelected [1,4,5,7,11] rootPS < 2^1333 := by decide +kernel

def env11224 : List Nat := [2,4,8,16,32,64,9,4,512,1024,2048,3188,1053,3093,1076,3,2064,3125,1024,1077,3125,33,17,114,1052,64,3141,3189,2065,3092,69,32,4,81,3140,512]

theorem envBound11224 : H12AffineFastState.Bounded env11224 := by
  intro p hp
  have h : env11224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11223_11224 : H12AffineEnvironment.transform 7 4 env11223 = env11224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env11223 == env11224) = true)

theorem identity11224 : scanCanonicalize (H12AffineFastState.compose env11224 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11224 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env11225 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,3109,1053,3093,1076,3,2064,3125,1024,1077,3125,33,17,35,1052,17,3092,3108,2065,3092,20,32,4,0,3093,512]

theorem envBound11225 : H12AffineFastState.Bounded env11225 := by
  intro p hp
  have h : env11225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11224_11225 : H12AffineEnvironment.transform 5 17 env11224 = env11225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11224 == env11225) = true)

theorem identity11225 : scanCanonicalize (H12AffineFastState.compose env11225 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound11225 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env11226 : List Nat := [2,4,8,16,32,17,9,4,512,52,2048,2065,41,2081,0,3,2064,2049,52,1,2049,33,17,35,40,17,2080,2064,2065,2080,20,32,4,0,2081,512]

theorem envBound11226 : H12AffineFastState.Bounded env11226 := by
  intro p hp
  have h : env11226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11225_11226 : H12AffineEnvironment.transform 9 52 env11225 = env11226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env11225 == env11226) = true)

theorem identity11226 : scanCanonicalize (H12AffineFastState.compose env11226 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound11226 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env11227 : List Nat := [2,4,8,16,32,17,9,4,512,52,512,529,41,545,0,3,528,513,52,1,513,33,17,35,40,17,544,528,529,544,20,32,4,0,545,512]

theorem envBound11227 : H12AffineFastState.Bounded env11227 := by
  intro p hp
  have h : env11227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11226_11227 : H12AffineEnvironment.transform 10 512 env11226 = env11227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env11226 == env11227) = true)

theorem identity11227 : scanCanonicalize (H12AffineFastState.compose env11227 (packedSelected [0,1,2] rootPS)) = affineNative (2^(8+1) ^^^ 53) := by decide +kernel

theorem selectedBound11227 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env11228 : List Nat := [2,4,8,16,32,17,9,4,53,52,53,36,41,20,0,3,37,52,52,1,52,33,17,35,40,17,21,37,36,21,20,32,4,0,20,53]

theorem envBound11228 : H12AffineFastState.Bounded env11228 := by
  intro p hp
  have h : env11228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11227_11228 : H12AffineEnvironment.transform 8 53 env11227 = env11228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 53 env11227 == env11228) = true)

theorem identity11228 : scanCanonicalize (H12AffineFastState.compose env11228 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound11228 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11229 : List Nat := [2,4,8,4,32,5,9,4,33,32,33,36,41,0,0,3,37,32,32,1,32,33,5,35,40,5,1,37,36,1,0,32,4,0,0,33]

theorem envBound11229 : H12AffineFastState.Bounded env11229 := by
  intro p hp
  have h : env11229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11228_11229 : H12AffineEnvironment.transform 3 4 env11228 = env11229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env11228 == env11229) = true)

def env11230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115870,272513,8388608,95497,8328,64,8560008,79131,8491470,8830977,8450328,392406,256,8484155,8492191,8509134]

theorem envBound11230 : H12AffineFastState.Bounded env11230 := by
  intro p hp
  have h : env11230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11174_11230 : H12AffineEnvironment.transform 21 272513 env11174 = env11230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env11174 == env11230) = true)

theorem identity11230 : scanCanonicalize (H12AffineFastState.compose env11230 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound11230 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115870,272513,16,95497,8328,64,171416,79131,102878,442385,61704,392406,256,95531,103567,120542]

theorem envBound11231 : H12AffineFastState.Bounded env11231 := by
  intro p hp
  have h : env11231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11230_11231 : H12AffineEnvironment.transform 22 16 env11230 = env11231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env11230 == env11231) = true)

def env11232 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,272393,16,95497,8192,64,171280,79131,102742,442385,61704,392286,256,95531,103431,120406]

theorem envBound11232 : H12AffineFastState.Bounded env11232 := by
  intro p hp
  have h : env11232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11231_11232 : H12AffineEnvironment.transform 6 8 env11231 = env11232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11231 == env11232) = true)

theorem identity11232 : scanCanonicalize (H12AffineFastState.compose env11232 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound11232 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11233 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,262144,1024,32769,45341,272393,16,2,8192,64,171280,16400,58461,442385,61704,297301,256,32,57612,41821]

theorem envBound11233 : H12AffineFastState.Bounded env11233 := by
  intro p hp
  have h : env11233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11232_11233 : H12AffineEnvironment.transform 15 29963 env11232 = env11233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env11232 == env11233) = true)

theorem identity11233 : scanCanonicalize (H12AffineFastState.compose env11233 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 138292) := by decide +kernel

theorem selectedBound11233 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env11234 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,138292,1024,32769,45341,144445,16,2,8192,64,171280,16400,58461,56357,61704,169313,256,32,57612,41821]

theorem envBound11234 : H12AffineFastState.Bounded env11234 := by
  intro p hp
  have h : env11234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11233_11234 : H12AffineEnvironment.transform 17 138292 env11233 = env11234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138292 env11233 == env11234) = true)

theorem identity11234 : scanCanonicalize (H12AffineFastState.compose env11234 (packedSelected [0,1,4,7,8,10,11,14,16,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 57449) := by decide +kernel

theorem selectedBound11234 : packedSelected [0,1,4,7,8,10,11,14,16,22,23] rootPS < 2^1333 := by decide +kernel

def env11235 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,57449,64605,1024,32769,45341,54356,16,2,8192,64,32121,16400,58461,56357,61704,29960,256,32,57612,41821]

theorem envBound11235 : H12AffineFastState.Bounded env11235 := by
  intro p hp
  have h : env11235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11234_11235 : H12AffineEnvironment.transform 16 57449 env11234 = env11235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57449 env11234 == env11235) = true)

theorem identity11235 : scanCanonicalize (H12AffineFastState.compose env11235 (packedSelected [2,3,4,6,12,15,22,24,35] rootPS)) = affineNative (2^(14+1) ^^^ 30073) := by decide +kernel

theorem selectedBound11235 : packedSelected [2,3,4,6,12,15,22,24,35] rootPS < 2^1333 := by decide +kernel

def env11236 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,30073,29963,5392,2340,1024,30072,17508,8493,16,2,8192,64,32121,16400,4388,10588,1137,29960,256,32,5237,22052]

theorem envBound11236 : H12AffineFastState.Bounded env11236 := by
  intro p hp
  have h : env11236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11235_11236 : H12AffineEnvironment.transform 14 30073 env11235 = env11236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30073 env11235 == env11236) = true)

theorem identity11236 : scanCanonicalize (H12AffineFastState.compose env11236 (packedSelected [1,3,5,8,11,12,14,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound11236 : packedSelected [1,3,5,8,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env11237 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21541,21591,5392,2340,1024,21540,17508,113,16,2,348,64,23589,16400,4388,2048,1137,21588,256,32,5237,22052]

theorem envBound11237 : H12AffineFastState.Bounded env11237 := by
  intro p hp
  have h : env11237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11236_11237 : H12AffineEnvironment.transform 12 348 env11236 = env11237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env11236 == env11237) = true)

theorem identity11237 : scanCanonicalize (H12AffineFastState.compose env11237 (packedSelected [1,4,8,9,12,14,15,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound11237 : packedSelected [1,4,8,9,12,14,15,19,20] rootPS < 2^1333 := by decide +kernel

def env11238 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5237,80,34,5392,2340,1024,81,4113,113,16,2,348,64,2128,5221,4388,2048,1137,33,256,32,5237,593]

theorem envBound11238 : H12AffineFastState.Bounded env11238 := by
  intro p hp
  have h : env11238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11237_11238 : H12AffineEnvironment.transform 13 5237 env11237 = env11238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env11237 == env11238) = true)

theorem identity11238 : scanCanonicalize (H12AffineFastState.compose env11238 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound11238 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env11239 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,5237,80,34,5220,2128,1024,81,4113,113,16,2,40,64,2128,5221,4176,2048,1137,33,116,32,5237,593]

theorem envBound11239 : H12AffineFastState.Bounded env11239 := by
  intro p hp
  have h : env11239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11238_11239 : H12AffineEnvironment.transform 7 116 env11238 = env11239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env11238 == env11239) = true)

theorem identity11239 : scanCanonicalize (H12AffineFastState.compose env11239 (packedSelected [0,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11239 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env11240 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,5156,1,34,5173,2049,1024,0,4113,32,16,2,40,17,2049,5172,4097,2048,1056,33,37,32,5156,512]

theorem envBound11240 : H12AffineFastState.Bounded env11240 := by
  intro p hp
  have h : env11240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11239_11240 : H12AffineEnvironment.transform 5 17 env11239 = env11240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11239 == env11240) = true)

theorem identity11240 : scanCanonicalize (H12AffineFastState.compose env11240 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11240 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11241 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,4096,8,5124,1,2,5141,2049,1024,0,4113,0,16,2,8,17,2049,5140,4097,2048,1024,1,5,0,5124,512]

theorem envBound11241 : H12AffineFastState.Bounded env11241 := by
  intro p hp
  have h : env11241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11240_11241 : H12AffineEnvironment.transform 4 0 env11240 = env11241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11240 == env11241) = true)

def env11242 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,16,8,1044,1,2,1029,2049,1024,0,1,0,16,2,8,17,2049,1028,17,2048,1024,1,5,0,1044,512]

theorem envBound11242 : H12AffineFastState.Bounded env11242 := by
  intro p hp
  have h : env11242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11241_11242 : H12AffineEnvironment.transform 11 16 env11241 = env11242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env11241 == env11242) = true)

theorem identity11242 : scanCanonicalize (H12AffineFastState.compose env11242 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound11242 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11243 : List Nat := [2,4,8,16,0,17,8,5,512,1024,0,16,8,1044,1,2,1029,1,1024,0,1,0,16,2,8,17,1,1028,17,0,1024,1,5,0,1044,512]

theorem envBound11243 : H12AffineFastState.Bounded env11243 := by
  intro p hp
  have h : env11243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11242_11243 : H12AffineEnvironment.transform 10 0 env11242 = env11243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env11242 == env11243) = true)

def env11244 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,16,8,0,1,2,17,1,20,0,1,0,16,2,8,17,1,16,17,0,20,1,5,0,0,512]

theorem envBound11244 : H12AffineFastState.Bounded env11244 := by
  intro p hp
  have h : env11244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11243_11244 : H12AffineEnvironment.transform 9 20 env11243 = env11244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env11243 == env11244) = true)

theorem identity11244 : scanCanonicalize (H12AffineFastState.compose env11244 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound11244 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11245 : List Nat := [2,4,8,16,0,17,8,5,30,20,0,16,8,0,1,2,17,1,20,0,1,0,16,2,8,17,1,16,17,0,20,1,5,0,0,30]

theorem envBound11245 : H12AffineFastState.Bounded env11245 := by
  intro p hp
  have h : env11245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11244_11245 : H12AffineEnvironment.transform 8 30 env11244 = env11245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env11244 == env11245) = true)

def leafEnv11245 : List Nat := [2,4,8,16,0,17,8,5,30,20,0,16,8,0,1,2,17,1,20,0,1,0,16,2,20,8,1,17,1,16,17,0,20,1,5,0,4,2,0,30,1,1,0]

def active11245 : List Nat := [0,1,2,3]

def tree11245 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11245 : H12WitnessSearch.Good tree11245 := H12GlobalWitnessIndex.good

theorem leafIdentity11245 : H12AffineFastState.composeSystem env11245 rootObs = leafEnv11245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11245 rootObs == leafEnv11245) = true)

theorem terminalChecked11245 : H12PackedTerminal.terminalCheckFast leafEnv11245 active11245 tree11245 = true := by decide +kernel

def env11246 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,16,8,1,1,2,16,1,21,0,1,0,16,2,8,17,1,17,17,0,21,1,5,0,1,512]

theorem envBound11246 : H12AffineFastState.Bounded env11246 := by
  intro p hp
  have h : env11246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11243_11246 : H12AffineEnvironment.transform 9 21 env11243 = env11246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env11243 == env11246) = true)

theorem identity11246 : scanCanonicalize (H12AffineFastState.compose env11246 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound11246 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11247 : List Nat := [2,4,8,5,0,4,8,5,512,0,0,5,8,1,1,2,5,1,0,0,1,0,5,2,8,4,1,4,4,0,0,1,5,0,1,512]

theorem envBound11247 : H12AffineFastState.Bounded env11247 := by
  intro p hp
  have h : env11247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11246_11247 : H12AffineEnvironment.transform 3 5 env11246 = env11247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env11246 == env11247) = true)

def leafEnv11247 : List Nat := [2,4,8,5,0,4,8,5,512,0,0,5,8,1,1,2,5,1,0,0,1,0,5,2,0,8,1,4,1,4,4,0,0,1,5,0,4,2,1,512,1,1,0]

def active11247 : List Nat := [0,1,2,8]

def tree11247 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11247 : H12WitnessSearch.Good tree11247 := H12GlobalWitnessIndex.good

theorem leafIdentity11247 : H12AffineFastState.composeSystem env11247 rootObs = leafEnv11247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11247 rootObs == leafEnv11247) = true)

theorem terminalChecked11247 : H12PackedTerminal.terminalCheckFast leafEnv11247 active11247 tree11247 = true := by decide +kernel

def env11248 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,17,8,1045,1,2,1028,2049,1024,0,0,0,16,2,8,17,2049,1029,16,2048,1024,1,5,0,1045,512]

theorem envBound11248 : H12AffineFastState.Bounded env11248 := by
  intro p hp
  have h : env11248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11241_11248 : H12AffineEnvironment.transform 11 17 env11241 = env11248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env11241 == env11248) = true)

theorem identity11248 : scanCanonicalize (H12AffineFastState.compose env11248 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

end H12CloudChart0