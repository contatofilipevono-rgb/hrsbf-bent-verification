import H12CloudChart0Data114

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env29162 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,4096,9,5125,0,3,5140,2049,1024,1,4113,0,16,2,9,17,2049,5141,4097,2048,1024,1,5,0,5125,512]

theorem envBound29162 : H12AffineFastState.Bounded env29162 := by
  intro p hp
  have h : env29162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29161_29162 : H12AffineEnvironment.transform 7 5 env29161 = env29162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env29161 == env29162) = true)

def env29163 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,16,9,1045,0,3,1028,2049,1024,1,1,0,16,2,9,17,2049,1029,17,2048,1024,1,5,0,1045,512]

theorem envBound29163 : H12AffineFastState.Bounded env29163 := by
  intro p hp
  have h : env29163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29162_29163 : H12AffineEnvironment.transform 11 16 env29162 = env29163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env29162 == env29163) = true)

theorem identity29163 : scanCanonicalize (H12AffineFastState.compose env29163 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound29163 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29164 : List Nat := [2,4,8,16,0,17,8,5,512,1024,1045,16,9,1045,0,3,1028,1044,1024,1,1,0,16,2,9,17,1044,1029,17,1045,1024,1,5,0,1045,512]

theorem envBound29164 : H12AffineFastState.Bounded env29164 := by
  intro p hp
  have h : env29164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29163_29164 : H12AffineEnvironment.transform 10 1045 env29163 = env29164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env29163 == env29164) = true)

def env29165 : List Nat := [2,4,8,16,0,17,8,5,512,20,1,16,9,1,0,3,16,0,20,1,1,0,16,2,9,17,0,17,17,1,20,1,5,0,1,512]

theorem envBound29165 : H12AffineFastState.Bounded env29165 := by
  intro p hp
  have h : env29165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29164_29165 : H12AffineEnvironment.transform 9 20 env29164 = env29165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env29164 == env29165) = true)

theorem identity29165 : scanCanonicalize (H12AffineFastState.compose env29165 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound29165 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29166 : List Nat := [2,4,8,5,0,4,8,5,512,1,1,5,9,1,0,3,5,0,1,1,1,0,5,2,9,4,0,4,4,1,1,1,5,0,1,512]

theorem envBound29166 : H12AffineFastState.Bounded env29166 := by
  intro p hp
  have h : env29166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29165_29166 : H12AffineEnvironment.transform 3 5 env29165 = env29166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env29165 == env29166) = true)

def leafEnv29166 : List Nat := [2,4,8,5,0,4,8,5,512,1,1,5,9,1,0,3,5,0,1,1,1,0,5,2,1,9,1,4,0,4,4,1,1,1,5,0,4,3,1,512,1,1,0]

def active29166 : List Nat := [0,1,2,8]

def tree29166 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood29166 : H12WitnessSearch.Good tree29166 := H12GlobalWitnessIndex.good

theorem leafIdentity29166 : H12AffineFastState.composeSystem env29166 rootObs = leafEnv29166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env29166 rootObs == leafEnv29166) = true)

theorem terminalChecked29166 : H12PackedTerminal.terminalCheckFast leafEnv29166 active29166 tree29166 = true := by decide +kernel

def env29167 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,16,9,0,0,3,17,1,21,1,1,0,16,2,9,17,1,16,17,0,21,1,5,0,0,512]

theorem envBound29167 : H12AffineFastState.Bounded env29167 := by
  intro p hp
  have h : env29167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29164_29167 : H12AffineEnvironment.transform 9 21 env29164 = env29167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env29164 == env29167) = true)

theorem identity29167 : scanCanonicalize (H12AffineFastState.compose env29167 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound29167 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29168 : List Nat := [2,4,8,16,0,17,8,5,30,21,0,16,9,0,0,3,17,1,21,1,1,0,16,2,9,17,1,16,17,0,21,1,5,0,0,30]

theorem envBound29168 : H12AffineFastState.Bounded env29168 := by
  intro p hp
  have h : env29168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29167_29168 : H12AffineEnvironment.transform 8 30 env29167 = env29168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env29167 == env29168) = true)

def leafEnv29168 : List Nat := [2,4,8,16,0,17,8,5,30,21,0,16,9,0,0,3,17,1,21,1,1,0,16,2,21,9,1,17,1,16,17,0,21,1,5,0,4,3,0,30,1,1,0]

def active29168 : List Nat := [0,1,2,3]

def tree29168 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood29168 : H12WitnessSearch.Good tree29168 := H12GlobalWitnessIndex.good

theorem leafIdentity29168 : H12AffineFastState.composeSystem env29168 rootObs = leafEnv29168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env29168 rootObs == leafEnv29168) = true)

theorem terminalChecked29168 : H12PackedTerminal.terminalCheckFast leafEnv29168 active29168 tree29168 = true := by decide +kernel

def env29169 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,17,9,1044,0,3,1029,2049,1024,1,0,0,16,2,9,17,2049,1028,16,2048,1024,1,5,0,1044,512]

theorem envBound29169 : H12AffineFastState.Bounded env29169 := by
  intro p hp
  have h : env29169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29162_29169 : H12AffineEnvironment.transform 11 17 env29162 = env29169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env29162 == env29169) = true)

theorem identity29169 : scanCanonicalize (H12AffineFastState.compose env29169 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound29169 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29170 : List Nat := [2,4,8,16,0,17,8,5,512,1024,0,17,9,1044,0,3,1029,1,1024,1,0,0,16,2,9,17,1,1028,16,0,1024,1,5,0,1044,512]

theorem envBound29170 : H12AffineFastState.Bounded env29170 := by
  intro p hp
  have h : env29170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29169_29170 : H12AffineEnvironment.transform 10 0 env29169 = env29170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env29169 == env29170) = true)

def env29171 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,17,9,0,0,3,17,1,20,1,0,0,16,2,9,17,1,16,16,0,20,1,5,0,0,512]

theorem envBound29171 : H12AffineFastState.Bounded env29171 := by
  intro p hp
  have h : env29171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29170_29171 : H12AffineEnvironment.transform 9 20 env29170 = env29171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env29170 == env29171) = true)

theorem identity29171 : scanCanonicalize (H12AffineFastState.compose env29171 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound29171 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29172 : List Nat := [2,4,8,5,0,4,8,5,512,1,0,4,9,0,0,3,4,1,1,1,0,0,5,2,9,4,1,5,5,0,1,1,5,0,0,512]

theorem envBound29172 : H12AffineFastState.Bounded env29172 := by
  intro p hp
  have h : env29172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29171_29172 : H12AffineEnvironment.transform 3 5 env29171 = env29172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env29171 == env29172) = true)

def leafEnv29172 : List Nat := [2,4,8,5,0,4,8,5,512,1,0,4,9,0,0,3,4,1,1,1,0,0,5,2,1,9,1,4,1,5,5,0,1,1,5,0,4,3,0,512,1,0,0]

def active29172 : List Nat := [0,1,2,8]

def tree29172 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood29172 : H12WitnessSearch.Good tree29172 := H12GlobalWitnessIndex.good

theorem leafIdentity29172 : H12AffineFastState.composeSystem env29172 rootObs = leafEnv29172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env29172 rootObs == leafEnv29172) = true)

theorem terminalChecked29172 : H12PackedTerminal.terminalCheckFast leafEnv29172 active29172 tree29172 = true := by decide +kernel

def env29173 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,17,9,1,0,3,16,1,21,1,0,0,16,2,9,17,1,17,16,0,21,1,5,0,1,512]

theorem envBound29173 : H12AffineFastState.Bounded env29173 := by
  intro p hp
  have h : env29173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29170_29173 : H12AffineEnvironment.transform 9 21 env29170 = env29173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env29170 == env29173) = true)

theorem identity29173 : scanCanonicalize (H12AffineFastState.compose env29173 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound29173 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29174 : List Nat := [2,4,8,16,0,17,8,5,30,21,0,17,9,1,0,3,16,1,21,1,0,0,16,2,9,17,1,17,16,0,21,1,5,0,1,30]

theorem envBound29174 : H12AffineFastState.Bounded env29174 := by
  intro p hp
  have h : env29174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29173_29174 : H12AffineEnvironment.transform 8 30 env29173 = env29174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env29173 == env29174) = true)

def leafEnv29174 : List Nat := [2,4,8,16,0,17,8,5,30,21,0,17,9,1,0,3,16,1,21,1,0,0,16,2,21,9,1,17,1,17,16,0,21,1,5,0,4,3,1,30,1,0,0]

def active29174 : List Nat := [0,1,2,3]

def tree29174 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood29174 : H12WitnessSearch.Good tree29174 := H12GlobalWitnessIndex.good

theorem leafIdentity29174 : H12AffineFastState.composeSystem env29174 rootObs = leafEnv29174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env29174 rootObs == leafEnv29174) = true)

theorem terminalChecked29174 : H12PackedTerminal.terminalCheckFast leafEnv29174 active29174 tree29174 = true := by decide +kernel

def env29175 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4161,32,17,98645,8192,64,398436,5393,4097,431377,1365,41341,256,32,46092,74251]

theorem envBound29175 : H12AffineFastState.Bounded env29175 := by
  intro p hp
  have h : env29175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29153_29175 : H12AffineEnvironment.transform 20 4161 env29153 = env29175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env29153 == env29175) = true)

theorem identity29175 : scanCanonicalize (H12AffineFastState.compose env29175 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 108927) := by decide +kernel

theorem selectedBound29175 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29176 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,108927,1024,32769,4161,32,17,98645,8192,64,245019,5393,4097,212078,1365,41341,256,32,46092,74251]

theorem envBound29176 : H12AffineFastState.Bounded env29176 := by
  intro p hp
  have h : env29176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29175_29176 : H12AffineEnvironment.transform 17 108927 env29175 = env29176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108927 env29175 == env29176) = true)

theorem identity29176 : scanCanonicalize (H12AffineFastState.compose env29176 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound29176 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29177 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8202,131072,35189,1024,32769,4161,32,17,41311,8192,64,171281,5393,4097,138340,1365,41341,256,32,46092,513]

theorem envBound29177 : H12AffineFastState.Bounded env29177 := by
  intro p hp
  have h : env29177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29176_29177 : H12AffineEnvironment.transform 15 8202 env29176 = env29177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env29176 == env29177) = true)

theorem identity29177 : scanCanonicalize (H12AffineFastState.compose env29177 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 12637) := by decide +kernel

theorem selectedBound29177 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env29178 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8202,12637,35189,1024,32769,4161,32,17,41311,8192,64,44108,5393,4097,11577,1365,41341,256,32,46092,513]

theorem envBound29178 : H12AffineFastState.Bounded env29178 := by
  intro p hp
  have h : env29178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29177_29178 : H12AffineEnvironment.transform 16 12637 env29177 = env29178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12637 env29177 == env29178) = true)

theorem identity29178 : scanCanonicalize (H12AffineFastState.compose env29178 (packedSelected [0,7,16] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound29178 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env29179 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,5376,32768,1095,5392,35189,1024,32769,4161,32,17,34066,1101,64,34817,5393,4097,2420,1365,34096,256,32,36929,513]

theorem envBound29179 : H12AffineFastState.Bounded env29179 := by
  intro p hp
  have h : env29179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29178_29179 : H12AffineEnvironment.transform 12 1101 env29178 = env29179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env29178 == env29179) = true)

theorem identity29179 : scanCanonicalize (H12AffineFastState.compose env29179 (packedSelected [0,1,2,3,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 5685) := by decide +kernel

theorem selectedBound29179 : packedSelected [0,1,2,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env29180 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,5376,5685,1095,5392,8000,1024,5684,4161,32,17,4903,1101,64,7732,5393,4097,2420,1365,4869,256,32,1652,513]

theorem envBound29180 : H12AffineFastState.Bounded env29180 := by
  intro p hp
  have h : env29180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29179_29180 : H12AffineEnvironment.transform 14 5685 env29179 = env29180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5685 env29179 == env29180) = true)

def env29181 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,32,2101329,98645,8193,64,2491429,2098513,4097,2524496,2102549,2142524,256,33,46093,2175562]

theorem envBound29181 : H12AffineFastState.Bounded env29181 := by
  intro p hp
  have h : env29181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29152_29181 : H12AffineEnvironment.transform 6 9 env29152 = env29181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29152 == env29181) = true)

def env29182 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4160,32,17,98645,8193,64,398437,5393,4097,431376,1365,41340,256,33,46093,74250]

theorem envBound29182 : H12AffineFastState.Bounded env29182 := by
  intro p hp
  have h : env29182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29181_29182 : H12AffineEnvironment.transform 20 4160 env29181 = env29182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env29181 == env29182) = true)

theorem identity29182 : scanCanonicalize (H12AffineFastState.compose env29182 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound29182 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29183 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,67619,1024,32769,4160,32,17,98645,8193,64,203846,5393,4097,236851,1365,41340,256,33,46093,74250]

theorem envBound29183 : H12AffineFastState.Bounded env29183 := by
  intro p hp
  have h : env29183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29182_29183 : H12AffineEnvironment.transform 17 67619 env29182 = env29183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env29182 == env29183) = true)

theorem identity29183 : scanCanonicalize (H12AffineFastState.compose env29183 (packedSelected [1,3,8,9,12,18,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound29183 : packedSelected [1,3,8,9,12,18,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env29184 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8203,131072,10280,1024,32769,4160,32,17,41310,8193,64,146509,5393,4097,179512,1365,41340,256,33,46093,513]

theorem envBound29184 : H12AffineFastState.Bounded env29184 := by
  intro p hp
  have h : env29184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29183_29184 : H12AffineEnvironment.transform 15 8203 env29183 = env29184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env29183 == env29184) = true)

theorem identity29184 : scanCanonicalize (H12AffineFastState.compose env29184 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound29184 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env29185 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,32768,263,131072,2340,1024,32769,4160,32,17,32850,269,64,138561,5393,4097,171060,1365,32880,256,33,38145,513]

theorem envBound29185 : H12AffineFastState.Bounded env29185 := by
  intro p hp
  have h : env29185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29184_29185 : H12AffineEnvironment.transform 12 268 env29184 = env29185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env29184 == env29185) = true)

theorem identity29185 : scanCanonicalize (H12AffineFastState.compose env29185 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound29185 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env29186 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,32768,263,5441,2340,1024,32769,4160,32,17,32850,269,64,2048,5393,4097,35189,1365,32880,256,33,38145,513]

theorem envBound29186 : H12AffineFastState.Bounded env29186 := by
  intro p hp
  have h : env29186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29185_29186 : H12AffineEnvironment.transform 16 5441 env29185 = env29186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env29185 == env29186) = true)

def env29187 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4161,32,16,98645,8193,64,398436,5392,4097,431377,1364,41341,256,33,46093,74251]

theorem envBound29187 : H12AffineFastState.Bounded env29187 := by
  intro p hp
  have h : env29187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29181_29187 : H12AffineEnvironment.transform 20 4161 env29181 = env29187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env29181 == env29187) = true)

theorem identity29187 : scanCanonicalize (H12AffineFastState.compose env29187 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound29187 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29188 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,131072,262144,1024,32769,4161,32,16,41311,8193,64,398436,5392,4097,431377,1364,41341,256,33,46093,513]

theorem envBound29188 : H12AffineFastState.Bounded env29188 := by
  intro p hp
  have h : env29188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29187_29188 : H12AffineEnvironment.transform 15 8202 env29187 = env29188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env29187 == env29188) = true)

theorem identity29188 : scanCanonicalize (H12AffineFastState.compose env29188 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound29188 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env29189 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,131072,262144,1024,8541,4161,32,16,3,8193,64,398436,5392,4097,406605,1364,33,256,33,5457,513]

theorem envBound29189 : H12AffineFastState.Bounded env29189 := by
  intro p hp
  have h : env29189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29188_29189 : H12AffineEnvironment.transform 14 8540 env29188 = env29189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env29188 == env29189) = true)

theorem identity29189 : scanCanonicalize (H12AffineFastState.compose env29189 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound29189 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29190 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,5440,262144,1024,8541,4161,32,16,3,8193,64,262436,5392,4097,270605,1364,33,256,33,5457,513]

theorem envBound29190 : H12AffineFastState.Bounded env29190 := by
  intro p hp
  have h : env29190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29189_29190 : H12AffineEnvironment.transform 16 5440 env29189 = env29190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env29189 == env29190) = true)

theorem identity29190 : scanCanonicalize (H12AffineFastState.compose env29190 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 10361) := by decide +kernel

theorem selectedBound29190 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env29191 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,5440,10361,1024,8541,4161,32,16,3,8193,64,10589,5392,4097,2420,1364,33,256,33,5457,513]

theorem envBound29191 : H12AffineFastState.Bounded env29191 := by
  intro p hp
  have h : env29191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29190_29191 : H12AffineEnvironment.transform 17 10361 env29190 = env29191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10361 env29190 == env29191) = true)

def env29192 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,2097152,33,2101464,98645,8328,64,2491428,2098648,4097,2524496,2102684,2142525,256,168,46212,2175562]

theorem envBound29192 : H12AffineFastState.Bounded env29192 := by
  intro p hp
  have h : env29192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29151_29192 : H12AffineEnvironment.transform 21 33 env29151 = env29192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env29151 == env29192) = true)

theorem identity29192 : scanCanonicalize (H12AffineFastState.compose env29192 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 4296) := by decide +kernel

theorem selectedBound29192 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29193 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,4296,33,16,98645,8328,64,398572,5392,4097,431512,1364,41461,256,168,46212,74370]

theorem envBound29193 : H12AffineFastState.Bounded env29193 := by
  intro p hp
  have h : env29193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29192_29193 : H12AffineEnvironment.transform 20 4296 env29192 = env29193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4296 env29192 == env29193) = true)

def env29194 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,33,16,98645,8192,64,398436,5392,4097,431376,1364,41341,256,32,46092,74250]

theorem envBound29194 : H12AffineFastState.Bounded env29194 := by
  intro p hp
  have h : env29194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29193_29194 : H12AffineEnvironment.transform 6 8 env29193 = env29194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29193 == env29194) = true)

theorem identity29194 : scanCanonicalize (H12AffineFastState.compose env29194 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound29194 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29195 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,131072,262144,1024,32769,4160,33,16,2,8192,64,398436,5392,4097,431376,1364,41341,256,32,46092,41821]

theorem envBound29195 : H12AffineFastState.Bounded env29195 := by
  intro p hp
  have h : env29195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29194_29195 : H12AffineEnvironment.transform 15 33111 env29194 = env29195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env29194 == env29195) = true)

theorem identity29195 : scanCanonicalize (H12AffineFastState.compose env29195 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound29195 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env29196 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,46157,262144,1024,32769,4160,33,16,2,8192,64,303145,5392,4097,270685,1364,41341,256,32,46092,41821]

theorem envBound29196 : H12AffineFastState.Bounded env29196 := by
  intro p hp
  have h : env29196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29195_29196 : H12AffineEnvironment.transform 16 46157 env29195 = env29196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env29195 == env29196) = true)

theorem identity29196 : scanCanonicalize (H12AffineFastState.compose env29196 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound29196 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env29197 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,5393,262144,1024,8541,4160,33,16,2,8192,64,262517,5392,4097,270685,1364,33,256,32,5456,513]

theorem envBound29197 : H12AffineFastState.Bounded env29197 := by
  intro p hp
  have h : env29197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29196_29197 : H12AffineEnvironment.transform 14 8540 env29196 = env29197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env29196 == env29197) = true)

theorem identity29197 : scanCanonicalize (H12AffineFastState.compose env29197 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound29197 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29198 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,5393,10281,1024,8541,4160,33,16,2,8192,64,10588,5392,4097,2420,1364,33,256,32,5456,513]

theorem envBound29198 : H12AffineFastState.Bounded env29198 := by
  intro p hp
  have h : env29198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29197_29198 : H12AffineEnvironment.transform 17 10281 env29197 = env29198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env29197 == env29198) = true)

theorem identity29198 : scanCanonicalize (H12AffineFastState.compose env29198 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound29198 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env29199 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8,5376,340,3,5393,2081,1024,341,4160,33,16,2,8,64,2388,5392,4097,2420,1364,33,256,32,5456,513]

theorem envBound29199 : H12AffineFastState.Bounded env29199 := by
  intro p hp
  have h : env29199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29198_29199 : H12AffineEnvironment.transform 12 8 env29198 = env29199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env29198 == env29199) = true)

theorem identity29199 : scanCanonicalize (H12AffineFastState.compose env29199 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound29199 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29200 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8,4113,340,3,4096,2081,273,341,4160,33,16,2,8,64,2388,4097,4097,2420,69,33,256,32,4161,513]

theorem envBound29200 : H12AffineFastState.Bounded env29200 := by
  intro p hp
  have h : env29200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29199_29200 : H12AffineEnvironment.transform 9 273 env29199 = env29200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env29199 == env29200) = true)

theorem identity29200 : scanCanonicalize (H12AffineFastState.compose env29200 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound29200 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29201 : List Nat := [2,4,8,16,32,64,8,101,512,116,2048,4096,8,4113,49,3,4096,2081,116,48,4160,33,16,2,8,64,2097,4097,4097,2065,69,33,101,32,4161,513]

theorem envBound29201 : H12AffineFastState.Bounded env29201 := by
  intro p hp
  have h : env29201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29200_29201 : H12AffineEnvironment.transform 7 101 env29200 = env29201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env29200 == env29201) = true)

theorem identity29201 : scanCanonicalize (H12AffineFastState.compose env29201 (packedSelected [5] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound29201 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env29202 : List Nat := [2,4,8,16,32,64,8,101,512,116,2048,528,8,513,49,3,528,2081,116,48,592,33,16,2,8,64,2097,529,529,2065,69,33,101,32,593,513]

theorem envBound29202 : H12AffineFastState.Bounded env29202 := by
  intro p hp
  have h : env29202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29201_29202 : H12AffineEnvironment.transform 11 528 env29201 = env29202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env29201 == env29202) = true)

theorem identity29202 : scanCanonicalize (H12AffineFastState.compose env29202 (packedSelected [0,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 608) := by decide +kernel

theorem selectedBound29202 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env29203 : List Nat := [2,4,8,16,32,64,8,101,512,116,608,528,8,513,49,3,528,577,116,48,592,33,16,2,8,64,593,529,529,625,69,33,101,32,593,513]

theorem envBound29203 : H12AffineFastState.Bounded env29203 := by
  intro p hp
  have h : env29203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29202_29203 : H12AffineEnvironment.transform 10 608 env29202 = env29203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 608 env29202 == env29203) = true)

theorem identity29203 : scanCanonicalize (H12AffineFastState.compose env29203 (packedSelected [0,1,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29203 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env29204 : List Nat := [2,4,8,16,32,17,8,52,512,37,561,528,8,513,49,3,528,528,37,48,513,33,16,2,8,17,512,529,529,544,20,33,52,32,512,513]

theorem envBound29204 : H12AffineFastState.Bounded env29204 := by
  intro p hp
  have h : env29204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29203_29204 : H12AffineEnvironment.transform 5 17 env29203 = env29204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29203 == env29204) = true)

theorem identity29204 : scanCanonicalize (H12AffineFastState.compose env29204 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound29204 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29205 : List Nat := [2,4,8,16,32,17,8,52,16,37,33,0,8,17,49,3,0,0,37,48,17,33,16,2,8,17,16,1,1,48,20,33,52,32,16,17]

theorem envBound29205 : H12AffineFastState.Bounded env29205 := by
  intro p hp
  have h : env29205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29204_29205 : H12AffineEnvironment.transform 8 16 env29204 = env29205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env29204 == env29205) = true)

theorem identity29205 : scanCanonicalize (H12AffineFastState.compose env29205 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound29205 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29206 : List Nat := [2,4,8,16,1,17,8,21,16,4,0,0,8,17,16,3,0,0,4,17,17,0,16,2,8,17,16,1,1,17,20,0,21,1,16,17]

theorem envBound29206 : H12AffineFastState.Bounded env29206 := by
  intro p hp
  have h : env29206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29205_29206 : H12AffineEnvironment.transform 4 1 env29205 = env29206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env29205 == env29206) = true)

theorem identity29206 : scanCanonicalize (H12AffineFastState.compose env29206 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29206 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29207 : List Nat := [2,4,8,1,1,0,8,4,1,4,0,0,8,0,1,3,0,0,4,0,0,0,1,2,8,0,1,1,1,0,5,0,4,1,1,0]

theorem envBound29207 : H12AffineFastState.Bounded env29207 := by
  intro p hp
  have h : env29207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29206_29207 : H12AffineEnvironment.transform 3 1 env29206 = env29207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29206 == env29207) = true)

def env29208 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4161,33,16,98645,8193,64,398437,5392,4097,431377,1364,41340,256,33,46093,74251]

theorem envBound29208 : H12AffineFastState.Bounded env29208 := by
  intro p hp
  have h : env29208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29193_29208 : H12AffineEnvironment.transform 6 9 env29193 = env29208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29193 == env29208) = true)

theorem identity29208 : scanCanonicalize (H12AffineFastState.compose env29208 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound29208 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29209 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,131072,262144,1024,32769,4161,33,16,41311,8193,64,398437,5392,4097,431377,1364,41340,256,33,46093,513]

theorem envBound29209 : H12AffineFastState.Bounded env29209 := by
  intro p hp
  have h : env29209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29208_29209 : H12AffineEnvironment.transform 15 8202 env29208 = env29209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env29208 == env29209) = true)

theorem identity29209 : scanCanonicalize (H12AffineFastState.compose env29209 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound29209 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env29210 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,131072,262144,1024,8541,4161,33,16,3,8193,64,398437,5392,4097,406605,1364,32,256,33,5457,513]

theorem envBound29210 : H12AffineFastState.Bounded env29210 := by
  intro p hp
  have h : env29210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29209_29210 : H12AffineEnvironment.transform 14 8540 env29209 = env29210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env29209 == env29210) = true)

theorem identity29210 : scanCanonicalize (H12AffineFastState.compose env29210 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound29210 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29211 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,5440,262144,1024,8541,4161,33,16,3,8193,64,262437,5392,4097,270605,1364,32,256,33,5457,513]

theorem envBound29211 : H12AffineFastState.Bounded env29211 := by
  intro p hp
  have h : env29211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29210_29211 : H12AffineEnvironment.transform 16 5440 env29210 = env29211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env29210 == env29211) = true)

theorem identity29211 : scanCanonicalize (H12AffineFastState.compose env29211 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound29211 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env29212 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,5440,2421,1024,8541,4161,33,16,3,8193,64,2128,5392,4097,10360,1364,32,256,33,5457,513]

theorem envBound29212 : H12AffineFastState.Bounded env29212 := by
  intro p hp
  have h : env29212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29211_29212 : H12AffineEnvironment.transform 17 2421 env29211 = env29212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env29211 == env29212) = true)

theorem identity29212 : scanCanonicalize (H12AffineFastState.compose env29212 (packedSelected [11,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound29212 : packedSelected [11,15] rootPS < 2^1333 := by decide +kernel

def env29213 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,0,342,5440,2421,1024,1,4161,33,16,3,349,64,2128,5392,4097,2340,1364,32,256,33,5457,513]

theorem envBound29213 : H12AffineFastState.Bounded env29213 := by
  intro p hp
  have h : env29213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29212_29213 : H12AffineEnvironment.transform 12 348 env29212 = env29213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env29212 == env29213) = true)

theorem identity29213 : scanCanonicalize (H12AffineFastState.compose env29213 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3077) := by decide +kernel

theorem selectedBound29213 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env29214 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3077,348,2308,0,342,2373,2421,1024,1,3140,33,16,3,349,64,2128,2325,3076,2340,1364,32,256,33,2388,513]

theorem envBound29214 : H12AffineFastState.Bounded env29214 := by
  intro p hp
  have h : env29214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29213_29214 : H12AffineEnvironment.transform 11 3077 env29213 = env29214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3077 env29213 == env29214) = true)

theorem identity29214 : scanCanonicalize (H12AffineFastState.compose env29214 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound29214 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env29215 : List Nat := [2,4,8,16,32,64,9,4,512,1024,2048,3077,88,2048,0,82,2113,2161,1024,1,3140,33,16,3,89,64,2128,2065,3076,2080,1104,32,4,33,2128,513]

theorem envBound29215 : H12AffineFastState.Bounded env29215 := by
  intro p hp
  have h : env29215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29214_29215 : H12AffineEnvironment.transform 7 4 env29214 = env29215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env29214 == env29215) = true)

theorem identity29215 : scanCanonicalize (H12AffineFastState.compose env29215 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound29215 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env29216 : List Nat := [2,4,8,16,32,64,9,4,65,1024,2048,3077,88,2048,0,82,2113,2161,1024,1,3140,33,16,3,89,64,2128,2065,3076,2080,1104,32,4,33,2128,64]

theorem envBound29216 : H12AffineFastState.Bounded env29216 := by
  intro p hp
  have h : env29216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29215_29216 : H12AffineEnvironment.transform 8 65 env29215 = env29216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env29215 == env29216) = true)

theorem identity29216 : scanCanonicalize (H12AffineFastState.compose env29216 (packedSelected [0,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound29216 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env29217 : List Nat := [2,4,8,16,32,64,9,4,65,21,2048,2064,88,2048,0,82,2113,2161,21,1,2129,33,16,3,89,64,2128,2065,2065,2080,69,32,4,33,2128,64]

theorem envBound29217 : H12AffineFastState.Bounded env29217 := by
  intro p hp
  have h : env29217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29216_29217 : H12AffineEnvironment.transform 9 21 env29216 = env29217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env29216 == env29217) = true)

theorem identity29217 : scanCanonicalize (H12AffineFastState.compose env29217 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound29217 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env29218 : List Nat := [2,4,8,16,32,64,9,4,65,21,0,16,88,0,0,82,65,113,21,1,81,33,16,3,89,64,80,17,17,32,69,32,4,33,80,64]

theorem envBound29218 : H12AffineFastState.Bounded env29218 := by
  intro p hp
  have h : env29218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29217_29218 : H12AffineEnvironment.transform 10 0 env29217 = env29218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env29217 == env29218) = true)

theorem identity29218 : scanCanonicalize (H12AffineFastState.compose env29218 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound29218 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29219 : List Nat := [2,4,8,16,32,32,9,4,33,21,0,16,56,0,0,50,33,17,21,1,49,33,16,3,57,32,48,17,17,32,37,32,4,33,48,32]

theorem envBound29219 : H12AffineFastState.Bounded env29219 := by
  intro p hp
  have h : env29219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29218_29219 : H12AffineEnvironment.transform 5 32 env29218 = env29219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env29218 == env29219) = true)

theorem identity29219 : scanCanonicalize (H12AffineFastState.compose env29219 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound29219 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env29220 : List Nat := [2,4,8,16,17,17,9,4,16,21,0,16,9,0,0,3,16,17,21,1,0,16,16,3,8,17,1,17,17,17,20,17,4,16,1,17]

theorem envBound29220 : H12AffineFastState.Bounded env29220 := by
  intro p hp
  have h : env29220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29219_29220 : H12AffineEnvironment.transform 4 17 env29219 = env29220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env29219 == env29220) = true)

def env29221 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,2097152,4194304,2101465,98644,8328,64,6685701,2098649,4096,2524497,2102684,6336797,256,168,46212,2175562]

theorem envBound29221 : H12AffineFastState.Bounded env29221 := by
  intro p hp
  have h : env29221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29150_29221 : H12AffineEnvironment.transform 22 2101465 env29150 = env29221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101465 env29150 == env29221) = true)

def env29222 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,2097152,32,2101465,98644,8328,64,2491429,2098649,4096,2524497,2102684,2142525,256,168,46212,2175562]

theorem envBound29222 : H12AffineFastState.Bounded env29222 := by
  intro p hp
  have h : env29222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29221_29222 : H12AffineEnvironment.transform 21 32 env29221 = env29222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env29221 == env29222) = true)

theorem identity29222 : scanCanonicalize (H12AffineFastState.compose env29222 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound29222 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29223 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,65536,131072,262144,1024,8541,2097152,32,2101465,73736,8328,64,2491429,2098649,4096,2499597,2102684,2101345,256,168,5592,2175562]

theorem envBound29223 : H12AffineFastState.Bounded env29223 := by
  intro p hp
  have h : env29223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29222_29223 : H12AffineEnvironment.transform 14 8540 env29222 = env29223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env29222 == env29223) = true)

def env29224 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,65536,131072,10400,1024,8541,2097152,32,2101465,73736,8328,64,2239621,2098649,4096,2231469,2102684,2101345,256,168,5592,2175562]

theorem envBound29224 : H12AffineFastState.Bounded env29224 := by
  intro p hp
  have h : env29224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29223_29224 : H12AffineEnvironment.transform 17 10400 env29223 = env29224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env29223 == env29224) = true)

theorem identity29224 : scanCanonicalize (H12AffineFastState.compose env29224 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound29224 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29225 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,8322,131072,10400,1024,8541,2097152,32,2101465,138,8328,64,2239621,2098649,4096,2231469,2102684,2101345,256,168,5592,2101960]

theorem envBound29225 : H12AffineFastState.Bounded env29225 := by
  intro p hp
  have h : env29225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29224_29225 : H12AffineEnvironment.transform 15 8322 env29224 = env29225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env29224 == env29225) = true)

theorem identity29225 : scanCanonicalize (H12AffineFastState.compose env29225 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound29225 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env29226 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,8322,5392,10400,1024,8541,2097152,32,2101465,138,8328,64,2111893,2098649,4096,2103741,2102684,2101345,256,168,5592,2101960]

theorem envBound29226 : H12AffineFastState.Bounded env29226 := by
  intro p hp
  have h : env29226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29225_29226 : H12AffineEnvironment.transform 16 5392 env29225 = env29226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env29225 == env29226) = true)

theorem identity29226 : scanCanonicalize (H12AffineFastState.compose env29226 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound29226 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env29227 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5512,81,399,5392,2477,1024,80,2097152,32,2101465,138,389,64,2103448,2098649,4096,2103741,2102684,2101345,256,168,5592,2101960]

theorem envBound29227 : H12AffineFastState.Bounded env29227 := by
  intro p hp
  have h : env29227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29226_29227 : H12AffineEnvironment.transform 12 269 env29226 = env29227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env29226 == env29227) = true)

theorem identity29227 : scanCanonicalize (H12AffineFastState.compose env29227 (packedSelected [10,11,12,14,15,16,18,19] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound29227 : packedSelected [10,11,12,14,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env29228 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5512,81,399,5392,2477,1024,80,4161,32,152,138,389,64,2265,5528,4096,2556,1501,32,256,168,5592,649]

theorem envBound29228 : H12AffineFastState.Bounded env29228 := by
  intro p hp
  have h : env29228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29227_29228 : H12AffineEnvironment.transform 20 4161 env29227 = env29228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env29227 == env29228) = true)

theorem identity29228 : scanCanonicalize (H12AffineFastState.compose env29228 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound29228 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env29229 : List Nat := [2,4,8,16,32,64,128,256,512,188,2048,4096,269,4404,81,399,4524,2477,188,80,4161,32,152,138,389,64,2265,4388,4096,2556,353,32,256,168,4452,649]

theorem envBound29229 : H12AffineFastState.Bounded env29229 := by
  intro p hp
  have h : env29229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29228_29229 : H12AffineEnvironment.transform 9 188 env29228 = env29229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env29228 == env29229) = true)

theorem identity29229 : scanCanonicalize (H12AffineFastState.compose env29229 (packedSelected [0,1,3,4,5,6,7,8,9,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2248) := by decide +kernel

theorem selectedBound29229 : packedSelected [0,1,3,4,5,6,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env29230 : List Nat := [2,4,8,16,32,64,128,256,512,188,2048,2248,269,2556,81,399,2404,2477,188,80,2185,32,152,138,389,64,2265,2540,2248,2556,353,32,256,168,2476,649]

theorem envBound29230 : H12AffineFastState.Bounded env29230 := by
  intro p hp
  have h : env29230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29229_29230 : H12AffineEnvironment.transform 11 2248 env29229 = env29230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2248 env29229 == env29230) = true)

theorem identity29230 : scanCanonicalize (H12AffineFastState.compose env29230 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound29230 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env29231 : List Nat := [2,4,8,16,32,64,128,37,512,188,2048,2248,40,2265,81,170,2113,2184,188,80,2185,32,152,138,160,64,2265,2249,2248,2265,68,32,37,168,2185,649]

theorem envBound29231 : H12AffineFastState.Bounded env29231 := by
  intro p hp
  have h : env29231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29230_29231 : H12AffineEnvironment.transform 7 37 env29230 = env29231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env29230 == env29231) = true)

theorem identity29231 : scanCanonicalize (H12AffineFastState.compose env29231 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound29231 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env29232 : List Nat := [2,4,8,16,32,64,8,37,512,52,2048,2112,40,2129,81,34,2113,2048,52,80,2049,32,16,2,40,64,2129,2113,2112,2129,68,32,37,32,2049,513]

theorem envBound29232 : H12AffineFastState.Bounded env29232 := by
  intro p hp
  have h : env29232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29231_29232 : H12AffineEnvironment.transform 6 8 env29231 = env29232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29231 == env29232) = true)

theorem identity29232 : scanCanonicalize (H12AffineFastState.compose env29232 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29232 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29233 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,2064,40,2049,1,34,2065,2048,52,0,2049,32,16,2,40,16,2049,2065,2064,2049,20,32,37,32,2049,513]

theorem envBound29233 : H12AffineFastState.Bounded env29233 := by
  intro p hp
  have h : env29233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29232_29233 : H12AffineEnvironment.transform 5 16 env29232 = env29233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29232 == env29233) = true)

theorem identity29233 : scanCanonicalize (H12AffineFastState.compose env29233 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound29233 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29234 : List Nat := [2,4,8,16,32,16,8,37,512,52,529,513,40,528,1,34,512,529,52,0,528,32,16,2,40,16,528,512,513,528,20,32,37,32,528,513]

theorem envBound29234 : H12AffineFastState.Bounded env29234 := by
  intro p hp
  have h : env29234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29233_29234 : H12AffineEnvironment.transform 10 529 env29233 = env29234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env29233 == env29234) = true)

theorem identity29234 : scanCanonicalize (H12AffineFastState.compose env29234 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound29234 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29235 : List Nat := [2,4,8,16,32,16,8,37,27,52,10,26,40,11,1,34,27,10,52,0,11,32,16,2,40,16,11,27,26,11,20,32,37,32,11,26]

theorem envBound29235 : H12AffineFastState.Bounded env29235 := by
  intro p hp
  have h : env29235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29234_29235 : H12AffineEnvironment.transform 8 27 env29234 = env29235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env29234 == env29235) = true)

def env29236 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,65536,131072,10401,1024,8541,2097152,32,2101465,73736,8328,64,2239620,2098649,4096,2231468,2102684,2101345,256,168,5592,2175562]

theorem envBound29236 : H12AffineFastState.Bounded env29236 := by
  intro p hp
  have h : env29236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29223_29236 : H12AffineEnvironment.transform 17 10401 env29223 = env29236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env29223 == env29236) = true)

theorem identity29236 : scanCanonicalize (H12AffineFastState.compose env29236 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound29236 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29237 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,65536,131072,10401,1024,8541,77899,32,73874,73736,8328,64,203983,79250,4096,212199,75223,73770,256,168,5592,513]

theorem envBound29237 : H12AffineFastState.Bounded env29237 := by
  intro p hp
  have h : env29237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29236_29237 : H12AffineEnvironment.transform 20 77899 env29236 = env29237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env29236 == env29237) = true)

theorem identity29237 : scanCanonicalize (H12AffineFastState.compose env29237 (packedSelected [0,1,7,8,10,12,14,16,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 13509) := by decide +kernel

theorem selectedBound29237 : packedSelected [0,1,7,8,10,12,14,16,20,23] rootPS < 2^1333 := by decide +kernel

def env29238 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,65536,13509,10401,1024,8541,77899,32,73874,73736,8328,64,75786,79250,4096,67618,75223,73770,256,168,5592,513]

theorem envBound29238 : H12AffineFastState.Bounded env29238 := by
  intro p hp
  have h : env29238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29237_29238 : H12AffineEnvironment.transform 16 13509 env29237 = env29238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env29237 == env29238) = true)

theorem identity29238 : scanCanonicalize (H12AffineFastState.compose env29238 (packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound29238 : packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS < 2^1333 := by decide +kernel

def env29239 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,136,65536,5393,2421,1024,137,70047,32,65862,66012,348,64,68062,70726,4096,67618,66563,66046,256,168,5592,513]

theorem envBound29239 : H12AffineFastState.Bounded env29239 := by
  intro p hp
  have h : env29239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29238_29239 : H12AffineEnvironment.transform 12 468 env29238 = env29239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env29238 == env29239) = true)

theorem identity29239 : scanCanonicalize (H12AffineFastState.compose env29239 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound29239 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env29240 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,136,478,5393,2421,1024,137,4161,32,152,2,348,64,2048,5528,4096,2556,1501,32,256,168,5592,513]

theorem envBound29240 : H12AffineFastState.Bounded env29240 := by
  intro p hp
  have h : env29240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29239_29240 : H12AffineEnvironment.transform 15 478 env29239 = env29240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env29239 == env29240) = true)

theorem identity29240 : scanCanonicalize (H12AffineFastState.compose env29240 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound29240 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env29241 : List Nat := [2,4,8,16,32,48,128,256,512,1024,2048,4096,420,5512,136,430,5393,2309,1024,137,4145,32,152,2,300,48,2048,5528,4096,2444,1453,32,256,168,5544,513]

theorem envBound29241 : H12AffineFastState.Bounded env29241 := by
  intro p hp
  have h : env29241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29240_29241 : H12AffineEnvironment.transform 5 48 env29240 = env29241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env29240 == env29241) = true)

theorem identity29241 : scanCanonicalize (H12AffineFastState.compose env29241 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound29241 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env29242 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,4096,301,5377,1,295,5393,2309,1024,0,4145,32,17,2,300,48,2048,5393,4096,2309,1316,32,256,33,5409,513]

theorem envBound29242 : H12AffineFastState.Bounded env29242 := by
  intro p hp
  have h : env29242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29241_29242 : H12AffineEnvironment.transform 6 9 env29241 = env29242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29241 == env29242) = true)

theorem identity29242 : scanCanonicalize (H12AffineFastState.compose env29242 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound29242 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29243 : List Nat := [2,4,8,16,32,48,9,256,261,1024,2048,4096,301,5377,1,295,5393,2309,1024,0,4145,32,17,2,300,48,2048,5393,4096,2309,1316,32,256,33,5409,260]

theorem envBound29243 : H12AffineFastState.Bounded env29243 := by
  intro p hp
  have h : env29243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29242_29243 : H12AffineEnvironment.transform 8 261 env29242 = env29243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env29242 == env29243) = true)

def env29244 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,2097152,33,2101465,98644,8328,64,2491428,2098649,4096,2524497,2102684,2142524,256,168,46212,2175562]

theorem envBound29244 : H12AffineFastState.Bounded env29244 := by
  intro p hp
  have h : env29244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29221_29244 : H12AffineEnvironment.transform 21 33 env29221 = env29244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env29221 == env29244) = true)

theorem identity29244 : scanCanonicalize (H12AffineFastState.compose env29244 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 45461) := by decide +kernel

theorem selectedBound29244 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,45461,33,41292,98644,8328,64,439729,46156,4096,406724,41993,169,256,168,46212,99295]

theorem envBound29245 : H12AffineFastState.Bounded env29245 := by
  intro p hp
  have h : env29245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29244_29245 : H12AffineEnvironment.transform 20 45461 env29244 = env29245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 45461 env29244 == env29245) = true)

theorem identity29245 : scanCanonicalize (H12AffineFastState.compose env29245 (packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 108927) := by decide +kernel

theorem selectedBound29245 : packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env29246 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,108927,1024,32769,45461,33,41292,98644,8328,64,203982,46156,4096,236987,41993,169,256,168,46212,99295]

theorem envBound29246 : H12AffineFastState.Bounded env29246 := by
  intro p hp
  have h : env29246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29245_29246 : H12AffineEnvironment.transform 17 108927 env29245 = env29246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108927 env29245 == env29246) = true)

theorem identity29246 : scanCanonicalize (H12AffineFastState.compose env29246 (packedSelected [1,3,4,7,9,11,12,15,18,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound29246 : packedSelected [1,3,4,7,9,11,12,15,18,24,27,28] rootPS < 2^1333 := by decide +kernel

def env29247 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33246,131072,10401,1024,32769,45461,33,41292,138,8328,64,171280,46156,4096,138341,41993,169,256,168,46212,513]

theorem envBound29247 : H12AffineFastState.Bounded env29247 := by
  intro p hp
  have h : env29247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29246_29247 : H12AffineEnvironment.transform 15 33246 env29246 = env29247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env29246 == env29247) = true)

theorem identity29247 : scanCanonicalize (H12AffineFastState.compose env29247 (packedSelected [4,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound29247 : packedSelected [4,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env29248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33246,13340,10401,1024,32769,45461,33,41292,138,8328,64,43276,46156,4096,10361,41993,169,256,168,46212,513]

theorem envBound29248 : H12AffineFastState.Bounded env29248 := by
  intro p hp
  have h : env29248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29247_29248 : H12AffineEnvironment.transform 16 13340 env29247 = env29248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env29247 == env29248) = true)

theorem identity29248 : scanCanonicalize (H12AffineFastState.compose env29248 (packedSelected [0,1,7,8,10,11,14,15,16,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound29248 : packedSelected [0,1,7,8,10,11,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env29249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5512,32768,33246,5392,2477,1024,32769,37017,33,32832,138,388,64,34816,38208,4096,2421,34053,169,256,168,38280,513]

theorem envBound29249 : H12AffineFastState.Bounded env29249 := by
  intro p hp
  have h : env29249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29248_29249 : H12AffineEnvironment.transform 12 268 env29248 = env29249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env29248 == env29249) = true)

def env29250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10588556,8328,64,6685701,8393985,10485976,8820105,2102685,12624324,256,168,46213,2175563]

theorem envBound29250 : H12AffineFastState.Bounded env29250 := by
  intro p hp
  have h : env29250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29149_29250 : H12AffineEnvironment.transform 13 5513 env29149 = env29250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env29149 == env29250) = true)

def env29251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,2097152,4194304,2101464,98644,8328,64,6685701,2098649,4096,2524497,2102685,6336796,256,168,46213,2175563]

theorem envBound29251 : H12AffineFastState.Bounded env29251 := by
  intro p hp
  have h : env29251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29250_29251 : H12AffineEnvironment.transform 22 2101464 env29250 = env29251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101464 env29250 == env29251) = true)

def env29252 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,2097152,32,2101464,98644,8328,64,2491429,2098649,4096,2524497,2102685,2142524,256,168,46213,2175563]

theorem envBound29252 : H12AffineFastState.Bounded env29252 := by
  intro p hp
  have h : env29252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29251_29252 : H12AffineEnvironment.transform 21 32 env29251 = env29252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env29251 == env29252) = true)

theorem identity29252 : scanCanonicalize (H12AffineFastState.compose env29252 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 102678) := by decide +kernel

theorem selectedBound29252 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29253 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,102678,32,98766,98644,8328,64,496947,103631,4096,463943,99467,73770,256,168,46213,41821]

theorem envBound29253 : H12AffineFastState.Bounded env29253 := by
  intro p hp
  have h : env29253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29252_29253 : H12AffineEnvironment.transform 20 102678 env29252 = env29253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 102678 env29252 == env29253) = true)

theorem identity29253 : scanCanonicalize (H12AffineFastState.compose env29253 (packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,21,23,24,26,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound29253 : packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,21,23,24,26,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env29254 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,65536,131072,262144,1024,8541,77898,32,73874,73736,8328,64,472175,79251,4096,463943,75223,73770,256,168,5593,513]

theorem envBound29254 : H12AffineFastState.Bounded env29254 := by
  intro p hp
  have h : env29254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29253_29254 : H12AffineEnvironment.transform 14 8540 env29253 = env29254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env29253 == env29254) = true)

def env29255 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,65536,131072,10400,1024,8541,77898,32,73874,73736,8328,64,203983,79251,4096,212199,75223,73770,256,168,5593,513]

theorem envBound29255 : H12AffineFastState.Bounded env29255 := by
  intro p hp
  have h : env29255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29254_29255 : H12AffineEnvironment.transform 17 10400 env29254 = env29255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env29254 == env29255) = true)

theorem identity29255 : scanCanonicalize (H12AffineFastState.compose env29255 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound29255 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29256 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,8322,131072,10400,1024,8541,4296,32,16,138,8328,64,146509,5393,4096,138341,1365,168,256,168,5593,513]

theorem envBound29256 : H12AffineFastState.Bounded env29256 := by
  intro p hp
  have h : env29256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29255_29256 : H12AffineEnvironment.transform 15 8322 env29255 = env29256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env29255 == env29256) = true)

theorem identity29256 : scanCanonicalize (H12AffineFastState.compose env29256 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound29256 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env29257 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1337,5513,1125,1467,131072,3481,1024,1124,4296,32,16,138,1457,64,137588,5393,4096,138341,1365,168,256,168,5593,513]

theorem envBound29257 : H12AffineFastState.Bounded env29257 := by
  intro p hp
  have h : env29257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29256_29257 : H12AffineEnvironment.transform 12 1337 env29256 = env29257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env29256 == env29257) = true)

theorem identity29257 : scanCanonicalize (H12AffineFastState.compose env29257 (packedSelected [12,15] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound29257 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env29258 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,160,4112,508,34,131072,2048,409,509,4296,32,16,138,40,64,137588,4232,4096,137724,204,168,256,168,4160,513]

theorem envBound29258 : H12AffineFastState.Bounded env29258 := by
  intro p hp
  have h : env29258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29257_29258 : H12AffineEnvironment.transform 9 409 env29257 = env29258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env29257 == env29258) = true)

theorem identity29258 : scanCanonicalize (H12AffineFastState.compose env29258 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(16+1) ^^^ 4389) := by decide +kernel

theorem selectedBound29258 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env29259 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,160,4112,508,34,4389,2048,409,509,4296,32,16,138,40,64,2129,4232,4096,2265,204,168,256,168,4160,513]

theorem envBound29259 : H12AffineFastState.Bounded env29259 := by
  intro p hp
  have h : env29259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29258_29259 : H12AffineEnvironment.transform 16 4389 env29258 = env29259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4389 env29258 == env29259) = true)

theorem identity29259 : scanCanonicalize (H12AffineFastState.compose env29259 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound29259 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env29260 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,17,160,1,508,34,308,2048,409,509,217,32,16,138,40,64,2129,153,17,2265,204,168,256,168,81,513]

theorem envBound29260 : H12AffineFastState.Bounded env29260 := by
  intro p hp
  have h : env29260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29259_29260 : H12AffineEnvironment.transform 11 17 env29259 = env29260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env29259 == env29260) = true)

theorem identity29260 : scanCanonicalize (H12AffineFastState.compose env29260 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound29260 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env29261 : List Nat := [2,4,8,16,32,64,128,173,512,52,2048,17,160,1,81,34,153,2048,52,80,217,32,16,138,40,64,2129,153,17,2265,204,168,173,168,81,513]

theorem envBound29261 : H12AffineFastState.Bounded env29261 := by
  intro p hp
  have h : env29261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29260_29261 : H12AffineEnvironment.transform 7 173 env29260 = env29261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env29260 == env29261) = true)

theorem identity29261 : scanCanonicalize (H12AffineFastState.compose env29261 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound29261 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env29262 : List Nat := [2,4,8,16,32,64,128,173,512,52,1,17,160,1,81,34,153,1,52,80,217,32,16,138,40,64,80,153,17,216,204,168,173,168,81,513]

theorem envBound29262 : H12AffineFastState.Bounded env29262 := by
  intro p hp
  have h : env29262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29261_29262 : H12AffineEnvironment.transform 10 1 env29261 = env29262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env29261 == env29262) = true)

theorem identity29262 : scanCanonicalize (H12AffineFastState.compose env29262 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound29262 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env29263 : List Nat := [2,4,8,16,32,64,8,37,512,52,1,17,40,1,81,34,17,1,52,80,81,32,16,2,40,64,80,17,17,80,68,32,37,32,81,513]

theorem envBound29263 : H12AffineFastState.Bounded env29263 := by
  intro p hp
  have h : env29263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29262_29263 : H12AffineEnvironment.transform 6 8 env29262 = env29263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29262 == env29263) = true)

theorem identity29263 : scanCanonicalize (H12AffineFastState.compose env29263 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29263 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29264 : List Nat := [2,4,8,16,32,16,8,37,512,52,1,17,40,1,1,34,17,1,52,0,1,32,16,2,40,16,0,17,17,0,20,32,37,32,1,513]

theorem envBound29264 : H12AffineFastState.Bounded env29264 := by
  intro p hp
  have h : env29264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29263_29264 : H12AffineEnvironment.transform 5 16 env29263 = env29264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29263 == env29264) = true)

theorem identity29264 : scanCanonicalize (H12AffineFastState.compose env29264 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound29264 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29265 : List Nat := [2,4,8,16,32,16,8,37,33,52,1,17,40,1,1,34,17,1,52,0,1,32,16,2,40,16,0,17,17,0,20,32,37,32,1,32]

theorem envBound29265 : H12AffineFastState.Bounded env29265 := by
  intro p hp
  have h : env29265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29264_29265 : H12AffineEnvironment.transform 8 33 env29264 = env29265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env29264 == env29265) = true)

theorem identity29265 : scanCanonicalize (H12AffineFastState.compose env29265 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound29265 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29266 : List Nat := [2,4,8,16,1,16,8,4,0,21,1,17,9,1,1,3,17,1,21,0,1,1,16,2,9,16,0,17,17,0,20,1,4,1,1,1]

theorem envBound29266 : H12AffineFastState.Bounded env29266 := by
  intro p hp
  have h : env29266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29265_29266 : H12AffineEnvironment.transform 4 1 env29265 = env29266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env29265 == env29266) = true)

def env29267 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,65536,131072,10401,1024,8541,77898,32,73874,73736,8328,64,203982,79251,4096,212198,75223,73770,256,168,5593,513]

theorem envBound29267 : H12AffineFastState.Bounded env29267 := by
  intro p hp
  have h : env29267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29254_29267 : H12AffineEnvironment.transform 17 10401 env29254 = env29267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env29254 == env29267) = true)

theorem identity29267 : scanCanonicalize (H12AffineFastState.compose env29267 (packedSelected [0,1,7,8,10,12,14,16,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound29267 : packedSelected [0,1,7,8,10,12,14,16,20,23] rootPS < 2^1333 := by decide +kernel

def env29268 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,65536,13508,10401,1024,8541,77898,32,73874,73736,8328,64,75786,79251,4096,67618,75223,73770,256,168,5593,513]

theorem envBound29268 : H12AffineFastState.Bounded env29268 := by
  intro p hp
  have h : env29268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29267_29268 : H12AffineEnvironment.transform 16 13508 env29267 = env29268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env29267 == env29268) = true)

theorem identity29268 : scanCanonicalize (H12AffineFastState.compose env29268 (packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound29268 : packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS < 2^1333 := by decide +kernel

def env29269 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,136,65536,5392,2421,1024,137,70046,32,65862,66012,348,64,68062,70727,4096,67618,66563,66046,256,168,5593,513]

theorem envBound29269 : H12AffineFastState.Bounded env29269 := by
  intro p hp
  have h : env29269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29268_29269 : H12AffineEnvironment.transform 12 468 env29268 = env29269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env29268 == env29269) = true)

theorem identity29269 : scanCanonicalize (H12AffineFastState.compose env29269 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound29269 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env29270 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,136,478,5392,2421,1024,137,4160,32,152,2,348,64,2048,5529,4096,2556,1501,32,256,168,5593,513]

theorem envBound29270 : H12AffineFastState.Bounded env29270 := by
  intro p hp
  have h : env29270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29269_29270 : H12AffineEnvironment.transform 15 478 env29269 = env29270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env29269 == env29270) = true)

theorem identity29270 : scanCanonicalize (H12AffineFastState.compose env29270 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound29270 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env29271 : List Nat := [2,4,8,16,32,64,120,256,512,1024,2048,4096,300,5489,112,294,5392,2421,1024,113,4160,32,96,2,348,64,2048,5473,4096,2308,1317,32,256,80,5409,513]

theorem envBound29271 : H12AffineFastState.Bounded env29271 := by
  intro p hp
  have h : env29271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29270_29271 : H12AffineEnvironment.transform 6 120 env29270 = env29271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env29270 == env29271) = true)

theorem identity29271 : scanCanonicalize (H12AffineFastState.compose env29271 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound29271 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env29272 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,300,5376,1,294,5392,2308,1024,0,4145,32,17,2,301,49,2048,5392,4096,2308,1317,32,256,33,5409,513]

theorem envBound29272 : H12AffineFastState.Bounded env29272 := by
  intro p hp
  have h : env29272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29271_29272 : H12AffineEnvironment.transform 5 49 env29271 = env29272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env29271 == env29272) = true)

theorem identity29272 : scanCanonicalize (H12AffineFastState.compose env29272 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound29272 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29273 : List Nat := [2,4,8,16,32,49,9,256,261,1024,2048,4096,300,5376,1,294,5392,2308,1024,0,4145,32,17,2,301,49,2048,5392,4096,2308,1317,32,256,33,5409,260]

theorem envBound29273 : H12AffineFastState.Bounded env29273 := by
  intro p hp
  have h : env29273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29272_29273 : H12AffineEnvironment.transform 8 261 env29272 = env29273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env29272 == env29273) = true)

def env29274 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,2097152,33,2101464,98644,8328,64,2491428,2098649,4096,2524497,2102685,2142525,256,168,46213,2175563]

theorem envBound29274 : H12AffineFastState.Bounded env29274 := by
  intro p hp
  have h : env29274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29251_29274 : H12AffineEnvironment.transform 21 33 env29251 = env29274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env29251 == env29274) = true)

theorem identity29274 : scanCanonicalize (H12AffineFastState.compose env29274 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound29274 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33246,131072,262144,1024,32769,2097152,33,2101464,138,8328,64,2491428,2098649,4096,2524497,2102685,2142525,256,168,46213,2143125]

theorem envBound29275 : H12AffineFastState.Bounded env29275 := by
  intro p hp
  have h : env29275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29274_29275 : H12AffineEnvironment.transform 15 33246 env29274 = env29275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env29274 == env29275) = true)

theorem identity29275 : scanCanonicalize (H12AffineFastState.compose env29275 (packedSelected [3,4,7,9,10,11,12,14,15,16,18,20,23,24,26,27,32,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 301365) := by decide +kernel

theorem selectedBound29275 : packedSelected [3,4,7,9,10,11,12,14,15,16,18,20,23,24,26,27,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env29276 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33246,131072,262144,1024,32769,301365,33,297453,138,8328,64,171281,302316,4096,138340,298152,272392,256,168,46213,273056]

theorem envBound29276 : H12AffineFastState.Bounded env29276 := by
  intro p hp
  have h : env29276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29275_29276 : H12AffineEnvironment.transform 20 301365 env29275 = env29276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 301365 env29275 == env29276) = true)

theorem identity29276 : scanCanonicalize (H12AffineFastState.compose env29276 (packedSelected [0,3,5,8,9,12,15,16,19,20,22,23,26,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound29276 : packedSelected [0,3,5,8,9,12,15,16,19,20,22,23,26,27,28,32] rootPS < 2^1333 := by decide +kernel

def env29277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33246,131072,10401,1024,32769,45460,33,41292,138,8328,64,171281,46157,4096,138340,41993,169,256,168,46213,513]

theorem envBound29277 : H12AffineFastState.Bounded env29277 := by
  intro p hp
  have h : env29277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29276_29277 : H12AffineEnvironment.transform 17 10401 env29276 = env29277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env29276 == env29277) = true)

theorem identity29277 : scanCanonicalize (H12AffineFastState.compose env29277 (packedSelected [4,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound29277 : packedSelected [4,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env29278 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33246,13341,10401,1024,32769,45460,33,41292,138,8328,64,43276,46157,4096,10361,41993,169,256,168,46213,513]

theorem envBound29278 : H12AffineFastState.Bounded env29278 := by
  intro p hp
  have h : env29278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29277_29278 : H12AffineEnvironment.transform 16 13341 env29277 = env29278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env29277 == env29278) = true)

theorem identity29278 : scanCanonicalize (H12AffineFastState.compose env29278 (packedSelected [0,1,7,8,10,11,14,15,16,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound29278 : packedSelected [0,1,7,8,10,11,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env29279 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5513,32768,33246,5393,2477,1024,32769,37016,33,32832,138,388,64,34816,38209,4096,2421,34053,169,256,168,38281,513]

theorem envBound29279 : H12AffineFastState.Bounded env29279 := by
  intro p hp
  have h : env29279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29278_29279 : H12AffineEnvironment.transform 12 268 env29278 = env29279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env29278 == env29279) = true)

def env29280 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,2097152,4194304,2101465,98645,8328,64,6685701,2098648,4097,2524496,2102685,6336797,256,168,46213,2175563]

theorem envBound29280 : H12AffineFastState.Bounded env29280 := by
  intro p hp
  have h : env29280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29250_29280 : H12AffineEnvironment.transform 22 2101465 env29250 = env29280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101465 env29250 == env29280) = true)

def env29281 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,2097152,32,2101465,98645,8328,64,2491429,2098648,4097,2524496,2102685,2142525,256,168,46213,2175563]

theorem envBound29281 : H12AffineFastState.Bounded env29281 := by
  intro p hp
  have h : env29281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29280_29281 : H12AffineEnvironment.transform 21 32 env29280 = env29281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env29280 == env29281) = true)

theorem identity29281 : scanCanonicalize (H12AffineFastState.compose env29281 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound29281 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29282 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,77898,32,73875,98645,8328,64,472175,79250,4097,505114,75223,98679,256,168,46213,513]

theorem envBound29282 : H12AffineFastState.Bounded env29282 := by
  intro p hp
  have h : env29282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29281_29282 : H12AffineEnvironment.transform 20 77898 env29281 = env29282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env29281 == env29282) = true)

def env29283 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,32,73755,98645,8192,64,472175,79130,4097,505114,75103,98679,256,32,46093,513]

theorem envBound29283 : H12AffineFastState.Bounded env29283 := by
  intro p hp
  have h : env29283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29282_29283 : H12AffineEnvironment.transform 6 8 env29282 = env29283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29282 == env29283) = true)

theorem identity29283 : scanCanonicalize (H12AffineFastState.compose env29283 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound29283 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env29284 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,79131,262144,1024,32769,77898,32,73755,98645,8192,64,262516,79130,4097,294913,75103,98679,256,32,46093,513]

theorem envBound29284 : H12AffineFastState.Bounded env29284 := by
  intro p hp
  have h : env29284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29283_29284 : H12AffineEnvironment.transform 16 79131 env29283 = env29284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env29283 == env29284) = true)

theorem identity29284 : scanCanonicalize (H12AffineFastState.compose env29284 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound29284 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env29285 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,9292,65536,79131,262144,1024,9293,77898,32,73755,75033,8192,64,262516,79130,4097,271437,75103,75067,256,32,4161,513]

theorem envBound29285 : H12AffineFastState.Bounded env29285 := by
  intro p hp
  have h : env29285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29284_29285 : H12AffineEnvironment.transform 14 9292 env29284 = env29285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env29284 == env29285) = true)

theorem identity29285 : scanCanonicalize (H12AffineFastState.compose env29285 (packedSelected [3,5,10,12,21,38] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound29285 : packedSelected [3,5,10,12,21,38] rootPS < 2^1333 := by decide +kernel

def env29286 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,5377,372,65536,69667,262144,1024,373,71026,32,66851,65569,1336,64,262516,69666,4097,262517,65639,65539,256,32,4161,513]

theorem envBound29286 : H12AffineFastState.Bounded env29286 := by
  intro p hp
  have h : env29286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29285_29286 : H12AffineEnvironment.transform 12 1336 env29285 = env29286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env29285 == env29286) = true)

theorem identity29286 : scanCanonicalize (H12AffineFastState.compose env29286 (packedSelected [3,5,10,18,21,32] rootPS)) = affineNative (2^(17+1) ^^^ 3124) := by decide +kernel

theorem selectedBound29286 : packedSelected [3,5,10,18,21,32] rootPS < 2^1333 := by decide +kernel

def env29287 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,5377,372,65536,69667,3124,1024,373,71026,32,66851,65569,1336,64,3392,69666,4097,3393,65639,65539,256,32,4161,513]

theorem envBound29287 : H12AffineFastState.Bounded env29287 := by
  intro p hp
  have h : env29287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29286_29287 : H12AffineEnvironment.transform 17 3124 env29286 = env29287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3124 env29286 == env29287) = true)

theorem identity29287 : scanCanonicalize (H12AffineFastState.compose env29287 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound29287 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env29288 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,5377,372,263,4388,3124,1024,373,5237,32,1060,294,1336,64,3392,4389,4097,3393,352,260,256,32,4161,513]

theorem envBound29288 : H12AffineFastState.Bounded env29288 := by
  intro p hp
  have h : env29288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29287_29288 : H12AffineEnvironment.transform 15 263 env29287 = env29288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env29287 == env29288) = true)

theorem identity29288 : scanCanonicalize (H12AffineFastState.compose env29288 (packedSelected [0,3,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 885) := by decide +kernel

theorem selectedBound29288 : packedSelected [0,3,7,8,10] rootPS < 2^1333 := by decide +kernel

def env29289 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,885,1336,1652,372,263,593,3124,1024,373,1792,32,1060,294,1336,64,3392,592,884,3393,352,260,256,32,820,513]

theorem envBound29289 : H12AffineFastState.Bounded env29289 := by
  intro p hp
  have h : env29289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29288_29289 : H12AffineEnvironment.transform 11 885 env29288 = env29289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 885 env29288 == env29289) = true)

theorem identity29289 : scanCanonicalize (H12AffineFastState.compose env29289 (packedSelected [0,1,2,4,5,6,14] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound29289 : packedSelected [0,1,2,4,5,6,14] rootPS < 2^1333 := by decide +kernel

def env29290 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,885,348,528,372,263,593,2128,100,373,868,32,64,294,348,64,2340,592,884,2341,352,260,256,32,820,513]

theorem envBound29290 : H12AffineFastState.Bounded env29290 := by
  intro p hp
  have h : env29290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29289_29290 : H12AffineEnvironment.transform 9 100 env29289 = env29290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env29289 == env29290) = true)

theorem identity29290 : scanCanonicalize (H12AffineFastState.compose env29290 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound29290 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env29291 : List Nat := [2,4,8,16,32,64,8,36,512,100,2048,593,120,528,80,35,593,2128,100,81,576,32,64,2,120,64,2048,592,592,2049,68,32,36,32,528,513]

theorem envBound29291 : H12AffineFastState.Bounded env29291 := by
  intro p hp
  have h : env29291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29290_29291 : H12AffineEnvironment.transform 7 36 env29290 = env29291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env29290 == env29291) = true)

def env29292 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,77898,32,73754,98645,8193,64,472175,79131,4097,505114,75102,98679,256,33,46092,513]

theorem envBound29292 : H12AffineFastState.Bounded env29292 := by
  intro p hp
  have h : env29292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29282_29292 : H12AffineEnvironment.transform 6 9 env29282 = env29292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29282 == env29292) = true)

theorem identity29292 : scanCanonicalize (H12AffineFastState.compose env29292 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound29292 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env29293 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33110,131072,262144,1024,32769,45340,32,41292,3,8193,64,439609,46157,4097,406604,41992,33,256,33,46092,513]

theorem envBound29293 : H12AffineFastState.Bounded env29293 := by
  intro p hp
  have h : env29293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29292_29293 : H12AffineEnvironment.transform 15 33110 env29292 = env29293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env29292 == env29293) = true)

theorem identity29293 : scanCanonicalize (H12AffineFastState.compose env29293 (packedSelected [2,6,21] rootPS)) = affineNative (2^(16+1) ^^^ 46109) := by decide +kernel

theorem selectedBound29293 : packedSelected [2,6,21] rootPS < 2^1333 := by decide +kernel

def env29294 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33110,46109,262144,1024,32769,45340,32,41292,3,8193,64,262436,46157,4097,294993,41992,33,256,33,46092,513]

theorem envBound29294 : H12AffineFastState.Bounded env29294 := by
  intro p hp
  have h : env29294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29293_29294 : H12AffineEnvironment.transform 16 46109 env29293 = env29294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46109 env29293 == env29294) = true)

theorem identity29294 : scanCanonicalize (H12AffineFastState.compose env29294 (packedSelected [3,10,18,19,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound29294 : packedSelected [3,10,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env29295 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1,343,13340,262144,1024,0,12573,32,8525,3,8193,64,262436,13388,4097,262224,9225,33,256,33,13325,513]

theorem envBound29295 : H12AffineFastState.Bounded env29295 := by
  intro p hp
  have h : env29295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29294_29295 : H12AffineEnvironment.transform 14 1 env29294 = env29295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env29294 == env29295) = true)

theorem identity29295 : scanCanonicalize (H12AffineFastState.compose env29295 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound29295 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env29296 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,343,5440,262144,1024,0,4161,32,17,3,349,64,262436,5392,4097,262224,1365,33,256,33,5457,513]

theorem envBound29296 : H12AffineFastState.Bounded env29296 := by
  intro p hp
  have h : env29296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29295_29296 : H12AffineEnvironment.transform 12 348 env29295 = env29296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env29295 == env29296) = true)

theorem identity29296 : scanCanonicalize (H12AffineFastState.compose env29296 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound29296 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29297 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,343,5440,2420,1024,0,4161,32,17,3,349,64,2128,5392,4097,2340,1365,33,256,33,5457,513]

theorem envBound29297 : H12AffineFastState.Bounded env29297 := by
  intro p hp
  have h : env29297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29296_29297 : H12AffineEnvironment.transform 17 2420 env29296 = env29297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env29296 == env29297) = true)

theorem identity29297 : scanCanonicalize (H12AffineFastState.compose env29297 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound29297 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env29298 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3328,348,2048,1,343,2112,2420,1024,0,3393,32,17,3,349,64,2128,2064,3329,2340,1365,33,256,33,2129,513]

theorem envBound29298 : H12AffineFastState.Bounded env29298 := by
  intro p hp
  have h : env29298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29297_29298 : H12AffineEnvironment.transform 11 3328 env29297 = env29298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env29297 == env29298) = true)

theorem identity29298 : scanCanonicalize (H12AffineFastState.compose env29298 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1345) := by decide +kernel

theorem selectedBound29298 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env29299 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1345,65,348,1345,1,343,1281,1077,1024,0,0,32,17,3,349,64,1297,1361,64,1125,1365,33,256,33,1296,513]

theorem envBound29299 : H12AffineFastState.Bounded env29299 := by
  intro p hp
  have h : env29299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29298_29299 : H12AffineEnvironment.transform 10 1345 env29298 = env29299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env29298 == env29299) = true)

theorem identity29299 : scanCanonicalize (H12AffineFastState.compose env29299 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound29299 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env29300 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1077,65,40,1077,1,35,1141,1077,1024,0,0,32,17,3,41,64,1125,1061,64,1125,1057,33,116,33,1124,513]

theorem envBound29300 : H12AffineFastState.Bounded env29300 := by
  intro p hp
  have h : env29300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29299_29300 : H12AffineEnvironment.transform 7 116 env29299 = env29300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env29299 == env29300) = true)

def env29301 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,2097152,33,2101465,98645,8328,64,2491428,2098648,4097,2524496,2102685,2142524,256,168,46213,2175563]

theorem envBound29301 : H12AffineFastState.Bounded env29301 := by
  intro p hp
  have h : env29301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29280_29301 : H12AffineEnvironment.transform 21 33 env29280 = env29301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env29280 == env29301) = true)

theorem identity29301 : scanCanonicalize (H12AffineFastState.compose env29301 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound29301 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29302 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,8323,131072,262144,1024,32769,2097152,33,2101465,41430,8328,64,2491428,2098648,4097,2524496,2102685,2142524,256,168,46213,2101960]

theorem envBound29302 : H12AffineFastState.Bounded env29302 := by
  intro p hp
  have h : env29302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29301_29302 : H12AffineEnvironment.transform 15 8323 env29301 = env29302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env29301 == env29302) = true)

def env29303 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,32768,8323,131072,262144,1024,32769,2097152,33,2101385,41350,8328,16,2491428,2098568,4097,2524416,2102685,2142524,256,168,46213,2101912]

theorem envBound29303 : H12AffineFastState.Bounded env29303 := by
  intro p hp
  have h : env29303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29302_29303 : H12AffineEnvironment.transform 5 16 env29302 = env29303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29302 == env29303) = true)

theorem identity29303 : scanCanonicalize (H12AffineFastState.compose env29303 (packedSelected [0,1,9,12,15,19,22,27,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 35245) := by decide +kernel

theorem selectedBound29303 : packedSelected [0,1,9,12,15,19,22,27,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env29304 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,32768,8323,131072,35245,1024,32769,2097152,33,2101385,41350,8328,16,2264457,2098568,4097,2231469,2102685,2142524,256,168,46213,2101912]

theorem envBound29304 : H12AffineFastState.Bounded env29304 := by
  intro p hp
  have h : env29304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29303_29304 : H12AffineEnvironment.transform 17 35245 env29303 = env29304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35245 env29303 == env29304) = true)

theorem identity29304 : scanCanonicalize (H12AffineFastState.compose env29304 (packedSelected [3,4,5,7,8,9,10,16,20,21,27,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4249) := by decide +kernel

theorem selectedBound29304 : packedSelected [3,4,5,7,8,9,10,16,20,21,27,28,31] rootPS < 2^1333 := by decide +kernel

def env29305 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,32768,8323,131072,35245,1024,32769,4249,33,16,41350,8328,16,171280,5393,4097,138292,1284,41381,256,168,46213,513]

theorem envBound29305 : H12AffineFastState.Bounded env29305 := by
  intro p hp
  have h : env29305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29304_29305 : H12AffineEnvironment.transform 20 4249 env29304 = env29305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4249 env29304 == env29305) = true)

theorem identity29305 : scanCanonicalize (H12AffineFastState.compose env29305 (packedSelected [2,6,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound29305 : packedSelected [2,6,18,23] rootPS < 2^1333 := by decide +kernel

def env29306 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5513,32768,263,131072,35245,1024,32769,4249,33,16,32770,268,16,171280,5393,4097,138292,1284,32801,256,168,38145,513]

theorem envBound29306 : H12AffineFastState.Bounded env29306 := by
  intro p hp
  have h : env29306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29305_29306 : H12AffineEnvironment.transform 12 388 env29305 = env29306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env29305 == env29306) = true)

theorem identity29306 : scanCanonicalize (H12AffineFastState.compose env29306 (packedSelected [2,4,6,9,14,20,21] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound29306 : packedSelected [2,4,6,9,14,20,21] rootPS < 2^1333 := by decide +kernel

def env29307 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5513,136,263,131072,2341,1024,137,4249,33,16,138,268,16,138648,5393,4097,138292,1284,169,256,168,5513,513]

theorem envBound29307 : H12AffineFastState.Bounded env29307 := by
  intro p hp
  have h : env29307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29306_29307 : H12AffineEnvironment.transform 14 136 env29306 = env29307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env29306 == env29307) = true)

theorem identity29307 : scanCanonicalize (H12AffineFastState.compose env29307 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound29307 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29308 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5513,136,263,5528,2341,1024,137,4249,33,16,138,268,16,2048,5393,4097,2476,1284,169,256,168,5513,513]

theorem envBound29308 : H12AffineFastState.Bounded env29308 := by
  intro p hp
  have h : env29308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29307_29308 : H12AffineEnvironment.transform 16 5528 env29307 = env29308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env29307 == env29308) = true)

theorem identity29308 : scanCanonicalize (H12AffineFastState.compose env29308 (packedSelected [11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound29308 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env29309 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5376,1,263,5393,2341,1024,0,4112,33,16,3,268,16,2048,5393,4097,2341,1284,32,256,33,5376,513]

theorem envBound29309 : H12AffineFastState.Bounded env29309 := by
  intro p hp
  have h : env29309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29308_29309 : H12AffineEnvironment.transform 6 9 env29308 = env29309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29308 == env29309) = true)

theorem identity29309 : scanCanonicalize (H12AffineFastState.compose env29309 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound29309 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29310 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1077,269,309,1,263,292,2341,1024,0,1061,33,16,3,268,16,2048,292,1076,2341,1284,32,256,33,309,513]

theorem envBound29310 : H12AffineFastState.Bounded env29310 := by
  intro p hp
  have h : env29310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29309_29310 : H12AffineEnvironment.transform 11 1077 env29309 = env29310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env29309 == env29310) = true)

theorem identity29310 : scanCanonicalize (H12AffineFastState.compose env29310 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 303) := by decide +kernel

theorem selectedBound29310 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29311 : List Nat := [2,4,8,16,32,16,9,256,512,1024,303,1077,269,309,1,263,292,10,1024,0,1061,33,16,3,268,16,303,292,1076,10,1284,32,256,33,309,513]

theorem envBound29311 : H12AffineFastState.Bounded env29311 := by
  intro p hp
  have h : env29311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29310_29311 : H12AffineEnvironment.transform 10 303 env29310 = env29311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 303 env29310 == env29311) = true)

theorem identity29311 : scanCanonicalize (H12AffineFastState.compose env29311 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound29311 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29312 : List Nat := [2,4,8,16,32,16,9,256,512,5,303,48,269,309,1,263,292,10,5,0,32,33,16,3,268,16,303,292,49,10,257,32,256,33,309,513]

theorem envBound29312 : H12AffineFastState.Bounded env29312 := by
  intro p hp
  have h : env29312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29311_29312 : H12AffineEnvironment.transform 9 5 env29311 = env29312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env29311 == env29312) = true)

theorem identity29312 : scanCanonicalize (H12AffineFastState.compose env29312 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound29312 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env29313 : List Nat := [2,4,8,16,32,16,9,14,512,5,33,48,3,59,1,9,42,10,5,0,32,33,16,3,2,16,33,42,49,10,15,32,14,33,59,513]

theorem envBound29313 : H12AffineFastState.Bounded env29313 := by
  intro p hp
  have h : env29313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29312_29313 : H12AffineEnvironment.transform 7 14 env29312 = env29313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env29312 == env29313) = true)

def env29314 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,8323,131072,262144,1024,32769,2097152,33,2101384,41351,8328,17,2491428,2098569,4097,2524417,2102685,2142524,256,168,46213,2101913]

theorem envBound29314 : H12AffineFastState.Bounded env29314 := by
  intro p hp
  have h : env29314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29302_29314 : H12AffineEnvironment.transform 5 17 env29302 = env29314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29302 == env29314) = true)

theorem identity29314 : scanCanonicalize (H12AffineFastState.compose env29314 (packedSelected [0,1,9,12,15,19,22,27,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 35108) := by decide +kernel

theorem selectedBound29314 : packedSelected [0,1,9,12,15,19,22,27,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env29315 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,8323,131072,35108,1024,32769,2097152,33,2101384,41351,8328,17,2264320,2098569,4097,2231333,2102685,2142524,256,168,46213,2101913]

theorem envBound29315 : H12AffineFastState.Bounded env29315 := by
  intro p hp
  have h : env29315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29314_29315 : H12AffineEnvironment.transform 17 35108 env29314 = env29315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35108 env29314 == env29315) = true)

theorem identity29315 : scanCanonicalize (H12AffineFastState.compose env29315 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 132488) := by decide +kernel

theorem selectedBound29315 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29316 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,8323,131072,35108,1024,32769,132488,33,136448,41351,8328,17,34952,131073,4097,2477,135189,177332,256,168,46213,136977]

theorem envBound29316 : H12AffineFastState.Bounded env29316 := by
  intro p hp
  have h : env29316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29315_29316 : H12AffineEnvironment.transform 20 132488 env29315 = env29316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 132488 env29315 == env29316) = true)

theorem identity29316 : scanCanonicalize (H12AffineFastState.compose env29316 (packedSelected [16,20] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound29316 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env29317 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,8323,5528,35108,1024,32769,4112,33,152,41351,8328,17,34952,5529,4097,2477,1421,41260,256,168,46213,649]

theorem envBound29317 : H12AffineFastState.Bounded env29317 := by
  intro p hp
  have h : env29317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29316_29317 : H12AffineEnvironment.transform 16 5528 env29316 = env29317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env29316 == env29317) = true)

theorem identity29317 : scanCanonicalize (H12AffineFastState.compose env29317 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound29317 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29318 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,8461,8323,5528,10281,1024,8460,4112,33,152,138,8328,17,10629,5529,4097,2477,1421,33,256,168,5512,649]

theorem envBound29318 : H12AffineFastState.Bounded env29318 := by
  intro p hp
  have h : env29318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29317_29318 : H12AffineEnvironment.transform 14 8461 env29317 = env29318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env29317 == env29318) = true)

theorem identity29318 : scanCanonicalize (H12AffineFastState.compose env29318 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound29318 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29319 : List Nat := [2,4,8,16,32,17,128,256,512,408,2048,4096,8192,4113,8461,8323,4096,10281,408,8460,4112,33,152,138,8328,17,10629,4097,4097,2477,21,33,256,168,4112,649]

theorem envBound29319 : H12AffineFastState.Bounded env29319 := by
  intro p hp
  have h : env29319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29318_29319 : H12AffineEnvironment.transform 9 408 env29318 = env29319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env29318 == env29319) = true)

theorem identity29319 : scanCanonicalize (H12AffineFastState.compose env29319 (packedSelected [1,3,4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 2720) := by decide +kernel

theorem selectedBound29319 : packedSelected [1,3,4,9,11] rootPS < 2^1333 := by decide +kernel

def env29320 : List Nat := [2,4,8,16,32,17,128,256,512,408,2048,4096,2720,4113,2989,2595,4096,649,408,2988,4112,33,152,138,2600,17,805,4097,4097,2477,21,33,256,168,4112,649]

theorem envBound29320 : H12AffineFastState.Bounded env29320 := by
  intro p hp
  have h : env29320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29319_29320 : H12AffineEnvironment.transform 12 2720 env29319 = env29320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2720 env29319 == env29320) = true)

theorem identity29320 : scanCanonicalize (H12AffineFastState.compose env29320 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound29320 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env29321 : List Nat := [2,4,8,16,32,17,128,256,512,408,2048,528,2720,513,2989,2595,528,649,408,2988,512,33,152,138,2600,17,805,529,529,2477,21,33,256,168,512,649]

theorem envBound29321 : H12AffineFastState.Bounded env29321 := by
  intro p hp
  have h : env29321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29320_29321 : H12AffineEnvironment.transform 11 528 env29320 = env29321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env29320 == env29321) = true)

theorem identity29321 : scanCanonicalize (H12AffineFastState.compose env29321 (packedSelected [1,4,5,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound29321 : packedSelected [1,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env29322 : List Nat := [2,4,8,16,16,17,128,256,512,408,2048,528,2704,513,2973,2579,528,649,408,2972,512,17,152,138,2584,17,789,529,529,2461,21,17,256,152,512,649]

theorem envBound29322 : H12AffineFastState.Bounded env29322 := by
  intro p hp
  have h : env29322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29321_29322 : H12AffineEnvironment.transform 4 16 env29321 = env29322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env29321 == env29322) = true)

theorem identity29322 : scanCanonicalize (H12AffineFastState.compose env29322 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound29322 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29323 : List Nat := [2,4,8,16,16,17,128,256,512,408,277,528,901,513,648,774,528,649,408,649,512,17,152,138,781,17,789,529,529,136,21,17,256,152,512,649]

theorem envBound29323 : H12AffineFastState.Bounded env29323 := by
  intro p hp
  have h : env29323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29322_29323 : H12AffineEnvironment.transform 10 277 env29322 = env29323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env29322 == env29323) = true)

theorem identity29323 : scanCanonicalize (H12AffineFastState.compose env29323 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 412) := by decide +kernel

theorem selectedBound29323 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env29324 : List Nat := [2,4,8,16,16,17,128,256,412,408,277,396,25,413,276,154,396,277,408,277,412,17,152,138,145,17,137,397,397,136,21,17,256,152,412,277]

theorem envBound29324 : H12AffineFastState.Bounded env29324 := by
  intro p hp
  have h : env29324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29323_29324 : H12AffineEnvironment.transform 8 412 env29323 = env29324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 412 env29323 == env29324) = true)

theorem identity29324 : scanCanonicalize (H12AffineFastState.compose env29324 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound29324 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env29325 : List Nat := [2,4,8,16,16,17,128,140,16,20,153,0,25,17,152,154,0,153,20,153,16,17,152,138,145,17,137,1,1,136,21,17,140,152,16,153]

theorem envBound29325 : H12AffineFastState.Bounded env29325 := by
  intro p hp
  have h : env29325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29324_29325 : H12AffineEnvironment.transform 7 140 env29324 = env29325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env29324 == env29325) = true)

theorem identity29325 : scanCanonicalize (H12AffineFastState.compose env29325 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29325 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29326 : List Nat := [2,4,8,1,1,0,128,140,1,5,136,0,8,0,137,139,0,136,5,136,1,0,137,138,128,0,137,1,1,136,4,0,140,137,1,136]

theorem envBound29326 : H12AffineFastState.Bounded env29326 := by
  intro p hp
  have h : env29326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29325_29326 : H12AffineEnvironment.transform 3 1 env29325 = env29326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29325 == env29326) = true)

theorem identity29326 : scanCanonicalize (H12AffineFastState.compose env29326 (packedSelected [16] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound29326 : packedSelected [16] rootPS < 2^1333 := by decide +kernel

def env29327 : List Nat := [2,4,8,1,1,0,8,4,1,5,0,0,8,0,1,3,0,0,5,0,1,0,1,2,8,0,1,1,1,0,4,0,4,1,1,0]

theorem envBound29327 : H12AffineFastState.Bounded env29327 := by
  intro p hp
  have h : env29327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29326_29327 : H12AffineEnvironment.transform 6 8 env29326 = env29327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29326 == env29327) = true)

def env29328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830977,25265169,23160257,257,27378860,27337993,25207750]

theorem envBound29328 : H12AffineFastState.Bounded env29328 := by
  intro p hp
  have h : env29328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29147_29328 : H12AffineEnvironment.transform 18 1025 env29147 = env29328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env29147 == env29328) = true)

theorem identity29328 : scanCanonicalize (H12AffineFastState.compose env29328 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 140421) := by decide +kernel

theorem selectedBound29328 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env29329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140421,4194304,8388608,16777216,8328,64,29868033,17014793,8548820,8830977,25265169,21184836,257,25419817,25362828,25207750]

theorem envBound29329 : H12AffineFastState.Bounded env29329 := by
  intro p hp
  have h : env29329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29328_29329 : H12AffineEnvironment.transform 20 140421 env29328 = env29329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 140421 env29328 == env29329) = true)

def env29330 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140421,4194304,8388608,8631560,8328,64,4486409,8393985,8548820,8830977,143641,12645452,257,21793,46212,202446]

theorem envBound29330 : H12AffineFastState.Bounded env29330 := by
  intro p hp
  have h : env29330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29329_29330 : H12AffineEnvironment.transform 23 8631560 env29329 = env29330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8631560 env29329 == env29330) = true)

def env29331 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140421,4194304,180224,95496,8328,64,4486409,185601,45524,262145,143641,4338764,257,21793,46212,202446]

theorem envBound29331 : H12AffineFastState.Bounded env29331 := by
  intro p hp
  have h : env29331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29330_29331 : H12AffineEnvironment.transform 22 180224 env29330 = env29331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180224 env29330 == env29331) = true)

def env29332 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140421,272512,180224,95496,8328,64,23945,185601,45524,262145,143641,400588,257,21793,46212,202446]

theorem envBound29332 : H12AffineFastState.Bounded env29332 := by
  intro p hp
  have h : env29332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29331_29332 : H12AffineEnvironment.transform 21 272512 env29331 = env29332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env29331 == env29332) = true)

theorem identity29332 : scanCanonicalize (H12AffineFastState.compose env29332 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound29332 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29333 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,140421,272512,180224,41430,8328,64,23945,185601,45524,262145,143641,400588,257,21793,46212,180752]

theorem envBound29333 : H12AffineFastState.Bounded env29333 := by
  intro p hp
  have h : env29333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29332_29333 : H12AffineEnvironment.transform 15 54494 env29332 = env29333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env29332 == env29333) = true)

def env29334 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,262144,1025,32769,140421,272512,180224,41350,8328,16,23945,185601,45444,262145,143641,400540,257,21793,46212,180752]

theorem envBound29334 : H12AffineFastState.Bounded env29334 := by
  intro p hp
  have h : env29334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29333_29334 : H12AffineEnvironment.transform 5 16 env29333 = env29334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29333 == env29334) = true)

theorem identity29334 : scanCanonicalize (H12AffineFastState.compose env29334 (packedSelected [4,7,9,10,12,19,26,27,31,41] rootPS)) = affineNative (2^(13+1) ^^^ 13445) := by decide +kernel

theorem selectedBound29334 : packedSelected [4,7,9,10,12,19,26,27,31,41] rootPS < 2^1333 := by decide +kernel

def env29335 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13445,32768,40971,131072,262144,1025,32769,140421,272512,177285,41350,8328,16,10508,172420,45444,262145,143641,400540,257,8612,46212,177813]

theorem envBound29335 : H12AffineFastState.Bounded env29335 := by
  intro p hp
  have h : env29335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29334_29335 : H12AffineEnvironment.transform 13 13445 env29334 = env29335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13445 env29334 == env29335) = true)

theorem identity29335 : scanCanonicalize (H12AffineFastState.compose env29335 (packedSelected [1,10,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound29335 : packedSelected [1,10,26,28] rootPS < 2^1333 := by decide +kernel

def env29336 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13445,32768,40971,5529,262144,1025,32769,12572,272512,41244,41350,8328,16,10508,46109,45444,262145,9344,264453,257,8612,46212,41740]

theorem envBound29336 : H12AffineFastState.Bounded env29336 := by
  intro p hp
  have h : env29336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29335_29336 : H12AffineEnvironment.transform 16 5529 env29335 = env29336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env29335 == env29336) = true)

theorem identity29336 : scanCanonicalize (H12AffineFastState.compose env29336 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(17+1) ^^^ 35245) := by decide +kernel

theorem selectedBound29336 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env29337 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13445,32768,40971,5529,35245,1025,32769,12572,41261,41244,41350,8328,16,10508,46109,45444,35244,9344,32936,257,8612,46212,41740]

theorem envBound29337 : H12AffineFastState.Bounded env29337 := by
  intro p hp
  have h : env29337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29336_29337 : H12AffineEnvironment.transform 17 35245 env29336 = env29337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35245 env29336 == env29337) = true)

theorem identity29337 : scanCanonicalize (H12AffineFastState.compose env29337 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound29337 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env29338 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13445,1,8202,5529,2476,1025,0,12572,8492,8477,8583,8328,16,10508,13340,12677,2477,9344,169,257,8612,13445,8973]

theorem envBound29338 : H12AffineFastState.Bounded env29338 := by
  intro p hp
  have h : env29338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29337_29338 : H12AffineEnvironment.transform 14 1 env29337 = env29338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env29337 == env29338) = true)

def env29339 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,262144,1025,32769,140421,272512,180224,41351,8328,17,23945,185601,45445,262145,143641,400541,257,21793,46212,180752]

theorem envBound29339 : H12AffineFastState.Bounded env29339 := by
  intro p hp
  have h : env29339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29333_29339 : H12AffineEnvironment.transform 5 17 env29333 = env29339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29333 == env29339) = true)

theorem identity29339 : scanCanonicalize (H12AffineFastState.compose env29339 (packedSelected [4,7,9,10,12,19,26,27,31,41] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound29339 : packedSelected [4,7,9,10,12,19,26,27,31,41] rootPS < 2^1333 := by decide +kernel

def env29340 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,43049,1025,32769,140421,32937,180224,41351,8328,17,23945,185601,45445,43048,143641,177332,257,21793,46212,180752]

theorem envBound29340 : H12AffineFastState.Bounded env29340 := by
  intro p hp
  have h : env29340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29339_29340 : H12AffineEnvironment.transform 17 43049 env29339 = env29340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env29339 == env29340) = true)

theorem identity29340 : scanCanonicalize (H12AffineFastState.compose env29340 (packedSelected [1,3,4,5,7,8,9,10,18,19,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 49305) := by decide +kernel

theorem selectedBound29340 : packedSelected [1,3,4,5,7,8,9,10,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env29341 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,49305,43049,1025,32769,58396,32937,153,41351,8328,17,23945,5528,45445,43048,61824,29741,257,21793,46212,649]

theorem envBound29341 : H12AffineFastState.Bounded env29341 := by
  intro p hp
  have h : env29341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29340_29341 : H12AffineEnvironment.transform 16 49305 env29340 = env29341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env29340 == env29341) = true)

theorem identity29341 : scanCanonicalize (H12AffineFastState.compose env29341 (packedSelected [3,5,10,12,15,16,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound29341 : packedSelected [3,5,10,12,15,16,17,20] rootPS < 2^1333 := by decide +kernel

def env29342 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,16384,32768,54415,49305,35108,1025,32769,50449,32937,153,32906,389,17,23945,5528,37000,35109,53389,21792,257,21793,38281,649]

theorem envBound29342 : H12AffineFastState.Bounded env29342 := by
  intro p hp
  have h : env29342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29341_29342 : H12AffineEnvironment.transform 12 269 env29341 = env29342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env29341 == env29342) = true)

theorem identity29342 : scanCanonicalize (H12AffineFastState.compose env29342 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound29342 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env29343 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,16384,1,21646,16536,2341,1025,0,17680,168,153,139,389,17,23945,5528,4233,2340,20620,21792,257,21793,5512,649]

theorem envBound29343 : H12AffineFastState.Bounded env29343 := by
  intro p hp
  have h : env29343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29342_29343 : H12AffineEnvironment.transform 14 1 env29342 = env29343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env29342 == env29343) = true)

theorem identity29343 : scanCanonicalize (H12AffineFastState.compose env29343 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound29343 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29344 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,5377,1,399,5529,2341,1025,0,4113,168,153,139,389,17,2184,5528,4233,2340,1421,33,257,32,5512,649]

theorem envBound29344 : H12AffineFastState.Bounded env29344 := by
  intro p hp
  have h : env29344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29343_29344 : H12AffineEnvironment.transform 13 5377 env29343 = env29344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env29343 == env29344) = true)

theorem identity29344 : scanCanonicalize (H12AffineFastState.compose env29344 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound29344 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env29345 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,1,263,5393,2341,1025,0,4113,32,17,3,269,17,2048,5392,4097,2340,1285,33,257,32,5376,513]

theorem envBound29345 : H12AffineFastState.Bounded env29345 := by
  intro p hp
  have h : env29345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29344_29345 : H12AffineEnvironment.transform 6 8 env29344 = env29345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29344 == env29345) = true)

theorem identity29345 : scanCanonicalize (H12AffineFastState.compose env29345 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound29345 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29346 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1060,269,293,1,263,309,2341,1025,0,1077,32,17,3,269,17,2048,308,1061,2340,1285,33,257,32,292,513]

theorem envBound29346 : H12AffineFastState.Bounded env29346 := by
  intro p hp
  have h : env29346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29345_29346 : H12AffineEnvironment.transform 11 1060 env29345 = env29346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env29345 == env29346) = true)

theorem identity29346 : scanCanonicalize (H12AffineFastState.compose env29346 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound29346 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29347 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,16,269,293,1,263,309,2341,53,0,1,32,17,3,269,17,2048,308,17,2340,305,33,257,32,292,513]

theorem envBound29347 : H12AffineFastState.Bounded env29347 := by
  intro p hp
  have h : env29347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29346_29347 : H12AffineEnvironment.transform 9 52 env29346 = env29347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env29346 == env29347) = true)

theorem identity29347 : scanCanonicalize (H12AffineFastState.compose env29347 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound29347 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29348 : List Nat := [2,4,8,16,32,17,8,256,512,52,1,16,269,293,1,263,309,292,53,0,1,32,17,3,269,17,1,308,17,293,305,33,257,32,292,513]

theorem envBound29348 : H12AffineFastState.Bounded env29348 := by
  intro p hp
  have h : env29348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29347_29348 : H12AffineEnvironment.transform 10 1 env29347 = env29348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env29347 == env29348) = true)

def env29349 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140421,272513,180224,95496,8328,64,23944,185601,45524,262145,143641,400589,257,21793,46212,202446]

theorem envBound29349 : H12AffineFastState.Bounded env29349 := by
  intro p hp
  have h : env29349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29331_29349 : H12AffineEnvironment.transform 21 272513 env29331 = env29349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env29331 == env29349) = true)

theorem identity29349 : scanCanonicalize (H12AffineFastState.compose env29349 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70863) := by decide +kernel

theorem selectedBound29349 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29350 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70863,262144,1025,32769,77898,272513,120015,95496,8328,64,23944,115150,45524,262145,75222,329730,257,21793,46212,513]

theorem envBound29350 : H12AffineFastState.Bounded env29350 := by
  intro p hp
  have h : env29350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29349_29350 : H12AffineEnvironment.transform 16 70863 env29349 = env29350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70863 env29349 == env29350) = true)

def env29351 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70727,262144,1025,32769,77898,272393,119879,95496,8192,64,23808,115014,45404,262145,75102,329730,257,21793,46092,513]

theorem envBound29351 : H12AffineFastState.Bounded env29351 := by
  intro p hp
  have h : env29351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29350_29351 : H12AffineEnvironment.transform 6 8 env29350 = env29351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29350 == env29351) = true)

def env29352 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70727,10280,1025,32769,77898,33,119879,95496,8192,64,23808,115014,45404,10281,75102,73770,257,21793,46092,513]

theorem envBound29352 : H12AffineFastState.Bounded env29352 := by
  intro p hp
  have h : env29352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29351_29352 : H12AffineEnvironment.transform 17 10280 env29351 = env29352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env29351 == env29352) = true)

theorem identity29352 : scanCanonicalize (H12AffineFastState.compose env29352 (packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound29352 : packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env29353 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,70727,10280,1025,8541,77898,33,95515,95496,8192,64,23808,90138,4096,10281,75102,73770,257,21793,5456,513]

theorem envBound29353 : H12AffineFastState.Bounded env29353 := by
  intro p hp
  have h : env29353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29352_29353 : H12AffineEnvironment.transform 14 8540 env29352 = env29353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env29352 == env29353) = true)

theorem identity29353 : scanCanonicalize (H12AffineFastState.compose env29353 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound29353 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env29354 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,21590,16401,10280,1025,8541,25628,33,8525,8542,8192,64,23808,13388,4096,10281,28936,29820,257,21793,5456,513]

theorem envBound29354 : H12AffineFastState.Bounded env29354 := by
  intro p hp
  have h : env29354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29353_29354 : H12AffineEnvironment.transform 15 21590 env29353 = env29354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env29353 == env29354) = true)

theorem identity29354 : scanCanonicalize (H12AffineFastState.compose env29354 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound29354 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29355 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,0,21590,16401,2420,1025,1,17728,33,17,2,348,64,23808,5392,4096,2421,20564,21792,257,21793,5456,513]

theorem envBound29355 : H12AffineFastState.Bounded env29355 := by
  intro p hp
  have h : env29355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29354_29355 : H12AffineEnvironment.transform 12 348 env29354 = env29355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env29354 == env29355) = true)

theorem identity29355 : scanCanonicalize (H12AffineFastState.compose env29355 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound29355 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env29356 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,0,343,5392,2420,1025,1,4161,33,17,2,348,64,2049,5392,4096,2421,1365,33,257,32,5456,513]

theorem envBound29356 : H12AffineFastState.Bounded env29356 := by
  intro p hp
  have h : env29356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29355_29356 : H12AffineEnvironment.transform 13 5377 env29355 = env29356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env29355 == env29356) = true)

theorem identity29356 : scanCanonicalize (H12AffineFastState.compose env29356 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound29356 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29357 : List Nat := [2,4,8,16,32,64,8,256,512,564,2048,4096,348,4917,0,343,4900,2420,565,1,4161,33,17,2,348,64,2049,4900,4096,2421,865,33,257,32,4964,513]

theorem envBound29357 : H12AffineFastState.Bounded env29357 := by
  intro p hp
  have h : env29357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29356_29357 : H12AffineEnvironment.transform 9 564 env29356 = env29357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env29356 == env29357) = true)

theorem identity29357 : scanCanonicalize (H12AffineFastState.compose env29357 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29357 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29358 : List Nat := [2,4,8,16,32,16,8,256,512,564,2048,4096,268,4917,0,263,4900,2340,565,1,4113,33,17,2,268,16,2049,4900,4096,2341,817,33,257,32,4916,513]

theorem envBound29358 : H12AffineFastState.Bounded env29358 := by
  intro p hp
  have h : env29358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29357_29358 : H12AffineEnvironment.transform 5 16 env29357 = env29358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29357 == env29358) = true)

theorem identity29358 : scanCanonicalize (H12AffineFastState.compose env29358 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound29358 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29359 : List Nat := [2,4,8,16,32,16,8,256,512,564,2048,513,268,308,0,263,293,2340,565,1,528,33,17,2,268,16,2049,293,513,2341,817,33,257,32,309,513]

theorem envBound29359 : H12AffineFastState.Bounded env29359 := by
  intro p hp
  have h : env29359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29358_29359 : H12AffineEnvironment.transform 11 513 env29358 = env29359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env29358 == env29359) = true)

theorem identity29359 : scanCanonicalize (H12AffineFastState.compose env29359 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 820) := by decide +kernel

theorem selectedBound29359 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29360 : List Nat := [2,4,8,16,32,16,8,256,512,564,820,513,268,308,0,263,293,528,565,1,528,33,17,2,268,16,821,293,513,529,817,33,257,32,309,513]

theorem envBound29360 : H12AffineFastState.Bounded env29360 := by
  intro p hp
  have h : env29360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29359_29360 : H12AffineEnvironment.transform 10 820 env29359 = env29360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 820 env29359 == env29360) = true)

theorem identity29360 : scanCanonicalize (H12AffineFastState.compose env29360 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound29360 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env29361 : List Nat := [2,4,8,16,32,16,8,256,292,272,16,293,268,308,0,263,293,308,273,1,308,33,17,2,268,16,17,293,293,309,21,33,257,32,309,293]

theorem envBound29361 : H12AffineFastState.Bounded env29361 := by
  intro p hp
  have h : env29361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29360_29361 : H12AffineEnvironment.transform 8 292 env29360 = env29361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env29360 == env29361) = true)

theorem identity29361 : scanCanonicalize (H12AffineFastState.compose env29361 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound29361 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env29362 : List Nat := [2,4,8,16,16,16,8,256,276,272,16,277,268,260,0,263,277,260,273,1,260,17,17,2,268,16,17,277,277,261,21,17,257,16,261,277]

theorem envBound29362 : H12AffineFastState.Bounded env29362 := by
  intro p hp
  have h : env29362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29361_29362 : H12AffineEnvironment.transform 4 16 env29361 = env29362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env29361 == env29362) = true)

theorem identity29362 : scanCanonicalize (H12AffineFastState.compose env29362 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound29362 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env29363 : List Nat := [2,4,8,16,16,16,8,21,1,5,16,0,25,17,0,18,0,17,4,1,17,17,17,2,25,16,17,0,0,16,21,17,20,16,16,0]

theorem envBound29363 : H12AffineFastState.Bounded env29363 := by
  intro p hp
  have h : env29363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29362_29363 : H12AffineEnvironment.transform 7 21 env29362 = env29363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env29362 == env29363) = true)

theorem identity29363 : scanCanonicalize (H12AffineFastState.compose env29363 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29363 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29364 : List Nat := [2,4,8,1,1,1,8,4,1,5,1,0,8,0,0,3,0,0,4,1,0,0,0,2,8,1,0,0,0,1,4,0,5,1,1,0]

theorem envBound29364 : H12AffineFastState.Bounded env29364 := by
  intro p hp
  have h : env29364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29363_29364 : H12AffineEnvironment.transform 3 1 env29363 = env29364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29363 == env29364) = true)

def env29365 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70727,10281,1025,32769,77898,32,119879,95496,8192,64,23808,115014,45404,10280,75102,73771,257,21793,46092,513]

theorem envBound29365 : H12AffineFastState.Bounded env29365 := by
  intro p hp
  have h : env29365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29351_29365 : H12AffineEnvironment.transform 17 10281 env29351 = env29365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env29351 == env29365) = true)

theorem identity29365 : scanCanonicalize (H12AffineFastState.compose env29365 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound29365 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29366 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49168,10281,1025,32769,58397,32,16,41311,8192,64,23808,5393,45404,10280,61705,62588,257,21793,46092,513]

theorem envBound29366 : H12AffineFastState.Bounded env29366 := by
  intro p hp
  have h : env29366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29365_29366 : H12AffineEnvironment.transform 15 54359 env29365 = env29366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env29365 == env29366) = true)

theorem identity29366 : scanCanonicalize (H12AffineFastState.compose env29366 (packedSelected [3,4,5,9,10,11,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 15373) := by decide +kernel

theorem selectedBound29366 : packedSelected [3,4,5,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env29367 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,15373,32768,43098,48157,10281,1025,32769,38928,32,16,41311,8192,64,8461,5393,45404,10280,36100,34929,257,10540,46092,513]

theorem envBound29367 : H12AffineFastState.Bounded env29367 := by
  intro p hp
  have h : env29367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29366_29367 : H12AffineEnvironment.transform 13 15373 env29366 = env29367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15373 env29366 == env29367) = true)

theorem identity29367 : scanCanonicalize (H12AffineFastState.compose env29367 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound29367 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env29368 : List Nat := [2,4,8,16,32,64,8,256,512,1024,80,4096,8192,13405,32768,40970,46157,8313,1025,32769,36928,32,16,41311,8192,64,8461,5393,45404,8312,34132,32801,257,8572,46092,513]

theorem envBound29368 : H12AffineFastState.Bounded env29368 := by
  intro p hp
  have h : env29368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29367_29368 : H12AffineEnvironment.transform 10 80 env29367 = env29368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env29367 == env29368) = true)

theorem identity29368 : scanCanonicalize (H12AffineFastState.compose env29368 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 12621) := by decide +kernel

theorem selectedBound29368 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env29369 : List Nat := [2,4,8,16,32,64,8,256,512,1024,80,4096,8192,13405,12621,4423,1280,8313,1025,12620,8461,32,16,4114,8192,64,8461,5393,17,8312,13337,12652,257,8572,1345,513]

theorem envBound29369 : H12AffineFastState.Bounded env29369 := by
  intro p hp
  have h : env29369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29368_29369 : H12AffineEnvironment.transform 14 12621 env29368 = env29369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12621 env29368 == env29369) = true)

theorem identity29369 : scanCanonicalize (H12AffineFastState.compose env29369 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound29369 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env29370 : List Nat := [2,4,8,16,32,64,8,256,512,273,80,4096,8192,12620,12621,4423,17,8313,272,12620,8461,32,16,4114,8192,64,8461,4096,17,8312,12552,12652,257,8572,80,513]

theorem envBound29370 : H12AffineFastState.Bounded env29370 := by
  intro p hp
  have h : env29370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29369_29370 : H12AffineEnvironment.transform 9 273 env29369 = env29370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env29369 == env29370) = true)

theorem identity29370 : scanCanonicalize (H12AffineFastState.compose env29370 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 4153) := by decide +kernel

theorem selectedBound29370 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env29371 : List Nat := [2,4,8,16,32,64,8,256,512,273,80,4096,4153,373,372,4423,17,4160,272,373,4404,32,16,4114,4153,64,4404,4096,17,4161,305,341,257,4421,80,513]

theorem envBound29371 : H12AffineFastState.Bounded env29371 := by
  intro p hp
  have h : env29371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29370_29371 : H12AffineEnvironment.transform 12 4153 env29370 = env29371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4153 env29370 == env29371) = true)

def env29372 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70726,262144,1025,32769,77898,272392,119878,95496,8193,64,23809,115015,45405,262145,75103,329730,257,21793,46093,513]

theorem envBound29372 : H12AffineFastState.Bounded env29372 := by
  intro p hp
  have h : env29372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29350_29372 : H12AffineEnvironment.transform 6 9 env29350 = env29372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29350 == env29372) = true)

theorem identity29372 : scanCanonicalize (H12AffineFastState.compose env29372 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound29372 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env29373 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,32768,65536,70726,262144,1025,32769,77898,272392,106522,65876,8193,64,10589,111899,45405,262145,75103,329730,257,8573,46093,513]

theorem envBound29373 : H12AffineFastState.Bounded env29373 := by
  intro p hp
  have h : env29373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29372_29373 : H12AffineEnvironment.transform 13 13404 env29372 = env29373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env29372 == env29373) = true)

theorem identity29373 : scanCanonicalize (H12AffineFastState.compose env29373 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 41051) := by decide +kernel

theorem selectedBound29373 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env29374 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,32768,41051,46109,262144,1025,32769,36881,272392,65,41231,8193,64,10589,5440,45405,262145,34052,305241,257,8573,46093,513]

theorem envBound29374 : H12AffineFastState.Bounded env29374 := by
  intro p hp
  have h : env29374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29373_29374 : H12AffineEnvironment.transform 15 41051 env29373 = env29374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41051 env29373 == env29374) = true)

theorem identity29374 : scanCanonicalize (H12AffineFastState.compose env29374 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound29374 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env29375 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1385,4405,32768,34098,37236,262144,1025,32769,36881,265569,65,33894,1384,64,3124,5440,37940,262145,34052,298288,257,1044,37220,513]

theorem envBound29375 : H12AffineFastState.Bounded env29375 := by
  intro p hp
  have h : env29375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29374_29375 : H12AffineEnvironment.transform 12 1385 env29374 = env29375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env29374 == env29375) = true)

theorem identity29375 : scanCanonicalize (H12AffineFastState.compose env29375 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 3392) := by decide +kernel

theorem selectedBound29375 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env29376 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1385,4405,32768,34098,37236,3392,1025,32769,36881,33,65,33894,1384,64,3124,5440,37940,3393,34052,32880,257,1044,37220,513]

theorem envBound29376 : H12AffineFastState.Bounded env29376 := by
  intro p hp
  have h : env29376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29375_29376 : H12AffineEnvironment.transform 17 3392 env29375 = env29376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3392 env29375 == env29376) = true)

theorem identity29376 : scanCanonicalize (H12AffineFastState.compose env29376 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 7425) := by decide +kernel

theorem selectedBound29376 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env29377 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1385,4405,7425,6195,3189,3392,1025,7424,3344,33,65,6503,1384,64,3124,5440,2357,3393,6149,7537,257,1044,3173,513]

theorem envBound29377 : H12AffineFastState.Bounded env29377 := by
  intro p hp
  have h : env29377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29376_29377 : H12AffineEnvironment.transform 14 7425 env29376 = env29377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7425 env29376 == env29377) = true)

theorem identity29377 : scanCanonicalize (H12AffineFastState.compose env29377 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound29377 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env29378 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,269,4405,6501,6195,2065,2340,101,6500,2420,33,65,6503,268,64,2128,4388,2357,2341,6149,6421,257,112,2049,513]

theorem envBound29378 : H12AffineFastState.Bounded env29378 := by
  intro p hp
  have h : env29378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29377_29378 : H12AffineEnvironment.transform 9 100 env29377 = env29378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env29377 == env29378) = true)

theorem identity29378 : scanCanonicalize (H12AffineFastState.compose env29378 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound29378 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env29379 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,2065,269,2340,372,34,2065,2340,101,373,2420,33,65,374,268,64,2128,2357,2357,2341,20,260,257,112,2049,513]

theorem envBound29379 : H12AffineFastState.Bounded env29379 := by
  intro p hp
  have h : env29379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29378_29379 : H12AffineEnvironment.transform 11 2065 env29378 = env29379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env29378 == env29379) = true)

theorem identity29379 : scanCanonicalize (H12AffineFastState.compose env29379 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29379 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env29380 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,2065,269,2340,293,34,2065,2340,52,292,2341,33,16,295,268,17,2049,2357,2357,2341,20,260,257,33,2049,513]

theorem envBound29380 : H12AffineFastState.Bounded env29380 := by
  intro p hp
  have h : env29380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29379_29380 : H12AffineEnvironment.transform 5 17 env29379 = env29380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29379 == env29380) = true)

theorem identity29380 : scanCanonicalize (H12AffineFastState.compose env29380 (packedSelected [0,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound29380 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env29381 : List Nat := [2,4,8,16,32,17,9,256,26,53,2048,2065,269,2340,293,34,2065,2340,52,292,2341,33,16,295,268,17,2049,2357,2357,2341,20,260,257,33,2049,27]

theorem envBound29381 : H12AffineFastState.Bounded env29381 := by
  intro p hp
  have h : env29381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29380_29381 : H12AffineEnvironment.transform 8 26 env29380 = env29381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env29380 == env29381) = true)

def env29382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140421,4194304,180225,95497,8328,64,4486409,185600,45525,262144,143641,4338765,257,21793,46212,202446]

theorem envBound29382 : H12AffineFastState.Bounded env29382 := by
  intro p hp
  have h : env29382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29330_29382 : H12AffineEnvironment.transform 22 180225 env29330 = env29382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180225 env29330 == env29382) = true)

def env29383 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140421,272512,180225,95497,8328,64,23945,185600,45525,262144,143641,400589,257,21793,46212,202446]

theorem envBound29383 : H12AffineFastState.Bounded env29383 := by
  intro p hp
  have h : env29383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29382_29383 : H12AffineEnvironment.transform 21 272512 env29382 = env29383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env29382 == env29383) = true)

theorem identity29383 : scanCanonicalize (H12AffineFastState.compose env29383 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound29383 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,140421,272512,180225,21763,8328,64,23945,185600,45525,262144,143641,400589,257,21793,46212,145092]

theorem envBound29384 : H12AffineFastState.Bounded env29384 := by
  intro p hp
  have h : env29384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29383_29384 : H12AffineEnvironment.transform 15 8202 env29383 = env29384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env29383 == env29384) = true)

def env29385 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,140301,272392,180225,21763,8192,64,23809,185600,45405,262144,143641,400453,257,21793,46092,144972]

theorem envBound29385 : H12AffineFastState.Bounded env29385 := by
  intro p hp
  have h : env29385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29384_29385 : H12AffineEnvironment.transform 6 8 env29384 = env29385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29384 == env29385) = true)

def env29386 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,58397,272392,17,21763,8192,64,23809,5392,45405,262144,61705,318549,257,21793,46092,63068]

theorem envBound29386 : H12AffineFastState.Bounded env29386 := by
  intro p hp
  have h : env29386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29385_29386 : H12AffineEnvironment.transform 16 49168 env29385 = env29386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env29385 == env29386) = true)

theorem identity29386 : scanCanonicalize (H12AffineFastState.compose env29386 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound29386 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29387 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49168,56437,1025,32769,58397,62589,17,21763,8192,64,23809,5392,45405,56437,61705,32,257,21793,46092,63068]

theorem envBound29387 : H12AffineFastState.Bounded env29387 := by
  intro p hp
  have h : env29387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29386_29387 : H12AffineEnvironment.transform 17 56437 env29386 = env29387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env29386 == env29387) = true)

theorem identity29387 : scanCanonicalize (H12AffineFastState.compose env29387 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound29387 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env29388 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,24909,32040,1025,8540,17728,21792,17,21763,8192,64,23809,5392,4096,32040,20564,32,257,21793,5457,22273]

theorem envBound29388 : H12AffineFastState.Bounded env29388 := by
  intro p hp
  have h : env29388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29387_29388 : H12AffineEnvironment.transform 14 8541 env29387 = env29388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env29387 == env29388) = true)

theorem identity29388 : scanCanonicalize (H12AffineFastState.compose env29388 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound29388 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env29389 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,8541,8202,5440,2341,1025,8540,12621,8493,17,8462,8192,64,10508,5392,4096,2341,9305,32,257,8492,5457,8972]

theorem envBound29389 : H12AffineFastState.Bounded env29389 := by
  intro p hp
  have h : env29389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29388_29389 : H12AffineEnvironment.transform 13 13325 env29388 = env29389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env29388 == env29389) = true)

theorem identity29389 : scanCanonicalize (H12AffineFastState.compose env29389 (packedSelected [2,3,4,5,9,10,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound29389 : packedSelected [2,3,4,5,9,10,16] rootPS < 2^1333 := by decide +kernel

def env29390 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5456,0,343,5440,2341,1025,1,4112,112,17,83,349,64,2129,5392,4096,2341,1284,32,257,113,5457,593]

theorem envBound29390 : H12AffineFastState.Bounded env29390 := by
  intro p hp
  have h : env29390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29389_29390 : H12AffineEnvironment.transform 12 349 env29389 = env29390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env29389 == env29390) = true)

theorem identity29390 : scanCanonicalize (H12AffineFastState.compose env29390 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound29390 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env29391 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1076,4096,349,5456,0,343,5440,1297,1025,1,4112,112,17,83,349,64,1125,5392,4096,1297,1284,32,257,113,5457,593]

theorem envBound29391 : H12AffineFastState.Bounded env29391 := by
  intro p hp
  have h : env29391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29390_29391 : H12AffineEnvironment.transform 10 1076 env29390 = env29391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env29390 == env29391) = true)

def env29392 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,58396,272392,16,21763,8192,64,23809,5393,45405,262144,61704,318548,257,21793,46092,63069]

theorem envBound29392 : H12AffineFastState.Bounded env29392 := by
  intro p hp
  have h : env29392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29385_29392 : H12AffineEnvironment.transform 16 49169 env29385 = env29392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env29385 == env29392) = true)

theorem identity29392 : scanCanonicalize (H12AffineFastState.compose env29392 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound29392 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29393 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,13389,262144,1025,29789,4160,272392,16,21763,8192,64,23809,5393,17665,262144,1364,272392,257,21793,16464,513]

theorem envBound29393 : H12AffineFastState.Bounded env29393 := by
  intro p hp
  have h : env29393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29392_29393 : H12AffineEnvironment.transform 14 29788 env29392 = env29393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env29392 == env29393) = true)

theorem identity29393 : scanCanonicalize (H12AffineFastState.compose env29393 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29393 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env29394 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29708,8202,13341,262144,1025,29709,4112,272392,16,21763,8192,16,23809,5393,17665,262144,1284,272392,257,21793,16384,513]

theorem envBound29394 : H12AffineFastState.Bounded env29394 := by
  intro p hp
  have h : env29394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29393_29394 : H12AffineEnvironment.transform 5 16 env29393 = env29394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29393 == env29394) = true)

theorem identity29394 : scanCanonicalize (H12AffineFastState.compose env29394 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound29394 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env29395 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29708,8202,13341,32040,1025,29709,4112,21792,16,21763,8192,16,23809,5393,17665,32040,1284,21792,257,21793,16384,513]

theorem envBound29395 : H12AffineFastState.Bounded env29395 := by
  intro p hp
  have h : env29395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29394_29395 : H12AffineEnvironment.transform 17 32040 env29394 = env29395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env29394 == env29395) = true)

theorem identity29395 : scanCanonicalize (H12AffineFastState.compose env29395 (packedSelected [0,4,6,7,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 10281) := by decide +kernel

theorem selectedBound29395 : packedSelected [0,4,6,7,9,11] rootPS < 2^1333 := by decide +kernel

def env29396 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,10281,7205,8202,13341,5377,1025,7204,4112,15625,16,15658,8192,16,13608,5393,11560,5377,1284,15625,257,15624,10281,513]

theorem envBound29396 : H12AffineFastState.Bounded env29396 := by
  intro p hp
  have h : env29396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29395_29396 : H12AffineEnvironment.transform 13 10281 env29395 = env29396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10281 env29395 == env29396) = true)

theorem identity29396 : scanCanonicalize (H12AffineFastState.compose env29396 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 7180) := by decide +kernel

theorem selectedBound29396 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env29397 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,7180,5157,7205,7174,2065,5377,1025,7204,4112,261,16,294,7180,16,2340,5393,4388,5377,1284,261,257,260,5157,513]

theorem envBound29397 : H12AffineFastState.Bounded env29397 := by
  intro p hp
  have h : env29397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29396_29397 : H12AffineEnvironment.transform 12 7180 env29396 = env29397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7180 env29396 == env29397) = true)

theorem identity29397 : scanCanonicalize (H12AffineFastState.compose env29397 (packedSelected [3,4,5,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound29397 : packedSelected [3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env29398 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,7180,5157,7205,7174,2065,5156,1025,7204,4112,32,16,3,7180,16,2049,5172,4097,5156,1057,32,36,33,5157,513]

theorem envBound29398 : H12AffineFastState.Bounded env29398 := by
  intro p hp
  have h : env29398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29397_29398 : H12AffineEnvironment.transform 7 37 env29397 = env29398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env29397 == env29398) = true)

theorem identity29398 : scanCanonicalize (H12AffineFastState.compose env29398 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound29398 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env29399 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,3109,41,2048,0,35,2065,2049,1025,1,3125,32,16,3,41,16,2049,2065,3108,2049,1057,32,36,33,2048,513]

theorem envBound29399 : H12AffineFastState.Bounded env29399 := by
  intro p hp
  have h : env29399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29398_29399 : H12AffineEnvironment.transform 11 3109 env29398 = env29399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env29398 == env29399) = true)

theorem identity29399 : scanCanonicalize (H12AffineFastState.compose env29399 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound29399 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29400 : List Nat := [2,4,8,16,32,16,8,37,512,1024,0,1061,41,0,0,35,17,1,1025,1,1077,32,16,3,41,16,1,17,1060,1,1057,32,36,33,0,513]

theorem envBound29400 : H12AffineFastState.Bounded env29400 := by
  intro p hp
  have h : env29400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29399_29400 : H12AffineEnvironment.transform 10 0 env29399 = env29400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env29399 == env29400) = true)

theorem identity29400 : scanCanonicalize (H12AffineFastState.compose env29400 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound29400 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29401 : List Nat := [2,4,8,16,32,16,8,37,11,1024,0,1061,41,0,0,35,17,1,1025,1,1077,32,16,3,41,16,1,17,1060,1,1057,32,36,33,0,10]

theorem envBound29401 : H12AffineFastState.Bounded env29401 := by
  intro p hp
  have h : env29401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29400_29401 : H12AffineEnvironment.transform 8 11 env29400 = env29401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env29400 == env29401) = true)

theorem identity29401 : scanCanonicalize (H12AffineFastState.compose env29401 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound29401 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env29402 : List Nat := [2,4,8,16,13,16,8,8,11,1024,0,1032,4,0,0,14,17,1,1025,1,1048,13,16,3,4,16,1,17,1033,1,1036,13,9,12,0,10]

theorem envBound29402 : H12AffineFastState.Bounded env29402 := by
  intro p hp
  have h : env29402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29401_29402 : H12AffineEnvironment.transform 4 13 env29401 = env29402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env29401 == env29402) = true)

theorem identity29402 : scanCanonicalize (H12AffineFastState.compose env29402 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound29402 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29403 : List Nat := [2,4,8,16,13,16,8,8,11,20,0,28,4,0,0,14,17,1,21,1,12,13,16,3,4,16,1,17,29,1,24,13,9,12,0,10]

theorem envBound29403 : H12AffineFastState.Bounded env29403 := by
  intro p hp
  have h : env29403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29402_29403 : H12AffineEnvironment.transform 9 20 env29402 = env29403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env29402 == env29403) = true)

theorem identity29403 : scanCanonicalize (H12AffineFastState.compose env29403 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound29403 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29404 : List Nat := [2,1,8,16,8,16,8,8,11,17,0,25,1,0,0,11,17,1,16,1,9,8,16,3,1,16,1,17,24,1,24,8,9,9,0,10]

theorem envBound29404 : H12AffineFastState.Bounded env29404 := by
  intro p hp
  have h : env29404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29403_29404 : H12AffineEnvironment.transform 1 1 env29403 = env29404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env29403 == env29404) = true)

def env29405 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,140300,272393,180225,21763,8193,64,23808,185600,45404,262144,143641,400452,257,21793,46093,144973]

theorem envBound29405 : H12AffineFastState.Bounded env29405 := by
  intro p hp
  have h : env29405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29384_29405 : H12AffineEnvironment.transform 6 9 env29384 = env29405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29384 == env29405) = true)

def env29406 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,58396,272393,17,21763,8193,64,23808,5392,45404,262144,61705,318548,257,21793,46093,63069]

theorem envBound29406 : H12AffineFastState.Bounded env29406 := by
  intro p hp
  have h : env29406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29405_29406 : H12AffineEnvironment.transform 16 49168 env29405 = env29406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env29405 == env29406) = true)

theorem identity29406 : scanCanonicalize (H12AffineFastState.compose env29406 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound29406 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29407 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,49168,32040,1025,32769,58396,21793,17,21763,8193,64,23808,5392,45404,32040,61705,41340,257,21793,46093,63069]

theorem envBound29407 : H12AffineFastState.Bounded env29407 := by
  intro p hp
  have h : env29407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29406_29407 : H12AffineEnvironment.transform 17 32040 env29406 = env29407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env29406 == env29407) = true)

theorem identity29407 : scanCanonicalize (H12AffineFastState.compose env29407 (packedSelected [2,11,14,16,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound29407 : packedSelected [2,11,14,16,18,20] rootPS < 2^1333 := by decide +kernel

def env29408 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,8202,5393,32040,1025,21760,12573,21793,17,21763,8193,64,23808,5392,25693,32040,9224,29821,257,21793,24844,9052]

theorem envBound29408 : H12AffineFastState.Bounded env29408 := by
  intro p hp
  have h : env29408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29407_29408 : H12AffineEnvironment.transform 14 21761 env29407 = env29408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env29407 == env29408) = true)

theorem identity29408 : scanCanonicalize (H12AffineFastState.compose env29408 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound29408 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env29409 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1,8202,5393,10280,1025,0,12573,33,17,3,8193,64,2048,5392,12637,10280,9224,8573,257,33,13324,9052]

theorem envBound29409 : H12AffineFastState.Bounded env29409 := by
  intro p hp
  have h : env29409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29408_29409 : H12AffineEnvironment.transform 13 5376 env29408 = env29409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env29408 == env29409) = true)

def env29410 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,58397,272393,16,21763,8193,64,23808,5393,45404,262144,61704,318549,257,21793,46093,63068]

theorem envBound29410 : H12AffineFastState.Bounded env29410 := by
  intro p hp
  have h : env29410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29405_29410 : H12AffineEnvironment.transform 16 49169 env29405 = env29410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env29405 == env29410) = true)

theorem identity29410 : scanCanonicalize (H12AffineFastState.compose env29410 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound29410 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29411 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8202,38161,262144,1025,32769,45341,272393,16,3,8193,64,2048,5393,45404,262144,41992,297301,257,33,46093,41820]

theorem envBound29411 : H12AffineFastState.Bounded env29411 := by
  intro p hp
  have h : env29411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29410_29411 : H12AffineEnvironment.transform 13 5376 env29410 = env29411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env29410 == env29411) = true)

theorem identity29411 : scanCanonicalize (H12AffineFastState.compose env29411 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound29411 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env29412 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8202,38161,10281,1025,32769,45341,32,16,3,8193,64,2048,5393,45404,10281,41992,41340,257,33,46093,41820]

theorem envBound29412 : H12AffineFastState.Bounded env29412 := by
  intro p hp
  have h : env29412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29411_29412 : H12AffineEnvironment.transform 17 10281 env29411 = env29412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env29411 == env29412) = true)

theorem identity29412 : scanCanonicalize (H12AffineFastState.compose env29412 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound29412 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29413 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,5376,32768,1094,38161,3173,1025,32769,38225,32,16,3,1101,64,2048,5393,38160,3173,32836,34096,257,33,36929,34576]

theorem envBound29413 : H12AffineFastState.Bounded env29413 := by
  intro p hp
  have h : env29413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29412_29413 : H12AffineEnvironment.transform 12 1100 env29412 = env29413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env29412 == env29413) = true)

theorem identity29413 : scanCanonicalize (H12AffineFastState.compose env29413 (packedSelected [2,14] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound29413 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env29414 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,5376,81,1094,5440,3173,1025,80,5376,32,16,3,1101,64,2048,5393,5441,3173,21,1377,257,33,4112,1857]

theorem envBound29414 : H12AffineFastState.Bounded env29414 := by
  intro p hp
  have h : env29414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29413_29414 : H12AffineEnvironment.transform 14 81 env29413 = env29414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env29413 == env29414) = true)

theorem identity29414 : scanCanonicalize (H12AffineFastState.compose env29414 (packedSelected [0,1,4,8,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound29414 : packedSelected [0,1,4,8,11,12] rootPS < 2^1333 := by decide +kernel

def env29415 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2112,1100,3392,81,1094,3328,3173,1025,80,3392,32,16,3,1101,64,2048,3409,3329,3173,21,1377,257,33,2128,1857]

theorem envBound29415 : H12AffineFastState.Bounded env29415 := by
  intro p hp
  have h : env29415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29414_29415 : H12AffineEnvironment.transform 11 2112 env29414 = env29415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env29414 == env29415) = true)

theorem identity29415 : scanCanonicalize (H12AffineFastState.compose env29415 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound29415 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env29416 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,1060,1100,292,81,1094,356,1,1025,80,292,32,16,3,1101,64,1124,309,357,1,21,1377,257,33,1076,1857]

theorem envBound29416 : H12AffineFastState.Bounded env29416 := by
  intro p hp
  have h : env29416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29415_29416 : H12AffineEnvironment.transform 10 1124 env29415 = env29416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env29415 == env29416) = true)

theorem identity29416 : scanCanonicalize (H12AffineFastState.compose env29416 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound29416 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env29417 : List Nat := [2,4,8,16,32,64,9,256,512,273,373,309,349,292,81,343,356,1,272,80,292,32,16,3,348,64,373,309,357,1,21,112,257,33,293,592]

end H12CloudChart0