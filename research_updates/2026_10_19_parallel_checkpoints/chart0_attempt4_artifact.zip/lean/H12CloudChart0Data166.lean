import H12CloudChart0Data165

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env42070 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,2113,40,2048,1,34,2065,2049,100,0,2049,33,17,82,40,65,2128,2064,2065,2049,20,32,116,33,2128,593]

theorem envBound42070 : H12AffineFastState.Bounded env42070 := by
  intro p hp
  have h : env42070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42069_42070 : H12AffineEnvironment.transform 7 116 env42069 = env42070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env42069 == env42070) = true)

theorem identity42070 : scanCanonicalize (H12AffineFastState.compose env42070 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 112) := by decide +kernel

theorem selectedBound42070 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env42071 : List Nat := [2,4,8,16,32,64,8,116,512,100,112,49,40,112,1,34,97,113,100,0,113,33,17,82,40,65,32,96,97,113,20,32,116,33,32,593]

theorem envBound42071 : H12AffineFastState.Bounded env42071 := by
  intro p hp
  have h : env42071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42070_42071 : H12AffineEnvironment.transform 10 112 env42070 = env42071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 112 env42070 == env42071) = true)

theorem identity42071 : scanCanonicalize (H12AffineFastState.compose env42071 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42071 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env42072 : List Nat := [2,4,8,16,32,17,8,37,512,53,33,49,40,33,1,34,48,32,53,0,32,33,17,3,40,16,32,49,48,32,20,32,37,33,32,512]

theorem envBound42072 : H12AffineFastState.Bounded env42072 := by
  intro p hp
  have h : env42072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42071_42072 : H12AffineEnvironment.transform 5 17 env42071 = env42072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42071 == env42072) = true)

theorem identity42072 : scanCanonicalize (H12AffineFastState.compose env42072 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound42072 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42073 : List Nat := [2,4,8,16,5,17,8,0,512,16,4,20,13,4,1,7,21,5,16,0,5,4,17,3,13,16,5,20,21,5,20,5,0,4,5,512]

theorem envBound42073 : H12AffineFastState.Bounded env42073 := by
  intro p hp
  have h : env42073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42072_42073 : H12AffineEnvironment.transform 4 5 env42072 = env42073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env42072 == env42073) = true)

theorem identity42073 : scanCanonicalize (H12AffineFastState.compose env42073 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound42073 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42074 : List Nat := [2,0,8,16,1,17,8,0,512,16,0,16,9,0,1,3,17,1,16,0,1,0,17,3,9,16,1,16,17,1,16,1,0,0,1,512]

theorem envBound42074 : H12AffineFastState.Bounded env42074 := by
  intro p hp
  have h : env42074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42073_42074 : H12AffineEnvironment.transform 1 0 env42073 = env42074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env42073 == env42074) = true)

def env42075 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,213350,17,21763,8193,65,171280,115014,17665,35189,119042,156012,256,98679,90202,63068]

theorem envBound42075 : H12AffineFastState.Bounded env42075 := by
  intro p hp
  have h : env42075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42061_42075 : H12AffineEnvironment.transform 6 9 env42061 = env42075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42061 == env42075) = true)

def env42076 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,2421,1024,32769,4160,65910,17,21763,8193,65,56576,115014,17665,35189,119042,8572,256,98679,90202,63068]

theorem envBound42076 : H12AffineFastState.Bounded env42076 := by
  intro p hp
  have h : env42076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42075_42076 : H12AffineEnvironment.transform 16 16400 env42075 = env42076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env42075 == env42076) = true)

theorem identity42076 : scanCanonicalize (H12AffineFastState.compose env42076 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound42076 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env42077 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,16400,2421,1024,29788,4160,65910,17,21763,8193,65,10589,79131,17665,32040,75103,8572,256,95530,90202,513]

theorem envBound42077 : H12AffineFastState.Bounded env42077 := by
  intro p hp
  have h : env42077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42076_42077 : H12AffineEnvironment.transform 14 29789 env42076 = env42077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env42076 == env42077) = true)

theorem identity42077 : scanCanonicalize (H12AffineFastState.compose env42077 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound42077 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env42078 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,16400,2421,1024,29788,4160,8572,17,21763,8193,65,10589,5393,17665,32040,1365,8572,256,21792,16464,513]

theorem envBound42078 : H12AffineFastState.Bounded env42078 := by
  intro p hp
  have h : env42078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42077_42078 : H12AffineEnvironment.transform 15 8202 env42077 = env42078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env42077 == env42078) = true)

theorem identity42078 : scanCanonicalize (H12AffineFastState.compose env42078 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound42078 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env42079 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,343,16400,2421,1024,21761,4160,33,17,21763,348,65,2048,5393,17665,23669,1365,33,256,21792,16464,513]

theorem envBound42079 : H12AffineFastState.Bounded env42079 := by
  intro p hp
  have h : env42079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42078_42079 : H12AffineEnvironment.transform 12 349 env42078 = env42079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env42078 == env42079) = true)

theorem identity42079 : scanCanonicalize (H12AffineFastState.compose env42079 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound42079 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42080 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,343,5392,2421,1024,1,4160,33,17,3,348,65,2048,5393,4097,2421,1365,33,256,32,5456,513]

theorem envBound42080 : H12AffineFastState.Bounded env42080 := by
  intro p hp
  have h : env42080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42079_42080 : H12AffineEnvironment.transform 13 5376 env42079 = env42080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env42079 == env42080) = true)

theorem identity42080 : scanCanonicalize (H12AffineFastState.compose env42080 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound42080 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42081 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,5237,0,34,5221,2048,1024,1,4160,33,17,3,41,65,2048,5220,4097,2048,1056,33,117,32,5157,513]

theorem envBound42081 : H12AffineFastState.Bounded env42081 := by
  intro p hp
  have h : env42081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42080_42081 : H12AffineEnvironment.transform 7 117 env42080 = env42081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env42080 == env42081) = true)

theorem identity42081 : scanCanonicalize (H12AffineFastState.compose env42081 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42081 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env42082 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5157,0,34,5173,2048,1024,1,4112,33,17,3,41,17,2048,5172,4097,2048,1056,33,37,32,5157,513]

theorem envBound42082 : H12AffineFastState.Bounded env42082 := by
  intro p hp
  have h : env42082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42081_42082 : H12AffineEnvironment.transform 5 16 env42081 = env42082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42081 == env42082) = true)

def env42083 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,40,1045,0,34,1029,2048,1024,1,32,33,17,3,41,17,2048,1028,49,2048,1056,33,37,32,1045,513]

theorem envBound42083 : H12AffineFastState.Bounded env42083 := by
  intro p hp
  have h : env42083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42082_42083 : H12AffineEnvironment.transform 11 48 env42082 = env42083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env42082 == env42083) = true)

theorem identity42083 : scanCanonicalize (H12AffineFastState.compose env42083 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound42083 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42084 : List Nat := [2,4,8,16,32,16,9,37,512,1024,561,48,40,1045,0,34,1029,561,1024,1,32,33,17,3,41,17,561,1028,49,561,1056,33,37,32,1045,513]

theorem envBound42084 : H12AffineFastState.Bounded env42084 := by
  intro p hp
  have h : env42084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42083_42084 : H12AffineEnvironment.transform 10 561 env42083 = env42084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env42083 == env42084) = true)

def env42085 : List Nat := [2,4,8,16,32,16,9,37,512,52,561,48,40,33,0,34,49,561,52,1,32,33,17,3,41,17,561,48,49,561,20,33,37,32,33,513]

theorem envBound42085 : H12AffineFastState.Bounded env42085 := by
  intro p hp
  have h : env42085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42084_42085 : H12AffineEnvironment.transform 9 52 env42084 = env42085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env42084 == env42085) = true)

theorem identity42085 : scanCanonicalize (H12AffineFastState.compose env42085 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound42085 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42086 : List Nat := [2,4,8,16,32,16,9,37,16,52,33,48,40,33,0,34,49,33,52,1,32,33,17,3,41,17,33,48,49,33,20,33,37,32,33,17]

theorem envBound42086 : H12AffineFastState.Bounded env42086 := by
  intro p hp
  have h : env42086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42085_42086 : H12AffineEnvironment.transform 8 16 env42085 = env42086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env42085 == env42086) = true)

def leafEnv42086 : List Nat := [2,4,8,16,32,16,9,37,16,52,33,48,40,33,0,34,49,33,52,1,32,33,17,3,20,41,1,17,33,48,49,33,20,33,37,32,4,35,33,17,1,32,0]

def active42086 : List Nat := [0,1,2,3,4]

def tree42086 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42086 : H12WitnessSearch.Good tree42086 := H12GlobalWitnessIndex.good

theorem leafIdentity42086 : H12AffineFastState.composeSystem env42086 rootObs = leafEnv42086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42086 rootObs == leafEnv42086) = true)

theorem terminalChecked42086 : H12PackedTerminal.terminalCheckFast leafEnv42086 active42086 tree42086 = true := by decide +kernel

def env42087 : List Nat := [2,4,8,16,32,16,9,37,512,53,561,48,40,32,0,34,48,561,53,1,32,33,17,3,41,17,561,49,49,561,21,33,37,32,32,513]

theorem envBound42087 : H12AffineFastState.Bounded env42087 := by
  intro p hp
  have h : env42087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42084_42087 : H12AffineEnvironment.transform 9 53 env42084 = env42087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env42084 == env42087) = true)

theorem identity42087 : scanCanonicalize (H12AffineFastState.compose env42087 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound42087 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42088 : List Nat := [2,4,8,16,26,16,9,31,512,15,523,10,18,26,0,24,10,523,15,1,26,27,17,3,19,17,523,11,11,523,21,27,31,26,26,513]

theorem envBound42088 : H12AffineFastState.Bounded env42088 := by
  intro p hp
  have h : env42088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42087_42088 : H12AffineEnvironment.transform 4 26 env42087 = env42088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env42087 == env42088) = true)

def leafEnv42088 : List Nat := [2,4,8,16,26,16,9,31,512,15,523,10,18,26,0,24,10,523,15,1,26,27,17,3,21,19,1,17,523,11,11,523,21,27,31,26,4,25,26,513,1,26,0]

def active42088 : List Nat := [0,1,2,3,8]

def tree42088 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42088 : H12WitnessSearch.Good tree42088 := H12GlobalWitnessIndex.good

theorem leafIdentity42088 : H12AffineFastState.composeSystem env42088 rootObs = leafEnv42088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42088 rootObs == leafEnv42088) = true)

theorem terminalChecked42088 : H12PackedTerminal.terminalCheckFast leafEnv42088 active42088 tree42088 = true := by decide +kernel

def env42089 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,40,1044,0,34,1028,2048,1024,1,33,33,17,3,41,17,2048,1029,48,2048,1056,33,37,32,1044,513]

theorem envBound42089 : H12AffineFastState.Bounded env42089 := by
  intro p hp
  have h : env42089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42082_42089 : H12AffineEnvironment.transform 11 49 env42082 = env42089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env42082 == env42089) = true)

theorem identity42089 : scanCanonicalize (H12AffineFastState.compose env42089 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound42089 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42090 : List Nat := [2,4,8,16,32,16,9,37,512,1024,1541,49,40,1044,0,34,1028,1541,1024,1,33,33,17,3,41,17,1541,1029,48,1541,1056,33,37,32,1044,513]

theorem envBound42090 : H12AffineFastState.Bounded env42090 := by
  intro p hp
  have h : env42090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42089_42090 : H12AffineEnvironment.transform 10 1541 env42089 = env42090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env42089 == env42090) = true)

def env42091 : List Nat := [2,4,8,16,32,16,9,37,512,52,561,49,40,32,0,34,48,561,52,1,33,33,17,3,41,17,561,49,48,561,20,33,37,32,32,513]

theorem envBound42091 : H12AffineFastState.Bounded env42091 := by
  intro p hp
  have h : env42091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42090_42091 : H12AffineEnvironment.transform 9 52 env42090 = env42091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env42090 == env42091) = true)

theorem identity42091 : scanCanonicalize (H12AffineFastState.compose env42091 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound42091 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42092 : List Nat := [2,4,8,16,32,16,9,37,17,52,32,49,40,32,0,34,48,32,52,1,33,33,17,3,41,17,32,49,48,32,20,33,37,32,32,16]

theorem envBound42092 : H12AffineFastState.Bounded env42092 := by
  intro p hp
  have h : env42092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42091_42092 : H12AffineEnvironment.transform 8 17 env42091 = env42092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env42091 == env42092) = true)

def leafEnv42092 : List Nat := [2,4,8,16,32,16,9,37,17,52,32,49,40,32,0,34,48,32,52,1,33,33,17,3,20,41,1,17,32,49,48,32,20,33,37,32,4,35,32,16,1,33,0]

def active42092 : List Nat := [0,1,2,3,4]

def tree42092 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42092 : H12WitnessSearch.Good tree42092 := H12GlobalWitnessIndex.good

theorem leafIdentity42092 : H12AffineFastState.composeSystem env42092 rootObs = leafEnv42092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42092 rootObs == leafEnv42092) = true)

theorem terminalChecked42092 : H12PackedTerminal.terminalCheckFast leafEnv42092 active42092 tree42092 = true := by decide +kernel

def env42093 : List Nat := [2,4,8,16,32,16,9,37,512,53,560,49,40,33,0,34,49,560,53,1,33,33,17,3,41,17,560,48,48,560,21,33,37,32,33,513]

theorem envBound42093 : H12AffineFastState.Bounded env42093 := by
  intro p hp
  have h : env42093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42090_42093 : H12AffineEnvironment.transform 9 53 env42090 = env42093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env42090 == env42093) = true)

theorem identity42093 : scanCanonicalize (H12AffineFastState.compose env42093 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound42093 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42094 : List Nat := [2,4,8,16,27,16,9,30,512,14,523,10,19,26,0,25,10,523,14,1,26,26,17,3,18,17,523,11,11,523,21,26,30,27,26,513]

theorem envBound42094 : H12AffineFastState.Bounded env42094 := by
  intro p hp
  have h : env42094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42093_42094 : H12AffineEnvironment.transform 4 27 env42093 = env42094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env42093 == env42094) = true)

def leafEnv42094 : List Nat := [2,4,8,16,27,16,9,30,512,14,523,10,19,26,0,25,10,523,14,1,26,26,17,3,21,18,1,17,523,11,11,523,21,26,30,27,4,24,26,513,1,26,0]

def active42094 : List Nat := [0,1,2,3,8]

def tree42094 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42094 : H12WitnessSearch.Good tree42094 := H12GlobalWitnessIndex.good

theorem leafIdentity42094 : H12AffineFastState.composeSystem env42094 rootObs = leafEnv42094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42094 rootObs == leafEnv42094) = true)

theorem terminalChecked42094 : H12PackedTerminal.terminalCheckFast leafEnv42094 active42094 tree42094 = true := by decide +kernel

def env42095 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,2420,1024,32769,4160,65911,17,21763,8193,65,56577,115014,17665,35189,119042,8573,256,98679,90202,63068]

theorem envBound42095 : H12AffineFastState.Bounded env42095 := by
  intro p hp
  have h : env42095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42075_42095 : H12AffineEnvironment.transform 16 16401 env42075 = env42095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env42075 == env42095) = true)

theorem identity42095 : scanCanonicalize (H12AffineFastState.compose env42095 (packedSelected [0,3,5,7,9,10,11,12,14,15,16,18,19,22,23,26,32] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound42095 : packedSelected [0,3,5,7,9,10,11,12,14,15,16,18,19,22,23,26,32] rootPS < 2^1333 := by decide +kernel

def env42096 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,65536,16401,2420,1024,32769,4160,65911,17,21763,348,65,56577,115014,17665,35189,119042,32,256,98679,82183,55041]

theorem envBound42096 : H12AffineFastState.Bounded env42096 := by
  intro p hp
  have h : env42096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42095_42096 : H12AffineEnvironment.transform 12 349 env42095 = env42096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env42095 == env42096) = true)

theorem identity42096 : scanCanonicalize (H12AffineFastState.compose env42096 (packedSelected [0,1,4,7,8,19,22] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound42096 : packedSelected [0,1,4,7,8,19,22] rootPS < 2^1333 := by decide +kernel

def env42097 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,349,16384,32768,65536,16401,2420,272,32769,4160,65911,17,20499,348,65,55313,115014,16401,35189,119042,32,256,98679,82183,53777]

theorem envBound42097 : H12AffineFastState.Bounded env42097 := by
  intro p hp
  have h : env42097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42096_42097 : H12AffineEnvironment.transform 9 272 env42096 = env42097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env42096 == env42097) = true)

theorem identity42097 : scanCanonicalize (H12AffineFastState.compose env42097 (packedSelected [11,18] rootPS)) = affineNative (2^(15+1) ^^^ 20579) := by decide +kernel

theorem selectedBound42097 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env42098 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,349,16384,32768,20579,16401,2420,272,32769,4160,20756,17,20499,348,65,55313,37157,16401,35189,33121,32,256,53524,4452,53777]

theorem envBound42098 : H12AffineFastState.Bounded env42098 := by
  intro p hp
  have h : env42098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42097_42098 : H12AffineEnvironment.transform 15 20579 env42097 = env42098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20579 env42097 == env42098) = true)

theorem identity42098 : scanCanonicalize (H12AffineFastState.compose env42098 (packedSelected [0,4,6,7,9,12,15,16,20] rootPS)) = affineNative (2^(14+1) ^^^ 20789) := by decide +kernel

theorem selectedBound42098 : packedSelected [0,4,6,7,9,12,15,16,20] rootPS < 2^1333 := by decide +kernel

def env42099 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,349,16384,20789,20579,16401,2420,272,20788,4160,20756,17,20499,348,65,2340,16400,16401,22592,20564,32,256,33,4452,804]

theorem envBound42099 : H12AffineFastState.Bounded env42099 := by
  intro p hp
  have h : env42099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42098_42099 : H12AffineEnvironment.transform 14 20789 env42098 = env42099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20789 env42098 == env42099) = true)

theorem identity42099 : scanCanonicalize (H12AffineFastState.compose env42099 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound42099 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42100 : List Nat := [2,4,8,16,32,64,9,36,512,52,2048,4096,121,16384,20497,20579,16401,2128,52,20496,4160,20528,17,20499,120,65,2048,16400,16401,22592,20564,32,36,33,4160,512]

theorem envBound42100 : H12AffineFastState.Bounded env42100 := by
  intro p hp
  have h : env42100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42099_42100 : H12AffineEnvironment.transform 7 36 env42099 = env42100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env42099 == env42100) = true)

theorem identity42100 : scanCanonicalize (H12AffineFastState.compose env42100 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42100 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env42101 : List Nat := [2,4,8,16,1,64,9,5,512,21,2048,4096,88,16384,20497,20546,16401,2128,21,20496,4160,20497,17,20499,89,65,2048,16400,16401,22592,20564,1,5,0,4160,512]

theorem envBound42101 : H12AffineFastState.Bounded env42101 := by
  intro p hp
  have h : env42101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42100_42101 : H12AffineEnvironment.transform 4 1 env42100 = env42101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42100 == env42101) = true)

theorem identity42101 : scanCanonicalize (H12AffineFastState.compose env42101 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound42101 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env42102 : List Nat := [2,4,8,16,1,64,9,5,512,21,2048,4096,88,4112,1,82,4097,2128,21,0,4160,1,17,3,89,65,2048,4096,4097,2128,68,1,5,0,4160,512]

theorem envBound42102 : H12AffineFastState.Bounded env42102 := by
  intro p hp
  have h : env42102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42101_42102 : H12AffineEnvironment.transform 13 4112 env42101 = env42102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env42101 == env42102) = true)

theorem identity42102 : scanCanonicalize (H12AffineFastState.compose env42102 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42102 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42103 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,4096,9,4112,1,3,4097,2049,21,0,4113,1,17,3,8,16,2048,4096,4097,2049,21,1,5,0,4113,512]

theorem envBound42103 : H12AffineFastState.Bounded env42103 := by
  intro p hp
  have h : env42103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42102_42103 : H12AffineEnvironment.transform 5 17 env42102 = env42103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42102 == env42103) = true)

theorem identity42103 : scanCanonicalize (H12AffineFastState.compose env42103 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 20) := by decide +kernel

theorem selectedBound42103 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42104 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,20,9,4,1,3,21,2049,21,0,5,1,17,3,8,16,2048,20,21,2049,21,1,5,0,5,512]

theorem envBound42104 : H12AffineFastState.Bounded env42104 := by
  intro p hp
  have h : env42104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42103_42104 : H12AffineEnvironment.transform 11 20 env42103 = env42104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 20 env42103 == env42104) = true)

theorem identity42104 : scanCanonicalize (H12AffineFastState.compose env42104 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 4) := by decide +kernel

theorem selectedBound42104 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env42105 : List Nat := [2,4,8,16,1,17,9,5,512,21,4,20,9,4,1,3,21,5,21,0,5,1,17,3,8,16,4,20,21,5,21,1,5,0,5,512]

theorem envBound42105 : H12AffineFastState.Bounded env42105 := by
  intro p hp
  have h : env42105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42104_42105 : H12AffineEnvironment.transform 10 4 env42104 = env42105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 4 env42104 == env42105) = true)

def env42106 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4161,4194304,8388608,21762,8328,65,12705007,115151,8406289,8423917,8507666,4268163,256,8487407,8478795,8451781]

theorem envBound42106 : H12AffineFastState.Bounded env42106 := by
  intro p hp
  have h : env42106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42035_42106 : H12AffineEnvironment.transform 20 4161 env42035 = env42106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env42035 == env42106) = true)

def env42107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4161,4194304,16,21762,8328,65,4316415,115151,17665,35325,119042,4268163,256,98815,90203,63189]

theorem envBound42107 : H12AffineFastState.Bounded env42107 := by
  intro p hp
  have h : env42107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42106_42107 : H12AffineEnvironment.transform 22 16 env42106 = env42107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env42106 == env42107) = true)

theorem identity42107 : scanCanonicalize (H12AffineFastState.compose env42107 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound42107 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42108 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149996,1024,32769,4161,4194304,16,21762,8328,65,4259060,57796,17665,35325,61705,4194440,256,41460,16464,63189]

theorem envBound42108 : H12AffineFastState.Bounded env42108 := by
  intro p hp
  have h : env42108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42107_42108 : H12AffineEnvironment.transform 15 8203 env42107 = env42108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env42107 == env42108) = true)

def env42109 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149860,1024,32769,4161,4194304,16,21762,8192,65,4258940,57676,17665,35189,61705,4194304,256,41340,16464,63069]

theorem envBound42109 : H12AffineFastState.Bounded env42109 := by
  intro p hp
  have h : env42109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42108_42109 : H12AffineEnvironment.transform 6 8 env42108 = env42109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42108 == env42109) = true)

theorem identity42109 : scanCanonicalize (H12AffineFastState.compose env42109 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound42109 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42110 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,49168,35188,1024,32769,4161,4194304,16,21762,8192,65,4258940,57676,17665,35189,61705,4194304,256,41340,16464,63069]

theorem envBound42110 : H12AffineFastState.Bounded env42110 := by
  intro p hp
  have h : env42110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42109_42110 : H12AffineEnvironment.transform 16 49168 env42109 = env42110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env42109 == env42110) = true)

theorem identity42110 : scanCanonicalize (H12AffineFastState.compose env42110 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 41340) := by decide +kernel

theorem selectedBound42110 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env42111 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,49168,35188,1024,32769,4161,41340,16,21762,8192,65,23808,57676,17665,35189,61705,41340,256,41340,16464,63069]

theorem envBound42111 : H12AffineFastState.Bounded env42111 := by
  intro p hp
  have h : env42111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42110_42111 : H12AffineEnvironment.transform 21 41340 env42110 = env42111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41340 env42110 == env42111) = true)

theorem identity42111 : scanCanonicalize (H12AffineFastState.compose env42111 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 341) := by decide +kernel

theorem selectedBound42111 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env42112 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,341,8203,16709,2081,1024,340,4161,8233,16,21762,8192,65,23808,24601,17665,2080,28764,8233,256,8233,16464,30472]

theorem envBound42112 : H12AffineFastState.Bounded env42112 := by
  intro p hp
  have h : env42112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42111_42112 : H12AffineEnvironment.transform 14 341 env42111 = env42112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 341 env42111 == env42112) = true)

theorem identity42112 : scanCanonicalize (H12AffineFastState.compose env42112 (packedSelected [1,2,3,4,5,6,8,9,10,14,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound42112 : packedSelected [1,2,3,4,5,6,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env42113 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,341,8203,5188,2081,1024,340,4161,8233,16,3,8192,65,2049,13592,4096,2080,9565,8233,256,8233,5457,8713]

theorem envBound42113 : H12AffineFastState.Bounded env42113 := by
  intro p hp
  have h : env42113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42112_42113 : H12AffineEnvironment.transform 13 5377 env42112 = env42113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env42112 == env42113) = true)

theorem identity42113 : scanCanonicalize (H12AffineFastState.compose env42113 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound42113 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env42114 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5377,341,35,5188,2081,1024,340,4161,1,16,3,40,65,2049,5424,4096,2080,1397,1,256,1,5457,545]

theorem envBound42114 : H12AffineFastState.Bounded env42114 := by
  intro p hp
  have h : env42114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42113_42114 : H12AffineEnvironment.transform 12 40 env42113 = env42114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env42113 == env42114) = true)

theorem identity42114 : scanCanonicalize (H12AffineFastState.compose env42114 (packedSelected [1,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound42114 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env42115 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1077,4096,40,5377,341,35,5188,1044,1024,340,4161,1,16,3,40,65,1076,5424,4096,1045,1397,1,256,1,5457,545]

theorem envBound42115 : H12AffineFastState.Bounded env42115 := by
  intro p hp
  have h : env42115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42114_42115 : H12AffineEnvironment.transform 10 1077 env42114 = env42115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env42114 == env42115) = true)

theorem identity42115 : scanCanonicalize (H12AffineFastState.compose env42115 (packedSelected [1,2,3,5,8,14] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound42115 : packedSelected [1,2,3,5,8,14] rootPS < 2^1333 := by decide +kernel

def env42116 : List Nat := [2,4,8,16,32,64,8,84,512,1024,1077,4096,40,5205,1,35,5188,1044,1024,0,4161,1,16,3,40,65,1076,5220,4096,1045,1057,1,84,1,5125,545]

theorem envBound42116 : H12AffineFastState.Bounded env42116 := by
  intro p hp
  have h : env42116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42115_42116 : H12AffineEnvironment.transform 7 84 env42115 = env42116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env42115 == env42116) = true)

theorem identity42116 : scanCanonicalize (H12AffineFastState.compose env42116 (packedSelected [0,2,3,5,7,12] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound42116 : packedSelected [0,2,3,5,7,12] rootPS < 2^1333 := by decide +kernel

def env42117 : List Nat := [2,4,8,0,32,64,8,68,512,1024,1061,4096,40,5189,1,35,5188,1028,1024,0,4161,1,0,3,40,65,1060,5220,4096,1029,1057,1,68,1,5125,545]

theorem envBound42117 : H12AffineFastState.Bounded env42117 := by
  intro p hp
  have h : env42117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42116_42117 : H12AffineEnvironment.transform 3 0 env42116 = env42117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42116 == env42117) = true)

theorem identity42117 : scanCanonicalize (H12AffineFastState.compose env42117 (packedSelected [1,2,8] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound42117 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env42118 : List Nat := [2,4,8,0,32,64,8,68,512,1024,1061,32,40,1125,1,35,1124,1028,1024,0,97,1,0,3,40,65,1060,1092,32,1029,1057,1,68,1,1061,545]

theorem envBound42118 : H12AffineFastState.Bounded env42118 := by
  intro p hp
  have h : env42118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42117_42118 : H12AffineEnvironment.transform 11 32 env42117 = env42118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env42117 == env42118) = true)

theorem identity42118 : scanCanonicalize (H12AffineFastState.compose env42118 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound42118 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env42119 : List Nat := [2,4,8,0,32,64,8,68,64,1024,1061,32,40,1125,1,35,1124,1028,1024,0,97,1,0,3,40,65,1060,1092,32,1029,1057,1,68,1,1061,97]

theorem envBound42119 : H12AffineFastState.Bounded env42119 := by
  intro p hp
  have h : env42119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42118_42119 : H12AffineEnvironment.transform 8 64 env42118 = env42119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env42118 == env42119) = true)

theorem identity42119 : scanCanonicalize (H12AffineFastState.compose env42119 (packedSelected [2,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound42119 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env42120 : List Nat := [2,4,8,0,0,64,8,68,64,1024,1029,0,8,1093,1,3,1092,1028,1024,0,65,1,0,3,8,65,1028,1092,0,1029,1025,1,68,1,1029,65]

theorem envBound42120 : H12AffineFastState.Bounded env42120 := by
  intro p hp
  have h : env42120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42119_42120 : H12AffineEnvironment.transform 4 0 env42119 = env42120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42119 == env42120) = true)

theorem identity42120 : scanCanonicalize (H12AffineFastState.compose env42120 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound42120 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env42121 : List Nat := [2,4,8,0,0,64,8,68,64,5,0,0,8,64,1,3,65,1,5,0,65,1,0,3,8,65,1,65,0,0,4,1,68,1,0,65]

theorem envBound42121 : H12AffineFastState.Bounded env42121 := by
  intro p hp
  have h : env42121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42120_42121 : H12AffineEnvironment.transform 9 5 env42120 = env42121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env42120 == env42121) = true)

def env42122 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149861,1024,32769,4161,4194304,16,21762,8193,65,4258941,57677,17665,35188,61705,4194305,256,41341,16464,63068]

theorem envBound42122 : H12AffineFastState.Bounded env42122 := by
  intro p hp
  have h : env42122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42108_42122 : H12AffineEnvironment.transform 6 9 env42108 = env42122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42108 == env42122) = true)

theorem identity42122 : scanCanonicalize (H12AffineFastState.compose env42122 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound42122 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42123 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,24909,10280,1024,32769,4161,4194304,16,21762,8193,65,4258941,57677,17665,35188,61705,4194305,256,41341,16464,63068]

theorem envBound42123 : H12AffineFastState.Bounded env42123 := by
  intro p hp
  have h : env42123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42122_42123 : H12AffineEnvironment.transform 16 24909 env42122 = env42123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env42122 == env42123) = true)

theorem identity42123 : scanCanonicalize (H12AffineFastState.compose env42123 (packedSelected [2,3,5,6,7,9,10,11,16,18,22,27] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound42123 : packedSelected [2,3,5,6,7,9,10,11,16,18,22,27] rootPS < 2^1333 := by decide +kernel

def env42124 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,13389,10280,1024,32769,4161,4194304,16,2,8193,65,4237693,46157,4097,35188,41993,4194305,256,41341,5456,41820]

theorem envBound42124 : H12AffineFastState.Bounded env42124 := by
  intro p hp
  have h : env42124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42123_42124 : H12AffineEnvironment.transform 13 5376 env42123 = env42124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env42123 == env42124) = true)

theorem identity42124 : scanCanonicalize (H12AffineFastState.compose env42124 (packedSelected [16,20] rootPS)) = affineNative (2^(21+1) ^^^ 32800) := by decide +kernel

theorem selectedBound42124 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env42125 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,13389,10280,1024,32769,4161,32800,16,2,8193,65,10589,46157,4097,35188,41993,32801,256,41341,5456,41820]

theorem envBound42125 : H12AffineFastState.Bounded env42125 := by
  intro p hp
  have h : env42125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42124_42125 : H12AffineEnvironment.transform 21 32800 env42124 = env42125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32800 env42124 == env42125) = true)

theorem identity42125 : scanCanonicalize (H12AffineFastState.compose env42125 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound42125 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env42126 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,32768,343,5393,2420,1024,32769,4161,32800,16,2,349,65,2049,38161,4097,35188,34133,32801,256,32801,5456,33280]

theorem envBound42126 : H12AffineFastState.Bounded env42126 := by
  intro p hp
  have h : env42126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42125_42126 : H12AffineEnvironment.transform 12 348 env42125 = env42126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env42125 == env42126) = true)

theorem identity42126 : scanCanonicalize (H12AffineFastState.compose env42126 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 340) := by decide +kernel

theorem selectedBound42126 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env42127 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,340,343,5393,2420,1024,341,4161,372,16,2,349,65,2049,5189,4097,2080,1025,373,256,373,5456,852]

theorem envBound42127 : H12AffineFastState.Bounded env42127 := by
  intro p hp
  have h : env42127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42126_42127 : H12AffineEnvironment.transform 14 340 env42126 = env42127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 340 env42126 == env42127) = true)

theorem identity42127 : scanCanonicalize (H12AffineFastState.compose env42127 (packedSelected [6,11,12,14,15,23] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound42127 : packedSelected [6,11,12,14,15,23] rootPS < 2^1333 := by decide +kernel

def env42128 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,4096,8,5204,0,3,5189,2080,1024,1,4161,32,16,2,9,65,2049,5189,4097,2080,1025,33,84,33,5124,512]

theorem envBound42128 : H12AffineFastState.Bounded env42128 := by
  intro p hp
  have h : env42128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42127_42128 : H12AffineEnvironment.transform 7 84 env42127 = env42128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env42127 == env42128) = true)

theorem identity42128 : scanCanonicalize (H12AffineFastState.compose env42128 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3167) := by decide +kernel

theorem selectedBound42128 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42129 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,3167,8,2059,0,3,2074,2080,1024,1,3102,32,16,2,9,65,2049,2074,3166,2080,1025,33,84,33,2139,512]

theorem envBound42129 : H12AffineFastState.Bounded env42129 := by
  intro p hp
  have h : env42129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42128_42129 : H12AffineEnvironment.transform 11 3167 env42128 = env42129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3167 env42128 == env42129) = true)

theorem identity42129 : scanCanonicalize (H12AffineFastState.compose env42129 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42129 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42130 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,3167,8,2059,0,3,2074,2049,1024,1,3102,1,16,2,9,65,2049,2074,3166,2049,1025,0,84,0,2139,512]

theorem envBound42130 : H12AffineFastState.Bounded env42130 := by
  intro p hp
  have h : env42130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42129_42130 : H12AffineEnvironment.transform 4 1 env42129 = env42130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42129 == env42130) = true)

theorem identity42130 : scanCanonicalize (H12AffineFastState.compose env42130 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 95) := by decide +kernel

theorem selectedBound42130 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env42131 : List Nat := [2,4,8,16,1,64,9,84,512,95,2048,2048,8,2059,0,3,2074,2049,95,1,2113,1,16,2,9,65,2049,2074,2049,2049,94,0,84,0,2139,512]

theorem envBound42131 : H12AffineFastState.Bounded env42131 := by
  intro p hp
  have h : env42131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42130_42131 : H12AffineEnvironment.transform 9 95 env42130 = env42131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 95 env42130 == env42131) = true)

theorem identity42131 : scanCanonicalize (H12AffineFastState.compose env42131 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound42131 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env42132 : List Nat := [2,4,8,16,1,0,9,20,512,31,2048,2048,8,2059,0,3,2074,2049,31,1,2049,1,16,2,9,1,2049,2074,2049,2049,30,0,20,0,2075,512]

theorem envBound42132 : H12AffineFastState.Bounded env42132 := by
  intro p hp
  have h : env42132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42131_42132 : H12AffineEnvironment.transform 5 0 env42131 = env42132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env42131 == env42132) = true)

theorem identity42132 : scanCanonicalize (H12AffineFastState.compose env42132 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound42132 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env42133 : List Nat := [2,4,8,11,1,0,9,15,512,4,2048,2048,8,2059,0,3,2049,2049,4,1,2049,1,11,2,9,1,2049,2049,2049,2049,5,0,15,0,2048,512]

theorem envBound42133 : H12AffineFastState.Bounded env42133 := by
  intro p hp
  have h : env42133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42132_42133 : H12AffineEnvironment.transform 3 11 env42132 = env42133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env42132 == env42133) = true)

theorem identity42133 : scanCanonicalize (H12AffineFastState.compose env42133 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound42133 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env42134 : List Nat := [2,4,8,11,1,0,9,15,3,4,2048,2048,8,2059,0,3,2049,2049,4,1,2049,1,11,2,9,1,2049,2049,2049,2049,5,0,15,0,2048,3]

theorem envBound42134 : H12AffineFastState.Bounded env42134 := by
  intro p hp
  have h : env42134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42133_42134 : H12AffineEnvironment.transform 8 3 env42133 = env42134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env42133 == env42134) = true)

theorem identity42134 : scanCanonicalize (H12AffineFastState.compose env42134 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound42134 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42135 : List Nat := [2,4,3,0,1,0,2,4,3,4,2048,2048,3,2048,0,3,2049,2049,4,1,2049,1,0,2,2,1,2049,2049,2049,2049,5,0,4,0,2048,3]

theorem envBound42135 : H12AffineFastState.Bounded env42135 := by
  intro p hp
  have h : env42135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42134_42135 : H12AffineEnvironment.transform 2 3 env42134 = env42135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env42134 == env42135) = true)

theorem identity42135 : scanCanonicalize (H12AffineFastState.compose env42135 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound42135 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42136 : List Nat := [2,3,3,0,1,0,2,3,3,3,2048,2048,3,2048,0,3,2049,2049,3,1,2049,1,0,2,2,1,2049,2049,2049,2049,2,0,3,0,2048,3]

theorem envBound42136 : H12AffineFastState.Bounded env42136 := by
  intro p hp
  have h : env42136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42135_42136 : H12AffineEnvironment.transform 1 3 env42135 = env42136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env42135 == env42136) = true)

theorem identity42136 : scanCanonicalize (H12AffineFastState.compose env42136 (packedSelected [11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound42136 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env42137 : List Nat := [2,3,3,0,1,0,2,3,3,3,1,1,3,1,0,3,0,0,3,1,0,1,0,2,2,1,0,0,0,0,2,0,3,0,1,3]

theorem envBound42137 : H12AffineFastState.Bounded env42137 := by
  intro p hp
  have h : env42137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42136_42137 : H12AffineEnvironment.transform 10 1 env42136 = env42137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env42136 == env42137) = true)

def env42138 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4161,4194304,17,21762,8328,65,4316414,115151,17664,35324,119043,4268163,256,98814,90202,63188]

theorem envBound42138 : H12AffineFastState.Bounded env42138 := by
  intro p hp
  have h : env42138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42106_42138 : H12AffineEnvironment.transform 22 17 env42106 = env42138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env42106 == env42138) = true)

theorem identity42138 : scanCanonicalize (H12AffineFastState.compose env42138 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 243123) := by decide +kernel

theorem selectedBound42138 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42139 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4161,243123,17,21762,8328,65,158029,115151,17664,35324,119043,169264,256,98814,90202,63188]

theorem envBound42139 : H12AffineFastState.Bounded env42139 := by
  intro p hp
  have h : env42139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42138_42139 : H12AffineEnvironment.transform 21 243123 env42138 = env42139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 243123 env42138 == env42139) = true)

theorem identity42139 : scanCanonicalize (H12AffineFastState.compose env42139 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound42139 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env42140 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,149996,1024,29908,4161,213350,17,21762,8328,65,158029,79130,17664,32041,75222,156133,256,95531,90202,513]

theorem envBound42140 : H12AffineFastState.Bounded env42140 := by
  intro p hp
  have h : env42140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42139_42140 : H12AffineEnvironment.transform 14 29909 env42139 = env42140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env42139 == env42140) = true)

theorem identity42140 : scanCanonicalize (H12AffineFastState.compose env42140 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound42140 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env42141 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90138,76278,1024,29908,4161,8572,17,21762,8328,65,67927,79130,17664,32041,75222,66047,256,95531,90202,513]

theorem envBound42141 : H12AffineFastState.Bounded env42141 := by
  intro p hp
  have h : env42141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42140_42141 : H12AffineEnvironment.transform 16 90138 env42140 = env42141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env42140 == env42141) = true)

def env42142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,79130,76278,1024,8660,4161,8572,17,2,8328,65,67927,79130,4096,10281,75222,66047,256,73771,79194,513]

theorem envBound42142 : H12AffineFastState.Bounded env42142 := by
  intro p hp
  have h : env42142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42141_42142 : H12AffineEnvironment.transform 13 5376 env42141 = env42142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env42141 == env42142) = true)

theorem identity42142 : scanCanonicalize (H12AffineFastState.compose env42142 (packedSelected [1,2,3,4,6,9,14,18,20,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound42142 : packedSelected [1,2,3,4,6,9,14,18,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env42143 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,343,13389,10401,1024,8660,4161,8572,17,2,8328,65,2048,13389,4096,10281,9345,168,256,8572,13325,513]

theorem envBound42143 : H12AffineFastState.Bounded env42143 := by
  intro p hp
  have h : env42143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42142_42143 : H12AffineEnvironment.transform 15 343 env42142 = env42143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env42142 == env42143) = true)

theorem identity42143 : scanCanonicalize (H12AffineFastState.compose env42143 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound42143 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env42144 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,5376,8461,343,13389,10361,1024,8460,4161,8572,17,2,8272,65,2048,13389,4096,10281,9305,112,256,8572,13325,513]

theorem envBound42144 : H12AffineFastState.Bounded env42144 := by
  intro p hp
  have h : env42144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42143_42144 : H12AffineEnvironment.transform 6 88 env42143 = env42144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env42143 == env42144) = true)

theorem identity42144 : scanCanonicalize (H12AffineFastState.compose env42144 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound42144 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42145 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,268,5376,1,343,5441,2421,1024,0,4161,112,17,2,348,65,2048,5441,4096,2341,1365,112,256,112,5377,513]

theorem envBound42145 : H12AffineFastState.Bounded env42145 := by
  intro p hp
  have h : env42145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42144_42145 : H12AffineEnvironment.transform 12 268 env42144 = env42145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env42144 == env42145) = true)

theorem identity42145 : scanCanonicalize (H12AffineFastState.compose env42145 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound42145 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env42146 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,65,268,1345,1,343,1280,2421,1024,0,0,112,17,2,348,65,2048,1280,65,2341,1365,112,256,112,1344,513]

theorem envBound42146 : H12AffineFastState.Bounded env42146 := by
  intro p hp
  have h : env42146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42145_42146 : H12AffineEnvironment.transform 11 65 env42145 = env42146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env42145 == env42146) = true)

theorem identity42146 : scanCanonicalize (H12AffineFastState.compose env42146 (packedSelected [0,9] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound42146 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env42147 : List Nat := [2,4,8,16,32,64,88,256,512,273,2048,65,268,80,1,343,17,2421,273,0,0,112,17,2,348,65,2048,17,65,2341,68,112,256,112,81,513]

theorem envBound42147 : H12AffineFastState.Bounded env42147 := by
  intro p hp
  have h : env42147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42146_42147 : H12AffineEnvironment.transform 9 273 env42146 = env42147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env42146 == env42147) = true)

theorem identity42147 : scanCanonicalize (H12AffineFastState.compose env42147 (packedSelected [1,8] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound42147 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env42148 : List Nat := [2,4,8,16,32,64,88,256,512,273,292,65,268,80,1,343,17,81,273,0,0,112,17,2,348,65,292,17,65,1,68,112,256,112,81,513]

theorem envBound42148 : H12AffineFastState.Bounded env42148 := by
  intro p hp
  have h : env42148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42147_42148 : H12AffineEnvironment.transform 10 292 env42147 = env42148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env42147 == env42148) = true)

def env42149 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,79131,76278,1024,8661,4161,8572,17,3,8328,65,67927,79130,4097,10280,75222,66047,256,73770,79195,513]

theorem envBound42149 : H12AffineFastState.Bounded env42149 := by
  intro p hp
  have h : env42149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42141_42149 : H12AffineEnvironment.transform 13 5377 env42141 = env42149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env42141 == env42149) = true)

theorem identity42149 : scanCanonicalize (H12AffineFastState.compose env42149 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound42149 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42150 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,79131,76159,1024,8540,4161,8572,17,3,8193,65,67927,79130,4097,10280,75103,65910,256,73770,79195,513]

theorem envBound42150 : H12AffineFastState.Bounded env42150 := by
  intro p hp
  have h : env42150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42149_42150 : H12AffineEnvironment.transform 6 9 env42149 = env42150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42149 == env42150) = true)

theorem identity42150 : scanCanonicalize (H12AffineFastState.compose env42150 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound42150 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env42151 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,5393,2421,1024,8540,4161,8572,17,3,8193,65,10589,5392,4097,10280,1365,8572,256,32,5457,513]

theorem envBound42151 : H12AffineFastState.Bounded env42151 := by
  intro p hp
  have h : env42151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42150_42151 : H12AffineEnvironment.transform 15 8202 env42150 = env42151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env42150 == env42151) = true)

theorem identity42151 : scanCanonicalize (H12AffineFastState.compose env42151 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound42151 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42152 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,343,5393,2421,1024,1,4161,33,17,3,348,65,2048,5392,4097,2421,1365,33,256,32,5457,513]

theorem envBound42152 : H12AffineFastState.Bounded env42152 := by
  intro p hp
  have h : env42152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42151_42152 : H12AffineEnvironment.transform 12 349 env42151 = env42152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env42151 == env42152) = true)

theorem identity42152 : scanCanonicalize (H12AffineFastState.compose env42152 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound42152 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42153 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,41,5237,0,35,5221,2049,1024,1,4161,33,17,3,40,65,2048,5220,4097,2049,1057,33,116,32,5157,513]

theorem envBound42153 : H12AffineFastState.Bounded env42153 := by
  intro p hp
  have h : env42153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42152_42153 : H12AffineEnvironment.transform 7 116 env42152 = env42153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env42152 == env42153) = true)

theorem identity42153 : scanCanonicalize (H12AffineFastState.compose env42153 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42153 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env42154 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5157,0,35,5173,2049,1024,1,4113,33,17,3,40,17,2048,5172,4097,2049,1057,33,36,32,5157,513]

theorem envBound42154 : H12AffineFastState.Bounded env42154 := by
  intro p hp
  have h : env42154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42153_42154 : H12AffineEnvironment.transform 5 16 env42153 = env42154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42153 == env42154) = true)

def env42155 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,48,41,1045,0,35,1029,2049,1024,1,33,33,17,3,40,17,2048,1028,49,2049,1057,33,36,32,1045,513]

theorem envBound42155 : H12AffineFastState.Bounded env42155 := by
  intro p hp
  have h : env42155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42154_42155 : H12AffineEnvironment.transform 11 48 env42154 = env42155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env42154 == env42155) = true)

theorem identity42155 : scanCanonicalize (H12AffineFastState.compose env42155 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound42155 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42156 : List Nat := [2,4,8,16,32,16,9,36,512,20,2048,48,41,1,0,35,17,2049,20,1,33,33,17,3,40,17,2048,16,49,2049,53,33,36,32,1,513]

theorem envBound42156 : H12AffineFastState.Bounded env42156 := by
  intro p hp
  have h : env42156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42155_42156 : H12AffineEnvironment.transform 9 20 env42155 = env42156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env42155 == env42156) = true)

def env42157 : List Nat := [2,4,8,16,0,16,9,4,512,20,2048,16,9,1,0,3,17,2049,20,1,1,1,17,3,8,17,2048,16,17,2049,21,1,4,0,1,513]

theorem envBound42157 : H12AffineFastState.Bounded env42157 := by
  intro p hp
  have h : env42157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42156_42157 : H12AffineEnvironment.transform 4 0 env42156 = env42157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42156 == env42157) = true)

theorem identity42157 : scanCanonicalize (H12AffineFastState.compose env42157 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound42157 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42158 : List Nat := [2,4,8,16,0,16,9,4,512,20,1,16,9,1,0,3,17,0,20,1,1,1,17,3,8,17,1,16,17,0,21,1,4,0,1,513]

theorem envBound42158 : H12AffineFastState.Bounded env42158 := by
  intro p hp
  have h : env42158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42157_42158 : H12AffineEnvironment.transform 10 1 env42157 = env42158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env42157 == env42158) = true)

def leafEnv42158 : List Nat := [2,4,8,16,0,16,9,4,512,20,1,16,9,1,0,3,17,0,20,1,1,1,17,3,21,8,1,17,1,16,17,0,21,1,4,0,4,2,1,513,1,1,0]

def active42158 : List Nat := [0,1,2,3,8]

def tree42158 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42158 : H12WitnessSearch.Good tree42158 := H12GlobalWitnessIndex.good

theorem leafIdentity42158 : H12AffineFastState.composeSystem env42158 rootObs = leafEnv42158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42158 rootObs == leafEnv42158) = true)

theorem terminalChecked42158 : H12PackedTerminal.terminalCheckFast leafEnv42158 active42158 tree42158 = true := by decide +kernel

def env42159 : List Nat := [2,4,8,16,1,16,9,5,512,20,2048,17,8,1,0,2,17,2049,20,1,0,0,17,3,9,17,2048,16,16,2049,20,0,5,1,1,513]

theorem envBound42159 : H12AffineFastState.Bounded env42159 := by
  intro p hp
  have h : env42159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42156_42159 : H12AffineEnvironment.transform 4 1 env42156 = env42159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42156 == env42159) = true)

theorem identity42159 : scanCanonicalize (H12AffineFastState.compose env42159 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound42159 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42160 : List Nat := [2,4,8,16,1,16,9,5,512,20,522,17,8,1,0,2,17,523,20,1,0,0,17,3,9,17,522,16,16,523,20,0,5,1,1,513]

theorem envBound42160 : H12AffineFastState.Bounded env42160 := by
  intro p hp
  have h : env42160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42159_42160 : H12AffineEnvironment.transform 10 522 env42159 = env42160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env42159 == env42160) = true)

def leafEnv42160 : List Nat := [2,4,8,16,1,16,9,5,512,20,522,17,8,1,0,2,17,523,20,1,0,0,17,3,20,9,1,17,522,16,16,523,20,0,5,1,4,3,1,513,1,0,0]

def active42160 : List Nat := [0,1,2,3,8]

def tree42160 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42160 : H12WitnessSearch.Good tree42160 := H12GlobalWitnessIndex.good

theorem leafIdentity42160 : H12AffineFastState.composeSystem env42160 rootObs = leafEnv42160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42160 rootObs == leafEnv42160) = true)

theorem terminalChecked42160 : H12PackedTerminal.terminalCheckFast leafEnv42160 active42160 tree42160 = true := by decide +kernel

def env42161 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,49,41,1044,0,35,1028,2049,1024,1,32,33,17,3,40,17,2048,1029,48,2049,1057,33,36,32,1044,513]

theorem envBound42161 : H12AffineFastState.Bounded env42161 := by
  intro p hp
  have h : env42161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42154_42161 : H12AffineEnvironment.transform 11 49 env42154 = env42161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env42154 == env42161) = true)

theorem identity42161 : scanCanonicalize (H12AffineFastState.compose env42161 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound42161 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42162 : List Nat := [2,4,8,16,0,16,9,4,512,1024,2048,17,9,1044,0,3,1028,2049,1024,1,0,1,17,3,8,17,2048,1029,16,2049,1025,1,4,0,1044,513]

theorem envBound42162 : H12AffineFastState.Bounded env42162 := by
  intro p hp
  have h : env42162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42161_42162 : H12AffineEnvironment.transform 4 0 env42161 = env42162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42161 == env42162) = true)

def env42163 : List Nat := [2,4,8,16,0,16,9,4,512,20,2048,17,9,0,0,3,16,2049,20,1,0,1,17,3,8,17,2048,17,16,2049,21,1,4,0,0,513]

theorem envBound42163 : H12AffineFastState.Bounded env42163 := by
  intro p hp
  have h : env42163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42162_42163 : H12AffineEnvironment.transform 9 20 env42162 = env42163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env42162 == env42163) = true)

theorem identity42163 : scanCanonicalize (H12AffineFastState.compose env42163 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound42163 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42164 : List Nat := [2,4,8,16,0,16,9,4,512,20,0,17,9,0,0,3,16,1,20,1,0,1,17,3,8,17,0,17,16,1,21,1,4,0,0,513]

theorem envBound42164 : H12AffineFastState.Bounded env42164 := by
  intro p hp
  have h : env42164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42163_42164 : H12AffineEnvironment.transform 10 0 env42163 = env42164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env42163 == env42164) = true)

def leafEnv42164 : List Nat := [2,4,8,16,0,16,9,4,512,20,0,17,9,0,0,3,16,1,20,1,0,1,17,3,21,8,1,17,0,17,16,1,21,1,4,0,4,2,0,513,1,0,0]

def active42164 : List Nat := [0,1,2,3,8]

def tree42164 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42164 : H12WitnessSearch.Good tree42164 := H12GlobalWitnessIndex.good

theorem leafIdentity42164 : H12AffineFastState.composeSystem env42164 rootObs = leafEnv42164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42164 rootObs == leafEnv42164) = true)

theorem terminalChecked42164 : H12PackedTerminal.terminalCheckFast leafEnv42164 active42164 tree42164 = true := by decide +kernel

def env42165 : List Nat := [2,4,8,16,0,16,9,4,512,21,2048,17,9,1,0,3,17,2049,21,1,0,1,17,3,8,17,2048,16,16,2049,20,1,4,0,1,513]

theorem envBound42165 : H12AffineFastState.Bounded env42165 := by
  intro p hp
  have h : env42165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42162_42165 : H12AffineEnvironment.transform 9 21 env42162 = env42165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env42162 == env42165) = true)

theorem identity42165 : scanCanonicalize (H12AffineFastState.compose env42165 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound42165 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42166 : List Nat := [2,4,8,16,0,16,9,4,512,21,522,17,9,1,0,3,17,523,21,1,0,1,17,3,8,17,522,16,16,523,20,1,4,0,1,513]

theorem envBound42166 : H12AffineFastState.Bounded env42166 := by
  intro p hp
  have h : env42166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42165_42166 : H12AffineEnvironment.transform 10 522 env42165 = env42166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env42165 == env42166) = true)

def leafEnv42166 : List Nat := [2,4,8,16,0,16,9,4,512,21,522,17,9,1,0,3,17,523,21,1,0,1,17,3,20,8,1,17,522,16,16,523,20,1,4,0,4,2,1,513,1,0,0]

def active42166 : List Nat := [0,1,2,3,8]

def tree42166 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42166 : H12WitnessSearch.Good tree42166 := H12GlobalWitnessIndex.good

theorem leafIdentity42166 : H12AffineFastState.composeSystem env42166 rootObs = leafEnv42166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42166 rootObs == leafEnv42166) = true)

theorem terminalChecked42166 : H12PackedTerminal.terminalCheckFast leafEnv42166 active42166 tree42166 = true := by decide +kernel

def env42167 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,2097152,4194304,8388608,2114882,8328,65,14797998,115150,10507600,8423916,10600786,4268162,256,8487406,8478794,10544773]

theorem envBound42167 : H12AffineFastState.Bounded env42167 := by
  intro p hp
  have h : env42167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42034_42167 : H12AffineEnvironment.transform 17 149997 env42034 = env42167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149997 env42034 == env42167) = true)

def env42168 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4160,4194304,8388608,21762,8328,65,12705006,115150,8406288,8423916,8507666,4268162,256,8487406,8478794,8451781]

theorem envBound42168 : H12AffineFastState.Bounded env42168 := by
  intro p hp
  have h : env42168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42167_42168 : H12AffineEnvironment.transform 20 4160 env42167 = env42168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env42167 == env42168) = true)

def env42169 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4160,4194304,16,21762,8328,65,4316414,115150,17664,35324,119042,4268162,256,98814,90202,63189]

theorem envBound42169 : H12AffineFastState.Bounded env42169 := by
  intro p hp
  have h : env42169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42168_42169 : H12AffineEnvironment.transform 22 16 env42168 = env42169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env42168 == env42169) = true)

def env42170 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,4194304,16,21762,8192,65,4316278,115014,17664,35188,119042,4268042,256,98678,90202,63069]

theorem envBound42170 : H12AffineFastState.Bounded env42170 := by
  intro p hp
  have h : env42170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42169_42170 : H12AffineEnvironment.transform 6 8 env42169 = env42170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42169 == env42170) = true)

theorem identity42170 : scanCanonicalize (H12AffineFastState.compose env42170 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound42170 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42171 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35188,1024,32769,4160,4194304,16,21762,8192,65,4316278,115014,17664,35188,119042,4268042,256,98678,90202,63069]

theorem envBound42171 : H12AffineFastState.Bounded env42171 := by
  intro p hp
  have h : env42171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42170_42171 : H12AffineEnvironment.transform 16 49169 env42170 = env42171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env42170 == env42171) = true)

theorem identity42171 : scanCanonicalize (H12AffineFastState.compose env42171 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound42171 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env42172 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21591,49169,35188,1024,32769,4160,4194304,16,21762,8192,65,4229153,38161,17664,35188,34133,4224093,256,54561,13325,63069]

theorem envBound42172 : H12AffineFastState.Bounded env42172 := by
  intro p hp
  have h : env42172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42171_42172 : H12AffineEnvironment.transform 15 21591 env42171 = env42172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env42171 == env42172) = true)

theorem identity42172 : scanCanonicalize (H12AffineFastState.compose env42172 (packedSelected [0,1,3,5,7,9,10,11,12,14,18,19,20,22,23,28,31,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 29993) := by decide +kernel

theorem selectedBound42172 : packedSelected [0,1,3,5,7,9,10,11,12,14,18,19,20,22,23,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env42173 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29993,21591,13624,31837,1024,29992,4160,4194304,16,21762,8192,65,4226312,24632,17664,31837,28796,4224093,256,8200,13325,884]

theorem envBound42173 : H12AffineFastState.Bounded env42173 := by
  intro p hp
  have h : env42173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42172_42173 : H12AffineEnvironment.transform 14 29993 env42172 = env42173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29993 env42172 == env42173) = true)

theorem identity42173 : scanCanonicalize (H12AffineFastState.compose env42173 (packedSelected [0,2,3,6,7,10,18,19,20,24,32] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound42173 : packedSelected [0,2,3,6,7,10,18,19,20,24,32] rootPS < 2^1333 := by decide +kernel

def env42174 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,21841,21591,5440,23589,1024,21840,4160,4194304,16,21762,120,65,4218224,16448,17664,23589,20484,4215845,256,112,5237,884]

theorem envBound42174 : H12AffineFastState.Bounded env42174 := by
  intro p hp
  have h : env42174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42173_42174 : H12AffineEnvironment.transform 12 120 env42173 = env42174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env42173 == env42174) = true)

theorem identity42174 : scanCanonicalize (H12AffineFastState.compose env42174 (packedSelected [0,1,2,6,7,8,11,12,15,18,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound42174 : packedSelected [0,1,2,6,7,8,11,12,15,18,19,20] rootPS < 2^1333 := by decide +kernel

def env42175 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,120,16384,21621,21591,5220,23589,1024,21620,4160,4194304,16,21542,120,65,4217940,16448,17444,23589,20484,4215845,36,112,5237,592]

theorem envBound42175 : H12AffineFastState.Bounded env42175 := by
  intro p hp
  have h : env42175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42174_42175 : H12AffineEnvironment.transform 7 36 env42174 = env42175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env42174 == env42175) = true)

theorem identity42175 : scanCanonicalize (H12AffineFastState.compose env42175 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42175 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42176 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,16384,21540,21510,5173,23589,1024,21541,4113,4194304,16,21542,41,16,4217861,16401,17444,23589,20484,4215845,36,33,5156,513]

theorem envBound42176 : H12AffineFastState.Bounded env42176 := by
  intro p hp
  have h : env42176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42175_42176 : H12AffineEnvironment.transform 5 17 env42175 = env42176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42175 == env42176) = true)

theorem identity42176 : scanCanonicalize (H12AffineFastState.compose env42176 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound42176 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env42177 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,4113,1077,1047,5173,3124,1024,1076,4113,4194304,16,1079,41,16,4197396,4096,5173,3124,21,4195380,36,33,5156,513]

theorem envBound42177 : H12AffineFastState.Bounded env42177 := by
  intro p hp
  have h : env42177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42176_42177 : H12AffineEnvironment.transform 13 4113 env42176 = env42177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env42176 == env42177) = true)

theorem identity42177 : scanCanonicalize (H12AffineFastState.compose env42177 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound42177 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42178 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,4096,41,4113,0,34,4096,2049,53,1,4113,4194304,16,2,41,16,4196385,4096,4096,2049,21,4194305,36,33,4113,513]

theorem envBound42178 : H12AffineFastState.Bounded env42178 := by
  intro p hp
  have h : env42178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42177_42178 : H12AffineEnvironment.transform 9 53 env42177 = env42178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env42177 == env42178) = true)

theorem identity42178 : scanCanonicalize (H12AffineFastState.compose env42178 (packedSelected [1] rootPS)) = affineNative (2^(21+1) ^^^ 561) := by decide +kernel

theorem selectedBound42178 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42179 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,4096,41,4113,0,34,4096,2049,53,1,4113,561,16,2,41,16,2576,4096,4096,2049,21,560,36,33,4113,513]

theorem envBound42179 : H12AffineFastState.Bounded env42179 := by
  intro p hp
  have h : env42179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42178_42179 : H12AffineEnvironment.transform 21 561 env42178 = env42179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 561 env42178 == env42179) = true)

theorem identity42179 : scanCanonicalize (H12AffineFastState.compose env42179 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound42179 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env42180 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,32,41,49,0,34,32,2049,53,1,49,561,16,2,41,16,2576,32,32,2049,21,560,36,33,49,513]

theorem envBound42180 : H12AffineFastState.Bounded env42180 := by
  intro p hp
  have h : env42180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42179_42180 : H12AffineEnvironment.transform 11 32 env42179 = env42180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env42179 == env42180) = true)

theorem identity42180 : scanCanonicalize (H12AffineFastState.compose env42180 (packedSelected [0,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound42180 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env42181 : List Nat := [2,4,8,16,32,17,8,36,33,53,2048,32,41,49,0,34,32,2049,53,1,49,16,16,2,41,16,2097,32,32,2049,21,17,36,33,49,32]

theorem envBound42181 : H12AffineFastState.Bounded env42181 := by
  intro p hp
  have h : env42181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42180_42181 : H12AffineEnvironment.transform 8 33 env42180 = env42181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env42180 == env42181) = true)

theorem identity42181 : scanCanonicalize (H12AffineFastState.compose env42181 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound42181 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env42182 : List Nat := [2,4,8,16,16,17,8,20,17,5,2048,16,25,1,0,18,16,2049,5,1,1,16,16,2,25,16,2049,16,16,2049,21,17,20,17,1,16]

theorem envBound42182 : H12AffineFastState.Bounded env42182 := by
  intro p hp
  have h : env42182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42181_42182 : H12AffineEnvironment.transform 4 16 env42181 = env42182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env42181 == env42182) = true)

theorem identity42182 : scanCanonicalize (H12AffineFastState.compose env42182 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound42182 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42183 : List Nat := [2,4,8,0,0,1,8,4,1,5,2048,0,9,1,0,2,0,2049,5,1,1,0,0,2,9,0,2049,0,0,2049,5,1,4,1,1,0]

theorem envBound42183 : H12AffineFastState.Bounded env42183 := by
  intro p hp
  have h : env42183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42182_42183 : H12AffineEnvironment.transform 3 0 env42182 = env42183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42182 == env42183) = true)

theorem identity42183 : scanCanonicalize (H12AffineFastState.compose env42183 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound42183 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env42184 : List Nat := [2,4,8,0,0,1,8,4,1,5,1,0,9,1,0,2,0,0,5,1,1,0,0,2,9,0,0,0,0,0,5,1,4,1,1,0]

theorem envBound42184 : H12AffineFastState.Bounded env42184 := by
  intro p hp
  have h : env42184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42183_42184 : H12AffineEnvironment.transform 10 1 env42183 = env42184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env42183 == env42184) = true)

def env42185 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,4194304,16,21762,8193,65,4316279,115015,17664,35189,119042,4268043,256,98679,90202,63068]

theorem envBound42185 : H12AffineFastState.Bounded env42185 := by
  intro p hp
  have h : env42185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42169_42185 : H12AffineEnvironment.transform 6 9 env42169 = env42185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42169 == env42185) = true)

theorem identity42185 : scanCanonicalize (H12AffineFastState.compose env42185 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound42185 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42186 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,10280,1024,32769,4160,4194304,16,21762,8193,65,4316279,115015,17664,35189,119042,4268043,256,98679,90202,63068]

theorem envBound42186 : H12AffineFastState.Bounded env42186 := by
  intro p hp
  have h : env42186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42185_42186 : H12AffineEnvironment.transform 16 24908 env42185 = env42186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env42185 == env42186) = true)

theorem identity42186 : scanCanonicalize (H12AffineFastState.compose env42186 (packedSelected [0,1,3,7,8,9,11,12,14,15,16,18,22,23,24,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound42186 : packedSelected [0,1,3,7,8,9,11,12,14,15,16,18,22,23,24,31,32] rootPS < 2^1333 := by decide +kernel

def env42187 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,24908,10280,1024,8540,4160,4194304,16,21762,8193,65,4291882,90138,17664,10280,94303,4268043,256,73770,90202,22273]

theorem envBound42187 : H12AffineFastState.Bounded env42187 := by
  intro p hp
  have h : env42187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42186_42187 : H12AffineEnvironment.transform 14 8541 env42186 = env42187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env42186 == env42187) = true)

theorem identity42187 : scanCanonicalize (H12AffineFastState.compose env42187 (packedSelected [1,8,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound42187 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env42188 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,24908,10280,1024,8540,4160,4194304,16,21762,8193,65,4218144,16400,17664,10280,20565,4194305,256,32,16464,22273]

theorem envBound42188 : H12AffineFastState.Bounded env42188 := by
  intro p hp
  have h : env42188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42187_42188 : H12AffineEnvironment.transform 15 8202 env42187 = env42188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env42187 == env42188) = true)

theorem identity42188 : scanCanonicalize (H12AffineFastState.compose env42188 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound42188 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env42189 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,24908,10280,1024,8540,4160,113,16,21762,8193,65,23889,16400,17664,10280,20565,112,256,32,16464,22273]

theorem envBound42189 : H12AffineFastState.Bounded env42189 := by
  intro p hp
  have h : env42189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42188_42189 : H12AffineEnvironment.transform 21 113 env42188 = env42189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env42188 == env42189) = true)

theorem identity42189 : scanCanonicalize (H12AffineFastState.compose env42189 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound42189 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env42190 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1,342,16400,2420,1024,0,4160,113,16,21762,349,65,23889,16400,17664,2420,20565,112,256,32,16464,22273]

theorem envBound42190 : H12AffineFastState.Bounded env42190 := by
  intro p hp
  have h : env42190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42189_42190 : H12AffineEnvironment.transform 12 348 env42189 = env42190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env42189 == env42190) = true)

theorem identity42190 : scanCanonicalize (H12AffineFastState.compose env42190 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound42190 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env42191 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,342,5392,2420,1024,0,4160,113,16,2,349,65,2129,5392,4096,2420,1365,112,256,32,5456,513]

theorem envBound42191 : H12AffineFastState.Bounded env42191 := by
  intro p hp
  have h : env42191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42190_42191 : H12AffineEnvironment.transform 13 5376 env42190 = env42191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env42190 == env42191) = true)

def env42192 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4160,4194304,17,21762,8328,65,4316415,115150,17665,35325,119043,4268162,256,98815,90203,63188]

theorem envBound42192 : H12AffineFastState.Bounded env42192 := by
  intro p hp
  have h : env42192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42168_42192 : H12AffineEnvironment.transform 22 17 env42168 = env42192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env42168 == env42192) = true)

theorem identity42192 : scanCanonicalize (H12AffineFastState.compose env42192 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169400) := by decide +kernel

theorem selectedBound42192 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42193 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4160,169400,17,21762,8328,65,215367,115150,17665,35325,119043,243002,256,98815,90203,63188]

theorem envBound42193 : H12AffineFastState.Bounded env42193 := by
  intro p hp
  have h : env42193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42192_42193 : H12AffineEnvironment.transform 21 169400 env42192 = env42193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169400 env42192 == env42193) = true)

def env42194 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,169264,17,21762,8192,65,215367,115014,17665,35189,119043,243002,256,98679,90203,63068]

theorem envBound42194 : H12AffineFastState.Bounded env42194 := by
  intro p hp
  have h : env42194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42193_42194 : H12AffineEnvironment.transform 6 8 env42193 = env42194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42193 == env42194) = true)

theorem identity42194 : scanCanonicalize (H12AffineFastState.compose env42194 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound42194 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42195 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,149861,1024,8540,4160,144493,17,21762,8192,65,215367,90139,17665,10280,94302,201831,256,73770,90203,22273]

theorem envBound42195 : H12AffineFastState.Bounded env42195 := by
  intro p hp
  have h : env42195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42194_42195 : H12AffineEnvironment.transform 14 8541 env42194 = env42195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env42194 == env42195) = true)

theorem identity42195 : scanCanonicalize (H12AffineFastState.compose env42195 (packedSelected [0,7,8,9,12,14,15,18,19,20,22,23,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 78958) := by decide +kernel

theorem selectedBound42195 : packedSelected [0,7,8,9,12,14,15,18,19,20,22,23,26,28,31] rootPS < 2^1333 := by decide +kernel

def env42196 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,78958,97547,1024,8540,4160,65539,17,21762,8192,65,32041,90139,17665,10280,94302,8201,256,73770,90203,22273]

theorem envBound42196 : H12AffineFastState.Bounded env42196 := by
  intro p hp
  have h : env42196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42195_42196 : H12AffineEnvironment.transform 16 78958 env42195 = env42196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78958 env42195 == env42196) = true)

theorem identity42196 : scanCanonicalize (H12AffineFastState.compose env42196 (packedSelected [0,1,2,3,4,6,8,9,10,11,12,15,20,23,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound42196 : packedSelected [0,1,2,3,4,6,8,9,10,11,12,15,20,23,24,27] rootPS < 2^1333 := by decide +kernel

def env42197 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,8541,65536,78958,67619,1024,8540,4160,65539,17,8234,8192,65,2049,70963,12329,10280,66934,8201,256,73770,71027,8745]

theorem envBound42197 : H12AffineFastState.Bounded env42197 := by
  intro p hp
  have h : env42197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42196_42197 : H12AffineEnvironment.transform 13 13608 env42196 = env42197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env42196 == env42197) = true)

theorem identity42197 : scanCanonicalize (H12AffineFastState.compose env42197 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound42197 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env42198 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,8541,8202,5220,10281,1024,8540,4160,8201,17,8234,8192,65,2049,13625,12329,10280,9596,8201,256,32,13689,8745]

theorem envBound42198 : H12AffineFastState.Bounded env42198 := by
  intro p hp
  have h : env42198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42197_42198 : H12AffineEnvironment.transform 15 8202 env42197 = env42198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env42197 == env42198) = true)

theorem identity42198 : scanCanonicalize (H12AffineFastState.compose env42198 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound42198 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env42199 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,4096,8192,12572,8541,8202,4176,10281,52,8540,4160,8201,17,8234,8192,65,2049,12557,12329,10280,8520,8201,256,32,12621,8745]

theorem envBound42199 : H12AffineFastState.Bounded env42199 := by
  intro p hp
  have h : env42199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42198_42199 : H12AffineEnvironment.transform 9 52 env42198 = env42199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env42198 == env42199) = true)

theorem identity42199 : scanCanonicalize (H12AffineFastState.compose env42199 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound42199 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env42200 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,4096,40,4404,373,34,4176,2049,52,372,4160,33,17,2,40,65,2049,4389,4097,2048,352,33,256,32,4453,513]

theorem envBound42200 : H12AffineFastState.Bounded env42200 := by
  intro p hp
  have h : env42200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42199_42200 : H12AffineEnvironment.transform 12 40 env42199 = env42200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env42199 == env42200) = true)

theorem identity42200 : scanCanonicalize (H12AffineFastState.compose env42200 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound42200 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42201 : List Nat := [2,4,8,16,32,64,8,117,512,52,2048,4096,40,4161,0,34,4176,2049,52,1,4160,33,17,2,40,65,2049,4176,4097,2048,21,33,117,32,4112,513]

theorem envBound42201 : H12AffineFastState.Bounded env42201 := by
  intro p hp
  have h : env42201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42200_42201 : H12AffineEnvironment.transform 7 117 env42200 = env42201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env42200 == env42201) = true)

theorem identity42201 : scanCanonicalize (H12AffineFastState.compose env42201 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound42201 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42202 : List Nat := [2,4,8,16,32,64,8,117,512,52,2048,80,40,17,0,34,0,2049,52,1,16,33,17,2,40,65,2049,0,81,2048,21,33,117,32,64,513]

theorem envBound42202 : H12AffineFastState.Bounded env42202 := by
  intro p hp
  have h : env42202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42201_42202 : H12AffineEnvironment.transform 11 80 env42201 = env42202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env42201 == env42202) = true)

theorem identity42202 : scanCanonicalize (H12AffineFastState.compose env42202 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 90) := by decide +kernel

theorem selectedBound42202 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42203 : List Nat := [2,4,8,16,32,64,8,117,512,52,90,80,40,17,0,34,0,91,52,1,16,33,17,2,40,65,91,0,81,90,21,33,117,32,64,513]

theorem envBound42203 : H12AffineFastState.Bounded env42203 := by
  intro p hp
  have h : env42203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42202_42203 : H12AffineEnvironment.transform 10 90 env42202 = env42203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 90 env42202 == env42203) = true)

def env42204 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,169265,17,21762,8193,65,215367,115015,17665,35188,119043,243002,256,98678,90203,63069]

theorem envBound42204 : H12AffineFastState.Bounded env42204 := by
  intro p hp
  have h : env42204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42193_42204 : H12AffineEnvironment.transform 6 9 env42193 = env42204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42193 == env42204) = true)

theorem identity42204 : scanCanonicalize (H12AffineFastState.compose env42204 (packedSelected [0,7,8,9,14,15,20,22,28,31,41] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound42204 : packedSelected [0,7,8,9,14,15,20,22,28,31,41] rootPS < 2^1333 := by decide +kernel

def env42205 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,65536,131072,149860,1024,0,4160,136496,17,21762,8193,65,215367,82246,17665,2421,86274,210235,256,65911,90203,30300]

theorem envBound42205 : H12AffineFastState.Bounded env42205 := by
  intro p hp
  have h : env42205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42204_42205 : H12AffineEnvironment.transform 14 1 env42204 = env42205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env42204 == env42205) = true)

theorem identity42205 : scanCanonicalize (H12AffineFastState.compose env42205 (packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound42205 : packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env42206 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,65536,24908,10280,1024,0,4160,29820,17,21762,8193,65,75787,82246,17665,2421,86274,87159,256,65911,90203,30300]

theorem envBound42206 : H12AffineFastState.Bounded env42206 := by
  intro p hp
  have h : env42206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42205_42206 : H12AffineEnvironment.transform 16 24908 env42205 = env42206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env42205 == env42206) = true)

theorem identity42206 : scanCanonicalize (H12AffineFastState.compose env42206 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound42206 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env42207 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,1,65536,5393,10280,1024,0,4160,33,17,8543,8193,65,75787,79131,12636,2421,75103,73770,256,65911,70662,513]

theorem envBound42207 : H12AffineFastState.Bounded env42207 := by
  intro p hp
  have h : env42207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42206_42207 : H12AffineEnvironment.transform 13 13405 env42206 = env42207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env42206 == env42207) = true)

theorem identity42207 : scanCanonicalize (H12AffineFastState.compose env42207 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound42207 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42208 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,1,8203,5393,10280,1024,0,4160,33,17,8543,8193,65,2048,5392,12636,2421,1364,33,256,8572,13325,513]

theorem envBound42208 : H12AffineFastState.Bounded env42208 := by
  intro p hp
  have h : env42208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42207_42208 : H12AffineEnvironment.transform 15 8203 env42207 = env42208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env42207 == env42208) = true)

theorem identity42208 : scanCanonicalize (H12AffineFastState.compose env42208 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound42208 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42209 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,1,262,5393,2341,1024,0,4160,33,17,82,268,65,2048,5392,4177,2421,1364,33,256,113,5376,513]

theorem envBound42209 : H12AffineFastState.Bounded env42209 := by
  intro p hp
  have h : env42209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42208_42209 : H12AffineEnvironment.transform 12 269 env42208 = env42209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env42208 == env42209) = true)

theorem identity42209 : scanCanonicalize (H12AffineFastState.compose env42209 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 1573) := by decide +kernel

theorem selectedBound42209 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env42210 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1573,4096,269,5456,1,262,5393,1792,1024,0,4160,33,17,82,268,65,1573,5392,4177,1872,1364,33,256,113,5376,513]

theorem envBound42210 : H12AffineFastState.Bounded env42210 := by
  intro p hp
  have h : env42210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42209_42210 : H12AffineEnvironment.transform 10 1573 env42209 = env42210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1573 env42209 == env42210) = true)

theorem identity42210 : scanCanonicalize (H12AffineFastState.compose env42210 (packedSelected [0,3,4,5,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42210 : packedSelected [0,3,4,5,11] rootPS < 2^1333 := by decide +kernel

def env42211 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1573,4096,269,5376,1,262,5393,1792,1024,0,4112,33,17,2,268,17,1573,5392,4097,1792,1284,33,256,33,5376,513]

theorem envBound42211 : H12AffineFastState.Bounded env42211 := by
  intro p hp
  have h : env42211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42210_42211 : H12AffineEnvironment.transform 5 16 env42210 = env42211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42210 == env42211) = true)

theorem identity42211 : scanCanonicalize (H12AffineFastState.compose env42211 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound42211 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42212 : List Nat := [2,4,8,16,17,16,9,256,512,1024,1556,4096,269,5376,1,262,5393,1792,1024,0,4112,16,17,2,268,17,1556,5392,4097,1792,1284,16,256,16,5376,513]

theorem envBound42212 : H12AffineFastState.Bounded env42212 := by
  intro p hp
  have h : env42212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42211_42212 : H12AffineEnvironment.transform 4 17 env42211 = env42212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env42211 == env42212) = true)

theorem identity42212 : scanCanonicalize (H12AffineFastState.compose env42212 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound42212 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42213 : List Nat := [2,4,8,16,17,16,9,256,512,517,17,4096,269,4869,1,262,4884,261,517,0,4112,16,17,2,268,17,17,4885,4097,261,769,16,256,16,4869,513]

theorem envBound42213 : H12AffineFastState.Bounded env42213 := by
  intro p hp
  have h : env42213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42212_42213 : H12AffineEnvironment.transform 9 517 env42212 = env42213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env42212 == env42213) = true)

theorem identity42213 : scanCanonicalize (H12AffineFastState.compose env42213 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound42213 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42214 : List Nat := [2,4,8,16,17,16,9,256,277,272,17,4096,269,4112,1,262,4097,261,272,0,4112,16,17,2,268,17,17,4096,4097,261,20,16,256,16,4112,276]

theorem envBound42214 : H12AffineFastState.Bounded env42214 := by
  intro p hp
  have h : env42214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42213_42214 : H12AffineEnvironment.transform 8 277 env42213 = env42214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env42213 == env42214) = true)

theorem identity42214 : scanCanonicalize (H12AffineFastState.compose env42214 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound42214 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env42215 : List Nat := [2,4,8,16,17,16,9,256,277,272,17,277,269,261,1,262,276,261,272,0,261,16,17,2,268,17,17,277,276,261,20,16,256,16,261,276]

theorem envBound42215 : H12AffineFastState.Bounded env42215 := by
  intro p hp
  have h : env42215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42214_42215 : H12AffineEnvironment.transform 11 277 env42214 = env42215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env42214 == env42215) = true)

theorem identity42215 : scanCanonicalize (H12AffineFastState.compose env42215 (packedSelected [0,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound42215 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env42216 : List Nat := [2,4,8,16,17,16,9,5,16,21,17,16,8,0,1,3,17,0,21,0,0,16,17,2,9,17,17,16,17,0,20,16,5,16,0,17]

theorem envBound42216 : H12AffineFastState.Bounded env42216 := by
  intro p hp
  have h : env42216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42215_42216 : H12AffineEnvironment.transform 7 5 env42215 = env42216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env42215 == env42216) = true)

theorem identity42216 : scanCanonicalize (H12AffineFastState.compose env42216 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound42216 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env42217 : List Nat := [2,4,8,1,0,1,9,5,1,4,0,1,8,0,1,3,0,0,4,0,0,1,0,2,9,0,0,1,0,0,5,1,5,1,0,0]

theorem envBound42217 : H12AffineFastState.Bounded env42217 := by
  intro p hp
  have h : env42217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42216_42217 : H12AffineEnvironment.transform 3 1 env42216 = env42217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42216 == env42217) = true)

def env42218 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4161,4194304,8388608,21763,8328,65,12705007,115150,8406289,8423916,8507667,4268162,256,8487406,8478794,8451780]

theorem envBound42218 : H12AffineFastState.Bounded env42218 := by
  intro p hp
  have h : env42218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42167_42218 : H12AffineEnvironment.transform 20 4161 env42167 = env42218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env42167 == env42218) = true)

def env42219 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4161,4194304,16,21763,8328,65,4316415,115150,17665,35324,119043,4268162,256,98814,90202,63188]

theorem envBound42219 : H12AffineFastState.Bounded env42219 := by
  intro p hp
  have h : env42219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42218_42219 : H12AffineEnvironment.transform 22 16 env42218 = env42219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env42218 == env42219) = true)

theorem identity42219 : scanCanonicalize (H12AffineFastState.compose env42219 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound42219 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42220 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,149997,1024,29908,4161,4194304,16,21763,8328,65,4270122,79131,17665,32041,75222,4268162,256,95531,90202,513]

theorem envBound42220 : H12AffineFastState.Bounded env42220 := by
  intro p hp
  have h : env42220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42219_42220 : H12AffineEnvironment.transform 14 29909 env42219 = env42220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env42219 == env42220) = true)

def env42221 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,138477,1024,8660,4161,4194304,16,3,8328,65,4270122,79131,4097,10281,75222,4268162,256,73771,79194,513]

theorem envBound42221 : H12AffineFastState.Bounded env42221 := by
  intro p hp
  have h : env42221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42220_42221 : H12AffineEnvironment.transform 13 5376 env42220 = env42221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env42220 == env42221) = true)

theorem identity42221 : scanCanonicalize (H12AffineFastState.compose env42221 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound42221 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42222 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,13388,10401,1024,8660,4161,4194304,16,3,8328,65,4270122,79131,4097,10281,75222,4268162,256,73771,79194,513]

theorem envBound42222 : H12AffineFastState.Bounded env42222 := by
  intro p hp
  have h : env42222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42221_42222 : H12AffineEnvironment.transform 16 13388 env42221 = env42222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env42221 == env42222) = true)

theorem identity42222 : scanCanonicalize (H12AffineFastState.compose env42222 (packedSelected [0,1,2,6,8,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 8693) := by decide +kernel

theorem selectedBound42222 : packedSelected [0,1,2,6,8,14,19,27] rootPS < 2^1333 := by decide +kernel

def env42223 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,13388,10401,1024,8660,4161,8693,16,3,8328,65,68063,79131,4097,10281,75222,65911,256,73771,79194,513]

theorem envBound42223 : H12AffineFastState.Bounded env42223 := by
  intro p hp
  have h : env42223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42222_42223 : H12AffineEnvironment.transform 21 8693 env42222 = env42223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8693 env42222 == env42223) = true)

theorem identity42223 : scanCanonicalize (H12AffineFastState.compose env42223 (packedSelected [0,2,3,4,5,6,7,9,11,15,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound42223 : packedSelected [0,2,3,4,5,6,7,9,11,15,19,20] rootPS < 2^1333 := by decide +kernel

def env42224 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8203,13388,10401,1024,8660,4161,8693,16,3,8328,65,10708,5392,4097,10281,1501,8572,256,32,5457,513]

theorem envBound42224 : H12AffineFastState.Bounded env42224 := by
  intro p hp
  have h : env42224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42223_42224 : H12AffineEnvironment.transform 15 8203 env42223 = env42224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env42223 == env42224) = true)

theorem identity42224 : scanCanonicalize (H12AffineFastState.compose env42224 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound42224 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42225 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5376,137,343,5392,2557,1024,136,4161,169,16,3,468,65,2184,5392,4097,2421,1501,32,256,32,5457,513]

theorem envBound42225 : H12AffineFastState.Bounded env42225 := by
  intro p hp
  have h : env42225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42224_42225 : H12AffineEnvironment.transform 12 348 env42224 = env42225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env42224 == env42225) = true)

theorem identity42225 : scanCanonicalize (H12AffineFastState.compose env42225 (packedSelected [0,4,5,7,8,9,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2138) := by decide +kernel

theorem selectedBound42225 : packedSelected [0,4,5,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env42226 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2138,348,3418,137,343,3402,2557,1024,136,2075,169,16,3,468,65,2184,3402,2139,2421,1501,32,256,32,3339,513]

theorem envBound42226 : H12AffineFastState.Bounded env42226 := by
  intro p hp
  have h : env42226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42225_42226 : H12AffineEnvironment.transform 11 2138 env42225 = env42226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2138 env42225 == env42226) = true)

theorem identity42226 : scanCanonicalize (H12AffineFastState.compose env42226 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound42226 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env42227 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2138,348,3418,0,343,3402,2420,1024,1,2075,32,16,3,349,65,2049,3402,2139,2421,1364,32,256,32,3339,513]

theorem envBound42227 : H12AffineFastState.Bounded env42227 := by
  intro p hp
  have h : env42227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42226_42227 : H12AffineEnvironment.transform 6 9 env42226 = env42227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42226 == env42227) = true)

theorem identity42227 : scanCanonicalize (H12AffineFastState.compose env42227 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 91) := by decide +kernel

theorem selectedBound42227 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42228 : List Nat := [2,4,8,16,32,64,9,256,512,1024,91,1,348,1281,0,343,1297,303,1024,1,64,32,16,3,349,65,90,1297,0,302,1364,32,256,32,1360,513]

theorem envBound42228 : H12AffineFastState.Bounded env42228 := by
  intro p hp
  have h : env42228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42227_42228 : H12AffineEnvironment.transform 10 91 env42227 = env42228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 91 env42227 == env42228) = true)

theorem identity42228 : scanCanonicalize (H12AffineFastState.compose env42228 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound42228 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env42229 : List Nat := [2,4,8,16,32,64,9,116,512,1024,91,1,40,1141,0,35,1125,91,1024,1,64,32,16,3,41,65,90,1125,0,90,1056,32,116,32,1060,513]

theorem envBound42229 : H12AffineFastState.Bounded env42229 := by
  intro p hp
  have h : env42229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42228_42229 : H12AffineEnvironment.transform 7 116 env42228 = env42229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env42228 == env42229) = true)

theorem identity42229 : scanCanonicalize (H12AffineFastState.compose env42229 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 63) := by decide +kernel

theorem selectedBound42229 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env42230 : List Nat := [2,4,8,16,32,64,9,116,512,63,91,1,40,74,0,35,90,91,63,1,64,32,16,3,41,65,90,90,0,90,31,32,116,32,27,513]

theorem envBound42230 : H12AffineFastState.Bounded env42230 := by
  intro p hp
  have h : env42230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42229_42230 : H12AffineEnvironment.transform 9 63 env42229 = env42230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 63 env42229 == env42230) = true)

theorem identity42230 : scanCanonicalize (H12AffineFastState.compose env42230 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound42230 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env42231 : List Nat := [2,4,8,16,0,64,9,84,512,31,91,1,8,74,0,3,90,91,31,1,64,0,16,3,9,65,90,90,0,90,31,0,84,0,27,513]

theorem envBound42231 : H12AffineFastState.Bounded env42231 := by
  intro p hp
  have h : env42231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42230_42231 : H12AffineEnvironment.transform 4 0 env42230 = env42231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42230 == env42231) = true)

def env42232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,138476,1024,8661,4161,4194304,16,2,8328,65,4270122,79131,4096,10280,75222,4268162,256,73770,79195,513]

theorem envBound42232 : H12AffineFastState.Bounded env42232 := by
  intro p hp
  have h : env42232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42220_42232 : H12AffineEnvironment.transform 13 5377 env42220 = env42232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env42220 == env42232) = true)

theorem identity42232 : scanCanonicalize (H12AffineFastState.compose env42232 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound42232 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,13508,10280,1024,8661,4161,4194304,16,2,8328,65,4270122,79131,4096,10280,75222,4268162,256,73770,79195,513]

theorem envBound42233 : H12AffineFastState.Bounded env42233 := by
  intro p hp
  have h : env42233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42232_42233 : H12AffineEnvironment.transform 16 13508 env42232 = env42233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env42232 == env42233) = true)

theorem identity42233 : scanCanonicalize (H12AffineFastState.compose env42233 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound42233 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env42234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8202,13508,10280,1024,8661,4161,4194304,16,2,8328,65,4196384,5393,4096,10280,1500,4194440,256,32,5457,513]

theorem envBound42234 : H12AffineFastState.Bounded env42234 := by
  intro p hp
  have h : env42234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42233_42234 : H12AffineEnvironment.transform 15 8202 env42233 = env42234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env42233 == env42234) = true)

theorem identity42234 : scanCanonicalize (H12AffineFastState.compose env42234 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound42234 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42235 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8202,13508,10280,1024,8661,4161,113,16,2,8328,65,2129,5393,4096,10280,1500,249,256,32,5457,513]

theorem envBound42235 : H12AffineFastState.Bounded env42235 := by
  intro p hp
  have h : env42235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42234_42235 : H12AffineEnvironment.transform 21 113 env42234 = env42235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env42234 == env42235) = true)

theorem identity42235 : scanCanonicalize (H12AffineFastState.compose env42235 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound42235 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env42236 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,13389,10280,1024,8540,4161,113,16,2,8193,65,2129,5393,4096,10280,1365,112,256,32,5457,513]

theorem envBound42236 : H12AffineFastState.Bounded env42236 := by
  intro p hp
  have h : env42236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42235_42236 : H12AffineEnvironment.transform 6 9 env42235 = env42236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42235 == env42236) = true)

theorem identity42236 : scanCanonicalize (H12AffineFastState.compose env42236 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound42236 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env42237 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,343,5392,2421,1024,1,4161,113,16,2,348,65,2129,5393,4096,2421,1365,112,256,32,5457,513]

theorem envBound42237 : H12AffineFastState.Bounded env42237 := by
  intro p hp
  have h : env42237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42236_42237 : H12AffineEnvironment.transform 12 349 env42236 = env42237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env42236 == env42237) = true)

def env42238 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4161,4194304,17,21763,8328,65,4316414,115150,17664,35325,119042,4268162,256,98815,90203,63189]

theorem envBound42238 : H12AffineFastState.Bounded env42238 := by
  intro p hp
  have h : env42238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42218_42238 : H12AffineEnvironment.transform 22 17 env42218 = env42238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env42218 == env42238) = true)

theorem identity42238 : scanCanonicalize (H12AffineFastState.compose env42238 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 156013) := by decide +kernel

theorem selectedBound42238 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42239 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4161,156013,17,21763,8328,65,245139,115150,17664,35325,119042,213487,256,98815,90203,63189]

theorem envBound42239 : H12AffineFastState.Bounded env42239 := by
  intro p hp
  have h : env42239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42238_42239 : H12AffineEnvironment.transform 21 156013 env42238 = env42239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156013 env42238 == env42239) = true)

def env42240 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,156013,17,21763,8192,65,245019,115014,17664,35189,119042,213351,256,98679,90203,63069]

theorem envBound42240 : H12AffineFastState.Bounded env42240 := by
  intro p hp
  have h : env42240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42239_42240 : H12AffineEnvironment.transform 6 8 env42239 = env42240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42239 == env42240) = true)

theorem identity42240 : scanCanonicalize (H12AffineFastState.compose env42240 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound42240 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42241 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,149861,1024,8540,4161,156013,17,21763,8192,65,203846,90139,17664,10280,94303,213351,256,73770,90203,22272]

theorem envBound42241 : H12AffineFastState.Bounded env42241 := by
  intro p hp
  have h : env42241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42240_42241 : H12AffineEnvironment.transform 14 8541 env42240 = env42241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env42240 == env42241) = true)

theorem identity42241 : scanCanonicalize (H12AffineFastState.compose env42241 (packedSelected [0,1,3,4,7,16,18,20,22,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound42241 : packedSelected [0,1,3,4,7,16,18,20,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env42242 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90138,76159,1024,8540,4161,65911,17,21763,8192,65,31836,90139,17664,10280,94303,8573,256,73770,90203,22272]

theorem envBound42242 : H12AffineFastState.Bounded env42242 := by
  intro p hp
  have h : env42242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42241_42242 : H12AffineEnvironment.transform 16 90138 env42241 = env42242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env42241 == env42242) = true)

theorem identity42242 : scanCanonicalize (H12AffineFastState.compose env42242 (packedSelected [1,3,7,8,10,12,14,15,16,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound42242 : packedSelected [1,3,7,8,10,12,14,15,16,24,27] rootPS < 2^1333 := by decide +kernel

def env42243 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,115,24681,10508,1024,8540,4161,260,17,21763,8192,65,31836,24680,17664,10280,28716,8573,256,8281,24616,22272]

theorem envBound42243 : H12AffineFastState.Bounded env42243 := by
  intro p hp
  have h : env42243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42242_42243 : H12AffineEnvironment.transform 15 115 env42242 = env42243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env42242 == env42243) = true)

theorem identity42243 : scanCanonicalize (H12AffineFastState.compose env42243 (packedSelected [0,1,2,6,7,8,11,12,15,18,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound42243 : packedSelected [0,1,2,6,7,8,11,12,15,18,19,20] rootPS < 2^1333 := by decide +kernel

def env42244 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,8541,115,5393,10508,1024,8540,4161,260,17,8315,8192,65,2340,5392,12408,10280,1364,8573,256,8281,5456,8824]

theorem envBound42244 : H12AffineFastState.Bounded env42244 := by
  intro p hp
  have h : env42244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42243_42244 : H12AffineEnvironment.transform 13 13688 env42243 = env42244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env42243 == env42244) = true)

theorem identity42244 : scanCanonicalize (H12AffineFastState.compose env42244 (packedSelected [2,3,5,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound42244 : packedSelected [2,3,5,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env42245 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5237,80,115,5393,2049,1024,81,4161,260,17,374,269,65,2340,5392,4469,2341,1364,112,256,340,5456,885]

theorem envBound42245 : H12AffineFastState.Bounded env42245 := by
  intro p hp
  have h : env42245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42244_42245 : H12AffineEnvironment.transform 12 269 env42244 = env42245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env42244 == env42245) = true)

def env42246 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,156013,17,21763,8193,65,245018,115015,17664,35188,119042,213350,256,98678,90203,63068]

theorem envBound42246 : H12AffineFastState.Bounded env42246 := by
  intro p hp
  have h : env42246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42239_42246 : H12AffineEnvironment.transform 6 9 env42239 = env42246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42239 == env42246) = true)

theorem identity42246 : scanCanonicalize (H12AffineFastState.compose env42246 (packedSelected [0,1,3,9,10,11,14,16,18,19,20,22,23,24,26,27,28,31,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound42246 : packedSelected [0,1,3,9,10,11,14,16,18,19,20,22,23,24,26,27,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env42247 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149860,1024,32769,4161,156013,17,21763,8193,65,171281,57676,17664,35188,61705,156013,256,41341,16464,63068]

theorem envBound42247 : H12AffineFastState.Bounded env42247 := by
  intro p hp
  have h : env42247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42246_42247 : H12AffineEnvironment.transform 15 8203 env42246 = env42247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env42246 == env42247) = true)

theorem identity42247 : scanCanonicalize (H12AffineFastState.compose env42247 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound42247 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env42248 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,46156,64808,1024,32769,4161,54561,17,21763,8193,65,10589,57676,17664,35188,61705,54561,256,41341,16464,63068]

theorem envBound42248 : H12AffineFastState.Bounded env42248 := by
  intro p hp
  have h : env42248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42247_42248 : H12AffineEnvironment.transform 16 46156 env42247 = env42248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env42247 == env42248) = true)

theorem identity42248 : scanCanonicalize (H12AffineFastState.compose env42248 (packedSelected [0,5,7,9,12,14,15,19,20,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound42248 : packedSelected [0,5,7,9,12,14,15,19,20,22,24] rootPS < 2^1333 := by decide +kernel

def env42249 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,32768,8203,46156,35188,1024,32769,4161,41341,17,8543,8193,65,10589,38160,12636,35188,34133,41341,256,41341,13324,33280]

theorem envBound42249 : H12AffineFastState.Bounded env42249 := by
  intro p hp
  have h : env42249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42248_42249 : H12AffineEnvironment.transform 13 13404 env42248 = env42249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env42248 == env42249) = true)

theorem identity42249 : scanCanonicalize (H12AffineFastState.compose env42249 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound42249 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env42250 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,8192,13404,32768,8203,46156,34849,1024,32769,4161,41000,17,8202,8193,65,10248,37957,12297,34849,33792,41000,85,41000,13324,33280]

theorem envBound42250 : H12AffineFastState.Bounded env42250 := by
  intro p hp
  have h : env42250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42249_42250 : H12AffineEnvironment.transform 7 85 env42249 = env42250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env42249 == env42250) = true)

theorem identity42250 : scanCanonicalize (H12AffineFastState.compose env42250 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound42250 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env42251 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,8192,13404,81,8203,13341,2160,1024,80,4161,8313,17,8202,8193,65,10248,5140,12297,2160,1105,8313,85,8313,13324,593]

theorem envBound42251 : H12AffineFastState.Bounded env42251 := by
  intro p hp
  have h : env42251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42250_42251 : H12AffineEnvironment.transform 14 81 env42250 = env42251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env42250 == env42251) = true)

theorem identity42251 : scanCanonicalize (H12AffineFastState.compose env42251 (packedSelected [0,1,3,4,5,6,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 5725) := by decide +kernel

theorem selectedBound42251 : packedSelected [0,1,3,4,5,6,8,10] rootPS < 2^1333 := by decide +kernel

def env42252 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,5725,513,81,5718,576,2160,1024,80,4161,5668,17,5719,5724,65,7765,5140,1620,2160,1105,5668,85,5668,593,593]

theorem envBound42252 : H12AffineFastState.Bounded env42252 := by
  intro p hp
  have h : env42252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42251_42252 : H12AffineEnvironment.transform 12 5725 env42251 = env42252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5725 env42251 == env42252) = true)

theorem identity42252 : scanCanonicalize (H12AffineFastState.compose env42252 (packedSelected [0,2,4,5,6,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 592) := by decide +kernel

theorem selectedBound42252 : packedSelected [0,2,4,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env42253 : List Nat := [2,4,8,16,32,64,9,85,512,1024,592,4096,5725,513,81,5718,576,544,1024,80,4161,5668,17,5719,5724,65,5125,5140,1620,544,1105,5668,85,5668,593,593]

theorem envBound42253 : H12AffineFastState.Bounded env42253 := by
  intro p hp
  have h : env42253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42252_42253 : H12AffineEnvironment.transform 10 592 env42252 = env42253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 592 env42252 == env42253) = true)

theorem identity42253 : scanCanonicalize (H12AffineFastState.compose env42253 (packedSelected [0,3,6,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 113) := by decide +kernel

theorem selectedBound42253 : packedSelected [0,3,6,7,8] rootPS < 2^1333 := by decide +kernel

def env42254 : List Nat := [2,4,8,16,32,64,9,85,512,1024,592,113,1580,513,81,1575,576,544,1024,80,48,1621,17,1574,1581,65,1140,1125,1620,544,1105,1621,85,1621,593,593]

theorem envBound42254 : H12AffineFastState.Bounded env42254 := by
  intro p hp
  have h : env42254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42253_42254 : H12AffineEnvironment.transform 11 113 env42253 = env42254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 113 env42253 == env42254) = true)

theorem identity42254 : scanCanonicalize (H12AffineFastState.compose env42254 (packedSelected [2,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound42254 : packedSelected [2,6,7,9] rootPS < 2^1333 := by decide +kernel

def env42255 : List Nat := [2,4,8,16,32,64,9,85,512,53,592,113,537,513,81,530,576,544,53,80,48,608,17,531,536,65,65,80,609,544,100,608,85,608,593,593]

theorem envBound42255 : H12AffineFastState.Bounded env42255 := by
  intro p hp
  have h : env42255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42254_42255 : H12AffineEnvironment.transform 9 53 env42254 = env42255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env42254 == env42255) = true)

theorem identity42255 : scanCanonicalize (H12AffineFastState.compose env42255 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound42255 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env42256 : List Nat := [2,4,8,0,32,64,9,69,512,37,576,97,521,513,65,514,576,544,37,64,32,608,1,515,520,65,65,64,609,544,100,608,69,608,577,577]

theorem envBound42256 : H12AffineFastState.Bounded env42256 := by
  intro p hp
  have h : env42256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42255_42256 : H12AffineEnvironment.transform 3 0 env42255 = env42256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42255 == env42256) = true)

theorem identity42256 : scanCanonicalize (H12AffineFastState.compose env42256 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound42256 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42257 : List Nat := [2,4,8,0,32,64,9,69,65,37,1,97,72,64,65,67,1,97,37,64,32,33,1,66,73,65,65,64,32,97,100,33,69,33,0,0]

theorem envBound42257 : H12AffineFastState.Bounded env42257 := by
  intro p hp
  have h : env42257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42256_42257 : H12AffineEnvironment.transform 8 65 env42256 = env42257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env42256 == env42257) = true)

theorem identity42257 : scanCanonicalize (H12AffineFastState.compose env42257 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound42257 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env42258 : List Nat := [2,4,8,0,32,32,9,37,33,37,1,1,40,32,33,35,1,1,37,32,32,33,1,34,41,33,33,32,32,1,4,33,37,33,0,0]

theorem envBound42258 : H12AffineFastState.Bounded env42258 := by
  intro p hp
  have h : env42258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42257_42258 : H12AffineEnvironment.transform 5 32 env42257 = env42258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env42257 == env42258) = true)

theorem identity42258 : scanCanonicalize (H12AffineFastState.compose env42258 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound42258 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42259 : List Nat := [2,4,8,0,0,0,9,5,1,5,1,1,8,0,1,3,1,1,5,0,0,1,1,2,9,1,1,0,0,1,4,1,5,1,0,0]

theorem envBound42259 : H12AffineFastState.Bounded env42259 := by
  intro p hp
  have h : env42259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42258_42259 : H12AffineEnvironment.transform 4 0 env42258 = env42259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42258 == env42259) = true)

theorem identity42259 : scanCanonicalize (H12AffineFastState.compose env42259 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound42259 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42260 : List Nat := [2,4,3,0,0,0,2,5,1,5,1,1,3,0,1,3,1,1,5,0,0,1,1,2,2,1,1,0,0,1,4,1,5,1,0,0]

theorem envBound42260 : H12AffineFastState.Bounded env42260 := by
  intro p hp
  have h : env42260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42259_42260 : H12AffineEnvironment.transform 2 3 env42259 = env42260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env42259 == env42260) = true)

def env42261 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830976,25265168,23160256,257,27378861,27337992,25207750]

theorem envBound42261 : H12AffineFastState.Bounded env42261 := by
  intro p hp
  have h : env42261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42032_42261 : H12AffineEnvironment.transform 18 1025 env42032 = env42261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env42032 == env42261) = true)

theorem identity42261 : scanCanonicalize (H12AffineFastState.compose env42261 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2485295) := by decide +kernel

theorem selectedBound42261 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env42262 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2485295,16777216,8328,65,23211055,18973837,375167,2305071,19163199,23160256,257,17049730,17090855,19222505]

theorem envBound42262 : H12AffineFastState.Bounded env42262 := by
  intro p hp
  have h : env42262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42261_42262 : H12AffineEnvironment.transform 22 2485295 env42261 = env42262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2485295 env42261 == env42262) = true)

def env42263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155700,2485295,16777216,8328,65,16959643,18973837,375167,2305071,19163199,16875892,257,17049730,17090855,19222505]

theorem envBound42263 : H12AffineFastState.Bounded env42263 := by
  intro p hp
  have h : env42263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42262_42263 : H12AffineEnvironment.transform 21 2155700 env42262 = env42263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2155700 env42262 == env42263) = true)

def env42264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155700,2485295,2559344,8328,65,2475499,428541,375167,2305071,222543,2526212,257,2303474,2344023,148121]

theorem envBound42264 : H12AffineFastState.Bounded env42264 := by
  intro p hp
  have h : env42264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42263_42264 : H12AffineEnvironment.transform 23 2559344 env42263 = env42264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2559344 env42263 == env42264) = true)

theorem identity42264 : scanCanonicalize (H12AffineFastState.compose env42264 (packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 388158) := by decide +kernel

theorem selectedBound42264 : packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS < 2^1333 := by decide +kernel

def env42265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388158,329866,17,188750,8328,65,10709,428541,375167,442385,222543,221242,257,444876,403561,148121]

theorem envBound42265 : H12AffineFastState.Bounded env42265 := by
  intro p hp
  have h : env42265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42264_42265 : H12AffineEnvironment.transform 20 388158 env42264 = env42265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 388158 env42264 == env42265) = true)

def env42266 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388158,329730,17,188750,8192,65,10589,428405,375167,442385,222543,221242,257,444740,403561,147985]

theorem envBound42266 : H12AffineFastState.Bounded env42266 := by
  intro p hp
  have h : env42266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42265_42266 : H12AffineEnvironment.transform 6 8 env42265 = env42266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42265 == env42266) = true)

theorem identity42266 : scanCanonicalize (H12AffineFastState.compose env42266 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 157752) := by decide +kernel

theorem selectedBound42266 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env42267 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157752,1025,32769,230406,221242,17,188750,8192,65,10589,57677,250183,43049,222543,221242,257,41340,16465,147985]

theorem envBound42267 : H12AffineFastState.Bounded env42267 := by
  intro p hp
  have h : env42267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42266_42267 : H12AffineEnvironment.transform 17 157752 env42266 = env42267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157752 env42266 == env42267) = true)

theorem identity42267 : scanCanonicalize (H12AffineFastState.compose env42267 (packedSelected [1,2,3,4,5,6,7,8,10,11,14,16,18,19,20,22,27] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound42267 : packedSelected [1,2,3,4,5,6,7,8,10,11,14,16,18,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env42268 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,67618,1025,32769,58396,32,17,98644,8192,65,10589,57677,45405,43049,1365,32,257,41340,16465,74251]

theorem envBound42268 : H12AffineFastState.Bounded env42268 := by
  intro p hp
  have h : env42268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42267_42268 : H12AffineEnvironment.transform 16 90138 env42267 = env42268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env42267 == env42268) = true)

theorem identity42268 : scanCanonicalize (H12AffineFastState.compose env42268 (packedSelected [0,1,3,5,7,8,14,15,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound42268 : packedSelected [0,1,3,5,7,8,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env42269 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,65536,90138,67618,1025,8460,17681,32,17,73817,8192,65,10589,16448,4176,2340,1365,32,257,113,16465,74251]

theorem envBound42269 : H12AffineFastState.Bounded env42269 := by
  intro p hp
  have h : env42269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42268_42269 : H12AffineEnvironment.transform 14 8461 env42268 = env42269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env42268 == env42269) = true)

theorem identity42269 : scanCanonicalize (H12AffineFastState.compose env42269 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42269 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env42270 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,65536,90138,67618,1025,8460,17681,32,17,73736,8192,16,10508,16401,4097,2340,1284,32,257,32,16384,74251]

theorem envBound42270 : H12AffineFastState.Bounded env42270 := by
  intro p hp
  have h : env42270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42269_42270 : H12AffineEnvironment.transform 5 17 env42269 = env42270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42269 == env42270) = true)

theorem identity42270 : scanCanonicalize (H12AffineFastState.compose env42270 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound42270 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env42271 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,8203,16401,10281,1025,8460,17681,32,17,3,8192,16,10508,16401,4097,2340,1284,32,257,32,16384,512]

theorem envBound42271 : H12AffineFastState.Bounded env42271 := by
  intro p hp
  have h : env42271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42270_42271 : H12AffineEnvironment.transform 15 8203 env42270 = env42271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env42270 == env42271) = true)

theorem identity42271 : scanCanonicalize (H12AffineFastState.compose env42271 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 9260) := by decide +kernel

theorem selectedBound42271 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42272 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,9260,8461,8203,9277,10281,1025,8460,8509,32,17,3,8192,16,10508,9277,4097,2340,1284,32,257,32,9260,512]

theorem envBound42272 : H12AffineFastState.Bounded env42272 := by
  intro p hp
  have h : env42272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42271_42272 : H12AffineEnvironment.transform 13 9260 env42271 = env42272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9260 env42271 == env42272) = true)

theorem identity42272 : scanCanonicalize (H12AffineFastState.compose env42272 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound42272 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42273 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,300,1280,33,295,1297,2309,1025,32,17,32,17,3,300,16,2080,1297,4097,2340,1284,32,257,32,1280,512]

theorem envBound42273 : H12AffineFastState.Bounded env42273 := by
  intro p hp
  have h : env42273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42272_42273 : H12AffineEnvironment.transform 12 300 env42272 = env42273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env42272 == env42273) = true)

theorem identity42273 : scanCanonicalize (H12AffineFastState.compose env42273 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound42273 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env42274 : List Nat := [2,4,8,16,32,17,8,256,512,1024,11,4096,300,1280,33,295,1297,270,1025,32,17,32,17,3,300,16,43,1297,4097,303,1284,32,257,32,1280,512]

theorem envBound42274 : H12AffineFastState.Bounded env42274 := by
  intro p hp
  have h : env42274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42273_42274 : H12AffineEnvironment.transform 10 11 env42273 = env42274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env42273 == env42274) = true)

theorem identity42274 : scanCanonicalize (H12AffineFastState.compose env42274 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound42274 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env42275 : List Nat := [2,4,8,16,32,17,8,256,512,1024,11,1,300,1280,33,295,1297,270,1025,32,17,32,17,3,300,16,43,1297,0,303,1284,32,257,32,1280,512]

theorem envBound42275 : H12AffineFastState.Bounded env42275 := by
  intro p hp
  have h : env42275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42274_42275 : H12AffineEnvironment.transform 11 1 env42274 = env42275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env42274 == env42275) = true)

theorem identity42275 : scanCanonicalize (H12AffineFastState.compose env42275 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound42275 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42276 : List Nat := [2,4,8,16,32,17,8,256,512,304,11,1,300,48,33,295,33,270,305,32,17,32,17,3,300,16,43,33,0,303,52,32,257,32,48,512]

theorem envBound42276 : H12AffineFastState.Bounded env42276 := by
  intro p hp
  have h : env42276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42275_42276 : H12AffineEnvironment.transform 9 304 env42275 = env42276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env42275 == env42276) = true)

theorem identity42276 : scanCanonicalize (H12AffineFastState.compose env42276 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound42276 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42277 : List Nat := [2,4,8,1,32,0,8,256,512,289,11,1,300,33,33,295,33,270,288,32,0,32,0,3,300,1,43,33,0,303,37,32,257,32,33,512]

theorem envBound42277 : H12AffineFastState.Bounded env42277 := by
  intro p hp
  have h : env42277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42276_42277 : H12AffineEnvironment.transform 3 1 env42276 = env42277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42276 == env42277) = true)

theorem identity42277 : scanCanonicalize (H12AffineFastState.compose env42277 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound42277 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42278 : List Nat := [2,4,8,1,32,0,8,14,512,47,11,1,34,33,33,41,33,0,46,32,0,32,0,3,34,1,43,33,0,33,37,32,15,32,33,512]

theorem envBound42278 : H12AffineFastState.Bounded env42278 := by
  intro p hp
  have h : env42278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42277_42278 : H12AffineEnvironment.transform 7 14 env42277 = env42278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env42277 == env42278) = true)

theorem identity42278 : scanCanonicalize (H12AffineFastState.compose env42278 (packedSelected [0,4,11] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound42278 : packedSelected [0,4,11] rootPS < 2^1333 := by decide +kernel

def env42279 : List Nat := [2,4,8,1,11,0,8,14,512,4,11,1,9,10,10,2,10,0,5,11,0,11,0,3,9,1,0,10,0,10,14,11,15,11,10,512]

theorem envBound42279 : H12AffineFastState.Bounded env42279 := by
  intro p hp
  have h : env42279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42278_42279 : H12AffineEnvironment.transform 4 11 env42278 = env42279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env42278 == env42279) = true)

theorem identity42279 : scanCanonicalize (H12AffineFastState.compose env42279 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound42279 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42280 : List Nat := [2,1,8,1,11,0,8,11,512,1,11,1,9,10,10,2,10,0,0,11,0,11,0,3,9,1,0,10,0,10,11,11,10,11,10,512]

theorem envBound42280 : H12AffineFastState.Bounded env42280 := by
  intro p hp
  have h : env42280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42279_42280 : H12AffineEnvironment.transform 1 1 env42279 = env42280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env42279 == env42280) = true)

def env42281 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388158,329731,17,188750,8193,65,10588,428404,375167,442385,222543,221242,257,444741,403561,147984]

theorem envBound42281 : H12AffineFastState.Bounded env42281 := by
  intro p hp
  have h : env42281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42265_42281 : H12AffineEnvironment.transform 6 9 env42265 = env42281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42265 == env42281) = true)

theorem identity42281 : scanCanonicalize (H12AffineFastState.compose env42281 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound42281 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env42282 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,1025,8541,347490,329731,17,147474,8193,65,10588,403496,333859,418125,222543,221242,257,419865,403561,147984]

theorem envBound42282 : H12AffineFastState.Bounded env42282 := by
  intro p hp
  have h : env42282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42281_42282 : H12AffineEnvironment.transform 14 8540 env42281 = env42282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env42281 == env42282) = true)

def env42283 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,262144,1025,8541,347490,329731,17,2,8193,65,10588,288824,333859,270685,75103,73770,257,272393,288889,512]

theorem envBound42283 : H12AffineFastState.Bounded env42283 := by
  intro p hp
  have h : env42283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42282_42283 : H12AffineEnvironment.transform 16 16400 env42282 = env42283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env42282 == env42283) = true)

theorem identity42283 : scanCanonicalize (H12AffineFastState.compose env42283 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8543) := by decide +kernel

theorem selectedBound42283 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env42284 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8543,16400,262144,1025,8541,289853,272732,17,2,8193,65,10588,288824,276860,270685,1024,373,257,272393,288889,512]

theorem envBound42284 : H12AffineFastState.Bounded env42284 := by
  intro p hp
  have h : env42284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42283_42284 : H12AffineEnvironment.transform 15 8543 env42283 = env42284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8543 env42283 == env42284) = true)

theorem identity42284 : scanCanonicalize (H12AffineFastState.compose env42284 (packedSelected [0,7,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound42284 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env42285 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,8232,8235,16400,262144,1025,8233,289853,272424,17,2,8193,65,10280,288824,276488,270377,1024,1,117,272393,288889,512]

theorem envBound42285 : H12AffineFastState.Bounded env42285 := by
  intro p hp
  have h : env42285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42284_42285 : H12AffineEnvironment.transform 7 116 env42284 = env42285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env42284 == env42285) = true)

theorem identity42285 : scanCanonicalize (H12AffineFastState.compose env42285 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound42285 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env42286 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,41,16384,1,2,16400,262144,1025,0,281620,264193,17,2,40,65,2049,280593,268321,262144,1024,1,117,264224,280656,512]

theorem envBound42286 : H12AffineFastState.Bounded env42286 := by
  intro p hp
  have h : env42286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42285_42286 : H12AffineEnvironment.transform 12 41 env42285 = env42286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env42285 == env42286) = true)

def env42287 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16401,262144,1025,8541,347490,329731,17,3,8193,65,10588,288825,333859,270684,75102,73771,257,272392,288888,513]

theorem envBound42287 : H12AffineFastState.Bounded env42287 := by
  intro p hp
  have h : env42287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42282_42287 : H12AffineEnvironment.transform 16 16401 env42282 = env42287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env42282 == env42287) = true)

theorem identity42287 : scanCanonicalize (H12AffineFastState.compose env42287 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound42287 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env42288 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12620,8540,65536,12637,262144,1025,8541,343086,329731,17,3,8193,65,10588,268661,333859,270684,75102,73771,257,272392,268596,513]

theorem envBound42288 : H12AffineFastState.Bounded env42288 := by
  intro p hp
  have h : env42288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42287_42288 : H12AffineEnvironment.transform 13 12620 env42287 = env42288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env42287 == env42288) = true)

theorem identity42288 : scanCanonicalize (H12AffineFastState.compose env42288 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound42288 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42289 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12620,8540,8203,12637,262144,1025,8541,269349,272392,17,3,8193,65,10588,268661,276520,270684,1365,32,257,272392,268596,513]

theorem envBound42289 : H12AffineFastState.Bounded env42289 := by
  intro p hp
  have h : env42289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42288_42289 : H12AffineEnvironment.transform 15 8203 env42288 = env42289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env42288 == env42289) = true)

theorem identity42289 : scanCanonicalize (H12AffineFastState.compose env42289 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10361) := by decide +kernel

theorem selectedBound42289 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42290 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12620,8540,8203,12637,10361,1025,8541,13404,113,17,3,8193,65,10588,12556,4177,2341,1365,32,257,113,12621,513]

theorem envBound42290 : H12AffineFastState.Bounded env42290 := by
  intro p hp
  have h : env42290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42289_42290 : H12AffineEnvironment.transform 17 10361 env42289 = env42290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10361 env42289 == env42290) = true)

theorem identity42290 : scanCanonicalize (H12AffineFastState.compose env42290 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound42290 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env42291 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,4453,373,34,4468,2128,1025,372,5237,113,17,3,40,65,2421,4389,4177,2341,1365,32,257,113,4452,513]

theorem envBound42291 : H12AffineFastState.Bounded env42291 := by
  intro p hp
  have h : env42291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42290_42291 : H12AffineEnvironment.transform 12 41 env42290 = env42291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env42290 == env42291) = true)

theorem identity42291 : scanCanonicalize (H12AffineFastState.compose env42291 (packedSelected [0,2,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound42291 : packedSelected [0,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env42292 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,41,4160,80,34,4177,2128,1025,81,5237,113,17,3,40,65,2128,4096,4177,2048,1136,32,36,113,4161,513]

theorem envBound42292 : H12AffineFastState.Bounded env42292 := by
  intro p hp
  have h : env42292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42291_42292 : H12AffineEnvironment.transform 7 37 env42291 = env42292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env42291 == env42292) = true)

theorem identity42292 : scanCanonicalize (H12AffineFastState.compose env42292 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound42292 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env42293 : List Nat := [2,4,8,16,32,64,9,37,512,52,2048,4096,41,4160,80,34,4177,2128,53,81,4161,113,17,3,40,65,2128,4096,4177,2048,68,32,36,113,4161,513]

theorem envBound42293 : H12AffineFastState.Bounded env42293 := by
  intro p hp
  have h : env42293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42292_42293 : H12AffineEnvironment.transform 9 52 env42292 = env42293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env42292 == env42293) = true)

def env42294 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155700,2485295,2559345,8328,65,2475498,428540,375167,2305071,222542,2526213,257,2303475,2344022,148120]

theorem envBound42294 : H12AffineFastState.Bounded env42294 := by
  intro p hp
  have h : env42294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42263_42294 : H12AffineEnvironment.transform 23 2559345 env42263 = env42294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2559345 env42263 == env42294) = true)

theorem identity42294 : scanCanonicalize (H12AffineFastState.compose env42294 (packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 388278) := by decide +kernel

theorem selectedBound42294 : packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS < 2^1333 := by decide +kernel

def env42295 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388278,329730,153,188871,8328,65,10588,428540,375167,442521,222542,221363,257,444741,403680,148120]

theorem envBound42295 : H12AffineFastState.Bounded env42295 := by
  intro p hp
  have h : env42295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42294_42295 : H12AffineEnvironment.transform 20 388278 env42294 = env42295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 388278 env42294 == env42295) = true)

theorem identity42295 : scanCanonicalize (H12AffineFastState.compose env42295 (packedSelected [3,10,21,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound42295 : packedSelected [3,10,21,24,26] rootPS < 2^1333 := by decide +kernel

def env42296 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388158,329730,17,188751,8192,65,10588,428404,375167,442385,222542,221243,257,444741,403560,147984]

theorem envBound42296 : H12AffineFastState.Bounded env42296 := by
  intro p hp
  have h : env42296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42295_42296 : H12AffineEnvironment.transform 6 8 env42295 = env42296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42295 == env42296) = true)

def env42297 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,388158,329730,17,41311,8192,65,10588,313700,375167,294913,75102,73771,257,297301,288888,512]

theorem envBound42297 : H12AffineFastState.Bounded env42297 := by
  intro p hp
  have h : env42297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42296_42297 : H12AffineEnvironment.transform 16 16400 env42296 = env42297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env42296 == env42297) = true)

theorem identity42297 : scanCanonicalize (H12AffineFastState.compose env42297 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound42297 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env42298 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,388158,329730,17,41003,8192,65,10280,313360,374795,294913,74794,73771,117,296993,288888,512]

theorem envBound42298 : H12AffineFastState.Bounded env42298 := by
  intro p hp
  have h : env42298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42297_42298 : H12AffineEnvironment.transform 7 116 env42297 = env42298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env42297 == env42298) = true)

theorem identity42298 : scanCanonicalize (H12AffineFastState.compose env42298 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 29822) := by decide +kernel

theorem selectedBound42298 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42299 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,29822,16400,262144,1025,32769,301120,294012,17,41003,8192,65,10280,313360,314485,294913,20564,21589,117,296993,288888,512]

theorem envBound42299 : H12AffineFastState.Bounded env42299 := by
  intro p hp
  have h : env42299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42298_42299 : H12AffineEnvironment.transform 15 29822 env42298 = env42299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29822 env42298 == env42299) = true)

theorem identity42299 : scanCanonicalize (H12AffineFastState.compose env42299 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 21589) := by decide +kernel

theorem selectedBound42299 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env42300 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,21589,29822,16400,262144,1025,21588,281621,294012,17,29822,8192,65,10280,269381,268320,283732,20564,21589,117,285812,288888,512]

theorem envBound42300 : H12AffineFastState.Bounded env42300 := by
  intro p hp
  have h : env42300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42299_42300 : H12AffineEnvironment.transform 14 21589 env42299 = env42300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21589 env42299 == env42300) = true)

theorem identity42300 : scanCanonicalize (H12AffineFastState.compose env42300 (packedSelected [2,4,14,20,22] rootPS)) = affineNative (2^(17+1) ^^^ 23637) := by decide +kernel

theorem selectedBound42300 : packedSelected [2,4,14,20,22] rootPS < 2^1333 := by decide +kernel

def env42301 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,21589,29822,16400,23637,1025,21588,4160,8233,17,29822,8192,65,10280,16400,17525,2049,20564,21589,117,33,13357,512]

theorem envBound42301 : H12AffineFastState.Bounded env42301 := by
  intro p hp
  have h : env42301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42300_42301 : H12AffineEnvironment.transform 17 23637 env42300 = env42301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23637 env42300 == env42301) = true)

theorem identity42301 : scanCanonicalize (H12AffineFastState.compose env42301 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound42301 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env42302 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,9,16384,21589,21623,16400,23637,1025,21588,4160,32,17,21623,9,65,2081,16400,17525,2049,20564,21589,117,33,5156,512]

theorem envBound42302 : H12AffineFastState.Bounded env42302 := by
  intro p hp
  have h : env42302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42301_42302 : H12AffineEnvironment.transform 12 9 env42301 = env42302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env42301 == env42302) = true)

theorem identity42302 : scanCanonicalize (H12AffineFastState.compose env42302 (packedSelected [2,3,5,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 2081) := by decide +kernel

theorem selectedBound42302 : packedSelected [2,3,5,10,11] rootPS < 2^1333 := by decide +kernel

def env42303 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,9,2081,7284,7254,2097,5236,1025,7285,4160,32,17,7254,9,65,2081,2097,3156,2049,6261,7284,117,33,5156,512]

theorem envBound42303 : H12AffineFastState.Bounded env42303 := by
  intro p hp
  have h : env42303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42302_42303 : H12AffineEnvironment.transform 13 2081 env42302 = env42303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2081 env42302 == env42303) = true)

theorem identity42303 : scanCanonicalize (H12AffineFastState.compose env42303 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound42303 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env42304 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,3109,9,2081,81,115,2097,2129,1025,80,3173,32,17,115,9,65,2081,2097,3156,2049,1104,81,117,33,2049,512]

theorem envBound42304 : H12AffineFastState.Bounded env42304 := by
  intro p hp
  have h : env42304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42303_42304 : H12AffineEnvironment.transform 11 3109 env42303 = env42304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env42303 == env42304) = true)

theorem identity42304 : scanCanonicalize (H12AffineFastState.compose env42304 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound42304 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env42305 : List Nat := [2,4,8,16,32,64,8,116,512,20,2048,2097,9,2081,81,115,2097,2129,21,80,2161,32,17,115,9,65,2081,2097,2112,2049,68,81,117,33,2049,512]

theorem envBound42305 : H12AffineFastState.Bounded env42305 := by
  intro p hp
  have h : env42305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42304_42305 : H12AffineEnvironment.transform 9 20 env42304 = env42305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env42304 == env42305) = true)

theorem identity42305 : scanCanonicalize (H12AffineFastState.compose env42305 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42305 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env42306 : List Nat := [2,4,8,16,1,64,8,85,512,20,2048,2064,9,2048,81,82,2064,2129,21,80,2128,1,17,82,9,65,2048,2064,2112,2049,68,81,84,0,2049,512]

theorem envBound42306 : H12AffineFastState.Bounded env42306 := by
  intro p hp
  have h : env42306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42305_42306 : H12AffineEnvironment.transform 4 1 env42305 = env42306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42305 == env42306) = true)

theorem identity42306 : scanCanonicalize (H12AffineFastState.compose env42306 (packedSelected [1,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42306 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env42307 : List Nat := [2,4,8,16,1,16,8,5,512,20,2048,2064,9,2048,1,2,2064,2049,21,0,2048,1,17,2,9,17,2048,2064,2064,2049,20,1,4,0,2049,512]

theorem envBound42307 : H12AffineFastState.Bounded env42307 := by
  intro p hp
  have h : env42307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42306_42307 : H12AffineEnvironment.transform 5 16 env42306 = env42307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42306 == env42307) = true)

theorem identity42307 : scanCanonicalize (H12AffineFastState.compose env42307 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound42307 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42308 : List Nat := [2,4,8,16,1,16,8,5,1,20,2048,2064,9,2048,1,2,2064,2049,21,0,2048,1,17,2,9,17,2048,2064,2064,2049,20,1,4,0,2049,1]

theorem envBound42308 : H12AffineFastState.Bounded env42308 := by
  intro p hp
  have h : env42308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42307_42308 : H12AffineEnvironment.transform 8 1 env42307 = env42308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env42307 == env42308) = true)

theorem identity42308 : scanCanonicalize (H12AffineFastState.compose env42308 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound42308 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42309 : List Nat := [2,4,8,5,1,5,8,5,1,1,2048,2053,9,2048,1,2,2053,2049,0,0,2048,1,4,2,9,4,2048,2053,2053,2049,1,1,4,0,2049,1]

theorem envBound42309 : H12AffineFastState.Bounded env42309 := by
  intro p hp
  have h : env42309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42308_42309 : H12AffineEnvironment.transform 3 5 env42308 = env42309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env42308 == env42309) = true)

def leafEnv42309 : List Nat := [2,4,8,5,1,5,8,5,1,1,2048,2053,9,2048,1,2,2053,2049,0,0,2048,1,4,2,0,9,1,4,2048,2053,2053,2049,1,1,4,0,5,2,2049,1,1,2049,0]

def active42309 : List Nat := [0,1,2,10]

def tree42309 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42309 : H12WitnessSearch.Good tree42309 := H12GlobalWitnessIndex.good

theorem leafIdentity42309 : H12AffineFastState.composeSystem env42309 rootObs = leafEnv42309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42309 rootObs == leafEnv42309) = true)

theorem terminalChecked42309 : H12PackedTerminal.terminalCheckFast leafEnv42309 active42309 tree42309 = true := by decide +kernel

def env42310 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,388158,329730,17,41310,8192,65,10588,313701,375167,294912,75103,73770,257,297300,288889,513]

theorem envBound42310 : H12AffineFastState.Bounded env42310 := by
  intro p hp
  have h : env42310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42296_42310 : H12AffineEnvironment.transform 16 16401 env42296 = env42310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env42296 == env42310) = true)

theorem identity42310 : scanCanonicalize (H12AffineFastState.compose env42310 (packedSelected [2,4,6,7,9,11,17,18,23,27,32] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound42310 : packedSelected [2,4,6,7,9,11,17,18,23,27,32] rootPS < 2^1333 := by decide +kernel

def env42311 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,343,16401,262144,1025,32769,322921,264533,17,41310,8192,65,10588,313701,309288,294912,9224,8573,257,297300,288889,513]

theorem envBound42311 : H12AffineFastState.Bounded env42311 := by
  intro p hp
  have h : env42311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42310_42311 : H12AffineEnvironment.transform 15 343 env42310 = env42311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env42310 == env42311) = true)

theorem identity42311 : scanCanonicalize (H12AffineFastState.compose env42311 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound42311 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env42312 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,343,16401,43048,1025,32769,17729,41341,17,41310,8192,65,10588,24909,4096,10280,9224,8573,257,8572,49233,513]

theorem envBound42312 : H12AffineFastState.Bounded env42312 := by
  intro p hp
  have h : env42312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42311_42312 : H12AffineEnvironment.transform 17 43048 env42311 = env42312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env42311 == env42312) = true)

theorem identity42312 : scanCanonicalize (H12AffineFastState.compose env42312 (packedSelected [0,4,7,9,14,17] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound42312 : packedSelected [0,4,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env42313 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,343,16401,10280,1025,1,17729,8573,17,8542,8192,65,10588,24909,4096,10280,9224,8573,257,8572,16465,513]

theorem envBound42313 : H12AffineFastState.Bounded env42313 := by
  intro p hp
  have h : env42313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42312_42313 : H12AffineEnvironment.transform 14 0 env42312 = env42313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env42312 == env42313) = true)

theorem identity42313 : scanCanonicalize (H12AffineFastState.compose env42313 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound42313 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42314 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,0,343,16401,2420,1025,1,17729,33,17,2,348,65,2048,16401,4096,2420,1364,33,257,32,16465,513]

theorem envBound42314 : H12AffineFastState.Bounded env42314 := by
  intro p hp
  have h : env42314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42313_42314 : H12AffineEnvironment.transform 12 348 env42313 = env42314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env42313 == env42314) = true)

theorem identity42314 : scanCanonicalize (H12AffineFastState.compose env42314 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound42314 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42315 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,0,343,5393,2420,1025,1,4161,33,17,2,348,65,2048,5393,4096,2420,1364,33,257,32,5457,513]

theorem envBound42315 : H12AffineFastState.Bounded env42315 := by
  intro p hp
  have h : env42315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42314_42315 : H12AffineEnvironment.transform 13 5376 env42314 = env42315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env42314 == env42315) = true)

theorem identity42315 : scanCanonicalize (H12AffineFastState.compose env42315 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42315 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42316 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5376,0,262,5393,2341,1025,1,4112,33,17,2,269,16,2048,5393,4096,2341,1285,33,257,32,5376,513]

theorem envBound42316 : H12AffineFastState.Bounded env42316 := by
  intro p hp
  have h : env42316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42315_42316 : H12AffineEnvironment.transform 5 17 env42315 = env42316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42315 == env42316) = true)

theorem identity42316 : scanCanonicalize (H12AffineFastState.compose env42316 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound42316 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42317 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,5157,0,35,5172,2048,1025,1,4112,33,17,2,40,16,2048,5172,4096,2048,1056,33,36,32,5157,513]

theorem envBound42317 : H12AffineFastState.Bounded env42317 := by
  intro p hp
  have h : env42317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42316_42317 : H12AffineEnvironment.transform 7 37 env42316 = env42317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env42316 == env42317) = true)

def env42318 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,40,1045,0,35,1028,2048,1025,1,32,33,17,2,40,16,2048,1028,48,2048,1056,33,36,32,1045,513]

theorem envBound42318 : H12AffineFastState.Bounded env42318 := by
  intro p hp
  have h : env42318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0