import H12CloudChart0Data182

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans46345_46346 : H12AffineEnvironment.transform 5 48 env46345 = env46346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env46345 == env46346) = true)

theorem identity46346 : scanCanonicalize (H12AffineFastState.compose env46346 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound46346 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46347 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,2065,300,16384,0,262,16400,2309,1025,1,17680,32,16,34,301,49,2048,16433,2096,2309,1316,1,257,0,16385,545]

theorem envBound46347 : H12AffineFastState.Bounded env46347 := by
  intro p hp
  have h : env46347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46346_46347 : H12AffineEnvironment.transform 15 262 env46346 = env46347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env46346 == env46347) = true)

theorem identity46347 : scanCanonicalize (H12AffineFastState.compose env46347 (packedSelected [1,2,3,4,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound46347 : packedSelected [1,2,3,4,7,11] rootPS < 2^1333 := by decide +kernel

def env46348 : List Nat := [2,4,8,16,32,48,9,256,512,1024,260,277,300,16384,0,262,16400,1,1025,1,17680,32,16,34,301,49,260,16433,308,1,1316,1,257,0,16385,545]

theorem envBound46348 : H12AffineFastState.Bounded env46348 := by
  intro p hp
  have h : env46348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46347_46348 : H12AffineEnvironment.transform 10 260 env46347 = env46348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env46347 == env46348) = true)

theorem identity46348 : scanCanonicalize (H12AffineFastState.compose env46348 (packedSelected [1,2,4,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound46348 : packedSelected [1,2,4,8,9] rootPS < 2^1333 := by decide +kernel

def env46349 : List Nat := [2,4,8,16,32,48,9,256,512,52,260,277,300,16384,0,262,16400,1,53,1,16676,32,16,34,301,49,260,16433,308,1,272,1,257,0,16385,545]

theorem envBound46349 : H12AffineFastState.Bounded env46349 := by
  intro p hp
  have h : env46349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46348_46349 : H12AffineEnvironment.transform 9 52 env46348 = env46349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env46348 == env46349) = true)

def env46350 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,4194304,17,16777216,8193,65,21039476,18973701,2118976,2421,16876545,23160137,257,18990133,18949400,16819038]

theorem envBound46350 : H12AffineFastState.Bounded env46350 := by
  intro p hp
  have h : env46350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46338_46350 : H12AffineEnvironment.transform 16 16401 env46338 = env46350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env46338 == env46350) = true)

def env46351 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16401,34817,1025,32769,2097152,4194304,17,16777216,8193,65,21039104,18973701,2118708,2049,16876545,23159869,117,18990133,18949228,16818730]

theorem envBound46351 : H12AffineFastState.Bounded env46351 := by
  intro p hp
  have h : env46351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46350_46351 : H12AffineEnvironment.transform 7 116 env46350 = env46351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env46350 == env46351) = true)

theorem identity46351 : scanCanonicalize (H12AffineFastState.compose env46351 (packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS)) = affineNative (2^(23+1) ^^^ 2212884) := by decide +kernel

theorem selectedBound46351 : packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env46352 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16401,34817,1025,32769,2097152,4194304,17,2212884,8193,65,6343700,16401,2118708,2049,2113557,4235305,117,33,57464,2188862]

theorem envBound46352 : H12AffineFastState.Bounded env46352 := by
  intro p hp
  have h : env46352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46351_46352 : H12AffineEnvironment.transform 23 2212884 env46351 = env46352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2212884 env46351 == env46352) = true)

def env46353 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,16384,32768,65536,16401,34817,1025,32769,2097152,4194304,17,2212884,8193,17,6343700,16401,2118708,2049,2113557,4235305,37,33,57384,2188862]

theorem envBound46353 : H12AffineFastState.Bounded env46353 := by
  intro p hp
  have h : env46353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46352_46353 : H12AffineEnvironment.transform 5 16 env46352 = env46353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46352 == env46353) = true)

theorem identity46353 : scanCanonicalize (H12AffineFastState.compose env46353 (packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 73771) := by decide +kernel

theorem selectedBound46353 : packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS < 2^1333 := by decide +kernel

def env46354 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,16384,32768,65536,16401,34817,1025,32769,2097152,73771,17,2212884,8193,17,2223167,16401,2118708,2049,2113557,98306,37,33,57384,2188862]

theorem envBound46354 : H12AffineFastState.Bounded env46354 := by
  intro p hp
  have h : env46354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46353_46354 : H12AffineEnvironment.transform 21 73771 env46353 = env46354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73771 env46353 == env46354) = true)

theorem identity46354 : scanCanonicalize (H12AffineFastState.compose env46354 (packedSelected [0,3,7,9,10,14,17,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound46354 : packedSelected [0,3,7,9,10,14,17,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env46355 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,16384,8232,65536,16401,10281,1025,8233,2097152,73771,17,2188348,8193,17,2182167,16401,2118708,2049,2113557,73770,37,33,16384,2188862]

theorem envBound46355 : H12AffineFastState.Bounded env46355 := by
  intro p hp
  have h : env46355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46354_46355 : H12AffineEnvironment.transform 14 8232 env46354 = env46355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env46354 == env46355) = true)

theorem identity46355 : scanCanonicalize (H12AffineFastState.compose env46355 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(20+1) ^^^ 25629) := by decide +kernel

theorem selectedBound46355 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env46356 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,16384,8232,65536,16401,10281,1025,8233,25629,73771,17,65569,8193,17,75786,16401,12329,2049,9224,73770,37,33,16384,66083]

theorem envBound46356 : H12AffineFastState.Bounded env46356 := by
  intro p hp
  have h : env46356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46355_46356 : H12AffineEnvironment.transform 20 25629 env46355 = env46356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25629 env46355 == env46356) = true)

theorem identity46356 : scanCanonicalize (H12AffineFastState.compose env46356 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound46356 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env46357 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,16384,8232,21510,16401,10281,1025,8233,25629,29741,17,21543,8193,17,31756,16401,12329,2049,9224,29740,37,33,16384,22053]

theorem envBound46357 : H12AffineFastState.Bounded env46357 := by
  intro p hp
  have h : env46357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46356_46357 : H12AffineEnvironment.transform 15 21510 env46356 = env46357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env46356 == env46357) = true)

theorem identity46357 : scanCanonicalize (H12AffineFastState.compose env46357 (packedSelected [12,15] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound46357 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env46358 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,16384,0,21510,16401,2049,1025,1,17461,21509,17,21543,41,17,23588,16401,4097,2049,1056,21508,37,33,16384,22053]

theorem envBound46358 : H12AffineFastState.Bounded env46358 := by
  intro p hp
  have h : env46358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46357_46358 : H12AffineEnvironment.transform 12 40 env46357 = env46358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env46357 == env46358) = true)

theorem identity46358 : scanCanonicalize (H12AffineFastState.compose env46358 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound46358 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env46359 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,3108,40,16384,0,18466,16401,2049,1025,1,17461,18465,17,18435,41,17,16384,16401,3109,2049,1056,18464,37,33,16384,18945]

theorem envBound46359 : H12AffineFastState.Bounded env46359 := by
  intro p hp
  have h : env46359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46358_46359 : H12AffineEnvironment.transform 11 3108 env46358 = env46359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env46358 == env46359) = true)

def env46360 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,8192,16384,32768,65536,16401,34817,1025,32769,2097152,4194304,17,2212884,8193,16,6343700,16401,2118708,2049,2113557,4235305,36,33,57385,2188862]

theorem envBound46360 : H12AffineFastState.Bounded env46360 := by
  intro p hp
  have h : env46360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46352_46360 : H12AffineEnvironment.transform 5 17 env46352 = env46360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46352 == env46360) = true)

theorem identity46360 : scanCanonicalize (H12AffineFastState.compose env46360 (packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound46360 : packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS < 2^1333 := by decide +kernel

def env46361 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,8192,16384,0,65536,16401,2049,1025,1,2097152,4194304,17,2180116,8193,16,6310932,16401,2118708,2049,2113557,4202537,36,33,24617,2188862]

theorem envBound46361 : H12AffineFastState.Bounded env46361 := by
  intro p hp
  have h : env46361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46360_46361 : H12AffineEnvironment.transform 14 0 env46360 = env46361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env46360 == env46361) = true)

theorem identity46361 : scanCanonicalize (H12AffineFastState.compose env46361 (packedSelected [1,3,5,8,10,17,18,19,23] rootPS)) = affineNative (2^(21+1) ^^^ 2122813) := by decide +kernel

theorem selectedBound46361 : packedSelected [1,3,5,8,10,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env46362 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,8192,16384,0,65536,16401,2049,1025,1,2097152,2122813,17,2180116,8193,16,10281,16401,2118708,2049,2113557,2114580,36,33,24617,2188862]

theorem envBound46362 : H12AffineFastState.Bounded env46362 := by
  intro p hp
  have h : env46362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46361_46362 : H12AffineEnvironment.transform 21 2122813 env46361 = env46362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2122813 env46361 == env46362) = true)

theorem identity46362 : scanCanonicalize (H12AffineFastState.compose env46362 (packedSelected [1,3,6,8,10,11,12,14,15,18,24] rootPS)) = affineNative (2^(20+1) ^^^ 12313) := by decide +kernel

theorem selectedBound46362 : packedSelected [1,3,6,8,10,11,12,14,15,18,24] rootPS < 2^1333 := by decide +kernel

def env46363 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,8192,16384,0,65536,16401,2049,1025,1,12313,21540,17,95245,8193,16,10281,16401,25645,2049,28684,29709,36,33,24617,87591]

theorem envBound46363 : H12AffineFastState.Bounded env46363 := by
  intro p hp
  have h : env46363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46362_46363 : H12AffineEnvironment.transform 20 12313 env46362 = env46363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12313 env46362 == env46363) = true)

theorem identity46363 : scanCanonicalize (H12AffineFastState.compose env46363 (packedSelected [0,1,4,6,7,8,9,12,15,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound46363 : packedSelected [0,1,4,6,7,8,9,12,15,17,19] rootPS < 2^1333 := by decide +kernel

def env46364 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,8192,5124,0,65536,5141,2049,1025,1,12313,32,17,73737,8193,16,10281,5141,12329,2049,9224,8201,36,33,13357,66083]

theorem envBound46364 : H12AffineFastState.Bounded env46364 := by
  intro p hp
  have h : env46364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46363_46364 : H12AffineEnvironment.transform 13 5124 env46363 = env46364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env46363 == env46364) = true)

theorem identity46364 : scanCanonicalize (H12AffineFastState.compose env46364 (packedSelected [0,1,2,3,4,5,7,8,9,10,11,14] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound46364 : packedSelected [0,1,2,3,4,5,7,8,9,10,11,14] rootPS < 2^1333 := by decide +kernel

def env46365 : List Nat := [2,4,8,16,32,17,9,37,512,1024,33,4096,8192,5124,0,65536,5141,32,1025,1,12313,32,17,73737,8193,16,8200,5141,12329,32,9224,8201,36,33,13357,66083]

theorem envBound46365 : H12AffineFastState.Bounded env46365 := by
  intro p hp
  have h : env46365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46364_46365 : H12AffineEnvironment.transform 10 33 env46364 = env46365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env46364 == env46365) = true)

theorem identity46365 : scanCanonicalize (H12AffineFastState.compose env46365 (packedSelected [0,1,4,6,7,8,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound46365 : packedSelected [0,1,4,6,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env46366 : List Nat := [2,4,8,16,32,17,9,37,512,1024,33,1060,8192,32,0,65536,49,32,1025,1,9277,32,17,73737,8193,16,8200,49,9229,32,9224,8201,36,33,8201,66083]

theorem envBound46366 : H12AffineFastState.Bounded env46366 := by
  intro p hp
  have h : env46366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46365_46366 : H12AffineEnvironment.transform 11 1060 env46365 = env46366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env46365 == env46366) = true)

theorem identity46366 : scanCanonicalize (H12AffineFastState.compose env46366 (packedSelected [0,1,3,4,5,6,7,8,9] rootPS)) = affineNative (2^(15+1) ^^^ 1079) := by decide +kernel

theorem selectedBound46366 : packedSelected [0,1,3,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env46367 : List Nat := [2,4,8,16,32,17,9,37,512,1024,33,1060,8192,32,0,1079,49,32,1025,1,9277,32,17,9278,8193,16,8200,49,9229,32,9224,8201,36,33,8201,1556]

theorem envBound46367 : H12AffineFastState.Bounded env46367 := by
  intro p hp
  have h : env46367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46366_46367 : H12AffineEnvironment.transform 15 1079 env46366 = env46367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1079 env46366 == env46367) = true)

theorem identity46367 : scanCanonicalize (H12AffineFastState.compose env46367 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound46367 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env46368 : List Nat := [2,4,8,16,32,17,9,37,512,20,33,48,8192,32,0,35,49,32,21,1,8233,32,17,8234,8193,16,8200,49,8217,32,8220,8201,36,33,8201,512]

theorem envBound46368 : H12AffineFastState.Bounded env46368 := by
  intro p hp
  have h : env46368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46367_46368 : H12AffineEnvironment.transform 9 20 env46367 = env46368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env46367 == env46368) = true)

theorem identity46368 : scanCanonicalize (H12AffineFastState.compose env46368 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound46368 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46369 : List Nat := [2,4,8,16,0,17,9,5,512,20,1,16,8192,0,0,3,17,0,21,1,8201,0,17,8202,8193,16,8200,17,8217,0,8220,8201,4,1,8201,512]

theorem envBound46369 : H12AffineFastState.Bounded env46369 := by
  intro p hp
  have h : env46369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46368_46369 : H12AffineEnvironment.transform 4 0 env46368 = env46369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env46368 == env46369) = true)

def env46370 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16401,34816,1025,32769,2097152,4194304,17,16777216,8193,65,21039105,18973701,2118709,2048,16876545,23159868,116,18990133,18949229,16818731]

theorem envBound46370 : H12AffineFastState.Bounded env46370 := by
  intro p hp
  have h : env46370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46350_46370 : H12AffineEnvironment.transform 7 117 env46350 = env46370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env46350 == env46370) = true)

theorem identity46370 : scanCanonicalize (H12AffineFastState.compose env46370 (packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 91198) := by decide +kernel

theorem selectedBound46370 : packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env46371 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16401,34816,1025,32769,91198,4194304,17,16777216,8193,65,21039105,16834619,77835,2048,16876545,20971522,116,16818187,16793683,16818731]

theorem envBound46371 : H12AffineFastState.Bounded env46371 := by
  intro p hp
  have h : env46371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46370_46371 : H12AffineEnvironment.transform 20 91198 env46370 = env46371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91198 env46370 == env46371) = true)

def env46372 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,16384,32768,65536,16401,34816,1025,32769,91198,4194304,17,16777216,8193,17,21039105,16834619,77835,2048,16876545,20971522,36,16818187,16793603,16818731]

theorem envBound46372 : H12AffineFastState.Bounded env46372 := by
  intro p hp
  have h : env46372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46371_46372 : H12AffineEnvironment.transform 5 16 env46371 = env46372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46371 == env46372) = true)

theorem identity46372 : scanCanonicalize (H12AffineFastState.compose env46372 (packedSelected [3,7,10,14,17,20,24,26,27] rootPS)) = affineNative (2^(23+1) ^^^ 4292608) := by decide +kernel

theorem selectedBound46372 : packedSelected [3,7,10,14,17,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env46373 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,16384,32768,65536,16401,34816,1025,32769,91198,4194304,17,4292608,8193,17,34817,4284475,77835,2048,4195329,98306,36,4268043,4308995,4268587]

theorem envBound46373 : H12AffineFastState.Bounded env46373 := by
  intro p hp
  have h : env46373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46372_46373 : H12AffineEnvironment.transform 23 4292608 env46372 = env46373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4292608 env46372 == env46373) = true)

theorem identity46373 : scanCanonicalize (H12AffineFastState.compose env46373 (packedSelected [0,3,7,9,10,14,17,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound46373 : packedSelected [0,3,7,9,10,14,17,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env46374 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,16384,8233,65536,16401,10281,1025,8232,91198,4194304,17,4268073,8193,17,10280,4284475,77835,2048,4195329,73771,36,4268043,4284458,4268587]

theorem envBound46374 : H12AffineFastState.Bounded env46374 := by
  intro p hp
  have h : env46374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46373_46374 : H12AffineEnvironment.transform 14 8233 env46373 = env46374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env46373 == env46374) = true)

theorem identity46374 : scanCanonicalize (H12AffineFastState.compose env46374 (packedSelected [0,2,4,7,9,17] rootPS)) = affineNative (2^(13+1) ^^^ 13357) := by decide +kernel

theorem selectedBound46374 : packedSelected [0,2,4,7,9,17] rootPS < 2^1333 := by decide +kernel

def env46375 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,13357,8233,65536,13372,10281,1025,8232,69651,4194304,17,4268073,8193,17,10280,4264982,77835,2048,4195329,73771,36,4268043,4264967,4268587]

theorem envBound46375 : H12AffineFastState.Bounded env46375 := by
  intro p hp
  have h : env46375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46374_46375 : H12AffineEnvironment.transform 13 13357 env46374 = env46375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13357 env46374 == env46375) = true)

theorem identity46375 : scanCanonicalize (H12AffineFastState.compose env46375 (packedSelected [2,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound46375 : packedSelected [2,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env46376 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5125,1,65536,5140,2049,1025,0,69651,4194304,17,4259841,41,17,2048,4264982,69667,2048,4195329,65539,36,4259875,4264967,4260355]

theorem envBound46376 : H12AffineFastState.Bounded env46376 := by
  intro p hp
  have h : env46376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46375_46376 : H12AffineEnvironment.transform 12 40 env46375 = env46376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env46375 == env46376) = true)

theorem identity46376 : scanCanonicalize (H12AffineFastState.compose env46376 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound46376 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env46377 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5125,1,65536,5140,2049,1025,0,69651,33,17,65568,41,17,2048,70711,69667,2048,1056,65539,36,65538,70694,66082]

theorem envBound46377 : H12AffineFastState.Bounded env46377 := by
  intro p hp
  have h : env46377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46376_46377 : H12AffineEnvironment.transform 21 33 env46376 = env46377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env46376 == env46377) = true)

theorem identity46377 : scanCanonicalize (H12AffineFastState.compose env46377 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound46377 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env46378 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,3076,40,2049,1,65536,2064,2049,1025,0,68631,33,17,65568,41,17,2048,67635,68647,2048,1056,65539,36,65538,67618,66082]

theorem envBound46378 : H12AffineFastState.Bounded env46378 := by
  intro p hp
  have h : env46378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46377_46378 : H12AffineEnvironment.transform 11 3076 env46377 = env46378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env46377 == env46378) = true)

theorem identity46378 : scanCanonicalize (H12AffineFastState.compose env46378 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound46378 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env46379 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,3076,40,2049,1,34,2064,2049,1025,0,3125,33,17,2,41,17,2048,2065,3077,2048,1056,33,36,32,2048,512]

theorem envBound46379 : H12AffineFastState.Bounded env46379 := by
  intro p hp
  have h : env46379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46378_46379 : H12AffineEnvironment.transform 15 34 env46378 = env46379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env46378 == env46379) = true)

theorem identity46379 : scanCanonicalize (H12AffineFastState.compose env46379 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound46379 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46380 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,2097,40,2049,1,34,2064,2049,52,0,2048,33,17,2,41,17,2048,2065,2096,2048,21,33,36,32,2048,512]

theorem envBound46380 : H12AffineFastState.Bounded env46380 := by
  intro p hp
  have h : env46380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46379_46380 : H12AffineEnvironment.transform 9 53 env46379 = env46380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env46379 == env46380) = true)

theorem identity46380 : scanCanonicalize (H12AffineFastState.compose env46380 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound46380 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46381 : List Nat := [2,4,8,16,32,16,9,37,512,53,1,48,40,0,1,34,17,0,52,0,1,33,17,2,41,17,1,16,49,1,21,33,36,32,1,512]

theorem envBound46381 : H12AffineFastState.Bounded env46381 := by
  intro p hp
  have h : env46381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46380_46381 : H12AffineEnvironment.transform 10 1 env46380 = env46381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env46380 == env46381) = true)

theorem identity46381 : scanCanonicalize (H12AffineFastState.compose env46381 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound46381 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46382 : List Nat := [2,4,8,16,0,16,9,5,512,21,1,16,8,0,1,2,17,0,20,0,1,1,17,2,9,17,1,16,17,1,21,1,4,0,1,512]

theorem envBound46382 : H12AffineFastState.Bounded env46382 := by
  intro p hp
  have h : env46382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46381_46382 : H12AffineEnvironment.transform 4 0 env46381 = env46382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env46381 == env46382) = true)

theorem identity46382 : scanCanonicalize (H12AffineFastState.compose env46382 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound46382 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46383 : List Nat := [2,4,8,0,0,0,9,5,512,5,1,0,8,0,1,2,1,0,4,0,1,1,1,2,9,1,1,0,1,1,5,1,4,0,1,512]

theorem envBound46383 : H12AffineFastState.Bounded env46383 := by
  intro p hp
  have h : env46383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46382_46383 : H12AffineEnvironment.transform 3 0 env46382 = env46383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env46382 == env46383) = true)

theorem identity46383 : scanCanonicalize (H12AffineFastState.compose env46383 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound46383 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46384 : List Nat := [2,4,8,0,0,0,9,5,14,5,1,0,8,0,1,2,1,0,4,0,1,1,1,2,9,1,1,0,1,1,5,1,4,0,1,14]

theorem envBound46384 : H12AffineFastState.Bounded env46384 := by
  intro p hp
  have h : env46384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46383_46384 : H12AffineEnvironment.transform 8 14 env46383 = env46384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env46383 == env46384) = true)

def env46385 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,8192,16384,32768,65536,16401,34816,1025,32769,91198,4194304,17,16777216,8193,16,21039105,16834619,77835,2048,16876545,20971522,37,16818187,16793602,16818731]

theorem envBound46385 : H12AffineFastState.Bounded env46385 := by
  intro p hp
  have h : env46385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46371_46385 : H12AffineEnvironment.transform 5 17 env46371 = env46385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46371 == env46385) = true)

theorem identity46385 : scanCanonicalize (H12AffineFastState.compose env46385 (packedSelected [3,7,10,14,17,20,24,26,27] rootPS)) = affineNative (2^(23+1) ^^^ 4235275) := by decide +kernel

theorem selectedBound46385 : packedSelected [3,7,10,14,17,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env46386 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,8192,16384,32768,65536,16401,34816,1025,32769,91198,4194304,17,4235275,8193,16,108554,4210736,77835,2048,4269066,40969,37,4194304,4251657,4194848]

theorem envBound46386 : H12AffineFastState.Bounded env46386 := by
  intro p hp
  have h : env46386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46385_46386 : H12AffineEnvironment.transform 23 4235275 env46385 = env46386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4235275 env46385 == env46386) = true)

theorem identity46386 : scanCanonicalize (H12AffineFastState.compose env46386 (packedSelected [0,7,9,14,18,19,20,22,23,26] rootPS)) = affineNative (2^(21+1) ^^^ 8200) := by decide +kernel

theorem selectedBound46386 : packedSelected [0,7,9,14,18,19,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env46387 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,8192,16384,32768,65536,16401,34816,1025,32769,91198,8200,17,32771,8193,16,108554,24632,77835,2048,66562,40969,37,8200,49153,8744]

theorem envBound46387 : H12AffineFastState.Bounded env46387 := by
  intro p hp
  have h : env46387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46386_46387 : H12AffineEnvironment.transform 21 8200 env46386 = env46387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8200 env46386 == env46387) = true)

theorem identity46387 : scanCanonicalize (H12AffineFastState.compose env46387 (packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound46387 : packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env46388 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,8192,16384,32768,34,16401,34816,1025,32769,25628,8200,17,32771,8193,16,43048,24632,12329,2048,1056,40969,37,8200,49153,8744]

theorem envBound46388 : H12AffineFastState.Bounded env46388 := by
  intro p hp
  have h : env46388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46387_46388 : H12AffineEnvironment.transform 15 34 env46387 = env46388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env46387 == env46388) = true)

theorem identity46388 : scanCanonicalize (H12AffineFastState.compose env46388 (packedSelected [0,1,2,6,7,8,10,14,17] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound46388 : packedSelected [0,1,2,6,7,8,10,14,17] rootPS < 2^1333 := by decide +kernel

def env46389 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,8192,16384,0,34,16401,2048,1025,1,25628,8200,17,3,8193,16,10280,24632,12329,2048,1056,8201,37,8200,16385,8744]

theorem envBound46389 : H12AffineFastState.Bounded env46389 := by
  intro p hp
  have h : env46389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46388_46389 : H12AffineEnvironment.transform 14 0 env46388 = env46389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env46388 == env46389) = true)

theorem identity46389 : scanCanonicalize (H12AffineFastState.compose env46389 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound46389 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env46390 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,8192,5124,0,34,5141,2048,1025,1,12312,8200,17,3,8193,16,10280,13372,12329,2048,1056,8201,37,8200,5125,8744]

theorem envBound46390 : H12AffineFastState.Bounded env46390 := by
  intro p hp
  have h : env46390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46389_46390 : H12AffineEnvironment.transform 13 5124 env46389 = env46390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env46389 == env46390) = true)

theorem identity46390 : scanCanonicalize (H12AffineFastState.compose env46390 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound46390 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env46391 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5124,0,34,5141,2048,1025,1,4144,32,17,3,41,16,2048,5140,4097,2048,1056,33,37,32,5125,512]

theorem envBound46391 : H12AffineFastState.Bounded env46391 := by
  intro p hp
  have h : env46391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46390_46391 : H12AffineEnvironment.transform 12 40 env46390 = env46391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env46390 == env46391) = true)

theorem identity46391 : scanCanonicalize (H12AffineFastState.compose env46391 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 3077) := by decide +kernel

theorem selectedBound46391 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46392 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,3077,40,2049,0,34,2064,2048,1025,1,3125,32,17,3,41,16,2048,2065,3076,2048,1056,33,37,32,2048,512]

theorem envBound46392 : H12AffineFastState.Bounded env46392 := by
  intro p hp
  have h : env46392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46391_46392 : H12AffineEnvironment.transform 11 3077 env46391 = env46392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3077 env46391 == env46392) = true)

theorem identity46392 : scanCanonicalize (H12AffineFastState.compose env46392 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46392 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env46393 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,3077,9,2049,0,3,2064,2048,1025,1,3092,1,17,3,8,16,2048,2065,3076,2048,1025,0,4,1,2048,512]

theorem envBound46393 : H12AffineFastState.Bounded env46393 := by
  intro p hp
  have h : env46393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46392_46393 : H12AffineEnvironment.transform 4 1 env46392 = env46393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46392 == env46393) = true)

theorem identity46393 : scanCanonicalize (H12AffineFastState.compose env46393 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound46393 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env46394 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,2065,9,2049,0,3,2064,2048,21,1,2048,1,17,3,8,16,2048,2065,2064,2048,21,0,4,1,2048,512]

theorem envBound46394 : H12AffineFastState.Bounded env46394 := by
  intro p hp
  have h : env46394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46393_46394 : H12AffineEnvironment.transform 9 20 env46393 = env46394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env46393 == env46394) = true)

theorem identity46394 : scanCanonicalize (H12AffineFastState.compose env46394 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound46394 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46395 : List Nat := [2,4,8,16,1,17,9,5,1,20,2048,2065,9,2049,0,3,2064,2048,21,1,2048,1,17,3,8,16,2048,2065,2064,2048,21,0,4,1,2048,1]

theorem envBound46395 : H12AffineFastState.Bounded env46395 := by
  intro p hp
  have h : env46395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46394_46395 : H12AffineEnvironment.transform 8 1 env46394 = env46395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env46394 == env46395) = true)

theorem identity46395 : scanCanonicalize (H12AffineFastState.compose env46395 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 30) := by decide +kernel

theorem selectedBound46395 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46396 : List Nat := [2,4,8,16,1,17,9,5,1,20,30,15,9,31,0,3,14,30,21,1,30,1,17,3,8,16,30,15,14,30,21,0,4,1,30,1]

theorem envBound46396 : H12AffineFastState.Bounded env46396 := by
  intro p hp
  have h : env46396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46395_46396 : H12AffineEnvironment.transform 10 30 env46395 = env46396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 30 env46395 == env46396) = true)

def leafEnv46396 : List Nat := [2,4,8,16,1,17,9,5,1,20,30,15,9,31,0,3,14,30,21,1,30,1,17,3,20,8,1,16,30,15,14,30,21,0,4,1,5,2,30,1,1,31,0]

def active46396 : List Nat := [0,1,2,3]

def tree46396 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46396 : H12WitnessSearch.Good tree46396 := H12GlobalWitnessIndex.good

theorem leafIdentity46396 : H12AffineFastState.composeSystem env46396 rootObs = leafEnv46396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46396 rootObs == leafEnv46396) = true)

theorem terminalChecked46396 : H12PackedTerminal.terminalCheckFast leafEnv46396 active46396 tree46396 = true := by decide +kernel

def env46397 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,147457,16777216,8193,65,21039477,18973701,2233680,2420,17024017,23160137,257,19104805,19096840,16966478]

theorem envBound46397 : H12AffineFastState.Bounded env46397 := by
  intro p hp
  have h : env46397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46337_46397 : H12AffineEnvironment.transform 22 147457 env46337 = env46397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env46337 == env46397) = true)

theorem identity46397 : scanCanonicalize (H12AffineFastState.compose env46397 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188751) := by decide +kernel

theorem selectedBound46397 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env46398 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,147457,188751,8193,65,4450362,2319690,2233680,2420,75102,6521862,257,2188650,2196551,513]

theorem envBound46398 : H12AffineFastState.Bounded env46398 := by
  intro p hp
  have h : env46398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46397_46398 : H12AffineEnvironment.transform 23 188751 env46397 = env46398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188751 env46397 == env46398) = true)

def env46399 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,2097152,4194304,17,41311,8193,65,4302890,2172250,2118976,2420,75102,6407190,257,2188650,2196551,513]

theorem envBound46399 : H12AffineFastState.Bounded env46399 := by
  intro p hp
  have h : env46399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46398_46399 : H12AffineEnvironment.transform 16 16400 env46398 = env46399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env46398 == env46399) = true)

theorem identity46399 : scanCanonicalize (H12AffineFastState.compose env46399 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound46399 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env46400 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,115735,4194304,17,41311,8193,65,4302890,57677,102743,2420,75102,4194305,257,41341,16464,513]

theorem envBound46400 : H12AffineFastState.Bounded env46400 := by
  intro p hp
  have h : env46400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46399_46400 : H12AffineEnvironment.transform 20 115735 env46399 = env46400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env46399 == env46400) = true)

def env46401 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,65536,16400,10589,1025,8233,91199,4194304,17,375,8193,65,4261890,16741,78207,2420,75102,4194305,257,341,16464,513]

theorem envBound46401 : H12AffineFastState.Bounded env46401 := by
  intro p hp
  have h : env46401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46400_46401 : H12AffineEnvironment.transform 14 8232 env46400 = env46401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env46400 == env46401) = true)

theorem identity46401 : scanCanonicalize (H12AffineFastState.compose env46401 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound46401 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env46402 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,65536,16400,10589,1025,8233,91199,8572,17,375,8193,65,76158,16741,78207,2420,75102,8573,257,341,16464,513]

theorem envBound46402 : H12AffineFastState.Bounded env46402 := by
  intro p hp
  have h : env46402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46401_46402 : H12AffineEnvironment.transform 21 8572 env46401 = env46402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env46401 == env46402) = true)

theorem identity46402 : scanCanonicalize (H12AffineFastState.compose env46402 (packedSelected [1,3,5,8,10,11,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound46402 : packedSelected [1,3,5,8,10,11,18,19] rootPS < 2^1333 := by decide +kernel

def env46403 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,35,16400,10589,1025,8233,25628,8572,17,375,8193,65,10589,16741,12636,2420,9597,8573,257,341,16464,513]

theorem envBound46403 : H12AffineFastState.Bounded env46403 := by
  intro p hp
  have h : env46403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46402_46403 : H12AffineEnvironment.transform 15 35 env46402 = env46403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env46402 == env46403) = true)

theorem identity46403 : scanCanonicalize (H12AffineFastState.compose env46403 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound46403 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env46404 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,1,35,16400,2420,1025,0,17461,341,17,375,40,65,2420,16741,4469,2420,1364,340,257,341,16464,513]

theorem envBound46404 : H12AffineFastState.Bounded env46404 := by
  intro p hp
  have h : env46404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46403_46404 : H12AffineEnvironment.transform 12 41 env46403 = env46404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env46403 == env46404) = true)

theorem identity46404 : scanCanonicalize (H12AffineFastState.compose env46404 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound46404 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46405 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,41,16384,1,35,16400,2128,1025,0,17461,113,17,83,40,65,2128,16449,4177,2128,1136,112,37,113,16464,513]

theorem envBound46405 : H12AffineFastState.Bounded env46405 := by
  intro p hp
  have h : env46405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46404_46405 : H12AffineEnvironment.transform 7 36 env46404 = env46405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env46404 == env46405) = true)

theorem identity46405 : scanCanonicalize (H12AffineFastState.compose env46405 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound46405 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env46406 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,41,5237,1,35,5221,2128,1025,0,4160,113,17,83,40,65,2128,5172,4177,2128,1136,112,37,113,5157,513]

theorem envBound46406 : H12AffineFastState.Bounded env46406 := by
  intro p hp
  have h : env46406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46405_46406 : H12AffineEnvironment.transform 13 5237 env46405 = env46406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env46405 == env46406) = true)

theorem identity46406 : scanCanonicalize (H12AffineFastState.compose env46406 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46406 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46407 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5157,1,35,5173,2048,1025,0,4112,33,17,3,40,17,2048,5172,4097,2048,1056,32,37,33,5157,513]

theorem envBound46407 : H12AffineFastState.Bounded env46407 := by
  intro p hp
  have h : env46407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46406_46407 : H12AffineEnvironment.transform 5 16 env46406 = env46407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46406 == env46407) = true)

def env46408 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,48,41,1045,1,35,1029,2048,1025,0,32,33,17,3,40,17,2048,1028,49,2048,1056,32,37,33,1045,513]

theorem envBound46408 : H12AffineFastState.Bounded env46408 := by
  intro p hp
  have h : env46408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46407_46408 : H12AffineEnvironment.transform 11 48 env46407 = env46408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env46407 == env46408) = true)

theorem identity46408 : scanCanonicalize (H12AffineFastState.compose env46408 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound46408 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46409 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1541,48,41,1045,1,35,1029,1541,1025,0,32,33,17,3,40,17,1541,1028,49,1541,1056,32,37,33,1045,513]

theorem envBound46409 : H12AffineFastState.Bounded env46409 := by
  intro p hp
  have h : env46409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46408_46409 : H12AffineEnvironment.transform 10 1541 env46408 = env46409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env46408 == env46409) = true)

def env46410 : List Nat := [2,4,8,16,32,16,9,36,512,52,561,48,41,33,1,35,49,561,53,0,32,33,17,3,40,17,561,48,49,561,20,32,37,33,33,513]

theorem envBound46410 : H12AffineFastState.Bounded env46410 := by
  intro p hp
  have h : env46410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46409_46410 : H12AffineEnvironment.transform 9 52 env46409 = env46410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env46409 == env46410) = true)

theorem identity46410 : scanCanonicalize (H12AffineFastState.compose env46410 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound46410 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46411 : List Nat := [2,4,8,16,27,16,9,31,512,15,522,11,18,26,1,24,10,522,14,0,27,26,17,3,19,17,522,11,10,522,20,27,30,26,26,513]

theorem envBound46411 : H12AffineFastState.Bounded env46411 := by
  intro p hp
  have h : env46411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46410_46411 : H12AffineEnvironment.transform 4 27 env46410 = env46411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env46410 == env46411) = true)

def leafEnv46411 : List Nat := [2,4,8,16,27,16,9,31,512,15,522,11,18,26,1,24,10,522,14,0,27,26,17,3,21,19,1,17,522,11,10,522,20,27,30,26,5,25,26,513,1,27,0]

def active46411 : List Nat := [0,1,2,3,8]

def tree46411 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46411 : H12WitnessSearch.Good tree46411 := H12GlobalWitnessIndex.good

theorem leafIdentity46411 : H12AffineFastState.composeSystem env46411 rootObs = leafEnv46411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46411 rootObs == leafEnv46411) = true)

theorem terminalChecked46411 : H12PackedTerminal.terminalCheckFast leafEnv46411 active46411 tree46411 = true := by decide +kernel

def env46412 : List Nat := [2,4,8,16,32,16,9,36,512,53,560,48,41,32,1,35,48,560,52,0,32,33,17,3,40,17,560,49,49,560,21,32,37,33,32,513]

theorem envBound46412 : H12AffineFastState.Bounded env46412 := by
  intro p hp
  have h : env46412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46409_46412 : H12AffineEnvironment.transform 9 53 env46409 = env46412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env46409 == env46412) = true)

theorem identity46412 : scanCanonicalize (H12AffineFastState.compose env46412 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound46412 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46413 : List Nat := [2,4,8,16,32,16,9,36,17,53,33,48,41,32,1,35,48,33,52,0,32,33,17,3,40,17,33,49,49,33,21,32,37,33,32,16]

theorem envBound46413 : H12AffineFastState.Bounded env46413 := by
  intro p hp
  have h : env46413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46412_46413 : H12AffineEnvironment.transform 8 17 env46412 = env46413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env46412 == env46413) = true)

def leafEnv46413 : List Nat := [2,4,8,16,32,16,9,36,17,53,33,48,41,32,1,35,48,33,52,0,32,33,17,3,20,40,1,17,33,49,49,33,21,32,37,33,5,34,32,16,1,32,0]

def active46413 : List Nat := [0,1,2,3,4]

def tree46413 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46413 : H12WitnessSearch.Good tree46413 := H12GlobalWitnessIndex.good

theorem leafIdentity46413 : H12AffineFastState.composeSystem env46413 rootObs = leafEnv46413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46413 rootObs == leafEnv46413) = true)

theorem terminalChecked46413 : H12PackedTerminal.terminalCheckFast leafEnv46413 active46413 tree46413 = true := by decide +kernel

def env46414 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,49,41,1044,1,35,1028,2048,1025,0,33,33,17,3,40,17,2048,1029,48,2048,1056,32,37,33,1044,513]

theorem envBound46414 : H12AffineFastState.Bounded env46414 := by
  intro p hp
  have h : env46414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46407_46414 : H12AffineEnvironment.transform 11 49 env46407 = env46414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env46407 == env46414) = true)

theorem identity46414 : scanCanonicalize (H12AffineFastState.compose env46414 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound46414 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46415 : List Nat := [2,4,8,16,32,16,9,36,512,1024,560,49,41,1044,1,35,1028,560,1025,0,33,33,17,3,40,17,560,1029,48,560,1056,32,37,33,1044,513]

theorem envBound46415 : H12AffineFastState.Bounded env46415 := by
  intro p hp
  have h : env46415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46414_46415 : H12AffineEnvironment.transform 10 560 env46414 = env46415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env46414 == env46415) = true)

def env46416 : List Nat := [2,4,8,16,32,16,9,36,512,52,560,49,41,32,1,35,48,560,53,0,33,33,17,3,40,17,560,49,48,560,20,32,37,33,32,513]

theorem envBound46416 : H12AffineFastState.Bounded env46416 := by
  intro p hp
  have h : env46416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46415_46416 : H12AffineEnvironment.transform 9 52 env46415 = env46416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env46415 == env46416) = true)

theorem identity46416 : scanCanonicalize (H12AffineFastState.compose env46416 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound46416 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46417 : List Nat := [2,4,8,16,26,16,9,30,512,14,522,11,19,26,1,25,10,522,15,0,27,27,17,3,18,17,522,11,10,522,20,26,31,27,26,513]

theorem envBound46417 : H12AffineFastState.Bounded env46417 := by
  intro p hp
  have h : env46417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46416_46417 : H12AffineEnvironment.transform 4 26 env46416 = env46417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env46416 == env46417) = true)

def leafEnv46417 : List Nat := [2,4,8,16,26,16,9,30,512,14,522,11,19,26,1,25,10,522,15,0,27,27,17,3,21,18,1,17,522,11,10,522,20,26,31,27,5,24,26,513,1,27,0]

def active46417 : List Nat := [0,1,2,3,8]

def tree46417 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46417 : H12WitnessSearch.Good tree46417 := H12GlobalWitnessIndex.good

theorem leafIdentity46417 : H12AffineFastState.composeSystem env46417 rootObs = leafEnv46417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46417 rootObs == leafEnv46417) = true)

theorem terminalChecked46417 : H12PackedTerminal.terminalCheckFast leafEnv46417 active46417 tree46417 = true := by decide +kernel

def env46418 : List Nat := [2,4,8,16,32,16,9,36,512,53,560,49,41,33,1,35,49,560,52,0,33,33,17,3,40,17,560,48,48,560,21,32,37,33,33,513]

theorem envBound46418 : H12AffineFastState.Bounded env46418 := by
  intro p hp
  have h : env46418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46415_46418 : H12AffineEnvironment.transform 9 53 env46415 = env46418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env46415 == env46418) = true)

theorem identity46418 : scanCanonicalize (H12AffineFastState.compose env46418 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound46418 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46419 : List Nat := [2,4,8,16,32,16,9,36,16,53,32,49,41,33,1,35,49,32,52,0,33,33,17,3,40,17,32,48,48,32,21,32,37,33,33,17]

theorem envBound46419 : H12AffineFastState.Bounded env46419 := by
  intro p hp
  have h : env46419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46418_46419 : H12AffineEnvironment.transform 8 16 env46418 = env46419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env46418 == env46419) = true)

def leafEnv46419 : List Nat := [2,4,8,16,32,16,9,36,16,53,32,49,41,33,1,35,49,32,52,0,33,33,17,3,20,40,1,17,32,48,48,32,21,32,37,33,5,34,33,17,1,33,0]

def active46419 : List Nat := [0,1,2,3,4]

def tree46419 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46419 : H12WitnessSearch.Good tree46419 := H12GlobalWitnessIndex.good

theorem leafIdentity46419 : H12AffineFastState.composeSystem env46419 rootObs = leafEnv46419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46419 rootObs == leafEnv46419) = true)

theorem terminalChecked46419 : H12PackedTerminal.terminalCheckFast leafEnv46419 active46419 tree46419 = true := by decide +kernel

def env46420 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,65536,16400,10588,1025,8232,91198,4194304,17,374,8193,65,4261891,16740,78206,2420,75102,4194305,257,340,16464,513]

theorem envBound46420 : H12AffineFastState.Bounded env46420 := by
  intro p hp
  have h : env46420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46400_46420 : H12AffineEnvironment.transform 14 8233 env46400 = env46420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env46400 == env46420) = true)

theorem identity46420 : scanCanonicalize (H12AffineFastState.compose env46420 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(21+1) ^^^ 8201) := by decide +kernel

theorem selectedBound46420 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env46421 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,65536,16400,10588,1025,8232,91198,8201,17,374,8193,65,75786,16740,78206,2420,75102,8200,257,340,16464,513]

theorem envBound46421 : H12AffineFastState.Bounded env46421 := by
  intro p hp
  have h : env46421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46420_46421 : H12AffineEnvironment.transform 21 8201 env46420 = env46421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8201 env46420 == env46421) = true)

theorem identity46421 : scanCanonicalize (H12AffineFastState.compose env46421 (packedSelected [2,4,6,7,9,27] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound46421 : packedSelected [2,4,6,7,9,27] rootPS < 2^1333 := by decide +kernel

def env46422 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,343,16400,10588,1025,8232,25961,8201,17,374,8193,65,10589,16740,12329,2420,9225,8200,257,340,16464,513]

theorem envBound46422 : H12AffineFastState.Bounded env46422 := by
  intro p hp
  have h : env46422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46421_46422 : H12AffineEnvironment.transform 15 343 env46421 = env46422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env46421 == env46422) = true)

theorem identity46422 : scanCanonicalize (H12AffineFastState.compose env46422 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound46422 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env46423 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,372,343,16400,2049,1025,373,17460,340,17,374,348,65,2048,16740,4468,2420,1364,341,257,340,16464,513]

theorem envBound46423 : H12AffineFastState.Bounded env46423 := by
  intro p hp
  have h : env46423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46422_46423 : H12AffineEnvironment.transform 12 349 env46422 = env46423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env46422 == env46423) = true)

theorem identity46423 : scanCanonicalize (H12AffineFastState.compose env46423 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46423 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46424 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,292,263,16400,2049,1025,293,17460,260,17,294,268,17,2048,16692,4388,2340,1284,261,257,260,16384,513]

theorem envBound46424 : H12AffineFastState.Bounded env46424 := by
  intro p hp
  have h : env46424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46423_46424 : H12AffineEnvironment.transform 5 16 env46423 = env46424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46423 == env46424) = true)

theorem identity46424 : scanCanonicalize (H12AffineFastState.compose env46424 (packedSelected [2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound46424 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env46425 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,16384,1,34,16400,2049,1025,0,17460,33,17,3,41,17,2048,16401,4097,2049,1057,32,36,33,16384,513]

theorem envBound46425 : H12AffineFastState.Bounded env46425 := by
  intro p hp
  have h : env46425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46424_46425 : H12AffineEnvironment.transform 7 37 env46424 = env46425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env46424 == env46425) = true)

theorem identity46425 : scanCanonicalize (H12AffineFastState.compose env46425 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound46425 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46426 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5157,1,34,5173,2049,1025,0,4113,33,17,3,41,17,2048,5172,4097,2049,1057,32,36,33,5157,513]

theorem envBound46426 : H12AffineFastState.Bounded env46426 := by
  intro p hp
  have h : env46426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46425_46426 : H12AffineEnvironment.transform 13 5157 env46425 = env46426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env46425 == env46426) = true)

def env46427 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,40,1045,1,34,1029,2049,1025,0,33,33,17,3,41,17,2048,1028,49,2049,1057,32,36,33,1045,513]

theorem envBound46427 : H12AffineFastState.Bounded env46427 := by
  intro p hp
  have h : env46427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46426_46427 : H12AffineEnvironment.transform 11 48 env46426 = env46427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env46426 == env46427) = true)

theorem identity46427 : scanCanonicalize (H12AffineFastState.compose env46427 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46427 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46428 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,17,9,1045,1,3,1029,2049,1025,0,0,0,17,3,8,17,2048,1028,16,2049,1024,1,5,0,1045,513]

theorem envBound46428 : H12AffineFastState.Bounded env46428 := by
  intro p hp
  have h : env46428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46427_46428 : H12AffineEnvironment.transform 4 1 env46427 = env46428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46427 == env46428) = true)

def env46429 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,17,9,1,1,3,17,2049,21,0,0,0,17,3,8,17,2048,16,16,2049,20,1,5,0,1,513]

theorem envBound46429 : H12AffineFastState.Bounded env46429 := by
  intro p hp
  have h : env46429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46428_46429 : H12AffineEnvironment.transform 9 20 env46428 = env46429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env46428 == env46429) = true)

theorem identity46429 : scanCanonicalize (H12AffineFastState.compose env46429 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound46429 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46430 : List Nat := [2,4,8,16,1,16,9,4,512,20,0,17,9,1,1,3,17,1,21,0,0,0,17,3,8,17,0,16,16,1,20,1,5,0,1,513]

theorem envBound46430 : H12AffineFastState.Bounded env46430 := by
  intro p hp
  have h : env46430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46429_46430 : H12AffineEnvironment.transform 10 0 env46429 = env46430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env46429 == env46430) = true)

def leafEnv46430 : List Nat := [2,4,8,16,1,16,9,4,512,20,0,17,9,1,1,3,17,1,21,0,0,0,17,3,21,8,1,17,0,16,16,1,20,1,5,0,5,2,1,513,1,0,0]

def active46430 : List Nat := [0,1,2,3,8]

def tree46430 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46430 : H12WitnessSearch.Good tree46430 := H12GlobalWitnessIndex.good

theorem leafIdentity46430 : H12AffineFastState.composeSystem env46430 rootObs = leafEnv46430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46430 rootObs == leafEnv46430) = true)

theorem terminalChecked46430 : H12PackedTerminal.terminalCheckFast leafEnv46430 active46430 tree46430 = true := by decide +kernel

def env46431 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,17,9,0,1,3,16,2049,20,0,0,0,17,3,8,17,2048,17,16,2049,21,1,5,0,0,513]

theorem envBound46431 : H12AffineFastState.Bounded env46431 := by
  intro p hp
  have h : env46431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46428_46431 : H12AffineEnvironment.transform 9 21 env46428 = env46431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env46428 == env46431) = true)

theorem identity46431 : scanCanonicalize (H12AffineFastState.compose env46431 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound46431 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46432 : List Nat := [2,4,8,16,1,16,9,4,512,21,523,17,9,0,1,3,16,522,20,0,0,0,17,3,8,17,523,17,16,522,21,1,5,0,0,513]

theorem envBound46432 : H12AffineFastState.Bounded env46432 := by
  intro p hp
  have h : env46432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46431_46432 : H12AffineEnvironment.transform 10 523 env46431 = env46432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env46431 == env46432) = true)

def leafEnv46432 : List Nat := [2,4,8,16,1,16,9,4,512,21,523,17,9,0,1,3,16,522,20,0,0,0,17,3,20,8,1,17,523,17,16,522,21,1,5,0,5,2,0,513,1,0,0]

def active46432 : List Nat := [0,1,2,3,8]

def tree46432 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46432 : H12WitnessSearch.Good tree46432 := H12GlobalWitnessIndex.good

theorem leafIdentity46432 : H12AffineFastState.composeSystem env46432 rootObs = leafEnv46432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46432 rootObs == leafEnv46432) = true)

theorem terminalChecked46432 : H12PackedTerminal.terminalCheckFast leafEnv46432 active46432 tree46432 = true := by decide +kernel

def env46433 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,40,1044,1,34,1028,2049,1025,0,32,33,17,3,41,17,2048,1029,48,2049,1057,32,36,33,1044,513]

theorem envBound46433 : H12AffineFastState.Bounded env46433 := by
  intro p hp
  have h : env46433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46426_46433 : H12AffineEnvironment.transform 11 49 env46426 = env46433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env46426 == env46433) = true)

theorem identity46433 : scanCanonicalize (H12AffineFastState.compose env46433 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound46433 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46434 : List Nat := [2,4,8,16,32,16,9,37,512,20,2048,49,40,0,1,34,16,2049,21,0,32,33,17,3,41,17,2048,17,48,2049,53,32,36,33,0,513]

theorem envBound46434 : H12AffineFastState.Bounded env46434 := by
  intro p hp
  have h : env46434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46433_46434 : H12AffineEnvironment.transform 9 20 env46433 = env46434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env46433 == env46434) = true)

def env46435 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,17,8,0,1,2,16,2049,21,0,0,1,17,3,9,17,2048,17,16,2049,21,0,4,1,0,513]

theorem envBound46435 : H12AffineFastState.Bounded env46435 := by
  intro p hp
  have h : env46435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46434_46435 : H12AffineEnvironment.transform 4 0 env46434 = env46435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env46434 == env46435) = true)

theorem identity46435 : scanCanonicalize (H12AffineFastState.compose env46435 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound46435 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46436 : List Nat := [2,4,8,16,0,16,9,5,512,20,523,17,8,0,1,2,16,522,21,0,0,1,17,3,9,17,523,17,16,522,21,0,4,1,0,513]

theorem envBound46436 : H12AffineFastState.Bounded env46436 := by
  intro p hp
  have h : env46436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46435_46436 : H12AffineEnvironment.transform 10 523 env46435 = env46436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env46435 == env46436) = true)

def leafEnv46436 : List Nat := [2,4,8,16,0,16,9,5,512,20,523,17,8,0,1,2,16,522,21,0,0,1,17,3,20,9,1,17,523,17,16,522,21,0,4,1,5,3,0,513,1,0,0]

def active46436 : List Nat := [0,1,2,3,8]

def tree46436 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46436 : H12WitnessSearch.Good tree46436 := H12GlobalWitnessIndex.good

theorem leafIdentity46436 : H12AffineFastState.composeSystem env46436 rootObs = leafEnv46436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46436 rootObs == leafEnv46436) = true)

theorem terminalChecked46436 : H12PackedTerminal.terminalCheckFast leafEnv46436 active46436 tree46436 = true := by decide +kernel

def env46437 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,16,9,0,1,3,16,2049,21,0,1,0,17,3,8,17,2048,17,17,2049,20,1,5,0,0,513]

theorem envBound46437 : H12AffineFastState.Bounded env46437 := by
  intro p hp
  have h : env46437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46434_46437 : H12AffineEnvironment.transform 4 1 env46434 = env46437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46434 == env46437) = true)

theorem identity46437 : scanCanonicalize (H12AffineFastState.compose env46437 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound46437 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46438 : List Nat := [2,4,8,16,1,16,9,4,512,20,1,16,9,0,1,3,16,0,21,0,1,0,17,3,8,17,1,17,17,0,20,1,5,0,0,513]

theorem envBound46438 : H12AffineFastState.Bounded env46438 := by
  intro p hp
  have h : env46438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46437_46438 : H12AffineEnvironment.transform 10 1 env46437 = env46438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env46437 == env46438) = true)

def leafEnv46438 : List Nat := [2,4,8,16,1,16,9,4,512,20,1,16,9,0,1,3,16,0,21,0,1,0,17,3,21,8,1,17,1,17,17,0,20,1,5,0,5,2,0,513,1,1,0]

def active46438 : List Nat := [0,1,2,3,8]

def tree46438 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46438 : H12WitnessSearch.Good tree46438 := H12GlobalWitnessIndex.good

theorem leafIdentity46438 : H12AffineFastState.composeSystem env46438 rootObs = leafEnv46438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46438 rootObs == leafEnv46438) = true)

theorem terminalChecked46438 : H12PackedTerminal.terminalCheckFast leafEnv46438 active46438 tree46438 = true := by decide +kernel

def env46439 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,4194304,16,41310,8193,65,4302891,2172251,2118977,2420,75102,6407191,257,2188650,2196551,513]

theorem envBound46439 : H12AffineFastState.Bounded env46439 := by
  intro p hp
  have h : env46439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46398_46439 : H12AffineEnvironment.transform 16 16401 env46398 = env46439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env46398 == env46439) = true)

theorem identity46439 : scanCanonicalize (H12AffineFastState.compose env46439 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound46439 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env46440 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16401,35189,1025,32769,2097152,4194304,16,41310,8193,65,4229152,2098512,2118977,2420,1365,6349852,257,2114913,2139212,513]

theorem envBound46440 : H12AffineFastState.Bounded env46440 := by
  intro p hp
  have h : env46440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46439_46440 : H12AffineEnvironment.transform 15 8203 env46439 = env46440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env46439 == env46440) = true)

theorem identity46440 : scanCanonicalize (H12AffineFastState.compose env46440 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound46440 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46441 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16401,35189,1025,32769,2097152,32,16,41310,8193,65,34816,2098512,2118977,2420,1365,2155580,257,2114913,2139212,513]

theorem envBound46441 : H12AffineFastState.Bounded env46441 := by
  intro p hp
  have h : env46441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46440_46441 : H12AffineEnvironment.transform 21 32 env46440 = env46441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env46440 == env46441) = true)

theorem identity46441 : scanCanonicalize (H12AffineFastState.compose env46441 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound46441 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env46442 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16401,10281,1025,8541,2097152,32,16,2,8193,65,10588,2098512,2118977,2420,1365,2114912,257,2114913,2098448,513]

theorem envBound46442 : H12AffineFastState.Bounded env46442 := by
  intro p hp
  have h : env46442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46441_46442 : H12AffineEnvironment.transform 14 8540 env46441 = env46442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env46441 == env46442) = true)

theorem identity46442 : scanCanonicalize (H12AffineFastState.compose env46442 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 25676) := by decide +kernel

theorem selectedBound46442 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46443 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16401,10281,1025,8541,25676,32,16,2,8193,65,10588,24860,12557,2420,1365,8492,257,8493,24924,513]

theorem envBound46443 : H12AffineFastState.Bounded env46443 := by
  intro p hp
  have h : env46443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46442_46443 : H12AffineEnvironment.transform 20 25676 env46442 = env46443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25676 env46442 == env46443) = true)

theorem identity46443 : scanCanonicalize (H12AffineFastState.compose env46443 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound46443 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env46444 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8203,5392,10281,1025,8541,12621,32,16,2,8193,65,10588,13341,12557,2420,1365,8492,257,8493,13405,513]

theorem envBound46444 : H12AffineFastState.Bounded env46444 := by
  intro p hp
  have h : env46444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46443_46444 : H12AffineEnvironment.transform 13 5377 env46443 = env46444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env46443 == env46444) = true)

theorem identity46444 : scanCanonicalize (H12AffineFastState.compose env46444 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound46444 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env46445 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,80,263,5392,2341,1025,81,4161,32,16,2,269,65,2128,5393,4097,2420,1365,32,257,33,5457,513]

theorem envBound46445 : H12AffineFastState.Bounded env46445 := by
  intro p hp
  have h : env46445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46444_46445 : H12AffineEnvironment.transform 12 268 env46444 = env46445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env46444 == env46445) = true)

theorem identity46445 : scanCanonicalize (H12AffineFastState.compose env46445 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound46445 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env46446 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,268,4453,80,263,4468,2341,101,81,4161,32,16,2,269,65,2128,4469,4097,2420,305,32,257,33,4405,513]

theorem envBound46446 : H12AffineFastState.Bounded env46446 := by
  intro p hp
  have h : env46446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46445_46446 : H12AffineEnvironment.transform 9 100 env46445 = env46446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env46445 == env46446) = true)

theorem identity46446 : scanCanonicalize (H12AffineFastState.compose env46446 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound46446 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env46447 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,2113,268,2340,80,263,2357,2341,101,81,2048,32,16,2,269,65,2128,2356,2112,2420,305,32,257,33,2420,513]

theorem envBound46447 : H12AffineFastState.Bounded env46447 := by
  intro p hp
  have h : env46447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46446_46447 : H12AffineEnvironment.transform 11 2113 env46446 = env46447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env46446 == env46447) = true)

theorem identity46447 : scanCanonicalize (H12AffineFastState.compose env46447 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46447 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env46448 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,2064,268,2340,1,263,2357,2341,52,0,2048,32,16,2,269,16,2049,2356,2065,2341,305,32,257,33,2341,513]

theorem envBound46448 : H12AffineFastState.Bounded env46448 := by
  intro p hp
  have h : env46448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46447_46448 : H12AffineEnvironment.transform 5 17 env46447 = env46448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46447 == env46448) = true)

theorem identity46448 : scanCanonicalize (H12AffineFastState.compose env46448 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound46448 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46449 : List Nat := [2,4,8,16,32,17,9,256,512,53,292,308,268,0,1,263,17,1,52,0,292,32,16,2,269,16,293,16,309,1,305,32,257,33,1,513]

theorem envBound46449 : H12AffineFastState.Bounded env46449 := by
  intro p hp
  have h : env46449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46448_46449 : H12AffineEnvironment.transform 10 292 env46448 = env46449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env46448 == env46449) = true)

def env46450 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507601,9356288,25265168,23160257,525568,27902125,27337993,25733063]

theorem envBound46450 : H12AffineFastState.Bounded env46450 := by
  intro p hp
  have h : env46450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46136_46450 : H12AffineEnvironment.transform 26 30393345 env46136 = env46450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env46136 == env46450) = true)

def env46451 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830976,25265168,23160257,256,27378861,27337993,25207751]

theorem envBound46451 : H12AffineFastState.Bounded env46451 := by
  intro p hp
  have h : env46451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46450_46451 : H12AffineEnvironment.transform 18 1024 env46450 = env46451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env46450 == env46451) = true)

theorem identity46451 : scanCanonicalize (H12AffineFastState.compose env46451 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2493493) := by decide +kernel

theorem selectedBound46451 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env46452 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2493493,16777216,8328,65,23186484,18973837,416100,2149429,19367973,23160257,256,17287320,17246524,19312626]

theorem envBound46452 : H12AffineFastState.Bounded env46452 := by
  intro p hp
  have h : env46452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46451_46452 : H12AffineEnvironment.transform 22 2493493 env46451 = env46452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2493493 env46451 == env46452) = true)

def env46453 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2493493,499128,8328,65,6705548,2496821,416100,2149429,2102685,6748281,256,21792,46212,2175562]

theorem envBound46453 : H12AffineFastState.Bounded env46453 := by
  intro p hp
  have h : env46453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46452_46453 : H12AffineEnvironment.transform 23 499128 env46452 = env46453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 499128 env46452 == env46453) = true)

def env46454 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180272,2493493,499128,8328,65,2396604,2496821,416100,2149429,2102685,2373705,256,21792,46212,2175562]

theorem envBound46454 : H12AffineFastState.Bounded env46454 := by
  intro p hp
  have h : env46454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46453_46454 : H12AffineEnvironment.transform 21 180272 env46453 = env46454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180272 env46453 == env46454) = true)

def env46455 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180272,400501,499128,8328,65,295420,395637,416100,56437,1501,272393,256,21792,46212,74250]

theorem envBound46455 : H12AffineFastState.Bounded env46455 := by
  intro p hp
  have h : env46455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46454_46455 : H12AffineEnvironment.transform 20 4160 env46454 = env46455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env46454 == env46455) = true)

theorem identity46455 : scanCanonicalize (H12AffineFastState.compose env46455 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138341) := by decide +kernel

theorem selectedBound46455 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46456 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138341,1024,32769,4160,180272,16,98781,8328,65,171417,5392,17665,56437,1501,144492,256,21792,46212,74250]

theorem envBound46456 : H12AffineFastState.Bounded env46456 := by
  intro p hp
  have h : env46456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46455_46456 : H12AffineEnvironment.transform 17 138341 env46455 = env46456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138341 env46455 == env46456) = true)

def env46457 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138341,1024,32769,4160,180272,16,98645,8192,65,171281,5392,17665,56437,1365,144492,256,21792,46092,74250]

theorem envBound46457 : H12AffineFastState.Bounded env46457 := by
  intro p hp
  have h : env46457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46456_46457 : H12AffineEnvironment.transform 6 8 env46456 = env46457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46456 == env46457) = true)

theorem identity46457 : scanCanonicalize (H12AffineFastState.compose env46457 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound46457 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46458 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,35189,1024,32769,4160,21792,16,98645,8192,65,2049,5392,17665,56437,1365,41340,256,21792,46092,74250]

theorem envBound46458 : H12AffineFastState.Bounded env46458 := by
  intro p hp
  have h : env46458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46457_46458 : H12AffineEnvironment.transform 16 38160 env46457 = env46458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env46457 == env46458) = true)

theorem identity46458 : scanCanonicalize (H12AffineFastState.compose env46458 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound46458 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env46459 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,38160,35189,1024,32769,4160,33,16,98645,8192,65,2049,5392,4096,35188,1365,41340,256,33,46092,74250]

theorem envBound46459 : H12AffineFastState.Bounded env46459 := by
  intro p hp
  have h : env46459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46458_46459 : H12AffineEnvironment.transform 13 5377 env46458 = env46459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env46458 == env46459) = true)

theorem identity46459 : scanCanonicalize (H12AffineFastState.compose env46459 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 41051) := by decide +kernel

theorem selectedBound46459 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env46460 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,41051,38160,35189,1024,32769,4160,33,16,8462,8192,65,2049,5392,4096,35188,1365,41340,256,33,46092,33361]

theorem envBound46460 : H12AffineFastState.Bounded env46460 := by
  intro p hp
  have h : env46460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46459_46460 : H12AffineEnvironment.transform 15 41051 env46459 = env46460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41051 env46459 == env46460) = true)

theorem identity46460 : scanCanonicalize (H12AffineFastState.compose env46460 (packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound46460 : packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS < 2^1333 := by decide +kernel

def env46461 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5377,32768,32803,38160,35189,1024,32769,4160,33,16,374,120,65,2049,5392,4096,35188,1365,33028,256,33,38004,33361]

theorem envBound46461 : H12AffineFastState.Bounded env46461 := by
  intro p hp
  have h : env46461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46460_46461 : H12AffineEnvironment.transform 12 120 env46460 = env46461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env46460 == env46461) = true)

theorem identity46461 : scanCanonicalize (H12AffineFastState.compose env46461 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound46461 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env46462 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5377,0,35,5392,2421,1024,1,4160,33,16,374,120,65,2049,5392,4096,2420,1365,260,256,33,5236,593]

theorem envBound46462 : H12AffineFastState.Bounded env46462 := by
  intro p hp
  have h : env46462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46461_46462 : H12AffineEnvironment.transform 14 0 env46461 = env46462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env46461 == env46462) = true)

theorem identity46462 : scanCanonicalize (H12AffineFastState.compose env46462 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46462 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env46463 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,41,5377,0,35,5392,2340,1024,1,4113,33,16,295,41,16,2049,5392,4096,2341,1284,260,256,33,5157,512]

theorem envBound46463 : H12AffineFastState.Bounded env46463 := by
  intro p hp
  have h : env46463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46462_46463 : H12AffineEnvironment.transform 5 17 env46462 = env46463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46462 == env46463) = true)

theorem identity46463 : scanCanonicalize (H12AffineFastState.compose env46463 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound46463 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46464 : List Nat := [2,4,8,16,32,17,8,256,32,1024,2048,4096,41,5377,0,35,5392,2340,1024,1,4113,33,16,295,41,16,2049,5392,4096,2341,1284,260,256,33,5157,32]

theorem envBound46464 : H12AffineFastState.Bounded env46464 := by
  intro p hp
  have h : env46464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46463_46464 : H12AffineEnvironment.transform 8 32 env46463 = env46464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env46463 == env46464) = true)

theorem identity46464 : scanCanonicalize (H12AffineFastState.compose env46464 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound46464 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46465 : List Nat := [2,4,8,16,0,17,8,256,0,1024,2048,4096,9,5377,0,3,5392,2308,1024,1,4113,1,16,263,9,16,2049,5392,4096,2309,1284,260,256,1,5125,0]

theorem envBound46465 : H12AffineFastState.Bounded env46465 := by
  intro p hp
  have h : env46465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46464_46465 : H12AffineEnvironment.transform 4 0 env46464 = env46465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env46464 == env46465) = true)

theorem identity46465 : scanCanonicalize (H12AffineFastState.compose env46465 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound46465 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46466 : List Nat := [2,4,8,16,0,17,8,256,0,1024,2048,1044,9,277,0,3,260,2308,1024,1,1029,1,16,263,9,16,2049,260,1044,2309,1284,260,256,1,17,0]

theorem envBound46466 : H12AffineFastState.Bounded env46466 := by
  intro p hp
  have h : env46466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46465_46466 : H12AffineEnvironment.transform 11 1044 env46465 = env46466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env46465 == env46466) = true)

theorem identity46466 : scanCanonicalize (H12AffineFastState.compose env46466 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound46466 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env46467 : List Nat := [2,4,8,16,0,17,8,4,0,1024,2048,1044,9,17,0,3,0,2048,1024,1,1029,1,16,3,9,16,2049,0,1044,2049,1024,0,4,1,17,0]

theorem envBound46467 : H12AffineFastState.Bounded env46467 := by
  intro p hp
  have h : env46467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46466_46467 : H12AffineEnvironment.transform 7 4 env46466 = env46467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env46466 == env46467) = true)

theorem identity46467 : scanCanonicalize (H12AffineFastState.compose env46467 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound46467 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env46468 : List Nat := [2,4,8,16,0,17,8,4,0,20,2048,0,9,17,0,3,0,2048,20,1,17,1,16,3,9,16,2049,0,0,2049,20,0,4,1,17,0]

theorem envBound46468 : H12AffineFastState.Bounded env46468 := by
  intro p hp
  have h : env46468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46467_46468 : H12AffineEnvironment.transform 9 20 env46467 = env46468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env46467 == env46468) = true)

theorem identity46468 : scanCanonicalize (H12AffineFastState.compose env46468 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound46468 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46469 : List Nat := [2,4,8,1,0,0,8,4,0,5,2048,0,9,0,0,3,0,2048,5,1,0,1,1,3,9,1,2049,0,0,2049,5,0,4,1,0,0]

theorem envBound46469 : H12AffineFastState.Bounded env46469 := by
  intro p hp
  have h : env46469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46468_46469 : H12AffineEnvironment.transform 3 1 env46468 = env46469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env46468 == env46469) = true)

theorem identity46469 : scanCanonicalize (H12AffineFastState.compose env46469 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound46469 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46470 : List Nat := [2,0,8,1,0,0,8,0,0,1,2048,0,9,0,0,3,0,2048,1,1,0,1,1,3,9,1,2049,0,0,2049,1,0,0,1,0,0]

theorem envBound46470 : H12AffineFastState.Bounded env46470 := by
  intro p hp
  have h : env46470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46469_46470 : H12AffineEnvironment.transform 1 0 env46469 = env46470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env46469 == env46470) = true)

def env46471 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138341,1024,32769,4160,180272,16,98644,8193,65,171280,5392,17665,56437,1364,144492,256,21792,46093,74250]

theorem envBound46471 : H12AffineFastState.Bounded env46471 := by
  intro p hp
  have h : env46471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46456_46471 : H12AffineEnvironment.transform 6 9 env46456 = env46471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46456 == env46471) = true)

theorem identity46471 : scanCanonicalize (H12AffineFastState.compose env46471 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound46471 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46472 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13388,10281,1024,32769,4160,62588,16,98644,8193,65,43356,5392,17665,56437,1364,32,256,21792,46093,74250]

theorem envBound46472 : H12AffineFastState.Bounded env46472 := by
  intro p hp
  have h : env46472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46471_46472 : H12AffineEnvironment.transform 16 13388 env46471 = env46472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env46471 == env46472) = true)

theorem identity46472 : scanCanonicalize (H12AffineFastState.compose env46472 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound46472 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env46473 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,13388,10281,1024,29788,4160,33,16,95497,8193,65,23809,5392,17665,10280,1364,32,256,21792,16464,74250]

theorem envBound46473 : H12AffineFastState.Bounded env46473 := by
  intro p hp
  have h : env46473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46472_46473 : H12AffineEnvironment.transform 14 29789 env46472 = env46473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env46472 == env46473) = true)

theorem identity46473 : scanCanonicalize (H12AffineFastState.compose env46473 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound46473 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env46474 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,21590,13388,10281,1024,29788,4160,33,16,8543,8193,65,23809,5392,17665,10280,1364,32,256,21792,16464,30300]

theorem envBound46474 : H12AffineFastState.Bounded env46474 := by
  intro p hp
  have h : env46474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46473_46474 : H12AffineEnvironment.transform 15 21590 env46473 = env46474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env46473 == env46474) = true)

theorem identity46474 : scanCanonicalize (H12AffineFastState.compose env46474 (packedSelected [0,1,2,5,6,7,8,11,16,18,24] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46474 : packedSelected [0,1,2,5,6,7,8,11,16,18,24] rootPS < 2^1333 := by decide +kernel

def env46475 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29708,21511,13341,10281,1024,29709,4113,33,16,8462,8193,16,23809,5392,17665,10280,1285,32,256,21792,16385,30221]

theorem envBound46475 : H12AffineFastState.Bounded env46475 := by
  intro p hp
  have h : env46475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46474_46475 : H12AffineEnvironment.transform 5 17 env46474 = env46475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46474 == env46475) = true)

def env46476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180272,400500,499128,8328,65,295421,395636,416100,56436,1500,272392,256,21792,46212,74251]

theorem envBound46476 : H12AffineFastState.Bounded env46476 := by
  intro p hp
  have h : env46476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46454_46476 : H12AffineEnvironment.transform 20 4161 env46454 = env46476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env46454 == env46476) = true)

theorem identity46476 : scanCanonicalize (H12AffineFastState.compose env46476 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound46476 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,4161,144612,400500,485740,8328,65,292137,395636,416100,10400,1500,272392,256,21792,16464,74251]

theorem envBound46477 : H12AffineFastState.Bounded env46477 := by
  intro p hp
  have h : env46477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46476_46477 : H12AffineEnvironment.transform 14 29908 env46476 = env46477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env46476 == env46477) = true)

def env46478 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,4161,144492,400500,485740,8192,65,292137,395636,416100,10280,1364,272392,256,21792,16464,74251]

theorem envBound46478 : H12AffineFastState.Bounded env46478 := by
  intro p hp
  have h : env46478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46477_46478 : H12AffineEnvironment.transform 6 8 env46477 = env46478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46477 == env46478) = true)

theorem identity46478 : scanCanonicalize (H12AffineFastState.compose env46478 (packedSelected [3,10,11,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 215090) := by decide +kernel

theorem selectedBound46478 : packedSelected [3,10,11,24,26,32] rootPS < 2^1333 := by decide +kernel

def env46479 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,215090,1024,29789,4161,144492,87110,8542,8192,65,212251,82246,69974,10280,1364,221242,256,21792,16464,74251]

theorem envBound46479 : H12AffineFastState.Bounded env46479 := by
  intro p hp
  have h : env46479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46478_46479 : H12AffineEnvironment.transform 17 215090 env46478 = env46479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 215090 env46478 == env46479) = true)

theorem identity46479 : scanCanonicalize (H12AffineFastState.compose env46479 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound46479 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env46480 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,16400,67618,1024,29789,4161,29820,87110,8542,8192,65,97547,82246,69974,10280,1364,73770,256,21792,16464,74251]

theorem envBound46480 : H12AffineFastState.Bounded env46480 := by
  intro p hp
  have h : env46480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46479_46480 : H12AffineEnvironment.transform 16 16400 env46479 = env46480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env46479 == env46480) = true)

theorem identity46480 : scanCanonicalize (H12AffineFastState.compose env46480 (packedSelected [0,1,4,7,8,9,10,11,15,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound46480 : packedSelected [0,1,4,7,8,9,10,11,15,17,20] rootPS < 2^1333 := by decide +kernel

def env46481 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8461,65536,5441,67618,1024,8460,4161,8493,65815,8542,8192,65,75866,70679,69974,10280,1364,73770,256,113,5377,74251]

theorem envBound46481 : H12AffineFastState.Bounded env46481 := by
  intro p hp
  have h : env46481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46480_46481 : H12AffineEnvironment.transform 13 5457 env46480 = env46481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env46480 == env46481) = true)

theorem identity46481 : scanCanonicalize (H12AffineFastState.compose env46481 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound46481 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env46482 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,5237,8233,65536,5221,67618,1024,8232,4161,8201,65587,8314,8192,65,75866,70679,69746,10280,1136,73770,36,113,5157,74251]

theorem envBound46482 : H12AffineFastState.Bounded env46482 := by
  intro p hp
  have h : env46482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46481_46482 : H12AffineEnvironment.transform 7 36 env46481 = env46482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env46481 == env46482) = true)

theorem identity46482 : scanCanonicalize (H12AffineFastState.compose env46482 (packedSelected [1,2,4,6,8,9,10,11,12,17] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound46482 : packedSelected [1,2,4,6,8,9,10,11,12,17] rootPS < 2^1333 := by decide +kernel

def env46483 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,5237,80,65536,5221,67618,1024,81,4161,112,65587,3,121,65,67619,70679,69746,2129,1136,65619,36,113,5157,66162]

theorem envBound46483 : H12AffineFastState.Bounded env46483 := by
  intro p hp
  have h : env46483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46482_46483 : H12AffineEnvironment.transform 12 121 env46482 = env46483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env46482 == env46483) = true)

theorem identity46483 : scanCanonicalize (H12AffineFastState.compose env46483 (packedSelected [0,2,4,6,7,9,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound46483 : packedSelected [0,2,4,6,7,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env46484 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,5237,80,1094,5221,3172,1024,81,4161,112,1141,3,121,65,3173,4177,5172,2129,1136,1045,36,113,5157,1588]

theorem envBound46484 : H12AffineFastState.Bounded env46484 := by
  intro p hp
  have h : env46484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46483_46484 : H12AffineEnvironment.transform 15 1094 env46483 = env46484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env46483 == env46484) = true)

theorem identity46484 : scanCanonicalize (H12AffineFastState.compose env46484 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound46484 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env46485 : List Nat := [2,4,8,16,32,64,8,36,512,101,2048,4096,121,4112,80,35,4096,2049,101,81,4161,112,16,3,121,65,2048,4177,4177,2129,21,112,36,113,4160,593]

theorem envBound46485 : H12AffineFastState.Bounded env46485 := by
  intro p hp
  have h : env46485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46484_46485 : H12AffineEnvironment.transform 9 101 env46484 = env46485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env46484 == env46485) = true)

theorem identity46485 : scanCanonicalize (H12AffineFastState.compose env46485 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46485 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env46486 : List Nat := [2,4,8,16,1,64,8,5,512,68,2048,4096,88,4112,80,2,4096,2049,68,81,4161,81,16,3,88,65,2048,4177,4177,2129,21,81,5,80,4160,593]

theorem envBound46486 : H12AffineFastState.Bounded env46486 := by
  intro p hp
  have h : env46486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46485_46486 : H12AffineEnvironment.transform 4 1 env46485 = env46486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46485 == env46486) = true)

theorem identity46486 : scanCanonicalize (H12AffineFastState.compose env46486 (packedSelected [1,2,3,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46486 : packedSelected [1,2,3,7,9] rootPS < 2^1333 := by decide +kernel

def env46487 : List Nat := [2,4,8,16,1,16,8,5,512,20,2048,4096,8,4112,0,2,4096,2049,20,1,4113,1,16,3,8,17,2048,4097,4097,2049,21,1,5,0,4112,513]

theorem envBound46487 : H12AffineFastState.Bounded env46487 := by
  intro p hp
  have h : env46487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46486_46487 : H12AffineEnvironment.transform 5 16 env46486 = env46487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46486 == env46487) = true)

theorem identity46487 : scanCanonicalize (H12AffineFastState.compose env46487 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound46487 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46488 : List Nat := [2,4,8,16,1,16,8,5,17,20,2048,4096,8,4112,0,2,4096,2049,20,1,4113,1,16,3,8,17,2048,4097,4097,2049,21,1,5,0,4112,16]

theorem envBound46488 : H12AffineFastState.Bounded env46488 := by
  intro p hp
  have h : env46488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46487_46488 : H12AffineEnvironment.transform 8 17 env46487 = env46488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env46487 == env46488) = true)

theorem identity46488 : scanCanonicalize (H12AffineFastState.compose env46488 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound46488 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46489 : List Nat := [2,4,8,16,1,16,8,5,17,20,2048,2049,8,2065,0,2,2049,2049,20,1,2064,1,16,3,8,17,2048,2048,2048,2049,21,1,5,0,2065,16]

theorem envBound46489 : H12AffineFastState.Bounded env46489 := by
  intro p hp
  have h : env46489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46488_46489 : H12AffineEnvironment.transform 11 2049 env46488 = env46489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env46488 == env46489) = true)

theorem identity46489 : scanCanonicalize (H12AffineFastState.compose env46489 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound46489 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46490 : List Nat := [2,4,8,16,1,16,8,5,17,20,1,0,8,16,0,2,0,0,20,1,17,1,16,3,8,17,1,1,1,0,21,1,5,0,16,16]

theorem envBound46490 : H12AffineFastState.Bounded env46490 := by
  intro p hp
  have h : env46490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46489_46490 : H12AffineEnvironment.transform 10 1 env46489 = env46490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env46489 == env46490) = true)

theorem identity46490 : scanCanonicalize (H12AffineFastState.compose env46490 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound46490 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env46491 : List Nat := [2,4,8,0,1,0,8,5,1,4,1,0,8,0,0,2,0,0,4,1,1,1,0,3,8,1,1,1,1,0,5,1,5,0,0,0]

theorem envBound46491 : H12AffineFastState.Bounded env46491 := by
  intro p hp
  have h : env46491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46490_46491 : H12AffineEnvironment.transform 3 0 env46490 = env46491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env46490 == env46491) = true)

def env46492 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,4161,144493,400500,485740,8193,65,292137,395636,416100,10281,1365,272392,256,21792,16464,74251]

theorem envBound46492 : H12AffineFastState.Bounded env46492 := by
  intro p hp
  have h : env46492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46477_46492 : H12AffineEnvironment.transform 6 9 env46477 = env46492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46477 == env46492) = true)

theorem identity46492 : scanCanonicalize (H12AffineFastState.compose env46492 (packedSelected [3,10,11,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound46492 : packedSelected [3,10,11,24,26,32] rootPS < 2^1333 := by decide +kernel

def env46493 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,5440,262144,1024,29788,4161,8493,264500,359468,8193,65,292137,269364,281636,10281,1365,272392,256,21792,16464,74251]

theorem envBound46493 : H12AffineFastState.Bounded env46493 := by
  intro p hp
  have h : env46493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46492_46493 : H12AffineEnvironment.transform 16 5440 env46492 = env46493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env46492 == env46493) = true)

theorem identity46493 : scanCanonicalize (H12AffineFastState.compose env46493 (packedSelected [1,3,4,8,9,10,12,14,15,17,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 89459) := by decide +kernel

theorem selectedBound46493 : packedSelected [1,3,4,8,9,10,12,14,15,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env46494 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,5440,89459,1024,29788,4161,8493,87111,8543,8193,65,75866,82247,69975,10281,1365,95611,256,21792,16464,74251]

theorem envBound46494 : H12AffineFastState.Bounded env46494 := by
  intro p hp
  have h : env46494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46493_46494 : H12AffineEnvironment.transform 17 89459 env46493 = env46494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89459 env46493 == env46494) = true)

theorem identity46494 : scanCanonicalize (H12AffineFastState.compose env46494 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46494 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env46495 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,65536,5392,89379,1024,29708,4113,8493,87063,8463,8193,17,75786,82199,69895,10281,1285,95531,256,21792,16384,74251]

theorem envBound46495 : H12AffineFastState.Bounded env46495 := by
  intro p hp
  have h : env46495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46494_46495 : H12AffineEnvironment.transform 5 16 env46494 = env46495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46494 == env46495) = true)

theorem identity46495 : scanCanonicalize (H12AffineFastState.compose env46495 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound46495 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env46496 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,29962,5392,10281,1024,29708,4113,8493,8477,8463,8193,17,23808,13341,25613,10281,1285,33,256,21792,16384,22273]

theorem envBound46496 : H12AffineFastState.Bounded env46496 := by
  intro p hp
  have h : env46496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46495_46496 : H12AffineEnvironment.transform 15 29962 env46495 = env46496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env46495 == env46496) = true)

theorem identity46496 : scanCanonicalize (H12AffineFastState.compose env46496 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound46496 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46497 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8461,8202,5392,10281,1024,8460,4113,8493,8477,8463,8193,17,2048,13341,12557,10281,1285,33,256,32,5376,513]

theorem envBound46497 : H12AffineFastState.Bounded env46497 := by
  intro p hp
  have h : env46497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46496_46497 : H12AffineEnvironment.transform 13 5376 env46496 = env46497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env46496 == env46497) = true)

theorem identity46497 : scanCanonicalize (H12AffineFastState.compose env46497 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound46497 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46498 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,1,262,5392,2341,1024,0,4113,33,17,3,269,17,2048,5393,4097,2341,1285,33,256,32,5376,513]

theorem envBound46498 : H12AffineFastState.Bounded env46498 := by
  intro p hp
  have h : env46498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46497_46498 : H12AffineEnvironment.transform 12 268 env46497 = env46498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env46497 == env46498) = true)

theorem identity46498 : scanCanonicalize (H12AffineFastState.compose env46498 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound46498 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46499 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,5156,1,34,5172,2049,1024,0,4113,33,17,3,41,17,2048,5173,4097,2049,1057,33,36,32,5156,513]

theorem envBound46499 : H12AffineFastState.Bounded env46499 := by
  intro p hp
  have h : env46499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46498_46499 : H12AffineEnvironment.transform 7 36 env46498 = env46499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env46498 == env46499) = true)

def env46500 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,48,40,1044,1,34,1028,2049,1024,0,33,33,17,3,41,17,2048,1029,49,2049,1057,33,36,32,1044,513]

theorem envBound46500 : H12AffineFastState.Bounded env46500 := by
  intro p hp
  have h : env46500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46499_46500 : H12AffineEnvironment.transform 11 48 env46499 = env46500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env46499 == env46500) = true)

theorem identity46500 : scanCanonicalize (H12AffineFastState.compose env46500 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46500 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46501 : List Nat := [2,4,8,16,1,16,9,5,512,1024,2048,17,9,1044,1,3,1028,2049,1024,0,0,0,17,3,8,17,2048,1029,16,2049,1024,0,5,1,1044,513]

theorem envBound46501 : H12AffineFastState.Bounded env46501 := by
  intro p hp
  have h : env46501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46500_46501 : H12AffineEnvironment.transform 4 1 env46500 = env46501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46500 == env46501) = true)

def env46502 : List Nat := [2,4,8,16,1,16,9,5,512,20,2048,17,9,0,1,3,16,2049,20,0,0,0,17,3,8,17,2048,17,16,2049,20,0,5,1,0,513]

theorem envBound46502 : H12AffineFastState.Bounded env46502 := by
  intro p hp
  have h : env46502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46501_46502 : H12AffineEnvironment.transform 9 20 env46501 = env46502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env46501 == env46502) = true)

theorem identity46502 : scanCanonicalize (H12AffineFastState.compose env46502 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound46502 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46503 : List Nat := [2,4,8,16,1,16,9,5,512,20,0,17,9,0,1,3,16,1,20,0,0,0,17,3,8,17,0,17,16,1,20,0,5,1,0,513]

theorem envBound46503 : H12AffineFastState.Bounded env46503 := by
  intro p hp
  have h : env46503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46502_46503 : H12AffineEnvironment.transform 10 0 env46502 = env46503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env46502 == env46503) = true)

def leafEnv46503 : List Nat := [2,4,8,16,1,16,9,5,512,20,0,17,9,0,1,3,16,1,20,0,0,0,17,3,20,8,1,17,0,17,16,1,20,0,5,1,4,2,0,513,1,0,0]

def active46503 : List Nat := [0,1,2,3,8]

def tree46503 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46503 : H12WitnessSearch.Good tree46503 := H12GlobalWitnessIndex.good

theorem leafIdentity46503 : H12AffineFastState.composeSystem env46503 rootObs = leafEnv46503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46503 rootObs == leafEnv46503) = true)

theorem terminalChecked46503 : H12PackedTerminal.terminalCheckFast leafEnv46503 active46503 tree46503 = true := by decide +kernel

def env46504 : List Nat := [2,4,8,16,1,16,9,5,512,21,2048,17,9,1,1,3,17,2049,21,0,0,0,17,3,8,17,2048,16,16,2049,21,0,5,1,1,513]

theorem envBound46504 : H12AffineFastState.Bounded env46504 := by
  intro p hp
  have h : env46504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46501_46504 : H12AffineEnvironment.transform 9 21 env46501 = env46504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env46501 == env46504) = true)

theorem identity46504 : scanCanonicalize (H12AffineFastState.compose env46504 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound46504 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46505 : List Nat := [2,4,8,16,1,16,9,5,512,21,523,17,9,1,1,3,17,522,21,0,0,0,17,3,8,17,523,16,16,522,21,0,5,1,1,513]

theorem envBound46505 : H12AffineFastState.Bounded env46505 := by
  intro p hp
  have h : env46505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46504_46505 : H12AffineEnvironment.transform 10 523 env46504 = env46505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env46504 == env46505) = true)

def leafEnv46505 : List Nat := [2,4,8,16,1,16,9,5,512,21,523,17,9,1,1,3,17,522,21,0,0,0,17,3,21,8,1,17,523,16,16,522,21,0,5,1,4,2,1,513,1,0,0]

def active46505 : List Nat := [0,1,2,3,8]

def tree46505 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46505 : H12WitnessSearch.Good tree46505 := H12GlobalWitnessIndex.good

theorem leafIdentity46505 : H12AffineFastState.composeSystem env46505 rootObs = leafEnv46505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46505 rootObs == leafEnv46505) = true)

theorem terminalChecked46505 : H12PackedTerminal.terminalCheckFast leafEnv46505 active46505 tree46505 = true := by decide +kernel

def env46506 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,49,40,1045,1,34,1029,2049,1024,0,32,33,17,3,41,17,2048,1028,48,2049,1057,33,36,32,1045,513]

theorem envBound46506 : H12AffineFastState.Bounded env46506 := by
  intro p hp
  have h : env46506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46499_46506 : H12AffineEnvironment.transform 11 49 env46499 = env46506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env46499 == env46506) = true)

theorem identity46506 : scanCanonicalize (H12AffineFastState.compose env46506 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound46506 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46507 : List Nat := [2,4,8,16,32,16,9,36,512,20,2048,49,40,1,1,34,17,2049,20,0,32,33,17,3,41,17,2048,16,48,2049,53,33,36,32,1,513]

theorem envBound46507 : H12AffineFastState.Bounded env46507 := by
  intro p hp
  have h : env46507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46506_46507 : H12AffineEnvironment.transform 9 20 env46506 = env46507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env46506 == env46507) = true)

def env46508 : List Nat := [2,4,8,16,0,16,9,4,512,20,2048,17,8,1,1,2,17,2049,20,0,0,1,17,3,9,17,2048,16,16,2049,21,1,4,0,1,513]

theorem envBound46508 : H12AffineFastState.Bounded env46508 := by
  intro p hp
  have h : env46508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46507_46508 : H12AffineEnvironment.transform 4 0 env46507 = env46508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env46507 == env46508) = true)

theorem identity46508 : scanCanonicalize (H12AffineFastState.compose env46508 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound46508 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46509 : List Nat := [2,4,8,16,0,16,9,4,512,20,523,17,8,1,1,2,17,522,20,0,0,1,17,3,9,17,523,16,16,522,21,1,4,0,1,513]

theorem envBound46509 : H12AffineFastState.Bounded env46509 := by
  intro p hp
  have h : env46509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46508_46509 : H12AffineEnvironment.transform 10 523 env46508 = env46509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env46508 == env46509) = true)

def leafEnv46509 : List Nat := [2,4,8,16,0,16,9,4,512,20,523,17,8,1,1,2,17,522,20,0,0,1,17,3,21,9,1,17,523,16,16,522,21,1,4,0,4,3,1,513,1,0,0]

def active46509 : List Nat := [0,1,2,3,8]

def tree46509 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46509 : H12WitnessSearch.Good tree46509 := H12GlobalWitnessIndex.good

theorem leafIdentity46509 : H12AffineFastState.composeSystem env46509 rootObs = leafEnv46509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46509 rootObs == leafEnv46509) = true)

theorem terminalChecked46509 : H12PackedTerminal.terminalCheckFast leafEnv46509 active46509 tree46509 = true := by decide +kernel

def env46510 : List Nat := [2,4,8,16,1,16,9,5,512,20,2048,16,9,1,1,3,17,2049,20,0,1,0,17,3,8,17,2048,16,17,2049,20,0,5,1,1,513]

theorem envBound46510 : H12AffineFastState.Bounded env46510 := by
  intro p hp
  have h : env46510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46507_46510 : H12AffineEnvironment.transform 4 1 env46507 = env46510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46507 == env46510) = true)

theorem identity46510 : scanCanonicalize (H12AffineFastState.compose env46510 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound46510 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46511 : List Nat := [2,4,8,16,1,16,9,5,512,20,1,16,9,1,1,3,17,0,20,0,1,0,17,3,8,17,1,16,17,0,20,0,5,1,1,513]

theorem envBound46511 : H12AffineFastState.Bounded env46511 := by
  intro p hp
  have h : env46511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46510_46511 : H12AffineEnvironment.transform 10 1 env46510 = env46511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env46510 == env46511) = true)

def leafEnv46511 : List Nat := [2,4,8,16,1,16,9,5,512,20,1,16,9,1,1,3,17,0,20,0,1,0,17,3,20,8,1,17,1,16,17,0,20,0,5,1,4,2,1,513,1,1,0]

def active46511 : List Nat := [0,1,2,3,8]

def tree46511 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46511 : H12WitnessSearch.Good tree46511 := H12GlobalWitnessIndex.good

theorem leafIdentity46511 : H12AffineFastState.composeSystem env46511 rootObs = leafEnv46511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46511 rootObs == leafEnv46511) = true)

theorem terminalChecked46511 : H12PackedTerminal.terminalCheckFast leafEnv46511 active46511 tree46511 = true := by decide +kernel

def env46512 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180273,2493493,499128,8328,65,2396605,2496821,416100,2149429,2102685,2373704,256,21792,46212,2175562]

theorem envBound46512 : H12AffineFastState.Bounded env46512 := by
  intro p hp
  have h : env46512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46453_46512 : H12AffineEnvironment.transform 21 180273 env46453 = env46512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180273 env46453 == env46512) = true)

def env46513 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180273,400501,499128,8328,65,295421,395637,416100,56437,1501,272392,256,21792,46212,74250]

theorem envBound46513 : H12AffineFastState.Bounded env46513 := by
  intro p hp
  have h : env46513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46512_46513 : H12AffineEnvironment.transform 20 4160 env46512 = env46513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env46512 == env46513) = true)

def env46514 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,180273,144477,243088,8328,65,43477,139613,160076,56437,1501,32,256,21792,46212,74250]

theorem envBound46514 : H12AffineFastState.Bounded env46514 := by
  intro p hp
  have h : env46514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46513_46514 : H12AffineEnvironment.transform 17 10280 env46513 = env46514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env46513 == env46514) = true)

def env46515 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1024,32769,4160,21793,41293,73856,8328,65,43477,46157,58460,56437,1501,32,256,21792,46212,74250]

theorem envBound46515 : H12AffineFastState.Bounded env46515 := by
  intro p hp
  have h : env46515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46514_46515 : H12AffineEnvironment.transform 16 38160 env46514 = env46515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env46514 == env46515) = true)

theorem identity46515 : scanCanonicalize (H12AffineFastState.compose env46515 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound46515 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46516 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,13509,10280,1024,8660,4160,21793,152,73856,8328,65,2048,5528,17801,32160,1501,32,256,21792,5457,74250]

theorem envBound46516 : H12AffineFastState.Bounded env46516 := by
  intro p hp
  have h : env46516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46515_46516 : H12AffineEnvironment.transform 14 8661 env46515 = env46516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env46515 == env46516) = true)

theorem identity46516 : scanCanonicalize (H12AffineFastState.compose env46516 (packedSelected [0,2,3,6,7,8,11,16,18,24,26,28] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound46516 : packedSelected [0,2,3,6,7,8,11,16,18,24,26,28] rootPS < 2^1333 := by decide +kernel

def env46517 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,4096,8192,16384,8661,65536,12328,10280,237,8660,4160,20940,152,73856,8328,65,2048,4469,16740,31053,304,32,256,20941,4540,74250]

theorem envBound46517 : H12AffineFastState.Bounded env46517 := by
  intro p hp
  have h : env46517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46516_46517 : H12AffineEnvironment.transform 9 237 env46516 = env46517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env46516 == env46517) = true)

theorem identity46517 : scanCanonicalize (H12AffineFastState.compose env46517 (packedSelected [0,1,2,5,6,7,8,12,15,18,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 8694) := by decide +kernel

theorem selectedBound46517 : packedSelected [0,1,2,5,6,7,8,12,15,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env46518 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,4096,8192,16384,8661,8694,12328,10280,237,8660,4160,20940,152,374,8328,65,2048,4469,16740,31053,304,32,256,20941,4540,1020]

theorem envBound46518 : H12AffineFastState.Bounded env46518 := by
  intro p hp
  have h : env46518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46517_46518 : H12AffineEnvironment.transform 15 8694 env46517 = env46518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8694 env46517 == env46518) = true)

theorem identity46518 : scanCanonicalize (H12AffineFastState.compose env46518 (packedSelected [3,4,5,9,10,11,14,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound46518 : packedSelected [3,4,5,9,10,11,14,20,23] rootPS < 2^1333 := by decide +kernel

def env46519 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,4096,120,16384,429,398,4176,2128,237,428,4160,20940,152,374,240,65,2048,4469,16740,22837,304,32,256,20941,4540,1020]

theorem envBound46519 : H12AffineFastState.Bounded env46519 := by
  intro p hp
  have h : env46519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46518_46519 : H12AffineEnvironment.transform 12 120 env46518 = env46519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env46518 == env46519) = true)

theorem identity46519 : scanCanonicalize (H12AffineFastState.compose env46519 (packedSelected [0,1,2,6,7,8,11,12,15,16,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 4541) := by decide +kernel

theorem selectedBound46519 : packedSelected [0,1,2,6,7,8,11,12,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env46520 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,4096,120,4541,429,398,4176,2128,237,428,4160,113,152,374,240,65,2048,4469,4313,2184,304,32,256,112,4540,1020]

theorem envBound46520 : H12AffineFastState.Bounded env46520 := by
  intro p hp
  have h : env46520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46519_46520 : H12AffineEnvironment.transform 13 4541 env46519 = env46520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4541 env46519 == env46520) = true)

theorem identity46520 : scanCanonicalize (H12AffineFastState.compose env46520 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound46520 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env46521 : List Nat := [2,4,8,16,32,64,128,36,512,237,2048,4096,120,4249,137,170,4176,2128,237,136,4160,113,152,82,240,65,2048,4177,4313,2184,20,32,36,112,4248,728]

theorem envBound46521 : H12AffineFastState.Bounded env46521 := by
  intro p hp
  have h : env46521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46520_46521 : H12AffineEnvironment.transform 7 36 env46520 = env46521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env46520 == env46521) = true)

theorem identity46521 : scanCanonicalize (H12AffineFastState.compose env46521 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound46521 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env46522 : List Nat := [2,4,8,16,32,64,9,36,512,100,2048,4096,120,4112,0,35,4176,2128,100,1,4160,113,17,82,121,65,2048,4177,4176,2049,20,32,36,112,4113,593]

theorem envBound46522 : H12AffineFastState.Bounded env46522 := by
  intro p hp
  have h : env46522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46521_46522 : H12AffineEnvironment.transform 6 9 env46521 = env46522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46521 == env46522) = true)

theorem identity46522 : scanCanonicalize (H12AffineFastState.compose env46522 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2144) := by decide +kernel

theorem selectedBound46522 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env46523 : List Nat := [2,4,8,16,32,64,9,36,512,100,2048,2144,120,2160,0,35,2096,2128,100,1,2080,113,17,82,121,65,2048,2097,2096,2049,20,32,36,112,2161,593]

theorem envBound46523 : H12AffineFastState.Bounded env46523 := by
  intro p hp
  have h : env46523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46522_46523 : H12AffineEnvironment.transform 11 2144 env46522 = env46523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2144 env46522 == env46523) = true)

theorem identity46523 : scanCanonicalize (H12AffineFastState.compose env46523 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound46523 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env46524 : List Nat := [2,4,8,16,32,48,9,36,512,20,2048,2064,8,2048,0,35,2096,2080,20,1,2080,1,17,34,9,49,2048,2097,2096,2049,20,32,36,0,2049,545]

theorem envBound46524 : H12AffineFastState.Bounded env46524 := by
  intro p hp
  have h : env46524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46523_46524 : H12AffineEnvironment.transform 5 48 env46523 = env46524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env46523 == env46524) = true)

theorem identity46524 : scanCanonicalize (H12AffineFastState.compose env46524 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46524 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env46525 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,2064,8,2048,0,2,2065,2049,20,1,2049,1,17,3,9,16,2048,2064,2065,2049,20,1,5,0,2049,512]

theorem envBound46525 : H12AffineFastState.Bounded env46525 := by
  intro p hp
  have h : env46525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46524_46525 : H12AffineEnvironment.transform 4 1 env46524 = env46525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46524 == env46525) = true)

def env46526 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1024,32769,4160,21792,41292,73857,8328,65,43477,46156,58461,56437,1501,32,256,21792,46212,74250]

theorem envBound46526 : H12AffineFastState.Bounded env46526 := by
  intro p hp
  have h : env46526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46514_46526 : H12AffineEnvironment.transform 16 38161 env46514 = env46526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env46514 == env46526) = true)

theorem identity46526 : scanCanonicalize (H12AffineFastState.compose env46526 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound46526 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46527 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,13388,10280,1024,8540,4160,21792,17,73857,8328,65,2184,5393,17664,32040,1501,32,256,21792,5593,74250]

theorem envBound46527 : H12AffineFastState.Bounded env46527 := by
  intro p hp
  have h : env46527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46526_46527 : H12AffineEnvironment.transform 14 8541 env46526 = env46527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env46526 == env46527) = true)

theorem identity46527 : scanCanonicalize (H12AffineFastState.compose env46527 (packedSelected [5,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound46527 : packedSelected [5,24,26] rootPS < 2^1333 := by decide +kernel

def env46528 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,28698,13388,10280,1024,8540,4160,21792,17,20635,8328,65,2184,5393,17664,32040,1501,32,256,21792,5593,21008]

theorem envBound46528 : H12AffineFastState.Bounded env46528 := by
  intro p hp
  have h : env46528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46527_46528 : H12AffineEnvironment.transform 15 28698 env46527 = env46528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env46527 == env46528) = true)

theorem identity46528 : scanCanonicalize (H12AffineFastState.compose env46528 (packedSelected [1,3,5,8,10,11,16,18,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound46528 : packedSelected [1,3,5,8,10,11,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env46529 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4404,8541,8494,13388,10280,1024,8540,4160,1044,17,431,8328,65,2184,5393,5172,11292,1501,32,256,1044,5593,804]

theorem envBound46529 : H12AffineFastState.Bounded env46529 := by
  intro p hp
  have h : env46529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46528_46529 : H12AffineEnvironment.transform 13 4404 env46528 = env46529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env46528 == env46529) = true)

theorem identity46529 : scanCanonicalize (H12AffineFastState.compose env46529 (packedSelected [0,1,4,5,8,12,14,15,16,22,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 240) := by decide +kernel

theorem selectedBound46529 : packedSelected [0,1,4,5,8,12,14,15,16,22,24,27] rootPS < 2^1333 := by decide +kernel

def env46530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,4404,429,478,5308,2264,1024,428,4160,1044,17,431,120,65,2184,5393,5172,3308,1501,32,256,1044,5593,804]

theorem envBound46530 : H12AffineFastState.Bounded env46530 := by
  intro p hp
  have h : env46530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46529_46530 : H12AffineEnvironment.transform 12 240 env46529 = env46530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env46529 == env46530) = true)

theorem identity46530 : scanCanonicalize (H12AffineFastState.compose env46530 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound46530 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46531 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,240,4404,429,478,4389,2264,409,428,4160,397,17,431,120,65,2184,4232,4525,2421,68,32,256,397,4160,804]

theorem envBound46531 : H12AffineFastState.Bounded env46531 := by
  intro p hp
  have h : env46531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46530_46531 : H12AffineEnvironment.transform 9 409 env46530 = env46531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env46530 == env46531) = true)

theorem identity46531 : scanCanonicalize (H12AffineFastState.compose env46531 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(11+1) ^^^ 2200) := by decide +kernel

theorem selectedBound46531 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env46532 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,2200,240,2476,429,478,2493,2264,409,428,2264,397,17,431,120,65,2184,2064,2357,2421,68,32,256,397,2264,804]

theorem envBound46532 : H12AffineFastState.Bounded env46532 := by
  intro p hp
  have h : env46532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46531_46532 : H12AffineEnvironment.transform 11 2200 env46531 = env46532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2200 env46531 == env46532) = true)

theorem identity46532 : scanCanonicalize (H12AffineFastState.compose env46532 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound46532 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env46533 : List Nat := [2,4,8,16,32,64,128,256,512,409,0,152,240,428,429,478,445,216,409,428,216,397,17,431,120,65,136,16,309,373,68,32,256,397,216,804]

theorem envBound46533 : H12AffineFastState.Bounded env46533 := by
  intro p hp
  have h : env46533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46532_46533 : H12AffineEnvironment.transform 10 0 env46532 = env46533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env46532 == env46533) = true)

theorem identity46533 : scanCanonicalize (H12AffineFastState.compose env46533 (packedSelected [0,3,4,5,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound46533 : packedSelected [0,3,4,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env46534 : List Nat := [2,4,8,16,32,64,128,253,512,100,0,152,240,81,80,35,64,216,100,81,216,112,17,82,120,65,136,16,200,136,68,32,253,112,216,729]

theorem envBound46534 : H12AffineFastState.Bounded env46534 := by
  intro p hp
  have h : env46534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46533_46534 : H12AffineEnvironment.transform 7 253 env46533 = env46534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env46533 == env46534) = true)

theorem identity46534 : scanCanonicalize (H12AffineFastState.compose env46534 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46534 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env46535 : List Nat := [2,4,8,16,32,16,128,173,512,52,0,152,160,1,0,35,16,136,52,1,136,32,17,2,40,17,136,16,152,136,20,32,173,32,136,649]

theorem envBound46535 : H12AffineFastState.Bounded env46535 := by
  intro p hp
  have h : env46535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46534_46535 : H12AffineEnvironment.transform 5 16 env46534 = env46535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46534 == env46535) = true)

theorem identity46535 : scanCanonicalize (H12AffineFastState.compose env46535 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound46535 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env46536 : List Nat := [2,4,8,16,32,16,128,173,17,52,0,152,160,1,0,35,16,136,52,1,136,32,17,2,40,17,136,16,152,136,20,32,173,32,136,152]

theorem envBound46536 : H12AffineFastState.Bounded env46536 := by
  intro p hp
  have h : env46536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46535_46536 : H12AffineEnvironment.transform 8 17 env46535 = env46536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env46535 == env46536) = true)

theorem identity46536 : scanCanonicalize (H12AffineFastState.compose env46536 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46536 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env46537 : List Nat := [2,4,8,16,32,16,8,37,17,52,0,16,40,1,0,35,16,0,52,1,0,32,17,2,40,17,0,16,16,0,20,32,37,32,0,16]

theorem envBound46537 : H12AffineFastState.Bounded env46537 := by
  intro p hp
  have h : env46537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46536_46537 : H12AffineEnvironment.transform 6 8 env46536 = env46537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46536 == env46537) = true)

theorem identity46537 : scanCanonicalize (H12AffineFastState.compose env46537 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound46537 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46538 : List Nat := [2,4,8,1,32,1,8,37,0,37,0,1,40,1,0,35,1,0,37,1,0,32,0,2,40,0,0,1,1,0,5,32,37,32,0,1]

theorem envBound46538 : H12AffineFastState.Bounded env46538 := by
  intro p hp
  have h : env46538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46537_46538 : H12AffineEnvironment.transform 3 1 env46537 = env46538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env46537 == env46538) = true)

theorem identity46538 : scanCanonicalize (H12AffineFastState.compose env46538 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound46538 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46539 : List Nat := [2,4,8,1,11,1,8,14,0,14,0,1,3,1,0,8,1,0,14,1,0,11,0,2,3,0,0,1,1,0,5,11,14,11,0,1]

theorem envBound46539 : H12AffineFastState.Bounded env46539 := by
  intro p hp
  have h : env46539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46538_46539 : H12AffineEnvironment.transform 4 11 env46538 = env46539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env46538 == env46539) = true)

def env46540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,180273,144476,243089,8328,65,43476,139612,160077,56437,1501,33,256,21792,46212,74250]

theorem envBound46540 : H12AffineFastState.Bounded env46540 := by
  intro p hp
  have h : env46540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46513_46540 : H12AffineEnvironment.transform 17 10281 env46513 = env46540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env46513 == env46540) = true)

def env46541 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1024,32769,4160,21793,41292,73857,8328,65,43476,46156,58461,56437,1501,33,256,21792,46212,74250]

theorem envBound46541 : H12AffineFastState.Bounded env46541 := by
  intro p hp
  have h : env46541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46540_46541 : H12AffineEnvironment.transform 16 38160 env46540 = env46541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env46540 == env46541) = true)

theorem identity46541 : scanCanonicalize (H12AffineFastState.compose env46541 (packedSelected [3,5,8,10,11,18,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound46541 : packedSelected [3,5,8,10,11,18,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env46542 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,38160,10281,1024,32769,4160,21793,41292,3,8328,65,43476,46156,58461,56437,1501,33,256,21792,46212,648]

theorem envBound46542 : H12AffineFastState.Bounded env46542 := by
  intro p hp
  have h : env46542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46541_46542 : H12AffineEnvironment.transform 15 8322 env46541 = env46542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env46541 == env46542) = true)

theorem identity46542 : scanCanonicalize (H12AffineFastState.compose env46542 (packedSelected [1,3,5,8,9,10,19,20,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound46542 : packedSelected [1,3,5,8,9,10,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env46543 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,479,38160,2420,1024,32769,4160,21793,32785,3,469,65,34953,38161,50432,56437,1501,33,256,21792,38361,648]

theorem envBound46543 : H12AffineFastState.Bounded env46543 := by
  intro p hp
  have h : env46543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46542_46543 : H12AffineEnvironment.transform 12 349 env46542 = env46543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env46542 == env46543) = true)

theorem identity46543 : scanCanonicalize (H12AffineFastState.compose env46543 (packedSelected [0,1,4,7,8,9,10,12,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 217) := by decide +kernel

theorem selectedBound46543 : packedSelected [0,1,4,7,8,9,10,12,16,18] rootPS < 2^1333 := by decide +kernel

def env46544 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,217,479,5577,2420,1024,216,4160,21793,200,3,469,65,2128,5576,17881,23724,1501,33,256,21792,5376,648]

theorem envBound46544 : H12AffineFastState.Bounded env46544 := by
  intro p hp
  have h : env46544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46543_46544 : H12AffineEnvironment.transform 14 217 env46543 = env46544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 217 env46543 == env46544) = true)

theorem identity46544 : scanCanonicalize (H12AffineFastState.compose env46544 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound46544 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env46545 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,16384,1,263,5393,2420,1024,0,4160,21793,16,3,269,65,2128,5392,17665,23668,1285,33,256,21792,5376,592]

theorem envBound46545 : H12AffineFastState.Bounded env46545 := by
  intro p hp
  have h : env46545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46544_46545 : H12AffineEnvironment.transform 6 88 env46544 = env46545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env46544 == env46545) = true)

theorem identity46545 : scanCanonicalize (H12AffineFastState.compose env46545 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound46545 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env46546 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,5376,1,263,5393,2420,1024,0,4160,33,16,3,269,65,2128,5392,4097,2420,1285,33,256,32,5376,592]

theorem envBound46546 : H12AffineFastState.Bounded env46546 := by
  intro p hp
  have h : env46546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46545_46546 : H12AffineEnvironment.transform 13 5376 env46545 = env46546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env46545 == env46546) = true)

theorem identity46546 : scanCanonicalize (H12AffineFastState.compose env46546 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 868) := by decide +kernel

theorem selectedBound46546 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env46547 : List Nat := [2,4,8,16,32,64,88,256,512,1024,868,4096,349,5376,1,263,5393,528,1024,0,4160,33,16,3,269,65,820,5392,4097,528,1285,33,256,32,5376,592]

theorem envBound46547 : H12AffineFastState.Bounded env46547 := by
  intro p hp
  have h : env46547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46546_46547 : H12AffineEnvironment.transform 10 868 env46546 = env46547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 868 env46546 == env46547) = true)

theorem identity46547 : scanCanonicalize (H12AffineFastState.compose env46547 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound46547 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env46548 : List Nat := [2,4,8,16,32,49,41,256,512,1024,789,4096,300,5376,1,263,5393,528,1024,0,4145,33,16,3,269,48,820,5392,4097,528,1285,33,256,32,5376,545]

theorem envBound46548 : H12AffineFastState.Bounded env46548 := by
  intro p hp
  have h : env46548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46547_46548 : H12AffineEnvironment.transform 5 49 env46547 = env46548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env46547 == env46548) = true)

theorem identity46548 : scanCanonicalize (H12AffineFastState.compose env46548 (packedSelected [0,1,2,3,7,14] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound46548 : packedSelected [0,1,2,3,7,14] rootPS < 2^1333 := by decide +kernel

def env46549 : List Nat := [2,4,8,16,32,49,41,256,512,1024,789,1588,300,820,1,263,805,528,1024,0,1541,33,16,3,269,48,820,804,1589,528,1285,33,256,32,820,545]

theorem envBound46549 : H12AffineFastState.Bounded env46549 := by
  intro p hp
  have h : env46549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46548_46549 : H12AffineEnvironment.transform 11 1588 env46548 = env46549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env46548 == env46549) = true)

theorem identity46549 : scanCanonicalize (H12AffineFastState.compose env46549 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound46549 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env46550 : List Nat := [2,4,8,16,32,49,41,256,512,53,789,513,300,820,1,263,805,528,53,0,560,33,16,3,269,48,820,804,512,528,304,33,256,32,820,545]

theorem envBound46550 : H12AffineFastState.Bounded env46550 := by
  intro p hp
  have h : env46550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46549_46550 : H12AffineEnvironment.transform 9 53 env46549 = env46550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env46549 == env46550) = true)

theorem identity46550 : scanCanonicalize (H12AffineFastState.compose env46550 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound46550 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env46551 : List Nat := [2,4,8,16,32,49,41,37,512,53,560,513,9,529,1,34,512,528,53,0,560,33,16,3,40,48,529,513,512,528,21,33,37,32,529,545]

theorem envBound46551 : H12AffineFastState.Bounded env46551 := by
  intro p hp
  have h : env46551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46550_46551 : H12AffineEnvironment.transform 7 37 env46550 = env46551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env46550 == env46551) = true)

theorem identity46551 : scanCanonicalize (H12AffineFastState.compose env46551 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound46551 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env46552 : List Nat := [2,4,8,16,16,1,25,21,512,5,512,513,9,529,1,18,512,528,5,0,512,17,16,3,24,0,529,513,512,528,21,17,21,16,529,529]

theorem envBound46552 : H12AffineFastState.Bounded env46552 := by
  intro p hp
  have h : env46552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46551_46552 : H12AffineEnvironment.transform 4 16 env46551 = env46552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env46551 == env46552) = true)

theorem identity46552 : scanCanonicalize (H12AffineFastState.compose env46552 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound46552 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46553 : List Nat := [2,4,8,16,16,1,25,21,0,5,0,1,9,17,1,18,0,16,5,0,0,17,16,3,24,0,17,1,0,16,21,17,21,16,17,17]

theorem envBound46553 : H12AffineFastState.Bounded env46553 := by
  intro p hp
  have h : env46553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46552_46553 : H12AffineEnvironment.transform 8 0 env46552 = env46553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env46552 == env46553) = true)

def env46554 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1024,32769,4160,21792,41293,73856,8328,65,43476,46157,58460,56437,1501,33,256,21792,46212,74250]

theorem envBound46554 : H12AffineFastState.Bounded env46554 := by
  intro p hp
  have h : env46554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46540_46554 : H12AffineEnvironment.transform 16 38161 env46540 = env46554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env46540 == env46554) = true)

theorem identity46554 : scanCanonicalize (H12AffineFastState.compose env46554 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound46554 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46555 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1024,32769,4160,21792,41293,73737,8193,65,43357,46157,58460,56437,1364,33,256,21792,46093,74250]

theorem envBound46555 : H12AffineFastState.Bounded env46555 := by
  intro p hp
  have h : env46555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46554_46555 : H12AffineEnvironment.transform 6 9 env46554 = env46555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46554 == env46555) = true)

theorem identity46555 : scanCanonicalize (H12AffineFastState.compose env46555 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound46555 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env46556 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,38161,10281,1024,32769,4160,21792,41293,54531,8193,65,43357,46157,58460,56437,1364,33,256,21792,46093,55040]

theorem envBound46556 : H12AffineFastState.Bounded env46556 := by
  intro p hp
  have h : env46556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46555_46556 : H12AffineEnvironment.transform 15 62730 env46555 = env46556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env46555 == env46556) = true)

theorem identity46556 : scanCanonicalize (H12AffineFastState.compose env46556 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound46556 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env46557 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,29963,5392,10281,1024,0,4160,21792,8524,21762,8193,65,10588,13388,25693,23668,1364,33,256,21792,13324,22273]

theorem envBound46557 : H12AffineFastState.Bounded env46557 := by
  intro p hp
  have h : env46557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46556_46557 : H12AffineEnvironment.transform 14 1 env46556 = env46557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env46556 == env46557) = true)

theorem identity46557 : scanCanonicalize (H12AffineFastState.compose env46557 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound46557 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env46558 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,1,262,5392,10281,1024,0,4160,8493,8524,8463,8193,65,10588,13388,4176,10361,1364,33,256,8493,13324,8972]

theorem envBound46558 : H12AffineFastState.Bounded env46558 := by
  intro p hp
  have h : env46558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46557_46558 : H12AffineEnvironment.transform 13 13325 env46557 = env46558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env46557 == env46558) = true)

theorem identity46558 : scanCanonicalize (H12AffineFastState.compose env46558 (packedSelected [0,3,5,6,7,10,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46558 : packedSelected [0,3,5,6,7,10,14,16] rootPS < 2^1333 := by decide +kernel

def env46559 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,1,262,5392,10281,1024,0,4112,8493,8476,8463,8193,17,10508,13340,4096,10281,1284,33,256,8493,13324,8972]

theorem envBound46559 : H12AffineFastState.Bounded env46559 := by
  intro p hp
  have h : env46559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46558_46559 : H12AffineEnvironment.transform 5 16 env46558 = env46559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46558 == env46559) = true)

theorem identity46559 : scanCanonicalize (H12AffineFastState.compose env46559 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound46559 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env46560 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2097,8192,11324,1,262,3361,10281,1024,0,2081,8493,8476,8463,8193,17,10508,11309,2097,10281,1284,33,256,8493,11325,8972]

theorem envBound46560 : H12AffineFastState.Bounded env46560 := by
  intro p hp
  have h : env46560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46559_46560 : H12AffineEnvironment.transform 11 2097 env46559 = env46560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env46559 == env46560) = true)

theorem identity46560 : scanCanonicalize (H12AffineFastState.compose env46560 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound46560 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env46561 : List Nat := [2,4,8,16,32,16,9,256,512,20,2048,2097,8192,10280,1,262,2357,10281,20,0,2081,8493,8476,8463,8193,17,10508,10297,2097,10281,272,33,256,8493,10281,8972]

theorem envBound46561 : H12AffineFastState.Bounded env46561 := by
  intro p hp
  have h : env46561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46560_46561 : H12AffineEnvironment.transform 9 20 env46560 = env46561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env46560 == env46561) = true)

theorem identity46561 : scanCanonicalize (H12AffineFastState.compose env46561 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound46561 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env46562 : List Nat := [2,4,8,16,32,16,9,4,512,20,2048,2097,8192,10280,1,2,2097,10281,20,0,2081,8233,8216,8203,8193,17,10248,10297,2097,10281,20,33,4,8233,10281,8712]

theorem envBound46562 : H12AffineFastState.Bounded env46562 := by
  intro p hp
  have h : env46562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46561_46562 : H12AffineEnvironment.transform 7 4 env46561 = env46562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env46561 == env46562) = true)

def env46563 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180273,400500,499128,8328,65,295420,395636,416100,56436,1500,272393,256,21792,46212,74251]

theorem envBound46563 : H12AffineFastState.Bounded env46563 := by
  intro p hp
  have h : env46563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46512_46563 : H12AffineEnvironment.transform 20 4161 env46512 = env46563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env46512 == env46563) = true)

theorem identity46563 : scanCanonicalize (H12AffineFastState.compose env46563 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190640) := by decide +kernel

theorem selectedBound46563 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4161,180273,62660,95496,8328,65,158028,57796,45524,56436,1500,180409,256,21792,46212,74251]

theorem envBound46564 : H12AffineFastState.Bounded env46564 := by
  intro p hp
  have h : env46564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46563_46564 : H12AffineEnvironment.transform 17 190640 env46563 = env46564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190640 env46563 == env46564) = true)

theorem identity46564 : scanCanonicalize (H12AffineFastState.compose env46564 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound46564 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env46565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190640,1024,32769,4161,180273,62660,21762,8328,65,158028,57796,45524,56436,1500,180409,256,21792,46212,513]

theorem envBound46565 : H12AffineFastState.Bounded env46565 := by
  intro p hp
  have h : env46565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46564_46565 : H12AffineEnvironment.transform 15 8202 env46564 = env46565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env46564 == env46565) = true)

theorem identity46565 : scanCanonicalize (H12AffineFastState.compose env46565 (packedSelected [11,12,15,16,18,20,23,32,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound46565 : packedSelected [11,12,15,16,18,20,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env46566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,8202,131072,138477,1024,29788,4161,144492,153,21762,8328,65,158028,5529,17801,10281,1500,144612,256,21792,16601,513]

theorem envBound46566 : H12AffineFastState.Bounded env46566 := by
  intro p hp
  have h : env46566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46565_46566 : H12AffineEnvironment.transform 14 29789 env46565 = env46566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env46565 == env46566) = true)

theorem identity46566 : scanCanonicalize (H12AffineFastState.compose env46566 (packedSelected [7,11,14,16,18,23,27,32] rootPS)) = affineNative (2^(16+1) ^^^ 5576) := by decide +kernel

theorem selectedBound46566 : packedSelected [7,11,14,16,18,23,27,32] rootPS < 2^1333 := by decide +kernel

def env46567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,8202,5576,2341,1024,29788,4161,8612,153,21762,8328,65,31876,5529,17801,10281,1500,8492,256,21792,16601,513]

theorem envBound46567 : H12AffineFastState.Bounded env46567 := by
  intro p hp
  have h : env46567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46566_46567 : H12AffineEnvironment.transform 16 5576 env46566 = env46567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5576 env46566 == env46567) = true)

theorem identity46567 : scanCanonicalize (H12AffineFastState.compose env46567 (packedSelected [1,2,5,6,8,24] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound46567 : packedSelected [1,2,5,6,8,24] rootPS < 2^1333 := by decide +kernel

def env46568 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21897,478,5576,2341,1024,21896,4161,112,153,21762,348,65,23888,5529,17801,2557,1500,248,256,21792,16601,513]

theorem envBound46568 : H12AffineFastState.Bounded env46568 := by
  intro p hp
  have h : env46568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46567_46568 : H12AffineEnvironment.transform 12 468 env46567 = env46568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env46567 == env46568) = true)

theorem identity46568 : scanCanonicalize (H12AffineFastState.compose env46568 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound46568 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env46569 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,268,16384,21841,262,5392,2341,1024,21840,4161,112,65,21762,348,65,23888,5441,17745,2341,1284,32,256,21792,16385,513]

theorem envBound46569 : H12AffineFastState.Bounded env46569 := by
  intro p hp
  have h : env46569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46568_46569 : H12AffineEnvironment.transform 6 88 env46568 = env46569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env46568 == env46569) = true)

theorem identity46569 : scanCanonicalize (H12AffineFastState.compose env46569 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46569 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46570 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,21760,262,5392,2341,1024,21761,4112,33,16,21762,269,16,23809,5392,17664,2341,1284,32,256,21792,16385,513]

theorem envBound46570 : H12AffineFastState.Bounded env46570 := by
  intro p hp
  have h : env46570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46569_46570 : H12AffineEnvironment.transform 5 17 env46569 = env46570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46569 == env46570) = true)

theorem identity46570 : scanCanonicalize (H12AffineFastState.compose env46570 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound46570 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46571 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,1,262,5392,2341,1024,0,4112,33,16,3,269,16,2048,5392,4097,2341,1284,32,256,33,5376,513]

theorem envBound46571 : H12AffineFastState.Bounded env46571 := by
  intro p hp
  have h : env46571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46570_46571 : H12AffineEnvironment.transform 13 5377 env46570 = env46571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env46570 == env46571) = true)

theorem identity46571 : scanCanonicalize (H12AffineFastState.compose env46571 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound46571 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46572 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,5156,1,35,5173,2048,1024,0,4112,33,16,3,40,16,2048,5173,4097,2048,1057,32,37,33,5157,513]

theorem envBound46572 : H12AffineFastState.Bounded env46572 := by
  intro p hp
  have h : env46572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46571_46572 : H12AffineEnvironment.transform 7 37 env46571 = env46572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env46571 == env46572) = true)

theorem identity46572 : scanCanonicalize (H12AffineFastState.compose env46572 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound46572 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46573 : List Nat := [2,4,8,16,32,17,9,37,512,1024,523,4096,41,5156,1,35,5173,523,1024,0,4112,33,16,3,40,16,523,5173,4097,523,1057,32,37,33,5157,513]

theorem envBound46573 : H12AffineFastState.Bounded env46573 := by
  intro p hp
  have h : env46573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46572_46573 : H12AffineEnvironment.transform 10 523 env46572 = env46573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env46572 == env46573) = true)

theorem identity46573 : scanCanonicalize (H12AffineFastState.compose env46573 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound46573 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46574 : List Nat := [2,4,8,16,0,17,9,5,512,1024,523,4096,9,5124,1,3,5141,523,1024,0,4112,1,16,3,8,16,523,5141,4097,523,1025,0,5,1,5125,513]

theorem envBound46574 : H12AffineFastState.Bounded env46574 := by
  intro p hp
  have h : env46574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46573_46574 : H12AffineEnvironment.transform 4 0 env46573 = env46574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env46573 == env46574) = true)

def env46575 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2493493,499129,8328,65,6705549,2496820,416100,2149429,2102684,6748280,256,21793,46213,2175563]

theorem envBound46575 : H12AffineFastState.Bounded env46575 := by
  intro p hp
  have h : env46575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46452_46575 : H12AffineEnvironment.transform 23 499129 env46452 = env46575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 499129 env46452 == env46575) = true)

def env46576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180272,2493493,499129,8328,65,2396605,2496820,416100,2149429,2102684,2373704,256,21793,46213,2175563]

theorem envBound46576 : H12AffineFastState.Bounded env46576 := by
  intro p hp
  have h : env46576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46575_46576 : H12AffineEnvironment.transform 21 180272 env46575 = env46576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180272 env46575 == env46576) = true)

def env46577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180272,400501,499129,8328,65,295421,395636,416100,56437,1500,272392,256,21793,46213,74251]

theorem envBound46577 : H12AffineFastState.Bounded env46577 := by
  intro p hp
  have h : env46577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46576_46577 : H12AffineEnvironment.transform 20 4160 env46576 = env46577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env46576 == env46577) = true)

theorem identity46577 : scanCanonicalize (H12AffineFastState.compose env46577 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound46577 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,4160,180272,400501,412006,8328,65,295421,395636,416100,56437,1500,272392,256,21793,46213,63188]

theorem envBound46578 : H12AffineFastState.Bounded env46578 := by
  intro p hp
  have h : env46578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46577_46578 : H12AffineEnvironment.transform 15 54495 env46577 = env46578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env46577 == env46578) = true)

def env46579 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4160,180272,400501,412006,8192,65,295285,395636,416100,56437,1364,272392,256,21793,46093,63068]

theorem envBound46579 : H12AffineFastState.Bounded env46579 := by
  intro p hp
  have h : env46579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46578_46579 : H12AffineEnvironment.transform 6 8 env46578 = env46579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46578 == env46579) = true)

theorem identity46579 : scanCanonicalize (H12AffineFastState.compose env46579 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(16+1) ^^^ 5173) := by decide +kernel

theorem selectedBound46579 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env46580 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,5173,262144,1024,32769,4160,54277,264256,286035,8192,65,295285,269633,281937,56437,1364,272392,256,21793,46093,63068]

theorem envBound46580 : H12AffineFastState.Bounded env46580 := by
  intro p hp
  have h : env46580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46579_46580 : H12AffineEnvironment.transform 16 5173 env46579 = env46580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5173 env46579 == env46580) = true)

theorem identity46580 : scanCanonicalize (H12AffineFastState.compose env46580 (packedSelected [0,8,9,10,12,15,17,22,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 56357) := by decide +kernel

theorem selectedBound46580 : packedSelected [0,8,9,10,12,15,17,22,27,28] rootPS < 2^1333 := by decide +kernel

def env46581 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,5173,56357,1024,32769,4160,54277,54373,33142,8192,65,23888,49508,37236,56437,1364,62509,256,21793,46093,63068]

theorem envBound46581 : H12AffineFastState.Bounded env46581 := by
  intro p hp
  have h : env46581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46580_46581 : H12AffineEnvironment.transform 17 56357 env46580 = env46581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56357 env46580 == env46581) = true)

theorem identity46581 : scanCanonicalize (H12AffineFastState.compose env46581 (packedSelected [0,2,4,6,7,9,11,14,17,23] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound46581 : packedSelected [0,2,4,6,7,9,11,14,17,23] rootPS < 2^1333 := by decide +kernel

def env46582 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,32768,41262,5173,43356,1024,32769,4160,41340,41244,33142,8192,65,10281,46109,37236,43276,1364,33108,256,8280,46093,33573]

theorem envBound46582 : H12AffineFastState.Bounded env46582 := by
  intro p hp
  have h : env46582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46581_46582 : H12AffineEnvironment.transform 13 13689 env46581 = env46582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env46581 == env46582) = true)

def env46583 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4160,180272,400501,412006,8193,65,295284,395636,416100,56437,1365,272392,256,21793,46092,63069]

theorem envBound46583 : H12AffineFastState.Bounded env46583 := by
  intro p hp
  have h : env46583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46578_46583 : H12AffineEnvironment.transform 6 9 env46578 = env46583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46578 == env46583) = true)

theorem identity46583 : scanCanonicalize (H12AffineFastState.compose env46583 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(16+1) ^^^ 16448) := by decide +kernel

theorem selectedBound46583 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env46584 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,16448,262144,1024,32769,4160,32880,285749,264486,8193,65,295284,280884,268580,56437,1365,272392,256,21793,46092,63069]

theorem envBound46584 : H12AffineFastState.Bounded env46584 := by
  intro p hp
  have h : env46584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46583_46584 : H12AffineEnvironment.transform 16 16448 env46583 = env46584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env46583 == env46584) = true)

theorem identity46584 : scanCanonicalize (H12AffineFastState.compose env46584 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound46584 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env46585 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,16448,262144,1024,29789,4160,29740,285749,264486,8193,65,292136,280884,268580,10281,1365,272392,256,21793,16464,513]

theorem envBound46585 : H12AffineFastState.Bounded env46585 := by
  intro p hp
  have h : env46585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46584_46585 : H12AffineEnvironment.transform 14 29788 env46584 = env46585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env46584 == env46585) = true)

theorem identity46585 : scanCanonicalize (H12AffineFastState.compose env46585 (packedSelected [2,3,5,6,10,12,15,16,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound46585 : packedSelected [2,3,5,6,10,12,15,16,20] rootPS < 2^1333 := by decide +kernel

def env46586 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,342,16448,262144,1024,21761,4160,21872,285749,264486,349,65,283764,280884,268580,2421,1365,264532,256,21793,16464,513]

theorem envBound46586 : H12AffineFastState.Bounded env46586 := by
  intro p hp
  have h : env46586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46585_46586 : H12AffineEnvironment.transform 12 348 env46585 = env46586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env46585 == env46586) = true)

theorem identity46586 : scanCanonicalize (H12AffineFastState.compose env46586 (packedSelected [0,4,7,9,14,17] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound46586 : packedSelected [0,4,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env46587 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,342,16448,2341,1024,21761,4160,21872,21776,3,349,65,23889,16401,4097,2421,1365,113,256,21793,16464,513]

theorem envBound46587 : H12AffineFastState.Bounded env46587 := by
  intro p hp
  have h : env46587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46586_46587 : H12AffineEnvironment.transform 17 2341 env46586 = env46587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env46586 == env46587) = true)

theorem identity46587 : scanCanonicalize (H12AffineFastState.compose env46587 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46587 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env46588 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,21760,262,16400,2341,1024,21761,4112,21792,21776,3,269,17,23809,16401,4097,2341,1285,33,256,21793,16384,513]

theorem envBound46588 : H12AffineFastState.Bounded env46588 := by
  intro p hp
  have h : env46588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46587_46588 : H12AffineEnvironment.transform 5 16 env46587 = env46588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46587 == env46588) = true)

theorem identity46588 : scanCanonicalize (H12AffineFastState.compose env46588 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound46588 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env46589 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,1,262,5393,2341,1024,0,4112,33,17,3,269,17,2048,5392,4097,2341,1285,33,256,32,5377,513]

theorem envBound46589 : H12AffineFastState.Bounded env46589 := by
  intro p hp
  have h : env46589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46588_46589 : H12AffineEnvironment.transform 13 5377 env46588 = env46589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env46588 == env46589) = true)

theorem identity46589 : scanCanonicalize (H12AffineFastState.compose env46589 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound46589 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46590 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5156,1,35,5172,2048,1024,0,4112,33,17,3,40,17,2048,5173,4097,2048,1056,33,37,32,5156,513]

theorem envBound46590 : H12AffineFastState.Bounded env46590 := by
  intro p hp
  have h : env46590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46589_46590 : H12AffineEnvironment.transform 7 37 env46589 = env46590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env46589 == env46590) = true)

def env46591 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,41,1044,1,35,1028,2048,1024,0,32,33,17,3,40,17,2048,1029,49,2048,1056,33,37,32,1044,513]

theorem envBound46591 : H12AffineFastState.Bounded env46591 := by
  intro p hp
  have h : env46591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46590_46591 : H12AffineEnvironment.transform 11 48 env46590 = env46591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env46590 == env46591) = true)

theorem identity46591 : scanCanonicalize (H12AffineFastState.compose env46591 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1540) := by decide +kernel

theorem selectedBound46591 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46592 : List Nat := [2,4,8,16,32,16,9,37,512,1024,1540,48,41,1044,1,35,1028,1540,1024,0,32,33,17,3,40,17,1540,1029,49,1540,1056,33,37,32,1044,513]

theorem envBound46592 : H12AffineFastState.Bounded env46592 := by
  intro p hp
  have h : env46592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46591_46592 : H12AffineEnvironment.transform 10 1540 env46591 = env46592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env46591 == env46592) = true)

def env46593 : List Nat := [2,4,8,16,32,16,9,37,512,52,560,48,41,32,1,35,48,560,52,0,32,33,17,3,40,17,560,49,49,560,20,33,37,32,32,513]

end H12CloudChart0