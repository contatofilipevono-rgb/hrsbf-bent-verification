import H12CloudChart0Data031

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound7934 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env7935 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,14968,8200,8234,4097,262144,4708,8200,271420,32,5749,35,8225,264241,7732,265748,265748,267829,268820,269844,5681,269845,11340,512]

theorem envBound7935 : H12AffineFastState.Bounded env7935 := by
  intro p hp
  have h : env7935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7934_7935 : H12AffineEnvironment.transform 13 14968 env7934 = env7935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14968 env7934 == env7935) = true)

theorem identity7935 : scanCanonicalize (H12AffineFastState.compose env7935 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound7935 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env7936 : List Nat := [2,4,8,16,32,48,40,37,512,1024,2048,4096,8192,14856,8200,8234,4097,262144,4628,8200,271420,32,5637,35,8225,264241,7732,265748,265748,267829,268820,269844,5681,269845,11324,512]

theorem envBound7936 : H12AffineFastState.Bounded env7936 := by
  intro p hp
  have h : env7936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7935_7936 : H12AffineEnvironment.transform 5 48 env7935 = env7936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env7935 == env7936) = true)

theorem identity7936 : scanCanonicalize (H12AffineFastState.compose env7936 (packedSelected [0,1,3,6] rootPS)) = affineNative (2^(12+1) ^^^ 552) := by decide +kernel

theorem selectedBound7936 : packedSelected [0,1,3,6] rootPS < 2^1333 := by decide +kernel

def env7937 : List Nat := [2,4,8,16,32,48,40,37,512,1024,2048,4096,552,6176,544,514,4097,262144,4628,544,263700,32,5637,35,521,264241,7732,265748,265748,267829,268820,269844,5681,269845,3604,512]

theorem envBound7937 : H12AffineFastState.Bounded env7937 := by
  intro p hp
  have h : env7937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7936_7937 : H12AffineEnvironment.transform 12 552 env7936 = env7937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 552 env7936 == env7937) = true)

theorem identity7937 : scanCanonicalize (H12AffineFastState.compose env7937 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound7937 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env7938 : List Nat := [2,4,8,16,32,48,40,37,512,1024,2048,4096,552,6176,544,514,4097,2080,4628,544,3636,32,5637,35,521,17,7732,1588,1588,7701,4660,5684,5681,5685,3604,512]

theorem envBound7938 : H12AffineFastState.Bounded env7938 := by
  intro p hp
  have h : env7938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7937_7938 : H12AffineEnvironment.transform 17 2080 env7937 = env7938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env7937 == env7938) = true)

theorem identity7938 : scanCanonicalize (H12AffineFastState.compose env7938 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound7938 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env7939 : List Nat := [2,4,8,16,32,48,40,37,27,1024,2048,4096,51,6176,59,25,4097,2080,4111,59,3119,32,5150,35,18,17,7215,1071,1071,7182,4143,5167,5162,5166,3087,27]

theorem envBound7939 : H12AffineFastState.Bounded env7939 := by
  intro p hp
  have h : env7939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7938_7939 : H12AffineEnvironment.transform 8 27 env7938 = env7939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env7938 == env7939) = true)

theorem identity7939 : scanCanonicalize (H12AffineFastState.compose env7939 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 1070) := by decide +kernel

theorem selectedBound7939 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7940 : List Nat := [2,4,8,16,32,48,40,37,27,1024,2048,1070,51,3086,59,25,1071,2080,1057,59,3119,32,48,35,18,17,2049,1071,1071,2080,1025,1,4,0,3087,27]

theorem envBound7940 : H12AffineFastState.Bounded env7940 := by
  intro p hp
  have h : env7940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7939_7940 : H12AffineEnvironment.transform 11 1070 env7939 = env7940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1070 env7939 == env7940) = true)

theorem identity7940 : scanCanonicalize (H12AffineFastState.compose env7940 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound7940 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7941 : List Nat := [2,4,8,16,32,48,40,37,27,1024,16,1070,51,1054,59,25,1071,48,1057,59,1087,32,48,35,18,17,17,1071,1071,48,1025,1,4,0,1055,27]

theorem envBound7941 : H12AffineFastState.Bounded env7941 := by
  intro p hp
  have h : env7941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7940_7941 : H12AffineEnvironment.transform 10 16 env7940 = env7941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env7940 == env7941) = true)

theorem identity7941 : scanCanonicalize (H12AffineFastState.compose env7941 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound7941 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env7942 : List Nat := [2,4,8,16,27,11,19,30,27,1024,16,1045,8,1054,0,25,1044,11,1050,0,1028,27,11,24,18,17,17,1044,1044,11,1025,1,4,0,1055,27]

theorem envBound7942 : H12AffineFastState.Bounded env7942 := by
  intro p hp
  have h : env7942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7941_7942 : H12AffineEnvironment.transform 4 27 env7941 = env7942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env7941 == env7942) = true)

def leafEnv7942 : List Nat := [2,4,8,16,27,11,19,30,27,1024,16,1045,8,1054,0,25,1044,11,1050,0,1028,27,11,24,1051,18,1,17,17,1044,1044,11,1025,1,4,0,30,2,1055,27,1,1028,0]

def active7942 : List Nat := [0,1,2,3,9]

def tree7942 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7942 : H12WitnessSearch.Good tree7942 := H12GlobalWitnessIndex.good

theorem leafIdentity7942 : H12AffineFastState.composeSystem env7942 rootObs = leafEnv7942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7942 rootObs == leafEnv7942) = true)

theorem terminalChecked7942 : H12PackedTerminal.terminalCheckFast leafEnv7942 active7942 tree7942 = true := by decide +kernel

def env7943 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,2097152,33,525636,74076,8225,67108864,67450747,67184474,67184143,67116549,67633428,67114864,525568,67114533,69206080,74282]

theorem envBound7943 : H12AffineFastState.Bounded env7943 := by
  intro p hp
  have h : env7943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7928_7943 : H12AffineEnvironment.transform 21 33 env7928 = env7943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env7928 == env7943) = true)

theorem identity7943 : scanCanonicalize (H12AffineFastState.compose env7943 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(20+1) ^^^ 619038) := by decide +kernel

theorem selectedBound7943 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env7944 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,619038,33,525636,74076,8225,67108864,67450747,67184474,67184143,67116549,67633428,67114864,525568,67114533,67727966,74282]

theorem envBound7944 : H12AffineFastState.Bounded env7944 := by
  intro p hp
  have h : env7944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7943_7944 : H12AffineEnvironment.transform 20 619038 env7943 = env7944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 619038 env7943 == env7944) = true)

theorem identity7944 : scanCanonicalize (H12AffineFastState.compose env7944 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(18+1) ^^^ 339035) := by decide +kernel

theorem selectedBound7944 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env7945 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,339035,8541,286277,33,338207,74076,8225,67108864,67450747,67184474,67184143,67116549,67448143,67114864,338267,67114533,67395077,74282]

theorem envBound7945 : H12AffineFastState.Bounded env7945 := by
  intro p hp
  have h : env7945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7944_7945 : H12AffineEnvironment.transform 18 339035 env7944 = env7945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 339035 env7944 == env7945) = true)

theorem identity7945 : scanCanonicalize (H12AffineFastState.compose env7945 (packedSelected [0,1,3,4,9,13,17,20,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 8000) := by decide +kernel

theorem selectedBound7945 : packedSelected [0,1,3,4,9,13,17,20,24,27,28] rootPS < 2^1333 := by decide +kernel

def env7946 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,8000,78619,8541,16645,33,79455,74076,8225,67108864,67184699,67184474,67184143,67116549,67187215,67114864,79387,67114533,67125573,74282]

theorem envBound7946 : H12AffineFastState.Bounded env7946 := by
  intro p hp
  have h : env7946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7945_7946 : H12AffineEnvironment.transform 17 8000 env7945 = env7946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8000 env7945 == env7946) = true)

theorem identity7946 : scanCanonicalize (H12AffineFastState.compose env7946 (packedSelected [2,3,5,6,7,9,11,12,13,14] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound7946 : packedSelected [2,3,5,6,7,9,11,12,13,14] rootPS < 2^1333 := by decide +kernel

def env7947 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8200,65536,4097,7701,78414,8200,16464,33,79455,73737,8225,67108864,67184699,67184143,67184143,67116549,67187215,67114533,79387,67114533,67125264,74282]

theorem envBound7947 : H12AffineFastState.Bounded env7947 := by
  intro p hp
  have h : env7947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7946_7947 : H12AffineEnvironment.transform 7 85 env7946 = env7947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env7946 == env7947) = true)

theorem identity7947 : scanCanonicalize (H12AffineFastState.compose env7947 (packedSelected [2,3,4,6,7,8,11,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 8234) := by decide +kernel

theorem selectedBound7947 : packedSelected [2,3,4,6,7,8,11,13,15] rootPS < 2^1333 := by decide +kernel

def env7948 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8200,8234,4097,7701,4708,8200,16464,33,5749,35,8225,67108864,67110929,67110437,67110437,67116549,67113509,67114533,5681,67114533,67125264,512]

theorem envBound7948 : H12AffineFastState.Bounded env7948 := by
  intro p hp
  have h : env7948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7947_7948 : H12AffineEnvironment.transform 15 8234 env7947 = env7948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8234 env7947 == env7948) = true)

theorem identity7948 : scanCanonicalize (H12AffineFastState.compose env7948 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(25+1) ^^^ 27773) := by decide +kernel

theorem selectedBound7948 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env7949 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8200,8234,4097,7701,4708,8200,16464,33,5749,35,8225,27773,25708,27224,27224,29304,32344,31320,5681,31320,11373,512]

theorem envBound7949 : H12AffineFastState.Bounded env7949 := by
  intro p hp
  have h : env7949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7948_7949 : H12AffineEnvironment.transform 25 27773 env7948 = env7949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 27773 env7948 == env7949) = true)

theorem identity7949 : scanCanonicalize (H12AffineFastState.compose env7949 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 14937) := by decide +kernel

theorem selectedBound7949 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7950 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,14937,8200,8234,4097,7701,4708,8200,14857,33,5749,35,8225,5668,7733,4097,4097,2081,1025,1,5681,1,11373,512]

theorem envBound7950 : H12AffineFastState.Bounded env7950 := by
  intro p hp
  have h : env7950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7949_7950 : H12AffineEnvironment.transform 13 14937 env7949 = env7950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14937 env7949 == env7950) = true)

theorem identity7950 : scanCanonicalize (H12AffineFastState.compose env7950 (packedSelected [1,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 7212) := by decide +kernel

theorem selectedBound7950 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env7951 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,7212,1653,7204,7174,4097,7701,4708,7204,1573,33,5749,35,7181,5668,7733,4097,4097,2081,1025,1,5681,1,4161,512]

theorem envBound7951 : H12AffineFastState.Bounded env7951 := by
  intro p hp
  have h : env7951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7950_7951 : H12AffineEnvironment.transform 12 7212 env7950 = env7951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7212 env7950 == env7951) = true)

theorem identity7951 : scanCanonicalize (H12AffineFastState.compose env7951 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1583) := by decide +kernel

theorem selectedBound7951 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env7952 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,1583,2563,1653,2571,2601,1582,2106,1099,2571,1573,33,90,35,2594,11,2074,1582,1582,2081,1025,1,30,1,1646,512]

theorem envBound7952 : H12AffineFastState.Bounded env7952 := by
  intro p hp
  have h : env7952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7951_7952 : H12AffineEnvironment.transform 11 1583 env7951 = env7952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1583 env7951 == env7952) = true)

theorem identity7952 : scanCanonicalize (H12AffineFastState.compose env7952 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound7952 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env7953 : List Nat := [2,4,8,16,32,64,40,85,512,1024,528,1583,19,1653,27,57,1582,554,1099,27,1573,33,90,35,50,11,522,1582,1582,561,1025,1,30,1,1646,512]

theorem envBound7953 : H12AffineFastState.Bounded env7953 := by
  intro p hp
  have h : env7953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7952_7953 : H12AffineEnvironment.transform 10 528 env7952 = env7953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env7952 == env7953) = true)

theorem identity7953 : scanCanonicalize (H12AffineFastState.compose env7953 (packedSelected [0,4,11] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound7953 : packedSelected [0,4,11] rootPS < 2^1333 := by decide +kernel

def env7954 : List Nat := [2,4,8,10,32,64,40,79,512,1024,522,1583,9,1647,1,35,1582,554,1099,1,1573,33,64,35,40,11,522,1582,1582,555,1025,1,4,1,1646,512]

theorem envBound7954 : H12AffineFastState.Bounded env7954 := by
  intro p hp
  have h : env7954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7953_7954 : H12AffineEnvironment.transform 3 10 env7953 = env7954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env7953 == env7954) = true)

def env7955 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,2097152,4194304,525637,74077,8224,67108864,71645019,67184474,67184142,71310885,67633429,67114865,525568,71308805,73400416,74282]

theorem envBound7955 : H12AffineFastState.Bounded env7955 := by
  intro p hp
  have h : env7955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7927_7955 : H12AffineEnvironment.transform 6 41 env7927 = env7955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env7927 == env7955) = true)

def env7956 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,2097152,32,525637,74077,8224,67108864,67450747,67184474,67184142,67116549,67633429,67114865,525568,67114533,69206080,74282]

theorem envBound7956 : H12AffineFastState.Bounded env7956 := by
  intro p hp
  have h : env7956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7955_7956 : H12AffineEnvironment.transform 21 32 env7955 = env7956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env7955 == env7956) = true)

theorem identity7956 : scanCanonicalize (H12AffineFastState.compose env7956 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(20+1) ^^^ 619039) := by decide +kernel

theorem selectedBound7956 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env7957 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,619039,32,525637,74077,8224,67108864,67450747,67184474,67184142,67116549,67633429,67114865,525568,67114533,67727967,74282]

theorem envBound7957 : H12AffineFastState.Bounded env7957 := by
  intro p hp
  have h : env7957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7956_7957 : H12AffineEnvironment.transform 20 619039 env7956 = env7957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 619039 env7956 == env7957) = true)

theorem identity7957 : scanCanonicalize (H12AffineFastState.compose env7957 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 7700) := by decide +kernel

theorem selectedBound7957 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env7958 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,7700,524288,8540,619039,32,525637,74077,8224,67108864,67185007,67184474,67184142,67116549,67633429,67114865,525568,67114533,67727967,74282]

theorem envBound7958 : H12AffineFastState.Bounded env7958 := by
  intro p hp
  have h : env7958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7957_7958 : H12AffineEnvironment.transform 17 7700 env7957 = env7958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7700 env7957 == env7958) = true)

theorem identity7958 : scanCanonicalize (H12AffineFastState.compose env7958 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(18+1) ^^^ 78415) := by decide +kernel

theorem selectedBound7958 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env7959 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,7700,78415,8540,16464,32,79626,74077,8224,67108864,67185007,67184474,67184142,67116549,67187546,67114865,79695,67114533,67125264,74282]

theorem envBound7959 : H12AffineFastState.Bounded env7959 := by
  intro p hp
  have h : env7959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7958_7959 : H12AffineEnvironment.transform 18 78415 env7958 = env7959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78415 env7958 == env7959) = true)

theorem identity7959 : scanCanonicalize (H12AffineFastState.compose env7959 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound7959 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env7960 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8200,65536,4097,7700,78415,8200,16464,32,79454,73737,8224,67108864,67184699,67184142,67184142,67116549,67187214,67114533,79387,67114533,67125264,74282]

theorem envBound7960 : H12AffineFastState.Bounded env7960 := by
  intro p hp
  have h : env7960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7959_7960 : H12AffineEnvironment.transform 7 84 env7959 = env7960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env7959 == env7960) = true)

theorem identity7960 : scanCanonicalize (H12AffineFastState.compose env7960 (packedSelected [2,3,4,6,7,8,11,13,15] rootPS)) = affineNative (2^(25+1) ^^^ 79375) := by decide +kernel

theorem selectedBound7960 : packedSelected [2,3,4,6,7,8,11,13,15] rootPS < 2^1333 := by decide +kernel

def env7961 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8200,65536,4097,7700,78415,8200,16464,32,79454,73737,8224,79375,7732,4097,4097,75786,1025,73770,79387,73770,95775,74282]

theorem envBound7961 : H12AffineFastState.Bounded env7961 := by
  intro p hp
  have h : env7961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7960_7961 : H12AffineEnvironment.transform 25 79375 env7960 = env7961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 79375 env7960 == env7961) = true)

theorem identity7961 : scanCanonicalize (H12AffineFastState.compose env7961 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound7961 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env7962 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8200,8235,4097,7700,4708,8200,16464,32,5749,34,8224,5668,7732,4097,4097,2081,1025,1,5680,1,22068,513]

theorem envBound7962 : H12AffineFastState.Bounded env7962 := by
  intro p hp
  have h : env7962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7961_7962 : H12AffineEnvironment.transform 15 8235 env7961 = env7962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env7961 == env7962) = true)

theorem identity7962 : scanCanonicalize (H12AffineFastState.compose env7962 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 1652) := by decide +kernel

theorem selectedBound7962 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env7963 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,1652,8200,8235,4097,7700,4708,8200,1572,32,5749,34,8224,5668,7732,4097,4097,2081,1025,1,5680,1,4160,513]

theorem envBound7963 : H12AffineFastState.Bounded env7963 := by
  intro p hp
  have h : env7963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7962_7963 : H12AffineEnvironment.transform 13 1652 env7962 = env7963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1652 env7962 == env7963) = true)

theorem identity7963 : scanCanonicalize (H12AffineFastState.compose env7963 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound7963 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env7964 : List Nat := [2,4,8,16,32,42,41,62,512,1024,2048,4096,8192,1566,8200,8235,4097,7700,4622,8200,1572,32,5663,34,8224,5668,7732,4097,4097,2081,1025,1,5680,1,4138,513]

theorem envBound7964 : H12AffineFastState.Bounded env7964 := by
  intro p hp
  have h : env7964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7963_7964 : H12AffineEnvironment.transform 5 42 env7963 = env7964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env7963 == env7964) = true)

theorem identity7964 : scanCanonicalize (H12AffineFastState.compose env7964 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 5692) := by decide +kernel

theorem selectedBound7964 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env7965 : List Nat := [2,4,8,16,32,42,41,62,512,1024,2048,4096,5692,1566,5684,5655,4097,7700,4622,5684,1572,32,5663,34,5660,5668,7732,4097,4097,2081,1025,1,5680,1,4138,513]

theorem envBound7965 : H12AffineFastState.Bounded env7965 := by
  intro p hp
  have h : env7965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7964_7965 : H12AffineEnvironment.transform 12 5692 env7964 = env7965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5692 env7964 == env7965) = true)

theorem identity7965 : scanCanonicalize (H12AffineFastState.compose env7965 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3134) := by decide +kernel

theorem selectedBound7965 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env7966 : List Nat := [2,4,8,16,32,42,41,62,512,1024,2048,3134,2562,1566,2570,2601,3135,554,3632,2570,1572,32,2593,34,2594,2586,522,3135,3135,2081,1025,1,2574,1,3092,513]

theorem envBound7966 : H12AffineFastState.Bounded env7966 := by
  intro p hp
  have h : env7966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7965_7966 : H12AffineEnvironment.transform 11 3134 env7965 = env7966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3134 env7965 == env7966) = true)

theorem identity7966 : scanCanonicalize (H12AffineFastState.compose env7966 (packedSelected [2,4,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound7966 : packedSelected [2,4,7,11] rootPS < 2^1333 := by decide +kernel

def env7967 : List Nat := [2,4,8,16,32,42,41,62,512,1024,523,1589,9,1566,1,34,1588,554,1083,1,1572,32,42,34,41,17,522,1588,1588,554,1025,1,5,1,1567,513]

theorem envBound7967 : H12AffineFastState.Bounded env7967 := by
  intro p hp
  have h : env7967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7966_7967 : H12AffineEnvironment.transform 10 523 env7966 = env7967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env7966 == env7967) = true)

theorem identity7967 : scanCanonicalize (H12AffineFastState.compose env7967 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound7967 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7968 : List Nat := [2,4,8,16,26,16,19,4,512,1024,523,1551,9,1566,1,24,1550,528,1025,1,1566,26,16,24,19,17,522,1550,1550,528,1025,1,5,1,1567,513]

theorem envBound7968 : H12AffineFastState.Bounded env7968 := by
  intro p hp
  have h : env7968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7967_7968 : H12AffineEnvironment.transform 4 26 env7967 = env7968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env7967 == env7968) = true)

theorem identity7968 : scanCanonicalize (H12AffineFastState.compose env7968 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound7968 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env7969 : List Nat := [2,4,8,16,26,16,19,4,14,1024,5,1025,9,1040,1,24,1024,30,1025,1,1040,26,16,24,19,17,4,1024,1024,30,1025,1,5,1,1041,15]

theorem envBound7969 : H12AffineFastState.Bounded env7969 := by
  intro p hp
  have h : env7969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7968_7969 : H12AffineEnvironment.transform 8 14 env7968 = env7969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env7968 == env7969) = true)

theorem identity7969 : scanCanonicalize (H12AffineFastState.compose env7969 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 10) := by decide +kernel

theorem selectedBound7969 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7970 : List Nat := [2,4,8,16,26,16,19,4,14,10,5,11,9,26,1,24,10,30,11,1,26,26,16,24,19,17,4,10,10,30,11,1,5,1,27,15]

theorem envBound7970 : H12AffineFastState.Bounded env7970 := by
  intro p hp
  have h : env7970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7969_7970 : H12AffineEnvironment.transform 9 10 env7969 = env7970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 10 env7969 == env7970) = true)

theorem identity7970 : scanCanonicalize (H12AffineFastState.compose env7970 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound7970 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7971 : List Nat := [2,4,8,10,0,10,9,4,14,10,5,11,9,0,1,2,10,4,11,1,0,0,10,2,9,11,4,10,10,4,11,1,5,1,1,15]

theorem envBound7971 : H12AffineFastState.Bounded env7971 := by
  intro p hp
  have h : env7971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7970_7971 : H12AffineEnvironment.transform 3 10 env7970 = env7971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env7970 == env7971) = true)

theorem identity7971 : scanCanonicalize (H12AffineFastState.compose env7971 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound7971 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7972 : List Nat := [2,1,8,10,0,10,9,1,11,10,0,11,9,0,1,2,10,1,11,1,0,0,10,2,9,11,1,10,10,1,11,1,0,1,1,10]

theorem envBound7972 : H12AffineFastState.Bounded env7972 := by
  intro p hp
  have h : env7972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7971_7972 : H12AffineEnvironment.transform 1 1 env7971 = env7972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env7971 == env7972) = true)

def env7973 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,2097152,33,525637,74077,8224,67108864,67450746,67184474,67184142,67116548,67633429,67114865,525568,67114532,69206081,74282]

theorem envBound7973 : H12AffineFastState.Bounded env7973 := by
  intro p hp
  have h : env7973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7955_7973 : H12AffineEnvironment.transform 21 33 env7955 = env7973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env7955 == env7973) = true)

theorem identity7973 : scanCanonicalize (H12AffineFastState.compose env7973 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(25+1) ^^^ 2712942) := by decide +kernel

theorem selectedBound7973 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env7974 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,2097152,33,525637,74077,8224,2712942,2904596,2638388,2638688,2718570,2188411,2716191,525568,2716490,615727,74282]

theorem envBound7974 : H12AffineFastState.Bounded env7974 := by
  intro p hp
  have h : env7974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7973_7974 : H12AffineEnvironment.transform 25 2712942 env7973 = env7974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 2712942 env7973 == env7974) = true)

theorem identity7974 : scanCanonicalize (H12AffineFastState.compose env7974 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(20+1) ^^^ 879967) := by decide +kernel

theorem selectedBound7974 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env7975 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,879967,33,525637,74077,8224,264241,81739,339819,339519,267829,788772,270144,525568,269845,615727,74282]

theorem envBound7975 : H12AffineFastState.Bounded env7975 := by
  intro p hp
  have h : env7975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7974_7975 : H12AffineEnvironment.transform 20 879967 env7974 = env7975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 879967 env7974 == env7975) = true)

def env7976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,524288,8693,2097152,4194304,525804,74229,8329,67108864,71645171,67184475,67184294,71310988,67633597,67114968,525568,71308972,73400521,74283]

theorem envBound7976 : H12AffineFastState.Bounded env7976 := by
  intro p hp
  have h : env7976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7926_7976 : H12AffineEnvironment.transform 23 74229 env7926 = env7976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 74229 env7926 == env7976) = true)

def env7977 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,2097152,4194304,525636,74077,8225,67108864,71645019,67184475,67184142,71310884,67633429,67114864,525568,71308804,73400417,74283]

theorem envBound7977 : H12AffineFastState.Bounded env7977 := by
  intro p hp
  have h : env7977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7976_7977 : H12AffineEnvironment.transform 6 40 env7976 = env7977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env7976 == env7977) = true)

def env7978 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,2097152,32,525636,74077,8225,67108864,67450747,67184475,67184142,67116548,67633429,67114864,525568,67114532,69206081,74283]

theorem envBound7978 : H12AffineFastState.Bounded env7978 := by
  intro p hp
  have h : env7978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7977_7978 : H12AffineEnvironment.transform 21 32 env7977 = env7978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env7977 == env7978) = true)

theorem identity7978 : scanCanonicalize (H12AffineFastState.compose env7978 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(20+1) ^^^ 619039) := by decide +kernel

theorem selectedBound7978 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env7979 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,619039,32,525636,74077,8225,67108864,67450747,67184475,67184142,67116548,67633429,67114864,525568,67114532,67727966,74283]

theorem envBound7979 : H12AffineFastState.Bounded env7979 := by
  intro p hp
  have h : env7979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7978_7979 : H12AffineEnvironment.transform 20 619039 env7978 = env7979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 619039 env7978 == env7979) = true)

theorem identity7979 : scanCanonicalize (H12AffineFastState.compose env7979 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 7701) := by decide +kernel

theorem selectedBound7979 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env7980 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,7701,524288,8541,619039,32,525636,74077,8225,67108864,67185006,67184475,67184142,67116548,67633429,67114864,525568,67114532,67727966,74283]

theorem envBound7980 : H12AffineFastState.Bounded env7980 := by
  intro p hp
  have h : env7980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7979_7980 : H12AffineEnvironment.transform 17 7701 env7979 = env7980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7701 env7979 == env7980) = true)

theorem identity7980 : scanCanonicalize (H12AffineFastState.compose env7980 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound7980 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env7981 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8200,65536,4097,7701,524288,8200,619039,32,525329,73736,8225,67108864,67184699,67184142,67184142,67116548,67633216,67114533,525397,67114532,67727966,74283]

theorem envBound7981 : H12AffineFastState.Bounded env7981 := by
  intro p hp
  have h : env7981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7980_7981 : H12AffineEnvironment.transform 7 85 env7980 = env7981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env7980 == env7981) = true)

theorem identity7981 : scanCanonicalize (H12AffineFastState.compose env7981 (packedSelected [13,17] rootPS)) = affineNative (2^(18+1) ^^^ 4709) := by decide +kernel

theorem selectedBound7981 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env7982 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8200,65536,4097,7701,4709,8200,90234,32,5748,73736,8225,67108864,67184699,67184142,67184142,67116548,67113509,67114533,5680,67114532,67199035,74283]

theorem envBound7982 : H12AffineFastState.Bounded env7982 := by
  intro p hp
  have h : env7982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7981_7982 : H12AffineEnvironment.transform 18 4709 env7981 = env7982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4709 env7981 == env7982) = true)

theorem identity7982 : scanCanonicalize (H12AffineFastState.compose env7982 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound7982 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env7983 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8200,8235,4097,7701,4709,8200,16465,32,5748,35,8225,67108864,67110928,67110437,67110437,67116548,67113509,67114533,5680,67114532,67125264,512]

theorem envBound7983 : H12AffineFastState.Bounded env7983 := by
  intro p hp
  have h : env7983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7982_7983 : H12AffineEnvironment.transform 15 8235 env7982 = env7983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env7982 == env7983) = true)

theorem identity7983 : scanCanonicalize (H12AffineFastState.compose env7983 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(25+1) ^^^ 31256) := by decide +kernel

theorem selectedBound7983 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env7984 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8200,8235,4097,7701,4709,8200,16465,32,5748,35,8225,31256,29192,31805,31805,25628,26685,27709,5680,27708,14856,512]

theorem envBound7984 : H12AffineFastState.Bounded env7984 := by
  intro p hp
  have h : env7984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7983_7984 : H12AffineEnvironment.transform 25 31256 env7983 = env7984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 31256 env7983 == env7984) = true)

theorem identity7984 : scanCanonicalize (H12AffineFastState.compose env7984 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 11341) := by decide +kernel

theorem selectedBound7984 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env7985 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,11341,8200,8235,4097,7701,4709,8200,11292,32,5748,35,8225,5717,7749,4208,4208,2129,1136,112,5680,113,14856,512]

theorem envBound7985 : H12AffineFastState.Bounded env7985 := by
  intro p hp
  have h : env7985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7984_7985 : H12AffineEnvironment.transform 13 11341 env7984 = env7985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11341 env7984 == env7985) = true)

theorem identity7985 : scanCanonicalize (H12AffineFastState.compose env7985 (packedSelected [0,6] rootPS)) = affineNative (2^(12+1) ^^^ 552) := by decide +kernel

theorem selectedBound7985 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env7986 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,552,3685,544,515,4097,7701,4709,544,3636,32,5748,35,521,5717,7749,4208,4208,2129,1136,112,5680,113,6176,512]

theorem envBound7986 : H12AffineFastState.Bounded env7986 := by
  intro p hp
  have h : env7986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7985_7986 : H12AffineEnvironment.transform 12 552 env7985 = env7986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 552 env7985 == env7986) = true)

theorem identity7986 : scanCanonicalize (H12AffineFastState.compose env7986 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound7986 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env7987 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,1589,552,3685,544,515,1588,2080,1104,544,3636,32,65,35,521,96,2160,1605,1605,2129,1136,112,5,113,3605,512]

theorem envBound7987 : H12AffineFastState.Bounded env7987 := by
  intro p hp
  have h : env7987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7986_7987 : H12AffineEnvironment.transform 11 1589 env7986 = env7987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env7986 == env7987) = true)

theorem identity7987 : scanCanonicalize (H12AffineFastState.compose env7987 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound7987 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env7988 : List Nat := [2,4,8,16,32,64,40,85,27,1024,2048,1070,51,3198,59,24,1071,2080,1104,59,3119,32,65,35,18,96,2160,1118,1118,2129,1136,112,5,113,3086,27]

theorem envBound7988 : H12AffineFastState.Bounded env7988 := by
  intro p hp
  have h : env7988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7987_7988 : H12AffineEnvironment.transform 8 27 env7987 = env7988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env7987 == env7988) = true)

theorem identity7988 : scanCanonicalize (H12AffineFastState.compose env7988 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound7988 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7989 : List Nat := [2,4,8,16,32,48,40,37,27,1024,2048,1070,51,3086,59,24,1071,2080,1056,59,3119,32,49,35,18,16,2048,1070,1070,2081,1024,0,5,1,3086,27]

theorem envBound7989 : H12AffineFastState.Bounded env7989 := by
  intro p hp
  have h : env7989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7988_7989 : H12AffineEnvironment.transform 5 48 env7988 = env7989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env7988 == env7989) = true)

theorem identity7989 : scanCanonicalize (H12AffineFastState.compose env7989 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound7989 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7990 : List Nat := [2,4,8,16,32,48,40,37,27,1024,17,1070,51,1055,59,24,1071,49,1056,59,1086,32,49,35,18,16,17,1070,1070,48,1024,0,5,1,1055,27]

theorem envBound7990 : H12AffineFastState.Bounded env7990 := by
  intro p hp
  have h : env7990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7989_7990 : H12AffineEnvironment.transform 10 17 env7989 = env7990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env7989 == env7990) = true)

theorem identity7990 : scanCanonicalize (H12AffineFastState.compose env7990 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound7990 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env7991 : List Nat := [2,4,8,16,27,11,19,30,27,1024,17,1045,8,1055,0,24,1044,10,1051,0,1029,27,10,24,18,16,17,1045,1045,11,1024,0,5,1,1055,27]

theorem envBound7991 : H12AffineFastState.Bounded env7991 := by
  intro p hp
  have h : env7991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7990_7991 : H12AffineEnvironment.transform 4 27 env7990 = env7991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env7990 == env7991) = true)

def leafEnv7991 : List Nat := [2,4,8,16,27,11,19,30,27,1024,17,1045,8,1055,0,24,1044,10,1051,0,1029,27,10,24,1051,18,1,16,17,1045,1045,11,1024,0,5,1,31,3,1055,27,1,1028,0]

def active7991 : List Nat := [0,1,2,3,9]

def tree7991 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7991 : H12WitnessSearch.Good tree7991 := H12GlobalWitnessIndex.good

theorem leafIdentity7991 : H12AffineFastState.composeSystem env7991 rootObs = leafEnv7991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7991 rootObs == leafEnv7991) = true)

theorem terminalChecked7991 : H12PackedTerminal.terminalCheckFast leafEnv7991 active7991 tree7991 = true := by decide +kernel

def env7992 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,2097152,33,525636,74077,8225,67108864,67450746,67184475,67184142,67116549,67633429,67114864,525568,67114533,69206080,74283]

theorem envBound7992 : H12AffineFastState.Bounded env7992 := by
  intro p hp
  have h : env7992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7977_7992 : H12AffineEnvironment.transform 21 33 env7977 = env7992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env7977 == env7992) = true)

theorem identity7992 : scanCanonicalize (H12AffineFastState.compose env7992 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(25+1) ^^^ 2712942) := by decide +kernel

theorem selectedBound7992 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env7993 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,2097152,33,525636,74077,8225,2712942,2904596,2638389,2638688,2718571,2188411,2716190,525568,2716491,615726,74283]

theorem envBound7993 : H12AffineFastState.Bounded env7993 := by
  intro p hp
  have h : env7993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7992_7993 : H12AffineEnvironment.transform 25 2712942 env7992 = env7993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 2712942 env7992 == env7993) = true)

theorem identity7993 : scanCanonicalize (H12AffineFastState.compose env7993 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(20+1) ^^^ 879966) := by decide +kernel

theorem selectedBound7993 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env7994 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,879966,33,525636,74077,8225,264240,81738,339819,339518,267829,788773,270144,525568,269845,615726,74283]

theorem envBound7994 : H12AffineFastState.Bounded env7994 := by
  intro p hp
  have h : env7994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7993_7994 : H12AffineEnvironment.transform 20 879966 env7993 = env7994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 879966 env7993 == env7994) = true)

theorem identity7994 : scanCanonicalize (H12AffineFastState.compose env7994 (packedSelected [0,4,5,8,9,10,13,17,19,20,24,27,28] rootPS)) = affineNative (2^(18+1) ^^^ 78619) := by decide +kernel

theorem selectedBound7994 : packedSelected [0,4,5,8,9,10,13,17,19,20,24,27,28] rootPS < 2^1333 := by decide +kernel

def env7995 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,78619,8541,286277,33,79455,74077,8225,264240,81738,339819,339518,267829,342590,270144,79387,269845,22069,74283]

theorem envBound7995 : H12AffineFastState.Bounded env7995 := by
  intro p hp
  have h : env7995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7994_7995 : H12AffineEnvironment.transform 18 78619 env7994 = env7995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78619 env7994 == env7995) = true)

theorem identity7995 : scanCanonicalize (H12AffineFastState.compose env7995 (packedSelected [1,3,12,13,14,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound7995 : packedSelected [1,3,12,13,14,15,17] rootPS < 2^1333 := by decide +kernel

def env7996 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,8574,4436,262144,4709,8541,286277,33,5921,35,8225,264240,7732,265749,266048,267829,269120,270144,5989,269845,22069,853]

theorem envBound7996 : H12AffineFastState.Bounded env7996 := by
  intro p hp
  have h : env7996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7995_7996 : H12AffineEnvironment.transform 15 8574 env7995 = env7996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env7995 == env7996) = true)

theorem identity7996 : scanCanonicalize (H12AffineFastState.compose env7996 (packedSelected [0,2,3,4,5,6,11,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound7996 : packedSelected [0,2,3,4,5,6,11,12,13] rootPS < 2^1333 := by decide +kernel

def env7997 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,8574,4436,2080,4709,8541,22117,33,5921,35,8225,16,7732,1589,1888,7701,4960,5984,5989,5685,22069,853]

theorem envBound7997 : H12AffineFastState.Bounded env7997 := by
  intro p hp
  have h : env7997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7996_7997 : H12AffineEnvironment.transform 17 2080 env7996 = env7997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env7996 == env7997) = true)

theorem identity7997 : scanCanonicalize (H12AffineFastState.compose env7997 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound7997 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env7998 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8200,8235,4097,2080,4709,8200,22117,33,5748,35,8225,16,7732,1589,1589,7701,4661,5685,5680,5685,22069,512]

theorem envBound7998 : H12AffineFastState.Bounded env7998 := by
  intro p hp
  have h : env7998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7997_7998 : H12AffineEnvironment.transform 7 85 env7997 = env7998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env7997 == env7998) = true)

theorem identity7998 : scanCanonicalize (H12AffineFastState.compose env7998 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 11293) := by decide +kernel

theorem selectedBound7998 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env7999 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,11293,8200,8235,4097,2080,4709,8200,14968,33,5748,35,8225,16,7732,1589,1589,7701,4661,5685,5680,5685,14888,512]

theorem envBound7999 : H12AffineFastState.Bounded env7999 := by
  intro p hp
  have h : env7999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7998_7999 : H12AffineEnvironment.transform 13 11293 env7998 = env7999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11293 env7998 == env7999) = true)

theorem identity7999 : scanCanonicalize (H12AffineFastState.compose env7999 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 2067) := by decide +kernel

theorem selectedBound7999 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env8000 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,2067,1038,2075,2104,4097,2080,4709,2075,4715,33,5748,35,2098,16,7732,1589,1589,7701,4661,5685,5680,5685,4667,512]

theorem envBound8000 : H12AffineFastState.Bounded env8000 := by
  intro p hp
  have h : env8000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7999_8000 : H12AffineEnvironment.transform 12 2067 env7999 = env8000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2067 env7999 == env8000) = true)

theorem identity8000 : scanCanonicalize (H12AffineFastState.compose env8000 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound8000 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8001 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,1589,2067,1038,2075,2104,1588,2080,1104,2075,1118,33,65,35,2098,16,2049,1589,1589,2080,1024,0,5,0,1038,512]

theorem envBound8001 : H12AffineFastState.Bounded env8001 := by
  intro p hp
  have h : env8001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8000_8001 : H12AffineEnvironment.transform 11 1589 env8000 = env8001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env8000 == env8001) = true)

theorem identity8001 : scanCanonicalize (H12AffineFastState.compose env8001 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 122) := by decide +kernel

theorem selectedBound8001 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8002 : List Nat := [2,4,8,16,32,64,40,85,122,1024,2048,1103,2067,1038,2075,2104,1102,2080,1104,2075,1118,33,65,35,2098,16,2049,1103,1103,2080,1024,0,5,0,1038,122]

theorem envBound8002 : H12AffineFastState.Bounded env8002 := by
  intro p hp
  have h : env8002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8001_8002 : H12AffineEnvironment.transform 8 122 env8001 = env8002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 122 env8001 == env8002) = true)

def env8003 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,2097152,4194304,525637,74076,8224,67108864,71645018,67184475,67184143,71310885,67633428,67114865,525568,71308805,73400416,74283]

theorem envBound8003 : H12AffineFastState.Bounded env8003 := by
  intro p hp
  have h : env8003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7976_8003 : H12AffineEnvironment.transform 6 41 env7976 = env8003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env7976 == env8003) = true)

def env8004 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,2097152,32,525637,74076,8224,67108864,67450746,67184475,67184143,67116549,67633428,67114865,525568,67114533,69206080,74283]

theorem envBound8004 : H12AffineFastState.Bounded env8004 := by
  intro p hp
  have h : env8004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8003_8004 : H12AffineEnvironment.transform 21 32 env8003 = env8004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env8003 == env8004) = true)

theorem identity8004 : scanCanonicalize (H12AffineFastState.compose env8004 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(25+1) ^^^ 2712942) := by decide +kernel

theorem selectedBound8004 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8005 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,2097152,32,525637,74076,8224,2712942,2904596,2638389,2638689,2718571,2188410,2716191,525568,2716491,615726,74283]

theorem envBound8005 : H12AffineFastState.Bounded env8005 := by
  intro p hp
  have h : env8005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8004_8005 : H12AffineEnvironment.transform 25 2712942 env8004 = env8005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 2712942 env8004 == env8005) = true)

theorem identity8005 : scanCanonicalize (H12AffineFastState.compose env8005 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(20+1) ^^^ 286480) := by decide +kernel

theorem selectedBound8005 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env8006 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,286480,32,525637,74076,8224,866942,527620,793893,793713,861307,342890,863503,525568,863323,615726,74283]

theorem envBound8006 : H12AffineFastState.Bounded env8006 := by
  intro p hp
  have h : env8006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8005_8006 : H12AffineEnvironment.transform 20 286480 env8005 = env8006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 286480 env8005 == env8006) = true)

theorem identity8006 : scanCanonicalize (H12AffineFastState.compose env8006 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(18+1) ^^^ 78415) := by decide +kernel

theorem selectedBound8006 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env8007 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,78415,8540,286480,32,79626,74076,8224,264241,81739,339818,339518,267828,342890,270144,79695,269844,22369,74283]

theorem envBound8007 : H12AffineFastState.Bounded env8007 := by
  intro p hp
  have h : env8007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8006_8007 : H12AffineEnvironment.transform 18 78415 env8006 = env8007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78415 env8006 == env8007) = true)

theorem identity8007 : scanCanonicalize (H12AffineFastState.compose env8007 (packedSelected [0,1,3,5,7,8,10,13,17,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound8007 : packedSelected [0,1,3,5,7,8,10,13,17,19,20] rootPS < 2^1333 := by decide +kernel

def env8008 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,78415,8200,286276,32,79454,73736,8224,264241,81439,339518,339518,267828,342590,269844,79387,269844,22069,74283]

theorem envBound8008 : H12AffineFastState.Bounded env8008 := by
  intro p hp
  have h : env8008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8007_8008 : H12AffineEnvironment.transform 7 84 env8007 = env8008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env8007 == env8008) = true)

theorem identity8008 : scanCanonicalize (H12AffineFastState.compose env8008 (packedSelected [1,2,4,6,7,8,11,12,13,14] rootPS)) = affineNative (2^(17+1) ^^^ 7701) := by decide +kernel

theorem selectedBound8008 : packedSelected [1,2,4,6,7,8,11,12,13,14] rootPS < 2^1333 := by decide +kernel

def env8009 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8200,65536,4097,7701,78415,8200,16465,32,79454,73736,8224,5668,81439,77867,77867,2081,74795,1,79387,1,22069,74283]

theorem envBound8009 : H12AffineFastState.Bounded env8009 := by
  intro p hp
  have h : env8009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8008_8009 : H12AffineEnvironment.transform 17 7701 env8008 = env8009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7701 env8008 == env8009) = true)

theorem identity8009 : scanCanonicalize (H12AffineFastState.compose env8009 (packedSelected [1,2,3] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound8009 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env8010 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8200,8235,4097,7701,4708,8200,16465,32,5749,35,8224,5668,7732,4096,4096,2081,1024,1,5680,1,22069,512]

theorem envBound8010 : H12AffineFastState.Bounded env8010 := by
  intro p hp
  have h : env8010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8009_8010 : H12AffineEnvironment.transform 15 8235 env8009 = env8010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env8009 == env8010) = true)

theorem identity8010 : scanCanonicalize (H12AffineFastState.compose env8010 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound8010 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env8011 : List Nat := [2,4,8,16,32,42,41,62,512,1024,2048,4096,8192,16384,8200,8235,4097,7701,4622,8200,16443,32,5663,35,8224,5668,7732,4096,4096,2081,1024,1,5680,1,22069,512]

theorem envBound8011 : H12AffineFastState.Bounded env8011 := by
  intro p hp
  have h : env8011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8010_8011 : H12AffineEnvironment.transform 5 42 env8010 = env8011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env8010 == env8011) = true)

def env8012 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,2097152,33,525637,74076,8224,67108864,67450747,67184475,67184143,67116548,67633428,67114865,525568,67114532,69206081,74283]

theorem envBound8012 : H12AffineFastState.Bounded env8012 := by
  intro p hp
  have h : env8012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8003_8012 : H12AffineEnvironment.transform 21 33 env8003 = env8012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env8003 == env8012) = true)

theorem identity8012 : scanCanonicalize (H12AffineFastState.compose env8012 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(20+1) ^^^ 619038) := by decide +kernel

theorem selectedBound8012 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8013 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,619038,33,525637,74076,8224,67108864,67450747,67184475,67184143,67116548,67633428,67114865,525568,67114532,67727967,74283]

theorem envBound8013 : H12AffineFastState.Bounded env8013 := by
  intro p hp
  have h : env8013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8012_8013 : H12AffineEnvironment.transform 20 619038 env8012 = env8013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 619038 env8012 == env8013) = true)

theorem identity8013 : scanCanonicalize (H12AffineFastState.compose env8013 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(18+1) ^^^ 339034) := by decide +kernel

theorem selectedBound8013 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env8014 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,339034,8540,286276,33,338207,74076,8224,67108864,67450747,67184475,67184143,67116548,67448142,67114865,338266,67114532,67395077,74283]

theorem envBound8014 : H12AffineFastState.Bounded env8014 := by
  intro p hp
  have h : env8014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8013_8014 : H12AffineEnvironment.transform 18 339034 env8013 = env8014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 339034 env8013 == env8014) = true)

def env8015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,524288,8693,2097152,4194304,525804,16777216,8329,67108864,134217728,138678441,138678612,151259274,84484168,155451870,525568,151257258,73400521,16778206]

theorem envBound8015 : H12AffineFastState.Bounded env8015 := by
  intro p hp
  have h : env8015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7924_8015 : H12AffineEnvironment.transform 27 138678441 env7924 = env8015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 138678441 env7924 == env8015) = true)

theorem identity8015 : scanCanonicalize (H12AffineFastState.compose env8015 (packedSelected [9,14,22] rootPS)) = affineNative (2^(26+1) ^^^ 88348666) := by decide +kernel

theorem selectedBound8015 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env8016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,524288,8693,2097152,4194304,525804,16777216,8329,67108864,88348666,83887955,83887790,71311216,84484168,67114532,525568,71309136,73400521,16778206]

theorem envBound8016 : H12AffineFastState.Bounded env8016 := by
  intro p hp
  have h : env8016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8015_8016 : H12AffineEnvironment.transform 26 88348666 env8015 = env8016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 88348666 env8015 == env8016) = true)

def env8017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,524288,8693,2097152,4194304,525804,74228,8329,67108864,71644686,67184295,67184474,71311216,67633596,67114532,525568,71309136,73400521,74282]

theorem envBound8017 : H12AffineFastState.Bounded env8017 := by
  intro p hp
  have h : env8017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8016_8017 : H12AffineEnvironment.transform 23 74228 env8016 = env8017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 74228 env8016 == env8017) = true)

def env8018 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,2097152,4194304,525636,74076,8225,67108864,71644686,67184143,67184474,71311216,67633428,67114532,525568,71309136,73400417,74282]

theorem envBound8018 : H12AffineFastState.Bounded env8018 := by
  intro p hp
  have h : env8018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8017_8018 : H12AffineEnvironment.transform 6 40 env8017 = env8018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env8017 == env8018) = true)

def env8019 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,2097152,32,525636,74076,8225,67108864,67450414,67184143,67184474,67116880,67633428,67114532,525568,67114864,69206081,74282]

theorem envBound8019 : H12AffineFastState.Bounded env8019 := by
  intro p hp
  have h : env8019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8018_8019 : H12AffineEnvironment.transform 21 32 env8018 = env8019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env8018 == env8019) = true)

theorem identity8019 : scanCanonicalize (H12AffineFastState.compose env8019 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(25+1) ^^^ 2712943) := by decide +kernel

theorem selectedBound8019 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8020 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,2097152,32,525636,74076,8225,2712943,2904897,2638688,2638389,2718271,2188411,2716491,525568,2716191,615726,74282]

theorem envBound8020 : H12AffineFastState.Bounded env8020 := by
  intro p hp
  have h : env8020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8019_8020 : H12AffineEnvironment.transform 25 2712943 env8019 = env8020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 2712943 env8019 == env8020) = true)

theorem identity8020 : scanCanonicalize (H12AffineFastState.compose env8020 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(20+1) ^^^ 286276) := by decide +kernel

theorem selectedBound8020 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env8021 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,286276,32,525636,74076,8225,867115,527621,793892,793713,861307,342591,863503,525568,863323,615726,74282]

theorem envBound8021 : H12AffineFastState.Bounded env8021 := by
  intro p hp
  have h : env8021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8020_8021 : H12AffineEnvironment.transform 20 286276 env8020 = env8021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 286276 env8020 == env8021) = true)

theorem identity8021 : scanCanonicalize (H12AffineFastState.compose env8021 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(18+1) ^^^ 78619) := by decide +kernel

theorem selectedBound8021 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env8022 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,78619,8541,286276,32,79455,74076,8225,264240,81438,339519,339818,268128,342591,269844,79387,270144,22069,74282]

theorem envBound8022 : H12AffineFastState.Bounded env8022 := by
  intro p hp
  have h : env8022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8021_8022 : H12AffineEnvironment.transform 18 78619 env8021 = env8022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78619 env8021 == env8022) = true)

theorem identity8022 : scanCanonicalize (H12AffineFastState.compose env8022 (packedSelected [0,1,3,5,7,8,10,13,17,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound8022 : packedSelected [0,1,3,5,7,8,10,13,17,19,20] rootPS < 2^1333 := by decide +kernel

def env8023 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,16384,8201,65536,4096,262144,78415,8201,286276,32,79455,73736,8225,264240,81438,339519,339518,267828,342591,269844,79387,269844,22069,74282]

theorem envBound8023 : H12AffineFastState.Bounded env8023 := by
  intro p hp
  have h : env8023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8022_8023 : H12AffineEnvironment.transform 7 84 env8022 = env8023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env8022 == env8023) = true)

theorem identity8023 : scanCanonicalize (H12AffineFastState.compose env8023 (packedSelected [1,2,4,6,7,8,11,12,13,14] rootPS)) = affineNative (2^(17+1) ^^^ 81470) := by decide +kernel

theorem selectedBound8023 : packedSelected [1,2,4,6,7,8,11,12,13,14] rootPS < 2^1333 := by decide +kernel

def env8024 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,16384,8201,65536,4096,81470,78415,8201,90234,32,79455,73736,8225,79374,81438,4097,4096,75786,1025,73770,79387,73770,22069,74282]

theorem envBound8024 : H12AffineFastState.Bounded env8024 := by
  intro p hp
  have h : env8024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8023_8024 : H12AffineEnvironment.transform 17 81470 env8023 = env8024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 81470 env8023 == env8024) = true)

theorem identity8024 : scanCanonicalize (H12AffineFastState.compose env8024 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound8024 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env8025 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,16384,8201,8235,4096,7701,4708,8201,16465,32,5748,35,8225,5669,7733,4097,4096,2081,1025,1,5680,1,22069,513]

theorem envBound8025 : H12AffineFastState.Bounded env8025 := by
  intro p hp
  have h : env8025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8024_8025 : H12AffineEnvironment.transform 15 8235 env8024 = env8025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env8024 == env8025) = true)

theorem identity8025 : scanCanonicalize (H12AffineFastState.compose env8025 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 1652) := by decide +kernel

theorem selectedBound8025 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env8026 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,1652,8201,8235,4096,7701,4708,8201,1573,32,5748,35,8225,5669,7733,4097,4096,2081,1025,1,5680,1,4161,513]

theorem envBound8026 : H12AffineFastState.Bounded env8026 := by
  intro p hp
  have h : env8026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8025_8026 : H12AffineEnvironment.transform 13 1652 env8025 = env8026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1652 env8025 == env8026) = true)

theorem identity8026 : scanCanonicalize (H12AffineFastState.compose env8026 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1583) := by decide +kernel

theorem selectedBound8026 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env8027 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,1583,8192,1652,8201,8235,1583,2106,1099,8201,1573,32,91,35,8225,10,2074,1582,1583,2081,1025,1,31,1,1646,513]

theorem envBound8027 : H12AffineFastState.Bounded env8027 := by
  intro p hp
  have h : env8027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8026_8027 : H12AffineEnvironment.transform 11 1583 env8026 = env8027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1583 env8026 == env8027) = true)

theorem identity8027 : scanCanonicalize (H12AffineFastState.compose env8027 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound8027 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env8028 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,1583,9,1652,0,34,1583,2106,1099,0,1573,32,91,35,40,10,2074,1582,1583,2081,1025,1,31,1,1646,513]

theorem envBound8028 : H12AffineFastState.Bounded env8028 := by
  intro p hp
  have h : env8028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8027_8028 : H12AffineEnvironment.transform 12 9 env8027 = env8028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env8027 == env8028) = true)

theorem identity8028 : scanCanonicalize (H12AffineFastState.compose env8028 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound8028 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env8029 : List Nat := [2,4,8,16,32,64,40,84,512,1024,529,1583,9,1652,0,34,1583,555,1099,0,1573,32,91,35,40,10,523,1582,1583,560,1025,1,31,1,1646,513]

theorem envBound8029 : H12AffineFastState.Bounded env8029 := by
  intro p hp
  have h : env8029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8028_8029 : H12AffineEnvironment.transform 10 529 env8028 = env8029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env8028 == env8029) = true)

theorem identity8029 : scanCanonicalize (H12AffineFastState.compose env8029 (packedSelected [13] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound8029 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env8030 : List Nat := [2,4,8,10,32,64,40,78,512,1024,523,1583,9,1646,0,34,1583,555,1099,0,1573,32,65,35,40,10,523,1582,1583,554,1025,1,5,1,1646,513]

theorem envBound8030 : H12AffineFastState.Bounded env8030 := by
  intro p hp
  have h : env8030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8029_8030 : H12AffineEnvironment.transform 3 10 env8029 = env8030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env8029 == env8030) = true)

theorem identity8030 : scanCanonicalize (H12AffineFastState.compose env8030 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound8030 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8031 : List Nat := [2,4,8,10,32,11,40,5,512,1024,523,1583,9,1573,0,34,1583,555,1024,0,1573,32,10,35,40,10,523,1582,1583,554,1025,1,5,1,1573,513]

theorem envBound8031 : H12AffineFastState.Bounded env8031 := by
  intro p hp
  have h : env8031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8030_8031 : H12AffineEnvironment.transform 5 11 env8030 = env8031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env8030 == env8031) = true)

theorem identity8031 : scanCanonicalize (H12AffineFastState.compose env8031 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 46) := by decide +kernel

theorem selectedBound8031 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env8032 : List Nat := [2,4,8,10,32,11,40,5,46,1024,37,1025,9,1035,0,34,1025,5,1024,0,1035,32,10,35,40,10,37,1024,1025,4,1025,1,5,1,1035,47]

theorem envBound8032 : H12AffineFastState.Bounded env8032 := by
  intro p hp
  have h : env8032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8031_8032 : H12AffineEnvironment.transform 8 46 env8031 = env8032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 46 env8031 == env8032) = true)

theorem identity8032 : scanCanonicalize (H12AffineFastState.compose env8032 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 11) := by decide +kernel

theorem selectedBound8032 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env8033 : List Nat := [2,4,8,10,32,11,40,5,46,11,37,10,9,0,0,34,10,5,11,0,0,32,10,35,40,10,37,11,10,4,10,1,5,1,0,47]

theorem envBound8033 : H12AffineFastState.Bounded env8033 := by
  intro p hp
  have h : env8033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8032_8033 : H12AffineEnvironment.transform 9 11 env8032 = env8033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 11 env8032 == env8033) = true)

theorem identity8033 : scanCanonicalize (H12AffineFastState.compose env8033 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8033 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env8034 : List Nat := [2,4,8,10,0,11,8,5,14,11,5,10,9,0,0,2,10,5,11,0,0,0,10,3,8,10,5,11,10,4,10,1,5,1,0,15]

theorem envBound8034 : H12AffineFastState.Bounded env8034 := by
  intro p hp
  have h : env8034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8033_8034 : H12AffineEnvironment.transform 4 0 env8033 = env8034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8033 == env8034) = true)

theorem identity8034 : scanCanonicalize (H12AffineFastState.compose env8034 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound8034 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8035 : List Nat := [2,0,8,10,0,11,8,1,10,11,1,10,9,0,0,2,10,1,11,0,0,0,10,3,8,10,1,11,10,0,10,1,1,1,0,11]

theorem envBound8035 : H12AffineFastState.Bounded env8035 := by
  intro p hp
  have h : env8035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8034_8035 : H12AffineEnvironment.transform 1 0 env8034 = env8035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env8034 == env8035) = true)

def env8036 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,2097152,33,525636,74076,8225,67108864,67450415,67184143,67184474,67116881,67633428,67114532,525568,67114865,69206080,74282]

theorem envBound8036 : H12AffineFastState.Bounded env8036 := by
  intro p hp
  have h : env8036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8018_8036 : H12AffineEnvironment.transform 21 33 env8018 = env8036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env8018 == env8036) = true)

theorem identity8036 : scanCanonicalize (H12AffineFastState.compose env8036 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(20+1) ^^^ 619339) := by decide +kernel

theorem selectedBound8036 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8037 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,619339,33,525636,74076,8225,67108864,67450415,67184143,67184474,67116881,67633428,67114532,525568,67114865,67728139,74282]

theorem envBound8037 : H12AffineFastState.Bounded env8037 := by
  intro p hp
  have h : env8037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8036_8037 : H12AffineEnvironment.transform 20 619339 env8036 = env8037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 619339 env8036 == env8037) = true)

theorem identity8037 : scanCanonicalize (H12AffineFastState.compose env8037 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(18+1) ^^^ 339035) := by decide +kernel

theorem selectedBound8037 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env8038 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,339035,8541,286480,33,338207,74076,8225,67108864,67450415,67184143,67184474,67116881,67448143,67114532,338267,67114865,67395408,74282]

theorem envBound8038 : H12AffineFastState.Bounded env8038 := by
  intro p hp
  have h : env8038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8037_8038 : H12AffineEnvironment.transform 18 339035 env8037 = env8038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 339035 env8037 == env8038) = true)

def env8039 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,2097152,4194304,525637,74077,8224,67108864,71644686,67184142,67184474,71311216,67633429,67114532,525568,71309136,73400416,74282]

theorem envBound8039 : H12AffineFastState.Bounded env8039 := by
  intro p hp
  have h : env8039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8017_8039 : H12AffineEnvironment.transform 6 41 env8017 = env8039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env8017 == env8039) = true)

def env8040 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,2097152,32,525637,74077,8224,67108864,67450414,67184142,67184474,67116880,67633429,67114532,525568,67114864,69206080,74282]

theorem envBound8040 : H12AffineFastState.Bounded env8040 := by
  intro p hp
  have h : env8040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8039_8040 : H12AffineEnvironment.transform 21 32 env8039 = env8040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env8039 == env8040) = true)

theorem identity8040 : scanCanonicalize (H12AffineFastState.compose env8040 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(20+1) ^^^ 619339) := by decide +kernel

theorem selectedBound8040 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8041 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,619339,32,525637,74077,8224,67108864,67450414,67184142,67184474,67116880,67633429,67114532,525568,67114864,67728139,74282]

theorem envBound8041 : H12AffineFastState.Bounded env8041 := by
  intro p hp
  have h : env8041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8040_8041 : H12AffineEnvironment.transform 20 619339 env8040 = env8041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 619339 env8040 == env8041) = true)

theorem identity8041 : scanCanonicalize (H12AffineFastState.compose env8041 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 8001) := by decide +kernel

theorem selectedBound8041 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env8042 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,8001,524288,8540,619339,32,525637,74077,8224,67108864,67185007,67184142,67184474,67116880,67633429,67114532,525568,67114864,67728139,74282]

theorem envBound8042 : H12AffineFastState.Bounded env8042 := by
  intro p hp
  have h : env8042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8041_8042 : H12AffineEnvironment.transform 17 8001 env8041 = env8042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8001 env8041 == env8042) = true)

theorem identity8042 : scanCanonicalize (H12AffineFastState.compose env8042 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound8042 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env8043 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8201,65536,4096,7700,524288,8201,619038,32,525328,73736,8224,67108864,67184698,67184142,67184143,67116549,67633216,67114532,525397,67114533,67727966,74282]

theorem envBound8043 : H12AffineFastState.Bounded env8043 := by
  intro p hp
  have h : env8043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8042_8043 : H12AffineEnvironment.transform 7 85 env8042 = env8043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env8042 == env8043) = true)

theorem identity8043 : scanCanonicalize (H12AffineFastState.compose env8043 (packedSelected [13,17] rootPS)) = affineNative (2^(18+1) ^^^ 4708) := by decide +kernel

theorem selectedBound8043 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8044 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8201,65536,4096,7700,4708,8201,90234,32,5748,73736,8224,67108864,67184698,67184142,67184143,67116549,67113508,67114532,5681,67114533,67199034,74282]

theorem envBound8044 : H12AffineFastState.Bounded env8044 := by
  intro p hp
  have h : env8044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8043_8044 : H12AffineEnvironment.transform 18 4708 env8043 = env8044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4708 env8043 == env8044) = true)

theorem identity8044 : scanCanonicalize (H12AffineFastState.compose env8044 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 8234) := by decide +kernel

theorem selectedBound8044 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env8045 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8201,8234,4096,7700,4708,8201,16464,32,5748,34,8224,67108864,67110928,67110436,67110437,67116549,67113508,67114532,5681,67114533,67125264,512]

theorem envBound8045 : H12AffineFastState.Bounded env8045 := by
  intro p hp
  have h : env8045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8044_8045 : H12AffineEnvironment.transform 15 8234 env8044 = env8045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8234 env8044 == env8045) = true)

theorem identity8045 : scanCanonicalize (H12AffineFastState.compose env8045 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(25+1) ^^^ 27693) := by decide +kernel

theorem selectedBound8045 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env8046 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8201,8234,4096,7700,4708,8201,16464,32,5748,34,8224,27693,25661,27145,27144,29224,32265,31241,5681,31240,11325,512]

theorem envBound8046 : H12AffineFastState.Bounded env8046 := by
  intro p hp
  have h : env8046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8045_8046 : H12AffineEnvironment.transform 25 27693 env8045 = env8046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 27693 env8045 == env8046) = true)

theorem identity8046 : scanCanonicalize (H12AffineFastState.compose env8046 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 14969) := by decide +kernel

theorem selectedBound8046 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env8047 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,14969,8201,8234,4096,7700,4708,8201,14889,32,5748,34,8224,5716,7748,4208,4209,2129,1136,112,5681,113,11325,512]

theorem envBound8047 : H12AffineFastState.Bounded env8047 := by
  intro p hp
  have h : env8047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8046_8047 : H12AffineEnvironment.transform 13 14969 env8046 = env8047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14969 env8046 == env8047) = true)

theorem identity8047 : scanCanonicalize (H12AffineFastState.compose env8047 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 1604) := by decide +kernel

theorem selectedBound8047 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env8048 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,1604,8192,11325,8201,8234,1604,2128,1056,8201,11373,32,48,34,8224,16,2048,1588,1589,2129,1136,112,117,113,11325,512]

theorem envBound8048 : H12AffineFastState.Bounded env8048 := by
  intro p hp
  have h : env8048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8047_8048 : H12AffineEnvironment.transform 11 1604 env8047 = env8048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1604 env8047 == env8048) = true)

theorem identity8048 : scanCanonicalize (H12AffineFastState.compose env8048 (packedSelected [1,2,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound8048 : packedSelected [1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env8049 : List Nat := [2,4,8,16,32,10,41,31,512,1024,2048,1550,8192,11325,8201,8234,1550,2074,1056,8201,11303,32,48,34,8224,16,2048,1588,1589,2075,1082,58,63,59,11325,512]

theorem envBound8049 : H12AffineFastState.Bounded env8049 := by
  intro p hp
  have h : env8049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8048_8049 : H12AffineEnvironment.transform 5 10 env8048 = env8049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env8048 == env8049) = true)

theorem identity8049 : scanCanonicalize (H12AffineFastState.compose env8049 (packedSelected [1,2,4,10] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound8049 : packedSelected [1,2,4,10] rootPS < 2^1333 := by decide +kernel

def env8050 : List Nat := [2,4,8,16,26,10,19,31,512,1024,2048,1550,8192,11271,8201,8208,1550,2074,1050,8201,11293,26,10,24,8218,16,2048,1550,1551,2075,1024,0,5,1,11271,512]

theorem envBound8050 : H12AffineFastState.Bounded env8050 := by
  intro p hp
  have h : env8050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8049_8050 : H12AffineEnvironment.transform 4 26 env8049 = env8050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env8049 == env8050) = true)

theorem identity8050 : scanCanonicalize (H12AffineFastState.compose env8050 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound8050 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8051 : List Nat := [2,4,8,16,26,10,19,31,512,20,2048,538,8192,10259,8201,8208,538,2074,14,8201,10249,26,10,24,8218,16,2048,538,539,2075,20,0,5,1,10259,512]

theorem envBound8051 : H12AffineFastState.Bounded env8051 := by
  intro p hp
  have h : env8051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8050_8051 : H12AffineEnvironment.transform 9 20 env8050 = env8051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env8050 == env8051) = true)

theorem identity8051 : scanCanonicalize (H12AffineFastState.compose env8051 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 520) := by decide +kernel

theorem selectedBound8051 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8052 : List Nat := [2,4,8,16,26,10,19,31,512,20,2048,538,520,2587,513,536,538,2074,14,513,2561,26,10,24,530,16,2048,538,539,2075,20,0,5,1,2587,512]

theorem envBound8052 : H12AffineFastState.Bounded env8052 := by
  intro p hp
  have h : env8052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8051_8052 : H12AffineEnvironment.transform 12 520 env8051 = env8052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 520 env8051 == env8052) = true)

theorem identity8052 : scanCanonicalize (H12AffineFastState.compose env8052 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound8052 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8053 : List Nat := [2,4,8,16,26,10,19,31,27,20,2048,1,19,2048,26,3,1,2074,14,26,2074,26,10,24,9,16,2048,1,0,2075,20,0,5,1,2048,27]

theorem envBound8053 : H12AffineFastState.Bounded env8053 := by
  intro p hp
  have h : env8053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8052_8053 : H12AffineEnvironment.transform 8 27 env8052 = env8053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env8052 == env8053) = true)

def env8054 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,2097152,33,525637,74077,8224,67108864,67450415,67184142,67184474,67116881,67633429,67114532,525568,67114865,69206081,74282]

theorem envBound8054 : H12AffineFastState.Bounded env8054 := by
  intro p hp
  have h : env8054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8039_8054 : H12AffineEnvironment.transform 21 33 env8039 = env8054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env8039 == env8054) = true)

theorem identity8054 : scanCanonicalize (H12AffineFastState.compose env8054 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(25+1) ^^^ 2712943) := by decide +kernel

theorem selectedBound8054 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8055 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,2097152,33,525637,74077,8224,2712943,2904896,2638689,2638389,2718270,2188410,2716491,525568,2716190,615726,74282]

theorem envBound8055 : H12AffineFastState.Bounded env8055 := by
  intro p hp
  have h : env8055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8054_8055 : H12AffineEnvironment.transform 25 2712943 env8054 = env8055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 2712943 env8054 == env8055) = true)

theorem identity8055 : scanCanonicalize (H12AffineFastState.compose env8055 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(20+1) ^^^ 879966) := by decide +kernel

theorem selectedBound8055 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env8056 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,879966,33,525637,74077,8224,264241,81438,339519,339819,268128,788772,269845,525568,270144,615726,74282]

theorem envBound8056 : H12AffineFastState.Bounded env8056 := by
  intro p hp
  have h : env8056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8055_8056 : H12AffineEnvironment.transform 20 879966 env8055 = env8056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 879966 env8055 == env8056) = true)

theorem identity8056 : scanCanonicalize (H12AffineFastState.compose env8056 (packedSelected [0,4,5,8,9,10,13,17,19,20,24,27,28] rootPS)) = affineNative (2^(18+1) ^^^ 78414) := by decide +kernel

theorem selectedBound8056 : packedSelected [0,4,5,8,9,10,13,17,19,20,24,27,28] rootPS < 2^1333 := by decide +kernel

def env8057 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,78414,8540,286480,33,79627,74077,8224,264241,81438,339519,339819,268128,342890,269845,79694,270144,22368,74282]

theorem envBound8057 : H12AffineFastState.Bounded env8057 := by
  intro p hp
  have h : env8057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8056_8057 : H12AffineEnvironment.transform 18 78414 env8056 = env8057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78414 env8056 == env8057) = true)

theorem identity8057 : scanCanonicalize (H12AffineFastState.compose env8057 (packedSelected [2,3,4,6,7,8,12,13,18] rootPS)) = affineNative (2^(17+1) ^^^ 8000) := by decide +kernel

theorem selectedBound8057 : packedSelected [2,3,4,6,7,8,12,13,18] rootPS < 2^1333 := by decide +kernel

def env8058 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,8000,78414,8540,16464,33,79627,74077,8224,6001,81438,78207,77867,2080,74794,341,79694,0,22368,74282]

theorem envBound8058 : H12AffineFastState.Bounded env8058 := by
  intro p hp
  have h : env8058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8057_8058 : H12AffineEnvironment.transform 17 8000 env8057 = env8058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8000 env8057 == env8058) = true)

theorem identity8058 : scanCanonicalize (H12AffineFastState.compose env8058 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound8058 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env8059 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8200,65536,4097,7700,78414,8200,16464,33,79455,73737,8224,5669,81438,77867,77867,2080,74794,1,79386,0,22068,74282]

theorem envBound8059 : H12AffineFastState.Bounded env8059 := by
  intro p hp
  have h : env8059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8058_8059 : H12AffineEnvironment.transform 7 84 env8058 = env8059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env8058 == env8059) = true)

theorem identity8059 : scanCanonicalize (H12AffineFastState.compose env8059 (packedSelected [1,2,3] rootPS)) = affineNative (2^(15+1) ^^^ 26158) := by decide +kernel

theorem selectedBound8059 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env8060 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8200,26158,4097,7700,21600,8200,16464,33,20593,17959,8224,5669,22576,22021,22021,2080,16900,1,20532,0,22068,17412]

theorem envBound8060 : H12AffineFastState.Bounded env8060 := by
  intro p hp
  have h : env8060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8059_8060 : H12AffineEnvironment.transform 15 26158 env8059 = env8060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26158 env8059 == env8060) = true)

theorem identity8060 : scanCanonicalize (H12AffineFastState.compose env8060 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound8060 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env8061 : List Nat := [2,4,8,16,32,64,41,84,512,1024,560,4096,8192,16384,8200,26158,4097,5156,21600,8200,16464,33,20593,17959,8224,5669,20992,22021,22021,528,16900,1,20532,0,22068,17412]

theorem envBound8061 : H12AffineFastState.Bounded env8061 := by
  intro p hp
  have h : env8061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8060_8061 : H12AffineEnvironment.transform 10 560 env8060 = env8061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env8060 == env8061) = true)

theorem identity8061 : scanCanonicalize (H12AffineFastState.compose env8061 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1663) := by decide +kernel

theorem selectedBound8061 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env8062 : List Nat := [2,4,8,16,32,64,41,84,512,1024,560,1663,8192,16384,8200,26158,1662,603,16927,8200,16464,33,17934,17959,8224,90,17535,16506,16506,528,16900,1,17995,0,16459,17412]

theorem envBound8062 : H12AffineFastState.Bounded env8062 := by
  intro p hp
  have h : env8062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8061_8062 : H12AffineEnvironment.transform 11 1663 env8061 = env8062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1663 env8061 == env8062) = true)

theorem identity8062 : scanCanonicalize (H12AffineFastState.compose env8062 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 1653) := by decide +kernel

theorem selectedBound8062 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env8063 : List Nat := [2,4,8,16,32,64,41,84,512,1024,560,1663,8192,1653,8200,8283,1662,603,1130,8200,1573,33,123,82,8224,90,522,1551,1551,528,1137,1,62,0,1598,625]

theorem envBound8063 : H12AffineFastState.Bounded env8063 := by
  intro p hp
  have h : env8063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8062_8063 : H12AffineEnvironment.transform 13 1653 env8062 = env8063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1653 env8062 == env8063) = true)

def env8064 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,524288,8693,2097152,4194304,525804,74229,8329,67108864,71644687,67184294,67184475,71311216,67633597,67114532,525568,71309136,73400521,74283]

theorem envBound8064 : H12AffineFastState.Bounded env8064 := by
  intro p hp
  have h : env8064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8016_8064 : H12AffineEnvironment.transform 23 74229 env8016 = env8064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 74229 env8016 == env8064) = true)

def env8065 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,2097152,4194304,525636,74077,8225,67108864,71644687,67184142,67184475,71311216,67633429,67114532,525568,71309136,73400417,74283]

theorem envBound8065 : H12AffineFastState.Bounded env8065 := by
  intro p hp
  have h : env8065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8064_8065 : H12AffineEnvironment.transform 6 40 env8064 = env8065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env8064 == env8065) = true)

def env8066 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,2097152,32,525636,74077,8225,67108864,67450415,67184142,67184475,67116880,67633429,67114532,525568,67114864,69206081,74283]

theorem envBound8066 : H12AffineFastState.Bounded env8066 := by
  intro p hp
  have h : env8066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8065_8066 : H12AffineEnvironment.transform 21 32 env8065 = env8066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env8065 == env8066) = true)

theorem identity8066 : scanCanonicalize (H12AffineFastState.compose env8066 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(20+1) ^^^ 619338) := by decide +kernel

theorem selectedBound8066 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8067 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,619338,32,525636,74077,8225,67108864,67450415,67184142,67184475,67116880,67633429,67114532,525568,67114864,67728139,74283]

theorem envBound8067 : H12AffineFastState.Bounded env8067 := by
  intro p hp
  have h : env8067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8066_8067 : H12AffineEnvironment.transform 20 619338 env8066 = env8067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 619338 env8066 == env8067) = true)

theorem identity8067 : scanCanonicalize (H12AffineFastState.compose env8067 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 8001) := by decide +kernel

theorem selectedBound8067 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env8068 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,8001,524288,8541,619338,32,525636,74077,8225,67108864,67185006,67184142,67184475,67116880,67633429,67114532,525568,67114864,67728139,74283]

theorem envBound8068 : H12AffineFastState.Bounded env8068 := by
  intro p hp
  have h : env8068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8067_8068 : H12AffineEnvironment.transform 17 8001 env8067 = env8068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8001 env8067 == env8068) = true)

theorem identity8068 : scanCanonicalize (H12AffineFastState.compose env8068 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(18+1) ^^^ 78619) := by decide +kernel

theorem selectedBound8068 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env8069 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,8001,78619,8541,16465,32,79455,74077,8225,67108864,67185006,67184142,67184475,67116880,67187214,67114532,79387,67114864,67125264,74283]

theorem envBound8069 : H12AffineFastState.Bounded env8069 := by
  intro p hp
  have h : env8069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8068_8069 : H12AffineEnvironment.transform 18 78619 env8068 = env8069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78619 env8068 == env8069) = true)

theorem identity8069 : scanCanonicalize (H12AffineFastState.compose env8069 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound8069 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env8070 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,16384,8201,65536,4096,7701,78415,8201,16465,32,79455,73737,8225,67108864,67184698,67184142,67184143,67116548,67187214,67114532,79387,67114532,67125264,74283]

theorem envBound8070 : H12AffineFastState.Bounded env8070 := by
  intro p hp
  have h : env8070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8069_8070 : H12AffineEnvironment.transform 7 84 env8069 = env8070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env8069 == env8070) = true)

def env8071 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,2097152,33,525636,74077,8225,67108864,67450414,67184142,67184475,67116881,67633429,67114532,525568,67114865,69206080,74283]

theorem envBound8071 : H12AffineFastState.Bounded env8071 := by
  intro p hp
  have h : env8071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8065_8071 : H12AffineEnvironment.transform 21 33 env8065 = env8071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env8065 == env8071) = true)

theorem identity8071 : scanCanonicalize (H12AffineFastState.compose env8071 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(25+1) ^^^ 2712943) := by decide +kernel

theorem selectedBound8071 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8072 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,2097152,33,525636,74077,8225,2712943,2904897,2638689,2638388,2718270,2188410,2716491,525568,2716190,615727,74283]

theorem envBound8072 : H12AffineFastState.Bounded env8072 := by
  intro p hp
  have h : env8072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8071_8072 : H12AffineEnvironment.transform 25 2712943 env8071 = env8072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 2712943 env8071 == env8072) = true)

theorem identity8072 : scanCanonicalize (H12AffineFastState.compose env8072 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(20+1) ^^^ 879967) := by decide +kernel

theorem selectedBound8072 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env8073 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,879967,33,525636,74077,8225,264240,81438,339518,339819,268129,788773,269844,525568,270145,615727,74283]

theorem envBound8073 : H12AffineFastState.Bounded env8073 := by
  intro p hp
  have h : env8073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8072_8073 : H12AffineEnvironment.transform 20 879967 env8072 = env8073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 879967 env8072 == env8073) = true)

def env8074 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,2097152,4194304,525637,74076,8224,67108864,71644687,67184143,67184475,71311216,67633428,67114532,525568,71309136,73400416,74283]

theorem envBound8074 : H12AffineFastState.Bounded env8074 := by
  intro p hp
  have h : env8074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8064_8074 : H12AffineEnvironment.transform 6 41 env8064 = env8074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env8064 == env8074) = true)

def env8075 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,2097152,32,525637,74076,8224,67108864,67450415,67184143,67184475,67116880,67633428,67114532,525568,67114864,69206080,74283]

theorem envBound8075 : H12AffineFastState.Bounded env8075 := by
  intro p hp
  have h : env8075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8074_8075 : H12AffineEnvironment.transform 21 32 env8074 = env8075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env8074 == env8075) = true)

theorem identity8075 : scanCanonicalize (H12AffineFastState.compose env8075 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(25+1) ^^^ 2712943) := by decide +kernel

theorem selectedBound8075 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8076 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,2097152,32,525637,74076,8224,2712943,2904896,2638688,2638388,2718271,2188411,2716491,525568,2716191,615727,74283]

theorem envBound8076 : H12AffineFastState.Bounded env8076 := by
  intro p hp
  have h : env8076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8075_8076 : H12AffineEnvironment.transform 25 2712943 env8075 = env8076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 2712943 env8075 == env8076) = true)

theorem identity8076 : scanCanonicalize (H12AffineFastState.compose env8076 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(20+1) ^^^ 286276) := by decide +kernel

theorem selectedBound8076 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env8077 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,286276,32,525637,74076,8224,867115,527620,793892,793712,861307,342591,863503,525568,863323,615727,74283]

theorem envBound8077 : H12AffineFastState.Bounded env8077 := by
  intro p hp
  have h : env8077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8076_8077 : H12AffineEnvironment.transform 20 286276 env8076 = env8077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 286276 env8076 == env8077) = true)

theorem identity8077 : scanCanonicalize (H12AffineFastState.compose env8077 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound8077 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env8078 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8201,65536,4096,262144,524288,8201,286276,32,525328,73737,8224,866942,527441,793713,793712,861307,342591,863322,525397,863323,615546,74283]

theorem envBound8078 : H12AffineFastState.Bounded env8078 := by
  intro p hp
  have h : env8078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8077_8078 : H12AffineEnvironment.transform 7 85 env8077 = env8078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env8077 == env8078) = true)

theorem identity8078 : scanCanonicalize (H12AffineFastState.compose env8078 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(18+1) ^^^ 4709) := by decide +kernel

theorem selectedBound8078 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env8079 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8201,65536,4096,262144,4709,8201,286276,32,5749,73737,8224,337947,7732,265748,265749,341534,342591,343615,5680,343614,95775,74283]

theorem envBound8079 : H12AffineFastState.Bounded env8079 := by
  intro p hp
  have h : env8079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8078_8079 : H12AffineEnvironment.transform 18 4709 env8078 = env8079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4709 env8078 == env8079) = true)

theorem identity8079 : scanCanonicalize (H12AffineFastState.compose env8079 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound8079 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env8080 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8201,8235,4096,262144,4709,8201,286276,32,5749,34,8224,264240,7732,265748,265749,267829,268820,269844,5680,269845,22068,512]

theorem envBound8080 : H12AffineFastState.Bounded env8080 := by
  intro p hp
  have h : env8080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8079_8080 : H12AffineEnvironment.transform 15 8235 env8079 = env8080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env8079 == env8080) = true)

theorem identity8080 : scanCanonicalize (H12AffineFastState.compose env8080 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(17+1) ^^^ 29272) := by decide +kernel

theorem selectedBound8080 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env8081 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8201,8235,4096,29272,4709,8201,11292,32,5749,34,8224,31336,7732,31820,31821,25709,26700,27724,5680,27725,22068,512]

theorem envBound8081 : H12AffineFastState.Bounded env8081 := by
  intro p hp
  have h : env8081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8080_8081 : H12AffineEnvironment.transform 17 29272 env8080 = env8081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 29272 env8080 == env8081) = true)

theorem identity8081 : scanCanonicalize (H12AffineFastState.compose env8081 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound8081 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env8082 : List Nat := [2,4,8,16,32,49,41,36,512,1024,2048,4096,8192,16384,8201,8235,4096,29225,4628,8201,11292,32,5636,34,8224,31257,7732,31805,31804,25628,26685,27709,5680,27708,22068,512]

theorem envBound8082 : H12AffineFastState.Bounded env8082 := by
  intro p hp
  have h : env8082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8081_8082 : H12AffineEnvironment.transform 5 49 env8081 = env8082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env8081 == env8082) = true)

theorem identity8082 : scanCanonicalize (H12AffineFastState.compose env8082 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound8082 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env8083 : List Nat := [2,4,8,16,32,49,41,36,512,1024,2048,1589,8192,16384,8201,8235,1589,25628,1057,8201,11292,32,49,34,8224,27692,2049,27144,27145,25628,26685,27709,5,27708,16385,512]

theorem envBound8083 : H12AffineFastState.Bounded env8083 := by
  intro p hp
  have h : env8083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8082_8083 : H12AffineEnvironment.transform 11 1589 env8082 = env8083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env8082 == env8083) = true)

theorem identity8083 : scanCanonicalize (H12AffineFastState.compose env8083 (packedSelected [2,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 11270) := by decide +kernel

theorem selectedBound8083 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env8084 : List Nat := [2,4,8,16,32,49,41,36,512,1024,2048,1589,8192,11270,8201,8235,1589,2074,1057,8201,11292,32,49,34,8224,42,2049,1550,1551,2074,1083,59,5,58,11271,512]

theorem envBound8084 : H12AffineFastState.Bounded env8084 := by
  intro p hp
  have h : env8084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8083_8084 : H12AffineEnvironment.transform 13 11270 env8083 = env8084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11270 env8083 == env8084) = true)

theorem identity8084 : scanCanonicalize (H12AffineFastState.compose env8084 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound8084 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env8085 : List Nat := [2,4,8,16,27,10,18,31,512,1024,2048,1550,8192,11270,8201,8208,1550,2074,1050,8201,11292,27,10,25,8219,17,2049,1550,1551,2074,1024,0,5,1,11271,512]

theorem envBound8085 : H12AffineFastState.Bounded env8085 := by
  intro p hp
  have h : env8085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8084_8085 : H12AffineEnvironment.transform 4 27 env8084 = env8085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env8084 == env8085) = true)

theorem identity8085 : scanCanonicalize (H12AffineFastState.compose env8085 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 2073) := by decide +kernel

theorem selectedBound8085 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8086 : List Nat := [2,4,8,16,27,10,18,31,512,1024,2048,1550,2073,1055,2064,2057,1550,2074,1050,2064,1029,27,10,25,2050,17,2049,1550,1551,2074,1024,0,5,1,1054,512]

theorem envBound8086 : H12AffineFastState.Bounded env8086 := by
  intro p hp
  have h : env8086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8085_8086 : H12AffineEnvironment.transform 12 2073 env8085 = env8086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2073 env8085 == env8086) = true)

theorem identity8086 : scanCanonicalize (H12AffineFastState.compose env8086 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound8086 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8087 : List Nat := [2,4,8,16,27,10,18,31,27,1024,2048,1045,2073,1055,2064,2057,1045,2074,1050,2064,1029,27,10,25,2050,17,2049,1045,1044,2074,1024,0,5,1,1054,27]

theorem envBound8087 : H12AffineFastState.Bounded env8087 := by
  intro p hp
  have h : env8087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8086_8087 : H12AffineEnvironment.transform 8 27 env8086 = env8087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env8086 == env8087) = true)

def env8088 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,2097152,33,525637,74076,8224,67108864,67450414,67184143,67184475,67116881,67633428,67114532,525568,67114865,69206081,74283]

theorem envBound8088 : H12AffineFastState.Bounded env8088 := by
  intro p hp
  have h : env8088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8074_8088 : H12AffineEnvironment.transform 21 33 env8074 = env8088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env8074 == env8088) = true)

theorem identity8088 : scanCanonicalize (H12AffineFastState.compose env8088 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(20+1) ^^^ 619338) := by decide +kernel

theorem selectedBound8088 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8089 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,619338,33,525637,74076,8224,67108864,67450414,67184143,67184475,67116881,67633428,67114532,525568,67114865,67728139,74283]

theorem envBound8089 : H12AffineFastState.Bounded env8089 := by
  intro p hp
  have h : env8089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8088_8089 : H12AffineEnvironment.transform 20 619338 env8088 = env8089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 619338 env8088 == env8089) = true)

theorem identity8089 : scanCanonicalize (H12AffineFastState.compose env8089 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(18+1) ^^^ 339034) := by decide +kernel

theorem selectedBound8089 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env8090 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,339034,8540,286480,33,338207,74076,8224,67108864,67450414,67184143,67184475,67116881,67448142,67114532,338266,67114865,67395409,74283]

theorem envBound8090 : H12AffineFastState.Bounded env8090 := by
  intro p hp
  have h : env8090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8089_8090 : H12AffineEnvironment.transform 18 339034 env8089 = env8090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 339034 env8089 == env8090) = true)

theorem identity8090 : scanCanonicalize (H12AffineFastState.compose env8090 (packedSelected [0,1,3,4,9,13,17,20,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 7700) := by decide +kernel

theorem selectedBound8090 : packedSelected [0,1,3,4,9,13,17,20,24,27,28] rootPS < 2^1333 := by decide +kernel

def env8091 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,7700,78414,8540,16644,33,79627,74076,8224,67108864,67184698,67184143,67184475,67116881,67187546,67114532,79694,67114865,67125573,74283]

theorem envBound8091 : H12AffineFastState.Bounded env8091 := by
  intro p hp
  have h : env8091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8090_8091 : H12AffineEnvironment.transform 17 7700 env8090 = env8091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7700 env8090 == env8091) = true)

theorem identity8091 : scanCanonicalize (H12AffineFastState.compose env8091 (packedSelected [2,3,5,6,7,9,11,12,13,14] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound8091 : packedSelected [2,3,5,6,7,9,11,12,13,14] rootPS < 2^1333 := by decide +kernel

def env8092 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8200,65536,4097,7700,78414,8200,16464,33,79455,73736,8224,67108864,67184698,67184143,67184143,67116549,67187214,67114532,79386,67114533,67125265,74283]

theorem envBound8092 : H12AffineFastState.Bounded env8092 := by
  intro p hp
  have h : env8092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8091_8092 : H12AffineEnvironment.transform 7 84 env8091 = env8092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env8091 == env8092) = true)

theorem identity8092 : scanCanonicalize (H12AffineFastState.compose env8092 (packedSelected [2,3,4,6,7,8,11,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound8092 : packedSelected [2,3,4,6,7,8,11,13,15] rootPS < 2^1333 := by decide +kernel

def env8093 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8200,8282,4097,7700,4628,8200,16464,33,5637,82,8224,67108864,67111008,67110485,67110485,67116549,67113556,67114532,5696,67114533,67125265,625]

theorem envBound8093 : H12AffineFastState.Bounded env8093 := by
  intro p hp
  have h : env8093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8092_8093 : H12AffineEnvironment.transform 15 8282 env8092 = env8093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env8092 == env8093) = true)

theorem identity8093 : scanCanonicalize (H12AffineFastState.compose env8093 (packedSelected [13,17] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound8093 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8094 : List Nat := [2,4,8,16,32,48,41,36,512,1024,2048,4096,8192,16384,8200,8234,4097,7700,4628,8200,16416,33,5637,34,8224,67108864,67110928,67110437,67110437,67116549,67113508,67114532,5680,67114533,67125265,513]

theorem envBound8094 : H12AffineFastState.Bounded env8094 := by
  intro p hp
  have h : env8094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8093_8094 : H12AffineEnvironment.transform 5 48 env8093 = env8094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env8093 == env8094) = true)

theorem identity8094 : scanCanonicalize (H12AffineFastState.compose env8094 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 14857) := by decide +kernel

theorem selectedBound8094 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env8095 : List Nat := [2,4,8,16,32,48,41,36,512,1024,2048,4096,8192,14857,8200,8234,4097,7700,4628,8200,14889,33,5637,34,8224,67108864,67110928,67110437,67110437,67116549,67113508,67114532,5680,67114533,67123736,513]

theorem envBound8095 : H12AffineFastState.Bounded env8095 := by
  intro p hp
  have h : env8095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8094_8095 : H12AffineEnvironment.transform 13 14857 env8094 = env8095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14857 env8094 == env8095) = true)

theorem identity8095 : scanCanonicalize (H12AffineFastState.compose env8095 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(25+1) ^^^ 5668) := by decide +kernel

theorem selectedBound8095 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env8096 : List Nat := [2,4,8,16,32,48,41,36,512,1024,2048,4096,8192,14857,8200,8234,4097,7700,4628,8200,14889,33,5637,34,8224,5668,7732,4097,4097,2081,1024,0,5680,1,11324,513]

theorem envBound8096 : H12AffineFastState.Bounded env8096 := by
  intro p hp
  have h : env8096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8095_8096 : H12AffineEnvironment.transform 25 5668 env8095 = env8096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5668 env8095 == env8096) = true)

theorem identity8096 : scanCanonicalize (H12AffineFastState.compose env8096 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 7190) := by decide +kernel

theorem selectedBound8096 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8097 : List Nat := [2,4,8,16,32,48,41,36,512,1024,2048,4096,7190,1567,7198,7228,4097,7700,4628,7198,1599,33,5637,34,7222,5668,7732,4097,4097,2081,1024,0,5680,1,4138,513]

theorem envBound8097 : H12AffineFastState.Bounded env8097 := by
  intro p hp
  have h : env8097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8096_8097 : H12AffineEnvironment.transform 12 7190 env8096 = env8097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7190 env8096 == env8097) = true)

theorem identity8097 : scanCanonicalize (H12AffineFastState.compose env8097 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound8097 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env8098 : List Nat := [2,4,8,10,32,42,41,36,512,1024,2048,4096,7180,1541,7172,7206,4097,7694,4622,7172,1573,33,5637,34,7212,5668,7726,4097,4097,2081,1024,0,5674,1,4138,513]

theorem envBound8098 : H12AffineFastState.Bounded env8098 := by
  intro p hp
  have h : env8098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8097_8098 : H12AffineEnvironment.transform 3 10 env8097 = env8098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env8097 == env8098) = true)

theorem identity8098 : scanCanonicalize (H12AffineFastState.compose env8098 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1551) := by decide +kernel

theorem selectedBound8098 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env8099 : List Nat := [2,4,8,10,32,42,41,36,512,1024,2048,1551,2563,1541,2571,2601,1550,2049,1025,2571,1573,33,10,34,2595,43,2081,1550,1550,2081,1024,0,37,1,1573,513]

theorem envBound8099 : H12AffineFastState.Bounded env8099 := by
  intro p hp
  have h : env8099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8098_8099 : H12AffineEnvironment.transform 11 1551 env8098 = env8099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1551 env8098 == env8099) = true)

theorem identity8099 : scanCanonicalize (H12AffineFastState.compose env8099 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound8099 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8100 : List Nat := [2,4,8,10,32,42,41,36,512,1024,555,1551,40,1541,32,2,1550,554,1025,32,1573,33,10,34,8,43,522,1550,1550,522,1024,0,37,1,1573,513]

theorem envBound8100 : H12AffineFastState.Bounded env8100 := by
  intro p hp
  have h : env8100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8099_8100 : H12AffineEnvironment.transform 10 555 env8099 = env8100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env8099 == env8100) = true)

theorem identity8100 : scanCanonicalize (H12AffineFastState.compose env8100 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8100 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env8101 : List Nat := [2,4,8,10,0,10,9,4,512,1024,523,1551,8,1541,0,2,1550,522,1025,0,1541,1,10,2,8,11,522,1550,1550,522,1024,0,5,1,1541,513]

theorem envBound8101 : H12AffineFastState.Bounded env8101 := by
  intro p hp
  have h : env8101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8100_8101 : H12AffineEnvironment.transform 4 0 env8100 = env8101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8100 == env8101) = true)

theorem identity8101 : scanCanonicalize (H12AffineFastState.compose env8101 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound8101 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8102 : List Nat := [2,1,8,10,0,10,9,1,512,1024,523,1546,8,1536,0,2,1547,522,1025,0,1536,1,10,2,8,11,522,1547,1547,522,1024,0,0,1,1536,513]

theorem envBound8102 : H12AffineFastState.Bounded env8102 := by
  intro p hp
  have h : env8102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8101_8102 : H12AffineEnvironment.transform 1 1 env8101 = env8102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env8101 == env8102) = true)

theorem identity8102 : scanCanonicalize (H12AffineFastState.compose env8102 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 11) := by decide +kernel

theorem selectedBound8102 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env8103 : List Nat := [2,1,8,10,0,10,9,1,512,11,523,513,8,523,0,2,512,522,10,0,523,1,10,2,8,11,522,512,512,522,11,0,0,1,523,513]

theorem envBound8103 : H12AffineFastState.Bounded env8103 := by
  intro p hp
  have h : env8103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8102_8103 : H12AffineEnvironment.transform 9 11 env8102 = env8103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 11 env8102 == env8103) = true)

def env8104 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,525805,16777216,8329,67108864,134217728,268435456,268435964,151259274,84509116,155492394,525568,151257258,34359738368,16818730]

theorem envBound8104 : H12AffineFastState.Bounded env8104 := by
  intro p hp
  have h : env8104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7595_8104 : H12AffineEnvironment.transform 16 4605 env7595 = env8104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4605 env7595 == env8104) = true)

theorem identity8104 : scanCanonicalize (H12AffineFastState.compose env8104 (packedSelected [5,8,12,13,15,17,24,26,28,31,38,41] rootPS)) = affineNative (2^(34+1) ^^^ 203784471) := by decide +kernel

theorem selectedBound8104 : packedSelected [5,8,12,13,15,17,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env8105 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,525805,16777216,8329,67108864,134217728,268435456,268435964,151259274,84509116,155492394,525568,151257258,203784471,16818730]

theorem envBound8105 : H12AffineFastState.Bounded env8105 := by
  intro p hp
  have h : env8105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8104_8105 : H12AffineEnvironment.transform 34 203784471 env8104 = env8105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 203784471 env8104 == env8105) = true)

def env8106 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,4194304,525805,16777216,8329,67108864,134217728,268435456,268435964,151259274,84484168,155451870,525568,151257258,203759843,16778206]

theorem envBound8106 : H12AffineFastState.Bounded env8106 := by
  intro p hp
  have h : env8106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8105_8106 : H12AffineEnvironment.transform 14 8692 env8105 = env8106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8692 env8105 == env8106) = true)

def env8107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,4194304,525805,16777216,8329,67108864,134217728,138678440,138678612,151259274,84484168,155451870,525568,151257258,203759843,16778206]

theorem envBound8107 : H12AffineFastState.Bounded env8107 := by
  intro p hp
  have h : env8107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8106_8107 : H12AffineEnvironment.transform 27 138678440 env8106 = env8107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 138678440 env8106 == env8107) = true)

theorem identity8107 : scanCanonicalize (H12AffineFastState.compose env8107 (packedSelected [9,14,22] rootPS)) = affineNative (2^(25+1) ^^^ 79375) := by decide +kernel

theorem selectedBound8107 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env8108 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,4194304,525805,16777216,8329,79375,134217728,138678440,138678612,151259274,17307207,155451870,525568,151257258,136582892,16778206]

theorem envBound8108 : H12AffineFastState.Bounded env8108 := by
  intro p hp
  have h : env8108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8107_8108 : H12AffineEnvironment.transform 25 79375 env8107 = env8108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 79375 env8107 == env8108) = true)

def env8109 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,16740,525805,16777216,8329,79375,134217728,134500812,134500400,151259274,17307207,151273658,525568,151257258,136582892,16778206]

theorem envBound8109 : H12AffineFastState.Bounded env8109 := by
  intro p hp
  have h : env8109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8108_8109 : H12AffineEnvironment.transform 21 16740 env8108 = env8109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16740 env8108 == env8109) = true)

def env8110 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,16740,525805,16777216,8329,79375,279904,5292,5456,16797162,17307207,16778714,525568,16795082,2118540,16778206]

theorem envBound8110 : H12AffineFastState.Bounded env8110 := by
  intro p hp
  have h : env8110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8109_8110 : H12AffineEnvironment.transform 26 279904 env8109 = env8110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 279904 env8109 == env8110) = true)

def env8111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,16740,525805,91616,8329,79375,279904,5292,5456,75786,619431,90170,525568,73770,2118540,91710]

theorem envBound8111 : H12AffineFastState.Bounded env8111 := by
  intro p hp
  have h : env8111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8110_8111 : H12AffineEnvironment.transform 23 91616 env8110 = env8111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 91616 env8110 == env8111) = true)

theorem identity8111 : scanCanonicalize (H12AffineFastState.compose env8111 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound8111 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8112 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,4096,262144,524288,8201,2097152,16537,525328,91165,8329,79375,279709,5292,5293,75786,619098,90170,525565,73770,2118257,91710]

theorem envBound8112 : H12AffineFastState.Bounded env8112 := by
  intro p hp
  have h : env8112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8111_8112 : H12AffineEnvironment.transform 7 253 env8111 = env8112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env8111 == env8112) = true)

def env8113 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16384,8201,65536,4096,262144,524288,8201,2097152,16537,525328,91165,8329,78959,279709,5292,5293,75786,618554,90170,525565,73770,2117649,91230]

theorem envBound8113 : H12AffineFastState.Bounded env8113 := by
  intro p hp
  have h : env8113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8112_8113 : H12AffineEnvironment.transform 8 96 env8112 = env8113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env8112 == env8113) = true)

theorem identity8113 : scanCanonicalize (H12AffineFastState.compose env8113 (packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 25662) := by decide +kernel

theorem selectedBound8113 : packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env8114 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16384,8201,25662,4096,262144,524288,8201,2097152,16537,525328,35,8329,20561,279709,5292,5293,19508,529412,1028,525565,17428,2117649,96]

theorem envBound8114 : H12AffineFastState.Bounded env8114 := by
  intro p hp
  have h : env8114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8113_8114 : H12AffineEnvironment.transform 15 25662 env8113 = env8114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25662 env8113 == env8114) = true)

theorem identity8114 : scanCanonicalize (H12AffineFastState.compose env8114 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 16) := by decide +kernel

theorem selectedBound8114 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env8115 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16,8201,9262,4096,262144,524288,8201,2097152,137,525328,35,8329,4161,263309,5292,5293,3108,529412,1028,525565,1028,2101249,96]

theorem envBound8115 : H12AffineFastState.Bounded env8115 := by
  intro p hp
  have h : env8115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8114_8115 : H12AffineEnvironment.transform 13 16 env8114 = env8115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16 env8114 == env8115) = true)

theorem identity8115 : scanCanonicalize (H12AffineFastState.compose env8115 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 529640) := by decide +kernel

theorem selectedBound8115 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8116 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16,8201,9262,4096,262144,524288,8201,529640,137,525328,35,8329,4161,263309,5292,5293,3108,529412,1028,525565,1028,525545,96]

theorem envBound8116 : H12AffineFastState.Bounded env8116 := by
  intro p hp
  have h : env8116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8115_8116 : H12AffineEnvironment.transform 20 529640 env8115 = env8116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529640 env8115 == env8116) = true)

theorem identity8116 : scanCanonicalize (H12AffineFastState.compose env8116 (packedSelected [2,11,12,13,14,15,23] rootPS)) = affineNative (2^(18+1) ^^^ 13472) := by decide +kernel

theorem selectedBound8116 : packedSelected [2,11,12,13,14,15,23] rootPS < 2^1333 := by decide +kernel

def env8117 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16,8201,9262,4096,262144,13472,8201,8264,137,12464,35,8329,4161,263309,5292,5293,3108,8356,1028,12381,1028,12361,96]

theorem envBound8117 : H12AffineFastState.Bounded env8117 := by
  intro p hp
  have h : env8117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8116_8117 : H12AffineEnvironment.transform 18 13472 env8116 = env8117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 13472 env8116 == env8117) = true)

theorem identity8117 : scanCanonicalize (H12AffineFastState.compose env8117 (packedSelected [0,6,27] rootPS)) = affineNative (2^(17+1) ^^^ 9287) := by decide +kernel

theorem selectedBound8117 : packedSelected [0,6,27] rootPS < 2^1333 := by decide +kernel

def env8118 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16,8201,9262,4096,9287,13472,8201,8264,137,12464,35,8329,4161,8394,5292,5293,3108,8356,1028,12381,1028,12361,96]

theorem envBound8118 : H12AffineFastState.Bounded env8118 := by
  intro p hp
  have h : env8118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8117_8118 : H12AffineEnvironment.transform 17 9287 env8117 = env8118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9287 env8117 == env8118) = true)

theorem identity8118 : scanCanonicalize (H12AffineFastState.compose env8118 (packedSelected [12,13,38] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound8118 : packedSelected [12,13,38] rootPS < 2^1333 := by decide +kernel

def env8119 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8,16,1,1062,4096,1103,5288,1,64,137,4280,35,129,4161,194,5292,5293,3108,172,1028,4181,1028,4161,96]

theorem envBound8119 : H12AffineFastState.Bounded env8119 := by
  intro p hp
  have h : env8119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8118_8119 : H12AffineEnvironment.transform 12 8 env8118 = env8119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env8118 == env8119) = true)

theorem identity8119 : scanCanonicalize (H12AffineFastState.compose env8119 (packedSelected [2,13,14] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound8119 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env8120 : List Nat := [2,4,8,16,32,64,40,85,96,1024,2048,4096,8,16,1,1062,4096,1103,5120,1,64,33,4112,35,41,4161,106,5124,5125,3108,4,1028,4181,1028,4161,96]

theorem envBound8120 : H12AffineFastState.Bounded env8120 := by
  intro p hp
  have h : env8120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8119_8120 : H12AffineEnvironment.transform 6 40 env8119 = env8120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env8119 == env8120) = true)

theorem identity8120 : scanCanonicalize (H12AffineFastState.compose env8120 (packedSelected [2,6,13] rootPS)) = affineNative (2^(11+1) ^^^ 1108) := by decide +kernel

theorem selectedBound8120 : packedSelected [2,6,13] rootPS < 2^1333 := by decide +kernel

def env8121 : List Nat := [2,4,8,16,32,64,40,85,96,1024,2048,1108,8,16,1,1062,1108,1103,84,1,64,33,1092,35,41,1045,106,80,81,3108,4,1028,1025,1028,1045,96]

theorem envBound8121 : H12AffineFastState.Bounded env8121 := by
  intro p hp
  have h : env8121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8120_8121 : H12AffineEnvironment.transform 11 1108 env8120 = env8121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env8120 == env8121) = true)

def env8122 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16384,8201,65536,4096,262144,524288,8201,2097152,16537,525328,91165,8329,78958,279709,5292,5293,75786,618555,90170,525565,73770,2117648,91231]

theorem envBound8122 : H12AffineFastState.Bounded env8122 := by
  intro p hp
  have h : env8122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8112_8122 : H12AffineEnvironment.transform 8 97 env8112 = env8122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env8112 == env8122) = true)

theorem identity8122 : scanCanonicalize (H12AffineFastState.compose env8122 (packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 9263) := by decide +kernel

theorem selectedBound8122 : packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env8123 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16384,8201,9263,4096,262144,524288,8201,2097152,16537,525328,16434,8329,4161,279709,5292,5293,3109,545812,17429,525565,1029,2117648,16496]

theorem envBound8123 : H12AffineFastState.Bounded env8123 := by
  intro p hp
  have h : env8123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8122_8123 : H12AffineEnvironment.transform 15 9263 env8122 = env8123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9263 env8122 == env8123) = true)

theorem identity8123 : scanCanonicalize (H12AffineFastState.compose env8123 (packedSelected [13,21] rootPS)) = affineNative (2^(20+1) ^^^ 545021) := by decide +kernel

theorem selectedBound8123 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env8124 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16384,8201,9263,4096,262144,524288,8201,545021,16537,525328,16434,8329,4161,279709,5292,5293,3109,545812,17429,525565,1029,524525,16496]

theorem envBound8124 : H12AffineFastState.Bounded env8124 := by
  intro p hp
  have h : env8124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8123_8124 : H12AffineEnvironment.transform 20 545021 env8123 = env8124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 545021 env8123 == env8124) = true)

theorem identity8124 : scanCanonicalize (H12AffineFastState.compose env8124 (packedSelected [0,3,5,6,10,27] rootPS)) = affineNative (2^(18+1) ^^^ 282655) := by decide +kernel

theorem selectedBound8124 : packedSelected [0,3,5,6,10,27] rootPS < 2^1333 := by decide +kernel

def env8125 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16384,8201,9263,4096,262144,282655,8201,262370,16537,283663,16434,8329,4161,279709,5292,5293,3109,263179,17429,283874,1029,282866,16496]

theorem envBound8125 : H12AffineFastState.Bounded env8125 := by
  intro p hp
  have h : env8125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8124_8125 : H12AffineEnvironment.transform 18 282655 env8124 = env8125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 282655 env8124 == env8125) = true)

theorem identity8125 : scanCanonicalize (H12AffineFastState.compose env8125 (packedSelected [2,14,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 17591) := by decide +kernel

theorem selectedBound8125 : packedSelected [2,14,23,32] rootPS < 2^1333 := by decide +kernel

def env8126 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16384,8201,9263,4096,17591,5288,8201,17493,16537,4280,16434,8329,4161,42,5292,5293,3109,16572,17429,4181,1029,5189,16496]

theorem envBound8126 : H12AffineFastState.Bounded env8126 := by
  intro p hp
  have h : env8126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8125_8126 : H12AffineEnvironment.transform 17 17591 env8125 = env8126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 17591 env8125 == env8126) = true)

theorem identity8126 : scanCanonicalize (H12AffineFastState.compose env8126 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 16) := by decide +kernel

theorem selectedBound8126 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8127 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16,8201,9263,4096,1191,5288,8201,1093,137,4280,34,8329,4161,42,5292,5293,3109,172,1029,4181,1029,5189,96]

theorem envBound8127 : H12AffineFastState.Bounded env8127 := by
  intro p hp
  have h : env8127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8126_8127 : H12AffineEnvironment.transform 13 16 env8126 = env8127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16 env8126 == env8127) = true)

def env8128 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,16740,525805,91617,8329,79375,279904,5292,5456,75787,619430,90171,525568,73771,2118540,91711]

theorem envBound8128 : H12AffineFastState.Bounded env8128 := by
  intro p hp
  have h : env8128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8110_8128 : H12AffineEnvironment.transform 23 91617 env8110 = env8128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 91617 env8110 == env8128) = true)

theorem identity8128 : scanCanonicalize (H12AffineFastState.compose env8128 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 26050) := by decide +kernel

theorem selectedBound8128 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8129 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,26050,4605,262144,524288,8692,2097152,16740,525805,35,8329,21453,279904,5292,5456,19913,530020,1529,525568,17897,2118540,1021]

theorem envBound8129 : H12AffineFastState.Bounded env8129 := by
  intro p hp
  have h : env8129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8128_8129 : H12AffineEnvironment.transform 15 26050 env8128 = env8129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26050 env8128 == env8129) = true)

def env8130 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,26050,4605,262144,524288,8692,529264,16740,525805,35,8329,21453,279904,5292,5456,19913,530020,1529,525568,17897,540924,1021]

theorem envBound8130 : H12AffineFastState.Bounded env8130 := by
  intro p hp
  have h : env8130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8129_8130 : H12AffineEnvironment.transform 20 529264 env8129 = env8130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529264 env8129 == env8130) = true)

def env8131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,26050,4605,262144,4432,8692,544,16740,5309,35,8329,21453,279904,5292,5456,19913,1844,1529,5200,17897,20908,1021]

theorem envBound8131 : H12AffineFastState.Bounded env8131 := by
  intro p hp
  have h : env8131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8130_8131 : H12AffineEnvironment.transform 18 4432 env8130 = env8131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4432 env8130 == env8131) = true)

theorem identity8131 : scanCanonicalize (H12AffineFastState.compose env8131 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 17) := by decide +kernel

theorem selectedBound8131 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env8132 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,17,8692,9683,4605,262144,4432,8692,544,373,5309,35,8329,5084,263537,5292,5456,3544,1844,1529,5200,1528,4541,1021]

theorem envBound8132 : H12AffineFastState.Bounded env8132 := by
  intro p hp
  have h : env8132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8131_8132 : H12AffineEnvironment.transform 13 17 env8131 = env8132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env8131 == env8132) = true)

theorem identity8132 : scanCanonicalize (H12AffineFastState.compose env8132 (packedSelected [2,14,23,32] rootPS)) = affineNative (2^(9+1) ^^^ 613) := by decide +kernel

theorem selectedBound8132 : packedSelected [2,14,23,32] rootPS < 2^1333 := by decide +kernel

def env8133 : List Nat := [2,4,8,16,32,64,128,256,512,613,2048,4096,8192,17,8692,9142,4605,262144,4432,8692,544,373,4824,35,8329,5084,262932,4809,4917,3005,337,924,4661,925,4541,1021]

theorem envBound8133 : H12AffineFastState.Bounded env8133 := by
  intro p hp
  have h : env8133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8132_8133 : H12AffineEnvironment.transform 9 613 env8132 = env8133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 613 env8132 == env8133) = true)

theorem identity8133 : scanCanonicalize (H12AffineFastState.compose env8133 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 7149) := by decide +kernel

theorem selectedBound8133 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8134 : List Nat := [2,4,8,16,32,64,128,256,512,613,2048,4096,8192,17,8692,9142,4605,7149,4432,8692,544,373,4824,35,8329,5084,6393,4809,4917,3005,337,924,4661,925,4541,1021]

theorem envBound8134 : H12AffineFastState.Bounded env8134 := by
  intro p hp
  have h : env8134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8133_8134 : H12AffineEnvironment.transform 17 7149 env8133 = env8134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7149 env8133 == env8134) = true)

theorem identity8134 : scanCanonicalize (H12AffineFastState.compose env8134 (packedSelected [1,2,3,8,10,11,14,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 665) := by decide +kernel

theorem selectedBound8134 : packedSelected [1,2,3,8,10,11,14,23,24] rootPS < 2^1333 := by decide +kernel

def env8135 : List Nat := [2,4,8,16,32,64,128,256,512,613,2048,665,8192,17,8692,9142,868,2420,969,8692,544,373,65,35,8329,325,2656,80,428,3005,337,924,172,925,804,1021]

theorem envBound8135 : H12AffineFastState.Bounded env8135 := by
  intro p hp
  have h : env8135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8134_8135 : H12AffineEnvironment.transform 11 665 env8134 = env8135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 665 env8134 == env8135) = true)

theorem identity8135 : scanCanonicalize (H12AffineFastState.compose env8135 (packedSelected [0,4,7,9,11,12,14,15,23] rootPS)) = affineNative (2^(8+1) ^^^ 493) := by decide +kernel

theorem selectedBound8135 : packedSelected [0,4,7,9,11,12,14,15,23] rootPS < 2^1333 := by decide +kernel

def env8136 : List Nat := [2,4,8,16,32,64,128,256,493,392,2048,372,8192,17,8692,8283,137,2420,36,8692,461,373,65,35,8329,325,2445,80,428,2128,337,113,172,112,201,16]

theorem envBound8136 : H12AffineFastState.Bounded env8136 := by
  intro p hp
  have h : env8136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8135_8136 : H12AffineEnvironment.transform 8 493 env8135 = env8136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 493 env8135 == env8136) = true)

theorem identity8136 : scanCanonicalize (H12AffineFastState.compose env8136 (packedSelected [3,5,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound8136 : packedSelected [3,5,10,11,12] rootPS < 2^1333 := by decide +kernel

def env8137 : List Nat := [2,4,8,16,32,64,128,85,184,221,2048,33,8192,17,8353,8283,137,2081,36,8353,152,32,65,35,8329,16,2264,80,249,2128,4,113,172,112,201,16]

theorem envBound8137 : H12AffineFastState.Bounded env8137 := by
  intro p hp
  have h : env8137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8136_8137 : H12AffineEnvironment.transform 7 85 env8136 = env8137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env8136 == env8137) = true)

theorem identity8137 : scanCanonicalize (H12AffineFastState.compose env8137 (packedSelected [0,2,3,4,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound8137 : packedSelected [0,2,3,4,6,8] rootPS < 2^1333 := by decide +kernel

def env8138 : List Nat := [2,4,8,16,32,64,128,85,184,221,136,33,8192,17,8353,8283,137,169,36,8353,152,32,65,35,8329,16,80,80,249,216,4,113,172,112,201,16]

theorem envBound8138 : H12AffineFastState.Bounded env8138 := by
  intro p hp
  have h : env8138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8137_8138 : H12AffineEnvironment.transform 10 136 env8137 = env8138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env8137 == env8138) = true)

theorem identity8138 : scanCanonicalize (H12AffineFastState.compose env8138 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 154) := by decide +kernel

theorem selectedBound8138 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env8139 : List Nat := [2,4,8,16,32,64,128,85,184,221,136,33,154,17,59,193,137,169,36,59,152,32,65,35,19,16,80,80,249,216,4,113,172,112,201,16]

theorem envBound8139 : H12AffineFastState.Bounded env8139 := by
  intro p hp
  have h : env8139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8138_8139 : H12AffineEnvironment.transform 12 154 env8138 = env8139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 154 env8138 == env8139) = true)

theorem identity8139 : scanCanonicalize (H12AffineFastState.compose env8139 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound8139 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env8140 : List Nat := [2,4,8,16,32,11,128,30,184,150,136,33,154,17,59,138,137,169,36,59,152,32,10,35,19,16,27,27,178,147,4,58,172,59,130,16]

theorem envBound8140 : H12AffineFastState.Bounded env8140 := by
  intro p hp
  have h : env8140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8139_8140 : H12AffineEnvironment.transform 5 11 env8139 = env8140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env8139 == env8140) = true)

theorem identity8140 : scanCanonicalize (H12AffineFastState.compose env8140 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound8140 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env8141 : List Nat := [2,4,8,16,32,11,19,30,43,5,27,33,9,17,59,25,26,58,36,59,11,32,10,35,19,16,27,27,33,0,4,58,63,59,17,16]

theorem envBound8141 : H12AffineFastState.Bounded env8141 := by
  intro p hp
  have h : env8141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8140_8141 : H12AffineEnvironment.transform 6 19 env8140 = env8141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env8140 == env8141) = true)

theorem identity8141 : scanCanonicalize (H12AffineFastState.compose env8141 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound8141 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8142 : List Nat := [2,4,8,16,16,11,19,30,27,5,27,17,9,17,11,25,26,10,20,11,11,16,10,19,19,16,27,27,17,0,4,10,15,11,17,16]

theorem envBound8142 : H12AffineFastState.Bounded env8142 := by
  intro p hp
  have h : env8142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8141_8142 : H12AffineEnvironment.transform 4 16 env8141 = env8142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env8141 == env8142) = true)

theorem identity8142 : scanCanonicalize (H12AffineFastState.compose env8142 (packedSelected [0,6] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8142 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env8143 : List Nat := [2,4,3,16,16,0,19,21,16,5,16,17,2,17,0,18,17,1,20,0,0,16,1,19,19,16,16,16,17,0,4,1,4,0,17,16]

theorem envBound8143 : H12AffineFastState.Bounded env8143 := by
  intro p hp
  have h : env8143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8142_8143 : H12AffineEnvironment.transform 2 3 env8142 = env8143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8142 == env8143) = true)

def leafEnv8143 : List Nat := [2,4,3,16,16,0,19,21,16,5,16,17,2,17,0,18,17,1,20,0,0,16,1,19,21,19,1,16,16,16,17,0,4,1,4,0,21,2,17,16,1,1,0]

def active8143 : List Nat := [0,1,3]

def tree8143 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8143 : H12WitnessSearch.Good tree8143 := H12GlobalWitnessIndex.good

theorem leafIdentity8143 : H12AffineFastState.composeSystem env8143 rootObs = leafEnv8143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8143 rootObs == leafEnv8143) = true)

theorem terminalChecked8143 : H12PackedTerminal.terminalCheckFast leafEnv8143 active8143 tree8143 = true := by decide +kernel

def env8144 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,26050,4605,262144,4433,8692,545,16740,5308,35,8329,21453,279904,5292,5456,19913,1845,1529,5201,17897,20909,1021]

theorem envBound8144 : H12AffineFastState.Bounded env8144 := by
  intro p hp
  have h : env8144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8130_8144 : H12AffineEnvironment.transform 18 4433 env8130 = env8144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4433 env8130 == env8144) = true)

theorem identity8144 : scanCanonicalize (H12AffineFastState.compose env8144 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 492) := by decide +kernel

theorem selectedBound8144 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env8145 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,492,8692,9262,4605,262144,4433,8692,545,136,5308,35,8329,4641,263308,5292,5456,3109,1845,1529,5201,1029,4161,1021]

theorem envBound8145 : H12AffineFastState.Bounded env8145 := by
  intro p hp
  have h : env8145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8144_8145 : H12AffineEnvironment.transform 13 492 env8144 = env8145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 492 env8144 == env8145) = true)

theorem identity8145 : scanCanonicalize (H12AffineFastState.compose env8145 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound8145 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8146 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,4096,8192,492,8692,8235,4605,262144,4433,8692,545,136,4281,35,8329,4641,262281,4265,4437,2080,816,508,4180,0,4161,1021]

theorem envBound8146 : H12AffineFastState.Bounded env8146 := by
  intro p hp
  have h : env8146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8145_8146 : H12AffineEnvironment.transform 9 5 env8145 = env8146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env8145 == env8146) = true)

theorem identity8146 : scanCanonicalize (H12AffineFastState.compose env8146 (packedSelected [0,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound8146 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env8147 : List Nat := [2,4,8,16,32,64,128,253,512,5,2048,4096,8192,17,8201,8235,4096,262144,4268,8201,545,136,4281,35,8329,4641,262281,4265,4264,2080,717,1,4180,0,4161,512]

theorem envBound8147 : H12AffineFastState.Bounded env8147 := by
  intro p hp
  have h : env8147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8146_8147 : H12AffineEnvironment.transform 7 253 env8146 = env8147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env8146 == env8147) = true)

def env8148 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,26050,4605,262144,524288,8692,529265,16740,525805,35,8329,21453,279904,5292,5456,19913,530020,1529,525568,17897,540925,1021]

theorem envBound8148 : H12AffineFastState.Bounded env8148 := by
  intro p hp
  have h : env8148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8129_8148 : H12AffineEnvironment.transform 20 529265 env8129 = env8148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529265 env8129 == env8148) = true)

theorem identity8148 : scanCanonicalize (H12AffineFastState.compose env8148 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound8148 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env8149 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,25663,4096,262144,524288,8201,529036,16537,525328,35,8329,21040,279709,5292,5293,19508,530020,1028,525565,17428,540925,512]

theorem envBound8149 : H12AffineFastState.Bounded env8149 := by
  intro p hp
  have h : env8149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8148_8149 : H12AffineEnvironment.transform 7 253 env8148 = env8149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env8148 == env8149) = true)

theorem identity8149 : scanCanonicalize (H12AffineFastState.compose env8149 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 17) := by decide +kernel

theorem selectedBound8149 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env8150 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,17,8201,9262,4096,262144,524288,8201,529036,136,525328,35,8329,4641,263308,5292,5293,3109,530020,1028,525565,1029,524524,512]

theorem envBound8150 : H12AffineFastState.Bounded env8150 := by
  intro p hp
  have h : env8150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8149_8150 : H12AffineEnvironment.transform 13 17 env8149 = env8150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env8149 == env8150) = true)

theorem identity8150 : scanCanonicalize (H12AffineFastState.compose env8150 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound8150 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8151 : List Nat := [2,4,8,16,32,64,128,253,512,4,2048,4096,8192,17,8201,8234,4096,262144,524288,8201,529036,136,524308,35,8329,4641,262280,4264,4265,2081,528992,0,524537,1,524524,512]

theorem envBound8151 : H12AffineFastState.Bounded env8151 := by
  intro p hp
  have h : env8151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8150_8151 : H12AffineEnvironment.transform 9 4 env8150 = env8151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env8150 == env8151) = true)

theorem identity8151 : scanCanonicalize (H12AffineFastState.compose env8151 (packedSelected [2,11,13,14,17,18] rootPS)) = affineNative (2^(18+1) ^^^ 4269) := by decide +kernel

theorem selectedBound8151 : packedSelected [2,11,13,14,17,18] rootPS < 2^1333 := by decide +kernel

def env8152 : List Nat := [2,4,8,16,32,64,128,253,512,4,2048,4096,8192,17,8201,8234,4096,262144,4269,8201,545,136,4281,35,8329,4641,262280,4264,4265,2081,717,0,4180,1,4161,512]

theorem envBound8152 : H12AffineFastState.Bounded env8152 := by
  intro p hp
  have h : env8152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8151_8152 : H12AffineEnvironment.transform 18 4269 env8151 = env8152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4269 env8151 == env8152) = true)

theorem identity8152 : scanCanonicalize (H12AffineFastState.compose env8152 (packedSelected [2,11,12,13,14,15,23] rootPS)) = affineNative (2^(17+1) ^^^ 14545) := by decide +kernel

theorem selectedBound8152 : packedSelected [2,11,12,13,14,15,23] rootPS < 2^1333 := by decide +kernel

def env8153 : List Nat := [2,4,8,16,32,64,128,253,512,4,2048,4096,8192,17,8201,8234,4096,14545,4269,8201,545,136,4281,35,8329,4641,14425,4264,4265,2081,717,0,4180,1,4161,512]

theorem envBound8153 : H12AffineFastState.Bounded env8153 := by
  intro p hp
  have h : env8153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8152_8153 : H12AffineEnvironment.transform 17 14545 env8152 = env8153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 14545 env8152 == env8153) = true)

theorem identity8153 : scanCanonicalize (H12AffineFastState.compose env8153 (packedSelected [0,6,27] rootPS)) = affineNative (2^(12+1) ^^^ 6907) := by decide +kernel

theorem selectedBound8153 : packedSelected [0,6,27] rootPS < 2^1333 := by decide +kernel

def env8154 : List Nat := [2,4,8,16,32,64,128,253,512,4,2048,4096,6907,17,6898,6865,4096,554,4269,6898,545,136,4281,35,6770,4641,674,4264,4265,2081,717,0,4180,1,4161,512]

theorem envBound8154 : H12AffineFastState.Bounded env8154 := by
  intro p hp
  have h : env8154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8153_8154 : H12AffineEnvironment.transform 12 6907 env8153 = env8154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6907 env8153 == env8154) = true)

theorem identity8154 : scanCanonicalize (H12AffineFastState.compose env8154 (packedSelected [11,12,13,15,32] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound8154 : packedSelected [11,12,13,15,32] rootPS < 2^1333 := by decide +kernel

def env8155 : List Nat := [2,4,8,16,32,64,128,253,97,4,2048,4096,6298,17,6291,6320,4096,75,4269,6291,64,136,4281,35,6163,4160,195,4264,4265,2081,172,0,4180,1,4161,97]

theorem envBound8155 : H12AffineFastState.Bounded env8155 := by
  intro p hp
  have h : env8155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8154_8155 : H12AffineEnvironment.transform 8 97 env8154 = env8155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env8154 == env8155) = true)

theorem identity8155 : scanCanonicalize (H12AffineFastState.compose env8155 (packedSelected [2,13,14] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound8155 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env8156 : List Nat := [2,4,8,16,32,64,128,253,97,4,26,4096,4224,17,4233,4266,4096,75,4269,4233,64,136,4281,35,4105,4160,195,4264,4265,59,172,0,4180,1,4161,97]

theorem envBound8156 : H12AffineFastState.Bounded env8156 := by
  intro p hp
  have h : env8156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8155_8156 : H12AffineEnvironment.transform 10 26 env8155 = env8156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env8155 == env8156) = true)

theorem identity8156 : scanCanonicalize (H12AffineFastState.compose env8156 (packedSelected [0,4,6,7,9,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound8156 : packedSelected [0,4,6,7,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env8157 : List Nat := [2,4,8,16,32,64,128,253,97,4,26,81,209,17,216,251,81,75,252,216,64,136,232,35,88,17,195,249,248,59,172,0,5,1,16,97]

theorem envBound8157 : H12AffineFastState.Bounded env8157 := by
  intro p hp
  have h : env8157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8156_8157 : H12AffineEnvironment.transform 11 81 env8156 = env8157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env8156 == env8157) = true)

theorem identity8157 : scanCanonicalize (H12AffineFastState.compose env8157 (packedSelected [0,2,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound8157 : packedSelected [0,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env8158 : List Nat := [2,4,8,16,32,64,88,37,97,4,26,81,9,17,0,35,81,75,36,0,64,80,48,35,88,17,27,33,32,59,116,0,5,1,16,97]

theorem envBound8158 : H12AffineFastState.Bounded env8158 := by
  intro p hp
  have h : env8158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8157_8158 : H12AffineEnvironment.transform 6 88 env8157 = env8158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env8157 == env8158) = true)

theorem identity8158 : scanCanonicalize (H12AffineFastState.compose env8158 (packedSelected [1,4] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound8158 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env8159 : List Nat := [2,4,8,16,32,48,40,37,17,4,26,33,9,17,0,35,33,59,36,0,48,32,48,35,40,17,27,33,32,59,4,0,5,1,16,17]

theorem envBound8159 : H12AffineFastState.Bounded env8159 := by
  intro p hp
  have h : env8159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8158_8159 : H12AffineEnvironment.transform 5 48 env8158 = env8159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env8158 == env8159) = true)

theorem identity8159 : scanCanonicalize (H12AffineFastState.compose env8159 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound8159 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env8160 : List Nat := [2,4,8,16,27,11,19,30,17,4,26,26,9,17,0,24,26,0,31,0,11,27,11,24,19,17,27,26,27,0,4,0,5,1,16,17]

theorem envBound8160 : H12AffineFastState.Bounded env8160 := by
  intro p hp
  have h : env8160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8159_8160 : H12AffineEnvironment.transform 4 27 env8159 = env8160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env8159 == env8160) = true)

theorem identity8160 : scanCanonicalize (H12AffineFastState.compose env8160 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8160 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8161 : List Nat := [2,4,2,16,17,1,19,20,17,4,16,16,3,17,0,18,16,0,21,0,1,17,1,18,19,17,17,16,17,0,4,0,5,1,16,17]

theorem envBound8161 : H12AffineFastState.Bounded env8161 := by
  intro p hp
  have h : env8161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8160_8161 : H12AffineEnvironment.transform 2 2 env8160 = env8161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8160 == env8161) = true)

def leafEnv8161 : List Nat := [2,4,2,16,17,1,19,20,17,4,16,16,3,17,0,18,16,0,21,0,1,17,1,18,21,19,1,17,17,16,17,0,4,0,5,1,21,3,16,17,1,1,0]

def active8161 : List Nat := [0,1,3]

def tree8161 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8161 : H12WitnessSearch.Good tree8161 := H12GlobalWitnessIndex.good

theorem leafIdentity8161 : H12AffineFastState.composeSystem env8161 rootObs = leafEnv8161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8161 rootObs == leafEnv8161) = true)

theorem terminalChecked8161 : H12PackedTerminal.terminalCheckFast leafEnv8161 active8161 tree8161 = true := by decide +kernel

def env8162 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,16740,525805,16777216,8329,79375,279905,5293,5457,16797163,17307207,16778715,525568,16795083,2118541,16778206]

theorem envBound8162 : H12AffineFastState.Bounded env8162 := by
  intro p hp
  have h : env8162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8109_8162 : H12AffineEnvironment.transform 26 279905 env8109 = env8162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 279905 env8109 == env8162) = true)

def env8163 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,16740,525805,91616,8329,79375,279905,5293,5457,75787,619431,90171,525568,73771,2118541,91710]

theorem envBound8163 : H12AffineFastState.Bounded env8163 := by
  intro p hp
  have h : env8163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8162_8163 : H12AffineEnvironment.transform 23 91616 env8162 = env8163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 91616 env8162 == env8163) = true)

theorem identity8163 : scanCanonicalize (H12AffineFastState.compose env8163 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 26051) := by decide +kernel

theorem selectedBound8163 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8164 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,26051,4605,262144,524288,8692,2097152,16740,525805,35,8329,21452,279905,5293,5457,19912,530020,1528,525568,17896,2118541,1021]

theorem envBound8164 : H12AffineFastState.Bounded env8164 := by
  intro p hp
  have h : env8164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8163_8164 : H12AffineEnvironment.transform 15 26051 env8163 = env8164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26051 env8163 == env8164) = true)

def env8165 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,26051,4605,262144,524288,8692,529264,16740,525805,35,8329,21452,279905,5293,5457,19912,530020,1528,525568,17896,540925,1021]

theorem envBound8165 : H12AffineFastState.Bounded env8165 := by
  intro p hp
  have h : env8165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8164_8165 : H12AffineEnvironment.transform 20 529264 env8164 = env8165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529264 env8164 == env8165) = true)

def env8166 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,26051,4605,262144,4432,8692,544,16740,5309,35,8329,21452,279905,5293,5457,19912,1844,1528,5200,17896,20909,1021]

theorem envBound8166 : H12AffineFastState.Bounded env8166 := by
  intro p hp
  have h : env8166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8165_8166 : H12AffineEnvironment.transform 18 4432 env8165 = env8166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4432 env8165 == env8166) = true)

theorem identity8166 : scanCanonicalize (H12AffineFastState.compose env8166 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 492) := by decide +kernel

theorem selectedBound8166 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env8167 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,492,8692,9263,4605,262144,4432,8692,544,136,5309,35,8329,4640,263309,5293,5457,3108,1844,1528,5200,1028,4161,1021]

theorem envBound8167 : H12AffineFastState.Bounded env8167 := by
  intro p hp
  have h : env8167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8166_8167 : H12AffineEnvironment.transform 13 492 env8166 = env8167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 492 env8166 == env8167) = true)

theorem identity8167 : scanCanonicalize (H12AffineFastState.compose env8167 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound8167 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8168 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,8192,492,8692,8235,4605,262144,4432,8692,544,136,4281,35,8329,4640,262281,4265,4437,2080,816,508,4180,0,4161,1021]

theorem envBound8168 : H12AffineFastState.Bounded env8168 := by
  intro p hp
  have h : env8168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8167_8168 : H12AffineEnvironment.transform 9 4 env8167 = env8168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env8167 == env8168) = true)

theorem identity8168 : scanCanonicalize (H12AffineFastState.compose env8168 (packedSelected [0,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound8168 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env8169 : List Nat := [2,4,8,16,32,64,128,253,512,4,2048,4096,8192,17,8201,8235,4096,262144,4269,8201,544,136,4281,35,8329,4640,262281,4265,4264,2080,717,1,4180,0,4161,512]

theorem envBound8169 : H12AffineFastState.Bounded env8169 := by
  intro p hp
  have h : env8169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8168_8169 : H12AffineEnvironment.transform 7 253 env8168 = env8169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env8168 == env8169) = true)

def env8170 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,26051,4605,262144,4433,8692,545,16740,5308,35,8329,21452,279905,5293,5457,19912,1845,1528,5201,17896,20908,1021]

theorem envBound8170 : H12AffineFastState.Bounded env8170 := by
  intro p hp
  have h : env8170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8165_8170 : H12AffineEnvironment.transform 18 4433 env8165 = env8170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4433 env8165 == env8170) = true)

theorem identity8170 : scanCanonicalize (H12AffineFastState.compose env8170 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 17) := by decide +kernel

theorem selectedBound8170 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env8171 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,17,8692,9682,4605,262144,4433,8692,545,373,5308,35,8329,5085,263536,5293,5457,3545,1845,1528,5201,1529,4541,1021]

theorem envBound8171 : H12AffineFastState.Bounded env8171 := by
  intro p hp
  have h : env8171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8170_8171 : H12AffineEnvironment.transform 13 17 env8170 = env8171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env8170 == env8171) = true)

theorem identity8171 : scanCanonicalize (H12AffineFastState.compose env8171 (packedSelected [2,14,23,32] rootPS)) = affineNative (2^(9+1) ^^^ 613) := by decide +kernel

theorem selectedBound8171 : packedSelected [2,14,23,32] rootPS < 2^1333 := by decide +kernel

def env8172 : List Nat := [2,4,8,16,32,64,128,256,512,613,2048,4096,8192,17,8692,9143,4605,262144,4433,8692,545,373,4825,35,8329,5085,262933,4808,4916,3004,336,925,4660,924,4541,1021]

theorem envBound8172 : H12AffineFastState.Bounded env8172 := by
  intro p hp
  have h : env8172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8171_8172 : H12AffineEnvironment.transform 9 613 env8171 = env8172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 613 env8171 == env8172) = true)

theorem identity8172 : scanCanonicalize (H12AffineFastState.compose env8172 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 7148) := by decide +kernel

theorem selectedBound8172 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8173 : List Nat := [2,4,8,16,32,64,128,256,512,613,2048,4096,8192,17,8692,9143,4605,7148,4433,8692,545,373,4825,35,8329,5085,6393,4808,4916,3004,336,925,4660,924,4541,1021]

theorem envBound8173 : H12AffineFastState.Bounded env8173 := by
  intro p hp
  have h : env8173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8172_8173 : H12AffineEnvironment.transform 17 7148 env8172 = env8173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7148 env8172 == env8173) = true)

theorem identity8173 : scanCanonicalize (H12AffineFastState.compose env8173 (packedSelected [1,2,3,8,10,11,14,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 664) := by decide +kernel

theorem selectedBound8173 : packedSelected [1,2,3,8,10,11,14,23,24] rootPS < 2^1333 := by decide +kernel

def env8174 : List Nat := [2,4,8,16,32,64,128,256,512,613,2048,664,8192,17,8692,9143,869,2420,969,8692,545,373,65,35,8329,325,2657,80,428,3004,336,925,172,924,805,1021]

theorem envBound8174 : H12AffineFastState.Bounded env8174 := by
  intro p hp
  have h : env8174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8173_8174 : H12AffineEnvironment.transform 11 664 env8173 = env8174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 664 env8173 == env8174) = true)

theorem identity8174 : scanCanonicalize (H12AffineFastState.compose env8174 (packedSelected [0,4,7,9,11,12,14,15,23] rootPS)) = affineNative (2^(8+1) ^^^ 492) := by decide +kernel

theorem selectedBound8174 : packedSelected [0,4,7,9,11,12,14,15,23] rootPS < 2^1333 := by decide +kernel

def env8175 : List Nat := [2,4,8,16,32,64,128,256,492,393,2048,372,8192,17,8692,8283,137,2420,37,8692,461,373,65,35,8329,325,2445,80,428,2128,336,113,172,112,201,17]

theorem envBound8175 : H12AffineFastState.Bounded env8175 := by
  intro p hp
  have h : env8175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8174_8175 : H12AffineEnvironment.transform 8 492 env8174 = env8175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 492 env8174 == env8175) = true)

theorem identity8175 : scanCanonicalize (H12AffineFastState.compose env8175 (packedSelected [3,5,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound8175 : packedSelected [3,5,10,11,12] rootPS < 2^1333 := by decide +kernel

def env8176 : List Nat := [2,4,8,16,32,64,128,85,185,220,2048,33,8192,17,8353,8283,137,2081,37,8353,152,32,65,35,8329,16,2264,80,249,2128,5,113,172,112,201,17]

theorem envBound8176 : H12AffineFastState.Bounded env8176 := by
  intro p hp
  have h : env8176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8175_8176 : H12AffineEnvironment.transform 7 85 env8175 = env8176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env8175 == env8176) = true)

theorem identity8176 : scanCanonicalize (H12AffineFastState.compose env8176 (packedSelected [0,2,3,4,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound8176 : packedSelected [0,2,3,4,6,8] rootPS < 2^1333 := by decide +kernel

def env8177 : List Nat := [2,4,8,16,32,64,128,85,185,220,33,33,8192,17,8353,8283,137,0,37,8353,152,32,65,35,8329,16,249,80,249,113,5,113,172,112,201,17]

theorem envBound8177 : H12AffineFastState.Bounded env8177 := by
  intro p hp
  have h : env8177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8176_8177 : H12AffineEnvironment.transform 10 33 env8176 = env8177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env8176 == env8177) = true)

theorem identity8177 : scanCanonicalize (H12AffineFastState.compose env8177 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 50) := by decide +kernel

theorem selectedBound8177 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env8178 : List Nat := [2,4,8,16,32,64,128,85,185,220,33,33,50,17,147,105,137,0,37,147,152,32,65,35,187,16,249,80,249,113,5,113,172,112,201,17]

theorem envBound8178 : H12AffineFastState.Bounded env8178 := by
  intro p hp
  have h : env8178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8177_8178 : H12AffineEnvironment.transform 12 50 env8177 = env8178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 50 env8177 == env8178) = true)

theorem identity8178 : scanCanonicalize (H12AffineFastState.compose env8178 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound8178 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env8179 : List Nat := [2,4,8,16,32,11,128,30,185,151,33,33,50,17,147,34,137,0,37,147,152,32,10,35,187,16,178,27,178,58,5,58,172,59,130,17]

theorem envBound8179 : H12AffineFastState.Bounded env8179 := by
  intro p hp
  have h : env8179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8178_8179 : H12AffineEnvironment.transform 5 11 env8178 = env8179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env8178 == env8179) = true)

theorem identity8179 : scanCanonicalize (H12AffineFastState.compose env8179 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound8179 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env8180 : List Nat := [2,4,8,16,27,11,128,30,130,151,26,26,9,17,147,25,137,0,30,147,152,27,10,24,128,16,137,27,137,1,5,1,151,0,130,17]

theorem envBound8180 : H12AffineFastState.Bounded env8180 := by
  intro p hp
  have h : env8180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8179_8180 : H12AffineEnvironment.transform 4 27 env8179 = env8180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env8179 == env8180) = true)

theorem identity8180 : scanCanonicalize (H12AffineFastState.compose env8180 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound8180 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8181 : List Nat := [2,4,8,16,27,11,19,30,17,4,26,26,9,17,0,25,26,0,30,0,11,27,10,24,19,16,26,27,26,1,5,1,4,0,17,17]

theorem envBound8181 : H12AffineFastState.Bounded env8181 := by
  intro p hp
  have h : env8181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8180_8181 : H12AffineEnvironment.transform 6 19 env8180 = env8181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env8180 == env8181) = true)

theorem identity8181 : scanCanonicalize (H12AffineFastState.compose env8181 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8181 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8182 : List Nat := [2,4,2,16,17,1,19,20,17,4,16,16,3,17,0,19,16,0,20,0,1,17,0,18,19,16,16,17,16,1,5,1,4,0,17,17]

theorem envBound8182 : H12AffineFastState.Bounded env8182 := by
  intro p hp
  have h : env8182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8181_8182 : H12AffineEnvironment.transform 2 2 env8181 = env8182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8181 == env8182) = true)

def leafEnv8182 : List Nat := [2,4,2,16,17,1,19,20,17,4,16,16,3,17,0,19,16,0,20,0,1,17,0,18,21,19,1,16,16,17,16,1,5,1,4,0,20,2,17,17,1,0,0]

def active8182 : List Nat := [0,1,3]

def tree8182 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8182 : H12WitnessSearch.Good tree8182 := H12GlobalWitnessIndex.good

theorem leafIdentity8182 : H12AffineFastState.composeSystem env8182 rootObs = leafEnv8182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8182 rootObs == leafEnv8182) = true)

theorem terminalChecked8182 : H12PackedTerminal.terminalCheckFast leafEnv8182 active8182 tree8182 = true := by decide +kernel

def env8183 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,26051,4605,262144,524288,8692,529265,16740,525805,35,8329,21452,279905,5293,5457,19912,530020,1528,525568,17896,540924,1021]

theorem envBound8183 : H12AffineFastState.Bounded env8183 := by
  intro p hp
  have h : env8183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8164_8183 : H12AffineEnvironment.transform 20 529265 env8164 = env8183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529265 env8164 == env8183) = true)

theorem identity8183 : scanCanonicalize (H12AffineFastState.compose env8183 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound8183 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env8184 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,25662,4096,262144,524288,8201,529036,16537,525328,35,8329,21041,279708,5293,5292,19509,530020,1029,525565,17429,540924,512]

theorem envBound8184 : H12AffineFastState.Bounded env8184 := by
  intro p hp
  have h : env8184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8183_8184 : H12AffineEnvironment.transform 7 253 env8183 = env8184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env8183 == env8184) = true)

theorem identity8184 : scanCanonicalize (H12AffineFastState.compose env8184 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 17) := by decide +kernel

theorem selectedBound8184 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env8185 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,17,8201,9263,4096,262144,524288,8201,529036,136,525328,35,8329,4640,263309,5293,5292,3108,530020,1029,525565,1028,524525,512]

theorem envBound8185 : H12AffineFastState.Bounded env8185 := by
  intro p hp
  have h : env8185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8184_8185 : H12AffineEnvironment.transform 13 17 env8184 = env8185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env8184 == env8185) = true)

theorem identity8185 : scanCanonicalize (H12AffineFastState.compose env8185 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound8185 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8186 : List Nat := [2,4,8,16,32,64,128,253,512,5,2048,4096,8192,17,8201,8234,4096,262144,524288,8201,529036,136,524309,35,8329,4640,262280,4264,4265,2081,528993,0,524536,1,524525,512]

theorem envBound8186 : H12AffineFastState.Bounded env8186 := by
  intro p hp
  have h : env8186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8185_8186 : H12AffineEnvironment.transform 9 5 env8185 = env8186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env8185 == env8186) = true)

theorem identity8186 : scanCanonicalize (H12AffineFastState.compose env8186 (packedSelected [2,11,13,14,17,18] rootPS)) = affineNative (2^(18+1) ^^^ 4268) := by decide +kernel

end H12CloudChart0