import H12CloudChart0Data105

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound26849 : H12AffineFastState.Bounded env26849 := by
  intro p hp
  have h : env26849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26848_26849 : H12AffineEnvironment.transform 17 10400 env26848 = env26849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env26848 == env26849) = true)

theorem identity26849 : scanCanonicalize (H12AffineFastState.compose env26849 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound26849 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10400,1024,8541,77899,32,73874,73736,8328,64,203847,79250,4232,212079,75223,73890,256,32,5592,513]

theorem envBound26850 : H12AffineFastState.Bounded env26850 := by
  intro p hp
  have h : env26850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26849_26850 : H12AffineEnvironment.transform 20 77899 env26849 = env26850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env26849 == env26850) = true)

theorem identity26850 : scanCanonicalize (H12AffineFastState.compose env26850 (packedSelected [2,4,6,7,9,11,12,15,16,18,20,27] rootPS)) = affineNative (2^(16+1) ^^^ 79251) := by decide +kernel

theorem selectedBound26850 : packedSelected [2,4,6,7,9,11,12,15,16,18,20,27] rootPS < 2^1333 := by decide +kernel

def env26851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,79251,10400,1024,8541,77899,32,73874,73736,8328,64,10708,79250,4232,2556,75223,73890,256,32,5592,513]

theorem envBound26851 : H12AffineFastState.Bounded env26851 := by
  intro p hp
  have h : env26851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26850_26851 : H12AffineEnvironment.transform 16 79251 env26850 = env26851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79251 env26850 == env26851) = true)

theorem identity26851 : scanCanonicalize (H12AffineFastState.compose env26851 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound26851 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env26852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8203,5528,10400,1024,8541,4160,32,153,3,8328,64,10708,5529,4232,2556,1500,169,256,32,5592,513]

theorem envBound26852 : H12AffineFastState.Bounded env26852 := by
  intro p hp
  have h : env26852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26851_26852 : H12AffineEnvironment.transform 15 8203 env26851 = env26852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env26851 == env26852) = true)

theorem identity26852 : scanCanonicalize (H12AffineFastState.compose env26852 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound26852 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env26853 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8203,5393,10281,1024,8541,4160,32,16,3,8193,64,10589,5392,4097,2421,1365,32,256,32,5457,513]

theorem envBound26853 : H12AffineFastState.Bounded env26853 := by
  intro p hp
  have h : env26853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26852_26853 : H12AffineEnvironment.transform 6 9 env26852 = env26853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26852 == env26853) = true)

theorem identity26853 : scanCanonicalize (H12AffineFastState.compose env26853 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26853 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26854 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8461,8203,5393,10281,1024,8460,4113,32,16,3,8193,17,10508,5392,4097,2340,1284,32,256,32,5376,513]

theorem envBound26854 : H12AffineFastState.Bounded env26854 := by
  intro p hp
  have h : env26854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26853_26854 : H12AffineEnvironment.transform 5 17 env26853 = env26854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26853 == env26854) = true)

theorem identity26854 : scanCanonicalize (H12AffineFastState.compose env26854 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 1305) := by decide +kernel

theorem selectedBound26854 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26855 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,1305,5376,1044,1298,5393,3376,1024,1045,4113,32,16,3,1304,17,3093,5392,4097,2340,1284,32,256,32,5376,513]

theorem envBound26855 : H12AffineFastState.Bounded env26855 := by
  intro p hp
  have h : env26855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26854_26855 : H12AffineEnvironment.transform 12 1305 env26854 = env26855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1305 env26854 == env26855) = true)

theorem identity26855 : scanCanonicalize (H12AffineFastState.compose env26855 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound26855 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env26856 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,301,4404,32,294,4389,2308,52,33,4113,32,16,3,300,17,2081,4388,4097,2340,304,32,256,32,4404,513]

theorem envBound26856 : H12AffineFastState.Bounded env26856 := by
  intro p hp
  have h : env26856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26855_26856 : H12AffineEnvironment.transform 9 52 env26855 = env26856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env26855 == env26856) = true)

theorem identity26856 : scanCanonicalize (H12AffineFastState.compose env26856 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 2324) := by decide +kernel

theorem selectedBound26856 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env26857 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,2324,301,2080,32,294,2097,2308,52,33,2309,32,16,3,300,17,2081,2096,2325,2340,304,32,256,32,2080,513]

theorem envBound26857 : H12AffineFastState.Bounded env26857 := by
  intro p hp
  have h : env26857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26856_26857 : H12AffineEnvironment.transform 11 2324 env26856 = env26857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2324 env26856 == env26857) = true)

theorem identity26857 : scanCanonicalize (H12AffineFastState.compose env26857 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound26857 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env26858 : List Nat := [2,4,8,16,32,17,9,256,309,52,2048,2324,301,2080,32,294,2097,2308,52,33,2309,32,16,3,300,17,2081,2096,2325,2340,304,32,256,32,2080,308]

theorem envBound26858 : H12AffineFastState.Bounded env26858 := by
  intro p hp
  have h : env26858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26857_26858 : H12AffineEnvironment.transform 8 309 env26857 = env26858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env26857 == env26858) = true)

theorem identity26858 : scanCanonicalize (H12AffineFastState.compose env26858 (packedSelected [0,4,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound26858 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env26859 : List Nat := [2,4,8,16,32,17,9,37,16,52,2048,2097,8,2080,32,3,2097,2081,52,33,2080,32,16,3,9,17,2081,2096,2096,2049,21,32,37,32,2080,17]

theorem envBound26859 : H12AffineFastState.Bounded env26859 := by
  intro p hp
  have h : env26859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26858_26859 : H12AffineEnvironment.transform 7 37 env26858 = env26859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env26858 == env26859) = true)

theorem identity26859 : scanCanonicalize (H12AffineFastState.compose env26859 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound26859 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26860 : List Nat := [2,4,8,1,32,0,9,37,1,37,2048,2080,8,2080,32,3,2080,2081,37,33,2080,32,1,3,9,0,2081,2081,2081,2049,4,32,37,32,2080,0]

theorem envBound26860 : H12AffineFastState.Bounded env26860 := by
  intro p hp
  have h : env26860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26859_26860 : H12AffineEnvironment.transform 3 1 env26859 = env26860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env26859 == env26860) = true)

theorem identity26860 : scanCanonicalize (H12AffineFastState.compose env26860 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound26860 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26861 : List Nat := [2,4,8,1,32,0,9,37,1,37,33,1,8,1,32,3,1,0,37,33,1,32,1,3,9,0,0,0,0,32,4,32,37,32,1,0]

theorem envBound26861 : H12AffineFastState.Bounded env26861 := by
  intro p hp
  have h : env26861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26860_26861 : H12AffineEnvironment.transform 10 33 env26860 = env26861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env26860 == env26861) = true)

def env26862 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10401,1024,8541,2097152,32,2101465,73736,8328,64,2239501,2098649,4232,2231333,2102684,2101481,256,32,5592,2175562]

theorem envBound26862 : H12AffineFastState.Bounded env26862 := by
  intro p hp
  have h : env26862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26848_26862 : H12AffineEnvironment.transform 17 10401 env26848 = env26862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env26848 == env26862) = true)

theorem identity26862 : scanCanonicalize (H12AffineFastState.compose env26862 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound26862 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8322,131072,10401,1024,8541,2097152,32,2101465,138,8328,64,2239501,2098649,4232,2231333,2102684,2101481,256,32,5592,2101960]

theorem envBound26863 : H12AffineFastState.Bounded env26863 := by
  intro p hp
  have h : env26863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26862_26863 : H12AffineEnvironment.transform 15 8322 env26862 = env26863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env26862 == env26863) = true)

theorem identity26863 : scanCanonicalize (H12AffineFastState.compose env26863 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound26863 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env26864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8322,5528,10401,1024,8541,2097152,32,2101465,138,8328,64,2111893,2098649,4232,2103741,2102684,2101481,256,32,5592,2101960]

theorem envBound26864 : H12AffineFastState.Bounded env26864 := by
  intro p hp
  have h : env26864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26863_26864 : H12AffineEnvironment.transform 16 5528 env26863 = env26864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env26863 == env26864) = true)

theorem identity26864 : scanCanonicalize (H12AffineFastState.compose env26864 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound26864 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env26865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5376,217,263,5528,2340,1024,216,2097152,32,2101465,138,269,64,2103312,2098649,4232,2103741,2102684,2101481,256,32,5592,2101960]

theorem envBound26865 : H12AffineFastState.Bounded env26865 := by
  intro p hp
  have h : env26865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26864_26865 : H12AffineEnvironment.transform 12 389 env26864 = env26865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env26864 == env26865) = true)

theorem identity26865 : scanCanonicalize (H12AffineFastState.compose env26865 (packedSelected [1,3,5,8,11,12,14,15,16,18] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound26865 : packedSelected [1,3,5,8,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env26866 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,80,263,5393,2340,1024,81,2097152,32,2101328,3,269,64,2103312,2098512,4097,2103604,2102549,2101344,256,32,5457,2101825]

theorem envBound26866 : H12AffineFastState.Bounded env26866 := by
  intro p hp
  have h : env26866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26865_26866 : H12AffineEnvironment.transform 6 9 env26865 = env26866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26865 == env26866) = true)

theorem identity26866 : scanCanonicalize (H12AffineFastState.compose env26866 (packedSelected [6,7,9,10,11,12] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound26866 : packedSelected [6,7,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env26867 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,80,263,5393,2340,1024,81,4160,32,16,3,269,64,2128,5392,4097,2420,1365,32,256,32,5457,513]

theorem envBound26867 : H12AffineFastState.Bounded env26867 := by
  intro p hp
  have h : env26867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26866_26867 : H12AffineEnvironment.transform 20 4160 env26866 = env26867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env26866 == env26867) = true)

theorem identity26867 : scanCanonicalize (H12AffineFastState.compose env26867 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound26867 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env26868 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,4096,268,4405,80,263,4388,2340,53,81,4160,32,16,3,269,64,2128,4389,4097,2420,352,32,256,32,4452,513]

theorem envBound26868 : H12AffineFastState.Bounded env26868 := by
  intro p hp
  have h : env26868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26867_26868 : H12AffineEnvironment.transform 9 53 env26867 = env26868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env26867 == env26868) = true)

theorem identity26868 : scanCanonicalize (H12AffineFastState.compose env26868 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound26868 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env26869 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,2357,268,2048,80,263,2065,2340,53,81,2421,32,16,3,269,64,2128,2064,2356,2420,352,32,256,32,2129,513]

theorem envBound26869 : H12AffineFastState.Bounded env26869 := by
  intro p hp
  have h : env26869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26868_26869 : H12AffineEnvironment.transform 11 2357 env26868 = env26869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env26868 == env26869) = true)

theorem identity26869 : scanCanonicalize (H12AffineFastState.compose env26869 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound26869 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26870 : List Nat := [2,4,8,16,32,64,9,256,512,53,373,64,268,373,80,263,356,81,53,81,0,32,16,3,269,64,293,357,65,1,352,32,256,32,292,513]

theorem envBound26870 : H12AffineFastState.Bounded env26870 := by
  intro p hp
  have h : env26870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26869_26870 : H12AffineEnvironment.transform 10 373 env26869 = env26870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env26869 == env26870) = true)

theorem identity26870 : scanCanonicalize (H12AffineFastState.compose env26870 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26870 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26871 : List Nat := [2,4,8,16,32,16,9,256,512,53,293,16,268,293,0,263,308,1,53,1,0,32,16,3,269,16,293,309,17,1,304,32,256,32,292,513]

theorem envBound26871 : H12AffineFastState.Bounded env26871 := by
  intro p hp
  have h : env26871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26870_26871 : H12AffineEnvironment.transform 5 16 env26870 = env26871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26870 == env26871) = true)

def env26872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,33,2101465,98644,8328,64,2491565,2098649,4232,2524632,2102684,2142644,256,32,46212,2175562]

theorem envBound26872 : H12AffineFastState.Bounded env26872 := by
  intro p hp
  have h : env26872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26846_26872 : H12AffineEnvironment.transform 21 33 env26846 = env26872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env26846 == env26872) = true)

theorem identity26872 : scanCanonicalize (H12AffineFastState.compose env26872 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 45461) := by decide +kernel

theorem selectedBound26872 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,45461,33,41292,98644,8328,64,439608,46156,4232,406605,41993,33,256,32,46212,99295]

theorem envBound26873 : H12AffineFastState.Bounded env26873 := by
  intro p hp
  have h : env26873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26872_26873 : H12AffineEnvironment.transform 20 45461 env26872 = env26873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 45461 env26872 == env26873) = true)

theorem identity26873 : scanCanonicalize (H12AffineFastState.compose env26873 (packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 108926) := by decide +kernel

theorem selectedBound26873 : packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env26874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,108926,1024,32769,45461,33,41292,98644,8328,64,203846,46156,4232,236851,41993,33,256,32,46212,99295]

theorem envBound26874 : H12AffineFastState.Bounded env26874 := by
  intro p hp
  have h : env26874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26873_26874 : H12AffineEnvironment.transform 17 108926 env26873 = env26874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108926 env26873 == env26874) = true)

theorem identity26874 : scanCanonicalize (H12AffineFastState.compose env26874 (packedSelected [0,1,3,5,8,9,11,12,15,16,18,20,21,22,26,27,31] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound26874 : packedSelected [0,1,3,5,8,9,11,12,15,16,18,20,21,22,26,27,31] rootPS < 2^1333 := by decide +kernel

def env26875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,33246,131072,10400,1024,32769,45461,33,41292,138,8328,64,171416,46156,4232,138477,41993,33,256,32,46212,513]

theorem envBound26875 : H12AffineFastState.Bounded env26875 := by
  intro p hp
  have h : env26875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26874_26875 : H12AffineEnvironment.transform 15 33246 env26874 = env26875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env26874 == env26875) = true)

theorem identity26875 : scanCanonicalize (H12AffineFastState.compose env26875 (packedSelected [0,7,9,11,12,14,15,18,20,21,22] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound26875 : packedSelected [0,7,9,11,12,14,15,18,20,21,22] rootPS < 2^1333 := by decide +kernel

def env26876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,33246,13340,10400,1024,32769,45461,33,41292,138,8328,64,43396,46156,4232,10481,41993,33,256,32,46212,513]

theorem envBound26876 : H12AffineFastState.Bounded env26876 := by
  intro p hp
  have h : env26876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26875_26876 : H12AffineEnvironment.transform 16 13340 env26875 = env26876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env26875 == env26876) = true)

theorem identity26876 : scanCanonicalize (H12AffineFastState.compose env26876 (packedSelected [0,1,2,6,7,8,10,11,14,15,16,20,21] rootPS)) = affineNative (2^(14+1) ^^^ 217) := by decide +kernel

theorem selectedBound26876 : packedSelected [0,1,2,6,7,8,10,11,14,15,16,20,21] rootPS < 2^1333 := by decide +kernel

def env26877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,217,263,13340,10400,1024,216,12620,33,8597,138,8328,64,10589,13461,4232,10481,9424,33,256,32,13405,513]

theorem envBound26877 : H12AffineFastState.Bounded env26877 := by
  intro p hp
  have h : env26877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26876_26877 : H12AffineEnvironment.transform 14 217 env26876 = env26877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 217 env26876 == env26877) = true)

theorem identity26877 : scanCanonicalize (H12AffineFastState.compose env26877 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound26877 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env26878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5376,217,263,5529,2341,1024,216,4297,33,16,138,269,64,2264,5392,4232,2420,1365,33,256,32,5592,513]

theorem envBound26878 : H12AffineFastState.Bounded env26878 := by
  intro p hp
  have h : env26878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26877_26878 : H12AffineEnvironment.transform 12 389 env26877 = env26878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env26877 == env26878) = true)

theorem identity26878 : scanCanonicalize (H12AffineFastState.compose env26878 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 347) := by decide +kernel

theorem selectedBound26878 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env26879 : List Nat := [2,4,8,16,32,64,128,256,512,347,2048,4096,389,4187,217,263,4290,2341,347,216,4297,33,16,138,269,64,2264,4171,4232,2420,14,33,256,32,4227,513]

theorem envBound26879 : H12AffineFastState.Bounded env26879 := by
  intro p hp
  have h : env26879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26878_26879 : H12AffineEnvironment.transform 9 347 env26878 = env26879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 347 env26878 == env26879) = true)

theorem identity26879 : scanCanonicalize (H12AffineFastState.compose env26879 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound26879 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env26880 : List Nat := [2,4,8,16,32,64,89,256,512,347,2048,4096,348,4187,0,263,4123,2341,347,1,4112,33,16,83,269,64,2049,4171,4177,2420,14,33,256,32,4186,513]

theorem envBound26880 : H12AffineFastState.Bounded env26880 := by
  intro p hp
  have h : env26880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26879_26880 : H12AffineEnvironment.transform 6 89 env26879 = env26880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env26879 == env26880) = true)

theorem identity26880 : scanCanonicalize (H12AffineFastState.compose env26880 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26880 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26881 : List Nat := [2,4,8,16,32,16,9,256,512,267,2048,4096,268,4107,0,263,4123,2341,267,1,4112,33,16,3,269,16,2049,4123,4097,2340,14,33,256,32,4106,513]

theorem envBound26881 : H12AffineFastState.Bounded env26881 := by
  intro p hp
  have h : env26881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26880_26881 : H12AffineEnvironment.transform 5 16 env26880 = env26881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26880 == env26881) = true)

theorem identity26881 : scanCanonicalize (H12AffineFastState.compose env26881 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound26881 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26882 : List Nat := [2,4,8,16,32,16,9,256,512,267,2048,0,268,11,0,263,27,2341,267,1,16,33,16,3,269,16,2049,27,1,2340,14,33,256,32,10,513]

theorem envBound26882 : H12AffineFastState.Bounded env26882 := by
  intro p hp
  have h : env26882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26881_26882 : H12AffineEnvironment.transform 11 0 env26881 = env26882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env26881 == env26882) = true)

theorem identity26882 : scanCanonicalize (H12AffineFastState.compose env26882 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 303) := by decide +kernel

theorem selectedBound26882 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26883 : List Nat := [2,4,8,16,32,16,9,256,512,267,303,0,268,11,0,263,27,10,267,1,16,33,16,3,269,16,302,27,1,11,14,33,256,32,10,513]

theorem envBound26883 : H12AffineFastState.Bounded env26883 := by
  intro p hp
  have h : env26883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26882_26883 : H12AffineEnvironment.transform 10 303 env26882 = env26883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 303 env26882 == env26883) = true)

theorem identity26883 : scanCanonicalize (H12AffineFastState.compose env26883 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound26883 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26884 : List Nat := [2,4,8,16,11,16,9,256,512,267,260,0,268,11,0,263,27,10,267,1,16,10,16,3,269,16,261,27,1,11,14,10,256,11,10,513]

theorem envBound26884 : H12AffineFastState.Bounded env26884 := by
  intro p hp
  have h : env26884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26883_26884 : H12AffineEnvironment.transform 4 11 env26883 = env26884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env26883 == env26884) = true)

theorem identity26884 : scanCanonicalize (H12AffineFastState.compose env26884 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound26884 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26885 : List Nat := [2,4,8,16,11,16,9,14,512,5,10,0,2,11,0,9,27,10,5,1,16,10,16,3,3,16,11,27,1,11,14,10,14,11,10,513]

theorem envBound26885 : H12AffineFastState.Bounded env26885 := by
  intro p hp
  have h : env26885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26884_26885 : H12AffineEnvironment.transform 7 14 env26884 = env26885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env26884 == env26885) = true)

theorem identity26885 : scanCanonicalize (H12AffineFastState.compose env26885 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound26885 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26886 : List Nat := [2,4,8,5,11,5,9,14,512,5,10,0,2,11,0,9,14,10,5,1,5,10,5,3,3,5,11,14,1,11,14,10,14,11,10,513]

theorem envBound26886 : H12AffineFastState.Bounded env26886 := by
  intro p hp
  have h : env26886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26885_26886 : H12AffineEnvironment.transform 3 5 env26885 = env26886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env26885 == env26886) = true)

theorem identity26886 : scanCanonicalize (H12AffineFastState.compose env26886 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound26886 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env26887 : List Nat := [2,4,6,5,5,5,7,0,512,5,4,0,2,5,0,7,0,4,5,1,5,4,5,3,3,5,5,0,1,5,0,4,0,5,4,513]

theorem envBound26887 : H12AffineFastState.Bounded env26887 := by
  intro p hp
  have h : env26887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26886_26887 : H12AffineEnvironment.transform 2 6 env26886 = env26887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env26886 == env26887) = true)

theorem identity26887 : scanCanonicalize (H12AffineFastState.compose env26887 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound26887 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26888 : List Nat := [2,4,6,5,5,5,7,0,7,5,4,0,2,5,0,7,0,4,5,1,5,4,5,3,3,5,5,0,1,5,0,4,0,5,4,6]

theorem envBound26888 : H12AffineFastState.Bounded env26888 := by
  intro p hp
  have h : env26888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26887_26888 : H12AffineEnvironment.transform 8 7 env26887 = env26888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env26887 == env26888) = true)

def env26889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10588556,8328,64,6685836,8393985,10485840,8819968,2102685,12624204,256,32,46213,2175563]

theorem envBound26889 : H12AffineFastState.Bounded env26889 := by
  intro p hp
  have h : env26889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26809_26889 : H12AffineEnvironment.transform 13 5377 env26809 = env26889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env26809 == env26889) = true)

def env26890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,4194304,2101464,98644,8328,64,6685836,2098649,4232,2524632,2102685,6336916,256,32,46213,2175563]

theorem envBound26890 : H12AffineFastState.Bounded env26890 := by
  intro p hp
  have h : env26890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26889_26890 : H12AffineEnvironment.transform 22 2101464 env26889 = env26890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101464 env26889 == env26890) = true)

def env26891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,32,2101464,98644,8328,64,2491564,2098649,4232,2524632,2102685,2142644,256,32,46213,2175563]

theorem envBound26891 : H12AffineFastState.Bounded env26891 := by
  intro p hp
  have h : env26891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26890_26891 : H12AffineEnvironment.transform 21 32 env26890 = env26891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env26890 == env26891) = true)

theorem identity26891 : scanCanonicalize (H12AffineFastState.compose env26891 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 102678) := by decide +kernel

theorem selectedBound26891 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26892 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,32,98766,98644,8328,64,497082,103631,4232,464078,99467,73890,256,32,46213,41821]

theorem envBound26892 : H12AffineFastState.Bounded env26892 := by
  intro p hp
  have h : env26892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26891_26892 : H12AffineEnvironment.transform 20 102678 env26891 = env26892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 102678 env26891 == env26892) = true)

theorem identity26892 : scanCanonicalize (H12AffineFastState.compose env26892 (packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,21,23,24,26,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound26892 : packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,21,23,24,26,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env26893 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,77898,32,73874,73736,8328,64,472294,79251,4232,464078,75223,73890,256,32,5593,513]

theorem envBound26893 : H12AffineFastState.Bounded env26893 := by
  intro p hp
  have h : env26893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26892_26893 : H12AffineEnvironment.transform 14 8540 env26892 = env26893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env26892 == env26893) = true)

def env26894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10400,1024,8541,77898,32,73874,73736,8328,64,203846,79251,4232,212078,75223,73890,256,32,5593,513]

theorem envBound26894 : H12AffineFastState.Bounded env26894 := by
  intro p hp
  have h : env26894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26893_26894 : H12AffineEnvironment.transform 17 10400 env26893 = env26894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env26893 == env26894) = true)

theorem identity26894 : scanCanonicalize (H12AffineFastState.compose env26894 (packedSelected [2,4,6,7,9,11,12,15,16,18,20,27] rootPS)) = affineNative (2^(16+1) ^^^ 79250) := by decide +kernel

theorem selectedBound26894 : packedSelected [2,4,6,7,9,11,12,15,16,18,20,27] rootPS < 2^1333 := by decide +kernel

def env26895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,79250,10400,1024,8541,77898,32,73874,73736,8328,64,10708,79251,4232,2556,75223,73890,256,32,5593,513]

theorem envBound26895 : H12AffineFastState.Bounded env26895 := by
  intro p hp
  have h : env26895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26894_26895 : H12AffineEnvironment.transform 16 79250 env26894 = env26895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79250 env26894 == env26895) = true)

theorem identity26895 : scanCanonicalize (H12AffineFastState.compose env26895 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound26895 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env26896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,8203,5529,10400,1024,8541,4161,32,153,3,8328,64,10708,5528,4232,2556,1500,169,256,32,5593,513]

theorem envBound26896 : H12AffineFastState.Bounded env26896 := by
  intro p hp
  have h : env26896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26895_26896 : H12AffineEnvironment.transform 15 8203 env26895 = env26896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env26895 == env26896) = true)

theorem identity26896 : scanCanonicalize (H12AffineFastState.compose env26896 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound26896 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env26897 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8203,5392,10281,1024,8541,4161,32,16,3,8193,64,10589,5393,4097,2421,1365,32,256,32,5456,513]

theorem envBound26897 : H12AffineFastState.Bounded env26897 := by
  intro p hp
  have h : env26897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26896_26897 : H12AffineEnvironment.transform 6 9 env26896 = env26897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26896 == env26897) = true)

theorem identity26897 : scanCanonicalize (H12AffineFastState.compose env26897 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26897 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26898 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8461,8203,5392,10281,1024,8460,4112,32,16,3,8193,17,10508,5393,4097,2340,1284,32,256,32,5377,513]

theorem envBound26898 : H12AffineFastState.Bounded env26898 := by
  intro p hp
  have h : env26898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26897_26898 : H12AffineEnvironment.transform 5 17 env26897 = env26898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26897 == env26898) = true)

theorem identity26898 : scanCanonicalize (H12AffineFastState.compose env26898 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 1304) := by decide +kernel

theorem selectedBound26898 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26899 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,1304,5377,1045,1299,5392,3377,1024,1044,4112,32,16,3,1305,17,3092,5393,4097,2340,1284,32,256,32,5377,513]

theorem envBound26899 : H12AffineFastState.Bounded env26899 := by
  intro p hp
  have h : env26899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26898_26899 : H12AffineEnvironment.transform 12 1304 env26898 = env26899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1304 env26898 == env26899) = true)

theorem identity26899 : scanCanonicalize (H12AffineFastState.compose env26899 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound26899 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env26900 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,300,4405,33,295,4388,2309,52,32,4112,32,16,3,301,17,2080,4389,4097,2340,304,32,256,32,4405,513]

theorem envBound26900 : H12AffineFastState.Bounded env26900 := by
  intro p hp
  have h : env26900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26899_26900 : H12AffineEnvironment.transform 9 52 env26899 = env26900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env26899 == env26900) = true)

theorem identity26900 : scanCanonicalize (H12AffineFastState.compose env26900 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 2324) := by decide +kernel

theorem selectedBound26900 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env26901 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,2324,300,2081,33,295,2096,2309,52,32,2308,32,16,3,301,17,2080,2097,2325,2340,304,32,256,32,2081,513]

theorem envBound26901 : H12AffineFastState.Bounded env26901 := by
  intro p hp
  have h : env26901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26900_26901 : H12AffineEnvironment.transform 11 2324 env26900 = env26901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2324 env26900 == env26901) = true)

theorem identity26901 : scanCanonicalize (H12AffineFastState.compose env26901 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound26901 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env26902 : List Nat := [2,4,8,16,32,17,9,256,276,52,2048,2324,300,2081,33,295,2096,2309,52,32,2308,32,16,3,301,17,2080,2097,2325,2340,304,32,256,32,2081,277]

theorem envBound26902 : H12AffineFastState.Bounded env26902 := by
  intro p hp
  have h : env26902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26901_26902 : H12AffineEnvironment.transform 8 276 env26901 = env26902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env26901 == env26902) = true)

theorem identity26902 : scanCanonicalize (H12AffineFastState.compose env26902 (packedSelected [0,4,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound26902 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env26903 : List Nat := [2,4,8,16,32,17,9,36,48,52,2048,2096,8,2081,33,3,2096,2081,52,32,2080,32,16,3,9,17,2080,2097,2097,2048,20,32,36,32,2081,49]

theorem envBound26903 : H12AffineFastState.Bounded env26903 := by
  intro p hp
  have h : env26903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26902_26903 : H12AffineEnvironment.transform 7 36 env26902 = env26903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env26902 == env26903) = true)

theorem identity26903 : scanCanonicalize (H12AffineFastState.compose env26903 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound26903 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26904 : List Nat := [2,4,8,16,32,17,9,36,48,52,48,0,8,17,33,3,0,17,52,32,16,32,16,3,9,17,16,1,1,48,20,32,36,32,17,49]

theorem envBound26904 : H12AffineFastState.Bounded env26904 := by
  intro p hp
  have h : env26904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26903_26904 : H12AffineEnvironment.transform 10 48 env26903 = env26904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env26903 == env26904) = true)

theorem identity26904 : scanCanonicalize (H12AffineFastState.compose env26904 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound26904 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26905 : List Nat := [2,4,8,16,16,17,9,20,0,4,0,0,8,17,17,3,0,17,4,16,16,16,16,3,9,17,16,1,1,0,20,16,20,16,17,1]

theorem envBound26905 : H12AffineFastState.Bounded env26905 := by
  intro p hp
  have h : env26905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26904_26905 : H12AffineEnvironment.transform 4 16 env26904 = env26905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env26904 == env26905) = true)

theorem identity26905 : scanCanonicalize (H12AffineFastState.compose env26905 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound26905 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26906 : List Nat := [2,4,8,0,0,1,9,4,0,4,0,0,8,1,1,3,0,1,4,0,0,0,0,3,9,1,0,1,1,0,4,0,4,0,1,1]

theorem envBound26906 : H12AffineFastState.Bounded env26906 := by
  intro p hp
  have h : env26906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26905_26906 : H12AffineEnvironment.transform 3 0 env26905 = env26906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env26905 == env26906) = true)

def env26907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10401,1024,8541,77898,32,73874,73736,8328,64,203847,79251,4232,212079,75223,73890,256,32,5593,513]

theorem envBound26907 : H12AffineFastState.Bounded env26907 := by
  intro p hp
  have h : env26907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26893_26907 : H12AffineEnvironment.transform 17 10401 env26893 = env26907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env26893 == env26907) = true)

theorem identity26907 : scanCanonicalize (H12AffineFastState.compose env26907 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound26907 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env26908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,79131,10401,1024,8541,77898,32,73874,73736,8328,64,10588,79251,4232,2420,75223,73890,256,32,5593,513]

theorem envBound26908 : H12AffineFastState.Bounded env26908 := by
  intro p hp
  have h : env26908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26907_26908 : H12AffineEnvironment.transform 16 79131 env26907 = env26908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env26907 == env26908) = true)

theorem identity26908 : scanCanonicalize (H12AffineFastState.compose env26908 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 3465) := by decide +kernel

theorem selectedBound26908 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env26909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3465,8192,2184,8540,65536,75922,10401,1024,8541,77251,32,73874,73736,8328,64,10588,75802,3329,2420,75223,73890,256,32,2128,513]

theorem envBound26909 : H12AffineFastState.Bounded env26909 := by
  intro p hp
  have h : env26909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26908_26909 : H12AffineEnvironment.transform 11 3465 env26908 = env26909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3465 env26908 == env26909) = true)

theorem identity26909 : scanCanonicalize (H12AffineFastState.compose env26909 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound26909 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3465,8192,2184,8540,8322,2064,10401,1024,8541,3393,32,16,138,8328,64,10588,2200,3329,2420,1365,32,256,32,2128,513]

theorem envBound26910 : H12AffineFastState.Bounded env26910 := by
  intro p hp
  have h : env26910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26909_26910 : H12AffineEnvironment.transform 15 8322 env26909 = env26910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env26909 == env26910) = true)

theorem identity26910 : scanCanonicalize (H12AffineFastState.compose env26910 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound26910 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env26911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1416,8192,137,8540,8322,17,8352,1024,8541,1344,32,16,138,8328,64,8541,153,1280,373,1365,32,256,32,81,513]

theorem envBound26911 : H12AffineFastState.Bounded env26911 := by
  intro p hp
  have h : env26911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26910_26911 : H12AffineEnvironment.transform 10 1 env26910 = env26911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env26910 == env26911) = true)

theorem identity26911 : scanCanonicalize (H12AffineFastState.compose env26911 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound26911 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env26912 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1416,1337,137,1125,1467,17,1433,1024,1124,1344,32,16,138,1457,64,1124,153,1280,373,1365,32,256,32,81,513]

theorem envBound26912 : H12AffineFastState.Bounded env26912 := by
  intro p hp
  have h : env26912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26911_26912 : H12AffineEnvironment.transform 12 1337 env26911 = env26912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env26911 == env26912) = true)

theorem identity26912 : scanCanonicalize (H12AffineFastState.compose env26912 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound26912 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env26913 : List Nat := [2,4,8,16,32,64,128,256,512,53,1,445,268,137,80,398,17,428,53,81,373,32,16,138,388,64,81,153,309,373,352,32,256,32,81,513]

theorem envBound26913 : H12AffineFastState.Bounded env26913 := by
  intro p hp
  have h : env26913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26912_26913 : H12AffineEnvironment.transform 9 53 env26912 = env26913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env26912 == env26913) = true)

def env26914 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,33,2101464,98644,8328,64,2491565,2098649,4232,2524632,2102685,2142645,256,32,46213,2175563]

theorem envBound26914 : H12AffineFastState.Bounded env26914 := by
  intro p hp
  have h : env26914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26890_26914 : H12AffineEnvironment.transform 21 33 env26890 = env26914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env26890 == env26914) = true)

theorem identity26914 : scanCanonicalize (H12AffineFastState.compose env26914 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound26914 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,131072,262144,1024,32769,2097152,33,2101464,138,8328,64,2491565,2098649,4232,2524632,2102685,2142645,256,32,46213,2143125]

theorem envBound26915 : H12AffineFastState.Bounded env26915 := by
  intro p hp
  have h : env26915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26914_26915 : H12AffineEnvironment.transform 15 33246 env26914 = env26915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env26914 == env26915) = true)

theorem identity26915 : scanCanonicalize (H12AffineFastState.compose env26915 (packedSelected [0,1,9,11,12,14,15,18,19,22,23,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound26915 : packedSelected [0,1,9,11,12,14,15,18,19,22,23,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env26916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,131072,10400,1024,32769,2097152,33,2101464,138,8328,64,2239501,2098649,4232,2272632,2102685,2142645,256,32,46213,2143125]

theorem envBound26916 : H12AffineFastState.Bounded env26916 := by
  intro p hp
  have h : env26916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26915_26916 : H12AffineEnvironment.transform 17 10400 env26915 = env26916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env26915 == env26916) = true)

def env26917 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,131072,10280,1024,32769,2097152,33,2101328,2,8192,64,2239501,2098513,4096,2272632,2102549,2142525,256,32,46093,2143005]

theorem envBound26917 : H12AffineFastState.Bounded env26917 := by
  intro p hp
  have h : env26917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26916_26917 : H12AffineEnvironment.transform 6 8 env26916 = env26917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26916 == env26917) = true)

theorem identity26917 : scanCanonicalize (H12AffineFastState.compose env26917 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 45340) := by decide +kernel

theorem selectedBound26917 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26918 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,131072,10280,1024,32769,45340,33,41292,2,8192,64,171281,46157,4096,138340,41993,33,256,32,46093,513]

theorem envBound26918 : H12AffineFastState.Bounded env26918 := by
  intro p hp
  have h : env26918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26917_26918 : H12AffineEnvironment.transform 20 45340 env26917 = env26918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 45340 env26917 == env26918) = true)

theorem identity26918 : scanCanonicalize (H12AffineFastState.compose env26918 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound26918 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26919 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,131072,10280,1024,8540,4161,33,17,2,8192,64,146508,5392,4096,138340,1364,33,256,32,5456,513]

theorem envBound26919 : H12AffineFastState.Bounded env26919 := by
  intro p hp
  have h : env26919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26918_26919 : H12AffineEnvironment.transform 14 8541 env26918 = env26919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env26918 == env26919) = true)

theorem identity26919 : scanCanonicalize (H12AffineFastState.compose env26919 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound26919 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env26920 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,13340,10280,1024,8540,4161,33,17,2,8192,64,2128,5392,4096,10360,1364,33,256,32,5456,513]

theorem envBound26920 : H12AffineFastState.Bounded env26920 := by
  intro p hp
  have h : env26920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26919_26920 : H12AffineEnvironment.transform 16 13340 env26919 = env26920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env26919 == env26920) = true)

theorem identity26920 : scanCanonicalize (H12AffineFastState.compose env26920 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound26920 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env26921 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,5156,8312,8203,13340,10280,1024,8313,4161,33,17,2,8192,64,2128,5173,4096,10360,1137,33,37,32,5237,513]

theorem envBound26921 : H12AffineFastState.Bounded env26921 := by
  intro p hp
  have h : env26921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26920_26921 : H12AffineEnvironment.transform 7 37 env26920 = env26921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env26920 == env26921) = true)

theorem identity26921 : scanCanonicalize (H12AffineFastState.compose env26921 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26921 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env26922 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,5156,8233,8203,13340,10280,1024,8232,4112,33,17,2,8192,17,2049,5173,4096,10281,1056,33,37,32,5156,513]

theorem envBound26922 : H12AffineFastState.Bounded env26922 := by
  intro p hp
  have h : env26922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26921_26922 : H12AffineEnvironment.transform 5 17 env26921 = env26922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26921 == env26922) = true)

theorem identity26922 : scanCanonicalize (H12AffineFastState.compose env26922 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound26922 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env26923 : List Nat := [2,4,8,16,32,17,8,37,512,52,2048,4096,8192,4112,8233,8203,12328,10280,52,8232,4112,33,17,2,8192,17,2049,4097,4096,10281,20,33,37,32,4112,513]

theorem envBound26923 : H12AffineFastState.Bounded env26923 := by
  intro p hp
  have h : env26923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26922_26923 : H12AffineEnvironment.transform 9 52 env26922 = env26923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env26922 == env26923) = true)

def env26924 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33111,131072,10281,1024,32769,2097152,33,2101329,3,8193,64,2239501,2098512,4097,2272632,2102548,2142524,256,32,46092,2143004]

theorem envBound26924 : H12AffineFastState.Bounded env26924 := by
  intro p hp
  have h : env26924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26916_26924 : H12AffineEnvironment.transform 6 9 env26916 = env26924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26916 == env26924) = true)

theorem identity26924 : scanCanonicalize (H12AffineFastState.compose env26924 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound26924 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26925 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33111,131072,10281,1024,32769,4161,33,16,3,8193,64,146508,5393,4097,179513,1365,41341,256,32,46092,41821]

theorem envBound26925 : H12AffineFastState.Bounded env26925 := by
  intro p hp
  have h : env26925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26924_26925 : H12AffineEnvironment.transform 20 4161 env26924 = env26925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env26924 == env26925) = true)

theorem identity26925 : scanCanonicalize (H12AffineFastState.compose env26925 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 13624) := by decide +kernel

theorem selectedBound26925 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env26926 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33111,13624,10281,1024,32769,4161,33,16,3,8193,64,2420,5393,4097,34817,1365,41341,256,32,46092,41821]

theorem envBound26926 : H12AffineFastState.Bounded env26926 := by
  intro p hp
  have h : env26926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26925_26926 : H12AffineEnvironment.transform 16 13624 env26925 = env26926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13624 env26925 == env26926) = true)

theorem identity26926 : scanCanonicalize (H12AffineFastState.compose env26926 (packedSelected [6,11,12,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound26926 : packedSelected [6,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env26927 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,9292,9499,13624,10281,1024,9293,4161,33,16,3,8193,64,2420,5393,4097,11341,1365,1329,256,32,4160,1809]

theorem envBound26927 : H12AffineFastState.Bounded env26927 := by
  intro p hp
  have h : env26927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26926_26927 : H12AffineEnvironment.transform 14 9292 env26926 = env26927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env26926 == env26927) = true)

def env26928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,4194304,2101465,98645,8328,64,6685836,2098648,4233,2524633,2102685,6336917,256,32,46213,2175563]

theorem envBound26928 : H12AffineFastState.Bounded env26928 := by
  intro p hp
  have h : env26928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26889_26928 : H12AffineEnvironment.transform 22 2101465 env26889 = env26928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101465 env26889 == env26928) = true)

def env26929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,32,2101465,98645,8328,64,2491564,2098648,4233,2524633,2102685,2142645,256,32,46213,2175563]

theorem envBound26929 : H12AffineFastState.Bounded env26929 := by
  intro p hp
  have h : env26929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26928_26929 : H12AffineEnvironment.transform 21 32 env26928 = env26929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env26928 == env26929) = true)

theorem identity26929 : scanCanonicalize (H12AffineFastState.compose env26929 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 78018) := by decide +kernel

theorem selectedBound26929 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,32,73755,98645,8328,64,472174,79130,4233,505115,75103,98679,256,32,46213,649]

theorem envBound26930 : H12AffineFastState.Bounded env26930 := by
  intro p hp
  have h : env26930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26929_26930 : H12AffineEnvironment.transform 20 78018 env26929 = env26930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78018 env26929 == env26930) = true)

def env26931 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,32,73755,98645,8192,64,472174,79130,4097,505115,75103,98679,256,32,46093,513]

theorem envBound26931 : H12AffineFastState.Bounded env26931 := by
  intro p hp
  have h : env26931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26930_26931 : H12AffineEnvironment.transform 6 8 env26930 = env26931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26930 == env26931) = true)

theorem identity26931 : scanCanonicalize (H12AffineFastState.compose env26931 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound26931 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env26932 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,131072,262144,1024,32769,45341,32,41292,2,8192,64,439609,46157,4097,406604,41992,32,256,32,46093,513]

theorem envBound26932 : H12AffineFastState.Bounded env26932 := by
  intro p hp
  have h : env26932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26931_26932 : H12AffineEnvironment.transform 15 33111 env26931 = env26932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env26931 == env26932) = true)

theorem identity26932 : scanCanonicalize (H12AffineFastState.compose env26932 (packedSelected [2,6,21] rootPS)) = affineNative (2^(17+1) ^^^ 171061) := by decide +kernel

theorem selectedBound26932 : packedSelected [2,6,21] rootPS < 2^1333 := by decide +kernel

def env26933 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,131072,171061,1024,32769,45341,32,41292,2,8192,64,10508,46157,4097,43129,41992,32,256,32,46093,513]

theorem envBound26933 : H12AffineFastState.Bounded env26933 := by
  intro p hp
  have h : env26933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26932_26933 : H12AffineEnvironment.transform 17 171061 env26932 = env26933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171061 env26932 == env26933) = true)

theorem identity26933 : scanCanonicalize (H12AffineFastState.compose env26933 (packedSelected [0,3,4,7,9,10,14,19,24] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound26933 : packedSelected [0,3,4,7,9,10,14,19,24] rootPS < 2^1333 := by decide +kernel

def env26934 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,38161,2340,1024,32769,45341,32,41292,2,8192,64,10508,46157,4097,43129,41992,32,256,32,46093,513]

theorem envBound26934 : H12AffineFastState.Bounded env26934 := by
  intro p hp
  have h : env26934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26933_26934 : H12AffineEnvironment.transform 16 38161 env26933 = env26934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env26933 == env26934) = true)

theorem identity26934 : scanCanonicalize (H12AffineFastState.compose env26934 (packedSelected [0,3,5,7,10,12,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26934 : packedSelected [0,3,5,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env26935 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,32768,33031,38161,2340,1024,32769,45341,32,41244,2,8192,16,10508,46109,4097,43049,41992,32,256,32,46093,513]

theorem envBound26935 : H12AffineFastState.Bounded env26935 := by
  intro p hp
  have h : env26935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26934_26935 : H12AffineEnvironment.transform 5 16 env26934 = env26935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26934 == env26935) = true)

theorem identity26935 : scanCanonicalize (H12AffineFastState.compose env26935 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound26935 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env26936 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8460,8203,13341,2340,1024,8461,4113,32,16,2,8192,16,10508,5393,4097,2341,1284,32,256,32,5377,513]

theorem envBound26936 : H12AffineFastState.Bounded env26936 := by
  intro p hp
  have h : env26936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26935_26936 : H12AffineEnvironment.transform 14 8460 env26935 = env26936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env26935 == env26936) = true)

theorem identity26936 : scanCanonicalize (H12AffineFastState.compose env26936 (packedSelected [1,2,3,4,5,8,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound26936 : packedSelected [1,2,3,4,5,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env26937 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3328,8192,2049,8460,8203,10525,2340,1024,8461,3345,32,16,2,8192,16,10508,2065,3329,2341,1284,32,256,32,2049,513]

theorem envBound26937 : H12AffineFastState.Bounded env26937 := by
  intro p hp
  have h : env26937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26936_26937 : H12AffineEnvironment.transform 11 3328 env26936 = env26937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env26936 == env26937) = true)

theorem identity26937 : scanCanonicalize (H12AffineFastState.compose env26937 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound26937 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env26938 : List Nat := [2,4,8,16,32,16,8,256,512,1024,0,1280,8192,1,8460,8203,8477,292,1024,8461,1297,32,16,2,8192,16,8460,17,1281,293,1284,32,256,32,1,513]

theorem envBound26938 : H12AffineFastState.Bounded env26938 := by
  intro p hp
  have h : env26938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26937_26938 : H12AffineEnvironment.transform 10 0 env26937 = env26938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env26937 == env26938) = true)

theorem identity26938 : scanCanonicalize (H12AffineFastState.compose env26938 (packedSelected [1,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound26938 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env26939 : List Nat := [2,4,8,16,32,16,8,256,512,1024,0,1280,269,1,1,262,16,292,1024,0,1297,32,16,2,269,16,1,17,1281,293,1284,32,256,32,1,513]

theorem envBound26939 : H12AffineFastState.Bounded env26939 := by
  intro p hp
  have h : env26939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26938_26939 : H12AffineEnvironment.transform 12 269 env26938 = env26939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env26938 == env26939) = true)

theorem identity26939 : scanCanonicalize (H12AffineFastState.compose env26939 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound26939 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26940 : List Nat := [2,4,8,16,32,16,8,256,512,52,0,308,269,1,1,262,16,292,52,0,293,32,16,2,269,16,1,17,309,293,304,32,256,32,1,513]

theorem envBound26940 : H12AffineFastState.Bounded env26940 := by
  intro p hp
  have h : env26940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26939_26940 : H12AffineEnvironment.transform 9 52 env26939 = env26940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env26939 == env26940) = true)

theorem identity26940 : scanCanonicalize (H12AffineFastState.compose env26940 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound26940 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26941 : List Nat := [2,4,8,16,32,16,8,37,512,52,0,17,40,1,1,35,16,1,52,0,0,32,16,2,40,16,1,17,16,0,21,32,37,32,1,513]

theorem envBound26941 : H12AffineFastState.Bounded env26941 := by
  intro p hp
  have h : env26941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26940_26941 : H12AffineEnvironment.transform 7 37 env26940 = env26941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env26940 == env26941) = true)

theorem identity26941 : scanCanonicalize (H12AffineFastState.compose env26941 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound26941 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26942 : List Nat := [2,4,8,0,32,0,8,37,512,36,0,1,40,1,1,35,0,1,36,0,0,32,0,2,40,0,1,1,0,0,5,32,37,32,1,513]

theorem envBound26942 : H12AffineFastState.Bounded env26942 := by
  intro p hp
  have h : env26942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26941_26942 : H12AffineEnvironment.transform 3 0 env26941 = env26942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env26941 == env26942) = true)

theorem identity26942 : scanCanonicalize (H12AffineFastState.compose env26942 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound26942 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26943 : List Nat := [2,4,8,0,32,0,8,37,11,36,0,1,40,1,1,35,0,1,36,0,0,32,0,2,40,0,1,1,0,0,5,32,37,32,1,10]

theorem envBound26943 : H12AffineFastState.Bounded env26943 := by
  intro p hp
  have h : env26943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26942_26943 : H12AffineEnvironment.transform 8 11 env26942 = env26943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env26942 == env26943) = true)

def env26944 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77899,32,73755,98645,8193,64,472174,79130,4096,505115,75103,98679,256,32,46092,512]

theorem envBound26944 : H12AffineFastState.Bounded env26944 := by
  intro p hp
  have h : env26944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26930_26944 : H12AffineEnvironment.transform 6 9 env26930 = env26944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26930 == env26944) = true)

theorem identity26944 : scanCanonicalize (H12AffineFastState.compose env26944 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound26944 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env26945 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33110,131072,262144,1024,32769,45341,32,41293,3,8193,64,439608,46156,4096,406605,41993,33,256,32,46092,512]

theorem envBound26945 : H12AffineFastState.Bounded env26945 := by
  intro p hp
  have h : env26945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26944_26945 : H12AffineEnvironment.transform 15 33110 env26944 = env26945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env26944 == env26945) = true)

theorem identity26945 : scanCanonicalize (H12AffineFastState.compose env26945 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 5425) := by decide +kernel

theorem selectedBound26945 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env26946 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33110,5425,262144,1024,32769,45341,32,41293,3,8193,64,303113,46156,4096,270716,41993,33,256,32,46092,512]

theorem envBound26946 : H12AffineFastState.Bounded env26946 := by
  intro p hp
  have h : env26946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26945_26946 : H12AffineEnvironment.transform 16 5425 env26945 = env26946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5425 env26945 == env26946) = true)

theorem identity26946 : scanCanonicalize (H12AffineFastState.compose env26946 (packedSelected [1,2,3,4,5,8,9,10,11,16,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 8572) := by decide +kernel

theorem selectedBound26946 : packedSelected [1,2,3,4,5,8,9,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env26947 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8572,8234,5425,262144,1024,8573,4193,32,49,3,8193,64,262517,5424,4096,270716,1397,33,256,32,5488,512]

theorem envBound26947 : H12AffineFastState.Bounded env26947 := by
  intro p hp
  have h : env26947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26946_26947 : H12AffineEnvironment.transform 14 8572 env26946 = env26947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8572 env26946 == env26947) = true)

theorem identity26947 : scanCanonicalize (H12AffineFastState.compose env26947 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 10589) := by decide +kernel

theorem selectedBound26947 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env26948 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8572,8234,5425,10589,1024,8573,4193,32,49,3,8193,64,10280,5424,4096,2081,1397,33,256,32,5488,512]

theorem envBound26948 : H12AffineFastState.Bounded env26948 := by
  intro p hp
  have h : env26948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26947_26948 : H12AffineEnvironment.transform 17 10589 env26947 = env26948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10589 env26947 == env26948) = true)

theorem identity26948 : scanCanonicalize (H12AffineFastState.compose env26948 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound26948 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env26949 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,8192,5204,8233,8234,5220,10248,1024,8232,4193,32,49,3,8193,64,10280,5221,4096,2081,1056,33,85,32,5157,512]

theorem envBound26949 : H12AffineFastState.Bounded env26949 := by
  intro p hp
  have h : env26949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26948_26949 : H12AffineEnvironment.transform 7 85 env26948 = env26949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env26948 == env26949) = true)

theorem identity26949 : scanCanonicalize (H12AffineFastState.compose env26949 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound26949 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26950 : List Nat := [2,4,8,16,32,49,9,36,512,1024,2048,4096,8192,5157,8233,8234,5141,10248,1024,8232,4112,32,49,3,8193,49,10280,5140,4096,2081,1056,33,36,32,5157,512]

theorem envBound26950 : H12AffineFastState.Bounded env26950 := by
  intro p hp
  have h : env26950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26949_26950 : H12AffineEnvironment.transform 5 49 env26949 = env26950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env26949 == env26950) = true)

theorem identity26950 : scanCanonicalize (H12AffineFastState.compose env26950 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound26950 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env26951 : List Nat := [2,4,8,16,32,49,9,36,512,1024,2048,4096,8,5157,33,34,5141,2048,1024,32,4112,32,49,3,9,49,2080,5140,4096,2081,1056,33,36,32,5157,512]

theorem envBound26951 : H12AffineFastState.Bounded env26951 := by
  intro p hp
  have h : env26951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26950_26951 : H12AffineEnvironment.transform 12 8 env26950 = env26951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env26950 == env26951) = true)

theorem identity26951 : scanCanonicalize (H12AffineFastState.compose env26951 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3086) := by decide +kernel

theorem selectedBound26951 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26952 : List Nat := [2,4,8,16,32,49,9,36,512,1024,2048,3086,8,2091,33,34,2075,2048,1024,32,3102,32,49,3,9,49,2080,2074,3086,2081,1056,33,36,32,2091,512]

theorem envBound26952 : H12AffineFastState.Bounded env26952 := by
  intro p hp
  have h : env26952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26951_26952 : H12AffineEnvironment.transform 11 3086 env26951 = env26952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3086 env26951 == env26952) = true)

theorem identity26952 : scanCanonicalize (H12AffineFastState.compose env26952 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound26952 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env26953 : List Nat := [2,4,8,16,32,49,9,36,512,1024,522,1540,8,545,33,34,529,522,1024,32,1556,32,49,3,9,49,554,528,1540,555,1056,33,36,32,545,512]

theorem envBound26953 : H12AffineFastState.Bounded env26953 := by
  intro p hp
  have h : env26953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26952_26953 : H12AffineEnvironment.transform 10 522 env26952 = env26953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env26952 == env26953) = true)

theorem identity26953 : scanCanonicalize (H12AffineFastState.compose env26953 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound26953 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26954 : List Nat := [2,4,8,16,32,49,9,36,512,14,522,522,8,545,33,34,529,522,14,32,538,32,49,3,9,49,554,528,522,555,46,33,36,32,545,512]

theorem envBound26954 : H12AffineFastState.Bounded env26954 := by
  intro p hp
  have h : env26954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26953_26954 : H12AffineEnvironment.transform 9 14 env26953 = env26954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env26953 == env26954) = true)

theorem identity26954 : scanCanonicalize (H12AffineFastState.compose env26954 (packedSelected [1,2,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound26954 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env26955 : List Nat := [2,4,8,16,11,26,9,15,512,14,522,522,8,522,10,9,529,522,14,11,538,11,26,3,9,26,513,528,522,512,5,10,15,11,522,512]

theorem envBound26955 : H12AffineFastState.Bounded env26955 := by
  intro p hp
  have h : env26955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26954_26955 : H12AffineEnvironment.transform 4 11 env26954 = env26955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env26954 == env26955) = true)

theorem identity26955 : scanCanonicalize (H12AffineFastState.compose env26955 (packedSelected [0,2,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound26955 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env26956 : List Nat := [2,4,3,16,0,17,2,4,512,5,513,513,3,513,1,2,529,513,5,0,529,0,17,3,2,17,513,528,513,512,5,1,4,0,513,512]

theorem envBound26956 : H12AffineFastState.Bounded env26956 := by
  intro p hp
  have h : env26956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26955_26956 : H12AffineEnvironment.transform 2 3 env26955 = env26956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env26955 == env26956) = true)

theorem identity26956 : scanCanonicalize (H12AffineFastState.compose env26956 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 18) := by decide +kernel

theorem selectedBound26956 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env26957 : List Nat := [2,4,3,16,0,17,2,4,18,5,19,19,3,19,1,2,3,19,5,0,3,0,17,3,2,17,19,2,19,18,5,1,4,0,19,18]

theorem envBound26957 : H12AffineFastState.Bounded env26957 := by
  intro p hp
  have h : env26957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26956_26957 : H12AffineEnvironment.transform 8 18 env26956 = env26957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 18 env26956 == env26957) = true)

theorem identity26957 : scanCanonicalize (H12AffineFastState.compose env26957 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound26957 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26958 : List Nat := [2,4,3,1,0,0,2,4,3,5,2,2,3,2,1,2,3,2,5,0,3,0,0,3,2,0,2,2,2,3,5,1,4,0,2,3]

theorem envBound26958 : H12AffineFastState.Bounded env26958 := by
  intro p hp
  have h : env26958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26957_26958 : H12AffineEnvironment.transform 3 1 env26957 = env26958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env26957 == env26958) = true)

theorem identity26958 : scanCanonicalize (H12AffineFastState.compose env26958 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound26958 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26959 : List Nat := [2,2,3,1,0,0,2,2,3,3,2,2,3,2,1,2,3,2,3,0,3,0,0,3,2,0,2,2,2,3,3,1,2,0,2,3]

theorem envBound26959 : H12AffineFastState.Bounded env26959 := by
  intro p hp
  have h : env26959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26958_26959 : H12AffineEnvironment.transform 1 2 env26958 = env26959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env26958 == env26959) = true)

def env26960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,33,2101465,98645,8328,64,2491565,2098648,4233,2524633,2102685,2142644,256,32,46213,2175563]

theorem envBound26960 : H12AffineFastState.Bounded env26960 := by
  intro p hp
  have h : env26960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26928_26960 : H12AffineEnvironment.transform 21 33 env26928 = env26960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env26928 == env26960) = true)

theorem identity26960 : scanCanonicalize (H12AffineFastState.compose env26960 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound26960 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,2097152,33,2101465,41310,8328,64,2491565,2098648,4233,2524633,2102685,2142644,256,32,46213,2101824]

theorem envBound26961 : H12AffineFastState.Bounded env26961 := by
  intro p hp
  have h : env26961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26960_26961 : H12AffineEnvironment.transform 15 8203 env26960 = env26961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env26960 == env26961) = true)

def env26962 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,2097152,33,2101385,41230,8328,16,2491565,2098568,4233,2524553,2102685,2142644,256,32,46213,2101776]

theorem envBound26962 : H12AffineFastState.Bounded env26962 := by
  intro p hp
  have h : env26962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26961_26962 : H12AffineEnvironment.transform 5 16 env26961 = env26962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26961 == env26962) = true)

theorem identity26962 : scanCanonicalize (H12AffineFastState.compose env26962 (packedSelected [0,1,9,10,11,14,18,21,22,23,26,27,28,32,35] rootPS)) = affineNative (2^(17+1) ^^^ 35244) := by decide +kernel

theorem selectedBound26962 : packedSelected [0,1,9,10,11,14,18,21,22,23,26,27,28,32,35] rootPS < 2^1333 := by decide +kernel

def env26963 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,32768,8203,131072,35244,1024,32769,2097152,33,2101385,41230,8328,16,2264321,2098568,4233,2231333,2102685,2142644,256,32,46213,2101776]

theorem envBound26963 : H12AffineFastState.Bounded env26963 := by
  intro p hp
  have h : env26963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26962_26963 : H12AffineEnvironment.transform 17 35244 env26962 = env26963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35244 env26962 == env26963) = true)

theorem identity26963 : scanCanonicalize (H12AffineFastState.compose env26963 (packedSelected [0,4,5,7,8,16,20,21,22,24,26,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4113) := by decide +kernel

theorem selectedBound26963 : packedSelected [0,4,5,7,8,16,20,21,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env26964 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,32768,8203,131072,35244,1024,32769,4113,33,152,41230,8328,16,171280,5529,4233,138292,1420,41381,256,32,46213,513]

theorem envBound26964 : H12AffineFastState.Bounded env26964 := by
  intro p hp
  have h : env26964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26963_26964 : H12AffineEnvironment.transform 20 4113 env26963 = env26964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4113 env26963 == env26964) = true)

theorem identity26964 : scanCanonicalize (H12AffineFastState.compose env26964 (packedSelected [2,3,6,10,16,18,20,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound26964 : packedSelected [2,3,6,10,16,18,20,23,24,26] rootPS < 2^1333 := by decide +kernel

def env26965 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,32768,8203,5393,35244,1024,32769,4113,33,152,41230,8328,16,34817,5529,4233,2341,1420,41381,256,32,46213,513]

theorem envBound26965 : H12AffineFastState.Bounded env26965 := by
  intro p hp
  have h : env26965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26964_26965 : H12AffineEnvironment.transform 16 5393 env26964 = env26965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env26964 == env26965) = true)

theorem identity26965 : scanCanonicalize (H12AffineFastState.compose env26965 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound26965 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env26966 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,32768,8203,5393,35108,1024,32769,4113,33,16,41230,8192,16,34817,5393,4097,2341,1284,41261,256,32,46093,513]

theorem envBound26966 : H12AffineFastState.Bounded env26966 := by
  intro p hp
  have h : env26966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26965_26966 : H12AffineEnvironment.transform 6 8 env26965 = env26966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26965 == env26966) = true)

theorem identity26966 : scanCanonicalize (H12AffineFastState.compose env26966 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 5173) := by decide +kernel

theorem selectedBound26966 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env26967 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,5173,8203,5393,7441,1024,5172,4113,33,16,13627,8192,16,7220,5393,4097,2341,1284,13592,256,32,8248,513]

theorem envBound26967 : H12AffineFastState.Bounded env26967 := by
  intro p hp
  have h : env26967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26966_26967 : H12AffineEnvironment.transform 14 5173 env26966 = env26967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5173 env26966 == env26967) = true)

theorem identity26967 : scanCanonicalize (H12AffineFastState.compose env26967 (packedSelected [14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound26967 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env26968 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5377,5173,262,5393,7441,1024,5172,4113,33,16,5174,269,16,7220,5393,4097,2341,1284,5141,256,32,309,513]

theorem envBound26968 : H12AffineFastState.Bounded env26968 := by
  intro p hp
  have h : env26968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26967_26968 : H12AffineEnvironment.transform 12 269 env26967 = env26968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env26967 == env26968) = true)

theorem identity26968 : scanCanonicalize (H12AffineFastState.compose env26968 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 302) := by decide +kernel

theorem selectedBound26968 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env26969 : List Nat := [2,4,8,16,32,16,8,256,512,1024,302,4096,269,5377,5173,262,5393,5183,1024,5172,4113,33,16,5174,269,16,5402,5393,4097,11,1284,5141,256,32,309,513]

theorem envBound26969 : H12AffineFastState.Bounded env26969 := by
  intro p hp
  have h : env26969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26968_26969 : H12AffineEnvironment.transform 10 302 env26968 = env26969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 302 env26968 == env26969) = true)

theorem identity26969 : scanCanonicalize (H12AffineFastState.compose env26969 (packedSelected [1,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound26969 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env26970 : List Nat := [2,4,8,16,32,16,8,256,512,1024,302,1076,269,309,1,262,293,11,1024,0,1061,33,16,2,269,16,302,293,1077,11,1284,33,256,32,309,513]

theorem envBound26970 : H12AffineFastState.Bounded env26970 := by
  intro p hp
  have h : env26970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26969_26970 : H12AffineEnvironment.transform 11 1076 env26969 = env26970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env26969 == env26970) = true)

def env26971 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,2097152,33,2101384,41231,8328,17,2491565,2098569,4233,2524552,2102685,2142644,256,32,46213,2101777]

theorem envBound26971 : H12AffineFastState.Bounded env26971 := by
  intro p hp
  have h : env26971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26961_26971 : H12AffineEnvironment.transform 5 17 env26961 = env26971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26961 == env26971) = true)

theorem identity26971 : scanCanonicalize (H12AffineFastState.compose env26971 (packedSelected [0,1,9,10,11,14,18,21,22,23,26,27,28,32,35] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound26971 : packedSelected [0,1,9,10,11,14,18,21,22,23,26,27,28,32,35] rootPS < 2^1333 := by decide +kernel

def env26972 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,2097152,33,2101248,41231,8192,17,2491429,2098433,4097,2524416,2102549,2142524,256,32,46093,2101777]

theorem envBound26972 : H12AffineFastState.Bounded env26972 := by
  intro p hp
  have h : env26972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26971_26972 : H12AffineEnvironment.transform 6 8 env26971 = env26972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26971 == env26972) = true)

def env26973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830976,25265169,23160257,257,27378860,27337993,25207750]

theorem envBound26973 : H12AffineFastState.Bounded env26973 := by
  intro p hp
  have h : env26973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26807_26973 : H12AffineEnvironment.transform 18 1025 env26807 = env26973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env26807 == env26973) = true)

theorem identity26973 : scanCanonicalize (H12AffineFastState.compose env26973 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 140300) := by decide +kernel

theorem selectedBound26973 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env26974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,4194304,8388608,16777216,8328,64,29868032,17014912,8548701,8830976,25265169,21184973,257,25419936,25362693,25207750]

theorem envBound26974 : H12AffineFastState.Bounded env26974 := by
  intro p hp
  have h : env26974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26973_26974 : H12AffineEnvironment.transform 20 140300 env26973 = env26974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 140300 env26973 == env26974) = true)

def env26975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,4194304,8388608,8631680,8328,64,4486528,8393984,8548701,8830976,143761,12645453,257,21792,46213,202310]

theorem envBound26975 : H12AffineFastState.Bounded env26975 := by
  intro p hp
  have h : env26975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26974_26975 : H12AffineEnvironment.transform 23 8631680 env26974 = env26975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8631680 env26974 == env26975) = true)

def env26976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,4194304,180360,95496,8328,64,4486528,185736,45525,262280,143761,4338885,257,21792,46213,202310]

theorem envBound26976 : H12AffineFastState.Bounded env26976 := by
  intro p hp
  have h : env26976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26975_26976 : H12AffineEnvironment.transform 22 180360 env26975 = env26976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180360 env26975 == env26976) = true)

def env26977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,272512,180360,95496,8328,64,23808,185736,45525,262280,143761,400453,257,21792,46213,202310]

theorem envBound26977 : H12AffineFastState.Bounded env26977 := by
  intro p hp
  have h : env26977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26976_26977 : H12AffineEnvironment.transform 21 272512 env26976 = env26977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env26976 == env26977) = true)

def env26978 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,272392,180224,95496,8192,64,23808,185600,45405,262144,143641,400453,257,21792,46093,202310]

theorem envBound26978 : H12AffineFastState.Bounded env26978 := by
  intro p hp
  have h : env26978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26977_26978 : H12AffineEnvironment.transform 6 8 env26977 = env26978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26977 == env26978) = true)

def env26979 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58396,272392,16,95496,8192,64,23808,5392,45405,262144,61705,318549,257,21792,46093,120406]

theorem envBound26979 : H12AffineFastState.Bounded env26979 := by
  intro p hp
  have h : env26979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26978_26979 : H12AffineEnvironment.transform 16 49168 env26978 = env26979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env26978 == env26979) = true)

theorem identity26979 : scanCanonicalize (H12AffineFastState.compose env26979 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound26979 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26980 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,49168,262144,1025,32769,58396,272392,16,2,8192,64,23808,5392,45405,262144,61705,318549,257,21792,46093,41820]

theorem envBound26980 : H12AffineFastState.Bounded env26980 := by
  intro p hp
  have h : env26980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26979_26980 : H12AffineEnvironment.transform 15 29962 env26979 = env26980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env26979 == env26980) = true)

theorem identity26980 : scanCanonicalize (H12AffineFastState.compose env26980 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 35108) := by decide +kernel

theorem selectedBound26980 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env26981 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,49168,35108,1025,32769,58396,41260,16,2,8192,64,23808,5392,45405,35108,61705,21873,257,21792,46093,41820]

theorem envBound26981 : H12AffineFastState.Bounded env26981 := by
  intro p hp
  have h : env26981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26980_26981 : H12AffineEnvironment.transform 17 35108 env26980 = env26981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35108 env26980 == env26981) = true)

theorem identity26981 : scanCanonicalize (H12AffineFastState.compose env26981 (packedSelected [0,1,3,7,8,9,10,12,14,15,20,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound26981 : packedSelected [0,1,3,7,8,9,10,12,14,15,20,22,24] rootPS < 2^1333 := by decide +kernel

def env26982 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,32768,35,46393,35108,1025,32769,37173,41260,16,2,8192,64,10281,5392,45405,35108,33824,8280,257,8201,46093,41820]

theorem envBound26982 : H12AffineFastState.Bounded env26982 := by
  intro p hp
  have h : env26982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26981_26982 : H12AffineEnvironment.transform 13 13609 env26981 = env26982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env26981 == env26982) = true)

theorem identity26982 : scanCanonicalize (H12AffineFastState.compose env26982 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound26982 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env26983 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,81,35,13672,2421,1025,80,4452,8573,16,2,8192,64,10281,5392,12556,2421,1137,8280,257,8201,13404,8973]

theorem envBound26983 : H12AffineFastState.Bounded env26983 := by
  intro p hp
  have h : env26983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26982_26983 : H12AffineEnvironment.transform 14 81 env26982 = env26983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env26982 == env26983) = true)

theorem identity26983 : scanCanonicalize (H12AffineFastState.compose env26983 (packedSelected [0,1,2,3,5,6,7,8,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound26983 : packedSelected [0,1,2,3,5,6,7,8,12,14,15] rootPS < 2^1333 := by decide +kernel

def env26984 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5157,81,35,5220,2421,1025,80,4452,113,16,2,268,64,2341,5392,4096,2421,1137,340,257,261,5456,513]

theorem envBound26984 : H12AffineFastState.Bounded env26984 := by
  intro p hp
  have h : env26984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26983_26984 : H12AffineEnvironment.transform 12 268 env26983 = env26984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env26983 == env26984) = true)

theorem identity26984 : scanCanonicalize (H12AffineFastState.compose env26984 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26984 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26985 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5157,0,35,5173,2340,1025,1,4405,32,16,2,268,17,2341,5392,4096,2340,1056,261,257,261,5377,513]

theorem envBound26985 : H12AffineFastState.Bounded env26985 := by
  intro p hp
  have h : env26985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26984_26985 : H12AffineEnvironment.transform 5 17 env26984 = env26985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26984 == env26985) = true)

theorem identity26985 : scanCanonicalize (H12AffineFastState.compose env26985 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound26985 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env26986 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,4096,268,4404,0,35,4388,2340,272,1,4405,32,16,2,268,17,2341,4097,4096,2340,305,261,257,261,4112,513]

theorem envBound26986 : H12AffineFastState.Bounded env26986 := by
  intro p hp
  have h : env26986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26985_26986 : H12AffineEnvironment.transform 9 273 env26985 = env26986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env26985 == env26986) = true)

def env26987 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58397,272392,17,95496,8192,64,23808,5393,45405,262144,61704,318548,257,21792,46093,120407]

theorem envBound26987 : H12AffineFastState.Bounded env26987 := by
  intro p hp
  have h : env26987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26978_26987 : H12AffineEnvironment.transform 16 49169 env26978 = env26987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env26978 == env26987) = true)

theorem identity26987 : scanCanonicalize (H12AffineFastState.compose env26987 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound26987 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26988 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,89378,1025,32769,58397,95530,17,95496,8192,64,23808,5393,45405,89378,61704,98678,257,21792,46093,120407]

theorem envBound26988 : H12AffineFastState.Bounded env26988 := by
  intro p hp
  have h : env26988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26987_26988 : H12AffineEnvironment.transform 17 89378 env26987 = env26988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env26987 == env26988) = true)

theorem identity26988 : scanCanonicalize (H12AffineFastState.compose env26988 (packedSelected [0,1,4,5,12,14,15,16,19,22,24,26,27,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound26988 : packedSelected [0,1,4,5,12,14,15,16,19,22,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env26989 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,32768,65536,46440,75867,1025,32769,37220,65619,17,65649,8192,64,10361,5393,45405,75867,33905,98678,257,8281,46093,107310]

theorem envBound26989 : H12AffineFastState.Bounded env26989 := by
  intro p hp
  have h : env26989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26988_26989 : H12AffineEnvironment.transform 13 13689 env26988 = env26989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env26988 == env26989) = true)

theorem identity26989 : scanCanonicalize (H12AffineFastState.compose env26989 (packedSelected [7,14,16,18,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound26989 : packedSelected [7,14,16,18,23,27] rootPS < 2^1333 := by decide +kernel

def env26990 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,8460,65536,5220,75867,1025,8461,12392,65619,17,65649,8192,64,10361,5393,4177,75867,9597,73850,257,8281,5377,66082]

theorem envBound26990 : H12AffineFastState.Bounded env26990 := by
  intro p hp
  have h : env26990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26989_26990 : H12AffineEnvironment.transform 14 8460 env26989 = env26990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env26989 == env26990) = true)

theorem identity26990 : scanCanonicalize (H12AffineFastState.compose env26990 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound26990 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env26991 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5456,293,65536,5220,67698,1025,292,4161,65619,17,65649,41,64,2128,5393,4177,67698,1364,65619,257,112,5377,66082]

theorem envBound26991 : H12AffineFastState.Bounded env26991 := by
  intro p hp
  have h : env26991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26990_26991 : H12AffineEnvironment.transform 12 41 env26990 = env26991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env26990 == env26991) = true)

theorem identity26991 : scanCanonicalize (H12AffineFastState.compose env26991 (packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26991 : packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS < 2^1333 := by decide +kernel

def env26992 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,41,5376,293,65536,5172,67618,1025,292,4113,65539,17,65569,41,16,2048,5393,4097,67618,1284,65539,257,32,5377,66082]

theorem envBound26992 : H12AffineFastState.Bounded env26992 := by
  intro p hp
  have h : env26992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26991_26992 : H12AffineEnvironment.transform 5 16 env26991 = env26992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26991 == env26992) = true)

theorem identity26992 : scanCanonicalize (H12AffineFastState.compose env26992 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound26992 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env26993 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,41,5376,293,35,5172,2049,1025,292,4113,32,17,2,41,16,2048,5393,4097,2049,1284,32,257,32,5377,513]

theorem envBound26993 : H12AffineFastState.Bounded env26993 := by
  intro p hp
  have h : env26993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26992_26993 : H12AffineEnvironment.transform 15 35 env26992 = env26993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env26992 == env26993) = true)

theorem identity26993 : scanCanonicalize (H12AffineFastState.compose env26993 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound26993 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26994 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,41,5157,0,35,5172,2049,1025,1,4113,32,17,2,41,16,2048,5172,4097,2049,1057,32,36,32,5156,513]

theorem envBound26994 : H12AffineFastState.Bounded env26994 := by
  intro p hp
  have h : env26994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26993_26994 : H12AffineEnvironment.transform 7 37 env26993 = env26994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env26993 == env26994) = true)

theorem identity26994 : scanCanonicalize (H12AffineFastState.compose env26994 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound26994 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26995 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,4096,41,4113,0,35,4096,2049,53,1,4113,32,17,2,41,16,2048,4096,4097,2049,21,32,36,32,4112,513]

theorem envBound26995 : H12AffineFastState.Bounded env26995 := by
  intro p hp
  have h : env26995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26994_26995 : H12AffineEnvironment.transform 9 52 env26994 = env26995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env26994 == env26995) = true)

theorem identity26995 : scanCanonicalize (H12AffineFastState.compose env26995 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 37) := by decide +kernel

theorem selectedBound26995 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26996 : List Nat := [2,4,8,16,32,16,8,37,37,52,2048,4096,41,4113,0,35,4096,2049,53,1,4113,32,17,2,41,16,2048,4096,4097,2049,21,32,36,32,4112,36]

theorem envBound26996 : H12AffineFastState.Bounded env26996 := by
  intro p hp
  have h : env26996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26995_26996 : H12AffineEnvironment.transform 8 37 env26995 = env26996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 37 env26995 == env26996) = true)

theorem identity26996 : scanCanonicalize (H12AffineFastState.compose env26996 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 24) := by decide +kernel

theorem selectedBound26996 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26997 : List Nat := [2,4,8,16,32,16,8,37,37,52,2048,24,41,9,0,35,24,2049,53,1,9,32,17,2,41,16,2048,24,25,2049,21,32,36,32,8,36]

theorem envBound26997 : H12AffineFastState.Bounded env26997 := by
  intro p hp
  have h : env26997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26996_26997 : H12AffineEnvironment.transform 11 24 env26996 = env26997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 24 env26996 == env26997) = true)

theorem identity26997 : scanCanonicalize (H12AffineFastState.compose env26997 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 47) := by decide +kernel

theorem selectedBound26997 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env26998 : List Nat := [2,4,8,16,32,16,8,37,37,52,47,24,41,9,0,35,24,46,53,1,9,32,17,2,41,16,47,24,25,46,21,32,36,32,8,36]

theorem envBound26998 : H12AffineFastState.Bounded env26998 := by
  intro p hp
  have h : env26998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26997_26998 : H12AffineEnvironment.transform 10 47 env26997 = env26998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 47 env26997 == env26998) = true)

theorem identity26998 : scanCanonicalize (H12AffineFastState.compose env26998 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound26998 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env26999 : List Nat := [2,4,8,16,1,16,8,4,4,21,14,24,8,9,0,2,24,15,20,1,9,1,17,2,8,16,14,24,25,15,21,1,5,1,8,5]

theorem envBound26999 : H12AffineFastState.Bounded env26999 := by
  intro p hp
  have h : env26999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26998_26999 : H12AffineEnvironment.transform 4 1 env26998 = env26999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env26998 == env26999) = true)

theorem identity26999 : scanCanonicalize (H12AffineFastState.compose env26999 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound26999 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env27000 : List Nat := [2,4,1,16,1,16,1,4,4,21,7,17,1,0,0,2,17,6,20,1,0,1,17,2,1,16,7,17,16,6,21,1,5,1,1,5]

theorem envBound27000 : H12AffineFastState.Bounded env27000 := by
  intro p hp
  have h : env27000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26999_27000 : H12AffineEnvironment.transform 2 1 env26999 = env27000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env26999 == env27000) = true)

theorem identity27000 : scanCanonicalize (H12AffineFastState.compose env27000 (packedSelected [12] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound27000 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env27001 : List Nat := [2,2,1,16,1,16,1,2,2,19,1,17,1,0,0,2,17,0,18,1,0,1,17,2,1,16,1,17,16,0,19,1,3,1,1,3]

theorem envBound27001 : H12AffineFastState.Bounded env27001 := by
  intro p hp
  have h : env27001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27000_27001 : H12AffineEnvironment.transform 1 2 env27000 = env27001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env27000 == env27001) = true)

def env27002 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,272393,180225,95496,8193,64,23808,185601,45404,262145,143640,400453,257,21792,46092,202310]

theorem envBound27002 : H12AffineFastState.Bounded env27002 := by
  intro p hp
  have h : env27002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26977_27002 : H12AffineEnvironment.transform 6 9 env26977 = env27002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26977 == env27002) = true)

def env27003 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58396,272393,17,95496,8193,64,23808,5393,45404,262145,61704,318549,257,21792,46092,120406]

theorem envBound27003 : H12AffineFastState.Bounded env27003 := by
  intro p hp
  have h : env27003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27002_27003 : H12AffineEnvironment.transform 16 49168 env27002 = env27003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env27002 == env27003) = true)

theorem identity27003 : scanCanonicalize (H12AffineFastState.compose env27003 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130175) := by decide +kernel

theorem selectedBound27003 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27004 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,130175,1025,32769,58396,119926,17,95496,8193,64,23808,5393,45404,130174,61704,73770,257,21792,46092,120406]

theorem envBound27004 : H12AffineFastState.Bounded env27004 := by
  intro p hp
  have h : env27004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27003_27004 : H12AffineEnvironment.transform 17 130175 env27003 = env27004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130175 env27003 == env27004) = true)

theorem identity27004 : scanCanonicalize (H12AffineFastState.compose env27004 (packedSelected [0,1,2,4,6,7,8,10,14,15,16,18,19,22,26] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound27004 : packedSelected [0,1,2,4,6,7,8,10,14,15,16,18,19,22,26] rootPS < 2^1333 := by decide +kernel

def env27005 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,65536,16400,97407,1025,1,25628,87158,17,95496,8193,64,23808,5393,12636,97406,28936,73770,257,21792,13324,87638]

theorem envBound27005 : H12AffineFastState.Bounded env27005 := by
  intro p hp
  have h : env27005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27004_27005 : H12AffineEnvironment.transform 14 0 env27004 = env27005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env27004 == env27005) = true)

theorem identity27005 : scanCanonicalize (H12AffineFastState.compose env27005 (packedSelected [0,1,3,5,7,8,14,15,23] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound27005 : packedSelected [0,1,3,5,7,8,14,15,23] rootPS < 2^1333 := by decide +kernel

def env27006 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,0,65536,13341,67698,1025,1,4113,73851,17,65797,8193,64,10509,5393,12636,67699,1285,73770,257,8493,13324,74331]

theorem envBound27006 : H12AffineFastState.Bounded env27006 := by
  intro p hp
  have h : env27006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27005_27006 : H12AffineEnvironment.transform 13 13325 env27005 = env27006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env27005 == env27006) = true)

theorem identity27006 : scanCanonicalize (H12AffineFastState.compose env27006 (packedSelected [0,1,3,5,7,8,14,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27006 : packedSelected [0,1,3,5,7,8,14,15,18] rootPS < 2^1333 := by decide +kernel

def env27007 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,0,65536,13341,67618,1025,1,4113,73771,17,65797,8193,16,10509,5393,12556,67619,1285,73770,257,8493,13324,74251]

theorem envBound27007 : H12AffineFastState.Bounded env27007 := by
  intro p hp
  have h : env27007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27006_27007 : H12AffineEnvironment.transform 5 16 env27006 = env27007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27006 == env27007) = true)

theorem identity27007 : scanCanonicalize (H12AffineFastState.compose env27007 (packedSelected [0,3,4,8,10] rootPS)) = affineNative (2^(15+1) ^^^ 15166) := by decide +kernel

theorem selectedBound27007 : packedSelected [0,3,4,8,10] rootPS < 2^1333 := by decide +kernel

def env27008 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,0,15166,13341,13084,1025,1,4113,6933,17,14907,8193,16,10509,5393,12556,13085,1285,6932,257,8493,13324,6453]

theorem envBound27008 : H12AffineFastState.Bounded env27008 := by
  intro p hp
  have h : env27008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27007_27008 : H12AffineEnvironment.transform 15 15166 env27007 = env27008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 15166 env27007 == env27008) = true)

theorem identity27008 : scanCanonicalize (H12AffineFastState.compose env27008 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound27008 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env27009 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,0,6706,5393,4624,1025,1,4113,6933,17,6967,269,16,2049,5393,4096,4625,1285,6932,257,33,5376,6453]

theorem envBound27009 : H12AffineFastState.Bounded env27009 := by
  intro p hp
  have h : env27009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27008_27009 : H12AffineEnvironment.transform 12 268 env27008 = env27009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env27008 == env27009) = true)

theorem identity27009 : scanCanonicalize (H12AffineFastState.compose env27009 (packedSelected [0,1,2,5,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound27009 : packedSelected [0,1,2,5,6,7] rootPS < 2^1333 := by decide +kernel

def env27010 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1076,268,309,0,3590,293,1572,1025,1,1061,3873,17,3843,269,16,2049,293,1076,1573,1285,3872,257,33,308,3329]

theorem envBound27010 : H12AffineFastState.Bounded env27010 := by
  intro p hp
  have h : env27010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27009_27010 : H12AffineEnvironment.transform 11 1076 env27009 = env27010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env27009 == env27010) = true)

theorem identity27010 : scanCanonicalize (H12AffineFastState.compose env27010 (packedSelected [0,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 1281) := by decide +kernel

theorem selectedBound27010 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env27011 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1281,1076,268,309,0,775,293,1572,1025,1,1061,544,17,514,269,16,1280,293,1076,1573,1285,545,257,33,308,0]

theorem envBound27011 : H12AffineFastState.Bounded env27011 := by
  intro p hp
  have h : env27011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27010_27011 : H12AffineEnvironment.transform 10 1281 env27010 = env27011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1281 env27010 == env27011) = true)

theorem identity27011 : scanCanonicalize (H12AffineFastState.compose env27011 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound27011 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env27012 : List Nat := [2,4,8,16,32,16,9,256,512,273,16,293,268,309,0,775,293,821,272,1,308,544,17,514,269,16,17,293,293,820,20,545,257,33,308,0]

theorem envBound27012 : H12AffineFastState.Bounded env27012 := by
  intro p hp
  have h : env27012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27011_27012 : H12AffineEnvironment.transform 9 273 env27011 = env27012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env27011 == env27012) = true)

theorem identity27012 : scanCanonicalize (H12AffineFastState.compose env27012 (packedSelected [0,3,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound27012 : packedSelected [0,3,4,8] rootPS < 2^1333 := by decide +kernel

def env27013 : List Nat := [2,4,8,16,32,16,9,256,1,273,16,293,268,309,0,262,293,308,272,1,308,33,17,3,269,16,17,293,293,309,20,32,257,33,308,0]

theorem envBound27013 : H12AffineFastState.Bounded env27013 := by
  intro p hp
  have h : env27013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27012_27013 : H12AffineEnvironment.transform 8 1 env27012 = env27013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env27012 == env27013) = true)

theorem identity27013 : scanCanonicalize (H12AffineFastState.compose env27013 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound27013 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env27014 : List Nat := [2,4,8,16,16,16,9,256,1,273,16,277,268,261,0,262,277,260,272,1,260,17,17,3,269,16,17,277,277,261,20,16,257,17,260,0]

theorem envBound27014 : H12AffineFastState.Bounded env27014 := by
  intro p hp
  have h : env27014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27013_27014 : H12AffineEnvironment.transform 4 16 env27013 = env27014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env27013 == env27014) = true)

theorem identity27014 : scanCanonicalize (H12AffineFastState.compose env27014 (packedSelected [0,3] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound27014 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env27015 : List Nat := [2,4,8,16,16,16,9,21,1,4,16,0,25,16,0,19,0,17,5,1,17,17,17,3,24,16,17,0,0,16,20,16,20,17,17,0]

theorem envBound27015 : H12AffineFastState.Bounded env27015 := by
  intro p hp
  have h : env27015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27014_27015 : H12AffineEnvironment.transform 7 21 env27014 = env27015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env27014 == env27015) = true)

def env27016 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58397,272393,16,95496,8193,64,23808,5392,45404,262145,61705,318548,257,21792,46092,120407]

theorem envBound27016 : H12AffineFastState.Bounded env27016 := by
  intro p hp
  have h : env27016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27002_27016 : H12AffineEnvironment.transform 16 49169 env27002 = env27016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env27002 == env27016) = true)

theorem identity27016 : scanCanonicalize (H12AffineFastState.compose env27016 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound27016 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27017 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,49169,262144,1025,32769,58397,272393,16,41310,8193,64,23808,5392,45404,262145,61705,318548,257,21792,46092,513]

theorem envBound27017 : H12AffineFastState.Bounded env27017 := by
  intro p hp
  have h : env27017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27016_27017 : H12AffineEnvironment.transform 15 54358 env27016 = env27017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env27016 == env27017) = true)

theorem identity27017 : scanCanonicalize (H12AffineFastState.compose env27017 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound27017 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env27018 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,40971,46156,262144,1025,32769,36928,272393,16,41310,8193,64,10589,5392,45404,262145,34132,305161,257,8573,46092,513]

theorem envBound27018 : H12AffineFastState.Bounded env27018 := by
  intro p hp
  have h : env27018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27017_27018 : H12AffineEnvironment.transform 13 13405 env27017 = env27018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env27017 == env27018) = true)

theorem identity27018 : scanCanonicalize (H12AffineFastState.compose env27018 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound27018 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env27019 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,32768,33110,38161,262144,1025,32769,36928,264532,16,32771,348,64,2048,5392,36865,262145,34132,297300,257,32,38225,513]

theorem envBound27019 : H12AffineFastState.Bounded env27019 := by
  intro p hp
  have h : env27019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27018_27019 : H12AffineEnvironment.transform 12 349 env27018 = env27019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env27018 == env27019) = true)

theorem identity27019 : scanCanonicalize (H12AffineFastState.compose env27019 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound27019 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env27020 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,32768,33110,38161,2420,1025,32769,36928,32,16,32771,348,64,2048,5392,36865,2421,34132,32800,257,32,38225,513]

theorem envBound27020 : H12AffineFastState.Bounded env27020 := by
  intro p hp
  have h : env27020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27019_27020 : H12AffineEnvironment.transform 17 2420 env27019 = env27020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env27019 == env27020) = true)

theorem identity27020 : scanCanonicalize (H12AffineFastState.compose env27020 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound27020 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27021 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,349,4112,32768,33110,36865,2420,273,32769,36928,32,16,32771,348,64,2048,4096,36865,2421,32836,32800,257,32,36929,513]

theorem envBound27021 : H12AffineFastState.Bounded env27021 := by
  intro p hp
  have h : env27021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27020_27021 : H12AffineEnvironment.transform 9 272 env27020 = env27021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env27020 == env27021) = true)

theorem identity27021 : scanCanonicalize (H12AffineFastState.compose env27021 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 2129) := by decide +kernel

theorem selectedBound27021 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env27022 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,349,4112,2129,2311,6224,2420,273,2128,6161,32,16,2130,348,64,2048,4096,6224,2421,2069,2161,257,32,6160,513]

theorem envBound27022 : H12AffineFastState.Bounded env27022 := by
  intro p hp
  have h : env27022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27021_27022 : H12AffineEnvironment.transform 14 2129 env27021 = env27022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2129 env27021 == env27022) = true)

theorem identity27022 : scanCanonicalize (H12AffineFastState.compose env27022 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound27022 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env27023 : List Nat := [2,4,8,16,32,64,9,116,512,100,2048,4096,41,4112,2129,2163,6224,2048,101,2128,6161,32,16,2130,40,64,2048,4096,6224,2049,2069,2161,117,32,6160,513]

theorem envBound27023 : H12AffineFastState.Bounded env27023 := by
  intro p hp
  have h : env27023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27022_27023 : H12AffineEnvironment.transform 7 116 env27022 = env27023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env27022 == env27023) = true)

theorem identity27023 : scanCanonicalize (H12AffineFastState.compose env27023 (packedSelected [1,3,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound27023 : packedSelected [1,3,4,6] rootPS < 2^1333 := by decide +kernel

def env27024 : List Nat := [2,4,8,16,32,64,9,116,512,100,2048,512,41,528,2129,2163,2640,2048,101,2128,2577,32,16,2130,40,64,2048,512,2640,2049,2069,2161,117,32,2576,513]

theorem envBound27024 : H12AffineFastState.Bounded env27024 := by
  intro p hp
  have h : env27024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27023_27024 : H12AffineEnvironment.transform 11 512 env27023 = env27024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env27023 == env27024) = true)

theorem identity27024 : scanCanonicalize (H12AffineFastState.compose env27024 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound27024 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27025 : List Nat := [2,4,8,16,32,64,9,116,16,100,2048,16,41,0,2129,2163,2112,2048,101,2128,2049,32,16,2130,40,64,2048,16,2112,2049,2069,2161,117,32,2048,17]

theorem envBound27025 : H12AffineFastState.Bounded env27025 := by
  intro p hp
  have h : env27025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27024_27025 : H12AffineEnvironment.transform 8 16 env27024 = env27025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env27024 == env27025) = true)

theorem identity27025 : scanCanonicalize (H12AffineFastState.compose env27025 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound27025 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env27026 : List Nat := [2,4,8,16,32,64,9,116,16,100,80,16,41,0,1,35,16,80,101,0,81,32,16,2,40,64,80,16,16,81,69,33,117,32,80,17]

theorem envBound27026 : H12AffineFastState.Bounded env27026 := by
  intro p hp
  have h : env27026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27025_27026 : H12AffineEnvironment.transform 10 80 env27025 = env27026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env27025 == env27026) = true)

def env27027 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,272513,180360,95496,8328,64,23809,185736,45525,262280,143761,400452,257,21792,46213,202310]

theorem envBound27027 : H12AffineFastState.Bounded env27027 := by
  intro p hp
  have h : env27027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26976_27027 : H12AffineEnvironment.transform 21 272513 env26976 = env27027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env26976 == env27027) = true)

theorem identity27027 : scanCanonicalize (H12AffineFastState.compose env27027 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49305) := by decide +kernel

theorem selectedBound27027 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,58517,272513,17,95496,8328,64,23809,5393,45525,262280,61704,318685,257,21792,46213,120543]

theorem envBound27028 : H12AffineFastState.Bounded env27028 := by
  intro p hp
  have h : env27028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27027_27028 : H12AffineEnvironment.transform 16 49305 env27027 = env27028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env27027 == env27028) = true)

def env27029 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58397,272393,17,95496,8192,64,23809,5393,45405,262144,61704,318549,257,21792,46093,120407]

theorem envBound27029 : H12AffineFastState.Bounded env27029 := by
  intro p hp
  have h : env27029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27028_27029 : H12AffineEnvironment.transform 6 8 env27028 = env27029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27028 == env27029) = true)

theorem identity27029 : scanCanonicalize (H12AffineFastState.compose env27029 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound27029 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27030 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,89378,1025,32769,58397,95531,17,95496,8192,64,23809,5393,45405,89378,61704,98679,257,21792,46093,120407]

theorem envBound27030 : H12AffineFastState.Bounded env27030 := by
  intro p hp
  have h : env27030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27029_27030 : H12AffineEnvironment.transform 17 89378 env27029 = env27030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env27029 == env27030) = true)

theorem identity27030 : scanCanonicalize (H12AffineFastState.compose env27030 (packedSelected [0,1,4,5,12,14,15,16,19,22,24,26,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 21621) := by decide +kernel

theorem selectedBound27030 : packedSelected [0,1,4,5,12,14,15,16,19,22,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env27031 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21621,65536,5220,89378,1025,21620,12392,95531,17,95496,8192,64,23809,5393,25896,89378,9597,87298,257,21792,24696,66082]

theorem envBound27031 : H12AffineFastState.Bounded env27031 := by
  intro p hp
  have h : env27031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27030_27031 : H12AffineEnvironment.transform 14 21621 env27030 = env27031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21621 env27030 == env27031) = true)

theorem identity27031 : scanCanonicalize (H12AffineFastState.compose env27031 (packedSelected [2,4,6,7,11,14,18,22,27] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound27031 : packedSelected [2,4,6,7,11,14,18,22,27] rootPS < 2^1333 := by decide +kernel

def env27032 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,21621,65536,5220,89378,1025,21620,4160,87299,17,87328,40,64,23809,5393,17664,89378,1365,87298,257,21792,16464,66082]

theorem envBound27032 : H12AffineFastState.Bounded env27032 := by
  intro p hp
  have h : env27032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27031_27032 : H12AffineEnvironment.transform 12 40 env27031 = env27032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env27031 == env27032) = true)

theorem identity27032 : scanCanonicalize (H12AffineFastState.compose env27032 (packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 21794) := by decide +kernel

theorem selectedBound27032 : packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS < 2^1333 := by decide +kernel

def env27033 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,21621,21794,5220,2048,1025,21620,4160,33,17,2,40,64,23809,5393,17664,2048,1365,32,257,21792,16464,22272]

theorem envBound27033 : H12AffineFastState.Bounded env27033 := by
  intro p hp
  have h : env27033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27032_27033 : H12AffineEnvironment.transform 15 21794 env27032 = env27033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21794 env27032 == env27033) = true)

theorem identity27033 : scanCanonicalize (H12AffineFastState.compose env27033 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound27033 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env27034 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5376,373,34,5220,2048,1025,372,4160,33,17,2,40,64,2049,5393,4096,2048,1365,32,257,32,5456,512]

theorem envBound27034 : H12AffineFastState.Bounded env27034 := by
  intro p hp
  have h : env27034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27033_27034 : H12AffineEnvironment.transform 13 5376 env27033 = env27034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env27033 == env27034) = true)

theorem identity27034 : scanCanonicalize (H12AffineFastState.compose env27034 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound27034 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27035 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,4096,40,5376,260,34,5141,2048,1025,261,4145,33,17,2,40,49,2049,5393,4096,2048,1316,32,257,32,5409,512]

theorem envBound27035 : H12AffineFastState.Bounded env27035 := by
  intro p hp
  have h : env27035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27034_27035 : H12AffineEnvironment.transform 5 49 env27034 = env27035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env27034 == env27035) = true)

theorem identity27035 : scanCanonicalize (H12AffineFastState.compose env27035 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound27035 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env27036 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,1028,40,260,260,34,17,2048,1025,261,1077,33,17,2,40,49,2049,277,1028,2048,1316,32,257,32,293,512]

theorem envBound27036 : H12AffineFastState.Bounded env27036 := by
  intro p hp
  have h : env27036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27035_27036 : H12AffineEnvironment.transform 11 1028 env27035 = env27036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env27035 == env27036) = true)

theorem identity27036 : scanCanonicalize (H12AffineFastState.compose env27036 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound27036 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27037 : List Nat := [2,4,8,16,32,49,8,256,512,1024,512,1028,40,260,260,34,17,512,1025,261,1077,33,17,2,40,49,513,277,1028,512,1316,32,257,32,293,512]

theorem envBound27037 : H12AffineFastState.Bounded env27037 := by
  intro p hp
  have h : env27037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27036_27037 : H12AffineEnvironment.transform 10 512 env27036 = env27037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env27036 == env27037) = true)

theorem identity27037 : scanCanonicalize (H12AffineFastState.compose env27037 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound27037 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env27038 : List Nat := [2,4,8,16,32,49,8,36,512,1024,512,1028,40,32,32,34,17,512,1025,33,1077,33,17,2,40,49,513,49,1028,512,1024,32,37,32,1,512]

theorem envBound27038 : H12AffineFastState.Bounded env27038 := by
  intro p hp
  have h : env27038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27037_27038 : H12AffineEnvironment.transform 7 36 env27037 = env27038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env27037 == env27038) = true)

theorem identity27038 : scanCanonicalize (H12AffineFastState.compose env27038 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound27038 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env27039 : List Nat := [2,4,8,16,32,49,8,36,16,1024,16,1028,40,32,32,34,17,16,1025,33,1077,33,17,2,40,49,17,49,1028,16,1024,32,37,32,1,16]

theorem envBound27039 : H12AffineFastState.Bounded env27039 := by
  intro p hp
  have h : env27039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27038_27039 : H12AffineEnvironment.transform 8 16 env27038 = env27039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env27038 == env27039) = true)

theorem identity27039 : scanCanonicalize (H12AffineFastState.compose env27039 (packedSelected [12] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27039 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env27040 : List Nat := [2,4,8,16,1,16,8,5,16,1024,16,1028,9,1,1,3,17,16,1025,0,1044,0,17,2,9,16,17,16,1028,16,1024,1,4,1,1,16]

theorem envBound27040 : H12AffineFastState.Bounded env27040 := by
  intro p hp
  have h : env27040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27039_27040 : H12AffineEnvironment.transform 4 1 env27039 = env27040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27039 == env27040) = true)

theorem identity27040 : scanCanonicalize (H12AffineFastState.compose env27040 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound27040 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27041 : List Nat := [2,4,8,4,1,4,8,5,4,1024,4,1028,9,1,1,3,5,4,1025,0,1024,0,5,2,9,4,5,4,1028,4,1024,1,4,1,1,4]

theorem envBound27041 : H12AffineFastState.Bounded env27041 := by
  intro p hp
  have h : env27041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27040_27041 : H12AffineEnvironment.transform 3 4 env27040 = env27041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env27040 == env27041) = true)

theorem identity27041 : scanCanonicalize (H12AffineFastState.compose env27041 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 1) := by decide +kernel

theorem selectedBound27041 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27042 : List Nat := [2,4,8,4,1,4,8,5,4,1,4,5,9,1,1,3,5,4,0,0,1,0,5,2,9,4,5,4,5,4,1,1,4,1,1,4]

theorem envBound27042 : H12AffineFastState.Bounded env27042 := by
  intro p hp
  have h : env27042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27041_27042 : H12AffineEnvironment.transform 9 1 env27041 = env27042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env27041 == env27042) = true)

theorem identity27042 : scanCanonicalize (H12AffineFastState.compose env27042 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound27042 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27043 : List Nat := [2,4,4,4,1,4,4,5,4,1,4,5,5,1,1,3,5,4,0,0,1,0,5,2,5,4,5,4,5,4,1,1,4,1,1,4]

theorem envBound27043 : H12AffineFastState.Bounded env27043 := by
  intro p hp
  have h : env27043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27042_27043 : H12AffineEnvironment.transform 2 4 env27042 = env27043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env27042 == env27043) = true)

theorem identity27043 : scanCanonicalize (H12AffineFastState.compose env27043 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound27043 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env27044 : List Nat := [2,3,3,3,1,3,3,2,3,1,3,2,2,1,1,3,2,3,0,0,1,0,2,2,2,3,2,3,2,3,1,1,3,1,1,3]

theorem envBound27044 : H12AffineFastState.Bounded env27044 := by
  intro p hp
  have h : env27044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27043_27044 : H12AffineEnvironment.transform 1 3 env27043 = env27044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env27043 == env27044) = true)

theorem identity27044 : scanCanonicalize (H12AffineFastState.compose env27044 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound27044 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env27045 : List Nat := [1,0,0,0,1,0,0,1,0,1,0,1,1,1,1,0,1,0,0,0,1,0,1,1,1,0,1,0,1,0,1,1,0,1,1,0]

theorem envBound27045 : H12AffineFastState.Bounded env27045 := by
  intro p hp
  have h : env27045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27044_27045 : H12AffineEnvironment.transform 0 1 env27044 = env27045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env27044 == env27045) = true)

def env27046 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58396,272392,17,95496,8193,64,23809,5393,45404,262145,61704,318548,257,21792,46092,120406]

theorem envBound27046 : H12AffineFastState.Bounded env27046 := by
  intro p hp
  have h : env27046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27028_27046 : H12AffineEnvironment.transform 6 9 env27028 = env27046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27028 == env27046) = true)

theorem identity27046 : scanCanonicalize (H12AffineFastState.compose env27046 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130175) := by decide +kernel

theorem selectedBound27046 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27047 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,130175,1025,32769,58396,119927,17,95496,8193,64,23809,5393,45404,130174,61704,73771,257,21792,46092,120406]

theorem envBound27047 : H12AffineFastState.Bounded env27047 := by
  intro p hp
  have h : env27047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27046_27047 : H12AffineEnvironment.transform 17 130175 env27046 = env27047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130175 env27046 == env27047) = true)

theorem identity27047 : scanCanonicalize (H12AffineFastState.compose env27047 (packedSelected [0,1,2,4,6,7,8,10,14,15,16,18,19,22,26] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound27047 : packedSelected [0,1,2,4,6,7,8,10,14,15,16,18,19,22,26] rootPS < 2^1333 := by decide +kernel

def env27048 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21590,49168,43049,1025,32769,58396,32801,17,8542,8193,64,23809,5393,45404,43048,61704,29821,257,21792,46092,33280]

theorem envBound27048 : H12AffineFastState.Bounded env27048 := by
  intro p hp
  have h : env27048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27047_27048 : H12AffineEnvironment.transform 15 21590 env27047 = env27048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env27047 == env27048) = true)

theorem identity27048 : scanCanonicalize (H12AffineFastState.compose env27048 (packedSelected [0,3,4,5,7,9,11,15,18,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound27048 : packedSelected [0,3,4,5,7,9,11,15,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env27049 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,32768,8282,46108,43049,1025,32769,36880,32801,17,8542,8193,64,10509,5393,45404,43048,34052,113,257,8492,46092,33280]

theorem envBound27049 : H12AffineFastState.Bounded env27049 := by
  intro p hp
  have h : env27049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27048_27049 : H12AffineEnvironment.transform 13 13324 env27048 = env27049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env27048 == env27049) = true)

theorem identity27049 : scanCanonicalize (H12AffineFastState.compose env27049 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound27049 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env27050 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8461,8282,5393,2340,1025,8460,12573,8492,17,8542,8193,64,10509,5393,4177,2341,9225,113,257,8492,5377,8973]

theorem envBound27050 : H12AffineFastState.Bounded env27050 := by
  intro p hp
  have h : env27050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27049_27050 : H12AffineEnvironment.transform 14 8461 env27049 = env27050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env27049 == env27050) = true)

theorem identity27050 : scanCanonicalize (H12AffineFastState.compose env27050 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound27050 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env27051 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,0,343,5393,2340,1025,1,4112,33,17,83,268,64,2048,5393,4177,2341,1284,113,257,33,5377,512]

theorem envBound27051 : H12AffineFastState.Bounded env27051 := by
  intro p hp
  have h : env27051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27050_27051 : H12AffineEnvironment.transform 12 269 env27050 = env27051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env27050 == env27051) = true)

theorem identity27051 : scanCanonicalize (H12AffineFastState.compose env27051 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27051 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27052 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,269,5377,0,343,5393,2309,1025,1,4112,0,17,83,268,64,2048,5393,4177,2308,1284,80,257,0,5377,512]

theorem envBound27052 : H12AffineFastState.Bounded env27052 := by
  intro p hp
  have h : env27052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27051_27052 : H12AffineEnvironment.transform 4 1 env27051 = env27052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27051 == env27052) = true)

theorem identity27052 : scanCanonicalize (H12AffineFastState.compose env27052 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound27052 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27053 : List Nat := [2,4,8,16,1,64,9,256,512,272,2048,4096,269,4113,0,343,4097,2309,273,1,4112,0,17,83,268,64,2048,4097,4177,2308,20,80,257,0,4113,512]

theorem envBound27053 : H12AffineFastState.Bounded env27053 := by
  intro p hp
  have h : env27053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27052_27053 : H12AffineEnvironment.transform 9 272 env27052 = env27053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env27052 == env27053) = true)

theorem identity27053 : scanCanonicalize (H12AffineFastState.compose env27053 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 341) := by decide +kernel

theorem selectedBound27053 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27054 : List Nat := [2,4,8,16,1,64,9,256,512,272,341,4096,269,4113,0,343,4097,80,273,1,4112,0,17,83,268,64,341,4097,4177,81,20,80,257,0,4113,512]

theorem envBound27054 : H12AffineFastState.Bounded env27054 := by
  intro p hp
  have h : env27054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27053_27054 : H12AffineEnvironment.transform 10 341 env27053 = env27054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 341 env27053 == env27054) = true)

theorem identity27054 : scanCanonicalize (H12AffineFastState.compose env27054 (packedSelected [1,2,3,4,5,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound27054 : packedSelected [1,2,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env27055 : List Nat := [2,4,8,16,1,64,9,256,512,272,341,17,269,0,0,343,16,80,273,1,1,0,17,83,268,64,341,16,64,81,20,80,257,0,0,512]

theorem envBound27055 : H12AffineFastState.Bounded env27055 := by
  intro p hp
  have h : env27055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27054_27055 : H12AffineEnvironment.transform 11 17 env27054 = env27055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env27054 == env27055) = true)

theorem identity27055 : scanCanonicalize (H12AffineFastState.compose env27055 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27055 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env27056 : List Nat := [2,4,8,16,1,17,9,256,512,272,260,17,269,0,0,262,16,1,273,1,1,0,17,2,268,17,260,16,17,0,20,1,257,0,0,512]

theorem envBound27056 : H12AffineFastState.Bounded env27056 := by
  intro p hp
  have h : env27056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27055_27056 : H12AffineEnvironment.transform 5 17 env27055 = env27056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27055 == env27056) = true)

theorem identity27056 : scanCanonicalize (H12AffineFastState.compose env27056 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound27056 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27057 : List Nat := [2,4,8,16,1,17,9,5,512,21,1,17,8,0,0,3,16,1,20,1,1,0,17,2,9,17,1,16,17,0,20,1,4,0,0,512]

theorem envBound27057 : H12AffineFastState.Bounded env27057 := by
  intro p hp
  have h : env27057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27056_27057 : H12AffineEnvironment.transform 7 5 env27056 = env27057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env27056 == env27057) = true)

theorem identity27057 : scanCanonicalize (H12AffineFastState.compose env27057 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound27057 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27058 : List Nat := [2,4,8,16,1,17,9,5,0,21,1,17,8,0,0,3,16,1,20,1,1,0,17,2,9,17,1,16,17,0,20,1,4,0,0,0]

theorem envBound27058 : H12AffineFastState.Bounded env27058 := by
  intro p hp
  have h : env27058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27057_27058 : H12AffineEnvironment.transform 8 0 env27057 = env27058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env27057 == env27058) = true)

theorem identity27058 : scanCanonicalize (H12AffineFastState.compose env27058 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound27058 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27059 : List Nat := [2,4,8,15,1,14,9,5,0,10,1,14,8,0,0,3,15,1,11,1,1,0,14,2,9,14,1,15,14,0,11,1,4,0,0,0]

theorem envBound27059 : H12AffineFastState.Bounded env27059 := by
  intro p hp
  have h : env27059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27058_27059 : H12AffineEnvironment.transform 3 15 env27058 = env27059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env27058 == env27059) = true)

def env27060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,4194304,180361,95497,8328,64,4486528,185737,45524,262281,143761,4338884,257,21792,46213,202310]

theorem envBound27060 : H12AffineFastState.Bounded env27060 := by
  intro p hp
  have h : env27060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26975_27060 : H12AffineEnvironment.transform 22 180361 env26975 = env27060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180361 env26975 == env27060) = true)

def env27061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,272512,180361,95497,8328,64,23808,185737,45524,262281,143761,400452,257,21792,46213,202310]

theorem envBound27061 : H12AffineFastState.Bounded env27061 := by
  intro p hp
  have h : env27061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27060_27061 : H12AffineEnvironment.transform 21 272512 env27060 = env27061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env27060 == env27061) = true)

theorem identity27061 : scanCanonicalize (H12AffineFastState.compose env27061 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound27061 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,140300,272512,144477,95497,8328,64,23808,139613,17664,262281,143761,400452,257,21792,16465,202310]

theorem envBound27062 : H12AffineFastState.Bounded env27062 := by
  intro p hp
  have h : env27062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27061_27062 : H12AffineEnvironment.transform 14 29908 env27061 = env27062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env27061 == env27062) = true)

def env27063 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,140300,272392,144477,95497,8192,64,23808,139613,17664,262145,143641,400452,257,21792,16465,202310]

theorem envBound27063 : H12AffineFastState.Bounded env27063 := by
  intro p hp
  have h : env27063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27062_27063 : H12AffineEnvironment.transform 6 8 env27062 = env27063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27062 == env27063) = true)

theorem identity27063 : scanCanonicalize (H12AffineFastState.compose env27063 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 212078) := by decide +kernel

theorem selectedBound27063 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env27064 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,212078,1025,29789,140300,201830,144477,95497,8192,64,23808,139613,17664,212079,143641,73770,257,21792,16465,202310]

theorem envBound27064 : H12AffineFastState.Bounded env27064 := by
  intro p hp
  have h : env27064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27063_27064 : H12AffineEnvironment.transform 17 212078 env27063 = env27064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212078 env27063 == env27064) = true)

theorem identity27064 : scanCanonicalize (H12AffineFastState.compose env27064 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound27064 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env27065 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,131072,212078,1025,8540,140300,201830,144477,73736,8192,64,2049,139613,4097,212079,143641,73770,257,33,5456,202310]

theorem envBound27065 : H12AffineFastState.Bounded env27065 := by
  intro p hp
  have h : env27065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27064_27065 : H12AffineEnvironment.transform 13 5377 env27064 = env27065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env27064 == env27065) = true)

theorem identity27065 : scanCanonicalize (H12AffineFastState.compose env27065 (packedSelected [2,3,5,6,11,12,14,16,17,19] rootPS)) = affineNative (2^(16+1) ^^^ 13673) := by decide +kernel

theorem selectedBound27065 : packedSelected [2,3,5,6,11,12,14,16,17,19] rootPS < 2^1333 := by decide +kernel

def env27066 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,13673,67847,1025,8540,4453,73999,308,73736,8192,64,2049,5172,4097,67846,1136,73770,257,33,5456,74543]

theorem envBound27066 : H12AffineFastState.Bounded env27066 := by
  intro p hp
  have h : env27066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27065_27066 : H12AffineEnvironment.transform 16 13673 env27065 = env27066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13673 env27065 == env27066) = true)

theorem identity27066 : scanCanonicalize (H12AffineFastState.compose env27066 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound27066 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env27067 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,0,65536,5172,67847,1025,1,4453,65618,308,65877,349,64,2049,5172,4097,67846,1136,65911,257,33,5456,66162]

theorem envBound27067 : H12AffineFastState.Bounded env27067 := by
  intro p hp
  have h : env27067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27066_27067 : H12AffineEnvironment.transform 12 349 env27066 = env27067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env27066 == env27067) = true)

theorem identity27067 : scanCanonicalize (H12AffineFastState.compose env27067 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound27067 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env27068 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,0,343,5172,2128,1025,1,4453,261,308,2,349,64,2049,5172,4097,2129,1136,32,257,33,5456,805]

theorem envBound27068 : H12AffineFastState.Bounded env27068 := by
  intro p hp
  have h : env27068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27067_27068 : H12AffineEnvironment.transform 15 343 env27067 = env27068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env27067 == env27068) = true)

def env27069 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,140300,272393,144477,95497,8193,64,23808,139613,17664,262144,143640,400452,257,21792,16465,202310]

theorem envBound27069 : H12AffineFastState.Bounded env27069 := by
  intro p hp
  have h : env27069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27062_27069 : H12AffineEnvironment.transform 6 9 env27062 = env27069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27062 == env27069) = true)

theorem identity27069 : scanCanonicalize (H12AffineFastState.compose env27069 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 146744) := by decide +kernel

theorem selectedBound27069 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env27070 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,146744,1025,29788,140300,136497,144477,95497,8193,64,23808,139613,17664,146744,143640,8572,257,21792,16465,202310]

theorem envBound27070 : H12AffineFastState.Bounded env27070 := by
  intro p hp
  have h : env27070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27069_27070 : H12AffineEnvironment.transform 17 146744 env27069 = env27070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146744 env27069 == env27070) = true)

theorem identity27070 : scanCanonicalize (H12AffineFastState.compose env27070 (packedSelected [3,4,5,7,8,9,10,11,17,19,26,27,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound27070 : packedSelected [3,4,5,7,8,9,10,11,17,19,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env27071 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,13389,2421,1025,29788,4161,8572,16,95497,8193,64,23808,5392,17664,2421,1365,8572,257,21792,16465,74251]

theorem envBound27071 : H12AffineFastState.Bounded env27071 := by
  intro p hp
  have h : env27071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27070_27071 : H12AffineEnvironment.transform 16 13389 env27070 = env27071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env27070 == env27071) = true)

theorem identity27071 : scanCanonicalize (H12AffineFastState.compose env27071 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound27071 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27072 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,13389,2421,1025,29788,4161,8572,16,21763,8193,64,23808,5392,17664,2421,1365,8572,257,21792,16465,513]

theorem envBound27072 : H12AffineFastState.Bounded env27072 := by
  intro p hp
  have h : env27072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27071_27072 : H12AffineEnvironment.transform 15 8202 env27071 = env27072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env27071 == env27072) = true)

theorem identity27072 : scanCanonicalize (H12AffineFastState.compose env27072 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound27072 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env27073 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8202,13389,2421,1025,8540,4161,8572,16,3,8193,64,2048,5392,4096,2421,1365,8572,257,32,5457,513]

theorem envBound27073 : H12AffineFastState.Bounded env27073 := by
  intro p hp
  have h : env27073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27072_27073 : H12AffineEnvironment.transform 13 5376 env27072 = env27073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env27072 == env27073) = true)

theorem identity27073 : scanCanonicalize (H12AffineFastState.compose env27073 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound27073 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27074 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,342,5393,2421,1025,0,4161,32,16,3,349,64,2048,5392,4096,2421,1365,32,257,32,5457,513]

theorem envBound27074 : H12AffineFastState.Bounded env27074 := by
  intro p hp
  have h : env27074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27073_27074 : H12AffineEnvironment.transform 12 348 env27073 = env27074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env27073 == env27074) = true)

theorem identity27074 : scanCanonicalize (H12AffineFastState.compose env27074 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound27074 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27075 : List Nat := [2,4,8,16,32,64,9,256,512,1024,10,4096,348,5376,1,342,5393,383,1025,0,4161,32,16,3,349,64,10,5392,4096,383,1365,32,257,32,5457,513]

theorem envBound27075 : H12AffineFastState.Bounded env27075 := by
  intro p hp
  have h : env27075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27074_27075 : H12AffineEnvironment.transform 10 10 env27074 = env27075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env27074 == env27075) = true)

theorem identity27075 : scanCanonicalize (H12AffineFastState.compose env27075 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound27075 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27076 : List Nat := [2,4,8,16,32,64,9,256,512,1024,10,1077,348,309,1,342,292,383,1025,0,1140,32,16,3,349,64,10,293,1077,383,1365,32,257,32,356,513]

theorem envBound27076 : H12AffineFastState.Bounded env27076 := by
  intro p hp
  have h : env27076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27075_27076 : H12AffineEnvironment.transform 11 1077 env27075 = env27076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env27075 == env27076) = true)

theorem identity27076 : scanCanonicalize (H12AffineFastState.compose env27076 (packedSelected [2,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27076 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env27077 : List Nat := [2,4,8,16,32,17,9,256,512,1024,10,1077,269,309,1,263,292,302,1025,0,1061,32,16,3,268,17,10,293,1077,302,1284,32,257,32,309,513]

theorem envBound27077 : H12AffineFastState.Bounded env27077 := by
  intro p hp
  have h : env27077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27076_27077 : H12AffineEnvironment.transform 5 17 env27076 = env27077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27076 == env27077) = true)

def env27078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,272513,180361,95497,8328,64,23809,185737,45524,262281,143761,400453,257,21792,46213,202310]

theorem envBound27078 : H12AffineFastState.Bounded env27078 := by
  intro p hp
  have h : env27078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27060_27078 : H12AffineEnvironment.transform 21 272513 env27060 = env27078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env27060 == env27078) = true)

theorem identity27078 : scanCanonicalize (H12AffineFastState.compose env27078 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound27078 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,262144,1025,32769,4160,272513,62661,95497,8328,64,23809,57797,45524,262281,1501,272393,257,21792,46213,74250]

theorem envBound27079 : H12AffineFastState.Bounded env27079 := by
  intro p hp
  have h : env27079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27078_27079 : H12AffineEnvironment.transform 16 13388 env27078 = env27079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env27078 == env27079) = true)

theorem identity27079 : scanCanonicalize (H12AffineFastState.compose env27079 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound27079 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env27080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,13388,262144,1025,32769,4160,272513,62661,21762,8328,64,23809,57797,45524,262281,1501,272393,257,21792,46213,513]

theorem envBound27080 : H12AffineFastState.Bounded env27080 := by
  intro p hp
  have h : env27080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27079_27080 : H12AffineEnvironment.transform 15 8203 env27079 = env27080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env27079 == env27080) = true)

theorem identity27080 : scanCanonicalize (H12AffineFastState.compose env27080 (packedSelected [7,12,14,15,16,27,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound27080 : packedSelected [7,12,14,15,16,27,38,41] rootPS < 2^1333 := by decide +kernel

def env27081 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,479,5528,262144,1025,32769,4160,264533,54545,21762,348,64,23809,49169,36864,262281,1501,264669,257,21792,38225,513]

theorem envBound27081 : H12AffineFastState.Bounded env27081 := by
  intro p hp
  have h : env27081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27080_27081 : H12AffineEnvironment.transform 12 468 env27080 = env27081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env27080 == env27081) = true)

theorem identity27081 : scanCanonicalize (H12AffineFastState.compose env27081 (packedSelected [0,7,9,14,16,22] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound27081 : packedSelected [0,7,9,14,16,22] rootPS < 2^1333 := by decide +kernel

def env27082 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,479,5528,56436,1025,32769,4160,54561,54545,21762,348,64,23809,49169,36864,56573,1501,54697,257,21792,38225,513]

theorem envBound27082 : H12AffineFastState.Bounded env27082 := by
  intro p hp
  have h : env27082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27081_27082 : H12AffineEnvironment.transform 17 56436 env27081 = env27082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env27081 == env27082) = true)

theorem identity27082 : scanCanonicalize (H12AffineFastState.compose env27082 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound27082 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env27083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,32768,479,5528,35325,1025,32769,4160,32936,32920,139,348,64,2184,38296,36864,35188,1501,32800,257,169,38225,513]

theorem envBound27083 : H12AffineFastState.Bounded env27083 := by
  intro p hp
  have h : env27083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27082_27083 : H12AffineEnvironment.transform 13 5513 env27082 = env27083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env27082 == env27083) = true)

theorem identity27083 : scanCanonicalize (H12AffineFastState.compose env27083 (packedSelected [0,2,3,4,5,7,9,10,12,15,17,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound27083 : packedSelected [0,2,3,4,5,7,9,10,12,15,17,18,23] rootPS < 2^1333 := by decide +kernel

def env27084 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,136,479,5528,2421,1025,137,4160,32,16,139,348,64,2184,5392,4232,2556,1501,168,257,169,5593,513]

theorem envBound27084 : H12AffineFastState.Bounded env27084 := by
  intro p hp
  have h : env27084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27083_27084 : H12AffineEnvironment.transform 14 136 env27083 = env27084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env27083 == env27084) = true)

theorem identity27084 : scanCanonicalize (H12AffineFastState.compose env27084 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound27084 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27085 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,268,5457,80,263,5440,2421,1025,81,4160,32,16,83,348,64,2128,5392,4176,2340,1285,112,257,113,5377,513]

theorem envBound27085 : H12AffineFastState.Bounded env27085 := by
  intro p hp
  have h : env27085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27084_27085 : H12AffineEnvironment.transform 6 88 env27084 = env27085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env27084 == env27085) = true)

theorem identity27085 : scanCanonicalize (H12AffineFastState.compose env27085 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound27085 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env27086 : List Nat := [2,4,8,16,32,64,88,53,512,1024,2048,4096,57,5220,80,50,5237,2112,1025,81,4160,32,16,83,105,64,2128,5157,4176,2065,1072,112,52,113,5172,513]

theorem envBound27086 : H12AffineFastState.Bounded env27086 := by
  intro p hp
  have h : env27086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27085_27086 : H12AffineEnvironment.transform 7 53 env27085 = env27086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env27085 == env27086) = true)

theorem identity27086 : scanCanonicalize (H12AffineFastState.compose env27086 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 1573) := by decide +kernel

theorem selectedBound27086 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env27087 : List Nat := [2,4,8,16,32,64,88,53,512,1024,1573,4096,57,5220,80,50,5237,1637,1025,81,4160,32,16,83,105,64,1653,5157,4176,1588,1072,112,52,113,5172,513]

theorem envBound27087 : H12AffineFastState.Bounded env27087 := by
  intro p hp
  have h : env27087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27086_27087 : H12AffineEnvironment.transform 10 1573 env27086 = env27087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1573 env27086 == env27087) = true)

theorem identity27087 : scanCanonicalize (H12AffineFastState.compose env27087 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 593) := by decide +kernel

theorem selectedBound27087 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env27088 : List Nat := [2,4,8,16,32,64,88,53,512,1024,1573,593,57,1589,80,50,1572,1637,1025,81,529,32,16,83,105,64,1653,1652,513,1588,1072,112,52,113,1637,513]

theorem envBound27088 : H12AffineFastState.Bounded env27088 := by
  intro p hp
  have h : env27088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27087_27088 : H12AffineEnvironment.transform 11 593 env27087 = env27088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 593 env27087 == env27088) = true)

theorem identity27088 : scanCanonicalize (H12AffineFastState.compose env27088 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 613) := by decide +kernel

theorem selectedBound27088 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env27089 : List Nat := [2,4,8,16,32,64,88,53,512,613,64,593,57,80,80,50,65,0,612,81,529,32,16,83,105,64,16,17,513,81,597,112,52,113,0,513]

theorem envBound27089 : H12AffineFastState.Bounded env27089 := by
  intro p hp
  have h : env27089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27088_27089 : H12AffineEnvironment.transform 9 613 env27088 = env27089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 613 env27088 == env27089) = true)

theorem identity27089 : scanCanonicalize (H12AffineFastState.compose env27089 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound27089 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env27090 : List Nat := [2,4,8,16,32,64,88,53,17,116,64,64,57,80,80,50,65,0,117,81,0,32,16,83,105,64,16,17,16,81,68,112,52,113,0,16]

theorem envBound27090 : H12AffineFastState.Bounded env27090 := by
  intro p hp
  have h : env27090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27089_27090 : H12AffineEnvironment.transform 8 17 env27089 = env27090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env27089 == env27090) = true)

theorem identity27090 : scanCanonicalize (H12AffineFastState.compose env27090 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound27090 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27091 : List Nat := [2,4,8,1,32,64,73,36,0,101,64,64,40,65,65,35,65,0,100,64,0,32,1,66,105,64,1,0,1,64,68,97,37,96,0,1]

theorem envBound27091 : H12AffineFastState.Bounded env27091 := by
  intro p hp
  have h : env27091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27090_27091 : H12AffineEnvironment.transform 3 1 env27090 = env27091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27090 == env27091) = true)

theorem identity27091 : scanCanonicalize (H12AffineFastState.compose env27091 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound27091 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27092 : List Nat := [2,4,8,1,32,33,40,36,0,4,33,33,40,32,32,35,32,0,5,33,0,32,1,35,8,33,1,0,1,33,37,0,37,1,0,1]

theorem envBound27092 : H12AffineFastState.Bounded env27092 := by
  intro p hp
  have h : env27092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27091_27092 : H12AffineEnvironment.transform 5 33 env27091 = env27092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env27091 == env27092) = true)

theorem identity27092 : scanCanonicalize (H12AffineFastState.compose env27092 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27092 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27093 : List Nat := [2,4,8,1,0,1,8,4,0,4,1,1,8,0,0,3,0,0,5,1,0,0,1,3,8,1,1,0,1,1,5,0,5,1,0,1]

theorem envBound27093 : H12AffineFastState.Bounded env27093 := by
  intro p hp
  have h : env27093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27092_27093 : H12AffineEnvironment.transform 4 0 env27092 = env27093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27092 == env27093) = true)

def env27094 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,4194304,8388608,8631681,8328,64,4486529,8393985,8548701,8830976,143760,12645452,257,21793,46212,202311]

theorem envBound27094 : H12AffineFastState.Bounded env27094 := by
  intro p hp
  have h : env27094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26974_27094 : H12AffineEnvironment.transform 23 8631681 env26974 = env27094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8631681 env26974 == env27094) = true)

def env27095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,4194304,180360,95497,8328,64,4486529,185737,45525,262280,143760,4338884,257,21793,46212,202311]

theorem envBound27095 : H12AffineFastState.Bounded env27095 := by
  intro p hp
  have h : env27095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27094_27095 : H12AffineEnvironment.transform 22 180360 env27094 = env27095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180360 env27094 == env27095) = true)

def env27096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,272512,180360,95497,8328,64,23809,185737,45525,262280,143760,400452,257,21793,46212,202311]

theorem envBound27096 : H12AffineFastState.Bounded env27096 := by
  intro p hp
  have h : env27096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27095_27096 : H12AffineEnvironment.transform 21 272512 env27095 = env27096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env27095 == env27096) = true)

theorem identity27096 : scanCanonicalize (H12AffineFastState.compose env27096 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound27096 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70726,262144,1025,32769,77898,272512,120014,95497,8328,64,23809,115151,45525,262280,75222,329730,257,21793,46212,513]

theorem envBound27097 : H12AffineFastState.Bounded env27097 := by
  intro p hp
  have h : env27097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27096_27097 : H12AffineEnvironment.transform 16 70726 env27096 = env27097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env27096 == env27097) = true)

def env27098 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70726,262144,1025,32769,77898,272392,119878,95497,8192,64,23809,115015,45405,262144,75102,329730,257,21793,46092,513]

theorem envBound27098 : H12AffineFastState.Bounded env27098 := by
  intro p hp
  have h : env27098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27097_27098 : H12AffineEnvironment.transform 6 8 env27097 = env27098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27097 == env27098) = true)

theorem identity27098 : scanCanonicalize (H12AffineFastState.compose env27098 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound27098 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env27099 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,65536,70726,262144,1025,32769,77898,272392,106522,65877,8192,64,10589,111899,45405,262144,75102,329730,257,8573,46092,513]

theorem envBound27099 : H12AffineFastState.Bounded env27099 := by
  intro p hp
  have h : env27099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27098_27099 : H12AffineEnvironment.transform 13 13404 env27098 = env27099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env27098 == env27099) = true)

theorem identity27099 : scanCanonicalize (H12AffineFastState.compose env27099 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 100467) := by decide +kernel

theorem selectedBound27099 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env27100 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,65536,70726,100467,1025,32769,77898,106619,106522,65877,8192,64,10589,111899,45405,100467,75102,32881,257,8573,46092,513]

theorem envBound27100 : H12AffineFastState.Bounded env27100 := by
  intro p hp
  have h : env27100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27099_27100 : H12AffineEnvironment.transform 17 100467 env27099 = env27100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100467 env27099 == env27100) = true)

theorem identity27100 : scanCanonicalize (H12AffineFastState.compose env27100 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound27100 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env27101 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,343,5393,35108,1025,32769,12573,41260,41293,2,8192,64,10589,46156,45405,35108,9225,32881,257,8573,46092,513]

theorem envBound27101 : H12AffineFastState.Bounded env27101 := by
  intro p hp
  have h : env27101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27100_27101 : H12AffineEnvironment.transform 15 343 env27100 = env27101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env27100 == env27101) = true)

theorem identity27101 : scanCanonicalize (H12AffineFastState.compose env27101 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound27101 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env27102 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,4161,32768,343,5393,35108,1025,32769,5376,34097,34128,2,1053,64,3392,36945,38208,35108,20,32881,257,1376,36881,513]

theorem envBound27102 : H12AffineFastState.Bounded env27102 := by
  intro p hp
  have h : env27102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27101_27102 : H12AffineEnvironment.transform 12 1053 env27101 = env27102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env27101 == env27102) = true)

theorem identity27102 : scanCanonicalize (H12AffineFastState.compose env27102 (packedSelected [12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound27102 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env27103 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,1053,4161,32768,34,5220,34897,1025,32769,5237,33860,33829,2,1053,64,3125,36945,37941,34897,20,32881,116,1045,36881,513]

theorem envBound27103 : H12AffineFastState.Bounded env27103 := by
  intro p hp
  have h : env27103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27102_27103 : H12AffineEnvironment.transform 7 117 env27102 = env27103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env27102 == env27103) = true)

theorem identity27103 : scanCanonicalize (H12AffineFastState.compose env27103 (packedSelected [1,2,4,6,8,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound27103 : packedSelected [1,2,4,6,8,9,10] rootPS < 2^1333 := by decide +kernel

def env27104 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,1053,4161,0,34,5220,2129,1025,1,5237,1092,1061,2,1053,64,3125,4177,5173,2129,20,113,116,1045,4113,513]

theorem envBound27104 : H12AffineFastState.Bounded env27104 := by
  intro p hp
  have h : env27104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27103_27104 : H12AffineEnvironment.transform 14 0 env27103 = env27104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env27103 == env27104) = true)

theorem identity27104 : scanCanonicalize (H12AffineFastState.compose env27104 (packedSelected [0,2,5,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

end H12CloudChart0