import H12CloudChart0Data118

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity30183 : scanCanonicalize (H12AffineFastState.compose env30183 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound30183 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env30184 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,4113,1,1095,4097,2421,1025,0,4160,32,17,1298,1101,65,2049,5392,5392,2420,1365,32,257,1328,4160,513]

theorem envBound30184 : H12AffineFastState.Bounded env30184 := by
  intro p hp
  have h : env30184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30183_30184 : H12AffineEnvironment.transform 12 1101 env30183 = env30184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env30183 == env30184) = true)

theorem identity30184 : scanCanonicalize (H12AffineFastState.compose env30184 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound30184 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env30185 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,348,4113,1,342,4097,2421,272,0,4160,32,17,3,348,65,2049,4097,4097,2420,68,32,257,33,4160,513]

theorem envBound30185 : H12AffineFastState.Bounded env30185 := by
  intro p hp
  have h : env30185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30184_30185 : H12AffineEnvironment.transform 9 273 env30184 = env30185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env30184 == env30185) = true)

theorem identity30185 : scanCanonicalize (H12AffineFastState.compose env30185 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 96) := by decide +kernel

theorem selectedBound30185 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30186 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,96,348,113,1,342,97,2421,272,0,32,32,17,3,348,65,2049,97,97,2420,68,32,257,33,32,513]

theorem envBound30186 : H12AffineFastState.Bounded env30186 := by
  intro p hp
  have h : env30186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30185_30186 : H12AffineEnvironment.transform 11 96 env30185 = env30186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 96 env30185 == env30186) = true)

theorem identity30186 : scanCanonicalize (H12AffineFastState.compose env30186 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 814) := by decide +kernel

theorem selectedBound30186 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30187 : List Nat := [2,4,8,16,32,64,8,256,512,273,814,96,348,113,1,342,97,603,272,0,32,32,17,3,348,65,815,97,97,602,68,32,257,33,32,513]

theorem envBound30187 : H12AffineFastState.Bounded env30187 := by
  intro p hp
  have h : env30187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30186_30187 : H12AffineEnvironment.transform 10 814 env30186 = env30187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 814 env30186 == env30187) = true)

theorem identity30187 : scanCanonicalize (H12AffineFastState.compose env30187 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound30187 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env30188 : List Nat := [2,4,8,16,32,64,8,84,512,69,634,96,8,113,1,2,97,603,68,0,32,32,17,3,8,65,635,97,97,602,68,32,85,33,32,513]

theorem envBound30188 : H12AffineFastState.Bounded env30188 := by
  intro p hp
  have h : env30188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30187_30188 : H12AffineEnvironment.transform 7 84 env30187 = env30188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env30187 == env30188) = true)

theorem identity30188 : scanCanonicalize (H12AffineFastState.compose env30188 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound30188 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env30189 : List Nat := [2,4,8,16,32,64,8,84,33,69,91,96,8,113,1,2,97,122,68,0,32,32,17,3,8,65,90,97,97,123,68,32,85,33,32,32]

theorem envBound30189 : H12AffineFastState.Bounded env30189 := by
  intro p hp
  have h : env30189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30188_30189 : H12AffineEnvironment.transform 8 33 env30188 = env30189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env30188 == env30189) = true)

theorem identity30189 : scanCanonicalize (H12AffineFastState.compose env30189 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30189 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env30190 : List Nat := [2,4,3,16,32,64,3,84,33,69,80,96,3,113,1,2,97,113,68,0,32,32,17,3,3,65,81,97,97,112,68,32,85,33,32,32]

theorem envBound30190 : H12AffineFastState.Bounded env30190 := by
  intro p hp
  have h : env30190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30189_30190 : H12AffineEnvironment.transform 2 3 env30189 = env30190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30189 == env30190) = true)

theorem identity30190 : scanCanonicalize (H12AffineFastState.compose env30190 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound30190 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30191 : List Nat := [2,4,3,4,32,64,3,64,33,69,68,96,3,101,1,2,97,101,68,0,32,32,5,3,3,65,69,97,97,100,68,32,65,33,32,32]

theorem envBound30191 : H12AffineFastState.Bounded env30191 := by
  intro p hp
  have h : env30191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30190_30191 : H12AffineEnvironment.transform 3 4 env30190 = env30191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env30190 == env30191) = true)

theorem identity30191 : scanCanonicalize (H12AffineFastState.compose env30191 (packedSelected [1,5] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound30191 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env30192 : List Nat := [2,0,3,0,32,64,3,64,33,65,64,96,3,97,1,2,97,97,64,0,32,32,1,3,3,65,65,97,97,96,64,32,65,33,32,32]

theorem envBound30192 : H12AffineFastState.Bounded env30192 := by
  intro p hp
  have h : env30192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30191_30192 : H12AffineEnvironment.transform 1 0 env30191 = env30192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env30191 == env30192) = true)

theorem identity30192 : scanCanonicalize (H12AffineFastState.compose env30192 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound30192 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30193 : List Nat := [2,0,3,0,3,64,3,64,2,65,64,67,3,66,1,2,66,66,64,0,3,3,1,3,3,65,65,66,66,67,64,3,65,2,3,3]

theorem envBound30193 : H12AffineFastState.Bounded env30193 := by
  intro p hp
  have h : env30193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30192_30193 : H12AffineEnvironment.transform 4 3 env30192 = env30193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env30192 == env30193) = true)

theorem identity30193 : scanCanonicalize (H12AffineFastState.compose env30193 (packedSelected [4,12] rootPS)) = affineNative (2^(5+1) ^^^ 3) := by decide +kernel

theorem selectedBound30193 : packedSelected [4,12] rootPS < 2^1333 := by decide +kernel

def env30194 : List Nat := [2,0,3,0,3,3,3,3,2,2,3,0,3,1,1,2,1,1,3,0,3,3,1,3,3,2,2,1,1,0,3,3,2,2,3,3]

theorem envBound30194 : H12AffineFastState.Bounded env30194 := by
  intro p hp
  have h : env30194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30193_30194 : H12AffineEnvironment.transform 5 3 env30193 = env30194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 3 env30193 == env30194) = true)

theorem identity30194 : scanCanonicalize (H12AffineFastState.compose env30194 (packedSelected [15] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound30194 : packedSelected [15] rootPS < 2^1333 := by decide +kernel

def env30195 : List Nat := [0,0,1,0,1,1,1,1,0,0,1,0,1,1,1,0,1,1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,0,0,1,1]

theorem envBound30195 : H12AffineFastState.Bounded env30195 := by
  intro p hp
  have h : env30195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30194_30195 : H12AffineEnvironment.transform 0 0 env30194 = env30195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env30194 == env30195) = true)

def env30196 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32041,1025,32769,4160,4194304,17,21763,8193,65,4340844,5392,17665,179513,1364,4256861,257,21793,46093,63069]

theorem envBound30196 : H12AffineFastState.Bounded env30196 := by
  intro p hp
  have h : env30196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30178_30196 : H12AffineEnvironment.transform 6 9 env30178 = env30196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30178 == env30196) = true)

theorem identity30196 : scanCanonicalize (H12AffineFastState.compose env30196 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound30196 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30197 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33110,131072,10281,1025,32769,4160,4194304,17,3,8193,65,4340844,5392,4097,179513,1364,4235613,257,33,46093,41821]

theorem envBound30197 : H12AffineFastState.Bounded env30197 := by
  intro p hp
  have h : env30197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30196_30197 : H12AffineEnvironment.transform 13 5376 env30196 = env30197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env30196 == env30197) = true)

theorem identity30197 : scanCanonicalize (H12AffineFastState.compose env30197 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound30197 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30198 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33110,5393,10281,1025,32769,4160,4194304,17,3,8193,65,4204925,5392,4097,43048,1364,4235613,257,33,46093,41821]

theorem envBound30198 : H12AffineFastState.Bounded env30198 := by
  intro p hp
  have h : env30198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30197_30198 : H12AffineEnvironment.transform 16 5393 env30197 = env30198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env30197 == env30198) = true)

theorem identity30198 : scanCanonicalize (H12AffineFastState.compose env30198 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound30198 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30199 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,9293,9499,5393,10281,1025,9292,4160,4194304,17,3,8193,65,4204925,5392,4097,3173,1364,4195600,257,33,4160,1808]

theorem envBound30199 : H12AffineFastState.Bounded env30199 := by
  intro p hp
  have h : env30199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30198_30199 : H12AffineEnvironment.transform 14 9293 env30198 = env30199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env30198 == env30199) = true)

theorem identity30199 : scanCanonicalize (H12AffineFastState.compose env30199 (packedSelected [11,16,18,20] rootPS)) = affineNative (2^(21+1) ^^^ 8201) := by decide +kernel

theorem selectedBound30199 : packedSelected [11,16,18,20] rootPS < 2^1333 := by decide +kernel

def env30200 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,9293,9499,5393,10281,1025,9292,4160,8201,17,3,8193,65,2420,5392,4097,3173,1364,9497,257,33,4160,1808]

theorem envBound30200 : H12AffineFastState.Bounded env30200 := by
  intro p hp
  have h : env30200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30199_30200 : H12AffineEnvironment.transform 21 8201 env30199 = env30200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8201 env30199 == env30200) = true)

theorem identity30200 : scanCanonicalize (H12AffineFastState.compose env30200 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound30200 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env30201 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,5157,9293,9278,5172,10281,1025,9292,4160,8201,17,3,8193,65,2129,5173,4097,3173,1137,9276,36,33,4160,1589]

theorem envBound30201 : H12AffineFastState.Bounded env30201 := by
  intro p hp
  have h : env30201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30200_30201 : H12AffineEnvironment.transform 7 37 env30200 = env30201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env30200 == env30201) = true)

def env30202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4161,4194304,16,98780,8328,65,4340964,5393,17665,179512,1500,4256860,257,21793,46212,74250]

theorem envBound30202 : H12AffineFastState.Bounded env30202 := by
  intro p hp
  have h : env30202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30176_30202 : H12AffineEnvironment.transform 20 4161 env30176 = env30202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env30176 == env30202) = true)

theorem identity30202 : scanCanonicalize (H12AffineFastState.compose env30202 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 98679) := by decide +kernel

theorem selectedBound30202 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30203 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4161,98679,16,98780,8328,65,245139,5393,17665,179512,1500,95531,257,21793,46212,74250]

theorem envBound30203 : H12AffineFastState.Bounded env30203 := by
  intro p hp
  have h : env30203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30202_30203 : H12AffineEnvironment.transform 21 98679 env30202 = env30203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98679 env30202 == env30203) = true)

def env30204 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4161,98679,16,98644,8192,65,245019,5393,17665,179512,1364,95531,257,21793,46092,74250]

theorem envBound30204 : H12AffineFastState.Bounded env30204 := by
  intro p hp
  have h : env30204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30203_30204 : H12AffineEnvironment.transform 6 8 env30203 = env30204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30203 == env30204) = true)

theorem identity30204 : scanCanonicalize (H12AffineFastState.compose env30204 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound30204 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30205 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,131072,32041,1025,32769,4161,62589,16,62558,8192,65,182289,5393,17665,179512,1364,33,257,21793,46092,22272]

theorem envBound30205 : H12AffineFastState.Bounded env30205 := by
  intro p hp
  have h : env30205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30204_30205 : H12AffineEnvironment.transform 15 29962 env30204 = env30205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env30204 == env30205) = true)

theorem identity30205 : scanCanonicalize (H12AffineFastState.compose env30205 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound30205 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env30206 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,13388,32041,1025,32769,4161,62589,16,62558,8192,65,64605,5393,17665,35188,1364,33,257,21793,46092,22272]

theorem envBound30206 : H12AffineFastState.Bounded env30206 := by
  intro p hp
  have h : env30206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30205_30206 : H12AffineEnvironment.transform 16 13388 env30205 = env30206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env30205 == env30206) = true)

theorem identity30206 : scanCanonicalize (H12AffineFastState.compose env30206 (packedSelected [1,4,8,9,11,14,18,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound30206 : packedSelected [1,4,8,9,11,14,18,19,20] rootPS < 2^1333 := by decide +kernel

def env30207 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,32768,8282,13388,10361,1025,32769,4161,41261,16,41230,8192,65,43277,5393,4177,35188,1364,33,257,113,46092,592]

theorem envBound30207 : H12AffineFastState.Bounded env30207 := by
  intro p hp
  have h : env30207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30206_30207 : H12AffineEnvironment.transform 13 5456 env30206 = env30207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env30206 == env30207) = true)

theorem identity30207 : scanCanonicalize (H12AffineFastState.compose env30207 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30207 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env30208 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,32768,8202,13340,10281,1025,32769,4113,41261,16,41230,8192,17,43277,5393,4097,35108,1284,33,257,33,46092,512]

theorem envBound30208 : H12AffineFastState.Bounded env30208 := by
  intro p hp
  have h : env30208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30207_30208 : H12AffineEnvironment.transform 5 16 env30207 = env30208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30207 == env30208) = true)

theorem identity30208 : scanCanonicalize (H12AffineFastState.compose env30208 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 33) := by decide +kernel

theorem selectedBound30208 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30209 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,33,8202,13340,10281,1025,32,4113,8460,16,8495,8192,17,10540,5393,4097,2309,1284,33,257,33,13357,512]

theorem envBound30209 : H12AffineFastState.Bounded env30209 := by
  intro p hp
  have h : env30209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30208_30209 : H12AffineEnvironment.transform 14 33 env30208 = env30209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 33 env30208 == env30209) = true)

theorem identity30209 : scanCanonicalize (H12AffineFastState.compose env30209 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound30209 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30210 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,1053,5376,33,1047,4097,3124,1025,32,4113,1297,16,1330,1053,17,3377,5393,4097,2309,1284,33,257,33,4144,512]

theorem envBound30210 : H12AffineFastState.Bounded env30210 := by
  intro p hp
  have h : env30210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30209_30210 : H12AffineEnvironment.transform 12 1053 env30209 = env30210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env30209 == env30210) = true)

theorem identity30210 : scanCanonicalize (H12AffineFastState.compose env30210 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound30210 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env30211 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3328,1053,2048,33,1047,3329,3124,1025,32,3345,1297,16,1330,1053,17,3377,2065,3329,2309,1284,33,257,33,3376,512]

theorem envBound30211 : H12AffineFastState.Bounded env30211 := by
  intro p hp
  have h : env30211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30210_30211 : H12AffineEnvironment.transform 11 3328 env30210 = env30211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env30210 == env30211) = true)

theorem identity30211 : scanCanonicalize (H12AffineFastState.compose env30211 (packedSelected [1,3,5,8,11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound30211 : packedSelected [1,3,5,8,11] rootPS < 2^1333 := by decide +kernel

def env30212 : List Nat := [2,4,8,16,1,16,8,256,512,1024,2048,3328,1053,2048,0,1047,3329,3093,1025,1,3345,1297,16,1299,1053,17,3344,2065,3329,2309,1284,0,257,0,3345,512]

theorem envBound30212 : H12AffineFastState.Bounded env30212 := by
  intro p hp
  have h : env30212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30211_30212 : H12AffineEnvironment.transform 4 1 env30211 = env30212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env30211 == env30212) = true)

theorem identity30212 : scanCanonicalize (H12AffineFastState.compose env30212 (packedSelected [0,2,7,12] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound30212 : packedSelected [0,2,7,12] rootPS < 2^1333 := by decide +kernel

def env30213 : List Nat := [2,4,8,16,1,16,8,256,512,21,2048,2325,8,2048,0,2,2324,2048,20,1,2308,260,16,262,8,17,2309,2065,2324,2309,273,0,257,0,2308,512]

theorem envBound30213 : H12AffineFastState.Bounded env30213 := by
  intro p hp
  have h : env30213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30212_30213 : H12AffineEnvironment.transform 9 21 env30212 = env30213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env30212 == env30213) = true)

theorem identity30213 : scanCanonicalize (H12AffineFastState.compose env30213 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound30213 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env30214 : List Nat := [2,4,8,16,1,16,8,256,512,21,0,277,8,0,0,2,276,0,20,1,260,260,16,262,8,17,261,17,276,261,273,0,257,0,260,512]

theorem envBound30214 : H12AffineFastState.Bounded env30214 := by
  intro p hp
  have h : env30214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30213_30214 : H12AffineEnvironment.transform 10 0 env30213 = env30214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env30213 == env30214) = true)

theorem identity30214 : scanCanonicalize (H12AffineFastState.compose env30214 (packedSelected [2,14] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound30214 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env30215 : List Nat := [2,4,8,16,1,16,8,5,512,21,0,16,8,0,0,2,17,0,20,1,1,1,16,3,8,17,0,17,17,0,20,0,4,0,1,512]

theorem envBound30215 : H12AffineFastState.Bounded env30215 := by
  intro p hp
  have h : env30215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30214_30215 : H12AffineEnvironment.transform 7 5 env30214 = env30215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env30214 == env30215) = true)

theorem identity30215 : scanCanonicalize (H12AffineFastState.compose env30215 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound30215 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30216 : List Nat := [2,1,8,16,1,16,8,0,512,16,0,16,8,0,0,2,17,0,17,1,1,1,16,3,8,17,0,17,17,0,17,0,1,0,1,512]

theorem envBound30216 : H12AffineFastState.Bounded env30216 := by
  intro p hp
  have h : env30216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30215_30216 : H12AffineEnvironment.transform 1 1 env30215 = env30216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env30215 == env30216) = true)

theorem identity30216 : scanCanonicalize (H12AffineFastState.compose env30216 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound30216 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30217 : List Nat := [2,1,8,9,1,9,8,0,512,9,0,9,8,0,0,2,8,0,8,1,1,1,9,3,8,8,0,8,8,0,8,0,1,0,1,512]

theorem envBound30217 : H12AffineFastState.Bounded env30217 := by
  intro p hp
  have h : env30217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30216_30217 : H12AffineEnvironment.transform 3 9 env30216 = env30217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env30216 == env30217) = true)

theorem identity30217 : scanCanonicalize (H12AffineFastState.compose env30217 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound30217 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30218 : List Nat := [2,1,1,0,1,0,1,0,512,0,0,0,1,0,0,2,1,0,1,1,1,1,0,3,1,1,0,1,1,0,1,0,1,0,1,512]

theorem envBound30218 : H12AffineFastState.Bounded env30218 := by
  intro p hp
  have h : env30218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30217_30218 : H12AffineEnvironment.transform 2 1 env30217 = env30218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env30217 == env30218) = true)

theorem identity30218 : scanCanonicalize (H12AffineFastState.compose env30218 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound30218 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30219 : List Nat := [1,1,1,0,1,0,1,0,512,0,0,0,1,0,0,1,1,0,1,1,1,1,0,0,1,1,0,1,1,0,1,0,1,0,1,512]

theorem envBound30219 : H12AffineFastState.Bounded env30219 := by
  intro p hp
  have h : env30219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30218_30219 : H12AffineEnvironment.transform 0 1 env30218 = env30219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env30218 == env30219) = true)

theorem identity30219 : scanCanonicalize (H12AffineFastState.compose env30219 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound30219 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env30220 : List Nat := [1,1,1,0,1,0,1,0,0,0,0,0,1,0,0,1,1,0,1,1,1,1,0,0,1,1,0,1,1,0,1,0,1,0,1,0]

theorem envBound30220 : H12AffineFastState.Bounded env30220 := by
  intro p hp
  have h : env30220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30219_30220 : H12AffineEnvironment.transform 8 0 env30219 = env30220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env30219 == env30220) = true)

def env30221 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4161,98679,16,98645,8193,65,245018,5393,17665,179512,1365,95531,257,21793,46093,74250]

theorem envBound30221 : H12AffineFastState.Bounded env30221 := by
  intro p hp
  have h : env30221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30203_30221 : H12AffineEnvironment.transform 6 9 env30203 = env30221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30203 == env30221) = true)

theorem identity30221 : scanCanonicalize (H12AffineFastState.compose env30221 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound30221 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30222 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32041,1025,32769,4161,21792,16,21762,8193,65,158029,5393,17665,179512,1365,41340,257,21793,46093,63069]

theorem envBound30222 : H12AffineFastState.Bounded env30222 := by
  intro p hp
  have h : env30222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30221_30222 : H12AffineEnvironment.transform 15 54359 env30221 = env30222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env30221 == env30222) = true)

theorem identity30222 : scanCanonicalize (H12AffineFastState.compose env30222 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound30222 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env30223 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,131072,32041,1025,29789,4161,21792,16,21762,8193,65,158029,5393,17665,149860,1365,21792,257,21793,16465,513]

theorem envBound30223 : H12AffineFastState.Bounded env30223 := by
  intro p hp
  have h : env30223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30222_30223 : H12AffineEnvironment.transform 14 29788 env30222 = env30223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env30222 == env30223) = true)

theorem identity30223 : scanCanonicalize (H12AffineFastState.compose env30223 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 17664) := by decide +kernel

theorem selectedBound30223 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env30224 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,17664,32041,1025,29789,4161,21792,16,21762,8193,65,11341,5393,17665,3172,1365,21792,257,21793,16465,513]

theorem envBound30224 : H12AffineFastState.Bounded env30224 := by
  intro p hp
  have h : env30224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30223_30224 : H12AffineEnvironment.transform 16 17664 env30223 = env30224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 17664 env30223 == env30224) = true)

theorem identity30224 : scanCanonicalize (H12AffineFastState.compose env30224 (packedSelected [12,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound30224 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env30225 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,29788,8203,17445,31756,1025,29789,4161,21509,16,21543,8193,65,11341,5172,17444,3172,1136,21509,36,21508,16465,513]

theorem envBound30225 : H12AffineFastState.Bounded env30225 := by
  intro p hp
  have h : env30225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30224_30225 : H12AffineEnvironment.transform 7 37 env30224 = env30225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env30224 == env30225) = true)

theorem identity30225 : scanCanonicalize (H12AffineFastState.compose env30225 (packedSelected [0,4,6,7,9,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30225 : packedSelected [0,4,6,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env30226 : List Nat := [2,4,8,16,0,64,9,5,512,1024,2048,4096,8192,16384,29788,8203,17413,31756,1025,29789,4161,21509,16,21511,8193,65,11341,5140,17412,3140,1104,21509,4,21508,16465,513]

theorem envBound30226 : H12AffineFastState.Bounded env30226 := by
  intro p hp
  have h : env30226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30225_30226 : H12AffineEnvironment.transform 4 0 env30225 = env30226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30225 == env30226) = true)

theorem identity30226 : scanCanonicalize (H12AffineFastState.compose env30226 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound30226 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env30227 : List Nat := [2,4,8,16,0,64,9,5,512,21,2048,4096,8192,16384,28745,8203,16400,30745,20,28744,4161,20496,16,20498,8193,65,10328,4097,16401,2129,69,20496,4,20497,16465,513]

theorem envBound30227 : H12AffineFastState.Bounded env30227 := by
  intro p hp
  have h : env30227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30226_30227 : H12AffineEnvironment.transform 9 21 env30226 = env30227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env30226 == env30227) = true)

theorem identity30227 : scanCanonicalize (H12AffineFastState.compose env30227 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 4105) := by decide +kernel

theorem selectedBound30227 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30228 : List Nat := [2,4,8,16,0,64,9,5,512,21,2048,4096,4105,16384,16448,4098,16400,18448,20,16449,4161,20496,16,20498,4104,65,6225,4097,16401,2129,69,20496,4,20497,16465,513]

theorem envBound30228 : H12AffineFastState.Bounded env30228 := by
  intro p hp
  have h : env30228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30227_30228 : H12AffineEnvironment.transform 12 4105 env30227 = env30228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4105 env30227 == env30228) = true)

theorem identity30228 : scanCanonicalize (H12AffineFastState.compose env30228 (packedSelected [0,2,4,5,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound30228 : packedSelected [0,2,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env30229 : List Nat := [2,4,8,16,0,64,9,5,512,21,2048,512,521,16384,16448,514,16400,18448,20,16449,577,16912,16,16914,520,65,2641,513,16401,2129,69,16912,4,16913,16465,513]

theorem envBound30229 : H12AffineFastState.Bounded env30229 := by
  intro p hp
  have h : env30229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30228_30229 : H12AffineEnvironment.transform 11 512 env30228 = env30229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env30228 == env30229) = true)

def env30230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507600,9356289,25265168,23160256,525568,27902124,27337993,25733063]

theorem envBound30230 : H12AffineFastState.Bounded env30230 := by
  intro p hp
  have h : env30230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29822_30230 : H12AffineEnvironment.transform 26 30393345 env29822 = env30230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env29822 == env30230) = true)

def env30231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507600,8830977,25265168,23160256,256,27378860,27337993,25207751]

theorem envBound30231 : H12AffineFastState.Bounded env30231 := by
  intro p hp
  have h : env30231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30230_30231 : H12AffineEnvironment.transform 18 1024 env30230 = env30231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env30230 == env30231) = true)

theorem identity30231 : scanCanonicalize (H12AffineFastState.compose env30231 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 485861) := by decide +kernel

theorem selectedBound30231 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env30232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,485861,8328,65,12626404,2551144,10507600,8830977,8842741,6687781,256,10923337,10898668,8899106]

theorem envBound30232 : H12AffineFastState.Bounded env30232 := by
  intro p hp
  have h : env30232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30231_30232 : H12AffineEnvironment.transform 23 485861 env30231 = env30232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 485861 env30231 == env30232) = true)

def env30233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2553960,485861,8328,65,6705548,2551144,437560,2111593,2102685,6687781,256,21793,46212,2175562]

theorem envBound30233 : H12AffineFastState.Bounded env30233 := by
  intro p hp
  have h : env30233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30232_30233 : H12AffineEnvironment.transform 22 2553960 env30232 = env30233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2553960 env30232 == env30233) = true)

def env30234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,2097152,4194304,2101328,98781,8328,65,6338996,2098512,17664,2111593,2102685,6349853,256,21793,46212,2175562]

theorem envBound30234 : H12AffineFastState.Bounded env30234 := by
  intro p hp
  have h : env30234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30233_30234 : H12AffineEnvironment.transform 17 190520 env30233 = env30234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190520 env30233 == env30234) = true)

def env30235 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,4194304,16,98781,8328,65,4237812,5392,17664,10281,1501,4256861,256,21793,46212,74250]

theorem envBound30235 : H12AffineFastState.Bounded env30235 := by
  intro p hp
  have h : env30235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30234_30235 : H12AffineEnvironment.transform 20 4160 env30234 = env30235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env30234 == env30235) = true)

theorem identity30235 : scanCanonicalize (H12AffineFastState.compose env30235 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound30235 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30236 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,138477,1024,29908,4160,4194304,16,95496,8328,65,4218145,5392,17664,10281,1501,4194440,256,21793,16465,74250]

theorem envBound30236 : H12AffineFastState.Bounded env30236 := by
  intro p hp
  have h : env30236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30235_30236 : H12AffineEnvironment.transform 14 29909 env30235 = env30236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env30235 == env30236) = true)

def env30237 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,138477,1024,8660,4160,4194304,16,73736,8328,65,4196385,5392,4096,10281,1501,4194440,256,33,5457,74250]

theorem envBound30237 : H12AffineFastState.Bounded env30237 := by
  intro p hp
  have h : env30237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30236_30237 : H12AffineEnvironment.transform 13 5376 env30236 = env30237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env30236 == env30237) = true)

theorem identity30237 : scanCanonicalize (H12AffineFastState.compose env30237 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70862) := by decide +kernel

theorem selectedBound30237 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30238 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,70862,67619,1024,8660,4160,4194304,16,73736,8328,65,4196385,5392,4096,10281,1501,4194440,256,33,5457,74250]

theorem envBound30238 : H12AffineFastState.Bounded env30238 := by
  intro p hp
  have h : env30238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30237_30238 : H12AffineEnvironment.transform 16 70862 env30237 = env30238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70862 env30237 == env30238) = true)

theorem identity30238 : scanCanonicalize (H12AffineFastState.compose env30238 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound30238 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30239 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8203,13509,10280,1024,8660,4160,4194304,16,3,8328,65,4196385,5392,4096,10281,1501,4194440,256,33,5457,513]

theorem envBound30239 : H12AffineFastState.Bounded env30239 := by
  intro p hp
  have h : env30239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30238_30239 : H12AffineEnvironment.transform 15 8203 env30238 = env30239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env30238 == env30239) = true)

theorem identity30239 : scanCanonicalize (H12AffineFastState.compose env30239 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 248) := by decide +kernel

theorem selectedBound30239 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30240 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8203,13509,10280,1024,8660,4160,248,16,3,8328,65,2265,5392,4096,10281,1501,112,256,33,5457,513]

theorem envBound30240 : H12AffineFastState.Bounded env30240 := by
  intro p hp
  have h : env30240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30239_30240 : H12AffineEnvironment.transform 21 248 env30239 = env30240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 248 env30239 == env30240) = true)

theorem identity30240 : scanCanonicalize (H12AffineFastState.compose env30240 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound30240 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30241 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5376,0,478,5392,2557,1024,1,4160,248,16,3,349,65,2265,5392,4096,2556,1501,112,256,33,5457,513]

theorem envBound30241 : H12AffineFastState.Bounded env30241 := by
  intro p hp
  have h : env30241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30240_30241 : H12AffineEnvironment.transform 12 469 env30240 = env30241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env30240 == env30241) = true)

theorem identity30241 : scanCanonicalize (H12AffineFastState.compose env30241 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound30241 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env30242 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,343,5392,2420,1024,1,4160,113,16,3,349,65,2128,5392,4096,2421,1364,112,256,33,5457,513]

theorem envBound30242 : H12AffineFastState.Bounded env30242 := by
  intro p hp
  have h : env30242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30241_30242 : H12AffineEnvironment.transform 6 9 env30241 = env30242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30241 == env30242) = true)

theorem identity30242 : scanCanonicalize (H12AffineFastState.compose env30242 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1360) := by decide +kernel

theorem selectedBound30242 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env30243 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1360,348,80,0,343,64,2420,1024,1,1296,113,16,3,349,65,2128,64,1360,2421,1364,112,256,33,1,513]

theorem envBound30243 : H12AffineFastState.Bounded env30243 := by
  intro p hp
  have h : env30243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30242_30243 : H12AffineEnvironment.transform 11 1360 env30242 = env30243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1360 env30242 == env30243) = true)

theorem identity30243 : scanCanonicalize (H12AffineFastState.compose env30243 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 769) := by decide +kernel

theorem selectedBound30243 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env30244 : List Nat := [2,4,8,16,32,64,9,256,512,769,2048,593,348,80,0,343,64,2420,769,1,529,113,16,3,349,65,2128,64,593,2421,597,112,256,33,1,513]

theorem envBound30244 : H12AffineFastState.Bounded env30244 := by
  intro p hp
  have h : env30244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30243_30244 : H12AffineEnvironment.transform 9 769 env30243 = env30244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env30243 == env30244) = true)

theorem identity30244 : scanCanonicalize (H12AffineFastState.compose env30244 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound30244 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env30245 : List Nat := [2,4,8,16,32,64,9,256,512,769,1,593,348,80,0,343,64,373,769,1,529,113,16,3,349,65,81,64,593,372,597,112,256,33,1,513]

theorem envBound30245 : H12AffineFastState.Bounded env30245 := by
  intro p hp
  have h : env30245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30244_30245 : H12AffineEnvironment.transform 10 1 env30244 = env30245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env30244 == env30245) = true)

theorem identity30245 : scanCanonicalize (H12AffineFastState.compose env30245 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound30245 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env30246 : List Nat := [2,4,8,16,32,64,9,37,512,548,1,593,121,80,0,114,64,80,548,1,529,113,16,3,120,65,81,64,593,81,597,112,37,33,1,513]

theorem envBound30246 : H12AffineFastState.Bounded env30246 := by
  intro p hp
  have h : env30246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30245_30246 : H12AffineEnvironment.transform 7 37 env30245 = env30246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env30245 == env30246) = true)

theorem identity30246 : scanCanonicalize (H12AffineFastState.compose env30246 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound30246 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env30247 : List Nat := [2,4,8,1,32,64,9,37,512,548,1,576,104,65,0,99,64,65,548,1,512,96,1,3,105,65,64,64,576,64,580,97,37,33,1,513]

theorem envBound30247 : H12AffineFastState.Bounded env30247 := by
  intro p hp
  have h : env30247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30246_30247 : H12AffineEnvironment.transform 3 1 env30246 = env30247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env30246 == env30247) = true)

theorem identity30247 : scanCanonicalize (H12AffineFastState.compose env30247 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound30247 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env30248 : List Nat := [2,4,8,1,32,64,9,37,64,100,1,0,104,65,0,99,64,65,100,1,64,96,1,3,105,65,64,64,0,64,4,97,37,33,1,65]

theorem envBound30248 : H12AffineFastState.Bounded env30248 := by
  intro p hp
  have h : env30248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30247_30248 : H12AffineEnvironment.transform 8 64 env30247 = env30248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env30247 == env30248) = true)

theorem identity30248 : scanCanonicalize (H12AffineFastState.compose env30248 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound30248 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env30249 : List Nat := [2,4,8,1,32,33,9,37,33,5,1,0,9,32,0,2,33,32,5,1,33,1,1,3,8,32,33,33,0,33,4,0,37,33,1,32]

theorem envBound30249 : H12AffineFastState.Bounded env30249 := by
  intro p hp
  have h : env30249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30248_30249 : H12AffineEnvironment.transform 5 33 env30248 = env30249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env30248 == env30249) = true)

theorem identity30249 : scanCanonicalize (H12AffineFastState.compose env30249 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound30249 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30250 : List Nat := [2,4,8,1,1,0,9,4,0,5,1,0,9,1,0,2,0,1,5,1,0,1,1,3,8,1,0,0,0,0,4,0,4,0,1,1]

theorem envBound30250 : H12AffineFastState.Bounded env30250 := by
  intro p hp
  have h : env30250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30249_30250 : H12AffineEnvironment.transform 4 1 env30249 = env30250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env30249 == env30250) = true)

def env30251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,138477,1024,8661,4160,4194304,16,73737,8328,65,4196384,5392,4097,10281,1501,4194440,256,32,5456,74250]

theorem envBound30251 : H12AffineFastState.Bounded env30251 := by
  intro p hp
  have h : env30251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30236_30251 : H12AffineEnvironment.transform 13 5377 env30236 = env30251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env30236 == env30251) = true)

theorem identity30251 : scanCanonicalize (H12AffineFastState.compose env30251 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound30251 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30252 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,70726,67755,1024,8661,4160,4194304,16,73737,8328,65,4196384,5392,4097,10281,1501,4194440,256,32,5456,74250]

theorem envBound30252 : H12AffineFastState.Bounded env30252 := by
  intro p hp
  have h : env30252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30251_30252 : H12AffineEnvironment.transform 16 70726 env30251 = env30252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env30251 == env30252) = true)

theorem identity30252 : scanCanonicalize (H12AffineFastState.compose env30252 (packedSelected [0,1,3,4,7,8,9,11,15,18,19,20,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound30252 : packedSelected [0,1,3,4,7,8,9,11,15,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env30253 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,70726,67619,1024,8541,4160,4194304,16,73737,8192,65,4196384,5392,4097,10281,1365,4194304,256,32,5456,74250]

theorem envBound30253 : H12AffineFastState.Bounded env30253 := by
  intro p hp
  have h : env30253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30252_30253 : H12AffineEnvironment.transform 6 8 env30252 = env30253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30252 == env30253) = true)

theorem identity30253 : scanCanonicalize (H12AffineFastState.compose env30253 (packedSelected [3,4,5,9,10,11,14,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 73851) := by decide +kernel

theorem selectedBound30253 : packedSelected [3,4,5,9,10,11,14,20,23] rootPS < 2^1333 := by decide +kernel

def env30254 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,70726,67619,1024,8541,4160,73851,16,73737,8192,65,75867,5392,4097,10281,1365,73851,256,32,5456,74250]

theorem envBound30254 : H12AffineFastState.Bounded env30254 := by
  intro p hp
  have h : env30254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30253_30254 : H12AffineEnvironment.transform 21 73851 env30253 = env30254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73851 env30253 == env30254) = true)

theorem identity30254 : scanCanonicalize (H12AffineFastState.compose env30254 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound30254 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env30255 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8282,13340,10361,1024,8541,4160,33,16,83,8192,65,2049,5392,4097,10281,1365,33,256,32,5456,592]

theorem envBound30255 : H12AffineFastState.Bounded env30255 := by
  intro p hp
  have h : env30255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30254_30255 : H12AffineEnvironment.transform 15 8282 env30254 = env30255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env30254 == env30255) = true)

theorem identity30255 : scanCanonicalize (H12AffineFastState.compose env30255 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound30255 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env30256 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,5157,8312,8282,13340,10361,1024,8313,4160,33,16,83,8192,65,2049,5172,4097,10281,1137,33,36,32,5236,592]

theorem envBound30256 : H12AffineFastState.Bounded env30256 := by
  intro p hp
  have h : env30256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30255_30256 : H12AffineEnvironment.transform 7 36 env30255 = env30256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env30255 == env30256) = true)

theorem identity30256 : scanCanonicalize (H12AffineFastState.compose env30256 (packedSelected [1,2,3,4,5,6,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound30256 : packedSelected [1,2,3,4,5,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env30257 : List Nat := [2,4,8,16,32,64,8,36,512,52,2048,4096,8192,4113,8312,8282,12328,10361,52,8313,4160,33,16,83,8192,65,2049,4096,4097,10281,69,33,36,32,4160,592]

theorem envBound30257 : H12AffineFastState.Bounded env30257 := by
  intro p hp
  have h : env30257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30256_30257 : H12AffineEnvironment.transform 9 52 env30256 = env30257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env30256 == env30257) = true)

theorem identity30257 : scanCanonicalize (H12AffineFastState.compose env30257 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound30257 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env30258 : List Nat := [2,4,8,16,32,64,8,36,512,52,2048,4096,120,4113,0,34,4176,2049,52,1,4160,33,16,83,120,65,2049,4096,4097,2129,69,33,36,32,4160,592]

theorem envBound30258 : H12AffineFastState.Bounded env30258 := by
  intro p hp
  have h : env30258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30257_30258 : H12AffineEnvironment.transform 12 120 env30257 = env30258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env30257 == env30258) = true)

theorem identity30258 : scanCanonicalize (H12AffineFastState.compose env30258 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound30258 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30259 : List Nat := [2,4,8,16,32,64,8,36,512,52,0,4096,120,4113,0,34,4176,1,52,1,4160,33,16,83,120,65,1,4096,4097,81,69,33,36,32,4160,592]

theorem envBound30259 : H12AffineFastState.Bounded env30259 := by
  intro p hp
  have h : env30259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30258_30259 : H12AffineEnvironment.transform 10 0 env30258 = env30259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env30258 == env30259) = true)

theorem identity30259 : scanCanonicalize (H12AffineFastState.compose env30259 (packedSelected [2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound30259 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env30260 : List Nat := [2,4,8,1,32,64,8,36,512,37,0,4096,105,4096,0,34,4161,1,37,1,4160,33,1,66,105,65,1,4096,4097,64,69,33,36,32,4160,577]

theorem envBound30260 : H12AffineFastState.Bounded env30260 := by
  intro p hp
  have h : env30260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30259_30260 : H12AffineEnvironment.transform 3 1 env30259 = env30260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env30259 == env30260) = true)

theorem identity30260 : scanCanonicalize (H12AffineFastState.compose env30260 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound30260 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env30261 : List Nat := [2,4,8,1,32,64,8,36,512,37,0,65,105,65,0,34,0,1,37,1,1,33,1,66,105,65,1,65,64,64,69,33,36,32,1,577]

theorem envBound30261 : H12AffineFastState.Bounded env30261 := by
  intro p hp
  have h : env30261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30260_30261 : H12AffineEnvironment.transform 11 65 env30260 = env30261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env30260 == env30261) = true)

theorem identity30261 : scanCanonicalize (H12AffineFastState.compose env30261 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound30261 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30262 : List Nat := [2,4,8,1,32,1,8,36,512,37,0,0,40,0,0,34,0,1,37,1,1,33,1,3,40,0,1,0,1,1,4,33,36,32,1,512]

theorem envBound30262 : H12AffineFastState.Bounded env30262 := by
  intro p hp
  have h : env30262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30261_30262 : H12AffineEnvironment.transform 5 1 env30261 = env30262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env30261 == env30262) = true)

theorem identity30262 : scanCanonicalize (H12AffineFastState.compose env30262 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound30262 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30263 : List Nat := [2,4,8,1,4,1,8,0,512,1,0,0,12,0,0,6,0,1,1,1,1,5,1,3,12,0,1,0,1,1,4,5,0,4,1,512]

theorem envBound30263 : H12AffineFastState.Bounded env30263 := by
  intro p hp
  have h : env30263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30262_30263 : H12AffineEnvironment.transform 4 4 env30262 = env30263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env30262 == env30263) = true)

theorem identity30263 : scanCanonicalize (H12AffineFastState.compose env30263 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound30263 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30264 : List Nat := [2,4,8,1,4,1,8,0,13,1,0,0,12,0,0,6,0,1,1,1,1,5,1,3,12,0,1,0,1,1,4,5,0,4,1,13]

theorem envBound30264 : H12AffineFastState.Bounded env30264 := by
  intro p hp
  have h : env30264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30263_30264 : H12AffineEnvironment.transform 8 13 env30263 = env30264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env30263 == env30264) = true)

theorem identity30264 : scanCanonicalize (H12AffineFastState.compose env30264 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound30264 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30265 : List Nat := [2,0,8,1,0,1,8,0,9,1,0,0,8,0,0,2,0,1,1,1,1,1,1,3,8,0,1,0,1,1,0,1,0,0,1,9]

theorem envBound30265 : H12AffineFastState.Bounded env30265 := by
  intro p hp
  have h : env30265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30264_30265 : H12AffineEnvironment.transform 1 0 env30264 = env30265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env30264 == env30265) = true)

theorem identity30265 : scanCanonicalize (H12AffineFastState.compose env30265 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound30265 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30266 : List Nat := [2,0,2,1,0,1,2,0,3,1,0,0,2,0,0,2,0,1,1,1,1,1,1,3,2,0,1,0,1,1,0,1,0,0,1,3]

theorem envBound30266 : H12AffineFastState.Bounded env30266 := by
  intro p hp
  have h : env30266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30265_30266 : H12AffineEnvironment.transform 2 2 env30265 = env30266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env30265 == env30266) = true)

def env30267 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,4194304,17,98781,8328,65,4237813,5393,17664,10280,1500,4256860,256,21793,46212,74251]

theorem envBound30267 : H12AffineFastState.Bounded env30267 := by
  intro p hp
  have h : env30267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30234_30267 : H12AffineEnvironment.transform 20 4161 env30234 = env30267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env30234 == env30267) = true)

theorem identity30267 : scanCanonicalize (H12AffineFastState.compose env30267 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 144492) := by decide +kernel

theorem selectedBound30267 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30268 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,144492,17,98781,8328,65,171417,5393,17664,10280,1500,180272,256,21793,46212,74251]

theorem envBound30268 : H12AffineFastState.Bounded env30268 := by
  intro p hp
  have h : env30268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30267_30268 : H12AffineEnvironment.transform 21 144492 env30267 = env30268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144492 env30267 == env30268) = true)

def env30269 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,144492,17,98645,8192,65,171281,5393,17664,10280,1364,180272,256,21793,46092,74251]

theorem envBound30269 : H12AffineFastState.Bounded env30269 := by
  intro p hp
  have h : env30269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30268_30269 : H12AffineEnvironment.transform 6 8 env30268 = env30269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30268 == env30269) = true)

theorem identity30269 : scanCanonicalize (H12AffineFastState.compose env30269 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound30269 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30270 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190520,1024,32769,4161,144492,17,41311,8192,65,171281,5393,17664,10280,1364,180272,256,21793,46092,513]

theorem envBound30270 : H12AffineFastState.Bounded env30270 := by
  intro p hp
  have h : env30270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30269_30270 : H12AffineEnvironment.transform 15 8202 env30269 = env30270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env30269 == env30270) = true)

theorem identity30270 : scanCanonicalize (H12AffineFastState.compose env30270 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 49216) := by decide +kernel

theorem selectedBound30270 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env30271 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49216,10360,1024,32769,4161,62508,17,41311,8192,65,23889,5393,17664,10280,1364,112,256,21793,46092,513]

theorem envBound30271 : H12AffineFastState.Bounded env30271 := by
  intro p hp
  have h : env30271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30270_30271 : H12AffineEnvironment.transform 16 49216 env30270 = env30271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49216 env30270 == env30271) = true)

theorem identity30271 : scanCanonicalize (H12AffineFastState.compose env30271 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound30271 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env30272 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,81,8202,16401,10360,1024,80,4161,29821,17,8462,8192,65,23889,5393,17664,10280,1364,112,256,21793,13405,513]

theorem envBound30272 : H12AffineFastState.Bounded env30272 := by
  intro p hp
  have h : env30272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30271_30272 : H12AffineEnvironment.transform 14 81 env30271 = env30272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env30271 == env30272) = true)

theorem identity30272 : scanCanonicalize (H12AffineFastState.compose env30272 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound30272 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env30273 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,81,263,16401,2421,1024,80,4161,21872,17,3,269,65,23889,5393,17664,2341,1364,112,256,21793,5456,513]

theorem envBound30273 : H12AffineFastState.Bounded env30273 := by
  intro p hp
  have h : env30273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30272_30273 : H12AffineEnvironment.transform 12 269 env30272 = env30273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env30272 == env30273) = true)

theorem identity30273 : scanCanonicalize (H12AffineFastState.compose env30273 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound30273 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env30274 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5457,81,263,5440,2421,1024,80,4161,33,17,3,269,65,2048,5393,4177,2341,1364,112,256,112,5456,513]

theorem envBound30274 : H12AffineFastState.Bounded env30274 := by
  intro p hp
  have h : env30274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30273_30274 : H12AffineEnvironment.transform 13 5457 env30273 = env30274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env30273 == env30274) = true)

theorem identity30274 : scanCanonicalize (H12AffineFastState.compose env30274 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound30274 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env30275 : List Nat := [2,4,8,16,32,64,8,53,512,1024,2048,4096,56,5220,81,50,5237,2112,1024,80,4161,33,17,3,56,65,2048,5156,4177,2064,1121,112,53,112,5221,513]

theorem envBound30275 : H12AffineFastState.Bounded env30275 := by
  intro p hp
  have h : env30275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30274_30275 : H12AffineEnvironment.transform 7 53 env30274 = env30275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env30274 == env30275) = true)

theorem identity30275 : scanCanonicalize (H12AffineFastState.compose env30275 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 3173) := by decide +kernel

theorem selectedBound30275 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env30276 : List Nat := [2,4,8,16,32,64,8,53,512,1024,2048,3173,56,2049,81,50,2064,2112,1024,80,3108,33,17,3,56,65,2048,2113,3124,2064,1121,112,53,112,2048,513]

theorem envBound30276 : H12AffineFastState.Bounded env30276 := by
  intro p hp
  have h : env30276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30275_30276 : H12AffineEnvironment.transform 11 3173 env30275 = env30276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3173 env30275 == env30276) = true)

theorem identity30276 : scanCanonicalize (H12AffineFastState.compose env30276 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound30276 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env30277 : List Nat := [2,4,8,0,32,64,8,37,512,1024,2048,3173,40,2049,65,34,2048,2112,1024,64,3108,33,1,3,40,65,2048,2113,3108,2048,1121,96,37,96,2048,513]

theorem envBound30277 : H12AffineFastState.Bounded env30277 := by
  intro p hp
  have h : env30277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30276_30277 : H12AffineEnvironment.transform 3 0 env30276 = env30277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env30276 == env30277) = true)

theorem identity30277 : scanCanonicalize (H12AffineFastState.compose env30277 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound30277 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env30278 : List Nat := [2,4,8,0,32,64,8,37,512,1024,512,1637,40,513,65,34,512,576,1024,64,1572,33,1,3,40,65,512,577,1572,512,1121,96,37,96,512,513]

theorem envBound30278 : H12AffineFastState.Bounded env30278 := by
  intro p hp
  have h : env30278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30277_30278 : H12AffineEnvironment.transform 10 512 env30277 = env30278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env30277 == env30278) = true)

theorem identity30278 : scanCanonicalize (H12AffineFastState.compose env30278 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound30278 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30279 : List Nat := [2,4,8,0,32,64,8,37,512,101,512,512,40,513,65,34,512,576,101,64,577,33,1,3,40,65,512,577,577,512,4,96,37,96,512,513]

theorem envBound30279 : H12AffineFastState.Bounded env30279 := by
  intro p hp
  have h : env30279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30278_30279 : H12AffineEnvironment.transform 9 101 env30278 = env30279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env30278 == env30279) = true)

theorem identity30279 : scanCanonicalize (H12AffineFastState.compose env30279 (packedSelected [0,1,2] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound30279 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env30280 : List Nat := [2,4,8,0,32,11,8,37,512,46,512,512,40,513,10,34,512,523,46,11,522,33,1,3,40,10,512,522,522,512,4,43,37,43,512,513]

theorem envBound30280 : H12AffineFastState.Bounded env30280 := by
  intro p hp
  have h : env30280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30279_30280 : H12AffineEnvironment.transform 5 11 env30279 = env30280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env30279 == env30280) = true)

def env30281 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,144492,17,98644,8193,65,171280,5393,17664,10280,1365,180272,256,21793,46093,74251]

theorem envBound30281 : H12AffineFastState.Bounded env30281 := by
  intro p hp
  have h : env30281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30268_30281 : H12AffineEnvironment.transform 6 9 env30268 = env30281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30268 == env30281) = true)

theorem identity30281 : scanCanonicalize (H12AffineFastState.compose env30281 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound30281 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30282 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,131072,190520,1024,32769,4161,144492,17,3,8193,65,171280,5393,17664,10280,1365,180272,256,21793,46093,41820]

theorem envBound30282 : H12AffineFastState.Bounded env30282 := by
  intro p hp
  have h : env30282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30281_30282 : H12AffineEnvironment.transform 15 33111 env30281 = env30282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env30281 == env30282) = true)

theorem identity30282 : scanCanonicalize (H12AffineFastState.compose env30282 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46108) := by decide +kernel

theorem selectedBound30282 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env30283 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,46108,23588,1024,32769,4161,32880,17,3,8193,65,10508,5393,17664,10280,1365,29740,256,21793,46093,41820]

theorem envBound30283 : H12AffineFastState.Bounded env30283 := by
  intro p hp
  have h : env30283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30282_30283 : H12AffineEnvironment.transform 16 46108 env30282 = env30283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46108 env30282 == env30283) = true)

theorem identity30283 : scanCanonicalize (H12AffineFastState.compose env30283 (packedSelected [0,1,5,8,9,22,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound30283 : packedSelected [0,1,5,8,9,22,24,27] rootPS < 2^1333 := by decide +kernel

def env30284 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29963,16448,23588,1024,29789,4161,29740,17,3,8193,65,10508,5393,17664,10280,1365,29740,256,21793,16465,22272]

theorem envBound30284 : H12AffineFastState.Bounded env30284 := by
  intro p hp
  have h : env30284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30283_30284 : H12AffineEnvironment.transform 14 29788 env30283 = env30284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env30283 == env30284) = true)

theorem identity30284 : scanCanonicalize (H12AffineFastState.compose env30284 (packedSelected [0,2,7,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound30284 : packedSelected [0,2,7,14,20] rootPS < 2^1333 := by decide +kernel

def env30285 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,9,16384,21589,21762,16448,23588,1024,21588,4161,21541,17,3,8,65,2309,5393,17664,2081,1365,21541,256,21793,16465,22272]

theorem envBound30285 : H12AffineFastState.Bounded env30285 := by
  intro p hp
  have h : env30285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30284_30285 : H12AffineEnvironment.transform 12 9 env30284 = env30285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env30284 == env30285) = true)

theorem identity30285 : scanCanonicalize (H12AffineFastState.compose env30285 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound30285 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env30286 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,9,16384,21589,21623,16448,23588,1024,21588,4161,21541,17,3,8,65,2160,5220,17525,2081,1056,21541,117,21588,16465,22133]

theorem envBound30286 : H12AffineFastState.Bounded env30286 := by
  intro p hp
  have h : env30286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30285_30286 : H12AffineEnvironment.transform 7 117 env30285 = env30286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env30285 == env30286) = true)

theorem identity30286 : scanCanonicalize (H12AffineFastState.compose env30286 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound30286 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env30287 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,9,5157,112,82,5221,2049,1024,113,4161,0,17,3,8,65,2160,5220,4176,2081,1056,0,117,113,5236,592]

theorem envBound30287 : H12AffineFastState.Bounded env30287 := by
  intro p hp
  have h : env30287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30286_30287 : H12AffineEnvironment.transform 13 5157 env30286 = env30287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env30286 == env30287) = true)

theorem identity30287 : scanCanonicalize (H12AffineFastState.compose env30287 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound30287 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30288 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,4096,9,5124,81,82,5188,2049,1024,80,4161,0,17,3,8,65,2129,5189,4176,2048,1025,0,84,80,5205,592]

theorem envBound30288 : H12AffineFastState.Bounded env30288 := by
  intro p hp
  have h : env30288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30287_30288 : H12AffineEnvironment.transform 4 1 env30287 = env30288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env30287 == env30288) = true)

theorem identity30288 : scanCanonicalize (H12AffineFastState.compose env30288 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound30288 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30289 : List Nat := [2,4,8,16,1,64,9,84,512,68,2048,4096,9,4160,81,82,4096,2049,68,80,4161,0,17,3,8,65,2129,4097,4176,2048,69,0,84,80,4113,592]

theorem envBound30289 : H12AffineFastState.Bounded env30289 := by
  intro p hp
  have h : env30289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30288_30289 : H12AffineEnvironment.transform 9 68 env30288 = env30289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env30288 == env30289) = true)

theorem identity30289 : scanCanonicalize (H12AffineFastState.compose env30289 (packedSelected [0,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound30289 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env30290 : List Nat := [2,4,8,16,1,64,9,84,512,68,2048,2049,9,2113,81,82,2049,2049,68,80,2112,0,17,3,8,65,2129,2048,2129,2048,69,0,84,80,2064,592]

theorem envBound30290 : H12AffineFastState.Bounded env30290 := by
  intro p hp
  have h : env30290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30289_30290 : H12AffineEnvironment.transform 11 2049 env30289 = env30290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env30289 == env30290) = true)

def env30291 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,2097152,4194304,2101329,98780,8328,65,6338997,2098513,17665,2111593,2102685,6349852,256,21793,46212,2175562]

theorem envBound30291 : H12AffineFastState.Bounded env30291 := by
  intro p hp
  have h : env30291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30233_30291 : H12AffineEnvironment.transform 17 190521 env30233 = env30291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190521 env30233 == env30291) = true)

def env30292 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,4194304,17,98780,8328,65,4237813,5393,17665,10281,1501,4256860,256,21793,46212,74250]

theorem envBound30292 : H12AffineFastState.Bounded env30292 := by
  intro p hp
  have h : env30292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30291_30292 : H12AffineEnvironment.transform 20 4160 env30291 = env30292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env30291 == env30292) = true)

theorem identity30292 : scanCanonicalize (H12AffineFastState.compose env30292 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 180408) := by decide +kernel

theorem selectedBound30292 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30293 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,180408,17,98780,8328,65,158029,5393,17665,10281,1501,144612,256,21793,46212,74250]

theorem envBound30293 : H12AffineFastState.Bounded env30293 := by
  intro p hp
  have h : env30293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30292_30293 : H12AffineEnvironment.transform 21 180408 env30292 = env30293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180408 env30292 == env30293) = true)

theorem identity30293 : scanCanonicalize (H12AffineFastState.compose env30293 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound30293 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env30294 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190521,1024,32769,4160,180408,17,41431,8328,65,158029,5393,17665,10281,1501,144612,256,21793,46212,513]

theorem envBound30294 : H12AffineFastState.Bounded env30294 := by
  intro p hp
  have h : env30294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30293_30294 : H12AffineEnvironment.transform 15 8203 env30293 = env30294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env30293 == env30294) = true)

theorem identity30294 : scanCanonicalize (H12AffineFastState.compose env30294 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound30294 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env30295 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,43049,1024,32769,4160,32936,17,41431,8328,65,10589,5393,17665,10281,1501,29940,256,21793,46212,513]

theorem envBound30295 : H12AffineFastState.Bounded env30295 := by
  intro p hp
  have h : env30295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30294_30295 : H12AffineEnvironment.transform 16 16400 env30294 = env30295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env30294 == env30295) = true)

theorem identity30295 : scanCanonicalize (H12AffineFastState.compose env30295 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound30295 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env30296 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29708,8203,16400,23589,1024,29709,4160,29860,17,21979,8328,65,10589,5393,17665,10281,1501,29940,256,21793,16520,513]

theorem envBound30296 : H12AffineFastState.Bounded env30296 := by
  intro p hp
  have h : env30296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30295_30296 : H12AffineEnvironment.transform 14 29708 env30295 = env30296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env30295 == env30296) = true)

theorem identity30296 : scanCanonicalize (H12AffineFastState.compose env30296 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound30296 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env30297 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13325,1,8203,13341,10280,1024,0,4160,169,17,8662,8328,65,10589,5393,12556,10281,1501,249,256,8492,13445,513]

theorem envBound30297 : H12AffineFastState.Bounded env30297 := by
  intro p hp
  have h : env30297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30296_30297 : H12AffineEnvironment.transform 13 13325 env30296 = env30297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env30296 == env30297) = true)

theorem identity30297 : scanCanonicalize (H12AffineFastState.compose env30297 (packedSelected [0,5,6,8,9,10,11,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound30297 : packedSelected [0,5,6,8,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env30298 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3188,8192,10361,1,8203,10345,10280,1024,0,3124,169,17,8662,8328,65,10589,2405,11640,10281,1501,249,256,8492,10481,513]

theorem envBound30298 : H12AffineFastState.Bounded env30298 := by
  intro p hp
  have h : env30298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30297_30298 : H12AffineEnvironment.transform 11 3188 env30297 = env30298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env30297 == env30298) = true)

theorem identity30298 : scanCanonicalize (H12AffineFastState.compose env30298 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound30298 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env30299 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,3188,8192,10361,1,8203,10345,10280,1024,0,3124,112,17,8463,8273,65,10589,2405,11640,10281,1284,32,256,8492,10280,513]

theorem envBound30299 : H12AffineFastState.Bounded env30299 := by
  intro p hp
  have h : env30299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30298_30299 : H12AffineEnvironment.transform 6 89 env30298 = env30299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env30298 == env30299) = true)

theorem identity30299 : scanCanonicalize (H12AffineFastState.compose env30299 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound30299 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env30300 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,3188,1336,3393,1,1331,3409,3344,1024,0,3124,112,17,1079,1385,65,3173,2405,2112,3345,1284,32,256,1044,3344,513]

theorem envBound30300 : H12AffineFastState.Bounded env30300 := by
  intro p hp
  have h : env30300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30299_30300 : H12AffineEnvironment.transform 12 1336 env30299 = env30300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env30299 == env30300) = true)

theorem identity30300 : scanCanonicalize (H12AffineFastState.compose env30300 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30300 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30301 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3108,1336,3345,1,1331,3329,3344,1024,0,3124,32,17,1079,1337,17,3125,2357,2064,3345,1284,32,256,1044,3344,513]

theorem envBound30301 : H12AffineFastState.Bounded env30301 := by
  intro p hp
  have h : env30301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30300_30301 : H12AffineEnvironment.transform 5 16 env30300 = env30301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30300 == env30301) = true)

theorem identity30301 : scanCanonicalize (H12AffineFastState.compose env30301 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound30301 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30302 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,2065,269,2340,1,262,2356,2341,53,0,2049,32,17,2,268,17,2048,2357,2064,2340,305,32,256,33,2341,513]

theorem envBound30302 : H12AffineFastState.Bounded env30302 := by
  intro p hp
  have h : env30302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30301_30302 : H12AffineEnvironment.transform 9 53 env30301 = env30302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env30301 == env30302) = true)

theorem identity30302 : scanCanonicalize (H12AffineFastState.compose env30302 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound30302 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30303 : List Nat := [2,4,8,16,32,16,9,256,512,53,293,308,269,1,1,262,17,0,53,0,292,32,17,2,268,17,293,16,309,1,305,32,256,33,0,513]

theorem envBound30303 : H12AffineFastState.Bounded env30303 := by
  intro p hp
  have h : env30303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30302_30303 : H12AffineEnvironment.transform 10 293 env30302 = env30303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env30302 == env30303) = true)

def env30304 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,4194304,16,98780,8328,65,4237812,5392,17665,10280,1500,4256861,256,21793,46212,74251]

theorem envBound30304 : H12AffineFastState.Bounded env30304 := by
  intro p hp
  have h : env30304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30291_30304 : H12AffineEnvironment.transform 20 4161 env30291 = env30304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env30291 == env30304) = true)

def env30305 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,4194304,16,98644,8192,65,4237692,5392,17665,10280,1364,4256861,256,21793,46092,74251]

theorem envBound30305 : H12AffineFastState.Bounded env30305 := by
  intro p hp
  have h : env30305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30304_30305 : H12AffineEnvironment.transform 6 8 env30304 = env30305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30304 == env30305) = true)

theorem identity30305 : scanCanonicalize (H12AffineFastState.compose env30305 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound30305 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30306 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,67618,1024,32769,4161,4194304,16,98644,8192,65,4237692,5392,17665,10280,1364,4256861,256,21793,46092,74251]

theorem envBound30306 : H12AffineFastState.Bounded env30306 := by
  intro p hp
  have h : env30306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30305_30306 : H12AffineEnvironment.transform 16 122907 env30305 = env30306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env30305 == env30306) = true)

theorem identity30306 : scanCanonicalize (H12AffineFastState.compose env30306 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 32801) := by decide +kernel

theorem selectedBound30306 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env30307 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,67618,1024,32769,4161,32801,16,98644,8192,65,10589,5392,17665,10280,1364,29820,256,21793,46092,74251]

theorem envBound30307 : H12AffineFastState.Bounded env30307 := by
  intro p hp
  have h : env30307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30306_30307 : H12AffineEnvironment.transform 21 32801 env30306 = env30307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32801 env30306 == env30307) = true)

theorem identity30307 : scanCanonicalize (H12AffineFastState.compose env30307 (packedSelected [3,10,19,24] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound30307 : packedSelected [3,10,19,24] rootPS < 2^1333 := by decide +kernel

def env30308 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,13388,56437,1024,32769,4161,32801,16,21763,8192,65,10589,5392,17665,10280,1364,29820,256,21793,46092,63068]

theorem envBound30308 : H12AffineFastState.Bounded env30308 := by
  intro p hp
  have h : env30308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30307_30308 : H12AffineEnvironment.transform 15 54359 env30307 = env30308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env30307 == env30308) = true)

theorem identity30308 : scanCanonicalize (H12AffineFastState.compose env30308 (packedSelected [2,3,5,6,14,15,16,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound30308 : packedSelected [2,3,5,6,14,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env30309 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,54359,5392,56437,1024,32769,4161,32801,16,21763,348,65,2049,5392,17665,2420,1364,21792,256,21793,38224,55040]

theorem envBound30309 : H12AffineFastState.Bounded env30309 := by
  intro p hp
  have h : env30309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30308_30309 : H12AffineEnvironment.transform 12 348 env30308 = env30309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env30308 == env30309) = true)

theorem identity30309 : scanCanonicalize (H12AffineFastState.compose env30309 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound30309 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env30310 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,80,21511,5392,23589,1024,81,4161,113,16,21763,348,65,2049,5392,17665,2420,1364,21792,256,21793,5376,22352]

theorem envBound30310 : H12AffineFastState.Bounded env30310 := by
  intro p hp
  have h : env30310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30309_30310 : H12AffineEnvironment.transform 14 80 env30309 = env30310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env30309 == env30310) = true)

theorem identity30310 : scanCanonicalize (H12AffineFastState.compose env30310 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound30310 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env30311 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5457,80,342,5392,2420,1024,81,4161,113,16,82,348,65,2049,5392,4176,2420,1364,113,256,112,5376,513]

theorem envBound30311 : H12AffineFastState.Bounded env30311 := by
  intro p hp
  have h : env30311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30310_30311 : H12AffineEnvironment.transform 13 5457 env30310 = env30311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env30310 == env30311) = true)

theorem identity30311 : scanCanonicalize (H12AffineFastState.compose env30311 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 97) := by decide +kernel

theorem selectedBound30311 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env30312 : List Nat := [2,4,8,16,32,64,8,256,512,1024,97,4096,348,5457,80,342,5392,277,1024,81,4161,113,16,82,348,65,96,5392,4176,277,1364,113,256,112,5376,513]

theorem envBound30312 : H12AffineFastState.Bounded env30312 := by
  intro p hp
  have h : env30312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30311_30312 : H12AffineEnvironment.transform 10 97 env30311 = env30312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 97 env30311 == env30312) = true)

theorem identity30312 : scanCanonicalize (H12AffineFastState.compose env30312 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30312 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30313 : List Nat := [2,4,8,16,32,16,8,256,512,1024,49,4096,268,5377,0,262,5392,277,1024,1,4113,33,16,2,268,17,48,5392,4096,277,1284,33,256,32,5376,513]

theorem envBound30313 : H12AffineFastState.Bounded env30313 := by
  intro p hp
  have h : env30313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30312_30313 : H12AffineEnvironment.transform 5 16 env30312 = env30313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30312 == env30313) = true)

theorem identity30313 : scanCanonicalize (H12AffineFastState.compose env30313 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound30313 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30314 : List Nat := [2,4,8,16,32,16,8,256,512,1024,49,277,268,1044,0,262,1029,277,1024,1,260,33,16,2,268,17,48,1029,277,277,1284,33,256,32,1045,513]

theorem envBound30314 : H12AffineFastState.Bounded env30314 := by
  intro p hp
  have h : env30314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30313_30314 : H12AffineEnvironment.transform 11 277 env30313 = env30314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env30313 == env30314) = true)

theorem identity30314 : scanCanonicalize (H12AffineFastState.compose env30314 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound30314 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30315 : List Nat := [2,4,8,16,32,16,8,256,512,305,49,277,268,293,0,262,308,277,305,1,260,33,16,2,268,17,48,308,277,277,53,33,256,32,292,513]

theorem envBound30315 : H12AffineFastState.Bounded env30315 := by
  intro p hp
  have h : env30315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30314_30315 : H12AffineEnvironment.transform 9 305 env30314 = env30315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env30314 == env30315) = true)

theorem identity30315 : scanCanonicalize (H12AffineFastState.compose env30315 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound30315 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30316 : List Nat := [2,4,8,16,32,16,8,256,292,305,49,277,268,293,0,262,308,277,305,1,260,33,16,2,268,17,48,308,277,277,53,33,256,32,292,293]

theorem envBound30316 : H12AffineFastState.Bounded env30316 := by
  intro p hp
  have h : env30316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30315_30316 : H12AffineEnvironment.transform 8 292 env30315 = env30316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env30315 == env30316) = true)

theorem identity30316 : scanCanonicalize (H12AffineFastState.compose env30316 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound30316 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env30317 : List Nat := [2,4,8,16,16,16,8,256,276,257,1,277,268,277,0,262,260,277,257,1,260,17,16,2,268,17,0,260,277,277,5,17,256,16,276,277]

theorem envBound30317 : H12AffineFastState.Bounded env30317 := by
  intro p hp
  have h : env30317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30316_30317 : H12AffineEnvironment.transform 4 16 env30316 = env30317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env30316 == env30317) = true)

def env30318 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,4194304,16,98645,8193,65,4237693,5392,17665,10280,1365,4256861,256,21793,46093,74251]

theorem envBound30318 : H12AffineFastState.Bounded env30318 := by
  intro p hp
  have h : env30318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30304_30318 : H12AffineEnvironment.transform 6 9 env30304 = env30318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30304 == env30318) = true)

theorem identity30318 : scanCanonicalize (H12AffineFastState.compose env30318 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound30318 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30319 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,108926,1024,32769,4161,4194304,16,98645,8193,65,4237693,5392,17665,10280,1365,4256861,256,21793,46093,74251]

theorem envBound30319 : H12AffineFastState.Bounded env30319 := by
  intro p hp
  have h : env30319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30318_30319 : H12AffineEnvironment.transform 16 82247 env30318 = env30319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env30318 == env30319) = true)

theorem identity30319 : scanCanonicalize (H12AffineFastState.compose env30319 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 21873) := by decide +kernel

theorem selectedBound30319 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env30320 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,108926,1024,32769,4161,21873,16,98645,8193,65,64524,5392,17665,10280,1365,41260,256,21793,46093,74251]

theorem envBound30320 : H12AffineFastState.Bounded env30320 := by
  intro p hp
  have h : env30320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30319_30320 : H12AffineEnvironment.transform 21 21873 env30319 = env30320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21873 env30319 == env30320) = true)

theorem identity30320 : scanCanonicalize (H12AffineFastState.compose env30320 (packedSelected [1,4,8,9,12,14,15,16,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound30320 : packedSelected [1,4,8,9,12,14,15,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env30321 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,292,65536,82247,75866,1024,293,4161,21873,16,65649,8193,65,32040,5392,17665,10280,1365,8200,256,21793,13609,74251]

theorem envBound30321 : H12AffineFastState.Bounded env30321 := by
  intro p hp
  have h : env30321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30320_30321 : H12AffineEnvironment.transform 14 292 env30320 = env30321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env30320 == env30321) = true)

theorem identity30321 : scanCanonicalize (H12AffineFastState.compose env30321 (packedSelected [1,5,7,10,12,14,15,20,24,27,28] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound30321 : packedSelected [1,5,7,10,12,14,15,20,24,27,28] rootPS < 2^1333 := by decide +kernel

def env30322 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,292,65536,82247,67618,1024,293,4161,21873,16,65649,121,65,23888,5392,17665,2128,1365,112,256,21793,5457,66163]

theorem envBound30322 : H12AffineFastState.Bounded env30322 := by
  intro p hp
  have h : env30322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30321_30322 : H12AffineEnvironment.transform 12 120 env30321 = env30322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env30321 == env30322) = true)

theorem identity30322 : scanCanonicalize (H12AffineFastState.compose env30322 (packedSelected [1,8,12,15,19] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound30322 : packedSelected [1,8,12,15,19] rootPS < 2^1333 := by decide +kernel

def env30323 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,292,343,16400,2421,1024,293,4161,21873,16,294,121,65,23888,5392,17665,2128,1365,112,256,21793,5457,804]

theorem envBound30323 : H12AffineFastState.Bounded env30323 := by
  intro p hp
  have h : env30323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30322_30323 : H12AffineEnvironment.transform 15 343 env30322 = env30323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env30322 == env30323) = true)

theorem identity30323 : scanCanonicalize (H12AffineFastState.compose env30323 (packedSelected [0,1,7,8,10,11,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 3393) := by decide +kernel

theorem selectedBound30323 : packedSelected [0,1,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env30324 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,3393,292,343,3409,2421,1024,293,4161,6192,16,294,121,65,4113,5392,2112,2128,1365,112,256,6240,5457,804]

theorem envBound30324 : H12AffineFastState.Bounded env30324 := by
  intro p hp
  have h : env30324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30323_30324 : H12AffineEnvironment.transform 13 3393 env30323 = env30324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3393 env30323 == env30324) = true)

theorem identity30324 : scanCanonicalize (H12AffineFastState.compose env30324 (packedSelected [1,3,4,5,8,9,12,14,16] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound30324 : packedSelected [1,3,4,5,8,9,12,14,16] rootPS < 2^1333 := by decide +kernel

def env30325 : List Nat := [2,4,8,16,32,64,9,256,512,1024,293,4096,120,1124,292,343,1140,80,1024,293,4161,4373,16,294,121,65,4113,5392,357,373,1365,112,256,4421,5457,804]

theorem envBound30325 : H12AffineFastState.Bounded env30325 := by
  intro p hp
  have h : env30325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30324_30325 : H12AffineEnvironment.transform 10 293 env30324 = env30325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env30324 == env30325) = true)

theorem identity30325 : scanCanonicalize (H12AffineFastState.compose env30325 (packedSelected [1,2,3,4,5,6,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound30325 : packedSelected [1,2,3,4,5,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env30326 : List Nat := [2,4,8,16,32,64,9,256,512,1024,293,1280,120,1124,292,343,1140,80,1024,293,1345,1045,16,294,121,65,1297,16,357,373,1365,112,256,1093,81,804]

theorem envBound30326 : H12AffineFastState.Bounded env30326 := by
  intro p hp
  have h : env30326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30325_30326 : H12AffineEnvironment.transform 11 1280 env30325 = env30326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env30325 == env30326) = true)

def env30327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2553961,485861,8328,65,6705549,2551144,437561,2111592,2102684,6687781,256,21792,46213,2175563]

theorem envBound30327 : H12AffineFastState.Bounded env30327 := by
  intro p hp
  have h : env30327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30232_30327 : H12AffineEnvironment.transform 22 2553961 env30232 = env30327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2553961 env30232 == env30327) = true)

def env30328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,2097152,4194304,2101329,98781,8328,65,6338997,2098512,17665,2111592,2102684,6349853,256,21792,46213,2175563]

theorem envBound30328 : H12AffineFastState.Bounded env30328 := by
  intro p hp
  have h : env30328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30327_30328 : H12AffineEnvironment.transform 17 190520 env30327 = env30328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190520 env30327 == env30328) = true)

def env30329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,4194304,17,98781,8328,65,4237813,5392,17665,10280,1500,4256861,256,21792,46213,74251]

theorem envBound30329 : H12AffineFastState.Bounded env30329 := by
  intro p hp
  have h : env30329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30328_30329 : H12AffineEnvironment.transform 20 4160 env30328 = env30329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env30328 == env30329) = true)

theorem identity30329 : scanCanonicalize (H12AffineFastState.compose env30329 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 201831) := by decide +kernel

theorem selectedBound30329 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30330 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,201831,17,98781,8328,65,245138,5392,17665,10280,1500,254010,256,21792,46213,74251]

theorem envBound30330 : H12AffineFastState.Bounded env30330 := by
  intro p hp
  have h : env30330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30329_30330 : H12AffineEnvironment.transform 21 201831 env30329 = env30330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 201831 env30329 == env30330) = true)

def env30331 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,201831,17,98645,8192,65,245018,5392,17665,10280,1364,254010,256,21792,46093,74251]

theorem envBound30331 : H12AffineFastState.Bounded env30331 := by
  intro p hp
  have h : env30331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30330_30331 : H12AffineEnvironment.transform 6 8 env30330 = env30331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30330 == env30331) = true)

theorem identity30331 : scanCanonicalize (H12AffineFastState.compose env30331 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound30331 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30332 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190520,1024,32769,4160,144493,17,41311,8192,65,171280,5392,17665,10280,1364,180272,256,21792,46093,513]

theorem envBound30332 : H12AffineFastState.Bounded env30332 := by
  intro p hp
  have h : env30332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30331_30332 : H12AffineEnvironment.transform 15 8202 env30331 = env30332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env30331 == env30332) = true)

theorem identity30332 : scanCanonicalize (H12AffineFastState.compose env30332 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 49216) := by decide +kernel

theorem selectedBound30332 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env30333 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49216,10360,1024,32769,4160,62509,17,41311,8192,65,23888,5392,17665,10280,1364,112,256,21792,46093,513]

theorem envBound30333 : H12AffineFastState.Bounded env30333 := by
  intro p hp
  have h : env30333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30332_30333 : H12AffineEnvironment.transform 16 49216 env30332 = env30333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49216 env30332 == env30333) = true)

theorem identity30333 : scanCanonicalize (H12AffineFastState.compose env30333 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound30333 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env30334 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,81,8202,16401,10360,1024,80,4160,29820,17,8462,8192,65,23888,5392,17665,10280,1364,112,256,21792,13404,513]

theorem envBound30334 : H12AffineFastState.Bounded env30334 := by
  intro p hp
  have h : env30334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30333_30334 : H12AffineEnvironment.transform 14 81 env30333 = env30334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env30333 == env30334) = true)

theorem identity30334 : scanCanonicalize (H12AffineFastState.compose env30334 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound30334 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env30335 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,81,263,16401,2421,1024,80,4160,21873,17,3,269,65,23888,5392,17665,2341,1364,112,256,21792,5457,513]

theorem envBound30335 : H12AffineFastState.Bounded env30335 := by
  intro p hp
  have h : env30335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30334_30335 : H12AffineEnvironment.transform 12 269 env30334 = env30335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env30334 == env30335) = true)

theorem identity30335 : scanCanonicalize (H12AffineFastState.compose env30335 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound30335 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env30336 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,81,263,5393,2421,1024,80,4160,113,17,3,269,65,2128,5392,4097,2341,1364,112,256,32,5457,513]

theorem envBound30336 : H12AffineFastState.Bounded env30336 := by
  intro p hp
  have h : env30336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30335_30336 : H12AffineEnvironment.transform 13 5376 env30335 = env30336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env30335 == env30336) = true)

theorem identity30336 : scanCanonicalize (H12AffineFastState.compose env30336 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound30336 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env30337 : List Nat := [2,4,8,16,32,64,8,256,512,516,2048,4096,269,4868,81,263,4885,2421,516,80,4160,113,17,3,269,65,2128,4884,4097,2341,848,112,256,32,4949,513]

theorem envBound30337 : H12AffineFastState.Bounded env30337 := by
  intro p hp
  have h : env30337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30336_30337 : H12AffineEnvironment.transform 9 516 env30336 = env30337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env30336 == env30337) = true)

theorem identity30337 : scanCanonicalize (H12AffineFastState.compose env30337 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 625) := by decide +kernel

theorem selectedBound30337 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env30338 : List Nat := [2,4,8,16,32,64,8,256,512,516,2048,625,269,373,81,263,356,2421,516,80,561,113,17,3,269,65,2128,357,624,2341,848,112,256,32,292,513]

theorem envBound30338 : H12AffineFastState.Bounded env30338 := by
  intro p hp
  have h : env30338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30337_30338 : H12AffineEnvironment.transform 11 625 env30337 = env30338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 625 env30337 == env30338) = true)

theorem identity30338 : scanCanonicalize (H12AffineFastState.compose env30338 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 341) := by decide +kernel

theorem selectedBound30338 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env30339 : List Nat := [2,4,8,16,32,64,8,256,512,516,341,625,269,373,81,263,356,32,516,80,561,113,17,3,269,65,261,357,624,112,848,112,256,32,292,513]

theorem envBound30339 : H12AffineFastState.Bounded env30339 := by
  intro p hp
  have h : env30339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30338_30339 : H12AffineEnvironment.transform 10 341 env30338 = env30339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 341 env30338 == env30339) = true)

theorem identity30339 : scanCanonicalize (H12AffineFastState.compose env30339 (packedSelected [0,1,2,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound30339 : packedSelected [0,1,2,5,9] rootPS < 2^1333 := by decide +kernel

def env30340 : List Nat := [2,4,8,16,32,64,8,85,512,516,0,625,88,32,81,82,49,32,516,80,561,113,17,3,88,65,80,48,624,112,517,112,85,32,113,513]

theorem envBound30340 : H12AffineFastState.Bounded env30340 := by
  intro p hp
  have h : env30340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30339_30340 : H12AffineEnvironment.transform 7 85 env30339 = env30340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env30339 == env30340) = true)

theorem identity30340 : scanCanonicalize (H12AffineFastState.compose env30340 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound30340 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30341 : List Nat := [2,4,8,16,32,0,8,21,512,516,0,561,24,32,17,18,49,32,516,16,561,49,17,3,24,1,16,48,560,48,517,48,21,32,49,513]

theorem envBound30341 : H12AffineFastState.Bounded env30341 := by
  intro p hp
  have h : env30341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30340_30341 : H12AffineEnvironment.transform 5 0 env30340 = env30341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env30340 == env30341) = true)

theorem identity30341 : scanCanonicalize (H12AffineFastState.compose env30341 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound30341 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env30342 : List Nat := [2,4,8,16,32,0,8,21,32,36,0,17,24,32,17,18,49,32,36,16,17,49,17,3,24,1,16,48,16,48,37,48,21,32,49,33]

theorem envBound30342 : H12AffineFastState.Bounded env30342 := by
  intro p hp
  have h : env30342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30341_30342 : H12AffineEnvironment.transform 8 32 env30341 = env30342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env30341 == env30342) = true)

def env30343 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,201831,17,98644,8193,65,245019,5392,17665,10280,1365,254010,256,21792,46092,74251]

theorem envBound30343 : H12AffineFastState.Bounded env30343 := by
  intro p hp
  have h : env30343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30330_30343 : H12AffineEnvironment.transform 6 9 env30330 = env30343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30330 == env30343) = true)

theorem identity30343 : scanCanonicalize (H12AffineFastState.compose env30343 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound30343 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30344 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,131072,190520,1024,32769,4160,169264,17,3,8193,65,146508,5392,17665,10280,1365,156013,256,21792,46092,41820]

theorem envBound30344 : H12AffineFastState.Bounded env30344 := by
  intro p hp
  have h : env30344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30343_30344 : H12AffineEnvironment.transform 15 33111 env30343 = env30344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env30343 == env30344) = true)

theorem identity30344 : scanCanonicalize (H12AffineFastState.compose env30344 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46109) := by decide +kernel

theorem selectedBound30344 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env30345 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,46109,23589,1024,32769,4160,8493,17,3,8193,65,34897,5392,17665,10280,1365,54640,256,21792,46092,41820]

theorem envBound30345 : H12AffineFastState.Bounded env30345 := by
  intro p hp
  have h : env30345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30344_30345 : H12AffineEnvironment.transform 16 46109 env30344 = env30345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46109 env30344 == env30345) = true)

theorem identity30345 : scanCanonicalize (H12AffineFastState.compose env30345 (packedSelected [0,3,5,7,9,10,12,14,15,18,20,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound30345 : packedSelected [0,3,5,7,9,10,12,14,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env30346 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13609,32768,33111,46109,10508,1024,32769,4160,8493,17,3,8193,65,34897,5392,12328,10280,1365,41049,256,8201,46092,41820]

theorem envBound30346 : H12AffineFastState.Bounded env30346 := by
  intro p hp
  have h : env30346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30345_30346 : H12AffineEnvironment.transform 13 13609 env30345 = env30346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env30345 == env30346) = true)

theorem identity30346 : scanCanonicalize (H12AffineFastState.compose env30346 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound30346 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env30347 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5457,32768,33111,37989,2420,1024,32769,4160,341,17,3,121,65,34897,5392,4176,2128,1365,32801,256,113,38004,33572]

theorem envBound30347 : H12AffineFastState.Bounded env30347 := by
  intro p hp
  have h : env30347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30346_30347 : H12AffineEnvironment.transform 12 120 env30346 = env30347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env30346 == env30347) = true)

theorem identity30347 : scanCanonicalize (H12AffineFastState.compose env30347 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound30347 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env30348 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5457,373,34,5392,2420,1024,372,4160,341,17,3,121,65,2340,5392,4176,2128,1365,340,256,113,5377,593]

theorem envBound30348 : H12AffineFastState.Bounded env30348 := by
  intro p hp
  have h : env30348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30347_30348 : H12AffineEnvironment.transform 14 373 env30347 = env30348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env30347 == env30348) = true)

theorem identity30348 : scanCanonicalize (H12AffineFastState.compose env30348 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound30348 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env30349 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,120,5157,1,34,5220,2048,1024,0,4160,33,17,3,121,65,2128,5220,4176,2128,1057,32,116,113,5237,593]

theorem envBound30349 : H12AffineFastState.Bounded env30349 := by
  intro p hp
  have h : env30349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30348_30349 : H12AffineEnvironment.transform 7 116 env30348 = env30349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env30348 == env30349) = true)

theorem identity30349 : scanCanonicalize (H12AffineFastState.compose env30349 (packedSelected [4,7] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound30349 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env30350 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,80,120,1141,1,34,1076,2048,1024,0,16,33,17,3,121,65,2128,1076,0,2128,1057,32,116,113,1061,593]

theorem envBound30350 : H12AffineFastState.Bounded env30350 := by
  intro p hp
  have h : env30350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30349_30350 : H12AffineEnvironment.transform 11 80 env30349 = env30350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env30349 == env30350) = true)

theorem identity30350 : scanCanonicalize (H12AffineFastState.compose env30350 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound30350 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env30351 : List Nat := [2,4,8,16,32,64,9,116,512,52,2048,80,120,65,1,34,0,2048,52,0,16,33,17,3,121,65,2128,0,0,2128,21,32,116,113,17,593]

theorem envBound30351 : H12AffineFastState.Bounded env30351 := by
  intro p hp
  have h : env30351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30350_30351 : H12AffineEnvironment.transform 9 52 env30350 = env30351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env30350 == env30351) = true)

theorem identity30351 : scanCanonicalize (H12AffineFastState.compose env30351 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30351 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30352 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,0,40,17,1,34,0,2048,52,0,16,33,17,3,41,17,2048,0,0,2048,21,32,36,33,17,513]

theorem envBound30352 : H12AffineFastState.Bounded env30352 := by
  intro p hp
  have h : env30352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30351_30352 : H12AffineEnvironment.transform 5 16 env30351 = env30352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30351 == env30352) = true)

theorem identity30352 : scanCanonicalize (H12AffineFastState.compose env30352 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound30352 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30353 : List Nat := [2,4,8,16,32,16,9,36,512,52,529,0,40,17,1,34,0,529,52,0,16,33,17,3,41,17,529,0,0,529,21,32,36,33,17,513]

theorem envBound30353 : H12AffineFastState.Bounded env30353 := by
  intro p hp
  have h : env30353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30352_30353 : H12AffineEnvironment.transform 10 529 env30352 = env30353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env30352 == env30353) = true)

theorem identity30353 : scanCanonicalize (H12AffineFastState.compose env30353 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound30353 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30354 : List Nat := [2,4,8,16,32,16,9,36,59,52,42,0,40,17,1,34,0,42,52,0,16,33,17,3,41,17,42,0,0,42,21,32,36,33,17,58]

theorem envBound30354 : H12AffineFastState.Bounded env30354 := by
  intro p hp
  have h : env30354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30353_30354 : H12AffineEnvironment.transform 8 59 env30353 = env30354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env30353 == env30354) = true)

theorem identity30354 : scanCanonicalize (H12AffineFastState.compose env30354 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound30354 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30355 : List Nat := [2,4,8,0,32,0,9,36,43,36,42,0,40,1,1,34,0,42,36,0,0,33,1,3,41,1,42,0,0,42,5,32,36,33,1,42]

theorem envBound30355 : H12AffineFastState.Bounded env30355 := by
  intro p hp
  have h : env30355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30354_30355 : H12AffineEnvironment.transform 3 0 env30354 = env30355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env30354 == env30355) = true)

theorem identity30355 : scanCanonicalize (H12AffineFastState.compose env30355 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound30355 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30356 : List Nat := [2,4,8,0,11,0,9,15,0,15,1,0,3,1,1,9,0,1,15,0,0,10,1,3,2,1,1,0,0,1,5,11,15,10,1,1]

theorem envBound30356 : H12AffineFastState.Bounded env30356 := by
  intro p hp
  have h : env30356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30355_30356 : H12AffineEnvironment.transform 4 11 env30355 = env30356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env30355 == env30356) = true)

def env30357 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,4194304,16,98781,8328,65,4237812,5393,17665,10281,1501,4256860,256,21792,46213,74250]

theorem envBound30357 : H12AffineFastState.Bounded env30357 := by
  intro p hp
  have h : env30357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30328_30357 : H12AffineEnvironment.transform 20 4161 env30328 = env30357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env30328 == env30357) = true)

theorem identity30357 : scanCanonicalize (H12AffineFastState.compose env30357 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound30357 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,190520,1024,32769,4161,4194304,16,21762,8328,65,4237812,5393,17665,10281,1501,4256860,256,21792,46213,63189]

theorem envBound30358 : H12AffineFastState.Bounded env30358 := by
  intro p hp
  have h : env30358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30357_30358 : H12AffineEnvironment.transform 15 54495 env30357 = env30358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env30357 == env30358) = true)

def env30359 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,190520,1024,32769,4161,4194304,16,21762,8192,65,4237692,5393,17665,10281,1365,4256860,256,21792,46093,63069]

theorem envBound30359 : H12AffineFastState.Bounded env30359 := by
  intro p hp
  have h : env30359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30358_30359 : H12AffineEnvironment.transform 6 8 env30358 = env30359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30358 == env30359) = true)

theorem identity30359 : scanCanonicalize (H12AffineFastState.compose env30359 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound30359 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30360 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,13388,56436,1024,32769,4161,4194304,16,21762,8192,65,4237692,5393,17665,10281,1365,4256860,256,21792,46093,63069]

theorem envBound30360 : H12AffineFastState.Bounded env30360 := by
  intro p hp
  have h : env30360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30359_30360 : H12AffineEnvironment.transform 16 13388 env30359 = env30360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env30359 == env30360) = true)

theorem identity30360 : scanCanonicalize (H12AffineFastState.compose env30360 (packedSelected [16,20] rootPS)) = affineNative (2^(21+1) ^^^ 54560) := by decide +kernel

theorem selectedBound30360 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env30361 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,13388,56436,1024,32769,4161,54560,16,21762,8192,65,31836,5393,17665,10281,1365,8572,256,21792,46093,63069]

theorem envBound30361 : H12AffineFastState.Bounded env30361 := by
  intro p hp
  have h : env30361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30360_30361 : H12AffineEnvironment.transform 21 54560 env30360 = env30361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 54560 env30360 == env30361) = true)

theorem identity30361 : scanCanonicalize (H12AffineFastState.compose env30361 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound30361 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env30362 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,13388,10280,1024,29789,4161,8572,16,21762,8192,65,31836,5393,17665,10281,1365,8572,256,21792,16465,513]

theorem envBound30362 : H12AffineFastState.Bounded env30362 := by
  intro p hp
  have h : env30362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30361_30362 : H12AffineEnvironment.transform 14 29788 env30361 = env30362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env30361 == env30362) = true)

theorem identity30362 : scanCanonicalize (H12AffineFastState.compose env30362 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound30362 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30363 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,81,8203,13388,10280,1024,80,4161,8572,16,8463,8192,65,2129,5393,12556,10281,1365,8572,256,8493,13404,513]

theorem envBound30363 : H12AffineFastState.Bounded env30363 := by
  intro p hp
  have h : env30363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30362_30363 : H12AffineEnvironment.transform 13 13325 env30362 = env30363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env30362 == env30363) = true)

def env30364 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,190520,1024,32769,4161,4194304,16,21762,8193,65,4237693,5393,17665,10281,1364,4256860,256,21792,46092,63068]

theorem envBound30364 : H12AffineFastState.Bounded env30364 := by
  intro p hp
  have h : env30364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30358_30364 : H12AffineEnvironment.transform 6 9 env30358 = env30364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30358 == env30364) = true)

theorem identity30364 : scanCanonicalize (H12AffineFastState.compose env30364 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound30364 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30365 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38161,32041,1024,32769,4161,4194304,16,21762,8193,65,4237693,5393,17665,10281,1364,4256860,256,21792,46092,63068]

theorem envBound30365 : H12AffineFastState.Bounded env30365 := by
  intro p hp
  have h : env30365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30364_30365 : H12AffineEnvironment.transform 16 38161 env30364 = env30365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env30364 == env30365) = true)

theorem identity30365 : scanCanonicalize (H12AffineFastState.compose env30365 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 29821) := by decide +kernel

theorem selectedBound30365 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env30366 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38161,32041,1024,32769,4161,29821,16,21762,8193,65,56576,5393,17665,10281,1364,32801,256,21792,46092,63068]

theorem envBound30366 : H12AffineFastState.Bounded env30366 := by
  intro p hp
  have h : env30366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30365_30366 : H12AffineEnvironment.transform 21 29821 env30365 = env30366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29821 env30365 == env30366) = true)

theorem identity30366 : scanCanonicalize (H12AffineFastState.compose env30366 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound30366 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env30367 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,54358,38161,23669,1024,32769,4161,21793,16,21762,349,65,56576,5393,17665,2421,1364,32801,256,21792,38224,55040]

theorem envBound30367 : H12AffineFastState.Bounded env30367 := by
  intro p hp
  have h : env30367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30366_30367 : H12AffineEnvironment.transform 12 348 env30366 = env30367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env30366 == env30367) = true)

theorem identity30367 : scanCanonicalize (H12AffineFastState.compose env30367 (packedSelected [3,4,5,6,9,10,11,12,15,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound30367 : packedSelected [3,4,5,6,9,10,11,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env30368 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,81,21511,5440,23669,1024,80,4161,21793,16,21762,349,65,23889,5393,17665,2421,1364,112,256,21792,5377,22353]

theorem envBound30368 : H12AffineFastState.Bounded env30368 := by
  intro p hp
  have h : env30368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30367_30368 : H12AffineEnvironment.transform 14 81 env30367 = env30368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env30367 == env30368) = true)

theorem identity30368 : scanCanonicalize (H12AffineFastState.compose env30368 (packedSelected [0,4,6,7,9,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 3188) := by decide +kernel

theorem selectedBound30368 : packedSelected [0,4,6,7,9,12,14] rootPS < 2^1333 := by decide +kernel

def env30369 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,3188,81,6259,5440,4097,1024,80,4161,6485,16,6518,349,65,4389,5393,2421,2421,1364,112,256,6484,5377,6949]

theorem envBound30369 : H12AffineFastState.Bounded env30369 := by
  intro p hp
  have h : env30369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30368_30369 : H12AffineEnvironment.transform 13 3188 env30368 = env30369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3188 env30368 == env30369) = true)

theorem identity30369 : scanCanonicalize (H12AffineFastState.compose env30369 (packedSelected [3,4,5,6,9] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound30369 : packedSelected [3,4,5,6,9] rootPS < 2^1333 := by decide +kernel

def env30370 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3328,348,3188,81,1395,2112,3329,1024,80,3393,1109,16,1142,349,65,3109,2065,2421,2421,1364,112,256,1108,2049,1573]

theorem envBound30370 : H12AffineFastState.Bounded env30370 := by
  intro p hp
  have h : env30370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30369_30370 : H12AffineEnvironment.transform 11 3328 env30369 = env30370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env30369 == env30370) = true)

theorem identity30370 : scanCanonicalize (H12AffineFastState.compose env30370 (packedSelected [0,7,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound30370 : packedSelected [0,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env30371 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,3108,120,3188,81,1111,2112,3109,1024,80,3173,1109,16,1142,121,65,3109,2065,2129,2129,1136,112,36,1108,2049,1573]

theorem envBound30371 : H12AffineFastState.Bounded env30371 := by
  intro p hp
  have h : env30371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30370_30371 : H12AffineEnvironment.transform 7 36 env30370 = env30371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env30370 == env30371) = true)

theorem identity30371 : scanCanonicalize (H12AffineFastState.compose env30371 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound30371 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env30372 : List Nat := [2,4,8,16,32,64,9,36,512,37,2048,2049,120,2129,81,114,2112,2048,37,80,2112,112,16,83,121,65,2048,2065,2129,2129,85,112,36,113,2049,512]

theorem envBound30372 : H12AffineFastState.Bounded env30372 := by
  intro p hp
  have h : env30372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30371_30372 : H12AffineEnvironment.transform 9 37 env30371 = env30372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env30371 == env30372) = true)

theorem identity30372 : scanCanonicalize (H12AffineFastState.compose env30372 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound30372 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30373 : List Nat := [2,4,8,16,32,1,9,36,512,37,2048,2049,57,2064,16,51,2049,2048,37,17,2049,49,16,18,56,0,2048,2065,2064,2064,20,49,36,48,2049,512]

theorem envBound30373 : H12AffineFastState.Bounded env30373 := by
  intro p hp
  have h : env30373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30372_30373 : H12AffineEnvironment.transform 5 1 env30372 = env30373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env30372 == env30373) = true)

theorem identity30373 : scanCanonicalize (H12AffineFastState.compose env30373 (packedSelected [0,1,3] rootPS)) = affineNative (2^(10+1) ^^^ 526) := by decide +kernel

theorem selectedBound30373 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env30374 : List Nat := [2,4,8,16,32,1,9,36,512,37,526,527,57,542,16,51,527,526,37,17,527,49,16,18,56,0,526,543,542,542,20,49,36,48,527,512]

theorem envBound30374 : H12AffineFastState.Bounded env30374 := by
  intro p hp
  have h : env30374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30373_30374 : H12AffineEnvironment.transform 10 526 env30373 = env30374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 526 env30373 == env30374) = true)

theorem identity30374 : scanCanonicalize (H12AffineFastState.compose env30374 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound30374 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30375 : List Nat := [2,4,8,15,32,1,9,36,512,37,526,527,38,513,15,44,527,526,37,14,527,46,15,13,39,0,526,512,513,513,11,46,36,47,527,512]

theorem envBound30375 : H12AffineFastState.Bounded env30375 := by
  intro p hp
  have h : env30375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30374_30375 : H12AffineEnvironment.transform 3 15 env30374 = env30375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env30374 == env30375) = true)

theorem identity30375 : scanCanonicalize (H12AffineFastState.compose env30375 (packedSelected [1,5] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound30375 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env30376 : List Nat := [2,1,8,10,32,1,9,33,512,32,523,522,35,513,10,41,522,523,32,11,522,43,10,8,34,0,523,512,513,513,11,43,33,42,522,512]

theorem envBound30376 : H12AffineFastState.Bounded env30376 := by
  intro p hp
  have h : env30376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30375_30376 : H12AffineEnvironment.transform 1 1 env30375 = env30376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env30375 == env30376) = true)

theorem identity30376 : scanCanonicalize (H12AffineFastState.compose env30376 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30376 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30377 : List Nat := [2,1,8,10,0,1,9,1,512,0,523,522,3,513,10,9,522,523,0,11,522,11,10,8,2,0,523,512,513,513,11,11,1,10,522,512]

theorem envBound30377 : H12AffineFastState.Bounded env30377 := by
  intro p hp
  have h : env30377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30376_30377 : H12AffineEnvironment.transform 4 0 env30376 = env30377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30376 == env30377) = true)

theorem identity30377 : scanCanonicalize (H12AffineFastState.compose env30377 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound30377 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30378 : List Nat := [2,1,8,10,0,1,9,1,8,0,3,2,3,9,10,9,2,3,0,11,2,11,10,8,2,0,3,8,9,9,11,11,1,10,2,8]

theorem envBound30378 : H12AffineFastState.Bounded env30378 := by
  intro p hp
  have h : env30378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30377_30378 : H12AffineEnvironment.transform 8 8 env30377 = env30378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env30377 == env30378) = true)

theorem identity30378 : scanCanonicalize (H12AffineFastState.compose env30378 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30378 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env30379 : List Nat := [2,1,3,1,0,1,2,1,3,0,3,2,3,2,1,2,2,3,0,0,2,0,1,3,2,0,3,3,2,2,0,0,1,1,2,3]

theorem envBound30379 : H12AffineFastState.Bounded env30379 := by
  intro p hp
  have h : env30379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30378_30379 : H12AffineEnvironment.transform 2 3 env30378 = env30379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30378 == env30379) = true)

def env30380 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,2097152,4194304,2101328,98780,8328,65,6338996,2098513,17664,2111592,2102684,6349852,256,21792,46213,2175563]

theorem envBound30380 : H12AffineFastState.Bounded env30380 := by
  intro p hp
  have h : env30380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30327_30380 : H12AffineEnvironment.transform 17 190521 env30327 = env30380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190521 env30327 == env30380) = true)

def env30381 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,4194304,16,98780,8328,65,4237812,5393,17664,10280,1500,4256860,256,21792,46213,74251]

theorem envBound30381 : H12AffineFastState.Bounded env30381 := by
  intro p hp
  have h : env30381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30380_30381 : H12AffineEnvironment.transform 20 4160 env30380 = env30381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env30380 == env30381) = true)

theorem identity30381 : scanCanonicalize (H12AffineFastState.compose env30381 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound30381 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190521,1024,32769,4160,4194304,16,41430,8328,65,4237812,5393,17664,10280,1500,4256860,256,21792,46213,513]

theorem envBound30382 : H12AffineFastState.Bounded env30382 := by
  intro p hp
  have h : env30382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30381_30382 : H12AffineEnvironment.transform 15 8202 env30381 = env30382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env30381 == env30382) = true)

theorem identity30382 : scanCanonicalize (H12AffineFastState.compose env30382 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 32937) := by decide +kernel

theorem selectedBound30382 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env30383 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190521,1024,32769,4160,32937,16,41430,8328,65,10589,5393,17664,10280,1500,29941,256,21792,46213,513]

theorem envBound30383 : H12AffineFastState.Bounded env30383 := by
  intro p hp
  have h : env30383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30382_30383 : H12AffineEnvironment.transform 21 32937 env30382 = env30383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32937 env30382 == env30383) = true)

theorem identity30383 : scanCanonicalize (H12AffineFastState.compose env30383 (packedSelected [3,4,9,10,11,14,18,20,23,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound30383 : packedSelected [3,4,9,10,11,14,18,20,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env30384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8202,131072,149861,1024,8541,4160,8693,16,138,8328,65,10589,5393,17664,10280,1500,29941,256,21792,5593,513]

theorem envBound30384 : H12AffineFastState.Bounded env30384 := by
  intro p hp
  have h : env30384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30383_30384 : H12AffineEnvironment.transform 14 8540 env30383 = env30384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env30383 == env30384) = true)

theorem identity30384 : scanCanonicalize (H12AffineFastState.compose env30384 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound30384 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8202,24909,10280,1024,8541,4160,8693,16,138,8328,65,10589,5393,17664,10280,1500,29941,256,21792,5593,513]

theorem envBound30385 : H12AffineFastState.Bounded env30385 := by
  intro p hp
  have h : env30385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30384_30385 : H12AffineEnvironment.transform 16 24909 env30384 = env30385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env30384 == env30385) = true)

theorem identity30385 : scanCanonicalize (H12AffineFastState.compose env30385 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound30385 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env30386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,0,342,16401,2420,1024,1,4160,169,16,138,468,65,2049,5393,17664,2420,1500,21929,256,21792,5593,513]

theorem envBound30386 : H12AffineFastState.Bounded env30386 := by
  intro p hp
  have h : env30386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30385_30386 : H12AffineEnvironment.transform 12 348 env30385 = env30386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env30385 == env30386) = true)

theorem identity30386 : scanCanonicalize (H12AffineFastState.compose env30386 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(13+1) ^^^ 6297) := by decide +kernel

theorem selectedBound30386 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env30387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,6297,0,342,6280,2420,1024,1,4160,169,16,138,468,65,2049,5393,7577,2420,1500,3376,256,3513,5593,513]

theorem envBound30387 : H12AffineFastState.Bounded env30387 := by
  intro p hp
  have h : env30387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30386_30387 : H12AffineEnvironment.transform 13 6297 env30386 = env30387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6297 env30386 == env30387) = true)

theorem identity30387 : scanCanonicalize (H12AffineFastState.compose env30387 (packedSelected [2,4,9,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound30387 : packedSelected [2,4,9,12,15] rootPS < 2^1333 := by decide +kernel

def env30388 : List Nat := [2,4,8,16,32,64,120,256,512,1024,2048,4096,348,6241,0,342,6256,2420,1024,1,4160,81,16,114,300,65,2049,5393,7521,2420,1316,3376,256,3393,5409,513]

theorem envBound30388 : H12AffineFastState.Bounded env30388 := by
  intro p hp
  have h : env30388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30387_30388 : H12AffineEnvironment.transform 6 120 env30387 = env30388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env30387 == env30388) = true)

theorem identity30388 : scanCanonicalize (H12AffineFastState.compose env30388 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound30388 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env30389 : List Nat := [2,4,8,16,32,48,8,256,512,1024,2048,4096,300,6161,0,294,6144,2308,1024,1,4144,33,16,2,300,49,2049,5393,7441,2308,1316,3376,256,3377,5409,513]

theorem envBound30389 : H12AffineFastState.Bounded env30389 := by
  intro p hp
  have h : env30389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30388_30389 : H12AffineEnvironment.transform 5 48 env30388 = env30389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env30388 == env30389) = true)

theorem identity30389 : scanCanonicalize (H12AffineFastState.compose env30389 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 1313) := by decide +kernel

theorem selectedBound30389 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env30390 : List Nat := [2,4,8,16,32,48,8,256,512,1024,1313,4096,300,5424,0,294,5409,1061,1024,1,4144,33,16,2,300,49,1312,5393,4144,1061,1316,17,256,16,5409,513]

theorem envBound30390 : H12AffineFastState.Bounded env30390 := by
  intro p hp
  have h : env30390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30389_30390 : H12AffineEnvironment.transform 10 1313 env30389 = env30390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1313 env30389 == env30390) = true)

theorem identity30390 : scanCanonicalize (H12AffineFastState.compose env30390 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound30390 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30391 : List Nat := [2,4,8,16,16,0,8,256,512,1024,1297,4096,284,5376,0,278,5393,1045,1024,1,4096,17,16,2,284,1,1296,5393,4096,1045,1300,17,256,16,5393,513]

theorem envBound30391 : H12AffineFastState.Bounded env30391 := by
  intro p hp
  have h : env30391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30390_30391 : H12AffineEnvironment.transform 4 16 env30390 = env30391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env30390 == env30391) = true)

theorem identity30391 : scanCanonicalize (H12AffineFastState.compose env30391 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound30391 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30392 : List Nat := [2,4,8,16,16,0,8,256,512,1024,1297,1045,284,277,0,278,260,1045,1024,1,1045,17,16,2,284,1,1296,260,1045,1045,1300,17,256,16,260,513]

theorem envBound30392 : H12AffineFastState.Bounded env30392 := by
  intro p hp
  have h : env30392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30391_30392 : H12AffineEnvironment.transform 11 1045 env30391 = env30392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env30391 == env30392) = true)

theorem identity30392 : scanCanonicalize (H12AffineFastState.compose env30392 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound30392 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env30393 : List Nat := [2,4,8,16,16,0,8,256,260,1024,1297,1045,284,277,0,278,260,1045,1024,1,1045,17,16,2,284,1,1296,260,1045,1045,1300,17,256,16,260,261]

theorem envBound30393 : H12AffineFastState.Bounded env30393 := by
  intro p hp
  have h : env30393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30392_30393 : H12AffineEnvironment.transform 8 260 env30392 = env30393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env30392 == env30393) = true)

theorem identity30393 : scanCanonicalize (H12AffineFastState.compose env30393 (packedSelected [2,4,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound30393 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env30394 : List Nat := [2,4,8,0,0,0,8,256,260,1024,1281,1029,268,261,0,262,260,1029,1024,1,1029,1,0,2,268,1,1280,260,1029,1029,1284,1,256,0,260,261]

theorem envBound30394 : H12AffineFastState.Bounded env30394 := by
  intro p hp
  have h : env30394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30393_30394 : H12AffineEnvironment.transform 3 0 env30393 = env30394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env30393 == env30394) = true)

theorem identity30394 : scanCanonicalize (H12AffineFastState.compose env30394 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound30394 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30395 : List Nat := [2,4,8,0,0,0,8,256,260,257,0,260,268,261,0,262,260,260,257,1,260,1,0,2,268,1,1,260,260,260,5,1,256,0,260,261]

theorem envBound30395 : H12AffineFastState.Bounded env30395 := by
  intro p hp
  have h : env30395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30394_30395 : H12AffineEnvironment.transform 9 257 env30394 = env30395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env30394 == env30395) = true)

theorem identity30395 : scanCanonicalize (H12AffineFastState.compose env30395 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound30395 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30396 : List Nat := [2,4,8,0,0,0,8,5,1,4,0,1,9,0,0,3,1,1,4,1,1,1,0,2,9,1,1,1,1,1,5,1,5,0,1,0]

theorem envBound30396 : H12AffineFastState.Bounded env30396 := by
  intro p hp
  have h : env30396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30395_30396 : H12AffineEnvironment.transform 7 5 env30395 = env30396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env30395 == env30396) = true)

def env30397 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,4194304,17,98780,8328,65,4237813,5392,17664,10281,1501,4256861,256,21792,46213,74250]

theorem envBound30397 : H12AffineFastState.Bounded env30397 := by
  intro p hp
  have h : env30397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30380_30397 : H12AffineEnvironment.transform 20 4161 env30380 = env30397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env30380 == env30397) = true)

theorem identity30397 : scanCanonicalize (H12AffineFastState.compose env30397 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 254131) := by decide +kernel

theorem selectedBound30397 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30398 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,254131,17,98780,8328,65,215366,5392,17664,10281,1501,201966,256,21792,46213,74250]

theorem envBound30398 : H12AffineFastState.Bounded env30398 := by
  intro p hp
  have h : env30398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30397_30398 : H12AffineEnvironment.transform 21 254131 env30397 = env30398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 254131 env30397 == env30398) = true)

theorem identity30398 : scanCanonicalize (H12AffineFastState.compose env30398 (packedSelected [3,10,11,12,15,16,17,18,20,23,24,26,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound30398 : packedSelected [3,10,11,12,15,16,17,18,20,23,24,26,32,38,41] rootPS < 2^1333 := by decide +kernel

def env30399 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90138,100387,1024,32769,4161,32937,17,98780,8328,65,10588,5392,17664,10281,1501,29940,256,21792,46213,74250]

theorem envBound30399 : H12AffineFastState.Bounded env30399 := by
  intro p hp
  have h : env30399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30398_30399 : H12AffineEnvironment.transform 16 90138 env30398 = env30399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env30398 == env30399) = true)

theorem identity30399 : scanCanonicalize (H12AffineFastState.compose env30399 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound30399 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env30400 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90138,97526,1024,29908,4161,29820,17,95497,8328,65,10588,5392,17664,10281,1501,29940,256,21792,16464,74250]

theorem envBound30400 : H12AffineFastState.Bounded env30400 := by
  intro p hp
  have h : env30400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30399_30400 : H12AffineEnvironment.transform 14 29909 env30399 = env30400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env30399 == env30400) = true)

theorem identity30400 : scanCanonicalize (H12AffineFastState.compose env30400 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound30400 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env30401 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8203,16401,23805,1024,29908,4161,29820,17,21762,8328,65,10588,5392,17664,10281,1501,29940,256,21792,16464,513]

theorem envBound30401 : H12AffineFastState.Bounded env30401 := by
  intro p hp
  have h : env30401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30400_30401 : H12AffineEnvironment.transform 15 8203 env30400 = env30401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env30400 == env30401) = true)

def env30402 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830976,25265168,23160256,257,27378861,27337993,25207750]

theorem envBound30402 : H12AffineFastState.Bounded env30402 := by
  intro p hp
  have h : env30402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30230_30402 : H12AffineEnvironment.transform 18 1025 env30230 = env30402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env30230 == env30402) = true)

theorem identity30402 : scanCanonicalize (H12AffineFastState.compose env30402 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 297317) := by decide +kernel

theorem selectedBound30402 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env30403 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,297317,16777216,8328,65,21186917,18973836,2415669,149861,17108341,23160256,257,19221960,19246188,17050275]

theorem envBound30403 : H12AffineFastState.Bounded env30403 := by
  intro p hp
  have h : env30403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30402_30403 : H12AffineEnvironment.transform 22 297317 env30402 = env30403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 297317 env30402 == env30403) = true)

def env30404 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,182628,1025,32769,2097152,4194304,147457,16777216,8328,65,21186917,18973836,2233681,149861,17024017,23160256,257,19104940,19096840,16966599]

theorem envBound30404 : H12AffineFastState.Bounded env30404 := by
  intro p hp
  have h : env30404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30403_30404 : H12AffineEnvironment.transform 17 182628 env30403 = env30404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182628 env30403 == env30404) = true)

def env30405 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,35324,1025,32769,2097152,4194304,153,16777216,8328,65,21039613,18973836,2119113,2557,16876681,23160256,257,18990132,18949520,16819039]

theorem envBound30405 : H12AffineFastState.Bounded env30405 := by
  intro p hp
  have h : env30405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30404_30405 : H12AffineEnvironment.transform 16 16536 env30404 = env30405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env30404 == env30405) = true)

theorem identity30405 : scanCanonicalize (H12AffineFastState.compose env30405 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 138) := by decide +kernel

theorem selectedBound30405 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env30406 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,35324,1025,32769,2097152,4194304,153,138,8328,65,4262263,2196486,2119113,2557,99331,6382922,257,2213054,2172186,41941]

theorem envBound30406 : H12AffineFastState.Bounded env30406 := by
  intro p hp
  have h : env30406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30405_30406 : H12AffineEnvironment.transform 23 138 env30405 = env30406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 138 env30405 == env30406) = true)

def env30407 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,2097152,4194304,17,2,8192,65,4262263,2196486,2118977,2421,99331,6382922,257,2212918,2172186,41821]

theorem envBound30407 : H12AffineFastState.Bounded env30407 := by
  intro p hp
  have h : env30407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30406_30407 : H12AffineEnvironment.transform 6 8 env30406 = env30407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30406 == env30407) = true)

def env30408 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,4194304,16,3,8193,65,4262263,2196486,2118976,2420,99331,6382922,257,2212919,2172186,41820]

theorem envBound30408 : H12AffineFastState.Bounded env30408 := by
  intro p hp
  have h : env30408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30406_30408 : H12AffineEnvironment.transform 6 9 env30406 = env30408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30406 == env30408) = true)

theorem identity30408 : scanCanonicalize (H12AffineFastState.compose env30408 (packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound30408 : packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env30409 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10280,1025,8540,2097152,4194304,16,3,8193,65,4262263,2172251,2118976,2420,75102,6382922,257,2188650,2172186,513]

theorem envBound30409 : H12AffineFastState.Bounded env30409 := by
  intro p hp
  have h : env30409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30408_30409 : H12AffineEnvironment.transform 14 8541 env30408 = env30409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env30408 == env30409) = true)

theorem identity30409 : scanCanonicalize (H12AffineFastState.compose env30409 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound30409 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env30410 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,16401,10280,1025,8540,2097152,4194304,16,3,8193,65,4204925,2098513,2118976,2420,1364,6309184,257,2114912,2098448,513]

theorem envBound30410 : H12AffineFastState.Bounded env30410 := by
  intro p hp
  have h : env30410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30409_30410 : H12AffineEnvironment.transform 15 8202 env30409 = env30410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env30409 == env30410) = true)

theorem identity30410 : scanCanonicalize (H12AffineFastState.compose env30410 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound30410 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30411 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,16401,10280,1025,8540,2097152,32,16,3,8193,65,10589,2098513,2118976,2420,1364,2114912,257,2114912,2098448,513]

theorem envBound30411 : H12AffineFastState.Bounded env30411 := by
  intro p hp
  have h : env30411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30410_30411 : H12AffineEnvironment.transform 21 32 env30410 = env30411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env30410 == env30411) = true)

theorem identity30411 : scanCanonicalize (H12AffineFastState.compose env30411 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(20+1) ^^^ 25880) := by decide +kernel

theorem selectedBound30411 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env30412 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,16401,10280,1025,8540,25880,32,16,3,8193,65,10589,24649,12376,2420,1364,8312,257,8312,24584,513]

theorem envBound30412 : H12AffineFastState.Bounded env30412 := by
  intro p hp
  have h : env30412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30411_30412 : H12AffineEnvironment.transform 20 25880 env30411 = env30412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25880 env30411 == env30412) = true)

theorem identity30412 : scanCanonicalize (H12AffineFastState.compose env30412 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound30412 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env30413 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1,342,16401,2420,1025,0,17476,32,16,3,349,65,2049,16661,4356,2420,1364,292,257,292,16724,513]

theorem envBound30413 : H12AffineFastState.Bounded env30413 := by
  intro p hp
  have h : env30413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30412_30413 : H12AffineEnvironment.transform 12 348 env30412 = env30413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env30412 == env30413) = true)

theorem identity30413 : scanCanonicalize (H12AffineFastState.compose env30413 (packedSelected [2,14] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound30413 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env30414 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,4096,89,16384,1,83,16401,2161,1025,0,17476,32,16,3,88,65,2049,16400,4097,2161,1105,33,4,33,16465,513]

theorem envBound30414 : H12AffineFastState.Bounded env30414 := by
  intro p hp
  have h : env30414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30413_30414 : H12AffineEnvironment.transform 7 5 env30413 = env30414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env30413 == env30414) = true)

theorem identity30414 : scanCanonicalize (H12AffineFastState.compose env30414 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 577) := by decide +kernel

theorem selectedBound30414 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30415 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,577,89,16384,1,83,16401,2161,1025,0,17476,32,16,3,88,65,2049,16400,576,2161,1105,33,4,33,16465,513]

theorem envBound30415 : H12AffineFastState.Bounded env30415 := by
  intro p hp
  have h : env30415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30414_30415 : H12AffineEnvironment.transform 11 577 env30414 = env30415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 577 env30414 == env30415) = true)

theorem identity30415 : scanCanonicalize (H12AffineFastState.compose env30415 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 2113) := by decide +kernel

theorem selectedBound30415 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env30416 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,577,89,2113,1,83,2128,2161,1025,0,3077,32,16,3,88,65,2049,2129,576,2161,1105,33,4,33,2064,513]

theorem envBound30416 : H12AffineFastState.Bounded env30416 := by
  intro p hp
  have h : env30416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30415_30416 : H12AffineEnvironment.transform 13 2113 env30415 = env30416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2113 env30415 == env30416) = true)

def env30417 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16537,35325,1025,32769,2097152,4194304,152,16777216,8328,65,21039612,18973836,2119112,2556,16876680,23160256,257,18990133,18949521,16819038]

theorem envBound30417 : H12AffineFastState.Bounded env30417 := by
  intro p hp
  have h : env30417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30404_30417 : H12AffineEnvironment.transform 16 16537 env30404 = env30417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env30404 == env30417) = true)

theorem identity30417 : scanCanonicalize (H12AffineFastState.compose env30417 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 41311) := by decide +kernel

theorem selectedBound30417 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env30418 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16537,35325,1025,32769,2097152,4194304,152,41311,8328,65,4303011,2172371,2119112,2556,75223,6407327,257,2188650,2196686,513]

theorem envBound30418 : H12AffineFastState.Bounded env30418 := by
  intro p hp
  have h : env30418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30417_30418 : H12AffineEnvironment.transform 23 41311 env30417 = env30418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41311 env30417 == env30418) = true)

theorem identity30418 : scanCanonicalize (H12AffineFastState.compose env30418 (packedSelected [1,3,5,8,10,12,15,17,19,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 91586) := by decide +kernel

theorem selectedBound30418 : packedSelected [1,3,5,8,10,12,15,17,19,38,41] rootPS < 2^1333 := by decide +kernel

def env30419 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16537,35325,1025,32769,91586,4194304,152,41311,8328,65,4303011,16401,77834,2556,75223,4235613,257,168,57612,513]

theorem envBound30419 : H12AffineFastState.Bounded env30419 := by
  intro p hp
  have h : env30419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30418_30419 : H12AffineEnvironment.transform 20 91586 env30418 = env30419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91586 env30418 == env30419) = true)

def env30420 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,91466,4194304,16,41311,8192,65,4302891,16401,77834,2420,75103,4235613,257,32,57612,513]

theorem envBound30420 : H12AffineFastState.Bounded env30420 := by
  intro p hp
  have h : env30420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30419_30420 : H12AffineEnvironment.transform 6 8 env30419 = env30420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30419 == env30420) = true)

theorem identity30420 : scanCanonicalize (H12AffineFastState.compose env30420 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound30420 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env30421 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,35189,1025,32769,17728,4194304,16,41311,8192,65,4229153,16401,4096,2420,1365,4235613,257,32,57612,513]

theorem envBound30421 : H12AffineFastState.Bounded env30421 := by
  intro p hp
  have h : env30421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30420_30421 : H12AffineEnvironment.transform 15 8202 env30420 = env30421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env30420 == env30421) = true)

theorem identity30421 : scanCanonicalize (H12AffineFastState.compose env30421 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound30421 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30422 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,35189,1025,32769,17728,32,16,41311,8192,65,34817,16401,4096,2420,1365,41341,257,32,57612,513]

theorem envBound30422 : H12AffineFastState.Bounded env30422 := by
  intro p hp
  have h : env30422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30421_30422 : H12AffineEnvironment.transform 21 32 env30421 = env30422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env30421 == env30422) = true)

theorem identity30422 : scanCanonicalize (H12AffineFastState.compose env30422 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound30422 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env30423 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12620,32768,8202,12637,35189,1025,32769,13324,32,16,41311,8192,65,34817,12637,4096,2420,1365,41341,257,32,36928,513]

theorem envBound30423 : H12AffineFastState.Bounded env30423 := by
  intro p hp
  have h : env30423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30422_30423 : H12AffineEnvironment.transform 13 12620 env30422 = env30423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env30422 == env30423) = true)

theorem identity30423 : scanCanonicalize (H12AffineFastState.compose env30423 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound30423 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env30424 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12620,8541,8202,12637,10280,1025,8540,13324,32,16,2,8192,65,10588,12637,4096,2420,1365,32,257,32,12573,513]

theorem envBound30424 : H12AffineFastState.Bounded env30424 := by
  intro p hp
  have h : env30424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30423_30424 : H12AffineEnvironment.transform 14 8541 env30423 = env30424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env30423 == env30424) = true)

def env30425 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,91467,4194304,17,41311,8193,65,4302890,16401,77834,2421,75102,4235613,257,33,57612,513]

theorem envBound30425 : H12AffineFastState.Bounded env30425 := by
  intro p hp
  have h : env30425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30419_30425 : H12AffineEnvironment.transform 6 9 env30419 = env30425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30419 == env30425) = true)

theorem identity30425 : scanCanonicalize (H12AffineFastState.compose env30425 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound30425 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env30426 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10280,1025,8541,91467,4194304,17,3,8193,65,4262262,16401,77834,2421,75102,4194305,257,33,16464,513]

theorem envBound30426 : H12AffineFastState.Bounded env30426 := by
  intro p hp
  have h : env30426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30425_30426 : H12AffineEnvironment.transform 14 8540 env30425 = env30426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env30425 == env30426) = true)

theorem identity30426 : scanCanonicalize (H12AffineFastState.compose env30426 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound30426 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env30427 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10280,1025,8541,91467,32,17,3,8193,65,67926,16401,77834,2421,75102,33,257,33,16464,513]

theorem envBound30427 : H12AffineFastState.Bounded env30427 := by
  intro p hp
  have h : env30427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30426_30427 : H12AffineEnvironment.transform 21 32 env30426 = env30427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env30426 == env30427) = true)

def env30428 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,182629,1025,32769,2097152,4194304,147456,16777216,8328,65,21186917,18973836,2233680,149861,17024016,23160256,257,19104941,19096841,16966598]

theorem envBound30428 : H12AffineFastState.Bounded env30428 := by
  intro p hp
  have h : env30428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30403_30428 : H12AffineEnvironment.transform 17 182629 env30403 = env30428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182629 env30403 == env30428) = true)

theorem identity30428 : scanCanonicalize (H12AffineFastState.compose env30428 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188871) := by decide +kernel

theorem selectedBound30428 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env30429 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,182629,1025,32769,2097152,4194304,147456,188871,8328,65,4303010,2319691,2233680,149861,75223,6521863,257,2188650,2196686,513]

theorem envBound30429 : H12AffineFastState.Bounded env30429 := by
  intro p hp
  have h : env30429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30428_30429 : H12AffineEnvironment.transform 23 188871 env30428 = env30429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188871 env30428 == env30429) = true)

def env30430 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,35325,1025,32769,2097152,4194304,152,41311,8328,65,4303010,2172371,2119112,2557,75223,6407327,257,2188650,2196686,513]

theorem envBound30430 : H12AffineFastState.Bounded env30430 := by
  intro p hp
  have h : env30430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30429_30430 : H12AffineEnvironment.transform 16 16536 env30429 = env30430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env30429 == env30430) = true)

def env30431 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,2097152,4194304,16,41311,8192,65,4302890,2172251,2118976,2421,75103,6407191,257,2188650,2196550,513]

theorem envBound30431 : H12AffineFastState.Bounded env30431 := by
  intro p hp
  have h : env30431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30430_30431 : H12AffineEnvironment.transform 6 8 env30430 = env30431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30430 == env30431) = true)

theorem identity30431 : scanCanonicalize (H12AffineFastState.compose env30431 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound30431 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env30432 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,35189,1025,32769,2097152,4194304,16,41311,8192,65,4229153,2098512,2118976,2421,1364,6349852,257,2114913,2139213,513]

theorem envBound30432 : H12AffineFastState.Bounded env30432 := by
  intro p hp
  have h : env30432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30431_30432 : H12AffineEnvironment.transform 15 8203 env30431 = env30432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env30431 == env30432) = true)

theorem identity30432 : scanCanonicalize (H12AffineFastState.compose env30432 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 41340) := by decide +kernel

theorem selectedBound30432 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30433 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,35189,1025,32769,2097152,41340,16,41311,8192,65,10589,2098512,2118976,2421,1364,2114912,257,2114913,2139213,513]

theorem envBound30433 : H12AffineFastState.Bounded env30433 := by
  intro p hp
  have h : env30433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30432_30433 : H12AffineEnvironment.transform 21 41340 env30432 = env30433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41340 env30432 == env30433) = true)

theorem identity30433 : scanCanonicalize (H12AffineFastState.compose env30433 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(20+1) ^^^ 38144) := by decide +kernel

theorem selectedBound30433 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env30434 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,35189,1025,32769,38144,41340,16,41311,8192,65,10589,36944,49216,2421,1364,53344,257,53345,12621,513]

theorem envBound30434 : H12AffineFastState.Bounded env30434 := by
  intro p hp
  have h : env30434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30433_30434 : H12AffineEnvironment.transform 20 38144 env30433 = env30434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 38144 env30433 == env30434) = true)

theorem identity30434 : scanCanonicalize (H12AffineFastState.compose env30434 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29005) := by decide +kernel

theorem selectedBound30434 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env30435 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29005,8203,16400,30776,1025,29004,25677,20529,16,20498,8192,65,10589,24861,12557,2421,1364,8493,257,8492,12621,513]

theorem envBound30435 : H12AffineFastState.Bounded env30435 := by
  intro p hp
  have h : env30435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30434_30435 : H12AffineEnvironment.transform 14 29005 env30434 = env30435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29005 env30434 == env30435) = true)

theorem identity30435 : scanCanonicalize (H12AffineFastState.compose env30435 (packedSelected [0,1,2,3,4,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 3409) := by decide +kernel

theorem selectedBound30435 : packedSelected [0,1,2,3,4,10,11,15] rootPS < 2^1333 := by decide +kernel

def env30436 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3409,8192,16384,27676,8203,16400,25961,1025,27677,25677,19808,16,19779,8192,65,10589,24861,11356,2421,1364,8493,257,8492,11292,513]

theorem envBound30436 : H12AffineFastState.Bounded env30436 := by
  intro p hp
  have h : env30436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30435_30436 : H12AffineEnvironment.transform 11 3409 env30435 = env30436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3409 env30435 == env30436) = true)

theorem identity30436 : scanCanonicalize (H12AffineFastState.compose env30436 (packedSelected [3,4,7,8,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 11625) := by decide +kernel

theorem selectedBound30436 : packedSelected [3,4,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env30437 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3409,8192,11625,373,8203,11641,2048,1025,372,2340,8201,16,8234,8192,65,10589,3188,11356,2421,1364,8493,257,8492,11292,513]

theorem envBound30437 : H12AffineFastState.Bounded env30437 := by
  intro p hp
  have h : env30437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30436_30437 : H12AffineEnvironment.transform 13 11625 env30436 = env30437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11625 env30436 == env30437) = true)

theorem identity30437 : scanCanonicalize (H12AffineFastState.compose env30437 (packedSelected [1,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound30437 : packedSelected [1,7,8,9] rootPS < 2^1333 := by decide +kernel

def env30438 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,1141,8192,9293,373,8203,9309,292,1025,372,0,8201,16,8234,8192,65,8313,1360,9592,81,1364,8493,257,8492,9528,513]

theorem envBound30438 : H12AffineFastState.Bounded env30438 := by
  intro p hp
  have h : env30438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30437_30438 : H12AffineEnvironment.transform 10 292 env30437 = env30438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env30437 == env30438) = true)

theorem identity30438 : scanCanonicalize (H12AffineFastState.compose env30438 (packedSelected [4,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound30438 : packedSelected [4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env30439 : List Nat := [2,4,8,16,32,64,8,256,512,320,292,309,8192,8461,373,8203,8477,292,321,372,0,8201,16,8234,8192,65,8313,16,8248,81,20,8493,257,8492,8312,513]

theorem envBound30439 : H12AffineFastState.Bounded env30439 := by
  intro p hp
  have h : env30439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30438_30439 : H12AffineEnvironment.transform 9 320 env30438 = env30439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env30438 == env30439) = true)

theorem identity30439 : scanCanonicalize (H12AffineFastState.compose env30439 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound30439 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0