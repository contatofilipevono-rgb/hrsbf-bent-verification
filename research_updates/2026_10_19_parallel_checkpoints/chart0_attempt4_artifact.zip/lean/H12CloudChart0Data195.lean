import H12CloudChart0Data194

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound49383 : H12AffineFastState.Bounded env49383 := by
  intro p hp
  have h : env49383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49382_49383 : H12AffineEnvironment.transform 10 1556 env49382 = env49383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1556 env49382 == env49383) = true)

theorem identity49383 : scanCanonicalize (H12AffineFastState.compose env49383 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound49383 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env49384 : List Nat := [2,4,8,16,32,17,8,256,512,36,560,49,268,276,0,262,260,789,36,1,33,33,16,3,268,16,561,261,48,788,289,33,256,33,277,513]

theorem envBound49384 : H12AffineFastState.Bounded env49384 := by
  intro p hp
  have h : env49384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49383_49384 : H12AffineEnvironment.transform 9 36 env49383 = env49384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env49383 == env49384) = true)

theorem identity49384 : scanCanonicalize (H12AffineFastState.compose env49384 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound49384 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env49385 : List Nat := [2,4,8,16,32,17,8,53,512,36,560,49,57,33,0,51,49,544,36,1,33,33,16,3,57,16,561,48,48,545,20,33,53,33,32,513]

theorem envBound49385 : H12AffineFastState.Bounded env49385 := by
  intro p hp
  have h : env49385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49384_49385 : H12AffineEnvironment.transform 7 53 env49384 = env49385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env49384 == env49385) = true)

theorem identity49385 : scanCanonicalize (H12AffineFastState.compose env49385 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound49385 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49386 : List Nat := [2,4,8,0,32,1,8,37,512,36,544,33,41,33,0,35,33,544,36,1,33,33,0,3,41,0,545,32,32,545,4,33,37,33,32,513]

theorem envBound49386 : H12AffineFastState.Bounded env49386 := by
  intro p hp
  have h : env49386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49385_49386 : H12AffineEnvironment.transform 3 0 env49385 = env49386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env49385 == env49386) = true)

theorem identity49386 : scanCanonicalize (H12AffineFastState.compose env49386 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound49386 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49387 : List Nat := [2,4,8,0,32,1,8,37,1,36,33,33,41,33,0,35,33,33,36,1,33,33,0,3,41,0,32,32,32,32,4,33,37,33,32,0]

theorem envBound49387 : H12AffineFastState.Bounded env49387 := by
  intro p hp
  have h : env49387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49386_49387 : H12AffineEnvironment.transform 8 1 env49386 = env49387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env49386 == env49387) = true)

theorem identity49387 : scanCanonicalize (H12AffineFastState.compose env49387 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49387 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env49388 : List Nat := [2,4,8,0,1,1,8,4,1,5,0,0,8,0,0,2,0,0,5,1,0,0,0,3,8,0,1,1,1,1,4,0,4,0,1,0]

theorem envBound49388 : H12AffineFastState.Bounded env49388 := by
  intro p hp
  have h : env49388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49387_49388 : H12AffineEnvironment.transform 4 1 env49387 = env49388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49387 == env49388) = true)

def env49389 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,4161,180272,16,98645,8193,65,171281,5392,17664,56437,1365,144492,256,21792,46093,74251]

theorem envBound49389 : H12AffineFastState.Bounded env49389 := by
  intro p hp
  have h : env49389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49374_49389 : H12AffineEnvironment.transform 6 9 env49374 = env49389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49374 == env49389) = true)

theorem identity49389 : scanCanonicalize (H12AffineFastState.compose env49389 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound49389 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49390 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,35189,1024,32769,4161,21793,16,98645,8193,65,2048,5392,17664,56437,1365,41341,256,21792,46093,74251]

theorem envBound49390 : H12AffineFastState.Bounded env49390 := by
  intro p hp
  have h : env49390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49389_49390 : H12AffineEnvironment.transform 16 38161 env49389 = env49390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env49389 == env49390) = true)

def env49391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830976,25265168,23160257,257,27378860,27337993,25207750]

theorem envBound49391 : H12AffineFastState.Bounded env49391 := by
  intro p hp
  have h : env49391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49133_49391 : H12AffineEnvironment.transform 18 1025 env49133 = env49391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env49133 == env49391) = true)

theorem identity49391 : scanCanonicalize (H12AffineFastState.compose env49391 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2485308) := by decide +kernel

theorem selectedBound49391 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env49392 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2485308,8328,65,14822461,288944,10507601,8830976,10774572,4491773,257,8661136,8702261,10833914]

theorem envBound49392 : H12AffineFastState.Bounded env49392 := by
  intro p hp
  have h : env49392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49391_49392 : H12AffineEnvironment.transform 23 2485308 env49391 = env49392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2485308 env49391 == env49392) = true)

def env49393 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,294320,2485308,8328,65,6705549,288944,2369761,179632,2102684,4491773,257,21792,46213,2175562]

theorem envBound49393 : H12AffineFastState.Bounded env49393 := by
  intro p hp
  have h : env49393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49392_49393 : H12AffineEnvironment.transform 22 294320 env49392 = env49393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 294320 env49392 == env49393) = true)

def env49394 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290272,4194304,294320,98780,8328,65,4340845,288944,17665,179632,292988,4491773,257,21792,46213,352170]

theorem envBound49394 : H12AffineFastState.Bounded env49394 := by
  intro p hp
  have h : env49394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49393_49394 : H12AffineEnvironment.transform 20 290272 env49393 = env49394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290272 env49393 == env49394) = true)

def env49395 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290272,272512,294320,98780,8328,65,398573,288944,17665,179632,292988,41341,257,21792,46213,352170]

theorem envBound49395 : H12AffineFastState.Bounded env49395 := by
  intro p hp
  have h : env49395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49394_49395 : H12AffineEnvironment.transform 21 272512 env49394 = env49395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env49394 == env49395) = true)

theorem identity49395 : scanCanonicalize (H12AffineFastState.compose env49395 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 89515) := by decide +kernel

theorem selectedBound49395 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49396 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89515,1025,32769,77899,95531,73755,98780,8328,65,215366,79131,17665,179632,75223,41341,257,21792,46213,513]

theorem envBound49396 : H12AffineFastState.Bounded env49396 := by
  intro p hp
  have h : env49396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49395_49396 : H12AffineEnvironment.transform 17 89515 env49395 = env49396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89515 env49395 == env49396) = true)

def env49397 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89379,1025,32769,77899,95531,73755,98644,8192,65,215366,79131,17665,179512,75103,41341,257,21792,46093,513]

theorem envBound49397 : H12AffineFastState.Bounded env49397 := by
  intro p hp
  have h : env49397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49396_49397 : H12AffineEnvironment.transform 6 8 env49396 = env49397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49396 == env49397) = true)

theorem identity49397 : scanCanonicalize (H12AffineFastState.compose env49397 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 91402) := by decide +kernel

theorem selectedBound49397 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env49398 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,91402,89379,1025,32769,77899,95531,73755,98644,8192,65,11340,79131,17665,120882,75103,41341,257,21792,46093,513]

theorem envBound49398 : H12AffineFastState.Bounded env49398 := by
  intro p hp
  have h : env49398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49397_49398 : H12AffineEnvironment.transform 16 91402 env49397 = env49398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 91402 env49397 == env49398) = true)

theorem identity49398 : scanCanonicalize (H12AffineFastState.compose env49398 (packedSelected [1,3,5,8,9,10,14,17,19,22] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound49398 : packedSelected [1,3,5,8,9,10,14,17,19,22] rootPS < 2^1333 := by decide +kernel

def env49399 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,32768,65536,90138,88115,273,32769,77899,94267,73755,98644,8192,65,10588,77835,16401,120882,73807,41341,257,20528,45341,513]

theorem envBound49399 : H12AffineFastState.Bounded env49399 := by
  intro p hp
  have h : env49399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49398_49399 : H12AffineEnvironment.transform 9 272 env49398 = env49399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env49398 == env49399) = true)

theorem identity49399 : scanCanonicalize (H12AffineFastState.compose env49399 (packedSelected [3,5,10,11,17,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 29004) := by decide +kernel

theorem selectedBound49399 : packedSelected [3,5,10,11,17,18,23,32] rootPS < 2^1333 := by decide +kernel

def env49400 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,29004,65536,90138,88115,273,29005,77899,94267,73755,94232,8192,65,10588,77835,16401,76158,73807,20529,257,20528,16465,513]

theorem envBound49400 : H12AffineFastState.Bounded env49400 := by
  intro p hp
  have h : env49400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49399_49400 : H12AffineEnvironment.transform 14 29004 env49399 = env49400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29004 env49399 == env49400) = true)

theorem identity49400 : scanCanonicalize (H12AffineFastState.compose env49400 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound49400 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49401 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4112,8540,65536,77834,67619,273,8541,77899,73771,73755,73736,8192,65,10588,77835,4097,76158,73807,33,257,32,4161,513]

theorem envBound49401 : H12AffineFastState.Bounded env49401 := by
  intro p hp
  have h : env49401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49400_49401 : H12AffineEnvironment.transform 13 4112 env49400 = env49401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env49400 == env49401) = true)

theorem identity49401 : scanCanonicalize (H12AffineFastState.compose env49401 (packedSelected [0,1,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(15+1) ^^^ 2310) := by decide +kernel

theorem selectedBound49401 : packedSelected [0,1,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env49402 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4112,8540,2310,14604,293,273,8541,14669,10541,10525,10510,8192,65,10588,14605,4097,8312,10569,33,257,32,4161,513]

theorem envBound49402 : H12AffineFastState.Bounded env49402 := by
  intro p hp
  have h : env49402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49401_49402 : H12AffineEnvironment.transform 15 2310 env49401 = env49402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2310 env49401 == env49402) = true)

theorem identity49402 : scanCanonicalize (H12AffineFastState.compose env49402 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 4381) := by decide +kernel

theorem selectedBound49402 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env49403 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,4381,4112,4161,2310,2065,293,273,4160,2128,6192,6144,6163,4381,65,6209,2064,4097,4453,6228,33,257,32,4161,513]

theorem envBound49403 : H12AffineFastState.Bounded env49403 := by
  intro p hp
  have h : env49403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49402_49403 : H12AffineEnvironment.transform 12 4381 env49402 = env49403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4381 env49402 == env49403) = true)

theorem identity49403 : scanCanonicalize (H12AffineFastState.compose env49403 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound49403 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env49404 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2065,2316,2049,2128,2310,2065,293,273,2129,2128,33,17,2,2316,65,80,2064,2064,2420,69,33,257,32,2128,513]

theorem envBound49404 : H12AffineFastState.Bounded env49404 := by
  intro p hp
  have h : env49404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49403_49404 : H12AffineEnvironment.transform 11 2065 env49403 = env49404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env49403 == env49404) = true)

theorem identity49404 : scanCanonicalize (H12AffineFastState.compose env49404 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 341) := by decide +kernel

theorem selectedBound49404 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49405 : List Nat := [2,4,8,16,32,64,8,256,512,272,341,324,89,340,261,83,324,293,273,260,261,33,17,2,89,65,80,325,325,33,69,33,257,32,261,513]

theorem envBound49405 : H12AffineFastState.Bounded env49405 := by
  intro p hp
  have h : env49405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49404_49405 : H12AffineEnvironment.transform 10 341 env49404 = env49405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 341 env49404 == env49405) = true)

theorem identity49405 : scanCanonicalize (H12AffineFastState.compose env49405 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound49405 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49406 : List Nat := [2,4,8,16,32,64,8,256,81,272,341,324,89,340,261,83,324,293,273,260,261,33,17,2,89,65,80,325,325,33,69,33,257,32,261,80]

theorem envBound49406 : H12AffineFastState.Bounded env49406 := by
  intro p hp
  have h : env49406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49405_49406 : H12AffineEnvironment.transform 8 81 env49405 = env49406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env49405 == env49406) = true)

theorem identity49406 : scanCanonicalize (H12AffineFastState.compose env49406 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound49406 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env49407 : List Nat := [2,4,8,16,32,48,8,256,33,272,293,308,41,292,261,35,308,293,273,260,261,33,17,2,41,49,32,309,309,33,53,33,257,32,261,32]

theorem envBound49407 : H12AffineFastState.Bounded env49407 := by
  intro p hp
  have h : env49407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49406_49407 : H12AffineEnvironment.transform 5 48 env49406 = env49407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env49406 == env49407) = true)

theorem identity49407 : scanCanonicalize (H12AffineFastState.compose env49407 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound49407 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env49408 : List Nat := [2,4,8,16,32,48,8,52,33,36,17,0,41,16,49,35,0,17,37,48,49,33,17,2,41,49,32,1,1,33,53,33,53,32,49,32]

theorem envBound49408 : H12AffineFastState.Bounded env49408 := by
  intro p hp
  have h : env49408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49407_49408 : H12AffineEnvironment.transform 7 52 env49407 = env49408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env49407 == env49408) = true)

theorem identity49408 : scanCanonicalize (H12AffineFastState.compose env49408 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound49408 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env49409 : List Nat := [2,4,8,1,32,33,8,37,33,36,0,0,41,1,32,35,0,0,37,33,32,33,0,2,41,32,32,1,1,33,36,33,36,32,32,32]

theorem envBound49409 : H12AffineFastState.Bounded env49409 := by
  intro p hp
  have h : env49409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49408_49409 : H12AffineEnvironment.transform 3 1 env49408 = env49409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env49408 == env49409) = true)

theorem identity49409 : scanCanonicalize (H12AffineFastState.compose env49409 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49409 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49410 : List Nat := [2,4,8,1,1,0,8,4,0,5,0,0,8,1,1,2,0,0,4,0,1,0,0,2,8,1,1,1,1,0,5,0,5,1,1,1]

theorem envBound49410 : H12AffineFastState.Bounded env49410 := by
  intro p hp
  have h : env49410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49409_49410 : H12AffineEnvironment.transform 4 1 env49409 = env49410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49409 == env49410) = true)

def env49411 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89378,1025,32769,77899,95531,73755,98645,8193,65,215366,79131,17665,179513,75102,41341,257,21792,46092,513]

theorem envBound49411 : H12AffineFastState.Bounded env49411 := by
  intro p hp
  have h : env49411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49396_49411 : H12AffineEnvironment.transform 6 9 env49396 = env49411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49396 == env49411) = true)

theorem identity49411 : scanCanonicalize (H12AffineFastState.compose env49411 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound49411 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env49412 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,35189,1025,32769,58396,41340,62540,21762,8193,65,171281,57676,17665,179513,61705,41341,257,21792,46092,513]

theorem envBound49412 : H12AffineFastState.Bounded env49412 := by
  intro p hp
  have h : env49412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49411_49412 : H12AffineEnvironment.transform 15 54359 env49411 = env49412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env49411 == env49412) = true)

theorem identity49412 : scanCanonicalize (H12AffineFastState.compose env49412 (packedSelected [0,1,3,4,5,8,9,10,16,17,18,19,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound49412 : packedSelected [0,1,3,4,5,8,9,10,16,17,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env49413 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33110,131072,35189,1025,32769,45341,41340,41293,3,8193,65,171281,46157,4096,179513,41992,41341,257,33,46092,513]

theorem envBound49413 : H12AffineFastState.Bounded env49413 := by
  intro p hp
  have h : env49413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49412_49413 : H12AffineEnvironment.transform 13 5377 env49412 = env49413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env49412 == env49413) = true)

theorem identity49413 : scanCanonicalize (H12AffineFastState.compose env49413 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49413 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49414 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,32768,33031,131072,35108,1025,32769,45341,41261,41244,3,8193,16,171281,46108,4096,179513,41992,41260,257,33,46092,513]

theorem envBound49414 : H12AffineFastState.Bounded env49414 := by
  intro p hp
  have h : env49414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49413_49414 : H12AffineEnvironment.transform 5 17 env49413 = env49414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49413 == env49414) = true)

theorem identity49414 : scanCanonicalize (H12AffineFastState.compose env49414 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound49414 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49415 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8461,8202,131072,10281,1025,8460,4112,32,17,3,8193,16,146460,5393,4096,138292,1285,33,257,33,5377,513]

theorem envBound49415 : H12AffineFastState.Bounded env49415 := by
  intro p hp
  have h : env49415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49414_49415 : H12AffineEnvironment.transform 14 8461 env49414 = env49415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env49414 == env49415) = true)

theorem identity49415 : scanCanonicalize (H12AffineFastState.compose env49415 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound49415 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env49416 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,9,5377,260,3,131072,2080,1025,261,4112,32,17,3,8,16,138261,5393,4096,138292,1285,33,257,33,5377,513]

theorem envBound49416 : H12AffineFastState.Bounded env49416 := by
  intro p hp
  have h : env49416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49415_49416 : H12AffineEnvironment.transform 12 9 env49415 = env49416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env49415 == env49416) = true)

def env49417 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290272,272513,294320,98780,8328,65,398572,288944,17665,179632,292988,41340,257,21792,46213,352170]

theorem envBound49417 : H12AffineFastState.Bounded env49417 := by
  intro p hp
  have h : env49417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49394_49417 : H12AffineEnvironment.transform 21 272513 env49394 = env49417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env49394 == env49417) = true)

theorem identity49417 : scanCanonicalize (H12AffineFastState.compose env49417 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound49417 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49418 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,290272,272513,294320,41430,8328,65,398572,288944,17665,179632,292988,41340,257,21792,46213,294816]

theorem envBound49418 : H12AffineFastState.Bounded env49418 := by
  intro p hp
  have h : env49418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49417_49418 : H12AffineEnvironment.transform 15 8202 env49417 = env49418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env49417 == env49418) = true)

def env49419 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32160,1025,32769,4160,21793,16,41430,8328,65,158028,5392,17665,179632,1500,41340,257,21792,46213,512]

theorem envBound49419 : H12AffineFastState.Bounded env49419 := by
  intro p hp
  have h : env49419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49418_49419 : H12AffineEnvironment.transform 17 32160 env49418 = env49419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env49418 == env49419) = true)

theorem identity49419 : scanCanonicalize (H12AffineFastState.compose env49419 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 8353) := by decide +kernel

theorem selectedBound49419 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env49420 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,8202,131072,32160,1025,8352,4160,21793,16,375,8328,65,158028,5392,17665,138513,1500,477,257,21792,5156,512]

theorem envBound49420 : H12AffineFastState.Bounded env49420 := by
  intro p hp
  have h : env49420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49419_49420 : H12AffineEnvironment.transform 14 8353 env49419 = env49420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env49419 == env49420) = true)

theorem identity49420 : scanCanonicalize (H12AffineFastState.compose env49420 (packedSelected [0,1,2,3,5,6,7,8,10,11,18,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 5173) := by decide +kernel

theorem selectedBound49420 : packedSelected [0,1,2,3,5,6,7,8,10,11,18,19,20] rootPS < 2^1333 := by decide +kernel

def env49421 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,8202,5173,32160,1025,8352,4160,21793,16,375,8328,65,32121,5392,17665,2340,1500,477,257,21792,5156,512]

theorem envBound49421 : H12AffineFastState.Bounded env49421 := by
  intro p hp
  have h : env49421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49420_49421 : H12AffineEnvironment.transform 16 5173 env49420 = env49421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5173 env49420 == env49421) = true)

theorem identity49421 : scanCanonicalize (H12AffineFastState.compose env49421 (packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 13556) := by decide +kernel

theorem selectedBound49421 : packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env49422 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13556,8353,8202,5173,2388,1025,8352,4160,8661,16,375,8328,65,2445,5392,12789,2340,1500,477,257,8660,5156,512]

theorem envBound49422 : H12AffineFastState.Bounded env49422 := by
  intro p hp
  have h : env49422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49421_49422 : H12AffineEnvironment.transform 13 13556 env49421 = env49422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13556 env49421 == env49422) = true)

theorem identity49422 : scanCanonicalize (H12AffineFastState.compose env49422 (packedSelected [2,11,14,18,19,26] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound49422 : packedSelected [2,11,14,18,19,26] rootPS < 2^1333 := by decide +kernel

def env49423 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,13556,8353,8202,5173,2297,1025,8352,4160,8312,16,218,8328,65,2080,5309,12376,2185,1137,112,172,8313,5156,512]

theorem envBound49423 : H12AffineFastState.Bounded env49423 := by
  intro p hp
  have h : env49423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49422_49423 : H12AffineEnvironment.transform 7 173 env49422 = env49423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env49422 == env49423) = true)

theorem identity49423 : scanCanonicalize (H12AffineFastState.compose env49423 (packedSelected [1,2,3,5,8,10,11,14,17,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound49423 : packedSelected [1,2,3,5,8,10,11,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env49424 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,88,5292,249,82,5173,2297,1025,248,4160,32,16,218,208,65,2080,5309,4096,2185,1137,112,172,33,5156,512]

theorem envBound49424 : H12AffineFastState.Bounded env49424 := by
  intro p hp
  have h : env49424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49423_49424 : H12AffineEnvironment.transform 12 88 env49423 = env49424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env49423 == env49424) = true)

def env49425 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32161,1025,32769,4161,21792,17,41430,8328,65,158029,5393,17665,179632,1501,41340,257,21792,46213,513]

theorem envBound49425 : H12AffineFastState.Bounded env49425 := by
  intro p hp
  have h : env49425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49418_49425 : H12AffineEnvironment.transform 17 32161 env49418 = env49425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env49418 == env49425) = true)

theorem identity49425 : scanCanonicalize (H12AffineFastState.compose env49425 (packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS)) = affineNative (2^(16+1) ^^^ 24981) := by decide +kernel

theorem selectedBound49425 : packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env49426 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,24981,32161,1025,32769,4161,21792,17,41430,8328,65,2264,5393,17665,56357,1501,41340,257,21792,46213,513]

theorem envBound49426 : H12AffineFastState.Bounded env49426 := by
  intro p hp
  have h : env49426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49425_49426 : H12AffineEnvironment.transform 16 24981 env49425 = env49426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24981 env49425 == env49426) = true)

theorem identity49426 : scanCanonicalize (H12AffineFastState.compose env49426 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound49426 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env49427 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29708,8202,24981,32161,1025,29709,4161,21792,17,21978,8328,65,2264,5393,17665,10281,1501,21872,257,21792,16521,513]

theorem envBound49427 : H12AffineFastState.Bounded env49427 := by
  intro p hp
  have h : env49427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49426_49427 : H12AffineEnvironment.transform 14 29708 env49426 = env49427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env49426 == env49427) = true)

theorem identity49427 : scanCanonicalize (H12AffineFastState.compose env49427 (packedSelected [2,3,6,10,17,18,19,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound49427 : packedSelected [2,3,6,10,17,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env49428 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,16384,21897,399,16400,23588,1025,21896,4161,21792,17,21978,269,65,2264,5393,17665,2476,1501,21872,257,21792,16521,513]

theorem envBound49428 : H12AffineFastState.Bounded env49428 := by
  intro p hp
  have h : env49428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49427_49428 : H12AffineEnvironment.transform 12 389 env49427 = env49428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env49427 == env49428) = true)

theorem identity49428 : scanCanonicalize (H12AffineFastState.compose env49428 (packedSelected [3,4,6,7,8,10,11,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound49428 : packedSelected [3,4,6,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env49429 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5156,429,399,5172,2048,1025,428,4161,260,17,510,269,65,2264,5393,4389,2476,1501,340,257,260,5293,513]

theorem envBound49429 : H12AffineFastState.Bounded env49429 := by
  intro p hp
  have h : env49429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49428_49429 : H12AffineEnvironment.transform 13 5156 env49428 = env49429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env49428 == env49429) = true)

theorem identity49429 : scanCanonicalize (H12AffineFastState.compose env49429 (packedSelected [2,4,6,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound49429 : packedSelected [2,4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env49430 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,120,5156,80,114,5172,2048,1025,81,4161,249,17,3,240,65,2264,5356,4312,2129,1056,169,252,249,5293,513]

theorem envBound49430 : H12AffineFastState.Bounded env49430 := by
  intro p hp
  have h : env49430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49429_49430 : H12AffineEnvironment.transform 7 253 env49429 = env49430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env49429 == env49430) = true)

theorem identity49430 : scanCanonicalize (H12AffineFastState.compose env49430 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound49430 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env49431 : List Nat := [2,4,8,16,32,64,89,36,512,1024,2048,4096,120,5156,80,114,5172,2048,1025,81,4161,32,17,3,41,65,2049,5173,4097,2129,1056,112,37,32,5236,513]

theorem envBound49431 : H12AffineFastState.Bounded env49431 := by
  intro p hp
  have h : env49431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49430_49431 : H12AffineEnvironment.transform 6 89 env49430 = env49431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env49430 == env49431) = true)

theorem identity49431 : scanCanonicalize (H12AffineFastState.compose env49431 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49431 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49432 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,5156,0,34,5172,2048,1025,1,4113,32,17,3,41,17,2049,5173,4097,2049,1056,32,37,32,5156,513]

theorem envBound49432 : H12AffineFastState.Bounded env49432 := by
  intro p hp
  have h : env49432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49431_49432 : H12AffineEnvironment.transform 5 16 env49431 = env49432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49431 == env49432) = true)

theorem identity49432 : scanCanonicalize (H12AffineFastState.compose env49432 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound49432 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49433 : List Nat := [2,4,8,16,32,16,9,36,512,53,2048,4096,40,4113,0,34,4097,2048,52,1,4113,32,17,3,41,17,2049,4096,4097,2049,21,32,37,32,4113,513]

theorem envBound49433 : H12AffineFastState.Bounded env49433 := by
  intro p hp
  have h : env49433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49432_49433 : H12AffineEnvironment.transform 9 53 env49432 = env49433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49432 == env49433) = true)

theorem identity49433 : scanCanonicalize (H12AffineFastState.compose env49433 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound49433 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49434 : List Nat := [2,4,8,16,32,16,9,36,512,53,2048,17,40,0,0,34,16,2048,52,1,0,32,17,3,41,17,2049,17,16,2049,21,32,37,32,0,513]

theorem envBound49434 : H12AffineFastState.Bounded env49434 := by
  intro p hp
  have h : env49434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49433_49434 : H12AffineEnvironment.transform 11 17 env49433 = env49434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env49433 == env49434) = true)

theorem identity49434 : scanCanonicalize (H12AffineFastState.compose env49434 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound49434 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49435 : List Nat := [2,4,8,16,32,16,9,36,512,53,523,17,40,0,0,34,16,523,52,1,0,32,17,3,41,17,522,17,16,522,21,32,37,32,0,513]

theorem envBound49435 : H12AffineFastState.Bounded env49435 := by
  intro p hp
  have h : env49435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49434_49435 : H12AffineEnvironment.transform 10 523 env49434 = env49435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env49434 == env49435) = true)

theorem identity49435 : scanCanonicalize (H12AffineFastState.compose env49435 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound49435 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env49436 : List Nat := [2,4,8,16,32,16,9,36,11,53,0,17,40,0,0,34,16,0,52,1,0,32,17,3,41,17,1,17,16,1,21,32,37,32,0,10]

theorem envBound49436 : H12AffineFastState.Bounded env49436 := by
  intro p hp
  have h : env49436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49435_49436 : H12AffineEnvironment.transform 8 11 env49435 = env49436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env49435 == env49436) = true)

def env49437 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290273,4194304,294320,98781,8328,65,4340844,288944,17664,179632,292989,4491773,257,21792,46213,352171]

theorem envBound49437 : H12AffineFastState.Bounded env49437 := by
  intro p hp
  have h : env49437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49393_49437 : H12AffineEnvironment.transform 20 290273 env49393 = env49437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290273 env49393 == env49437) = true)

def env49438 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290273,272512,294320,98781,8328,65,398572,288944,17664,179632,292989,41341,257,21792,46213,352171]

theorem envBound49438 : H12AffineFastState.Bounded env49438 := by
  intro p hp
  have h : env49438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49437_49438 : H12AffineEnvironment.transform 21 272512 env49437 = env49438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env49437 == env49438) = true)

theorem identity49438 : scanCanonicalize (H12AffineFastState.compose env49438 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 108926) := by decide +kernel

theorem selectedBound49438 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49439 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,108926,1025,32769,115871,98814,120014,98781,8328,65,245138,115150,17664,179632,119043,41341,257,21792,46213,63189]

theorem envBound49439 : H12AffineFastState.Bounded env49439 := by
  intro p hp
  have h : env49439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49438_49439 : H12AffineEnvironment.transform 17 108926 env49438 = env49439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108926 env49438 == env49439) = true)

def env49440 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,108926,1025,32769,102815,98814,98766,98781,8328,65,245138,103630,4096,179632,99331,41341,257,32,46213,41941]

theorem envBound49440 : H12AffineFastState.Bounded env49440 := by
  intro p hp
  have h : env49440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49439_49440 : H12AffineEnvironment.transform 13 5376 env49439 = env49440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env49439 == env49440) = true)

theorem identity49440 : scanCanonicalize (H12AffineFastState.compose env49440 (packedSelected [11,18,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound49440 : packedSelected [11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env49441 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8202,131072,35188,1025,32769,45461,41460,41412,41431,8328,65,171416,46276,4096,179632,41993,41341,257,32,46213,41941]

theorem envBound49441 : H12AffineFastState.Bounded env49441 := by
  intro p hp
  have h : env49441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49440_49441 : H12AffineEnvironment.transform 15 8202 env49440 = env49441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env49440 == env49441) = true)

theorem identity49441 : scanCanonicalize (H12AffineFastState.compose env49441 (packedSelected [3,5,6,12,17,18,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound49441 : packedSelected [3,5,6,12,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env49442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8,5376,32768,2,131072,35188,1025,32769,37277,33276,33228,33247,128,65,171416,38092,4096,171448,33793,33141,257,32,38029,33757]

theorem envBound49442 : H12AffineFastState.Bounded env49442 := by
  intro p hp
  have h : env49442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49441_49442 : H12AffineEnvironment.transform 12 8 env49441 = env49442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env49441 == env49442) = true)

theorem identity49442 : scanCanonicalize (H12AffineFastState.compose env49442 (packedSelected [0,1,2,3,5,7,8,10,11,12,14,15,16,18,19] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound49442 : packedSelected [0,1,2,3,5,7,8,10,11,12,14,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env49443 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8,5376,32768,2,131072,35188,1025,32769,37188,33061,33045,33030,89,65,171329,37909,4096,171361,33793,33141,257,32,37972,33540]

theorem envBound49443 : H12AffineFastState.Bounded env49443 := by
  intro p hp
  have h : env49443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49442_49443 : H12AffineEnvironment.transform 6 89 env49442 = env49443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env49442 == env49443) = true)

theorem identity49443 : scanCanonicalize (H12AffineFastState.compose env49443 (packedSelected [0,2,6,7,9,11,12,14,15,16,18,22] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49443 : packedSelected [0,2,6,7,9,11,12,14,15,16,18,22] rootPS < 2^1333 := by decide +kernel

def env49444 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8,5376,32768,2,131072,35108,1025,32769,37140,33061,33045,33030,9,17,171281,37909,4096,171313,33793,33061,257,32,37892,33540]

theorem envBound49444 : H12AffineFastState.Bounded env49444 := by
  intro p hp
  have h : env49444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49443_49444 : H12AffineEnvironment.transform 5 16 env49443 = env49444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49443 == env49444) = true)

theorem identity49444 : scanCanonicalize (H12AffineFastState.compose env49444 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound49444 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env49445 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8,5376,32768,2,38161,35108,1025,32769,37140,33061,33045,33030,9,17,2048,37909,4096,2080,33793,33061,257,32,37892,33540]

theorem envBound49445 : H12AffineFastState.Bounded env49445 := by
  intro p hp
  have h : env49445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49444_49445 : H12AffineEnvironment.transform 16 38161 env49444 = env49445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env49444 == env49445) = true)

theorem identity49445 : scanCanonicalize (H12AffineFastState.compose env49445 (packedSelected [0,1,2,3,4,5,7,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 3360) := by decide +kernel

theorem selectedBound49445 : packedSelected [0,1,2,3,4,5,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env49446 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3360,8,2080,32768,2,34865,35108,1025,32769,35892,33061,33045,33030,9,17,2048,35125,3360,2080,33793,33061,257,32,35108,33540]

theorem envBound49446 : H12AffineFastState.Bounded env49446 := by
  intro p hp
  have h : env49446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49445_49446 : H12AffineEnvironment.transform 11 3360 env49445 = env49446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3360 env49445 == env49446) = true)

theorem identity49446 : scanCanonicalize (H12AffineFastState.compose env49446 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(14+1) ^^^ 260) := by decide +kernel

theorem selectedBound49446 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env49447 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3360,8,2080,260,2,2357,2080,1025,261,3376,33,17,2,9,17,2048,2097,3360,2080,1285,33,257,32,2080,512]

theorem envBound49447 : H12AffineFastState.Bounded env49447 := by
  intro p hp
  have h : env49447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49446_49447 : H12AffineEnvironment.transform 14 260 env49446 = env49447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 260 env49446 == env49447) = true)

theorem identity49447 : scanCanonicalize (H12AffineFastState.compose env49447 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound49447 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49448 : List Nat := [2,4,8,16,0,16,9,256,512,1024,2048,3328,8,2048,260,2,2325,2048,1025,261,3344,1,17,2,9,17,2048,2065,3328,2048,1285,1,257,0,2048,512]

theorem envBound49448 : H12AffineFastState.Bounded env49448 := by
  intro p hp
  have h : env49448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49447_49448 : H12AffineEnvironment.transform 4 0 env49447 = env49448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env49447 == env49448) = true)

theorem identity49448 : scanCanonicalize (H12AffineFastState.compose env49448 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1793) := by decide +kernel

theorem selectedBound49448 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env49449 : List Nat := [2,4,8,16,0,16,9,256,512,1024,1793,513,8,1793,260,2,1556,1793,1025,261,529,1,17,2,9,17,1793,1808,513,1793,1285,1,257,0,1793,512]

theorem envBound49449 : H12AffineFastState.Bounded env49449 := by
  intro p hp
  have h : env49449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49448_49449 : H12AffineEnvironment.transform 10 1793 env49448 = env49449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env49448 == env49449) = true)

theorem identity49449 : scanCanonicalize (H12AffineFastState.compose env49449 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound49449 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env49450 : List Nat := [2,4,8,16,0,16,9,5,512,1024,1540,513,8,1540,1,2,1556,1540,1025,0,529,1,17,2,9,17,1540,1557,513,1540,1024,1,4,0,1540,512]

theorem envBound49450 : H12AffineFastState.Bounded env49450 := by
  intro p hp
  have h : env49450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49449_49450 : H12AffineEnvironment.transform 7 5 env49449 = env49450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env49449 == env49450) = true)

theorem identity49450 : scanCanonicalize (H12AffineFastState.compose env49450 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound49450 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49451 : List Nat := [2,4,8,16,0,16,9,5,0,1024,1028,1,8,1028,1,2,1044,1028,1025,0,17,1,17,2,9,17,1028,1045,1,1028,1024,1,4,0,1028,0]

theorem envBound49451 : H12AffineFastState.Bounded env49451 := by
  intro p hp
  have h : env49451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49450_49451 : H12AffineEnvironment.transform 8 0 env49450 = env49451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env49450 == env49451) = true)

theorem identity49451 : scanCanonicalize (H12AffineFastState.compose env49451 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound49451 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49452 : List Nat := [2,4,8,16,0,16,9,5,0,15,11,1,8,11,1,2,27,11,14,0,17,1,17,2,9,17,11,26,1,11,15,1,4,0,11,0]

theorem envBound49452 : H12AffineFastState.Bounded env49452 := by
  intro p hp
  have h : env49452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49451_49452 : H12AffineEnvironment.transform 9 15 env49451 = env49452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env49451 == env49452) = true)

theorem identity49452 : scanCanonicalize (H12AffineFastState.compose env49452 (packedSelected [0,1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound49452 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env49453 : List Nat := [1,4,8,16,0,16,9,5,0,12,8,1,8,8,1,1,24,8,13,0,17,1,17,1,9,17,8,25,1,8,12,1,4,0,8,0]

theorem envBound49453 : H12AffineFastState.Bounded env49453 := by
  intro p hp
  have h : env49453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49452_49453 : H12AffineEnvironment.transform 0 1 env49452 = env49453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env49452 == env49453) = true)

theorem identity49453 : scanCanonicalize (H12AffineFastState.compose env49453 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound49453 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49454 : List Nat := [1,4,8,9,0,9,9,5,0,12,8,1,8,8,1,1,1,8,13,0,8,1,8,1,9,8,8,0,1,8,12,1,4,0,8,0]

theorem envBound49454 : H12AffineFastState.Bounded env49454 := by
  intro p hp
  have h : env49454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49453_49454 : H12AffineEnvironment.transform 3 9 env49453 = env49454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env49453 == env49454) = true)

theorem identity49454 : scanCanonicalize (H12AffineFastState.compose env49454 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound49454 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49455 : List Nat := [1,4,4,5,0,5,5,5,0,0,4,1,4,4,1,1,1,4,1,0,4,1,4,1,5,4,4,0,1,4,0,1,4,0,4,0]

theorem envBound49455 : H12AffineFastState.Bounded env49455 := by
  intro p hp
  have h : env49455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49454_49455 : H12AffineEnvironment.transform 2 4 env49454 = env49455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env49454 == env49455) = true)

def env49456 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,108926,1025,32769,102814,98814,98767,98781,8328,65,245138,103631,4097,179632,99330,41341,257,33,46213,41940]

theorem envBound49456 : H12AffineFastState.Bounded env49456 := by
  intro p hp
  have h : env49456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49439_49456 : H12AffineEnvironment.transform 13 5377 env49439 = env49456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env49439 == env49456) = true)

theorem identity49456 : scanCanonicalize (H12AffineFastState.compose env49456 (packedSelected [0,5,8,9,14,17,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound49456 : packedSelected [0,5,8,9,14,17,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env49457 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,8322,131072,35324,1025,32769,45340,41340,41293,41311,8328,65,171280,46157,4097,179632,42112,41341,257,33,46213,41940]

theorem envBound49457 : H12AffineFastState.Bounded env49457 := by
  intro p hp
  have h : env49457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49456_49457 : H12AffineEnvironment.transform 15 8322 env49456 = env49457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env49456 == env49457) = true)

theorem identity49457 : scanCanonicalize (H12AffineFastState.compose env49457 (packedSelected [0,5,8,9,10,18,19,22,23,24,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound49457 : packedSelected [0,5,8,9,10,18,19,22,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env49458 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,8322,5393,35324,1025,32769,45340,41340,41293,41311,8328,65,34817,46157,4097,43169,42112,41341,257,33,46213,41940]

theorem envBound49458 : H12AffineFastState.Bounded env49458 := by
  intro p hp
  have h : env49458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49457_49458 : H12AffineEnvironment.transform 16 5393 env49457 = env49458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env49457 == env49458) = true)

theorem identity49458 : scanCanonicalize (H12AffineFastState.compose env49458 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound49458 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8322,5393,10281,1025,8660,4297,169,152,138,8328,65,10708,5528,4097,2420,1365,168,257,33,5456,513]

theorem envBound49459 : H12AffineFastState.Bounded env49459 := by
  intro p hp
  have h : env49459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49458_49459 : H12AffineEnvironment.transform 14 8661 env49458 = env49459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env49458 == env49459) = true)

def env49460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290273,272513,294320,98781,8328,65,398573,288944,17664,179632,292989,41340,257,21792,46213,352171]

theorem envBound49460 : H12AffineFastState.Bounded env49460 := by
  intro p hp
  have h : env49460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49437_49460 : H12AffineEnvironment.transform 21 272513 env49437 = env49460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env49437 == env49460) = true)

theorem identity49460 : scanCanonicalize (H12AffineFastState.compose env49460 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound49460 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,290273,272513,294320,21762,8328,65,398573,288944,17664,179632,292989,41340,257,21792,46213,297844]

theorem envBound49461 : H12AffineFastState.Bounded env49461 := by
  intro p hp
  have h : env49461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49460_49461 : H12AffineEnvironment.transform 15 54495 env49460 = env49461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env49460 == env49461) = true)

def env49462 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,290153,272393,294200,21762,8192,65,398437,288824,17664,179512,292989,41340,257,21792,46093,297844]

theorem envBound49462 : H12AffineFastState.Bounded env49462 := by
  intro p hp
  have h : env49462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49461_49462 : H12AffineEnvironment.transform 6 8 env49461 = env49462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49461 == env49462) = true)

theorem identity49462 : scanCanonicalize (H12AffineFastState.compose env49462 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 146744) := by decide +kernel

theorem selectedBound49462 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env49463 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,146744,1025,32769,151633,136497,147456,21762,8192,65,10589,152832,17664,179512,148805,41340,257,21792,46093,177740]

theorem envBound49463 : H12AffineFastState.Bounded env49463 := by
  intro p hp
  have h : env49463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49462_49463 : H12AffineEnvironment.transform 17 146744 env49462 = env49463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146744 env49462 == env49463) = true)

theorem identity49463 : scanCanonicalize (H12AffineFastState.compose env49463 (packedSelected [0,1,3,4,5,7,8,10,11,16,18,19,20,22,23,32] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound49463 : packedSelected [0,1,3,4,5,7,8,10,11,16,18,19,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env49464 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,16400,32040,1025,32769,4161,21793,16,21762,8192,65,10589,5392,17664,64808,1365,41340,257,21792,46093,63068]

theorem envBound49464 : H12AffineFastState.Bounded env49464 := by
  intro p hp
  have h : env49464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49463_49464 : H12AffineEnvironment.transform 16 16400 env49463 = env49464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env49463 == env49464) = true)

theorem identity49464 : scanCanonicalize (H12AffineFastState.compose env49464 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound49464 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49465 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,16400,32040,1025,29789,4161,21793,16,21762,8192,65,10589,5392,17664,2420,1365,21792,257,21792,16465,512]

theorem envBound49465 : H12AffineFastState.Bounded env49465 := by
  intro p hp
  have h : env49465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49464_49465 : H12AffineEnvironment.transform 14 29788 env49464 = env49465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env49464 == env49465) = true)

theorem identity49465 : scanCanonicalize (H12AffineFastState.compose env49465 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound49465 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env49466 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5157,8313,8203,5173,10509,1025,8312,4161,260,16,295,8192,65,10589,5392,4389,2420,1365,261,257,261,5236,512]

theorem envBound49466 : H12AffineFastState.Bounded env49466 := by
  intro p hp
  have h : env49466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49465_49466 : H12AffineEnvironment.transform 13 5157 env49465 = env49466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env49465 == env49466) = true)

theorem identity49466 : scanCanonicalize (H12AffineFastState.compose env49466 (packedSelected [3,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 2057) := by decide +kernel

theorem selectedBound49466 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env49467 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,2057,5157,2160,2050,5173,260,1025,2161,4161,260,16,295,2057,65,340,5392,4389,2420,1365,261,257,261,5236,512]

theorem envBound49467 : H12AffineFastState.Bounded env49467 := by
  intro p hp
  have h : env49467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49466_49467 : H12AffineEnvironment.transform 12 2057 env49466 = env49467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env49466 == env49467) = true)

theorem identity49467 : scanCanonicalize (H12AffineFastState.compose env49467 (packedSelected [5,8,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 340) := by decide +kernel

theorem selectedBound49467 : packedSelected [5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env49468 : List Nat := [2,4,8,16,32,64,8,256,512,1024,340,4096,349,5157,292,342,5173,260,1025,293,4161,260,16,295,349,65,340,5392,4389,32,1365,261,257,261,5236,512]

theorem envBound49468 : H12AffineFastState.Bounded env49468 := by
  intro p hp
  have h : env49468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49467_49468 : H12AffineEnvironment.transform 10 340 env49467 = env49468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 340 env49467 == env49468) = true)

theorem identity49468 : scanCanonicalize (H12AffineFastState.compose env49468 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound49468 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49469 : List Nat := [2,4,8,16,32,64,8,85,512,1024,1,4096,8,5157,113,3,5173,81,1025,112,4161,81,16,114,8,65,1,5189,4208,32,1024,80,84,80,5236,512]

theorem envBound49469 : H12AffineFastState.Bounded env49469 := by
  intro p hp
  have h : env49469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49468_49469 : H12AffineEnvironment.transform 7 85 env49468 = env49469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env49468 == env49469) = true)

theorem identity49469 : scanCanonicalize (H12AffineFastState.compose env49469 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound49469 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env49470 : List Nat := [2,4,8,16,32,64,8,85,512,37,1,4096,8,4096,113,3,4112,81,36,112,4161,81,16,114,8,65,1,4192,4208,32,37,80,84,80,4177,512]

theorem envBound49470 : H12AffineFastState.Bounded env49470 := by
  intro p hp
  have h : env49470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49469_49470 : H12AffineEnvironment.transform 9 37 env49469 = env49470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env49469 == env49470) = true)

theorem identity49470 : scanCanonicalize (H12AffineFastState.compose env49470 (packedSelected [12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49470 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env49471 : List Nat := [2,4,8,16,32,17,8,4,512,37,1,4096,8,4096,32,3,4112,0,36,33,4112,0,16,35,8,16,1,4145,4129,32,37,1,5,1,4096,512]

theorem envBound49471 : H12AffineFastState.Bounded env49471 := by
  intro p hp
  have h : env49471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49470_49471 : H12AffineEnvironment.transform 5 17 env49470 = env49471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49470 == env49471) = true)

theorem identity49471 : scanCanonicalize (H12AffineFastState.compose env49471 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 545) := by decide +kernel

theorem selectedBound49471 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env49472 : List Nat := [2,4,8,16,32,17,8,4,512,37,1,545,8,545,32,3,561,0,36,33,561,0,16,35,8,16,1,528,512,32,37,1,5,1,545,512]

theorem envBound49472 : H12AffineFastState.Bounded env49472 := by
  intro p hp
  have h : env49472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49471_49472 : H12AffineEnvironment.transform 11 545 env49471 = env49472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env49471 == env49472) = true)

theorem identity49472 : scanCanonicalize (H12AffineFastState.compose env49472 (packedSelected [2,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound49472 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env49473 : List Nat := [2,4,8,16,32,17,8,4,17,37,1,48,8,48,32,3,32,0,36,33,32,0,16,35,8,16,1,1,17,32,37,1,5,1,48,17]

theorem envBound49473 : H12AffineFastState.Bounded env49473 := by
  intro p hp
  have h : env49473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49472_49473 : H12AffineEnvironment.transform 8 17 env49472 = env49473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env49472 == env49473) = true)

theorem identity49473 : scanCanonicalize (H12AffineFastState.compose env49473 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49473 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49474 : List Nat := [2,4,8,16,1,17,8,4,17,4,1,17,8,17,1,3,1,0,5,0,1,0,16,2,8,16,1,1,17,1,4,1,5,1,17,17]

theorem envBound49474 : H12AffineFastState.Bounded env49474 := by
  intro p hp
  have h : env49474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49473_49474 : H12AffineEnvironment.transform 4 1 env49473 = env49474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49473 == env49474) = true)

theorem identity49474 : scanCanonicalize (H12AffineFastState.compose env49474 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound49474 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49475 : List Nat := [2,4,8,0,1,1,8,4,1,4,1,1,8,1,1,3,1,0,5,0,1,0,0,2,8,0,1,1,1,1,4,1,5,1,1,1]

theorem envBound49475 : H12AffineFastState.Bounded env49475 := by
  intro p hp
  have h : env49475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49474_49475 : H12AffineEnvironment.transform 3 0 env49474 = env49475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env49474 == env49475) = true)

theorem identity49475 : scanCanonicalize (H12AffineFastState.compose env49475 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound49475 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49476 : List Nat := [2,4,7,0,1,1,7,4,1,4,1,1,7,1,1,3,1,0,5,0,1,0,0,2,7,0,1,1,1,1,4,1,5,1,1,1]

theorem envBound49476 : H12AffineFastState.Bounded env49476 := by
  intro p hp
  have h : env49476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49475_49476 : H12AffineEnvironment.transform 2 7 env49475 = env49476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env49475 == env49476) = true)

def env49477 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,290152,272392,294201,21762,8193,65,398436,288825,17664,179513,292989,41340,257,21792,46092,297844]

theorem envBound49477 : H12AffineFastState.Bounded env49477 := by
  intro p hp
  have h : env49477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49461_49477 : H12AffineEnvironment.transform 6 9 env49461 = env49477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49461 == env49477) = true)

theorem identity49477 : scanCanonicalize (H12AffineFastState.compose env49477 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound49477 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env49478 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,35189,1025,32769,58397,41341,62540,21762,8193,65,171281,57676,17664,179513,61704,41340,257,21792,46092,513]

theorem envBound49478 : H12AffineFastState.Bounded env49478 := by
  intro p hp
  have h : env49478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49477_49478 : H12AffineEnvironment.transform 17 35189 env49477 = env49478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env49477 == env49478) = true)

theorem identity49478 : scanCanonicalize (H12AffineFastState.compose env49478 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound49478 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env49479 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,131072,32040,1025,29788,4160,21792,17,21762,8193,65,158028,5393,17664,149860,1365,21793,257,21792,16465,513]

theorem envBound49479 : H12AffineFastState.Bounded env49479 := by
  intro p hp
  have h : env49479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49478_49479 : H12AffineEnvironment.transform 14 29789 env49478 = env49479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env49478 == env49479) = true)

def env49480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,294321,2485308,8328,65,6705548,288944,2369760,179633,2102685,4491773,257,21793,46212,2175563]

theorem envBound49480 : H12AffineFastState.Bounded env49480 := by
  intro p hp
  have h : env49480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49392_49480 : H12AffineEnvironment.transform 22 294321 env49392 = env49480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 294321 env49392 == env49480) = true)

def env49481 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290272,4194304,294321,98780,8328,65,4340844,288944,17664,179633,292989,4491773,257,21793,46212,352171]

theorem envBound49481 : H12AffineFastState.Bounded env49481 := by
  intro p hp
  have h : env49481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49480_49481 : H12AffineEnvironment.transform 20 290272 env49480 = env49481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290272 env49480 == env49481) = true)

def env49482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290272,272512,294321,98780,8328,65,398572,288944,17664,179633,292989,41341,257,21793,46212,352171]

theorem envBound49482 : H12AffineFastState.Bounded env49482 := by
  intro p hp
  have h : env49482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49481_49482 : H12AffineEnvironment.transform 21 272512 env49481 = env49482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env49481 == env49482) = true)

def env49483 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290152,272392,294201,98644,8192,65,398436,288824,17664,179513,292989,41341,257,21793,46092,352035]

theorem envBound49483 : H12AffineFastState.Bounded env49483 := by
  intro p hp
  have h : env49483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49482_49483 : H12AffineEnvironment.transform 6 8 env49482 = env49483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49482 == env49483) = true)

theorem identity49483 : scanCanonicalize (H12AffineFastState.compose env49483 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound49483 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env49484 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,290152,272392,294201,98644,8192,65,283765,288824,17664,64808,292989,41341,257,21793,46092,352035]

theorem envBound49484 : H12AffineFastState.Bounded env49484 := by
  intro p hp
  have h : env49484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49483_49484 : H12AffineEnvironment.transform 16 16401 env49483 = env49484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env49483 == env49484) = true)

def env49485 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,5393,262144,1025,32769,276584,272392,272441,98644,8192,65,262517,277816,4096,43048,273789,41341,257,33,46092,330275]

theorem envBound49485 : H12AffineFastState.Bounded env49485 := by
  intro p hp
  have h : env49485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49484_49485 : H12AffineEnvironment.transform 13 5376 env49484 = env49485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env49484 == env49485) = true)

theorem identity49485 : scanCanonicalize (H12AffineFastState.compose env49485 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound49485 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49486 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,5393,35188,1025,32769,45340,41340,41293,98644,8192,65,34817,46156,4096,43048,41993,41341,257,33,46092,99159]

theorem envBound49486 : H12AffineFastState.Bounded env49486 := by
  intro p hp
  have h : env49486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49485_49486 : H12AffineEnvironment.transform 17 35188 env49485 = env49486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env49485 == env49486) = true)

theorem identity49486 : scanCanonicalize (H12AffineFastState.compose env49486 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound49486 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49487 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,5393,35188,1025,32769,45340,41340,41293,2,8192,65,34817,46156,4096,43048,41993,41341,257,33,46092,513]

theorem envBound49487 : H12AffineFastState.Bounded env49487 := by
  intro p hp
  have h : env49487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49486_49487 : H12AffineEnvironment.transform 15 33110 env49486 = env49487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env49486 == env49487) = true)

theorem identity49487 : scanCanonicalize (H12AffineFastState.compose env49487 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound49487 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49488 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8461,8283,5393,10361,1025,8460,4113,113,64,2,8192,65,10508,5441,4096,2341,1284,112,257,33,5377,513]

theorem envBound49488 : H12AffineFastState.Bounded env49488 := by
  intro p hp
  have h : env49488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49487_49488 : H12AffineEnvironment.transform 14 8461 env49487 = env49488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env49487 == env49488) = true)

theorem identity49488 : scanCanonicalize (H12AffineFastState.compose env49488 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound49488 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env49489 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,8312,8283,5220,10361,1025,8313,4113,113,64,2,8192,65,10361,5172,4096,2128,1137,112,116,33,5236,513]

theorem envBound49489 : H12AffineFastState.Bounded env49489 := by
  intro p hp
  have h : env49489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49488_49489 : H12AffineEnvironment.transform 7 117 env49488 = env49489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env49488 == env49489) = true)

theorem identity49489 : scanCanonicalize (H12AffineFastState.compose env49489 (packedSelected [1,3,5,8,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound49489 : packedSelected [1,3,5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env49490 : List Nat := [2,4,8,16,32,64,8,117,512,1024,80,4096,8192,5237,8312,8283,5220,8233,1025,8313,4113,113,64,2,8192,65,8233,5172,4096,0,1137,112,116,33,5236,513]

theorem envBound49490 : H12AffineFastState.Bounded env49490 := by
  intro p hp
  have h : env49490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49489_49490 : H12AffineEnvironment.transform 10 80 env49489 = env49490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env49489 == env49490) = true)

theorem identity49490 : scanCanonicalize (H12AffineFastState.compose env49490 (packedSelected [0,7,11,14] rootPS)) = affineNative (2^(12+1) ^^^ 4153) := by decide +kernel

theorem selectedBound49490 : packedSelected [0,7,11,14] rootPS < 2^1333 := by decide +kernel

def env49491 : List Nat := [2,4,8,16,32,64,8,117,512,1024,80,4096,4153,5237,4161,4194,5220,4112,1025,4160,4113,113,64,2,4153,65,4112,5172,4096,0,1137,112,116,33,5236,513]

theorem envBound49491 : H12AffineFastState.Bounded env49491 := by
  intro p hp
  have h : env49491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49490_49491 : H12AffineEnvironment.transform 12 4153 env49490 = env49491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4153 env49490 == env49491) = true)

theorem identity49491 : scanCanonicalize (H12AffineFastState.compose env49491 (packedSelected [1,2,8] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound49491 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env49492 : List Nat := [2,4,8,16,32,64,8,117,512,101,80,4096,4153,4112,4161,4194,4097,4112,100,4160,4113,113,64,2,4153,65,4112,4177,4096,0,20,112,116,33,4113,513]

theorem envBound49492 : H12AffineFastState.Bounded env49492 := by
  intro p hp
  have h : env49492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49491_49492 : H12AffineEnvironment.transform 9 101 env49491 = env49492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env49491 == env49492) = true)

theorem identity49492 : scanCanonicalize (H12AffineFastState.compose env49492 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound49492 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env49493 : List Nat := [2,4,8,16,32,64,8,117,512,101,80,64,121,80,1,34,65,80,100,0,81,113,64,2,121,65,80,17,64,0,20,112,116,33,81,513]

theorem envBound49493 : H12AffineFastState.Bounded env49493 := by
  intro p hp
  have h : env49493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49492_49493 : H12AffineEnvironment.transform 11 64 env49492 = env49493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env49492 == env49493) = true)

def env49494 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,5392,262144,1025,32769,276585,272392,272440,98644,8192,65,262516,277817,4097,43049,273788,41341,257,32,46092,330274]

theorem envBound49494 : H12AffineFastState.Bounded env49494 := by
  intro p hp
  have h : env49494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49484_49494 : H12AffineEnvironment.transform 13 5377 env49484 = env49494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env49484 == env49494) = true)

theorem identity49494 : scanCanonicalize (H12AffineFastState.compose env49494 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound49494 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49495 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,5392,262144,1025,8541,276585,272392,272440,73736,8192,65,262516,277817,4097,2421,273788,33,257,32,5456,330274]

theorem envBound49495 : H12AffineFastState.Bounded env49495 := by
  intro p hp
  have h : env49495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49494_49495 : H12AffineEnvironment.transform 14 8540 env49494 = env49495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env49494 == env49495) = true)

theorem identity49495 : scanCanonicalize (H12AffineFastState.compose env49495 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound49495 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env49496 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8202,5392,262144,1025,8541,276585,272392,272440,2,8192,65,262516,277817,4097,2421,273788,33,257,32,5456,272936]

theorem envBound49496 : H12AffineFastState.Bounded env49496 := by
  intro p hp
  have h : env49496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49495_49496 : H12AffineEnvironment.transform 15 8202 env49495 = env49496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env49495 == env49496) = true)

theorem identity49496 : scanCanonicalize (H12AffineFastState.compose env49496 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 7432) := by decide +kernel

theorem selectedBound49496 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env49497 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7432,5377,7252,7426,5392,262144,1025,7253,263521,267520,267568,2,7432,65,262516,262193,4097,2421,266356,33,257,32,5456,268064]

theorem envBound49497 : H12AffineFastState.Bounded env49497 := by
  intro p hp
  have h : env49497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49496_49497 : H12AffineEnvironment.transform 12 7432 env49496 = env49497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7432 env49496 == env49497) = true)

theorem identity49497 : scanCanonicalize (H12AffineFastState.compose env49497 (packedSelected [1,4,6,8,9,10,11,14,15] rootPS)) = affineNative (2^(17+1) ^^^ 3345) := by decide +kernel

theorem selectedBound49497 : packedSelected [1,4,6,8,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env49498 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7432,5377,7252,7426,5392,3345,1025,7253,2160,6161,6177,2,7432,65,3173,3360,4097,2421,7525,33,257,32,5456,6705]

theorem envBound49498 : H12AffineFastState.Bounded env49498 := by
  intro p hp
  have h : env49498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49497_49498 : H12AffineEnvironment.transform 17 3345 env49497 = env49498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3345 env49497 == env49498) = true)

theorem identity49498 : scanCanonicalize (H12AffineFastState.compose env49498 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound49498 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env49499 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,7293,5236,7252,7287,5221,3172,1025,7253,2160,6161,6177,2,7293,65,3173,3157,4097,2048,7184,33,116,32,5157,6705]

theorem envBound49499 : H12AffineFastState.Bounded env49499 := by
  intro p hp
  have h : env49499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49498_49499 : H12AffineEnvironment.transform 7 117 env49498 = env49499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env49498 == env49499) = true)

theorem identity49499 : scanCanonicalize (H12AffineFastState.compose env49499 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound49499 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env49500 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,3108,89,2128,112,83,2113,3172,1025,113,2160,1077,1029,2,89,65,3173,3157,3109,2048,52,33,116,32,2049,1557]

theorem envBound49500 : H12AffineFastState.Bounded env49500 := by
  intro p hp
  have h : env49500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49499_49500 : H12AffineEnvironment.transform 11 3108 env49499 = env49500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env49499 == env49500) = true)

theorem identity49500 : scanCanonicalize (H12AffineFastState.compose env49500 (packedSelected [2,3,4,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound49500 : packedSelected [2,3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env49501 : List Nat := [2,4,8,16,32,64,8,117,512,565,2048,2577,89,2128,112,83,2113,2641,564,113,2160,512,560,2,89,65,2640,2656,2576,2048,52,33,116,32,2049,32]

theorem envBound49501 : H12AffineFastState.Bounded env49501 := by
  intro p hp
  have h : env49501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49500_49501 : H12AffineEnvironment.transform 9 565 env49500 = env49501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env49500 == env49501) = true)

theorem identity49501 : scanCanonicalize (H12AffineFastState.compose env49501 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound49501 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49502 : List Nat := [2,4,8,16,32,49,8,4,512,565,2048,2577,40,2081,1,34,2096,2592,564,0,2049,512,560,2,40,48,2593,2577,2576,2048,52,33,5,32,2049,32]

theorem envBound49502 : H12AffineFastState.Bounded env49502 := by
  intro p hp
  have h : env49502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49501_49502 : H12AffineEnvironment.transform 5 49 env49501 = env49502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env49501 == env49502) = true)

theorem identity49502 : scanCanonicalize (H12AffineFastState.compose env49502 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound49502 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env49503 : List Nat := [2,4,8,16,32,49,8,4,512,565,33,560,40,0,1,34,17,513,564,0,32,512,560,2,40,48,512,560,561,33,52,33,5,32,32,32]

theorem envBound49503 : H12AffineFastState.Bounded env49503 := by
  intro p hp
  have h : env49503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49502_49503 : H12AffineEnvironment.transform 10 33 env49502 = env49503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env49502 == env49503) = true)

theorem identity49503 : scanCanonicalize (H12AffineFastState.compose env49503 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound49503 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env49504 : List Nat := [2,4,8,16,16,1,8,4,512,517,17,512,24,0,1,18,17,513,516,0,16,512,512,2,24,0,512,512,513,17,4,17,5,16,16,16]

theorem envBound49504 : H12AffineFastState.Bounded env49504 := by
  intro p hp
  have h : env49504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49503_49504 : H12AffineEnvironment.transform 4 16 env49503 = env49504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env49503 == env49504) = true)

theorem identity49504 : scanCanonicalize (H12AffineFastState.compose env49504 (packedSelected [2,6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound49504 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49505 : List Nat := [2,4,8,1,1,1,8,4,512,517,0,512,9,0,1,3,0,513,516,0,1,512,512,2,9,0,512,512,513,0,4,0,5,1,1,1]

theorem envBound49505 : H12AffineFastState.Bounded env49505 := by
  intro p hp
  have h : env49505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49504_49505 : H12AffineEnvironment.transform 3 1 env49504 = env49505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env49504 == env49505) = true)

theorem identity49505 : scanCanonicalize (H12AffineFastState.compose env49505 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound49505 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49506 : List Nat := [2,4,8,1,1,1,8,4,1,4,0,1,9,0,1,3,0,0,5,0,1,1,1,2,9,0,1,1,0,0,4,0,5,1,1,1]

theorem envBound49506 : H12AffineFastState.Bounded env49506 := by
  intro p hp
  have h : env49506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49505_49506 : H12AffineEnvironment.transform 8 1 env49505 = env49506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env49505 == env49506) = true)

theorem identity49506 : scanCanonicalize (H12AffineFastState.compose env49506 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound49506 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49507 : List Nat := [2,0,8,1,1,1,8,0,1,0,0,1,9,0,1,3,0,0,1,0,1,1,1,2,9,0,1,1,0,0,0,0,1,1,1,1]

theorem envBound49507 : H12AffineFastState.Bounded env49507 := by
  intro p hp
  have h : env49507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49506_49507 : H12AffineEnvironment.transform 1 0 env49506 = env49507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env49506 == env49507) = true)

def env49508 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,272393,294200,98645,8193,65,398437,288825,17664,179512,292989,41341,257,21793,46093,352034]

theorem envBound49508 : H12AffineFastState.Bounded env49508 := by
  intro p hp
  have h : env49508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49482_49508 : H12AffineEnvironment.transform 6 9 env49482 = env49508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49482 == env49508) = true)

theorem identity49508 : scanCanonicalize (H12AffineFastState.compose env49508 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 89379) := by decide +kernel

theorem selectedBound49508 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env49509 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89379,1025,32769,77898,95530,73755,98645,8193,65,215366,79130,17664,179512,75102,41341,257,21793,46093,513]

theorem envBound49509 : H12AffineFastState.Bounded env49509 := by
  intro p hp
  have h : env49509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49508_49509 : H12AffineEnvironment.transform 17 89379 env49508 = env49509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89379 env49508 == env49509) = true)

theorem identity49509 : scanCanonicalize (H12AffineFastState.compose env49509 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound49509 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env49510 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,35189,1025,32769,58396,41340,62541,21763,8193,65,171280,57676,17664,179512,61704,41341,257,21793,46093,513]

theorem envBound49510 : H12AffineFastState.Bounded env49510 := by
  intro p hp
  have h : env49510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49509_49510 : H12AffineEnvironment.transform 15 54358 env49509 = env49510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env49509 == env49510) = true)

theorem identity49510 : scanCanonicalize (H12AffineFastState.compose env49510 (packedSelected [0,1,3,4,5,8,9,10,16,17,18,19,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound49510 : packedSelected [0,1,3,4,5,8,9,10,16,17,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env49511 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33110,131072,35189,1025,32769,45340,41340,41293,3,8193,65,171280,46156,4096,179512,41992,41341,257,33,46093,513]

theorem envBound49511 : H12AffineFastState.Bounded env49511 := by
  intro p hp
  have h : env49511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49510_49511 : H12AffineEnvironment.transform 13 5376 env49510 = env49511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env49510 == env49511) = true)

theorem identity49511 : scanCanonicalize (H12AffineFastState.compose env49511 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49511 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49512 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,32768,33031,131072,35108,1025,32769,45340,41261,41244,3,8193,16,171280,46109,4096,179512,41992,41260,257,33,46093,513]

theorem envBound49512 : H12AffineFastState.Bounded env49512 := by
  intro p hp
  have h : env49512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49511_49512 : H12AffineEnvironment.transform 5 17 env49511 = env49512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49511 == env49512) = true)

theorem identity49512 : scanCanonicalize (H12AffineFastState.compose env49512 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound49512 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49513 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8461,8202,131072,10281,1025,8460,4113,32,17,3,8193,16,146461,5392,4096,138293,1285,33,257,33,5376,513]

theorem envBound49513 : H12AffineFastState.Bounded env49513 := by
  intro p hp
  have h : env49513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49512_49513 : H12AffineEnvironment.transform 14 8461 env49512 = env49513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env49512 == env49513) = true)

theorem identity49513 : scanCanonicalize (H12AffineFastState.compose env49513 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 13593) := by decide +kernel

theorem selectedBound49513 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env49514 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8461,8202,13593,10281,1025,8460,4113,32,17,3,8193,16,2308,5392,4096,10540,1285,33,257,33,5376,513]

theorem envBound49514 : H12AffineFastState.Bounded env49514 := by
  intro p hp
  have h : env49514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49513_49514 : H12AffineEnvironment.transform 16 13593 env49513 = env49514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13593 env49513 == env49514) = true)

def env49515 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290272,272513,294321,98780,8328,65,398573,288944,17664,179633,292989,41340,257,21793,46212,352171]

theorem envBound49515 : H12AffineFastState.Bounded env49515 := by
  intro p hp
  have h : env49515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49481_49515 : H12AffineEnvironment.transform 21 272513 env49481 = env49515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env49481 == env49515) = true)

theorem identity49515 : scanCanonicalize (H12AffineFastState.compose env49515 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 32160) := by decide +kernel

theorem selectedBound49515 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49516 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,4160,21793,17,98780,8328,65,158029,5392,17664,179633,1501,41340,257,21793,46212,74251]

theorem envBound49516 : H12AffineFastState.Bounded env49516 := by
  intro p hp
  have h : env49516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49515_49516 : H12AffineEnvironment.transform 17 32160 env49515 = env49516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env49515 == env49516) = true)

theorem identity49516 : scanCanonicalize (H12AffineFastState.compose env49516 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound49516 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env49517 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32160,1025,32769,4160,21793,17,41430,8328,65,158029,5392,17664,179633,1501,41340,257,21793,46212,513]

theorem envBound49517 : H12AffineFastState.Bounded env49517 := by
  intro p hp
  have h : env49517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49516_49517 : H12AffineEnvironment.transform 15 8202 env49516 = env49517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env49516 == env49517) = true)

theorem identity49517 : scanCanonicalize (H12AffineFastState.compose env49517 (packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS)) = affineNative (2^(16+1) ^^^ 24981) := by decide +kernel

theorem selectedBound49517 : packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env49518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,24981,32160,1025,32769,4160,21793,17,41430,8328,65,2264,5392,17664,56356,1501,41340,257,21793,46212,513]

theorem envBound49518 : H12AffineFastState.Bounded env49518 := by
  intro p hp
  have h : env49518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49517_49518 : H12AffineEnvironment.transform 16 24981 env49517 = env49518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24981 env49517 == env49518) = true)

theorem identity49518 : scanCanonicalize (H12AffineFastState.compose env49518 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound49518 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env49519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29709,8202,24981,32160,1025,29708,4160,21793,17,21979,8328,65,2264,5392,17664,10281,1501,21873,257,21793,16521,513]

theorem envBound49519 : H12AffineFastState.Bounded env49519 := by
  intro p hp
  have h : env49519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49518_49519 : H12AffineEnvironment.transform 14 29709 env49518 = env49519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env49518 == env49519) = true)

theorem identity49519 : scanCanonicalize (H12AffineFastState.compose env49519 (packedSelected [2,3,6,10,17,18,19,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound49519 : packedSelected [2,3,6,10,17,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env49520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,16384,21896,399,16400,23589,1025,21897,4160,21793,17,21979,269,65,2264,5392,17664,2476,1501,21873,257,21793,16521,513]

theorem envBound49520 : H12AffineFastState.Bounded env49520 := by
  intro p hp
  have h : env49520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49519_49520 : H12AffineEnvironment.transform 12 389 env49519 = env49520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env49519 == env49520) = true)

theorem identity49520 : scanCanonicalize (H12AffineFastState.compose env49520 (packedSelected [3,4,6,7,8,10,11,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound49520 : packedSelected [3,4,6,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env49521 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,121,16384,21620,115,16400,23589,1025,21621,4160,21725,17,21543,241,65,2264,5356,17660,2128,1057,21645,253,21725,16521,513]

theorem envBound49521 : H12AffineFastState.Bounded env49521 := by
  intro p hp
  have h : env49521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49520_49521 : H12AffineEnvironment.transform 7 252 env49520 = env49521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env49520 == env49521) = true)

theorem identity49521 : scanCanonicalize (H12AffineFastState.compose env49521 (packedSelected [0,2,5,6,8,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5372) := by decide +kernel

theorem selectedBound49521 : packedSelected [0,2,5,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env49522 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,121,5372,136,115,5356,2265,1025,137,4160,33,17,219,241,65,2264,5356,4096,2128,1057,113,253,33,5237,513]

theorem envBound49522 : H12AffineFastState.Bounded env49522 := by
  intro p hp
  have h : env49522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49521_49522 : H12AffineEnvironment.transform 13 5372 env49521 = env49522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5372 env49521 == env49522) = true)

theorem identity49522 : scanCanonicalize (H12AffineFastState.compose env49522 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49522 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env49523 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,40,5293,136,34,5309,2184,1025,137,4113,33,17,138,160,16,2185,5309,4096,2049,1057,32,172,33,5156,513]

theorem envBound49523 : H12AffineFastState.Bounded env49523 := by
  intro p hp
  have h : env49523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49522_49523 : H12AffineEnvironment.transform 5 17 env49522 = env49523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49522 == env49523) = true)

theorem identity49523 : scanCanonicalize (H12AffineFastState.compose env49523 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound49523 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49524 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5156,1,34,5172,2049,1025,0,4113,33,17,3,41,16,2048,5172,4096,2049,1057,32,37,33,5156,513]

theorem envBound49524 : H12AffineFastState.Bounded env49524 := by
  intro p hp
  have h : env49524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49523_49524 : H12AffineEnvironment.transform 6 9 env49523 = env49524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49523 == env49524) = true)

def env49525 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,40,1044,1,34,1028,2049,1025,0,33,33,17,3,41,16,2048,1028,48,2049,1057,32,37,33,1044,513]

theorem envBound49525 : H12AffineFastState.Bounded env49525 := by
  intro p hp
  have h : env49525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49524_49525 : H12AffineEnvironment.transform 11 48 env49524 = env49525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env49524 == env49525) = true)

theorem identity49525 : scanCanonicalize (H12AffineFastState.compose env49525 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound49525 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49526 : List Nat := [2,4,8,16,32,17,9,36,512,21,2048,48,40,1,1,34,17,2049,20,0,33,33,17,3,41,16,2048,17,48,2049,52,32,37,33,1,513]

theorem envBound49526 : H12AffineFastState.Bounded env49526 := by
  intro p hp
  have h : env49526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49525_49526 : H12AffineEnvironment.transform 9 21 env49525 = env49526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env49525 == env49526) = true)

def env49527 : List Nat := [2,4,8,16,0,17,9,4,512,21,2048,16,8,1,1,2,17,2049,20,0,1,1,17,3,9,16,2048,17,16,2049,20,0,5,1,1,513]

theorem envBound49527 : H12AffineFastState.Bounded env49527 := by
  intro p hp
  have h : env49527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49526_49527 : H12AffineEnvironment.transform 4 0 env49526 = env49527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env49526 == env49527) = true)

theorem identity49527 : scanCanonicalize (H12AffineFastState.compose env49527 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound49527 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49528 : List Nat := [2,4,8,16,0,17,9,4,512,21,522,16,8,1,1,2,17,523,20,0,1,1,17,3,9,16,522,17,16,523,20,0,5,1,1,513]

theorem envBound49528 : H12AffineFastState.Bounded env49528 := by
  intro p hp
  have h : env49528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49527_49528 : H12AffineEnvironment.transform 10 522 env49527 = env49528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env49527 == env49528) = true)

def leafEnv49528 : List Nat := [2,4,8,16,0,17,9,4,512,21,522,16,8,1,1,2,17,523,20,0,1,1,17,3,21,9,1,16,522,17,16,523,20,0,5,1,5,3,1,513,1,1,0]

def active49528 : List Nat := [0,1,2,3,8]

def tree49528 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49528 : H12WitnessSearch.Good tree49528 := H12GlobalWitnessIndex.good

theorem leafIdentity49528 : H12AffineFastState.composeSystem env49528 rootObs = leafEnv49528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49528 rootObs == leafEnv49528) = true)

theorem terminalChecked49528 : H12PackedTerminal.terminalCheckFast leafEnv49528 active49528 tree49528 = true := by decide +kernel

def env49529 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,17,9,1,1,3,17,2049,20,0,0,0,17,3,8,16,2048,17,17,2049,21,1,4,0,1,513]

theorem envBound49529 : H12AffineFastState.Bounded env49529 := by
  intro p hp
  have h : env49529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49526_49529 : H12AffineEnvironment.transform 4 1 env49526 = env49529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49526 == env49529) = true)

theorem identity49529 : scanCanonicalize (H12AffineFastState.compose env49529 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound49529 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49530 : List Nat := [2,4,8,16,1,17,9,5,512,21,1,17,9,1,1,3,17,0,20,0,0,0,17,3,8,16,1,17,17,0,21,1,4,0,1,513]

theorem envBound49530 : H12AffineFastState.Bounded env49530 := by
  intro p hp
  have h : env49530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49529_49530 : H12AffineEnvironment.transform 10 1 env49529 = env49530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env49529 == env49530) = true)

def leafEnv49530 : List Nat := [2,4,8,16,1,17,9,5,512,21,1,17,9,1,1,3,17,0,20,0,0,0,17,3,20,8,1,16,1,17,17,0,21,1,4,0,5,2,1,513,1,0,0]

def active49530 : List Nat := [0,1,2,3,8]

def tree49530 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49530 : H12WitnessSearch.Good tree49530 := H12GlobalWitnessIndex.good

theorem leafIdentity49530 : H12AffineFastState.composeSystem env49530 rootObs = leafEnv49530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49530 rootObs == leafEnv49530) = true)

theorem terminalChecked49530 : H12PackedTerminal.terminalCheckFast leafEnv49530 active49530 tree49530 = true := by decide +kernel

def env49531 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,40,1045,1,34,1029,2049,1025,0,32,33,17,3,41,16,2048,1029,49,2049,1057,32,37,33,1045,513]

theorem envBound49531 : H12AffineFastState.Bounded env49531 := by
  intro p hp
  have h : env49531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49524_49531 : H12AffineEnvironment.transform 11 49 env49524 = env49531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env49524 == env49531) = true)

theorem identity49531 : scanCanonicalize (H12AffineFastState.compose env49531 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49531 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49532 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,16,9,1045,1,3,1029,2049,1025,0,1,0,17,3,8,16,2048,1029,16,2049,1024,1,4,0,1045,513]

theorem envBound49532 : H12AffineFastState.Bounded env49532 := by
  intro p hp
  have h : env49532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49531_49532 : H12AffineEnvironment.transform 4 1 env49531 = env49532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49531 == env49532) = true)

def env49533 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,16,9,1,1,3,17,2049,21,0,1,0,17,3,8,16,2048,17,16,2049,20,1,4,0,1,513]

theorem envBound49533 : H12AffineFastState.Bounded env49533 := by
  intro p hp
  have h : env49533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49532_49533 : H12AffineEnvironment.transform 9 20 env49532 = env49533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env49532 == env49533) = true)

theorem identity49533 : scanCanonicalize (H12AffineFastState.compose env49533 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound49533 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49534 : List Nat := [2,4,8,16,1,17,9,5,512,20,523,16,9,1,1,3,17,522,21,0,1,0,17,3,8,16,523,17,16,522,20,1,4,0,1,513]

theorem envBound49534 : H12AffineFastState.Bounded env49534 := by
  intro p hp
  have h : env49534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49533_49534 : H12AffineEnvironment.transform 10 523 env49533 = env49534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env49533 == env49534) = true)

def leafEnv49534 : List Nat := [2,4,8,16,1,17,9,5,512,20,523,16,9,1,1,3,17,522,21,0,1,0,17,3,21,8,1,16,523,17,16,522,20,1,4,0,5,2,1,513,1,1,0]

def active49534 : List Nat := [0,1,2,3,8]

def tree49534 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49534 : H12WitnessSearch.Good tree49534 := H12GlobalWitnessIndex.good

theorem leafIdentity49534 : H12AffineFastState.composeSystem env49534 rootObs = leafEnv49534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49534 rootObs == leafEnv49534) = true)

theorem terminalChecked49534 : H12PackedTerminal.terminalCheckFast leafEnv49534 active49534 tree49534 = true := by decide +kernel

def env49535 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,16,9,0,1,3,16,2049,20,0,1,0,17,3,8,16,2048,16,16,2049,21,1,4,0,0,513]

theorem envBound49535 : H12AffineFastState.Bounded env49535 := by
  intro p hp
  have h : env49535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49532_49535 : H12AffineEnvironment.transform 9 21 env49532 = env49535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env49532 == env49535) = true)

theorem identity49535 : scanCanonicalize (H12AffineFastState.compose env49535 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound49535 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49536 : List Nat := [2,4,8,16,1,17,9,5,512,21,0,16,9,0,1,3,16,1,20,0,1,0,17,3,8,16,0,16,16,1,21,1,4,0,0,513]

theorem envBound49536 : H12AffineFastState.Bounded env49536 := by
  intro p hp
  have h : env49536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49535_49536 : H12AffineEnvironment.transform 10 0 env49535 = env49536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env49535 == env49536) = true)

def leafEnv49536 : List Nat := [2,4,8,16,1,17,9,5,512,21,0,16,9,0,1,3,16,1,20,0,1,0,17,3,20,8,1,16,0,16,16,1,21,1,4,0,5,2,0,513,1,1,0]

def active49536 : List Nat := [0,1,2,3,8]

def tree49536 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49536 : H12WitnessSearch.Good tree49536 := H12GlobalWitnessIndex.good

theorem leafIdentity49536 : H12AffineFastState.composeSystem env49536 rootObs = leafEnv49536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49536 rootObs == leafEnv49536) = true)

theorem terminalChecked49536 : H12PackedTerminal.terminalCheckFast leafEnv49536 active49536 tree49536 = true := by decide +kernel

def env49537 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290273,4194304,294321,98781,8328,65,4340845,288944,17665,179633,292988,4491773,257,21793,46212,352170]

theorem envBound49537 : H12AffineFastState.Bounded env49537 := by
  intro p hp
  have h : env49537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49480_49537 : H12AffineEnvironment.transform 20 290273 env49480 = env49537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290273 env49480 == env49537) = true)

def env49538 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290273,272512,294321,98781,8328,65,398573,288944,17665,179633,292988,41341,257,21793,46212,352170]

theorem envBound49538 : H12AffineFastState.Bounded env49538 := by
  intro p hp
  have h : env49538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49537_49538 : H12AffineEnvironment.transform 21 272512 env49537 = env49538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env49537 == env49538) = true)

theorem identity49538 : scanCanonicalize (H12AffineFastState.compose env49538 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound49538 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49539 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,290273,272512,294321,95496,8328,65,398573,288944,17665,149860,292988,21928,257,21793,16465,352170]

theorem envBound49539 : H12AffineFastState.Bounded env49539 := by
  intro p hp
  have h : env49539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49538_49539 : H12AffineEnvironment.transform 14 29909 env49538 = env49539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env49538 == env49539) = true)

def env49540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,262144,1025,8660,276705,272512,272561,73736,8328,65,398573,277936,4097,138340,273788,168,257,33,5457,330410]

theorem envBound49540 : H12AffineFastState.Bounded env49540 := by
  intro p hp
  have h : env49540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49539_49540 : H12AffineEnvironment.transform 13 5376 env49539 = env49540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env49539 == env49540) = true)

theorem identity49540 : scanCanonicalize (H12AffineFastState.compose env49540 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound49540 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49541 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10281,1025,8660,4296,169,152,73736,8328,65,146628,5529,4097,138340,1365,168,257,33,5457,74371]

theorem envBound49541 : H12AffineFastState.Bounded env49541 := by
  intro p hp
  have h : env49541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49540_49541 : H12AffineEnvironment.transform 17 10281 env49540 = env49541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env49540 == env49541) = true)

theorem identity49541 : scanCanonicalize (H12AffineFastState.compose env49541 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound49541 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env49542 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,79130,10281,1025,8660,4296,169,152,73736,8328,65,68062,5529,4097,76158,1365,168,257,33,5457,74371]

theorem envBound49542 : H12AffineFastState.Bounded env49542 := by
  intro p hp
  have h : env49542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49541_49542 : H12AffineEnvironment.transform 16 79130 env49541 = env49542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env49541 == env49542) = true)

theorem identity49542 : scanCanonicalize (H12AffineFastState.compose env49542 (packedSelected [0,2,3,4,5,6,9,10,11,18,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound49542 : packedSelected [0,2,3,4,5,6,9,10,11,18,20,27] rootPS < 2^1333 := by decide +kernel

def env49543 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,478,13508,10281,1025,8660,4296,169,152,8662,8328,65,2048,5529,4097,10400,1365,168,257,33,5457,9053]

theorem envBound49543 : H12AffineFastState.Bounded env49543 := by
  intro p hp
  have h : env49543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49542_49543 : H12AffineEnvironment.transform 15 478 env49542 = env49543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env49542 == env49543) = true)

def env49544 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,262144,1025,8661,276704,272512,272560,73737,8328,65,398573,277937,4096,138341,273789,169,257,32,5456,330411]

theorem envBound49544 : H12AffineFastState.Bounded env49544 := by
  intro p hp
  have h : env49544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49539_49544 : H12AffineEnvironment.transform 13 5377 env49539 = env49544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env49539 == env49544) = true)

theorem identity49544 : scanCanonicalize (H12AffineFastState.compose env49544 (packedSelected [0,1,3,4,5,7,8,10,11,16,18,19,20,22,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 204219) := by decide +kernel

theorem selectedBound49544 : packedSelected [0,1,3,4,5,7,8,10,11,16,18,19,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env49545 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,204219,1025,8661,206171,210235,210187,73737,8328,65,67926,204810,4096,138341,209094,169,257,32,5456,136976]

theorem envBound49545 : H12AffineFastState.Bounded env49545 := by
  intro p hp
  have h : env49545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49544_49545 : H12AffineEnvironment.transform 17 204219 env49544 = env49545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 204219 env49544 == env49545) = true)

theorem identity49545 : scanCanonicalize (H12AffineFastState.compose env49545 (packedSelected [3,4,7,9,10,14,16,20,24,26,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound49545 : packedSelected [3,4,7,9,10,14,16,20,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env49546 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,5393,67754,1025,8661,77898,73770,73754,73737,8328,65,67926,79131,4096,2420,75223,169,257,32,5456,513]

theorem envBound49546 : H12AffineFastState.Bounded env49546 := by
  intro p hp
  have h : env49546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49545_49546 : H12AffineEnvironment.transform 16 5393 env49545 = env49546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env49545 == env49546) = true)

theorem identity49546 : scanCanonicalize (H12AffineFastState.compose env49546 (packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound49546 : packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env49547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8202,5393,10400,1025,8661,4160,32,16,3,8328,65,10588,5393,4096,2420,1501,169,257,32,5456,513]

theorem envBound49547 : H12AffineFastState.Bounded env49547 := by
  intro p hp
  have h : env49547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49546_49547 : H12AffineEnvironment.transform 15 8202 env49546 = env49547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env49546 == env49547) = true)

theorem identity49547 : scanCanonicalize (H12AffineFastState.compose env49547 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound49547 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env49548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,89,5377,397,83,5393,2297,1025,396,4160,32,16,3,209,65,2309,5393,4096,2420,1501,169,257,32,5456,513]

theorem envBound49548 : H12AffineFastState.Bounded env49548 := by
  intro p hp
  have h : env49548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49547_49548 : H12AffineEnvironment.transform 12 89 env49547 = env49548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env49547 == env49548) = true)

theorem identity49548 : scanCanonicalize (H12AffineFastState.compose env49548 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound49548 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env49549 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,89,5377,260,83,5393,2160,1025,261,4160,32,16,3,88,65,2309,5393,4096,2420,1364,32,257,32,5456,513]

theorem envBound49549 : H12AffineFastState.Bounded env49549 := by
  intro p hp
  have h : env49549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49548_49549 : H12AffineEnvironment.transform 6 9 env49548 = env49549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49548 == env49549) = true)

def env49550 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290273,272513,294321,98781,8328,65,398572,288944,17665,179633,292988,41340,257,21793,46212,352170]

theorem envBound49550 : H12AffineFastState.Bounded env49550 := by
  intro p hp
  have h : env49550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49537_49550 : H12AffineEnvironment.transform 21 272513 env49537 = env49550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env49537 == env49550) = true)

theorem identity49550 : scanCanonicalize (H12AffineFastState.compose env49550 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound49550 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49551 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,58516,41460,62660,98781,8328,65,171417,57797,17665,179633,61705,41340,257,21793,46212,120543]

theorem envBound49551 : H12AffineFastState.Bounded env49551 := by
  intro p hp
  have h : env49551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49550_49551 : H12AffineEnvironment.transform 17 35189 env49550 = env49551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env49550 == env49551) = true)

def env49552 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,35189,1025,32769,45340,41460,41292,98781,8328,65,171417,46157,4233,179633,42113,41340,257,169,46212,99159]

theorem envBound49552 : H12AffineFastState.Bounded env49552 := by
  intro p hp
  have h : env49552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49551_49552 : H12AffineEnvironment.transform 13 5512 env49551 = env49552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env49551 == env49552) = true)

theorem identity49552 : scanCanonicalize (H12AffineFastState.compose env49552 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound49552 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49553 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,35189,1025,32769,45340,41341,41292,98644,8193,65,171280,46157,4096,179512,41992,41340,257,32,46093,99159]

theorem envBound49553 : H12AffineFastState.Bounded env49553 := by
  intro p hp
  have h : env49553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49552_49553 : H12AffineEnvironment.transform 6 9 env49552 = env49553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49552 == env49553) = true)

theorem identity49553 : scanCanonicalize (H12AffineFastState.compose env49553 (packedSelected [1,5,8,15,16,19,20,24,26,38] rootPS)) = affineNative (2^(16+1) ^^^ 103447) := by decide +kernel

theorem selectedBound49553 : packedSelected [1,5,8,15,16,19,20,24,26,38] rootPS < 2^1333 := by decide +kernel

def env49554 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,103447,35189,1025,32769,45340,41341,41292,98644,8193,65,67847,46157,4096,76079,41992,41340,257,32,46093,99159]

theorem envBound49554 : H12AffineFastState.Bounded env49554 := by
  intro p hp
  have h : env49554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49553_49554 : H12AffineEnvironment.transform 16 103447 env49553 = env49554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103447 env49553 == env49554) = true)

theorem identity49554 : scanCanonicalize (H12AffineFastState.compose env49554 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound49554 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env49555 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33111,5440,35189,1025,32769,45340,41341,41292,3,8193,65,34896,46157,4096,43128,41992,41340,257,32,46093,512]

theorem envBound49555 : H12AffineFastState.Bounded env49555 := by
  intro p hp
  have h : env49555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49554_49555 : H12AffineEnvironment.transform 15 33111 env49554 = env49555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env49554 == env49555) = true)

theorem identity49555 : scanCanonicalize (H12AffineFastState.compose env49555 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound49555 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49556 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,8192,5377,32768,33062,5425,35076,1025,32769,45340,41228,41277,3,8193,48,34849,46140,4096,43017,41992,41229,257,32,46093,512]

theorem envBound49556 : H12AffineFastState.Bounded env49556 := by
  intro p hp
  have h : env49556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49555_49556 : H12AffineEnvironment.transform 5 49 env49555 = env49556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env49555 == env49556) = true)

theorem identity49556 : scanCanonicalize (H12AffineFastState.compose env49556 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound49556 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env49557 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,300,5377,32768,33062,5425,35076,1025,32769,36912,32800,32785,3,301,48,34849,38160,4096,35109,34084,32801,257,32,38177,512]

theorem envBound49557 : H12AffineFastState.Bounded env49557 := by
  intro p hp
  have h : env49557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49556_49557 : H12AffineEnvironment.transform 12 300 env49556 = env49557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env49556 == env49557) = true)

theorem identity49557 : scanCanonicalize (H12AffineFastState.compose env49557 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound49557 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env49558 : List Nat := [2,4,8,16,32,49,9,256,512,304,2048,4096,300,4145,32768,33062,4097,35076,305,32769,36912,32800,32785,3,301,48,34849,36896,4096,35109,32788,32801,257,32,36881,512]

theorem envBound49558 : H12AffineFastState.Bounded env49558 := by
  intro p hp
  have h : env49558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49557_49558 : H12AffineEnvironment.transform 9 304 env49557 = env49558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env49557 == env49558) = true)

theorem identity49558 : scanCanonicalize (H12AffineFastState.compose env49558 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound49558 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env49559 : List Nat := [2,4,8,16,32,49,9,37,512,21,2048,4096,9,4145,32768,32771,4097,34849,20,32769,36912,32800,32785,3,8,48,34849,36896,4096,34816,32788,32801,36,32,36881,512]

theorem envBound49559 : H12AffineFastState.Bounded env49559 := by
  intro p hp
  have h : env49559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49558_49559 : H12AffineEnvironment.transform 7 37 env49558 = env49559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env49558 == env49559) = true)

theorem identity49559 : scanCanonicalize (H12AffineFastState.compose env49559 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 33) := by decide +kernel

theorem selectedBound49559 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env49560 : List Nat := [2,4,8,16,32,49,9,37,512,21,2048,4096,9,4145,33,34,4097,2048,20,32,4113,1,48,3,8,48,2048,4097,4096,2081,53,0,36,32,4144,512]

theorem envBound49560 : H12AffineFastState.Bounded env49560 := by
  intro p hp
  have h : env49560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49559_49560 : H12AffineEnvironment.transform 14 33 env49559 = env49560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 33 env49559 == env49560) = true)

theorem identity49560 : scanCanonicalize (H12AffineFastState.compose env49560 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49560 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env49561 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,4096,9,4112,0,3,4097,2048,20,1,4113,1,17,3,8,17,2048,4097,4096,2048,20,0,5,1,4113,512]

theorem envBound49561 : H12AffineFastState.Bounded env49561 := by
  intro p hp
  have h : env49561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49560_49561 : H12AffineEnvironment.transform 4 1 env49560 = env49561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49560 == env49561) = true)

theorem identity49561 : scanCanonicalize (H12AffineFastState.compose env49561 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2577) := by decide +kernel

theorem selectedBound49561 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49562 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,2577,9,2561,0,3,2576,2048,20,1,2560,1,17,3,8,17,2048,2576,2577,2048,20,0,5,1,2560,512]

theorem envBound49562 : H12AffineFastState.Bounded env49562 := by
  intro p hp
  have h : env49562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49561_49562 : H12AffineEnvironment.transform 11 2577 env49561 = env49562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2577 env49561 == env49562) = true)

theorem identity49562 : scanCanonicalize (H12AffineFastState.compose env49562 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 30) := by decide +kernel

theorem selectedBound49562 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49563 : List Nat := [2,4,8,16,1,16,9,4,512,21,30,527,9,543,0,3,526,30,20,1,542,1,17,3,8,17,30,526,527,30,20,0,5,1,542,512]

theorem envBound49563 : H12AffineFastState.Bounded env49563 := by
  intro p hp
  have h : env49563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49562_49563 : H12AffineEnvironment.transform 10 30 env49562 = env49563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 30 env49562 == env49563) = true)

theorem identity49563 : scanCanonicalize (H12AffineFastState.compose env49563 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound49563 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env49564 : List Nat := [2,4,8,16,1,16,9,4,0,21,30,15,9,31,0,3,14,30,20,1,30,1,17,3,8,17,30,14,15,30,20,0,5,1,30,0]

theorem envBound49564 : H12AffineFastState.Bounded env49564 := by
  intro p hp
  have h : env49564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49563_49564 : H12AffineEnvironment.transform 8 0 env49563 = env49564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env49563 == env49564) = true)

def leafEnv49564 : List Nat := [2,4,8,16,1,16,9,4,0,21,30,15,9,31,0,3,14,30,20,1,30,1,17,3,21,8,1,17,30,14,15,30,20,0,5,1,5,2,30,0,1,31,0]

def active49564 : List Nat := [0,1,2,3]

def tree49564 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49564 : H12WitnessSearch.Good tree49564 := H12GlobalWitnessIndex.good

theorem leafIdentity49564 : H12AffineFastState.composeSystem env49564 rootObs = leafEnv49564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49564 rootObs == leafEnv49564) = true)

theorem terminalChecked49564 : H12PackedTerminal.terminalCheckFast leafEnv49564 active49564 tree49564 = true := by decide +kernel

def env49565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,35189,1025,32769,45341,41460,41293,98781,8328,65,171417,46156,4232,179633,42112,41340,257,168,46212,99158]

theorem envBound49565 : H12AffineFastState.Bounded env49565 := by
  intro p hp
  have h : env49565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49551_49565 : H12AffineEnvironment.transform 13 5513 env49551 = env49565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env49551 == env49565) = true)

theorem identity49565 : scanCanonicalize (H12AffineFastState.compose env49565 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound49565 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,65536,131072,10281,1025,8541,4161,168,17,73857,8328,65,146629,5392,4232,138477,1500,32,257,168,5592,74250]

theorem envBound49566 : H12AffineFastState.Bounded env49566 := by
  intro p hp
  have h : env49566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49565_49566 : H12AffineEnvironment.transform 14 8540 env49565 = env49566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env49565 == env49566) = true)

theorem identity49566 : scanCanonicalize (H12AffineFastState.compose env49566 (packedSelected [0,2,4,5,6,8,9,10,11,16,18,19,24,27,28] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound49566 : packedSelected [0,2,4,5,6,8,9,10,11,16,18,19,24,27,28] rootPS < 2^1333 := by decide +kernel

def env49567 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,5456,8540,65536,131072,10281,1025,8541,4161,113,17,73816,8273,65,146460,5392,4177,138292,1285,32,257,113,5377,74250]

theorem envBound49567 : H12AffineFastState.Bounded env49567 := by
  intro p hp
  have h : env49567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49566_49567 : H12AffineEnvironment.transform 6 89 env49566 = env49567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env49566 == env49567) = true)

theorem identity49567 : scanCanonicalize (H12AffineFastState.compose env49567 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound49567 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env49568 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,5456,8540,8283,131072,10281,1025,8541,4161,113,17,3,8273,65,146460,5392,4177,138292,1285,32,257,113,5377,593]

theorem envBound49568 : H12AffineFastState.Bounded env49568 := by
  intro p hp
  have h : env49568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49567_49568 : H12AffineEnvironment.transform 15 8283 env49567 = env49568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env49567 == env49568) = true)

theorem identity49568 : scanCanonicalize (H12AffineFastState.compose env49568 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49568 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env49569 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8461,8202,131072,10281,1025,8460,4112,32,17,3,8192,16,146460,5392,4096,138292,1285,32,257,32,5377,512]

theorem envBound49569 : H12AffineFastState.Bounded env49569 := by
  intro p hp
  have h : env49569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49568_49569 : H12AffineEnvironment.transform 5 17 env49568 = env49569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49568 == env49569) = true)

theorem identity49569 : scanCanonicalize (H12AffineFastState.compose env49569 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 13373) := by decide +kernel

theorem selectedBound49569 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49570 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8461,8202,13373,10281,1025,8460,4112,32,17,3,8192,16,2081,5392,4096,10249,1285,32,257,32,5377,512]

theorem envBound49570 : H12AffineFastState.Bounded env49570 := by
  intro p hp
  have h : env49570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49569_49570 : H12AffineEnvironment.transform 16 13373 env49569 = env49570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13373 env49569 == env49570) = true)

theorem identity49570 : scanCanonicalize (H12AffineFastState.compose env49570 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound49570 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env49571 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,9,5377,260,3,5172,2080,1025,261,4112,32,17,3,9,16,2081,5392,4096,2048,1285,32,257,32,5377,512]

theorem envBound49571 : H12AffineFastState.Bounded env49571 := by
  intro p hp
  have h : env49571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49570_49571 : H12AffineEnvironment.transform 12 9 env49570 = env49571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env49570 == env49571) = true)

theorem identity49571 : scanCanonicalize (H12AffineFastState.compose env49571 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound49571 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env49572 : List Nat := [2,4,8,16,32,17,8,256,512,1024,293,4096,9,5377,260,3,5172,261,1025,261,4112,32,17,3,9,16,260,5392,4096,293,1285,32,257,32,5377,512]

theorem envBound49572 : H12AffineFastState.Bounded env49572 := by
  intro p hp
  have h : env49572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49571_49572 : H12AffineEnvironment.transform 10 293 env49571 = env49572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env49571 == env49572) = true)

theorem identity49572 : scanCanonicalize (H12AffineFastState.compose env49572 (packedSelected [2,14] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49572 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env49573 : List Nat := [2,4,8,16,1,17,8,256,512,1024,260,4096,9,5377,260,3,5141,261,1025,261,4112,1,17,3,9,16,260,5392,4096,260,1285,1,257,1,5377,512]

theorem envBound49573 : H12AffineFastState.Bounded env49573 := by
  intro p hp
  have h : env49573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49572_49573 : H12AffineEnvironment.transform 4 1 env49572 = env49573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49572 == env49573) = true)

theorem identity49573 : scanCanonicalize (H12AffineFastState.compose env49573 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound49573 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env49574 : List Nat := [2,4,8,16,1,17,8,256,512,1024,260,1028,9,261,260,3,17,261,1025,261,1044,1,17,3,9,16,260,276,1028,260,1285,1,257,1,261,512]

theorem envBound49574 : H12AffineFastState.Bounded env49574 := by
  intro p hp
  have h : env49574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49573_49574 : H12AffineEnvironment.transform 11 1028 env49573 = env49574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env49573 == env49574) = true)

theorem identity49574 : scanCanonicalize (H12AffineFastState.compose env49574 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound49574 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49575 : List Nat := [2,4,8,16,1,17,8,5,512,1024,1,1028,9,0,1,3,17,0,1025,0,1044,1,17,3,9,16,1,17,1028,1,1024,1,4,1,0,512]

theorem envBound49575 : H12AffineFastState.Bounded env49575 := by
  intro p hp
  have h : env49575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49574_49575 : H12AffineEnvironment.transform 7 5 env49574 = env49575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env49574 == env49575) = true)

theorem identity49575 : scanCanonicalize (H12AffineFastState.compose env49575 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound49575 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49576 : List Nat := [2,4,8,16,1,17,8,5,0,1024,1,1028,9,0,1,3,17,0,1025,0,1044,1,17,3,9,16,1,17,1028,1,1024,1,4,1,0,0]

theorem envBound49576 : H12AffineFastState.Bounded env49576 := by
  intro p hp
  have h : env49576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49575_49576 : H12AffineEnvironment.transform 8 0 env49575 = env49576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env49575 == env49576) = true)

def env49577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507601,9356288,25265168,23160256,525568,27902124,27337993,25733063]

theorem envBound49577 : H12AffineFastState.Bounded env49577 := by
  intro p hp
  have h : env49577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49132_49577 : H12AffineEnvironment.transform 26 30393345 env49132 = env49577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env49132 == env49577) = true)

def env49578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830976,25265168,23160256,256,27378860,27337993,25207751]

theorem envBound49578 : H12AffineFastState.Bounded env49578 := by
  intro p hp
  have h : env49578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49577_49578 : H12AffineEnvironment.transform 18 1024 env49577 = env49578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env49577 == env49578) = true)

theorem identity49578 : scanCanonicalize (H12AffineFastState.compose env49578 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8874364) := by decide +kernel

theorem selectedBound49578 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env49579 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8874364,8328,65,4237693,10939889,10507601,8830976,453996,15076540,256,2534864,2509941,510651]

theorem envBound49579 : H12AffineFastState.Bounded env49579 := by
  intro p hp
  have h : env49579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49578_49579 : H12AffineEnvironment.transform 23 8874364 env49578 = env49579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8874364 env49578 == env49579) = true)

def env49580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,4194304,8388608,8874364,8328,65,4237693,8393985,8826273,8830976,453996,12645452,256,21792,46213,510651]

theorem envBound49580 : H12AffineFastState.Bounded env49580 := by
  intro p hp
  have h : env49580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49579_49580 : H12AffineEnvironment.transform 20 456944 env49579 = env49580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456944 env49579 == env49580) = true)

def env49581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,4194304,452768,98780,8328,65,4237693,458145,17665,10400,453996,4594924,256,21792,46213,510651]

theorem envBound49581 : H12AffineFastState.Bounded env49581 := by
  intro p hp
  have h : env49581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49580_49581 : H12AffineEnvironment.transform 22 452768 env49580 = env49581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452768 env49580 == env49581) = true)

def env49582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,272512,452768,98780,8328,65,295421,458145,17665,10400,453996,144492,256,21792,46213,510651]

theorem envBound49582 : H12AffineFastState.Bounded env49582 := by
  intro p hp
  have h : env49582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49581_49582 : H12AffineEnvironment.transform 21 272512 env49581 = env49582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env49581 == env49582) = true)

theorem identity49582 : scanCanonicalize (H12AffineFastState.compose env49582 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138340) := by decide +kernel

theorem selectedBound49582 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,58516,144612,62660,98780,8328,65,171417,57797,17665,10400,61704,144492,256,21792,46213,120543]

theorem envBound49583 : H12AffineFastState.Bounded env49583 := by
  intro p hp
  have h : env49583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49582_49583 : H12AffineEnvironment.transform 17 138340 env49582 = env49583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138340 env49582 == env49583) = true)

def env49584 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,58396,144492,62540,98644,8192,65,171281,57677,17665,10280,61704,144492,256,21792,46093,120407]

theorem envBound49584 : H12AffineFastState.Bounded env49584 := by
  intro p hp
  have h : env49584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49583_49584 : H12AffineEnvironment.transform 6 8 env49583 = env49584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49583 == env49584) = true)

theorem identity49584 : scanCanonicalize (H12AffineFastState.compose env49584 (packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 78959) := by decide +kernel

theorem selectedBound49584 : packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS < 2^1333 := by decide +kernel

def env49585 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,78959,75787,1024,32769,58396,65539,62540,98644,8192,65,108926,57677,17665,10280,61704,65539,256,21792,46093,120407]

theorem envBound49585 : H12AffineFastState.Bounded env49585 := by
  intro p hp
  have h : env49585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49584_49585 : H12AffineEnvironment.transform 16 78959 env49584 = env49585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78959 env49584 == env49585) = true)

theorem identity49585 : scanCanonicalize (H12AffineFastState.compose env49585 (packedSelected [3,4,7,8,9,11,12,15,16,20,24,26,27,28,32] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound49585 : packedSelected [3,4,7,8,9,11,12,15,16,20,24,26,27,28,32] rootPS < 2^1333 := by decide +kernel

def env49586 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,78959,75787,1024,32769,58396,65539,62540,98336,8192,65,108554,57401,17525,10280,61564,65539,116,21588,46093,120407]

theorem envBound49586 : H12AffineFastState.Bounded env49586 := by
  intro p hp
  have h : env49586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49585_49586 : H12AffineEnvironment.transform 7 116 env49585 = env49586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env49585 == env49586) = true)

theorem identity49586 : scanCanonicalize (H12AffineFastState.compose env49586 (packedSelected [0,1,2,5,6,8,11,14,16,17,18,19,20,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound49586 : packedSelected [0,1,2,5,6,8,11,14,16,17,18,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env49587 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5236,32768,65536,78959,75787,1024,32769,45160,65539,41016,98336,8192,65,108554,46157,4097,10280,41992,65539,116,32,46093,98851]

theorem envBound49587 : H12AffineFastState.Bounded env49587 := by
  intro p hp
  have h : env49587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49586_49587 : H12AffineEnvironment.transform 13 5236 env49586 = env49587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env49586 == env49587) = true)

theorem identity49587 : scanCanonicalize (H12AffineFastState.compose env49587 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound49587 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env49588 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5236,0,65536,78959,75787,1024,1,12392,65539,8248,65568,8192,65,75786,13389,4097,10280,9224,65539,116,32,13325,66083]

theorem envBound49588 : H12AffineFastState.Bounded env49588 := by
  intro p hp
  have h : env49588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49587_49588 : H12AffineEnvironment.transform 14 0 env49587 = env49588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env49587 == env49588) = true)

theorem identity49588 : scanCanonicalize (H12AffineFastState.compose env49588 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound49588 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env49589 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,3109,8192,2129,0,65536,75850,75787,1024,1,11341,65539,8248,65568,8192,65,75786,10344,3108,10280,9224,65539,116,32,10280,66083]

theorem envBound49589 : H12AffineFastState.Bounded env49589 := by
  intro p hp
  have h : env49589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49588_49589 : H12AffineEnvironment.transform 11 3109 env49588 = env49589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env49588 == env49589) = true)

theorem identity49589 : scanCanonicalize (H12AffineFastState.compose env49589 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound49589 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env49590 : List Nat := [2,4,8,16,32,64,8,116,512,1024,0,1061,8192,81,0,65536,73802,73739,1024,1,9293,65539,8248,65568,8192,65,73738,8296,1060,8232,9224,65539,116,32,8232,66083]

theorem envBound49590 : H12AffineFastState.Bounded env49590 := by
  intro p hp
  have h : env49590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49589_49590 : H12AffineEnvironment.transform 10 0 env49589 = env49590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env49589 == env49590) = true)

theorem identity49590 : scanCanonicalize (H12AffineFastState.compose env49590 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound49590 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env49591 : List Nat := [2,4,8,16,32,64,8,116,512,1024,0,1061,40,81,0,65536,65634,65571,1024,1,1125,65539,16,65568,40,65,65570,64,1060,0,1056,65539,116,32,0,66083]

theorem envBound49591 : H12AffineFastState.Bounded env49591 := by
  intro p hp
  have h : env49591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49590_49591 : H12AffineEnvironment.transform 12 40 env49590 = env49591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env49590 == env49591) = true)

def env49592 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,58397,144493,62541,98645,8193,65,171280,57676,17665,10281,61704,144492,256,21792,46092,120406]

theorem envBound49592 : H12AffineFastState.Bounded env49592 := by
  intro p hp
  have h : env49592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49583_49592 : H12AffineEnvironment.transform 6 9 env49583 = env49592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49583 == env49592) = true)

theorem identity49592 : scanCanonicalize (H12AffineFastState.compose env49592 (packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound49592 : packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS < 2^1333 := by decide +kernel

def env49593 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,138340,1024,8541,17729,144493,21777,73737,8193,65,146508,16400,17665,10281,20564,144492,256,21792,5456,96010]

theorem envBound49593 : H12AffineFastState.Bounded env49593 := by
  intro p hp
  have h : env49593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49592_49593 : H12AffineEnvironment.transform 14 8540 env49592 = env49593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env49592 == env49593) = true)

theorem identity49593 : scanCanonicalize (H12AffineFastState.compose env49593 (packedSelected [1,3,16,17,20,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 16448) := by decide +kernel

theorem selectedBound49593 : packedSelected [1,3,16,17,20,24,28] rootPS < 2^1333 := by decide +kernel

def env49594 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16448,23588,1024,8541,17729,29741,21777,73737,8193,65,31756,16400,17665,10281,20564,29740,256,21792,5456,96010]

theorem envBound49594 : H12AffineFastState.Bounded env49594 := by
  intro p hp
  have h : env49594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49593_49594 : H12AffineEnvironment.transform 16 16448 env49593 = env49594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env49593 == env49594) = true)

theorem identity49594 : scanCanonicalize (H12AffineFastState.compose env49594 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound49594 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env49595 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,262,16448,23588,1024,8541,17729,29741,21777,8463,8193,65,31756,16400,17665,10281,20564,29740,256,21792,5456,30220]

theorem envBound49595 : H12AffineFastState.Bounded env49595 := by
  intro p hp
  have h : env49595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49594_49595 : H12AffineEnvironment.transform 15 262 env49594 = env49595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env49594 == env49595) = true)

theorem identity49595 : scanCanonicalize (H12AffineFastState.compose env49595 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound49595 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env49596 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,80,262,16448,23588,1024,81,17729,21793,21777,3,269,65,23808,16400,17665,2341,20564,21792,256,21792,5456,22272]

theorem envBound49596 : H12AffineFastState.Bounded env49596 := by
  intro p hp
  have h : env49596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49595_49596 : H12AffineEnvironment.transform 12 268 env49595 = env49596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env49595 == env49596) = true)

theorem identity49596 : scanCanonicalize (H12AffineFastState.compose env49596 (packedSelected [1,3,4,5,6,7,8,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 2609) := by decide +kernel

theorem selectedBound49596 : packedSelected [1,3,4,5,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env49597 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,2609,80,262,2673,5653,1024,81,3952,7952,7968,3,269,65,5937,2593,3888,2341,6757,7953,256,7953,5456,7473]

theorem envBound49597 : H12AffineFastState.Bounded env49597 := by
  intro p hp
  have h : env49597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49596_49597 : H12AffineEnvironment.transform 13 2609 env49596 = env49597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2609 env49596 == env49597) = true)

theorem identity49597 : scanCanonicalize (H12AffineFastState.compose env49597 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 3936) := by decide +kernel

theorem selectedBound49597 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env49598 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3936,268,2609,80,262,2673,2421,1024,81,3952,112,64,3,269,65,2129,2593,3888,2341,1285,113,256,113,2608,593]

theorem envBound49598 : H12AffineFastState.Bounded env49598 := by
  intro p hp
  have h : env49598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49597_49598 : H12AffineEnvironment.transform 11 3936 env49597 = env49598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3936 env49597 == env49598) = true)

theorem identity49598 : scanCanonicalize (H12AffineFastState.compose env49598 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound49598 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env49599 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,3636,88,2609,80,82,2673,2081,1024,81,3620,112,64,3,89,65,2129,2593,3684,2161,1105,113,84,113,2608,593]

theorem envBound49599 : H12AffineFastState.Bounded env49599 := by
  intro p hp
  have h : env49599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49598_49599 : H12AffineEnvironment.transform 7 84 env49598 = env49599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env49598 == env49599) = true)

theorem identity49599 : scanCanonicalize (H12AffineFastState.compose env49599 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound49599 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49600 : List Nat := [2,4,8,16,32,64,9,84,512,1024,48,1540,88,513,80,82,577,17,1024,81,1556,112,64,3,89,65,97,529,1620,65,1105,113,84,113,512,593]

theorem envBound49600 : H12AffineFastState.Bounded env49600 := by
  intro p hp
  have h : env49600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49599_49600 : H12AffineEnvironment.transform 10 48 env49599 = env49600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env49599 == env49600) = true)

theorem identity49600 : scanCanonicalize (H12AffineFastState.compose env49600 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound49600 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env49601 : List Nat := [2,4,8,16,32,64,9,84,512,565,48,49,88,513,80,82,577,17,565,81,33,112,64,3,89,65,97,529,97,65,612,113,84,113,512,593]

theorem envBound49601 : H12AffineFastState.Bounded env49601 := by
  intro p hp
  have h : env49601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49600_49601 : H12AffineEnvironment.transform 9 565 env49600 = env49601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env49600 == env49601) = true)

theorem identity49601 : scanCanonicalize (H12AffineFastState.compose env49601 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound49601 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env49602 : List Nat := [2,4,8,16,32,64,9,84,81,100,48,49,88,80,80,82,16,17,100,81,33,112,64,3,89,65,97,64,97,65,53,113,84,113,81,0]

theorem envBound49602 : H12AffineFastState.Bounded env49602 := by
  intro p hp
  have h : env49602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49601_49602 : H12AffineEnvironment.transform 8 81 env49601 = env49602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env49601 == env49602) = true)

theorem identity49602 : scanCanonicalize (H12AffineFastState.compose env49602 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound49602 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env49603 : List Nat := [2,4,8,16,32,1,9,21,16,37,48,49,25,17,17,19,16,17,37,16,33,49,1,3,24,0,32,1,32,0,53,48,21,48,16,0]

theorem envBound49603 : H12AffineFastState.Bounded env49603 := by
  intro p hp
  have h : env49603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49602_49603 : H12AffineEnvironment.transform 5 1 env49602 = env49603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env49602 == env49603) = true)

theorem identity49603 : scanCanonicalize (H12AffineFastState.compose env49603 (packedSelected [9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound49603 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env49604 : List Nat := [2,4,8,0,32,1,9,5,0,37,32,33,9,1,1,3,0,1,37,0,33,33,1,3,8,0,32,1,32,0,37,32,5,32,0,0]

theorem envBound49604 : H12AffineFastState.Bounded env49604 := by
  intro p hp
  have h : env49604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49603_49604 : H12AffineEnvironment.transform 3 0 env49603 = env49604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env49603 == env49604) = true)

theorem identity49604 : scanCanonicalize (H12AffineFastState.compose env49604 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49604 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49605 : List Nat := [2,4,8,0,1,1,9,5,0,4,1,0,9,1,1,3,0,1,4,0,0,0,1,3,8,0,1,1,1,0,4,1,5,1,0,0]

theorem envBound49605 : H12AffineFastState.Bounded env49605 := by
  intro p hp
  have h : env49605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49604_49605 : H12AffineEnvironment.transform 4 1 env49604 = env49605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49604 == env49605) = true)

theorem identity49605 : scanCanonicalize (H12AffineFastState.compose env49605 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound49605 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49606 : List Nat := [2,4,6,0,1,1,7,5,0,4,1,0,7,1,1,3,0,1,4,0,0,0,1,3,6,0,1,1,1,0,4,1,5,1,0,0]

theorem envBound49606 : H12AffineFastState.Bounded env49606 := by
  intro p hp
  have h : env49606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49605_49606 : H12AffineEnvironment.transform 2 6 env49605 = env49606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env49605 == env49606) = true)

def env49607 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,272513,452768,98780,8328,65,295420,458145,17665,10400,453996,144493,256,21792,46213,510651]

theorem envBound49607 : H12AffineFastState.Bounded env49607 := by
  intro p hp
  have h : env49607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49581_49607 : H12AffineEnvironment.transform 21 272513 env49581 = env49607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env49581 == env49607) = true)

theorem identity49607 : scanCanonicalize (H12AffineFastState.compose env49607 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound49607 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49608 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,396324,272513,400500,95496,8328,65,292136,395637,17665,10400,399800,144493,256,21792,16465,474735]

theorem envBound49608 : H12AffineFastState.Bounded env49608 := by
  intro p hp
  have h : env49608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49607_49608 : H12AffineEnvironment.transform 14 29908 env49607 = env49608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env49607 == env49608) = true)

def env49609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10400,1024,29909,140420,33,144596,95496,8328,65,23944,139733,17665,10400,143640,144493,256,21792,16465,202447]

theorem envBound49609 : H12AffineFastState.Bounded env49609 := by
  intro p hp
  have h : env49609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49608_49609 : H12AffineEnvironment.transform 17 10400 env49608 = env49609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env49608 == env49609) = true)

theorem identity49609 : scanCanonicalize (H12AffineFastState.compose env49609 (packedSelected [12,15,16,17,20,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound49609 : packedSelected [12,15,16,17,20,38,41] rootPS < 2^1333 := by decide +kernel

def env49610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90139,10400,1024,29909,83103,33,87247,95496,8328,65,23944,82382,17665,10400,86275,87158,256,21792,16465,30420]

theorem envBound49610 : H12AffineFastState.Bounded env49610 := by
  intro p hp
  have h : env49610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49609_49610 : H12AffineEnvironment.transform 16 90139 env49609 = env49610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env49609 == env49610) = true)

theorem identity49610 : scanCanonicalize (H12AffineFastState.compose env49610 (packedSelected [1,5,8,11,16,17,18,19,20,23,24,26,32] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound49610 : packedSelected [1,5,8,11,16,17,18,19,20,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env49611 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90139,10281,1024,29788,82966,33,87110,95496,8193,65,23809,82247,17665,10281,86275,87158,256,21792,16465,30301]

theorem envBound49611 : H12AffineFastState.Bounded env49611 := by
  intro p hp
  have h : env49611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49610_49611 : H12AffineEnvironment.transform 6 9 env49610 = env49611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49610 == env49611) = true)

theorem identity49611 : scanCanonicalize (H12AffineFastState.compose env49611 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound49611 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env49612 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,16401,10281,1024,29788,25628,33,29772,21762,8193,65,23809,24909,17665,10281,28937,29820,256,21792,16465,30301]

theorem envBound49612 : H12AffineFastState.Bounded env49612 := by
  intro p hp
  have h : env49612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49611_49612 : H12AffineEnvironment.transform 15 8202 env49611 = env49612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env49611 == env49612) = true)

theorem identity49612 : scanCanonicalize (H12AffineFastState.compose env49612 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound49612 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env49613 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,8460,8202,5440,10281,1024,8461,12621,33,8477,83,8193,65,2128,13340,4176,10281,9304,8493,256,113,5376,8972]

theorem envBound49613 : H12AffineFastState.Bounded env49613 := by
  intro p hp
  have h : env49613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49612_49613 : H12AffineEnvironment.transform 13 5457 env49612 = env49613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env49612 == env49613) = true)

theorem identity49613 : scanCanonicalize (H12AffineFastState.compose env49613 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound49613 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env49614 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5457,81,343,5440,2420,1024,80,4112,33,64,83,348,65,2128,5441,4176,2420,1285,112,256,113,5376,593]

theorem envBound49614 : H12AffineFastState.Bounded env49614 := by
  intro p hp
  have h : env49614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49613_49614 : H12AffineEnvironment.transform 12 349 env49613 = env49614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env49613 == env49614) = true)

theorem identity49614 : scanCanonicalize (H12AffineFastState.compose env49614 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49614 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env49615 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,1,263,5392,2340,1024,0,4112,33,16,3,268,17,2048,5393,4096,2340,1285,32,256,33,5376,513]

theorem envBound49615 : H12AffineFastState.Bounded env49615 := by
  intro p hp
  have h : env49615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49614_49615 : H12AffineEnvironment.transform 5 16 env49614 = env49615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49614 == env49615) = true)

theorem identity49615 : scanCanonicalize (H12AffineFastState.compose env49615 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound49615 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49616 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5157,1,35,5172,2048,1024,0,4112,33,16,3,40,17,2048,5173,4096,2048,1057,32,36,33,5156,513]

theorem envBound49616 : H12AffineFastState.Bounded env49616 := by
  intro p hp
  have h : env49616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49615_49616 : H12AffineEnvironment.transform 7 36 env49615 = env49616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env49615 == env49616) = true)

theorem identity49616 : scanCanonicalize (H12AffineFastState.compose env49616 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound49616 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49617 : List Nat := [2,4,8,16,32,16,9,36,512,1024,522,4096,41,5157,1,35,5172,522,1024,0,4112,33,16,3,40,17,522,5173,4096,522,1057,32,36,33,5156,513]

theorem envBound49617 : H12AffineFastState.Bounded env49617 := by
  intro p hp
  have h : env49617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49616_49617 : H12AffineEnvironment.transform 10 522 env49616 = env49617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env49616 == env49617) = true)

theorem identity49617 : scanCanonicalize (H12AffineFastState.compose env49617 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49617 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49618 : List Nat := [2,4,8,16,1,16,9,5,512,1024,522,4096,8,5124,1,2,5141,522,1024,0,4112,0,16,3,9,17,522,5140,4096,522,1024,1,5,0,5125,513]

theorem envBound49618 : H12AffineFastState.Bounded env49618 := by
  intro p hp
  have h : env49618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49617_49618 : H12AffineEnvironment.transform 4 1 env49617 = env49618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49617 == env49618) = true)

def env49619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10401,1024,29909,140421,32,144597,95496,8328,65,23945,139732,17665,10400,143641,144493,256,21792,16465,202446]

theorem envBound49619 : H12AffineFastState.Bounded env49619 := by
  intro p hp
  have h : env49619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49608_49619 : H12AffineEnvironment.transform 17 10401 env49608 = env49619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env49608 == env49619) = true)

theorem identity49619 : scanCanonicalize (H12AffineFastState.compose env49619 (packedSelected [12,15,16,17,20,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 79250) := by decide +kernel

theorem selectedBound49619 : packedSelected [12,15,16,17,20,38,41] rootPS < 2^1333 := by decide +kernel

def env49620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,79250,10401,1024,29909,69911,32,65863,95496,8328,65,23945,70726,17665,10400,66699,66047,256,21792,16465,9052]

theorem envBound49620 : H12AffineFastState.Bounded env49620 := by
  intro p hp
  have h : env49620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49619_49620 : H12AffineEnvironment.transform 16 79250 env49619 = env49620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79250 env49619 == env49620) = true)

theorem identity49620 : scanCanonicalize (H12AffineFastState.compose env49620 (packedSelected [0,1,2,3,4,5,6,7,9,11,12,14,15,16,19,20,23,28] rootPS)) = affineNative (2^(13+1) ^^^ 13729) := by decide +kernel

theorem selectedBound49620 : packedSelected [0,1,2,3,4,5,6,7,9,11,12,14,15,16,19,20,23,28] rootPS < 2^1333 := by decide +kernel

def env49621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13729,373,65536,79250,10401,1024,372,69911,32,65863,65705,8328,65,10280,70726,12448,10400,66699,66047,256,8321,13808,9052]

theorem envBound49621 : H12AffineFastState.Bounded env49621 := by
  intro p hp
  have h : env49621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49620_49621 : H12AffineEnvironment.transform 13 13729 env49620 = env49621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13729 env49620 == env49621) = true)

theorem identity49621 : scanCanonicalize (H12AffineFastState.compose env49621 (packedSelected [3,4,9,10,14,16,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound49621 : packedSelected [3,4,9,10,14,16,24,26] rootPS < 2^1333 := by decide +kernel

def env49622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5372,373,65536,70863,2556,1024,372,69911,32,65863,65705,469,65,2421,70726,4605,2557,66699,66047,256,476,5293,513]

theorem envBound49622 : H12AffineFastState.Bounded env49622 := by
  intro p hp
  have h : env49622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49621_49622 : H12AffineEnvironment.transform 12 349 env49621 = env49622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env49621 == env49622) = true)

theorem identity49622 : scanCanonicalize (H12AffineFastState.compose env49622 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound49622 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env49623 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,349,4540,373,65536,70031,2556,320,372,69911,32,65863,65705,469,65,2421,69894,4605,2557,65995,66047,256,476,4589,513]

theorem envBound49623 : H12AffineFastState.Bounded env49623 := by
  intro p hp
  have h : env49623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49622_49623 : H12AffineEnvironment.transform 9 320 env49622 = env49623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env49622 == env49623) = true)

theorem identity49623 : scanCanonicalize (H12AffineFastState.compose env49623 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 6558) := by decide +kernel

theorem selectedBound49623 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env49624 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,349,4540,373,6558,2065,2556,320,372,2185,32,6361,6455,469,65,2421,2200,4605,2557,6229,6241,256,476,4589,513]

theorem envBound49624 : H12AffineFastState.Bounded env49624 := by
  intro p hp
  have h : env49624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49623_49624 : H12AffineEnvironment.transform 15 6558 env49623 = env49624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6558 env49623 == env49624) = true)

theorem identity49624 : scanCanonicalize (H12AffineFastState.compose env49624 (packedSelected [0,1,2,3,5,6,7,8,11,16] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound49624 : packedSelected [0,1,2,3,5,6,7,8,11,16] rootPS < 2^1333 := by decide +kernel

def env49625 : List Nat := [2,4,8,16,32,64,128,256,512,320,137,4096,349,4540,373,4375,152,373,320,372,0,32,4176,4542,469,65,508,17,4605,372,4316,4328,256,476,4589,513]

theorem envBound49625 : H12AffineFastState.Bounded env49625 := by
  intro p hp
  have h : env49625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49624_49625 : H12AffineEnvironment.transform 10 137 env49624 = env49625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env49624 == env49625) = true)

theorem identity49625 : scanCanonicalize (H12AffineFastState.compose env49625 (packedSelected [1,2,3,4,5,6,8,9,11,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound49625 : packedSelected [1,2,3,4,5,6,8,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env49626 : List Nat := [2,4,8,16,32,64,128,116,512,52,137,4096,41,4296,1,4195,152,1,52,0,0,32,4176,4298,161,65,136,17,4233,0,4316,4328,116,168,4249,513]

theorem envBound49626 : H12AffineFastState.Bounded env49626 := by
  intro p hp
  have h : env49626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49625_49626 : H12AffineEnvironment.transform 7 116 env49625 = env49626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env49625 == env49626) = true)

theorem identity49626 : scanCanonicalize (H12AffineFastState.compose env49626 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 73) := by decide +kernel

theorem selectedBound49626 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env49627 : List Nat := [2,4,8,16,32,64,73,116,512,52,64,4096,41,4097,1,4195,81,1,52,0,0,32,4176,4099,104,65,65,17,4160,0,4117,4129,116,97,4176,513]

theorem envBound49627 : H12AffineFastState.Bounded env49627 := by
  intro p hp
  have h : env49627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49626_49627 : H12AffineEnvironment.transform 6 73 env49626 = env49627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env49626 == env49627) = true)

theorem identity49627 : scanCanonicalize (H12AffineFastState.compose env49627 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound49627 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env49628 : List Nat := [2,4,8,16,32,64,73,116,16,52,64,4096,41,4097,1,4195,81,1,52,0,0,32,4176,4099,104,65,65,17,4160,0,4117,4129,116,97,4176,17]

theorem envBound49628 : H12AffineFastState.Bounded env49628 := by
  intro p hp
  have h : env49628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49627_49628 : H12AffineEnvironment.transform 8 16 env49627 = env49628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env49627 == env49628) = true)

theorem identity49628 : scanCanonicalize (H12AffineFastState.compose env49628 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound49628 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env49629 : List Nat := [2,4,8,16,32,64,73,116,16,52,64,80,41,81,1,51,81,1,52,0,0,32,0,83,104,65,65,17,16,0,69,113,116,97,0,17]

theorem envBound49629 : H12AffineFastState.Bounded env49629 := by
  intro p hp
  have h : env49629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49628_49629 : H12AffineEnvironment.transform 11 80 env49628 = env49629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env49628 == env49629) = true)

theorem identity49629 : scanCanonicalize (H12AffineFastState.compose env49629 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound49629 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env49630 : List Nat := [2,4,8,0,32,64,73,100,0,36,64,64,41,65,1,35,65,1,36,0,0,32,0,67,104,65,65,1,0,0,69,97,100,97,0,1]

theorem envBound49630 : H12AffineFastState.Bounded env49630 := by
  intro p hp
  have h : env49630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49629_49630 : H12AffineEnvironment.transform 3 0 env49629 = env49630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env49629 == env49630) = true)

def env49631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,4194304,452769,98781,8328,65,4237693,458144,17664,10401,453996,4594925,256,21792,46213,510651]

theorem envBound49631 : H12AffineFastState.Bounded env49631 := by
  intro p hp
  have h : env49631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49580_49631 : H12AffineEnvironment.transform 22 452769 env49580 = env49631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452769 env49580 == env49631) = true)

def env49632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,272512,452769,98781,8328,65,295421,458144,17664,10401,453996,144493,256,21792,46213,510651]

theorem envBound49632 : H12AffineFastState.Bounded env49632 := by
  intro p hp
  have h : env49632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49631_49632 : H12AffineEnvironment.transform 21 272512 env49631 = env49632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env49631 == env49632) = true)

theorem identity49632 : scanCanonicalize (H12AffineFastState.compose env49632 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190641) := by decide +kernel

theorem selectedBound49632 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4161,180273,16,98781,8328,65,158028,5393,17664,10401,1501,144493,256,21792,46213,74250]

theorem envBound49633 : H12AffineFastState.Bounded env49633 := by
  intro p hp
  have h : env49633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49632_49633 : H12AffineEnvironment.transform 17 190641 env49632 = env49633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190641 env49632 == env49633) = true)

theorem identity49633 : scanCanonicalize (H12AffineFastState.compose env49633 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound49633 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env49634 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190641,1024,32769,4161,180273,16,41430,8328,65,158028,5393,17664,10401,1501,144493,256,21792,46213,513]

theorem envBound49634 : H12AffineFastState.Bounded env49634 := by
  intro p hp
  have h : env49634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49633_49634 : H12AffineEnvironment.transform 15 8203 env49633 = env49634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env49633 == env49634) = true)

theorem identity49634 : scanCanonicalize (H12AffineFastState.compose env49634 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound49634 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env49635 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,43169,1024,32769,4161,32801,16,41430,8328,65,10588,5393,17664,10401,1501,29821,256,21792,46213,513]

theorem envBound49635 : H12AffineFastState.Bounded env49635 := by
  intro p hp
  have h : env49635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49634_49635 : H12AffineEnvironment.transform 16 16400 env49634 = env49635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env49634 == env49635) = true)

theorem identity49635 : scanCanonicalize (H12AffineFastState.compose env49635 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound49635 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49636 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,8203,13388,43169,1024,32769,4161,32801,16,41430,8328,65,10588,5393,12636,10401,1501,33,256,8572,46213,513]

theorem envBound49636 : H12AffineFastState.Bounded env49636 := by
  intro p hp
  have h : env49636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49635_49636 : H12AffineEnvironment.transform 13 13404 env49635 = env49636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env49635 == env49636) = true)

theorem identity49636 : scanCanonicalize (H12AffineFastState.compose env49636 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound49636 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,8541,8203,13388,2556,1024,8540,4161,8572,16,139,8328,65,10588,5393,12636,10401,1501,33,256,8572,5592,513]

end H12CloudChart0