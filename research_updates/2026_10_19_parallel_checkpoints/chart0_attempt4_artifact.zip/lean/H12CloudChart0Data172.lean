import H12CloudChart0Data171

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound43579 : H12AffineFastState.Bounded env43579 := by
  intro p hp
  have h : env43579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43578_43579 : H12AffineEnvironment.transform 16 24861 env43578 = env43579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env43578 == env43579) = true)

theorem identity43579 : scanCanonicalize (H12AffineFastState.compose env43579 (packedSelected [2,6,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound43579 : packedSelected [2,6,11,15] rootPS < 2^1333 := by decide +kernel

def env43580 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,16384,21896,21647,16401,23588,1024,21897,4112,32,21912,21763,388,16,23944,16536,4233,23589,1420,21793,256,21792,16384,22409]

theorem envBound43580 : H12AffineFastState.Bounded env43580 := by
  intro p hp
  have h : env43580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43579_43580 : H12AffineEnvironment.transform 12 268 env43579 = env43580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env43579 == env43580) = true)

theorem identity43580 : scanCanonicalize (H12AffineFastState.compose env43580 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound43580 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env43581 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,268,16384,20632,20895,16401,22836,272,20633,4112,32,20616,20499,388,16,22680,16536,4233,22837,156,20529,256,20528,16384,21145]

theorem envBound43581 : H12AffineFastState.Bounded env43581 := by
  intro p hp
  have h : env43581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43580_43581 : H12AffineEnvironment.transform 9 272 env43580 = env43581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env43580 == env43581) = true)

theorem identity43581 : scanCanonicalize (H12AffineFastState.compose env43581 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound43581 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env43582 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,268,4405,429,170,4388,2049,272,428,4112,32,445,294,388,16,2477,4525,4233,2048,156,260,256,261,4405,940]

theorem envBound43582 : H12AffineFastState.Bounded env43582 := by
  intro p hp
  have h : env43582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43581_43582 : H12AffineEnvironment.transform 13 4405 env43581 = env43582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env43581 == env43582) = true)

theorem identity43582 : scanCanonicalize (H12AffineFastState.compose env43582 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound43582 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env43583 : List Nat := [2,4,8,16,32,17,128,37,512,53,2048,4096,41,4112,136,170,4097,2049,53,137,4112,32,152,3,161,16,2184,4232,4233,2048,156,33,37,32,4112,649]

theorem envBound43583 : H12AffineFastState.Bounded env43583 := by
  intro p hp
  have h : env43583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43582_43583 : H12AffineEnvironment.transform 7 37 env43582 = env43583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env43582 == env43583) = true)

theorem identity43583 : scanCanonicalize (H12AffineFastState.compose env43583 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2577) := by decide +kernel

theorem selectedBound43583 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env43584 : List Nat := [2,4,8,16,32,17,128,37,512,53,2048,2577,41,2561,136,170,2576,2049,53,137,2561,32,152,3,161,16,2184,2713,2712,2048,156,33,37,32,2561,649]

theorem envBound43584 : H12AffineFastState.Bounded env43584 := by
  intro p hp
  have h : env43584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43583_43584 : H12AffineEnvironment.transform 11 2577 env43583 = env43584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2577 env43583 == env43584) = true)

theorem identity43584 : scanCanonicalize (H12AffineFastState.compose env43584 (packedSelected [2,4,11] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound43584 : packedSelected [2,4,11] rootPS < 2^1333 := by decide +kernel

def env43585 : List Nat := [2,4,8,16,32,17,128,37,1,53,2048,2064,41,2048,136,170,2065,2049,53,137,2048,32,152,3,161,16,2184,2200,2201,2048,156,33,37,32,2048,136]

theorem envBound43585 : H12AffineFastState.Bounded env43585 := by
  intro p hp
  have h : env43585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43584_43585 : H12AffineEnvironment.transform 8 1 env43584 = env43585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env43584 == env43585) = true)

theorem identity43585 : scanCanonicalize (H12AffineFastState.compose env43585 (packedSelected [2,14] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43585 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env43586 : List Nat := [2,4,8,16,32,17,8,37,1,53,2048,2064,41,2048,0,34,2065,2049,53,1,2048,32,16,3,41,16,2048,2064,2065,2048,20,33,37,32,2048,0]

theorem envBound43586 : H12AffineFastState.Bounded env43586 := by
  intro p hp
  have h : env43586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43585_43586 : H12AffineEnvironment.transform 6 8 env43585 = env43586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43585 == env43586) = true)

def env43587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262521,412156,2114882,8328,65,215366,115150,2497708,35324,2590894,2336123,256,509970,469430,2535289]

theorem envBound43587 : H12AffineFastState.Bounded env43587 := by
  intro p hp
  have h : env43587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43534_43587 : H12AffineEnvironment.transform 21 2262521 env43534 = env43587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262521 env43534 == env43587) = true)

def env43588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169401,412156,21762,8328,65,215366,115150,396524,35324,497902,243003,256,509970,469430,442169]

theorem envBound43588 : H12AffineFastState.Bounded env43588 := by
  intro p hp
  have h : env43588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43587_43588 : H12AffineEnvironment.transform 20 4160 env43587 = env43588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env43587 == env43588) = true)

def env43589 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,169401,156116,21762,8328,65,215366,115150,140484,35324,241862,243003,256,254010,197022,169745]

theorem envBound43589 : H12AffineFastState.Bounded env43589 := by
  intro p hp
  have h : env43589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43588_43589 : H12AffineEnvironment.transform 17 10280 env43588 = env43589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env43588 == env43589) = true)

def env43590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,4160,21929,41412,21762,8328,65,100694,115150,58580,35324,94422,95531,256,73770,115086,22273]

theorem envBound43590 : H12AffineFastState.Bounded env43590 := by
  intro p hp
  have h : env43590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43589_43590 : H12AffineEnvironment.transform 16 49168 env43589 = env43590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env43589 == env43590) = true)

theorem identity43590 : scanCanonicalize (H12AffineFastState.compose env43590 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound43590 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,25029,10280,1024,8660,4160,21929,17,21762,8328,65,75907,90139,17665,10281,94422,95531,256,73770,90203,22273]

theorem envBound43591 : H12AffineFastState.Bounded env43591 := by
  intro p hp
  have h : env43591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43590_43591 : H12AffineEnvironment.transform 14 8661 env43590 = env43591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env43590 == env43591) = true)

theorem identity43591 : scanCanonicalize (H12AffineFastState.compose env43591 (packedSelected [2,3,5,6,7,8,9,11,16,22,23,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 21875) := by decide +kernel

theorem selectedBound43591 : packedSelected [2,3,5,6,7,8,9,11,16,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env43592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,21875,25029,10280,1024,8660,4160,21929,17,21762,8328,65,32240,13672,17665,10281,9637,8280,256,30041,13608,22273]

theorem envBound43592 : H12AffineFastState.Bounded env43592 := by
  intro p hp
  have h : env43592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43591_43592 : H12AffineEnvironment.transform 15 21875 env43591 = env43592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21875 env43591 == env43592) = true)

theorem identity43592 : scanCanonicalize (H12AffineFastState.compose env43592 (packedSelected [1,4,5,8,9,14,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 5592) := by decide +kernel

theorem selectedBound43592 : packedSelected [1,4,5,8,9,14,20,24] rootPS < 2^1333 := by decide +kernel

def env43593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5592,8661,171,13341,10280,1024,8660,4160,113,17,218,8328,65,10280,13672,4313,10281,9637,8280,256,8321,13608,729]

theorem envBound43593 : H12AffineFastState.Bounded env43593 := by
  intro p hp
  have h : env43593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43592_43593 : H12AffineEnvironment.transform 13 5592 env43592 = env43593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5592 env43592 == env43593) = true)

theorem identity43593 : scanCanonicalize (H12AffineFastState.compose env43593 (packedSelected [0,1,2,4,6,7,8,9,11,14,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 1457) := by decide +kernel

theorem selectedBound43593 : packedSelected [0,1,2,4,6,7,8,9,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env43594 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1457,5592,1124,171,4524,3481,1024,1125,4160,113,17,218,1337,65,3481,4313,4313,3480,20,1513,256,1328,4249,729]

theorem envBound43594 : H12AffineFastState.Bounded env43594 := by
  intro p hp
  have h : env43594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43593_43594 : H12AffineEnvironment.transform 12 1457 env43593 = env43594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1457 env43593 == env43594) = true)

theorem identity43594 : scanCanonicalize (H12AffineFastState.compose env43594 (packedSelected [4,9,11,14,18,20] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43594 : packedSelected [4,9,11,14,18,20] rootPS < 2^1333 := by decide +kernel

def env43595 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1337,5456,1124,35,4388,3345,1024,1125,4160,113,17,82,1337,65,3345,4177,4177,3344,20,1377,256,1328,4113,593]

theorem envBound43595 : H12AffineFastState.Bounded env43595 := by
  intro p hp
  have h : env43595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43594_43595 : H12AffineEnvironment.transform 6 8 env43594 = env43595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43594 == env43595) = true)

theorem identity43595 : scanCanonicalize (H12AffineFastState.compose env43595 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound43595 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env43596 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,1101,5156,1124,35,4176,3173,1024,1125,4160,113,17,82,1101,65,3173,4177,4177,3172,20,1045,116,1092,4113,593]

theorem envBound43596 : H12AffineFastState.Bounded env43596 := by
  intro p hp
  have h : env43596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43595_43596 : H12AffineEnvironment.transform 7 116 env43595 = env43596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env43595 == env43596) = true)

theorem identity43596 : scanCanonicalize (H12AffineFastState.compose env43596 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43596 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43597 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,1053,5156,1076,35,4096,3125,1024,1077,4112,33,17,2,1053,17,3125,4097,4097,3124,20,1045,36,1044,4113,513]

theorem envBound43597 : H12AffineFastState.Bounded env43597 := by
  intro p hp
  have h : env43597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43596_43597 : H12AffineEnvironment.transform 5 16 env43596 = env43597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43596 == env43597) = true)

theorem identity43597 : scanCanonicalize (H12AffineFastState.compose env43597 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound43597 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env43598 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,3109,1053,2049,1076,35,3109,3125,1024,1077,3125,33,17,2,1053,17,3125,3108,3108,3124,20,1045,36,1044,3124,513]

theorem envBound43598 : H12AffineFastState.Bounded env43598 := by
  intro p hp
  have h : env43598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43597_43598 : H12AffineEnvironment.transform 11 3109 env43597 = env43598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env43597 == env43598) = true)

theorem identity43598 : scanCanonicalize (H12AffineFastState.compose env43598 (packedSelected [0,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1061) := by decide +kernel

theorem selectedBound43598 : packedSelected [0,3,5] rootPS < 2^1333 := by decide +kernel

def env43599 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1061,0,1053,1060,1076,35,0,16,1024,1077,16,33,17,2,1053,17,16,1,1,17,20,1045,36,1044,17,513]

theorem envBound43599 : H12AffineFastState.Bounded env43599 := by
  intro p hp
  have h : env43599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43598_43599 : H12AffineEnvironment.transform 10 1061 env43598 = env43599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1061 env43598 == env43599) = true)

theorem identity43599 : scanCanonicalize (H12AffineFastState.compose env43599 (packedSelected [2,3] rootPS)) = affineNative (2^(8+1) ^^^ 58) := by decide +kernel

theorem selectedBound43599 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env43600 : List Nat := [2,4,8,16,32,16,8,36,58,1024,1061,0,1053,1060,1076,35,0,16,1024,1077,16,33,17,2,1053,17,16,1,1,17,20,1045,36,1044,17,59]

theorem envBound43600 : H12AffineFastState.Bounded env43600 := by
  intro p hp
  have h : env43600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43599_43600 : H12AffineEnvironment.transform 8 58 env43599 = env43600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 58 env43599 == env43600) = true)

theorem identity43600 : scanCanonicalize (H12AffineFastState.compose env43600 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound43600 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43601 : List Nat := [2,4,8,16,32,16,8,36,58,53,16,0,40,17,1,35,0,16,53,0,16,33,17,2,40,17,16,1,1,17,20,32,36,33,17,59]

theorem envBound43601 : H12AffineFastState.Bounded env43601 := by
  intro p hp
  have h : env43601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43600_43601 : H12AffineEnvironment.transform 9 53 env43600 = env43601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env43600 == env43601) = true)

theorem identity43601 : scanCanonicalize (H12AffineFastState.compose env43601 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound43601 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43602 : List Nat := [2,4,8,1,32,1,8,36,43,36,1,0,40,0,1,35,0,1,36,0,1,33,0,2,40,0,1,1,1,0,5,32,36,33,0,42]

theorem envBound43602 : H12AffineFastState.Bounded env43602 := by
  intro p hp
  have h : env43602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43601_43602 : H12AffineEnvironment.transform 3 1 env43601 = env43602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env43601 == env43602) = true)

theorem identity43602 : scanCanonicalize (H12AffineFastState.compose env43602 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound43602 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43603 : List Nat := [2,4,3,1,32,1,3,36,32,36,1,0,35,0,1,35,0,1,36,0,1,33,0,2,35,0,1,1,1,0,5,32,36,33,0,33]

theorem envBound43603 : H12AffineFastState.Bounded env43603 := by
  intro p hp
  have h : env43603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43602_43603 : H12AffineEnvironment.transform 2 3 env43602 = env43603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env43602 == env43603) = true)

theorem identity43603 : scanCanonicalize (H12AffineFastState.compose env43603 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43603 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43604 : List Nat := [2,4,3,1,0,1,3,4,0,4,1,0,3,0,1,3,0,1,4,0,1,1,0,2,3,0,1,1,1,0,5,0,4,1,0,1]

theorem envBound43604 : H12AffineFastState.Bounded env43604 := by
  intro p hp
  have h : env43604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43603_43604 : H12AffineEnvironment.transform 4 0 env43603 = env43604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43603 == env43604) = true)

def env43605 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,4160,21928,41413,21762,8328,65,100695,115150,58581,35324,94423,95530,256,73771,115087,22272]

theorem envBound43605 : H12AffineFastState.Bounded env43605 := by
  intro p hp
  have h : env43605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43589_43605 : H12AffineEnvironment.transform 16 49169 env43589 = env43605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env43589 == env43605) = true)

theorem identity43605 : scanCanonicalize (H12AffineFastState.compose env43605 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound43605 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43606 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,24908,10280,1024,8540,4160,21928,152,21762,8328,65,75786,90259,17800,10401,94423,95530,256,73771,90322,22272]

theorem envBound43606 : H12AffineFastState.Bounded env43606 := by
  intro p hp
  have h : env43606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43605_43606 : H12AffineEnvironment.transform 14 8541 env43605 = env43606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env43605 == env43606) = true)

theorem identity43606 : scanCanonicalize (H12AffineFastState.compose env43606 (packedSelected [0,1,2,5,6,7,8,11,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 29823) := by decide +kernel

theorem selectedBound43606 : packedSelected [0,1,2,5,6,7,8,11,20,23,24] rootPS < 2^1333 := by decide +kernel

def env43607 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,29823,24908,10280,1024,8540,4160,21928,152,21762,8328,65,23669,5356,17800,10401,1192,341,256,21588,5293,22272]

theorem envBound43607 : H12AffineFastState.Bounded env43607 := by
  intro p hp
  have h : env43607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43606_43607 : H12AffineEnvironment.transform 15 29823 env43606 = env43607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29823 env43606 == env43607) = true)

theorem identity43607 : scanCanonicalize (H12AffineFastState.compose env43607 (packedSelected [7,14,18,19,20,23,26,27] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound43607 : packedSelected [7,14,18,19,20,23,26,27] rootPS < 2^1333 := by decide +kernel

def env43608 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,1,21795,16400,2420,1024,0,4160,21928,152,21762,468,65,23669,5356,17800,2557,1192,341,256,21588,5293,22272]

theorem envBound43608 : H12AffineFastState.Bounded env43608 := by
  intro p hp
  have h : env43608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43607_43608 : H12AffineEnvironment.transform 12 348 env43607 = env43608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env43607 == env43608) = true)

theorem identity43608 : scanCanonicalize (H12AffineFastState.compose env43608 (packedSelected [1,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound43608 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env43609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,4112,1,1331,4096,2420,1024,0,4160,1464,152,1298,468,65,3173,5356,5528,2557,1192,341,256,1092,5293,1808]

theorem envBound43609 : H12AffineFastState.Bounded env43609 := by
  intro p hp
  have h : env43609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43608_43609 : H12AffineEnvironment.transform 13 4112 env43608 = env43609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env43608 == env43609) = true)

theorem identity43609 : scanCanonicalize (H12AffineFastState.compose env43609 (packedSelected [0,2,4,6,7,9,12,14,15,16,20] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound43609 : packedSelected [0,2,4,6,7,9,12,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env43610 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,348,4112,1,114,4096,2420,321,0,4160,249,152,83,468,65,2340,4525,4313,2557,489,341,256,261,4588,593]

theorem envBound43610 : H12AffineFastState.Bounded env43610 := by
  intro p hp
  have h : env43610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43609_43610 : H12AffineEnvironment.transform 9 321 env43609 = env43610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env43609 == env43610) = true)

theorem identity43610 : scanCanonicalize (H12AffineFastState.compose env43610 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound43610 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env43611 : List Nat := [2,4,8,16,32,64,128,116,512,53,2048,4096,40,4112,1,114,4096,2048,53,0,4160,249,152,83,160,65,2128,4313,4313,2185,157,33,116,113,4248,593]

theorem envBound43611 : H12AffineFastState.Bounded env43611 := by
  intro p hp
  have h : env43611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43610_43611 : H12AffineEnvironment.transform 7 116 env43610 = env43611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env43610 == env43611) = true)

theorem identity43611 : scanCanonicalize (H12AffineFastState.compose env43611 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43611 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43612 : List Nat := [2,4,8,16,32,16,128,36,512,53,2048,4096,40,4112,1,34,4096,2048,53,0,4112,169,152,3,160,17,2048,4233,4233,2185,157,33,36,33,4248,513]

theorem envBound43612 : H12AffineFastState.Bounded env43612 := by
  intro p hp
  have h : env43612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43611_43612 : H12AffineEnvironment.transform 5 16 env43611 = env43612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43611 == env43612) = true)

theorem identity43612 : scanCanonicalize (H12AffineFastState.compose env43612 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound43612 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env43613 : List Nat := [2,4,8,16,32,16,128,36,512,53,0,4096,40,4112,1,34,4096,0,53,0,4112,169,152,3,160,17,0,4233,4233,137,157,33,36,33,4248,513]

theorem envBound43613 : H12AffineFastState.Bounded env43613 := by
  intro p hp
  have h : env43613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43612_43613 : H12AffineEnvironment.transform 10 0 env43612 = env43613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env43612 == env43613) = true)

theorem identity43613 : scanCanonicalize (H12AffineFastState.compose env43613 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound43613 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env43614 : List Nat := [2,4,8,16,32,16,128,36,512,53,0,16,40,0,1,34,16,0,53,0,0,169,152,3,160,17,0,153,153,137,157,33,36,33,136,513]

theorem envBound43614 : H12AffineFastState.Bounded env43614 := by
  intro p hp
  have h : env43614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43613_43614 : H12AffineEnvironment.transform 11 16 env43613 = env43614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env43613 == env43614) = true)

theorem identity43614 : scanCanonicalize (H12AffineFastState.compose env43614 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43614 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43615 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,16,40,0,1,34,16,0,53,0,0,33,16,3,40,17,0,17,17,1,21,33,36,33,0,513]

theorem envBound43615 : H12AffineFastState.Bounded env43615 := by
  intro p hp
  have h : env43615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43614_43615 : H12AffineEnvironment.transform 6 8 env43614 = env43615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43614 == env43615) = true)

theorem identity43615 : scanCanonicalize (H12AffineFastState.compose env43615 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43615 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43616 : List Nat := [2,4,8,16,0,16,8,4,512,21,0,16,8,0,1,2,16,0,21,0,0,1,16,3,8,17,0,17,17,1,21,1,4,1,0,513]

theorem envBound43616 : H12AffineFastState.Bounded env43616 := by
  intro p hp
  have h : env43616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43615_43616 : H12AffineEnvironment.transform 4 0 env43615 = env43616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43615 == env43616) = true)

def env43617 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,169401,156117,21762,8328,65,215366,115150,140485,35324,241863,243003,256,254011,197023,169744]

theorem envBound43617 : H12AffineFastState.Bounded env43617 := by
  intro p hp
  have h : env43617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43588_43617 : H12AffineEnvironment.transform 17 10281 env43588 = env43617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env43588 == env43617) = true)

def env43618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1024,32769,4160,21929,41413,21762,8328,65,100694,115150,58581,35324,94423,95531,256,73771,115087,22272]

theorem envBound43618 : H12AffineFastState.Bounded env43618 := by
  intro p hp
  have h : env43618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43617_43618 : H12AffineEnvironment.transform 16 49168 env43617 = env43618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env43617 == env43618) = true)

theorem identity43618 : scanCanonicalize (H12AffineFastState.compose env43618 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43618 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43619 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1024,32769,4160,21792,41292,21762,8193,65,100694,115015,58460,35189,94302,95531,256,73771,114950,22272]

theorem envBound43619 : H12AffineFastState.Bounded env43619 := by
  intro p hp
  have h : env43619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43618_43619 : H12AffineEnvironment.transform 6 9 env43618 = env43619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43618 == env43619) = true)

theorem identity43619 : scanCanonicalize (H12AffineFastState.compose env43619 (packedSelected [0,3,4,10,12,14,15,16,22,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound43619 : packedSelected [0,3,4,10,12,14,15,16,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env43620 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21841,65536,5441,10281,1024,21840,4160,21792,29725,21762,8193,65,89095,70678,12557,23588,94302,95531,256,73771,70743,22272]

theorem envBound43620 : H12AffineFastState.Bounded env43620 := by
  intro p hp
  have h : env43620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43619_43620 : H12AffineEnvironment.transform 14 21841 env43619 = env43620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env43619 == env43620) = true)

theorem identity43620 : scanCanonicalize (H12AffineFastState.compose env43620 (packedSelected [0,2,3,6,7,10,11,16,18,19,24] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound43620 : packedSelected [0,2,3,6,7,10,11,16,18,19,24] rootPS < 2^1333 := by decide +kernel

def env43621 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21841,262,5441,10281,1024,21840,4160,21792,29725,21762,8193,65,23809,5392,12557,23588,29016,29741,256,8493,5457,22272]

theorem envBound43621 : H12AffineFastState.Bounded env43621 := by
  intro p hp
  have h : env43621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43620_43621 : H12AffineEnvironment.transform 15 262 env43620 = env43621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env43620 == env43621) = true)

theorem identity43621 : scanCanonicalize (H12AffineFastState.compose env43621 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound43621 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env43622 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8461,262,5441,10281,1024,8460,4160,8572,65,8542,8193,65,10589,5392,12557,10360,1284,113,256,8493,5457,9052]

theorem envBound43622 : H12AffineFastState.Bounded env43622 := by
  intro p hp
  have h : env43622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43621_43622 : H12AffineEnvironment.transform 13 13404 env43621 = env43622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env43621 == env43622) = true)

theorem identity43622 : scanCanonicalize (H12AffineFastState.compose env43622 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound43622 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43623 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5456,1,262,5441,2341,1024,0,4160,112,65,82,269,65,2129,5392,4097,2420,1284,113,256,33,5457,592]

theorem envBound43623 : H12AffineFastState.Bounded env43623 := by
  intro p hp
  have h : env43623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43622_43623 : H12AffineEnvironment.transform 12 268 env43622 = env43623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env43622 == env43623) = true)

theorem identity43623 : scanCanonicalize (H12AffineFastState.compose env43623 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43623 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env43624 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,1,262,5392,2341,1024,0,4113,33,16,3,269,16,2048,5392,4097,2341,1284,32,256,33,5376,513]

theorem envBound43624 : H12AffineFastState.Bounded env43624 := by
  intro p hp
  have h : env43624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43623_43624 : H12AffineEnvironment.transform 5 17 env43623 = env43624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43623 == env43624) = true)

theorem identity43624 : scanCanonicalize (H12AffineFastState.compose env43624 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound43624 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43625 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5157,1,34,5172,2049,1024,0,4113,33,16,3,41,16,2048,5172,4097,2049,1056,32,36,33,5156,513]

theorem envBound43625 : H12AffineFastState.Bounded env43625 := by
  intro p hp
  have h : env43625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43624_43625 : H12AffineEnvironment.transform 7 36 env43624 = env43625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env43624 == env43625) = true)

theorem identity43625 : scanCanonicalize (H12AffineFastState.compose env43625 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound43625 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43626 : List Nat := [2,4,8,16,32,17,9,36,512,1024,522,4096,40,5157,1,34,5172,523,1024,0,4113,33,16,3,41,16,522,5172,4097,523,1056,32,36,33,5156,513]

theorem envBound43626 : H12AffineFastState.Bounded env43626 := by
  intro p hp
  have h : env43626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43625_43626 : H12AffineEnvironment.transform 10 522 env43625 = env43626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env43625 == env43626) = true)

theorem identity43626 : scanCanonicalize (H12AffineFastState.compose env43626 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43626 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43627 : List Nat := [2,4,8,16,0,17,9,4,512,1024,522,4096,8,5125,1,2,5140,523,1024,0,4113,1,16,3,9,16,522,5140,4097,523,1024,0,4,1,5124,513]

theorem envBound43627 : H12AffineFastState.Bounded env43627 := by
  intro p hp
  have h : env43627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43626_43627 : H12AffineEnvironment.transform 4 0 env43626 = env43627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43626 == env43627) = true)

def env43628 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1024,32769,4160,21928,41412,21762,8328,65,100695,115150,58580,35324,94422,95530,256,73770,115086,22273]

theorem envBound43628 : H12AffineFastState.Bounded env43628 := by
  intro p hp
  have h : env43628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43617_43628 : H12AffineEnvironment.transform 16 49169 env43617 = env43628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env43617 == env43628) = true)

theorem identity43628 : scanCanonicalize (H12AffineFastState.compose env43628 (packedSelected [0,1,2,3,5,6,7,11,14,15,18,20,26,28,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 21726) := by decide +kernel

theorem selectedBound43628 : packedSelected [0,1,2,3,5,6,7,11,14,15,18,20,26,28,35,38] rootPS < 2^1333 := by decide +kernel

def env43629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,21726,49169,10281,1024,32769,4160,21928,41412,21762,8328,65,56713,38160,58580,35324,9224,8692,256,29940,38224,22273]

theorem envBound43629 : H12AffineFastState.Bounded env43629 := by
  intro p hp
  have h : env43629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43628_43629 : H12AffineEnvironment.transform 15 21726 env43628 = env43629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21726 env43628 == env43629) = true)

theorem identity43629 : scanCanonicalize (H12AffineFastState.compose env43629 (packedSelected [2,5,6,7,9,20,22,23,24,26,27,32] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound43629 : packedSelected [2,5,6,7,9,20,22,23,24,26,27,32] rootPS < 2^1333 := by decide +kernel

def env43630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,478,38161,10281,1024,32769,4160,168,41412,2,8328,65,34953,38160,45524,35324,9224,8692,256,8692,38224,513]

theorem envBound43630 : H12AffineFastState.Bounded env43630 := by
  intro p hp
  have h : env43630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43629_43630 : H12AffineEnvironment.transform 13 5376 env43629 = env43630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env43629 == env43630) = true)

theorem identity43630 : scanCanonicalize (H12AffineFastState.compose env43630 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound43630 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env43631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,137,478,5528,10281,1024,136,4160,168,8525,2,8328,65,2048,5529,12637,2421,9224,8692,256,8692,5593,513]

theorem envBound43631 : H12AffineFastState.Bounded env43631 := by
  intro p hp
  have h : env43631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43630_43631 : H12AffineEnvironment.transform 14 137 env43630 = env43631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env43630 == env43631) = true)

theorem identity43631 : scanCanonicalize (H12AffineFastState.compose env43631 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43631 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43632 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,0,343,5393,10281,1024,1,4160,33,8525,2,8193,65,2048,5392,12637,2421,9224,8573,256,8573,5456,513]

theorem envBound43632 : H12AffineFastState.Bounded env43632 := by
  intro p hp
  have h : env43632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43631_43632 : H12AffineEnvironment.transform 6 9 env43631 = env43632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43631 == env43632) = true)

theorem identity43632 : scanCanonicalize (H12AffineFastState.compose env43632 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound43632 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43633 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,0,343,5393,2340,1024,1,4160,33,64,2,268,65,2048,5392,4176,2421,1285,112,256,112,5456,513]

theorem envBound43633 : H12AffineFastState.Bounded env43633 := by
  intro p hp
  have h : env43633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43632_43633 : H12AffineEnvironment.transform 12 269 env43632 = env43633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env43632 == env43633) = true)

theorem identity43633 : scanCanonicalize (H12AffineFastState.compose env43633 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound43633 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env43634 : List Nat := [2,4,8,16,32,64,9,256,512,305,2048,4096,269,4145,0,343,4128,2340,305,1,4160,33,64,2,268,65,2048,4129,4176,2421,52,112,256,112,4193,513]

theorem envBound43634 : H12AffineFastState.Bounded env43634 := by
  intro p hp
  have h : env43634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43633_43634 : H12AffineEnvironment.transform 9 305 env43633 = env43634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env43633 == env43634) = true)

theorem identity43634 : scanCanonicalize (H12AffineFastState.compose env43634 (packedSelected [2,3,5,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43634 : packedSelected [2,3,5,11] rootPS < 2^1333 := by decide +kernel

def env43635 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,269,4145,0,263,4128,2340,305,1,4112,33,16,2,268,17,2048,4129,4096,2341,52,32,256,32,4145,513]

theorem envBound43635 : H12AffineFastState.Bounded env43635 := by
  intro p hp
  have h : env43635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43634_43635 : H12AffineEnvironment.transform 5 16 env43634 = env43635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43634 == env43635) = true)

def env43636 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169400,412156,21763,8328,65,215366,115150,396525,35324,497903,243002,256,509970,469430,442168]

theorem envBound43636 : H12AffineFastState.Bounded env43636 := by
  intro p hp
  have h : env43636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43587_43636 : H12AffineEnvironment.transform 20 4161 env43587 = env43636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env43587 == env43636) = true)

theorem identity43636 : scanCanonicalize (H12AffineFastState.compose env43636 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179513) := by decide +kernel

theorem selectedBound43636 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,169400,62661,21763,8328,65,215366,115150,45524,35324,75222,243002,256,95531,103567,513]

theorem envBound43637 : H12AffineFastState.Bounded env43637 := by
  intro p hp
  have h : env43637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43636_43637 : H12AffineEnvironment.transform 17 179513 env43636 = env43637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env43636 == env43637) = true)

def env43638 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,169264,62541,21763,8192,65,215366,115014,45404,35188,75102,243002,256,95531,103431,513]

theorem envBound43638 : H12AffineFastState.Bounded env43638 := by
  intro p hp
  have h : env43638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43637_43638 : H12AffineEnvironment.transform 6 8 env43637 = env43638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43637 == env43638) = true)

theorem identity43638 : scanCanonicalize (H12AffineFastState.compose env43638 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound43638 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env43639 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,122147,1024,32769,4161,128298,62541,21763,8192,65,10588,115014,45404,35188,75102,54560,256,95531,103431,513]

theorem envBound43639 : H12AffineFastState.Bounded env43639 := by
  intro p hp
  have h : env43639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43638_43639 : H12AffineEnvironment.transform 16 90138 env43638 = env43639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env43638 == env43639) = true)

theorem identity43639 : scanCanonicalize (H12AffineFastState.compose env43639 (packedSelected [0,3,5,10,12,14,18,23,27,38] rootPS)) = affineNative (2^(14+1) ^^^ 20788) := by decide +kernel

theorem selectedBound43639 : packedSelected [0,3,5,10,12,14,18,23,27,38] rootPS < 2^1333 := by decide +kernel

def env43640 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,20788,65536,90138,68631,1024,20789,4161,74782,9593,21763,8192,65,10588,69746,24680,22592,75102,1044,256,95531,83251,513]

theorem envBound43640 : H12AffineFastState.Bounded env43640 := by
  intro p hp
  have h : env43640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43639_43640 : H12AffineEnvironment.transform 14 20788 env43639 = env43640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20788 env43639 == env43640) = true)

theorem identity43640 : scanCanonicalize (H12AffineFastState.compose env43640 (packedSelected [7,8,10,14,17,20,23,27,28,32] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound43640 : packedSelected [7,8,10,14,17,20,23,27,28,32] rootPS < 2^1333 := by decide +kernel

def env43641 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,16384,20788,65536,83031,68631,1024,20789,4161,65619,308,21763,1101,65,3345,69746,17445,22592,65811,1044,256,86374,83251,513]

theorem envBound43641 : H12AffineFastState.Bounded env43641 := by
  intro p hp
  have h : env43641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43640_43641 : H12AffineEnvironment.transform 12 1101 env43640 = env43641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env43640 == env43641) = true)

theorem identity43641 : scanCanonicalize (H12AffineFastState.compose env43641 (packedSelected [0,1,2,4,5,6,9,10,11,12,15,17,18,20,24,27,28] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound43641 : packedSelected [0,1,2,4,5,6,9,10,11,12,15,17,18,20,24,27,28] rootPS < 2^1333 := by decide +kernel

def env43642 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,269,16384,20788,65536,82199,67927,320,20789,4161,65619,308,20547,269,65,2129,69746,16741,22592,65811,340,256,86374,82035,513]

theorem envBound43642 : H12AffineFastState.Bounded env43642 := by
  intro p hp
  have h : env43642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43641_43642 : H12AffineEnvironment.transform 9 320 env43641 = env43642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env43641 == env43642) = true)

theorem identity43642 : scanCanonicalize (H12AffineFastState.compose env43642 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 20579) := by decide +kernel

theorem selectedBound43642 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env43643 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,269,16384,20788,20579,4468,22836,320,20789,4161,20528,308,20547,269,65,2129,16401,16741,22592,20848,340,256,261,4112,513]

theorem envBound43643 : H12AffineFastState.Bounded env43643 := by
  intro p hp
  have h : env43643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43642_43643 : H12AffineEnvironment.transform 15 20579 env43642 = env43643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20579 env43642 == env43643) = true)

theorem identity43643 : scanCanonicalize (H12AffineFastState.compose env43643 (packedSelected [0,4,7,9,14,17] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound43643 : packedSelected [0,4,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env43644 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,269,4113,293,114,4468,2341,320,292,4161,33,308,82,269,65,2129,4096,4468,2129,353,340,256,261,4112,513]

theorem envBound43644 : H12AffineFastState.Bounded env43644 := by
  intro p hp
  have h : env43644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43643_43644 : H12AffineEnvironment.transform 13 4113 env43643 = env43644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env43643 == env43644) = true)

theorem identity43644 : scanCanonicalize (H12AffineFastState.compose env43644 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound43644 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43645 : List Nat := [2,4,8,16,32,64,8,116,512,52,2048,4096,121,4113,81,114,4096,2129,52,80,4161,33,64,82,121,65,2129,4096,4096,2129,21,32,116,113,4112,513]

theorem envBound43645 : H12AffineFastState.Bounded env43645 := by
  intro p hp
  have h : env43645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43644_43645 : H12AffineEnvironment.transform 7 116 env43644 = env43645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env43644 == env43645) = true)

theorem identity43645 : scanCanonicalize (H12AffineFastState.compose env43645 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound43645 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43646 : List Nat := [2,4,8,16,32,64,8,116,512,52,2048,529,121,512,81,114,529,2129,52,80,592,33,64,82,121,65,2129,529,529,2129,21,32,116,113,513,513]

theorem envBound43646 : H12AffineFastState.Bounded env43646 := by
  intro p hp
  have h : env43646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43645_43646 : H12AffineEnvironment.transform 11 529 env43645 = env43646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env43645 == env43646) = true)

theorem identity43646 : scanCanonicalize (H12AffineFastState.compose env43646 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound43646 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43647 : List Nat := [2,4,8,16,32,64,8,116,0,52,2048,17,121,0,81,114,17,2129,52,80,80,33,64,82,121,65,2129,17,17,2129,21,32,116,113,1,1]

theorem envBound43647 : H12AffineFastState.Bounded env43647 := by
  intro p hp
  have h : env43647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43646_43647 : H12AffineEnvironment.transform 8 0 env43646 = env43647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env43646 == env43647) = true)

theorem identity43647 : scanCanonicalize (H12AffineFastState.compose env43647 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound43647 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43648 : List Nat := [2,4,8,16,32,0,8,52,0,52,2048,17,57,0,17,50,17,2065,52,16,16,33,0,18,57,1,2065,17,17,2065,21,32,52,49,1,1]

theorem envBound43648 : H12AffineFastState.Bounded env43648 := by
  intro p hp
  have h : env43648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43647_43648 : H12AffineEnvironment.transform 5 0 env43647 = env43648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env43647 == env43648) = true)

theorem identity43648 : scanCanonicalize (H12AffineFastState.compose env43648 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43648 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43649 : List Nat := [2,4,8,16,1,0,8,21,0,21,2048,17,24,0,17,19,17,2065,21,16,16,0,0,18,24,1,2065,17,17,2065,21,1,21,16,1,1]

theorem envBound43649 : H12AffineFastState.Bounded env43649 := by
  intro p hp
  have h : env43649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43648_43649 : H12AffineEnvironment.transform 4 1 env43648 = env43649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43648 == env43649) = true)

theorem identity43649 : scanCanonicalize (H12AffineFastState.compose env43649 (packedSelected [7] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound43649 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env43650 : List Nat := [2,4,8,16,1,0,8,21,0,21,17,17,24,0,17,19,17,0,21,16,16,0,0,18,24,1,0,17,17,0,21,1,21,16,1,1]

theorem envBound43650 : H12AffineFastState.Bounded env43650 := by
  intro p hp
  have h : env43650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43649_43650 : H12AffineEnvironment.transform 10 17 env43649 = env43650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env43649 == env43650) = true)

def env43651 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,169265,62540,21763,8193,65,215366,115015,45405,35189,75103,243002,256,95531,103430,513]

theorem envBound43651 : H12AffineFastState.Bounded env43651 := by
  intro p hp
  have h : env43651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43637_43651 : H12AffineEnvironment.transform 6 9 env43637 = env43651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43637 == env43651) = true)

theorem identity43651 : scanCanonicalize (H12AffineFastState.compose env43651 (packedSelected [4,7,9,11,12,15,17,27,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound43651 : packedSelected [4,7,9,11,12,15,17,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env43652 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1024,32769,4161,33,62540,21763,8193,65,121942,115015,45405,35189,75103,73770,256,95531,103430,513]

theorem envBound43652 : H12AffineFastState.Bounded env43652 := by
  intro p hp
  have h : env43652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43651_43652 : H12AffineEnvironment.transform 16 38160 env43651 = env43652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env43651 == env43652) = true)

theorem identity43652 : scanCanonicalize (H12AffineFastState.compose env43652 (packedSelected [1,2,3,4,5,6,8,9,11,12,14,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound43652 : packedSelected [1,2,3,4,5,6,8,9,11,12,14,18,20] rootPS < 2^1333 := by decide +kernel

def env43653 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8460,65536,13340,10281,1024,8461,4161,33,21824,21763,8193,65,97626,90187,4177,10361,75103,73770,256,95531,79114,513]

theorem envBound43653 : H12AffineFastState.Bounded env43653 := by
  intro p hp
  have h : env43653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43652_43653 : H12AffineEnvironment.transform 14 8460 env43652 = env43653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env43652 == env43653) = true)

theorem identity43653 : scanCanonicalize (H12AffineFastState.compose env43653 (packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound43653 : packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env43654 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8460,30043,13340,10281,1024,8461,4161,33,21824,21763,8193,65,2049,5392,4177,10361,20484,21873,256,112,16465,513]

theorem envBound43654 : H12AffineFastState.Bounded env43654 := by
  intro p hp
  have h : env43654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43653_43654 : H12AffineEnvironment.transform 15 30043 env43653 = env43654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env43653 == env43654) = true)

theorem identity43654 : scanCanonicalize (H12AffineFastState.compose env43654 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound43654 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env43655 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,0,21591,5392,2341,1024,1,4161,33,21824,21763,269,65,2049,5392,4177,2421,20484,21873,256,112,16465,513]

theorem envBound43655 : H12AffineFastState.Bounded env43655 := by
  intro p hp
  have h : env43655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43654_43655 : H12AffineEnvironment.transform 12 268 env43654 = env43655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env43654 == env43655) = true)

theorem identity43655 : scanCanonicalize (H12AffineFastState.compose env43655 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound43655 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env43656 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,0,342,5392,2341,1024,1,4161,33,65,2,269,65,2049,5392,4177,2421,1285,112,256,112,5456,513]

theorem envBound43656 : H12AffineFastState.Bounded env43656 := by
  intro p hp
  have h : env43656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43655_43656 : H12AffineEnvironment.transform 13 5377 env43655 = env43656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env43655 == env43656) = true)

theorem identity43656 : scanCanonicalize (H12AffineFastState.compose env43656 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43656 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43657 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,0,262,5392,2341,1024,1,4113,33,17,2,269,17,2049,5392,4097,2341,1285,32,256,32,5376,513]

theorem envBound43657 : H12AffineFastState.Bounded env43657 := by
  intro p hp
  have h : env43657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43656_43657 : H12AffineEnvironment.transform 5 16 env43656 = env43657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43656 == env43657) = true)

theorem identity43657 : scanCanonicalize (H12AffineFastState.compose env43657 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound43657 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43658 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,0,268,1281,0,262,1296,2341,1024,1,17,33,17,2,269,17,2049,1296,1,2341,1285,32,256,32,1280,513]

theorem envBound43658 : H12AffineFastState.Bounded env43658 := by
  intro p hp
  have h : env43658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43657_43658 : H12AffineEnvironment.transform 11 0 env43657 = env43658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env43657 == env43658) = true)

theorem identity43658 : scanCanonicalize (H12AffineFastState.compose env43658 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 319) := by decide +kernel

theorem selectedBound43658 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43659 : List Nat := [2,4,8,16,32,16,9,256,512,1024,319,0,268,1281,0,262,1296,26,1024,1,17,33,17,2,269,17,318,1296,1,26,1285,32,256,32,1280,513]

theorem envBound43659 : H12AffineFastState.Bounded env43659 := by
  intro p hp
  have h : env43659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43658_43659 : H12AffineEnvironment.transform 10 319 env43658 = env43659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 319 env43658 == env43659) = true)

theorem identity43659 : scanCanonicalize (H12AffineFastState.compose env43659 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound43659 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43660 : List Nat := [2,4,8,16,32,16,9,256,512,21,319,0,268,276,0,262,261,26,21,1,17,33,17,2,269,17,318,261,1,26,272,32,256,32,277,513]

theorem envBound43660 : H12AffineFastState.Bounded env43660 := by
  intro p hp
  have h : env43660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43659_43660 : H12AffineEnvironment.transform 9 21 env43659 = env43660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env43659 == env43660) = true)

theorem identity43660 : scanCanonicalize (H12AffineFastState.compose env43660 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound43660 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43661 : List Nat := [2,4,8,16,32,16,9,53,512,21,10,0,57,33,0,51,48,26,21,1,17,33,17,2,56,17,11,48,1,26,37,32,53,32,32,513]

theorem envBound43661 : H12AffineFastState.Bounded env43661 := by
  intro p hp
  have h : env43661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43660_43661 : H12AffineEnvironment.transform 7 53 env43660 = env43661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env43660 == env43661) = true)

theorem identity43661 : scanCanonicalize (H12AffineFastState.compose env43661 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound43661 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43662 : List Nat := [2,4,8,16,27,16,9,14,512,21,10,0,2,26,0,8,11,26,21,1,17,26,17,2,3,17,11,11,1,26,30,27,14,27,27,513]

theorem envBound43662 : H12AffineFastState.Bounded env43662 := by
  intro p hp
  have h : env43662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43661_43662 : H12AffineEnvironment.transform 4 27 env43661 = env43662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env43661 == env43662) = true)

theorem identity43662 : scanCanonicalize (H12AffineFastState.compose env43662 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound43662 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env43663 : List Nat := [2,4,3,16,16,16,2,5,512,21,1,0,2,17,0,3,0,17,21,1,17,17,17,2,3,17,0,0,1,17,21,16,5,16,16,513]

theorem envBound43663 : H12AffineFastState.Bounded env43663 := by
  intro p hp
  have h : env43663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43662_43663 : H12AffineEnvironment.transform 2 3 env43662 = env43663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env43662 == env43663) = true)

theorem identity43663 : scanCanonicalize (H12AffineFastState.compose env43663 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 18) := by decide +kernel

theorem selectedBound43663 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43664 : List Nat := [2,4,3,16,16,16,2,5,18,21,1,0,2,17,0,3,0,17,21,1,17,17,17,2,3,17,0,0,1,17,21,16,5,16,16,19]

theorem envBound43664 : H12AffineFastState.Bounded env43664 := by
  intro p hp
  have h : env43664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43663_43664 : H12AffineEnvironment.transform 8 18 env43663 = env43664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 18 env43663 == env43664) = true)

theorem identity43664 : scanCanonicalize (H12AffineFastState.compose env43664 (packedSelected [0,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound43664 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env43665 : List Nat := [2,4,3,0,0,0,2,5,2,5,1,0,2,1,0,3,0,1,5,1,1,1,1,2,3,1,0,0,1,1,5,0,5,0,0,3]

theorem envBound43665 : H12AffineFastState.Bounded env43665 := by
  intro p hp
  have h : env43665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43664_43665 : H12AffineEnvironment.transform 3 0 env43664 = env43665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env43664 == env43665) = true)

theorem identity43665 : scanCanonicalize (H12AffineFastState.compose env43665 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound43665 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43666 : List Nat := [2,0,3,0,0,0,2,1,2,1,1,0,2,1,0,3,0,1,1,1,1,1,1,2,3,1,0,0,1,1,1,0,1,0,0,3]

theorem envBound43666 : H12AffineFastState.Bounded env43666 := by
  intro p hp
  have h : env43666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43665_43666 : H12AffineEnvironment.transform 1 0 env43665 = env43666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env43665 == env43666) = true)

def env43667 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,412157,2114883,8328,65,6409407,115151,2497709,35325,2590894,4268163,256,509970,469430,2535289]

theorem envBound43667 : H12AffineFastState.Bounded env43667 := by
  intro p hp
  have h : env43667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43533_43667 : H12AffineEnvironment.transform 22 412157 env43533 = env43667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 412157 env43533 == env43667) = true)

def env43668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262520,412157,2114883,8328,65,215367,115151,2497709,35325,2590894,2336123,256,509970,469430,2535289]

theorem envBound43668 : H12AffineFastState.Bounded env43668 := by
  intro p hp
  have h : env43668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43667_43668 : H12AffineEnvironment.transform 21 2262520 env43667 = env43668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262520 env43667 == env43668) = true)

def env43669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169400,412157,21763,8328,65,215367,115151,396525,35325,497902,243003,256,509970,469430,442169]

theorem envBound43669 : H12AffineFastState.Bounded env43669 := by
  intro p hp
  have h : env43669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43668_43669 : H12AffineEnvironment.transform 20 4160 env43668 = env43669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env43668 == env43669) = true)

theorem identity43669 : scanCanonicalize (H12AffineFastState.compose env43669 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236851) := by decide +kernel

theorem selectedBound43669 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43670 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236851,1024,32769,4160,169400,120014,21763,8328,65,215367,115151,102878,35325,1501,243003,256,21793,46213,74250]

theorem envBound43670 : H12AffineFastState.Bounded env43670 := by
  intro p hp
  have h : env43670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43669_43670 : H12AffineEnvironment.transform 17 236851 env43669 = env43670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236851 env43669 == env43670) = true)

def env43671 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,130175,1024,32769,4160,62708,120014,21763,8328,65,75787,115151,102878,35325,1501,119927,256,21793,46213,74250]

theorem envBound43671 : H12AffineFastState.Bounded env43671 := by
  intro p hp
  have h : env43671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43670_43671 : H12AffineEnvironment.transform 16 24908 env43670 = env43671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env43670 == env43671) = true)

def env43672 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,130175,1024,32769,4160,62588,119878,21763,8192,65,75787,115015,102742,35189,1365,119927,256,21793,46093,74250]

theorem envBound43672 : H12AffineFastState.Bounded env43672 := by
  intro p hp
  have h : env43672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43671_43672 : H12AffineEnvironment.transform 6 8 env43671 = env43672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43671 == env43672) = true)

theorem identity43672 : scanCanonicalize (H12AffineFastState.compose env43672 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound43672 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43673 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,24908,35189,1024,32769,4160,62588,41292,21763,8192,65,23809,46157,58460,35189,1365,41341,256,21793,46093,22272]

theorem envBound43673 : H12AffineFastState.Bounded env43673 := by
  intro p hp
  have h : env43673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43672_43673 : H12AffineEnvironment.transform 15 29962 env43672 = env43673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env43672 == env43673) = true)

theorem identity43673 : scanCanonicalize (H12AffineFastState.compose env43673 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound43673 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env43674 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21840,29962,24908,23589,1024,21841,4160,8492,29724,21763,8192,65,23809,24861,12556,23589,1365,29741,256,21793,24925,22272]

theorem envBound43674 : H12AffineFastState.Bounded env43674 := by
  intro p hp
  have h : env43674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43673_43674 : H12AffineEnvironment.transform 14 21840 env43673 = env43674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env43673 == env43674) = true)

theorem identity43674 : scanCanonicalize (H12AffineFastState.compose env43674 (packedSelected [3,5,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 15453) := by decide +kernel

theorem selectedBound43674 : packedSelected [3,5,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env43675 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,15453,10509,2391,7441,8312,1024,10508,4160,8492,2113,10590,8192,65,8540,7488,12556,8312,1365,2160,256,10620,7424,11101]

theorem envBound43675 : H12AffineFastState.Bounded env43675 := by
  intro p hp
  have h : env43675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43674_43675 : H12AffineEnvironment.transform 13 15453 env43674 = env43675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15453 env43674 == env43675) = true)

theorem identity43675 : scanCanonicalize (H12AffineFastState.compose env43675 (packedSelected [0,1,4,6,7,8,9,12,15,19] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound43675 : packedSelected [0,1,4,6,7,8,9,12,15,19] rootPS < 2^1333 := by decide +kernel

def env43676 : List Nat := [2,4,8,16,32,64,8,256,512,1024,293,4096,8192,13688,8232,114,5172,8312,1024,8233,4160,8492,356,8315,8192,65,8540,5221,12556,8312,1365,341,256,8281,5157,8824]

theorem envBound43676 : H12AffineFastState.Bounded env43676 := by
  intro p hp
  have h : env43676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43675_43676 : H12AffineEnvironment.transform 10 293 env43675 = env43676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env43675 == env43676) = true)

theorem identity43676 : scanCanonicalize (H12AffineFastState.compose env43676 (packedSelected [2,3,5,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound43676 : packedSelected [2,3,5,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env43677 : List Nat := [2,4,8,16,32,64,8,256,512,1024,293,4096,348,5156,372,114,5172,292,1024,373,4160,112,356,295,348,65,0,5221,4176,292,1365,341,256,261,5157,804]

theorem envBound43677 : H12AffineFastState.Bounded env43677 := by
  intro p hp
  have h : env43677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43676_43677 : H12AffineEnvironment.transform 12 348 env43676 = env43677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env43676 == env43677) = true)

theorem identity43677 : scanCanonicalize (H12AffineFastState.compose env43677 (packedSelected [2,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound43677 : packedSelected [2,7,9] rootPS < 2^1333 := by decide +kernel

def env43678 : List Nat := [2,4,8,16,32,64,8,4,512,1024,33,4096,88,5156,112,114,5172,32,1024,113,4160,112,96,35,88,65,0,5221,4176,32,1105,81,4,1,5157,544]

theorem envBound43678 : H12AffineFastState.Bounded env43678 := by
  intro p hp
  have h : env43678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43677_43678 : H12AffineEnvironment.transform 7 4 env43677 = env43678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env43677 == env43678) = true)

theorem identity43678 : scanCanonicalize (H12AffineFastState.compose env43678 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43678 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43679 : List Nat := [2,4,8,16,32,17,8,4,512,1024,33,4096,9,5156,33,35,5172,32,1024,32,4113,33,49,35,9,16,0,5172,4097,32,1024,0,4,1,5157,544]

theorem envBound43679 : H12AffineFastState.Bounded env43679 := by
  intro p hp
  have h : env43679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43678_43679 : H12AffineEnvironment.transform 5 17 env43678 = env43679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43678 == env43679) = true)

theorem identity43679 : scanCanonicalize (H12AffineFastState.compose env43679 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound43679 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env43680 : List Nat := [2,4,8,16,32,17,8,4,512,15,33,4096,9,4139,33,35,4155,32,15,32,4113,33,49,35,9,16,0,4155,4097,32,15,0,4,1,4138,544]

theorem envBound43680 : H12AffineFastState.Bounded env43680 := by
  intro p hp
  have h : env43680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43679_43680 : H12AffineEnvironment.transform 9 15 env43679 = env43680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env43679 == env43680) = true)

def env43681 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,130175,1024,32769,4160,62589,119879,21763,8193,65,75787,115014,102743,35188,1364,119927,256,21793,46092,74250]

theorem envBound43681 : H12AffineFastState.Bounded env43681 := by
  intro p hp
  have h : env43681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43671_43681 : H12AffineEnvironment.transform 6 9 env43671 = env43681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43671 == env43681) = true)

theorem identity43681 : scanCanonicalize (H12AffineFastState.compose env43681 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound43681 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43682 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,24908,10281,1024,32769,4160,62589,17,21763,8193,65,64605,5392,17665,35188,1364,33,256,21793,46092,63068]

theorem envBound43682 : H12AffineFastState.Bounded env43682 := by
  intro p hp
  have h : env43682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43681_43682 : H12AffineEnvironment.transform 15 54358 env43681 = env43682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env43681 == env43682) = true)

theorem identity43682 : scanCanonicalize (H12AffineFastState.compose env43682 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound43682 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43683 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,343,24908,10281,1024,21760,4160,8572,17,21763,8193,65,10588,5392,17665,23669,1364,33,256,21793,24845,9053]

theorem envBound43683 : H12AffineFastState.Bounded env43683 := by
  intro p hp
  have h : env43683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43682_43683 : H12AffineEnvironment.transform 14 21761 env43682 = env43683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env43682 == env43683) = true)

theorem identity43683 : scanCanonicalize (H12AffineFastState.compose env43683 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound43683 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env43684 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,343,16400,2421,1024,21760,4160,32,17,21763,349,65,2048,5392,17665,23669,1364,33,256,21793,16465,513]

theorem envBound43684 : H12AffineFastState.Bounded env43684 := by
  intro p hp
  have h : env43684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43683_43684 : H12AffineEnvironment.transform 12 348 env43683 = env43684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env43683 == env43684) = true)

theorem identity43684 : scanCanonicalize (H12AffineFastState.compose env43684 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43684 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43685 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,21761,262,16400,2340,1024,21760,4113,32,17,21763,268,16,2048,5392,17665,23588,1285,33,256,21793,16384,513]

theorem envBound43685 : H12AffineFastState.Bounded env43685 := by
  intro p hp
  have h : env43685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43684_43685 : H12AffineEnvironment.transform 5 17 env43684 = env43685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43684 == env43685) = true)

theorem identity43685 : scanCanonicalize (H12AffineFastState.compose env43685 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound43685 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env43686 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1281,269,16384,16384,262,16400,2340,1024,16385,1296,32,17,16386,268,16,2048,17,17665,18725,1285,33,256,16416,16384,513]

theorem envBound43686 : H12AffineFastState.Bounded env43686 := by
  intro p hp
  have h : env43686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43685_43686 : H12AffineEnvironment.transform 11 1281 env43685 = env43686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env43685 == env43686) = true)

theorem identity43686 : scanCanonicalize (H12AffineFastState.compose env43686 (packedSelected [1,5] rootPS)) = affineNative (2^(13+1) ^^^ 2603) := by decide +kernel

theorem selectedBound43686 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43687 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1281,269,2603,2603,262,2619,2340,1024,2602,1296,32,17,2601,268,16,2048,17,3882,782,1285,33,256,2571,2603,513]

theorem envBound43687 : H12AffineFastState.Bounded env43687 := by
  intro p hp
  have h : env43687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43686_43687 : H12AffineEnvironment.transform 13 2603 env43686 = env43687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2603 env43686 == env43687) = true)

theorem identity43687 : scanCanonicalize (H12AffineFastState.compose env43687 (packedSelected [1,2,8] rootPS)) = affineNative (2^(9+1) ^^^ 574) := by decide +kernel

theorem selectedBound43687 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env43688 : List Nat := [2,4,8,16,32,17,9,256,512,574,2048,831,269,2603,2603,262,2619,2340,574,2602,814,32,17,2601,268,16,2048,17,2324,782,827,33,256,2571,2603,513]

theorem envBound43688 : H12AffineFastState.Bounded env43688 := by
  intro p hp
  have h : env43688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43687_43688 : H12AffineEnvironment.transform 9 574 env43687 = env43688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 574 env43687 == env43688) = true)

theorem identity43688 : scanCanonicalize (H12AffineFastState.compose env43688 (packedSelected [0,2,9] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound43688 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env43689 : List Nat := [2,4,8,16,32,17,9,256,270,304,2048,49,269,2341,2341,262,2357,2340,304,2340,32,32,17,2343,268,16,2048,17,2324,0,53,33,256,2309,2341,271]

theorem envBound43689 : H12AffineFastState.Bounded env43689 := by
  intro p hp
  have h : env43689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43688_43689 : H12AffineEnvironment.transform 8 270 env43688 = env43689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env43688 == env43689) = true)

theorem identity43689 : scanCanonicalize (H12AffineFastState.compose env43689 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound43689 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env43690 : List Nat := [2,4,8,16,32,17,9,256,270,304,1,49,269,292,292,262,308,293,304,293,32,32,17,294,268,16,1,17,277,0,53,33,256,260,292,271]

theorem envBound43690 : H12AffineFastState.Bounded env43690 := by
  intro p hp
  have h : env43690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43689_43690 : H12AffineEnvironment.transform 10 1 env43689 = env43690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env43689 == env43690) = true)

theorem identity43690 : scanCanonicalize (H12AffineFastState.compose env43690 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 54) := by decide +kernel

theorem selectedBound43690 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43691 : List Nat := [2,4,8,16,32,17,9,54,56,6,1,49,59,18,18,48,2,19,6,19,32,32,17,16,58,16,1,17,35,0,53,33,54,50,18,57]

theorem envBound43691 : H12AffineFastState.Bounded env43691 := by
  intro p hp
  have h : env43691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43690_43691 : H12AffineEnvironment.transform 7 54 env43690 = env43691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 54 env43690 == env43691) = true)

theorem identity43691 : scanCanonicalize (H12AffineFastState.compose env43691 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound43691 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env43692 : List Nat := [2,4,8,2,32,3,9,36,42,6,1,35,41,0,0,34,2,1,6,1,32,32,3,2,40,2,1,3,35,0,39,33,36,32,0,43]

theorem envBound43692 : H12AffineFastState.Bounded env43692 := by
  intro p hp
  have h : env43692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43691_43692 : H12AffineEnvironment.transform 3 2 env43691 = env43692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env43691 == env43692) = true)

theorem identity43692 : scanCanonicalize (H12AffineFastState.compose env43692 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound43692 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43693 : List Nat := [2,4,6,2,32,3,7,36,36,6,1,35,39,0,0,34,2,1,6,1,32,32,3,2,38,2,1,3,35,0,39,33,36,32,0,37]

theorem envBound43693 : H12AffineFastState.Bounded env43693 := by
  intro p hp
  have h : env43693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43692_43693 : H12AffineEnvironment.transform 2 6 env43692 = env43693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env43692 == env43693) = true)

theorem identity43693 : scanCanonicalize (H12AffineFastState.compose env43693 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43693 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43694 : List Nat := [2,4,6,2,0,3,7,4,4,6,1,3,7,0,0,2,2,1,6,1,0,0,3,2,6,2,1,3,3,0,7,1,4,0,0,5]

theorem envBound43694 : H12AffineFastState.Bounded env43694 := by
  intro p hp
  have h : env43694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43693_43694 : H12AffineEnvironment.transform 4 0 env43693 = env43694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43693 == env43694) = true)

def env43695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,130174,1024,32769,4160,62709,120014,21763,8328,65,75786,115151,102878,35325,1501,119926,256,21793,46213,74250]

theorem envBound43695 : H12AffineFastState.Bounded env43695 := by
  intro p hp
  have h : env43695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43670_43695 : H12AffineEnvironment.transform 16 24909 env43670 = env43695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env43670 == env43695) = true)

def env43696 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,130174,1024,32769,4160,62589,119878,21763,8192,65,75786,115015,102742,35189,1365,119926,256,21793,46093,74250]

theorem envBound43696 : H12AffineFastState.Bounded env43696 := by
  intro p hp
  have h : env43696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43695_43696 : H12AffineEnvironment.transform 6 8 env43695 = env43696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43695 == env43696) = true)

theorem identity43696 : scanCanonicalize (H12AffineFastState.compose env43696 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound43696 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43697 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,24909,89379,1024,8540,4160,21792,95515,21763,8192,65,75786,90138,77835,10280,1365,95531,256,21793,5456,74250]

theorem envBound43697 : H12AffineFastState.Bounded env43697 := by
  intro p hp
  have h : env43697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43696_43697 : H12AffineEnvironment.transform 14 8541 env43696 = env43697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env43696 == env43697) = true)

def env43698 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,130174,1024,32769,4160,62588,119879,21763,8193,65,75786,115014,102743,35188,1364,119926,256,21793,46092,74250]

theorem envBound43698 : H12AffineFastState.Bounded env43698 := by
  intro p hp
  have h : env43698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43695_43698 : H12AffineEnvironment.transform 6 9 env43695 = env43698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43695 == env43698) = true)

theorem identity43698 : scanCanonicalize (H12AffineFastState.compose env43698 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound43698 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env43699 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,342,24909,64808,1024,32769,4160,62588,54545,21763,8193,65,10588,49168,36865,35188,1364,54560,256,21793,46092,9052]

theorem envBound43699 : H12AffineFastState.Bounded env43699 := by
  intro p hp
  have h : env43699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43698_43699 : H12AffineEnvironment.transform 15 342 env43698 = env43699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env43698 == env43699) = true)

theorem identity43699 : scanCanonicalize (H12AffineFastState.compose env43699 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound43699 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env43700 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,342,24909,2420,1024,29789,4160,32,8525,21763,8193,65,10588,13388,25693,32040,1364,8572,256,21793,16464,9052]

theorem envBound43700 : H12AffineFastState.Bounded env43700 := by
  intro p hp
  have h : env43700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43699_43700 : H12AffineEnvironment.transform 14 29788 env43699 = env43700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env43699 == env43700) = true)

theorem identity43700 : scanCanonicalize (H12AffineFastState.compose env43700 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound43700 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env43701 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,342,13389,2420,1024,8541,4160,32,8525,3,8193,65,10588,13388,12637,10280,1364,8572,256,33,5456,9052]

theorem envBound43701 : H12AffineFastState.Bounded env43701 := by
  intro p hp
  have h : env43701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43700_43701 : H12AffineEnvironment.transform 13 5376 env43700 = env43701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env43700 == env43701) = true)

theorem identity43701 : scanCanonicalize (H12AffineFastState.compose env43701 (packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound43701 : packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env43702 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5237,8233,35,13389,2049,1024,8232,4160,32,8248,3,8193,65,10281,13388,12328,10280,1057,8201,117,33,5157,8745]

theorem envBound43702 : H12AffineFastState.Bounded env43702 := by
  intro p hp
  have h : env43702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43701_43702 : H12AffineEnvironment.transform 7 117 env43701 = env43702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env43701 == env43702) = true)

theorem identity43702 : scanCanonicalize (H12AffineFastState.compose env43702 (packedSelected [0,3,4,5,6,7,9,10,11,23] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound43702 : packedSelected [0,3,4,5,6,7,9,10,11,23] rootPS < 2^1333 := by decide +kernel

def env43703 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5237,0,35,5220,2049,1024,1,4160,32,17,3,40,65,2048,5221,4097,2049,1057,32,117,33,5157,512]

theorem envBound43703 : H12AffineFastState.Bounded env43703 := by
  intro p hp
  have h : env43703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43702_43703 : H12AffineEnvironment.transform 12 41 env43702 = env43703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env43702 == env43703) = true)

theorem identity43703 : scanCanonicalize (H12AffineFastState.compose env43703 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound43703 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43704 : List Nat := [2,4,8,16,32,48,9,5,512,1024,2048,4096,41,5125,0,35,5140,2049,1024,1,4144,32,17,3,40,49,2048,5141,4097,2049,1057,32,5,33,5157,512]

theorem envBound43704 : H12AffineFastState.Bounded env43704 := by
  intro p hp
  have h : env43704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43703_43704 : H12AffineEnvironment.transform 5 48 env43703 = env43704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env43703 == env43704) = true)

theorem identity43704 : scanCanonicalize (H12AffineFastState.compose env43704 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43704 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43705 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,8,5125,0,2,5140,2049,1024,1,4113,1,17,3,9,16,2048,5141,4097,2049,1024,1,5,0,5124,512]

theorem envBound43705 : H12AffineFastState.Bounded env43705 := by
  intro p hp
  have h : env43705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43704_43705 : H12AffineEnvironment.transform 4 1 env43704 = env43705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43704 == env43705) = true)

theorem identity43705 : scanCanonicalize (H12AffineFastState.compose env43705 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound43705 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43706 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,3076,8,2049,0,2,2064,2049,1024,1,3093,1,17,3,9,16,2048,2065,3077,2049,1024,1,5,0,2048,512]

theorem envBound43706 : H12AffineFastState.Bounded env43706 := by
  intro p hp
  have h : env43706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43705_43706 : H12AffineEnvironment.transform 11 3076 env43705 = env43706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env43705 == env43706) = true)

theorem identity43706 : scanCanonicalize (H12AffineFastState.compose env43706 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound43706 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43707 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,2065,8,2049,0,2,2064,2049,21,1,2048,1,17,3,9,16,2048,2065,2064,2049,21,1,5,0,2048,512]

theorem envBound43707 : H12AffineFastState.Bounded env43707 := by
  intro p hp
  have h : env43707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43706_43707 : H12AffineEnvironment.transform 9 21 env43706 = env43707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env43706 == env43707) = true)

def env43708 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169401,412157,21762,8328,65,215367,115151,396524,35325,497903,243002,256,509970,469430,442168]

theorem envBound43708 : H12AffineFastState.Bounded env43708 := by
  intro p hp
  have h : env43708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43668_43708 : H12AffineEnvironment.transform 20 4161 env43668 = env43708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env43668 == env43708) = true)

theorem identity43708 : scanCanonicalize (H12AffineFastState.compose env43708 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound43708 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43709 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,4161,169401,412157,21762,8328,65,158028,57796,396524,35325,440548,169265,256,452633,395709,442168]

theorem envBound43709 : H12AffineFastState.Bounded env43709 := by
  intro p hp
  have h : env43709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43708_43709 : H12AffineEnvironment.transform 15 8203 env43708 = env43709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env43708 == env43709) = true)

theorem identity43709 : scanCanonicalize (H12AffineFastState.compose env43709 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 179513) := by decide +kernel

theorem selectedBound43709 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env43710 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179513,1024,32769,4161,169401,62660,21762,8328,65,158028,57796,45525,35325,1501,169265,256,21792,46212,513]

theorem envBound43710 : H12AffineFastState.Bounded env43710 := by
  intro p hp
  have h : env43710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43709_43710 : H12AffineEnvironment.transform 17 179513 env43709 = env43710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env43709 == env43710) = true)

theorem identity43710 : scanCanonicalize (H12AffineFastState.compose env43710 (packedSelected [11,12,15,16,18,20,23,32,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 21897) := by decide +kernel

theorem selectedBound43710 : packedSelected [11,12,15,16,18,20,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env43711 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21897,8203,131072,157872,1024,21896,4161,147504,8525,21762,8328,65,158028,13389,25692,23668,1501,147640,256,21792,24845,513]

theorem envBound43711 : H12AffineFastState.Bounded env43711 := by
  intro p hp
  have h : env43711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43710_43711 : H12AffineEnvironment.transform 14 21897 env43710 = env43711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21897 env43710 == env43711) = true)

theorem identity43711 : scanCanonicalize (H12AffineFastState.compose env43711 (packedSelected [1,2,5,6,7,8,14,15,16,17,18,23,24,27,38] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound43711 : packedSelected [1,2,5,6,7,8,14,15,16,17,18,23,24,27,38] rootPS < 2^1333 := by decide +kernel

def env43712 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,21841,8203,131072,157800,1024,21840,4161,147504,8525,21762,8272,65,158028,13389,25692,23668,1285,147552,256,21792,24845,513]

theorem envBound43712 : H12AffineFastState.Bounded env43712 := by
  intro p hp
  have h : env43712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43711_43712 : H12AffineEnvironment.transform 6 88 env43711 = env43712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env43711 == env43712) = true)

theorem identity43712 : scanCanonicalize (H12AffineFastState.compose env43712 (packedSelected [2,6,17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound43712 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env43713 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,21841,8203,24908,2340,1024,21840,4161,8572,8525,21762,8272,65,2048,13389,25692,23668,1285,8492,256,21792,24845,513]

theorem envBound43713 : H12AffineFastState.Bounded env43713 := by
  intro p hp
  have h : env43713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43712_43713 : H12AffineEnvironment.transform 16 24908 env43712 = env43713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env43712 == env43713) = true)

theorem identity43713 : scanCanonicalize (H12AffineFastState.compose env43713 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound43713 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env43714 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,16384,21841,342,16401,2340,1024,21840,4161,33,16,21762,269,65,2048,5392,17665,23668,1285,113,256,21792,16464,513]

theorem envBound43714 : H12AffineFastState.Bounded env43714 := by
  intro p hp
  have h : env43714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43713_43714 : H12AffineEnvironment.transform 12 349 env43713 = env43714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env43713 == env43714) = true)

theorem identity43714 : scanCanonicalize (H12AffineFastState.compose env43714 (packedSelected [2,5,7,8,9,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound43714 : packedSelected [2,5,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env43715 : List Nat := [2,4,8,16,32,64,88,256,512,101,2048,4096,349,16384,20788,342,16401,2340,101,20789,4161,33,16,20839,269,65,2048,4469,16740,22545,352,113,256,20805,16464,513]

theorem envBound43715 : H12AffineFastState.Bounded env43715 := by
  intro p hp
  have h : env43715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43714_43715 : H12AffineEnvironment.transform 9 101 env43714 = env43715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env43714 == env43715) = true)

theorem identity43715 : scanCanonicalize (H12AffineFastState.compose env43715 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 80) := by decide +kernel

theorem selectedBound43715 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43716 : List Nat := [2,4,8,16,32,64,88,256,512,101,2048,4096,349,80,4452,342,65,2340,101,4453,4161,33,16,4407,269,65,2048,4469,308,6209,352,113,256,4373,0,513]

theorem envBound43716 : H12AffineFastState.Bounded env43716 := by
  intro p hp
  have h : env43716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43715_43716 : H12AffineEnvironment.transform 13 80 env43715 = env43716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 80 env43715 == env43716) = true)

theorem identity43716 : scanCanonicalize (H12AffineFastState.compose env43716 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43716 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env43717 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,268,1,4405,263,16,2340,52,4404,4112,33,16,4407,269,16,2048,4388,308,6160,305,32,256,4373,0,513]

theorem envBound43717 : H12AffineFastState.Bounded env43717 := by
  intro p hp
  have h : env43717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43716_43717 : H12AffineEnvironment.transform 5 17 env43716 = env43717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43716 == env43717) = true)

def env43718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262521,412157,2114883,8328,65,215366,115151,2497709,35325,2590894,2336122,256,509970,469430,2535289]

theorem envBound43718 : H12AffineFastState.Bounded env43718 := by
  intro p hp
  have h : env43718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43667_43718 : H12AffineEnvironment.transform 21 2262521 env43667 = env43718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262521 env43667 == env43718) = true)

def env43719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169401,412157,21763,8328,65,215366,115151,396525,35325,497902,243002,256,509970,469430,442169]

theorem envBound43719 : H12AffineFastState.Bounded env43719 := by
  intro p hp
  have h : env43719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43718_43719 : H12AffineEnvironment.transform 20 4160 env43718 = env43719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env43718 == env43719) = true)

theorem identity43719 : scanCanonicalize (H12AffineFastState.compose env43719 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound43719 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,4160,169401,412157,21763,8328,65,171416,5393,396525,35325,412720,156132,256,400588,458088,442169]

theorem envBound43720 : H12AffineFastState.Bounded env43720 := by
  intro p hp
  have h : env43720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43719_43720 : H12AffineEnvironment.transform 15 54494 env43719 = env43720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env43719 == env43720) = true)

def env43721 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,262144,1024,32769,4112,169401,412077,21763,8328,17,171416,5393,396477,35245,412720,156084,256,400540,458040,442169]

theorem envBound43721 : H12AffineFastState.Bounded env43721 := by
  intro p hp
  have h : env43721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43720_43721 : H12AffineEnvironment.transform 5 16 env43720 = env43721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43720 == env43721) = true)

theorem identity43721 : scanCanonicalize (H12AffineFastState.compose env43721 (packedSelected [1,4,7,9,12,15,16,17,18,20,23,26,27,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 23589) := by decide +kernel

theorem selectedBound43721 : packedSelected [1,4,7,9,12,15,16,17,18,20,23,26,27,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env43722 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,23589,1024,32769,4112,169401,136584,21763,8328,17,171416,5393,151704,35245,135189,156084,256,147641,172317,189212]

theorem envBound43722 : H12AffineFastState.Bounded env43722 := by
  intro p hp
  have h : env43722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43721_43722 : H12AffineEnvironment.transform 17 23589 env43721 = env43722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23589 env43721 == env43722) = true)

theorem identity43722 : scanCanonicalize (H12AffineFastState.compose env43722 (packedSelected [0,5,8,9,10,16,18,20,22,23,24,26,27,28] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound43722 : packedSelected [0,5,8,9,10,16,18,20,22,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env43723 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,32768,33166,131072,2341,1024,32769,4112,169401,136584,3,8328,17,171416,5393,132504,35245,135189,144564,256,136633,172317,177692]

theorem envBound43723 : H12AffineFastState.Bounded env43723 := by
  intro p hp
  have h : env43723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43722_43723 : H12AffineEnvironment.transform 13 5376 env43722 = env43723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env43722 == env43723) = true)

theorem identity43723 : scanCanonicalize (H12AffineFastState.compose env43723 (packedSelected [0,1,3,4,5,7,8,10,16,20,22,26] rootPS)) = affineNative (2^(16+1) ^^^ 46109) := by decide +kernel

theorem selectedBound43723 : packedSelected [0,1,3,4,5,7,8,10,16,20,22,26] rootPS < 2^1333 := by decide +kernel

def env43724 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,32768,33166,46109,2341,1024,32769,4112,8612,41365,3,8328,17,10629,5393,45445,35245,41992,32937,256,41380,5376,513]

theorem envBound43724 : H12AffineFastState.Bounded env43724 := by
  intro p hp
  have h : env43724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43723_43724 : H12AffineEnvironment.transform 16 46109 env43723 = env43724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46109 env43723 == env43724) = true)

theorem identity43724 : scanCanonicalize (H12AffineFastState.compose env43724 (packedSelected [2,4,6,9,14,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound43724 : packedSelected [2,4,6,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env43725 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5376,32768,33166,38296,2341,1024,32769,4112,33,32784,3,269,17,2048,5393,36864,35245,34189,32937,256,32801,5376,513]

theorem envBound43725 : H12AffineFastState.Bounded env43725 := by
  intro p hp
  have h : env43725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43724_43725 : H12AffineEnvironment.transform 12 389 env43724 = env43725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env43724 == env43725) = true)

theorem identity43725 : scanCanonicalize (H12AffineFastState.compose env43725 (packedSelected [4,9,10,11,15,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43725 : packedSelected [4,9,10,11,15,19] rootPS < 2^1333 := by decide +kernel

def env43726 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,32768,33031,38161,2341,1024,32769,4112,33,32784,3,269,17,2048,5393,36864,35108,34052,32800,256,32801,5376,513]

theorem envBound43726 : H12AffineFastState.Bounded env43726 := by
  intro p hp
  have h : env43726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43725_43726 : H12AffineEnvironment.transform 6 9 env43725 = env43726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43725 == env43726) = true)

theorem identity43726 : scanCanonicalize (H12AffineFastState.compose env43726 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound43726 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env43727 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,1,262,5392,2341,1024,0,4112,33,17,3,269,17,2048,5393,4097,2341,1285,33,256,32,5376,513]

theorem envBound43727 : H12AffineFastState.Bounded env43727 := by
  intro p hp
  have h : env43727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43726_43727 : H12AffineEnvironment.transform 14 1 env43726 = env43727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env43726 == env43727) = true)

theorem identity43727 : scanCanonicalize (H12AffineFastState.compose env43727 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound43727 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43728 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5157,1,35,5173,2048,1024,0,4112,33,17,3,40,17,2048,5172,4097,2048,1056,33,37,32,5157,513]

theorem envBound43728 : H12AffineFastState.Bounded env43728 := by
  intro p hp
  have h : env43728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43727_43728 : H12AffineEnvironment.transform 7 37 env43727 = env43728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env43727 == env43728) = true)

def env43729 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,41,1045,1,35,1029,2048,1024,0,32,33,17,3,40,17,2048,1028,49,2048,1056,33,37,32,1045,513]

theorem envBound43729 : H12AffineFastState.Bounded env43729 := by
  intro p hp
  have h : env43729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43728_43729 : H12AffineEnvironment.transform 11 48 env43728 = env43729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env43728 == env43729) = true)

theorem identity43729 : scanCanonicalize (H12AffineFastState.compose env43729 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound43729 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43730 : List Nat := [2,4,8,16,32,16,9,37,512,1024,561,48,41,1045,1,35,1029,561,1024,0,32,33,17,3,40,17,561,1028,49,561,1056,33,37,32,1045,513]

theorem envBound43730 : H12AffineFastState.Bounded env43730 := by
  intro p hp
  have h : env43730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43729_43730 : H12AffineEnvironment.transform 10 561 env43729 = env43730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env43729 == env43730) = true)

def env43731 : List Nat := [2,4,8,16,32,16,9,37,512,52,561,48,41,33,1,35,49,561,52,0,32,33,17,3,40,17,561,48,49,561,20,33,37,32,33,513]

theorem envBound43731 : H12AffineFastState.Bounded env43731 := by
  intro p hp
  have h : env43731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43730_43731 : H12AffineEnvironment.transform 9 52 env43730 = env43731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env43730 == env43731) = true)

theorem identity43731 : scanCanonicalize (H12AffineFastState.compose env43731 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound43731 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43732 : List Nat := [2,4,8,16,32,16,9,37,17,52,32,48,41,33,1,35,49,32,52,0,32,33,17,3,40,17,32,48,49,32,20,33,37,32,33,16]

theorem envBound43732 : H12AffineFastState.Bounded env43732 := by
  intro p hp
  have h : env43732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43731_43732 : H12AffineEnvironment.transform 8 17 env43731 = env43732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env43731 == env43732) = true)

def leafEnv43732 : List Nat := [2,4,8,16,32,16,9,37,17,52,32,48,41,33,1,35,49,32,52,0,32,33,17,3,20,40,1,17,32,48,49,32,20,33,37,32,4,34,33,16,1,32,0]

def active43732 : List Nat := [0,1,2,3,4]

def tree43732 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43732 : H12WitnessSearch.Good tree43732 := H12GlobalWitnessIndex.good

theorem leafIdentity43732 : H12AffineFastState.composeSystem env43732 rootObs = leafEnv43732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43732 rootObs == leafEnv43732) = true)

theorem terminalChecked43732 : H12PackedTerminal.terminalCheckFast leafEnv43732 active43732 tree43732 = true := by decide +kernel

def env43733 : List Nat := [2,4,8,16,32,16,9,37,512,53,561,48,41,32,1,35,48,561,53,0,32,33,17,3,40,17,561,49,49,561,21,33,37,32,32,513]

theorem envBound43733 : H12AffineFastState.Bounded env43733 := by
  intro p hp
  have h : env43733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43730_43733 : H12AffineEnvironment.transform 9 53 env43730 = env43733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env43730 == env43733) = true)

theorem identity43733 : scanCanonicalize (H12AffineFastState.compose env43733 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound43733 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43734 : List Nat := [2,4,8,16,27,16,9,30,512,14,522,11,18,27,1,24,11,522,14,0,27,26,17,3,19,17,522,10,10,522,21,26,30,27,27,513]

theorem envBound43734 : H12AffineFastState.Bounded env43734 := by
  intro p hp
  have h : env43734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43733_43734 : H12AffineEnvironment.transform 4 27 env43733 = env43734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env43733 == env43734) = true)

def leafEnv43734 : List Nat := [2,4,8,16,27,16,9,30,512,14,522,11,18,27,1,24,11,522,14,0,27,26,17,3,21,19,1,17,522,10,10,522,21,26,30,27,4,25,27,513,1,27,0]

def active43734 : List Nat := [0,1,2,3,8]

def tree43734 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43734 : H12WitnessSearch.Good tree43734 := H12GlobalWitnessIndex.good

theorem leafIdentity43734 : H12AffineFastState.composeSystem env43734 rootObs = leafEnv43734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43734 rootObs == leafEnv43734) = true)

theorem terminalChecked43734 : H12PackedTerminal.terminalCheckFast leafEnv43734 active43734 tree43734 = true := by decide +kernel

def env43735 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,41,1044,1,35,1028,2048,1024,0,33,33,17,3,40,17,2048,1029,48,2048,1056,33,37,32,1044,513]

theorem envBound43735 : H12AffineFastState.Bounded env43735 := by
  intro p hp
  have h : env43735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43728_43735 : H12AffineEnvironment.transform 11 49 env43728 = env43735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env43728 == env43735) = true)

theorem identity43735 : scanCanonicalize (H12AffineFastState.compose env43735 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound43735 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43736 : List Nat := [2,4,8,16,32,16,9,37,512,1024,1541,49,41,1044,1,35,1028,1541,1024,0,33,33,17,3,40,17,1541,1029,48,1541,1056,33,37,32,1044,513]

theorem envBound43736 : H12AffineFastState.Bounded env43736 := by
  intro p hp
  have h : env43736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43735_43736 : H12AffineEnvironment.transform 10 1541 env43735 = env43736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env43735 == env43736) = true)

def env43737 : List Nat := [2,4,8,16,32,16,9,37,512,52,561,49,41,32,1,35,48,561,52,0,33,33,17,3,40,17,561,49,48,561,20,33,37,32,32,513]

theorem envBound43737 : H12AffineFastState.Bounded env43737 := by
  intro p hp
  have h : env43737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43736_43737 : H12AffineEnvironment.transform 9 52 env43736 = env43737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env43736 == env43737) = true)

theorem identity43737 : scanCanonicalize (H12AffineFastState.compose env43737 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound43737 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43738 : List Nat := [2,4,8,16,32,16,9,37,16,52,33,49,41,32,1,35,48,33,52,0,33,33,17,3,40,17,33,49,48,33,20,33,37,32,32,17]

theorem envBound43738 : H12AffineFastState.Bounded env43738 := by
  intro p hp
  have h : env43738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43737_43738 : H12AffineEnvironment.transform 8 16 env43737 = env43738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env43737 == env43738) = true)

def leafEnv43738 : List Nat := [2,4,8,16,32,16,9,37,16,52,33,49,41,32,1,35,48,33,52,0,33,33,17,3,20,40,1,17,33,49,48,33,20,33,37,32,4,34,32,17,1,33,0]

def active43738 : List Nat := [0,1,2,3,4]

def tree43738 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43738 : H12WitnessSearch.Good tree43738 := H12GlobalWitnessIndex.good

theorem leafIdentity43738 : H12AffineFastState.composeSystem env43738 rootObs = leafEnv43738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43738 rootObs == leafEnv43738) = true)

theorem terminalChecked43738 : H12PackedTerminal.terminalCheckFast leafEnv43738 active43738 tree43738 = true := by decide +kernel

def env43739 : List Nat := [2,4,8,16,32,16,9,37,512,53,560,49,41,33,1,35,49,560,53,0,33,33,17,3,40,17,560,48,48,560,21,33,37,32,33,513]

theorem envBound43739 : H12AffineFastState.Bounded env43739 := by
  intro p hp
  have h : env43739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43736_43739 : H12AffineEnvironment.transform 9 53 env43736 = env43739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env43736 == env43739) = true)

theorem identity43739 : scanCanonicalize (H12AffineFastState.compose env43739 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound43739 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43740 : List Nat := [2,4,8,16,26,16,9,31,512,15,522,11,19,27,1,25,11,522,15,0,27,27,17,3,18,17,522,10,10,522,21,27,31,26,27,513]

theorem envBound43740 : H12AffineFastState.Bounded env43740 := by
  intro p hp
  have h : env43740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43739_43740 : H12AffineEnvironment.transform 4 26 env43739 = env43740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env43739 == env43740) = true)

def leafEnv43740 : List Nat := [2,4,8,16,26,16,9,31,512,15,522,11,19,27,1,25,11,522,15,0,27,27,17,3,21,18,1,17,522,10,10,522,21,27,31,26,4,24,27,513,1,27,0]

def active43740 : List Nat := [0,1,2,3,8]

def tree43740 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43740 : H12WitnessSearch.Good tree43740 := H12GlobalWitnessIndex.good

theorem leafIdentity43740 : H12AffineFastState.composeSystem env43740 rootObs = leafEnv43740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43740 rootObs == leafEnv43740) = true)

theorem terminalChecked43740 : H12PackedTerminal.terminalCheckFast leafEnv43740 active43740 tree43740 = true := by decide +kernel

def env43741 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,262144,1024,32769,4113,169401,412076,21763,8328,16,171416,5393,396476,35244,412720,156085,256,400541,458041,442169]

theorem envBound43741 : H12AffineFastState.Bounded env43741 := by
  intro p hp
  have h : env43741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43720_43741 : H12AffineEnvironment.transform 5 17 env43720 = env43741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43720 == env43741) = true)

theorem identity43741 : scanCanonicalize (H12AffineFastState.compose env43741 (packedSelected [1,4,7,9,12,15,16,17,18,20,23,26,27,28,31,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound43741 : packedSelected [1,4,7,9,12,15,16,17,18,20,23,26,27,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env43742 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,21761,398,131072,262144,1024,21760,4113,147640,412076,21763,8328,16,149657,5393,396476,23725,412720,156085,256,400541,403512,420408]

theorem envBound43742 : H12AffineFastState.Bounded env43742 := by
  intro p hp
  have h : env43742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43741_43742 : H12AffineEnvironment.transform 14 21761 env43741 = env43742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env43741 == env43742) = true)

theorem identity43742 : scanCanonicalize (H12AffineFastState.compose env43742 (packedSelected [1,3,5,8,10,18,23,26] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound43742 : packedSelected [1,3,5,8,10,18,23,26] rootPS < 2^1333 := by decide +kernel

def env43743 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,16384,21761,398,131072,262144,1024,21760,4113,147640,412076,21763,388,16,149657,5393,396476,23725,412720,147641,256,400541,395572,412468]

theorem envBound43743 : H12AffineFastState.Bounded env43743 := by
  intro p hp
  have h : env43743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43742_43743 : H12AffineEnvironment.transform 12 268 env43742 = env43743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env43742 == env43743) = true)

theorem identity43743 : scanCanonicalize (H12AffineFastState.compose env43743 (packedSelected [0,3,4,5,7,8,18,22,23,28] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound43743 : packedSelected [0,3,4,5,7,8,18,22,23,28] rootPS < 2^1333 := by decide +kernel

def env43744 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,16384,21761,398,5392,262144,1024,21760,4113,21928,285884,21763,388,16,23945,5393,268716,23725,284960,21929,256,264589,269348,286244]

theorem envBound43744 : H12AffineFastState.Bounded env43744 := by
  intro p hp
  have h : env43744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43743_43744 : H12AffineEnvironment.transform 16 5392 env43743 = env43744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env43743 == env43744) = true)

theorem identity43744 : scanCanonicalize (H12AffineFastState.compose env43744 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 23589) := by decide +kernel

theorem selectedBound43744 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43745 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,16384,21761,398,5392,23589,1024,21760,4113,21928,153,21763,388,16,23945,5393,17801,23725,1285,21929,256,21928,16385,513]

theorem envBound43745 : H12AffineFastState.Bounded env43745 := by
  intro p hp
  have h : env43745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43744_43745 : H12AffineEnvironment.transform 17 23589 env43744 = env43745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23589 env43744 == env43745) = true)

theorem identity43745 : scanCanonicalize (H12AffineFastState.compose env43745 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound43745 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43746 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5376,1,398,5392,2341,1024,0,4113,168,153,3,388,16,2185,5393,4233,2477,1285,169,256,168,5377,513]

theorem envBound43746 : H12AffineFastState.Bounded env43746 := by
  intro p hp
  have h : env43746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43745_43746 : H12AffineEnvironment.transform 13 5376 env43745 = env43746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env43745 == env43746) = true)

theorem identity43746 : scanCanonicalize (H12AffineFastState.compose env43746 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43746 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43747 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,1,263,5392,2341,1024,0,4113,33,16,3,269,16,2048,5393,4096,2340,1285,32,256,33,5377,513]

theorem envBound43747 : H12AffineFastState.Bounded env43747 := by
  intro p hp
  have h : env43747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43746_43747 : H12AffineEnvironment.transform 6 9 env43746 = env43747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43746 == env43747) = true)

theorem identity43747 : scanCanonicalize (H12AffineFastState.compose env43747 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound43747 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43748 : List Nat := [2,4,8,16,32,17,9,256,512,5,2048,4096,268,4357,1,263,4373,2341,5,0,4113,33,16,3,269,16,2048,4372,4096,2340,256,32,256,33,4356,513]

theorem envBound43748 : H12AffineFastState.Bounded env43748 := by
  intro p hp
  have h : env43748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43747_43748 : H12AffineEnvironment.transform 9 5 env43747 = env43748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env43747 == env43748) = true)

theorem identity43748 : scanCanonicalize (H12AffineFastState.compose env43748 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2367) := by decide +kernel

theorem selectedBound43748 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43749 : List Nat := [2,4,8,16,32,17,9,256,512,5,2048,2367,268,2106,1,263,2090,2341,5,0,2350,33,16,3,269,16,2048,2091,2367,2340,256,32,256,33,2107,513]

theorem envBound43749 : H12AffineFastState.Bounded env43749 := by
  intro p hp
  have h : env43749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43748_43749 : H12AffineEnvironment.transform 11 2367 env43748 = env43749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2367 env43748 == env43749) = true)

theorem identity43749 : scanCanonicalize (H12AffineFastState.compose env43749 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound43749 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43750 : List Nat := [2,4,8,16,32,17,9,256,512,5,529,814,268,555,1,263,571,820,5,0,831,33,16,3,269,16,529,570,814,821,256,32,256,33,554,513]

theorem envBound43750 : H12AffineFastState.Bounded env43750 := by
  intro p hp
  have h : env43750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43749_43750 : H12AffineEnvironment.transform 10 529 env43749 = env43750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env43749 == env43750) = true)

theorem identity43750 : scanCanonicalize (H12AffineFastState.compose env43750 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound43750 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43751 : List Nat := [2,4,8,16,27,17,9,256,512,5,529,789,268,528,1,263,512,783,5,0,772,26,16,3,269,16,529,513,789,782,256,27,256,26,529,513]

theorem envBound43751 : H12AffineFastState.Bounded env43751 := by
  intro p hp
  have h : env43751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43750_43751 : H12AffineEnvironment.transform 4 27 env43750 = env43751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env43750 == env43751) = true)

theorem identity43751 : scanCanonicalize (H12AffineFastState.compose env43751 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound43751 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43752 : List Nat := [2,4,8,10,1,11,9,256,512,5,523,783,268,522,1,263,512,783,5,0,772,0,10,3,269,10,523,513,783,782,256,1,256,0,523,513]

theorem envBound43752 : H12AffineFastState.Bounded env43752 := by
  intro p hp
  have h : env43752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43751_43752 : H12AffineEnvironment.transform 3 10 env43751 = env43752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env43751 == env43752) = true)

theorem identity43752 : scanCanonicalize (H12AffineFastState.compose env43752 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound43752 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env43753 : List Nat := [2,4,8,10,1,11,9,4,512,5,523,523,8,522,1,3,512,523,5,0,512,0,10,3,9,10,523,513,523,522,4,1,4,0,523,513]

theorem envBound43753 : H12AffineFastState.Bounded env43753 := by
  intro p hp
  have h : env43753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43752_43753 : H12AffineEnvironment.transform 7 4 env43752 = env43753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env43752 == env43753) = true)

theorem identity43753 : scanCanonicalize (H12AffineFastState.compose env43753 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound43753 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env43754 : List Nat := [2,4,5,7,1,6,4,4,512,5,518,518,5,519,1,3,512,518,5,0,512,0,7,3,4,7,518,513,518,519,4,1,4,0,518,513]

theorem envBound43754 : H12AffineFastState.Bounded env43754 := by
  intro p hp
  have h : env43754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43753_43754 : H12AffineEnvironment.transform 2 5 env43753 = env43754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env43753 == env43754) = true)

def env43755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169400,412157,21762,8328,65,215366,115151,396524,35325,497903,243003,256,509970,469430,442168]

theorem envBound43755 : H12AffineFastState.Bounded env43755 := by
  intro p hp
  have h : env43755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43718_43755 : H12AffineEnvironment.transform 20 4161 env43718 = env43755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env43718 == env43755) = true)

theorem identity43755 : scanCanonicalize (H12AffineFastState.compose env43755 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223718) := by decide +kernel

theorem selectedBound43755 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,4161,169400,73755,21762,8328,65,215366,115151,91402,35325,61705,243003,256,41460,16464,120542]

theorem envBound43756 : H12AffineFastState.Bounded env43756 := by
  intro p hp
  have h : env43756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43755_43756 : H12AffineEnvironment.transform 17 223718 env43755 = env43756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223718 env43755 == env43756) = true)

def env43757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,67754,1024,32769,4161,62708,73755,21762,8328,65,75786,115151,91402,35325,61705,119927,256,41460,16464,120542]

theorem envBound43757 : H12AffineFastState.Bounded env43757 := by
  intro p hp
  have h : env43757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43756_43757 : H12AffineEnvironment.transform 16 24908 env43756 = env43757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env43756 == env43757) = true)

theorem identity43757 : scanCanonicalize (H12AffineFastState.compose env43757 (packedSelected [4,7,9,11,14,17,18,23,27,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 41090) := by decide +kernel

theorem selectedBound43757 : packedSelected [4,7,9,11,14,17,18,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env43758 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,41090,24908,43048,1024,32769,4161,62708,32921,21762,8328,65,34952,24909,50568,35325,61705,29941,256,41460,16464,30300]

theorem envBound43758 : H12AffineFastState.Bounded env43758 := by
  intro p hp
  have h : env43758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43757_43758 : H12AffineEnvironment.transform 15 41090 env43757 = env43758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41090 env43757 == env43758) = true)

theorem identity43758 : scanCanonicalize (H12AffineFastState.compose env43758 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound43758 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env43759 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8323,24908,10281,1024,0,4161,29941,152,21762,8328,65,2185,24909,17801,2556,28936,29941,256,8693,16464,30300]

theorem envBound43759 : H12AffineFastState.Bounded env43759 := by
  intro p hp
  have h : env43759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43758_43759 : H12AffineEnvironment.transform 14 1 env43758 = env43759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env43758 == env43759) = true)

theorem identity43759 : scanCanonicalize (H12AffineFastState.compose env43759 (packedSelected [1,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound43759 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env43760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,1,8323,5393,10281,1024,0,4161,168,152,8543,8328,65,2185,5392,12756,2556,1365,168,256,8693,13325,513]

theorem envBound43760 : H12AffineFastState.Bounded env43760 := by
  intro p hp
  have h : env43760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43759_43760 : H12AffineEnvironment.transform 13 13405 env43759 = env43760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env43759 == env43760) = true)

theorem identity43760 : scanCanonicalize (H12AffineFastState.compose env43760 (packedSelected [2,6,17] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound43760 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env43761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5512,1,342,5393,2556,1024,0,4161,168,152,138,349,65,2185,5392,4097,2556,1365,168,256,32,5592,513]

theorem envBound43761 : H12AffineFastState.Bounded env43761 := by
  intro p hp
  have h : env43761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43760_43761 : H12AffineEnvironment.transform 12 469 env43760 = env43761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env43760 == env43761) = true)

theorem identity43761 : scanCanonicalize (H12AffineFastState.compose env43761 (packedSelected [5,8,11,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound43761 : packedSelected [5,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env43762 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5457,1,342,5393,2341,1024,0,4161,113,65,83,349,65,2128,5392,4097,2341,1365,113,256,32,5377,513]

theorem envBound43762 : H12AffineFastState.Bounded env43762 := by
  intro p hp
  have h : env43762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43761_43762 : H12AffineEnvironment.transform 6 89 env43761 = env43762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env43761 == env43762) = true)

theorem identity43762 : scanCanonicalize (H12AffineFastState.compose env43762 (packedSelected [0,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound43762 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env43763 : List Nat := [2,4,8,16,32,64,89,116,512,1024,2048,4096,120,5157,1,34,5221,2129,1024,0,4161,113,65,83,41,65,2128,5220,4097,2129,1057,113,116,32,5237,513]

theorem envBound43763 : H12AffineFastState.Bounded env43763 := by
  intro p hp
  have h : env43763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43762_43763 : H12AffineEnvironment.transform 7 116 env43762 = env43763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env43762 == env43763) = true)

theorem identity43763 : scanCanonicalize (H12AffineFastState.compose env43763 (packedSelected [1,3,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43763 : packedSelected [1,3,14] rootPS < 2^1333 := by decide +kernel

def env43764 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,5157,1,34,5173,2049,1024,0,4113,33,17,3,41,17,2048,5172,4097,2049,1057,33,36,32,5157,513]

theorem envBound43764 : H12AffineFastState.Bounded env43764 := by
  intro p hp
  have h : env43764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43763_43764 : H12AffineEnvironment.transform 5 16 env43763 = env43764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43763 == env43764) = true)

def env43765 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,48,40,1045,1,34,1029,2049,1024,0,33,33,17,3,41,17,2048,1028,49,2049,1057,33,36,32,1045,513]

theorem envBound43765 : H12AffineFastState.Bounded env43765 := by
  intro p hp
  have h : env43765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43764_43765 : H12AffineEnvironment.transform 11 48 env43764 = env43765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env43764 == env43765) = true)

theorem identity43765 : scanCanonicalize (H12AffineFastState.compose env43765 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound43765 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43766 : List Nat := [2,4,8,16,32,16,9,36,512,21,2048,48,40,0,1,34,16,2049,21,0,33,33,17,3,41,17,2048,17,49,2049,52,33,36,32,0,513]

theorem envBound43766 : H12AffineFastState.Bounded env43766 := by
  intro p hp
  have h : env43766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43765_43766 : H12AffineEnvironment.transform 9 21 env43765 = env43766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env43765 == env43766) = true)

def env43767 : List Nat := [2,4,8,16,0,16,9,4,512,21,2048,16,8,0,1,2,16,2049,21,0,1,1,17,3,9,17,2048,17,17,2049,20,1,4,0,0,513]

theorem envBound43767 : H12AffineFastState.Bounded env43767 := by
  intro p hp
  have h : env43767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43766_43767 : H12AffineEnvironment.transform 4 0 env43766 = env43767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43766 == env43767) = true)

theorem identity43767 : scanCanonicalize (H12AffineFastState.compose env43767 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound43767 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43768 : List Nat := [2,4,8,16,0,16,9,4,512,21,523,16,8,0,1,2,16,522,21,0,1,1,17,3,9,17,523,17,17,522,20,1,4,0,0,513]

theorem envBound43768 : H12AffineFastState.Bounded env43768 := by
  intro p hp
  have h : env43768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43767_43768 : H12AffineEnvironment.transform 10 523 env43767 = env43768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env43767 == env43768) = true)

def leafEnv43768 : List Nat := [2,4,8,16,0,16,9,4,512,21,523,16,8,0,1,2,16,522,21,0,1,1,17,3,20,9,1,17,523,17,17,522,20,1,4,0,4,3,0,513,1,1,0]

def active43768 : List Nat := [0,1,2,3,8]

def tree43768 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43768 : H12WitnessSearch.Good tree43768 := H12GlobalWitnessIndex.good

theorem leafIdentity43768 : H12AffineFastState.composeSystem env43768 rootObs = leafEnv43768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43768 rootObs == leafEnv43768) = true)

theorem terminalChecked43768 : H12PackedTerminal.terminalCheckFast leafEnv43768 active43768 tree43768 = true := by decide +kernel

def env43769 : List Nat := [2,4,8,16,1,16,9,5,512,21,2048,17,9,0,1,3,16,2049,21,0,0,0,17,3,8,17,2048,17,16,2049,21,0,5,1,0,513]

theorem envBound43769 : H12AffineFastState.Bounded env43769 := by
  intro p hp
  have h : env43769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43766_43769 : H12AffineEnvironment.transform 4 1 env43766 = env43769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43766 == env43769) = true)

theorem identity43769 : scanCanonicalize (H12AffineFastState.compose env43769 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound43769 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43770 : List Nat := [2,4,8,16,1,16,9,5,512,21,1,17,9,0,1,3,16,0,21,0,0,0,17,3,8,17,1,17,16,0,21,0,5,1,0,513]

theorem envBound43770 : H12AffineFastState.Bounded env43770 := by
  intro p hp
  have h : env43770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43769_43770 : H12AffineEnvironment.transform 10 1 env43769 = env43770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env43769 == env43770) = true)

def leafEnv43770 : List Nat := [2,4,8,16,1,16,9,5,512,21,1,17,9,0,1,3,16,0,21,0,0,0,17,3,21,8,1,17,1,17,16,0,21,0,5,1,4,2,0,513,1,0,0]

def active43770 : List Nat := [0,1,2,3,8]

def tree43770 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43770 : H12WitnessSearch.Good tree43770 := H12GlobalWitnessIndex.good

theorem leafIdentity43770 : H12AffineFastState.composeSystem env43770 rootObs = leafEnv43770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43770 rootObs == leafEnv43770) = true)

theorem terminalChecked43770 : H12PackedTerminal.terminalCheckFast leafEnv43770 active43770 tree43770 = true := by decide +kernel

def env43771 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,49,40,1044,1,34,1028,2049,1024,0,32,33,17,3,41,17,2048,1029,48,2049,1057,33,36,32,1044,513]

theorem envBound43771 : H12AffineFastState.Bounded env43771 := by
  intro p hp
  have h : env43771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43764_43771 : H12AffineEnvironment.transform 11 49 env43764 = env43771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env43764 == env43771) = true)

theorem identity43771 : scanCanonicalize (H12AffineFastState.compose env43771 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43771 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43772 : List Nat := [2,4,8,16,1,16,9,5,512,1024,2048,16,9,1044,1,3,1028,2049,1024,0,1,0,17,3,8,17,2048,1029,17,2049,1024,0,5,1,1044,513]

theorem envBound43772 : H12AffineFastState.Bounded env43772 := by
  intro p hp
  have h : env43772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43771_43772 : H12AffineEnvironment.transform 4 1 env43771 = env43772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43771 == env43772) = true)

def env43773 : List Nat := [2,4,8,16,1,16,9,5,512,20,2048,16,9,0,1,3,16,2049,20,0,1,0,17,3,8,17,2048,17,17,2049,20,0,5,1,0,513]

theorem envBound43773 : H12AffineFastState.Bounded env43773 := by
  intro p hp
  have h : env43773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43772_43773 : H12AffineEnvironment.transform 9 20 env43772 = env43773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env43772 == env43773) = true)

theorem identity43773 : scanCanonicalize (H12AffineFastState.compose env43773 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound43773 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43774 : List Nat := [2,4,8,16,1,16,9,5,512,20,523,16,9,0,1,3,16,522,20,0,1,0,17,3,8,17,523,17,17,522,20,0,5,1,0,513]

theorem envBound43774 : H12AffineFastState.Bounded env43774 := by
  intro p hp
  have h : env43774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43773_43774 : H12AffineEnvironment.transform 10 523 env43773 = env43774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env43773 == env43774) = true)

def leafEnv43774 : List Nat := [2,4,8,16,1,16,9,5,512,20,523,16,9,0,1,3,16,522,20,0,1,0,17,3,20,8,1,17,523,17,17,522,20,0,5,1,4,2,0,513,1,1,0]

def active43774 : List Nat := [0,1,2,3,8]

def tree43774 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43774 : H12WitnessSearch.Good tree43774 := H12GlobalWitnessIndex.good

theorem leafIdentity43774 : H12AffineFastState.composeSystem env43774 rootObs = leafEnv43774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43774 rootObs == leafEnv43774) = true)

theorem terminalChecked43774 : H12PackedTerminal.terminalCheckFast leafEnv43774 active43774 tree43774 = true := by decide +kernel

def env43775 : List Nat := [2,4,8,16,1,16,9,5,512,21,2048,16,9,1,1,3,17,2049,21,0,1,0,17,3,8,17,2048,16,17,2049,21,0,5,1,1,513]

theorem envBound43775 : H12AffineFastState.Bounded env43775 := by
  intro p hp
  have h : env43775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43772_43775 : H12AffineEnvironment.transform 9 21 env43772 = env43775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env43772 == env43775) = true)

theorem identity43775 : scanCanonicalize (H12AffineFastState.compose env43775 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound43775 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43776 : List Nat := [2,4,8,16,1,16,9,5,512,21,0,16,9,1,1,3,17,1,21,0,1,0,17,3,8,17,0,16,17,1,21,0,5,1,1,513]

theorem envBound43776 : H12AffineFastState.Bounded env43776 := by
  intro p hp
  have h : env43776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43775_43776 : H12AffineEnvironment.transform 10 0 env43775 = env43776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env43775 == env43776) = true)

def leafEnv43776 : List Nat := [2,4,8,16,1,16,9,5,512,21,0,16,9,1,1,3,17,1,21,0,1,0,17,3,21,8,1,17,0,16,17,1,21,0,5,1,4,2,1,513,1,1,0]

def active43776 : List Nat := [0,1,2,3,8]

def tree43776 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43776 : H12WitnessSearch.Good tree43776 := H12GlobalWitnessIndex.good

theorem leafIdentity43776 : H12AffineFastState.composeSystem env43776 rootObs = leafEnv43776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43776 rootObs == leafEnv43776) = true)

theorem terminalChecked43776 : H12PackedTerminal.terminalCheckFast leafEnv43776 active43776 tree43776 = true := by decide +kernel

def env43777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,67755,1024,32769,4161,62709,73755,21762,8328,65,75787,115151,91402,35325,61705,119926,256,41460,16464,120542]

theorem envBound43777 : H12AffineFastState.Bounded env43777 := by
  intro p hp
  have h : env43777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43756_43777 : H12AffineEnvironment.transform 16 24909 env43756 = env43777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env43756 == env43777) = true)

theorem identity43777 : scanCanonicalize (H12AffineFastState.compose env43777 (packedSelected [4,7,9,11,14,17,18,23,27,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound43777 : packedSelected [4,7,9,11,14,17,18,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env43778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,21590,24909,23805,1024,32769,4161,62709,29773,21762,8328,65,31837,38297,12636,35325,61705,32800,256,41460,16464,33416]

theorem envBound43778 : H12AffineFastState.Bounded env43778 := by
  intro p hp
  have h : env43778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43777_43778 : H12AffineEnvironment.transform 15 21590 env43777 = env43778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env43777 == env43778) = true)

theorem identity43778 : scanCanonicalize (H12AffineFastState.compose env43778 (packedSelected [3,10,11,17,18,23,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound43778 : packedSelected [3,10,11,17,18,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env43779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,21590,24909,23805,1024,1,4161,29941,29773,21762,8328,65,31837,5529,12636,2557,28937,32,256,8692,16464,648]

theorem envBound43779 : H12AffineFastState.Bounded env43779 := by
  intro p hp
  have h : env43779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43778_43779 : H12AffineEnvironment.transform 14 0 env43778 = env43779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env43778 == env43779) = true)

theorem identity43779 : scanCanonicalize (H12AffineFastState.compose env43779 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43779 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env43780 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,21590,24909,23668,1024,1,4161,29820,29773,21762,8193,65,31837,5392,12636,2420,28937,32,256,8573,16464,513]

theorem envBound43780 : H12AffineFastState.Bounded env43780 := by
  intro p hp
  have h : env43780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43779_43780 : H12AffineEnvironment.transform 6 9 env43779 = env43780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43779 == env43780) = true)

theorem identity43780 : scanCanonicalize (H12AffineFastState.compose env43780 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound43780 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env43781 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,0,21590,16401,23668,1024,1,4161,21792,21777,21762,349,65,23809,5392,4096,2420,20565,32,256,33,16464,513]

theorem envBound43781 : H12AffineFastState.Bounded env43781 := by
  intro p hp
  have h : env43781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43780_43781 : H12AffineEnvironment.transform 12 348 env43780 = env43781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env43780 == env43781) = true)

theorem identity43781 : scanCanonicalize (H12AffineFastState.compose env43781 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound43781 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43782 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,0,343,5392,2421,1024,1,4161,33,16,3,349,65,2048,5392,4096,2420,1364,32,256,33,5457,513]

theorem envBound43782 : H12AffineFastState.Bounded env43782 := by
  intro p hp
  have h : env43782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43781_43782 : H12AffineEnvironment.transform 13 5377 env43781 = env43782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env43781 == env43782) = true)

theorem identity43782 : scanCanonicalize (H12AffineFastState.compose env43782 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 357) := by decide +kernel

theorem selectedBound43782 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43783 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,357,348,1124,0,343,1141,2421,1024,1,292,33,16,3,349,65,2048,1141,357,2420,1364,32,256,33,1076,513]

theorem envBound43783 : H12AffineFastState.Bounded env43783 := by
  intro p hp
  have h : env43783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43782_43783 : H12AffineEnvironment.transform 11 357 env43782 = env43783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 357 env43782 == env43783) = true)

theorem identity43783 : scanCanonicalize (H12AffineFastState.compose env43783 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound43783 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43784 : List Nat := [2,4,8,16,32,64,9,256,512,1024,372,357,348,1124,0,343,1141,1,1024,1,292,33,16,3,349,65,372,1141,357,0,1364,32,256,33,1076,513]

theorem envBound43784 : H12AffineFastState.Bounded env43784 := by
  intro p hp
  have h : env43784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43783_43784 : H12AffineEnvironment.transform 10 372 env43783 = env43784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env43783 == env43784) = true)

theorem identity43784 : scanCanonicalize (H12AffineFastState.compose env43784 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound43784 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env43785 : List Nat := [2,4,8,16,32,64,9,256,512,516,372,357,348,608,0,343,625,1,516,1,292,33,16,3,349,65,372,625,357,0,848,32,256,33,560,513]

theorem envBound43785 : H12AffineFastState.Bounded env43785 := by
  intro p hp
  have h : env43785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43784_43785 : H12AffineEnvironment.transform 9 516 env43784 = env43785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env43784 == env43785) = true)

theorem identity43785 : scanCanonicalize (H12AffineFastState.compose env43785 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 341) := by decide +kernel

theorem selectedBound43785 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env43786 : List Nat := [2,4,8,16,32,64,9,256,341,337,372,357,348,309,0,343,292,1,337,1,292,33,16,3,349,65,372,292,357,0,5,32,256,33,357,340]

theorem envBound43786 : H12AffineFastState.Bounded env43786 := by
  intro p hp
  have h : env43786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43785_43786 : H12AffineEnvironment.transform 8 341 env43785 = env43786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env43785 == env43786) = true)

theorem identity43786 : scanCanonicalize (H12AffineFastState.compose env43786 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43786 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env43787 : List Nat := [2,4,8,16,0,64,9,256,341,337,340,325,348,277,0,343,260,1,337,1,260,1,16,3,349,65,340,260,325,0,5,0,256,1,325,340]

theorem envBound43787 : H12AffineFastState.Bounded env43787 := by
  intro p hp
  have h : env43787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43786_43787 : H12AffineEnvironment.transform 4 0 env43786 = env43787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43786 == env43787) = true)

theorem identity43787 : scanCanonicalize (H12AffineFastState.compose env43787 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound43787 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env43788 : List Nat := [2,4,8,16,0,1,9,256,276,272,277,260,285,277,0,278,260,1,272,1,260,1,16,3,284,0,277,260,260,0,5,0,256,1,260,277]

theorem envBound43788 : H12AffineFastState.Bounded env43788 := by
  intro p hp
  have h : env43788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43787_43788 : H12AffineEnvironment.transform 5 1 env43787 = env43788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env43787 == env43788) = true)

theorem identity43788 : scanCanonicalize (H12AffineFastState.compose env43788 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound43788 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43789 : List Nat := [2,4,8,16,0,1,9,5,17,21,16,1,24,16,0,19,1,1,21,1,1,1,16,3,25,0,16,1,1,0,5,0,5,1,1,16]

theorem envBound43789 : H12AffineFastState.Bounded env43789 := by
  intro p hp
  have h : env43789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43788_43789 : H12AffineEnvironment.transform 7 5 env43788 = env43789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env43788 == env43789) = true)

theorem identity43789 : scanCanonicalize (H12AffineFastState.compose env43789 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound43789 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43790 : List Nat := [2,4,8,0,0,1,9,5,1,5,0,1,8,0,0,3,1,1,5,1,1,1,0,3,9,0,0,1,1,0,5,0,5,1,1,0]

theorem envBound43790 : H12AffineFastState.Bounded env43790 := by
  intro p hp
  have h : env43790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43789_43790 : H12AffineEnvironment.transform 3 0 env43789 = env43790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env43789 == env43790) = true)

def env43791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830977,25265168,23160256,257,27378861,27337992,25207750]

theorem envBound43791 : H12AffineFastState.Bounded env43791 := by
  intro p hp
  have h : env43791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43531_43791 : H12AffineEnvironment.transform 18 1025 env43531 = env43791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env43531 == env43791) = true)

theorem identity43791 : scanCanonicalize (H12AffineFastState.compose env43791 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 388159) := by decide +kernel

theorem selectedBound43791 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env43792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388159,4194304,8388608,16777216,8328,65,29868032,17066162,8763759,8830977,25265168,21268991,257,25438354,25479479,25207750]

theorem envBound43792 : H12AffineFastState.Bounded env43792 := by
  intro p hp
  have h : env43792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43791_43792 : H12AffineEnvironment.transform 20 388159 env43791 = env43792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 388159 env43791 == env43792) = true)

def env43793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388159,4194304,8388608,351656,8328,65,12754344,79130,8763759,8830977,8706488,4314199,257,8484154,8492191,8781422]

theorem envBound43793 : H12AffineFastState.Bounded env43793 := by
  intro p hp
  have h : env43793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43792_43793 : H12AffineEnvironment.transform 23 351656 env43792 = env43793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 351656 env43792 == env43793) = true)

def env43794 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,115871,4194304,8388608,95496,8328,65,12754344,79130,8491471,8579233,8450328,4314199,257,8484154,8492191,8509134]

theorem envBound43794 : H12AffineFastState.Bounded env43794 := by
  intro p hp
  have h : env43794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43793_43794 : H12AffineEnvironment.transform 17 10400 env43793 = env43794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env43793 == env43794) = true)

def env43795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,115871,32,8388608,95496,8328,65,8560008,79130,8491471,8579233,8450328,119927,257,8484154,8492191,8509134]

theorem envBound43795 : H12AffineFastState.Bounded env43795 := by
  intro p hp
  have h : env43795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43794_43795 : H12AffineEnvironment.transform 21 32 env43794 = env43795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env43794 == env43795) = true)

theorem identity43795 : scanCanonicalize (H12AffineFastState.compose env43795 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound43795 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10400,1025,32769,58516,32,8388608,21763,8328,65,8560008,5393,8434116,8579233,8450328,62588,257,8410417,8434836,8451781]

theorem envBound43796 : H12AffineFastState.Bounded env43796 := by
  intro p hp
  have h : env43796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43795_43796 : H12AffineEnvironment.transform 15 8203 env43795 = env43796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env43795 == env43796) = true)

def env43797 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10280,1025,32769,58396,32,8388608,21763,8192,65,8559872,5393,8433996,8579113,8450328,62588,257,8410417,8434716,8451661]

theorem envBound43797 : H12AffineFastState.Bounded env43797 := by
  intro p hp
  have h : env43797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43796_43797 : H12AffineEnvironment.transform 6 8 env43796 = env43797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43796 == env43797) = true)

theorem identity43797 : scanCanonicalize (H12AffineFastState.compose env43797 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound43797 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43798 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10280,1025,32769,58396,32,17,21763,8192,65,171281,5393,45405,190520,61705,62588,257,21792,46093,63068]

theorem envBound43798 : H12AffineFastState.Bounded env43798 := by
  intro p hp
  have h : env43798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43797_43798 : H12AffineEnvironment.transform 22 17 env43797 = env43798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env43797 == env43798) = true)

theorem identity43798 : scanCanonicalize (H12AffineFastState.compose env43798 (packedSelected [2,4,6,11,16,18,22] rootPS)) = affineNative (2^(16+1) ^^^ 16692) := by decide +kernel

theorem selectedBound43798 : packedSelected [2,4,6,11,16,18,22] rootPS < 2^1333 := by decide +kernel

def env43799 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16692,10280,1025,32769,58396,32,17,21763,8192,65,56357,5393,45405,43276,61705,62588,257,21792,46093,63068]

theorem envBound43799 : H12AffineFastState.Bounded env43799 := by
  intro p hp
  have h : env43799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43798_43799 : H12AffineEnvironment.transform 16 16692 env43798 = env43799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16692 env43798 == env43799) = true)

theorem identity43799 : scanCanonicalize (H12AffineFastState.compose env43799 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound43799 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,19,23] rootPS < 2^1333 := by decide +kernel

def env43800 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,80,8203,16692,10280,1025,81,25676,32,17,21763,8192,65,23669,5393,12557,10588,29017,29740,257,21792,13405,30220]

theorem envBound43800 : H12AffineFastState.Bounded env43800 := by
  intro p hp
  have h : env43800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43799_43800 : H12AffineEnvironment.transform 14 80 env43799 = env43800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env43799 == env43800) = true)

theorem identity43800 : scanCanonicalize (H12AffineFastState.compose env43800 (packedSelected [0,2,6,7,11,12,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound43800 : packedSelected [0,2,6,7,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env43801 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4404,80,8203,4096,10280,1025,81,13688,32,17,1079,8192,65,3393,5393,12557,10588,8301,9496,257,1044,13405,10040]

theorem envBound43801 : H12AffineFastState.Bounded env43801 := by
  intro p hp
  have h : env43801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43800_43801 : H12AffineEnvironment.transform 13 4404 env43800 = env43801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env43800 == env43801) = true)

theorem identity43801 : scanCanonicalize (H12AffineFastState.compose env43801 (packedSelected [1,3,5,6,7,8,9,11,14,15,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound43801 : packedSelected [1,3,5,6,7,8,9,11,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env43802 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1052,4404,80,1047,4096,3124,1025,81,4452,32,17,1079,1052,65,3393,5393,5393,3392,1137,260,257,1044,4161,804]

theorem envBound43802 : H12AffineFastState.Bounded env43802 := by
  intro p hp
  have h : env43802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43801_43802 : H12AffineEnvironment.transform 12 1052 env43801 = env43802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env43801 == env43802) = true)

theorem identity43802 : scanCanonicalize (H12AffineFastState.compose env43802 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound43802 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43803 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,269,4404,80,262,4096,2341,272,81,4452,32,17,294,269,65,2128,4096,4096,2129,352,260,257,261,4161,804]

theorem envBound43803 : H12AffineFastState.Bounded env43803 := by
  intro p hp
  have h : env43803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43802_43803 : H12AffineEnvironment.transform 9 273 env43802 = env43803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env43802 == env43803) = true)

theorem identity43803 : scanCanonicalize (H12AffineFastState.compose env43803 (packedSelected [0,1,3,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound43803 : packedSelected [0,1,3,7,11] rootPS < 2^1333 := by decide +kernel

def env43804 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,2405,269,2129,80,262,2405,2341,272,81,2049,32,17,294,269,65,2128,2405,2405,2129,352,260,257,261,2340,804]

theorem envBound43804 : H12AffineFastState.Bounded env43804 := by
  intro p hp
  have h : env43804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43803_43804 : H12AffineEnvironment.transform 11 2405 env43803 = env43804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env43803 == env43804) = true)

theorem identity43804 : scanCanonicalize (H12AffineFastState.compose env43804 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound43804 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env43805 : List Nat := [2,4,8,16,32,64,8,36,512,53,2048,2113,41,2129,80,34,2113,2049,52,81,2049,32,17,2,41,65,2128,2113,2113,2129,68,32,37,33,2048,512]

theorem envBound43805 : H12AffineFastState.Bounded env43805 := by
  intro p hp
  have h : env43805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43804_43805 : H12AffineEnvironment.transform 7 36 env43804 = env43805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env43804 == env43805) = true)

theorem identity43805 : scanCanonicalize (H12AffineFastState.compose env43805 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound43805 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43806 : List Nat := [2,4,8,16,32,49,8,36,512,53,2048,2096,41,2080,33,34,2096,2049,52,32,2049,32,17,2,41,48,2081,2096,2096,2080,53,32,37,33,2048,512]

theorem envBound43806 : H12AffineFastState.Bounded env43806 := by
  intro p hp
  have h : env43806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43805_43806 : H12AffineEnvironment.transform 5 49 env43805 = env43806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env43805 == env43806) = true)

theorem identity43806 : scanCanonicalize (H12AffineFastState.compose env43806 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43806 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43807 : List Nat := [2,4,8,16,1,16,8,5,512,20,2048,2065,8,2049,0,3,2065,2049,21,1,2049,1,17,2,8,17,2048,2065,2065,2049,20,1,4,0,2048,512]

theorem envBound43807 : H12AffineFastState.Bounded env43807 := by
  intro p hp
  have h : env43807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43806_43807 : H12AffineEnvironment.transform 4 1 env43806 = env43807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43806 == env43807) = true)

theorem identity43807 : scanCanonicalize (H12AffineFastState.compose env43807 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound43807 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43808 : List Nat := [2,4,8,16,1,16,8,5,0,20,2048,2065,8,2049,0,3,2065,2049,21,1,2049,1,17,2,8,17,2048,2065,2065,2049,20,1,4,0,2048,0]

theorem envBound43808 : H12AffineFastState.Bounded env43808 := by
  intro p hp
  have h : env43808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43807_43808 : H12AffineEnvironment.transform 8 0 env43807 = env43808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env43807 == env43808) = true)

theorem identity43808 : scanCanonicalize (H12AffineFastState.compose env43808 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound43808 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43809 : List Nat := [2,4,8,4,1,4,8,5,0,0,2048,2053,8,2049,0,3,2053,2049,1,1,2049,1,5,2,8,5,2048,2053,2053,2049,0,1,4,0,2048,0]

theorem envBound43809 : H12AffineFastState.Bounded env43809 := by
  intro p hp
  have h : env43809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43808_43809 : H12AffineEnvironment.transform 3 4 env43808 = env43809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env43808 == env43809) = true)

def leafEnv43809 : List Nat := [2,4,8,4,1,4,8,5,0,0,2048,2053,8,2049,0,3,2053,2049,1,1,2049,1,5,2,1,8,1,5,2048,2053,2053,2049,0,1,4,0,5,3,2048,0,1,2048,0]

def active43809 : List Nat := [0,1,2,10]

def tree43809 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43809 : H12WitnessSearch.Good tree43809 := H12GlobalWitnessIndex.good

theorem leafIdentity43809 : H12AffineFastState.composeSystem env43809 rootObs = leafEnv43809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43809 rootObs == leafEnv43809) = true)

theorem terminalChecked43809 : H12PackedTerminal.terminalCheckFast leafEnv43809 active43809 tree43809 = true := by decide +kernel

def env43810 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10281,1025,32769,58397,32,8388608,21763,8193,65,8559873,5393,8433997,8579112,8450328,62588,257,8410417,8434717,8451660]

theorem envBound43810 : H12AffineFastState.Bounded env43810 := by
  intro p hp
  have h : env43810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43796_43810 : H12AffineEnvironment.transform 6 9 env43796 = env43810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43796 == env43810) = true)

theorem identity43810 : scanCanonicalize (H12AffineFastState.compose env43810 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 41293) := by decide +kernel

theorem selectedBound43810 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43811 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10281,1025,32769,58397,32,41293,21763,8193,65,146508,5393,4096,149861,20565,62588,257,62588,5456,22273]

theorem envBound43811 : H12AffineFastState.Bounded env43811 := by
  intro p hp
  have h : env43811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43810_43811 : H12AffineEnvironment.transform 22 41293 env43810 = env43811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41293 env43810 == env43811) = true)

theorem identity43811 : scanCanonicalize (H12AffineFastState.compose env43811 (packedSelected [0,4,6,7,9,16,20] rootPS)) = affineNative (2^(16+1) ^^^ 57449) := by decide +kernel

theorem selectedBound43811 : packedSelected [0,4,6,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env43812 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,57449,10281,1025,32769,58397,32,41293,21763,8193,65,56357,5393,4096,43276,20565,62588,257,62588,5456,22273]

theorem envBound43812 : H12AffineFastState.Bounded env43812 := by
  intro p hp
  have h : env43812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43811_43812 : H12AffineEnvironment.transform 16 57449 env43811 = env43812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57449 env43811 == env43812) = true)

theorem identity43812 : scanCanonicalize (H12AffineFastState.compose env43812 (packedSelected [0,2,4,6,7,9,11,14,23] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound43812 : packedSelected [0,2,4,6,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env43813 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,32768,8203,46109,10281,1025,32769,45161,32,41293,375,8193,65,34897,5393,4096,43276,1057,40968,257,40968,5456,885]

theorem envBound43813 : H12AffineFastState.Bounded env43813 := by
  intro p hp
  have h : env43813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43812_43813 : H12AffineEnvironment.transform 13 5236 env43812 = env43813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env43812 == env43813) = true)

theorem identity43813 : scanCanonicalize (H12AffineFastState.compose env43813 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 8312) := by decide +kernel

theorem selectedBound43813 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env43814 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,8312,8203,5221,10281,1025,8313,4113,32,309,375,8193,65,10281,5393,4096,2420,1057,112,257,112,5456,885]

theorem envBound43814 : H12AffineFastState.Bounded env43814 := by
  intro p hp
  have h : env43814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43813_43814 : H12AffineEnvironment.transform 14 8312 env43813 = env43814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8312 env43813 == env43814) = true)

theorem identity43814 : scanCanonicalize (H12AffineFastState.compose env43814 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound43814 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env43815 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5236,292,343,5221,2421,1025,293,4113,32,309,375,349,65,2421,5393,4096,2420,1057,112,257,112,5456,885]

theorem envBound43815 : H12AffineFastState.Bounded env43815 := by
  intro p hp
  have h : env43815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43814_43815 : H12AffineEnvironment.transform 12 348 env43814 = env43815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env43814 == env43815) = true)

theorem identity43815 : scanCanonicalize (H12AffineFastState.compose env43815 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound43815 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env43816 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5236,81,34,5221,2048,1025,80,4113,32,64,2,40,65,2048,5220,4096,2049,1057,112,116,112,5157,512]

theorem envBound43816 : H12AffineFastState.Bounded env43816 := by
  intro p hp
  have h : env43816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43815_43816 : H12AffineEnvironment.transform 7 117 env43815 = env43816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env43815 == env43816) = true)

theorem identity43816 : scanCanonicalize (H12AffineFastState.compose env43816 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43816 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43817 : List Nat := [2,4,8,16,0,64,9,85,512,1024,2048,4096,9,5204,81,2,5189,2048,1025,80,4113,0,64,2,8,65,2048,5188,4096,2049,1025,80,84,80,5125,512]

theorem envBound43817 : H12AffineFastState.Bounded env43817 := by
  intro p hp
  have h : env43817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43816_43817 : H12AffineEnvironment.transform 4 0 env43816 = env43817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43816 == env43817) = true)

theorem identity43817 : scanCanonicalize (H12AffineFastState.compose env43817 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound43817 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env43818 : List Nat := [2,4,8,16,0,64,9,85,512,1024,80,4096,9,5204,81,2,5189,80,1025,80,4113,0,64,2,8,65,80,5188,4096,81,1025,80,84,80,5125,512]

theorem envBound43818 : H12AffineFastState.Bounded env43818 := by
  intro p hp
  have h : env43818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43817_43818 : H12AffineEnvironment.transform 10 80 env43817 = env43818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env43817 == env43818) = true)

theorem identity43818 : scanCanonicalize (H12AffineFastState.compose env43818 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound43818 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env43819 : List Nat := [2,4,8,16,0,64,9,85,512,1024,80,1028,9,80,81,2,65,80,1025,80,1045,0,64,2,8,65,80,64,1028,81,1025,80,84,80,1,512]

theorem envBound43819 : H12AffineFastState.Bounded env43819 := by
  intro p hp
  have h : env43819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43818_43819 : H12AffineEnvironment.transform 11 1028 env43818 = env43819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env43818 == env43819) = true)

theorem identity43819 : scanCanonicalize (H12AffineFastState.compose env43819 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43819 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43820 : List Nat := [2,4,8,16,0,17,9,4,512,1024,1,1028,9,1,0,2,16,1,1025,1,1045,0,17,2,8,16,1,17,1028,0,1025,1,5,1,1,512]

theorem envBound43820 : H12AffineFastState.Bounded env43820 := by
  intro p hp
  have h : env43820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43819_43820 : H12AffineEnvironment.transform 5 17 env43819 = env43820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43819 == env43820) = true)

theorem identity43820 : scanCanonicalize (H12AffineFastState.compose env43820 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 513) := by decide +kernel

theorem selectedBound43820 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43821 : List Nat := [2,4,8,16,0,17,9,4,512,513,1,517,9,1,0,2,16,1,512,1,532,0,17,2,8,16,1,17,517,0,512,1,5,1,1,512]

theorem envBound43821 : H12AffineFastState.Bounded env43821 := by
  intro p hp
  have h : env43821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43820_43821 : H12AffineEnvironment.transform 9 513 env43820 = env43821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 513 env43820 == env43821) = true)

theorem identity43821 : scanCanonicalize (H12AffineFastState.compose env43821 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound43821 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43822 : List Nat := [2,4,8,16,0,17,9,4,4,5,1,1,9,1,0,2,16,1,4,1,16,0,17,2,8,16,1,17,1,0,4,1,5,1,1,4]

theorem envBound43822 : H12AffineFastState.Bounded env43822 := by
  intro p hp
  have h : env43822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43821_43822 : H12AffineEnvironment.transform 8 4 env43821 = env43822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env43821 == env43822) = true)

theorem identity43822 : scanCanonicalize (H12AffineFastState.compose env43822 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound43822 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43823 : List Nat := [2,4,8,11,0,10,9,4,4,5,1,1,9,1,0,2,11,1,4,1,11,0,10,2,8,11,1,10,1,0,4,1,5,1,1,4]

theorem envBound43823 : H12AffineFastState.Bounded env43823 := by
  intro p hp
  have h : env43823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43822_43823 : H12AffineEnvironment.transform 3 11 env43822 = env43823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env43822 == env43823) = true)

def env43824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,115871,33,8388608,95496,8328,65,8560009,79130,8491471,8579233,8450328,119926,257,8484154,8492191,8509134]

theorem envBound43824 : H12AffineFastState.Bounded env43824 := by
  intro p hp
  have h : env43824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43794_43824 : H12AffineEnvironment.transform 21 33 env43794 = env43824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env43794 == env43824) = true)

theorem identity43824 : scanCanonicalize (H12AffineFastState.compose env43824 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 73754) := by decide +kernel

theorem selectedBound43824 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,115871,33,73754,95496,8328,65,245139,79130,45525,247995,119042,119926,257,21792,46213,63188]

theorem envBound43825 : H12AffineFastState.Bounded env43825 := by
  intro p hp
  have h : env43825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43824_43825 : H12AffineEnvironment.transform 22 73754 env43824 = env43825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73754 env43824 == env43825) = true)

def env43826 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115735,33,73754,95496,8192,65,245019,79130,45405,247859,119042,119926,257,21792,46093,63068]

theorem envBound43826 : H12AffineFastState.Bounded env43826 := by
  intro p hp
  have h : env43826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43825_43826 : H12AffineEnvironment.transform 6 8 env43825 = env43826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43825 == env43826) = true)

theorem identity43826 : scanCanonicalize (H12AffineFastState.compose env43826 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound43826 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43827 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10280,1025,32769,58396,33,17,21763,8192,65,171280,5393,45405,190520,61705,62589,257,21792,46093,63068]

theorem envBound43827 : H12AffineFastState.Bounded env43827 := by
  intro p hp
  have h : env43827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43826_43827 : H12AffineEnvironment.transform 15 8203 env43826 = env43827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env43826 == env43827) = true)

end H12CloudChart0