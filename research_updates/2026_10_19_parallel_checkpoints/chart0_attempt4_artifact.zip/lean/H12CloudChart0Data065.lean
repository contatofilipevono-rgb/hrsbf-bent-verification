import H12CloudChart0Data064

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env16358 : List Nat := [2,4,8,16,32,16,9,36,11,53,1,17,40,1,1,34,17,1,52,0,1,33,16,3,41,17,0,16,16,0,21,33,37,32,0,10]

theorem envBound16358 : H12AffineFastState.Bounded env16358 := by
  intro p hp
  have h : env16358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16357_16358 : H12AffineEnvironment.transform 8 11 env16357 = env16358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env16357 == env16358) = true)

def env16359 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,4194304,17,98781,8328,65,4340965,79130,91403,179512,1500,4314198,257,95530,103567,74250]

theorem envBound16359 : H12AffineFastState.Bounded env16359 := by
  intro p hp
  have h : env16359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16339_16359 : H12AffineEnvironment.transform 22 17 env16339 = env16359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env16339 == env16359) = true)

theorem identity16359 : scanCanonicalize (H12AffineFastState.compose env16359 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound16359 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32041,1025,32769,4161,4194304,17,41430,8328,65,4340965,5393,17664,179512,1500,4256861,257,21793,46212,513]

theorem envBound16360 : H12AffineFastState.Bounded env16360 := by
  intro p hp
  have h : env16360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16359_16360 : H12AffineEnvironment.transform 15 8203 env16359 = env16360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env16359 == env16360) = true)

theorem identity16360 : scanCanonicalize (H12AffineFastState.compose env16360 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 41380) := by decide +kernel

theorem selectedBound16360 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env16361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32041,1025,32769,4161,41380,17,41430,8328,65,171329,5393,17664,179512,1500,22009,257,21793,46212,513]

theorem envBound16361 : H12AffineFastState.Bounded env16361 := by
  intro p hp
  have h : env16361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16360_16361 : H12AffineEnvironment.transform 21 41380 env16360 = env16361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41380 env16360 == env16361) = true)

def env16362 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32041,1025,32769,4161,41260,17,41310,8192,65,171329,5393,17664,179512,1364,21873,257,21793,46092,513]

theorem envBound16362 : H12AffineFastState.Bounded env16362 := by
  intro p hp
  have h : env16362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16361_16362 : H12AffineEnvironment.transform 6 8 env16361 = env16362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16361 == env16362) = true)

theorem identity16362 : scanCanonicalize (H12AffineFastState.compose env16362 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound16362 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env16363 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,131072,32041,1025,29788,4161,21873,17,21763,8192,65,157980,5393,17664,149861,1364,21873,257,21793,16465,513]

theorem envBound16363 : H12AffineFastState.Bounded env16363 := by
  intro p hp
  have h : env16363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16362_16363 : H12AffineEnvironment.transform 14 29789 env16362 = env16363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env16362 == env16363) = true)

theorem identity16363 : scanCanonicalize (H12AffineFastState.compose env16363 (packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound16363 : packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS < 2^1333 := by decide +kernel

def env16364 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,16400,32041,1025,29788,4161,21873,17,21763,8192,65,10508,5393,17664,2421,1364,21873,257,21793,16465,513]

theorem envBound16364 : H12AffineFastState.Bounded env16364 := by
  intro p hp
  have h : env16364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16363_16364 : H12AffineEnvironment.transform 16 16400 env16363 = env16364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env16363 == env16364) = true)

theorem identity16364 : scanCanonicalize (H12AffineFastState.compose env16364 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound16364 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env16365 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,5393,10280,1025,8541,4161,112,17,2,8192,65,10508,5393,4097,2421,1364,112,257,32,5456,513]

theorem envBound16365 : H12AffineFastState.Bounded env16365 := by
  intro p hp
  have h : env16365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16364_16365 : H12AffineEnvironment.transform 13 5377 env16364 = env16365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env16364 == env16365) = true)

theorem identity16365 : scanCanonicalize (H12AffineFastState.compose env16365 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16365 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16366 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8461,8203,5393,10280,1025,8460,4112,33,17,2,8192,16,10508,5393,4097,2340,1285,33,257,32,5377,513]

theorem envBound16366 : H12AffineFastState.Bounded env16366 := by
  intro p hp
  have h : env16366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16365_16366 : H12AffineEnvironment.transform 5 17 env16365 = env16366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16365 == env16366) = true)

theorem identity16366 : scanCanonicalize (H12AffineFastState.compose env16366 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound16366 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16367 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1077,8192,308,8461,8203,292,10280,1025,8460,1061,33,17,2,8192,16,10508,292,1076,2340,1285,33,257,32,308,513]

theorem envBound16367 : H12AffineFastState.Bounded env16367 := by
  intro p hp
  have h : env16367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16366_16367 : H12AffineEnvironment.transform 11 1077 env16366 = env16367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env16366 == env16367) = true)

theorem identity16367 : scanCanonicalize (H12AffineFastState.compose env16367 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2083) := by decide +kernel

theorem selectedBound16367 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env16368 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1077,2083,308,2350,2088,292,11,1025,2351,1061,33,17,2,2083,16,303,292,1076,2340,1285,33,257,32,308,513]

theorem envBound16368 : H12AffineFastState.Bounded env16368 := by
  intro p hp
  have h : env16368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16367_16368 : H12AffineEnvironment.transform 12 2083 env16367 = env16368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2083 env16367 == env16368) = true)

theorem identity16368 : scanCanonicalize (H12AffineFastState.compose env16368 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 302) := by decide +kernel

theorem selectedBound16368 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env16369 : List Nat := [2,4,8,16,32,17,8,256,512,1024,302,1077,269,308,0,262,292,11,1025,1,1061,33,17,2,269,16,303,292,1076,10,1285,33,257,32,308,513]

theorem envBound16369 : H12AffineFastState.Bounded env16369 := by
  intro p hp
  have h : env16369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16368_16369 : H12AffineEnvironment.transform 10 302 env16368 = env16369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 302 env16368 == env16369) = true)

theorem identity16369 : scanCanonicalize (H12AffineFastState.compose env16369 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound16369 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16370 : List Nat := [2,4,8,16,32,17,8,256,512,273,302,292,269,308,0,262,292,11,272,1,308,33,17,2,269,16,303,292,293,10,20,33,257,32,308,513]

theorem envBound16370 : H12AffineFastState.Bounded env16370 := by
  intro p hp
  have h : env16370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16369_16370 : H12AffineEnvironment.transform 9 273 env16369 = env16370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env16369 == env16370) = true)

theorem identity16370 : scanCanonicalize (H12AffineFastState.compose env16370 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound16370 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16371 : List Nat := [2,4,8,16,26,17,8,256,512,273,276,286,269,270,0,262,286,11,272,1,270,27,17,2,269,16,277,286,287,10,20,27,257,26,270,513]

theorem envBound16371 : H12AffineFastState.Bounded env16371 := by
  intro p hp
  have h : env16371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16370_16371 : H12AffineEnvironment.transform 4 26 env16370 = env16371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env16370 == env16371) = true)

def env16372 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32041,1025,32769,4161,41261,17,41311,8193,65,171329,5393,17664,179512,1365,21872,257,21793,46093,513]

theorem envBound16372 : H12AffineFastState.Bounded env16372 := by
  intro p hp
  have h : env16372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16361_16372 : H12AffineEnvironment.transform 6 9 env16361 = env16372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16361 == env16372) = true)

theorem identity16372 : scanCanonicalize (H12AffineFastState.compose env16372 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound16372 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16373 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,131072,32041,1025,8541,4161,113,17,3,8193,65,146461,5393,17664,138340,1365,21872,257,21793,5457,513]

theorem envBound16373 : H12AffineFastState.Bounded env16373 := by
  intro p hp
  have h : env16373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16372_16373 : H12AffineEnvironment.transform 14 8540 env16372 = env16373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env16372 == env16373) = true)

theorem identity16373 : scanCanonicalize (H12AffineFastState.compose env16373 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound16373 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env16374 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16401,32041,1025,8541,4161,113,17,3,8193,65,31756,5393,17664,23669,1365,21872,257,21793,5457,513]

theorem envBound16374 : H12AffineFastState.Bounded env16374 := by
  intro p hp
  have h : env16374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16373_16374 : H12AffineEnvironment.transform 16 16401 env16373 = env16374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env16373 == env16374) = true)

theorem identity16374 : scanCanonicalize (H12AffineFastState.compose env16374 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound16374 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env16375 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,292,115,16401,23889,1025,293,4161,113,17,3,121,65,23668,5393,17664,23669,1365,21872,257,21793,5457,513]

theorem envBound16375 : H12AffineFastState.Bounded env16375 := by
  intro p hp
  have h : env16375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16374_16375 : H12AffineEnvironment.transform 12 120 env16374 = env16375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env16374 == env16375) = true)

theorem identity16375 : scanCanonicalize (H12AffineFastState.compose env16375 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound16375 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env16376 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,120,16384,292,115,16401,22592,272,293,4161,113,17,3,121,65,22885,4096,16401,22884,68,20577,257,20528,4160,513]

theorem envBound16376 : H12AffineFastState.Bounded env16376 := by
  intro p hp
  have h : env16376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16375_16376 : H12AffineEnvironment.transform 9 273 env16375 = env16376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env16375 == env16376) = true)

theorem identity16376 : scanCanonicalize (H12AffineFastState.compose env16376 (packedSelected [14] rootPS)) = affineNative (2^(13+1) ^^^ 4453) := by decide +kernel

theorem selectedBound16376 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env16377 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,120,4453,292,115,4468,2341,272,293,4161,113,17,3,121,65,2048,4096,4468,2049,68,260,257,341,4160,513]

theorem envBound16377 : H12AffineFastState.Bounded env16377 := by
  intro p hp
  have h : env16377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16376_16377 : H12AffineEnvironment.transform 13 4453 env16376 = env16377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4453 env16376 == env16377) = true)

theorem identity16377 : scanCanonicalize (H12AffineFastState.compose env16377 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound16377 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env16378 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,40,4405,292,35,4388,2341,272,293,4113,33,17,3,41,17,2048,4096,4388,2049,20,260,257,261,4112,513]

theorem envBound16378 : H12AffineFastState.Bounded env16378 := by
  intro p hp
  have h : env16378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16377_16378 : H12AffineEnvironment.transform 5 16 env16377 = env16378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16377 == env16378) = true)

theorem identity16378 : scanCanonicalize (H12AffineFastState.compose env16378 (packedSelected [2,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound16378 : packedSelected [2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env16379 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,2097,40,2308,292,35,2325,2341,272,293,2080,33,17,3,41,17,2048,2097,2325,2049,20,260,257,261,2081,513]

theorem envBound16379 : H12AffineFastState.Bounded env16379 := by
  intro p hp
  have h : env16379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16378_16379 : H12AffineEnvironment.transform 11 2097 env16378 = env16379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env16378 == env16379) = true)

theorem identity16379 : scanCanonicalize (H12AffineFastState.compose env16379 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound16379 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16380 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,2097,40,2081,1,35,2096,2048,53,0,2080,33,17,3,41,17,2048,2097,2096,2049,20,33,36,32,2081,513]

theorem envBound16380 : H12AffineFastState.Bounded env16380 := by
  intro p hp
  have h : env16380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16379_16380 : H12AffineEnvironment.transform 7 37 env16379 = env16380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env16379 == env16380) = true)

theorem identity16380 : scanCanonicalize (H12AffineFastState.compose env16380 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound16380 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16381 : List Nat := [2,4,8,16,32,16,9,37,17,52,2048,2097,40,2081,1,35,2096,2048,53,0,2080,33,17,3,41,17,2048,2097,2096,2049,20,33,36,32,2081,16]

theorem envBound16381 : H12AffineFastState.Bounded env16381 := by
  intro p hp
  have h : env16381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16380_16381 : H12AffineEnvironment.transform 8 17 env16380 = env16381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env16380 == env16381) = true)

theorem identity16381 : scanCanonicalize (H12AffineFastState.compose env16381 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound16381 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16382 : List Nat := [2,4,8,16,32,16,9,37,17,52,27,42,40,58,1,35,43,27,53,0,59,33,17,3,41,17,27,42,43,26,20,33,36,32,58,16]

theorem envBound16382 : H12AffineFastState.Bounded env16382 := by
  intro p hp
  have h : env16382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16381_16382 : H12AffineEnvironment.transform 10 27 env16381 = env16382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env16381 == env16382) = true)

theorem identity16382 : scanCanonicalize (H12AffineFastState.compose env16382 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16382 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16383 : List Nat := [2,4,8,16,1,16,9,4,17,21,27,11,9,27,1,2,10,27,20,0,26,0,17,3,8,17,27,11,10,26,20,0,5,1,27,16]

theorem envBound16383 : H12AffineFastState.Bounded env16383 := by
  intro p hp
  have h : env16383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16382_16383 : H12AffineEnvironment.transform 4 1 env16382 = env16383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16382 == env16383) = true)

theorem identity16383 : scanCanonicalize (H12AffineFastState.compose env16383 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound16383 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env16384 : List Nat := [2,4,8,11,1,11,9,4,10,14,0,11,9,0,1,2,10,0,15,0,1,0,10,3,8,10,0,11,10,1,15,0,5,1,0,11]

theorem envBound16384 : H12AffineFastState.Bounded env16384 := by
  intro p hp
  have h : env16384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16383_16384 : H12AffineEnvironment.transform 3 11 env16383 = env16384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env16383 == env16384) = true)

theorem identity16384 : scanCanonicalize (H12AffineFastState.compose env16384 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound16384 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16385 : List Nat := [2,4,3,0,1,0,2,4,1,5,0,0,2,0,1,2,1,0,4,0,1,0,1,3,3,1,0,0,1,1,4,0,5,1,0,0]

theorem envBound16385 : H12AffineFastState.Bounded env16385 := by
  intro p hp
  have h : env16385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16384_16385 : H12AffineEnvironment.transform 2 3 env16384 = env16385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env16384 == env16385) = true)

def env16386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,347491,4194304,8388608,392437,8328,65,12729589,79131,8722483,8830976,8681701,4314199,257,8484154,8492191,8740659]

theorem envBound16386 : H12AffineFastState.Bounded env16386 := by
  intro p hp
  have h : env16386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16295_16386 : H12AffineEnvironment.transform 23 392437 env16295 = env16386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 392437 env16295 == env16386) = true)

def env16387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,4194304,8388608,98781,8328,65,12729589,79131,8480027,8568104,8390093,4314199,257,8484154,8492191,8462875]

theorem envBound16387 : H12AffineFastState.Bounded env16387 := by
  intro p hp
  have h : env16387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16386_16387 : H12AffineEnvironment.transform 17 32040 env16386 = env16387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env16386 == env16387) = true)

def env16388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,4194304,16,98781,8328,65,4340965,79131,91403,179512,1501,4314199,257,95530,103567,74251]

theorem envBound16388 : H12AffineFastState.Bounded env16388 := by
  intro p hp
  have h : env16388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16387_16388 : H12AffineEnvironment.transform 22 16 env16387 = env16388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env16387 == env16388) = true)

theorem identity16388 : scanCanonicalize (H12AffineFastState.compose env16388 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 21928) := by decide +kernel

theorem selectedBound16388 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,21928,16,98781,8328,65,158029,79131,91403,179512,1501,98815,257,95530,103567,74251]

theorem envBound16389 : H12AffineFastState.Bounded env16389 := by
  intro p hp
  have h : env16389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16388_16389 : H12AffineEnvironment.transform 21 21928 env16388 = env16389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21928 env16388 == env16389) = true)

theorem identity16389 : scanCanonicalize (H12AffineFastState.compose env16389 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound16389 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env16390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32040,1025,32769,4161,21928,16,41431,8328,65,158029,5393,17665,179512,1501,41461,257,21792,46213,513]

theorem envBound16390 : H12AffineFastState.Bounded env16390 := by
  intro p hp
  have h : env16390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16389_16390 : H12AffineEnvironment.transform 15 8202 env16389 = env16390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env16389 == env16390) = true)

theorem identity16390 : scanCanonicalize (H12AffineFastState.compose env16390 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound16390 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env16391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,32040,1025,32769,4161,21928,16,41431,8328,65,10589,5393,17665,64808,1501,41461,257,21792,46213,513]

theorem envBound16391 : H12AffineFastState.Bounded env16391 := by
  intro p hp
  have h : env16391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16390_16391 : H12AffineEnvironment.transform 16 16400 env16390 = env16391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env16390 == env16391) = true)

def env16392 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,4194304,17,98781,8328,65,4340964,79131,91402,179513,1500,4314199,257,95531,103566,74250]

theorem envBound16392 : H12AffineFastState.Bounded env16392 := by
  intro p hp
  have h : env16392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16387_16392 : H12AffineEnvironment.transform 22 17 env16387 = env16392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env16387 == env16392) = true)

def env16393 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,4194304,17,98645,8192,65,4340844,79131,91402,179513,1364,4314199,257,95531,103430,74250]

theorem envBound16393 : H12AffineFastState.Bounded env16393 := by
  intro p hp
  have h : env16393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16392_16393 : H12AffineEnvironment.transform 6 8 env16392 = env16393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16392 == env16393) = true)

theorem identity16393 : scanCanonicalize (H12AffineFastState.compose env16393 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound16393 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16394 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32040,1025,32769,4160,4194304,17,41310,8192,65,4340844,5392,17665,179513,1364,4256860,257,21792,46093,513]

theorem envBound16394 : H12AffineFastState.Bounded env16394 := by
  intro p hp
  have h : env16394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16393_16394 : H12AffineEnvironment.transform 15 8203 env16393 = env16394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env16393 == env16394) = true)

theorem identity16394 : scanCanonicalize (H12AffineFastState.compose env16394 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound16394 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env16395 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,131072,32040,1025,29789,4160,4194304,17,21762,8192,65,4340844,5392,17665,149861,1364,4194304,257,21792,16465,513]

theorem envBound16395 : H12AffineFastState.Bounded env16395 := by
  intro p hp
  have h : env16395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16394_16395 : H12AffineEnvironment.transform 14 29788 env16394 = env16395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env16394 == env16395) = true)

theorem identity16395 : scanCanonicalize (H12AffineFastState.compose env16395 (packedSelected [0,1,3,5,8,10,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 21872) := by decide +kernel

theorem selectedBound16395 : packedSelected [0,1,3,5,8,10,14,19,27] rootPS < 2^1333 := by decide +kernel

def env16396 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,131072,32040,1025,29789,4160,21872,17,21762,8192,65,157980,5392,17665,149861,1364,21872,257,21792,16465,513]

theorem envBound16396 : H12AffineFastState.Bounded env16396 := by
  intro p hp
  have h : env16396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16395_16396 : H12AffineEnvironment.transform 21 21872 env16395 = env16396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21872 env16395 == env16396) = true)

theorem identity16396 : scanCanonicalize (H12AffineFastState.compose env16396 (packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound16396 : packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS < 2^1333 := by decide +kernel

def env16397 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,16400,32040,1025,29789,4160,21872,17,21762,8192,65,10508,5392,17665,2421,1364,21872,257,21792,16465,513]

theorem envBound16397 : H12AffineFastState.Bounded env16397 := by
  intro p hp
  have h : env16397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16396_16397 : H12AffineEnvironment.transform 16 16400 env16396 = env16397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env16396 == env16397) = true)

theorem identity16397 : scanCanonicalize (H12AffineFastState.compose env16397 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound16397 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env16398 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,5392,10280,1025,8541,4160,112,17,2,8192,65,10508,5392,4097,2421,1364,112,257,32,5457,513]

theorem envBound16398 : H12AffineFastState.Bounded env16398 := by
  intro p hp
  have h : env16398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16397_16398 : H12AffineEnvironment.transform 13 5376 env16397 = env16398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env16397 == env16398) = true)

theorem identity16398 : scanCanonicalize (H12AffineFastState.compose env16398 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16398 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16399 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8461,8203,5392,10280,1025,8460,4113,33,17,2,8192,16,10508,5392,4097,2340,1285,33,257,32,5376,513]

theorem envBound16399 : H12AffineFastState.Bounded env16399 := by
  intro p hp
  have h : env16399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16398_16399 : H12AffineEnvironment.transform 5 17 env16398 = env16399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16398 == env16399) = true)

theorem identity16399 : scanCanonicalize (H12AffineFastState.compose env16399 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound16399 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16400 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1076,8192,308,8461,8203,292,10280,1025,8460,1061,33,17,2,8192,16,10508,292,1077,2340,1285,33,257,32,308,513]

theorem envBound16400 : H12AffineFastState.Bounded env16400 := by
  intro p hp
  have h : env16400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16399_16400 : H12AffineEnvironment.transform 11 1076 env16399 = env16400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env16399 == env16400) = true)

theorem identity16400 : scanCanonicalize (H12AffineFastState.compose env16400 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2082) := by decide +kernel

theorem selectedBound16400 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env16401 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1076,2082,308,2351,2089,292,10,1025,2350,1061,33,17,2,2082,16,302,292,1077,2340,1285,33,257,32,308,513]

theorem envBound16401 : H12AffineFastState.Bounded env16401 := by
  intro p hp
  have h : env16401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16400_16401 : H12AffineEnvironment.transform 12 2082 env16400 = env16401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2082 env16400 == env16401) = true)

theorem identity16401 : scanCanonicalize (H12AffineFastState.compose env16401 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 303) := by decide +kernel

theorem selectedBound16401 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env16402 : List Nat := [2,4,8,16,32,17,8,256,512,1024,303,1076,269,308,0,262,292,10,1025,1,1061,33,17,2,269,16,302,292,1077,11,1285,33,257,32,308,513]

theorem envBound16402 : H12AffineFastState.Bounded env16402 := by
  intro p hp
  have h : env16402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16401_16402 : H12AffineEnvironment.transform 10 303 env16401 = env16402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 303 env16401 == env16402) = true)

theorem identity16402 : scanCanonicalize (H12AffineFastState.compose env16402 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound16402 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16403 : List Nat := [2,4,8,16,32,17,8,256,512,273,303,293,269,308,0,262,292,10,272,1,308,33,17,2,269,16,302,292,292,11,20,33,257,32,308,513]

theorem envBound16403 : H12AffineFastState.Bounded env16403 := by
  intro p hp
  have h : env16403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16402_16403 : H12AffineEnvironment.transform 9 273 env16402 = env16403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env16402 == env16403) = true)

theorem identity16403 : scanCanonicalize (H12AffineFastState.compose env16403 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound16403 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16404 : List Nat := [2,4,8,16,27,17,8,256,512,273,276,286,269,271,0,262,287,10,272,1,271,26,17,2,269,16,277,287,287,11,20,26,257,27,271,513]

theorem envBound16404 : H12AffineFastState.Bounded env16404 := by
  intro p hp
  have h : env16404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16403_16404 : H12AffineEnvironment.transform 4 27 env16403 = env16404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env16403 == env16404) = true)

def env16405 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,4194304,17,98644,8193,65,4340845,79131,91402,179513,1365,4314199,257,95531,103431,74250]

theorem envBound16405 : H12AffineFastState.Bounded env16405 := by
  intro p hp
  have h : env16405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16392_16405 : H12AffineEnvironment.transform 6 9 env16392 = env16405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16392 == env16405) = true)

theorem identity16405 : scanCanonicalize (H12AffineFastState.compose env16405 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound16405 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16406 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,131072,32040,1025,32769,45340,4194304,17,3,8193,65,4340845,46156,58461,179513,1365,4216064,257,62588,5456,41821]

theorem envBound16406 : H12AffineFastState.Bounded env16406 := by
  intro p hp
  have h : env16406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16405_16406 : H12AffineEnvironment.transform 15 33111 env16405 = env16406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env16405 == env16406) = true)

theorem identity16406 : scanCanonicalize (H12AffineFastState.compose env16406 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound16406 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env16407 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,131072,32040,1025,8541,4160,4194304,17,3,8193,65,4340845,5392,17665,138341,1365,4216064,257,21792,5456,513]

theorem envBound16407 : H12AffineFastState.Bounded env16407 := by
  intro p hp
  have h : env16407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16406_16407 : H12AffineEnvironment.transform 14 8540 env16406 = env16407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env16406 == env16407) = true)

theorem identity16407 : scanCanonicalize (H12AffineFastState.compose env16407 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound16407 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env16408 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16401,32040,1025,8541,4160,4194304,17,3,8193,65,4226172,5392,17665,23668,1365,4216064,257,21792,5456,513]

theorem envBound16408 : H12AffineFastState.Bounded env16408 := by
  intro p hp
  have h : env16408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16407_16408 : H12AffineEnvironment.transform 16 16401 env16407 = env16408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env16407 == env16408) = true)

theorem identity16408 : scanCanonicalize (H12AffineFastState.compose env16408 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound16408 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env16409 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,16384,8540,8203,16401,30776,273,8541,4160,4194304,17,3,8193,65,4225388,4096,16401,22884,69,4214800,257,20528,4160,513]

theorem envBound16409 : H12AffineFastState.Bounded env16409 := by
  intro p hp
  have h : env16409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16408_16409 : H12AffineEnvironment.transform 9 272 env16408 = env16409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env16408 == env16409) = true)

theorem identity16409 : scanCanonicalize (H12AffineFastState.compose env16409 (packedSelected [14] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound16409 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env16410 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,4404,8540,8203,4389,10508,273,8541,4160,4194304,17,3,8193,65,4204632,4096,4389,2128,69,4194596,257,260,4160,513]

theorem envBound16410 : H12AffineFastState.Bounded env16410 := by
  intro p hp
  have h : env16410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16409_16410 : H12AffineEnvironment.transform 13 4404 env16409 = env16410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env16409 == env16410) = true)

theorem identity16410 : scanCanonicalize (H12AffineFastState.compose env16410 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound16410 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env16411 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,4404,8540,8203,4389,10508,273,8541,4160,113,17,3,8193,65,10281,4096,4389,2128,69,341,257,260,4160,513]

theorem envBound16411 : H12AffineFastState.Bounded env16411 := by
  intro p hp
  have h : env16411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16410_16411 : H12AffineEnvironment.transform 21 113 env16410 = env16411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env16410 == env16411) = true)

theorem identity16411 : scanCanonicalize (H12AffineFastState.compose env16411 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound16411 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env16412 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,348,4404,0,343,4389,2128,273,1,4160,113,17,3,349,65,2421,4096,4389,2128,69,341,257,260,4160,513]

theorem envBound16412 : H12AffineFastState.Bounded env16412 := by
  intro p hp
  have h : env16412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16411_16412 : H12AffineEnvironment.transform 12 348 env16411 = env16412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env16411 == env16412) = true)

theorem identity16412 : scanCanonicalize (H12AffineFastState.compose env16412 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound16412 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env16413 : List Nat := [2,4,8,16,32,64,9,36,512,52,2048,4096,120,4112,0,115,4097,2128,53,1,4160,113,17,3,121,65,2129,4096,4097,2128,69,113,37,32,4160,513]

theorem envBound16413 : H12AffineFastState.Bounded env16413 := by
  intro p hp
  have h : env16413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16412_16413 : H12AffineEnvironment.transform 7 36 env16412 = env16413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env16412 == env16413) = true)

theorem identity16413 : scanCanonicalize (H12AffineFastState.compose env16413 (packedSelected [1,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 570) := by decide +kernel

theorem selectedBound16413 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env16414 : List Nat := [2,4,8,16,32,64,9,36,512,52,570,4096,120,4112,0,115,4097,618,53,1,4160,113,17,3,121,65,619,4096,4097,618,69,113,37,32,4160,513]

theorem envBound16414 : H12AffineFastState.Bounded env16414 := by
  intro p hp
  have h : env16414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16413_16414 : H12AffineEnvironment.transform 10 570 env16413 = env16414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 570 env16413 == env16414) = true)

theorem identity16414 : scanCanonicalize (H12AffineFastState.compose env16414 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound16414 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16415 : List Nat := [2,4,8,16,32,16,9,36,512,52,570,4096,40,4112,0,35,4097,570,53,1,4112,33,17,3,41,17,571,4096,4097,570,21,33,37,32,4112,513]

theorem envBound16415 : H12AffineFastState.Bounded env16415 := by
  intro p hp
  have h : env16415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16414_16415 : H12AffineEnvironment.transform 5 16 env16414 = env16415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16414 == env16415) = true)

theorem identity16415 : scanCanonicalize (H12AffineFastState.compose env16415 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound16415 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16416 : List Nat := [2,4,8,16,32,16,9,36,59,52,1,4096,40,4112,0,35,4097,1,53,1,4112,33,17,3,41,17,0,4096,4097,1,21,33,37,32,4112,58]

theorem envBound16416 : H12AffineFastState.Bounded env16416 := by
  intro p hp
  have h : env16416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16415_16416 : H12AffineEnvironment.transform 8 59 env16415 = env16416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env16415 == env16416) = true)

theorem identity16416 : scanCanonicalize (H12AffineFastState.compose env16416 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound16416 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16417 : List Nat := [2,4,8,0,32,0,9,36,43,36,1,4096,40,4096,0,35,4097,1,37,1,4096,33,1,3,41,1,0,4096,4097,1,5,33,37,32,4096,42]

theorem envBound16417 : H12AffineFastState.Bounded env16417 := by
  intro p hp
  have h : env16417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16416_16417 : H12AffineEnvironment.transform 3 0 env16416 = env16417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env16416 == env16417) = true)

theorem identity16417 : scanCanonicalize (H12AffineFastState.compose env16417 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16417 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16418 : List Nat := [2,4,8,0,1,0,9,5,10,5,1,4096,9,4096,0,2,4097,1,4,1,4096,0,1,3,8,1,0,4096,4097,1,5,0,4,1,4096,11]

theorem envBound16418 : H12AffineFastState.Bounded env16418 := by
  intro p hp
  have h : env16418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16417_16418 : H12AffineEnvironment.transform 4 1 env16417 = env16418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16417 == env16418) = true)

theorem identity16418 : scanCanonicalize (H12AffineFastState.compose env16418 (packedSelected [3] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound16418 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env16419 : List Nat := [2,4,8,0,1,0,9,5,10,5,1,0,9,0,0,2,1,1,4,1,0,0,1,3,8,1,0,0,1,1,5,0,4,1,0,11]

theorem envBound16419 : H12AffineFastState.Bounded env16419 := by
  intro p hp
  have h : env16419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16418_16419 : H12AffineEnvironment.transform 11 0 env16418 = env16419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env16418 == env16419) = true)

theorem identity16419 : scanCanonicalize (H12AffineFastState.compose env16419 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound16419 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16420 : List Nat := [2,4,2,0,1,0,3,5,0,5,1,0,3,0,0,2,1,1,4,1,0,0,1,3,2,1,0,0,1,1,5,0,4,1,0,1]

theorem envBound16420 : H12AffineFastState.Bounded env16420 := by
  intro p hp
  have h : env16420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16419_16420 : H12AffineEnvironment.transform 2 2 env16419 = env16420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env16419 == env16420) = true)

def env16421 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,4194304,8388608,98780,8328,65,12729589,79131,8480026,8568105,8390092,4314199,257,8484154,8492191,8462874]

theorem envBound16421 : H12AffineFastState.Bounded env16421 := by
  intro p hp
  have h : env16421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16386_16421 : H12AffineEnvironment.transform 17 32041 env16386 = env16421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env16386 == env16421) = true)

def env16422 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,4194304,16,98780,8328,65,4340965,79131,91402,179513,1500,4314199,257,95530,103567,74250]

theorem envBound16422 : H12AffineFastState.Bounded env16422 := by
  intro p hp
  have h : env16422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16421_16422 : H12AffineEnvironment.transform 22 16 env16421 = env16422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env16421 == env16422) = true)

theorem identity16422 : scanCanonicalize (H12AffineFastState.compose env16422 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 41340) := by decide +kernel

theorem selectedBound16422 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16423 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,41340,16,98780,8328,65,171417,79131,91402,179513,1500,95531,257,95530,103567,74250]

theorem envBound16423 : H12AffineFastState.Bounded env16423 := by
  intro p hp
  have h : env16423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16422_16423 : H12AffineEnvironment.transform 21 41340 env16422 = env16423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41340 env16422 == env16423) = true)

theorem identity16423 : scanCanonicalize (H12AffineFastState.compose env16423 (packedSelected [0,5,8,9,11,14,15,22,24,26,27,28,31,32,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 21646) := by decide +kernel

theorem selectedBound16423 : packedSelected [0,5,8,9,11,14,15,22,24,26,27,28,31,32,35,38] rootPS < 2^1333 := by decide +kernel

def env16424 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,21646,131072,32041,1025,32769,25796,41340,16,54610,8328,65,171417,24981,12676,179513,1500,8613,257,8612,49153,30340]

theorem envBound16424 : H12AffineFastState.Bounded env16424 := by
  intro p hp
  have h : env16424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16423_16424 : H12AffineEnvironment.transform 15 21646 env16423 = env16424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21646 env16423 == env16424) = true)

theorem identity16424 : scanCanonicalize (H12AffineFastState.compose env16424 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound16424 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env16425 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,16384,32768,21646,131072,23589,1025,32769,17864,32880,16,54610,388,65,171417,16537,4232,171061,1500,169,257,168,49153,22408]

theorem envBound16425 : H12AffineFastState.Bounded env16425 := by
  intro p hp
  have h : env16425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16424_16425 : H12AffineEnvironment.transform 12 268 env16424 = env16425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env16424 == env16425) = true)

theorem identity16425 : scanCanonicalize (H12AffineFastState.compose env16425 (packedSelected [0,3,4,7,10,11,12,15,17,18,19,22,24] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound16425 : packedSelected [0,3,4,7,10,11,12,15,17,18,19,22,24] rootPS < 2^1333 := by decide +kernel

def env16426 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,16384,32768,21646,5528,23589,1025,32769,17864,32880,16,54610,388,65,34817,16537,4232,35245,1500,169,257,168,49153,22408]

theorem envBound16426 : H12AffineFastState.Bounded env16426 := by
  intro p hp
  have h : env16426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16425_16426 : H12AffineEnvironment.transform 16 5528 env16425 = env16426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env16425 == env16426) = true)

theorem identity16426 : scanCanonicalize (H12AffineFastState.compose env16426 (packedSelected [0,1,3,4,5,7,8,10,11,12,15,16,18,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound16426 : packedSelected [0,1,3,4,5,7,8,10,11,12,15,16,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env16427 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5513,32768,263,5528,2476,1025,32769,4161,32880,16,32987,388,65,34817,5392,4232,35245,1500,169,257,168,38280,513]

theorem envBound16427 : H12AffineFastState.Bounded env16427 := by
  intro p hp
  have h : env16427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16426_16427 : H12AffineEnvironment.transform 13 5513 env16426 = env16427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env16426 == env16427) = true)

theorem identity16427 : scanCanonicalize (H12AffineFastState.compose env16427 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound16427 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env16428 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5456,32768,263,5441,2421,1025,32769,4161,32880,16,32770,349,65,34817,5392,4177,35188,1285,112,257,113,38225,513]

theorem envBound16428 : H12AffineFastState.Bounded env16428 := by
  intro p hp
  have h : env16428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16427_16428 : H12AffineEnvironment.transform 6 89 env16427 = env16428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env16427 == env16428) = true)

theorem identity16428 : scanCanonicalize (H12AffineFastState.compose env16428 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound16428 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env16429 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,1076,268,356,32768,263,373,2421,1025,32769,1141,32880,16,32770,349,65,34817,292,1125,35188,1285,112,257,113,33125,513]

theorem envBound16429 : H12AffineFastState.Bounded env16429 := by
  intro p hp
  have h : env16429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16428_16429 : H12AffineEnvironment.transform 11 1076 env16428 = env16429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env16428 == env16429) = true)

theorem identity16429 : scanCanonicalize (H12AffineFastState.compose env16429 (packedSelected [0,1,3,4,7,9,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 885) := by decide +kernel

theorem selectedBound16429 : packedSelected [0,1,3,4,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env16430 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,1076,268,356,885,263,373,2421,1025,884,1141,773,16,887,349,65,2932,292,1125,2561,1285,112,257,113,528,513]

theorem envBound16430 : H12AffineFastState.Bounded env16430 := by
  intro p hp
  have h : env16430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16429_16430 : H12AffineEnvironment.transform 14 885 env16429 = env16430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 885 env16429 == env16430) = true)

def env16431 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,4194304,17,98780,8328,65,4340964,79131,91403,179512,1501,4314199,257,95531,103566,74251]

theorem envBound16431 : H12AffineFastState.Bounded env16431 := by
  intro p hp
  have h : env16431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16421_16431 : H12AffineEnvironment.transform 22 17 env16421 = env16431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env16421 == env16431) = true)

theorem identity16431 : scanCanonicalize (H12AffineFastState.compose env16431 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound16431 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16432 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,32041,1025,29908,77898,4194304,17,95497,8328,65,4340964,79131,91403,149997,1501,4268162,257,95531,90203,74251]

theorem envBound16432 : H12AffineFastState.Bounded env16432 := by
  intro p hp
  have h : env16432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16431_16432 : H12AffineEnvironment.transform 14 29909 env16431 = env16432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env16431 == env16432) = true)

def env16433 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10281,1025,8660,77898,4194304,17,73737,8328,65,4340964,79131,77835,138477,1501,4268162,257,73771,79195,74251]

theorem envBound16433 : H12AffineFastState.Bounded env16433 := by
  intro p hp
  have h : env16433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16432_16433 : H12AffineEnvironment.transform 13 5376 env16432 = env16433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env16432 == env16433) = true)

theorem identity16433 : scanCanonicalize (H12AffineFastState.compose env16433 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound16433 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8202,131072,10281,1025,8660,4160,4194304,17,3,8328,65,4340964,5393,4097,138477,1501,4194440,257,33,5457,513]

theorem envBound16434 : H12AffineFastState.Bounded env16434 := by
  intro p hp
  have h : env16434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16433_16434 : H12AffineEnvironment.transform 15 8202 env16433 = env16434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env16433 == env16434) = true)

theorem identity16434 : scanCanonicalize (H12AffineFastState.compose env16434 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(21+1) ^^^ 8321) := by decide +kernel

theorem selectedBound16434 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env16435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8202,131072,10281,1025,8660,4160,8321,17,3,8328,65,138341,5393,4097,138477,1501,8201,257,33,5457,513]

theorem envBound16435 : H12AffineFastState.Bounded env16435 := by
  intro p hp
  have h : env16435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16434_16435 : H12AffineEnvironment.transform 21 8321 env16434 = env16435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8321 env16434 == env16435) = true)

theorem identity16435 : scanCanonicalize (H12AffineFastState.compose env16435 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound16435 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env16436 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8202,5392,10281,1025,8660,4160,8321,17,3,8328,65,2421,5393,4097,2557,1501,8201,257,33,5457,513]

theorem envBound16436 : H12AffineFastState.Bounded env16436 := by
  intro p hp
  have h : env16436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16435_16436 : H12AffineEnvironment.transform 16 5392 env16435 = env16436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env16435 == env16436) = true)

theorem identity16436 : scanCanonicalize (H12AffineFastState.compose env16436 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound16436 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env16437 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,4112,8661,8202,4096,10281,273,8660,4160,8321,17,3,8328,65,2421,4097,4097,2557,205,8201,257,33,4161,513]

theorem envBound16437 : H12AffineFastState.Bounded env16437 := by
  intro p hp
  have h : env16437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16436_16437 : H12AffineEnvironment.transform 9 272 env16436 = env16437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env16436 == env16437) = true)

theorem identity16437 : scanCanonicalize (H12AffineFastState.compose env16437 (packedSelected [14] rootPS)) = affineNative (2^(7+1) ^^^ 237) := by decide +kernel

theorem selectedBound16437 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env16438 : List Nat := [2,4,8,16,32,64,128,237,512,253,2048,4096,8192,4112,8248,8202,4096,10281,252,8249,4160,8321,17,3,8328,65,2200,4097,4097,2064,205,8201,236,33,4161,513]

theorem envBound16438 : H12AffineFastState.Bounded env16438 := by
  intro p hp
  have h : env16438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16437_16438 : H12AffineEnvironment.transform 7 237 env16437 = env16438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 237 env16437 == env16438) = true)

theorem identity16438 : scanCanonicalize (H12AffineFastState.compose env16438 (packedSelected [0,27] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound16438 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env16439 : List Nat := [2,4,8,16,32,64,128,237,512,253,2048,4096,160,4112,152,170,4096,2185,252,153,4160,33,17,3,40,65,2200,4097,4097,2064,205,169,236,33,4161,513]

theorem envBound16439 : H12AffineFastState.Bounded env16439 := by
  intro p hp
  have h : env16439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16438_16439 : H12AffineEnvironment.transform 12 160 env16438 = env16439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env16438 == env16439) = true)

theorem identity16439 : scanCanonicalize (H12AffineFastState.compose env16439 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2200) := by decide +kernel

theorem selectedBound16439 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env16440 : List Nat := [2,4,8,16,32,64,128,237,512,253,2048,2200,160,2184,152,170,2200,2185,252,153,2264,33,17,3,40,65,2200,2201,2201,2064,205,169,236,33,2265,513]

theorem envBound16440 : H12AffineFastState.Bounded env16440 := by
  intro p hp
  have h : env16440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16439_16440 : H12AffineEnvironment.transform 11 2200 env16439 = env16440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2200 env16439 == env16440) = true)

theorem identity16440 : scanCanonicalize (H12AffineFastState.compose env16440 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound16440 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env16441 : List Nat := [2,4,8,16,32,64,9,100,512,116,2048,2065,41,2049,17,35,2065,2048,117,16,2129,33,17,3,40,65,2065,2064,2064,2064,68,32,101,33,2128,513]

theorem envBound16441 : H12AffineFastState.Bounded env16441 := by
  intro p hp
  have h : env16441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16440_16441 : H12AffineEnvironment.transform 6 9 env16440 = env16441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16440 == env16441) = true)

theorem identity16441 : scanCanonicalize (H12AffineFastState.compose env16441 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16441 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16442 : List Nat := [2,4,8,16,1,64,9,69,512,85,2048,2065,8,2049,17,2,2065,2048,84,16,2129,0,17,3,9,65,2065,2064,2064,2064,68,1,68,0,2128,513]

theorem envBound16442 : H12AffineFastState.Bounded env16442 := by
  intro p hp
  have h : env16442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16441_16442 : H12AffineEnvironment.transform 4 1 env16441 = env16442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16441 == env16442) = true)

theorem identity16442 : scanCanonicalize (H12AffineFastState.compose env16442 (packedSelected [0,1,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16442 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env16443 : List Nat := [2,4,8,16,1,17,9,20,512,4,2048,2065,8,2049,17,2,2065,2048,5,16,2048,0,17,3,9,16,2065,2064,2064,2064,21,1,21,0,2049,513]

theorem envBound16443 : H12AffineFastState.Bounded env16443 := by
  intro p hp
  have h : env16443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16442_16443 : H12AffineEnvironment.transform 5 17 env16442 = env16443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16442 == env16443) = true)

theorem identity16443 : scanCanonicalize (H12AffineFastState.compose env16443 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound16443 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16444 : List Nat := [2,4,8,16,1,17,9,20,512,4,529,512,8,528,17,2,512,529,5,16,529,0,17,3,9,16,512,513,513,513,21,1,21,0,528,513]

theorem envBound16444 : H12AffineFastState.Bounded env16444 := by
  intro p hp
  have h : env16444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16443_16444 : H12AffineEnvironment.transform 10 529 env16443 = env16444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env16443 == env16444) = true)

def env16445 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,10280,1025,8661,77898,4194304,17,73736,8328,65,4340964,79131,77834,138476,1501,4268162,257,73770,79194,74251]

theorem envBound16445 : H12AffineFastState.Bounded env16445 := by
  intro p hp
  have h : env16445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16432_16445 : H12AffineEnvironment.transform 13 5377 env16432 = env16445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env16432 == env16445) = true)

theorem identity16445 : scanCanonicalize (H12AffineFastState.compose env16445 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound16445 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16446 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8322,131072,10280,1025,8661,4296,4194304,17,138,8328,65,4340964,5529,4232,138476,1501,4194304,257,168,5592,649]

theorem envBound16446 : H12AffineFastState.Bounded env16446 := by
  intro p hp
  have h : env16446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16445_16446 : H12AffineEnvironment.transform 15 8322 env16445 = env16446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env16445 == env16446) = true)

theorem identity16446 : scanCanonicalize (H12AffineFastState.compose env16446 (packedSelected [0,4,7,11,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound16446 : packedSelected [0,4,7,11,18,22] rootPS < 2^1333 := by decide +kernel

def env16447 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,137,479,131072,2421,1025,136,4296,4194304,17,138,469,65,4332985,5529,4232,138476,1501,4194304,257,168,5592,649]

theorem envBound16447 : H12AffineFastState.Bounded env16447 := by
  intro p hp
  have h : env16447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16446_16447 : H12AffineEnvironment.transform 12 349 env16446 = env16447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env16446 == env16447) = true)

theorem identity16447 : scanCanonicalize (H12AffineFastState.compose env16447 (packedSelected [0,1,2,6,7,8,10,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound16447 : packedSelected [0,1,2,6,7,8,10,15,16] rootPS < 2^1333 := by decide +kernel

def env16448 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,342,131072,2421,1025,1,4161,4194304,17,3,348,65,4332848,5392,4097,138341,1364,4194304,257,33,5457,512]

theorem envBound16448 : H12AffineFastState.Bounded env16448 := by
  intro p hp
  have h : env16448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16447_16448 : H12AffineEnvironment.transform 6 9 env16447 = env16448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16447 == env16448) = true)

theorem identity16448 : scanCanonicalize (H12AffineFastState.compose env16448 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 136512) := by decide +kernel

theorem selectedBound16448 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16449 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,342,131072,2421,1025,1,4161,136512,17,3,348,65,2160,5392,4097,138341,1364,136512,257,33,5457,512]

theorem envBound16449 : H12AffineFastState.Bounded env16449 := by
  intro p hp
  have h : env16449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16448_16449 : H12AffineEnvironment.transform 21 136512 env16448 = env16449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136512 env16448 == env16449) = true)

theorem identity16449 : scanCanonicalize (H12AffineFastState.compose env16449 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound16449 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env16450 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,0,262,131072,2341,1025,1,4113,136464,17,3,268,17,2080,5392,4097,138293,1284,136464,257,33,5377,512]

theorem envBound16450 : H12AffineFastState.Bounded env16450 := by
  intro p hp
  have h : env16450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16449_16450 : H12AffineEnvironment.transform 5 16 env16449 = env16450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16449 == env16450) = true)

theorem identity16450 : scanCanonicalize (H12AffineFastState.compose env16450 (packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 5141) := by decide +kernel

theorem selectedBound16450 : packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env16451 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,0,262,5141,2341,1025,1,4113,261,17,3,268,17,2080,5392,4097,2080,1284,261,257,33,5377,512]

theorem envBound16451 : H12AffineFastState.Bounded env16451 := by
  intro p hp
  have h : env16451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16450_16451 : H12AffineEnvironment.transform 16 5141 env16450 = env16451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5141 env16450 == env16451) = true)

theorem identity16451 : scanCanonicalize (H12AffineFastState.compose env16451 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound16451 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env16452 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5156,0,35,5141,2048,1025,1,4113,32,17,3,41,17,2080,5173,4097,2080,1057,32,36,33,5156,512]

theorem envBound16452 : H12AffineFastState.Bounded env16452 := by
  intro p hp
  have h : env16452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16451_16452 : H12AffineEnvironment.transform 7 37 env16451 = env16452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env16451 == env16452) = true)

theorem identity16452 : scanCanonicalize (H12AffineFastState.compose env16452 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16452 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env16453 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,4096,9,5125,0,2,5141,2048,1025,1,4113,1,17,3,8,17,2049,5140,4097,2049,1024,1,5,0,5125,512]

theorem envBound16453 : H12AffineFastState.Bounded env16453 := by
  intro p hp
  have h : env16453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16452_16453 : H12AffineEnvironment.transform 4 1 env16452 = env16453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16452 == env16453) = true)

def env16454 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,16,9,1045,0,2,1029,2048,1025,1,1,1,17,3,8,17,2049,1028,17,2049,1024,1,5,0,1045,512]

theorem envBound16454 : H12AffineFastState.Bounded env16454 := by
  intro p hp
  have h : env16454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16453_16454 : H12AffineEnvironment.transform 11 16 env16453 = env16454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env16453 == env16454) = true)

def env16455 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,17,9,1044,0,2,1028,2048,1025,1,0,1,17,3,8,17,2049,1029,16,2049,1024,1,5,0,1044,512]

theorem envBound16455 : H12AffineFastState.Bounded env16455 := by
  intro p hp
  have h : env16455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16453_16455 : H12AffineEnvironment.transform 11 17 env16453 = env16455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env16453 == env16455) = true)

theorem identity16455 : scanCanonicalize (H12AffineFastState.compose env16455 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound16455 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16456 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,17,9,0,0,2,16,2048,21,1,0,1,17,3,8,17,2049,17,16,2049,20,1,5,0,0,512]

theorem envBound16456 : H12AffineFastState.Bounded env16456 := by
  intro p hp
  have h : env16456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16455_16456 : H12AffineEnvironment.transform 9 20 env16455 = env16456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env16455 == env16456) = true)

theorem identity16456 : scanCanonicalize (H12AffineFastState.compose env16456 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 542) := by decide +kernel

theorem selectedBound16456 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16457 : List Nat := [2,4,8,16,1,16,9,4,512,20,542,17,9,0,0,2,16,542,21,1,0,1,17,3,8,17,543,17,16,543,20,1,5,0,0,512]

theorem envBound16457 : H12AffineFastState.Bounded env16457 := by
  intro p hp
  have h : env16457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16456_16457 : H12AffineEnvironment.transform 10 542 env16456 = env16457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 542 env16456 == env16457) = true)

def leafEnv16457 : List Nat := [2,4,8,16,1,16,9,4,512,20,542,17,9,0,0,2,16,542,21,1,0,1,17,3,21,8,1,17,543,17,16,543,20,1,5,0,5,3,0,512,1,0,0]

def active16457 : List Nat := [0,1,2,3,8]

def tree16457 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16457 : H12WitnessSearch.Good tree16457 := H12GlobalWitnessIndex.good

theorem leafIdentity16457 : H12AffineFastState.composeSystem env16457 rootObs = leafEnv16457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16457 rootObs == leafEnv16457) = true)

theorem terminalChecked16457 : H12PackedTerminal.terminalCheckFast leafEnv16457 active16457 tree16457 = true := by decide +kernel

def env16458 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616401,155254785,92374097,145662400,525568,140903596,27337993,25733063]

theorem envBound16458 : H12AffineFastState.Bounded env16458 := by
  intro p hp
  have h : env16458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14985_16458 : H12AffineEnvironment.transform 29 155254785 env14985 = env16458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env14985 == env16458) = true)

def env16459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507601,155254785,25265169,145662400,525568,140903596,27337993,25733063]

theorem envBound16459 : H12AffineFastState.Bounded env16459 := by
  intro p hp
  have h : env16459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16458_16459 : H12AffineEnvironment.transform 25 64 env16458 = env16459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env16458 == env16459) = true)

def env16460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507601,9356289,25265169,23160256,525568,27902124,27337993,25733063]

theorem envBound16460 : H12AffineFastState.Bounded env16460 := by
  intro p hp
  have h : env16460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16459_16460 : H12AffineEnvironment.transform 26 30393344 env16459 = env16460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env16459 == env16460) = true)

def env16461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830977,25265169,23160256,256,27378860,27337993,25207751]

theorem envBound16461 : H12AffineFastState.Bounded env16461 := by
  intro p hp
  have h : env16461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16460_16461 : H12AffineEnvironment.transform 18 1024 env16460 = env16461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env16460 == env16461) = true)

theorem identity16461 : scanCanonicalize (H12AffineFastState.compose env16461 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8388626) := by decide +kernel

theorem selectedBound16461 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env16462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8388626,8328,64,4702226,10585246,10507601,8830977,99331,14771666,256,2213054,2172187,41941]

theorem envBound16462 : H12AffineFastState.Bounded env16462 := by
  intro p hp
  have h : env16462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16461_16462 : H12AffineEnvironment.transform 23 8388626 env16461 = env16462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8388626 env16461 == env16462) = true)

def env16463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147592,147610,8328,64,4702226,2343958,2233817,295049,99331,6497626,256,2213054,2172187,41941]

theorem envBound16463 : H12AffineFastState.Bounded env16463 := by
  intro p hp
  have h : env16463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16462_16463 : H12AffineEnvironment.transform 22 147592 env16462 = env16463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147592 env16462 == env16463) = true)

def env16464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1024,32769,2097152,4194304,147592,147610,8328,64,4450482,2343958,2233817,43049,99331,6497626,256,2213054,2172187,41941]

theorem envBound16464 : H12AffineFastState.Bounded env16464 := by
  intro p hp
  have h : env16464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16463_16464 : H12AffineEnvironment.transform 17 10400 env16463 = env16464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env16463 == env16464) = true)

theorem identity16464 : scanCanonicalize (H12AffineFastState.compose env16464 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound16464 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env16465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10400,1024,32769,2097152,4194304,152,138,8328,64,4303010,2196486,2119113,43049,99331,6382922,256,2213054,2172187,41941]

theorem envBound16465 : H12AffineFastState.Bounded env16465 := by
  intro p hp
  have h : env16465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16464_16465 : H12AffineEnvironment.transform 16 16400 env16464 = env16465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env16464 == env16465) = true)

theorem identity16465 : scanCanonicalize (H12AffineFastState.compose env16465 (packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound16465 : packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env16466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10400,1024,32769,2097152,4194304,152,138,8328,64,4229289,2139149,2119113,43049,41992,6309185,256,2155701,2098448,41941]

theorem envBound16466 : H12AffineFastState.Bounded env16466 := by
  intro p hp
  have h : env16466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16465_16466 : H12AffineEnvironment.transform 15 8203 env16465 = env16466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env16465 == env16466) = true)

theorem identity16466 : scanCanonicalize (H12AffineFastState.compose env16466 (packedSelected [1,3,4,5,7,8,9,10,11,16,17,18,19,20,23,27,32] rootPS)) = affineNative (2^(20+1) ^^^ 17816) := by decide +kernel

theorem selectedBound16466 : packedSelected [1,3,4,5,7,8,9,10,11,16,17,18,19,20,23,27,32] rootPS < 2^1333 := by decide +kernel

def env16467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10400,1024,32769,17816,4194304,152,138,8328,64,4229289,57749,4177,43049,41992,4194521,256,41261,16520,41941]

theorem envBound16467 : H12AffineFastState.Bounded env16467 := by
  intro p hp
  have h : env16467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16466_16467 : H12AffineEnvironment.transform 20 17816 env16466 = env16467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17816 env16466 == env16467) = true)

theorem identity16467 : scanCanonicalize (H12AffineFastState.compose env16467 (packedSelected [4,5,7,8,9,10,16,17,19,20,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound16467 : packedSelected [4,5,7,8,9,10,16,17,19,20,24,27,28] rootPS < 2^1333 := by decide +kernel

def env16468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10400,1024,32769,17816,32,152,138,8328,64,34953,57749,4177,43049,41992,249,256,41261,16520,41941]

theorem envBound16468 : H12AffineFastState.Bounded env16468 := by
  intro p hp
  have h : env16468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16467_16468 : H12AffineEnvironment.transform 21 32 env16467 = env16468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env16467 == env16468) = true)

theorem identity16468 : scanCanonicalize (H12AffineFastState.compose env16468 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,18,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound16468 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env16469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5237,32768,8203,5221,10400,1024,32769,4589,32,152,138,8328,64,34953,46560,4177,43049,41992,249,256,41261,5373,41941]

theorem envBound16469 : H12AffineFastState.Bounded env16469 := by
  intro p hp
  have h : env16469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16468_16469 : H12AffineEnvironment.transform 13 5237 env16468 = env16469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env16468 == env16469) = true)

theorem identity16469 : scanCanonicalize (H12AffineFastState.compose env16469 (packedSelected [3,5,10,12,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 8432) := by decide +kernel

theorem selectedBound16469 : packedSelected [3,5,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env16470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5237,8432,8203,5221,10400,1024,8433,4589,32,152,138,8328,64,10361,5392,4177,2265,1272,249,256,477,5373,805]

theorem envBound16470 : H12AffineFastState.Bounded env16470 := by
  intro p hp
  have h : env16470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16469_16470 : H12AffineEnvironment.transform 14 8432 env16469 = env16470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8432 env16469 == env16470) = true)

theorem identity16470 : scanCanonicalize (H12AffineFastState.compose env16470 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound16470 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env16471 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5237,292,479,5221,2420,1024,293,4589,32,152,138,348,64,2477,5392,4177,2265,1272,249,256,477,5373,805]

theorem envBound16471 : H12AffineFastState.Bounded env16471 := by
  intro p hp
  have h : env16471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16470_16471 : H12AffineEnvironment.transform 12 468 env16470 = env16471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env16470 == env16471) = true)

theorem identity16471 : scanCanonicalize (H12AffineFastState.compose env16471 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound16471 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env16472 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,161,5237,81,170,5221,2049,1024,80,4248,32,152,138,41,64,2264,5221,4177,2265,1272,249,117,168,5373,592]

theorem envBound16472 : H12AffineFastState.Bounded env16472 := by
  intro p hp
  have h : env16472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16471_16472 : H12AffineEnvironment.transform 7 117 env16471 = env16472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env16471 == env16472) = true)

theorem identity16472 : scanCanonicalize (H12AffineFastState.compose env16472 (packedSelected [0,1,6,7,8,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound16472 : packedSelected [0,1,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env16473 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,4096,161,5157,1,170,5173,2049,1024,0,4248,32,152,138,41,16,2184,5173,4097,2185,1192,169,37,168,5293,512]

theorem envBound16473 : H12AffineFastState.Bounded env16473 := by
  intro p hp
  have h : env16473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16472_16473 : H12AffineEnvironment.transform 5 16 env16472 = env16473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16472 == env16473) = true)

theorem identity16473 : scanCanonicalize (H12AffineFastState.compose env16473 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16473 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16474 : List Nat := [2,4,8,16,0,16,128,5,512,1024,2048,4096,129,5125,1,138,5141,2049,1024,0,4248,0,152,138,9,16,2184,5141,4097,2185,1160,137,5,136,5261,512]

theorem envBound16474 : H12AffineFastState.Bounded env16474 := by
  intro p hp
  have h : env16474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16473_16474 : H12AffineEnvironment.transform 4 0 env16473 = env16474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16473 == env16474) = true)

def env16475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1024,32769,2097152,4194304,147592,147610,8328,64,4450483,2343958,2233817,43048,99331,6497626,256,2213054,2172187,41941]

theorem envBound16475 : H12AffineFastState.Bounded env16475 := by
  intro p hp
  have h : env16475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16463_16475 : H12AffineEnvironment.transform 17 10401 env16463 = env16475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env16463 == env16475) = true)

theorem identity16475 : scanCanonicalize (H12AffineFastState.compose env16475 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16475 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env16476 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,2097152,4194304,147456,147474,8192,64,4450363,2343958,2233681,43048,99331,6497626,256,2212918,2172187,41821]

theorem envBound16476 : H12AffineFastState.Bounded env16476 := by
  intro p hp
  have h : env16476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16475_16476 : H12AffineEnvironment.transform 6 8 env16475 = env16476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16475 == env16476) = true)

theorem identity16476 : scanCanonicalize (H12AffineFastState.compose env16476 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound16476 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env16477 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1024,8541,2097152,4194304,147456,147474,8192,64,4409703,2319690,2233681,2420,75103,6497626,256,2188650,2172187,513]

theorem envBound16477 : H12AffineFastState.Bounded env16477 := by
  intro p hp
  have h : env16477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16476_16477 : H12AffineEnvironment.transform 14 8540 env16476 = env16477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env16476 == env16477) = true)

def env16478 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10281,1024,8461,2097152,4194304,147456,147474,8192,16,4409655,2319642,2233601,2340,75023,6497546,256,2188602,2172187,513]

theorem envBound16478 : H12AffineFastState.Bounded env16478 := by
  intro p hp
  have h : env16478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16477_16478 : H12AffineEnvironment.transform 5 16 env16477 = env16478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16477 == env16478) = true)

theorem identity16478 : scanCanonicalize (H12AffineFastState.compose env16478 (packedSelected [0,3,4,5,7,9,10,16,17,18] rootPS)) = affineNative (2^(21+1) ^^^ 213302) := by decide +kernel

theorem selectedBound16478 : packedSelected [0,3,4,5,7,9,10,16,17,18] rootPS < 2^1333 := by decide +kernel

def env16479 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10281,1024,8461,2097152,213302,147456,147474,8192,16,2049,2319642,2233601,2340,75023,2122812,256,2188602,2172187,513]

theorem envBound16479 : H12AffineFastState.Bounded env16479 := by
  intro p hp
  have h : env16479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16478_16479 : H12AffineEnvironment.transform 21 213302 env16478 = env16479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 213302 env16478 == env16479) = true)

theorem identity16479 : scanCanonicalize (H12AffineFastState.compose env16479 (packedSelected [1,2,6,8,10,11,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound16479 : packedSelected [1,2,6,8,10,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env16480 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,1,65536,131072,2340,1024,0,2097152,213302,147456,147474,269,16,2049,2311191,2233601,2340,66562,2114865,256,2180151,2163734,513]

theorem envBound16480 : H12AffineFastState.Bounded env16480 := by
  intro p hp
  have h : env16480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16479_16480 : H12AffineEnvironment.transform 12 269 env16479 = env16480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env16479 == env16480) = true)

theorem identity16480 : scanCanonicalize (H12AffineFastState.compose env16480 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 132353) := by decide +kernel

theorem selectedBound16480 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env16481 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,1,65536,131072,2340,1024,0,132353,213302,147456,147474,269,16,2049,82198,4096,2340,66562,147504,256,213302,196887,513]

theorem envBound16481 : H12AffineFastState.Bounded env16481 := by
  intro p hp
  have h : env16481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16480_16481 : H12AffineEnvironment.transform 20 132353 env16480 = env16481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 132353 env16480 == env16481) = true)

theorem identity16481 : scanCanonicalize (H12AffineFastState.compose env16481 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound16481 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env16482 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,1,65536,16400,2340,1024,0,17681,65830,16,2,269,16,2049,82198,4096,2340,66562,32,256,65830,82183,513]

theorem envBound16482 : H12AffineFastState.Bounded env16482 := by
  intro p hp
  have h : env16482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16481_16482 : H12AffineEnvironment.transform 16 16400 env16481 = env16482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env16481 == env16482) = true)

theorem identity16482 : scanCanonicalize (H12AffineFastState.compose env16482 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(15+1) ^^^ 24370) := by decide +kernel

theorem selectedBound16482 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env16483 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,1,24370,16400,2340,1024,0,17681,24084,16,2,269,16,2049,7716,4096,2340,23344,32,256,24084,7733,513]

theorem envBound16483 : H12AffineFastState.Bounded env16483 := by
  intro p hp
  have h : env16483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16482_16483 : H12AffineEnvironment.transform 15 24370 env16482 = env16483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24370 env16482 == env16483) = true)

theorem identity16483 : scanCanonicalize (H12AffineFastState.compose env16483 (packedSelected [0,3,4,5,12] rootPS)) = affineNative (2^(13+1) ^^^ 7733) := by decide +kernel

theorem selectedBound16483 : packedSelected [0,3,4,5,12] rootPS < 2^1333 := by decide +kernel

def env16484 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,7733,1,263,7717,2340,1024,0,6948,33,16,2,269,16,2049,7716,4096,2340,1285,32,256,33,7733,513]

theorem envBound16484 : H12AffineFastState.Bounded env16484 := by
  intro p hp
  have h : env16484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16483_16484 : H12AffineEnvironment.transform 13 7733 env16483 = env16484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7733 env16483 == env16484) = true)

theorem identity16484 : scanCanonicalize (H12AffineFastState.compose env16484 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound16484 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16485 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,276,269,3873,1,263,3889,2340,1024,0,2608,33,16,2,269,16,2049,3888,276,2340,1285,32,256,33,3873,513]

theorem envBound16485 : H12AffineFastState.Bounded env16485 := by
  intro p hp
  have h : env16485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16484_16485 : H12AffineEnvironment.transform 11 276 env16484 = env16485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env16484 == env16485) = true)

theorem identity16485 : scanCanonicalize (H12AffineFastState.compose env16485 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 298) := by decide +kernel

theorem selectedBound16485 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16486 : List Nat := [2,4,8,16,32,16,8,256,512,298,2048,276,269,2571,1,263,2587,2340,298,0,2608,33,16,2,269,16,2049,2586,276,2340,47,32,256,33,2571,513]

theorem envBound16486 : H12AffineFastState.Bounded env16486 := by
  intro p hp
  have h : env16486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16485_16486 : H12AffineEnvironment.transform 9 298 env16485 = env16486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 298 env16485 == env16486) = true)

theorem identity16486 : scanCanonicalize (H12AffineFastState.compose env16486 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 58) := by decide +kernel

theorem selectedBound16486 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16487 : List Nat := [2,4,8,16,32,16,8,256,58,298,2048,276,269,2097,1,263,2081,2340,298,0,2058,33,16,2,269,16,2049,2080,276,2340,47,32,256,33,2097,59]

theorem envBound16487 : H12AffineFastState.Bounded env16487 := by
  intro p hp
  have h : env16487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16486_16487 : H12AffineEnvironment.transform 8 58 env16486 = env16487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 58 env16486 == env16487) = true)

theorem identity16487 : scanCanonicalize (H12AffineFastState.compose env16487 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound16487 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env16488 : List Nat := [2,4,2,16,32,16,2,256,48,288,2048,276,263,2097,1,263,2081,2340,288,0,2048,33,16,2,263,16,2049,2080,276,2340,37,32,256,33,2097,49]

theorem envBound16488 : H12AffineFastState.Bounded env16488 := by
  intro p hp
  have h : env16488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16487_16488 : H12AffineEnvironment.transform 2 2 env16487 = env16488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env16487 == env16488) = true)

theorem identity16488 : scanCanonicalize (H12AffineFastState.compose env16488 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound16488 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env16489 : List Nat := [2,4,2,16,32,16,2,256,48,288,48,276,263,1,1,263,17,276,288,0,48,33,16,2,263,16,49,16,276,276,37,32,256,33,1,49]

theorem envBound16489 : H12AffineFastState.Bounded env16489 := by
  intro p hp
  have h : env16489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16488_16489 : H12AffineEnvironment.transform 10 48 env16488 = env16489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env16488 == env16489) = true)

theorem identity16489 : scanCanonicalize (H12AffineFastState.compose env16489 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound16489 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env16490 : List Nat := [2,4,2,16,32,16,2,21,48,53,48,1,18,1,1,18,17,1,53,0,48,33,16,2,18,16,49,16,1,1,37,32,21,33,1,49]

theorem envBound16490 : H12AffineFastState.Bounded env16490 := by
  intro p hp
  have h : env16490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16489_16490 : H12AffineEnvironment.transform 7 21 env16489 = env16490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env16489 == env16490) = true)

theorem identity16490 : scanCanonicalize (H12AffineFastState.compose env16490 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound16490 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env16491 : List Nat := [2,4,2,7,32,7,2,2,39,34,39,1,5,1,1,5,6,1,34,0,39,33,7,2,5,7,38,7,1,1,37,32,2,33,1,38]

theorem envBound16491 : H12AffineFastState.Bounded env16491 := by
  intro p hp
  have h : env16491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16490_16491 : H12AffineEnvironment.transform 3 7 env16490 = env16491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env16490 == env16491) = true)

def env16492 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10281,1024,8460,2097152,4194304,147456,147474,8192,17,4409654,2319643,2233600,2341,75022,6497547,256,2188603,2172187,513]

theorem envBound16492 : H12AffineFastState.Bounded env16492 := by
  intro p hp
  have h : env16492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16477_16492 : H12AffineEnvironment.transform 5 17 env16477 = env16492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16477 == env16492) = true)

theorem identity16492 : scanCanonicalize (H12AffineFastState.compose env16492 (packedSelected [0,3,4,5,7,9,10,16,17,18] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound16492 : packedSelected [0,3,4,5,7,9,10,16,17,18] rootPS < 2^1333 := by decide +kernel

def env16493 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10281,1024,8460,2097152,8493,147456,147474,8192,17,223259,2319643,2233600,2341,75022,2294822,256,2188603,2172187,513]

theorem envBound16493 : H12AffineFastState.Bounded env16493 := by
  intro p hp
  have h : env16493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16492_16493 : H12AffineEnvironment.transform 21 8493 env16492 = env16493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env16492 == env16493) = true)

theorem identity16493 : scanCanonicalize (H12AffineFastState.compose env16493 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(20+1) ^^^ 197639) := by decide +kernel

theorem selectedBound16493 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env16494 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10281,1024,8460,197639,8493,147456,147474,8192,17,223259,24860,69895,2341,75022,33,256,155964,139548,513]

theorem envBound16494 : H12AffineFastState.Bounded env16494 := by
  intro p hp
  have h : env16494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16493_16494 : H12AffineEnvironment.transform 20 197639 env16493 = env16494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 197639 env16493 == env16494) = true)

theorem identity16494 : scanCanonicalize (H12AffineFastState.compose env16494 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound16494 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env16495 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,65536,24861,10281,1024,8460,91418,8493,8477,8463,8192,17,67846,24860,69895,2341,75022,33,256,33,16385,513]

theorem envBound16495 : H12AffineFastState.Bounded env16495 := by
  intro p hp
  have h : env16495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16494_16495 : H12AffineEnvironment.transform 16 24861 env16494 = env16495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env16494 == env16495) = true)

theorem identity16495 : scanCanonicalize (H12AffineFastState.compose env16495 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound16495 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env16496 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,1,65536,16401,2341,1024,0,82966,33,17,3,268,17,67846,16400,69895,2341,66562,33,256,33,16385,513]

theorem envBound16496 : H12AffineFastState.Bounded env16496 := by
  intro p hp
  have h : env16496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16495_16496 : H12AffineEnvironment.transform 12 268 env16495 = env16496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env16495 == env16496) = true)

theorem identity16496 : scanCanonicalize (H12AffineFastState.compose env16496 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound16496 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16497 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,1,263,16401,2341,1024,0,17681,33,17,3,268,17,2049,16400,4096,2341,1285,33,256,33,16385,513]

theorem envBound16497 : H12AffineFastState.Bounded env16497 := by
  intro p hp
  have h : env16497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16496_16497 : H12AffineEnvironment.transform 15 263 env16496 = env16497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env16496 == env16497) = true)

theorem identity16497 : scanCanonicalize (H12AffineFastState.compose env16497 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound16497 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16498 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,1,263,5393,2341,1024,0,4113,33,17,3,268,17,2049,5392,4096,2341,1285,33,256,33,5377,513]

theorem envBound16498 : H12AffineFastState.Bounded env16498 := by
  intro p hp
  have h : env16498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16497_16498 : H12AffineEnvironment.transform 13 5376 env16497 = env16498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env16497 == env16498) = true)

theorem identity16498 : scanCanonicalize (H12AffineFastState.compose env16498 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2879) := by decide +kernel

theorem selectedBound16498 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16499 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2879,268,3647,1,263,3630,2341,1024,0,2862,33,17,3,268,17,2049,3631,2879,2341,1285,33,256,33,3646,513]

theorem envBound16499 : H12AffineFastState.Bounded env16499 := by
  intro p hp
  have h : env16499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16498_16499 : H12AffineEnvironment.transform 11 2879 env16498 = env16499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2879 env16498 == env16499) = true)

theorem identity16499 : scanCanonicalize (H12AffineFastState.compose env16499 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound16499 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16500 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,2619,8,3647,1,3,3630,2081,1024,0,2602,33,17,3,8,17,2049,3631,2619,2081,1025,33,4,33,3646,513]

theorem envBound16500 : H12AffineFastState.Bounded env16500 := by
  intro p hp
  have h : env16500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16499_16500 : H12AffineEnvironment.transform 7 4 env16499 = env16500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env16499 == env16500) = true)

theorem identity16500 : scanCanonicalize (H12AffineFastState.compose env16500 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1567) := by decide +kernel

theorem selectedBound16500 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env16501 : List Nat := [2,4,8,16,32,17,8,4,512,1024,1567,1060,8,32,1,3,49,1598,1024,0,1077,33,17,3,8,17,1566,48,1060,1598,1025,33,4,33,33,513]

theorem envBound16501 : H12AffineFastState.Bounded env16501 := by
  intro p hp
  have h : env16501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16500_16501 : H12AffineEnvironment.transform 10 1567 env16500 = env16501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1567 env16500 == env16501) = true)

theorem identity16501 : scanCanonicalize (H12AffineFastState.compose env16501 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound16501 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env16502 : List Nat := [2,4,8,16,32,17,8,4,512,543,0,571,8,32,1,3,49,33,543,0,554,33,17,3,8,17,1,48,571,33,542,33,4,33,33,513]

theorem envBound16502 : H12AffineFastState.Bounded env16502 := by
  intro p hp
  have h : env16502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16501_16502 : H12AffineEnvironment.transform 9 543 env16501 = env16502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env16501 == env16502) = true)

theorem identity16502 : scanCanonicalize (H12AffineFastState.compose env16502 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16502 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env16503 : List Nat := [2,4,8,16,1,17,8,4,512,543,0,538,8,1,1,3,16,0,543,0,523,0,17,3,8,17,1,17,538,0,542,0,4,0,0,513]

theorem envBound16503 : H12AffineFastState.Bounded env16503 := by
  intro p hp
  have h : env16503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16502_16503 : H12AffineEnvironment.transform 4 1 env16502 = env16503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16502 == env16503) = true)

theorem identity16503 : scanCanonicalize (H12AffineFastState.compose env16503 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound16503 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16504 : List Nat := [2,4,7,16,1,17,7,4,512,528,0,533,7,1,1,3,16,0,528,0,516,0,17,3,7,17,1,17,533,0,529,0,4,0,0,513]

theorem envBound16504 : H12AffineFastState.Bounded env16504 := by
  intro p hp
  have h : env16504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16503_16504 : H12AffineEnvironment.transform 2 7 env16503 = env16504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env16503 == env16504) = true)

theorem identity16504 : scanCanonicalize (H12AffineFastState.compose env16504 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound16504 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16505 : List Nat := [2,3,0,16,1,17,0,3,512,528,0,530,0,1,1,3,16,0,528,0,515,0,17,3,0,17,1,17,530,0,529,0,3,0,0,513]

theorem envBound16505 : H12AffineFastState.Bounded env16505 := by
  intro p hp
  have h : env16505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16504_16505 : H12AffineEnvironment.transform 1 3 env16504 = env16505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env16504 == env16505) = true)

def env16506 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147593,147611,8328,64,4702226,2343959,2233816,295048,99331,6497627,256,2213054,2172187,41941]

theorem envBound16506 : H12AffineFastState.Bounded env16506 := by
  intro p hp
  have h : env16506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16462_16506 : H12AffineEnvironment.transform 22 147593 env16462 = env16506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147593 env16462 == env16506) = true)

def env16507 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1024,32769,2097152,4194304,147593,147611,8328,64,4450482,2343959,2233816,43048,99331,6497627,256,2213054,2172187,41941]

theorem envBound16507 : H12AffineFastState.Bounded env16507 := by
  intro p hp
  have h : env16507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16506_16507 : H12AffineEnvironment.transform 17 10400 env16506 = env16507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env16506 == env16507) = true)

theorem identity16507 : scanCanonicalize (H12AffineFastState.compose env16507 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 57797) := by decide +kernel

theorem selectedBound16507 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env16508 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57797,10400,1024,32769,2097152,4194304,41292,41310,8328,64,4262263,2172370,2159645,43048,99331,6407326,256,2213054,2172187,41941]

theorem envBound16508 : H12AffineFastState.Bounded env16508 := by
  intro p hp
  have h : env16508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16507_16508 : H12AffineEnvironment.transform 16 57797 env16507 = env16508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57797 env16507 == env16508) = true)

theorem identity16508 : scanCanonicalize (H12AffineFastState.compose env16508 (packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound16508 : packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env16509 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,57797,10400,1024,32769,2097152,4194304,41292,41310,8328,64,4204925,2098648,2159645,43048,41993,6349972,256,2155700,2098449,41941]

theorem envBound16509 : H12AffineFastState.Bounded env16509 := by
  intro p hp
  have h : env16509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16508_16509 : H12AffineEnvironment.transform 15 8202 env16508 = env16509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env16508 == env16509) = true)

theorem identity16509 : scanCanonicalize (H12AffineFastState.compose env16509 (packedSelected [0,1,3,5,8,9,10,11,17,18,19,22,23,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound16509 : packedSelected [0,1,3,5,8,9,10,11,17,18,19,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env16510 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8202,16401,10400,1024,8661,2097152,4194304,152,138,8328,64,4204925,2098648,2119113,2556,1501,6309184,256,2114912,2098449,513]

theorem envBound16510 : H12AffineFastState.Bounded env16510 := by
  intro p hp
  have h : env16510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16509_16510 : H12AffineEnvironment.transform 14 8660 env16509 = env16510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env16509 == env16510) = true)

theorem identity16510 : scanCanonicalize (H12AffineFastState.compose env16510 (packedSelected [0,3,5,10,14,17,27] rootPS)) = affineNative (2^(21+1) ^^^ 20528) := by decide +kernel

theorem selectedBound16510 : packedSelected [0,3,5,10,14,17,27] rootPS < 2^1333 := by decide +kernel

def env16511 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8202,16401,10400,1024,8661,2097152,20528,152,138,8328,64,31053,2098648,2119113,2556,1501,2102640,256,2114912,2098449,513]

theorem envBound16511 : H12AffineFastState.Bounded env16511 := by
  intro p hp
  have h : env16511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16510_16511 : H12AffineEnvironment.transform 21 20528 env16510 = env16511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 20528 env16510 == env16511) = true)

theorem identity16511 : scanCanonicalize (H12AffineFastState.compose env16511 (packedSelected [0,1,3,4,7,9,11,12,14,15,18,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound16511 : packedSelected [0,1,3,4,7,9,11,12,14,15,18,24,28] rootPS < 2^1333 := by decide +kernel

def env16512 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5156,8660,8202,5173,10400,1024,8661,2097152,1044,152,138,8328,64,11625,2098648,2097645,2556,1501,2102640,256,2101572,2098449,513]

theorem envBound16512 : H12AffineFastState.Bounded env16512 := by
  intro p hp
  have h : env16512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16511_16512 : H12AffineEnvironment.transform 13 5156 env16511 = env16512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env16511 == env16512) = true)

theorem identity16512 : scanCanonicalize (H12AffineFastState.compose env16512 (packedSelected [0,4,7,9,11,14,17,18] rootPS)) = affineNative (2^(20+1) ^^^ 13689) := by decide +kernel

theorem selectedBound16512 : packedSelected [0,4,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env16513 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5156,8660,8202,5173,10400,1024,8661,13689,1044,152,138,8328,64,11625,12449,13460,2556,1501,8201,256,9277,12392,513]

theorem envBound16513 : H12AffineFastState.Bounded env16513 := by
  intro p hp
  have h : env16513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16512_16513 : H12AffineEnvironment.transform 20 13689 env16512 = env16513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 13689 env16512 == env16513) = true)

theorem identity16513 : scanCanonicalize (H12AffineFastState.compose env16513 (packedSelected [11,12,23,38] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound16513 : packedSelected [11,12,23,38] rootPS < 2^1333 := by decide +kernel

def env16514 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,5156,8432,8202,5173,10400,1024,8433,13405,1044,152,138,8328,64,11341,12449,13460,2264,1273,8201,36,9277,12392,513]

theorem envBound16514 : H12AffineFastState.Bounded env16514 := by
  intro p hp
  have h : env16514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16513_16514 : H12AffineEnvironment.transform 7 36 env16513 = env16514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env16513 == env16514) = true)

theorem identity16514 : scanCanonicalize (H12AffineFastState.compose env16514 (packedSelected [11,17,23] rootPS)) = affineNative (2^(12+1) ^^^ 1220) := by decide +kernel

theorem selectedBound16514 : packedSelected [11,17,23] rootPS < 2^1333 := by decide +kernel

def env16515 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,1220,5156,1076,1230,5173,3172,1024,1077,4249,1044,152,138,1100,64,2185,5221,4176,2264,1273,1229,36,249,5292,513]

theorem envBound16515 : H12AffineFastState.Bounded env16515 := by
  intro p hp
  have h : env16515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16514_16515 : H12AffineEnvironment.transform 12 1220 env16514 = env16515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1220 env16514 == env16515) = true)

theorem identity16515 : scanCanonicalize (H12AffineFastState.compose env16515 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3244) := by decide +kernel

theorem selectedBound16515 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env16516 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,3244,1220,2184,1076,1230,2201,3172,1024,1077,3125,1044,152,138,1100,64,2185,2249,3324,2264,1273,1229,36,249,2048,513]

theorem envBound16516 : H12AffineFastState.Bounded env16516 := by
  intro p hp
  have h : env16516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16515_16516 : H12AffineEnvironment.transform 11 3244 env16515 = env16516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3244 env16515 == env16516) = true)

theorem identity16516 : scanCanonicalize (H12AffineFastState.compose env16516 (packedSelected [1,2,4,6,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound16516 : packedSelected [1,2,4,6,8,9,10] rootPS < 2^1333 := by decide +kernel

def env16517 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,3109,1101,2049,1076,1095,2064,3172,1024,1077,3125,1044,17,3,1100,64,2048,2112,3189,2129,1136,1092,36,112,2048,513]

theorem envBound16517 : H12AffineFastState.Bounded env16517 := by
  intro p hp
  have h : env16517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16516_16517 : H12AffineEnvironment.transform 6 9 env16516 = env16517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16516 == env16517) = true)

theorem identity16517 : scanCanonicalize (H12AffineFastState.compose env16517 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound16517 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env16518 : List Nat := [2,4,8,16,32,64,9,36,512,52,2048,2065,121,2049,0,115,2064,2128,52,1,2049,32,17,3,120,64,2048,2112,2113,2129,68,112,36,112,2048,513]

theorem envBound16518 : H12AffineFastState.Bounded env16518 := by
  intro p hp
  have h : env16518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16517_16518 : H12AffineEnvironment.transform 9 52 env16517 = env16518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env16517 == env16518) = true)

theorem identity16518 : scanCanonicalize (H12AffineFastState.compose env16518 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound16518 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16519 : List Nat := [2,4,8,16,32,64,9,36,512,52,32,49,121,33,0,115,48,112,52,1,33,32,17,3,120,64,32,96,97,113,68,112,36,112,32,513]

theorem envBound16519 : H12AffineFastState.Bounded env16519 := by
  intro p hp
  have h : env16519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16518_16519 : H12AffineEnvironment.transform 10 32 env16518 = env16519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env16518 == env16519) = true)

theorem identity16519 : scanCanonicalize (H12AffineFastState.compose env16519 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound16519 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16520 : List Nat := [2,4,8,16,32,49,9,36,512,52,32,49,8,33,0,2,48,1,52,1,33,32,17,3,9,49,32,17,16,0,53,1,36,1,32,513]

theorem envBound16520 : H12AffineFastState.Bounded env16520 := by
  intro p hp
  have h : env16520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16519_16520 : H12AffineEnvironment.transform 5 49 env16519 = env16520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env16519 == env16520) = true)

theorem identity16520 : scanCanonicalize (H12AffineFastState.compose env16520 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound16520 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16521 : List Nat := [2,4,8,16,32,49,9,36,32,52,32,49,8,33,0,2,48,1,52,1,33,32,17,3,9,49,32,17,16,0,53,1,36,1,32,33]

theorem envBound16521 : H12AffineFastState.Bounded env16521 := by
  intro p hp
  have h : env16521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16520_16521 : H12AffineEnvironment.transform 8 32 env16520 = env16521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env16520 == env16521) = true)

theorem identity16521 : scanCanonicalize (H12AffineFastState.compose env16521 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16521 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16522 : List Nat := [2,4,8,16,1,16,9,5,1,21,1,16,8,0,0,2,17,1,21,1,0,1,17,3,9,16,1,17,16,0,20,1,5,1,1,0]

theorem envBound16522 : H12AffineFastState.Bounded env16522 := by
  intro p hp
  have h : env16522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16521_16522 : H12AffineEnvironment.transform 4 1 env16521 = env16522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16521 == env16522) = true)

def env16523 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1024,32769,2097152,4194304,147593,147611,8328,64,4450483,2343959,2233816,43049,99331,6497627,256,2213054,2172187,41941]

theorem envBound16523 : H12AffineFastState.Bounded env16523 := by
  intro p hp
  have h : env16523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16506_16523 : H12AffineEnvironment.transform 17 10401 env16506 = env16523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env16506 == env16523) = true)

theorem identity16523 : scanCanonicalize (H12AffineFastState.compose env16523 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound16523 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env16524 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10401,1024,8541,2097152,4194304,147593,147611,8328,64,4409839,2319691,2233816,2421,75103,6497627,256,2188770,2172187,649]

theorem envBound16524 : H12AffineFastState.Bounded env16524 := by
  intro p hp
  have h : env16524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16523_16524 : H12AffineEnvironment.transform 14 8540 env16523 = env16524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env16523 == env16524) = true)

theorem identity16524 : scanCanonicalize (H12AffineFastState.compose env16524 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16524 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env16525 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1024,8541,2097152,4194304,147457,147475,8192,64,4409703,2319691,2233680,2421,75103,6497627,256,2188650,2172187,513]

theorem envBound16525 : H12AffineFastState.Bounded env16525 := by
  intro p hp
  have h : env16525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16524_16525 : H12AffineEnvironment.transform 6 8 env16524 = env16525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16524 == env16525) = true)

theorem identity16525 : scanCanonicalize (H12AffineFastState.compose env16525 (packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 25629) := by decide +kernel

theorem selectedBound16525 : packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS < 2^1333 := by decide +kernel

def env16526 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1024,8541,25629,4194304,147457,147475,8192,64,4409703,196950,160077,2421,75103,4407622,256,65911,82182,513]

theorem envBound16526 : H12AffineFastState.Bounded env16526 := by
  intro p hp
  have h : env16526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16525_16526 : H12AffineEnvironment.transform 20 25629 env16525 = env16526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25629 env16525 == env16526) = true)

theorem identity16526 : scanCanonicalize (H12AffineFastState.compose env16526 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound16526 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env16527 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10281,1024,8541,25629,4194304,16,2,8192,64,4262262,82247,12636,2421,75103,4260183,256,65911,82182,513]

theorem envBound16527 : H12AffineFastState.Bounded env16527 := by
  intro p hp
  have h : env16527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16526_16527 : H12AffineEnvironment.transform 16 16401 env16526 = env16527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env16526 == env16527) = true)

theorem identity16527 : scanCanonicalize (H12AffineFastState.compose env16527 (packedSelected [2,4,6,9,18] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound16527 : packedSelected [2,4,6,9,18] rootPS < 2^1333 := by decide +kernel

def env16528 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10281,1024,8541,25629,8572,16,2,8192,64,75786,82247,12636,2421,75103,73771,256,65911,82182,513]

theorem envBound16528 : H12AffineFastState.Bounded env16528 := by
  intro p hp
  have h : env16528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16527_16528 : H12AffineEnvironment.transform 21 8572 env16527 = env16528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env16527 == env16528) = true)

theorem identity16528 : scanCanonicalize (H12AffineFastState.compose env16528 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound16528 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env16529 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,342,16401,10281,1024,8541,25629,8572,16,2,8192,64,10588,16401,12636,2421,9225,8573,256,33,16464,513]

theorem envBound16529 : H12AffineFastState.Bounded env16529 := by
  intro p hp
  have h : env16529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16528_16529 : H12AffineEnvironment.transform 15 342 env16528 = env16529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env16528 == env16529) = true)

theorem identity16529 : scanCanonicalize (H12AffineFastState.compose env16529 (packedSelected [2,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 17) := by decide +kernel

theorem selectedBound16529 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env16530 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,17,8540,342,0,10281,1024,8541,9228,8572,16,2,8192,64,10588,0,12636,2421,9225,8573,256,33,65,513]

theorem envBound16530 : H12AffineFastState.Bounded env16530 := by
  intro p hp
  have h : env16530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16529_16530 : H12AffineEnvironment.transform 13 17 env16529 = env16530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env16529 == env16530) = true)

theorem identity16530 : scanCanonicalize (H12AffineFastState.compose env16530 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound16530 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env16531 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,17,1,342,0,2420,1024,0,1361,33,16,2,349,64,2049,0,4097,2421,1364,32,256,33,65,513]

theorem envBound16531 : H12AffineFastState.Bounded env16531 := by
  intro p hp
  have h : env16531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16530_16531 : H12AffineEnvironment.transform 12 349 env16530 = env16531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env16530 == env16531) = true)

theorem identity16531 : scanCanonicalize (H12AffineFastState.compose env16531 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2350) := by decide +kernel

theorem selectedBound16531 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16532 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2350,349,17,1,342,0,2420,1024,0,1361,33,16,2,349,64,2049,0,2351,2421,1364,32,256,33,65,513]

theorem envBound16532 : H12AffineFastState.Bounded env16532 := by
  intro p hp
  have h : env16532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16531_16532 : H12AffineEnvironment.transform 11 2350 env16531 = env16532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2350 env16531 == env16532) = true)

theorem identity16532 : scanCanonicalize (H12AffineFastState.compose env16532 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16532 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16533 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2350,268,17,1,263,0,2341,1024,0,1280,33,16,2,268,17,2049,0,2351,2340,1285,32,256,33,16,513]

theorem envBound16533 : H12AffineFastState.Bounded env16533 := by
  intro p hp
  have h : env16533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16532_16533 : H12AffineEnvironment.transform 5 17 env16532 = env16533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16532 == env16533) = true)

theorem identity16533 : scanCanonicalize (H12AffineFastState.compose env16533 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound16533 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16534 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,2350,268,17,1,263,0,2341,53,0,309,33,16,2,268,17,2049,0,2351,2340,304,32,256,33,16,513]

theorem envBound16534 : H12AffineFastState.Bounded env16534 := by
  intro p hp
  have h : env16534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16533_16534 : H12AffineEnvironment.transform 9 53 env16533 = env16534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env16533 == env16534) = true)

theorem identity16534 : scanCanonicalize (H12AffineFastState.compose env16534 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 524) := by decide +kernel

theorem selectedBound16534 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env16535 : List Nat := [2,4,8,16,32,17,8,256,512,53,524,802,268,17,1,263,0,809,53,0,309,33,16,2,268,17,525,0,803,808,304,32,256,33,16,513]

theorem envBound16535 : H12AffineFastState.Bounded env16535 := by
  intro p hp
  have h : env16535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16534_16535 : H12AffineEnvironment.transform 10 524 env16534 = env16535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 524 env16534 == env16535) = true)

theorem identity16535 : scanCanonicalize (H12AffineFastState.compose env16535 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound16535 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16536 : List Nat := [2,4,8,16,32,17,8,14,512,53,524,556,2,17,1,9,0,551,53,0,59,33,16,2,2,17,525,0,557,550,62,32,14,33,16,513]

theorem envBound16536 : H12AffineFastState.Bounded env16536 := by
  intro p hp
  have h : env16536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16535_16536 : H12AffineEnvironment.transform 7 14 env16535 = env16536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env16535 == env16536) = true)

theorem identity16536 : scanCanonicalize (H12AffineFastState.compose env16536 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound16536 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env16537 : List Nat := [2,4,8,16,17,17,8,14,512,4,524,541,2,17,1,9,0,534,4,0,10,16,16,2,2,17,525,0,540,535,15,17,14,16,16,513]

theorem envBound16537 : H12AffineFastState.Bounded env16537 := by
  intro p hp
  have h : env16537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16536_16537 : H12AffineEnvironment.transform 4 17 env16536 = env16537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env16536 == env16537) = true)

def env16538 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830976,25265169,23160256,257,27378861,27337993,25207750]

theorem envBound16538 : H12AffineFastState.Bounded env16538 := by
  intro p hp
  have h : env16538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16460_16538 : H12AffineEnvironment.transform 18 1025 env16460 = env16538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env16460 == env16538) = true)

theorem identity16538 : scanCanonicalize (H12AffineFastState.compose env16538 (packedSelected [13] rootPS)) = affineNative (2^(16+1) ^^^ 123026) := by decide +kernel

theorem selectedBound16538 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env16539 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29630611,18973837,10507601,8724626,25265169,23160256,257,27378861,27337993,25207750]

theorem envBound16539 : H12AffineFastState.Bounded env16539 := by
  intro p hp
  have h : env16539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16538_16539 : H12AffineEnvironment.transform 16 123026 env16538 = env16539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 123026 env16538 == env16539) = true)

def env16540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,2097152,4194304,8388608,10588556,8328,64,6664479,8393985,10507601,8724626,2102685,12645452,257,21793,46213,2175562]

theorem envBound16540 : H12AffineFastState.Bounded env16540 := by
  intro p hp
  have h : env16540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16539_16540 : H12AffineEnvironment.transform 23 10588556 env16539 = env16540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588556 env16539 == env16540) = true)

def env16541 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6664479,2098513,17665,2437314,2102685,6349852,257,21793,46213,2175562]

theorem envBound16541 : H12AffineFastState.Bounded env16541 := by
  intro p hp
  have h : env16541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16540_16541 : H12AffineEnvironment.transform 22 2101328 env16540 = env16541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env16540 == env16541) = true)

def env16542 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2202015,2098513,17665,2437314,2102685,2411676,257,21793,46213,2175562]

theorem envBound16542 : H12AffineFastState.Bounded env16542 := by
  intro p hp
  have h : env16542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16541_16542 : H12AffineEnvironment.transform 21 272512 env16541 = env16542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env16541 == env16542) = true)

theorem identity16542 : scanCanonicalize (H12AffineFastState.compose env16542 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58516) := by decide +kernel

theorem selectedBound16542 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16543 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,58516,272512,62660,98780,8328,64,97547,57797,17665,382038,61705,272392,257,21793,46213,120542]

theorem envBound16543 : H12AffineFastState.Bounded env16543 := by
  intro p hp
  have h : env16543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16542_16543 : H12AffineEnvironment.transform 20 58516 env16542 = env16543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58516 env16542 == env16543) = true)

def env16544 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,10280,1025,32769,58516,168,62660,98780,8328,64,97547,57797,17665,130174,61705,32,257,21793,46213,120542]

theorem envBound16544 : H12AffineFastState.Bounded env16544 := by
  intro p hp
  have h : env16544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16543_16544 : H12AffineEnvironment.transform 17 10280 env16543 = env16544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env16543 == env16544) = true)

theorem identity16544 : scanCanonicalize (H12AffineFastState.compose env16544 (packedSelected [1,5,8,11,12,15,17,18,19,23,24,26,32,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 62851) := by decide +kernel

theorem selectedBound16544 : packedSelected [1,5,8,11,12,15,17,18,19,23,24,26,32,38,41] rootPS < 2^1333 := by decide +kernel

def env16545 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62851,5393,10280,1025,32769,58516,168,62660,29791,8328,64,34952,57797,17665,2557,61705,32,257,21793,46213,9053]

theorem envBound16545 : H12AffineFastState.Bounded env16545 := by
  intro p hp
  have h : env16545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16544_16545 : H12AffineEnvironment.transform 15 62851 env16544 = env16545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62851 env16544 == env16545) = true)

theorem identity16545 : scanCanonicalize (H12AffineFastState.compose env16545 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound16545 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env16546 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,21590,5393,10280,1025,8660,17729,168,21777,29791,8328,64,10589,16400,17665,2557,20700,32,257,21793,5456,9053]

theorem envBound16546 : H12AffineFastState.Bounded env16546 := by
  intro p hp
  have h : env16546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16545_16546 : H12AffineEnvironment.transform 14 8661 env16545 = env16546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env16545 == env16546) = true)

theorem identity16546 : scanCanonicalize (H12AffineFastState.compose env16546 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound16546 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env16547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,137,21590,5393,2420,1025,136,17729,168,21777,21763,468,64,2049,16400,17665,2557,20700,32,257,21793,5456,513]

theorem envBound16547 : H12AffineFastState.Bounded env16547 := by
  intro p hp
  have h : env16547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16546_16547 : H12AffineEnvironment.transform 12 348 env16546 = env16547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env16546 == env16547) = true)

theorem identity16547 : scanCanonicalize (H12AffineFastState.compose env16547 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound16547 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env16548 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,348,16384,137,20807,4096,2420,272,136,16464,168,20480,20498,468,64,2049,16400,16400,2557,20700,32,257,20528,4161,513]

theorem envBound16548 : H12AffineFastState.Bounded env16548 := by
  intro p hp
  have h : env16548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16547_16548 : H12AffineEnvironment.transform 9 273 env16547 = env16548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env16547 == env16548) = true)

theorem identity16548 : scanCanonicalize (H12AffineFastState.compose env16548 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound16548 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env16549 : List Nat := [2,4,8,16,32,64,88,256,512,273,2048,4096,348,16384,81,20807,4096,2420,272,80,16464,112,20480,20498,268,64,2049,16400,16400,2341,20484,32,257,20528,4161,513]

theorem envBound16549 : H12AffineFastState.Bounded env16549 := by
  intro p hp
  have h : env16549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16548_16549 : H12AffineEnvironment.transform 6 88 env16548 = env16549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env16548 == env16549) = true)

theorem identity16549 : scanCanonicalize (H12AffineFastState.compose env16549 (packedSelected [1,2,3,4,6,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2625) := by decide +kernel

theorem selectedBound16549 : packedSelected [1,2,3,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env16550 : List Nat := [2,4,8,16,32,64,88,256,512,273,2048,2625,348,16384,81,19206,2625,2420,272,80,16464,112,19009,19027,268,64,2049,16400,16400,2341,19013,32,257,19057,2560,513]

theorem envBound16550 : H12AffineFastState.Bounded env16550 := by
  intro p hp
  have h : env16550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16549_16550 : H12AffineEnvironment.transform 11 2625 env16549 = env16550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2625 env16549 == env16550) = true)

theorem identity16550 : scanCanonicalize (H12AffineFastState.compose env16550 (packedSelected [0,1,3,5,7,8,15] rootPS)) = affineNative (2^(13+1) ^^^ 529) := by decide +kernel

theorem selectedBound16550 : packedSelected [0,1,3,5,7,8,15] rootPS < 2^1333 := by decide +kernel

def env16551 : List Nat := [2,4,8,16,32,64,88,256,512,273,2048,2625,348,529,81,2327,2625,2420,272,80,577,112,2128,2114,268,64,2049,513,513,2341,2132,32,257,2144,2560,513]

theorem envBound16551 : H12AffineFastState.Bounded env16551 := by
  intro p hp
  have h : env16551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16550_16551 : H12AffineEnvironment.transform 13 529 env16550 = env16551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 529 env16550 == env16551) = true)

theorem identity16551 : scanCanonicalize (H12AffineFastState.compose env16551 (packedSelected [2,3,4,6,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound16551 : packedSelected [2,3,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env16552 : List Nat := [2,4,8,16,32,64,88,256,512,273,512,65,348,529,81,791,65,884,272,80,577,112,592,578,268,64,513,513,513,805,596,32,257,608,0,513]

theorem envBound16552 : H12AffineFastState.Bounded env16552 := by
  intro p hp
  have h : env16552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16551_16552 : H12AffineEnvironment.transform 10 512 env16551 = env16552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env16551 == env16552) = true)

theorem identity16552 : scanCanonicalize (H12AffineFastState.compose env16552 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound16552 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16553 : List Nat := [2,4,8,16,32,64,88,256,0,273,0,65,348,17,81,279,65,372,272,80,65,112,80,66,268,64,1,1,1,293,84,32,257,96,0,1]

theorem envBound16553 : H12AffineFastState.Bounded env16553 := by
  intro p hp
  have h : env16553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16552_16553 : H12AffineEnvironment.transform 8 0 env16552 = env16553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env16552 == env16553) = true)

theorem identity16553 : scanCanonicalize (H12AffineFastState.compose env16553 (packedSelected [0,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound16553 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env16554 : List Nat := [2,4,8,16,32,64,88,36,0,53,0,65,120,17,81,51,65,80,52,80,65,112,80,66,40,64,1,1,1,1,84,32,37,96,0,1]

theorem envBound16554 : H12AffineFastState.Bounded env16554 := by
  intro p hp
  have h : env16554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16553_16554 : H12AffineEnvironment.transform 7 36 env16553 = env16554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env16553 == env16554) = true)

theorem identity16554 : scanCanonicalize (H12AffineFastState.compose env16554 (packedSelected [2,4] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound16554 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env16555 : List Nat := [2,4,8,16,32,1,25,36,0,53,0,0,57,17,16,51,0,17,52,17,0,49,17,3,40,1,1,1,1,1,21,32,37,33,0,1]

theorem envBound16555 : H12AffineFastState.Bounded env16555 := by
  intro p hp
  have h : env16555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16554_16555 : H12AffineEnvironment.transform 5 1 env16554 = env16555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env16554 == env16555) = true)

theorem identity16555 : scanCanonicalize (H12AffineFastState.compose env16555 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound16555 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16556 : List Nat := [2,4,8,16,16,1,25,20,0,5,0,0,9,17,16,3,0,17,4,17,0,1,17,3,24,1,1,1,1,1,21,16,21,17,0,1]

theorem envBound16556 : H12AffineFastState.Bounded env16556 := by
  intro p hp
  have h : env16556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16555_16556 : H12AffineEnvironment.transform 4 16 env16555 = env16556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env16555 == env16556) = true)

theorem identity16556 : scanCanonicalize (H12AffineFastState.compose env16556 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound16556 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16557 : List Nat := [2,4,8,1,1,1,8,5,0,5,0,0,9,0,1,3,0,0,4,0,0,1,0,3,9,1,1,1,1,1,4,1,4,0,0,1]

theorem envBound16557 : H12AffineFastState.Bounded env16557 := by
  intro p hp
  have h : env16557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16556_16557 : H12AffineEnvironment.transform 3 1 env16556 = env16557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env16556 == env16557) = true)

def env16558 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,10281,1025,32769,58516,169,62660,98780,8328,64,97547,57797,17665,130175,61705,33,257,21793,46213,120542]

theorem envBound16558 : H12AffineFastState.Bounded env16558 := by
  intro p hp
  have h : env16558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16543_16558 : H12AffineEnvironment.transform 17 10281 env16543 = env16558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env16543 == env16558) = true)

theorem identity16558 : scanCanonicalize (H12AffineFastState.compose env16558 (packedSelected [1,5,8,11,12,15,17,18,19,23,24,26,32,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound16558 : packedSelected [1,5,8,11,12,15,17,18,19,23,24,26,32,38,41] rootPS < 2^1333 := by decide +kernel

def env16559 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54358,13508,10281,1025,32769,58516,169,62660,21898,8328,64,43357,57797,17665,10281,61705,33,257,21793,46213,648]

theorem envBound16559 : H12AffineFastState.Bounded env16559 := by
  intro p hp
  have h : env16559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16558_16559 : H12AffineEnvironment.transform 15 54358 env16558 = env16559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env16558 == env16559) = true)

theorem identity16559 : scanCanonicalize (H12AffineFastState.compose env16559 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound16559 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env16560 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,13389,10281,1025,32769,58397,32,62541,21763,8193,64,43357,57676,17665,10281,61705,33,257,21793,46092,513]

theorem envBound16560 : H12AffineFastState.Bounded env16560 := by
  intro p hp
  have h : env16560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16559_16560 : H12AffineEnvironment.transform 6 9 env16559 = env16560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16559 == env16560) = true)

theorem identity16560 : scanCanonicalize (H12AffineFastState.compose env16560 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound16560 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env16561 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8460,30042,13389,10281,1025,8461,17681,32,21825,21763,8193,64,2129,16448,17665,10281,20485,33,257,21793,5376,513]

theorem envBound16561 : H12AffineFastState.Bounded env16561 := by
  intro p hp
  have h : env16561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16560_16561 : H12AffineEnvironment.transform 14 8460 env16560 = env16561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env16560 == env16561) = true)

theorem identity16561 : scanCanonicalize (H12AffineFastState.compose env16561 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound16561 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env16562 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8460,342,13389,10281,1025,8461,12573,32,8525,8463,8193,64,2129,13388,12557,10281,9225,33,257,8493,5376,513]

theorem envBound16562 : H12AffineFastState.Bounded env16562 := by
  intro p hp
  have h : env16562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16561_16562 : H12AffineEnvironment.transform 13 13324 env16561 = env16562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env16561 == env16562) = true)

theorem identity16562 : scanCanonicalize (H12AffineFastState.compose env16562 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound16562 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env16563 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,8460,262,13341,10281,1025,8461,12573,32,8477,8463,8193,16,2049,13340,12557,10281,9225,33,257,8493,5376,513]

theorem envBound16563 : H12AffineFastState.Bounded env16563 := by
  intro p hp
  have h : env16563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16562_16563 : H12AffineEnvironment.transform 5 16 env16562 = env16563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16562 == env16563) = true)

theorem identity16563 : scanCanonicalize (H12AffineFastState.compose env16563 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound16563 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16564 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,0,262,5393,2341,1025,1,4113,32,17,3,269,16,2049,5392,4097,2341,1285,33,257,33,5376,513]

theorem envBound16564 : H12AffineFastState.Bounded env16564 := by
  intro p hp
  have h : env16564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16563_16564 : H12AffineEnvironment.transform 12 268 env16563 = env16564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env16563 == env16564) = true)

theorem identity16564 : scanCanonicalize (H12AffineFastState.compose env16564 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound16564 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16565 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,32,268,1312,0,262,1329,2341,1025,1,49,32,17,3,269,16,2049,1328,33,2341,1285,33,257,33,1312,513]

theorem envBound16565 : H12AffineFastState.Bounded env16565 := by
  intro p hp
  have h : env16565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16564_16565 : H12AffineEnvironment.transform 11 32 env16564 = env16565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env16564 == env16565) = true)

theorem identity16565 : scanCanonicalize (H12AffineFastState.compose env16565 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound16565 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16566 : List Nat := [2,4,8,16,32,16,9,256,48,1024,2048,32,268,1312,0,262,1329,2341,1025,1,49,32,17,3,269,16,2049,1328,33,2341,1285,33,257,33,1312,49]

theorem envBound16566 : H12AffineFastState.Bounded env16566 := by
  intro p hp
  have h : env16566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16565_16566 : H12AffineEnvironment.transform 8 48 env16565 = env16566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env16565 == env16566) = true)

theorem identity16566 : scanCanonicalize (H12AffineFastState.compose env16566 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 288) := by decide +kernel

theorem selectedBound16566 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16567 : List Nat := [2,4,8,16,32,16,9,256,48,288,2048,32,268,0,0,262,17,2341,289,1,49,32,17,3,269,16,2049,16,33,2341,37,33,257,33,0,49]

theorem envBound16567 : H12AffineFastState.Bounded env16567 := by
  intro p hp
  have h : env16567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16566_16567 : H12AffineEnvironment.transform 9 288 env16566 = env16567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 288 env16566 == env16567) = true)

theorem identity16567 : scanCanonicalize (H12AffineFastState.compose env16567 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound16567 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env16568 : List Nat := [2,4,8,0,32,0,9,256,32,288,2048,32,268,0,0,262,1,2341,289,1,33,32,1,3,269,0,2049,0,33,2341,37,33,257,33,0,33]

theorem envBound16568 : H12AffineFastState.Bounded env16568 := by
  intro p hp
  have h : env16568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16567_16568 : H12AffineEnvironment.transform 3 0 env16567 = env16568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env16567 == env16568) = true)

theorem identity16568 : scanCanonicalize (H12AffineFastState.compose env16568 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound16568 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env16569 : List Nat := [2,4,8,0,32,0,9,256,32,288,1,32,268,0,0,262,1,292,289,1,33,32,1,3,269,0,0,0,33,292,37,33,257,33,0,33]

theorem envBound16569 : H12AffineFastState.Bounded env16569 := by
  intro p hp
  have h : env16569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16568_16569 : H12AffineEnvironment.transform 10 1 env16568 = env16569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env16568 == env16569) = true)

theorem identity16569 : scanCanonicalize (H12AffineFastState.compose env16569 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound16569 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16570 : List Nat := [2,4,8,0,32,0,9,37,32,5,1,32,41,0,0,35,1,1,4,1,33,32,1,3,40,0,0,0,33,1,37,33,36,33,0,33]

theorem envBound16570 : H12AffineFastState.Bounded env16570 := by
  intro p hp
  have h : env16570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16569_16570 : H12AffineEnvironment.transform 7 37 env16569 = env16570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env16569 == env16570) = true)

theorem identity16570 : scanCanonicalize (H12AffineFastState.compose env16570 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16570 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env16571 : List Nat := [2,4,8,0,0,0,9,5,0,5,1,0,9,0,0,3,1,1,4,1,1,0,1,3,8,0,0,0,1,1,5,1,4,1,0,1]

theorem envBound16571 : H12AffineFastState.Bounded env16571 := by
  intro p hp
  have h : env16571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16570_16571 : H12AffineEnvironment.transform 4 0 env16570 = env16571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16570 == env16571) = true)

theorem identity16571 : scanCanonicalize (H12AffineFastState.compose env16571 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound16571 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16572 : List Nat := [2,4,2,0,0,0,3,5,0,5,1,0,3,0,0,3,1,1,4,1,1,0,1,3,2,0,0,0,1,1,5,1,4,1,0,1]

theorem envBound16572 : H12AffineFastState.Bounded env16572 := by
  intro p hp
  have h : env16572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16571_16572 : H12AffineEnvironment.transform 2 2 env16571 = env16572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env16571 == env16572) = true)

def env16573 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2202014,2098513,17665,2437314,2102685,2411677,257,21793,46213,2175562]

theorem envBound16573 : H12AffineFastState.Bounded env16573 := by
  intro p hp
  have h : env16573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16541_16573 : H12AffineEnvironment.transform 21 272513 env16541 = env16573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env16541 == env16573) = true)

theorem identity16573 : scanCanonicalize (H12AffineFastState.compose env16573 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound16573 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16574 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,70727,262144,1025,29908,2097152,272513,2101328,95497,8328,64,2190667,2098513,17665,2437314,2102685,2373704,257,21793,16464,2175562]

theorem envBound16574 : H12AffineFastState.Bounded env16574 := by
  intro p hp
  have h : env16574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16573_16574 : H12AffineEnvironment.transform 14 29909 env16573 = env16574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env16573 == env16574) = true)

def env16575 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,70679,262144,1025,29828,2097152,272513,2101248,95497,8328,16,2190619,2098433,17665,2437266,2102685,2373656,257,21793,16384,2175514]

theorem envBound16575 : H12AffineFastState.Bounded env16575 := by
  intro p hp
  have h : env16575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16574_16575 : H12AffineEnvironment.transform 5 16 env16574 = env16575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16574 == env16575) = true)

theorem identity16575 : scanCanonicalize (H12AffineFastState.compose env16575 (packedSelected [3,14,15,16,19,20,24,31,35,38] rootPS)) = affineNative (2^(20+1) ^^^ 268596) := by decide +kernel

theorem selectedBound16575 : packedSelected [3,14,15,16,19,20,24,31,35,38] rootPS < 2^1333 := by decide +kernel

def env16576 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,70679,262144,1025,29828,268596,272513,264500,95497,8328,16,357423,269365,17665,76198,265385,8492,257,21793,16384,338734]

theorem envBound16576 : H12AffineFastState.Bounded env16576 := by
  intro p hp
  have h : env16576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16575_16576 : H12AffineEnvironment.transform 20 268596 env16575 = env16576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 268596 env16575 == env16576) = true)

theorem identity16576 : scanCanonicalize (H12AffineFastState.compose env16576 (packedSelected [0,1,9,10,11,16,20,22,26,27,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 21647) := by decide +kernel

theorem selectedBound16576 : packedSelected [0,1,9,10,11,16,20,22,26,27,28,32] rootPS < 2^1333 := by decide +kernel

def env16577 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,21647,16536,262144,1025,29828,268596,272513,264500,8582,8328,16,270496,269365,17665,32041,265385,8492,257,21793,16384,294817]

theorem envBound16577 : H12AffineFastState.Bounded env16577 := by
  intro p hp
  have h : env16577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16576_16577 : H12AffineEnvironment.transform 15 21647 env16576 = env16577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21647 env16576 == env16577) = true)

theorem identity16577 : scanCanonicalize (H12AffineFastState.compose env16577 (packedSelected [0,3,4,7,10,16,18,19,20,22,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound16577 : packedSelected [0,3,4,7,10,16,18,19,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env16578 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,21647,16536,2340,1025,29828,4112,8613,16,8582,8328,16,10628,5393,17665,32041,1421,8492,257,21793,16384,30341]

theorem envBound16578 : H12AffineFastState.Bounded env16578 := by
  intro p hp
  have h : env16578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16577_16578 : H12AffineEnvironment.transform 17 2340 env16577 = env16578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env16577 == env16578) = true)

theorem identity16578 : scanCanonicalize (H12AffineFastState.compose env16578 (packedSelected [3,4,5,6,9,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 5260) := by decide +kernel

theorem selectedBound16578 : packedSelected [3,4,5,6,9,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env16579 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5260,8201,3,5140,2340,1025,8200,4112,8613,16,8582,8328,16,10628,5393,4493,10661,1421,8492,257,429,5260,8713]

theorem envBound16579 : H12AffineFastState.Bounded env16579 := by
  intro p hp
  have h : env16579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16578_16579 : H12AffineEnvironment.transform 13 5260 env16578 = env16579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5260 env16578 == env16579) = true)

theorem identity16579 : scanCanonicalize (H12AffineFastState.compose env16579 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound16579 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env16580 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8,5260,1,3,5140,2340,1025,0,4112,429,16,398,128,16,2444,5393,4493,2477,1421,292,257,429,5260,513]

theorem envBound16580 : H12AffineFastState.Bounded env16580 := by
  intro p hp
  have h : env16580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16579_16580 : H12AffineEnvironment.transform 12 8 env16579 = env16580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env16579 == env16580) = true)

theorem identity16580 : scanCanonicalize (H12AffineFastState.compose env16580 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16580 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16581 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8,5124,1,3,5140,2340,1025,0,4112,293,16,262,8,16,2308,5393,4357,2341,1285,292,257,293,5124,513]

theorem envBound16581 : H12AffineFastState.Bounded env16581 := by
  intro p hp
  have h : env16581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16580_16581 : H12AffineEnvironment.transform 6 8 env16580 = env16581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16580 == env16581) = true)

theorem identity16581 : scanCanonicalize (H12AffineFastState.compose env16581 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound16581 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env16582 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1541,4096,8,5124,1,3,5140,1825,1025,0,4112,293,16,262,8,16,1793,5393,4357,1824,1285,292,257,293,5124,513]

theorem envBound16582 : H12AffineFastState.Bounded env16582 := by
  intro p hp
  have h : env16582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16581_16582 : H12AffineEnvironment.transform 10 1541 env16581 = env16582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env16581 == env16582) = true)

theorem identity16582 : scanCanonicalize (H12AffineFastState.compose env16582 (packedSelected [1,2,8] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound16582 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env16583 : List Nat := [2,4,8,16,32,16,8,256,512,21,528,4096,8,4113,1,3,4097,820,20,0,4112,293,16,262,8,16,788,4356,4357,821,272,292,257,293,4113,513]

theorem envBound16583 : H12AffineFastState.Bounded env16583 := by
  intro p hp
  have h : env16583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16582_16583 : H12AffineEnvironment.transform 9 21 env16582 = env16583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env16582 == env16583) = true)

theorem identity16583 : scanCanonicalize (H12AffineFastState.compose env16583 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound16583 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16584 : List Nat := [2,4,8,16,32,16,8,52,512,21,528,4096,8,4113,1,3,4097,512,20,0,4112,17,16,50,8,16,544,4144,4145,513,36,16,53,17,4113,513]

theorem envBound16584 : H12AffineFastState.Bounded env16584 := by
  intro p hp
  have h : env16584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16583_16584 : H12AffineEnvironment.transform 7 52 env16583 = env16584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env16583 == env16584) = true)

theorem identity16584 : scanCanonicalize (H12AffineFastState.compose env16584 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 561) := by decide +kernel

theorem selectedBound16584 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16585 : List Nat := [2,4,8,16,32,16,8,52,512,21,528,561,8,544,1,3,560,512,20,0,545,17,16,50,8,16,544,513,512,513,36,16,53,17,544,513]

theorem envBound16585 : H12AffineFastState.Bounded env16585 := by
  intro p hp
  have h : env16585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16584_16585 : H12AffineEnvironment.transform 11 561 env16584 = env16585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 561 env16584 == env16585) = true)

theorem identity16585 : scanCanonicalize (H12AffineFastState.compose env16585 (packedSelected [3,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound16585 : packedSelected [3,7] rootPS < 2^1333 := by decide +kernel

def env16586 : List Nat := [2,4,8,16,17,16,8,5,512,21,528,512,8,529,1,3,513,512,20,0,528,17,16,3,8,16,529,513,512,513,21,16,4,17,529,513]

theorem envBound16586 : H12AffineFastState.Bounded env16586 := by
  intro p hp
  have h : env16586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16585_16586 : H12AffineEnvironment.transform 4 17 env16585 = env16586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env16585 == env16586) = true)

theorem identity16586 : scanCanonicalize (H12AffineFastState.compose env16586 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound16586 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16587 : List Nat := [2,4,8,1,0,1,8,5,512,4,513,512,8,512,1,3,513,512,5,0,513,0,1,3,8,1,512,513,512,513,4,1,4,0,512,513]

theorem envBound16587 : H12AffineFastState.Bounded env16587 := by
  intro p hp
  have h : env16587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16586_16587 : H12AffineEnvironment.transform 3 1 env16586 = env16587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env16586 == env16587) = true)

theorem identity16587 : scanCanonicalize (H12AffineFastState.compose env16587 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound16587 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env16588 : List Nat := [2,4,8,1,0,1,8,5,1,4,0,1,8,1,1,3,0,1,5,0,0,0,1,3,8,1,1,0,1,0,4,1,4,0,1,0]

theorem envBound16588 : H12AffineFastState.Bounded env16588 := by
  intro p hp
  have h : env16588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16587_16588 : H12AffineEnvironment.transform 8 1 env16587 = env16588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env16587 == env16588) = true)

def env16589 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,70678,262144,1025,29829,2097152,272513,2101249,95497,8328,17,2190618,2098432,17665,2437267,2102685,2373657,257,21793,16385,2175515]

theorem envBound16589 : H12AffineFastState.Bounded env16589 := by
  intro p hp
  have h : env16589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16574_16589 : H12AffineEnvironment.transform 5 17 env16574 = env16589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16574 == env16589) = true)

theorem identity16589 : scanCanonicalize (H12AffineFastState.compose env16589 (packedSelected [3,14,15,16,19,20,24,31,35,38] rootPS)) = affineNative (2^(20+1) ^^^ 69910) := by decide +kernel

theorem selectedBound16589 : packedSelected [3,14,15,16,19,20,24,31,35,38] rootPS < 2^1333 := by decide +kernel

def env16590 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,70678,262144,1025,29829,69910,272513,65815,95497,8328,17,31756,70678,17665,270725,66699,338191,257,21793,16385,8973]

theorem envBound16590 : H12AffineFastState.Bounded env16590 := by
  intro p hp
  have h : env16590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16589_16590 : H12AffineEnvironment.transform 20 69910 env16589 = env16590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 69910 env16589 == env16590) = true)

theorem identity16590 : scanCanonicalize (H12AffineFastState.compose env16590 (packedSelected [1,4,7,9,10,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 97327) := by decide +kernel

theorem selectedBound16590 : packedSelected [1,4,7,9,10,26,27,28] rootPS < 2^1333 := by decide +kernel

def env16591 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,70678,97327,1025,29829,69910,87214,65815,95497,8328,17,31756,70678,17665,89514,66699,21792,257,21793,16385,8973]

theorem envBound16591 : H12AffineFastState.Bounded env16591 := by
  intro p hp
  have h : env16591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16590_16591 : H12AffineEnvironment.transform 17 97327 env16590 = env16591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97327 env16590 == env16591) = true)

theorem identity16591 : scanCanonicalize (H12AffineFastState.compose env16591 (packedSelected [0,1,4,5,7,8,17,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 13444) := by decide +kernel

theorem selectedBound16591 : packedSelected [0,1,4,5,7,8,17,22,24] rootPS < 2^1333 := by decide +kernel

def env16592 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13444,0,65536,70678,67755,1025,1,69910,73770,65815,65933,8328,17,2184,70678,12677,76078,66699,8612,257,8613,13445,8973]

theorem envBound16592 : H12AffineFastState.Bounded env16592 := by
  intro p hp
  have h : env16592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16591_16592 : H12AffineEnvironment.transform 13 13444 env16591 = env16592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13444 env16591 == env16592) = true)

def env16593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6664479,2098512,17664,2437315,2102685,6349853,257,21793,46213,2175562]

theorem envBound16593 : H12AffineFastState.Bounded env16593 := by
  intro p hp
  have h : env16593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16540_16593 : H12AffineEnvironment.transform 22 2101329 env16540 = env16593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env16540 == env16593) = true)

def env16594 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2202015,2098512,17664,2437315,2102685,2411677,257,21793,46213,2175562]

theorem envBound16594 : H12AffineFastState.Bounded env16594 := by
  intro p hp
  have h : env16594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16593_16594 : H12AffineEnvironment.transform 21 272512 env16593 = env16594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env16593 == env16594) = true)

theorem identity16594 : scanCanonicalize (H12AffineFastState.compose env16594 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound16594 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16595 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,4160,272512,17,98781,8328,64,100831,5392,17664,336003,1501,318685,257,21793,46213,74250]

theorem envBound16595 : H12AffineFastState.Bounded env16595 := by
  intro p hp
  have h : env16595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16594_16595 : H12AffineEnvironment.transform 20 4160 env16594 = env16595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env16594 == env16595) = true)

theorem identity16595 : scanCanonicalize (H12AffineFastState.compose env16595 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound16595 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env16596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49305,262144,1025,32769,4160,272512,17,41430,8328,64,43476,5392,17664,262280,1501,318685,257,21793,46213,513]

theorem envBound16596 : H12AffineFastState.Bounded env16596 := by
  intro p hp
  have h : env16596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16595_16596 : H12AffineEnvironment.transform 15 8203 env16595 = env16596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env16595 == env16596) = true)

def env16597 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2202014,2098512,17664,2437315,2102685,2411676,257,21793,46213,2175562]

theorem envBound16597 : H12AffineFastState.Bounded env16597 := by
  intro p hp
  have h : env16597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16593_16597 : H12AffineEnvironment.transform 21 272513 env16593 = env16597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env16593 == env16597) = true)

def env16598 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,272393,2101329,98645,8192,64,2201878,2098512,17664,2437195,2102549,2411540,257,21793,46093,2175562]

theorem envBound16598 : H12AffineFastState.Bounded env16598 := by
  intro p hp
  have h : env16598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16597_16598 : H12AffineEnvironment.transform 6 8 env16597 = env16598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16597 == env16598) = true)

theorem identity16598 : scanCanonicalize (H12AffineFastState.compose env16598 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound16598 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env16599 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40971,16401,262144,1025,32769,2097152,272393,2101329,8542,8192,64,2111773,2098512,17664,2396224,2102549,2411540,257,21793,46093,2134593]

theorem envBound16599 : H12AffineFastState.Bounded env16599 := by
  intro p hp
  have h : env16599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16598_16599 : H12AffineEnvironment.transform 15 40971 env16598 = env16599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env16598 == env16599) = true)

theorem identity16599 : scanCanonicalize (H12AffineFastState.compose env16599 (packedSelected [0,4,5,7,8,17,22,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound16599 : packedSelected [0,4,5,7,8,17,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env16600 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40971,16401,10281,1025,32769,2097152,32,2101329,8542,8192,64,2111773,2098512,17664,2144361,2102549,2155581,257,21793,46093,2134593]

theorem envBound16600 : H12AffineFastState.Bounded env16600 := by
  intro p hp
  have h : env16600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16599_16600 : H12AffineEnvironment.transform 17 10281 env16599 = env16600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env16599 == env16600) = true)

theorem identity16600 : scanCanonicalize (H12AffineFastState.compose env16600 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound16600 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16601 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,33111,16401,2421,1025,32769,2097152,32,2101329,2,348,64,2103361,2098512,17664,2136373,2102549,2147681,257,21793,38225,2134593]

theorem envBound16601 : H12AffineFastState.Bounded env16601 := by
  intro p hp
  have h : env16601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16600_16601 : H12AffineEnvironment.transform 12 348 env16600 = env16601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env16600 == env16601) = true)

theorem identity16601 : scanCanonicalize (H12AffineFastState.compose env16601 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound16601 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env16602 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,1,342,16401,2421,1025,0,2097152,32,2101329,2,348,64,2103361,2098512,17664,2103604,2102549,2114912,257,21793,5456,2101824]

theorem envBound16602 : H12AffineFastState.Bounded env16602 := by
  intro p hp
  have h : env16602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16601_16602 : H12AffineEnvironment.transform 14 1 env16601 = env16602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env16601 == env16602) = true)

theorem identity16602 : scanCanonicalize (H12AffineFastState.compose env16602 (packedSelected [2,4,6,9,14] rootPS)) = affineNative (2^(20+1) ^^^ 17509) := by decide +kernel

theorem selectedBound16602 : packedSelected [2,4,6,9,14] rootPS < 2^1333 := by decide +kernel

def env16603 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,1,342,16401,2421,1025,0,17509,32,21556,2,348,64,23588,16693,17664,23889,20848,261,257,21793,5456,22053]

theorem envBound16603 : H12AffineFastState.Bounded env16603 := by
  intro p hp
  have h : env16603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16602_16603 : H12AffineEnvironment.transform 20 17509 env16602 = env16603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17509 env16602 == env16603) = true)

theorem identity16603 : scanCanonicalize (H12AffineFastState.compose env16603 (packedSelected [1,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound16603 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env16604 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,120,16384,1,114,16401,2129,1025,0,17509,32,21556,2,120,64,23588,16401,17444,23669,20564,33,37,21509,5236,22053]

theorem envBound16604 : H12AffineFastState.Bounded env16604 := by
  intro p hp
  have h : env16604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16603_16604 : H12AffineEnvironment.transform 7 36 env16603 = env16604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env16603 == env16604) = true)

theorem identity16604 : scanCanonicalize (H12AffineFastState.compose env16604 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound16604 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env16605 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,120,5237,1,114,5220,2129,1025,0,4112,32,65,2,120,64,2129,5220,4177,2048,1057,33,37,112,5236,592]

theorem envBound16605 : H12AffineFastState.Bounded env16605 := by
  intro p hp
  have h : env16605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16604_16605 : H12AffineEnvironment.transform 13 5237 env16604 = env16605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env16604 == env16605) = true)

def env16606 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,272392,2101329,98644,8193,64,2201879,2098512,17664,2437194,2102548,2411541,257,21793,46092,2175562]

theorem envBound16606 : H12AffineFastState.Bounded env16606 := by
  intro p hp
  have h : env16606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16597_16606 : H12AffineEnvironment.transform 6 9 env16597 = env16606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16597 == env16606) = true)

theorem identity16606 : scanCanonicalize (H12AffineFastState.compose env16606 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound16606 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env16607 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,77899,272392,73754,98644,8193,64,43356,79131,17664,262145,75103,392286,257,21793,46092,513]

theorem envBound16607 : H12AffineFastState.Bounded env16607 := by
  intro p hp
  have h : env16607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16606_16607 : H12AffineEnvironment.transform 20 77899 env16606 = env16607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env16606 == env16607) = true)

theorem identity16607 : scanCanonicalize (H12AffineFastState.compose env16607 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound16607 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env16608 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,67618,1025,32769,77899,73770,73754,98644,8193,64,43356,79131,17664,67619,75103,62588,257,21793,46092,513]

theorem envBound16608 : H12AffineFastState.Bounded env16608 := by
  intro p hp
  have h : env16608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16607_16608 : H12AffineEnvironment.transform 17 67618 env16607 = env16608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env16607 == env16608) = true)

theorem identity16608 : scanCanonicalize (H12AffineFastState.compose env16608 (packedSelected [0,3,7,10,11,16,18,19,23,24,32] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound16608 : packedSelected [0,3,7,10,11,16,18,19,23,24,32] rootPS < 2^1333 := by decide +kernel

def env16609 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29708,65536,70679,67618,1025,29709,77899,73770,73754,95576,8193,64,23888,79131,17664,67619,75103,112,257,21793,16384,513]

theorem envBound16609 : H12AffineFastState.Bounded env16609 := by
  intro p hp
  have h : env16609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16608_16609 : H12AffineEnvironment.transform 14 29708 env16608 = env16609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env16608 == env16609) = true)

theorem identity16609 : scanCanonicalize (H12AffineFastState.compose env16609 (packedSelected [4,9,14,16,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound16609 : packedSelected [4,9,14,16,18,23] rootPS < 2^1333 := by decide +kernel

def env16610 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,0,65536,70679,67618,1025,1,77899,73770,73754,65876,8193,64,10588,79131,12556,67619,75103,112,257,8493,13324,513]

theorem envBound16610 : H12AffineFastState.Bounded env16610 := by
  intro p hp
  have h : env16610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16609_16610 : H12AffineEnvironment.transform 13 13324 env16609 = env16610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env16609 == env16610) = true)

theorem identity16610 : scanCanonicalize (H12AffineFastState.compose env16610 (packedSelected [1,2,3,6,8,10,12,15,24] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound16610 : packedSelected [1,2,3,6,8,10,12,15,24] rootPS < 2^1333 := by decide +kernel

def env16611 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,0,65536,70679,67618,1025,1,69959,65830,65814,65876,269,64,2128,70679,4096,67619,66643,112,257,33,5376,513]

theorem envBound16611 : H12AffineFastState.Bounded env16611 := by
  intro p hp
  have h : env16611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16610_16611 : H12AffineEnvironment.transform 12 268 env16610 = env16611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env16610 == env16611) = true)

theorem identity16611 : scanCanonicalize (H12AffineFastState.compose env16611 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound16611 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env16612 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,0,343,5440,2421,1025,1,4112,113,65,3,269,64,2128,5440,4096,2420,1284,112,257,33,5376,513]

theorem envBound16612 : H12AffineFastState.Bounded env16612 := by
  intro p hp
  have h : env16612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16611_16612 : H12AffineEnvironment.transform 15 343 env16611 = env16612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env16611 == env16612) = true)

theorem identity16612 : scanCanonicalize (H12AffineFastState.compose env16612 (packedSelected [0,3,7,8,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16612 : packedSelected [0,3,7,8,10] rootPS < 2^1333 := by decide +kernel

def env16613 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,0,262,5393,2340,1025,1,4112,32,16,3,269,17,2049,5393,4096,2341,1284,33,257,33,5376,513]

theorem envBound16613 : H12AffineFastState.Bounded env16613 := by
  intro p hp
  have h : env16613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16612_16613 : H12AffineEnvironment.transform 5 17 env16612 = env16613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16612 == env16613) = true)

end H12CloudChart0