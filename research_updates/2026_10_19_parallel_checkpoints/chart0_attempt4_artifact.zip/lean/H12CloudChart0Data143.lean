import H12CloudChart0Data142

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity36277 : scanCanonicalize (H12AffineFastState.compose env36277 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound36277 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env36278 : List Nat := [2,4,8,0,0,1,8,256,512,769,260,260,268,773,0,263,773,0,769,1,261,0,0,3,268,0,261,772,261,1,517,0,256,1,773,513]

theorem envBound36278 : H12AffineFastState.Bounded env36278 := by
  intro p hp
  have h : env36278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36277_36278 : H12AffineEnvironment.transform 3 0 env36277 = env36278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env36277 == env36278) = true)

theorem identity36278 : scanCanonicalize (H12AffineFastState.compose env36278 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound36278 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env36279 : List Nat := [2,4,8,0,0,1,8,256,260,5,260,260,268,1,0,263,1,0,5,1,261,0,0,3,268,0,261,0,261,1,257,0,256,1,1,261]

theorem envBound36279 : H12AffineFastState.Bounded env36279 := by
  intro p hp
  have h : env36279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36278_36279 : H12AffineEnvironment.transform 8 260 env36278 = env36279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env36278 == env36279) = true)

theorem identity36279 : scanCanonicalize (H12AffineFastState.compose env36279 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound36279 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36280 : List Nat := [2,4,8,0,0,1,8,5,1,5,1,1,9,1,0,2,1,0,5,1,0,0,0,3,9,0,0,0,0,1,4,0,5,1,1,0]

theorem envBound36280 : H12AffineFastState.Bounded env36280 := by
  intro p hp
  have h : env36280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36279_36280 : H12AffineEnvironment.transform 7 5 env36279 = env36280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env36279 == env36280) = true)

def env36281 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,4160,144493,474239,485740,8193,65,349475,395637,489838,67618,75103,272392,256,95530,90202,513]

theorem envBound36281 : H12AffineFastState.Bounded env36281 := by
  intro p hp
  have h : env36281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36266_36281 : H12AffineEnvironment.transform 6 9 env36266 = env36281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36266 == env36281) = true)

theorem identity36281 : scanCanonicalize (H12AffineFastState.compose env36281 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound36281 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env36282 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90139,262144,1024,29789,4160,87158,285796,264567,8193,65,349475,354670,268661,67618,75103,272392,256,95530,90202,513]

theorem envBound36282 : H12AffineFastState.Bounded env36282 := by
  intro p hp
  have h : env36282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36281_36282 : H12AffineEnvironment.transform 16 90139 env36281 = env36282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env36281 == env36282) = true)

theorem identity36282 : scanCanonicalize (H12AffineFastState.compose env36282 (packedSelected [0,4,7,9,11,14,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 96622) := by decide +kernel

theorem selectedBound36282 : packedSelected [0,4,7,9,11,14,18,23,32] rootPS < 2^1333 := by decide +kernel

def env36283 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90139,96622,1024,29789,4160,87158,75018,94233,8193,65,11341,4096,90139,67618,75103,86374,256,95530,90202,513]

theorem envBound36283 : H12AffineFastState.Bounded env36283 := by
  intro p hp
  have h : env36283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36282_36283 : H12AffineEnvironment.transform 17 96622 env36282 = env36283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 96622 env36282 == env36283) = true)

theorem identity36283 : scanCanonicalize (H12AffineFastState.compose env36283 (packedSelected [3,4,5,8,9,14,15,17,18,20,23,28,38] rootPS)) = affineNative (2^(15+1) ^^^ 1047) := by decide +kernel

theorem selectedBound36283 : packedSelected [3,4,5,8,9,14,15,17,18,20,23,28,38] rootPS < 2^1333 := by decide +kernel

def env36284 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,1047,25612,32121,1024,29789,4160,20577,8477,29710,8193,65,11341,4096,25612,3125,8520,21873,256,28989,25677,513]

theorem envBound36284 : H12AffineFastState.Bounded env36284 := by
  intro p hp
  have h : env36284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36283_36284 : H12AffineEnvironment.transform 15 1047 env36283 = env36284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1047 env36283 == env36284) = true)

theorem identity36284 : scanCanonicalize (H12AffineFastState.compose env36284 (packedSelected [0,4,7,9,14,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound36284 : packedSelected [0,4,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env36285 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8460,1047,12636,10281,1024,8461,4160,1329,8477,8542,8193,65,11341,4096,12636,3125,8520,33,256,9325,12573,513]

theorem envBound36285 : H12AffineFastState.Bounded env36285 := by
  intro p hp
  have h : env36285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36284_36285 : H12AffineEnvironment.transform 13 5456 env36284 = env36285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env36284 == env36285) = true)

theorem identity36285 : scanCanonicalize (H12AffineFastState.compose env36285 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 7180) := by decide +kernel

theorem selectedBound36285 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env36286 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7180,5456,7424,1047,3408,5157,1024,7425,4160,1329,7441,7506,7181,65,4161,4096,3408,3125,7492,33,256,6241,3345,513]

theorem envBound36286 : H12AffineFastState.Bounded env36286 := by
  intro p hp
  have h : env36286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36285_36286 : H12AffineEnvironment.transform 12 7180 env36285 = env36286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7180 env36285 == env36286) = true)

theorem identity36286 : scanCanonicalize (H12AffineFastState.compose env36286 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 3408) := by decide +kernel

theorem selectedBound36286 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env36287 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3408,348,2048,80,1047,3408,2421,1024,81,3344,1329,65,2,349,65,3345,3408,3408,3125,20,33,256,1329,3345,513]

theorem envBound36287 : H12AffineFastState.Bounded env36287 := by
  intro p hp
  have h : env36287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36286_36287 : H12AffineEnvironment.transform 11 3408 env36286 = env36287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3408 env36286 == env36287) = true)

theorem identity36287 : scanCanonicalize (H12AffineFastState.compose env36287 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound36287 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env36288 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2112,348,2048,80,263,2112,2421,272,81,2048,33,65,2,349,65,2049,2112,2112,2341,20,33,256,33,2049,513]

theorem envBound36288 : H12AffineFastState.Bounded env36288 := by
  intro p hp
  have h : env36288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36287_36288 : H12AffineEnvironment.transform 9 272 env36287 = env36288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env36287 == env36288) = true)

theorem identity36288 : scanCanonicalize (H12AffineFastState.compose env36288 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36288 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36289 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,2065,269,2048,1,263,2065,2340,272,0,2048,33,16,2,268,16,2049,2065,2065,2341,20,33,256,33,2049,513]

theorem envBound36289 : H12AffineFastState.Bounded env36289 := by
  intro p hp
  have h : env36289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36288_36289 : H12AffineEnvironment.transform 5 17 env36288 = env36289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36288 == env36289) = true)

theorem identity36289 : scanCanonicalize (H12AffineFastState.compose env36289 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound36289 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36290 : List Nat := [2,4,8,16,32,17,9,256,512,272,261,276,269,261,1,263,276,33,272,0,261,33,16,2,268,16,260,276,276,32,20,33,256,33,260,513]

theorem envBound36290 : H12AffineFastState.Bounded env36290 := by
  intro p hp
  have h : env36290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36289_36290 : H12AffineEnvironment.transform 10 261 env36289 = env36290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env36289 == env36290) = true)

theorem identity36290 : scanCanonicalize (H12AffineFastState.compose env36290 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound36290 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36291 : List Nat := [2,4,8,16,32,17,9,37,512,53,32,49,40,32,1,34,49,33,53,0,32,33,16,2,41,16,33,49,49,32,20,33,37,33,33,513]

theorem envBound36291 : H12AffineFastState.Bounded env36291 := by
  intro p hp
  have h : env36291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36290_36291 : H12AffineEnvironment.transform 7 37 env36290 = env36291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env36290 == env36291) = true)

theorem identity36291 : scanCanonicalize (H12AffineFastState.compose env36291 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound36291 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36292 : List Nat := [2,4,8,16,32,17,9,37,33,53,32,49,40,32,1,34,49,33,53,0,32,33,16,2,41,16,33,49,49,32,20,33,37,33,33,32]

theorem envBound36292 : H12AffineFastState.Bounded env36292 := by
  intro p hp
  have h : env36292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36291_36292 : H12AffineEnvironment.transform 8 33 env36291 = env36292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env36291 == env36292) = true)

theorem identity36292 : scanCanonicalize (H12AffineFastState.compose env36292 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound36292 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36293 : List Nat := [2,4,8,0,32,1,9,37,33,37,32,33,40,32,1,34,33,33,37,0,32,33,0,2,41,0,33,33,33,32,4,33,37,33,33,32]

theorem envBound36293 : H12AffineFastState.Bounded env36293 := by
  intro p hp
  have h : env36293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36292_36293 : H12AffineEnvironment.transform 3 0 env36292 = env36293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env36292 == env36293) = true)

theorem identity36293 : scanCanonicalize (H12AffineFastState.compose env36293 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36293 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env36294 : List Nat := [2,4,8,0,1,1,9,4,0,4,1,0,9,1,1,3,0,0,4,0,1,0,0,2,8,0,0,0,0,1,4,0,4,0,0,1]

theorem envBound36294 : H12AffineFastState.Bounded env36294 := by
  intro p hp
  have h : env36294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36293_36294 : H12AffineEnvironment.transform 4 1 env36293 = env36294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36293 == env36294) = true)

def env36295 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180408,509987,498992,8328,65,349610,395773,494899,67618,119043,272393,256,98814,90203,63188]

theorem envBound36295 : H12AffineFastState.Bounded env36295 := by
  intro p hp
  have h : env36295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36264_36295 : H12AffineEnvironment.transform 20 4161 env36264 = env36295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env36264 == env36295) = true)

theorem identity36295 : scanCanonicalize (H12AffineFastState.compose env36295 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138476) := by decide +kernel

theorem selectedBound36295 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36296 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138476,1024,32769,4161,180408,120015,98780,8328,65,215366,5393,102879,67618,119043,144613,256,98814,90203,63188]

theorem envBound36296 : H12AffineFastState.Bounded env36296 := by
  intro p hp
  have h : env36296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36295_36296 : H12AffineEnvironment.transform 17 138476 env36295 = env36296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138476 env36295 == env36296) = true)

def env36297 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,10400,1024,32769,4161,62708,120015,98780,8328,65,97546,5393,102879,67618,119043,169,256,98814,90203,63188]

theorem envBound36297 : H12AffineFastState.Bounded env36297 := by
  intro p hp
  have h : env36297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36296_36297 : H12AffineEnvironment.transform 16 13388 env36296 = env36297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env36296 == env36297) = true)

theorem identity36297 : scanCanonicalize (H12AffineFastState.compose env36297 (packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound36297 : packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS < 2^1333 := by decide +kernel

def env36298 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,13388,10400,1024,32769,4161,62708,16,21763,8328,65,43477,5393,17664,56573,1500,169,256,21793,46212,63188]

theorem envBound36298 : H12AffineFastState.Bounded env36298 := by
  intro p hp
  have h : env36298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36297_36298 : H12AffineEnvironment.transform 15 54495 env36297 = env36298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env36297 == env36298) = true)

theorem identity36298 : scanCanonicalize (H12AffineFastState.compose env36298 (packedSelected [16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound36298 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env36299 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,13388,10400,1024,32769,4161,41461,16,2,8328,65,43477,5393,4097,35324,1500,169,256,32,46212,41941]

theorem envBound36299 : H12AffineFastState.Bounded env36299 := by
  intro p hp
  have h : env36299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36298_36299 : H12AffineEnvironment.transform 13 5377 env36298 = env36299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env36298 == env36299) = true)

theorem identity36299 : scanCanonicalize (H12AffineFastState.compose env36299 (packedSelected [0,1,2,4,7,8,11,12,14,15,17,18,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 8492) := by decide +kernel

theorem selectedBound36299 : packedSelected [0,1,2,4,7,8,11,12,14,15,17,18,19,22] rootPS < 2^1333 := by decide +kernel

def env36300 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8492,8434,13388,10400,1024,8493,4161,217,16,2,8328,65,2297,5393,4097,10448,1500,169,256,32,5544,761]

theorem envBound36300 : H12AffineFastState.Bounded env36300 := by
  intro p hp
  have h : env36300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36299_36300 : H12AffineEnvironment.transform 14 8492 env36299 = env36300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8492 env36299 == env36300) = true)

theorem identity36300 : scanCanonicalize (H12AffineFastState.compose env36300 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound36300 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36301 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,249,295,5529,2421,1024,248,4161,217,16,2,349,65,2297,5393,4097,2309,1500,169,256,32,5544,761]

theorem envBound36301 : H12AffineFastState.Bounded env36301 := by
  intro p hp
  have h : env36301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36300_36301 : H12AffineEnvironment.transform 12 469 env36300 = env36301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env36300 == env36301) = true)

theorem identity36301 : scanCanonicalize (H12AffineFastState.compose env36301 (packedSelected [2,3,5,10,11,12,14,15,18] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound36301 : packedSelected [2,3,5,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env36302 : List Nat := [2,4,8,16,32,64,120,256,512,1024,2048,4096,301,5377,1,295,5473,2421,1024,0,4161,33,16,2,349,65,2049,5393,4097,2309,1316,81,256,32,5456,513]

theorem envBound36302 : H12AffineFastState.Bounded env36302 := by
  intro p hp
  have h : env36302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36301_36302 : H12AffineEnvironment.transform 6 120 env36301 = env36302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env36301 == env36302) = true)

theorem identity36302 : scanCanonicalize (H12AffineFastState.compose env36302 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36302 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env36303 : List Nat := [2,4,8,16,0,64,88,256,512,1024,2048,4096,269,5377,1,263,5441,2389,1024,0,4161,1,16,2,349,65,2049,5393,4097,2309,1284,81,256,0,5456,513]

theorem envBound36303 : H12AffineFastState.Bounded env36303 := by
  intro p hp
  have h : env36303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36302_36303 : H12AffineEnvironment.transform 4 0 env36302 = env36303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36302 == env36303) = true)

theorem identity36303 : scanCanonicalize (H12AffineFastState.compose env36303 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1360) := by decide +kernel

theorem selectedBound36303 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env36304 : List Nat := [2,4,8,16,0,64,88,256,512,1024,1360,4096,269,5377,1,263,5441,1029,1024,0,4161,1,16,2,349,65,1361,5393,4097,1109,1284,81,256,0,5456,513]

theorem envBound36304 : H12AffineFastState.Bounded env36304 := by
  intro p hp
  have h : env36304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36303_36304 : H12AffineEnvironment.transform 10 1360 env36303 = env36304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1360 env36303 == env36304) = true)

theorem identity36304 : scanCanonicalize (H12AffineFastState.compose env36304 (packedSelected [0,1,2,4,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 1541) := by decide +kernel

theorem selectedBound36304 : packedSelected [0,1,2,4,8,10] rootPS < 2^1333 := by decide +kernel

def env36305 : List Nat := [2,4,8,16,0,64,88,256,512,1024,1360,1541,269,772,1,263,836,1029,1024,0,1604,1,16,2,349,65,1361,788,1540,1109,1284,81,256,0,853,513]

theorem envBound36305 : H12AffineFastState.Bounded env36305 := by
  intro p hp
  have h : env36305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36304_36305 : H12AffineEnvironment.transform 11 1541 env36304 = env36305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1541 env36304 == env36305) = true)

theorem identity36305 : scanCanonicalize (H12AffineFastState.compose env36305 (packedSelected [0,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound36305 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env36306 : List Nat := [2,4,8,16,0,64,88,256,512,4,340,513,269,772,1,263,836,1,4,0,576,1,16,2,349,65,341,788,512,81,256,81,256,0,853,513]

theorem envBound36306 : H12AffineFastState.Bounded env36306 := by
  intro p hp
  have h : env36306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36305_36306 : H12AffineEnvironment.transform 9 4 env36305 = env36306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env36305 == env36306) = true)

theorem identity36306 : scanCanonicalize (H12AffineFastState.compose env36306 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound36306 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36307 : List Nat := [2,4,8,16,0,64,88,256,65,4,340,64,269,325,1,263,261,1,4,0,1,1,16,2,349,65,341,341,65,81,256,81,256,0,276,64]

theorem envBound36307 : H12AffineFastState.Bounded env36307 := by
  intro p hp
  have h : env36307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36306_36307 : H12AffineEnvironment.transform 8 65 env36306 = env36307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env36306 == env36307) = true)

theorem identity36307 : scanCanonicalize (H12AffineFastState.compose env36307 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound36307 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env36308 : List Nat := [2,4,8,16,0,64,88,68,65,4,16,64,73,1,1,67,65,1,4,0,1,1,16,2,25,65,17,17,65,81,68,81,68,0,80,64]

theorem envBound36308 : H12AffineFastState.Bounded env36308 := by
  intro p hp
  have h : env36308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36307_36308 : H12AffineEnvironment.transform 7 68 env36307 = env36308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env36307 == env36308) = true)

theorem identity36308 : scanCanonicalize (H12AffineFastState.compose env36308 (packedSelected [1,2,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36308 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env36309 : List Nat := [2,4,8,16,0,16,8,20,17,4,16,16,25,1,1,19,17,1,4,0,1,1,16,2,25,17,17,17,17,1,20,1,20,0,0,16]

theorem envBound36309 : H12AffineFastState.Bounded env36309 := by
  intro p hp
  have h : env36309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36308_36309 : H12AffineEnvironment.transform 5 16 env36308 = env36309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36308 == env36309) = true)

theorem identity36309 : scanCanonicalize (H12AffineFastState.compose env36309 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound36309 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36310 : List Nat := [2,1,8,16,0,16,8,17,17,1,16,16,25,1,1,19,17,1,1,0,1,1,16,2,25,17,17,17,17,1,17,1,17,0,0,16]

theorem envBound36310 : H12AffineFastState.Bounded env36310 := by
  intro p hp
  have h : env36310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36309_36310 : H12AffineEnvironment.transform 1 1 env36309 = env36310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env36309 == env36310) = true)

theorem identity36310 : scanCanonicalize (H12AffineFastState.compose env36310 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound36310 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36311 : List Nat := [1,1,8,16,0,16,8,17,17,1,16,16,25,1,1,16,17,1,1,0,1,1,16,1,25,17,17,17,17,1,17,1,17,0,0,16]

theorem envBound36311 : H12AffineFastState.Bounded env36311 := by
  intro p hp
  have h : env36311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36310_36311 : H12AffineEnvironment.transform 0 1 env36310 = env36311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env36310 == env36311) = true)

def env36312 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,10401,1024,32769,4161,62709,120015,98780,8328,65,97547,5393,102879,67618,119043,168,256,98814,90203,63188]

theorem envBound36312 : H12AffineFastState.Bounded env36312 := by
  intro p hp
  have h : env36312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36296_36312 : H12AffineEnvironment.transform 16 13389 env36296 = env36312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env36296 == env36312) = true)

theorem identity36312 : scanCanonicalize (H12AffineFastState.compose env36312 (packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS)) = affineNative (2^(14+1) ^^^ 30073) := by decide +kernel

theorem selectedBound36312 : packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS < 2^1333 := by decide +kernel

def env36313 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30073,65536,13389,10401,1024,30072,4161,396,74166,95397,8328,65,97547,5393,91302,67618,74874,168,256,95367,90203,941]

theorem envBound36313 : H12AffineFastState.Bounded env36313 := by
  intro p hp
  have h : env36313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36312_36313 : H12AffineEnvironment.transform 14 30073 env36312 = env36313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30073 env36312 == env36313) = true)

theorem identity36313 : scanCanonicalize (H12AffineFastState.compose env36313 (packedSelected [1,4,5,9,10,12,14,15,18,19,20,23,24,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 250) := by decide +kernel

theorem selectedBound36313 : packedSelected [1,4,5,9,10,12,14,15,18,19,20,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env36314 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30073,250,13389,10401,1024,30072,4161,396,8524,29791,8328,65,32241,5393,25692,2264,9344,168,256,29821,24737,941]

theorem envBound36314 : H12AffineFastState.Bounded env36314 := by
  intro p hp
  have h : env36314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36313_36314 : H12AffineEnvironment.transform 15 250 env36313 = env36314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 250 env36313 == env36314) = true)

theorem identity36314 : scanCanonicalize (H12AffineFastState.compose env36314 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound36314 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env36315 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,29908,250,13389,10401,1024,29909,4161,33,8417,29791,8328,65,31836,5308,25692,2264,9344,168,173,29821,24737,512]

theorem envBound36315 : H12AffineFastState.Bounded env36315 := by
  intro p hp
  have h : env36315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36314_36315 : H12AffineEnvironment.transform 7 173 env36314 = env36315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env36314 == env36315) = true)

theorem identity36315 : scanCanonicalize (H12AffineFastState.compose env36315 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound36315 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env36316 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,5124,8400,250,13389,10401,1024,8401,4161,33,8417,8283,8328,65,10328,5308,12376,2264,9344,168,173,8313,13477,512]

theorem envBound36316 : H12AffineFastState.Bounded env36316 := by
  intro p hp
  have h : env36316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36315_36316 : H12AffineEnvironment.transform 13 5124 env36315 = env36316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env36315 == env36316) = true)

def env36317 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180408,509987,498993,8328,65,349611,2496957,2596210,67618,119042,2373705,256,2199998,2191387,63189]

theorem envBound36317 : H12AffineFastState.Bounded env36317 := by
  intro p hp
  have h : env36317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36263_36317 : H12AffineEnvironment.transform 23 498993 env36263 = env36317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 498993 env36263 == env36317) = true)

def env36318 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180408,509987,498993,8328,65,349611,395773,494898,67618,119042,272393,256,98814,90203,63189]

theorem envBound36318 : H12AffineFastState.Bounded env36318 := by
  intro p hp
  have h : env36318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36317_36318 : H12AffineEnvironment.transform 20 4160 env36317 = env36318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env36317 == env36318) = true)

theorem identity36318 : scanCanonicalize (H12AffineFastState.compose env36318 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190521) := by decide +kernel

theorem selectedBound36318 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36319 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,180408,73754,95496,8328,65,245138,57796,91403,67618,119042,180272,256,98814,90203,63189]

theorem envBound36319 : H12AffineFastState.Bounded env36319 := by
  intro p hp
  have h : env36319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36318_36319 : H12AffineEnvironment.transform 17 190521 env36318 = env36319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190521 env36318 == env36319) = true)

def env36320 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,10401,1024,32769,4160,32,73754,95496,8328,65,97546,57796,91403,67618,119042,168,256,98814,90203,63189]

theorem envBound36320 : H12AffineFastState.Bounded env36320 := by
  intro p hp
  have h : env36320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36319_36320 : H12AffineEnvironment.transform 16 49304 env36319 = env36320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env36319 == env36320) = true)

theorem identity36320 : scanCanonicalize (H12AffineFastState.compose env36320 (packedSelected [1,2,4,5,6,7,12,14,16,18,20,22,24,27,28,31,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 29743) := by decide +kernel

theorem selectedBound36320 : packedSelected [1,2,4,5,6,7,12,14,16,18,20,22,24,27,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env36321 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,29743,49304,10401,1024,32769,4160,32,21557,295,8328,65,2341,57796,4388,31757,42285,168,256,62929,5236,63189]

theorem envBound36321 : H12AffineFastState.Bounded env36321 := by
  intro p hp
  have h : env36321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36320_36321 : H12AffineEnvironment.transform 15 29743 env36320 = env36321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29743 env36320 == env36321) = true)

theorem identity36321 : scanCanonicalize (H12AffineFastState.compose env36321 (packedSelected [3,4,5,9,11,12,14,15,20,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 21541) := by decide +kernel

theorem selectedBound36321 : packedSelected [3,4,5,9,11,12,14,15,20,31,32] rootPS < 2^1333 := by decide +kernel

def env36322 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21541,29743,5309,10401,1024,21540,4160,32,21557,295,8328,65,2341,13793,4388,31757,28936,168,256,8692,5236,8944]

theorem envBound36322 : H12AffineFastState.Bounded env36322 := by
  intro p hp
  have h : env36322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36321_36322 : H12AffineEnvironment.transform 14 21541 env36321 = env36322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21541 env36321 == env36322) = true)

theorem identity36322 : scanCanonicalize (H12AffineFastState.compose env36322 (packedSelected [2,6,9,11,14,17,22,23] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36322 : packedSelected [2,6,9,11,14,17,22,23] rootPS < 2^1333 := by decide +kernel

def env36323 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21541,29743,5309,10401,1024,21540,4112,32,21557,295,8328,17,2341,13745,4388,31757,28936,168,256,8612,5156,8864]

theorem envBound36323 : H12AffineFastState.Bounded env36323 := by
  intro p hp
  have h : env36323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36322_36323 : H12AffineEnvironment.transform 5 16 env36322 = env36323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36322 == env36323) = true)

theorem identity36323 : scanCanonicalize (H12AffineFastState.compose env36323 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,17,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound36323 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env36324 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,8233,35,5309,10401,1024,8232,4112,32,8249,295,8328,17,2341,13745,4388,2049,1284,168,256,8612,5156,8864]

theorem envBound36324 : H12AffineFastState.Bounded env36324 := by
  intro p hp
  have h : env36324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36323_36324 : H12AffineEnvironment.transform 13 13324 env36323 = env36324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env36323 == env36324) = true)

theorem identity36324 : scanCanonicalize (H12AffineFastState.compose env36324 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound36324 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env36325 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5376,293,35,5309,2477,1024,292,4112,32,309,295,388,17,2341,5309,4388,2049,1284,168,256,168,5156,940]

theorem envBound36325 : H12AffineFastState.Bounded env36325 := by
  intro p hp
  have h : env36325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36324_36325 : H12AffineEnvironment.transform 12 268 env36324 = env36325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env36324 == env36325) = true)

theorem identity36325 : scanCanonicalize (H12AffineFastState.compose env36325 (packedSelected [2,6,11] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound36325 : packedSelected [2,6,11] rootPS < 2^1333 := by decide +kernel

def env36326 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1060,268,292,293,35,153,2477,1024,292,1076,32,309,295,388,17,2341,153,1280,2049,1284,168,256,168,0,940]

theorem envBound36326 : H12AffineFastState.Bounded env36326 := by
  intro p hp
  have h : env36326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36325_36326 : H12AffineEnvironment.transform 11 1060 env36325 = env36326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env36325 == env36326) = true)

theorem identity36326 : scanCanonicalize (H12AffineFastState.compose env36326 (packedSelected [1,3,5,6,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound36326 : packedSelected [1,3,5,6,8,10] rootPS < 2^1333 := by decide +kernel

def env36327 : List Nat := [2,4,8,16,32,16,128,36,512,1024,2048,1060,40,0,1,35,153,2185,1024,0,1076,32,17,3,160,17,2049,153,1060,2049,1056,168,36,168,0,648]

theorem envBound36327 : H12AffineFastState.Bounded env36327 := by
  intro p hp
  have h : env36327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36326_36327 : H12AffineEnvironment.transform 7 36 env36326 = env36327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env36326 == env36327) = true)

theorem identity36327 : scanCanonicalize (H12AffineFastState.compose env36327 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound36327 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env36328 : List Nat := [2,4,8,16,32,16,128,36,512,1024,1077,1060,40,0,1,35,153,1212,1024,0,1076,32,17,3,160,17,1076,153,1060,1076,1056,168,36,168,0,648]

theorem envBound36328 : H12AffineFastState.Bounded env36328 := by
  intro p hp
  have h : env36328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36327_36328 : H12AffineEnvironment.transform 10 1077 env36327 = env36328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env36327 == env36328) = true)

theorem identity36328 : scanCanonicalize (H12AffineFastState.compose env36328 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound36328 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env36329 : List Nat := [2,4,8,16,32,16,128,36,512,53,0,17,40,0,1,35,153,137,53,0,1,32,17,3,160,17,1,153,17,1,21,168,36,168,0,648]

theorem envBound36329 : H12AffineFastState.Bounded env36329 := by
  intro p hp
  have h : env36329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36328_36329 : H12AffineEnvironment.transform 9 53 env36328 = env36329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env36328 == env36329) = true)

theorem identity36329 : scanCanonicalize (H12AffineFastState.compose env36329 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound36329 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env36330 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,17,40,0,1,35,17,1,53,0,1,32,17,3,40,17,1,17,17,1,21,32,36,32,0,512]

theorem envBound36330 : H12AffineFastState.Bounded env36330 := by
  intro p hp
  have h : env36330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36329_36330 : H12AffineEnvironment.transform 6 8 env36329 = env36330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36329 == env36330) = true)

theorem identity36330 : scanCanonicalize (H12AffineFastState.compose env36330 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound36330 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36331 : List Nat := [2,4,8,0,32,0,8,36,512,37,0,1,40,0,1,35,1,1,37,0,1,32,1,3,40,1,1,1,1,1,5,32,36,32,0,512]

theorem envBound36331 : H12AffineFastState.Bounded env36331 := by
  intro p hp
  have h : env36331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36330_36331 : H12AffineEnvironment.transform 3 0 env36330 = env36331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env36330 == env36331) = true)

theorem identity36331 : scanCanonicalize (H12AffineFastState.compose env36331 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 47) := by decide +kernel

theorem selectedBound36331 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36332 : List Nat := [2,4,8,0,32,0,8,36,47,37,0,1,40,0,1,35,1,1,37,0,1,32,1,3,40,1,1,1,1,1,5,32,36,32,0,47]

theorem envBound36332 : H12AffineFastState.Bounded env36332 := by
  intro p hp
  have h : env36332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36331_36332 : H12AffineEnvironment.transform 8 47 env36331 = env36332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 47 env36331 == env36332) = true)

theorem identity36332 : scanCanonicalize (H12AffineFastState.compose env36332 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36332 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36333 : List Nat := [2,4,8,0,0,0,8,4,15,5,0,1,8,0,1,3,1,1,5,0,1,0,1,3,8,1,1,1,1,1,5,0,4,0,0,15]

theorem envBound36333 : H12AffineFastState.Bounded env36333 := by
  intro p hp
  have h : env36333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36332_36333 : H12AffineEnvironment.transform 4 0 env36332 = env36333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36332 == env36333) = true)

def env36334 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,10400,1024,32769,4160,33,73754,95496,8328,65,97547,57796,91403,67618,119042,169,256,98814,90203,63189]

theorem envBound36334 : H12AffineFastState.Bounded env36334 := by
  intro p hp
  have h : env36334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36319_36334 : H12AffineEnvironment.transform 16 49305 env36319 = env36334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env36319 == env36334) = true)

theorem identity36334 : scanCanonicalize (H12AffineFastState.compose env36334 (packedSelected [1,2,4,5,6,7,12,14,16,18,20,22,24,27,28,31,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound36334 : packedSelected [1,2,4,5,6,7,12,14,16,18,20,22,24,27,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env36335 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49305,10400,1024,32769,4160,33,16,21762,8328,65,23809,57796,17665,10280,61704,169,256,41460,16465,63189]

theorem envBound36335 : H12AffineFastState.Bounded env36335 := by
  intro p hp
  have h : env36335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36334_36335 : H12AffineEnvironment.transform 15 8202 env36334 = env36335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env36334 == env36335) = true)

theorem identity36335 : scanCanonicalize (H12AffineFastState.compose env36335 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound36335 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env36336 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8202,38297,10400,1024,32769,4160,33,16,2,8328,65,2049,46276,4097,10280,41992,169,256,41460,5457,41941]

theorem envBound36336 : H12AffineFastState.Bounded env36336 := by
  intro p hp
  have h : env36336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36335_36336 : H12AffineEnvironment.transform 13 5376 env36335 = env36336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env36335 == env36336) = true)

theorem identity36336 : scanCanonicalize (H12AffineFastState.compose env36336 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 8693) := by decide +kernel

theorem selectedBound36336 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env36337 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8693,8202,13420,10400,1024,8692,4160,33,16,2,8328,65,2049,5425,4097,10280,1533,169,256,1,5457,544]

theorem envBound36337 : H12AffineFastState.Bounded env36337 := by
  intro p hp
  have h : env36337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36336_36337 : H12AffineEnvironment.transform 14 8693 env36336 = env36337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8693 env36336 == env36337) = true)

theorem identity36337 : scanCanonicalize (H12AffineFastState.compose env36337 (packedSelected [2,6,17] rootPS)) = affineNative (2^(12+1) ^^^ 500) := by decide +kernel

theorem selectedBound36337 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env36338 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,500,5376,1,510,5528,2388,1024,0,4160,33,16,2,380,65,2049,5425,4097,2524,1533,169,256,1,5457,544]

theorem envBound36338 : H12AffineFastState.Bounded env36338 := by
  intro p hp
  have h : env36338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36337_36338 : H12AffineEnvironment.transform 12 500 env36337 = env36338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 500 env36337 == env36338) = true)

theorem identity36338 : scanCanonicalize (H12AffineFastState.compose env36338 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound36338 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env36339 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,300,5376,1,294,5440,2388,1024,0,4160,33,16,2,380,65,2049,5425,4097,2308,1317,113,256,1,5457,544]

theorem envBound36339 : H12AffineFastState.Bounded env36339 := by
  intro p hp
  have h : env36339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36338_36339 : H12AffineEnvironment.transform 6 88 env36338 = env36339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env36338 == env36339) = true)

theorem identity36339 : scanCanonicalize (H12AffineFastState.compose env36339 (packedSelected [1,3,5,6,7,8,9,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2608) := by decide +kernel

theorem selectedBound36339 : packedSelected [1,3,5,6,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env36340 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,2608,300,3888,1,294,3952,2388,1024,0,2672,33,16,2,380,65,2049,3841,2609,2308,1317,113,256,1,3937,544]

theorem envBound36340 : H12AffineFastState.Bounded env36340 := by
  intro p hp
  have h : env36340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36339_36340 : H12AffineEnvironment.transform 11 2608 env36339 = env36340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2608 env36339 == env36340) = true)

theorem identity36340 : scanCanonicalize (H12AffineFastState.compose env36340 (packedSelected [1,3,4,5,6,8,9,10,11,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 1360) := by decide +kernel

theorem selectedBound36340 : packedSelected [1,3,4,5,6,8,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env36341 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1360,1888,300,608,1,294,544,1028,1024,0,1824,33,16,2,380,65,1361,593,1889,1108,1317,113,256,1,561,544]

theorem envBound36341 : H12AffineFastState.Bounded env36341 := by
  intro p hp
  have h : env36341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36340_36341 : H12AffineEnvironment.transform 10 1360 env36340 = env36341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1360 env36340 == env36341) = true)

theorem identity36341 : scanCanonicalize (H12AffineFastState.compose env36341 (packedSelected [1,2,6,7,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound36341 : packedSelected [1,2,6,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env36342 : List Nat := [2,4,8,16,32,64,88,100,512,1024,1076,1540,72,608,1,66,544,1028,1024,0,1604,33,16,2,24,65,1077,593,1541,1108,1089,113,100,1,561,544]

theorem envBound36342 : H12AffineFastState.Bounded env36342 := by
  intro p hp
  have h : env36342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36341_36342 : H12AffineEnvironment.transform 7 100 env36341 = env36342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env36341 == env36342) = true)

theorem identity36342 : scanCanonicalize (H12AffineFastState.compose env36342 (packedSelected [0,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound36342 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env36343 : List Nat := [2,4,8,16,32,64,88,100,512,84,96,592,72,608,1,66,544,80,84,0,528,33,16,2,24,65,97,593,593,0,21,113,100,1,561,544]

theorem envBound36343 : H12AffineFastState.Bounded env36343 := by
  intro p hp
  have h : env36343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36342_36343 : H12AffineEnvironment.transform 9 84 env36342 = env36343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env36342 == env36343) = true)

theorem identity36343 : scanCanonicalize (H12AffineFastState.compose env36343 (packedSelected [1,6,8] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound36343 : packedSelected [1,6,8] rootPS < 2^1333 := by decide +kernel

def env36344 : List Nat := [2,4,8,16,32,64,88,100,48,84,96,96,72,80,1,66,16,80,84,0,32,33,16,2,24,65,97,97,97,0,21,113,100,1,1,16]

theorem envBound36344 : H12AffineFastState.Bounded env36344 := by
  intro p hp
  have h : env36344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36343_36344 : H12AffineEnvironment.transform 8 48 env36343 = env36344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env36343 == env36344) = true)

theorem identity36344 : scanCanonicalize (H12AffineFastState.compose env36344 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36344 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36345 : List Nat := [2,4,8,16,32,17,9,53,48,5,49,49,25,1,1,19,16,1,5,0,32,33,16,2,24,16,48,48,48,0,21,32,53,1,1,16]

theorem envBound36345 : H12AffineFastState.Bounded env36345 := by
  intro p hp
  have h : env36345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36344_36345 : H12AffineEnvironment.transform 5 17 env36344 = env36345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36344 == env36345) = true)

theorem identity36345 : scanCanonicalize (H12AffineFastState.compose env36345 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound36345 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env36346 : List Nat := [2,4,8,16,17,17,9,4,1,5,0,0,25,1,1,19,16,1,5,0,17,16,16,2,24,16,1,1,1,0,21,17,4,1,1,16]

theorem envBound36346 : H12AffineFastState.Bounded env36346 := by
  intro p hp
  have h : env36346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36345_36346 : H12AffineEnvironment.transform 4 17 env36345 = env36346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env36345 == env36346) = true)

theorem identity36346 : scanCanonicalize (H12AffineFastState.compose env36346 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound36346 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36347 : List Nat := [2,4,8,0,1,1,9,4,1,5,0,0,9,1,1,3,0,1,5,0,1,0,0,2,8,0,1,1,1,0,5,1,4,1,1,0]

theorem envBound36347 : H12AffineFastState.Bounded env36347 := by
  intro p hp
  have h : env36347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36346_36347 : H12AffineEnvironment.transform 3 0 env36346 = env36347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env36346 == env36347) = true)

def env36348 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180408,509987,498993,8328,65,349611,395772,494899,67618,119042,272392,256,98815,90202,63189]

theorem envBound36348 : H12AffineFastState.Bounded env36348 := by
  intro p hp
  have h : env36348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36317_36348 : H12AffineEnvironment.transform 20 4161 env36317 = env36348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env36317 == env36348) = true)

def env36349 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1024,32769,4161,180408,254083,243089,8328,65,97547,139612,238995,67618,119042,168,256,98815,90202,63189]

theorem envBound36349 : H12AffineFastState.Bounded env36349 := by
  intro p hp
  have h : env36349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36348_36349 : H12AffineEnvironment.transform 17 10400 env36348 = env36349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env36348 == env36349) = true)

def env36350 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,180272,253963,242969,8192,65,97547,139612,238875,67618,119042,32,256,98679,90202,63069]

theorem envBound36350 : H12AffineFastState.Bounded env36350 := by
  intro p hp
  have h : env36350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36349_36350 : H12AffineEnvironment.transform 6 8 env36349 = env36350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36349 == env36350) = true)

theorem identity36350 : scanCanonicalize (H12AffineFastState.compose env36350 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound36350 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env36351 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10280,1024,29789,4161,144492,201815,213317,8192,65,97547,139612,217415,67618,75102,32,256,95531,90202,513]

theorem envBound36351 : H12AffineFastState.Bounded env36351 := by
  intro p hp
  have h : env36351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36350_36351 : H12AffineEnvironment.transform 14 29788 env36350 = env36351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env36350 == env36351) = true)

theorem identity36351 : scanCanonicalize (H12AffineFastState.compose env36351 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound36351 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env36352 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,82246,10280,1024,29789,4161,95530,21777,3,8192,65,97547,90138,4097,67618,75102,32,256,95531,90202,513]

theorem envBound36352 : H12AffineFastState.Bounded env36352 := by
  intro p hp
  have h : env36352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36351_36352 : H12AffineEnvironment.transform 16 82246 env36351 = env36352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env36351 == env36352) = true)

theorem identity36352 : scanCanonicalize (H12AffineFastState.compose env36352 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound36352 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env36353 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,263,16449,10280,1024,29789,4161,29741,21777,3,8192,65,31756,24861,4097,2341,9305,32,256,29740,24925,513]

theorem envBound36353 : H12AffineFastState.Bounded env36353 := by
  intro p hp
  have h : env36353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36352_36353 : H12AffineEnvironment.transform 15 263 env36352 = env36353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env36352 == env36353) = true)

theorem identity36353 : scanCanonicalize (H12AffineFastState.compose env36353 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound36353 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env36354 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,263,5440,10280,1024,8540,4161,8492,16,3,8192,65,10509,13340,4097,2341,9305,32,256,8493,13404,513]

theorem envBound36354 : H12AffineFastState.Bounded env36354 := by
  intro p hp
  have h : env36354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36353_36354 : H12AffineEnvironment.transform 13 5377 env36353 = env36354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env36353 == env36354) = true)

theorem identity36354 : scanCanonicalize (H12AffineFastState.compose env36354 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound36354 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36355 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,0,263,5440,2421,1024,1,4161,113,16,3,349,65,2128,5441,4097,2341,1284,32,256,112,5377,513]

theorem envBound36355 : H12AffineFastState.Bounded env36355 := by
  intro p hp
  have h : env36355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36354_36355 : H12AffineEnvironment.transform 12 349 env36354 = env36355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env36354 == env36355) = true)

theorem identity36355 : scanCanonicalize (H12AffineFastState.compose env36355 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1589) := by decide +kernel

theorem selectedBound36355 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env36356 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1589,4096,349,5377,0,263,5440,1856,1024,1,4161,113,16,3,349,65,1637,5441,4097,1808,1284,32,256,112,5377,513]

theorem envBound36356 : H12AffineFastState.Bounded env36356 := by
  intro p hp
  have h : env36356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36355_36356 : H12AffineEnvironment.transform 10 1589 env36355 = env36356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1589 env36355 == env36356) = true)

theorem identity36356 : scanCanonicalize (H12AffineFastState.compose env36356 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 325) := by decide +kernel

theorem selectedBound36356 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env36357 : List Nat := [2,4,8,16,32,64,8,256,325,1024,1392,4096,349,5377,0,263,5440,1029,1024,1,4161,113,16,3,349,65,1312,5441,4097,1109,1284,32,256,112,5377,324]

theorem envBound36357 : H12AffineFastState.Bounded env36357 := by
  intro p hp
  have h : env36357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36356_36357 : H12AffineEnvironment.transform 8 325 env36356 = env36357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 325 env36356 == env36357) = true)

theorem identity36357 : scanCanonicalize (H12AffineFastState.compose env36357 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 116) := by decide +kernel

theorem selectedBound36357 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env36358 : List Nat := [2,4,8,16,32,64,8,256,325,116,260,4096,349,4469,0,263,4404,113,116,1,4161,113,16,3,349,65,340,4405,4097,33,368,32,256,112,4469,324]

theorem envBound36358 : H12AffineFastState.Bounded env36358 := by
  intro p hp
  have h : env36358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36357_36358 : H12AffineEnvironment.transform 9 116 env36357 = env36358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 116 env36357 == env36358) = true)

theorem identity36358 : scanCanonicalize (H12AffineFastState.compose env36358 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 260) := by decide +kernel

theorem selectedBound36358 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36359 : List Nat := [2,4,8,16,32,64,8,256,325,116,260,260,349,113,0,263,48,113,116,1,325,113,16,3,349,65,340,49,261,33,368,32,256,112,113,324]

theorem envBound36359 : H12AffineFastState.Bounded env36359 := by
  intro p hp
  have h : env36359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36358_36359 : H12AffineEnvironment.transform 11 260 env36358 = env36359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 260 env36358 == env36359) = true)

theorem identity36359 : scanCanonicalize (H12AffineFastState.compose env36359 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound36359 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36360 : List Nat := [2,4,8,16,32,64,8,53,112,116,49,49,104,113,0,50,48,113,116,1,112,113,16,3,104,65,97,49,48,33,69,32,53,112,113,113]

theorem envBound36360 : H12AffineFastState.Bounded env36360 := by
  intro p hp
  have h : env36360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36359_36360 : H12AffineEnvironment.transform 7 53 env36359 = env36360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env36359 == env36360) = true)

theorem identity36360 : scanCanonicalize (H12AffineFastState.compose env36360 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound36360 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36361 : List Nat := [2,4,8,10,32,64,8,47,106,110,43,43,104,107,0,40,42,107,110,1,106,107,10,3,104,65,97,43,42,33,69,32,47,106,107,107]

theorem envBound36361 : H12AffineFastState.Bounded env36361 := by
  intro p hp
  have h : env36361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36360_36361 : H12AffineEnvironment.transform 3 10 env36360 = env36361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env36360 == env36361) = true)

theorem identity36361 : scanCanonicalize (H12AffineFastState.compose env36361 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound36361 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env36362 : List Nat := [2,4,8,10,32,1,8,47,43,47,43,43,41,42,0,40,42,42,47,1,43,42,10,3,41,0,32,43,42,33,4,32,47,43,42,42]

theorem envBound36362 : H12AffineFastState.Bounded env36362 := by
  intro p hp
  have h : env36362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36361_36362 : H12AffineEnvironment.transform 5 1 env36361 = env36362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env36361 == env36362) = true)

theorem identity36362 : scanCanonicalize (H12AffineFastState.compose env36362 (packedSelected [3,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36362 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env36363 : List Nat := [2,4,8,10,0,1,8,15,11,15,11,11,9,10,0,8,10,10,15,1,11,10,10,3,9,0,0,11,10,1,4,0,15,11,10,10]

theorem envBound36363 : H12AffineFastState.Bounded env36363 := by
  intro p hp
  have h : env36363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36362_36363 : H12AffineEnvironment.transform 4 0 env36362 = env36363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36362 == env36363) = true)

def env36364 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,180273,253962,242968,8193,65,97547,139612,238874,67618,119042,33,256,98678,90202,63068]

theorem envBound36364 : H12AffineFastState.Bounded env36364 := by
  intro p hp
  have h : env36364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36349_36364 : H12AffineEnvironment.transform 6 9 env36349 = env36364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36349 == env36364) = true)

theorem identity36364 : scanCanonicalize (H12AffineFastState.compose env36364 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound36364 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36365 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1024,8540,4161,156012,213335,201797,8193,65,97547,139612,197703,67618,94303,33,256,73771,90202,22273]

theorem envBound36365 : H12AffineFastState.Bounded env36365 := by
  intro p hp
  have h : env36365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36364_36365 : H12AffineEnvironment.transform 14 8541 env36364 = env36365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env36364 == env36365) = true)

theorem identity36365 : scanCanonicalize (H12AffineFastState.compose env36365 (packedSelected [1,2,6,8,9,11,12,14,15,16,19,20,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound36365 : packedSelected [1,2,6,8,9,11,12,14,15,16,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env36366 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,13389,10281,1024,8540,4161,21793,95514,73736,8193,65,97547,5393,77834,67618,94303,33,256,73771,90202,22273]

theorem envBound36366 : H12AffineFastState.Bounded env36366 := by
  intro p hp
  have h : env36366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36365_36366 : H12AffineEnvironment.transform 16 13389 env36365 = env36366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env36365 == env36366) = true)

theorem identity36366 : scanCanonicalize (H12AffineFastState.compose env36366 (packedSelected [0,1,4,7,8,19,22] rootPS)) = affineNative (2^(15+1) ^^^ 1095) := by decide +kernel

theorem selectedBound36366 : packedSelected [0,1,4,7,8,19,22] rootPS < 2^1333 := by decide +kernel

def env36367 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,1095,13389,10281,1024,8540,4161,21793,29021,9295,8193,65,31052,5393,13389,3173,29720,33,256,9324,25629,22273]

theorem envBound36367 : H12AffineFastState.Bounded env36367 := by
  intro p hp
  have h : env36367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36366_36367 : H12AffineEnvironment.transform 15 1095 env36366 = env36367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1095 env36366 == env36367) = true)

theorem identity36367 : scanCanonicalize (H12AffineFastState.compose env36367 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 12392) := by decide +kernel

theorem selectedBound36367 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env36368 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12392,8541,1095,13389,10281,1024,8540,4161,9545,309,9295,8193,65,2340,5393,13389,3173,1136,33,256,9324,5237,10089]

theorem envBound36368 : H12AffineFastState.Bounded env36368 := by
  intro p hp
  have h : env36368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36367_36368 : H12AffineEnvironment.transform 13 12392 env36367 = env36368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12392 env36367 == env36368) = true)

theorem identity36368 : scanCanonicalize (H12AffineFastState.compose env36368 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,14,19] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound36368 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,14,19] rootPS < 2^1333 := by decide +kernel

def env36369 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1385,5377,1076,1095,4388,3392,1024,1077,4161,32,309,294,1384,65,2340,5393,4388,3173,1136,33,256,261,5237,512]

theorem envBound36369 : H12AffineFastState.Bounded env36369 := by
  intro p hp
  have h : env36369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36368_36369 : H12AffineEnvironment.transform 12 1385 env36368 = env36369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env36368 == env36369) = true)

theorem identity36369 : scanCanonicalize (H12AffineFastState.compose env36369 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound36369 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env36370 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,4096,1085,5205,1076,1095,4208,3092,1024,1077,4161,32,97,114,1084,65,2160,5189,4208,3173,1136,33,84,81,5237,512]

theorem envBound36370 : H12AffineFastState.Bounded env36370 := by
  intro p hp
  have h : env36370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36369_36370 : H12AffineEnvironment.transform 7 84 env36369 = env36370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env36369 == env36370) = true)

theorem identity36370 : scanCanonicalize (H12AffineFastState.compose env36370 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound36370 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env36371 : List Nat := [2,4,8,16,32,64,9,84,512,1024,1,4096,1085,5205,1076,1095,4208,1045,1024,1077,4161,32,97,114,1084,65,113,5189,4208,1124,1136,33,84,81,5237,512]

theorem envBound36371 : H12AffineFastState.Bounded env36371 := by
  intro p hp
  have h : env36371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36370_36371 : H12AffineEnvironment.transform 10 1 env36370 = env36371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env36370 == env36371) = true)

theorem identity36371 : scanCanonicalize (H12AffineFastState.compose env36371 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 97) := by decide +kernel

theorem selectedBound36371 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env36372 : List Nat := [2,4,8,16,32,64,9,84,512,1024,1,97,1085,1076,1076,1095,17,1045,1024,1077,32,32,97,114,1084,65,113,1060,17,1124,1136,33,84,81,1044,512]

theorem envBound36372 : H12AffineFastState.Bounded env36372 := by
  intro p hp
  have h : env36372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36371_36372 : H12AffineEnvironment.transform 11 97 env36371 = env36372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 97 env36371 == env36372) = true)

theorem identity36372 : scanCanonicalize (H12AffineFastState.compose env36372 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36372 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env36373 : List Nat := [2,4,8,16,32,16,9,4,512,1024,1,49,1085,1076,1076,1047,17,1045,1024,1077,32,32,49,34,1084,17,33,1060,17,1076,1056,33,4,1,1044,512]

theorem envBound36373 : H12AffineFastState.Bounded env36373 := by
  intro p hp
  have h : env36373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36372_36373 : H12AffineEnvironment.transform 5 16 env36372 = env36373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36372 == env36373) = true)

theorem identity36373 : scanCanonicalize (H12AffineFastState.compose env36373 (packedSelected [0,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound36373 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env36374 : List Nat := [2,4,8,16,32,16,9,4,512,21,1,49,40,33,33,2,17,0,21,32,32,32,49,34,41,17,33,49,17,33,53,33,4,1,1,512]

theorem envBound36374 : H12AffineFastState.Bounded env36374 := by
  intro p hp
  have h : env36374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36373_36374 : H12AffineEnvironment.transform 9 21 env36373 = env36374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env36373 == env36374) = true)

theorem identity36374 : scanCanonicalize (H12AffineFastState.compose env36374 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 30) := by decide +kernel

theorem selectedBound36374 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36375 : List Nat := [2,4,8,16,30,16,9,4,512,21,1,15,22,31,31,2,17,0,21,30,30,30,15,28,23,17,31,15,17,31,11,31,4,1,1,512]

theorem envBound36375 : H12AffineFastState.Bounded env36375 := by
  intro p hp
  have h : env36375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36374_36375 : H12AffineEnvironment.transform 4 30 env36374 = env36375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 30 env36374 == env36375) = true)

theorem identity36375 : scanCanonicalize (H12AffineFastState.compose env36375 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound36375 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36376 : List Nat := [2,4,6,16,16,16,7,4,512,21,1,1,22,17,17,2,17,0,21,16,16,16,1,18,23,17,17,1,17,17,5,17,4,1,1,512]

theorem envBound36376 : H12AffineFastState.Bounded env36376 := by
  intro p hp
  have h : env36376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36375_36376 : H12AffineEnvironment.transform 2 6 env36375 = env36376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env36375 == env36376) = true)

theorem identity36376 : scanCanonicalize (H12AffineFastState.compose env36376 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound36376 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env36377 : List Nat := [2,4,6,16,16,16,7,4,16,21,1,1,22,17,17,2,17,0,21,16,16,16,1,18,23,17,17,1,17,17,5,17,4,1,1,16]

theorem envBound36377 : H12AffineFastState.Bounded env36377 := by
  intro p hp
  have h : env36377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36376_36377 : H12AffineEnvironment.transform 8 16 env36376 = env36377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env36376 == env36377) = true)

def env36378 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1024,32769,4161,180408,254082,243088,8328,65,97546,139613,238994,67618,119042,169,256,98815,90202,63189]

theorem envBound36378 : H12AffineFastState.Bounded env36378 := by
  intro p hp
  have h : env36378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36348_36378 : H12AffineEnvironment.transform 17 10401 env36348 = env36378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env36348 == env36378) = true)

def env36379 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,180272,253962,242968,8192,65,97546,139613,238874,67618,119042,33,256,98679,90202,63069]

theorem envBound36379 : H12AffineFastState.Bounded env36379 := by
  intro p hp
  have h : env36379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36378_36379 : H12AffineEnvironment.transform 6 8 env36378 = env36379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36378 == env36379) = true)

theorem identity36379 : scanCanonicalize (H12AffineFastState.compose env36379 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound36379 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36380 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10281,1024,32769,4161,73771,17,21763,8192,65,97546,115014,17665,67618,119042,33,256,98679,90202,63069]

theorem envBound36380 : H12AffineFastState.Bounded env36380 := by
  intro p hp
  have h : env36380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36379_36380 : H12AffineEnvironment.transform 16 122907 env36379 = env36380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env36379 == env36380) = true)

theorem identity36380 : scanCanonicalize (H12AffineFastState.compose env36380 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound36380 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env36381 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,65536,103495,10281,1024,32769,4161,73771,17,8543,8192,65,67926,111898,12637,67618,107870,33,256,98679,70662,33281]

theorem envBound36381 : H12AffineFastState.Bounded env36381 := by
  intro p hp
  have h : env36381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36380_36381 : H12AffineEnvironment.transform 13 13404 env36380 = env36381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env36380 == env36381) = true)

theorem identity36381 : scanCanonicalize (H12AffineFastState.compose env36381 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound36381 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env36382 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,8283,46108,10281,1024,32769,4161,112,17,8543,8192,65,10509,38209,12637,10361,34053,33,256,41260,13405,33281]

theorem envBound36382 : H12AffineFastState.Bounded env36382 := by
  intro p hp
  have h : env36382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36381_36382 : H12AffineEnvironment.transform 15 8283 env36381 = env36382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env36381 == env36382) = true)

theorem identity36382 : scanCanonicalize (H12AffineFastState.compose env36382 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound36382 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env36383 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,13404,32768,8283,46108,10281,1024,32769,4161,112,17,8315,8192,65,10281,37989,12409,10361,33825,33,36,40968,13405,33281]

theorem envBound36383 : H12AffineFastState.Bounded env36383 := by
  intro p hp
  have h : env36383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36382_36383 : H12AffineEnvironment.transform 7 36 env36382 = env36383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env36382 == env36383) = true)

theorem identity36383 : scanCanonicalize (H12AffineFastState.compose env36383 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound36383 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env36384 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,13404,1,8283,13341,10281,1024,0,4161,112,17,8315,8192,65,10281,5220,12409,10361,1056,33,36,8201,13405,512]

theorem envBound36384 : H12AffineFastState.Bounded env36384 := by
  intro p hp
  have h : env36384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36383_36384 : H12AffineEnvironment.transform 14 1 env36383 = env36384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env36383 == env36384) = true)

theorem identity36384 : scanCanonicalize (H12AffineFastState.compose env36384 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36384 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env36385 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,13324,1,8203,13341,10281,1024,0,4113,32,17,8235,8192,17,10281,5172,12329,10281,1056,33,36,8201,13325,512]

theorem envBound36385 : H12AffineFastState.Bounded env36385 := by
  intro p hp
  have h : env36385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36384_36385 : H12AffineEnvironment.transform 5 16 env36384 = env36385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36384 == env36385) = true)

theorem identity36385 : scanCanonicalize (H12AffineFastState.compose env36385 (packedSelected [0,2,4] rootPS)) = affineNative (2^(12+1) ^^^ 7180) := by decide +kernel

theorem selectedBound36385 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env36386 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,7180,2048,1,7175,2065,5157,1024,0,4113,32,17,7207,7180,17,5157,5172,3109,5157,1056,33,36,7173,2049,512]

theorem envBound36386 : H12AffineFastState.Bounded env36386 := by
  intro p hp
  have h : env36386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36385_36386 : H12AffineEnvironment.transform 12 7180 env36385 = env36386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7180 env36385 == env36386) = true)

theorem identity36386 : scanCanonicalize (H12AffineFastState.compose env36386 (packedSelected [1,2,5] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound36386 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env36387 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,3109,41,2048,1,34,2065,2048,1024,0,3124,32,17,2,41,17,2048,2065,3109,2048,1056,33,36,32,2049,512]

theorem envBound36387 : H12AffineFastState.Bounded env36387 := by
  intro p hp
  have h : env36387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36386_36387 : H12AffineEnvironment.transform 11 3109 env36386 = env36387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env36386 == env36387) = true)

theorem identity36387 : scanCanonicalize (H12AffineFastState.compose env36387 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36387 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36388 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,3077,9,2048,1,2,2065,2048,1024,0,3092,0,17,2,9,17,2048,2065,3077,2048,1024,1,4,0,2049,512]

theorem envBound36388 : H12AffineFastState.Bounded env36388 := by
  intro p hp
  have h : env36388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36387_36388 : H12AffineEnvironment.transform 4 0 env36387 = env36388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36387 == env36388) = true)

theorem identity36388 : scanCanonicalize (H12AffineFastState.compose env36388 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound36388 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env36389 : List Nat := [2,4,8,16,0,16,8,4,512,20,2048,2065,9,2048,1,2,2065,2048,20,0,2048,0,17,2,9,17,2048,2065,2065,2048,20,1,4,0,2049,512]

theorem envBound36389 : H12AffineFastState.Bounded env36389 := by
  intro p hp
  have h : env36389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36388_36389 : H12AffineEnvironment.transform 9 20 env36388 = env36389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env36388 == env36389) = true)

def env36390 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,180273,253963,242969,8193,65,97546,139613,238875,67618,119042,32,256,98678,90202,63068]

theorem envBound36390 : H12AffineFastState.Bounded env36390 := by
  intro p hp
  have h : env36390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36378_36390 : H12AffineEnvironment.transform 6 9 env36378 = env36390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36378 == env36390) = true)

theorem identity36390 : scanCanonicalize (H12AffineFastState.compose env36390 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound36390 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36391 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10280,1024,32769,4161,98678,41292,62558,8193,65,97546,90138,58460,67618,119042,32,256,98678,90202,63068]

theorem envBound36391 : H12AffineFastState.Bounded env36391 := by
  intro p hp
  have h : env36391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36390_36391 : H12AffineEnvironment.transform 16 82247 env36390 = env36391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env36390 == env36391) = true)

theorem identity36391 : scanCanonicalize (H12AffineFastState.compose env36391 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound36391 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env36392 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,65536,82247,2420,1024,32769,4161,98678,32784,54530,349,65,89174,82246,50432,67618,119042,32,256,98678,82182,55040]

theorem envBound36392 : H12AffineFastState.Bounded env36392 := by
  intro p hp
  have h : env36392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36391_36392 : H12AffineEnvironment.transform 12 348 env36391 = env36392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env36391 == env36392) = true)

theorem identity36392 : scanCanonicalize (H12AffineFastState.compose env36392 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 54278) := by decide +kernel

theorem selectedBound36392 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env36393 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,54278,38209,2420,1024,32769,4161,21872,32784,54530,349,65,34896,38208,50432,56356,1284,32,256,21872,38144,55040]

theorem envBound36393 : H12AffineFastState.Bounded env36393 := by
  intro p hp
  have h : env36393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36392_36393 : H12AffineEnvironment.transform 15 54278 env36392 = env36393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54278 env36392 == env36393) = true)

theorem identity36393 : scanCanonicalize (H12AffineFastState.compose env36393 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound36393 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env36394 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,262,16449,2420,1024,21761,4161,21872,21776,2,349,65,23888,16448,4096,2340,1284,32,256,21872,16384,512]

theorem envBound36394 : H12AffineFastState.Bounded env36394 := by
  intro p hp
  have h : env36394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36393_36394 : H12AffineEnvironment.transform 14 21760 env36393 = env36394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env36393 == env36394) = true)

theorem identity36394 : scanCanonicalize (H12AffineFastState.compose env36394 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5488) := by decide +kernel

theorem selectedBound36394 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env36395 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5488,112,262,5425,2420,1024,113,4161,0,96,2,349,65,2080,5424,4096,2340,1284,32,256,0,5488,512]

theorem envBound36395 : H12AffineFastState.Bounded env36395 := by
  intro p hp
  have h : env36395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36394_36395 : H12AffineEnvironment.transform 13 5488 env36394 = env36395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5488 env36394 == env36395) = true)

theorem identity36395 : scanCanonicalize (H12AffineFastState.compose env36395 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36395 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env36396 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5408,32,262,5425,2340,1024,33,4113,0,48,2,269,17,2080,5424,4096,2340,1284,32,256,0,5408,512]

theorem envBound36396 : H12AffineFastState.Bounded env36396 := by
  intro p hp
  have h : env36396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36395_36396 : H12AffineEnvironment.transform 5 16 env36395 = env36396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36395 == env36396) = true)

theorem identity36396 : scanCanonicalize (H12AffineFastState.compose env36396 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2587) := by decide +kernel

theorem selectedBound36396 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env36397 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2587,268,3899,32,262,3882,2340,1024,33,2570,0,48,2,269,17,2080,3883,2587,2340,1284,32,256,0,3899,512]

theorem envBound36397 : H12AffineFastState.Bounded env36397 := by
  intro p hp
  have h : env36397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36396_36397 : H12AffineEnvironment.transform 11 2587 env36396 = env36397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2587 env36396 == env36397) = true)

theorem identity36397 : scanCanonicalize (H12AffineFastState.compose env36397 (packedSelected [0,1,3,4,12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36397 : packedSelected [0,1,3,4,12] rootPS < 2^1333 := by decide +kernel

def env36398 : List Nat := [2,4,8,16,0,16,9,256,512,1024,2048,2587,268,3867,0,262,3850,2308,1024,1,2570,0,16,2,269,17,2048,3851,2587,2308,1284,0,256,0,3867,512]

theorem envBound36398 : H12AffineFastState.Bounded env36398 := by
  intro p hp
  have h : env36398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36397_36398 : H12AffineEnvironment.transform 4 0 env36397 = env36398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36397 == env36398) = true)

theorem identity36398 : scanCanonicalize (H12AffineFastState.compose env36398 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound36398 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36399 : List Nat := [2,4,8,16,0,16,9,21,512,1024,2048,2587,25,3598,0,19,3615,2065,1024,1,2570,0,16,2,24,17,2048,3614,2587,2065,1041,0,21,0,3598,512]

theorem envBound36399 : H12AffineFastState.Bounded env36399 := by
  intro p hp
  have h : env36399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36398_36399 : H12AffineEnvironment.transform 7 21 env36398 = env36399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env36398 == env36399) = true)

theorem identity36399 : scanCanonicalize (H12AffineFastState.compose env36399 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound36399 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36400 : List Nat := [2,4,8,16,0,16,9,21,512,1024,10,529,25,1540,0,19,1557,27,1024,1,512,0,16,2,24,17,10,1556,529,27,1041,0,21,0,1540,512]

theorem envBound36400 : H12AffineFastState.Bounded env36400 := by
  intro p hp
  have h : env36400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36399_36400 : H12AffineEnvironment.transform 10 10 env36399 = env36400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env36399 == env36400) = true)

theorem identity36400 : scanCanonicalize (H12AffineFastState.compose env36400 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound36400 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36401 : List Nat := [2,4,3,16,0,16,2,21,512,1024,1,529,18,1540,0,19,1557,16,1024,1,512,0,16,2,19,17,1,1556,529,16,1041,0,21,0,1540,512]

theorem envBound36401 : H12AffineFastState.Bounded env36401 := by
  intro p hp
  have h : env36401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36400_36401 : H12AffineEnvironment.transform 2 3 env36400 = env36401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env36400 == env36401) = true)

theorem identity36401 : scanCanonicalize (H12AffineFastState.compose env36401 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound36401 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env36402 : List Nat := [2,4,3,16,0,16,2,21,512,5,1,529,18,513,0,19,528,16,5,1,512,0,16,2,19,17,1,529,529,16,20,0,21,0,513,512]

theorem envBound36402 : H12AffineFastState.Bounded env36402 := by
  intro p hp
  have h : env36402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36401_36402 : H12AffineEnvironment.transform 9 5 env36401 = env36402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env36401 == env36402) = true)

theorem identity36402 : scanCanonicalize (H12AffineFastState.compose env36402 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound36402 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36403 : List Nat := [2,4,3,16,0,16,2,21,7,5,1,22,18,6,0,19,23,16,5,1,7,0,16,2,19,17,1,22,22,16,20,0,21,0,6,7]

theorem envBound36403 : H12AffineFastState.Bounded env36403 := by
  intro p hp
  have h : env36403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36402_36403 : H12AffineEnvironment.transform 8 7 env36402 = env36403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env36402 == env36403) = true)

theorem identity36403 : scanCanonicalize (H12AffineFastState.compose env36403 (packedSelected [0,7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound36403 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env36404 : List Nat := [2,2,3,16,0,16,2,19,1,3,1,16,18,0,0,19,17,16,3,1,1,0,16,2,19,17,1,16,16,16,18,0,19,0,0,1]

theorem envBound36404 : H12AffineFastState.Bounded env36404 := by
  intro p hp
  have h : env36404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36403_36404 : H12AffineEnvironment.transform 1 2 env36403 = env36404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env36403 == env36404) = true)

theorem identity36404 : scanCanonicalize (H12AffineFastState.compose env36404 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound36404 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36405 : List Nat := [2,2,3,3,0,3,2,0,1,3,1,3,1,0,0,0,2,3,3,1,1,0,3,2,0,2,1,3,3,3,1,0,0,0,0,1]

theorem envBound36405 : H12AffineFastState.Bounded env36405 := by
  intro p hp
  have h : env36405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36404_36405 : H12AffineEnvironment.transform 3 3 env36404 = env36405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env36404 == env36405) = true)

theorem identity36405 : scanCanonicalize (H12AffineFastState.compose env36405 (packedSelected [9] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound36405 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env36406 : List Nat := [0,0,1,1,0,1,0,0,1,1,1,1,1,0,0,0,0,1,1,1,1,0,1,0,0,0,1,1,1,1,1,0,0,0,0,1]

theorem envBound36406 : H12AffineFastState.Bounded env36406 := by
  intro p hp
  have h : env36406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36405_36406 : H12AffineEnvironment.transform 0 0 env36405 = env36406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env36405 == env36406) = true)

def env36407 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180409,509987,16777216,8328,65,16959643,18973836,2596210,67618,17189939,19113337,256,19270799,19328298,17263588]

theorem envBound36407 : H12AffineFastState.Bounded env36407 := by
  intro p hp
  have h : env36407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36262_36407 : H12AffineEnvironment.transform 21 180409 env36262 = env36407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180409 env36262 == env36407) = true)

def env36408 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180409,509987,498992,8328,65,349611,2496956,2596210,67618,119043,2373705,256,2199999,2191386,63188]

theorem envBound36408 : H12AffineFastState.Bounded env36408 := by
  intro p hp
  have h : env36408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36407_36408 : H12AffineEnvironment.transform 23 498992 env36407 = env36408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 498992 env36407 == env36408) = true)

def env36409 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180409,509987,498992,8328,65,349611,395772,494898,67618,119043,272393,256,98815,90202,63188]

theorem envBound36409 : H12AffineFastState.Bounded env36409 := by
  intro p hp
  have h : env36409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36408_36409 : H12AffineEnvironment.transform 20 4160 env36408 = env36409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env36408 == env36409) = true)

theorem identity36409 : scanCanonicalize (H12AffineFastState.compose env36409 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212198) := by decide +kernel

theorem selectedBound36409 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36410 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212198,1024,32769,4160,180409,62661,41430,8328,65,158029,79130,45524,67618,119043,201967,256,98815,90202,63188]

theorem envBound36410 : H12AffineFastState.Bounded env36410 := by
  intro p hp
  have h : env36410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36409_36410 : H12AffineEnvironment.transform 17 212198 env36409 = env36410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212198 env36409 == env36410) = true)

theorem identity36410 : scanCanonicalize (H12AffineFastState.compose env36410 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound36410 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env36411 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,212198,1024,29908,4160,144492,16,21763,8328,65,158029,79130,17665,67618,75222,201967,256,95530,90202,513]

theorem envBound36411 : H12AffineFastState.Bounded env36411 := by
  intro p hp
  have h : env36411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36410_36411 : H12AffineEnvironment.transform 14 29909 env36410 = env36411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env36410 == env36411) = true)

theorem identity36411 : scanCanonicalize (H12AffineFastState.compose env36411 (packedSelected [4,9,11,14,18,20,23,32] rootPS)) = affineNative (2^(16+1) ^^^ 79250) := by decide +kernel

theorem selectedBound36411 : packedSelected [4,9,11,14,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env36412 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,79250,2420,1024,29908,4160,66046,16,21763,8328,65,89311,79130,17665,67618,75222,8573,256,95530,90202,513]

theorem envBound36412 : H12AffineFastState.Bounded env36412 := by
  intro p hp
  have h : env36412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36411_36412 : H12AffineEnvironment.transform 16 79250 env36411 = env36412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79250 env36411 == env36412) = true)

theorem identity36412 : scanCanonicalize (H12AffineFastState.compose env36412 (packedSelected [0,7,9,14,17,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound36412 : packedSelected [0,7,9,14,17,20,22] rootPS < 2^1333 := by decide +kernel

def env36413 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,21897,65536,70862,2420,1024,21896,4160,66046,16,21763,468,65,89311,70726,17665,67618,66698,33,256,87158,82182,513]

theorem envBound36413 : H12AffineFastState.Bounded env36413 := by
  intro p hp
  have h : env36413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36412_36413 : H12AffineEnvironment.transform 12 348 env36412 = env36413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env36412 == env36413) = true)

theorem identity36413 : scanCanonicalize (H12AffineFastState.compose env36413 (packedSelected [1,8,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 21726) := by decide +kernel

theorem selectedBound36413 : packedSelected [1,8,17,19] rootPS < 2^1333 := by decide +kernel

def env36414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,21897,21726,16400,2420,1024,21896,4160,21792,16,21763,468,65,2049,16536,17665,23804,20564,33,256,168,5592,513]

theorem envBound36414 : H12AffineFastState.Bounded env36414 := by
  intro p hp
  have h : env36414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36413_36414 : H12AffineEnvironment.transform 15 21726 env36413 = env36414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21726 env36413 == env36414) = true)

theorem identity36414 : scanCanonicalize (H12AffineFastState.compose env36414 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5592) := by decide +kernel

theorem selectedBound36414 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env36415 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5592,81,262,5576,2420,1024,80,4160,248,16,219,468,65,2049,5440,4313,2340,1420,33,256,168,5592,513]

theorem envBound36415 : H12AffineFastState.Bounded env36415 := by
  intro p hp
  have h : env36415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36414_36415 : H12AffineEnvironment.transform 13 5592 env36414 = env36415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5592 env36414 == env36415) = true)

theorem identity36415 : scanCanonicalize (H12AffineFastState.compose env36415 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36415 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36416 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5512,1,262,5528,2340,1024,0,4112,168,16,139,388,17,2049,5392,4233,2340,1420,33,256,168,5512,513]

theorem envBound36416 : H12AffineFastState.Bounded env36416 := by
  intro p hp
  have h : env36416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36415_36416 : H12AffineEnvironment.transform 5 16 env36415 = env36416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36415 == env36416) = true)

theorem identity36416 : scanCanonicalize (H12AffineFastState.compose env36416 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1442) := by decide +kernel

theorem selectedBound36416 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env36417 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1442,4096,268,5512,1,262,5528,1158,1024,0,4112,168,16,139,388,17,1443,5392,4233,1158,1420,33,256,168,5512,513]

theorem envBound36417 : H12AffineFastState.Bounded env36417 := by
  intro p hp
  have h : env36417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36416_36417 : H12AffineEnvironment.transform 10 1442 env36416 = env36417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1442 env36416 == env36417) = true)

theorem identity36417 : scanCanonicalize (H12AffineFastState.compose env36417 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound36417 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env36418 : List Nat := [2,4,8,16,32,16,128,256,512,53,407,4096,268,4541,1,262,4525,179,53,0,4112,168,16,139,388,17,406,4389,4233,179,441,33,256,168,4541,513]

theorem envBound36418 : H12AffineFastState.Bounded env36418 := by
  intro p hp
  have h : env36418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36417_36418 : H12AffineEnvironment.transform 9 53 env36417 = env36418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env36417 == env36418) = true)

theorem identity36418 : scanCanonicalize (H12AffineFastState.compose env36418 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 169) := by decide +kernel

theorem selectedBound36418 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36419 : List Nat := [2,4,8,16,32,16,128,256,512,53,407,169,268,276,1,262,260,179,53,0,185,168,16,139,388,17,406,396,32,179,441,33,256,168,276,513]

theorem envBound36419 : H12AffineFastState.Bounded env36419 := by
  intro p hp
  have h : env36419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36418_36419 : H12AffineEnvironment.transform 11 169 env36418 = env36419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 169 env36418 == env36419) = true)

theorem identity36419 : scanCanonicalize (H12AffineFastState.compose env36419 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound36419 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env36420 : List Nat := [2,4,8,10,32,10,128,256,512,47,397,169,268,270,1,262,260,169,47,0,163,168,10,139,388,11,396,396,32,169,419,33,256,168,270,513]

theorem envBound36420 : H12AffineFastState.Bounded env36420 := by
  intro p hp
  have h : env36420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36419_36420 : H12AffineEnvironment.transform 3 10 env36419 = env36420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env36419 == env36420) = true)

theorem identity36420 : scanCanonicalize (H12AffineFastState.compose env36420 (packedSelected [1,2,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound36420 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env36421 : List Nat := [2,4,2,0,32,0,128,256,512,37,391,163,262,260,1,262,260,163,37,0,163,162,0,129,388,1,390,390,32,163,419,33,256,162,260,513]

theorem envBound36421 : H12AffineFastState.Bounded env36421 := by
  intro p hp
  have h : env36421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36420_36421 : H12AffineEnvironment.transform 2 2 env36420 = env36421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env36420 == env36421) = true)

theorem identity36421 : scanCanonicalize (H12AffineFastState.compose env36421 (packedSelected [0,2,9] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound36421 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env36422 : List Nat := [2,4,2,0,32,0,2,256,512,37,261,33,262,260,1,262,260,33,37,0,33,32,0,3,262,1,260,260,32,33,289,33,256,32,260,513]

theorem envBound36422 : H12AffineFastState.Bounded env36422 := by
  intro p hp
  have h : env36422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36421_36422 : H12AffineEnvironment.transform 6 2 env36421 = env36422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env36421 == env36422) = true)

theorem identity36422 : scanCanonicalize (H12AffineFastState.compose env36422 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound36422 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env36423 : List Nat := [2,4,2,0,32,0,2,256,7,37,261,33,262,260,1,262,260,33,37,0,33,32,0,3,262,1,260,260,32,33,289,33,256,32,260,6]

theorem envBound36423 : H12AffineFastState.Bounded env36423 := by
  intro p hp
  have h : env36423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36422_36423 : H12AffineEnvironment.transform 8 7 env36422 = env36423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env36422 == env36423) = true)

def env36424 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180409,509987,498992,8328,65,349611,395773,494899,67618,119043,272392,256,98814,90203,63188]

theorem envBound36424 : H12AffineFastState.Bounded env36424 := by
  intro p hp
  have h : env36424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36408_36424 : H12AffineEnvironment.transform 20 4161 env36408 = env36424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env36408 == env36424) = true)

theorem identity36424 : scanCanonicalize (H12AffineFastState.compose env36424 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound36424 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36425 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,4161,180409,400636,412143,8328,65,295284,395773,416236,56573,1500,272392,256,21793,46212,63188]

theorem envBound36425 : H12AffineFastState.Bounded env36425 := by
  intro p hp
  have h : env36425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36424_36425 : H12AffineEnvironment.transform 15 54495 env36424 = env36425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env36424 == env36425) = true)

def env36426 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4161,180273,400500,412007,8192,65,295284,395637,416100,56437,1364,272392,256,21793,46092,63068]

theorem envBound36426 : H12AffineFastState.Bounded env36426 := by
  intro p hp
  have h : env36426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36425_36426 : H12AffineEnvironment.transform 6 8 env36425 = env36426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36425 == env36426) = true)

theorem identity36426 : scanCanonicalize (H12AffineFastState.compose env36426 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound36426 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env36427 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,343,131072,262144,1024,21761,4161,136497,400500,412007,8192,65,283764,395637,416100,2421,1364,272392,256,21793,24844,9052]

theorem envBound36427 : H12AffineFastState.Bounded env36427 := by
  intro p hp
  have h : env36427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36426_36427 : H12AffineEnvironment.transform 14 21760 env36426 = env36427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env36426 == env36427) = true)

theorem identity36427 : scanCanonicalize (H12AffineFastState.compose env36427 (packedSelected [1,3,5,8,10,17,18,19,23] rootPS)) = affineNative (2^(17+1) ^^^ 146745) := by decide +kernel

theorem selectedBound36427 : packedSelected [1,3,5,8,10,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env36428 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,343,131072,146745,1024,21761,4161,136497,8525,29790,8192,65,158029,13388,25693,2421,1364,136497,256,21793,24844,9052]

theorem envBound36428 : H12AffineFastState.Bounded env36428 := by
  intro p hp
  have h : env36428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36427_36428 : H12AffineEnvironment.transform 17 146745 env36427 = env36428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146745 env36427 == env36428) = true)

theorem identity36428 : scanCanonicalize (H12AffineFastState.compose env36428 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound36428 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env36429 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,343,24909,23668,1024,21761,4161,29820,8525,29790,8192,65,2048,13388,25693,2421,1364,29820,256,21793,24844,9052]

theorem envBound36429 : H12AffineFastState.Bounded env36429 := by
  intro p hp
  have h : env36429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36428_36429 : H12AffineEnvironment.transform 16 24909 env36428 = env36429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env36428 == env36429) = true)

theorem identity36429 : scanCanonicalize (H12AffineFastState.compose env36429 (packedSelected [6,11,14,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound36429 : packedSelected [6,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env36430 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,8232,343,5221,10588,1024,8233,4161,340,8525,374,8192,65,2048,13388,4469,2421,1364,340,256,8201,5156,9052]

theorem envBound36430 : H12AffineFastState.Bounded env36430 := by
  intro p hp
  have h : env36430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36429_36430 : H12AffineEnvironment.transform 13 13608 env36429 = env36430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env36429 == env36430) = true)

theorem identity36430 : scanCanonicalize (H12AffineFastState.compose env36430 (packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound36430 : packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env36431 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,13405,8232,34,5221,10281,1024,8233,4161,33,8248,3,8192,65,2048,13388,4096,2048,1057,33,117,8201,5156,8745]

theorem envBound36431 : H12AffineFastState.Bounded env36431 := by
  intro p hp
  have h : env36431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36430_36431 : H12AffineEnvironment.transform 7 117 env36430 = env36431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env36430 == env36431) = true)

theorem identity36431 : scanCanonicalize (H12AffineFastState.compose env36431 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound36431 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36432 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,1100,4113,1124,34,5221,3173,1024,1125,4161,33,1140,3,1100,65,2048,4096,4096,2048,1057,33,117,1093,5156,1637]

theorem envBound36432 : H12AffineFastState.Bounded env36432 := by
  intro p hp
  have h : env36432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36431_36432 : H12AffineEnvironment.transform 12 1100 env36431 = env36432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env36431 == env36432) = true)

theorem identity36432 : scanCanonicalize (H12AffineFastState.compose env36432 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound36432 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env36433 : List Nat := [2,4,8,16,32,64,8,117,512,101,2048,4096,41,4113,1,34,4096,2048,101,0,4161,33,17,3,41,65,2048,4096,4096,2048,68,33,117,32,4161,512]

theorem envBound36433 : H12AffineFastState.Bounded env36433 := by
  intro p hp
  have h : env36433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36432_36433 : H12AffineEnvironment.transform 9 101 env36432 = env36433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env36432 == env36433) = true)

theorem identity36433 : scanCanonicalize (H12AffineFastState.compose env36433 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36433 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36434 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,4096,41,4113,1,34,4096,2048,53,0,4113,33,17,3,41,17,2048,4096,4096,2048,20,33,37,32,4113,512]

theorem envBound36434 : H12AffineFastState.Bounded env36434 := by
  intro p hp
  have h : env36434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36433_36434 : H12AffineEnvironment.transform 5 16 env36433 = env36434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36433 == env36434) = true)

theorem identity36434 : scanCanonicalize (H12AffineFastState.compose env36434 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound36434 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36435 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,2064,41,2049,1,34,2064,2048,53,0,2049,33,17,3,41,17,2048,2064,2064,2048,20,33,37,32,2049,512]

theorem envBound36435 : H12AffineFastState.Bounded env36435 := by
  intro p hp
  have h : env36435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36434_36435 : H12AffineEnvironment.transform 11 2064 env36434 = env36435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env36434 == env36435) = true)

theorem identity36435 : scanCanonicalize (H12AffineFastState.compose env36435 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound36435 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36436 : List Nat := [2,4,8,16,14,16,8,11,512,27,2048,2064,7,2049,1,12,2064,2048,27,0,2049,15,17,3,7,17,2048,2064,2064,2048,20,15,11,14,2049,512]

theorem envBound36436 : H12AffineFastState.Bounded env36436 := by
  intro p hp
  have h : env36436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36435_36436 : H12AffineEnvironment.transform 4 14 env36435 = env36436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env36435 == env36436) = true)

theorem identity36436 : scanCanonicalize (H12AffineFastState.compose env36436 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound36436 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env36437 : List Nat := [2,4,7,16,1,16,7,4,512,20,2048,2064,7,2049,1,3,2064,2048,20,0,2049,0,17,3,7,17,2048,2064,2064,2048,20,0,4,1,2049,512]

theorem envBound36437 : H12AffineFastState.Bounded env36437 := by
  intro p hp
  have h : env36437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36436_36437 : H12AffineEnvironment.transform 2 7 env36436 = env36437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env36436 == env36437) = true)

theorem identity36437 : scanCanonicalize (H12AffineFastState.compose env36437 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound36437 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env36438 : List Nat := [2,4,7,16,1,16,7,4,512,20,513,529,7,512,1,3,529,513,20,0,512,0,17,3,7,17,513,529,529,513,20,0,4,1,512,512]

theorem envBound36438 : H12AffineFastState.Bounded env36438 := by
  intro p hp
  have h : env36438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36437_36438 : H12AffineEnvironment.transform 10 513 env36437 = env36438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env36437 == env36438) = true)

theorem identity36438 : scanCanonicalize (H12AffineFastState.compose env36438 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound36438 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env36439 : List Nat := [2,4,7,1,1,1,7,4,512,5,513,512,7,512,1,3,512,513,5,0,512,0,0,3,7,0,513,512,512,513,5,0,4,1,512,512]

theorem envBound36439 : H12AffineFastState.Bounded env36439 := by
  intro p hp
  have h : env36439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36438_36439 : H12AffineEnvironment.transform 3 1 env36438 = env36439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env36438 == env36439) = true)

def env36440 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4161,180272,400501,412006,8193,65,295284,395636,416101,56436,1365,272392,256,21793,46093,63069]

theorem envBound36440 : H12AffineFastState.Bounded env36440 := by
  intro p hp
  have h : env36440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36425_36440 : H12AffineEnvironment.transform 6 9 env36425 = env36440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36425 == env36440) = true)

theorem identity36440 : scanCanonicalize (H12AffineFastState.compose env36440 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(16+1) ^^^ 16692) := by decide +kernel

theorem selectedBound36440 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env36441 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,16692,262144,1024,32769,4161,33028,286017,264274,8193,65,295284,280640,268369,56436,1365,272392,256,21793,46093,63069]

theorem envBound36441 : H12AffineFastState.Bounded env36441 := by
  intro p hp
  have h : env36441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36440_36441 : H12AffineEnvironment.transform 16 16692 env36440 = env36441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16692 env36440 == env36441) = true)

theorem identity36441 : scanCanonicalize (H12AffineFastState.compose env36441 (packedSelected [0,3,4,7,10,11,16,20,22,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound36441 : packedSelected [0,3,4,7,10,11,16,20,22,24,26,32] rootPS < 2^1333 := by decide +kernel

def env36442 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8460,30042,16692,262144,1024,8461,4161,8200,286017,264274,8193,65,270456,280640,268369,32120,1365,272392,256,21793,5377,22353]

theorem envBound36442 : H12AffineFastState.Bounded env36442 := by
  intro p hp
  have h : env36442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36441_36442 : H12AffineEnvironment.transform 14 8460 env36441 = env36442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env36441 == env36442) = true)

theorem identity36442 : scanCanonicalize (H12AffineFastState.compose env36442 (packedSelected [1,3,8,10,12,15,18,19,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound36442 : packedSelected [1,3,8,10,12,15,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env36443 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8460,8283,5173,262144,1024,8461,4161,8200,264256,264274,8193,65,270456,269633,268369,10361,1365,272392,256,32,5377,592]

theorem envBound36443 : H12AffineFastState.Bounded env36443 := by
  intro p hp
  have h : env36443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36442_36443 : H12AffineEnvironment.transform 13 5377 env36442 = env36443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env36442 == env36443) = true)

theorem identity36443 : scanCanonicalize (H12AffineFastState.compose env36443 (packedSelected [0,2,4,6,7,9,11,14,16,17,18,20] rootPS)) = affineNative (2^(17+1) ^^^ 10508) := by decide +kernel

theorem selectedBound36443 : packedSelected [0,2,4,6,7,9,11,14,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env36444 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8460,8283,5173,10508,1024,8461,4161,8200,8524,8542,8193,65,2420,13389,12637,10361,1365,260,256,32,5377,592]

theorem envBound36444 : H12AffineFastState.Bounded env36444 := by
  intro p hp
  have h : env36444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36443_36444 : H12AffineEnvironment.transform 17 10508 env36443 = env36444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10508 env36443 == env36444) = true)

theorem identity36444 : scanCanonicalize (H12AffineFastState.compose env36444 (packedSelected [3,5,10,12,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound36444 : packedSelected [3,5,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env36445 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,5156,8233,8283,5173,10281,1024,8232,4161,8200,8297,8315,8193,65,2129,13389,12408,10361,1136,33,37,32,5156,592]

theorem envBound36445 : H12AffineFastState.Bounded env36445 := by
  intro p hp
  have h : env36445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36444_36445 : H12AffineEnvironment.transform 7 37 env36444 = env36445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env36444 == env36445) = true)

theorem identity36445 : scanCanonicalize (H12AffineFastState.compose env36445 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound36445 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36446 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,1100,5156,1125,1047,5173,3173,1024,1124,4161,1092,1061,1079,1101,65,2129,4097,5172,3125,1136,33,37,32,5156,592]

theorem envBound36446 : H12AffineFastState.Bounded env36446 := by
  intro p hp
  have h : env36446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36445_36446 : H12AffineEnvironment.transform 12 1100 env36445 = env36446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env36445 == env36446) = true)

theorem identity36446 : scanCanonicalize (H12AffineFastState.compose env36446 (packedSelected [2,6,11] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound36446 : packedSelected [2,6,11] rootPS < 2^1333 := by decide +kernel

def env36447 : List Nat := [2,4,8,16,32,64,9,37,512,100,2048,4096,40,4160,1,115,4177,2049,100,0,4161,32,65,83,41,65,2129,4097,4176,2129,20,33,37,32,4160,592]

theorem envBound36447 : H12AffineFastState.Bounded env36447 := by
  intro p hp
  have h : env36447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36446_36447 : H12AffineEnvironment.transform 9 100 env36446 = env36447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env36446 == env36447) = true)

theorem identity36447 : scanCanonicalize (H12AffineFastState.compose env36447 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound36447 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env36448 : List Nat := [2,4,8,16,32,64,9,37,512,100,2048,65,40,1,1,115,16,2049,100,0,0,32,65,83,41,65,2129,64,17,2129,20,33,37,32,1,592]

theorem envBound36448 : H12AffineFastState.Bounded env36448 := by
  intro p hp
  have h : env36448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36447_36448 : H12AffineEnvironment.transform 11 65 env36447 = env36448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env36447 == env36448) = true)

theorem identity36448 : scanCanonicalize (H12AffineFastState.compose env36448 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36448 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36449 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,16,40,1,1,34,16,2049,53,0,0,32,16,2,41,16,2048,17,17,2048,20,33,37,32,1,513]

theorem envBound36449 : H12AffineFastState.Bounded env36449 := by
  intro p hp
  have h : env36449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36448_36449 : H12AffineEnvironment.transform 5 17 env36448 = env36449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36448 == env36449) = true)

theorem identity36449 : scanCanonicalize (H12AffineFastState.compose env36449 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound36449 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36450 : List Nat := [2,4,8,16,32,17,9,37,512,53,32,16,40,1,1,34,16,33,53,0,0,32,16,2,41,16,32,17,17,32,20,33,37,32,1,513]

theorem envBound36450 : H12AffineFastState.Bounded env36450 := by
  intro p hp
  have h : env36450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36449_36450 : H12AffineEnvironment.transform 10 32 env36449 = env36450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env36449 == env36450) = true)

theorem identity36450 : scanCanonicalize (H12AffineFastState.compose env36450 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound36450 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36451 : List Nat := [2,4,8,1,32,0,9,37,512,36,32,1,40,1,1,34,1,33,36,0,0,32,1,2,41,1,32,0,0,32,5,33,37,32,1,513]

theorem envBound36451 : H12AffineFastState.Bounded env36451 := by
  intro p hp
  have h : env36451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36450_36451 : H12AffineEnvironment.transform 3 1 env36450 = env36451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env36450 == env36451) = true)

def env36452 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180409,509987,498993,8328,65,349610,2496957,2596210,67618,119042,2373704,256,2199998,2191387,63189]

theorem envBound36452 : H12AffineFastState.Bounded env36452 := by
  intro p hp
  have h : env36452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36407_36452 : H12AffineEnvironment.transform 23 498993 env36407 = env36452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 498993 env36407 == env36452) = true)

def env36453 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180409,509987,498993,8328,65,349610,395773,494898,67618,119042,272392,256,98814,90203,63189]

theorem envBound36453 : H12AffineFastState.Bounded env36453 := by
  intro p hp
  have h : env36453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36452_36453 : H12AffineEnvironment.transform 20 4160 env36452 = env36453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env36452 == env36453) = true)

theorem identity36453 : scanCanonicalize (H12AffineFastState.compose env36453 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound36453 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36454 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,4160,180409,452649,441659,8328,65,292256,395773,437560,10280,61704,272392,256,41460,16465,63189]

theorem envBound36454 : H12AffineFastState.Bounded env36454 := by
  intro p hp
  have h : env36454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36453_36454 : H12AffineEnvironment.transform 15 8202 env36453 = env36454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env36453 == env36454) = true)

def env36455 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,16384,32768,250,131072,262144,1024,32769,4160,180409,444633,433611,120,65,283984,395773,429512,2264,53752,264440,256,33028,16465,54821]

theorem envBound36455 : H12AffineFastState.Bounded env36455 := by
  intro p hp
  have h : env36455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36454_36455 : H12AffineEnvironment.transform 12 240 env36454 = env36455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env36454 == env36455) = true)

theorem identity36455 : scanCanonicalize (H12AffineFastState.compose env36455 (packedSelected [7,8,10,11,12,14,15,17,20,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 182337) := by decide +kernel

theorem selectedBound36455 : packedSelected [7,8,10,11,12,14,15,17,20,27,28,32] rootPS < 2^1333 := by decide +kernel

def env36456 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,16384,32768,250,131072,182337,1024,32769,4160,180409,152,21898,120,65,171281,49596,17801,2264,53752,180409,256,33028,16465,54821]

theorem envBound36456 : H12AffineFastState.Bounded env36456 := by
  intro p hp
  have h : env36456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36455_36456 : H12AffineEnvironment.transform 17 182337 env36455 = env36456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182337 env36455 == env36456) = true)

theorem identity36456 : scanCanonicalize (H12AffineFastState.compose env36456 (packedSelected [0,2,6,8,11,12,14,16,19,20,23,26,27,28,31,38] rootPS)) = affineNative (2^(14+1) ^^^ 21896) := by decide +kernel

theorem selectedBound36456 : packedSelected [0,2,6,8,11,12,14,16,19,20,23,26,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env36457 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,16384,21896,250,131072,138697,1024,21897,4160,136497,152,21898,120,65,149657,5172,17801,2264,1136,136497,256,21644,16465,941]

theorem envBound36457 : H12AffineFastState.Bounded env36457 := by
  intro p hp
  have h : env36457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36456_36457 : H12AffineEnvironment.transform 14 21896 env36456 = env36457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21896 env36456 == env36457) = true)

theorem identity36457 : scanCanonicalize (H12AffineFastState.compose env36457 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5309) := by decide +kernel

theorem selectedBound36457 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env36458 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,16384,21896,250,5309,2420,1024,21897,4160,396,152,21898,120,65,23588,5172,17801,2264,1136,396,256,21644,16465,941]

theorem envBound36458 : H12AffineFastState.Bounded env36458 := by
  intro p hp
  have h : env36458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36457_36458 : H12AffineEnvironment.transform 16 5309 env36457 = env36458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5309 env36457 == env36458) = true)

theorem identity36458 : scanCanonicalize (H12AffineFastState.compose env36458 (packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound36458 : packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env36459 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,240,16384,21540,250,5309,2264,1024,21541,4160,32,152,21542,120,65,23588,5172,17445,2264,1136,32,172,21644,16465,513]

theorem envBound36459 : H12AffineFastState.Bounded env36459 := by
  intro p hp
  have h : env36459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36458_36459 : H12AffineEnvironment.transform 7 172 env36458 = env36459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env36458 == env36459) = true)

theorem identity36459 : scanCanonicalize (H12AffineFastState.compose env36459 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5292) := by decide +kernel

theorem selectedBound36459 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36460 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,240,5292,136,250,5309,2264,1024,137,4160,32,152,138,120,65,2184,5172,4233,2264,1136,32,172,32,5373,513]

theorem envBound36460 : H12AffineFastState.Bounded env36460 := by
  intro p hp
  have h : env36460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36459_36460 : H12AffineEnvironment.transform 13 5292 env36459 = env36460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5292 env36459 == env36460) = true)

theorem identity36460 : scanCanonicalize (H12AffineFastState.compose env36460 (packedSelected [0,1,3,5,7,8,11,14] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound36460 : packedSelected [0,1,3,5,7,8,11,14] rootPS < 2^1333 := by decide +kernel

def env36461 : List Nat := [2,4,8,16,32,64,128,172,512,1024,136,4096,240,5292,136,250,5309,80,1024,137,4160,32,152,138,120,65,0,5172,4233,80,1136,32,172,32,5373,513]

theorem envBound36461 : H12AffineFastState.Bounded env36461 := by
  intro p hp
  have h : env36461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36460_36461 : H12AffineEnvironment.transform 10 136 env36460 = env36461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env36460 == env36461) = true)

theorem identity36461 : scanCanonicalize (H12AffineFastState.compose env36461 (packedSelected [0,3,4,5,7,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound36461 : packedSelected [0,3,4,5,7,9,11] rootPS < 2^1333 := by decide +kernel

def env36462 : List Nat := [2,4,8,16,32,64,128,172,512,237,136,4096,240,4161,136,250,4176,80,237,137,4160,32,152,138,120,65,0,4313,4233,80,157,32,172,32,4112,513]

theorem envBound36462 : H12AffineFastState.Bounded env36462 := by
  intro p hp
  have h : env36462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36461_36462 : H12AffineEnvironment.transform 9 237 env36461 = env36462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env36461 == env36462) = true)

theorem identity36462 : scanCanonicalize (H12AffineFastState.compose env36462 (packedSelected [4,9] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound36462 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env36463 : List Nat := [2,4,8,16,32,64,128,172,512,237,136,65,240,0,136,250,17,80,237,137,1,32,152,138,120,65,0,152,200,80,157,32,172,32,81,513]

theorem envBound36463 : H12AffineFastState.Bounded env36463 := by
  intro p hp
  have h : env36463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36462_36463 : H12AffineEnvironment.transform 11 65 env36462 = env36463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env36462 == env36463) = true)

def env36464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,16384,32768,251,131072,262144,1024,32769,4160,180409,444632,433610,121,65,283985,395773,429513,2265,53753,264441,256,33029,16465,54820]

theorem envBound36464 : H12AffineFastState.Bounded env36464 := by
  intro p hp
  have h : env36464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36454_36464 : H12AffineEnvironment.transform 12 241 env36454 = env36464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env36454 == env36464) = true)

theorem identity36464 : scanCanonicalize (H12AffineFastState.compose env36464 (packedSelected [7,8,10,11,12,14,15,17,20,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 182472) := by decide +kernel

theorem selectedBound36464 : packedSelected [7,8,10,11,12,14,15,17,20,27,28,32] rootPS < 2^1333 := by decide +kernel

def env36465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,16384,32768,251,131072,182472,1024,32769,4160,180409,16,21762,121,65,171417,49461,17665,2265,53753,180273,256,33029,16465,54820]

theorem envBound36465 : H12AffineFastState.Bounded env36465 := by
  intro p hp
  have h : env36465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36464_36465 : H12AffineEnvironment.transform 17 182472 env36464 = env36465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182472 env36464 == env36465) = true)

theorem identity36465 : scanCanonicalize (H12AffineFastState.compose env36465 (packedSelected [3,4,6,7,8,15,16,17,19,20,22,24,27,28,41] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound36465 : packedSelected [3,4,6,7,8,15,16,17,19,20,22,24,27,28,41] rootPS < 2^1333 := by decide +kernel

def env36466 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,241,16384,32768,251,131072,182472,1024,32769,4160,180409,16,21623,121,65,171244,49216,17524,2265,53388,180273,117,32880,16465,54820]

theorem envBound36466 : H12AffineFastState.Bounded env36466 := by
  intro p hp
  have h : env36466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36465_36466 : H12AffineEnvironment.transform 7 117 env36465 = env36466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env36465 == env36466) = true)

theorem identity36466 : scanCanonicalize (H12AffineFastState.compose env36466 (packedSelected [1,2,3,4,5,6,7,8,10,11,14,16,17,19,20,22,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 49353) := by decide +kernel

theorem selectedBound36466 : packedSelected [1,2,3,4,5,6,7,8,10,11,14,16,17,19,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env36467 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,241,16384,32768,251,49353,2049,1024,32769,4160,112,16,21623,121,65,23589,49216,17524,2265,53388,248,117,32880,16465,54820]

theorem envBound36467 : H12AffineFastState.Bounded env36467 := by
  intro p hp
  have h : env36467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36466_36467 : H12AffineEnvironment.transform 16 49353 env36466 = env36467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49353 env36466 == env36467) = true)

theorem identity36467 : scanCanonicalize (H12AffineFastState.compose env36467 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound36467 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env36468 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,241,16384,136,251,16449,2049,1024,137,4160,112,16,21623,121,65,23589,16584,17524,2265,20484,248,117,248,16465,22188]

theorem envBound36468 : H12AffineFastState.Bounded env36468 := by
  intro p hp
  have h : env36468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36467_36468 : H12AffineEnvironment.transform 14 136 env36467 = env36468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env36467 == env36468) = true)

theorem identity36468 : scanCanonicalize (H12AffineFastState.compose env36468 (packedSelected [3,5,6,10,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound36468 : packedSelected [3,5,6,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env36469 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,3109,241,16384,136,251,16449,2049,1024,137,3173,112,16,18514,121,65,16384,16584,17524,2265,19489,248,117,248,16465,19081]

theorem envBound36469 : H12AffineFastState.Bounded env36469 := by
  intro p hp
  have h : env36469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36468_36469 : H12AffineEnvironment.transform 11 3109 env36468 = env36469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env36468 == env36469) = true)

theorem identity36469 : scanCanonicalize (H12AffineFastState.compose env36469 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound36469 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env36470 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,3109,120,16384,1,114,16449,2049,1024,0,3173,112,16,18514,121,65,16384,16449,17524,2128,19489,113,117,113,16465,18944]

theorem envBound36470 : H12AffineFastState.Bounded env36470 := by
  intro p hp
  have h : env36470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36469_36470 : H12AffineEnvironment.transform 6 9 env36469 = env36470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36469 == env36470) = true)

theorem identity36470 : scanCanonicalize (H12AffineFastState.compose env36470 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36470 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env36471 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,3109,41,16384,1,35,16400,2049,1024,0,3124,33,16,18435,40,16,16384,16400,17445,2049,19489,32,36,32,16384,18944]

theorem envBound36471 : H12AffineFastState.Bounded env36471 := by
  intro p hp
  have h : env36471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36470_36471 : H12AffineEnvironment.transform 5 17 env36470 = env36471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36470 == env36471) = true)

theorem identity36471 : scanCanonicalize (H12AffineFastState.compose env36471 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 2049) := by decide +kernel

theorem selectedBound36471 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env36472 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,3109,41,2049,1,35,2065,2049,1024,0,3124,33,16,2,40,16,2049,2065,3108,2049,1056,32,36,32,2049,513]

theorem envBound36472 : H12AffineFastState.Bounded env36472 := by
  intro p hp
  have h : env36472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36471_36472 : H12AffineEnvironment.transform 13 2049 env36471 = env36472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2049 env36471 == env36472) = true)

theorem identity36472 : scanCanonicalize (H12AffineFastState.compose env36472 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound36472 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36473 : List Nat := [2,4,8,16,32,17,9,36,512,36,2048,2049,41,2049,1,35,2065,2049,36,0,2064,33,16,2,40,16,2049,2065,2048,2049,4,32,36,32,2049,513]

theorem envBound36473 : H12AffineFastState.Bounded env36473 := by
  intro p hp
  have h : env36473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36472_36473 : H12AffineEnvironment.transform 9 36 env36472 = env36473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env36472 == env36473) = true)

theorem identity36473 : scanCanonicalize (H12AffineFastState.compose env36473 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound36473 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36474 : List Nat := [2,4,8,11,32,10,9,36,512,36,2048,2049,41,2049,1,35,2058,2049,36,0,2059,33,11,2,40,11,2049,2058,2048,2049,4,32,36,32,2049,513]

theorem envBound36474 : H12AffineFastState.Bounded env36474 := by
  intro p hp
  have h : env36474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36473_36474 : H12AffineEnvironment.transform 3 11 env36473 = env36474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env36473 == env36474) = true)

theorem identity36474 : scanCanonicalize (H12AffineFastState.compose env36474 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound36474 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36475 : List Nat := [2,4,8,11,32,10,9,36,512,36,43,42,41,42,1,35,33,42,36,0,32,33,11,2,40,11,42,33,43,42,4,32,36,32,42,513]

theorem envBound36475 : H12AffineFastState.Bounded env36475 := by
  intro p hp
  have h : env36475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36474_36475 : H12AffineEnvironment.transform 10 43 env36474 = env36475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env36474 == env36475) = true)

theorem identity36475 : scanCanonicalize (H12AffineFastState.compose env36475 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 46) := by decide +kernel

theorem selectedBound36475 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36476 : List Nat := [2,4,8,11,32,10,9,36,46,36,43,42,41,42,1,35,33,42,36,0,32,33,11,2,40,11,42,33,43,42,4,32,36,32,42,47]

theorem envBound36476 : H12AffineFastState.Bounded env36476 := by
  intro p hp
  have h : env36476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36475_36476 : H12AffineEnvironment.transform 8 46 env36475 = env36476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 46 env36475 == env36476) = true)

theorem identity36476 : scanCanonicalize (H12AffineFastState.compose env36476 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound36476 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env36477 : List Nat := [2,4,3,0,32,1,2,36,37,36,32,33,34,33,1,35,33,33,36,0,32,33,0,2,35,0,33,33,32,33,4,32,36,32,33,36]

theorem envBound36477 : H12AffineFastState.Bounded env36477 := by
  intro p hp
  have h : env36477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36476_36477 : H12AffineEnvironment.transform 2 3 env36476 = env36477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env36476 == env36477) = true)

theorem identity36477 : scanCanonicalize (H12AffineFastState.compose env36477 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound36477 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36478 : List Nat := [2,4,3,0,2,1,2,6,7,6,2,3,0,3,1,1,3,3,6,0,2,3,0,2,1,0,3,3,2,3,4,2,6,2,3,6]

theorem envBound36478 : H12AffineFastState.Bounded env36478 := by
  intro p hp
  have h : env36478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36477_36478 : H12AffineEnvironment.transform 4 2 env36477 = env36478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env36477 == env36478) = true)

def env36479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180409,509987,498993,8328,65,349610,395772,494899,67618,119042,272393,256,98815,90202,63189]

theorem envBound36479 : H12AffineFastState.Bounded env36479 := by
  intro p hp
  have h : env36479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36452_36479 : H12AffineEnvironment.transform 20 4161 env36452 = env36479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env36452 == env36479) = true)

theorem identity36479 : scanCanonicalize (H12AffineFastState.compose env36479 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247859) := by decide +kernel

theorem selectedBound36479 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,180409,16,21762,8328,65,171417,115151,17664,67618,119042,254010,256,98815,90202,63189]

theorem envBound36480 : H12AffineFastState.Bounded env36480 := by
  intro p hp
  have h : env36480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36479_36480 : H12AffineEnvironment.transform 17 247859 env36479 = env36480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247859 env36479 == env36480) = true)

def env36481 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,180273,16,21762,8192,65,171281,115015,17664,67618,119042,254010,256,98679,90202,63069]

theorem envBound36481 : H12AffineFastState.Bounded env36481 := by
  intro p hp
  have h : env36481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36480_36481 : H12AffineEnvironment.transform 6 8 env36480 = env36481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36480 == env36481) = true)

theorem identity36481 : scanCanonicalize (H12AffineFastState.compose env36481 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound36481 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36482 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10280,1024,32769,4161,73770,16,21762,8192,65,97546,115015,17664,67618,119042,33,256,98679,90202,63069]

theorem envBound36482 : H12AffineFastState.Bounded env36482 := by
  intro p hp
  have h : env36482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36481_36482 : H12AffineEnvironment.transform 16 122907 env36481 = env36482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env36481 == env36482) = true)

theorem identity36482 : scanCanonicalize (H12AffineFastState.compose env36482 (packedSelected [2,4,5,6,7,8,10,11,12,14,15,18,19,22,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound36482 : packedSelected [2,4,5,6,7,8,10,11,12,14,15,18,19,22,24,27,28] rootPS < 2^1333 := by decide +kernel

def env36483 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21591,46156,10280,1024,32769,4161,29821,16,21762,8192,65,10589,38160,17664,23669,34133,33,256,54560,13325,63069]

theorem envBound36483 : H12AffineFastState.Bounded env36483 := by
  intro p hp
  have h : env36483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36482_36483 : H12AffineEnvironment.transform 15 21591 env36482 = env36483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env36482 == env36483) = true)

theorem identity36483 : scanCanonicalize (H12AffineFastState.compose env36483 (packedSelected [0,3,4,5,7,10,16,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound36483 : packedSelected [0,3,4,5,7,10,16,20,22] rootPS < 2^1333 := by decide +kernel

def env36484 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,8203,46156,10280,1024,32769,4161,33,16,8542,8192,65,10589,38160,12636,10281,34133,33,256,41340,13325,33281]

theorem envBound36484 : H12AffineFastState.Bounded env36484 := by
  intro p hp
  have h : env36484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36483_36484 : H12AffineEnvironment.transform 13 13404 env36483 = env36484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env36483 == env36484) = true)

theorem identity36484 : scanCanonicalize (H12AffineFastState.compose env36484 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36484 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env36485 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,32768,8203,46108,10280,1024,32769,4113,33,16,8462,8192,17,10509,38160,12556,10281,34053,33,256,41260,13325,33281]

theorem envBound36485 : H12AffineFastState.Bounded env36485 := by
  intro p hp
  have h : env36485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36484_36485 : H12AffineEnvironment.transform 5 16 env36484 = env36485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36484 == env36485) = true)

theorem identity36485 : scanCanonicalize (H12AffineFastState.compose env36485 (packedSelected [0,1,2,3,5,7,8,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 14620) := by decide +kernel

theorem selectedBound36485 : packedSelected [0,1,2,3,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env36486 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,14620,8203,3328,10280,1024,14621,4113,33,16,8462,8192,17,10509,11276,12556,10281,15385,33,256,6192,13325,15133]

theorem envBound36486 : H12AffineFastState.Bounded env36486 := by
  intro p hp
  have h : env36486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36485_36486 : H12AffineEnvironment.transform 14 14620 env36485 = env36486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14620 env36485 == env36486) = true)

theorem identity36486 : scanCanonicalize (H12AffineFastState.compose env36486 (packedSelected [1,2,3,4,6,9] rootPS)) = affineNative (2^(11+1) ^^^ 3840) := by decide +kernel

theorem selectedBound36486 : packedSelected [1,2,3,4,6,9] rootPS < 2^1333 := by decide +kernel

def env36487 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3840,8192,11020,9756,8203,3328,10280,1024,9757,3857,33,16,8462,8192,17,10509,11276,11788,10281,8985,33,256,1840,11021,9245]

theorem envBound36487 : H12AffineFastState.Bounded env36487 := by
  intro p hp
  have h : env36487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36486_36487 : H12AffineEnvironment.transform 11 3840 env36486 = env36487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3840 env36486 == env36487) = true)

theorem identity36487 : scanCanonicalize (H12AffineFastState.compose env36487 (packedSelected [4,5,7,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 1281) := by decide +kernel

theorem selectedBound36487 : packedSelected [4,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env36488 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1281,513,8192,9741,9756,8203,1,9513,1024,9757,528,33,16,8462,8192,17,9228,8461,8973,9512,8985,33,256,1840,9740,9245]

theorem envBound36488 : H12AffineFastState.Bounded env36488 := by
  intro p hp
  have h : env36488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36487_36488 : H12AffineEnvironment.transform 10 1281 env36487 = env36488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1281 env36487 == env36488) = true)

theorem identity36488 : scanCanonicalize (H12AffineFastState.compose env36488 (packedSelected [2,4,5,7,8,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound36488 : packedSelected [2,4,5,7,8,12,14] rootPS < 2^1333 := by decide +kernel

def env36489 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1281,513,268,1793,1808,263,1,1061,1024,1809,528,33,16,2,268,17,1280,1,513,1060,533,33,256,1840,1792,1297]

theorem envBound36489 : H12AffineFastState.Bounded env36489 := by
  intro p hp
  have h : env36489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36488_36489 : H12AffineEnvironment.transform 12 268 env36488 = env36489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env36488 == env36489) = true)

theorem identity36489 : scanCanonicalize (H12AffineFastState.compose env36489 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound36489 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env36490 : List Nat := [2,4,8,16,32,16,8,256,512,565,820,513,268,308,293,263,1,528,565,292,528,33,16,2,268,17,821,1,513,529,533,33,256,261,309,804]

theorem envBound36490 : H12AffineFastState.Bounded env36490 := by
  intro p hp
  have h : env36490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36489_36490 : H12AffineEnvironment.transform 9 565 env36489 = env36490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env36489 == env36490) = true)

def env36491 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,180272,16,21762,8193,65,171280,115014,17664,67618,119042,254010,256,98678,90202,63068]

theorem envBound36491 : H12AffineFastState.Bounded env36491 := by
  intro p hp
  have h : env36491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36480_36491 : H12AffineEnvironment.transform 6 9 env36480 = env36491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36480 == env36491) = true)

theorem identity36491 : scanCanonicalize (H12AffineFastState.compose env36491 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound36491 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36492 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,35188,1024,32769,4161,98679,16,21762,8193,65,121943,115014,17664,67618,119042,41341,256,98678,90202,63068]

theorem envBound36492 : H12AffineFastState.Bounded env36492 := by
  intro p hp
  have h : env36492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36491_36492 : H12AffineEnvironment.transform 16 82247 env36491 = env36492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env36491 == env36492) = true)

theorem identity36492 : scanCanonicalize (H12AffineFastState.compose env36492 (packedSelected [0,1,4,8,12,14,15,16,18,19,22,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 8312) := by decide +kernel

theorem selectedBound36492 : packedSelected [0,1,4,8,12,14,15,16,18,19,22,23,27] rootPS < 2^1333 := by decide +kernel

def env36493 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8312,65536,82247,10508,1024,8313,4161,73999,16,21762,8193,65,97327,90430,17664,67618,94586,261,256,73998,90202,22052]

theorem envBound36493 : H12AffineFastState.Bounded env36493 := by
  intro p hp
  have h : env36493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36492_36493 : H12AffineEnvironment.transform 14 8312 env36492 = env36493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8312 env36492 == env36493) = true)

theorem identity36493 : scanCanonicalize (H12AffineFastState.compose env36493 (packedSelected [0,1,2,3,4,7,8,10,11,12,14,15,19,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound36493 : packedSelected [0,1,2,3,4,7,8,10,11,12,14,15,19,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env36494 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8312,65536,70727,10508,1024,8313,4161,73999,16,2,8193,65,76079,78910,4096,67618,74874,261,256,73998,79194,804]

theorem envBound36494 : H12AffineFastState.Bounded env36494 := by
  intro p hp
  have h : env36494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36493_36494 : H12AffineEnvironment.transform 13 5376 env36493 = env36494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env36493 == env36494) = true)

theorem identity36494 : scanCanonicalize (H12AffineFastState.compose env36494 (packedSelected [0,1,2,7,8,10,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound36494 : packedSelected [0,1,2,7,8,10,15,18] rootPS < 2^1333 := by decide +kernel

def env36495 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5376,81,65536,70727,2341,1024,80,4161,65830,16,2,40,65,67846,70679,4096,67618,66643,261,256,65831,71027,804]

theorem envBound36495 : H12AffineFastState.Bounded env36495 := by
  intro p hp
  have h : env36495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36494_36495 : H12AffineEnvironment.transform 12 41 env36494 = env36495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env36494 == env36495) = true)

theorem identity36495 : scanCanonicalize (H12AffineFastState.compose env36495 (packedSelected [0,1,7,8,10,11,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound36495 : packedSelected [0,1,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env36496 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,41,5157,81,65536,70727,2048,1024,80,4161,65539,16,2,40,65,67619,70679,4096,67618,66643,32,37,65538,70742,513]

theorem envBound36496 : H12AffineFastState.Bounded env36496 := by
  intro p hp
  have h : env36496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36495_36496 : H12AffineEnvironment.transform 7 37 env36495 = env36496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env36495 == env36496) = true)

theorem identity36496 : scanCanonicalize (H12AffineFastState.compose env36496 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36496 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env36497 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,5157,0,65536,70678,2048,1024,1,4112,65539,16,2,40,16,67619,70679,4096,67618,66562,32,37,65538,70663,513]

theorem envBound36497 : H12AffineFastState.Bounded env36497 := by
  intro p hp
  have h : env36497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36496_36497 : H12AffineEnvironment.transform 5 17 env36496 = env36497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36496 == env36497) = true)

theorem identity36497 : scanCanonicalize (H12AffineFastState.compose env36497 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound36497 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36498 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,5157,0,35,5173,2048,1024,1,4112,32,16,2,40,16,2048,5172,4096,2049,1057,32,37,33,5156,513]

theorem envBound36498 : H12AffineFastState.Bounded env36498 := by
  intro p hp
  have h : env36498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36497_36498 : H12AffineEnvironment.transform 15 35 env36497 = env36498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env36497 == env36498) = true)

theorem identity36498 : scanCanonicalize (H12AffineFastState.compose env36498 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound36498 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36499 : List Nat := [2,4,8,1,32,0,9,37,512,1024,2048,4096,41,5157,0,35,5156,2048,1024,1,4097,32,1,2,40,1,2048,5157,4096,2049,1057,32,37,33,5156,513]

theorem envBound36499 : H12AffineFastState.Bounded env36499 := by
  intro p hp
  have h : env36499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36498_36499 : H12AffineEnvironment.transform 3 1 env36498 = env36499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env36498 == env36499) = true)

theorem identity36499 : scanCanonicalize (H12AffineFastState.compose env36499 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3119) := by decide +kernel

theorem selectedBound36499 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36500 : List Nat := [2,4,8,1,32,0,9,37,512,1024,2048,3119,41,2058,0,35,2059,2048,1024,1,3118,32,1,2,40,1,2048,2058,3119,2049,1057,32,37,33,2059,513]

theorem envBound36500 : H12AffineFastState.Bounded env36500 := by
  intro p hp
  have h : env36500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36499_36500 : H12AffineEnvironment.transform 11 3119 env36499 = env36500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3119 env36499 == env36500) = true)

theorem identity36500 : scanCanonicalize (H12AffineFastState.compose env36500 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1028) := by decide +kernel

theorem selectedBound36500 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36501 : List Nat := [2,4,8,1,32,0,9,37,512,1024,1028,43,41,1038,0,35,1039,1028,1024,1,42,32,1,2,40,1,1028,1038,43,1029,1057,32,37,33,1039,513]

theorem envBound36501 : H12AffineFastState.Bounded env36501 := by
  intro p hp
  have h : env36501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36500_36501 : H12AffineEnvironment.transform 10 1028 env36500 = env36501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1028 env36500 == env36501) = true)

def env36502 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830976,25265168,23160256,257,27378861,27337993,25207750]

theorem envBound36502 : H12AffineFastState.Bounded env36502 := by
  intro p hp
  have h : env36502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36260_36502 : H12AffineEnvironment.transform 18 1025 env36260 = env36502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env36260 == env36502) = true)

theorem identity36502 : scanCanonicalize (H12AffineFastState.compose env36502 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 272546) := by decide +kernel

theorem selectedBound36502 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env36503 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,272546,8328,65,12839074,2468911,10507601,8830976,8760498,6638946,257,10873871,10816939,8686436]

theorem envBound36503 : H12AffineFastState.Bounded env36503 := by
  intro p hp
  have h : env36503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36502_36503 : H12AffineEnvironment.transform 23 272546 env36502 = env36503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 272546 env36502 == env36503) = true)

def env36504 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,147592,272546,8328,65,4302890,2468911,2233817,295048,519226,6638946,257,2600071,2575651,445420]

theorem envBound36504 : H12AffineFastState.Bounded env36504 := by
  intro p hp
  have h : env36504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36503_36504 : H12AffineEnvironment.transform 22 147592 env36503 = env36504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147592 env36503 == env36504) = true)

def env36505 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,152,272546,8328,65,4302890,2468911,2119113,295048,371754,6638946,257,2485399,2428211,297980]

theorem envBound36505 : H12AffineFastState.Bounded env36505 := by
  intro p hp
  have h : env36505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36504_36505 : H12AffineEnvironment.transform 16 16400 env36504 = env36505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env36504 == env36505) = true)

def env36506 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,16,272426,8192,65,4302890,2468911,2118977,294912,371754,6638946,257,2485279,2428211,297844]

theorem envBound36506 : H12AffineFastState.Bounded env36506 := by
  intro p hp
  have h : env36506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36505_36506 : H12AffineEnvironment.transform 6 8 env36505 = env36506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36505 == env36506) = true)

theorem identity36506 : scanCanonicalize (H12AffineFastState.compose env36506 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound36506 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env36507 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,2097152,4194304,16,41311,8192,65,4302890,2172250,2118977,2421,75103,6407191,257,2188650,2196550,513]

theorem envBound36507 : H12AffineFastState.Bounded env36507 := by
  intro p hp
  have h : env36507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36506_36507 : H12AffineEnvironment.transform 17 35189 env36506 = env36507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env36506 == env36507) = true)

theorem identity36507 : scanCanonicalize (H12AffineFastState.compose env36507 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound36507 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env36508 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,35189,1025,32769,2097152,4194304,16,41311,8192,65,4229153,2098513,2118977,2421,1364,6349852,257,2114913,2139213,513]

theorem envBound36508 : H12AffineFastState.Bounded env36508 := by
  intro p hp
  have h : env36508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36507_36508 : H12AffineEnvironment.transform 15 8203 env36507 = env36508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env36507 == env36508) = true)

theorem identity36508 : scanCanonicalize (H12AffineFastState.compose env36508 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 41340) := by decide +kernel

theorem selectedBound36508 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36509 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,35189,1025,32769,2097152,41340,16,41311,8192,65,10589,2098513,2118977,2421,1364,2114912,257,2114913,2139213,513]

theorem envBound36509 : H12AffineFastState.Bounded env36509 := by
  intro p hp
  have h : env36509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36508_36509 : H12AffineEnvironment.transform 21 41340 env36508 = env36509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41340 env36508 == env36509) = true)

theorem identity36509 : scanCanonicalize (H12AffineFastState.compose env36509 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(20+1) ^^^ 38144) := by decide +kernel

theorem selectedBound36509 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env36510 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,35189,1025,32769,38144,41340,16,41311,8192,65,10589,36945,49217,2421,1364,53344,257,53345,12621,513]

theorem envBound36510 : H12AffineFastState.Bounded env36510 := by
  intro p hp
  have h : env36510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36509_36510 : H12AffineEnvironment.transform 20 38144 env36509 = env36510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 38144 env36509 == env36510) = true)

theorem identity36510 : scanCanonicalize (H12AffineFastState.compose env36510 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29004) := by decide +kernel

theorem selectedBound36510 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env36511 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29004,8203,16400,30777,1025,29005,25676,20528,16,20499,8192,65,10589,24861,12557,2421,1364,8492,257,8493,12621,513]

theorem envBound36511 : H12AffineFastState.Bounded env36511 := by
  intro p hp
  have h : env36511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36510_36511 : H12AffineEnvironment.transform 14 29004 env36510 = env36511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29004 env36510 == env36511) = true)

theorem identity36511 : scanCanonicalize (H12AffineFastState.compose env36511 (packedSelected [0,1,2,3,4,10,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound36511 : packedSelected [0,1,2,3,4,10,11,15] rootPS < 2^1333 := by decide +kernel

def env36512 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,8192,16384,29004,8203,16400,30777,101,29005,24616,20528,16,20499,8192,65,10589,24861,12557,2421,304,8492,257,8493,12621,513]

theorem envBound36512 : H12AffineFastState.Bounded env36512 := by
  intro p hp
  have h : env36512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36511_36512 : H12AffineEnvironment.transform 9 100 env36511 = env36512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env36511 == env36512) = true)

theorem identity36512 : scanCanonicalize (H12AffineFastState.compose env36512 (packedSelected [2,5,8] rootPS)) = affineNative (2^(13+1) ^^^ 10589) := by decide +kernel

theorem selectedBound36512 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env36513 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,8192,10589,6161,8203,10573,4452,101,6160,2421,14701,16,14670,8192,65,10589,2112,12557,2421,304,8492,257,8493,12621,513]

theorem envBound36513 : H12AffineFastState.Bounded env36513 := by
  intro p hp
  have h : env36513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36512_36513 : H12AffineEnvironment.transform 13 10589 env36512 = env36513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10589 env36512 == env36513) = true)

def env36514 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,17,272427,8193,65,4302890,2468911,2118976,294913,371754,6638946,257,2485278,2428211,297845]

theorem envBound36514 : H12AffineFastState.Bounded env36514 := by
  intro p hp
  have h : env36514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36505_36514 : H12AffineEnvironment.transform 6 9 env36505 = env36514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36505 == env36514) = true)

theorem identity36514 : scanCanonicalize (H12AffineFastState.compose env36514 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound36514 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env36515 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,2097152,4194304,17,41311,8193,65,4302890,2172251,2118976,2421,75102,6407190,257,2188650,2196551,513]

theorem envBound36515 : H12AffineFastState.Bounded env36515 := by
  intro p hp
  have h : env36515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36514_36515 : H12AffineEnvironment.transform 17 35188 env36514 = env36515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env36514 == env36515) = true)

theorem identity36515 : scanCanonicalize (H12AffineFastState.compose env36515 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound36515 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env36516 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,115735,4194304,17,41311,8193,65,4302890,57676,102743,2421,75102,4194305,257,41341,16464,513]

theorem envBound36516 : H12AffineFastState.Bounded env36516 := by
  intro p hp
  have h : env36516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36515_36516 : H12AffineEnvironment.transform 20 115735 env36515 = env36516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env36515 == env36516) = true)

theorem identity36516 : scanCanonicalize (H12AffineFastState.compose env36516 (packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound36516 : packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS < 2^1333 := by decide +kernel

def env36517 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10280,1025,8541,91467,4194304,17,3,8193,65,4262262,16400,77835,2421,75102,4194305,257,33,16464,513]

theorem envBound36517 : H12AffineFastState.Bounded env36517 := by
  intro p hp
  have h : env36517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36516_36517 : H12AffineEnvironment.transform 14 8540 env36516 = env36517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env36516 == env36517) = true)

theorem identity36517 : scanCanonicalize (H12AffineFastState.compose env36517 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound36517 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env36518 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,16400,10280,1025,8541,17729,4194304,17,3,8193,65,4204924,16400,4097,2421,1364,4194305,257,33,16464,513]

theorem envBound36518 : H12AffineFastState.Bounded env36518 := by
  intro p hp
  have h : env36518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36517_36518 : H12AffineEnvironment.transform 15 8202 env36517 = env36518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env36517 == env36518) = true)

theorem identity36518 : scanCanonicalize (H12AffineFastState.compose env36518 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36518 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36519 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,8202,16400,10280,1025,8460,17680,4194304,17,3,8193,16,4204845,16400,4097,2340,1285,4194305,257,33,16385,513]

theorem envBound36519 : H12AffineFastState.Bounded env36519 := by
  intro p hp
  have h : env36519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36518_36519 : H12AffineEnvironment.transform 5 17 env36518 = env36519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36518 == env36519) = true)

theorem identity36519 : scanCanonicalize (H12AffineFastState.compose env36519 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 15366) := by decide +kernel

theorem selectedBound36519 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env36520 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,15366,8461,8202,15382,10280,1025,8460,14614,4194304,17,3,8193,16,4204845,15382,4097,2340,1285,4194305,257,33,15367,513]

theorem envBound36520 : H12AffineFastState.Bounded env36520 := by
  intro p hp
  have h : env36520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36519_36520 : H12AffineEnvironment.transform 13 15366 env36519 = env36520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15366 env36519 == env36520) = true)

theorem identity36520 : scanCanonicalize (H12AffineFastState.compose env36520 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound36520 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36521 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,7435,0,263,7451,2341,1025,1,6171,4194304,17,3,268,16,4196384,7451,4097,2340,1285,4194305,257,33,7434,513]

theorem envBound36521 : H12AffineFastState.Bounded env36521 := by
  intro p hp
  have h : env36521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36520_36521 : H12AffineEnvironment.transform 12 269 env36520 = env36521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env36520 == env36521) = true)

theorem identity36521 : scanCanonicalize (H12AffineFastState.compose env36521 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 5141) := by decide +kernel

theorem selectedBound36521 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env36522 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,7435,0,263,7451,2341,1025,1,6171,5141,17,3,268,16,7221,7451,4097,2340,1285,5140,257,33,7434,513]

theorem envBound36522 : H12AffineFastState.Bounded env36522 := by
  intro p hp
  have h : env36522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36521_36522 : H12AffineEnvironment.transform 21 5141 env36521 = env36522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 5141 env36521 == env36522) = true)

theorem identity36522 : scanCanonicalize (H12AffineFastState.compose env36522 (packedSelected [1,3,12] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound36522 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env36523 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1077,269,2366,0,263,2350,2341,1025,1,3118,32,17,3,268,16,2048,2350,1076,2340,1285,33,257,33,2367,513]

theorem envBound36523 : H12AffineFastState.Bounded env36523 := by
  intro p hp
  have h : env36523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36522_36523 : H12AffineEnvironment.transform 11 1077 env36522 = env36523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env36522 == env36523) = true)

theorem identity36523 : scanCanonicalize (H12AffineFastState.compose env36523 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 270) := by decide +kernel

theorem selectedBound36523 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36524 : List Nat := [2,4,8,16,32,17,9,256,512,1024,270,1077,269,48,0,263,32,43,1025,1,1312,32,17,3,268,16,270,32,1076,42,1285,33,257,33,49,513]

theorem envBound36524 : H12AffineFastState.Bounded env36524 := by
  intro p hp
  have h : env36524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36523_36524 : H12AffineEnvironment.transform 10 270 env36523 = env36524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 270 env36523 == env36524) = true)

theorem identity36524 : scanCanonicalize (H12AffineFastState.compose env36524 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound36524 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36525 : List Nat := [2,4,8,16,32,17,9,21,512,1024,27,1077,24,48,0,18,32,43,1025,1,1077,32,17,3,25,16,27,32,1076,42,1040,33,20,33,49,513]

theorem envBound36525 : H12AffineFastState.Bounded env36525 := by
  intro p hp
  have h : env36525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36524_36525 : H12AffineEnvironment.transform 7 21 env36524 = env36525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env36524 == env36525) = true)

theorem identity36525 : scanCanonicalize (H12AffineFastState.compose env36525 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound36525 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36526 : List Nat := [2,4,8,16,32,17,9,21,11,1024,27,1077,24,48,0,18,32,43,1025,1,1077,32,17,3,25,16,27,32,1076,42,1040,33,20,33,49,10]

theorem envBound36526 : H12AffineFastState.Bounded env36526 := by
  intro p hp
  have h : env36526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36525_36526 : H12AffineEnvironment.transform 8 11 env36525 = env36526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env36525 == env36526) = true)

theorem identity36526 : scanCanonicalize (H12AffineFastState.compose env36526 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound36526 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env36527 : List Nat := [2,4,8,6,32,7,9,3,11,1024,13,1059,14,38,0,4,32,43,1025,1,1059,32,7,3,15,6,13,32,1058,42,1030,33,2,33,39,10]

theorem envBound36527 : H12AffineFastState.Bounded env36527 := by
  intro p hp
  have h : env36527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36526_36527 : H12AffineEnvironment.transform 3 6 env36526 = env36527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env36526 == env36527) = true)

theorem identity36527 : scanCanonicalize (H12AffineFastState.compose env36527 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 8) := by decide +kernel

theorem selectedBound36527 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env36528 : List Nat := [2,4,8,6,32,7,9,3,11,8,13,43,14,38,0,4,32,43,9,1,43,32,7,3,15,6,13,32,42,42,14,33,2,33,39,10]

theorem envBound36528 : H12AffineFastState.Bounded env36528 := by
  intro p hp
  have h : env36528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36527_36528 : H12AffineEnvironment.transform 9 8 env36527 = env36528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 8 env36527 == env36528) = true)

def env36529 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,153,272546,8328,65,4302890,2468911,2119112,295048,371755,6638946,257,2485398,2428210,297981]

theorem envBound36529 : H12AffineFastState.Bounded env36529 := by
  intro p hp
  have h : env36529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36504_36529 : H12AffineEnvironment.transform 16 16401 env36504 = env36529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env36504 == env36529) = true)

theorem identity36529 : scanCanonicalize (H12AffineFastState.compose env36529 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound36529 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env36530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,153,138,8328,65,4302890,2196487,2119112,43168,99331,6382922,257,2213054,2172186,41941]

theorem envBound36530 : H12AffineFastState.Bounded env36530 := by
  intro p hp
  have h : env36530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36529_36530 : H12AffineEnvironment.transform 17 10280 env36529 = env36530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env36529 == env36530) = true)

def env36531 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,17,2,8192,65,4302890,2196487,2118976,43048,99331,6382922,257,2212918,2172186,41821]

theorem envBound36531 : H12AffineFastState.Bounded env36531 := by
  intro p hp
  have h : env36531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36530_36531 : H12AffineEnvironment.transform 6 8 env36530 = env36531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36530 == env36531) = true)

end H12CloudChart0