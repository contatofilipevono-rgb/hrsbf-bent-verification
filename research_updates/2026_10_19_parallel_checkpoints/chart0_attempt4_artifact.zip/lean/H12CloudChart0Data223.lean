import H12CloudChart0Data222

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans56465_56472 : H12AffineEnvironment.transform 13 5377 env56465 = env56472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env56465 == env56472) = true)

theorem identity56472 : scanCanonicalize (H12AffineFastState.compose env56472 (packedSelected [0,2,5,6,7,8,10,11,12,14,16,18,19,24,28,35,41] rootPS)) = affineNative (2^(21+1) ^^^ 168) := by decide +kernel

theorem selectedBound56472 : packedSelected [0,2,5,6,7,8,10,11,12,14,16,18,19,24,28,35,41] rootPS < 2^1333 := by decide +kernel

def env56473 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,10281,1025,8661,4160,168,17,73737,8328,65,146508,5393,4096,138476,1500,32,257,32,5456,74250]

theorem envBound56473 : H12AffineFastState.Bounded env56473 := by
  intro p hp
  have h : env56473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56472_56473 : H12AffineEnvironment.transform 21 168 env56472 = env56473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 168 env56472 == env56473) = true)

theorem identity56473 : scanCanonicalize (H12AffineFastState.compose env56473 (packedSelected [2,5,6,7,8,9,10,11,16,19,22,23,24,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 79250) := by decide +kernel

theorem selectedBound56473 : packedSelected [2,5,6,7,8,9,10,11,16,19,22,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env56474 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,79250,10281,1025,8661,4160,168,17,73737,8328,65,68062,5393,4096,76158,1500,32,257,32,5456,74250]

theorem envBound56474 : H12AffineFastState.Bounded env56474 := by
  intro p hp
  have h : env56474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56473_56474 : H12AffineEnvironment.transform 16 79250 env56473 = env56474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79250 env56473 == env56474) = true)

theorem identity56474 : scanCanonicalize (H12AffineFastState.compose env56474 (packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 128) := by decide +kernel

theorem selectedBound56474 : packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS < 2^1333 := by decide +kernel

def env56475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,128,5377,340,65536,70930,2217,1025,341,4160,168,17,65673,8,65,68062,5393,4096,68094,1500,32,257,32,5456,66186]

theorem envBound56475 : H12AffineFastState.Bounded env56475 := by
  intro p hp
  have h : env56475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56474_56475 : H12AffineEnvironment.transform 12 128 env56474 = env56475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env56474 == env56475) = true)

theorem identity56475 : scanCanonicalize (H12AffineFastState.compose env56475 (packedSelected [0,3,4,5,7,9,10,11,14,16,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound56475 : packedSelected [0,3,4,5,7,9,10,11,14,16,18,20] rootPS < 2^1333 := by decide +kernel

def env56476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,128,5377,340,343,5189,2217,1025,341,4160,168,17,478,8,65,2185,5393,4096,2217,1500,32,257,32,5456,989]

theorem envBound56476 : H12AffineFastState.Bounded env56476 := by
  intro p hp
  have h : env56476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56475_56476 : H12AffineEnvironment.transform 15 343 env56475 = env56476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env56475 == env56476) = true)

theorem identity56476 : scanCanonicalize (H12AffineFastState.compose env56476 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(7+1) ^^^ 220) := by decide +kernel

theorem selectedBound56476 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env56477 : List Nat := [2,4,8,16,32,64,128,220,512,1024,2048,4096,128,5341,136,139,5189,2217,1025,137,4160,168,17,2,8,65,2185,5325,4096,2217,1024,32,221,32,5260,513]

theorem envBound56477 : H12AffineFastState.Bounded env56477 := by
  intro p hp
  have h : env56477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56476_56477 : H12AffineEnvironment.transform 7 220 env56476 = env56477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 220 env56476 == env56477) = true)

def env56478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4161,4194304,8388608,8487373,8328,65,4365617,8393984,8406289,8527101,1501,12645452,257,21793,46212,74251]

theorem envBound56478 : H12AffineFastState.Bounded env56478 := by
  intro p hp
  have h : env56478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56458_56478 : H12AffineEnvironment.transform 20 4161 env56458 = env56478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env56458 == env56478) = true)

def env56479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4161,4194304,16,98781,8328,65,4365617,5392,17665,138477,1501,4256860,257,21793,46212,74251]

theorem envBound56479 : H12AffineFastState.Bounded env56479 := by
  intro p hp
  have h : env56479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56478_56479 : H12AffineEnvironment.transform 22 16 env56478 = env56479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env56478 == env56479) = true)

theorem identity56479 : scanCanonicalize (H12AffineFastState.compose env56479 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169) := by decide +kernel

theorem selectedBound56479 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4161,169,16,98781,8328,65,171416,5392,17665,138477,1501,62709,257,21793,46212,74251]

theorem envBound56480 : H12AffineFastState.Bounded env56480 := by
  intro p hp
  have h : env56480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56479_56480 : H12AffineEnvironment.transform 21 169 env56479 = env56480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169 env56479 == env56480) = true)

def env56481 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4161,33,16,98645,8192,65,171280,5392,17665,138341,1365,62589,257,21793,46092,74251]

theorem envBound56481 : H12AffineFastState.Bounded env56481 := by
  intro p hp
  have h : env56481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56480_56481 : H12AffineEnvironment.transform 6 8 env56480 = env56481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56480 == env56481) = true)

theorem identity56481 : scanCanonicalize (H12AffineFastState.compose env56481 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound56481 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56482 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,35188,1025,32769,4161,33,16,98645,8192,65,171280,5392,4097,138341,1365,41341,257,33,46092,74251]

theorem envBound56482 : H12AffineFastState.Bounded env56482 := by
  intro p hp
  have h : env56482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56481_56482 : H12AffineEnvironment.transform 13 5376 env56481 = env56482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env56481 == env56482) = true)

theorem identity56482 : scanCanonicalize (H12AffineFastState.compose env56482 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound56482 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env56483 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,5392,35188,1025,32769,4161,33,16,98645,8192,65,34816,5392,4097,2421,1365,41341,257,33,46092,74251]

theorem envBound56483 : H12AffineFastState.Bounded env56483 := by
  intro p hp
  have h : env56483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56482_56483 : H12AffineEnvironment.transform 16 5392 env56482 = env56483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env56482 == env56483) = true)

theorem identity56483 : scanCanonicalize (H12AffineFastState.compose env56483 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound56483 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56484 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,5392,35188,1025,32769,4161,33,16,41310,8192,65,34816,5392,4097,2421,1365,41341,257,33,46092,512]

theorem envBound56484 : H12AffineFastState.Bounded env56484 := by
  intro p hp
  have h : env56484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56483_56484 : H12AffineEnvironment.transform 15 8203 env56483 = env56484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env56483 == env56484) = true)

theorem identity56484 : scanCanonicalize (H12AffineFastState.compose env56484 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound56484 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env56485 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8201,8203,5392,10621,1025,8200,4161,33,16,343,8192,65,10249,5392,4097,2421,1365,372,257,33,5125,512]

theorem envBound56485 : H12AffineFastState.Bounded env56485 := by
  intro p hp
  have h : env56485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56484_56485 : H12AffineEnvironment.transform 14 8201 env56484 = env56485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env56484 == env56485) = true)

theorem identity56485 : scanCanonicalize (H12AffineFastState.compose env56485 (packedSelected [0,7,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound56485 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env56486 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,8201,8203,5221,10248,1025,8200,4161,33,16,34,8192,65,10249,5221,4097,2048,1056,1,116,33,5125,512]

theorem envBound56486 : H12AffineFastState.Bounded env56486 := by
  intro p hp
  have h : env56486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56485_56486 : H12AffineEnvironment.transform 7 117 env56485 = env56486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env56485 == env56486) = true)

theorem identity56486 : scanCanonicalize (H12AffineFastState.compose env56486 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2170) := by decide +kernel

theorem selectedBound56486 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env56487 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,2170,8192,3087,8201,8203,3103,10248,1025,8200,2107,33,16,34,8192,65,10249,3103,2171,2048,1056,1,116,33,3199,512]

theorem envBound56487 : H12AffineFastState.Bounded env56487 := by
  intro p hp
  have h : env56487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56486_56487 : H12AffineEnvironment.transform 11 2170 env56486 = env56487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2170 env56486 == env56487) = true)

theorem identity56487 : scanCanonicalize (H12AffineFastState.compose env56487 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound56487 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env56488 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,2170,89,3087,80,82,3103,2129,1025,81,2107,33,16,34,89,65,2128,3103,2171,2048,1056,1,116,33,3199,512]

theorem envBound56488 : H12AffineFastState.Bounded env56488 := by
  intro p hp
  have h : env56488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56487_56488 : H12AffineEnvironment.transform 12 89 env56487 = env56488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env56487 == env56488) = true)

theorem identity56488 : scanCanonicalize (H12AffineFastState.compose env56488 (packedSelected [1,3,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56488 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env56489 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,2090,9,3087,0,2,3103,2049,1025,1,2107,33,16,34,9,17,2048,3103,2091,2048,1056,1,36,33,3119,512]

theorem envBound56489 : H12AffineFastState.Bounded env56489 := by
  intro p hp
  have h : env56489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56488_56489 : H12AffineEnvironment.transform 5 16 env56488 = env56489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56488 == env56489) = true)

theorem identity56489 : scanCanonicalize (H12AffineFastState.compose env56489 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound56489 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56490 : List Nat := [2,4,8,16,32,16,8,37,512,37,2048,2090,9,2090,0,2,2106,2049,36,1,2107,33,16,34,9,17,2048,2106,2091,2048,5,1,36,33,2058,512]

theorem envBound56490 : H12AffineFastState.Bounded env56490 := by
  intro p hp
  have h : env56490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56489_56490 : H12AffineEnvironment.transform 9 37 env56489 = env56490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env56489 == env56490) = true)

theorem identity56490 : scanCanonicalize (H12AffineFastState.compose env56490 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound56490 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env56491 : List Nat := [2,4,2,16,32,16,2,37,512,37,2048,2080,3,2080,0,2,2096,2049,36,1,2097,33,16,34,3,17,2048,2096,2081,2048,5,1,36,33,2048,512]

theorem envBound56491 : H12AffineFastState.Bounded env56491 := by
  intro p hp
  have h : env56491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56490_56491 : H12AffineEnvironment.transform 2 2 env56490 = env56491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env56490 == env56491) = true)

theorem identity56491 : scanCanonicalize (H12AffineFastState.compose env56491 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound56491 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56492 : List Nat := [2,4,2,1,32,1,2,37,512,37,2048,2080,3,2080,0,2,2081,2049,36,1,2080,33,1,34,3,0,2048,2081,2081,2048,5,1,36,33,2048,512]

theorem envBound56492 : H12AffineFastState.Bounded env56492 := by
  intro p hp
  have h : env56492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56491_56492 : H12AffineEnvironment.transform 3 1 env56491 = env56492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56491 == env56492) = true)

theorem identity56492 : scanCanonicalize (H12AffineFastState.compose env56492 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 516) := by decide +kernel

theorem selectedBound56492 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56493 : List Nat := [2,4,2,1,32,1,2,37,512,37,516,548,3,548,0,2,549,517,36,1,548,33,1,34,3,0,516,549,549,516,5,1,36,33,516,512]

theorem envBound56493 : H12AffineFastState.Bounded env56493 := by
  intro p hp
  have h : env56493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56492_56493 : H12AffineEnvironment.transform 10 516 env56492 = env56493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 516 env56492 == env56493) = true)

theorem identity56493 : scanCanonicalize (H12AffineFastState.compose env56493 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound56493 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env56494 : List Nat := [2,4,2,1,0,1,2,5,512,5,516,516,3,516,0,2,517,517,4,1,516,1,1,2,3,0,516,517,517,516,5,1,4,1,516,512]

theorem envBound56494 : H12AffineFastState.Bounded env56494 := by
  intro p hp
  have h : env56494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56493_56494 : H12AffineEnvironment.transform 4 0 env56493 = env56494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env56493 == env56494) = true)

theorem identity56494 : scanCanonicalize (H12AffineFastState.compose env56494 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound56494 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56495 : List Nat := [2,3,2,1,0,1,2,2,512,2,515,515,3,515,0,2,514,514,3,1,515,1,1,2,3,0,515,514,514,515,2,1,3,1,515,512]

theorem envBound56495 : H12AffineFastState.Bounded env56495 := by
  intro p hp
  have h : env56495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56494_56495 : H12AffineEnvironment.transform 1 3 env56494 = env56495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env56494 == env56495) = true)

theorem identity56495 : scanCanonicalize (H12AffineFastState.compose env56495 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound56495 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env56496 : List Nat := [1,0,1,1,0,1,1,1,512,1,512,512,0,512,0,1,513,513,0,1,512,1,1,1,0,0,512,513,513,512,1,1,0,1,512,512]

theorem envBound56496 : H12AffineFastState.Bounded env56496 := by
  intro p hp
  have h : env56496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56495_56496 : H12AffineEnvironment.transform 0 1 env56495 = env56496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env56495 == env56496) = true)

theorem identity56496 : scanCanonicalize (H12AffineFastState.compose env56496 (packedSelected [11] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound56496 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env56497 : List Nat := [1,0,1,1,0,1,1,1,1,1,1,1,0,1,0,1,0,0,0,1,1,1,1,1,0,0,1,0,0,1,1,1,0,1,1,1]

theorem envBound56497 : H12AffineFastState.Bounded env56497 := by
  intro p hp
  have h : env56497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56496_56497 : H12AffineEnvironment.transform 8 1 env56496 = env56497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env56496 == env56497) = true)

def env56498 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4161,32,16,98644,8193,65,171281,5392,17665,138340,1364,62588,257,21793,46093,74251]

theorem envBound56498 : H12AffineFastState.Bounded env56498 := by
  intro p hp
  have h : env56498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56480_56498 : H12AffineEnvironment.transform 6 9 env56480 = env56498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56480 == env56498) = true)

theorem identity56498 : scanCanonicalize (H12AffineFastState.compose env56498 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound56498 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56499 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10281,1025,29789,4161,32,16,95496,8193,65,158029,5392,17665,138340,1364,32,257,21793,16465,74251]

theorem envBound56499 : H12AffineFastState.Bounded env56499 := by
  intro p hp
  have h : env56499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56498_56499 : H12AffineEnvironment.transform 14 29788 env56498 = env56499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env56498 == env56499) = true)

theorem identity56499 : scanCanonicalize (H12AffineFastState.compose env56499 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound56499 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env56500 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,16401,10281,1025,29789,4161,32,16,95496,8193,65,10588,5392,17665,23669,1364,32,257,21793,16465,74251]

theorem envBound56500 : H12AffineFastState.Bounded env56500 := by
  intro p hp
  have h : env56500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56499_56500 : H12AffineEnvironment.transform 16 16401 env56499 = env56500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env56499 == env56500) = true)

theorem identity56500 : scanCanonicalize (H12AffineFastState.compose env56500 (packedSelected [1,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound56500 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env56501 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,5392,10281,1025,8540,4161,32,16,73737,8193,65,10588,5392,4096,2420,1364,32,257,32,5456,74251]

theorem envBound56501 : H12AffineFastState.Bounded env56501 := by
  intro p hp
  have h : env56501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56500_56501 : H12AffineEnvironment.transform 13 5377 env56500 = env56501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env56500 == env56501) = true)

theorem identity56501 : scanCanonicalize (H12AffineFastState.compose env56501 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 82) := by decide +kernel

theorem selectedBound56501 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env56502 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,82,5392,10281,1025,8540,4161,32,16,8283,8193,65,10588,5392,4096,2420,1364,32,257,32,5456,8793]

theorem envBound56502 : H12AffineFastState.Bounded env56502 := by
  intro p hp
  have h : env56502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56501_56502 : H12AffineEnvironment.transform 15 82 env56501 = env56502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 82 env56501 == env56502) = true)

theorem identity56502 : scanCanonicalize (H12AffineFastState.compose env56502 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound56502 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56503 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,88,5377,261,82,5392,2161,1025,260,4161,32,16,3,89,65,2308,5392,4096,2420,1364,32,257,32,5456,513]

theorem envBound56503 : H12AffineFastState.Bounded env56503 := by
  intro p hp
  have h : env56503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56502_56503 : H12AffineEnvironment.transform 12 88 env56502 = env56503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env56502 == env56503) = true)

theorem identity56503 : scanCanonicalize (H12AffineFastState.compose env56503 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56503 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env56504 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8,5377,261,2,5392,2081,1025,260,4113,32,16,3,9,17,2308,5392,4096,2340,1284,32,257,32,5376,513]

theorem envBound56504 : H12AffineFastState.Bounded env56504 := by
  intro p hp
  have h : env56504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56503_56504 : H12AffineEnvironment.transform 5 16 env56503 = env56504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56503 == env56504) = true)

theorem identity56504 : scanCanonicalize (H12AffineFastState.compose env56504 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound56504 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56505 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,292,8,1061,261,2,1076,2081,1025,260,309,32,16,3,9,17,2308,1076,292,2340,1284,32,257,32,1060,513]

theorem envBound56505 : H12AffineFastState.Bounded env56505 := by
  intro p hp
  have h : env56505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56504_56505 : H12AffineEnvironment.transform 11 292 env56504 = env56505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env56504 == env56505) = true)

theorem identity56505 : scanCanonicalize (H12AffineFastState.compose env56505 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound56505 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56506 : List Nat := [2,4,8,16,32,16,9,256,1,1024,2048,292,8,1061,261,2,1076,2081,1025,260,309,32,16,3,9,17,2308,1076,292,2340,1284,32,257,32,1060,0]

theorem envBound56506 : H12AffineFastState.Bounded env56506 := by
  intro p hp
  have h : env56506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56505_56506 : H12AffineEnvironment.transform 8 1 env56505 = env56506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env56505 == env56506) = true)

def env56507 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4161,4194304,17,98780,8328,65,4365617,5393,17664,138476,1501,4256861,257,21793,46212,74251]

theorem envBound56507 : H12AffineFastState.Bounded env56507 := by
  intro p hp
  have h : env56507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56478_56507 : H12AffineEnvironment.transform 22 17 env56478 = env56507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env56478 == env56507) = true)

def env56508 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4161,4194304,17,98644,8192,65,4365617,5393,17664,138340,1365,4256861,257,21793,46092,74251]

theorem envBound56508 : H12AffineFastState.Bounded env56508 := by
  intro p hp
  have h : env56508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56507_56508 : H12AffineEnvironment.transform 6 8 env56507 = env56508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56507 == env56508) = true)

theorem identity56508 : scanCanonicalize (H12AffineFastState.compose env56508 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound56508 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56509 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,32040,1025,8541,4161,4194304,17,73736,8192,65,4340845,5393,17664,138340,1365,4216065,257,21793,5456,74251]

theorem envBound56509 : H12AffineFastState.Bounded env56509 := by
  intro p hp
  have h : env56509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56508_56509 : H12AffineEnvironment.transform 14 8540 env56508 = env56509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env56508 == env56509) = true)

theorem identity56509 : scanCanonicalize (H12AffineFastState.compose env56509 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound56509 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env56510 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90139,32040,1025,8541,4161,4194304,17,73736,8192,65,4283510,5393,17664,97407,1365,4216065,257,21793,5456,74251]

theorem envBound56510 : H12AffineFastState.Bounded env56510 := by
  intro p hp
  have h : env56510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56509_56510 : H12AffineEnvironment.transform 16 90139 env56509 = env56510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env56509 == env56510) = true)

theorem identity56510 : scanCanonicalize (H12AffineFastState.compose env56510 (packedSelected [0,3,5,7,9,10,12,14,20,22,38] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound56510 : packedSelected [0,3,5,7,9,10,12,14,20,22,38] rootPS < 2^1333 := by decide +kernel

def env56511 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8574,16741,32040,1025,8541,4161,4194304,17,374,8192,65,4226312,5393,17664,23809,1365,4216065,257,21793,5456,885]

theorem envBound56511 : H12AffineFastState.Bounded env56511 := by
  intro p hp
  have h : env56511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56510_56511 : H12AffineEnvironment.transform 15 8574 env56510 = env56511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env56510 == env56511) = true)

theorem identity56511 : scanCanonicalize (H12AffineFastState.compose env56511 (packedSelected [3,5,10,15,41] rootPS)) = affineNative (2^(21+1) ^^^ 21589) := by decide +kernel

theorem selectedBound56511 : packedSelected [3,5,10,15,41] rootPS < 2^1333 := by decide +kernel

def env56512 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8574,16741,32040,1025,8541,4161,21589,17,374,8192,65,10589,5393,17664,23809,1365,340,257,21793,5456,885]

theorem envBound56512 : H12AffineFastState.Bounded env56512 := by
  intro p hp
  have h : env56512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56511_56512 : H12AffineEnvironment.transform 21 21589 env56511 = env56512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21589 env56511 == env56512) = true)

theorem identity56512 : scanCanonicalize (H12AffineFastState.compose env56512 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound56512 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env56513 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,8232,8202,16401,31836,1025,8233,4161,21589,17,2,8192,65,10281,5221,17524,23669,1057,32,117,21589,5156,513]

theorem envBound56513 : H12AffineFastState.Bounded env56513 := by
  intro p hp
  have h : env56513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56512_56513 : H12AffineEnvironment.transform 7 116 env56512 = env56513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env56512 == env56513) = true)

theorem identity56513 : scanCanonicalize (H12AffineFastState.compose env56513 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound56513 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56514 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5157,8232,8202,5172,10361,1025,8233,4161,112,17,2,8192,65,10281,5221,4177,2128,1057,32,117,112,5156,513]

theorem envBound56514 : H12AffineFastState.Bounded env56514 := by
  intro p hp
  have h : env56514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56513_56514 : H12AffineEnvironment.transform 13 5157 env56513 = env56514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env56513 == env56514) = true)

theorem identity56514 : scanCanonicalize (H12AffineFastState.compose env56514 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound56514 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56515 : List Nat := [2,4,8,16,32,64,8,116,512,101,2048,4096,8192,4160,8232,8202,4177,10361,100,8233,4161,112,17,2,8192,65,10281,4096,4177,2128,68,32,117,112,4161,513]

theorem envBound56515 : H12AffineFastState.Bounded env56515 := by
  intro p hp
  have h : env56515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56514_56515 : H12AffineEnvironment.transform 9 101 env56514 = env56515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env56514 == env56515) = true)

theorem identity56515 : scanCanonicalize (H12AffineFastState.compose env56515 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound56515 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56516 : List Nat := [2,4,8,16,32,64,8,116,512,101,2048,4096,41,4160,1,35,4177,2128,100,0,4161,112,17,2,41,65,2048,4096,4177,2128,68,32,117,112,4161,513]

theorem envBound56516 : H12AffineFastState.Bounded env56516 := by
  intro p hp
  have h : env56516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56515_56516 : H12AffineEnvironment.transform 12 41 env56515 = env56516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env56515 == env56516) = true)

theorem identity56516 : scanCanonicalize (H12AffineFastState.compose env56516 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound56516 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56517 : List Nat := [2,4,8,16,32,64,8,116,512,101,2048,65,41,1,1,35,16,2128,100,0,0,112,17,2,41,65,2048,65,16,2128,68,32,117,112,0,513]

theorem envBound56517 : H12AffineFastState.Bounded env56517 := by
  intro p hp
  have h : env56517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56516_56517 : H12AffineEnvironment.transform 11 65 env56516 = env56517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env56516 == env56517) = true)

theorem identity56517 : scanCanonicalize (H12AffineFastState.compose env56517 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound56517 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56518 : List Nat := [2,4,8,16,32,64,8,116,512,101,81,65,41,1,1,35,16,1,100,0,0,112,17,2,41,65,81,65,16,1,68,32,117,112,0,513]

theorem envBound56518 : H12AffineFastState.Bounded env56518 := by
  intro p hp
  have h : env56518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56517_56518 : H12AffineEnvironment.transform 10 81 env56517 = env56518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env56517 == env56518) = true)

def env56519 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4161,4194304,17,98645,8193,65,4365617,5393,17664,138341,1364,4256861,257,21793,46093,74251]

theorem envBound56519 : H12AffineFastState.Bounded env56519 := by
  intro p hp
  have h : env56519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56507_56519 : H12AffineEnvironment.transform 6 9 env56507 = env56519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56507 == env56519) = true)

theorem identity56519 : scanCanonicalize (H12AffineFastState.compose env56519 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound56519 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env56520 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56437,1025,32769,4161,4194304,17,41311,8193,65,4365617,5393,17664,138341,1364,4256861,257,21793,46093,513]

theorem envBound56520 : H12AffineFastState.Bounded env56520 := by
  intro p hp
  have h : env56520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56519_56520 : H12AffineEnvironment.transform 15 8202 env56519 = env56520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env56519 == env56520) = true)

theorem identity56520 : scanCanonicalize (H12AffineFastState.compose env56520 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 112) := by decide +kernel

theorem selectedBound56520 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env56521 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56437,1025,32769,4161,112,17,41311,8193,65,171329,5393,17664,138341,1364,62509,257,21793,46093,513]

theorem envBound56521 : H12AffineFastState.Bounded env56521 := by
  intro p hp
  have h : env56521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56520_56521 : H12AffineEnvironment.transform 21 112 env56520 = env56521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 112 env56520 == env56521) = true)

def env56522 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56357,1025,32769,4113,32,17,41231,8193,17,171281,5393,17664,138293,1284,62509,257,21793,46093,513]

theorem envBound56522 : H12AffineFastState.Bounded env56522 := by
  intro p hp
  have h : env56522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56521_56522 : H12AffineEnvironment.transform 5 16 env56521 = env56522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56521 == env56522) = true)

theorem identity56522 : scanCanonicalize (H12AffineFastState.compose env56522 (packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound56522 : packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS < 2^1333 := by decide +kernel

def env56523 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,8202,13341,56357,1025,32769,4113,32,17,41231,8193,17,43276,5393,17664,10280,1284,62509,257,21793,46093,513]

theorem envBound56523 : H12AffineFastState.Bounded env56523 := by
  intro p hp
  have h : env56523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56522_56523 : H12AffineEnvironment.transform 16 13341 env56522 = env56523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env56522 == env56523) = true)

theorem identity56523 : scanCanonicalize (H12AffineFastState.compose env56523 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound56523 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env56524 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,32768,263,5392,56357,1025,32769,4113,32,17,32770,268,17,34817,5393,17664,2341,1284,54560,257,21793,38144,513]

theorem envBound56524 : H12AffineFastState.Bounded env56524 := by
  intro p hp
  have h : env56524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56523_56524 : H12AffineEnvironment.transform 12 269 env56523 = env56524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env56523 == env56524) = true)

theorem identity56524 : scanCanonicalize (H12AffineFastState.compose env56524 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound56524 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env56525 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,21761,263,5392,2340,1025,21760,4113,32,17,21763,268,17,23808,5393,17664,2341,1284,33,257,21793,16385,513]

theorem envBound56525 : H12AffineFastState.Bounded env56525 := by
  intro p hp
  have h : env56525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56524_56525 : H12AffineEnvironment.transform 14 21761 env56524 = env56525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env56524 == env56525) = true)

theorem identity56525 : scanCanonicalize (H12AffineFastState.compose env56525 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound56525 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56526 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,0,263,5392,2340,1025,1,4113,32,17,2,268,17,2049,5393,4097,2341,1284,33,257,32,5376,513]

theorem envBound56526 : H12AffineFastState.Bounded env56526 := by
  intro p hp
  have h : env56526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56525_56526 : H12AffineEnvironment.transform 13 5377 env56525 = env56526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env56525 == env56526) = true)

theorem identity56526 : scanCanonicalize (H12AffineFastState.compose env56526 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound56526 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56527 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,4096,9,5125,0,3,5140,2080,1025,1,4113,32,17,2,8,17,2049,5141,4097,2081,1024,33,5,32,5124,513]

theorem envBound56527 : H12AffineFastState.Bounded env56527 := by
  intro p hp
  have h : env56527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56526_56527 : H12AffineEnvironment.transform 7 4 env56526 = env56527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env56526 == env56527) = true)

theorem identity56527 : scanCanonicalize (H12AffineFastState.compose env56527 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound56527 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56528 : List Nat := [2,4,8,16,32,16,9,4,512,53,2048,4096,9,4144,0,3,4129,2080,52,1,4113,32,17,2,8,17,2049,4128,4097,2081,53,33,5,32,4145,513]

theorem envBound56528 : H12AffineFastState.Bounded env56528 := by
  intro p hp
  have h : env56528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56527_56528 : H12AffineEnvironment.transform 9 53 env56527 = env56528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env56527 == env56528) = true)

theorem identity56528 : scanCanonicalize (H12AffineFastState.compose env56528 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2608) := by decide +kernel

theorem selectedBound56528 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56529 : List Nat := [2,4,8,16,32,16,9,4,512,53,2048,2608,9,2560,0,3,2577,2080,52,1,2593,32,17,2,8,17,2049,2576,2609,2081,53,33,5,32,2561,513]

theorem envBound56529 : H12AffineFastState.Bounded env56529 := by
  intro p hp
  have h : env56529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56528_56529 : H12AffineEnvironment.transform 11 2608 env56528 = env56529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2608 env56528 == env56529) = true)

theorem identity56529 : scanCanonicalize (H12AffineFastState.compose env56529 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound56529 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56530 : List Nat := [2,4,8,16,32,16,9,4,512,53,529,33,9,17,0,3,0,561,52,1,48,32,17,2,8,17,528,1,32,560,53,33,5,32,16,513]

theorem envBound56530 : H12AffineFastState.Bounded env56530 := by
  intro p hp
  have h : env56530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56529_56530 : H12AffineEnvironment.transform 10 529 env56529 = env56530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env56529 == env56530) = true)

theorem identity56530 : scanCanonicalize (H12AffineFastState.compose env56530 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound56530 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56531 : List Nat := [2,4,8,16,32,16,9,4,33,53,48,33,9,17,0,3,0,16,52,1,48,32,17,2,8,17,49,1,32,17,53,33,5,32,16,32]

theorem envBound56531 : H12AffineFastState.Bounded env56531 := by
  intro p hp
  have h : env56531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56530_56531 : H12AffineEnvironment.transform 8 33 env56530 = env56531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env56530 == env56531) = true)

theorem identity56531 : scanCanonicalize (H12AffineFastState.compose env56531 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound56531 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env56532 : List Nat := [2,4,8,16,1,16,9,4,0,20,17,0,9,17,0,3,0,16,21,1,17,1,17,2,8,17,16,1,1,17,20,0,5,1,16,1]

theorem envBound56532 : H12AffineFastState.Bounded env56532 := by
  intro p hp
  have h : env56532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56531_56532 : H12AffineEnvironment.transform 4 1 env56531 = env56532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56531 == env56532) = true)

theorem identity56532 : scanCanonicalize (H12AffineFastState.compose env56532 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound56532 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56533 : List Nat := [2,4,8,1,1,1,9,4,0,5,0,0,9,0,0,3,0,1,4,1,0,1,0,2,8,0,1,1,1,0,5,0,5,1,1,1]

theorem envBound56533 : H12AffineFastState.Bounded env56533 := by
  intro p hp
  have h : env56533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56532_56533 : H12AffineEnvironment.transform 3 1 env56532 = env56533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56532 == env56533) = true)

def env56534 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56356,1025,32769,4112,33,17,41230,8193,16,171280,5393,17664,138292,1285,62509,257,21793,46093,513]

theorem envBound56534 : H12AffineFastState.Bounded env56534 := by
  intro p hp
  have h : env56534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56521_56534 : H12AffineEnvironment.transform 5 17 env56521 = env56534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56521 == env56534) = true)

theorem identity56534 : scanCanonicalize (H12AffineFastState.compose env56534 (packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound56534 : packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS < 2^1333 := by decide +kernel

def env56535 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,1,8202,131072,23589,1025,0,4112,33,17,8463,8193,16,138513,5393,17664,138292,1285,29740,257,21793,13324,513]

theorem envBound56535 : H12AffineFastState.Bounded env56535 := by
  intro p hp
  have h : env56535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56534_56535 : H12AffineEnvironment.transform 14 1 env56534 = env56535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env56534 == env56535) = true)

theorem identity56535 : scanCanonicalize (H12AffineFastState.compose env56535 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound56535 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env56536 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,1,262,131072,23589,1025,0,4112,33,17,3,269,16,138513,5393,17664,138292,1285,21792,257,21793,5376,513]

theorem envBound56536 : H12AffineFastState.Bounded env56536 := by
  intro p hp
  have h : env56536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56535_56536 : H12AffineEnvironment.transform 12 268 env56535 = env56536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env56535 == env56536) = true)

theorem identity56536 : scanCanonicalize (H12AffineFastState.compose env56536 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound56536 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env56537 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,1,262,16401,23589,1025,0,4112,33,17,3,269,16,23808,5393,17664,23589,1285,21792,257,21793,5376,513]

theorem envBound56537 : H12AffineFastState.Bounded env56537 := by
  intro p hp
  have h : env56537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56536_56537 : H12AffineEnvironment.transform 16 16401 env56536 = env56537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env56536 == env56537) = true)

theorem identity56537 : scanCanonicalize (H12AffineFastState.compose env56537 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound56537 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56538 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,1,262,5393,2341,1025,0,4112,33,17,3,269,16,2048,5393,4096,2341,1285,32,257,33,5376,513]

theorem envBound56538 : H12AffineFastState.Bounded env56538 := by
  intro p hp
  have h : env56538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56537_56538 : H12AffineEnvironment.transform 13 5376 env56537 = env56538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env56537 == env56538) = true)

theorem identity56538 : scanCanonicalize (H12AffineFastState.compose env56538 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound56538 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56539 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5156,1,34,5173,2049,1025,0,4112,33,17,3,41,16,2048,5173,4096,2049,1057,32,37,33,5156,513]

theorem envBound56539 : H12AffineFastState.Bounded env56539 := by
  intro p hp
  have h : env56539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56538_56539 : H12AffineEnvironment.transform 7 36 env56538 = env56539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env56538 == env56539) = true)

def env56540 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,40,1044,1,34,1029,2049,1025,0,32,33,17,3,41,16,2048,1029,48,2049,1057,32,37,33,1044,513]

theorem envBound56540 : H12AffineFastState.Bounded env56540 := by
  intro p hp
  have h : env56540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56539_56540 : H12AffineEnvironment.transform 11 48 env56539 = env56540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env56539 == env56540) = true)

theorem identity56540 : scanCanonicalize (H12AffineFastState.compose env56540 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound56540 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56541 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,17,9,1044,1,3,1029,2049,1025,0,1,0,17,3,8,16,2048,1029,17,2049,1024,1,4,0,1044,513]

theorem envBound56541 : H12AffineFastState.Bounded env56541 := by
  intro p hp
  have h : env56541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56540_56541 : H12AffineEnvironment.transform 4 1 env56540 = env56541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56540 == env56541) = true)

def env56542 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,17,9,0,1,3,17,2049,21,0,1,0,17,3,8,16,2048,17,17,2049,20,1,4,0,0,513]

theorem envBound56542 : H12AffineFastState.Bounded env56542 := by
  intro p hp
  have h : env56542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56541_56542 : H12AffineEnvironment.transform 9 20 env56541 = env56542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env56541 == env56542) = true)

theorem identity56542 : scanCanonicalize (H12AffineFastState.compose env56542 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound56542 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56543 : List Nat := [2,4,8,16,1,17,9,5,512,20,0,17,9,0,1,3,17,1,21,0,1,0,17,3,8,16,0,17,17,1,20,1,4,0,0,513]

theorem envBound56543 : H12AffineFastState.Bounded env56543 := by
  intro p hp
  have h : env56543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56542_56543 : H12AffineEnvironment.transform 10 0 env56542 = env56543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env56542 == env56543) = true)

def leafEnv56543 : List Nat := [2,4,8,16,1,17,9,5,512,20,0,17,9,0,1,3,17,1,21,0,1,0,17,3,21,8,1,16,0,17,17,1,20,1,4,0,5,2,0,513,1,1,0]

def active56543 : List Nat := [0,1,2,3,8]

def tree56543 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood56543 : H12WitnessSearch.Good tree56543 := H12GlobalWitnessIndex.good

theorem leafIdentity56543 : H12AffineFastState.composeSystem env56543 rootObs = leafEnv56543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env56543 rootObs == leafEnv56543) = true)

theorem terminalChecked56543 : H12PackedTerminal.terminalCheckFast leafEnv56543 active56543 tree56543 = true := by decide +kernel

def env56544 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,17,9,1,1,3,16,2049,20,0,1,0,17,3,8,16,2048,16,17,2049,21,1,4,0,1,513]

theorem envBound56544 : H12AffineFastState.Bounded env56544 := by
  intro p hp
  have h : env56544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56541_56544 : H12AffineEnvironment.transform 9 21 env56541 = env56544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env56541 == env56544) = true)

theorem identity56544 : scanCanonicalize (H12AffineFastState.compose env56544 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound56544 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56545 : List Nat := [2,4,8,16,1,17,9,5,512,21,523,17,9,1,1,3,16,522,20,0,1,0,17,3,8,16,523,16,17,522,21,1,4,0,1,513]

theorem envBound56545 : H12AffineFastState.Bounded env56545 := by
  intro p hp
  have h : env56545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56544_56545 : H12AffineEnvironment.transform 10 523 env56544 = env56545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env56544 == env56545) = true)

def leafEnv56545 : List Nat := [2,4,8,16,1,17,9,5,512,21,523,17,9,1,1,3,16,522,20,0,1,0,17,3,20,8,1,16,523,16,17,522,21,1,4,0,5,2,1,513,1,1,0]

def active56545 : List Nat := [0,1,2,3,8]

def tree56545 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood56545 : H12WitnessSearch.Good tree56545 := H12GlobalWitnessIndex.good

theorem leafIdentity56545 : H12AffineFastState.composeSystem env56545 rootObs = leafEnv56545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env56545 rootObs == leafEnv56545) = true)

theorem terminalChecked56545 : H12PackedTerminal.terminalCheckFast leafEnv56545 active56545 tree56545 = true := by decide +kernel

def env56546 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,40,1045,1,34,1028,2049,1025,0,33,33,17,3,41,16,2048,1028,49,2049,1057,32,37,33,1045,513]

theorem envBound56546 : H12AffineFastState.Bounded env56546 := by
  intro p hp
  have h : env56546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56539_56546 : H12AffineEnvironment.transform 11 49 env56539 = env56546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env56539 == env56546) = true)

theorem identity56546 : scanCanonicalize (H12AffineFastState.compose env56546 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound56546 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56547 : List Nat := [2,4,8,16,32,17,9,36,512,20,2048,49,40,1,1,34,16,2049,21,0,33,33,17,3,41,16,2048,16,49,2049,53,32,37,33,1,513]

theorem envBound56547 : H12AffineFastState.Bounded env56547 := by
  intro p hp
  have h : env56547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56546_56547 : H12AffineEnvironment.transform 9 20 env56546 = env56547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env56546 == env56547) = true)

def env56548 : List Nat := [2,4,8,16,0,17,9,4,512,20,2048,17,8,1,1,2,16,2049,21,0,1,1,17,3,9,16,2048,16,17,2049,21,0,5,1,1,513]

theorem envBound56548 : H12AffineFastState.Bounded env56548 := by
  intro p hp
  have h : env56548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56547_56548 : H12AffineEnvironment.transform 4 0 env56547 = env56548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env56547 == env56548) = true)

theorem identity56548 : scanCanonicalize (H12AffineFastState.compose env56548 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound56548 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56549 : List Nat := [2,4,8,16,0,17,9,4,512,20,522,17,8,1,1,2,16,523,21,0,1,1,17,3,9,16,522,16,17,523,21,0,5,1,1,513]

theorem envBound56549 : H12AffineFastState.Bounded env56549 := by
  intro p hp
  have h : env56549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56548_56549 : H12AffineEnvironment.transform 10 522 env56548 = env56549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env56548 == env56549) = true)

def leafEnv56549 : List Nat := [2,4,8,16,0,17,9,4,512,20,522,17,8,1,1,2,16,523,21,0,1,1,17,3,20,9,1,16,522,16,17,523,21,0,5,1,5,3,1,513,1,1,0]

def active56549 : List Nat := [0,1,2,3,8]

def tree56549 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood56549 : H12WitnessSearch.Good tree56549 := H12GlobalWitnessIndex.good

theorem leafIdentity56549 : H12AffineFastState.composeSystem env56549 rootObs = leafEnv56549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env56549 rootObs == leafEnv56549) = true)

theorem terminalChecked56549 : H12PackedTerminal.terminalCheckFast leafEnv56549 active56549 tree56549 = true := by decide +kernel

def env56550 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,16,9,1,1,3,16,2049,21,0,0,0,17,3,8,16,2048,16,16,2049,20,1,4,0,1,513]

theorem envBound56550 : H12AffineFastState.Bounded env56550 := by
  intro p hp
  have h : env56550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56547_56550 : H12AffineEnvironment.transform 4 1 env56547 = env56550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56547 == env56550) = true)

theorem identity56550 : scanCanonicalize (H12AffineFastState.compose env56550 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound56550 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56551 : List Nat := [2,4,8,16,1,17,9,5,512,20,1,16,9,1,1,3,16,0,21,0,0,0,17,3,8,16,1,16,16,0,20,1,4,0,1,513]

theorem envBound56551 : H12AffineFastState.Bounded env56551 := by
  intro p hp
  have h : env56551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56550_56551 : H12AffineEnvironment.transform 10 1 env56550 = env56551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env56550 == env56551) = true)

def leafEnv56551 : List Nat := [2,4,8,16,1,17,9,5,512,20,1,16,9,1,1,3,16,0,21,0,0,0,17,3,21,8,1,16,1,16,16,0,20,1,4,0,5,2,1,513,1,0,0]

def active56551 : List Nat := [0,1,2,3,8]

def tree56551 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood56551 : H12WitnessSearch.Good tree56551 := H12GlobalWitnessIndex.good

theorem leafIdentity56551 : H12AffineFastState.composeSystem env56551 rootObs = leafEnv56551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env56551 rootObs == leafEnv56551) = true)

theorem terminalChecked56551 : H12PackedTerminal.terminalCheckFast leafEnv56551 active56551 tree56551 = true := by decide +kernel

def env56552 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,2097152,4194304,8388608,10588557,8328,65,6458736,8393985,10507600,8527100,2102685,12645453,257,21792,46213,2175563]

theorem envBound56552 : H12AffineFastState.Bounded env56552 := by
  intro p hp
  have h : env56552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56457_56552 : H12AffineEnvironment.transform 17 56573 env56457 = env56552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56573 env56457 == env56552) = true)

def env56553 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4160,4194304,8388608,8487373,8328,65,4365616,8393985,8406288,8527100,1501,12645453,257,21792,46213,74251]

theorem envBound56553 : H12AffineFastState.Bounded env56553 := by
  intro p hp
  have h : env56553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56552_56553 : H12AffineEnvironment.transform 20 4160 env56552 = env56553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env56552 == env56553) = true)

def env56554 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4160,4194304,16,98781,8328,65,4365616,5393,17664,138476,1501,4256861,257,21792,46213,74251]

theorem envBound56554 : H12AffineFastState.Bounded env56554 := by
  intro p hp
  have h : env56554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56553_56554 : H12AffineEnvironment.transform 22 16 env56553 = env56554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env56553 == env56554) = true)

theorem identity56554 : scanCanonicalize (H12AffineFastState.compose env56554 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 73891) := by decide +kernel

theorem selectedBound56554 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56555 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4160,73891,16,98781,8328,65,245139,5393,17664,138476,1501,120062,257,21792,46213,74251]

theorem envBound56555 : H12AffineFastState.Bounded env56555 := by
  intro p hp
  have h : env56555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56554_56555 : H12AffineEnvironment.transform 21 73891 env56554 = env56555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73891 env56554 == env56555) = true)

def env56556 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4160,73771,16,98645,8192,65,245019,5393,17664,138340,1365,119926,257,21792,46093,74251]

theorem envBound56556 : H12AffineFastState.Bounded env56556 := by
  intro p hp
  have h : env56556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56555_56556 : H12AffineEnvironment.transform 6 8 env56555 = env56556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56555 == env56556) = true)

theorem identity56556 : scanCanonicalize (H12AffineFastState.compose env56556 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound56556 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56557 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,35188,1025,32769,4160,73771,16,98645,8192,65,245019,5393,4097,138340,1365,98679,257,33,46093,74251]

theorem envBound56557 : H12AffineFastState.Bounded env56557 := by
  intro p hp
  have h : env56557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56556_56557 : H12AffineEnvironment.transform 13 5377 env56556 = env56557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env56556 == env56557) = true)

theorem identity56557 : scanCanonicalize (H12AffineFastState.compose env56557 (packedSelected [0,1,9,10,16,20,22,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 103495) := by decide +kernel

theorem selectedBound56557 : packedSelected [0,1,9,10,16,20,22,26,27,28] rootPS < 2^1333 := by decide +kernel

def env56558 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,103495,35188,1025,32769,4160,73771,16,98645,8192,65,10588,5393,4097,100387,1365,98679,257,33,46093,74251]

theorem envBound56558 : H12AffineFastState.Bounded env56558 := by
  intro p hp
  have h : env56558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56557_56558 : H12AffineEnvironment.transform 16 103495 env56557 = env56558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103495 env56557 == env56558) = true)

theorem identity56558 : scanCanonicalize (H12AffineFastState.compose env56558 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound56558 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env56559 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,5392,35188,1025,32769,4160,41340,16,2,8192,65,10588,5393,4097,2420,1365,32,257,33,46093,41820]

theorem envBound56559 : H12AffineFastState.Bounded env56559 := by
  intro p hp
  have h : env56559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56558_56559 : H12AffineEnvironment.transform 15 33111 env56558 = env56559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env56558 == env56559) = true)

theorem identity56559 : scanCanonicalize (H12AffineFastState.compose env56559 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 7433) := by decide +kernel

theorem selectedBound56559 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env56560 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7433,5377,32768,33111,5392,35188,1025,32769,4160,40053,16,2,7433,65,5205,5393,4097,2420,1365,32,257,33,35076,40533]

theorem envBound56560 : H12AffineFastState.Bounded env56560 := by
  intro p hp
  have h : env56560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56559_56560 : H12AffineEnvironment.transform 12 7433 env56559 = env56560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7433 env56559 == env56560) = true)

theorem identity56560 : scanCanonicalize (H12AffineFastState.compose env56560 (packedSelected [0,2,3,5,6,7,10,11,14] rootPS)) = affineNative (2^(14+1) ^^^ 4113) := by decide +kernel

theorem selectedBound56560 : packedSelected [0,2,3,5,6,7,10,11,14] rootPS < 2^1333 := by decide +kernel

def env56561 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7433,5377,4113,4422,5392,6501,1025,4112,4160,3172,16,2,7433,65,5205,5393,4097,2420,1365,32,257,33,6421,3652]

theorem envBound56561 : H12AffineFastState.Bounded env56561 := by
  intro p hp
  have h : env56561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56560_56561 : H12AffineEnvironment.transform 14 4113 env56560 = env56561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4113 env56560 == env56561) = true)

theorem identity56561 : scanCanonicalize (H12AffineFastState.compose env56561 (packedSelected [3,5,6,10,11,16] rootPS)) = affineNative (2^(11+1) ^^^ 96) := by decide +kernel

theorem selectedBound56561 : packedSelected [3,5,6,10,11,16] rootPS < 2^1333 := by decide +kernel

def env56562 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,96,3433,1377,113,294,1392,2309,1025,112,32,3172,16,2,3433,65,1077,1393,97,2420,1365,32,257,33,2421,3652]

theorem envBound56562 : H12AffineFastState.Bounded env56562 := by
  intro p hp
  have h : env56562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56561_56562 : H12AffineEnvironment.transform 11 96 env56561 = env56562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 96 env56561 == env56562) = true)

theorem identity56562 : scanCanonicalize (H12AffineFastState.compose env56562 (packedSelected [0,3,4,6,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound56562 : packedSelected [0,3,4,6,8,11] rootPS < 2^1333 := by decide +kernel

def env56563 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,96,2169,113,113,294,96,2309,273,112,32,2420,16,2,2169,65,293,97,97,2420,69,32,257,33,2421,2900]

theorem envBound56563 : H12AffineFastState.Bounded env56563 := by
  intro p hp
  have h : env56563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56562_56563 : H12AffineEnvironment.transform 9 272 env56562 = env56563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env56562 == env56563) = true)

theorem identity56563 : scanCanonicalize (H12AffineFastState.compose env56563 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 341) := by decide +kernel

theorem selectedBound56563 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56564 : List Nat := [2,4,8,16,32,64,8,256,512,272,341,96,300,113,113,294,96,80,273,112,32,33,16,2,300,65,293,97,97,33,69,32,257,33,32,513]

theorem envBound56564 : H12AffineFastState.Bounded env56564 := by
  intro p hp
  have h : env56564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56563_56564 : H12AffineEnvironment.transform 10 341 env56563 = env56564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 341 env56563 == env56564) = true)

theorem identity56564 : scanCanonicalize (H12AffineFastState.compose env56564 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound56564 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56565 : List Nat := [2,4,8,16,32,64,8,20,512,4,65,96,56,113,113,50,96,80,5,112,32,33,16,2,56,65,49,97,97,33,69,32,21,33,32,513]

theorem envBound56565 : H12AffineFastState.Bounded env56565 := by
  intro p hp
  have h : env56565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56564_56565 : H12AffineEnvironment.transform 7 20 env56564 = env56565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env56564 == env56565) = true)

theorem identity56565 : scanCanonicalize (H12AffineFastState.compose env56565 (packedSelected [0,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound56565 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env56566 : List Nat := [2,4,8,16,32,64,8,20,26,4,65,96,56,113,113,50,96,80,5,112,32,33,16,2,56,65,49,97,97,33,69,32,21,33,32,27]

theorem envBound56566 : H12AffineFastState.Bounded env56566 := by
  intro p hp
  have h : env56566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56565_56566 : H12AffineEnvironment.transform 8 26 env56565 = env56566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env56565 == env56566) = true)

def env56567 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4160,73770,16,98644,8193,65,245018,5393,17664,138341,1364,119927,257,21792,46092,74251]

theorem envBound56567 : H12AffineFastState.Bounded env56567 := by
  intro p hp
  have h : env56567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56555_56567 : H12AffineEnvironment.transform 6 9 env56555 = env56567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56555 == env56567) = true)

theorem identity56567 : scanCanonicalize (H12AffineFastState.compose env56567 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound56567 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56568 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10281,1025,29788,4160,73770,16,95497,8193,65,215367,5393,17664,138341,1364,73770,257,21792,16465,74251]

theorem envBound56568 : H12AffineFastState.Bounded env56568 := by
  intro p hp
  have h : env56568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56567_56568 : H12AffineEnvironment.transform 14 29789 env56567 = env56568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env56567 == env56568) = true)

theorem identity56568 : scanCanonicalize (H12AffineFastState.compose env56568 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound56568 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env56569 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,16401,10281,1025,29788,4160,73770,16,95497,8193,65,67926,5393,17664,23668,1364,73770,257,21792,16465,74251]

theorem envBound56569 : H12AffineFastState.Bounded env56569 := by
  intro p hp
  have h : env56569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56568_56569 : H12AffineEnvironment.transform 16 16401 env56568 = env56569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env56568 == env56569) = true)

theorem identity56569 : scanCanonicalize (H12AffineFastState.compose env56569 (packedSelected [1,8,19] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound56569 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env56570 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29962,16401,10281,1025,29788,4160,21792,16,3,8193,65,31836,5393,17664,23668,1364,21792,257,21792,16465,22273]

theorem envBound56570 : H12AffineFastState.Bounded env56570 := by
  intro p hp
  have h : env56570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56569_56570 : H12AffineEnvironment.transform 15 29962 env56569 = env56570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env56569 == env56570) = true)

theorem identity56570 : scanCanonicalize (H12AffineFastState.compose env56570 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound56570 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56571 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8202,5393,10281,1025,8540,4160,32,16,3,8193,65,10588,5393,4096,2420,1364,32,257,32,5457,513]

theorem envBound56571 : H12AffineFastState.Bounded env56571 := by
  intro p hp
  have h : env56571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56570_56571 : H12AffineEnvironment.transform 13 5376 env56570 = env56571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env56570 == env56571) = true)

theorem identity56571 : scanCanonicalize (H12AffineFastState.compose env56571 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound56571 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env56572 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,89,5376,260,83,5393,2160,1025,261,4160,32,16,3,88,65,2309,5393,4096,2420,1364,32,257,32,5457,513]

theorem envBound56572 : H12AffineFastState.Bounded env56572 := by
  intro p hp
  have h : env56572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56571_56572 : H12AffineEnvironment.transform 12 89 env56571 = env56572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env56571 == env56572) = true)

theorem identity56572 : scanCanonicalize (H12AffineFastState.compose env56572 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56572 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env56573 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,9,5376,260,3,5393,2080,1025,261,4112,32,16,3,8,17,2309,5393,4096,2340,1284,32,257,32,5377,513]

theorem envBound56573 : H12AffineFastState.Bounded env56573 := by
  intro p hp
  have h : env56573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56572_56573 : H12AffineEnvironment.transform 5 16 env56572 = env56573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56572 == env56573) = true)

theorem identity56573 : scanCanonicalize (H12AffineFastState.compose env56573 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound56573 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56574 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,292,9,1060,260,3,1077,2080,1025,261,308,32,16,3,8,17,2309,1077,292,2340,1284,32,257,32,1061,513]

theorem envBound56574 : H12AffineFastState.Bounded env56574 := by
  intro p hp
  have h : env56574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56573_56574 : H12AffineEnvironment.transform 11 292 env56573 = env56574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env56573 == env56574) = true)

theorem identity56574 : scanCanonicalize (H12AffineFastState.compose env56574 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound56574 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56575 : List Nat := [2,4,8,16,32,16,9,256,0,1024,2048,292,9,1060,260,3,1077,2080,1025,261,308,32,16,3,8,17,2309,1077,292,2340,1284,32,257,32,1061,1]

theorem envBound56575 : H12AffineFastState.Bounded env56575 := by
  intro p hp
  have h : env56575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56574_56575 : H12AffineEnvironment.transform 8 0 env56574 = env56575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env56574 == env56575) = true)

def env56576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4160,4194304,17,98780,8328,65,4365616,5392,17665,138477,1501,4256860,257,21792,46213,74251]

theorem envBound56576 : H12AffineFastState.Bounded env56576 := by
  intro p hp
  have h : env56576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56553_56576 : H12AffineEnvironment.transform 22 17 env56553 = env56576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env56553 == env56576) = true)

theorem identity56576 : scanCanonicalize (H12AffineFastState.compose env56576 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound56576 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56573,1025,32769,4160,4194304,17,41430,8328,65,4365616,5392,17665,138477,1501,4256860,257,21792,46213,513]

theorem envBound56577 : H12AffineFastState.Bounded env56577 := by
  intro p hp
  have h : env56577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56576_56577 : H12AffineEnvironment.transform 15 8202 env56576 = env56577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env56576 == env56577) = true)

theorem identity56577 : scanCanonicalize (H12AffineFastState.compose env56577 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 112) := by decide +kernel

theorem selectedBound56577 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env56578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56573,1025,32769,4160,112,17,41430,8328,65,171328,5392,17665,138477,1501,62508,257,21792,46213,513]

theorem envBound56578 : H12AffineFastState.Bounded env56578 := by
  intro p hp
  have h : env56578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56577_56578 : H12AffineEnvironment.transform 21 112 env56577 = env56578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 112 env56577 == env56578) = true)

def env56579 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56437,1025,32769,4160,112,17,41310,8192,65,171328,5392,17665,138341,1365,62508,257,21792,46093,513]

theorem envBound56579 : H12AffineFastState.Bounded env56579 := by
  intro p hp
  have h : env56579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56578_56579 : H12AffineEnvironment.transform 6 8 env56578 = env56579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56578 == env56579) = true)

theorem identity56579 : scanCanonicalize (H12AffineFastState.compose env56579 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound56579 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56580 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,131072,32041,1025,8541,4160,112,17,2,8192,65,146460,5392,17665,138341,1365,21872,257,21792,5457,513]

theorem envBound56580 : H12AffineFastState.Bounded env56580 := by
  intro p hp
  have h : env56580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56579_56580 : H12AffineEnvironment.transform 14 8540 env56579 = env56580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env56579 == env56580) = true)

theorem identity56580 : scanCanonicalize (H12AffineFastState.compose env56580 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound56580 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env56581 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,16384,8540,8202,131072,30776,272,8541,4160,112,17,2,8192,65,145677,4097,16400,137588,68,20577,257,20529,4160,513]

theorem envBound56581 : H12AffineFastState.Bounded env56581 := by
  intro p hp
  have h : env56581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56580_56581 : H12AffineEnvironment.transform 9 273 env56580 = env56581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env56580 == env56581) = true)

theorem identity56581 : scanCanonicalize (H12AffineFastState.compose env56581 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 12409) := by decide +kernel

theorem selectedBound56581 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env56582 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,16384,8540,8202,12409,30776,272,8541,4160,112,17,2,8192,65,2420,4097,16400,10509,68,20577,257,20529,4160,513]

theorem envBound56582 : H12AffineFastState.Bounded env56582 := by
  intro p hp
  have h : env56582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56581_56582 : H12AffineEnvironment.transform 16 12409 env56581 = env56582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12409 env56581 == env56582) = true)

theorem identity56582 : scanCanonicalize (H12AffineFastState.compose env56582 (packedSelected [9,14,22] rootPS)) = affineNative (2^(13+1) ^^^ 12392) := by decide +kernel

theorem selectedBound56582 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env56583 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,12392,8540,8202,12409,2128,272,8541,4160,112,17,2,8192,65,2420,4097,12408,10509,68,8201,257,8281,4160,513]

theorem envBound56583 : H12AffineFastState.Bounded env56583 := by
  intro p hp
  have h : env56583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56582_56583 : H12AffineEnvironment.transform 13 12392 env56582 = env56583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12392 env56582 == env56583) = true)

theorem identity56583 : scanCanonicalize (H12AffineFastState.compose env56583 (packedSelected [14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound56583 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env56584 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,349,4405,1,343,4388,2128,272,0,4160,112,17,2,349,65,2420,4097,4389,2128,68,340,257,260,4160,513]

theorem envBound56584 : H12AffineFastState.Bounded env56584 := by
  intro p hp
  have h : env56584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56583_56584 : H12AffineEnvironment.transform 12 349 env56583 = env56584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env56583 == env56584) = true)

theorem identity56584 : scanCanonicalize (H12AffineFastState.compose env56584 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound56584 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env56585 : List Nat := [2,4,8,16,32,64,8,36,512,53,2048,4096,121,4113,1,115,4096,2128,52,0,4160,112,17,2,121,65,2128,4097,4097,2128,68,112,37,32,4160,513]

theorem envBound56585 : H12AffineFastState.Bounded env56585 := by
  intro p hp
  have h : env56585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56584_56585 : H12AffineEnvironment.transform 7 36 env56584 = env56585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env56584 == env56585) = true)

theorem identity56585 : scanCanonicalize (H12AffineFastState.compose env56585 (packedSelected [1,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound56585 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env56586 : List Nat := [2,4,8,16,32,64,8,36,512,53,2048,513,121,528,1,115,513,2128,52,0,577,112,17,2,121,65,2128,512,512,2128,68,112,37,32,577,513]

theorem envBound56586 : H12AffineFastState.Bounded env56586 := by
  intro p hp
  have h : env56586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56585_56586 : H12AffineEnvironment.transform 11 513 env56585 = env56586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env56585 == env56586) = true)

theorem identity56586 : scanCanonicalize (H12AffineFastState.compose env56586 (packedSelected [3,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound56586 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env56587 : List Nat := [2,4,8,16,0,64,8,4,512,21,2048,513,89,528,1,83,513,2128,20,0,577,80,17,2,89,65,2128,512,512,2128,68,80,5,0,577,513]

theorem envBound56587 : H12AffineFastState.Bounded env56587 := by
  intro p hp
  have h : env56587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56586_56587 : H12AffineEnvironment.transform 4 0 env56586 = env56587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env56586 == env56587) = true)

theorem identity56587 : scanCanonicalize (H12AffineFastState.compose env56587 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound56587 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56588 : List Nat := [2,4,8,16,0,17,8,4,512,21,2048,513,8,528,1,2,513,2049,20,0,528,1,17,2,8,16,2049,512,512,2049,21,1,5,0,528,513]

theorem envBound56588 : H12AffineFastState.Bounded env56588 := by
  intro p hp
  have h : env56588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56587_56588 : H12AffineEnvironment.transform 5 17 env56587 = env56588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56587 == env56588) = true)

theorem identity56588 : scanCanonicalize (H12AffineFastState.compose env56588 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound56588 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56589 : List Nat := [2,4,8,1,0,0,8,4,512,4,2048,513,8,513,1,2,513,2049,5,0,513,1,0,2,8,1,2049,512,512,2049,4,1,5,0,513,513]

theorem envBound56589 : H12AffineFastState.Bounded env56589 := by
  intro p hp
  have h : env56589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56588_56589 : H12AffineEnvironment.transform 3 1 env56588 = env56589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56588 == env56589) = true)

theorem identity56589 : scanCanonicalize (H12AffineFastState.compose env56589 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound56589 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env56590 : List Nat := [2,4,8,1,0,0,8,4,1,4,2048,0,8,0,1,2,0,2049,5,0,0,1,0,2,8,1,2049,1,1,2049,4,1,5,0,0,0]

theorem envBound56590 : H12AffineFastState.Bounded env56590 := by
  intro p hp
  have h : env56590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56589_56590 : H12AffineEnvironment.transform 8 1 env56589 = env56590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env56589 == env56590) = true)

theorem identity56590 : scanCanonicalize (H12AffineFastState.compose env56590 (packedSelected [7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound56590 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env56591 : List Nat := [2,4,8,1,0,0,8,4,1,4,1,0,8,0,1,2,0,0,5,0,0,1,0,2,8,1,0,1,1,0,4,1,5,0,0,0]

theorem envBound56591 : H12AffineFastState.Bounded env56591 := by
  intro p hp
  have h : env56591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56590_56591 : H12AffineEnvironment.transform 10 1 env56590 = env56591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env56590 == env56591) = true)

def env56592 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56436,1025,32769,4160,112,17,41311,8193,65,171328,5392,17665,138340,1364,62508,257,21792,46092,513]

theorem envBound56592 : H12AffineFastState.Bounded env56592 := by
  intro p hp
  have h : env56592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56578_56592 : H12AffineEnvironment.transform 6 9 env56578 = env56592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56578 == env56592) = true)

def env56593 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56356,1025,32769,4112,32,17,41231,8193,17,171280,5392,17665,138292,1284,62508,257,21792,46092,513]

theorem envBound56593 : H12AffineFastState.Bounded env56593 := by
  intro p hp
  have h : env56593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56592_56593 : H12AffineEnvironment.transform 5 16 env56592 = env56593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56592 == env56593) = true)

theorem identity56593 : scanCanonicalize (H12AffineFastState.compose env56593 (packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound56593 : packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS < 2^1333 := by decide +kernel

def env56594 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,8202,49169,56356,1025,32769,4112,32,17,41231,8193,17,23809,5392,17665,56357,1284,62508,257,21792,46092,513]

theorem envBound56594 : H12AffineFastState.Bounded env56594 := by
  intro p hp
  have h : env56594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56593_56594 : H12AffineEnvironment.transform 16 49169 env56593 = env56594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env56593 == env56594) = true)

theorem identity56594 : scanCanonicalize (H12AffineFastState.compose env56594 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound56594 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env56595 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,32768,263,49169,56356,1025,32769,4112,32,17,32770,268,17,23809,5392,17665,56357,1284,54561,257,21792,38145,513]

theorem envBound56595 : H12AffineFastState.Bounded env56595 := by
  intro p hp
  have h : env56595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56594_56595 : H12AffineEnvironment.transform 12 269 env56594 = env56595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env56594 == env56595) = true)

theorem identity56595 : scanCanonicalize (H12AffineFastState.compose env56595 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound56595 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env56596 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5376,32768,263,38161,35108,1025,32769,4112,32,17,32770,268,17,2049,5392,4097,35109,1284,32801,257,32,38145,513]

theorem envBound56596 : H12AffineFastState.Bounded env56596 := by
  intro p hp
  have h : env56596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56595_56596 : H12AffineEnvironment.transform 13 5376 env56595 = env56596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env56595 == env56596) = true)

theorem identity56596 : scanCanonicalize (H12AffineFastState.compose env56596 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound56596 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56597 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5376,0,263,5393,2340,1025,1,4112,32,17,2,268,17,2049,5392,4097,2341,1284,33,257,32,5377,513]

theorem envBound56597 : H12AffineFastState.Bounded env56597 := by
  intro p hp
  have h : env56597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56596_56597 : H12AffineEnvironment.transform 14 0 env56596 = env56597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env56596 == env56597) = true)

theorem identity56597 : scanCanonicalize (H12AffineFastState.compose env56597 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound56597 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56598 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,4096,8,5125,0,2,5140,2081,1025,1,4112,32,17,2,9,17,2049,5141,4097,2080,1025,33,4,32,5124,513]

theorem envBound56598 : H12AffineFastState.Bounded env56598 := by
  intro p hp
  have h : env56598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56597_56598 : H12AffineEnvironment.transform 7 5 env56597 = env56598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env56597 == env56598) = true)

theorem identity56598 : scanCanonicalize (H12AffineFastState.compose env56598 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound56598 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56599 : List Nat := [2,4,8,16,32,16,9,5,512,52,2048,4096,8,4145,0,2,4128,2081,53,1,4112,32,17,2,9,17,2049,4129,4097,2080,53,33,4,32,4144,513]

theorem envBound56599 : H12AffineFastState.Bounded env56599 := by
  intro p hp
  have h : env56599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56598_56599 : H12AffineEnvironment.transform 9 52 env56598 = env56599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env56598 == env56599) = true)

theorem identity56599 : scanCanonicalize (H12AffineFastState.compose env56599 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2609) := by decide +kernel

theorem selectedBound56599 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56600 : List Nat := [2,4,8,16,32,16,9,5,512,52,2048,2609,8,2560,0,2,2577,2081,53,1,2593,32,17,2,9,17,2049,2576,2608,2080,53,33,4,32,2561,513]

theorem envBound56600 : H12AffineFastState.Bounded env56600 := by
  intro p hp
  have h : env56600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56599_56600 : H12AffineEnvironment.transform 11 2609 env56599 = env56600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2609 env56599 == env56600) = true)

theorem identity56600 : scanCanonicalize (H12AffineFastState.compose env56600 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 544) := by decide +kernel

theorem selectedBound56600 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56601 : List Nat := [2,4,8,16,32,16,9,5,512,52,544,17,8,32,0,2,49,513,53,1,1,32,17,2,9,17,545,48,16,512,53,33,4,32,33,513]

theorem envBound56601 : H12AffineFastState.Bounded env56601 := by
  intro p hp
  have h : env56601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56600_56601 : H12AffineEnvironment.transform 10 544 env56600 = env56601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 544 env56600 == env56601) = true)

theorem identity56601 : scanCanonicalize (H12AffineFastState.compose env56601 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound56601 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56602 : List Nat := [2,4,8,16,32,16,9,5,17,52,49,17,8,32,0,2,49,16,53,1,1,32,17,2,9,17,48,48,16,17,53,33,4,32,33,16]

theorem envBound56602 : H12AffineFastState.Bounded env56602 := by
  intro p hp
  have h : env56602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56601_56602 : H12AffineEnvironment.transform 8 17 env56601 = env56602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env56601 == env56602) = true)

theorem identity56602 : scanCanonicalize (H12AffineFastState.compose env56602 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound56602 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env56603 : List Nat := [2,4,8,16,1,16,9,5,17,21,16,17,8,1,0,2,16,16,20,1,1,1,17,2,9,17,17,17,16,17,20,0,4,1,0,16]

theorem envBound56603 : H12AffineFastState.Bounded env56603 := by
  intro p hp
  have h : env56603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56602_56603 : H12AffineEnvironment.transform 4 1 env56602 = env56603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56602 == env56603) = true)

theorem identity56603 : scanCanonicalize (H12AffineFastState.compose env56603 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound56603 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56604 : List Nat := [2,4,8,10,1,10,9,5,11,15,10,11,8,1,0,2,10,10,14,1,1,1,11,2,9,11,11,11,10,11,14,0,4,1,0,10]

theorem envBound56604 : H12AffineFastState.Bounded env56604 := by
  intro p hp
  have h : env56604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56603_56604 : H12AffineEnvironment.transform 3 10 env56603 = env56604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env56603 == env56604) = true)

def env56605 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56357,1025,32769,4113,33,17,41230,8193,16,171281,5392,17665,138293,1285,62508,257,21792,46092,513]

theorem envBound56605 : H12AffineFastState.Bounded env56605 := by
  intro p hp
  have h : env56605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56592_56605 : H12AffineEnvironment.transform 5 17 env56592 = env56605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56592 == env56605) = true)

theorem identity56605 : scanCanonicalize (H12AffineFastState.compose env56605 (packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound56605 : packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS < 2^1333 := by decide +kernel

def env56606 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,32768,8202,131072,43048,1025,32769,4113,33,17,41230,8193,16,171281,5392,12556,138293,1285,32801,257,8493,46092,513]

theorem envBound56606 : H12AffineFastState.Bounded env56606 := by
  intro p hp
  have h : env56606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56605_56606 : H12AffineEnvironment.transform 13 13325 env56605 = env56606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env56605 == env56606) = true)

theorem identity56606 : scanCanonicalize (H12AffineFastState.compose env56606 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound56606 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env56607 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,32768,8202,5392,43048,1025,32769,4113,33,17,41230,8193,16,34817,5392,12556,2341,1285,32801,257,8493,46092,513]

theorem envBound56607 : H12AffineFastState.Bounded env56607 := by
  intro p hp
  have h : env56607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56606_56607 : H12AffineEnvironment.transform 16 5392 env56606 = env56607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env56606 == env56607) = true)

theorem identity56607 : scanCanonicalize (H12AffineFastState.compose env56607 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound56607 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56608 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,32768,262,5392,35108,1025,32769,4113,33,17,32770,269,16,34817,5392,4096,2341,1285,32801,257,33,38144,513]

theorem envBound56608 : H12AffineFastState.Bounded env56608 := by
  intro p hp
  have h : env56608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56607_56608 : H12AffineEnvironment.transform 12 268 env56607 = env56608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env56607 == env56608) = true)

theorem identity56608 : scanCanonicalize (H12AffineFastState.compose env56608 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound56608 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env56609 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,5156,32768,35,5173,34817,1025,32769,4113,33,17,32770,40,16,34817,5173,4096,2048,1056,32801,36,33,37925,513]

theorem envBound56609 : H12AffineFastState.Bounded env56609 := by
  intro p hp
  have h : env56609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56608_56609 : H12AffineEnvironment.transform 7 37 env56608 = env56609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env56608 == env56609) = true)

def env56610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4161,4194304,8388608,8487372,8328,65,4365617,8393985,8406289,8527100,1500,12645453,257,21792,46213,74250]

theorem envBound56610 : H12AffineFastState.Bounded env56610 := by
  intro p hp
  have h : env56610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56552_56610 : H12AffineEnvironment.transform 20 4161 env56552 = env56610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env56552 == env56610) = true)

def env56611 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4161,4194304,16,98780,8328,65,4365617,5393,17665,138476,1500,4256861,257,21792,46213,74250]

theorem envBound56611 : H12AffineFastState.Bounded env56611 := by
  intro p hp
  have h : env56611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56610_56611 : H12AffineEnvironment.transform 22 16 env56610 = env56611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env56610 == env56611) = true)

theorem identity56611 : scanCanonicalize (H12AffineFastState.compose env56611 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 119926) := by decide +kernel

theorem selectedBound56611 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56612 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4161,119926,16,98780,8328,65,215367,5393,17665,138476,1500,73771,257,21792,46213,74250]

theorem envBound56612 : H12AffineFastState.Bounded env56612 := by
  intro p hp
  have h : env56612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56611_56612 : H12AffineEnvironment.transform 21 119926 env56611 = env56612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 119926 env56611 == env56612) = true)

theorem identity56612 : scanCanonicalize (H12AffineFastState.compose env56612 (packedSelected [1,3,5,8,10,12,15,17,19,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound56612 : packedSelected [1,3,5,8,10,12,15,17,19,38,41] rootPS < 2^1333 := by decide +kernel

def env56613 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90139,56573,1025,32769,4161,119926,16,98780,8328,65,10588,5393,17665,97527,1500,73771,257,21792,46213,74250]

theorem envBound56613 : H12AffineFastState.Bounded env56613 := by
  intro p hp
  have h : env56613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56612_56613 : H12AffineEnvironment.transform 16 90139 env56612 = env56613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env56612 == env56613) = true)

def env56614 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,56437,1025,32769,4161,119926,16,98644,8192,65,10588,5393,17665,97407,1364,73771,257,21792,46093,74250]

theorem envBound56614 : H12AffineFastState.Bounded env56614 := by
  intro p hp
  have h : env56614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56613_56614 : H12AffineEnvironment.transform 6 8 env56613 = env56614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56613 == env56614) = true)

theorem identity56614 : scanCanonicalize (H12AffineFastState.compose env56614 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound56614 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56615 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,79130,35188,1025,32769,4161,98679,16,98644,8192,65,10588,5393,4096,76158,1364,73771,257,33,46093,74250]

theorem envBound56615 : H12AffineFastState.Bounded env56615 := by
  intro p hp
  have h : env56615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56614_56615 : H12AffineEnvironment.transform 13 5377 env56614 = env56615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env56614 == env56615) = true)

theorem identity56615 : scanCanonicalize (H12AffineFastState.compose env56615 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound56615 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env56616 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,5393,35188,1025,32769,4161,41340,16,41311,8192,65,10588,5393,4096,2421,1364,32,257,33,46093,513]

theorem envBound56616 : H12AffineFastState.Bounded env56616 := by
  intro p hp
  have h : env56616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56615_56616 : H12AffineEnvironment.transform 15 8203 env56615 = env56616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env56615 == env56616) = true)

theorem identity56616 : scanCanonicalize (H12AffineFastState.compose env56616 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound56616 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env56617 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,5377,32768,1046,5393,35188,1025,32769,4161,34145,16,34114,1053,65,3393,5393,4096,2421,1364,32,257,33,36880,513]

theorem envBound56617 : H12AffineFastState.Bounded env56617 := by
  intro p hp
  have h : env56617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56616_56617 : H12AffineEnvironment.transform 12 1053 env56616 = env56617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env56616 == env56617) = true)

theorem identity56617 : scanCanonicalize (H12AffineFastState.compose env56617 (packedSelected [2,3,6,8,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 3392) := by decide +kernel

theorem selectedBound56617 : packedSelected [2,3,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env56618 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,5377,3392,1046,5393,1076,1025,3393,4161,2081,16,2050,1053,65,3393,5393,4096,2421,1364,32,257,33,7504,513]

theorem envBound56618 : H12AffineFastState.Bounded env56618 := by
  intro p hp
  have h : env56618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56617_56618 : H12AffineEnvironment.transform 14 3392 env56617 = env56618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3392 env56617 == env56618) = true)

theorem identity56618 : scanCanonicalize (H12AffineFastState.compose env56618 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 1361) := by decide +kernel

theorem selectedBound56618 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env56619 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1361,1053,80,3392,1046,64,1076,1025,3393,1296,2081,16,2050,1053,65,3393,64,1361,2421,1364,32,257,33,2049,513]

theorem envBound56619 : H12AffineFastState.Bounded env56619 := by
  intro p hp
  have h : env56619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56618_56619 : H12AffineEnvironment.transform 11 1361 env56618 = env56619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1361 env56618 == env56619) = true)

def env56620 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,56436,1025,32769,4161,119926,16,98645,8193,65,10588,5393,17665,97406,1365,73771,257,21792,46092,74250]

theorem envBound56620 : H12AffineFastState.Bounded env56620 := by
  intro p hp
  have h : env56620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56613_56620 : H12AffineEnvironment.transform 6 9 env56613 = env56620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56613 == env56620) = true)

theorem identity56620 : scanCanonicalize (H12AffineFastState.compose env56620 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound56620 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56621 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90139,10281,1025,29788,4161,73771,16,95496,8193,65,10588,5393,17665,97406,1365,73771,257,21792,16465,74250]

theorem envBound56621 : H12AffineFastState.Bounded env56621 := by
  intro p hp
  have h : env56621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56620_56621 : H12AffineEnvironment.transform 14 29789 env56620 = env56621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env56620 == env56621) = true)

theorem identity56621 : scanCanonicalize (H12AffineFastState.compose env56621 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound56621 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env56622 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,16401,10281,1025,29788,4161,33,16,21762,8193,65,10588,5393,17665,23668,1365,33,257,21792,16465,512]

theorem envBound56622 : H12AffineFastState.Bounded env56622 := by
  intro p hp
  have h : env56622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56621_56622 : H12AffineEnvironment.transform 15 8202 env56621 = env56622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env56621 == env56622) = true)

theorem identity56622 : scanCanonicalize (H12AffineFastState.compose env56622 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound56622 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56623 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,343,16401,2420,1025,21761,4161,33,16,21762,348,65,2049,5393,17665,23668,1365,33,257,21792,16465,512]

theorem envBound56623 : H12AffineFastState.Bounded env56623 := by
  intro p hp
  have h : env56623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56622_56623 : H12AffineEnvironment.transform 12 349 env56622 = env56623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env56622 == env56623) = true)

theorem identity56623 : scanCanonicalize (H12AffineFastState.compose env56623 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound56623 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56624 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,349,16384,21760,343,16401,2388,1025,21761,4161,1,16,21762,348,65,2049,5393,17665,23636,1365,1,257,21760,16465,512]

theorem envBound56624 : H12AffineFastState.Bounded env56624 := by
  intro p hp
  have h : env56624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56623_56624 : H12AffineEnvironment.transform 4 0 env56623 = env56624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env56623 == env56624) = true)

theorem identity56624 : scanCanonicalize (H12AffineFastState.compose env56624 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound56624 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env56625 : List Nat := [2,4,8,16,0,64,9,256,512,1024,261,4096,349,16384,21760,343,16401,81,1025,21761,4161,1,16,21762,348,65,260,5393,17665,21841,1365,1,257,21760,16465,512]

theorem envBound56625 : H12AffineFastState.Bounded env56625 := by
  intro p hp
  have h : env56625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56624_56625 : H12AffineEnvironment.transform 10 261 env56624 = env56625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env56624 == env56625) = true)

theorem identity56625 : scanCanonicalize (H12AffineFastState.compose env56625 (packedSelected [2,3,4,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 842) := by decide +kernel

theorem selectedBound56625 : packedSelected [2,3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env56626 : List Nat := [2,4,8,16,0,64,9,256,512,842,261,4096,349,16384,21066,343,16401,81,843,21067,4161,1,16,21064,348,65,260,4699,16971,21019,543,1,257,21066,16465,512]

theorem envBound56626 : H12AffineFastState.Bounded env56626 := by
  intro p hp
  have h : env56626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56625_56626 : H12AffineEnvironment.transform 9 842 env56625 = env56626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 842 env56625 == env56626) = true)

theorem identity56626 : scanCanonicalize (H12AffineFastState.compose env56626 (packedSelected [0,2,3,7,8,14] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound56626 : packedSelected [0,2,3,7,8,14] rootPS < 2^1333 := by decide +kernel

def env56627 : List Nat := [2,4,8,16,0,64,9,256,270,68,261,4096,349,16384,20804,343,16401,81,69,20805,4161,1,16,20806,348,65,260,4437,16709,20757,273,1,257,20804,16465,270]

theorem envBound56627 : H12AffineFastState.Bounded env56627 := by
  intro p hp
  have h : env56627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56626_56627 : H12AffineEnvironment.transform 8 270 env56626 = env56627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env56626 == env56627) = true)

theorem identity56627 : scanCanonicalize (H12AffineFastState.compose env56627 (packedSelected [2,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56627 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env56628 : List Nat := [2,4,8,16,0,16,9,256,270,20,261,4096,269,16384,20756,263,16401,1,21,20757,4113,1,16,20758,268,17,260,4357,16661,20757,273,1,257,20756,16385,270]

theorem envBound56628 : H12AffineFastState.Bounded env56628 := by
  intro p hp
  have h : env56628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56627_56628 : H12AffineEnvironment.transform 5 16 env56627 = env56628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56627 == env56628) = true)

theorem identity56628 : scanCanonicalize (H12AffineFastState.compose env56628 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4372) := by decide +kernel

theorem selectedBound56628 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56629 : List Nat := [2,4,8,16,0,16,9,256,270,20,261,4096,269,4372,0,263,4357,1,21,1,4113,1,16,2,268,17,260,4357,4097,1,273,1,257,0,4373,270]

theorem envBound56629 : H12AffineFastState.Bounded env56629 := by
  intro p hp
  have h : env56629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56628_56629 : H12AffineEnvironment.transform 13 4372 env56628 = env56629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4372 env56628 == env56629) = true)

theorem identity56629 : scanCanonicalize (H12AffineFastState.compose env56629 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound56629 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56630 : List Nat := [2,4,8,16,0,16,9,256,270,20,261,276,269,0,0,263,17,1,21,1,261,1,16,2,268,17,260,17,277,1,273,1,257,0,1,270]

theorem envBound56630 : H12AffineFastState.Bounded env56630 := by
  intro p hp
  have h : env56630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56629_56630 : H12AffineEnvironment.transform 11 276 env56629 = env56630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env56629 == env56630) = true)

theorem identity56630 : scanCanonicalize (H12AffineFastState.compose env56630 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound56630 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56631 : List Nat := [2,4,8,16,0,16,9,4,10,20,1,16,9,0,0,3,17,1,21,1,1,1,16,2,8,17,0,17,17,1,21,1,5,0,1,10]

theorem envBound56631 : H12AffineFastState.Bounded env56631 := by
  intro p hp
  have h : env56631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56630_56631 : H12AffineEnvironment.transform 7 4 env56630 = env56631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env56630 == env56631) = true)

theorem identity56631 : scanCanonicalize (H12AffineFastState.compose env56631 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound56631 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56632 : List Nat := [2,0,8,16,0,16,9,0,10,16,1,16,9,0,0,3,17,1,17,1,1,1,16,2,8,17,0,17,17,1,17,1,1,0,1,10]

theorem envBound56632 : H12AffineFastState.Bounded env56632 := by
  intro p hp
  have h : env56632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56631_56632 : H12AffineEnvironment.transform 1 0 env56631 = env56632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env56631 == env56632) = true)

theorem identity56632 : scanCanonicalize (H12AffineFastState.compose env56632 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound56632 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56633 : List Nat := [2,0,8,2,0,2,9,0,10,2,1,2,9,0,0,3,3,1,3,1,1,1,2,2,8,3,0,3,3,1,3,1,1,0,1,10]

theorem envBound56633 : H12AffineFastState.Bounded env56633 := by
  intro p hp
  have h : env56633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56632_56633 : H12AffineEnvironment.transform 3 2 env56632 = env56633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env56632 == env56633) = true)

def env56634 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4161,4194304,17,98781,8328,65,4365617,5392,17664,138477,1500,4256860,257,21792,46213,74250]

theorem envBound56634 : H12AffineFastState.Bounded env56634 := by
  intro p hp
  have h : env56634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56610_56634 : H12AffineEnvironment.transform 22 17 env56610 = env56634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env56610 == env56634) = true)

theorem identity56634 : scanCanonicalize (H12AffineFastState.compose env56634 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound56634 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56635 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,56573,1025,32769,4161,4194304,17,21762,8328,65,4365617,5392,17664,138477,1500,4256860,257,21792,46213,63189]

theorem envBound56635 : H12AffineFastState.Bounded env56635 := by
  intro p hp
  have h : env56635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56634_56635 : H12AffineEnvironment.transform 15 54495 env56634 = env56635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env56634 == env56635) = true)

theorem identity56635 : scanCanonicalize (H12AffineFastState.compose env56635 (packedSelected [1,4,5,7,8,9,11,14,16,18,19,20,23,24,26,27,32,35] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound56635 : packedSelected [1,4,5,7,8,9,11,14,16,18,19,20,23,24,26,27,32,35] rootPS < 2^1333 := by decide +kernel

def env56636 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,56436,1025,32769,4161,4194304,17,21762,8193,65,4365617,5392,17664,138340,1365,4256860,257,21792,46092,63068]

theorem envBound56636 : H12AffineFastState.Bounded env56636 := by
  intro p hp
  have h : env56636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56635_56636 : H12AffineEnvironment.transform 6 9 env56635 = env56636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56635 == env56636) = true)

theorem identity56636 : scanCanonicalize (H12AffineFastState.compose env56636 (packedSelected [0,3,5,8,9,11,12,15,16,18,19,20,22,26,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 41341) := by decide +kernel

theorem selectedBound56636 : packedSelected [0,3,5,8,9,11,12,15,16,18,19,20,22,26,27,28] rootPS < 2^1333 := by decide +kernel

def env56637 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,56436,1025,32769,4161,41341,17,21762,8193,65,146508,5392,17664,138340,1365,21793,257,21792,46092,63068]

theorem envBound56637 : H12AffineFastState.Bounded env56637 := by
  intro p hp
  have h : env56637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56636_56637 : H12AffineEnvironment.transform 21 41341 env56636 = env56637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41341 env56636 == env56637) = true)

theorem identity56637 : scanCanonicalize (H12AffineFastState.compose env56637 (packedSelected [3,4,5,7,11,15,16,19,22,27] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound56637 : packedSelected [3,4,5,7,11,15,16,19,22,27] rootPS < 2^1333 := by decide +kernel

def env56638 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,57677,56436,1025,32769,4161,41341,17,21762,8193,65,56577,5392,17664,64809,1365,21793,257,21792,46092,63068]

theorem envBound56638 : H12AffineFastState.Bounded env56638 := by
  intro p hp
  have h : env56638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56637_56638 : H12AffineEnvironment.transform 16 57677 env56637 = env56638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env56637 == env56638) = true)

theorem identity56638 : scanCanonicalize (H12AffineFastState.compose env56638 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound56638 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env56639 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,54358,49169,56436,1025,32769,4161,32801,17,21762,349,65,56577,5392,17664,56437,1365,21793,257,21792,38224,55040]

theorem envBound56639 : H12AffineFastState.Bounded env56639 := by
  intro p hp
  have h : env56639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56638_56639 : H12AffineEnvironment.transform 12 348 env56638 = env56639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env56638 == env56639) = true)

theorem identity56639 : scanCanonicalize (H12AffineFastState.compose env56639 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56639 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env56640 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,32768,54278,49169,56356,1025,32769,4113,32801,17,21762,269,17,56577,5392,17664,56357,1285,21793,257,21792,38144,55040]

theorem envBound56640 : H12AffineFastState.Bounded env56640 := by
  intro p hp
  have h : env56640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56639_56640 : H12AffineEnvironment.transform 5 16 env56639 = env56640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56639 == env56640) = true)

theorem identity56640 : scanCanonicalize (H12AffineFastState.compose env56640 (packedSelected [0,1,2,6,7,8,10,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound56640 : packedSelected [0,1,2,6,7,8,10,12,14] rootPS < 2^1333 := by decide +kernel

def env56641 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2064,268,16384,32768,52246,49169,50228,1025,32769,2049,32801,17,19730,269,17,50449,3328,17664,50229,1285,19761,257,19760,36112,53008]

theorem envBound56641 : H12AffineFastState.Bounded env56641 := by
  intro p hp
  have h : env56641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56640_56641 : H12AffineEnvironment.transform 11 2064 env56640 = env56641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env56640 == env56641) = true)

theorem identity56641 : scanCanonicalize (H12AffineFastState.compose env56641 (packedSelected [4,9] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound56641 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env56642 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2064,268,16384,0,19478,16401,17460,1025,1,2049,33,17,19730,269,17,17681,3328,17664,17461,1285,19761,257,19760,3344,20240]

theorem envBound56642 : H12AffineFastState.Bounded env56642 := by
  intro p hp
  have h : env56642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56641_56642 : H12AffineEnvironment.transform 14 0 env56641 = env56642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env56641 == env56642) = true)

theorem identity56642 : scanCanonicalize (H12AffineFastState.compose env56642 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 561) := by decide +kernel

theorem selectedBound56642 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env56643 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2064,268,561,0,3623,544,1541,1025,1,2049,33,17,3875,269,17,1824,3328,1841,1540,1285,3840,257,3841,3344,3361]

theorem envBound56643 : H12AffineFastState.Bounded env56643 := by
  intro p hp
  have h : env56643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56642_56643 : H12AffineEnvironment.transform 13 561 env56642 = env56643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env56642 == env56643) = true)

theorem identity56643 : scanCanonicalize (H12AffineFastState.compose env56643 (packedSelected [1,3,6] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound56643 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env56644 : List Nat := [2,4,8,16,32,16,9,256,512,1024,555,571,268,561,0,1036,544,1541,1025,1,554,33,17,1288,269,17,1824,1835,1841,1540,1285,1323,257,1322,1851,1802]

theorem envBound56644 : H12AffineFastState.Bounded env56644 := by
  intro p hp
  have h : env56644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56643_56644 : H12AffineEnvironment.transform 10 555 env56643 = env56644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env56643 == env56644) = true)

theorem identity56644 : scanCanonicalize (H12AffineFastState.compose env56644 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound56644 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env56645 : List Nat := [2,4,8,16,32,16,9,31,512,1024,555,571,19,561,0,1036,544,1541,1025,1,554,33,17,1047,18,17,1599,1588,1582,1540,1050,1076,30,1077,1572,1557]

theorem envBound56645 : H12AffineFastState.Bounded env56645 := by
  intro p hp
  have h : env56645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56644_56645 : H12AffineEnvironment.transform 7 31 env56644 = env56645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env56644 == env56645) = true)

theorem identity56645 : scanCanonicalize (H12AffineFastState.compose env56645 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound56645 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env56646 : List Nat := [2,4,8,16,32,16,9,31,512,31,555,571,19,561,0,19,544,538,30,1,554,33,17,8,18,17,544,555,561,539,5,43,30,42,571,522]

theorem envBound56646 : H12AffineFastState.Bounded env56646 := by
  intro p hp
  have h : env56646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56645_56646 : H12AffineEnvironment.transform 9 31 env56645 = env56646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env56645 == env56646) = true)

theorem identity56646 : scanCanonicalize (H12AffineFastState.compose env56646 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound56646 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env56647 : List Nat := [2,4,8,16,32,16,9,31,16,31,59,43,19,33,0,19,48,10,30,1,58,33,17,8,18,17,48,59,33,11,5,43,30,42,43,26]

theorem envBound56647 : H12AffineFastState.Bounded env56647 := by
  intro p hp
  have h : env56647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56646_56647 : H12AffineEnvironment.transform 8 16 env56646 = env56647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env56646 == env56647) = true)

theorem identity56647 : scanCanonicalize (H12AffineFastState.compose env56647 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 21) := by decide +kernel

theorem selectedBound56647 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env56648 : List Nat := [2,4,8,16,21,16,9,31,16,31,14,30,19,20,0,19,5,10,30,1,15,20,17,8,18,17,5,14,20,11,5,30,30,31,30,26]

theorem envBound56648 : H12AffineFastState.Bounded env56648 := by
  intro p hp
  have h : env56648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56647_56648 : H12AffineEnvironment.transform 4 21 env56647 = env56648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 21 env56647 == env56648) = true)

theorem identity56648 : scanCanonicalize (H12AffineFastState.compose env56648 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound56648 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env56649 : List Nat := [2,4,8,12,9,12,9,3,12,3,14,2,15,8,0,15,5,10,2,1,15,8,13,8,14,13,5,14,8,11,5,2,2,3,2,6]

theorem envBound56649 : H12AffineFastState.Bounded env56649 := by
  intro p hp
  have h : env56649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56648_56649 : H12AffineEnvironment.transform 3 12 env56648 = env56649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env56648 == env56649) = true)

theorem identity56649 : scanCanonicalize (H12AffineFastState.compose env56649 (packedSelected [1,10] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound56649 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env56650 : List Nat := [2,4,0,4,1,4,1,3,4,3,6,2,7,0,0,7,5,2,2,1,7,0,5,0,6,5,5,6,0,3,5,2,2,3,2,6]

theorem envBound56650 : H12AffineFastState.Bounded env56650 := by
  intro p hp
  have h : env56650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56649_56650 : H12AffineEnvironment.transform 2 0 env56649 = env56650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env56649 == env56650) = true)

theorem identity56650 : scanCanonicalize (H12AffineFastState.compose env56650 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound56650 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56651 : List Nat := [0,4,0,4,1,4,1,1,4,1,4,0,5,0,0,5,5,0,0,1,5,0,5,0,4,5,5,4,0,1,5,0,0,1,0,4]

theorem envBound56651 : H12AffineFastState.Bounded env56651 := by
  intro p hp
  have h : env56651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56650_56651 : H12AffineEnvironment.transform 0 0 env56650 = env56651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env56650 == env56651) = true)

theorem identity56651 : scanCanonicalize (H12AffineFastState.compose env56651 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound56651 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56652 : List Nat := [0,0,0,0,1,0,1,1,0,1,0,0,1,0,0,1,1,0,0,1,1,0,1,0,0,1,1,0,0,1,1,0,0,1,0,0]

theorem envBound56652 : H12AffineFastState.Bounded env56652 := by
  intro p hp
  have h : env56652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56651_56652 : H12AffineEnvironment.transform 1 0 env56651 = env56652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env56651 == env56652) = true)

def env56653 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,1048576,2097152,4194304,8388608,16777216,33554432,67108864,134217728,268435456,536870912,1073741824,2147483648,4294967296,525569,6532211005,34359738368,60294990]

theorem envBound56653 : H12AffineFastState.Bounded env56653 := by
  intro p hp
  have h : env56653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2_56653 : H12AffineEnvironment.transform 32 525569 env2 = env56653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 32 525569 env2 == env56653) = true)

def env56654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,33554432,67108864,134217728,268435456,536870912,1073741824,2147483648,4294967296,525569,6531129661,34359738368,59279182]

theorem envBound56654 : H12AffineFastState.Bounded env56654 := by
  intro p hp
  have h : env56654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56653_56654 : H12AffineEnvironment.transform 19 32768 env56653 = env56654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 19 32768 env56653 == env56654) = true)

theorem identity56654 : scanCanonicalize (H12AffineFastState.compose env56654 (packedSelected [4,9,22,29] rootPS)) = affineNative (2^(30+1) ^^^ 897815632) := by decide +kernel

theorem selectedBound56654 : packedSelected [4,9,22,29] rootPS < 2^1333 := by decide +kernel

def env56655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,33554432,67108864,134217728,268435456,536870912,1073741824,897815632,4294967296,525569,5113558381,34359738368,59279182]

theorem envBound56655 : H12AffineFastState.Bounded env56655 := by
  intro p hp
  have h : env56655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56654_56655 : H12AffineEnvironment.transform 30 897815632 env56654 = env56655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 30 897815632 env56654 == env56655) = true)

theorem identity56655 : scanCanonicalize (H12AffineFastState.compose env56655 (packedSelected [3,5,24,34] rootPS)) = affineNative (2^(23+1) ^^^ 8955335) := by decide +kernel

theorem selectedBound56655 : packedSelected [3,5,24,34] rootPS < 2^1333 := by decide +kernel

def env56656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8955335,33554432,67108864,134217728,268435456,536870912,1073741824,873148823,4294967296,525569,5113558381,34359738368,33563273]

theorem envBound56656 : H12AffineFastState.Bounded env56656 := by
  intro p hp
  have h : env56656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56655_56656 : H12AffineEnvironment.transform 23 8955335 env56655 = env56656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8955335 env56655 == env56656) = true)

theorem identity56656 : scanCanonicalize (H12AffineFastState.compose env56656 (packedSelected [4,6,7,9,14,16,20,25,27,35] rootPS)) = affineNative (2^(29+1) ^^^ 809736330) := by decide +kernel

theorem selectedBound56656 : packedSelected [4,6,7,9,14,16,20,25,27,35] rootPS < 2^1333 := by decide +kernel

def env56657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8955335,33554432,67108864,134217728,268435456,536870912,809736330,873148823,4294967296,525569,5113558381,34359738368,33563273]

theorem envBound56657 : H12AffineFastState.Bounded env56657 := by
  intro p hp
  have h : env56657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56656_56657 : H12AffineEnvironment.transform 29 809736330 env56656 = env56657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 809736330 env56656 == env56657) = true)

def env56658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8955335,33554432,67108864,134217728,268435456,76174416,348769498,276915655,4294967296,525569,4634763581,34359738368,33563273]

theorem envBound56658 : H12AffineFastState.Bounded env56658 := by
  intro p hp
  have h : env56658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56657_56658 : H12AffineEnvironment.transform 28 76174416 env56657 = env56658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 76174416 env56657 == env56658) = true)

def env56659 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8955335,33554432,67108864,134217728,16384,76174416,80317658,8463815,4294967296,525569,4366311741,34359738368,33563273]

theorem envBound56659 : H12AffineFastState.Bounded env56659 := by
  intro p hp
  have h : env56659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56658_56659 : H12AffineEnvironment.transform 27 16384 env56658 = env56659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16384 env56658 == env56659) = true)

def env56660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8955335,33554432,8409088,134217728,16384,656464,4840666,8463815,4294967296,525569,4307611965,34359738368,33563273]

theorem envBound56660 : H12AffineFastState.Bounded env56660 := by
  intro p hp
  have h : env56660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56659_56660 : H12AffineEnvironment.transform 25 8409088 env56659 = env56660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8409088 env56659 == env56660) = true)

def env56661 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8409088,134217728,16384,131152,4315354,8463815,4294967296,257,4307611965,34359738368,33563273]

theorem envBound56661 : H12AffineFastState.Bounded env56661 := by
  intro p hp
  have h : env56661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56660_56661 : H12AffineEnvironment.transform 18 1024 env56660 = env56661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env56660 == env56661) = true)

def env56662 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8409088,134217728,16384,131152,4315354,8463815,4294967296,257,4307611965,131072,33563273]

theorem envBound56662 : H12AffineFastState.Bounded env56662 := by
  intro p hp
  have h : env56662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56661_56662 : H12AffineEnvironment.transform 34 131072 env56661 = env56662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env56661 == env56662) = true)

theorem identity56662 : scanCanonicalize (H12AffineFastState.compose env56662 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 8462791) := by decide +kernel

theorem selectedBound56662 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env56663 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8409088,134217728,16384,131152,4315354,8463815,8462791,257,4313338,131072,33563273]

theorem envBound56663 : H12AffineFastState.Bounded env56663 := by
  intro p hp
  have h : env56663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56662_56663 : H12AffineEnvironment.transform 31 8462791 env56662 = env56663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8462791 env56662 == env56663) = true)

theorem identity56663 : scanCanonicalize (H12AffineFastState.compose env56663 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(26+1) ^^^ 12992837) := by decide +kernel

theorem selectedBound56663 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env56664 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8409088,12992837,16384,131152,4315354,8463815,8462791,257,4313338,131072,33563273]

theorem envBound56664 : H12AffineFastState.Bounded env56664 := by
  intro p hp
  have h : env56664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56663_56664 : H12AffineEnvironment.transform 26 12992837 env56663 = env56664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 12992837 env56663 == env56664) = true)

def env56665 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8388688,12980501,4176,131152,4294794,8463815,8462791,257,4292778,131072,33563273]

theorem envBound56665 : H12AffineFastState.Bounded env56665 := by
  intro p hp
  have h : env56665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56664_56665 : H12AffineEnvironment.transform 13 4176 env56664 = env56665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env56664 == env56665) = true)

theorem identity56665 : scanCanonicalize (H12AffineFastState.compose env56665 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound56665 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env56666 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,8328,8388688,12980501,4176,131152,4294794,8463815,8462791,257,4292778,131072,513]

theorem envBound56666 : H12AffineFastState.Bounded env56666 := by
  intro p hp
  have h : env56666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56665_56666 : H12AffineEnvironment.transform 24 8328 env56665 = env56666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env56665 == env56666) = true)

theorem identity56666 : scanCanonicalize (H12AffineFastState.compose env56666 (packedSelected [4,9,16] rootPS)) = affineNative (2^(21+1) ^^^ 209246) := by decide +kernel

theorem selectedBound56666 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56667 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,2097152,209246,8388608,8430023,8328,8388688,8724555,4176,131152,178644,8463815,8462791,257,176628,131072,513]

theorem envBound56667 : H12AffineFastState.Bounded env56667 := by
  intro p hp
  have h : env56667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56666_56667 : H12AffineEnvironment.transform 21 209246 env56666 = env56667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 209246 env56666 == env56667) = true)

theorem identity56667 : scanCanonicalize (H12AffineFastState.compose env56667 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4096) := by decide +kernel

theorem selectedBound56667 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,4096,209246,8388608,8430023,8328,8388688,8724555,4176,131152,178644,8463815,8462791,257,176628,131072,513]

theorem envBound56668 : H12AffineFastState.Bounded env56668 := by
  intro p hp
  have h : env56668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56667_56668 : H12AffineEnvironment.transform 20 4096 env56667 = env56668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env56667 == env56668) = true)

theorem identity56668 : scanCanonicalize (H12AffineFastState.compose env56668 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 98766) := by decide +kernel

theorem selectedBound56668 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env56669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,4096,209246,98766,73737,8328,98718,303493,4176,131152,178644,41993,40969,257,176628,131072,513]

theorem envBound56669 : H12AffineFastState.Bounded env56669 := by
  intro p hp
  have h : env56669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56668_56669 : H12AffineEnvironment.transform 22 98766 env56668 = env56669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 98766 env56668 == env56669) = true)

theorem identity56669 : scanCanonicalize (H12AffineFastState.compose env56669 (packedSelected [6,25] rootPS)) = affineNative (2^(16+1) ^^^ 78035) := by decide +kernel

theorem selectedBound56669 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env56670 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78035,262144,1024,32768,4096,397,98766,73737,8328,98718,303493,4176,77955,100615,41993,40969,257,98599,78035,513]

theorem envBound56670 : H12AffineFastState.Bounded env56670 := by
  intro p hp
  have h : env56670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56669_56670 : H12AffineEnvironment.transform 16 78035 env56669 = env56670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78035 env56669 == env56670) = true)

theorem identity56670 : scanCanonicalize (H12AffineFastState.compose env56670 (packedSelected [5,8] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound56670 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56671 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,4176,32768,65536,77835,262144,1024,32768,4096,341,98582,73737,8272,98630,303453,4176,77915,100615,41993,40969,257,98599,77835,513]

theorem envBound56671 : H12AffineFastState.Bounded env56671 := by
  intro p hp
  have h : env56671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56670_56671 : H12AffineEnvironment.transform 6 88 env56670 = env56671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env56670 == env56671) = true)

theorem identity56671 : scanCanonicalize (H12AffineFastState.compose env56671 (packedSelected [13,17] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound56671 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env56672 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,4176,32768,8282,4177,262144,1024,32768,4096,341,41292,83,8272,41244,303453,4176,4097,43357,41993,40969,257,41341,4177,513]

theorem envBound56672 : H12AffineFastState.Bounded env56672 := by
  intro p hp
  have h : env56672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56671_56672 : H12AffineEnvironment.transform 15 8282 env56671 = env56672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env56671 == env56672) = true)

theorem identity56672 : scanCanonicalize (H12AffineFastState.compose env56672 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 113) := by decide +kernel

theorem selectedBound56672 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56673 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,4176,113,8282,4177,262144,1024,113,4096,341,8509,83,8272,8557,270636,4176,4097,10540,9336,8312,257,8460,4177,513]

theorem envBound56673 : H12AffineFastState.Bounded env56673 := by
  intro p hp
  have h : env56673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56672_56673 : H12AffineEnvironment.transform 14 113 env56672 = env56673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 113 env56672 == env56673) = true)

theorem identity56673 : scanCanonicalize (H12AffineFastState.compose env56673 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 2049) := by decide +kernel

theorem selectedBound56673 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env56674 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,4176,113,8282,4177,2049,1024,113,4096,341,8509,83,8272,8557,10541,4176,4097,10540,9336,8312,257,8460,4177,513]

theorem envBound56674 : H12AffineFastState.Bounded env56674 := by
  intro p hp
  have h : env56674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56673_56674 : H12AffineEnvironment.transform 17 2049 env56673 = env56674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2049 env56673 == env56674) = true)

theorem identity56674 : scanCanonicalize (H12AffineFastState.compose env56674 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound56674 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env56675 : List Nat := [2,4,8,16,32,64,88,116,512,1024,2048,4096,8192,4176,113,8282,4177,2049,1024,113,4096,33,8265,83,8272,8217,10329,4176,4097,10328,9336,8312,117,8312,4177,513]

theorem envBound56675 : H12AffineFastState.Bounded env56675 := by
  intro p hp
  have h : env56675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56674_56675 : H12AffineEnvironment.transform 7 116 env56674 = env56675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env56674 == env56675) = true)

theorem identity56675 : scanCanonicalize (H12AffineFastState.compose env56675 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56675 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env56676 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,4096,33,8202,4097,2049,1024,33,4096,33,8217,3,8192,8217,10249,4096,4097,10248,9256,8232,37,8232,4097,513]

theorem envBound56676 : H12AffineFastState.Bounded env56676 := by
  intro p hp
  have h : env56676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56675_56676 : H12AffineEnvironment.transform 5 16 env56675 = env56676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56675 == env56676) = true)

theorem identity56676 : scanCanonicalize (H12AffineFastState.compose env56676 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound56676 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56677 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8,4096,33,2,4097,2049,1024,33,4096,33,17,3,8,17,2049,4096,4097,2048,1056,32,37,32,4097,513]

theorem envBound56677 : H12AffineFastState.Bounded env56677 := by
  intro p hp
  have h : env56677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56676_56677 : H12AffineEnvironment.transform 12 8 env56676 = env56677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env56676 == env56677) = true)

theorem identity56677 : scanCanonicalize (H12AffineFastState.compose env56677 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 3095) := by decide +kernel

theorem selectedBound56677 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56678 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,3095,8,3095,33,2,3094,2049,1024,33,3095,33,17,3,8,17,2049,3095,3094,2048,1056,32,37,32,3094,513]

theorem envBound56678 : H12AffineFastState.Bounded env56678 := by
  intro p hp
  have h : env56678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56677_56678 : H12AffineEnvironment.transform 11 3095 env56677 = env56678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3095 env56677 == env56678) = true)

theorem identity56678 : scanCanonicalize (H12AffineFastState.compose env56678 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 551) := by decide +kernel

theorem selectedBound56678 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56679 : List Nat := [2,4,8,16,32,16,8,36,512,551,2048,2608,8,2608,33,2,2609,2049,551,33,2608,33,17,3,8,17,2049,2608,2609,2048,519,32,37,32,2609,513]

theorem envBound56679 : H12AffineFastState.Bounded env56679 := by
  intro p hp
  have h : env56679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56678_56679 : H12AffineEnvironment.transform 9 551 env56678 = env56679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 551 env56678 == env56679) = true)

theorem identity56679 : scanCanonicalize (H12AffineFastState.compose env56679 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound56679 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env56680 : List Nat := [2,4,8,9,32,9,8,36,512,551,2048,2601,8,2601,33,2,2600,2049,551,33,2601,33,8,3,8,8,2049,2601,2600,2048,519,32,37,32,2600,513]

theorem envBound56680 : H12AffineFastState.Bounded env56680 := by
  intro p hp
  have h : env56680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56679_56680 : H12AffineEnvironment.transform 3 9 env56679 = env56680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env56679 == env56680) = true)

theorem identity56680 : scanCanonicalize (H12AffineFastState.compose env56680 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound56680 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env56681 : List Nat := [1,4,8,9,32,9,8,36,512,548,2048,2601,8,2601,33,1,2600,2049,548,33,2601,33,8,0,8,8,2049,2601,2600,2048,516,32,37,32,2600,513]

theorem envBound56681 : H12AffineFastState.Bounded env56681 := by
  intro p hp
  have h : env56681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56680_56681 : H12AffineEnvironment.transform 0 1 env56680 = env56681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env56680 == env56681) = true)

theorem identity56681 : scanCanonicalize (H12AffineFastState.compose env56681 (packedSelected [10] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound56681 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env56682 : List Nat := [1,4,8,9,32,9,8,36,512,548,33,520,8,520,33,1,521,32,548,33,520,33,8,0,8,8,32,520,521,33,516,32,37,32,521,513]

theorem envBound56682 : H12AffineFastState.Bounded env56682 := by
  intro p hp
  have h : env56682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56681_56682 : H12AffineEnvironment.transform 10 33 env56681 = env56682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env56681 == env56682) = true)

theorem identity56682 : scanCanonicalize (H12AffineFastState.compose env56682 (packedSelected [11] rootPS)) = affineNative (2^(8+1) ^^^ 40) := by decide +kernel

theorem selectedBound56682 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env56683 : List Nat := [1,4,8,9,32,9,8,36,40,12,33,32,8,32,33,1,33,32,12,33,32,33,8,0,8,8,32,32,33,33,44,32,37,32,33,41]

theorem envBound56683 : H12AffineFastState.Bounded env56683 := by
  intro p hp
  have h : env56683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56682_56683 : H12AffineEnvironment.transform 8 40 env56682 = env56683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 40 env56682 == env56683) = true)

theorem identity56683 : scanCanonicalize (H12AffineFastState.compose env56683 (packedSelected [13] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound56683 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env56684 : List Nat := [1,4,8,9,8,9,8,12,0,12,9,8,8,8,9,1,9,8,12,9,8,9,8,0,8,8,8,8,9,9,4,8,13,8,9,1]

theorem envBound56684 : H12AffineFastState.Bounded env56684 := by
  intro p hp
  have h : env56684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56683_56684 : H12AffineEnvironment.transform 4 8 env56683 = env56684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env56683 == env56684) = true)

def env56685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8388689,12980500,4177,131152,4294795,8463815,8462791,257,4292779,131072,33563273]

theorem envBound56685 : H12AffineFastState.Bounded env56685 := by
  intro p hp
  have h : env56685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56664_56685 : H12AffineEnvironment.transform 13 4177 env56664 = env56685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env56664 == env56685) = true)

def env56686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,2097152,4194304,6329752,6304863,33554432,6329801,2524300,4177,131152,4294795,6402143,6403167,257,4292779,131072,33563273]

theorem envBound56686 : H12AffineFastState.Bounded env56686 := by
  intro p hp
  have h : env56686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56685_56686 : H12AffineEnvironment.transform 22 6329752 env56685 = env56686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6329752 env56685 == env56686) = true)

def env56687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,2097152,4194304,6329752,6304863,4227080,6329801,2524300,4177,131152,4294795,6402143,6403167,257,4292779,131072,4235905]

theorem envBound56687 : H12AffineFastState.Bounded env56687 := by
  intro p hp
  have h : env56687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56686_56687 : H12AffineEnvironment.transform 24 4227080 env56686 = env56687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4227080 env56686 == env56687) = true)

def env56688 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,2097152,4194304,6329752,6304863,4227081,6329801,2524300,4177,131152,4294795,6402143,6403167,257,4292779,131072,4235904]

theorem envBound56688 : H12AffineFastState.Bounded env56688 := by
  intro p hp
  have h : env56688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56686_56688 : H12AffineEnvironment.transform 24 4227081 env56686 = env56688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4227081 env56686 == env56688) = true)

theorem identity56688 : scanCanonicalize (H12AffineFastState.compose env56688 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41089) := by decide +kernel

theorem selectedBound56688 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env56689 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,2097152,41089,2110745,2135262,8328,2110792,2524300,4177,131152,75786,2167006,2168030,257,73770,131072,513]

theorem envBound56689 : H12AffineFastState.Bounded env56689 := by
  intro p hp
  have h : env56689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56688_56689 : H12AffineEnvironment.transform 21 41089 env56688 = env56689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env56688 == env56689) = true)

theorem identity56689 : scanCanonicalize (H12AffineFastState.compose env56689 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 111831) := by decide +kernel

theorem selectedBound56689 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56690 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,111831,41089,98766,73737,8328,98719,471131,4177,131152,75786,41993,40969,257,73770,131072,513]

theorem envBound56690 : H12AffineFastState.Bounded env56690 := by
  intro p hp
  have h : env56690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56689_56690 : H12AffineEnvironment.transform 20 111831 env56689 = env56690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 111831 env56689 == env56690) = true)

theorem identity56690 : scanCanonicalize (H12AffineFastState.compose env56690 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 13577) := by decide +kernel

theorem selectedBound56690 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56691 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,13577,262144,1024,32768,111831,41089,98766,73737,8328,98719,329042,4177,13657,75786,41993,40969,257,73770,13577,513]

theorem envBound56691 : H12AffineFastState.Bounded env56691 := by
  intro p hp
  have h : env56691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56690_56691 : H12AffineEnvironment.transform 16 13577 env56690 = env56691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13577 env56690 == env56691) = true)

theorem identity56691 : scanCanonicalize (H12AffineFastState.compose env56691 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 1528) := by decide +kernel

theorem selectedBound56691 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env56692 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,1528,65536,13577,262144,1024,1528,78127,9593,66614,73737,8328,66663,329042,4177,13657,75786,8689,9713,257,73770,13577,513]

theorem envBound56692 : H12AffineFastState.Bounded env56692 := by
  intro p hp
  have h : env56692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56691_56692 : H12AffineEnvironment.transform 14 1528 env56691 = env56692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1528 env56691 == env56692) = true)

theorem identity56692 : scanCanonicalize (H12AffineFastState.compose env56692 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(9+1) ^^^ 904) := by decide +kernel

theorem selectedBound56692 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env56693 : List Nat := [2,4,8,16,32,64,128,256,512,904,2048,4096,8192,4177,624,65536,12929,262144,904,624,78127,8945,66494,73737,8328,66543,328410,4177,13009,75786,8689,8825,257,73770,12929,513]

theorem envBound56693 : H12AffineFastState.Bounded env56693 := by
  intro p hp
  have h : env56693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56692_56693 : H12AffineEnvironment.transform 9 904 env56692 = env56693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 904 env56692 == env56693) = true)

theorem identity56693 : scanCanonicalize (H12AffineFastState.compose env56693 (packedSelected [0,3,4,5,6,7,9,10,13,17,18,23] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound56693 : packedSelected [0,3,4,5,6,7,9,10,13,17,18,23] rootPS < 2^1333 := by decide +kernel

def env56694 : List Nat := [2,4,8,16,32,64,128,256,512,904,2048,4096,8192,4177,624,65536,12929,2341,904,624,78127,8945,66494,73737,8328,66543,68607,4177,13009,75786,8689,8825,257,73770,12929,513]

theorem envBound56694 : H12AffineFastState.Bounded env56694 := by
  intro p hp
  have h : env56694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56693_56694 : H12AffineEnvironment.transform 17 2341 env56693 = env56694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env56693 == env56694) = true)

theorem identity56694 : scanCanonicalize (H12AffineFastState.compose env56694 (packedSelected [0,3,4,5,7,9,10,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound56694 : packedSelected [0,3,4,5,7,9,10,13,17] rootPS < 2^1333 := by decide +kernel

def env56695 : List Nat := [2,4,8,16,32,64,128,256,512,904,2048,493,8192,444,624,65536,9068,2341,904,624,73922,8945,66494,73737,8328,66543,68607,444,9020,75786,8689,8825,257,73770,9068,513]

theorem envBound56695 : H12AffineFastState.Bounded env56695 := by
  intro p hp
  have h : env56695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56694_56695 : H12AffineEnvironment.transform 11 493 env56694 = env56695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env56694 == env56695) = true)

theorem identity56695 : scanCanonicalize (H12AffineFastState.compose env56695 (packedSelected [1,5,6,8,24] rootPS)) = affineNative (2^(12+1) ^^^ 892) := by decide +kernel

theorem selectedBound56695 : packedSelected [1,5,6,8,24] rootPS < 2^1333 := by decide +kernel

def env56696 : List Nat := [2,4,8,16,32,64,128,256,512,904,2048,493,892,444,624,65536,16,2341,904,624,66494,397,66494,66421,1012,66543,68607,444,64,68470,653,261,257,66390,16,513]

theorem envBound56696 : H12AffineFastState.Bounded env56696 := by
  intro p hp
  have h : env56696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56695_56696 : H12AffineEnvironment.transform 12 892 env56695 = env56696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 892 env56695 == env56696) = true)

theorem identity56696 : scanCanonicalize (H12AffineFastState.compose env56696 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 595) := by decide +kernel

theorem selectedBound56696 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env56697 : List Nat := [2,4,8,16,32,64,128,256,512,904,2048,493,892,444,624,595,16,2341,904,624,493,397,493,294,1012,444,2476,444,64,2341,653,261,257,261,16,513]

theorem envBound56697 : H12AffineFastState.Bounded env56697 := by
  intro p hp
  have h : env56697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56696_56697 : H12AffineEnvironment.transform 15 595 env56696 = env56697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 595 env56696 == env56697) = true)

theorem identity56697 : scanCanonicalize (H12AffineFastState.compose env56697 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound56697 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56698 : List Nat := [2,4,8,16,32,64,128,173,512,549,2048,64,721,17,624,595,16,2184,549,624,64,32,64,139,601,17,2049,17,64,2184,653,168,172,168,16,513]

theorem envBound56698 : H12AffineFastState.Bounded env56698 := by
  intro p hp
  have h : env56698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56697_56698 : H12AffineEnvironment.transform 7 173 env56697 = env56698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env56697 == env56698) = true)

theorem identity56698 : scanCanonicalize (H12AffineFastState.compose env56698 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound56698 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56699 : List Nat := [2,4,8,16,32,64,128,173,49,20,2048,64,224,17,65,98,16,2184,20,65,64,32,64,139,104,17,2049,17,64,2184,188,168,172,168,16,48]

theorem envBound56699 : H12AffineFastState.Bounded env56699 := by
  intro p hp
  have h : env56699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56698_56699 : H12AffineEnvironment.transform 8 49 env56698 = env56699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env56698 == env56699) = true)

theorem identity56699 : scanCanonicalize (H12AffineFastState.compose env56699 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound56699 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56700 : List Nat := [2,4,8,16,32,64,128,173,49,20,64,64,224,17,65,98,16,200,20,65,64,32,64,139,104,17,65,17,64,200,188,168,172,168,16,48]

theorem envBound56700 : H12AffineFastState.Bounded env56700 := by
  intro p hp
  have h : env56700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56699_56700 : H12AffineEnvironment.transform 10 64 env56699 = env56700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env56699 == env56700) = true)

theorem identity56700 : scanCanonicalize (H12AffineFastState.compose env56700 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound56700 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56701 : List Nat := [2,4,8,16,32,27,128,173,49,20,27,27,187,17,26,57,16,147,20,26,27,32,27,139,51,17,26,17,27,147,188,168,172,168,16,48]

theorem envBound56701 : H12AffineFastState.Bounded env56701 := by
  intro p hp
  have h : env56701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56700_56701 : H12AffineEnvironment.transform 5 27 env56700 = env56701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env56700 == env56701) = true)

theorem identity56701 : scanCanonicalize (H12AffineFastState.compose env56701 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound56701 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56702 : List Nat := [2,4,8,16,32,27,3,46,49,20,27,27,56,17,26,57,16,16,20,26,27,32,27,8,51,17,26,17,27,16,63,43,47,43,16,48]

theorem envBound56702 : H12AffineFastState.Bounded env56702 := by
  intro p hp
  have h : env56702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56701_56702 : H12AffineEnvironment.transform 6 3 env56701 = env56702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env56701 == env56702) = true)

def env56703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,2097152,4194304,6329753,6304862,33554432,6329800,2524301,4177,131152,4294795,6402142,6403166,257,4292779,131072,33563273]

theorem envBound56703 : H12AffineFastState.Bounded env56703 := by
  intro p hp
  have h : env56703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56685_56703 : H12AffineEnvironment.transform 22 6329753 env56685 = env56703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6329753 env56685 == env56703) = true)

def env56704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,2097152,4194304,6329753,6304862,4227080,6329800,2524301,4177,131152,4294795,6402142,6403166,257,4292779,131072,4235905]

theorem envBound56704 : H12AffineFastState.Bounded env56704 := by
  intro p hp
  have h : env56704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56703_56704 : H12AffineEnvironment.transform 24 4227080 env56703 = env56704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4227080 env56703 == env56704) = true)

def env56705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,2097152,4194304,6329753,6304862,4227081,6329800,2524301,4177,131152,4294795,6402142,6403166,257,4292779,131072,4235904]

theorem envBound56705 : H12AffineFastState.Bounded env56705 := by
  intro p hp
  have h : env56705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56703_56705 : H12AffineEnvironment.transform 24 4227081 env56703 = env56705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4227081 env56703 == env56705) = true)

theorem identity56705 : scanCanonicalize (H12AffineFastState.compose env56705 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41089) := by decide +kernel

theorem selectedBound56705 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env56706 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,2097152,41089,2110744,2135263,8328,2110793,2524301,4177,131152,75786,2167007,2168031,257,73770,131072,513]

theorem envBound56706 : H12AffineFastState.Bounded env56706 := by
  intro p hp
  have h : env56706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56705_56706 : H12AffineEnvironment.transform 21 41089 env56705 = env56706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env56705 == env56706) = true)

theorem identity56706 : scanCanonicalize (H12AffineFastState.compose env56706 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 111830) := by decide +kernel

theorem selectedBound56706 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56707 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,111830,41089,98766,73737,8328,98719,471131,4177,131152,75786,41993,40969,257,73770,131072,513]

theorem envBound56707 : H12AffineFastState.Bounded env56707 := by
  intro p hp
  have h : env56707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56706_56707 : H12AffineEnvironment.transform 20 111830 env56706 = env56707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 111830 env56706 == env56707) = true)

theorem identity56707 : scanCanonicalize (H12AffineFastState.compose env56707 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 13576) := by decide +kernel

theorem selectedBound56707 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56708 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,13576,262144,1024,32768,111830,41089,98766,73737,8328,98719,329043,4177,13656,75786,41993,40969,257,73770,13576,513]

theorem envBound56708 : H12AffineFastState.Bounded env56708 := by
  intro p hp
  have h : env56708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56707_56708 : H12AffineEnvironment.transform 16 13576 env56707 = env56708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13576 env56707 == env56708) = true)

theorem identity56708 : scanCanonicalize (H12AffineFastState.compose env56708 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 32802) := by decide +kernel

theorem selectedBound56708 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env56709 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,32802,13576,262144,1024,32768,13556,41089,492,41003,8328,445,296305,4177,13656,43048,41993,40969,257,40968,13576,513]

theorem envBound56709 : H12AffineFastState.Bounded env56709 := by
  intro p hp
  have h : env56709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56708_56709 : H12AffineEnvironment.transform 15 32802 env56708 = env56709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32802 env56708 == env56709) = true)

theorem identity56709 : scanCanonicalize (H12AffineFastState.compose env56709 (packedSelected [0,1,4,5,6,7,8,9,24] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound56709 : packedSelected [0,1,4,5,6,7,8,9,24] rootPS < 2^1333 := by decide +kernel

def env56710 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8460,8494,13576,262144,1024,8460,13556,397,492,295,8328,445,271485,4177,13656,2340,1285,261,257,260,13576,513]

theorem envBound56710 : H12AffineFastState.Bounded env56710 := by
  intro p hp
  have h : env56710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56709_56710 : H12AffineEnvironment.transform 14 8460 env56709 = env56710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env56709 == env56710) = true)

theorem identity56710 : scanCanonicalize (H12AffineFastState.compose env56710 (packedSelected [3,5,6,10,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 8000) := by decide +kernel

theorem selectedBound56710 : packedSelected [3,5,6,10,13,17] rootPS < 2^1333 := by decide +kernel

def env56711 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8460,8494,13576,8000,1024,8460,13556,397,492,295,8328,445,15165,4177,13656,2340,1285,261,257,260,13576,513]

theorem envBound56711 : H12AffineFastState.Bounded env56711 := by
  intro p hp
  have h : env56711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56710_56711 : H12AffineEnvironment.transform 17 8000 env56710 = env56711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8000 env56710 == env56711) = true)

theorem identity56711 : scanCanonicalize (H12AffineFastState.compose env56711 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(9+1) ^^^ 904) := by decide +kernel

theorem selectedBound56711 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env56712 : List Nat := [2,4,8,16,32,64,128,256,512,904,2048,4096,8192,4177,8460,8494,12928,6344,904,8460,13180,397,492,295,8328,445,15165,4177,13008,2340,653,261,257,260,12928,513]

theorem envBound56712 : H12AffineFastState.Bounded env56712 := by
  intro p hp
  have h : env56712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56711_56712 : H12AffineEnvironment.transform 9 904 env56711 = env56712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 904 env56711 == env56712) = true)

theorem identity56712 : scanCanonicalize (H12AffineFastState.compose env56712 (packedSelected [6,25] rootPS)) = affineNative (2^(12+1) ^^^ 893) := by decide +kernel

theorem selectedBound56712 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env56713 : List Nat := [2,4,8,16,32,64,128,256,512,904,2048,4096,893,4177,625,595,4605,6344,904,625,4097,397,492,295,1013,445,6208,4177,4525,2340,653,261,257,260,4605,513]

theorem envBound56713 : H12AffineFastState.Bounded env56713 := by
  intro p hp
  have h : env56713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56712_56713 : H12AffineEnvironment.transform 12 893 env56712 = env56713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 893 env56712 == env56713) = true)

theorem identity56713 : scanCanonicalize (H12AffineFastState.compose env56713 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound56713 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56714 : List Nat := [2,4,8,16,32,64,128,256,512,904,2048,493,893,444,625,595,16,2341,904,625,492,397,492,295,1013,445,2477,444,64,2340,653,261,257,260,16,513]

theorem envBound56714 : H12AffineFastState.Bounded env56714 := by
  intro p hp
  have h : env56714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56713_56714 : H12AffineEnvironment.transform 11 493 env56713 = env56714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env56713 == env56714) = true)

theorem identity56714 : scanCanonicalize (H12AffineFastState.compose env56714 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound56714 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56715 : List Nat := [2,4,8,16,32,64,128,256,216,336,2048,493,421,444,169,139,16,2341,336,169,492,397,492,295,301,445,2477,444,64,2340,85,261,257,260,16,217]

theorem envBound56715 : H12AffineFastState.Bounded env56715 := by
  intro p hp
  have h : env56715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56714_56715 : H12AffineEnvironment.transform 8 216 env56714 = env56715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env56714 == env56715) = true)

theorem identity56715 : scanCanonicalize (H12AffineFastState.compose env56715 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound56715 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env56716 : List Nat := [2,4,8,16,32,27,128,256,131,267,2048,438,421,444,169,139,16,2341,267,169,439,397,439,295,301,445,2477,444,27,2340,14,261,257,260,16,130]

theorem envBound56716 : H12AffineFastState.Bounded env56716 := by
  intro p hp
  have h : env56716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56715_56716 : H12AffineEnvironment.transform 5 27 env56715 = env56716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env56715 == env56716) = true)

def env56717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8409088,134217728,16384,131152,4315354,8463815,4294967296,257,4307611965,131073,33563273]

theorem envBound56717 : H12AffineFastState.Bounded env56717 := by
  intro p hp
  have h : env56717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56661_56717 : H12AffineEnvironment.transform 34 131073 env56661 = env56717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env56661 == env56717) = true)

theorem identity56717 : scanCanonicalize (H12AffineFastState.compose env56717 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 10564039) := by decide +kernel

theorem selectedBound56717 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env56718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8409088,134217728,16384,131152,4315354,8463815,10564039,257,6406394,131073,33563273]

theorem envBound56718 : H12AffineFastState.Bounded env56718 := by
  intro p hp
  have h : env56718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56717_56718 : H12AffineEnvironment.transform 31 10564039 env56717 = env56718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 10564039 env56717 == env56718) = true)

theorem identity56718 : scanCanonicalize (H12AffineFastState.compose env56718 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(16+1) ^^^ 78034) := by decide +kernel

theorem selectedBound56718 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env56719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8409088,134217728,16384,77954,4315354,8463815,10564039,257,6406394,78035,33563273]

theorem envBound56719 : H12AffineFastState.Bounded env56719 := by
  intro p hp
  have h : env56719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56718_56719 : H12AffineEnvironment.transform 16 78034 env56718 = env56719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78034 env56718 == env56719) = true)

def env56720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8409088,10798236,16384,77954,4315354,8463815,10564039,257,6406394,78035,33563273]

theorem envBound56720 : H12AffineFastState.Bounded env56720 := by
  intro p hp
  have h : env56720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56719_56720 : H12AffineEnvironment.transform 26 10798236 env56719 = env56720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 10798236 env56719 == env56720) = true)

def env56721 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1024,32768,2097152,4194304,8388608,8430023,4247640,8409088,10798236,16384,77954,4315354,8463815,10564039,257,6406394,78035,4256465]

theorem envBound56721 : H12AffineFastState.Bounded env56721 := by
  intro p hp
  have h : env56721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56720_56721 : H12AffineEnvironment.transform 24 4247640 env56720 = env56721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4247640 env56720 == env56721) = true)

def env56722 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1024,32768,2097152,4194304,6336704,6295815,4247640,6348992,4486236,16384,77954,4315354,6395143,4292871,257,6406394,78035,4256465]

theorem envBound56722 : H12AffineFastState.Bounded env56722 := by
  intro p hp
  have h : env56722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56721_56722 : H12AffineEnvironment.transform 22 6336704 env56721 = env56722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6336704 env56721 == env56722) = true)

def env56723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,4194304,6336704,6295815,4247640,6348992,4273308,16384,77954,4315354,6395143,4292871,257,6406394,78035,4256465]

theorem envBound56723 : H12AffineFastState.Bounded env56723 := by
  intro p hp
  have h : env56723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56722_56723 : H12AffineEnvironment.transform 17 82112 env56722 = env56723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82112 env56722 == env56723) = true)

def env56724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41088,2101312,2142599,28888,2113600,103452,16384,77954,96346,2176391,74119,257,2187386,78035,21073]

theorem envBound56724 : H12AffineFastState.Bounded env56724 := by
  intro p hp
  have h : env56724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56723_56724 : H12AffineEnvironment.transform 21 41088 env56723 = env56724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env56723 == env56724) = true)

theorem identity56724 : scanCanonicalize (H12AffineFastState.compose env56724 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 501) := by decide +kernel

theorem selectedBound56724 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,501,16384,32768,65536,69927,82112,1024,32768,2097152,33141,2101312,2134130,20781,2113600,103452,16384,70007,88495,2167922,65650,257,2179471,69926,21073]

theorem envBound56725 : H12AffineFastState.Bounded env56725 := by
  intro p hp
  have h : env56725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56724_56725 : H12AffineEnvironment.transform 12 501 env56724 = env56725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 501 env56724 == env56725) = true)

theorem identity56725 : scanCanonicalize (H12AffineFastState.compose env56725 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 71050) := by decide +kernel

theorem selectedBound56725 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env56726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,501,16384,32768,65536,69927,82112,1024,32768,71050,33141,67018,99832,20781,87498,103452,16384,70007,88495,504,65650,257,21509,69926,21073]

theorem envBound56726 : H12AffineFastState.Bounded env56726 := by
  intro p hp
  have h : env56726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56725_56726 : H12AffineEnvironment.transform 20 71050 env56725 = env56726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 71050 env56725 == env56726) = true)

theorem identity56726 : scanCanonicalize (H12AffineFastState.compose env56726 (packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS)) = affineNative (2^(15+1) ^^^ 53727) := by decide +kernel

theorem selectedBound56726 : packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS < 2^1333 := by decide +kernel

def env56727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,501,16384,32768,53727,49400,37151,1024,32768,50261,33141,54293,21543,20781,33813,17859,16384,49320,34928,504,53677,257,21509,49401,21073]

theorem envBound56727 : H12AffineFastState.Bounded env56727 := by
  intro p hp
  have h : env56727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56726_56727 : H12AffineEnvironment.transform 15 53727 env56726 = env56727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53727 env56726 == env56727) = true)

theorem identity56727 : scanCanonicalize (H12AffineFastState.compose env56727 (packedSelected [5,8,10,13,17,19,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound56727 : packedSelected [5,8,10,13,17,19,24,28] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0