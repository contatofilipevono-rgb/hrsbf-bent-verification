import H12CloudChart0Data121

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env30948 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1024,8541,2097152,4194304,147457,147475,8192,64,4409702,2319690,2233680,2420,75103,6497627,256,2188650,2172187,513]

theorem envBound30948 : H12AffineFastState.Bounded env30948 := by
  intro p hp
  have h : env30948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30947_30948 : H12AffineEnvironment.transform 6 8 env30947 = env30948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30947 == env30948) = true)

def env30949 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10281,1024,8461,2097152,4194304,147457,147475,8192,16,4409654,2319642,2233600,2340,75023,6497547,256,2188602,2172187,513]

theorem envBound30949 : H12AffineFastState.Bounded env30949 := by
  intro p hp
  have h : env30949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30948_30949 : H12AffineEnvironment.transform 5 16 env30948 = env30949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30948 == env30949) = true)

theorem identity30949 : scanCanonicalize (H12AffineFastState.compose env30949 (packedSelected [0,3,4,5,7,9,10,16,17,18] rootPS)) = affineNative (2^(21+1) ^^^ 213303) := by decide +kernel

theorem selectedBound30949 : packedSelected [0,3,4,5,7,9,10,16,17,18] rootPS < 2^1333 := by decide +kernel

def env30950 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10281,1024,8461,2097152,213303,147457,147475,8192,16,2049,2319642,2233600,2340,75023,2122812,256,2188602,2172187,513]

theorem envBound30950 : H12AffineFastState.Bounded env30950 := by
  intro p hp
  have h : env30950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30949_30950 : H12AffineEnvironment.transform 21 213303 env30949 = env30950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 213303 env30949 == env30950) = true)

theorem identity30950 : scanCanonicalize (H12AffineFastState.compose env30950 (packedSelected [1,2,6,8,10,11,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound30950 : packedSelected [1,2,6,8,10,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env30951 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,1,65536,131072,2340,1024,0,2097152,213303,147457,147475,269,16,2049,2311191,2233600,2340,66562,2114865,256,2180151,2163734,513]

theorem envBound30951 : H12AffineFastState.Bounded env30951 := by
  intro p hp
  have h : env30951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30950_30951 : H12AffineEnvironment.transform 12 269 env30950 = env30951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env30950 == env30951) = true)

theorem identity30951 : scanCanonicalize (H12AffineFastState.compose env30951 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 132352) := by decide +kernel

theorem selectedBound30951 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30952 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,1,65536,131072,2340,1024,0,132352,213303,147457,147475,269,16,2049,82199,4096,2340,66562,147505,256,213303,196886,513]

theorem envBound30952 : H12AffineFastState.Bounded env30952 := by
  intro p hp
  have h : env30952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30951_30952 : H12AffineEnvironment.transform 20 132352 env30951 = env30952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 132352 env30951 == env30952) = true)

theorem identity30952 : scanCanonicalize (H12AffineFastState.compose env30952 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound30952 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env30953 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,1,65536,16401,2340,1024,0,17681,65830,16,2,269,16,2049,82199,4096,2340,66562,32,256,65830,82183,513]

theorem envBound30953 : H12AffineFastState.Bounded env30953 := by
  intro p hp
  have h : env30953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30952_30953 : H12AffineEnvironment.transform 16 16401 env30952 = env30953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env30952 == env30953) = true)

theorem identity30953 : scanCanonicalize (H12AffineFastState.compose env30953 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(15+1) ^^^ 24370) := by decide +kernel

theorem selectedBound30953 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env30954 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,1,24370,16401,2340,1024,0,17681,24084,16,2,269,16,2049,7717,4096,2340,23344,32,256,24084,7733,513]

theorem envBound30954 : H12AffineFastState.Bounded env30954 := by
  intro p hp
  have h : env30954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30953_30954 : H12AffineEnvironment.transform 15 24370 env30953 = env30954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24370 env30953 == env30954) = true)

theorem identity30954 : scanCanonicalize (H12AffineFastState.compose env30954 (packedSelected [0,3,4,5,12] rootPS)) = affineNative (2^(13+1) ^^^ 7733) := by decide +kernel

theorem selectedBound30954 : packedSelected [0,3,4,5,12] rootPS < 2^1333 := by decide +kernel

def env30955 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,7733,1,263,7716,2340,1024,0,6948,33,16,2,269,16,2049,7717,4096,2340,1285,32,256,33,7733,513]

theorem envBound30955 : H12AffineFastState.Bounded env30955 := by
  intro p hp
  have h : env30955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30954_30955 : H12AffineEnvironment.transform 13 7733 env30954 = env30955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7733 env30954 == env30955) = true)

theorem identity30955 : scanCanonicalize (H12AffineFastState.compose env30955 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound30955 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30956 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,276,269,3873,1,263,3888,2340,1024,0,2608,33,16,2,269,16,2049,3889,276,2340,1285,32,256,33,3873,513]

theorem envBound30956 : H12AffineFastState.Bounded env30956 := by
  intro p hp
  have h : env30956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30955_30956 : H12AffineEnvironment.transform 11 276 env30955 = env30956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env30955 == env30956) = true)

theorem identity30956 : scanCanonicalize (H12AffineFastState.compose env30956 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 298) := by decide +kernel

theorem selectedBound30956 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30957 : List Nat := [2,4,8,16,32,16,8,256,512,298,2048,276,269,2571,1,263,2586,2340,298,0,2608,33,16,2,269,16,2049,2587,276,2340,47,32,256,33,2571,513]

theorem envBound30957 : H12AffineFastState.Bounded env30957 := by
  intro p hp
  have h : env30957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30956_30957 : H12AffineEnvironment.transform 9 298 env30956 = env30957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 298 env30956 == env30957) = true)

theorem identity30957 : scanCanonicalize (H12AffineFastState.compose env30957 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound30957 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30958 : List Nat := [2,4,8,16,32,16,8,256,59,298,2048,276,269,2096,1,263,2081,2340,298,0,2059,33,16,2,269,16,2049,2080,276,2340,47,32,256,33,2096,58]

theorem envBound30958 : H12AffineFastState.Bounded env30958 := by
  intro p hp
  have h : env30958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30957_30958 : H12AffineEnvironment.transform 8 59 env30957 = env30958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env30957 == env30958) = true)

theorem identity30958 : scanCanonicalize (H12AffineFastState.compose env30958 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30958 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env30959 : List Nat := [2,4,3,16,32,16,3,256,48,289,2048,276,262,2096,1,263,2081,2340,289,0,2048,33,16,2,262,16,2049,2080,276,2340,36,32,256,33,2096,49]

theorem envBound30959 : H12AffineFastState.Bounded env30959 := by
  intro p hp
  have h : env30959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30958_30959 : H12AffineEnvironment.transform 2 3 env30958 = env30959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30958 == env30959) = true)

theorem identity30959 : scanCanonicalize (H12AffineFastState.compose env30959 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound30959 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env30960 : List Nat := [2,4,3,16,32,16,3,256,48,289,48,276,262,0,1,263,17,276,289,0,48,33,16,2,262,16,49,16,276,276,36,32,256,33,0,49]

theorem envBound30960 : H12AffineFastState.Bounded env30960 := by
  intro p hp
  have h : env30960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30959_30960 : H12AffineEnvironment.transform 10 48 env30959 = env30960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env30959 == env30960) = true)

theorem identity30960 : scanCanonicalize (H12AffineFastState.compose env30960 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound30960 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env30961 : List Nat := [2,4,3,16,32,16,3,20,48,53,48,0,18,0,1,19,17,0,53,0,48,33,16,2,18,16,49,16,0,0,36,32,20,33,0,49]

theorem envBound30961 : H12AffineFastState.Bounded env30961 := by
  intro p hp
  have h : env30961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30960_30961 : H12AffineEnvironment.transform 7 20 env30960 = env30961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env30960 == env30961) = true)

theorem identity30961 : scanCanonicalize (H12AffineFastState.compose env30961 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound30961 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env30962 : List Nat := [2,4,3,7,32,7,3,3,39,34,39,0,5,0,1,4,6,0,34,0,39,33,7,2,5,7,38,7,0,0,36,32,3,33,0,38]

theorem envBound30962 : H12AffineFastState.Bounded env30962 := by
  intro p hp
  have h : env30962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30961_30962 : H12AffineEnvironment.transform 3 7 env30961 = env30962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env30961 == env30962) = true)

def env30963 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10281,1024,8460,2097152,4194304,147457,147475,8192,17,4409655,2319643,2233601,2341,75022,6497546,256,2188603,2172187,513]

theorem envBound30963 : H12AffineFastState.Bounded env30963 := by
  intro p hp
  have h : env30963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30948_30963 : H12AffineEnvironment.transform 5 17 env30948 = env30963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30948 == env30963) = true)

theorem identity30963 : scanCanonicalize (H12AffineFastState.compose env30963 (packedSelected [0,3,4,5,7,9,10,16,17,18] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound30963 : packedSelected [0,3,4,5,7,9,10,16,17,18] rootPS < 2^1333 := by decide +kernel

def env30964 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10281,1024,8460,2097152,8493,147457,147475,8192,17,223258,2319643,2233601,2341,75022,2294823,256,2188603,2172187,513]

theorem envBound30964 : H12AffineFastState.Bounded env30964 := by
  intro p hp
  have h : env30964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30963_30964 : H12AffineEnvironment.transform 21 8493 env30963 = env30964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env30963 == env30964) = true)

theorem identity30964 : scanCanonicalize (H12AffineFastState.compose env30964 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(20+1) ^^^ 197638) := by decide +kernel

theorem selectedBound30964 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env30965 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10281,1024,8460,197638,8493,147457,147475,8192,17,223258,24861,69895,2341,75022,33,256,155965,139549,513]

theorem envBound30965 : H12AffineFastState.Bounded env30965 := by
  intro p hp
  have h : env30965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30964_30965 : H12AffineEnvironment.transform 20 197638 env30964 = env30965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 197638 env30964 == env30965) = true)

theorem identity30965 : scanCanonicalize (H12AffineFastState.compose env30965 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound30965 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env30966 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,65536,24860,10281,1024,8460,91418,8493,8477,8463,8192,17,67846,24861,69895,2341,75022,33,256,33,16385,513]

theorem envBound30966 : H12AffineFastState.Bounded env30966 := by
  intro p hp
  have h : env30966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30965_30966 : H12AffineEnvironment.transform 16 24860 env30965 = env30966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env30965 == env30966) = true)

theorem identity30966 : scanCanonicalize (H12AffineFastState.compose env30966 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound30966 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30967 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,1,65536,16400,2341,1024,0,82966,33,17,3,268,17,67846,16401,69895,2341,66562,33,256,33,16385,513]

theorem envBound30967 : H12AffineFastState.Bounded env30967 := by
  intro p hp
  have h : env30967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30966_30967 : H12AffineEnvironment.transform 12 268 env30966 = env30967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env30966 == env30967) = true)

theorem identity30967 : scanCanonicalize (H12AffineFastState.compose env30967 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound30967 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30968 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,1,263,16400,2341,1024,0,17681,33,17,3,268,17,2049,16401,4096,2341,1285,33,256,33,16385,513]

theorem envBound30968 : H12AffineFastState.Bounded env30968 := by
  intro p hp
  have h : env30968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30967_30968 : H12AffineEnvironment.transform 15 263 env30967 = env30968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env30967 == env30968) = true)

theorem identity30968 : scanCanonicalize (H12AffineFastState.compose env30968 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound30968 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30969 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,1,263,5392,2341,1024,0,4113,33,17,3,268,17,2049,5393,4096,2341,1285,33,256,33,5377,513]

theorem envBound30969 : H12AffineFastState.Bounded env30969 := by
  intro p hp
  have h : env30969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30968_30969 : H12AffineEnvironment.transform 13 5376 env30968 = env30969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env30968 == env30969) = true)

theorem identity30969 : scanCanonicalize (H12AffineFastState.compose env30969 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2878) := by decide +kernel

theorem selectedBound30969 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30970 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2878,268,3646,1,263,3630,2341,1024,0,2863,33,17,3,268,17,2049,3631,2878,2341,1285,33,256,33,3647,513]

theorem envBound30970 : H12AffineFastState.Bounded env30970 := by
  intro p hp
  have h : env30970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30969_30970 : H12AffineEnvironment.transform 11 2878 env30969 = env30970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2878 env30969 == env30970) = true)

theorem identity30970 : scanCanonicalize (H12AffineFastState.compose env30970 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound30970 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30971 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,2618,8,3646,1,3,3630,2081,1024,0,2603,33,17,3,8,17,2049,3631,2618,2081,1025,33,4,33,3647,513]

theorem envBound30971 : H12AffineFastState.Bounded env30971 := by
  intro p hp
  have h : env30971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30970_30971 : H12AffineEnvironment.transform 7 4 env30970 = env30971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env30970 == env30971) = true)

theorem identity30971 : scanCanonicalize (H12AffineFastState.compose env30971 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1567) := by decide +kernel

theorem selectedBound30971 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env30972 : List Nat := [2,4,8,16,32,17,8,4,512,1024,1567,1061,8,33,1,3,49,1598,1024,0,1076,33,17,3,8,17,1566,48,1061,1598,1025,33,4,33,32,513]

theorem envBound30972 : H12AffineFastState.Bounded env30972 := by
  intro p hp
  have h : env30972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30971_30972 : H12AffineEnvironment.transform 10 1567 env30971 = env30972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1567 env30971 == env30972) = true)

theorem identity30972 : scanCanonicalize (H12AffineFastState.compose env30972 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound30972 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env30973 : List Nat := [2,4,8,16,32,17,8,4,512,542,1,571,8,33,1,3,49,32,542,0,554,33,17,3,8,17,0,48,571,32,543,33,4,33,32,513]

theorem envBound30973 : H12AffineFastState.Bounded env30973 := by
  intro p hp
  have h : env30973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30972_30973 : H12AffineEnvironment.transform 9 542 env30972 = env30973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env30972 == env30973) = true)

theorem identity30973 : scanCanonicalize (H12AffineFastState.compose env30973 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound30973 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env30974 : List Nat := [2,4,8,16,1,17,8,4,512,542,1,538,8,0,1,3,16,1,542,0,523,0,17,3,8,17,0,17,538,1,543,0,4,0,1,513]

theorem envBound30974 : H12AffineFastState.Bounded env30974 := by
  intro p hp
  have h : env30974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30973_30974 : H12AffineEnvironment.transform 4 1 env30973 = env30974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env30973 == env30974) = true)

theorem identity30974 : scanCanonicalize (H12AffineFastState.compose env30974 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound30974 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30975 : List Nat := [2,4,8,14,1,15,8,4,512,512,1,516,8,0,1,3,14,1,512,0,523,0,15,3,8,15,0,15,516,1,513,0,4,0,1,513]

theorem envBound30975 : H12AffineFastState.Bounded env30975 := by
  intro p hp
  have h : env30975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30974_30975 : H12AffineEnvironment.transform 3 14 env30974 = env30975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env30974 == env30975) = true)

theorem identity30975 : scanCanonicalize (H12AffineFastState.compose env30975 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound30975 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30976 : List Nat := [2,4,8,14,1,15,8,4,8,8,1,12,8,0,1,3,14,1,8,0,3,0,15,3,8,15,0,15,12,1,9,0,4,0,1,9]

theorem envBound30976 : H12AffineFastState.Bounded env30976 := by
  intro p hp
  have h : env30976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30975_30976 : H12AffineEnvironment.transform 8 8 env30975 = env30976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env30975 == env30976) = true)

def env30977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830977,25265169,23160256,257,27378861,27337993,25207750]

theorem envBound30977 : H12AffineFastState.Bounded env30977 := by
  intro p hp
  have h : env30977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30896_30977 : H12AffineEnvironment.transform 18 1025 env30896 = env30977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env30896 == env30977) = true)

theorem identity30977 : scanCanonicalize (H12AffineFastState.compose env30977 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8601940) := by decide +kernel

theorem selectedBound30977 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env30978 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8601940,8328,64,4489556,10667480,10507601,8830977,181573,14820500,257,2262521,2253917,254610]

theorem envBound30978 : H12AffineFastState.Bounded env30978 := by
  intro p hp
  have h : env30978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30977_30978 : H12AffineEnvironment.transform 23 8601940 env30977 = env30978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8601940 env30977 == env30978) = true)

def env30979 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,4194304,8388608,8601940,8328,64,4489556,8393984,8553865,8830977,181573,12645452,257,21793,46213,254610]

theorem envBound30979 : H12AffineFastState.Bounded env30979 := by
  intro p hp
  have h : env30979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30978_30979 : H12AffineEnvironment.transform 20 184536 env30978 = env30979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184536 env30978 == env30979) = true)

def env30980 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,4194304,180360,98780,8328,64,4489556,185736,17665,262281,181573,4338884,257,21793,46213,254610]

theorem envBound30980 : H12AffineFastState.Bounded env30980 := by
  intro p hp
  have h : env30980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30979_30980 : H12AffineEnvironment.transform 22 180360 env30979 = env30980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180360 env30979 == env30980) = true)

def env30981 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272512,180360,98780,8328,64,43476,185736,17665,262281,181573,400452,257,21793,46213,254610]

theorem envBound30981 : H12AffineFastState.Bounded env30981 := by
  intro p hp
  have h : env30981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30980_30981 : H12AffineEnvironment.transform 21 272512 env30980 = env30981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env30980 == env30981) = true)

theorem identity30981 : scanCanonicalize (H12AffineFastState.compose env30981 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound30981 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30982 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,184536,272512,180360,21763,8328,64,43476,185736,17665,262281,181573,400452,257,21793,46213,144973]

theorem envBound30982 : H12AffineFastState.Bounded env30982 := by
  intro p hp
  have h : env30982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30981_30982 : H12AffineEnvironment.transform 15 54495 env30981 = env30982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env30981 == env30982) = true)

def env30983 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,184400,272392,180224,21763,8192,64,43356,185600,17665,262145,181573,400452,257,21793,46093,144973]

theorem envBound30983 : H12AffineFastState.Bounded env30983 := by
  intro p hp
  have h : env30983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30982_30983 : H12AffineEnvironment.transform 6 8 env30982 = env30983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30982 == env30983) = true)

theorem identity30983 : scanCanonicalize (H12AffineFastState.compose env30983 (packedSelected [0,3,4,8,10,12,14,18,19,20,22,23,24,27,28,31,38] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound30983 : packedSelected [0,3,4,8,10,12,14,18,19,20,22,23,24,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env30984 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,184400,272392,180224,21623,8192,64,43048,185460,17525,262145,181297,400452,117,21589,46093,144973]

theorem envBound30984 : H12AffineFastState.Bounded env30984 := by
  intro p hp
  have h : env30984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30983_30984 : H12AffineEnvironment.transform 7 116 env30983 = env30984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env30983 == env30984) = true)

theorem identity30984 : scanCanonicalize (H12AffineFastState.compose env30984 (packedSelected [1,3,7,8,10,14,15,16,17,18,23,24,27,41] rootPS)) = affineNative (2^(17+1) ^^^ 157752) := by decide +kernel

theorem selectedBound30984 : packedSelected [1,3,7,8,10,14,15,16,17,18,23,24,27,41] rootPS < 2^1333 := by decide +kernel

def env30985 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,54359,131072,157752,1025,32769,184400,147504,180224,21623,8192,64,43048,185460,17525,157753,181297,29820,117,21589,46093,144973]

theorem envBound30985 : H12AffineFastState.Bounded env30985 := by
  intro p hp
  have h : env30985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30984_30985 : H12AffineEnvironment.transform 17 157752 env30984 = env30985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157752 env30984 == env30985) = true)

theorem identity30985 : scanCanonicalize (H12AffineFastState.compose env30985 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound30985 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env30986 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,16384,32768,54359,131072,149520,1025,32769,184400,147504,180224,21623,40,64,34816,185460,17525,149521,181297,21588,117,21589,37925,136805]

theorem envBound30986 : H12AffineFastState.Bounded env30986 := by
  intro p hp
  have h : env30986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30985_30986 : H12AffineEnvironment.transform 12 40 env30985 = env30986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env30985 == env30986) = true)

theorem identity30986 : scanCanonicalize (H12AffineFastState.compose env30986 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound30986 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env30987 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,16384,32768,54359,16400,2048,1025,32769,36928,32,32784,21623,40,64,34816,37988,17525,2049,33825,21588,117,21589,37925,22133]

theorem envBound30987 : H12AffineFastState.Bounded env30987 := by
  intro p hp
  have h : env30987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30986_30987 : H12AffineEnvironment.transform 16 16400 env30986 = env30987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env30986 == env30987) = true)

theorem identity30987 : scanCanonicalize (H12AffineFastState.compose env30987 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1125) := by decide +kernel

theorem selectedBound30987 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30988 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,16384,1125,20530,16400,2048,1025,1124,5157,32,1141,21623,40,64,3173,4097,17525,2049,68,21588,117,21589,4160,22133]

theorem envBound30988 : H12AffineFastState.Bounded env30988 := by
  intro p hp
  have h : env30988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30987_30988 : H12AffineEnvironment.transform 14 1125 env30987 = env30988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1125 env30987 == env30988) = true)

theorem identity30988 : scanCanonicalize (H12AffineFastState.compose env30988 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound30988 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env30989 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,4112,1125,34,4096,2048,1025,1124,5157,32,1141,1127,40,64,3173,4097,5221,2049,68,1092,117,1093,4160,1637]

theorem envBound30989 : H12AffineFastState.Bounded env30989 := by
  intro p hp
  have h : env30989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30988_30989 : H12AffineEnvironment.transform 13 4112 env30988 = env30989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env30988 == env30989) = true)

theorem identity30989 : scanCanonicalize (H12AffineFastState.compose env30989 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 113) := by decide +kernel

theorem selectedBound30989 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30990 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,113,40,97,1125,34,113,2048,1025,1124,1108,32,1141,1127,40,64,3173,112,1044,2049,68,1092,117,1093,49,1637]

theorem envBound30990 : H12AffineFastState.Bounded env30990 := by
  intro p hp
  have h : env30990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30989_30990 : H12AffineEnvironment.transform 11 113 env30989 = env30990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 113 env30989 == env30990) = true)

theorem identity30990 : scanCanonicalize (H12AffineFastState.compose env30990 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound30990 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env30991 : List Nat := [2,4,8,16,32,64,8,116,512,20,2048,113,40,97,113,34,113,2048,21,112,64,32,97,115,40,64,2161,112,0,2049,68,80,117,81,49,625]

theorem envBound30991 : H12AffineFastState.Bounded env30991 := by
  intro p hp
  have h : env30991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30990_30991 : H12AffineEnvironment.transform 9 20 env30990 = env30991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env30990 == env30991) = true)

theorem identity30991 : scanCanonicalize (H12AffineFastState.compose env30991 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30991 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30992 : List Nat := [2,4,8,16,0,64,8,84,512,20,2048,81,8,65,81,2,81,2048,21,80,64,0,65,83,8,64,2129,80,0,2049,68,80,85,81,17,593]

theorem envBound30992 : H12AffineFastState.Bounded env30992 := by
  intro p hp
  have h : env30992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30991_30992 : H12AffineEnvironment.transform 4 0 env30991 = env30992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30991 == env30992) = true)

theorem identity30992 : scanCanonicalize (H12AffineFastState.compose env30992 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound30992 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env30993 : List Nat := [2,4,8,16,0,0,8,20,512,20,2048,17,8,1,17,2,17,2048,21,16,0,0,1,19,8,0,2065,16,0,2049,4,16,21,17,17,529]

theorem envBound30993 : H12AffineFastState.Bounded env30993 := by
  intro p hp
  have h : env30993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30992_30993 : H12AffineEnvironment.transform 5 0 env30992 = env30993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env30992 == env30993) = true)

theorem identity30993 : scanCanonicalize (H12AffineFastState.compose env30993 (packedSelected [4,7] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound30993 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env30994 : List Nat := [2,4,8,16,0,0,8,20,512,20,529,17,8,1,17,2,17,529,21,16,0,0,1,19,8,0,512,16,0,528,4,16,21,17,17,529]

theorem envBound30994 : H12AffineFastState.Bounded env30994 := by
  intro p hp
  have h : env30994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30993_30994 : H12AffineEnvironment.transform 10 529 env30993 = env30994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env30993 == env30994) = true)

theorem identity30994 : scanCanonicalize (H12AffineFastState.compose env30994 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound30994 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env30995 : List Nat := [2,4,8,0,0,0,8,4,512,4,513,1,8,1,1,2,1,513,5,0,0,0,1,3,8,0,512,0,0,512,4,0,5,1,1,513]

theorem envBound30995 : H12AffineFastState.Bounded env30995 := by
  intro p hp
  have h : env30995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30994_30995 : H12AffineEnvironment.transform 3 0 env30994 = env30995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env30994 == env30995) = true)

theorem identity30995 : scanCanonicalize (H12AffineFastState.compose env30995 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound30995 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30996 : List Nat := [2,4,8,0,0,0,8,4,1,4,0,1,8,1,1,2,1,0,5,0,0,0,1,3,8,0,1,0,0,1,4,0,5,1,1,0]

theorem envBound30996 : H12AffineFastState.Bounded env30996 := by
  intro p hp
  have h : env30996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30995_30996 : H12AffineEnvironment.transform 8 1 env30995 = env30996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env30995 == env30996) = true)

def env30997 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,184401,272393,180225,21763,8193,64,43357,185601,17665,262144,181573,400452,257,21793,46092,144973]

theorem envBound30997 : H12AffineFastState.Bounded env30997 := by
  intro p hp
  have h : env30997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30982_30997 : H12AffineEnvironment.transform 6 9 env30982 = env30997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30982 == env30997) = true)

theorem identity30997 : scanCanonicalize (H12AffineFastState.compose env30997 (packedSelected [0,3,4,8,10,12,14,18,19,20,22,23,24,27,28,31,38] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound30997 : packedSelected [0,3,4,8,10,12,14,18,19,20,22,23,24,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env30998 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32040,1025,32769,184401,21793,180225,21763,8193,64,43357,185601,17665,32040,181573,156012,257,21793,46092,144973]

theorem envBound30998 : H12AffineFastState.Bounded env30998 := by
  intro p hp
  have h : env30998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30997_30998 : H12AffineEnvironment.transform 17 32040 env30997 = env30998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env30997 == env30998) = true)

theorem identity30998 : scanCanonicalize (H12AffineFastState.compose env30998 (packedSelected [0,4,5,12,14,15,16,17,22,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound30998 : packedSelected [0,4,5,12,14,15,16,17,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env30999 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8461,30043,131072,32040,1025,8460,160092,21793,155916,21763,8193,64,2128,160780,17665,32040,156744,156012,257,21793,5377,144973]

theorem envBound30999 : H12AffineFastState.Bounded env30999 := by
  intro p hp
  have h : env30999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30998_30999 : H12AffineEnvironment.transform 14 8461 env30998 = env30999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env30998 == env30999) = true)

theorem identity30999 : scanCanonicalize (H12AffineFastState.compose env30999 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound30999 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env31000 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8461,30043,13340,32040,1025,8460,17728,21793,21776,21763,8193,64,2128,16400,17665,32040,20564,21872,257,21793,5377,593]

theorem envBound31000 : H12AffineFastState.Bounded env31000 := by
  intro p hp
  have h : env31000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30999_31000 : H12AffineEnvironment.transform 16 13340 env30999 = env31000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env30999 == env31000) = true)

theorem identity31000 : scanCanonicalize (H12AffineFastState.compose env31000 (packedSelected [17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31000 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31001 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8461,29963,13340,32040,1025,8460,17680,21793,21776,21763,8193,16,2048,16400,17665,32040,20484,21792,257,21793,5377,513]

theorem envBound31001 : H12AffineFastState.Bounded env31001 := by
  intro p hp
  have h : env31001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31000_31001 : H12AffineEnvironment.transform 5 16 env31000 = env31001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31000 == env31001) = true)

theorem identity31001 : scanCanonicalize (H12AffineFastState.compose env31001 (packedSelected [1,2,4,6,8,9,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound31001 : packedSelected [1,2,4,6,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env31002 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,1053,16384,1296,20758,4097,22837,1025,1297,17680,21793,21776,21763,1052,16,2048,16400,17665,22837,20484,21792,257,21793,5377,513]

theorem envBound31002 : H12AffineFastState.Bounded env31002 := by
  intro p hp
  have h : env31002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31001_31002 : H12AffineEnvironment.transform 12 1053 env31001 = env31002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env31001 == env31002) = true)

theorem identity31002 : scanCanonicalize (H12AffineFastState.compose env31002 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound31002 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env31003 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,1053,4112,1296,262,4097,2341,1025,1297,5376,1329,1280,1299,1052,16,2048,4096,5393,2341,20,1328,257,1329,5377,513]

theorem envBound31003 : H12AffineFastState.Bounded env31003 := by
  intro p hp
  have h : env31003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31002_31003 : H12AffineEnvironment.transform 13 4112 env31002 = env31003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env31002 == env31003) = true)

def env31004 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272513,180360,98780,8328,64,43477,185736,17665,262281,181573,400453,257,21793,46213,254610]

theorem envBound31004 : H12AffineFastState.Bounded env31004 := by
  intro p hp
  have h : env31004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30980_31004 : H12AffineEnvironment.transform 21 272513 env30980 = env31004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env30980 == env31004) = true)

theorem identity31004 : scanCanonicalize (H12AffineFastState.compose env31004 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound31004 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31005 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70726,262144,1025,32769,115870,272513,120014,98780,8328,64,43477,115150,17665,262281,119043,329731,257,21793,46213,63188]

theorem envBound31005 : H12AffineFastState.Bounded env31005 := by
  intro p hp
  have h : env31005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31004_31005 : H12AffineEnvironment.transform 16 70726 env31004 = env31005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env31004 == env31005) = true)

def env31006 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70726,10400,1025,32769,115870,33,120014,98780,8328,64,43477,115150,17665,10281,119043,73891,257,21793,46213,63188]

theorem envBound31006 : H12AffineFastState.Bounded env31006 := by
  intro p hp
  have h : env31006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31005_31006 : H12AffineEnvironment.transform 17 10400 env31005 = env31006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env31005 == env31006) = true)

theorem identity31006 : scanCanonicalize (H12AffineFastState.compose env31006 (packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound31006 : packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env31007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,137,65536,70726,10400,1025,136,82967,33,87111,65877,8328,64,10588,82247,17665,10281,86410,73891,257,21793,13324,30301]

theorem envBound31007 : H12AffineFastState.Bounded env31007 := by
  intro p hp
  have h : env31007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31006_31007 : H12AffineEnvironment.transform 14 137 env31006 = env31007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env31006 == env31007) = true)

theorem identity31007 : scanCanonicalize (H12AffineFastState.compose env31007 (packedSelected [0,3,9,10,16,17,18,19,20,22,23,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound31007 : packedSelected [0,3,9,10,16,17,18,19,20,22,23,24,27] rootPS < 2^1333 := by decide +kernel

def env31008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,137,8203,13389,10400,1025,136,25628,33,29772,8542,8328,64,10588,24908,17665,10281,29057,168,257,21793,13324,30301]

theorem envBound31008 : H12AffineFastState.Bounded env31008 := by
  intro p hp
  have h : env31008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31007_31008 : H12AffineEnvironment.transform 15 8203 env31007 = env31008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env31007 == env31008) = true)

theorem identity31008 : scanCanonicalize (H12AffineFastState.compose env31008 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound31008 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env31009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,137,8203,13389,10400,1025,136,4160,33,16,8542,8328,64,10588,5392,12637,10281,1501,168,257,8573,13324,513]

theorem envBound31009 : H12AffineFastState.Bounded env31009 := by
  intro p hp
  have h : env31009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31008_31009 : H12AffineEnvironment.transform 13 13404 env31008 = env31009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env31008 == env31009) = true)

theorem identity31009 : scanCanonicalize (H12AffineFastState.compose env31009 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31009 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31010 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,137,8203,13341,10400,1025,136,4112,33,16,8462,8328,16,10508,5392,12557,10281,1421,168,257,8493,13324,513]

theorem envBound31010 : H12AffineFastState.Bounded env31010 := by
  intro p hp
  have h : env31010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31009_31010 : H12AffineEnvironment.transform 5 16 env31009 = env31010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31009 == env31010) = true)

theorem identity31010 : scanCanonicalize (H12AffineFastState.compose env31010 (packedSelected [7,9,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 5645) := by decide +kernel

theorem selectedBound31010 : packedSelected [7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env31011 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5645,513,137,5638,528,7853,1025,136,4112,33,16,5891,5765,16,7937,5392,1792,7716,1421,168,257,5920,513,513]

theorem envBound31011 : H12AffineFastState.Bounded env31011 := by
  intro p hp
  have h : env31011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31010_31011 : H12AffineEnvironment.transform 12 5645 env31010 = env31011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5645 env31010 == env31011) = true)

theorem identity31011 : scanCanonicalize (H12AffineFastState.compose env31011 (packedSelected [0,2,4,5,7,8,9,14] rootPS)) = affineNative (2^(11+1) ^^^ 2444) := by decide +kernel

theorem selectedBound31011 : packedSelected [0,2,4,5,7,8,9,14] rootPS < 2^1333 := by decide +kernel

def env31012 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2444,3969,513,137,3978,528,1825,1025,136,2460,33,16,3727,3849,16,1677,3228,1792,1960,1421,168,257,3756,513,513]

theorem envBound31012 : H12AffineFastState.Bounded env31012 := by
  intro p hp
  have h : env31012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31011_31012 : H12AffineEnvironment.transform 11 2444 env31011 = env31012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2444 env31011 == env31012) = true)

theorem identity31012 : scanCanonicalize (H12AffineFastState.compose env31012 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 1540) := by decide +kernel

theorem selectedBound31012 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env31013 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1540,1928,389,513,137,398,528,1825,1025,136,1944,33,16,139,269,16,1677,664,1792,1960,1421,168,257,168,513,513]

theorem envBound31013 : H12AffineFastState.Bounded env31013 := by
  intro p hp
  have h : env31013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31012_31013 : H12AffineEnvironment.transform 10 1540 env31012 = env31013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env31012 == env31013) = true)

theorem identity31013 : scanCanonicalize (H12AffineFastState.compose env31013 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound31013 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env31014 : List Nat := [2,4,8,16,32,16,128,256,276,1024,1296,1180,389,277,137,398,260,1077,1025,136,1164,33,16,139,269,16,1433,396,1044,1212,1421,168,257,168,277,277]

theorem envBound31014 : H12AffineFastState.Bounded env31014 := by
  intro p hp
  have h : env31014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31013_31014 : H12AffineEnvironment.transform 8 276 env31013 = env31014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env31013 == env31014) = true)

theorem identity31014 : scanCanonicalize (H12AffineFastState.compose env31014 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound31014 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env31015 : List Nat := [2,4,8,16,32,16,9,256,276,1024,1296,1045,268,277,0,263,260,1077,1025,1,1029,33,16,2,269,16,1296,261,1044,1077,1284,33,257,33,277,277]

theorem envBound31015 : H12AffineFastState.Bounded env31015 := by
  intro p hp
  have h : env31015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31014_31015 : H12AffineEnvironment.transform 6 9 env31014 = env31015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31014 == env31015) = true)

theorem identity31015 : scanCanonicalize (H12AffineFastState.compose env31015 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 289) := by decide +kernel

theorem selectedBound31015 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31016 : List Nat := [2,4,8,16,32,16,9,256,276,289,49,308,268,277,0,263,260,276,288,1,292,33,16,2,269,16,49,261,309,276,37,33,257,33,277,277]

theorem envBound31016 : H12AffineFastState.Bounded env31016 := by
  intro p hp
  have h : env31016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31015_31016 : H12AffineEnvironment.transform 9 289 env31015 = env31016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 289 env31015 == env31016) = true)

theorem identity31016 : scanCanonicalize (H12AffineFastState.compose env31016 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound31016 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env31017 : List Nat := [2,4,8,16,32,16,9,4,16,37,49,48,8,17,0,3,0,16,36,1,32,33,16,2,9,16,49,1,49,16,37,33,5,33,17,17]

theorem envBound31017 : H12AffineFastState.Bounded env31017 := by
  intro p hp
  have h : env31017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31016_31017 : H12AffineEnvironment.transform 7 4 env31016 = env31017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env31016 == env31017) = true)

theorem identity31017 : scanCanonicalize (H12AffineFastState.compose env31017 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound31017 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env31018 : List Nat := [2,4,8,0,32,0,9,4,0,37,33,32,8,1,0,3,0,0,36,1,32,33,0,2,9,0,33,1,33,0,37,33,5,33,1,1]

theorem envBound31018 : H12AffineFastState.Bounded env31018 := by
  intro p hp
  have h : env31018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31017_31018 : H12AffineEnvironment.transform 3 0 env31017 = env31018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env31017 == env31018) = true)

theorem identity31018 : scanCanonicalize (H12AffineFastState.compose env31018 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31018 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31019 : List Nat := [2,4,8,0,1,0,9,4,0,4,0,1,8,1,0,3,0,0,5,1,1,0,0,2,9,0,0,1,0,0,4,0,5,0,1,1]

theorem envBound31019 : H12AffineFastState.Bounded env31019 := by
  intro p hp
  have h : env31019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31018_31019 : H12AffineEnvironment.transform 4 1 env31018 = env31019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31018 == env31019) = true)

def env31020 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70726,10401,1025,32769,115870,32,120014,98780,8328,64,43477,115150,17665,10280,119043,73890,257,21793,46213,63188]

theorem envBound31020 : H12AffineFastState.Bounded env31020 := by
  intro p hp
  have h : env31020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31005_31020 : H12AffineEnvironment.transform 17 10401 env31005 = env31020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env31005 == env31020) = true)

theorem identity31020 : scanCanonicalize (H12AffineFastState.compose env31020 (packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound31020 : packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env31021 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,21591,16401,10401,1025,32769,37065,32,32921,54667,8328,64,43477,38297,17665,10280,34132,29941,257,21793,46213,63188]

theorem envBound31021 : H12AffineFastState.Bounded env31021 := by
  intro p hp
  have h : env31021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31020_31021 : H12AffineEnvironment.transform 15 21591 env31020 = env31021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env31020 == env31021) = true)

theorem identity31021 : scanCanonicalize (H12AffineFastState.compose env31021 (packedSelected [1,5,8,16,17,19,20,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound31021 : packedSelected [1,5,8,16,17,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env31022 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,32768,8202,13388,10401,1025,32769,37065,32,32921,41430,8328,64,43477,38297,12636,10280,34132,168,257,8572,46213,33417]

theorem envBound31022 : H12AffineFastState.Bounded env31022 := by
  intro p hp
  have h : env31022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31021_31022 : H12AffineEnvironment.transform 13 13405 env31021 = env31022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env31021 == env31022) = true)

theorem identity31022 : scanCanonicalize (H12AffineFastState.compose env31022 (packedSelected [0,1,4,5,7,8,17,18,22,23,24] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31022 : packedSelected [0,1,4,5,7,8,17,18,22,23,24] rootPS < 2^1333 := by decide +kernel

def env31023 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13324,32768,8202,13341,10401,1025,32769,37016,32,32921,41351,8328,17,43396,38297,12557,10280,34053,168,257,8493,46213,33417]

theorem envBound31023 : H12AffineFastState.Bounded env31023 := by
  intro p hp
  have h : env31023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31022_31023 : H12AffineEnvironment.transform 5 17 env31022 = env31023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31022 == env31023) = true)

theorem identity31023 : scanCanonicalize (H12AffineFastState.compose env31023 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound31023 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env31024 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13324,292,8202,13341,10401,1025,293,4540,32,445,8355,8328,17,10400,5309,12557,10280,1057,168,257,8493,13729,941]

theorem envBound31024 : H12AffineFastState.Bounded env31024 := by
  intro p hp
  have h : env31024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31023_31024 : H12AffineEnvironment.transform 14 292 env31023 = env31024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env31023 == env31024) = true)

theorem identity31024 : scanCanonicalize (H12AffineFastState.compose env31024 (packedSelected [6,9,17,22] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound31024 : packedSelected [6,9,17,22] rootPS < 2^1333 := by decide +kernel

def env31025 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,13324,137,8202,13341,10401,1025,136,4113,32,16,8355,8328,17,10400,5309,12448,10280,1057,168,172,8320,13324,512]

theorem envBound31025 : H12AffineFastState.Bounded env31025 := by
  intro p hp
  have h : env31025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31024_31025 : H12AffineEnvironment.transform 7 173 env31024 = env31025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env31024 == env31025) = true)

theorem identity31025 : scanCanonicalize (H12AffineFastState.compose env31025 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound31025 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31026 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,9,5125,137,3,5140,2216,1025,136,4113,32,16,170,129,17,2217,5309,4265,2081,1057,168,172,137,5125,512]

theorem envBound31026 : H12AffineFastState.Bounded env31026 := by
  intro p hp
  have h : env31026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31025_31026 : H12AffineEnvironment.transform 12 9 env31025 = env31026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env31025 == env31026) = true)

theorem identity31026 : scanCanonicalize (H12AffineFastState.compose env31026 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound31026 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env31027 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,9,5125,1,3,5140,2080,1025,0,4113,32,16,34,9,17,2081,5173,4129,2081,1057,32,36,1,5125,512]

theorem envBound31027 : H12AffineFastState.Bounded env31027 := by
  intro p hp
  have h : env31027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31026_31027 : H12AffineEnvironment.transform 6 8 env31026 = env31027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31026 == env31027) = true)

def env31028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,4194304,180361,98781,8328,64,4489556,185737,17664,262280,181573,4338885,257,21793,46213,254610]

theorem envBound31028 : H12AffineFastState.Bounded env31028 := by
  intro p hp
  have h : env31028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30979_31028 : H12AffineEnvironment.transform 22 180361 env30979 = env31028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180361 env30979 == env31028) = true)

def env31029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272512,180361,98781,8328,64,43476,185737,17664,262280,181573,400453,257,21793,46213,254610]

theorem envBound31029 : H12AffineFastState.Bounded env31029 := by
  intro p hp
  have h : env31029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31028_31029 : H12AffineEnvironment.transform 21 272512 env31028 = env31029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env31028 == env31029) = true)

theorem identity31029 : scanCanonicalize (H12AffineFastState.compose env31029 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound31029 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,184536,272512,180361,41430,8328,64,43476,185737,17664,262280,181573,400453,257,21793,46213,180889]

theorem envBound31030 : H12AffineFastState.Bounded env31030 := by
  intro p hp
  have h : env31030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31029_31030 : H12AffineEnvironment.transform 15 8203 env31029 = env31030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env31029 == env31030) = true)

theorem identity31030 : scanCanonicalize (H12AffineFastState.compose env31030 (packedSelected [4,7,9,12,15,27,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound31030 : packedSelected [4,7,9,12,15,27,38,41] rootPS < 2^1333 := by decide +kernel

def env31031 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1025,32769,37065,272512,32920,41430,8328,64,43476,38296,17664,262280,34132,285780,257,21793,46213,33416]

theorem envBound31031 : H12AffineFastState.Bounded env31031 := by
  intro p hp
  have h : env31031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31030_31031 : H12AffineEnvironment.transform 16 16401 env31030 = env31031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env31030 == env31031) = true)

theorem identity31031 : scanCanonicalize (H12AffineFastState.compose env31031 (packedSelected [0,3,4,7,10,16,18,19,20,22,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 32240) := by decide +kernel

theorem selectedBound31031 : packedSelected [0,3,4,7,10,16,18,19,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env31032 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,32240,1025,32769,37065,21872,32920,41430,8328,64,43476,38296,17664,32120,34132,8612,257,21793,46213,33416]

theorem envBound31032 : H12AffineFastState.Bounded env31032 := by
  intro p hp
  have h : env31032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31031_31032 : H12AffineEnvironment.transform 17 32240 env31031 = env31032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32240 env31031 == env31032) = true)

theorem identity31032 : scanCanonicalize (H12AffineFastState.compose env31032 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound31032 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env31033 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21840,8203,16401,32240,1025,21841,17817,21872,21960,29830,8328,64,31876,16584,17664,32120,20484,8612,257,21793,25045,22488]

theorem envBound31033 : H12AffineFastState.Bounded env31033 := by
  intro p hp
  have h : env31033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31032_31033 : H12AffineEnvironment.transform 14 21840 env31032 = env31033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env31032 == env31033) = true)

theorem identity31033 : scanCanonicalize (H12AffineFastState.compose env31033 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(13+1) ^^^ 5592) := by decide +kernel

theorem selectedBound31033 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env31034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5592,136,8203,5577,10280,1025,137,4161,168,16,8542,8328,64,10588,5392,4312,10400,1500,8612,257,249,13325,512]

theorem envBound31034 : H12AffineFastState.Bounded env31034 := by
  intro p hp
  have h : env31034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31033_31034 : H12AffineEnvironment.transform 13 5592 env31033 = env31034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5592 env31033 == env31034) = true)

theorem identity31034 : scanCanonicalize (H12AffineFastState.compose env31034 (packedSelected [1,3,6,10,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 3606) := by decide +kernel

theorem selectedBound31034 : packedSelected [1,3,6,10,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env31035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3606,5592,136,3613,5577,1598,1025,137,4161,168,16,3912,3742,64,1866,5392,4312,1718,1500,4018,257,249,6683,512]

theorem envBound31035 : H12AffineFastState.Bounded env31035 := by
  intro p hp
  have h : env31035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31034_31035 : H12AffineEnvironment.transform 12 3606 env31034 = env31035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3606 env31034 == env31035) = true)

theorem identity31035 : scanCanonicalize (H12AffineFastState.compose env31035 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(10+1) ^^^ 1646) := by decide +kernel

theorem selectedBound31035 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env31036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1646,4096,120,5592,136,115,5577,1598,1025,137,4161,168,16,294,240,64,1866,5392,4312,1718,1500,476,257,249,5237,512]

theorem envBound31036 : H12AffineFastState.Bounded env31036 := by
  intro p hp
  have h : env31036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31035_31036 : H12AffineEnvironment.transform 10 1646 env31035 = env31036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1646 env31035 == env31036) = true)

theorem identity31036 : scanCanonicalize (H12AffineFastState.compose env31036 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound31036 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1646,65,120,1433,136,115,1416,1598,1025,137,0,168,16,294,240,64,1866,1361,153,1718,1500,476,257,249,1076,512]

theorem envBound31037 : H12AffineFastState.Bounded env31037 := by
  intro p hp
  have h : env31037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31036_31037 : H12AffineEnvironment.transform 11 65 env31036 = env31037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env31036 == env31037) = true)

theorem identity31037 : scanCanonicalize (H12AffineFastState.compose env31037 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound31037 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env31038 : List Nat := [2,4,8,16,32,64,128,256,512,69,555,65,120,476,136,115,461,635,68,137,0,168,16,294,240,64,783,276,153,755,409,476,257,249,113,512]

theorem envBound31038 : H12AffineFastState.Bounded env31038 := by
  intro p hp
  have h : env31038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31037_31038 : H12AffineEnvironment.transform 9 69 env31037 = env31038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env31037 == env31038) = true)

theorem identity31038 : scanCanonicalize (H12AffineFastState.compose env31038 (packedSelected [0,1,3,7,10] rootPS)) = affineNative (2^(8+1) ^^^ 302) := by decide +kernel

theorem selectedBound31038 : packedSelected [0,1,3,7,10] rootPS < 2^1333 := by decide +kernel

def env31039 : List Nat := [2,4,8,16,32,64,128,256,302,69,261,65,120,476,136,115,461,341,68,137,0,168,16,294,240,64,33,276,153,477,409,476,257,249,113,302]

theorem envBound31039 : H12AffineFastState.Bounded env31039 := by
  intro p hp
  have h : env31039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31038_31039 : H12AffineEnvironment.transform 8 302 env31038 = env31039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 302 env31038 == env31039) = true)

theorem identity31039 : scanCanonicalize (H12AffineFastState.compose env31039 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound31039 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31040 : List Nat := [2,4,8,16,32,64,128,253,211,69,248,65,120,33,136,115,48,168,68,137,0,168,16,219,240,64,33,233,153,32,100,33,252,249,113,211]

theorem envBound31040 : H12AffineFastState.Bounded env31040 := by
  intro p hp
  have h : env31040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31039_31040 : H12AffineEnvironment.transform 7 253 env31039 = env31040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env31039 == env31040) = true)

theorem identity31040 : scanCanonicalize (H12AffineFastState.compose env31040 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 112) := by decide +kernel

theorem selectedBound31040 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env31041 : List Nat := [2,4,8,16,32,64,112,13,35,69,8,65,120,33,120,115,48,88,68,121,0,88,16,43,0,64,33,25,105,32,100,33,12,9,113,35]

theorem envBound31041 : H12AffineFastState.Bounded env31041 := by
  intro p hp
  have h : env31041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31040_31041 : H12AffineEnvironment.transform 6 112 env31040 = env31041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 112 env31040 == env31041) = true)

theorem identity31041 : scanCanonicalize (H12AffineFastState.compose env31041 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 24) := by decide +kernel

theorem selectedBound31041 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31042 : List Nat := [2,4,8,16,32,24,40,13,35,29,8,25,32,33,32,43,48,0,28,33,0,0,16,43,0,24,33,25,49,32,60,33,12,9,41,35]

theorem envBound31042 : H12AffineFastState.Bounded env31042 := by
  intro p hp
  have h : env31042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31041_31042 : H12AffineEnvironment.transform 5 24 env31041 = env31042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 24 env31041 == env31042) = true)

def env31043 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272513,180361,98781,8328,64,43477,185737,17664,262280,181573,400452,257,21793,46213,254610]

theorem envBound31043 : H12AffineFastState.Bounded env31043 := by
  intro p hp
  have h : env31043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31028_31043 : H12AffineEnvironment.transform 21 272513 env31028 = env31043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env31028 == env31043) = true)

theorem identity31043 : scanCanonicalize (H12AffineFastState.compose env31043 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 123027) := by decide +kernel

theorem selectedBound31043 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31044 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,77899,272513,73754,98781,8328,64,43477,79130,17664,262280,75222,392407,257,21793,46213,513]

theorem envBound31044 : H12AffineFastState.Bounded env31044 := by
  intro p hp
  have h : env31044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31043_31044 : H12AffineEnvironment.transform 16 123027 env31043 = env31044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 123027 env31043 == env31044) = true)

def env31045 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,65536,90259,262144,1025,1,77899,272513,73754,66013,8328,64,10709,79130,17664,262280,75222,359639,257,21793,13445,513]

theorem envBound31045 : H12AffineFastState.Bounded env31045 := by
  intro p hp
  have h : env31045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31044_31045 : H12AffineEnvironment.transform 14 0 env31044 = env31045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env31044 == env31045) = true)

theorem identity31045 : scanCanonicalize (H12AffineFastState.compose env31045 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound31045 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env31046 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,65536,90138,262144,1025,1,77899,272392,73754,65876,8193,64,10588,79130,17664,262145,75103,359518,257,21793,13324,513]

theorem envBound31046 : H12AffineFastState.Bounded env31046 := by
  intro p hp
  have h : env31046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31045_31046 : H12AffineEnvironment.transform 6 9 env31045 = env31046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31045 == env31046) = true)

theorem identity31046 : scanCanonicalize (H12AffineFastState.compose env31046 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound31046 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env31047 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,65536,90138,67618,1025,1,77899,73770,73754,65876,8193,64,10588,79130,17664,67619,75103,29820,257,21793,13324,513]

theorem envBound31047 : H12AffineFastState.Bounded env31047 := by
  intro p hp
  have h : env31047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31046_31047 : H12AffineEnvironment.transform 17 67618 env31046 = env31047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env31046 == env31047) = true)

theorem identity31047 : scanCanonicalize (H12AffineFastState.compose env31047 (packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,18,23,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound31047 : packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,18,23,24,28] rootPS < 2^1333 := by decide +kernel

def env31048 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,0,65536,70726,67618,1025,1,77899,73770,73754,65876,8193,64,10588,79130,12636,67619,75103,32,257,8573,13324,513]

theorem envBound31048 : H12AffineFastState.Bounded env31048 := by
  intro p hp
  have h : env31048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31047_31048 : H12AffineEnvironment.transform 13 13404 env31047 = env31048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env31047 == env31048) = true)

theorem identity31048 : scanCanonicalize (H12AffineFastState.compose env31048 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound31048 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31049 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,65536,70726,67618,1025,1,69911,65910,65862,65876,349,64,2048,70726,4096,67619,66563,32,257,33,5456,513]

theorem envBound31049 : H12AffineFastState.Bounded env31049 := by
  intro p hp
  have h : env31049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31048_31049 : H12AffineEnvironment.transform 12 348 env31048 = env31049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env31048 == env31049) = true)

theorem identity31049 : scanCanonicalize (H12AffineFastState.compose env31049 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound31049 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31050 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,343,5393,2421,1025,1,4160,33,17,3,349,64,2048,5393,4096,2420,1364,32,257,33,5456,513]

theorem envBound31050 : H12AffineFastState.Bounded env31050 := by
  intro p hp
  have h : env31050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31049_31050 : H12AffineEnvironment.transform 15 343 env31049 = env31050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env31049 == env31050) = true)

theorem identity31050 : scanCanonicalize (H12AffineFastState.compose env31050 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound31050 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31051 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,356,348,1124,0,343,1141,2421,1025,1,292,33,17,3,349,64,2048,1141,356,2420,1364,32,257,33,1076,513]

theorem envBound31051 : H12AffineFastState.Bounded env31051 := by
  intro p hp
  have h : env31051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31050_31051 : H12AffineEnvironment.transform 11 356 env31050 = env31051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env31050 == env31051) = true)

theorem identity31051 : scanCanonicalize (H12AffineFastState.compose env31051 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound31051 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env31052 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,356,348,1124,0,343,1141,1297,1025,1,292,33,17,3,349,64,1124,1141,356,1296,1364,32,257,33,1076,513]

theorem envBound31052 : H12AffineFastState.Bounded env31052 := by
  intro p hp
  have h : env31052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31051_31052 : H12AffineEnvironment.transform 10 1124 env31051 = env31052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env31051 == env31052) = true)

theorem identity31052 : scanCanonicalize (H12AffineFastState.compose env31052 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound31052 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env31053 : List Nat := [2,4,8,16,32,64,9,256,309,1024,1124,356,348,1124,0,343,1141,1297,1025,1,292,33,17,3,349,64,1124,1141,356,1296,1364,32,257,33,1076,308]

theorem envBound31053 : H12AffineFastState.Bounded env31053 := by
  intro p hp
  have h : env31053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31052_31053 : H12AffineEnvironment.transform 8 309 env31052 = env31053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env31052 == env31053) = true)

theorem identity31053 : scanCanonicalize (H12AffineFastState.compose env31053 (packedSelected [1,2,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound31053 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env31054 : List Nat := [2,4,8,16,17,64,9,256,260,1024,1109,341,348,1109,0,343,1092,1297,1025,1,277,16,17,3,349,64,1109,1092,341,1296,1364,17,257,16,1029,261]

theorem envBound31054 : H12AffineFastState.Bounded env31054 := by
  intro p hp
  have h : env31054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31053_31054 : H12AffineEnvironment.transform 4 17 env31053 = env31054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env31053 == env31054) = true)

theorem identity31054 : scanCanonicalize (H12AffineFastState.compose env31054 (packedSelected [2,4,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound31054 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env31055 : List Nat := [2,4,8,0,1,64,9,256,260,1024,1093,325,332,1093,0,327,1092,1281,1025,1,261,0,1,3,333,64,1093,1092,325,1280,1348,1,257,0,1029,261]

theorem envBound31055 : H12AffineFastState.Bounded env31055 := by
  intro p hp
  have h : env31055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31054_31055 : H12AffineEnvironment.transform 3 0 env31054 = env31055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env31054 == env31055) = true)

theorem identity31055 : scanCanonicalize (H12AffineFastState.compose env31055 (packedSelected [0,2,4,15] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound31055 : packedSelected [0,2,4,15] rootPS < 2^1333 := by decide +kernel

def env31056 : List Nat := [2,4,8,0,1,0,9,256,260,1024,1029,261,268,1029,0,263,1028,1281,1025,1,261,0,1,3,269,0,1029,1028,261,1280,1284,1,257,0,1029,261]

theorem envBound31056 : H12AffineFastState.Bounded env31056 := by
  intro p hp
  have h : env31056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31055_31056 : H12AffineEnvironment.transform 5 0 env31055 = env31056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env31055 == env31056) = true)

theorem identity31056 : scanCanonicalize (H12AffineFastState.compose env31056 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound31056 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31057 : List Nat := [2,4,8,0,1,0,9,256,260,257,260,261,268,260,0,263,261,0,256,1,261,0,1,3,269,0,260,261,261,1,5,1,257,0,260,261]

theorem envBound31057 : H12AffineFastState.Bounded env31057 := by
  intro p hp
  have h : env31057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31056_31057 : H12AffineEnvironment.transform 9 257 env31056 = env31057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env31056 == env31057) = true)

theorem identity31057 : scanCanonicalize (H12AffineFastState.compose env31057 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound31057 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31058 : List Nat := [2,4,8,0,1,0,9,5,1,4,1,0,9,1,0,2,0,0,5,1,0,0,1,3,8,0,1,0,0,1,5,1,4,0,1,0]

theorem envBound31058 : H12AffineFastState.Bounded env31058 := by
  intro p hp
  have h : env31058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31057_31058 : H12AffineEnvironment.transform 7 5 env31057 = env31058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env31057 == env31058) = true)

def env31059 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,65536,90258,262144,1025,0,77899,272513,73754,66012,8328,64,10708,79130,17664,262280,75222,359638,257,21793,13444,513]

theorem envBound31059 : H12AffineFastState.Bounded env31059 := by
  intro p hp
  have h : env31059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31044_31059 : H12AffineEnvironment.transform 14 1 env31044 = env31059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env31044 == env31059) = true)

theorem identity31059 : scanCanonicalize (H12AffineFastState.compose env31059 (packedSelected [4,9,12,14,15,16,17,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound31059 : packedSelected [4,9,12,14,15,16,17,38,41] rootPS < 2^1333 := by decide +kernel

def env31060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8322,16400,262144,1025,0,4297,272513,152,8542,8328,64,10708,5528,17664,262280,1364,285780,257,21793,13444,513]

theorem envBound31060 : H12AffineFastState.Bounded env31060 := by
  intro p hp
  have h : env31060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31059_31060 : H12AffineEnvironment.transform 15 8322 env31059 = env31060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env31059 == env31060) = true)

theorem identity31060 : scanCanonicalize (H12AffineFastState.compose env31060 (packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound31060 : packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS < 2^1333 := by decide +kernel

def env31061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8322,16400,10281,1025,0,4297,168,152,8542,8328,64,10708,5528,17664,10401,1364,29821,257,21793,13444,513]

theorem envBound31061 : H12AffineFastState.Bounded env31061 := by
  intro p hp
  have h : env31061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31060_31061 : H12AffineEnvironment.transform 17 10281 env31060 = env31061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env31060 == env31061) = true)

theorem identity31061 : scanCanonicalize (H12AffineFastState.compose env31061 (packedSelected [2,3,5,6,10,17] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound31061 : packedSelected [2,3,5,6,10,17] rootPS < 2^1333 := by decide +kernel

def env31062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,1,342,16400,2557,1025,0,4297,168,152,138,348,64,2048,5528,17664,2421,1364,21929,257,21793,5456,513]

theorem envBound31062 : H12AffineFastState.Bounded env31062 := by
  intro p hp
  have h : env31062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31061_31062 : H12AffineEnvironment.transform 12 468 env31061 = env31062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env31061 == env31062) = true)

theorem identity31062 : scanCanonicalize (H12AffineFastState.compose env31062 (packedSelected [1,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound31062 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env31063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,1,342,5392,2557,1025,0,4297,168,152,138,348,64,2048,5528,4096,2421,1364,169,257,33,5456,513]

theorem envBound31063 : H12AffineFastState.Bounded env31063 := by
  intro p hp
  have h : env31063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31062_31063 : H12AffineEnvironment.transform 13 5376 env31062 = env31063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env31062 == env31063) = true)

theorem identity31063 : scanCanonicalize (H12AffineFastState.compose env31063 (packedSelected [18,23] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound31063 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env31064 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,1,342,5392,2421,1025,0,4161,32,16,2,348,64,2048,5392,4096,2421,1364,33,257,33,5456,513]

theorem envBound31064 : H12AffineFastState.Bounded env31064 := by
  intro p hp
  have h : env31064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31063_31064 : H12AffineEnvironment.transform 6 8 env31063 = env31064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31063 == env31064) = true)

theorem identity31064 : scanCanonicalize (H12AffineFastState.compose env31064 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound31064 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31065 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,348,4113,1,342,4097,2421,272,0,4161,32,16,2,348,64,2048,4097,4096,2421,69,33,257,33,4161,513]

theorem envBound31065 : H12AffineFastState.Bounded env31065 := by
  intro p hp
  have h : env31065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31064_31065 : H12AffineEnvironment.transform 9 273 env31064 = env31065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env31064 == env31065) = true)

theorem identity31065 : scanCanonicalize (H12AffineFastState.compose env31065 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31065 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31066 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,4096,269,4113,1,263,4097,2340,272,0,4112,32,16,2,269,17,2048,4097,4096,2340,20,33,257,33,4112,513]

theorem envBound31066 : H12AffineFastState.Bounded env31066 := by
  intro p hp
  have h : env31066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31065_31066 : H12AffineEnvironment.transform 5 17 env31065 = env31066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31065 == env31066) = true)

theorem identity31066 : scanCanonicalize (H12AffineFastState.compose env31066 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound31066 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31067 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,308,269,293,1,263,309,2340,272,0,292,32,16,2,269,17,2048,309,308,2340,20,33,257,33,292,513]

theorem envBound31067 : H12AffineFastState.Bounded env31067 := by
  intro p hp
  have h : env31067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31066_31067 : H12AffineEnvironment.transform 11 308 env31066 = env31067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env31066 == env31067) = true)

theorem identity31067 : scanCanonicalize (H12AffineFastState.compose env31067 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound31067 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env31068 : List Nat := [2,4,8,16,32,17,8,256,512,273,293,308,269,293,1,263,309,1,272,0,292,32,16,2,269,17,293,309,308,1,20,33,257,33,292,513]

theorem envBound31068 : H12AffineFastState.Bounded env31068 := by
  intro p hp
  have h : env31068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31067_31068 : H12AffineEnvironment.transform 10 293 env31067 = env31068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env31067 == env31068) = true)

theorem identity31068 : scanCanonicalize (H12AffineFastState.compose env31068 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound31068 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env31069 : List Nat := [2,4,8,16,32,17,8,36,512,53,1,16,41,1,1,35,17,1,52,0,0,32,16,2,41,17,1,17,16,1,20,33,37,33,0,513]

theorem envBound31069 : H12AffineFastState.Bounded env31069 := by
  intro p hp
  have h : env31069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31068_31069 : H12AffineEnvironment.transform 7 36 env31068 = env31069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env31068 == env31069) = true)

theorem identity31069 : scanCanonicalize (H12AffineFastState.compose env31069 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound31069 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31070 : List Nat := [2,4,8,16,17,17,8,21,512,4,1,16,24,1,1,18,17,1,5,0,0,17,16,2,24,17,1,17,16,1,20,16,20,16,0,513]

theorem envBound31070 : H12AffineFastState.Bounded env31070 := by
  intro p hp
  have h : env31070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31069_31070 : H12AffineEnvironment.transform 4 17 env31069 = env31070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env31069 == env31070) = true)

theorem identity31070 : scanCanonicalize (H12AffineFastState.compose env31070 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound31070 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31071 : List Nat := [2,4,8,16,17,17,8,21,1,4,1,16,24,1,1,18,17,1,5,0,0,17,16,2,24,17,1,17,16,1,20,16,20,16,0,0]

theorem envBound31071 : H12AffineFastState.Bounded env31071 := by
  intro p hp
  have h : env31071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31070_31071 : H12AffineEnvironment.transform 8 1 env31070 = env31071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env31070 == env31071) = true)

def env31072 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,4194304,8388608,8601940,8328,64,4489556,8393985,8553864,8830977,181573,12645453,257,21792,46212,254610]

theorem envBound31072 : H12AffineFastState.Bounded env31072 := by
  intro p hp
  have h : env31072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30978_31072 : H12AffineEnvironment.transform 20 184537 env30978 = env31072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184537 env30978 == env31072) = true)

def env31073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,4194304,180360,98780,8328,64,4489556,185737,17664,262281,181573,4338885,257,21792,46212,254610]

theorem envBound31073 : H12AffineFastState.Bounded env31073 := by
  intro p hp
  have h : env31073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31072_31073 : H12AffineEnvironment.transform 22 180360 env31072 = env31073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180360 env31072 == env31073) = true)

def env31074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272512,180360,98780,8328,64,43476,185737,17664,262281,181573,400453,257,21792,46212,254610]

theorem envBound31074 : H12AffineFastState.Bounded env31074 := by
  intro p hp
  have h : env31074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31073_31074 : H12AffineEnvironment.transform 21 272512 env31073 = env31074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env31073 == env31074) = true)

theorem identity31074 : scanCanonicalize (H12AffineFastState.compose env31074 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound31074 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,262144,1025,32769,58516,272512,62661,98780,8328,64,43476,57796,17664,262281,61704,272392,257,21792,46212,120543]

theorem envBound31075 : H12AffineFastState.Bounded env31075 := by
  intro p hp
  have h : env31075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31074_31075 : H12AffineEnvironment.transform 16 13389 env31074 = env31075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env31074 == env31075) = true)

def env31076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,10280,1025,32769,58516,168,62661,98780,8328,64,43476,57796,17664,10401,61704,32,257,21792,46212,120543]

theorem envBound31076 : H12AffineFastState.Bounded env31076 := by
  intro p hp
  have h : env31076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31075_31076 : H12AffineEnvironment.transform 17 10280 env31075 = env31076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env31075 == env31076) = true)

theorem identity31076 : scanCanonicalize (H12AffineFastState.compose env31076 (packedSelected [1,3,4,7,8,9,10,11,16,20,24,27,32] rootPS)) = affineNative (2^(12+1) ^^^ 1221) := by decide +kernel

theorem selectedBound31076 : packedSelected [1,3,4,7,8,9,10,11,16,20,24,27,32] rootPS < 2^1333 := by decide +kernel

def env31077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1221,16384,32768,65536,4232,3309,1025,32769,49233,168,53248,98780,1101,64,36113,50433,17664,3172,54733,32,257,21792,36929,120543]

theorem envBound31077 : H12AffineFastState.Bounded env31077 := by
  intro p hp
  have h : env31077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31076_31077 : H12AffineEnvironment.transform 12 1221 env31076 = env31077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1221 env31076 == env31077) = true)

theorem identity31077 : scanCanonicalize (H12AffineFastState.compose env31077 (packedSelected [1,3,4,7,8,9,15,16,17,18,19,20,23,24,26,27,31,38] rootPS)) = affineNative (2^(14+1) ^^^ 1481) := by decide +kernel

theorem selectedBound31077 : packedSelected [1,3,4,7,8,9,15,16,17,18,19,20,23,24,26,27,31,38] rootPS < 2^1333 := by decide +kernel

def env31078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1221,16384,1481,65536,4232,3309,1025,1480,17816,168,21961,66581,1101,64,2264,16584,17664,3172,20484,32,257,21792,5512,86806]

theorem envBound31078 : H12AffineFastState.Bounded env31078 := by
  intro p hp
  have h : env31078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31077_31078 : H12AffineEnvironment.transform 14 1481 env31077 = env31078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1481 env31077 == env31078) = true)

theorem identity31078 : scanCanonicalize (H12AffineFastState.compose env31078 (packedSelected [0,3,5,9,10,11,16,17,19,20,22,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 21794) := by decide +kernel

theorem selectedBound31078 : packedSelected [0,3,5,9,10,11,16,17,19,20,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env31079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1221,16384,1481,21794,4232,3309,1025,1480,17816,168,21961,20791,1101,64,2264,16584,17664,3172,20484,32,257,21792,5512,1588]

theorem envBound31079 : H12AffineFastState.Bounded env31079 := by
  intro p hp
  have h : env31079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31078_31079 : H12AffineEnvironment.transform 15 21794 env31078 = env31079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21794 env31078 == env31079) = true)

theorem identity31079 : scanCanonicalize (H12AffineFastState.compose env31079 (packedSelected [0,3,5,7,9,10,11,12,14,15,16,18,22] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound31079 : packedSelected [0,3,5,7,9,10,11,12,14,15,16,18,22] rootPS < 2^1333 := by decide +kernel

def env31080 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,389,16384,137,20578,4232,2477,321,136,16600,168,20617,20791,269,64,2264,16584,16448,2340,20484,32,257,20576,4296,884]

theorem envBound31080 : H12AffineFastState.Bounded env31080 := by
  intro p hp
  have h : env31080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31079_31080 : H12AffineEnvironment.transform 9 320 env31079 = env31080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env31079 == env31080) = true)

theorem identity31080 : scanCanonicalize (H12AffineFastState.compose env31080 (packedSelected [0,2,3,5,6,7,10,11,16,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 4541) := by decide +kernel

theorem selectedBound31080 : packedSelected [0,2,3,5,6,7,10,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env31081 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,389,4541,137,479,4232,2477,321,136,4453,168,308,138,269,64,2264,4469,4605,2340,441,32,257,477,4296,884]

theorem envBound31081 : H12AffineFastState.Bounded env31081 := by
  intro p hp
  have h : env31081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31080_31081 : H12AffineEnvironment.transform 13 4541 env31080 = env31081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4541 env31080 == env31081) = true)

theorem identity31081 : scanCanonicalize (H12AffineFastState.compose env31081 (packedSelected [1,4,8,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound31081 : packedSelected [1,4,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env31082 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,2113,389,2556,137,479,2249,2477,321,136,2340,168,308,138,269,64,2264,2356,2492,2340,441,32,257,477,2185,884]

theorem envBound31082 : H12AffineFastState.Bounded env31082 := by
  intro p hp
  have h : env31082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31081_31082 : H12AffineEnvironment.transform 11 2113 env31081 = env31082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env31081 == env31082) = true)

theorem identity31082 : scanCanonicalize (H12AffineFastState.compose env31082 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 429) := by decide +kernel

theorem selectedBound31082 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env31083 : List Nat := [2,4,8,16,32,64,128,256,512,320,429,492,389,81,137,479,356,0,321,136,137,168,308,138,269,64,373,153,17,137,441,32,257,477,292,884]

theorem envBound31083 : H12AffineFastState.Bounded env31083 := by
  intro p hp
  have h : env31083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31082_31083 : H12AffineEnvironment.transform 10 429 env31082 = env31083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 429 env31082 == env31083) = true)

theorem identity31083 : scanCanonicalize (H12AffineFastState.compose env31083 (packedSelected [1,2,6,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound31083 : packedSelected [1,2,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env31084 : List Nat := [2,4,8,16,32,64,89,256,512,320,372,309,348,81,80,262,356,0,321,81,80,113,308,83,269,64,373,64,17,80,352,32,257,260,292,884]

theorem envBound31084 : H12AffineFastState.Bounded env31084 := by
  intro p hp
  have h : env31084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31083_31084 : H12AffineEnvironment.transform 6 89 env31083 = env31084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env31083 == env31084) = true)

theorem identity31084 : scanCanonicalize (H12AffineFastState.compose env31084 (packedSelected [1,2,3,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound31084 : packedSelected [1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env31085 : List Nat := [2,4,8,16,32,64,89,256,293,320,372,309,348,81,80,262,356,0,321,81,80,113,308,83,269,64,373,64,17,80,352,32,257,260,292,81]

theorem envBound31085 : H12AffineFastState.Bounded env31085 := by
  intro p hp
  have h : env31085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31084_31085 : H12AffineEnvironment.transform 8 293 env31084 = env31085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env31084 == env31085) = true)

def env31086 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,10281,1025,32769,58516,169,62661,98780,8328,64,43476,57796,17664,10400,61704,33,257,21792,46212,120543]

theorem envBound31086 : H12AffineFastState.Bounded env31086 := by
  intro p hp
  have h : env31086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31075_31086 : H12AffineEnvironment.transform 17 10281 env31075 = env31086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env31075 == env31086) = true)

theorem identity31086 : scanCanonicalize (H12AffineFastState.compose env31086 (packedSelected [1,3,4,7,8,9,10,11,16,20,24,27,32] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound31086 : packedSelected [1,3,4,7,8,9,10,11,16,20,24,27,32] rootPS < 2^1333 := by decide +kernel

def env31087 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,343,13389,10281,1025,32769,58516,169,62661,32907,8328,64,43476,57796,17664,10400,61704,33,257,21792,46212,55176]

theorem envBound31087 : H12AffineFastState.Bounded env31087 := by
  intro p hp
  have h : env31087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31086_31087 : H12AffineEnvironment.transform 15 343 env31086 = env31087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env31086 == env31087) = true)

theorem identity31087 : scanCanonicalize (H12AffineFastState.compose env31087 (packedSelected [0,1,4,7,8,17,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound31087 : packedSelected [0,1,4,7,8,17,19,22] rootPS < 2^1333 := by decide +kernel

def env31088 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,137,343,13389,10281,1025,136,25629,169,29772,2,8328,64,10589,24909,17664,10400,29057,33,257,21792,13325,22273]

theorem envBound31088 : H12AffineFastState.Bounded env31088 := by
  intro p hp
  have h : env31088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31087_31088 : H12AffineEnvironment.transform 14 137 env31087 = env31088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env31087 == env31088) = true)

theorem identity31088 : scanCanonicalize (H12AffineFastState.compose env31088 (packedSelected [1,8,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound31088 : packedSelected [1,8,17,19] rootPS < 2^1333 := by decide +kernel

def env31089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,137,343,13389,10281,1025,136,4160,169,17,2,8328,64,10589,5392,12637,10400,1500,33,257,8573,13325,9052]

theorem envBound31089 : H12AffineFastState.Bounded env31089 := by
  intro p hp
  have h : env31089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31088_31089 : H12AffineEnvironment.transform 13 13405 env31088 = env31089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env31088 == env31089) = true)

theorem identity31089 : scanCanonicalize (H12AffineFastState.compose env31089 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound31089 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env31090 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,13405,32,343,13389,10281,1025,33,4160,0,17,2,8225,64,10589,5392,12637,10249,1397,33,257,8573,13325,9052]

theorem envBound31090 : H12AffineFastState.Bounded env31090 := by
  intro p hp
  have h : env31090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31089_31090 : H12AffineEnvironment.transform 6 41 env31089 = env31090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env31089 == env31090) = true)

theorem identity31090 : scanCanonicalize (H12AffineFastState.compose env31090 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound31090 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env31091 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,349,5376,32,343,5392,2420,1025,33,4160,0,17,2,380,64,2048,5392,4096,2388,1397,33,257,32,5456,513]

theorem envBound31091 : H12AffineFastState.Bounded env31091 := by
  intro p hp
  have h : env31091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31090_31091 : H12AffineEnvironment.transform 12 349 env31090 = env31091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env31090 == env31091) = true)

theorem identity31091 : scanCanonicalize (H12AffineFastState.compose env31091 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound31091 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31092 : List Nat := [2,4,8,16,32,49,41,256,512,1024,2048,4096,300,5376,32,294,5392,2309,1025,33,4145,0,17,2,269,49,2048,5392,4096,2341,1284,33,257,32,5409,513]

theorem envBound31092 : H12AffineFastState.Bounded env31092 := by
  intro p hp
  have h : env31092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31091_31092 : H12AffineEnvironment.transform 5 49 env31091 = env31092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env31091 == env31092) = true)

theorem identity31092 : scanCanonicalize (H12AffineFastState.compose env31092 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound31092 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31093 : List Nat := [2,4,8,16,32,49,41,256,512,1024,2048,292,300,1060,32,294,1076,2309,1025,33,277,0,17,2,269,49,2048,1076,292,2341,1284,33,257,32,1029,513]

theorem envBound31093 : H12AffineFastState.Bounded env31093 := by
  intro p hp
  have h : env31093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31092_31093 : H12AffineEnvironment.transform 11 292 env31092 = env31093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env31092 == env31093) = true)

theorem identity31093 : scanCanonicalize (H12AffineFastState.compose env31093 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound31093 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env31094 : List Nat := [2,4,8,16,32,49,41,256,512,1024,277,292,300,1060,32,294,1076,16,1025,33,277,0,17,2,269,49,277,1076,292,48,1284,33,257,32,1029,513]

theorem envBound31094 : H12AffineFastState.Bounded env31094 := by
  intro p hp
  have h : env31094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31093_31094 : H12AffineEnvironment.transform 10 277 env31093 = env31094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env31093 == env31094) = true)

theorem identity31094 : scanCanonicalize (H12AffineFastState.compose env31094 (packedSelected [0,3,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound31094 : packedSelected [0,3,7,8] rootPS < 2^1333 := by decide +kernel

def env31095 : List Nat := [2,4,8,16,32,49,41,256,309,1024,277,292,300,1060,32,294,1076,16,1025,33,277,0,17,2,269,49,277,1076,292,48,1284,33,257,32,1029,308]

theorem envBound31095 : H12AffineFastState.Bounded env31095 := by
  intro p hp
  have h : env31095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31094_31095 : H12AffineEnvironment.transform 8 309 env31094 = env31095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env31094 == env31095) = true)

theorem identity31095 : scanCanonicalize (H12AffineFastState.compose env31095 (packedSelected [11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31095 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env31096 : List Nat := [2,4,8,16,1,16,8,256,276,1024,277,261,269,1029,1,263,1045,16,1025,0,277,0,17,2,269,16,277,1045,261,17,1284,0,257,1,1029,277]

theorem envBound31096 : H12AffineFastState.Bounded env31096 := by
  intro p hp
  have h : env31096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31095_31096 : H12AffineEnvironment.transform 4 1 env31095 = env31096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31095 == env31096) = true)

theorem identity31096 : scanCanonicalize (H12AffineFastState.compose env31096 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound31096 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31097 : List Nat := [2,4,8,16,1,16,8,5,17,1024,16,0,8,1029,1,2,1045,16,1025,0,16,0,17,2,8,16,16,1045,0,17,1025,0,4,1,1029,16]

theorem envBound31097 : H12AffineFastState.Bounded env31097 := by
  intro p hp
  have h : env31097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31096_31097 : H12AffineEnvironment.transform 7 5 env31096 = env31097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env31096 == env31097) = true)

def env31098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272513,180360,98780,8328,64,43477,185737,17664,262281,181573,400452,257,21792,46212,254610]

theorem envBound31098 : H12AffineFastState.Bounded env31098 := by
  intro p hp
  have h : env31098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31073_31098 : H12AffineEnvironment.transform 21 272513 env31073 = env31098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env31073 == env31098) = true)

theorem identity31098 : scanCanonicalize (H12AffineFastState.compose env31098 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound31098 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,140301,272513,144476,95496,8328,64,23809,139613,17664,262281,143761,400452,257,21792,16464,202310]

theorem envBound31099 : H12AffineFastState.Bounded env31099 := by
  intro p hp
  have h : env31099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31098_31099 : H12AffineEnvironment.transform 14 29908 env31098 = env31099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env31098 == env31099) = true)

def env31100 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,140301,272393,144476,95496,8192,64,23809,139613,17664,262145,143641,400452,257,21792,16464,202310]

theorem envBound31100 : H12AffineFastState.Bounded env31100 := by
  intro p hp
  have h : env31100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31099_31100 : H12AffineEnvironment.transform 6 8 env31099 = env31100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31099 == env31100) = true)

theorem identity31100 : scanCanonicalize (H12AffineFastState.compose env31100 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 149861) := by decide +kernel

theorem selectedBound31100 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env31101 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,149861,1025,29789,140301,156012,144476,95496,8192,64,23809,139613,17664,149860,143641,21793,257,21792,16464,202310]

theorem envBound31101 : H12AffineFastState.Bounded env31101 := by
  intro p hp
  have h : env31101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31100_31101 : H12AffineEnvironment.transform 17 149861 env31100 = env31101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149861 env31100 == env31101) = true)

theorem identity31101 : scanCanonicalize (H12AffineFastState.compose env31101 (packedSelected [0,3,4,5,10,12,14,15,17,19,20,22,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 78910) := by decide +kernel

theorem selectedBound31101 : packedSelected [0,3,4,5,10,12,14,15,17,19,20,22,26,27] rootPS < 2^1333 := by decide +kernel

def env31102 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,78910,97627,1025,29789,69683,87378,65634,95496,8192,64,23809,71011,17664,97626,66855,21793,257,21792,16464,8824]

theorem envBound31102 : H12AffineFastState.Bounded env31102 := by
  intro p hp
  have h : env31102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31101_31102 : H12AffineEnvironment.transform 16 78910 env31101 = env31102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78910 env31101 == env31102) = true)

theorem identity31102 : scanCanonicalize (H12AffineFastState.compose env31102 (packedSelected [0,3,7,9,10,14,16,19,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound31102 : packedSelected [0,3,7,9,10,14,16,19,22,24] rootPS < 2^1333 := by decide +kernel

def env31103 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,372,65536,78910,67699,1025,373,69683,73850,65634,65568,8192,64,10281,71011,12328,67698,66855,8201,257,8200,13688,8824]

theorem envBound31103 : H12AffineFastState.Bounded env31103 := by
  intro p hp
  have h : env31103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31102_31103 : H12AffineEnvironment.transform 13 13608 env31102 = env31103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env31102 == env31103) = true)

theorem identity31103 : scanCanonicalize (H12AffineFastState.compose env31103 (packedSelected [0,2,6,7,11,16,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound31103 : packedSelected [0,2,6,7,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env31104 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5456,372,65536,70726,67699,1025,373,69683,65538,65634,65568,120,64,2129,71011,4176,67698,66855,113,257,112,5376,512]

theorem envBound31104 : H12AffineFastState.Bounded env31104 := by
  intro p hp
  have h : env31104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31103_31104 : H12AffineEnvironment.transform 12 120 env31103 = env31104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env31103 == env31104) = true)

theorem identity31104 : scanCanonicalize (H12AffineFastState.compose env31104 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound31104 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env31105 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5456,372,263,5441,2420,1025,373,4404,261,357,295,120,64,2129,5220,4176,2421,1056,113,257,112,5376,512]

theorem envBound31105 : H12AffineFastState.Bounded env31105 := by
  intro p hp
  have h : env31105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31104_31105 : H12AffineEnvironment.transform 15 263 env31104 = env31105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env31104 == env31105) = true)

theorem identity31105 : scanCanonicalize (H12AffineFastState.compose env31105 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound31105 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31106 : List Nat := [2,4,8,16,32,48,8,256,512,1024,2048,4096,8,5408,260,263,5425,2308,1025,261,4404,261,277,295,8,48,2081,5140,4128,2309,1056,1,257,0,5376,512]

theorem envBound31106 : H12AffineFastState.Bounded env31106 := by
  intro p hp
  have h : env31106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31105_31106 : H12AffineEnvironment.transform 5 48 env31105 = env31106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env31105 == env31106) = true)

theorem identity31106 : scanCanonicalize (H12AffineFastState.compose env31106 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31106 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env31107 : List Nat := [2,4,8,16,1,17,8,256,512,1024,2048,4096,8,5377,260,263,5392,2308,1025,261,4373,261,277,262,8,17,2048,5140,4097,2309,1025,1,257,0,5376,512]

theorem envBound31107 : H12AffineFastState.Bounded env31107 := by
  intro p hp
  have h : env31107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31106_31107 : H12AffineEnvironment.transform 4 1 env31106 = env31107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31106 == env31107) = true)

theorem identity31107 : scanCanonicalize (H12AffineFastState.compose env31107 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound31107 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env31108 : List Nat := [2,4,8,16,1,17,8,256,512,1024,2048,1029,8,260,260,263,277,2308,1025,261,1296,261,277,262,8,17,2048,17,1028,2309,1025,1,257,0,261,512]

theorem envBound31108 : H12AffineFastState.Bounded env31108 := by
  intro p hp
  have h : env31108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31107_31108 : H12AffineEnvironment.transform 11 1029 env31107 = env31108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env31107 == env31108) = true)

theorem identity31108 : scanCanonicalize (H12AffineFastState.compose env31108 (packedSelected [2,10] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound31108 : packedSelected [2,10] rootPS < 2^1333 := by decide +kernel

def env31109 : List Nat := [2,4,8,16,1,17,8,256,512,1024,1,1029,8,260,260,263,277,261,1025,261,1296,261,277,262,8,17,1,17,1028,260,1025,1,257,0,261,512]

theorem envBound31109 : H12AffineFastState.Bounded env31109 := by
  intro p hp
  have h : env31109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31108_31109 : H12AffineEnvironment.transform 10 1 env31108 = env31109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env31108 == env31109) = true)

theorem identity31109 : scanCanonicalize (H12AffineFastState.compose env31109 (packedSelected [1,2,8] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound31109 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env31110 : List Nat := [2,4,8,16,1,17,8,256,512,273,1,276,8,260,260,263,277,261,272,261,1,261,277,262,8,17,1,17,277,260,272,1,257,0,261,512]

theorem envBound31110 : H12AffineFastState.Bounded env31110 := by
  intro p hp
  have h : env31110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31109_31110 : H12AffineEnvironment.transform 9 273 env31109 = env31110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env31109 == env31110) = true)

theorem identity31110 : scanCanonicalize (H12AffineFastState.compose env31110 (packedSelected [2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound31110 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env31111 : List Nat := [2,4,8,16,1,17,8,5,512,20,1,17,8,1,1,2,16,0,21,0,1,0,16,3,8,17,1,17,16,1,21,1,4,0,0,512]

theorem envBound31111 : H12AffineFastState.Bounded env31111 := by
  intro p hp
  have h : env31111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31110_31111 : H12AffineEnvironment.transform 7 5 env31110 = env31111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env31110 == env31111) = true)

theorem identity31111 : scanCanonicalize (H12AffineFastState.compose env31111 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound31111 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31112 : List Nat := [2,4,8,16,1,17,8,5,17,20,1,17,8,1,1,2,16,0,21,0,1,0,16,3,8,17,1,17,16,1,21,1,4,0,0,17]

theorem envBound31112 : H12AffineFastState.Bounded env31112 := by
  intro p hp
  have h : env31112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31111_31112 : H12AffineEnvironment.transform 8 17 env31111 = env31112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env31111 == env31112) = true)

theorem identity31112 : scanCanonicalize (H12AffineFastState.compose env31112 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound31112 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31113 : List Nat := [2,4,8,4,1,5,8,5,5,0,1,5,8,1,1,2,4,0,1,0,1,0,4,3,8,5,1,5,4,1,1,1,4,0,0,5]

theorem envBound31113 : H12AffineFastState.Bounded env31113 := by
  intro p hp
  have h : env31113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31112_31113 : H12AffineEnvironment.transform 3 4 env31112 = env31113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env31112 == env31113) = true)

def env31114 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,140301,272392,144476,95496,8193,64,23809,139613,17664,262144,143640,400452,257,21792,16464,202310]

theorem envBound31114 : H12AffineFastState.Bounded env31114 := by
  intro p hp
  have h : env31114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31099_31114 : H12AffineEnvironment.transform 6 9 env31099 = env31114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31099 == env31114) = true)

theorem identity31114 : scanCanonicalize (H12AffineFastState.compose env31114 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 215091) := by decide +kernel

theorem selectedBound31114 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env31115 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,215091,1025,29788,140301,221243,144476,95496,8193,64,23809,139613,17664,215091,143640,87159,257,21792,16464,202310]

theorem envBound31115 : H12AffineFastState.Bounded env31115 := by
  intro p hp
  have h : env31115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31114_31115 : H12AffineEnvironment.transform 17 215091 env31114 = env31115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 215091 env31114 == env31115) = true)

theorem identity31115 : scanCanonicalize (H12AffineFastState.compose env31115 (packedSelected [0,3,4,7,10,17,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound31115 : packedSelected [0,3,4,7,10,17,22,24,26] rootPS < 2^1333 := by decide +kernel

def env31116 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90138,10281,1025,29788,82967,33,87110,95496,8193,64,23809,82247,17664,10281,86274,87159,257,21792,16464,30300]

theorem envBound31116 : H12AffineFastState.Bounded env31116 := by
  intro p hp
  have h : env31116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31115_31116 : H12AffineEnvironment.transform 16 90138 env31115 = env31116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env31115 == env31116) = true)

theorem identity31116 : scanCanonicalize (H12AffineFastState.compose env31116 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound31116 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31117 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,0,65536,70727,10281,1025,1,77898,33,73755,65877,8193,64,10588,79130,12637,10281,75103,73770,257,8573,13325,513]

theorem envBound31117 : H12AffineFastState.Bounded env31117 := by
  intro p hp
  have h : env31117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31116_31117 : H12AffineEnvironment.transform 13 13405 env31116 = env31117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env31116 == env31117) = true)

theorem identity31117 : scanCanonicalize (H12AffineFastState.compose env31117 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31117 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31118 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,0,65536,70679,10281,1025,1,77850,33,73755,65797,8193,16,10508,79130,12557,10281,75023,73770,257,8493,13325,513]

theorem envBound31118 : H12AffineFastState.Bounded env31118 := by
  intro p hp
  have h : env31118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31117_31118 : H12AffineEnvironment.transform 5 16 env31117 = env31118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31117 == env31118) = true)

def env31119 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,4194304,180361,98781,8328,64,4489556,185736,17665,262280,181573,4338884,257,21792,46212,254610]

theorem envBound31119 : H12AffineFastState.Bounded env31119 := by
  intro p hp
  have h : env31119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31072_31119 : H12AffineEnvironment.transform 22 180361 env31072 = env31119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180361 env31072 == env31119) = true)

def env31120 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272512,180361,98781,8328,64,43476,185736,17665,262280,181573,400452,257,21792,46212,254610]

theorem envBound31120 : H12AffineFastState.Bounded env31120 := by
  intro p hp
  have h : env31120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31119_31120 : H12AffineEnvironment.transform 21 272512 env31119 = env31120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env31119 == env31120) = true)

theorem identity31120 : scanCanonicalize (H12AffineFastState.compose env31120 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49304) := by decide +kernel

theorem selectedBound31120 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31121 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,4161,272512,17,98781,8328,64,43476,5392,17665,262280,1501,318684,257,21792,46212,74250]

theorem envBound31121 : H12AffineFastState.Bounded env31121 := by
  intro p hp
  have h : env31121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31120_31121 : H12AffineEnvironment.transform 16 49304 env31120 = env31121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env31120 == env31121) = true)

theorem identity31121 : scanCanonicalize (H12AffineFastState.compose env31121 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound31121 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env31122 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49304,262144,1025,32769,4161,272512,17,41430,8328,64,43476,5392,17665,262280,1501,318684,257,21792,46212,513]

theorem envBound31122 : H12AffineFastState.Bounded env31122 := by
  intro p hp
  have h : env31122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31121_31122 : H12AffineEnvironment.transform 15 8203 env31121 = env31122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env31121 == env31122) = true)

def env31123 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272513,180361,98781,8328,64,43477,185736,17665,262280,181573,400453,257,21792,46212,254610]

theorem envBound31123 : H12AffineFastState.Bounded env31123 := by
  intro p hp
  have h : env31123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31119_31123 : H12AffineEnvironment.transform 21 272513 env31119 = env31123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env31119 == env31123) = true)

def env31124 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272393,180225,98645,8192,64,43357,185600,17665,262144,181573,400453,257,21792,46092,254490]

theorem envBound31124 : H12AffineFastState.Bounded env31124 := by
  intro p hp
  have h : env31124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31123_31124 : H12AffineEnvironment.transform 6 8 env31123 = env31124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31123 == env31124) = true)

theorem identity31124 : scanCanonicalize (H12AffineFastState.compose env31124 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound31124 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env31125 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,36929,272393,32785,98645,8192,64,43357,38160,17665,262144,34133,285781,257,21792,46092,107018]

theorem envBound31125 : H12AffineFastState.Bounded env31125 := by
  intro p hp
  have h : env31125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31124_31125 : H12AffineEnvironment.transform 16 16400 env31124 = env31125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env31124 == env31125) = true)

theorem identity31125 : scanCanonicalize (H12AffineFastState.compose env31125 (packedSelected [0,1,4,7,19,22,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound31125 : packedSelected [0,1,4,7,19,22,28,31] rootPS < 2^1333 := by decide +kernel

def env31126 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,2421,1025,32769,36929,8572,32785,98645,8192,64,43357,38160,17665,2421,34133,21792,257,21792,46092,107018]

theorem envBound31126 : H12AffineFastState.Bounded env31126 := by
  intro p hp
  have h : env31126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31125_31126 : H12AffineEnvironment.transform 17 2421 env31125 = env31126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env31125 == env31126) = true)

theorem identity31126 : scanCanonicalize (H12AffineFastState.compose env31126 (packedSelected [3,10,16,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound31126 : packedSelected [3,10,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env31127 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,65536,16400,2421,1025,0,4160,8572,16,65876,8192,64,10588,5393,17665,2421,1364,21792,257,21792,13325,74251]

theorem envBound31127 : H12AffineFastState.Bounded env31127 := by
  intro p hp
  have h : env31127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31126_31127 : H12AffineEnvironment.transform 14 1 env31126 = env31127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env31126 == env31127) = true)

theorem identity31127 : scanCanonicalize (H12AffineFastState.compose env31127 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound31127 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31128 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,342,16400,2421,1025,0,4160,8572,16,2,8192,64,10588,5393,17665,2421,1364,21792,257,21792,13325,9053]

theorem envBound31128 : H12AffineFastState.Bounded env31128 := by
  intro p hp
  have h : env31128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31127_31128 : H12AffineEnvironment.transform 15 342 env31127 = env31128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env31127 == env31128) = true)

theorem identity31128 : scanCanonicalize (H12AffineFastState.compose env31128 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound31128 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env31129 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,1,342,5220,2421,1025,0,4160,8572,16,2,8192,64,10588,5393,4469,2421,1364,340,257,340,13325,9053]

theorem envBound31129 : H12AffineFastState.Bounded env31129 := by
  intro p hp
  have h : env31129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31128_31129 : H12AffineEnvironment.transform 13 5236 env31128 = env31129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env31128 == env31129) = true)

theorem identity31129 : scanCanonicalize (H12AffineFastState.compose env31129 (packedSelected [0,2,3,4,5,7,9,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound31129 : packedSelected [0,2,3,4,5,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env31130 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,4096,8192,5236,1,342,5220,81,1025,0,4160,8572,16,2,8192,64,8312,5393,4469,81,1364,340,257,340,13325,9053]

theorem envBound31130 : H12AffineFastState.Bounded env31130 := by
  intro p hp
  have h : env31130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31129_31130 : H12AffineEnvironment.transform 10 292 env31129 = env31130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env31129 == env31130) = true)

theorem identity31130 : scanCanonicalize (H12AffineFastState.compose env31130 (packedSelected [0,1,2,4,7,8,9,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound31130 : packedSelected [0,1,2,4,7,8,9,11,14] rootPS < 2^1333 := by decide +kernel

def env31131 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,309,8192,1345,1,342,1361,81,1025,0,373,8572,16,2,8192,64,8312,1060,64,81,1364,340,257,340,9528,9053]

theorem envBound31131 : H12AffineFastState.Bounded env31131 := by
  intro p hp
  have h : env31131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31130_31131 : H12AffineEnvironment.transform 11 309 env31130 = env31131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env31130 == env31131) = true)

theorem identity31131 : scanCanonicalize (H12AffineFastState.compose env31131 (packedSelected [5,7,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound31131 : packedSelected [5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env31132 : List Nat := [2,4,8,16,32,64,8,256,512,101,292,309,8192,292,1,342,308,81,100,0,373,8572,16,2,8192,64,8312,65,64,81,305,340,257,340,8541,9053]

theorem envBound31132 : H12AffineFastState.Bounded env31132 := by
  intro p hp
  have h : env31132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31131_31132 : H12AffineEnvironment.transform 9 101 env31131 = env31132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env31131 == env31132) = true)

theorem identity31132 : scanCanonicalize (H12AffineFastState.compose env31132 (packedSelected [2,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound31132 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env31133 : List Nat := [2,4,8,16,32,64,8,256,512,101,292,309,348,292,1,342,308,81,100,0,373,32,16,2,348,64,292,65,64,81,305,340,257,340,1,513]

theorem envBound31133 : H12AffineFastState.Bounded env31133 := by
  intro p hp
  have h : env31133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31132_31133 : H12AffineEnvironment.transform 12 348 env31132 = env31133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env31132 == env31133) = true)

theorem identity31133 : scanCanonicalize (H12AffineFastState.compose env31133 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound31133 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31134 : List Nat := [2,4,8,16,32,64,8,116,512,101,80,65,40,80,1,34,64,81,100,0,1,32,16,2,40,64,80,65,64,81,69,32,117,32,1,513]

theorem envBound31134 : H12AffineFastState.Bounded env31134 := by
  intro p hp
  have h : env31134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31133_31134 : H12AffineEnvironment.transform 7 116 env31133 = env31134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env31133 == env31134) = true)

theorem identity31134 : scanCanonicalize (H12AffineFastState.compose env31134 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound31134 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31135 : List Nat := [2,4,8,16,32,64,8,116,48,101,80,65,40,80,1,34,64,81,100,0,1,32,16,2,40,64,80,65,64,81,69,32,117,32,1,49]

theorem envBound31135 : H12AffineFastState.Bounded env31135 := by
  intro p hp
  have h : env31135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31134_31135 : H12AffineEnvironment.transform 8 48 env31134 = env31135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env31134 == env31135) = true)

theorem identity31135 : scanCanonicalize (H12AffineFastState.compose env31135 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound31135 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31136 : List Nat := [2,4,8,16,32,32,8,20,48,5,48,33,40,48,1,34,32,49,4,0,1,32,16,2,40,32,48,33,32,49,37,32,21,32,1,49]

theorem envBound31136 : H12AffineFastState.Bounded env31136 := by
  intro p hp
  have h : env31136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31135_31136 : H12AffineEnvironment.transform 5 32 env31135 = env31136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env31135 == env31136) = true)

theorem identity31136 : scanCanonicalize (H12AffineFastState.compose env31136 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound31136 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31137 : List Nat := [2,4,8,16,17,17,8,20,1,5,1,16,25,1,1,19,17,0,4,0,1,17,16,2,25,17,1,16,17,0,20,17,21,17,1,0]

theorem envBound31137 : H12AffineFastState.Bounded env31137 := by
  intro p hp
  have h : env31137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31136_31137 : H12AffineEnvironment.transform 4 17 env31136 = env31137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env31136 == env31137) = true)

def env31138 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272392,180224,98644,8193,64,43356,185601,17665,262145,181573,400453,257,21792,46093,254491]

theorem envBound31138 : H12AffineFastState.Bounded env31138 := by
  intro p hp
  have h : env31138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31123_31138 : H12AffineEnvironment.transform 6 9 env31123 = env31138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31123 == env31138) = true)

theorem identity31138 : scanCanonicalize (H12AffineFastState.compose env31138 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound31138 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env31139 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,77898,272392,73754,98644,8193,64,43356,79131,17665,262145,75103,392287,257,21792,46093,513]

theorem envBound31139 : H12AffineFastState.Bounded env31139 := by
  intro p hp
  have h : env31139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31138_31139 : H12AffineEnvironment.transform 16 122906 env31138 = env31139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env31138 == env31139) = true)

theorem identity31139 : scanCanonicalize (H12AffineFastState.compose env31139 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound31139 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env31140 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,67618,1025,32769,77898,73770,73754,98644,8193,64,43356,79131,17665,67619,75103,62589,257,21792,46093,513]

theorem envBound31140 : H12AffineFastState.Bounded env31140 := by
  intro p hp
  have h : env31140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31139_31140 : H12AffineEnvironment.transform 17 67618 env31139 = env31140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env31139 == env31140) = true)

theorem identity31140 : scanCanonicalize (H12AffineFastState.compose env31140 (packedSelected [0,3,7,10,11,16,18,19,23,24,32] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound31140 : packedSelected [0,3,7,10,11,16,18,19,23,24,32] rootPS < 2^1333 := by decide +kernel

def env31141 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29709,65536,70679,67618,1025,29708,77898,73770,73754,95577,8193,64,23889,79131,17665,67619,75103,112,257,21792,16384,513]

theorem envBound31141 : H12AffineFastState.Bounded env31141 := by
  intro p hp
  have h : env31141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31140_31141 : H12AffineEnvironment.transform 14 29709 env31140 = env31141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env31140 == env31141) = true)

theorem identity31141 : scanCanonicalize (H12AffineFastState.compose env31141 (packedSelected [4,9,14,16,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound31141 : packedSelected [4,9,14,16,18,23] rootPS < 2^1333 := by decide +kernel

def env31142 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,0,65536,70679,67618,1025,1,77898,73770,73754,65876,8193,64,10588,79131,12556,67619,75103,112,257,8493,13325,513]

theorem envBound31142 : H12AffineFastState.Bounded env31142 := by
  intro p hp
  have h : env31142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31141_31142 : H12AffineEnvironment.transform 13 13325 env31141 = env31142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env31141 == env31142) = true)

theorem identity31142 : scanCanonicalize (H12AffineFastState.compose env31142 (packedSelected [1,2,3,6,8,10,12,15,24] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound31142 : packedSelected [1,2,3,6,8,10,12,15,24] rootPS < 2^1333 := by decide +kernel

def env31143 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,0,65536,70679,67618,1025,1,69958,65830,65814,65876,269,64,2128,70679,4096,67619,66643,112,257,33,5377,513]

theorem envBound31143 : H12AffineFastState.Bounded env31143 := by
  intro p hp
  have h : env31143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31142_31143 : H12AffineEnvironment.transform 12 268 env31142 = env31143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env31142 == env31143) = true)

theorem identity31143 : scanCanonicalize (H12AffineFastState.compose env31143 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound31143 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31144 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,0,343,5440,2421,1025,1,4113,113,65,3,269,64,2128,5440,4096,2420,1284,112,257,33,5377,513]

theorem envBound31144 : H12AffineFastState.Bounded env31144 := by
  intro p hp
  have h : env31144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31143_31144 : H12AffineEnvironment.transform 15 343 env31143 = env31144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env31143 == env31144) = true)

theorem identity31144 : scanCanonicalize (H12AffineFastState.compose env31144 (packedSelected [0,3,7,8,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31144 : packedSelected [0,3,7,8,10] rootPS < 2^1333 := by decide +kernel

def env31145 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,0,262,5393,2340,1025,1,4113,32,16,3,269,17,2049,5393,4096,2341,1284,33,257,33,5377,513]

theorem envBound31145 : H12AffineFastState.Bounded env31145 := by
  intro p hp
  have h : env31145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31144_31145 : H12AffineEnvironment.transform 5 17 env31144 = env31145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31144 == env31145) = true)

theorem identity31145 : scanCanonicalize (H12AffineFastState.compose env31145 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound31145 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31146 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,268,4405,0,262,4389,2340,53,1,4113,32,16,3,269,17,2049,4389,4096,2341,304,33,257,33,4405,513]

theorem envBound31146 : H12AffineFastState.Bounded env31146 := by
  intro p hp
  have h : env31146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31145_31146 : H12AffineEnvironment.transform 9 52 env31145 = env31146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env31145 == env31146) = true)

theorem identity31146 : scanCanonicalize (H12AffineFastState.compose env31146 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound31146 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31147 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,4096,41,4112,0,35,4096,2049,53,1,4113,32,16,3,40,17,2049,4096,4096,2048,21,33,36,33,4112,513]

theorem envBound31147 : H12AffineFastState.Bounded env31147 := by
  intro p hp
  have h : env31147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31146_31147 : H12AffineEnvironment.transform 7 37 env31146 = env31147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env31146 == env31147) = true)

theorem identity31147 : scanCanonicalize (H12AffineFastState.compose env31147 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2577) := by decide +kernel

theorem selectedBound31147 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31148 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2577,41,2561,0,35,2577,2049,53,1,2560,32,16,3,40,17,2049,2577,2577,2048,21,33,36,33,2561,513]

theorem envBound31148 : H12AffineFastState.Bounded env31148 := by
  intro p hp
  have h : env31148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31147_31148 : H12AffineEnvironment.transform 11 2577 env31147 = env31148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2577 env31147 == env31148) = true)

theorem identity31148 : scanCanonicalize (H12AffineFastState.compose env31148 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 59) := by decide +kernel

theorem selectedBound31148 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31149 : List Nat := [2,4,8,16,32,17,9,37,512,52,59,554,41,570,0,35,554,58,53,1,571,32,16,3,40,17,58,554,554,59,21,33,36,33,570,513]

theorem envBound31149 : H12AffineFastState.Bounded env31149 := by
  intro p hp
  have h : env31149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31148_31149 : H12AffineEnvironment.transform 10 59 env31148 = env31149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 59 env31148 == env31149) = true)

theorem identity31149 : scanCanonicalize (H12AffineFastState.compose env31149 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound31149 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env31150 : List Nat := [2,4,8,16,26,17,9,31,512,14,1,528,19,512,0,25,528,0,15,1,513,26,16,3,18,17,0,528,528,1,21,27,30,27,512,513]

theorem envBound31150 : H12AffineFastState.Bounded env31150 := by
  intro p hp
  have h : env31150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31149_31150 : H12AffineEnvironment.transform 4 26 env31149 = env31150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env31149 == env31150) = true)

theorem identity31150 : scanCanonicalize (H12AffineFastState.compose env31150 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound31150 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env31151 : List Nat := [2,4,8,16,26,17,9,31,1,14,1,17,19,1,0,25,17,0,15,1,0,26,16,3,18,17,0,17,17,1,21,27,30,27,1,0]

theorem envBound31151 : H12AffineFastState.Bounded env31151 := by
  intro p hp
  have h : env31151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31150_31151 : H12AffineEnvironment.transform 8 1 env31150 = env31151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env31150 == env31151) = true)

def env31152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507600,155254785,25265168,145662401,525568,140903597,27337993,25733063]

theorem envBound31152 : H12AffineFastState.Bounded env31152 := by
  intro p hp
  have h : env31152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30476_31152 : H12AffineEnvironment.transform 25 65 env30476 = env31152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env30476 == env31152) = true)

def env31153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507600,9356289,25265168,23160257,525568,27902125,27337993,25733063]

theorem envBound31153 : H12AffineFastState.Bounded env31153 := by
  intro p hp
  have h : env31153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31152_31153 : H12AffineEnvironment.transform 26 30393344 env31152 = env31153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env31152 == env31153) = true)

def env31154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830977,25265168,23160257,256,27378861,27337993,25207751]

theorem envBound31154 : H12AffineFastState.Bounded env31154 := by
  intro p hp
  have h : env31154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31153_31154 : H12AffineEnvironment.transform 18 1024 env31153 = env31154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env31153 == env31154) = true)

theorem identity31154 : scanCanonicalize (H12AffineFastState.compose env31154 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2493492) := by decide +kernel

theorem selectedBound31154 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env31155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2493492,16777216,8328,65,23186484,18973837,416100,2149429,19367972,23160257,256,17287321,17246525,19312627]

theorem envBound31155 : H12AffineFastState.Bounded env31155 := by
  intro p hp
  have h : env31155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31154_31155 : H12AffineEnvironment.transform 22 2493492 env31154 = env31155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2493492 env31154 == env31155) = true)

def env31156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2493492,499128,8328,65,6705548,2496821,416100,2149429,2102684,6748281,256,21793,46213,2175563]

theorem envBound31156 : H12AffineFastState.Bounded env31156 := by
  intro p hp
  have h : env31156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31155_31156 : H12AffineEnvironment.transform 23 499128 env31155 = env31156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 499128 env31155 == env31156) = true)

def env31157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180272,2493492,499128,8328,65,2396604,2496821,416100,2149429,2102684,2373705,256,21793,46213,2175563]

theorem envBound31157 : H12AffineFastState.Bounded env31157 := by
  intro p hp
  have h : env31157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31156_31157 : H12AffineEnvironment.transform 21 180272 env31156 = env31157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180272 env31156 == env31157) = true)

def env31158 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180272,400500,499128,8328,65,295420,395637,416100,56437,1500,272393,256,21793,46213,74251]

theorem envBound31158 : H12AffineFastState.Bounded env31158 := by
  intro p hp
  have h : env31158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31157_31158 : H12AffineEnvironment.transform 20 4160 env31157 = env31158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env31157 == env31158) = true)

theorem identity31158 : scanCanonicalize (H12AffineFastState.compose env31158 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190641) := by decide +kernel

theorem selectedBound31158 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31159 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4160,180272,62661,95497,8328,65,158029,57796,45525,56437,1500,180408,256,21793,46213,74251]

theorem envBound31159 : H12AffineFastState.Bounded env31159 := by
  intro p hp
  have h : env31159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31158_31159 : H12AffineEnvironment.transform 17 190641 env31158 = env31159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190641 env31158 == env31159) = true)

theorem identity31159 : scanCanonicalize (H12AffineFastState.compose env31159 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound31159 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env31160 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190641,1024,32769,4160,180272,62661,21763,8328,65,158029,57796,45525,56437,1500,180408,256,21793,46213,513]

theorem envBound31160 : H12AffineFastState.Bounded env31160 := by
  intro p hp
  have h : env31160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31159_31160 : H12AffineEnvironment.transform 15 8202 env31159 = env31160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env31159 == env31160) = true)

theorem identity31160 : scanCanonicalize (H12AffineFastState.compose env31160 (packedSelected [11,12,15,16,18,20,23,32,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound31160 : packedSelected [11,12,15,16,18,20,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env31161 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190521,1024,32769,4160,180272,62541,21763,8192,65,158029,57676,45405,56437,1364,180272,256,21793,46093,513]

theorem envBound31161 : H12AffineFastState.Bounded env31161 := by
  intro p hp
  have h : env31161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31160_31161 : H12AffineEnvironment.transform 6 8 env31160 = env31161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31160 == env31161) = true)

theorem identity31161 : scanCanonicalize (H12AffineFastState.compose env31161 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound31161 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env31162 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,43048,1024,32769,4160,32801,62541,21763,8192,65,10588,57676,45405,56437,1364,32801,256,21793,46093,513]

theorem envBound31162 : H12AffineFastState.Bounded env31162 := by
  intro p hp
  have h : env31162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31161_31162 : H12AffineEnvironment.transform 16 16401 env31161 = env31162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env31161 == env31162) = true)

theorem identity31162 : scanCanonicalize (H12AffineFastState.compose env31162 (packedSelected [0,4,7,9,14,17,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound31162 : packedSelected [0,4,7,9,14,17,18,23] rootPS < 2^1333 := by decide +kernel

def env31163 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,9293,8202,16401,3173,1024,9292,4160,9324,20480,21763,8192,65,10588,17665,5392,30776,1364,9324,256,21793,4160,513]

theorem envBound31163 : H12AffineFastState.Bounded env31163 := by
  intro p hp
  have h : env31163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31162_31163 : H12AffineEnvironment.transform 14 9293 env31162 = env31163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env31162 == env31163) = true)

theorem identity31163 : scanCanonicalize (H12AffineFastState.compose env31163 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound31163 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31164 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,9293,8202,13389,3173,1024,9292,4160,9324,9308,8543,8192,65,10588,12637,5392,3172,1364,9324,256,8573,4160,513]

theorem envBound31164 : H12AffineFastState.Bounded env31164 := by
  intro p hp
  have h : env31164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31163_31164 : H12AffineEnvironment.transform 13 13404 env31163 = env31164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env31163 == env31164) = true)

theorem identity31164 : scanCanonicalize (H12AffineFastState.compose env31164 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound31164 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31165 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,12620,8541,8202,12637,2421,272,8540,4160,8572,8524,8543,8192,65,10588,12637,4096,2420,68,8572,256,8573,4160,513]

theorem envBound31165 : H12AffineFastState.Bounded env31165 := by
  intro p hp
  have h : env31165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31164_31165 : H12AffineEnvironment.transform 9 272 env31164 = env31165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env31164 == env31165) = true)

theorem identity31165 : scanCanonicalize (H12AffineFastState.compose env31165 (packedSelected [0,4,6,7,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 6429) := by decide +kernel

theorem selectedBound31165 : packedSelected [0,4,6,7,9,11] rootPS < 2^1333 := by decide +kernel

def env31166 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,6429,2129,6208,6423,2112,2421,272,6209,4160,6241,6225,6210,6429,65,4161,2112,4096,2420,68,6241,256,6240,4160,513]

theorem envBound31166 : H12AffineFastState.Bounded env31166 := by
  intro p hp
  have h : env31166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31165_31166 : H12AffineEnvironment.transform 12 6429 env31165 = env31166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6429 env31165 == env31166) = true)

theorem identity31166 : scanCanonicalize (H12AffineFastState.compose env31166 (packedSelected [0,1,3,5,6,7,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound31166 : packedSelected [0,1,3,5,6,7,8,12] rootPS < 2^1333 := by decide +kernel

def env31167 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2405,120,2129,293,114,2112,2421,272,292,2341,260,308,295,120,65,2340,2112,2405,2420,68,260,256,261,2341,513]

theorem envBound31167 : H12AffineFastState.Bounded env31167 := by
  intro p hp
  have h : env31167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31166_31167 : H12AffineEnvironment.transform 11 2405 env31166 = env31167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env31166 == env31167) = true)

theorem identity31167 : scanCanonicalize (H12AffineFastState.compose env31167 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound31167 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env31168 : List Nat := [2,4,8,16,32,64,8,37,512,53,2048,2112,120,2129,0,114,2112,2128,53,1,2048,33,17,2,120,65,2049,2112,2112,2129,68,33,37,32,2048,513]

theorem envBound31168 : H12AffineFastState.Bounded env31168 := by
  intro p hp
  have h : env31168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31167_31168 : H12AffineEnvironment.transform 7 37 env31167 = env31168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env31167 == env31168) = true)

theorem identity31168 : scanCanonicalize (H12AffineFastState.compose env31168 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31168 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31169 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,2064,40,2049,0,34,2064,2048,53,1,2048,33,17,2,40,17,2049,2064,2064,2049,20,33,37,32,2048,513]

theorem envBound31169 : H12AffineFastState.Bounded env31169 := by
  intro p hp
  have h : env31169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31168_31169 : H12AffineEnvironment.transform 5 16 env31168 = env31169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31168 == env31169) = true)

theorem identity31169 : scanCanonicalize (H12AffineFastState.compose env31169 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound31169 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31170 : List Nat := [2,4,8,16,32,16,8,37,512,53,528,512,40,529,0,34,512,528,53,1,528,33,17,2,40,17,529,512,512,529,20,33,37,32,528,513]

theorem envBound31170 : H12AffineFastState.Bounded env31170 := by
  intro p hp
  have h : env31170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31169_31170 : H12AffineEnvironment.transform 10 528 env31169 = env31170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env31169 == env31170) = true)

theorem identity31170 : scanCanonicalize (H12AffineFastState.compose env31170 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound31170 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31171 : List Nat := [2,4,8,16,32,16,8,37,26,53,10,26,40,11,0,34,26,10,53,1,10,33,17,2,40,17,11,26,26,11,20,33,37,32,10,27]

theorem envBound31171 : H12AffineFastState.Bounded env31171 := by
  intro p hp
  have h : env31171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31170_31171 : H12AffineEnvironment.transform 8 26 env31170 = env31171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env31170 == env31171) = true)

def env31172 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180272,400501,499128,8328,65,295421,395636,416100,56436,1501,272392,256,21793,46213,74250]

theorem envBound31172 : H12AffineFastState.Bounded env31172 := by
  intro p hp
  have h : env31172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31157_31172 : H12AffineEnvironment.transform 20 4161 env31157 = env31172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env31157 == env31172) = true)

def env31173 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,180272,144477,243088,8328,65,43477,139612,160076,56436,1501,32,256,21793,46213,74250]

theorem envBound31173 : H12AffineFastState.Bounded env31173 := by
  intro p hp
  have h : env31173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31172_31173 : H12AffineEnvironment.transform 17 10280 env31172 = env31173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env31172 == env31173) = true)

def env31174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1024,32769,4161,21792,41293,73856,8328,65,43477,46156,58460,56436,1501,32,256,21793,46213,74250]

theorem envBound31174 : H12AffineFastState.Bounded env31174 := by
  intro p hp
  have h : env31174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31173_31174 : H12AffineEnvironment.transform 16 38160 env31173 = env31174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env31173 == env31174) = true)

theorem identity31174 : scanCanonicalize (H12AffineFastState.compose env31174 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound31174 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,38160,10280,1024,32769,4161,21792,41293,41310,8328,65,43477,46156,58460,56436,1501,32,256,21793,46213,41940]

theorem envBound31175 : H12AffineFastState.Bounded env31175 := by
  intro p hp
  have h : env31175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31174_31175 : H12AffineEnvironment.transform 15 33246 env31174 = env31175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env31174 == env31175) = true)

theorem identity31175 : scanCanonicalize (H12AffineFastState.compose env31175 (packedSelected [0,3,4,5,7,8,16,20,22,28] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound31175 : packedSelected [0,3,4,5,7,8,16,20,22,28] rootPS < 2^1333 := by decide +kernel

def env31176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,32768,33246,38160,2420,1024,32769,4161,21792,32785,32770,468,65,34953,38160,50432,56436,1501,32,256,21793,38361,33416]

theorem envBound31176 : H12AffineFastState.Bounded env31176 := by
  intro p hp
  have h : env31176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31175_31176 : H12AffineEnvironment.transform 12 348 env31175 = env31176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env31175 == env31176) = true)

theorem identity31176 : scanCanonicalize (H12AffineFastState.compose env31176 (packedSelected [0,1,4,7,8,16,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound31176 : packedSelected [0,1,4,7,8,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env31177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,4112,32768,33246,38160,2420,1024,32769,4161,1328,32785,32770,468,65,34953,38160,38160,35940,1501,32,256,1329,38361,33416]

theorem envBound31177 : H12AffineFastState.Bounded env31177 := by
  intro p hp
  have h : env31177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31176_31177 : H12AffineEnvironment.transform 13 4112 env31176 = env31177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env31176 == env31177) = true)

theorem identity31177 : scanCanonicalize (H12AffineFastState.compose env31177 (packedSelected [0,2,6,7,16,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 1345) := by decide +kernel

theorem selectedBound31177 : packedSelected [0,2,6,7,16,18,23] rootPS < 2^1333 := by decide +kernel

def env31178 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,4112,1345,1183,4177,2420,1024,1344,4161,1328,1360,1347,468,65,3528,4177,4177,2341,1501,32,256,1329,4248,1993]

theorem envBound31178 : H12AffineFastState.Bounded env31178 := by
  intro p hp
  have h : env31178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31177_31178 : H12AffineEnvironment.transform 14 1345 env31177 = env31178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1345 env31177 == env31178) = true)

theorem identity31178 : scanCanonicalize (H12AffineFastState.compose env31178 (packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound31178 : packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env31179 : List Nat := [2,4,8,16,32,64,128,256,512,189,2048,4096,348,4112,508,34,4177,2420,189,509,4161,397,493,510,468,65,2421,4177,4177,2341,352,32,256,396,4248,884]

theorem envBound31179 : H12AffineFastState.Bounded env31179 := by
  intro p hp
  have h : env31179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31178_31179 : H12AffineEnvironment.transform 9 189 env31178 = env31179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env31178 == env31179) = true)

theorem identity31179 : scanCanonicalize (H12AffineFastState.compose env31179 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31179 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env31180 : List Nat := [2,4,8,16,32,16,128,256,512,189,2048,4096,268,4112,428,34,4097,2340,189,429,4113,397,445,430,388,17,2341,4097,4097,2341,304,32,256,396,4248,804]

theorem envBound31180 : H12AffineFastState.Bounded env31180 := by
  intro p hp
  have h : env31180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31179_31180 : H12AffineEnvironment.transform 5 16 env31179 = env31180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31179 == env31180) = true)

theorem identity31180 : scanCanonicalize (H12AffineFastState.compose env31180 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound31180 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env31181 : List Nat := [2,4,8,16,32,16,128,36,512,189,2048,4096,40,4112,136,34,4097,2048,189,137,4113,169,153,138,160,17,2049,4097,4097,2049,20,32,36,168,4248,512]

theorem envBound31181 : H12AffineFastState.Bounded env31181 := by
  intro p hp
  have h : env31181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31180_31181 : H12AffineEnvironment.transform 7 36 env31180 = env31181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env31180 == env31181) = true)

theorem identity31181 : scanCanonicalize (H12AffineFastState.compose env31181 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31181 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31182 : List Nat := [2,4,8,16,1,16,128,5,512,156,2048,4096,9,4112,136,3,4097,2048,156,137,4113,136,153,138,129,17,2049,4097,4097,2049,20,1,5,137,4248,512]

theorem envBound31182 : H12AffineFastState.Bounded env31182 := by
  intro p hp
  have h : env31182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31181_31182 : H12AffineEnvironment.transform 4 1 env31181 = env31182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31181 == env31182) = true)

theorem identity31182 : scanCanonicalize (H12AffineFastState.compose env31182 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 2710) := by decide +kernel

theorem selectedBound31182 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env31183 : List Nat := [2,4,8,16,1,16,128,5,512,156,2048,2710,9,2694,136,3,2711,2048,156,137,2695,136,153,138,129,17,2049,2711,2711,2049,20,1,5,137,2574,512]

theorem envBound31183 : H12AffineFastState.Bounded env31183 := by
  intro p hp
  have h : env31183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31182_31183 : H12AffineEnvironment.transform 11 2710 env31182 = env31183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2710 env31182 == env31183) = true)

def env31184 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1024,32769,4161,21793,41292,73857,8328,65,43477,46157,58461,56436,1501,32,256,21793,46213,74250]

theorem envBound31184 : H12AffineFastState.Bounded env31184 := by
  intro p hp
  have h : env31184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31173_31184 : H12AffineEnvironment.transform 16 38161 env31173 = env31184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env31173 == env31184) = true)

theorem identity31184 : scanCanonicalize (H12AffineFastState.compose env31184 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound31184 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31185 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33110,38161,10280,1024,32769,4161,21793,41292,41431,8328,65,43477,46157,58461,56436,1501,32,256,21793,46213,41820]

theorem envBound31185 : H12AffineFastState.Bounded env31185 := by
  intro p hp
  have h : env31185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31184_31185 : H12AffineEnvironment.transform 15 33110 env31184 = env31185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env31184 == env31185) = true)

theorem identity31185 : scanCanonicalize (H12AffineFastState.compose env31185 (packedSelected [0,2,3,4,6,9,10,11,18,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 8352) := by decide +kernel

theorem selectedBound31185 : packedSelected [0,2,3,4,6,9,10,11,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env31186 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,8694,13745,10280,1024,8353,4161,21793,492,375,8328,65,2421,5357,17661,31956,1501,32,256,21793,5157,1020]

theorem envBound31186 : H12AffineFastState.Bounded env31186 := by
  intro p hp
  have h : env31186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31185_31186 : H12AffineEnvironment.transform 14 8352 env31185 = env31186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env31185 == env31186) = true)

theorem identity31186 : scanCanonicalize (H12AffineFastState.compose env31186 (packedSelected [0,1,3,5,7,8,9,10,12,14,15,18,20,22,23,26] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound31186 : packedSelected [0,1,3,5,7,8,9,10,12,14,15,18,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env31187 : List Nat := [2,4,8,16,32,64,128,256,512,101,2048,4096,8192,16384,8352,8694,12756,10280,101,8353,4161,20804,492,375,8328,65,2421,4232,16536,30897,440,32,256,20804,4160,1020]

theorem envBound31187 : H12AffineFastState.Bounded env31187 := by
  intro p hp
  have h : env31187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31186_31187 : H12AffineEnvironment.transform 9 101 env31186 = env31187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env31186 == env31187) = true)

theorem identity31187 : scanCanonicalize (H12AffineFastState.compose env31187 (packedSelected [1,2,3,6,8,9,10,12,14,15,16,18,20,22,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 12393) := by decide +kernel

theorem selectedBound31187 : packedSelected [1,2,3,6,8,9,10,12,14,15,16,18,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env31188 : List Nat := [2,4,8,16,32,64,128,256,512,101,2048,4096,8192,12393,8352,8694,12756,10280,101,8353,4161,8493,492,375,8328,65,2421,4232,12529,2264,440,32,256,8493,4160,1020]

theorem envBound31188 : H12AffineFastState.Bounded env31188 := by
  intro p hp
  have h : env31188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31187_31188 : H12AffineEnvironment.transform 13 12393 env31187 = env31188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12393 env31187 == env31188) = true)

theorem identity31188 : scanCanonicalize (H12AffineFastState.compose env31188 (packedSelected [11,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31188 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env31189 : List Nat := [2,4,8,16,32,16,128,256,512,53,2048,4096,8192,12345,8352,8614,12676,10280,53,8353,4113,8493,444,295,8328,17,2341,4232,12449,2184,440,32,256,8493,4112,940]

theorem envBound31189 : H12AffineFastState.Bounded env31189 := by
  intro p hp
  have h : env31189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31188_31189 : H12AffineEnvironment.transform 5 16 env31188 = env31189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31188 == env31189) = true)

def env31190 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,180272,144476,243089,8328,65,43476,139613,160077,56436,1501,33,256,21793,46213,74250]

theorem envBound31190 : H12AffineFastState.Bounded env31190 := by
  intro p hp
  have h : env31190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31172_31190 : H12AffineEnvironment.transform 17 10281 env31172 = env31190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env31172 == env31190) = true)

def env31191 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1024,32769,4161,21792,41292,73857,8328,65,43476,46157,58461,56436,1501,33,256,21793,46213,74250]

theorem envBound31191 : H12AffineFastState.Bounded env31191 := by
  intro p hp
  have h : env31191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31190_31191 : H12AffineEnvironment.transform 16 38160 env31190 = env31191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env31190 == env31191) = true)

theorem identity31191 : scanCanonicalize (H12AffineFastState.compose env31191 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound31191 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31192 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38160,10281,1024,32769,4161,21792,41292,138,8328,65,43476,46157,58461,56436,1501,33,256,21793,46213,513]

theorem envBound31192 : H12AffineFastState.Bounded env31192 := by
  intro p hp
  have h : env31192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31191_31192 : H12AffineEnvironment.transform 15 8203 env31191 = env31192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env31191 == env31192) = true)

theorem identity31192 : scanCanonicalize (H12AffineFastState.compose env31192 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound31192 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env31193 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,8203,38160,10281,1024,32769,4161,169,41292,138,8328,65,43476,46157,45524,35325,1501,33,256,168,46213,513]

theorem envBound31193 : H12AffineFastState.Bounded env31193 := by
  intro p hp
  have h : env31193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31192_31193 : H12AffineEnvironment.transform 13 5513 env31192 = env31193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env31192 == env31193) = true)

theorem identity31193 : scanCanonicalize (H12AffineFastState.compose env31193 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound31193 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env31194 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,5513,32768,34,38160,2048,1024,32769,4161,169,33125,138,161,65,35325,37988,37373,35325,1501,33,256,168,38060,513]

theorem envBound31194 : H12AffineFastState.Bounded env31194 := by
  intro p hp
  have h : env31194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31193_31194 : H12AffineEnvironment.transform 12 41 env31193 = env31194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env31193 == env31194) = true)

theorem identity31194 : scanCanonicalize (H12AffineFastState.compose env31194 (packedSelected [3,4,5,9,10,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound31194 : packedSelected [3,4,5,9,10,14,16] rootPS < 2^1333 := by decide +kernel

def env31195 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,5513,373,34,5221,2048,1024,372,4161,169,16,138,161,65,2184,5393,4232,2184,1501,33,256,168,5593,513]

theorem envBound31195 : H12AffineFastState.Bounded env31195 := by
  intro p hp
  have h : env31195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31194_31195 : H12AffineEnvironment.transform 14 373 env31194 = env31195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env31194 == env31195) = true)

theorem identity31195 : scanCanonicalize (H12AffineFastState.compose env31195 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound31195 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env31196 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5377,373,34,5221,2048,1024,372,4161,33,16,2,41,65,2048,5393,4096,2048,1365,33,256,32,5457,513]

theorem envBound31196 : H12AffineFastState.Bounded env31196 := by
  intro p hp
  have h : env31196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31195_31196 : H12AffineEnvironment.transform 6 8 env31195 = env31196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31195 == env31196) = true)

theorem identity31196 : scanCanonicalize (H12AffineFastState.compose env31196 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound31196 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env31197 : List Nat := [2,4,8,16,32,64,8,256,512,1024,373,4096,41,5377,373,34,5221,373,1024,372,4161,33,16,2,41,65,373,5393,4096,373,1365,33,256,32,5457,513]

theorem envBound31197 : H12AffineFastState.Bounded env31197 := by
  intro p hp
  have h : env31197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31196_31197 : H12AffineEnvironment.transform 10 373 env31196 = env31197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env31196 == env31197) = true)

theorem identity31197 : scanCanonicalize (H12AffineFastState.compose env31197 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound31197 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env31198 : List Nat := [2,4,8,16,32,64,8,256,512,1024,373,1061,41,292,373,34,64,373,1024,372,1124,33,16,2,41,65,373,308,1061,373,1365,33,256,32,372,513]

theorem envBound31198 : H12AffineFastState.Bounded env31198 := by
  intro p hp
  have h : env31198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31197_31198 : H12AffineEnvironment.transform 11 1061 env31197 = env31198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env31197 == env31198) = true)

theorem identity31198 : scanCanonicalize (H12AffineFastState.compose env31198 (packedSelected [2,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound31198 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env31199 : List Nat := [2,4,8,16,32,64,8,256,512,272,373,309,41,292,373,34,64,373,272,372,372,33,16,2,41,65,373,308,309,373,69,33,256,32,372,513]

theorem envBound31199 : H12AffineFastState.Bounded env31199 := by
  intro p hp
  have h : env31199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31198_31199 : H12AffineEnvironment.transform 9 272 env31198 = env31199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env31198 == env31199) = true)

def env31200 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1024,32769,4161,21793,41293,73856,8328,65,43476,46156,58460,56436,1501,33,256,21793,46213,74250]

theorem envBound31200 : H12AffineFastState.Bounded env31200 := by
  intro p hp
  have h : env31200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31190_31200 : H12AffineEnvironment.transform 16 38161 env31190 = env31200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env31190 == env31200) = true)

theorem identity31200 : scanCanonicalize (H12AffineFastState.compose env31200 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound31200 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31201 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,38161,10281,1024,32769,4161,21793,41293,2,8328,65,43476,46156,58460,56436,1501,33,256,21793,46213,648]

theorem envBound31201 : H12AffineFastState.Bounded env31201 := by
  intro p hp
  have h : env31201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31200_31201 : H12AffineEnvironment.transform 15 8322 env31200 = env31201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env31200 == env31201) = true)

theorem identity31201 : scanCanonicalize (H12AffineFastState.compose env31201 (packedSelected [1,3,5,8,9,10,19,20,22,23] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound31201 : packedSelected [1,3,5,8,9,10,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env31202 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,8282,38161,10281,1024,32769,4161,21793,41293,2,8272,65,43276,46156,58460,56436,1285,33,256,21793,46173,592]

theorem envBound31202 : H12AffineFastState.Bounded env31202 := by
  intro p hp
  have h : env31202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31201_31202 : H12AffineEnvironment.transform 6 88 env31201 = env31202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env31201 == env31202) = true)

theorem identity31202 : scanCanonicalize (H12AffineFastState.compose env31202 (packedSelected [1,3,5,8,11,12,18] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound31202 : packedSelected [1,3,5,8,11,12,18] rootPS < 2^1333 := by decide +kernel

def env31203 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,21840,8282,16449,10281,1024,21841,4161,21793,29725,2,8272,65,31836,24860,12556,2340,1285,33,256,21793,24845,592]

theorem envBound31203 : H12AffineFastState.Bounded env31203 := by
  intro p hp
  have h : env31203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31202_31203 : H12AffineEnvironment.transform 14 21840 env31202 = env31203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env31202 == env31203) = true)

theorem identity31203 : scanCanonicalize (H12AffineFastState.compose env31203 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound31203 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env31204 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,268,16384,21840,342,16449,2341,1024,21841,4161,21793,21777,2,348,65,23888,16400,4096,2340,1285,33,256,21793,16385,592]

theorem envBound31204 : H12AffineFastState.Bounded env31204 := by
  intro p hp
  have h : env31204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31203_31204 : H12AffineEnvironment.transform 12 268 env31203 = env31204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env31203 == env31204) = true)

theorem identity31204 : scanCanonicalize (H12AffineFastState.compose env31204 (packedSelected [1,3,5,8,15] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

end H12CloudChart0