import H12CloudChart0Data128

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound32740 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env32741 : List Nat := [2,4,8,16,32,16,9,256,512,565,820,292,268,529,0,262,512,528,565,1,309,33,16,3,269,17,821,512,292,529,816,32,256,33,528,513]

theorem envBound32741 : H12AffineFastState.Bounded env32741 := by
  intro p hp
  have h : env32741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32740_32741 : H12AffineEnvironment.transform 10 820 env32740 = env32741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 820 env32740 == env32741) = true)

def env32742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180273,510122,16777216,8328,65,16959643,18973836,2596347,67754,17190074,19113457,256,19270662,19328419,17263469]

theorem envBound32742 : H12AffineFastState.Bounded env32742 := by
  intro p hp
  have h : env32742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32657_32742 : H12AffineEnvironment.transform 21 180273 env32657 = env32742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180273 env32657 == env32742) = true)

def env32743 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180273,510122,499128,8328,65,349475,2496820,2596347,67754,119042,2373705,256,2199998,2191387,63189]

theorem envBound32743 : H12AffineFastState.Bounded env32743 := by
  intro p hp
  have h : env32743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32742_32743 : H12AffineEnvironment.transform 23 499128 env32742 = env32743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 499128 env32742 == env32743) = true)

def env32744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180273,510122,499128,8328,65,349475,395636,495035,67754,119042,272393,256,98814,90203,63189]

theorem envBound32744 : H12AffineFastState.Bounded env32744 := by
  intro p hp
  have h : env32744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32743_32744 : H12AffineEnvironment.transform 20 4160 env32743 = env32744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env32743 == env32744) = true)

def env32745 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1024,32769,4160,180273,253962,242968,8328,65,97667,139732,238875,67754,119042,169,256,98814,90203,63189]

theorem envBound32745 : H12AffineFastState.Bounded env32745 := by
  intro p hp
  have h : env32745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32744_32745 : H12AffineEnvironment.transform 17 10400 env32744 = env32745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env32744 == env32745) = true)

def env32746 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,180273,253962,242968,8192,65,97547,139612,238875,67618,119042,33,256,98678,90203,63069]

theorem envBound32746 : H12AffineFastState.Bounded env32746 := by
  intro p hp
  have h : env32746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32745_32746 : H12AffineEnvironment.transform 6 8 env32745 = env32746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32745 == env32746) = true)

theorem identity32746 : scanCanonicalize (H12AffineFastState.compose env32746 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound32746 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32747 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10280,1024,32769,4160,98679,41292,62558,8192,65,97547,90138,58461,67618,119042,33,256,98678,90203,63069]

theorem envBound32747 : H12AffineFastState.Bounded env32747 := by
  intro p hp
  have h : env32747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32746_32747 : H12AffineEnvironment.transform 16 82246 env32746 = env32747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env32746 == env32747) = true)

theorem identity32747 : scanCanonicalize (H12AffineFastState.compose env32747 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound32747 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env32748 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,82246,2421,1024,32769,4160,98679,32785,54531,349,65,89174,82247,50432,67618,119042,33,256,98678,82182,55040]

theorem envBound32748 : H12AffineFastState.Bounded env32748 := by
  intro p hp
  have h : env32748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32747_32748 : H12AffineEnvironment.transform 12 349 env32747 = env32748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env32747 == env32748) = true)

theorem identity32748 : scanCanonicalize (H12AffineFastState.compose env32748 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound32748 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env32749 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,32768,65536,70727,2421,1024,32769,4160,98679,32785,32770,349,65,67927,70726,36865,67618,99331,33,256,98678,70663,33281]

theorem envBound32749 : H12AffineFastState.Bounded env32749 := by
  intro p hp
  have h : env32749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32748_32749 : H12AffineEnvironment.transform 13 5377 env32748 = env32749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env32748 == env32749) = true)

theorem identity32749 : scanCanonicalize (H12AffineFastState.compose env32749 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound32749 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32750 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1,65536,70727,2421,1024,0,4160,65910,16,3,349,65,67927,70726,4096,67618,66562,33,256,65911,70663,512]

theorem envBound32750 : H12AffineFastState.Bounded env32750 := by
  intro p hp
  have h : env32750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32749_32750 : H12AffineEnvironment.transform 14 1 env32749 = env32750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env32749 == env32750) = true)

theorem identity32750 : scanCanonicalize (H12AffineFastState.compose env32750 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32750 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env32751 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5377,1,65536,70679,2341,1024,0,4112,65830,16,3,269,17,67847,70678,4096,67618,66562,33,256,65831,70663,512]

theorem envBound32751 : H12AffineFastState.Bounded env32751 := by
  intro p hp
  have h : env32751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32750_32751 : H12AffineEnvironment.transform 5 16 env32750 = env32751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32750 == env32751) = true)

theorem identity32751 : scanCanonicalize (H12AffineFastState.compose env32751 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32751 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32752 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,4096,269,5377,1,65536,70679,2309,1024,0,4112,65798,16,3,269,17,67847,70678,4096,67586,66562,1,256,65799,70663,512]

theorem envBound32752 : H12AffineFastState.Bounded env32752 := by
  intro p hp
  have h : env32752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32751_32752 : H12AffineEnvironment.transform 4 0 env32751 = env32752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32751 == env32752) = true)

theorem identity32752 : scanCanonicalize (H12AffineFastState.compose env32752 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound32752 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env32753 : List Nat := [2,4,8,16,0,16,8,20,512,1024,2048,4096,25,5141,1,65536,70679,2065,1024,0,4112,65554,16,3,25,17,67603,70678,4096,67586,66562,1,20,65555,70663,512]

theorem envBound32753 : H12AffineFastState.Bounded env32753 := by
  intro p hp
  have h : env32753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32752_32753 : H12AffineEnvironment.transform 7 20 env32752 = env32753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env32752 == env32753) = true)

def env32754 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,180273,253962,242968,8193,65,97546,139613,238875,67619,119042,32,256,98679,90203,63068]

theorem envBound32754 : H12AffineFastState.Bounded env32754 := by
  intro p hp
  have h : env32754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32745_32754 : H12AffineEnvironment.transform 6 9 env32745 = env32754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32745 == env32754) = true)

theorem identity32754 : scanCanonicalize (H12AffineFastState.compose env32754 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound32754 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32755 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10281,1024,32769,4160,73770,17,21763,8193,65,97546,115014,17664,67619,119042,32,256,98679,90203,63068]

theorem envBound32755 : H12AffineFastState.Bounded env32755 := by
  intro p hp
  have h : env32755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32754_32755 : H12AffineEnvironment.transform 16 122907 env32754 = env32755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env32754 == env32755) = true)

theorem identity32755 : scanCanonicalize (H12AffineFastState.compose env32755 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound32755 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env32756 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,65536,103494,10281,1024,32769,4160,73770,17,8542,8193,65,67927,111899,12637,67619,107871,32,256,98679,70662,33281]

theorem envBound32756 : H12AffineFastState.Bounded env32756 := by
  intro p hp
  have h : env32756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32755_32756 : H12AffineEnvironment.transform 13 13405 env32755 = env32756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env32755 == env32756) = true)

theorem identity32756 : scanCanonicalize (H12AffineFastState.compose env32756 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound32756 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env32757 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,8282,46108,10281,1024,32769,4160,112,17,8542,8193,65,10509,38209,12637,10361,34053,32,256,41261,13404,33281]

theorem envBound32757 : H12AffineFastState.Bounded env32757 := by
  intro p hp
  have h : env32757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32756_32757 : H12AffineEnvironment.transform 15 8282 env32756 = env32757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env32756 == env32757) = true)

theorem identity32757 : scanCanonicalize (H12AffineFastState.compose env32757 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound32757 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env32758 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,13405,32768,8282,46108,10281,1024,32769,4160,112,17,8315,8193,65,10280,37988,12408,10361,33824,32,37,40968,13404,33281]

theorem envBound32758 : H12AffineFastState.Bounded env32758 := by
  intro p hp
  have h : env32758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32757_32758 : H12AffineEnvironment.transform 7 37 env32757 = env32758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env32757 == env32758) = true)

theorem identity32758 : scanCanonicalize (H12AffineFastState.compose env32758 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound32758 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env32759 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,13405,81,8282,13389,10281,1024,80,4160,112,17,8315,8193,65,10280,5173,12408,10361,1137,32,37,8281,13404,592]

theorem envBound32759 : H12AffineFastState.Bounded env32759 := by
  intro p hp
  have h : env32759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32758_32759 : H12AffineEnvironment.transform 14 81 env32758 = env32759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env32758 == env32759) = true)

theorem identity32759 : scanCanonicalize (H12AffineFastState.compose env32759 (packedSelected [1,8] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound32759 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env32760 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,2112,8192,11293,81,8282,11277,10281,1024,80,2048,112,17,8315,8193,65,10280,3189,10296,10361,1137,32,37,8281,11292,592]

theorem envBound32760 : H12AffineFastState.Bounded env32760 := by
  intro p hp
  have h : env32760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32759_32760 : H12AffineEnvironment.transform 11 2112 env32759 = env32760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env32759 == env32760) = true)

theorem identity32760 : scanCanonicalize (H12AffineFastState.compose env32760 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound32760 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env32761 : List Nat := [2,4,8,16,32,64,9,37,512,52,2048,2112,8192,10281,81,8282,10297,10281,52,80,2048,112,17,8315,8193,65,10280,2113,10296,10361,69,32,37,8281,10280,592]

theorem envBound32761 : H12AffineFastState.Bounded env32761 := by
  intro p hp
  have h : env32761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32760_32761 : H12AffineEnvironment.transform 9 52 env32760 = env32761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env32760 == env32761) = true)

theorem identity32761 : scanCanonicalize (H12AffineFastState.compose env32761 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound32761 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32762 : List Nat := [2,4,8,16,32,64,9,37,512,52,2048,2112,40,2049,81,114,2065,2049,52,80,2048,112,17,83,41,65,2048,2113,2064,2129,69,32,37,113,2048,592]

theorem envBound32762 : H12AffineFastState.Bounded env32762 := by
  intro p hp
  have h : env32762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32761_32762 : H12AffineEnvironment.transform 12 40 env32761 = env32762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env32761 == env32762) = true)

theorem identity32762 : scanCanonicalize (H12AffineFastState.compose env32762 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32762 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env32763 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,2064,40,2049,1,34,2065,2049,52,0,2048,32,17,3,41,17,2048,2065,2064,2049,21,32,37,33,2048,512]

theorem envBound32763 : H12AffineFastState.Bounded env32763 := by
  intro p hp
  have h : env32763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32762_32763 : H12AffineEnvironment.transform 5 16 env32762 = env32763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32762 == env32763) = true)

theorem identity32763 : scanCanonicalize (H12AffineFastState.compose env32763 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32763 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32764 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,2064,8,2049,1,2,2065,2049,20,0,2048,0,17,3,9,17,2048,2065,2064,2049,21,0,5,1,2048,512]

theorem envBound32764 : H12AffineFastState.Bounded env32764 := by
  intro p hp
  have h : env32764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32763_32764 : H12AffineEnvironment.transform 4 0 env32763 = env32764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32763 == env32764) = true)

theorem identity32764 : scanCanonicalize (H12AffineFastState.compose env32764 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 4) := by decide +kernel

theorem selectedBound32764 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32765 : List Nat := [2,4,8,16,0,16,9,5,512,20,4,20,8,5,1,2,21,5,20,0,4,0,17,3,9,17,4,21,20,5,21,0,5,1,4,512]

theorem envBound32765 : H12AffineFastState.Bounded env32765 := by
  intro p hp
  have h : env32765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32764_32765 : H12AffineEnvironment.transform 10 4 env32764 = env32765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 4 env32764 == env32765) = true)

def env32766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1024,32769,4160,180273,253963,242969,8328,65,97666,139733,238874,67754,119042,168,256,98814,90203,63189]

theorem envBound32766 : H12AffineFastState.Bounded env32766 := by
  intro p hp
  have h : env32766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32744_32766 : H12AffineEnvironment.transform 17 10401 env32744 = env32766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env32744 == env32766) = true)

def env32767 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,180273,253963,242969,8192,65,97546,139613,238874,67618,119042,32,256,98678,90203,63069]

theorem envBound32767 : H12AffineFastState.Bounded env32767 := by
  intro p hp
  have h : env32767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32766_32767 : H12AffineEnvironment.transform 6 8 env32766 = env32767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32766 == env32767) = true)

theorem identity32767 : scanCanonicalize (H12AffineFastState.compose env32767 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound32767 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32768 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1024,8540,4160,156012,213334,201796,8192,65,97546,139613,197703,67618,94303,32,256,73771,90203,22272]

theorem envBound32768 : H12AffineFastState.Bounded env32768 := by
  intro p hp
  have h : env32768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32767_32768 : H12AffineEnvironment.transform 14 8541 env32767 = env32768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env32767 == env32768) = true)

theorem identity32768 : scanCanonicalize (H12AffineFastState.compose env32768 (packedSelected [1,2,6,8,9,11,12,14,15,16,19,20,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound32768 : packedSelected [1,2,6,8,9,11,12,14,15,16,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env32769 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,21591,131072,10281,1024,8540,4160,156012,136449,147475,8192,65,10589,139613,151568,23669,9224,32,256,29820,13324,22272]

theorem envBound32769 : H12AffineFastState.Bounded env32769 := by
  intro p hp
  have h : env32769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32768_32769 : H12AffineEnvironment.transform 15 21591 env32768 = env32769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env32768 == env32769) = true)

theorem identity32769 : scanCanonicalize (H12AffineFastState.compose env32769 (packedSelected [0,2,4,5,6,7,9,11,12,14,15,16,18,19,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound32769 : packedSelected [0,2,4,5,6,7,9,11,12,14,15,16,18,19,20,24] rootPS < 2^1333 := by decide +kernel

def env32770 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,8541,8282,131072,10281,1024,8540,4160,136545,136449,144414,8192,65,10589,139613,140317,10360,9224,32,256,113,13324,8973]

theorem envBound32770 : H12AffineFastState.Bounded env32770 := by
  intro p hp
  have h : env32770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32769_32770 : H12AffineEnvironment.transform 13 13325 env32769 = env32770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env32769 == env32770) = true)

theorem identity32770 : scanCanonicalize (H12AffineFastState.compose env32770 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 4469) := by decide +kernel

theorem selectedBound32770 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env32771 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,8541,8282,4469,10281,1024,8540,4160,1044,1140,9579,8192,65,10589,12328,13672,10360,9224,32,256,113,13324,8973]

theorem envBound32771 : H12AffineFastState.Bounded env32771 := by
  intro p hp
  have h : env32771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32770_32771 : H12AffineEnvironment.transform 16 4469 env32770 = env32771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4469 env32770 == env32771) = true)

theorem identity32771 : scanCanonicalize (H12AffineFastState.compose env32771 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound32771 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env32772 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,4161,1297,1046,4469,3173,1024,1296,4160,1044,1140,295,1100,65,3345,5220,4388,3124,68,32,256,113,4160,1857]

theorem envBound32772 : H12AffineFastState.Bounded env32772 := by
  intro p hp
  have h : env32772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32771_32772 : H12AffineEnvironment.transform 12 1100 env32771 = env32772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env32771 == env32772) = true)

theorem identity32772 : scanCanonicalize (H12AffineFastState.compose env32772 (packedSelected [0,1,7,8,10,15] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound32772 : packedSelected [0,1,7,8,10,15] rootPS < 2^1333 := by decide +kernel

def env32773 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2356,1100,2421,1297,1046,2113,3173,1024,1296,2420,1044,1140,295,1100,65,3345,3408,2064,3124,68,32,256,113,2420,1857]

theorem envBound32773 : H12AffineFastState.Bounded env32773 := by
  intro p hp
  have h : env32773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32772_32773 : H12AffineEnvironment.transform 11 2356 env32772 = env32773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env32772 == env32773) = true)

theorem identity32773 : scanCanonicalize (H12AffineFastState.compose env32773 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound32773 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env32774 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,2113,1100,2048,1124,1046,2113,3173,1024,1125,2049,1044,1140,82,1100,65,3172,3109,2064,3124,68,32,117,113,2049,1588]

theorem envBound32774 : H12AffineFastState.Bounded env32774 := by
  intro p hp
  have h : env32774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32773_32774 : H12AffineEnvironment.transform 7 117 env32773 = env32774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env32773 == env32774) = true)

theorem identity32774 : scanCanonicalize (H12AffineFastState.compose env32774 (packedSelected [0,2,4,6,7,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound32774 : packedSelected [0,2,4,6,7,9,11] rootPS < 2^1333 := by decide +kernel

def env32775 : List Nat := [2,4,8,16,32,64,8,117,512,101,2048,2113,41,2048,1,115,2113,2048,101,0,2049,113,17,82,41,65,2049,2112,2064,2129,68,32,117,113,2049,593]

theorem envBound32775 : H12AffineFastState.Bounded env32775 := by
  intro p hp
  have h : env32775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32774_32775 : H12AffineEnvironment.transform 9 101 env32774 = env32775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env32774 == env32775) = true)

theorem identity32775 : scanCanonicalize (H12AffineFastState.compose env32775 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32775 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env32776 : List Nat := [2,4,8,16,32,17,8,36,512,52,2048,2064,41,2048,1,34,2064,2048,52,0,2049,32,17,3,41,16,2049,2065,2064,2048,21,32,36,32,2049,512]

theorem envBound32776 : H12AffineFastState.Bounded env32776 := by
  intro p hp
  have h : env32776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32775_32776 : H12AffineEnvironment.transform 5 17 env32775 = env32776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32775 == env32776) = true)

theorem identity32776 : scanCanonicalize (H12AffineFastState.compose env32776 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 517) := by decide +kernel

theorem selectedBound32776 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32777 : List Nat := [2,4,8,16,32,17,8,36,512,52,517,533,41,517,1,34,533,517,52,0,516,32,17,3,41,16,516,532,533,517,21,32,36,32,516,512]

theorem envBound32777 : H12AffineFastState.Bounded env32777 := by
  intro p hp
  have h : env32777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32776_32777 : H12AffineEnvironment.transform 10 517 env32776 = env32777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 517 env32776 == env32777) = true)

theorem identity32777 : scanCanonicalize (H12AffineFastState.compose env32777 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound32777 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32778 : List Nat := [2,4,8,16,3,17,8,7,512,23,517,533,10,517,1,1,533,517,23,0,516,3,17,3,10,16,516,532,533,517,21,3,7,3,516,512]

theorem envBound32778 : H12AffineFastState.Bounded env32778 := by
  intro p hp
  have h : env32778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32777_32778 : H12AffineEnvironment.transform 4 3 env32777 = env32778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env32777 == env32778) = true)

theorem identity32778 : scanCanonicalize (H12AffineFastState.compose env32778 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound32778 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32779 : List Nat := [2,4,8,16,3,17,8,7,7,23,2,18,10,2,1,1,18,2,23,0,3,3,17,3,10,16,3,19,18,2,21,3,7,3,3,7]

theorem envBound32779 : H12AffineFastState.Bounded env32779 := by
  intro p hp
  have h : env32779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32778_32779 : H12AffineEnvironment.transform 8 7 env32778 = env32779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env32778 == env32779) = true)

theorem identity32779 : scanCanonicalize (H12AffineFastState.compose env32779 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound32779 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env32780 : List Nat := [2,4,6,16,3,17,6,7,7,23,2,18,4,2,1,1,18,2,23,0,3,3,17,3,4,16,3,19,18,2,21,3,7,3,3,7]

theorem envBound32780 : H12AffineFastState.Bounded env32780 := by
  intro p hp
  have h : env32780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32779_32780 : H12AffineEnvironment.transform 2 6 env32779 = env32780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env32779 == env32780) = true)

theorem identity32780 : scanCanonicalize (H12AffineFastState.compose env32780 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound32780 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env32781 : List Nat := [1,4,5,16,0,17,5,4,4,20,1,17,4,1,1,1,17,1,20,0,0,0,17,0,4,16,0,16,17,1,21,0,4,0,0,4]

theorem envBound32781 : H12AffineFastState.Bounded env32781 := by
  intro p hp
  have h : env32781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32780_32781 : H12AffineEnvironment.transform 0 1 env32780 = env32781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env32780 == env32781) = true)

def env32782 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,180273,253963,242969,8193,65,97547,139612,238874,67619,119042,33,256,98679,90203,63068]

theorem envBound32782 : H12AffineFastState.Bounded env32782 := by
  intro p hp
  have h : env32782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32766_32782 : H12AffineEnvironment.transform 6 9 env32766 = env32782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32766 == env32782) = true)

theorem identity32782 : scanCanonicalize (H12AffineFastState.compose env32782 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound32782 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env32783 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10280,1024,29788,4160,144492,201814,213316,8193,65,97547,139612,217415,67619,75103,33,256,95530,90203,513]

theorem envBound32783 : H12AffineFastState.Bounded env32783 := by
  intro p hp
  have h : env32783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32782_32783 : H12AffineEnvironment.transform 14 29789 env32782 = env32783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env32782 == env32783) = true)

theorem identity32783 : scanCanonicalize (H12AffineFastState.compose env32783 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound32783 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env32784 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,82246,10280,1024,29788,4160,95530,21776,2,8193,65,97547,90138,4097,67619,75103,33,256,95530,90203,513]

theorem envBound32784 : H12AffineFastState.Bounded env32784 := by
  intro p hp
  have h : env32784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32783_32784 : H12AffineEnvironment.transform 16 82246 env32783 = env32784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env32783 == env32784) = true)

theorem identity32784 : scanCanonicalize (H12AffineFastState.compose env32784 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound32784 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env32785 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,262,16448,10280,1024,29788,4160,29740,21776,2,8193,65,31757,24860,4097,2341,9305,33,256,29740,24925,513]

theorem envBound32785 : H12AffineFastState.Bounded env32785 := by
  intro p hp
  have h : env32785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32784_32785 : H12AffineEnvironment.transform 15 262 env32784 = env32785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env32784 == env32785) = true)

theorem identity32785 : scanCanonicalize (H12AffineFastState.compose env32785 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound32785 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env32786 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,262,5440,10280,1024,8540,4160,8492,16,2,8193,65,10509,13340,4097,2341,9305,33,256,8492,13405,513]

theorem envBound32786 : H12AffineFastState.Bounded env32786 := by
  intro p hp
  have h : env32786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32785_32786 : H12AffineEnvironment.transform 13 5376 env32785 = env32786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env32785 == env32786) = true)

theorem identity32786 : scanCanonicalize (H12AffineFastState.compose env32786 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound32786 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32787 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,262,5440,2421,1024,1,4160,113,16,2,348,65,2128,5441,4097,2341,1284,33,256,113,5376,513]

theorem envBound32787 : H12AffineFastState.Bounded env32787 := by
  intro p hp
  have h : env32787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32786_32787 : H12AffineEnvironment.transform 12 349 env32786 = env32787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env32786 == env32787) = true)

theorem identity32787 : scanCanonicalize (H12AffineFastState.compose env32787 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1589) := by decide +kernel

theorem selectedBound32787 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env32788 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1589,4096,349,5376,0,262,5440,1856,1024,1,4160,113,16,2,348,65,1637,5441,4097,1808,1284,33,256,113,5376,513]

theorem envBound32788 : H12AffineFastState.Bounded env32788 := by
  intro p hp
  have h : env32788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32787_32788 : H12AffineEnvironment.transform 10 1589 env32787 = env32788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1589 env32787 == env32788) = true)

theorem identity32788 : scanCanonicalize (H12AffineFastState.compose env32788 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound32788 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env32789 : List Nat := [2,4,8,16,32,64,9,256,276,1024,1313,4096,349,5376,0,262,5440,1108,1024,1,4160,113,16,2,348,65,1393,5441,4097,1028,1284,33,256,113,5376,277]

theorem envBound32789 : H12AffineFastState.Bounded env32789 := by
  intro p hp
  have h : env32789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32788_32789 : H12AffineEnvironment.transform 8 276 env32788 = env32789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env32788 == env32789) = true)

theorem identity32789 : scanCanonicalize (H12AffineFastState.compose env32789 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 117) := by decide +kernel

theorem selectedBound32789 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env32790 : List Nat := [2,4,8,16,32,64,9,256,276,117,340,4096,349,4469,0,262,4405,33,117,1,4160,113,16,2,348,65,260,4404,4097,113,369,33,256,113,4469,277]

theorem envBound32790 : H12AffineFastState.Bounded env32790 := by
  intro p hp
  have h : env32790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32789_32790 : H12AffineEnvironment.transform 9 117 env32789 = env32790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 117 env32789 == env32790) = true)

theorem identity32790 : scanCanonicalize (H12AffineFastState.compose env32790 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound32790 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32791 : List Nat := [2,4,8,16,32,64,9,256,276,117,340,261,349,112,0,262,48,33,117,1,325,113,16,2,348,65,260,49,260,113,369,33,256,113,112,277]

theorem envBound32791 : H12AffineFastState.Bounded env32791 := by
  intro p hp
  have h : env32791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32790_32791 : H12AffineEnvironment.transform 11 261 env32790 = env32791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env32790 == env32791) = true)

theorem identity32791 : scanCanonicalize (H12AffineFastState.compose env32791 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound32791 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32792 : List Nat := [2,4,8,16,32,64,9,4,16,117,80,1,89,112,0,2,48,33,117,1,65,113,16,2,88,65,0,49,0,113,117,33,4,113,112,17]

theorem envBound32792 : H12AffineFastState.Bounded env32792 := by
  intro p hp
  have h : env32792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32791_32792 : H12AffineEnvironment.transform 7 4 env32791 = env32792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env32791 == env32792) = true)

theorem identity32792 : scanCanonicalize (H12AffineFastState.compose env32792 (packedSelected [3,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound32792 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env32793 : List Nat := [2,4,8,0,32,64,9,4,0,101,64,1,73,96,0,2,32,33,101,1,65,97,0,2,72,65,0,33,0,97,101,33,4,97,96,1]

theorem envBound32793 : H12AffineFastState.Bounded env32793 := by
  intro p hp
  have h : env32793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32792_32793 : H12AffineEnvironment.transform 3 0 env32792 = env32793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env32792 == env32793) = true)

theorem identity32793 : scanCanonicalize (H12AffineFastState.compose env32793 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound32793 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32794 : List Nat := [2,4,8,0,1,64,9,4,0,68,64,1,73,65,0,2,1,0,68,1,65,64,0,2,72,65,0,0,0,64,68,0,4,64,65,1]

theorem envBound32794 : H12AffineFastState.Bounded env32794 := by
  intro p hp
  have h : env32794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32793_32794 : H12AffineEnvironment.transform 4 1 env32793 = env32794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env32793 == env32794) = true)

def env32795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180273,510122,499128,8328,65,349475,395637,495034,67754,119042,272392,256,98815,90202,63189]

theorem envBound32795 : H12AffineFastState.Bounded env32795 := by
  intro p hp
  have h : env32795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32743_32795 : H12AffineEnvironment.transform 20 4161 env32743 = env32795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env32743 == env32795) = true)

theorem identity32795 : scanCanonicalize (H12AffineFastState.compose env32795 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190641) := by decide +kernel

theorem selectedBound32795 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4161,180273,73755,95497,8328,65,245138,57796,91403,67754,119042,180409,256,98815,90202,63189]

theorem envBound32796 : H12AffineFastState.Bounded env32796 := by
  intro p hp
  have h : env32796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32795_32796 : H12AffineEnvironment.transform 17 190641 env32795 = env32796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190641 env32795 == env32796) = true)

def env32797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10401,1024,32769,4161,33,73755,95497,8328,65,97666,57796,91403,67754,119042,169,256,98815,90202,63189]

theorem envBound32797 : H12AffineFastState.Bounded env32797 := by
  intro p hp
  have h : env32797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32796_32797 : H12AffineEnvironment.transform 16 49168 env32796 = env32797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env32796 == env32797) = true)

theorem identity32797 : scanCanonicalize (H12AffineFastState.compose env32797 (packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound32797 : packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS < 2^1333 := by decide +kernel

def env32798 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,49168,10401,1024,32769,4161,33,153,21899,8328,65,23808,57796,17801,10280,61824,169,256,41341,16600,63189]

theorem envBound32798 : H12AffineFastState.Bounded env32798 := by
  intro p hp
  have h : env32798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32797_32798 : H12AffineEnvironment.transform 15 8322 env32797 = env32798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env32797 == env32798) = true)

theorem identity32798 : scanCanonicalize (H12AffineFastState.compose env32798 (packedSelected [1,2,3,4,5,6,7,11,12,14,15,16,17,19,20,22,23,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound32798 : packedSelected [1,2,3,4,5,6,7,11,12,14,15,16,17,19,20,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env32799 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8322,13508,10401,1024,29909,4161,33,153,21899,8328,65,23808,5392,17801,10280,1364,169,256,21929,16600,513]

theorem envBound32799 : H12AffineFastState.Bounded env32799 := by
  intro p hp
  have h : env32799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32798_32799 : H12AffineEnvironment.transform 14 29908 env32798 = env32799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env32798 == env32799) = true)

theorem identity32799 : scanCanonicalize (H12AffineFastState.compose env32799 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound32799 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env32800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8322,13508,10401,1024,8660,4161,33,153,138,8328,65,2049,5392,4232,10280,1364,169,256,168,5593,513]

theorem envBound32800 : H12AffineFastState.Bounded env32800 := by
  intro p hp
  have h : env32800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32799_32800 : H12AffineEnvironment.transform 13 5377 env32799 = env32800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env32799 == env32800) = true)

theorem identity32800 : scanCanonicalize (H12AffineFastState.compose env32800 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound32800 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env32801 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5377,1,342,5392,2421,1024,0,4161,33,153,138,348,65,2049,5392,4232,2556,1364,169,256,168,5593,513]

theorem envBound32801 : H12AffineFastState.Bounded env32801 := by
  intro p hp
  have h : env32801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32800_32801 : H12AffineEnvironment.transform 12 468 env32800 = env32801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env32800 == env32801) = true)

theorem identity32801 : scanCanonicalize (H12AffineFastState.compose env32801 (packedSelected [1,3,4,5,8,9,12,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32801 : packedSelected [1,3,4,5,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env32802 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5377,1,263,5392,2340,1024,0,4112,33,153,138,269,16,2049,5392,4232,2477,1285,169,256,168,5512,513]

theorem envBound32802 : H12AffineFastState.Bounded env32802 := by
  intro p hp
  have h : env32802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32801_32802 : H12AffineEnvironment.transform 5 17 env32801 = env32802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32801 == env32802) = true)

theorem identity32802 : scanCanonicalize (H12AffineFastState.compose env32802 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound32802 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env32803 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3329,389,2048,1,263,2065,2340,1024,0,3345,33,153,138,269,16,2049,2065,3465,2477,1285,169,256,168,2185,513]

theorem envBound32803 : H12AffineFastState.Bounded env32803 := by
  intro p hp
  have h : env32803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32802_32803 : H12AffineEnvironment.transform 11 3329 env32802 = env32803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env32802 == env32803) = true)

theorem identity32803 : scanCanonicalize (H12AffineFastState.compose env32803 (packedSelected [2,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound32803 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env32804 : List Nat := [2,4,8,16,32,17,128,256,512,52,2048,2357,389,2048,1,263,2065,2340,52,0,2341,33,153,138,269,16,2049,2065,2493,2477,305,169,256,168,2185,513]

theorem envBound32804 : H12AffineFastState.Bounded env32804 := by
  intro p hp
  have h : env32804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32803_32804 : H12AffineEnvironment.transform 9 52 env32803 = env32804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env32803 == env32804) = true)

theorem identity32804 : scanCanonicalize (H12AffineFastState.compose env32804 (packedSelected [1,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound32804 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env32805 : List Nat := [2,4,8,16,32,17,128,172,512,52,2048,2201,41,2048,1,171,2065,2184,52,0,2185,33,153,138,161,16,2049,2065,2065,2049,157,169,172,168,2185,513]

theorem envBound32805 : H12AffineFastState.Bounded env32805 := by
  intro p hp
  have h : env32805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32804_32805 : H12AffineEnvironment.transform 7 172 env32804 = env32805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env32804 == env32805) = true)

theorem identity32805 : scanCanonicalize (H12AffineFastState.compose env32805 (packedSelected [11] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32805 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env32806 : List Nat := [2,4,8,16,32,17,8,36,512,52,2048,2065,41,2048,1,35,2065,2048,52,0,2049,33,17,2,41,16,2049,2065,2065,2049,21,33,36,32,2049,513]

theorem envBound32806 : H12AffineFastState.Bounded env32806 := by
  intro p hp
  have h : env32806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32805_32806 : H12AffineEnvironment.transform 6 8 env32805 = env32806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32805 == env32806) = true)

theorem identity32806 : scanCanonicalize (H12AffineFastState.compose env32806 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound32806 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32807 : List Nat := [2,4,8,16,32,17,8,36,0,52,2048,2065,41,2048,1,35,2065,2048,52,0,2049,33,17,2,41,16,2049,2065,2065,2049,21,33,36,32,2049,1]

theorem envBound32807 : H12AffineFastState.Bounded env32807 := by
  intro p hp
  have h : env32807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32806_32807 : H12AffineEnvironment.transform 8 0 env32806 = env32807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env32806 == env32807) = true)

theorem identity32807 : scanCanonicalize (H12AffineFastState.compose env32807 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound32807 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32808 : List Nat := [2,4,8,16,32,17,8,36,0,52,10,27,41,10,1,35,27,10,52,0,11,33,17,2,41,16,11,27,27,11,21,33,36,32,11,1]

theorem envBound32808 : H12AffineFastState.Bounded env32808 := by
  intro p hp
  have h : env32808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32807_32808 : H12AffineEnvironment.transform 10 10 env32807 = env32808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env32807 == env32808) = true)

def env32809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10400,1024,32769,4161,32,73755,95497,8328,65,97667,57796,91403,67754,119042,168,256,98815,90202,63189]

theorem envBound32809 : H12AffineFastState.Bounded env32809 := by
  intro p hp
  have h : env32809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32796_32809 : H12AffineEnvironment.transform 16 49169 env32796 = env32809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env32796 == env32809) = true)

theorem identity32809 : scanCanonicalize (H12AffineFastState.compose env32809 (packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound32809 : packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS < 2^1333 := by decide +kernel

def env32810 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8233,65536,24632,10400,1024,8232,4161,32,73755,95497,8328,65,97667,16877,91403,67754,94507,168,256,74198,90202,22268]

theorem envBound32810 : H12AffineFastState.Bounded env32810 := by
  intro p hp
  have h : env32810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32809_32810 : H12AffineEnvironment.transform 14 8233 env32809 = env32810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env32809 == env32810) = true)

theorem identity32810 : scanCanonicalize (H12AffineFastState.compose env32810 (packedSelected [1,2,6,7,9,11,16,18,19,22,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound32810 : packedSelected [1,2,6,7,9,11,16,18,19,22,27,28,31] rootPS < 2^1333 := by decide +kernel

def env32811 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8233,171,24632,10400,1024,8232,4161,32,8368,30114,8328,65,32040,16877,26016,2049,29056,168,256,8573,24817,22268]

theorem envBound32811 : H12AffineFastState.Bounded env32811 := by
  intro p hp
  have h : env32811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32810_32811 : H12AffineEnvironment.transform 15 171 env32810 = env32811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env32810 == env32811) = true)

theorem identity32811 : scanCanonicalize (H12AffineFastState.compose env32811 (packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound32811 : packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env32812 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5237,8233,171,13389,10400,1024,8232,4161,32,8368,8663,8328,65,10589,5528,12757,2049,9717,168,256,8573,13444,649]

theorem envBound32812 : H12AffineFastState.Bounded env32812 := by
  intro p hp
  have h : env32812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32811_32812 : H12AffineEnvironment.transform 13 5237 env32811 = env32812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env32811 == env32812) = true)

theorem identity32812 : scanCanonicalize (H12AffineFastState.compose env32812 (packedSelected [0,2,6,7,16,17] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound32812 : packedSelected [0,2,6,7,16,17] rootPS < 2^1333 := by decide +kernel

def env32813 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,4096,8192,4248,8233,171,12448,10400,237,8232,4161,32,8368,8663,8328,65,10589,4469,12757,2049,8472,168,256,8573,12393,649]

theorem envBound32813 : H12AffineFastState.Bounded env32813 := by
  intro p hp
  have h : env32813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32812_32813 : H12AffineEnvironment.transform 9 237 env32812 = env32813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env32812 == env32813) = true)

theorem identity32813 : scanCanonicalize (H12AffineFastState.compose env32813 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound32813 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env32814 : List Nat := [2,4,8,16,32,64,128,253,512,237,2048,4096,8192,4248,8233,171,12448,10400,237,8232,4161,32,8368,8234,8328,65,10400,4232,12328,2049,8421,168,253,8320,12393,649]

theorem envBound32814 : H12AffineFastState.Bounded env32814 := by
  intro p hp
  have h : env32814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32813_32814 : H12AffineEnvironment.transform 7 253 env32813 = env32814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env32813 == env32814) = true)

theorem identity32814 : scanCanonicalize (H12AffineFastState.compose env32814 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound32814 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32815 : List Nat := [2,4,8,16,32,64,128,253,512,237,2048,4096,40,4248,1,171,4232,2184,237,0,4161,32,152,2,160,65,2184,4232,4096,2049,205,168,253,168,4161,649]

theorem envBound32815 : H12AffineFastState.Bounded env32815 := by
  intro p hp
  have h : env32815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32814_32815 : H12AffineEnvironment.transform 12 40 env32814 = env32815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env32814 == env32815) = true)

theorem identity32815 : scanCanonicalize (H12AffineFastState.compose env32815 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(11+1) ^^^ 152) := by decide +kernel

theorem selectedBound32815 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env32816 : List Nat := [2,4,8,16,32,64,128,253,512,237,2048,152,40,0,1,171,16,2184,237,0,217,32,152,2,160,65,2184,16,152,2049,205,168,253,168,217,649]

theorem envBound32816 : H12AffineFastState.Bounded env32816 := by
  intro p hp
  have h : env32816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32815_32816 : H12AffineEnvironment.transform 11 152 env32815 = env32816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 152 env32815 == env32816) = true)

theorem identity32816 : scanCanonicalize (H12AffineFastState.compose env32816 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound32816 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32817 : List Nat := [2,4,8,16,32,48,128,141,512,157,2048,152,40,0,1,171,16,2184,157,0,169,32,152,2,160,49,2184,16,152,2049,189,168,141,168,169,649]

theorem envBound32817 : H12AffineFastState.Bounded env32817 := by
  intro p hp
  have h : env32817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32816_32817 : H12AffineEnvironment.transform 5 48 env32816 = env32817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env32816 == env32817) = true)

theorem identity32817 : scanCanonicalize (H12AffineFastState.compose env32817 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound32817 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env32818 : List Nat := [2,4,8,16,32,48,128,141,512,157,1,152,40,0,1,171,16,137,157,0,169,32,152,2,160,49,137,16,152,0,189,168,141,168,169,649]

theorem envBound32818 : H12AffineFastState.Bounded env32818 := by
  intro p hp
  have h : env32818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32817_32818 : H12AffineEnvironment.transform 10 1 env32817 = env32818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env32817 == env32818) = true)

theorem identity32818 : scanCanonicalize (H12AffineFastState.compose env32818 (packedSelected [3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound32818 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env32819 : List Nat := [2,4,8,16,32,48,128,141,48,157,1,152,40,0,1,171,16,137,157,0,169,32,152,2,160,49,137,16,152,0,189,168,141,168,169,185]

theorem envBound32819 : H12AffineFastState.Bounded env32819 := by
  intro p hp
  have h : env32819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32818_32819 : H12AffineEnvironment.transform 8 48 env32818 = env32819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env32818 == env32819) = true)

theorem identity32819 : scanCanonicalize (H12AffineFastState.compose env32819 (packedSelected [0,1,3] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound32819 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env32820 : List Nat := [2,4,8,16,32,48,40,37,48,53,1,48,40,0,1,3,16,33,53,0,1,32,48,2,8,49,33,16,48,0,21,0,37,0,1,17]

theorem envBound32820 : H12AffineFastState.Bounded env32820 := by
  intro p hp
  have h : env32820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32819_32820 : H12AffineEnvironment.transform 6 40 env32819 = env32820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env32819 == env32820) = true)

def env32821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180273,510122,499129,8328,65,349474,2496821,2596347,67754,119043,2373704,256,2199999,2191386,63188]

theorem envBound32821 : H12AffineFastState.Bounded env32821 := by
  intro p hp
  have h : env32821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32742_32821 : H12AffineEnvironment.transform 23 499129 env32742 = env32821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 499129 env32742 == env32821) = true)

def env32822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180273,510122,499129,8328,65,349474,395637,495035,67754,119043,272392,256,98815,90202,63188]

theorem envBound32822 : H12AffineFastState.Bounded env32822 := by
  intro p hp
  have h : env32822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32821_32822 : H12AffineEnvironment.transform 20 4160 env32821 = env32822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env32821 == env32822) = true)

theorem identity32822 : scanCanonicalize (H12AffineFastState.compose env32822 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138340) := by decide +kernel

theorem selectedBound32822 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,4160,180273,120014,98781,8328,65,215366,5393,102879,67754,119043,144492,256,98815,90202,63188]

theorem envBound32823 : H12AffineFastState.Bounded env32823 := by
  intro p hp
  have h : env32823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32822_32823 : H12AffineEnvironment.transform 17 138340 env32822 = env32823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138340 env32822 == env32823) = true)

def env32824 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,4160,180273,119878,98645,8192,65,215366,5393,102743,67618,119043,144492,256,98679,90202,63068]

theorem envBound32824 : H12AffineFastState.Bounded env32824 := by
  intro p hp
  have h : env32824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32823_32824 : H12AffineEnvironment.transform 6 8 env32823 = env32824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32823 == env32824) = true)

theorem identity32824 : scanCanonicalize (H12AffineFastState.compose env32824 (packedSelected [0,7,8,9,10,12,14,15,16,18,22,23,28] rootPS)) = affineNative (2^(15+1) ^^^ 29822) := by decide +kernel

theorem selectedBound32824 : packedSelected [0,7,8,9,10,12,14,15,16,18,22,23,28] rootPS < 2^1333 := by decide +kernel

def env32825 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29822,131072,138340,1024,32769,4160,180273,41016,62763,8192,65,146744,5393,58665,31836,42365,144492,256,62729,5156,63068]

theorem envBound32825 : H12AffineFastState.Bounded env32825 := by
  intro p hp
  have h : env32825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32824_32825 : H12AffineEnvironment.transform 15 29822 env32824 = env32825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29822 env32824 == env32825) = true)

theorem identity32825 : scanCanonicalize (H12AffineFastState.compose env32825 (packedSelected [1,2,4,5,6,8,14,19,20,22,23,24,26,32,35] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound32825 : packedSelected [1,2,4,5,6,8,14,19,20,22,23,24,26,32,35] rootPS < 2^1333 := by decide +kernel

def env32826 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,29822,131072,138340,1024,0,4160,147504,8249,29994,8192,65,146744,5393,25896,31836,9596,144492,256,29960,5156,30301]

theorem envBound32826 : H12AffineFastState.Bounded env32826 := by
  intro p hp
  have h : env32826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32825_32826 : H12AffineEnvironment.transform 14 1 env32825 = env32826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env32825 == env32826) = true)

theorem identity32826 : scanCanonicalize (H12AffineFastState.compose env32826 (packedSelected [0,7,9,14,17,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound32826 : packedSelected [0,7,9,14,17,20,22] rootPS < 2^1333 := by decide +kernel

def env32827 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,1,29822,131072,138340,1024,0,4160,147504,8249,29790,8192,65,146508,5221,25692,31836,9224,144492,116,29820,5156,30301]

theorem envBound32827 : H12AffineFastState.Bounded env32827 := by
  intro p hp
  have h : env32827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32826_32827 : H12AffineEnvironment.transform 7 116 env32826 = env32827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env32826 == env32827) = true)

theorem identity32827 : scanCanonicalize (H12AffineFastState.compose env32827 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound32827 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env32828 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,16384,1,21590,131072,138340,1024,0,4160,147504,17,21622,40,65,138340,5221,17524,23668,1056,136260,116,21588,5156,22133]

theorem envBound32828 : H12AffineFastState.Bounded env32828 := by
  intro p hp
  have h : env32828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32827_32828 : H12AffineEnvironment.transform 12 40 env32827 = env32828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env32827 == env32828) = true)

theorem identity32828 : scanCanonicalize (H12AffineFastState.compose env32828 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound32828 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env32829 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,16384,1,21590,16401,23669,1024,0,4160,33,17,21622,40,65,23669,5221,17524,23668,1056,21589,116,21588,5156,22133]

theorem envBound32829 : H12AffineFastState.Bounded env32829 := by
  intro p hp
  have h : env32829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32828_32829 : H12AffineEnvironment.transform 16 16401 env32828 = env32829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env32828 == env32829) = true)

theorem identity32829 : scanCanonicalize (H12AffineFastState.compose env32829 (packedSelected [1,2,4,6,8,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound32829 : packedSelected [1,2,4,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env32830 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,2048,1,7254,2065,5237,1024,0,4160,33,17,7286,40,65,5237,5221,3188,5236,1056,7253,116,7252,5156,7797]

theorem envBound32830 : H12AffineFastState.Bounded env32830 := by
  intro p hp
  have h : env32830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32829_32830 : H12AffineEnvironment.transform 13 2048 env32829 = env32830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env32829 == env32830) = true)

theorem identity32830 : scanCanonicalize (H12AffineFastState.compose env32830 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 3189) := by decide +kernel

theorem selectedBound32830 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env32831 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,3189,40,2048,1,35,2065,2048,1024,0,3125,33,17,3,40,65,2048,2064,3188,2049,1056,32,116,33,2129,512]

theorem envBound32831 : H12AffineFastState.Bounded env32831 := by
  intro p hp
  have h : env32831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32830_32831 : H12AffineEnvironment.transform 11 3189 env32830 = env32831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3189 env32830 == env32831) = true)

theorem identity32831 : scanCanonicalize (H12AffineFastState.compose env32831 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 624) := by decide +kernel

theorem selectedBound32831 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32832 : List Nat := [2,4,8,16,32,64,8,116,512,1024,624,1541,40,624,1,35,609,624,1024,0,1605,33,17,3,40,65,624,608,1540,625,1056,32,116,33,545,512]

theorem envBound32832 : H12AffineFastState.Bounded env32832 := by
  intro p hp
  have h : env32832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32831_32832 : H12AffineEnvironment.transform 10 624 env32831 = env32832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 624 env32831 == env32832) = true)

theorem identity32832 : scanCanonicalize (H12AffineFastState.compose env32832 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound32832 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env32833 : List Nat := [2,4,8,16,32,48,8,4,512,1024,512,1541,40,512,1,35,529,512,1024,0,1589,33,17,3,40,49,512,528,1540,513,1056,32,4,33,545,512]

theorem envBound32833 : H12AffineFastState.Bounded env32833 := by
  intro p hp
  have h : env32833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32832_32833 : H12AffineEnvironment.transform 5 48 env32832 = env32833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env32832 == env32833) = true)

def env32834 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,4160,180273,119879,98644,8193,65,215366,5393,102742,67619,119043,144492,256,98678,90202,63069]

theorem envBound32834 : H12AffineFastState.Bounded env32834 := by
  intro p hp
  have h : env32834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32823_32834 : H12AffineEnvironment.transform 6 9 env32823 = env32834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32823 == env32834) = true)

theorem identity32834 : scanCanonicalize (H12AffineFastState.compose env32834 (packedSelected [0,7,8,9,10,12,14,15,16,18,22,23,28] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound32834 : packedSelected [0,7,8,9,10,12,14,15,16,18,22,23,28] rootPS < 2^1333 := by decide +kernel

def env32835 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,138340,1024,32769,4160,169264,98630,98644,8193,65,203847,5393,102742,67619,99330,144492,256,98678,79195,41820]

theorem envBound32835 : H12AffineFastState.Bounded env32835 := by
  intro p hp
  have h : env32835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32834_32835 : H12AffineEnvironment.transform 13 5377 env32834 = env32835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env32834 == env32835) = true)

theorem identity32835 : scanCanonicalize (H12AffineFastState.compose env32835 (packedSelected [0,1,3,7,8,9,10,12,14,15,17,18,20,22,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 103494) := by decide +kernel

theorem selectedBound32835 : packedSelected [0,1,3,7,8,9,10,12,14,15,17,18,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env32836 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,103494,100386,1024,32769,4160,65910,98630,98644,8193,65,34817,5393,102742,67619,99330,106538,256,98678,79195,41820]

theorem envBound32836 : H12AffineFastState.Bounded env32836 := by
  intro p hp
  have h : env32836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32835_32836 : H12AffineEnvironment.transform 16 103494 env32835 = env32836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103494 env32835 == env32836) = true)

theorem identity32836 : scanCanonicalize (H12AffineFastState.compose env32836 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound32836 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env32837 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33111,5393,2421,1024,32769,4160,32801,17,3,8193,65,34817,5393,4097,35188,1365,8573,256,33,46092,41820]

theorem envBound32837 : H12AffineFastState.Bounded env32837 := by
  intro p hp
  have h : env32837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32836_32837 : H12AffineEnvironment.transform 15 33111 env32836 = env32837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env32836 == env32837) = true)

theorem identity32837 : scanCanonicalize (H12AffineFastState.compose env32837 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound32837 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env32838 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,32768,33111,5393,2421,1024,32769,4160,32801,17,3,348,65,34817,5393,4097,35188,1365,32,256,33,38225,33281]

theorem envBound32838 : H12AffineFastState.Bounded env32838 := by
  intro p hp
  have h : env32838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32837_32838 : H12AffineEnvironment.transform 12 349 env32837 = env32838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env32837 == env32838) = true)

theorem identity32838 : scanCanonicalize (H12AffineFastState.compose env32838 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound32838 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32839 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,342,5393,2421,1024,0,4160,32,17,3,348,65,2048,5393,4097,2421,1365,32,256,33,5456,512]

theorem envBound32839 : H12AffineFastState.Bounded env32839 := by
  intro p hp
  have h : env32839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32838_32839 : H12AffineEnvironment.transform 14 1 env32838 = env32839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env32838 == env32839) = true)

theorem identity32839 : scanCanonicalize (H12AffineFastState.compose env32839 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1898) := by decide +kernel

theorem selectedBound32839 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32840 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1898,4096,349,5377,1,342,5393,1567,1024,0,4160,32,17,3,348,65,1898,5393,4097,1567,1365,32,256,33,5456,512]

theorem envBound32840 : H12AffineFastState.Bounded env32840 := by
  intro p hp
  have h : env32840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32839_32840 : H12AffineEnvironment.transform 10 1898 env32839 = env32840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1898 env32839 == env32840) = true)

theorem identity32840 : scanCanonicalize (H12AffineFastState.compose env32840 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound32840 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32841 : List Nat := [2,4,8,16,32,48,9,256,512,1024,1818,4096,301,5377,1,294,5393,1567,1024,0,4144,32,17,3,300,49,1818,5393,4097,1567,1317,32,256,33,5408,512]

theorem envBound32841 : H12AffineFastState.Bounded env32841 := by
  intro p hp
  have h : env32841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32840_32841 : H12AffineEnvironment.transform 5 48 env32840 = env32841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env32840 == env32841) = true)

theorem identity32841 : scanCanonicalize (H12AffineFastState.compose env32841 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound32841 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32842 : List Nat := [2,4,8,16,32,48,9,256,512,52,814,4096,301,4405,1,294,4389,555,52,0,4144,32,17,3,300,49,814,4389,4097,555,273,32,256,33,4372,512]

theorem envBound32842 : H12AffineFastState.Bounded env32842 := by
  intro p hp
  have h : env32842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32841_32842 : H12AffineEnvironment.transform 9 52 env32841 = env32842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env32841 == env32842) = true)

theorem identity32842 : scanCanonicalize (H12AffineFastState.compose env32842 (packedSelected [2,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 539) := by decide +kernel

theorem selectedBound32842 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env32843 : List Nat := [2,4,8,16,32,48,9,256,512,52,814,539,301,814,1,294,830,555,52,0,555,32,17,3,300,49,814,830,538,555,273,32,256,33,783,512]

theorem envBound32843 : H12AffineFastState.Bounded env32843 := by
  intro p hp
  have h : env32843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32842_32843 : H12AffineEnvironment.transform 11 539 env32842 = env32843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 539 env32842 == env32843) = true)

theorem identity32843 : scanCanonicalize (H12AffineFastState.compose env32843 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound32843 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env32844 : List Nat := [2,4,8,16,32,48,9,256,42,52,260,49,301,260,1,294,276,1,52,0,1,32,17,3,300,49,260,276,48,1,273,32,256,33,293,42]

theorem envBound32844 : H12AffineFastState.Bounded env32844 := by
  intro p hp
  have h : env32844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32843_32844 : H12AffineEnvironment.transform 8 42 env32843 = env32844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env32843 == env32844) = true)

theorem identity32844 : scanCanonicalize (H12AffineFastState.compose env32844 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound32844 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env32845 : List Nat := [2,4,8,16,32,48,9,4,42,52,0,49,41,0,1,34,16,1,52,0,1,32,17,3,40,49,0,16,48,1,21,32,4,33,33,42]

theorem envBound32845 : H12AffineFastState.Bounded env32845 := by
  intro p hp
  have h : env32845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32844_32845 : H12AffineEnvironment.transform 7 4 env32844 = env32845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env32844 == env32845) = true)

theorem identity32845 : scanCanonicalize (H12AffineFastState.compose env32845 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound32845 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32846 : List Nat := [2,4,8,4,32,36,9,4,42,32,0,37,41,0,1,34,4,1,32,0,1,32,5,3,40,37,0,4,36,1,1,32,4,33,33,42]

theorem envBound32846 : H12AffineFastState.Bounded env32846 := by
  intro p hp
  have h : env32846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32845_32846 : H12AffineEnvironment.transform 3 4 env32845 = env32846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env32845 == env32846) = true)

theorem identity32846 : scanCanonicalize (H12AffineFastState.compose env32846 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound32846 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32847 : List Nat := [1,4,8,4,32,36,9,4,41,32,0,37,41,0,1,33,4,1,32,0,1,32,5,0,40,37,0,4,36,1,1,32,4,33,33,41]

theorem envBound32847 : H12AffineFastState.Bounded env32847 := by
  intro p hp
  have h : env32847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32846_32847 : H12AffineEnvironment.transform 0 1 env32846 = env32847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env32846 == env32847) = true)

theorem identity32847 : scanCanonicalize (H12AffineFastState.compose env32847 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound32847 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32848 : List Nat := [1,4,8,4,1,5,9,4,8,1,0,4,8,0,1,0,4,1,1,0,1,1,5,0,9,4,0,4,5,1,1,1,4,0,0,8]

theorem envBound32848 : H12AffineFastState.Bounded env32848 := by
  intro p hp
  have h : env32848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32847_32848 : H12AffineEnvironment.transform 4 1 env32847 = env32848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env32847 == env32848) = true)

def env32849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180273,510122,499129,8328,65,349474,395636,495034,67754,119043,272393,256,98814,90203,63188]

theorem envBound32849 : H12AffineFastState.Bounded env32849 := by
  intro p hp
  have h : env32849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32821_32849 : H12AffineEnvironment.transform 20 4161 env32821 = env32849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env32821 == env32849) = true)

theorem identity32849 : scanCanonicalize (H12AffineFastState.compose env32849 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound32849 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,4161,144612,474239,485740,8328,65,349474,395636,489839,67754,75222,272393,256,95531,90203,513]

theorem envBound32850 : H12AffineFastState.Bounded env32850 := by
  intro p hp
  have h : env32850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32849_32850 : H12AffineEnvironment.transform 14 29909 env32849 = env32850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env32849 == env32850) = true)

def env32851 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,4161,144492,474239,485740,8192,65,349474,395636,489839,67618,75102,272393,256,95531,90203,513]

theorem envBound32851 : H12AffineFastState.Bounded env32851 := by
  intro p hp
  have h : env32851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32850_32851 : H12AffineEnvironment.transform 6 8 env32850 = env32851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32850 == env32851) = true)

theorem identity32851 : scanCanonicalize (H12AffineFastState.compose env32851 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound32851 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env32852 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90139,262144,1024,29788,4161,87159,285796,264567,8192,65,349474,354671,268660,67618,75102,272393,256,95531,90203,513]

theorem envBound32852 : H12AffineFastState.Bounded env32852 := by
  intro p hp
  have h : env32852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32851_32852 : H12AffineEnvironment.transform 16 90139 env32851 = env32852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env32851 == env32852) = true)

theorem identity32852 : scanCanonicalize (H12AffineFastState.compose env32852 (packedSelected [0,4,7,9,11,14,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 76910) := by decide +kernel

theorem selectedBound32852 : packedSelected [0,4,7,9,11,14,18,23,32] rootPS < 2^1333 := by decide +kernel

def env32853 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90139,76910,1024,29788,4161,87159,94218,75033,8192,65,31052,17665,79130,67618,75102,66663,256,95531,90203,513]

theorem envBound32853 : H12AffineFastState.Bounded env32853 := by
  intro p hp
  have h : env32853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32852_32853 : H12AffineEnvironment.transform 17 76910 env32852 = env32853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76910 env32852 == env32853) = true)

theorem identity32853 : scanCanonicalize (H12AffineFastState.compose env32853 (packedSelected [3,4,5,8,9,14,15,17,18,20,23,28,38] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound32853 : packedSelected [3,4,5,8,9,14,15,17,18,20,23,28,38] rootPS < 2^1333 := by decide +kernel

def env32854 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,29962,5393,22884,1024,29788,4161,8573,1280,20499,8192,65,31052,17665,16400,32040,20564,29037,256,33,5457,513]

theorem envBound32854 : H12AffineFastState.Bounded env32854 := by
  intro p hp
  have h : env32854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32853_32854 : H12AffineEnvironment.transform 15 29962 env32853 = env32854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env32853 == env32854) = true)

theorem identity32854 : scanCanonicalize (H12AffineFastState.compose env32854 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(13+1) ^^^ 12621) := by decide +kernel

theorem selectedBound32854 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env32855 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12621,1296,1095,5393,10281,1024,1297,4161,8573,1280,8542,8192,65,2049,13388,12637,3173,8473,32,256,33,5457,513]

theorem envBound32855 : H12AffineFastState.Bounded env32855 := by
  intro p hp
  have h : env32855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32854_32855 : H12AffineEnvironment.transform 13 12621 env32854 = env32855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12621 env32854 == env32855) = true)

theorem identity32855 : scanCanonicalize (H12AffineFastState.compose env32855 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 6429) := by decide +kernel

theorem selectedBound32855 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env32856 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,6429,2128,1296,1095,5393,4404,1024,1297,4161,6240,1280,6211,6429,65,2049,3409,2112,3173,6148,32,256,33,5457,513]

theorem envBound32856 : H12AffineFastState.Bounded env32856 := by
  intro p hp
  have h : env32856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32855_32856 : H12AffineEnvironment.transform 12 6429 env32855 = env32856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6429 env32855 == env32856) = true)

theorem identity32856 : scanCanonicalize (H12AffineFastState.compose env32856 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound32856 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env32857 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,6249,2128,1124,1095,5221,4160,1024,1125,4161,6240,1140,6211,6249,65,2049,3109,2112,3173,6148,32,116,33,5157,513]

theorem envBound32857 : H12AffineFastState.Bounded env32857 := by
  intro p hp
  have h : env32857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32856_32857 : H12AffineEnvironment.transform 7 116 env32856 = env32857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env32856 == env32857) = true)

theorem identity32857 : scanCanonicalize (H12AffineFastState.compose env32857 (packedSelected [1,2,6,8,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32857 : packedSelected [1,2,6,8,10] rootPS < 2^1333 := by decide +kernel

def env32858 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,6201,2048,1076,1047,5173,4112,1024,1077,4113,6192,1060,6163,6201,17,2049,3109,2064,3125,6148,32,36,33,5157,513]

theorem envBound32858 : H12AffineFastState.Bounded env32858 := by
  intro p hp
  have h : env32858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32857_32858 : H12AffineEnvironment.transform 5 16 env32857 = env32858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32857 == env32858) = true)

theorem identity32858 : scanCanonicalize (H12AffineFastState.compose env32858 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound32858 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32859 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,3108,1053,2048,1076,1047,2065,3124,1024,1077,3125,1044,1060,1079,1053,17,2049,3109,2064,3125,1056,32,36,33,2049,513]

theorem envBound32859 : H12AffineFastState.Bounded env32859 := by
  intro p hp
  have h : env32859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32858_32859 : H12AffineEnvironment.transform 11 3108 env32858 = env32859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env32858 == env32859) = true)

theorem identity32859 : scanCanonicalize (H12AffineFastState.compose env32859 (packedSelected [0,1,2] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound32859 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env32860 : List Nat := [2,4,8,16,32,16,8,36,512,1024,554,1550,1053,554,1076,1047,571,1566,1024,1077,1567,1044,1060,1079,1053,17,555,1551,570,1567,1056,32,36,33,555,513]

theorem envBound32860 : H12AffineFastState.Bounded env32860 := by
  intro p hp
  have h : env32860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32859_32860 : H12AffineEnvironment.transform 10 554 env32859 = env32860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env32859 == env32860) = true)

theorem identity32860 : scanCanonicalize (H12AffineFastState.compose env32860 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound32860 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env32861 : List Nat := [2,4,8,16,32,16,8,36,512,53,554,571,40,554,1,34,571,555,53,0,554,33,17,2,40,17,555,570,570,554,21,32,36,33,555,513]

theorem envBound32861 : H12AffineFastState.Bounded env32861 := by
  intro p hp
  have h : env32861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32860_32861 : H12AffineEnvironment.transform 9 53 env32860 = env32861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env32860 == env32861) = true)

theorem identity32861 : scanCanonicalize (H12AffineFastState.compose env32861 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 58) := by decide +kernel

theorem selectedBound32861 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32862 : List Nat := [2,4,8,16,32,16,8,36,58,53,16,1,40,16,1,34,1,17,53,0,16,33,17,2,40,17,17,0,0,16,21,32,36,33,17,59]

theorem envBound32862 : H12AffineFastState.Bounded env32862 := by
  intro p hp
  have h : env32862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32861_32862 : H12AffineEnvironment.transform 8 58 env32861 = env32862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 58 env32861 == env32862) = true)

def env32863 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,4161,144493,474239,485740,8193,65,349474,395636,489839,67619,75103,272393,256,95531,90203,513]

theorem envBound32863 : H12AffineFastState.Bounded env32863 := by
  intro p hp
  have h : env32863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32850_32863 : H12AffineEnvironment.transform 6 9 env32850 = env32863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32850 == env32863) = true)

theorem identity32863 : scanCanonicalize (H12AffineFastState.compose env32863 (packedSelected [0,1,3,7,11,15,17,19,20,24,26,28,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound32863 : packedSelected [0,1,3,7,11,15,17,19,20,24,26,28,32,38] rootPS < 2^1333 := by decide +kernel

def env32864 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,32041,1024,29789,4161,144493,213334,201797,8193,65,75787,160861,197702,67619,75103,21792,256,95531,90203,513]

theorem envBound32864 : H12AffineFastState.Bounded env32864 := by
  intro p hp
  have h : env32864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32863_32864 : H12AffineEnvironment.transform 17 32041 env32863 = env32864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env32863 == env32864) = true)

theorem identity32864 : scanCanonicalize (H12AffineFastState.compose env32864 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound32864 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env32865 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,21590,131072,32041,1024,29789,4161,144493,136448,147475,8193,65,31837,160861,151568,23669,28937,21792,256,8573,13325,513]

theorem envBound32865 : H12AffineFastState.Bounded env32865 := by
  intro p hp
  have h : env32865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32864_32865 : H12AffineEnvironment.transform 15 21590 env32864 = env32865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env32864 == env32865) = true)

theorem identity32865 : scanCanonicalize (H12AffineFastState.compose env32865 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound32865 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env32866 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,21590,131072,23668,1024,21760,4161,136496,136448,147475,348,65,23808,152832,151568,23669,20564,21792,256,32,5456,513]

theorem envBound32866 : H12AffineFastState.Bounded env32866 := by
  intro p hp
  have h : env32866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32865_32866 : H12AffineEnvironment.transform 12 349 env32865 = env32866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env32865 == env32866) = true)

theorem identity32866 : scanCanonicalize (H12AffineFastState.compose env32866 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound32866 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env32867 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,21590,5392,23668,1024,21760,4161,32,16,21763,348,65,23808,16400,17664,23669,20564,21792,256,32,5456,513]

theorem envBound32867 : H12AffineFastState.Bounded env32867 := by
  intro p hp
  have h : env32867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32866_32867 : H12AffineEnvironment.transform 16 5392 env32866 = env32867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env32866 == env32867) = true)

theorem identity32867 : scanCanonicalize (H12AffineFastState.compose env32867 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32867 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env32868 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,349,16384,21761,21590,5392,23636,1024,21760,4161,0,16,21763,348,65,23808,16400,17664,23637,20564,21760,256,0,5456,513]

theorem envBound32868 : H12AffineFastState.Bounded env32868 := by
  intro p hp
  have h : env32868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32867_32868 : H12AffineEnvironment.transform 4 0 env32867 = env32868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32867 == env32868) = true)

theorem identity32868 : scanCanonicalize (H12AffineFastState.compose env32868 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound32868 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32869 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,349,5377,0,343,5392,2389,1024,1,4161,0,16,2,348,65,2049,5393,4097,2388,1365,1,256,0,5456,513]

theorem envBound32869 : H12AffineFastState.Bounded env32869 := by
  intro p hp
  have h : env32869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32868_32869 : H12AffineEnvironment.transform 13 5377 env32868 = env32869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env32868 == env32869) = true)

theorem identity32869 : scanCanonicalize (H12AffineFastState.compose env32869 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 833) := by decide +kernel

theorem selectedBound32869 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32870 : List Nat := [2,4,8,16,0,64,9,256,512,833,2048,4096,349,4672,0,343,4689,2389,833,1,4161,0,16,2,348,65,2049,4688,4097,2388,532,1,256,0,4625,513]

theorem envBound32870 : H12AffineFastState.Bounded env32870 := by
  intro p hp
  have h : env32870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32869_32870 : H12AffineEnvironment.transform 9 833 env32869 = env32870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 833 env32869 == env32870) = true)

theorem identity32870 : scanCanonicalize (H12AffineFastState.compose env32870 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32870 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32871 : List Nat := [2,4,8,16,0,17,9,256,512,784,2048,4096,268,4625,0,262,4608,2308,784,1,4112,0,16,2,269,16,2049,4609,4097,2309,532,1,256,0,4625,513]

theorem envBound32871 : H12AffineFastState.Bounded env32871 := by
  intro p hp
  have h : env32871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32870_32871 : H12AffineEnvironment.transform 5 17 env32870 = env32871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32870 == env32871) = true)

theorem identity32871 : scanCanonicalize (H12AffineFastState.compose env32871 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound32871 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32872 : List Nat := [2,4,8,16,0,17,9,256,512,784,2048,261,268,788,0,262,773,2308,784,1,277,0,16,2,269,16,2049,772,260,2309,532,1,256,0,788,513]

theorem envBound32872 : H12AffineFastState.Bounded env32872 := by
  intro p hp
  have h : env32872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32871_32872 : H12AffineEnvironment.transform 11 261 env32871 = env32872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env32871 == env32872) = true)

theorem identity32872 : scanCanonicalize (H12AffineFastState.compose env32872 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound32872 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env32873 : List Nat := [2,4,8,16,0,17,9,256,512,784,261,261,268,788,0,262,773,1,784,1,277,0,16,2,269,16,260,772,260,0,532,1,256,0,788,513]

theorem envBound32873 : H12AffineFastState.Bounded env32873 := by
  intro p hp
  have h : env32873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32872_32873 : H12AffineEnvironment.transform 10 261 env32872 = env32873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env32872 == env32873) = true)

theorem identity32873 : scanCanonicalize (H12AffineFastState.compose env32873 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound32873 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env32874 : List Nat := [2,4,8,1,0,0,9,256,512,769,261,261,268,773,0,262,773,1,769,1,260,0,1,2,269,1,260,772,260,0,517,1,256,0,773,513]

theorem envBound32874 : H12AffineFastState.Bounded env32874 := by
  intro p hp
  have h : env32874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32873_32874 : H12AffineEnvironment.transform 3 1 env32873 = env32874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env32873 == env32874) = true)

theorem identity32874 : scanCanonicalize (H12AffineFastState.compose env32874 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound32874 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32875 : List Nat := [2,4,8,1,0,0,9,256,261,4,261,261,268,0,0,262,0,1,4,1,260,0,1,2,269,1,260,1,260,0,256,1,256,0,0,260]

theorem envBound32875 : H12AffineFastState.Bounded env32875 := by
  intro p hp
  have h : env32875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32874_32875 : H12AffineEnvironment.transform 8 261 env32874 = env32875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env32874 == env32875) = true)

theorem identity32875 : scanCanonicalize (H12AffineFastState.compose env32875 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound32875 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32876 : List Nat := [2,4,8,1,0,0,9,4,1,4,1,1,8,0,0,2,0,1,4,1,0,0,1,2,9,1,0,1,0,0,4,1,4,0,0,0]

theorem envBound32876 : H12AffineFastState.Bounded env32876 := by
  intro p hp
  have h : env32876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32875_32876 : H12AffineEnvironment.transform 7 4 env32875 = env32876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env32875 == env32876) = true)

theorem identity32876 : scanCanonicalize (H12AffineFastState.compose env32876 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound32876 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32877 : List Nat := [2,4,2,1,0,0,3,4,1,4,1,1,2,0,0,2,0,1,4,1,0,0,1,2,3,1,0,1,0,0,4,1,4,0,0,0]

theorem envBound32877 : H12AffineFastState.Bounded env32877 := by
  intro p hp
  have h : env32877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32876_32877 : H12AffineEnvironment.transform 2 2 env32876 = env32877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env32876 == env32877) = true)

def env32878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830977,25265168,23160256,257,27378861,27337993,25207750]

theorem envBound32878 : H12AffineFastState.Bounded env32878 := by
  intro p hp
  have h : env32878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32655_32878 : H12AffineEnvironment.transform 18 1025 env32655 = env32878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env32655 == env32878) = true)

theorem identity32878 : scanCanonicalize (H12AffineFastState.compose env32878 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 272426) := by decide +kernel

theorem selectedBound32878 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env32879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,272426,8328,65,12838955,2469031,10507601,8830977,8760378,6639082,257,10873991,10816803,8686572]

theorem envBound32879 : H12AffineFastState.Bounded env32879 := by
  intro p hp
  have h : env32879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32878_32879 : H12AffineEnvironment.transform 23 272426 env32878 = env32879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 272426 env32878 == env32879) = true)

def env32880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,147592,272426,8328,65,4303011,2469031,2233817,295049,519346,6639082,257,2599951,2575787,445284]

theorem envBound32880 : H12AffineFastState.Bounded env32880 := by
  intro p hp
  have h : env32880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32879_32880 : H12AffineEnvironment.transform 22 147592 env32879 = env32880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147592 env32879 == env32880) = true)

def env32881 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,152,272426,8328,65,4303011,2469031,2119113,295049,371874,6639082,257,2485279,2428347,297844]

theorem envBound32881 : H12AffineFastState.Bounded env32881 := by
  intro p hp
  have h : env32881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32880_32881 : H12AffineEnvironment.transform 16 16400 env32880 = env32881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env32880 == env32881) = true)

theorem identity32881 : scanCanonicalize (H12AffineFastState.compose env32881 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound32881 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env32882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10400,1025,32769,2097152,4194304,152,138,8328,65,4303011,2196487,2119113,43049,99330,6382922,257,2213055,2172187,41940]

theorem envBound32882 : H12AffineFastState.Bounded env32882 := by
  intro p hp
  have h : env32882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32881_32882 : H12AffineEnvironment.transform 17 10400 env32881 = env32882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env32881 == env32882) = true)

def env32883 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,4194304,16,2,8192,65,4302891,2196487,2118977,43049,99330,6382922,257,2212919,2172187,41820]

theorem envBound32883 : H12AffineFastState.Bounded env32883 := by
  intro p hp
  have h : env32883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32882_32883 : H12AffineEnvironment.transform 6 8 env32882 = env32883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32882 == env32883) = true)

theorem identity32883 : scanCanonicalize (H12AffineFastState.compose env32883 (packedSelected [0,3,7,8,9,11,12,14,15,17,18,19,20,22,23,24,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound32883 : packedSelected [0,3,7,8,9,11,12,14,15,17,18,19,20,22,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env32884 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40971,16400,10280,1025,32769,2097152,4194304,16,2,8192,65,4196384,2106380,2118977,43049,9225,6341953,257,2122812,2131216,41820]

theorem envBound32884 : H12AffineFastState.Bounded env32884 := by
  intro p hp
  have h : env32884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32883_32884 : H12AffineEnvironment.transform 15 40971 env32883 = env32884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env32883 == env32884) = true)

theorem identity32884 : scanCanonicalize (H12AffineFastState.compose env32884 (packedSelected [0,1,2,3,5,6,11,12,14,15,16,19,20,23,27,28] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound32884 : packedSelected [0,1,2,3,5,6,11,12,14,15,16,19,20,23,27,28] rootPS < 2^1333 := by decide +kernel

def env32885 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,33111,16400,2420,1025,32769,2097152,4194304,16,2,348,65,4196384,2098512,2118977,35189,1365,6341953,257,2114912,2131216,33280]

theorem envBound32885 : H12AffineFastState.Bounded env32885 := by
  intro p hp
  have h : env32885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32884_32885 : H12AffineEnvironment.transform 12 348 env32884 = env32885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env32884 == env32885) = true)

theorem identity32885 : scanCanonicalize (H12AffineFastState.compose env32885 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(20+1) ^^^ 17729) := by decide +kernel

theorem selectedBound32885 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env32886 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,33111,16400,2420,1025,32769,17729,4194304,16,2,348,65,4196384,16401,4096,35189,1365,4227072,257,33,49233,33280]

theorem envBound32886 : H12AffineFastState.Bounded env32886 := by
  intro p hp
  have h : env32886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32885_32886 : H12AffineEnvironment.transform 20 17729 env32885 = env32886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env32885 == env32886) = true)

theorem identity32886 : scanCanonicalize (H12AffineFastState.compose env32886 (packedSelected [1,8,19] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound32886 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env32887 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,33111,16400,2420,1025,32769,17729,33,16,2,348,65,2049,16401,4096,35189,1365,32801,257,33,49233,33280]

theorem envBound32887 : H12AffineFastState.Bounded env32887 := by
  intro p hp
  have h : env32887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32886_32887 : H12AffineEnvironment.transform 21 33 env32886 = env32887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env32886 == env32887) = true)

theorem identity32887 : scanCanonicalize (H12AffineFastState.compose env32887 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21872) := by decide +kernel

theorem selectedBound32887 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env32888 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21872,21543,16400,2420,1025,21873,17729,33,16,2,348,65,2049,16401,4096,23557,1365,21841,257,33,5409,22384]

theorem envBound32888 : H12AffineFastState.Bounded env32888 := by
  intro p hp
  have h : env32888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32887_32888 : H12AffineEnvironment.transform 14 21872 env32887 = env32888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21872 env32887 == env32888) = true)

theorem identity32888 : scanCanonicalize (H12AffineFastState.compose env32888 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32888 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env32889 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,21792,21543,16400,2340,1025,21793,17681,33,16,2,268,17,2049,16401,4096,23557,1285,21761,257,33,5409,22304]

theorem envBound32889 : H12AffineFastState.Bounded env32889 := by
  intro p hp
  have h : env32889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32888_32889 : H12AffineEnvironment.transform 5 16 env32888 = env32889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32888 == env32889) = true)

theorem identity32889 : scanCanonicalize (H12AffineFastState.compose env32889 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(13+1) ^^^ 6715) := by decide +kernel

theorem selectedBound32889 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env32890 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,6715,3867,3612,6699,2340,1025,3866,7978,33,16,2,268,17,2049,6698,4096,1598,1285,3898,257,33,5409,3355]

theorem envBound32890 : H12AffineFastState.Bounded env32890 := by
  intro p hp
  have h : env32890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32889_32890 : H12AffineEnvironment.transform 13 6715 env32889 = env32890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6715 env32889 == env32890) = true)

theorem identity32890 : scanCanonicalize (H12AffineFastState.compose env32890 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1567) := by decide +kernel

theorem selectedBound32890 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env32891 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1567,4096,268,5156,260,3,5172,1851,1025,261,4405,33,16,2,268,17,1566,5173,4096,1598,1285,293,257,33,5409,772]

theorem envBound32891 : H12AffineFastState.Bounded env32891 := by
  intro p hp
  have h : env32891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32890_32891 : H12AffineEnvironment.transform 10 1567 env32890 = env32891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1567 env32890 == env32891) = true)

theorem identity32891 : scanCanonicalize (H12AffineFastState.compose env32891 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound32891 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env32892 : List Nat := [2,4,8,16,32,16,8,5,512,1024,1567,4096,9,5156,1,3,5172,1598,1025,0,4144,33,16,2,9,17,1566,5173,4096,1598,1024,32,4,33,5156,513]

theorem envBound32892 : H12AffineFastState.Bounded env32892 := by
  intro p hp
  have h : env32892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32891_32892 : H12AffineEnvironment.transform 7 5 env32891 = env32892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env32891 == env32892) = true)

theorem identity32892 : scanCanonicalize (H12AffineFastState.compose env32892 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound32892 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32893 : List Nat := [2,4,8,16,17,16,8,5,512,1024,1567,4096,9,5141,1,3,5125,1551,1025,0,4097,16,16,2,9,17,1566,5124,4096,1551,1024,17,4,16,5141,513]

theorem envBound32893 : H12AffineFastState.Bounded env32893 := by
  intro p hp
  have h : env32893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32892_32893 : H12AffineEnvironment.transform 4 17 env32892 = env32893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env32892 == env32893) = true)

theorem identity32893 : scanCanonicalize (H12AffineFastState.compose env32893 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound32893 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32894 : List Nat := [2,4,8,16,17,16,8,5,512,1024,1567,528,9,1541,1,3,1557,1551,1025,0,529,16,16,2,9,17,1566,1556,528,1551,1024,17,4,16,1541,513]

theorem envBound32894 : H12AffineFastState.Bounded env32894 := by
  intro p hp
  have h : env32894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32893_32894 : H12AffineEnvironment.transform 11 528 env32893 = env32894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env32893 == env32894) = true)

def env32895 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,2097152,4194304,17,3,8193,65,4302890,2196487,2118976,43049,99330,6382922,257,2212918,2172187,41821]

theorem envBound32895 : H12AffineFastState.Bounded env32895 := by
  intro p hp
  have h : env32895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32882_32895 : H12AffineEnvironment.transform 6 9 env32882 = env32895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32882 == env32895) = true)

theorem identity32895 : scanCanonicalize (H12AffineFastState.compose env32895 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound32895 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env32896 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10281,1025,8541,2097152,4194304,17,3,8193,65,4262262,2172251,2118976,2421,75102,6382922,257,2188650,2172187,513]

theorem envBound32896 : H12AffineFastState.Bounded env32896 := by
  intro p hp
  have h : env32896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32895_32896 : H12AffineEnvironment.transform 14 8540 env32895 = env32896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env32895 == env32896) = true)

theorem identity32896 : scanCanonicalize (H12AffineFastState.compose env32896 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound32896 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env32897 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16400,10281,1025,8541,2097152,4194304,17,3,8193,65,4204925,2098512,2118976,2421,1365,6309185,257,2114913,2098448,513]

theorem envBound32897 : H12AffineFastState.Bounded env32897 := by
  intro p hp
  have h : env32897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32896_32897 : H12AffineEnvironment.transform 15 8203 env32896 = env32897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env32896 == env32897) = true)

theorem identity32897 : scanCanonicalize (H12AffineFastState.compose env32897 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound32897 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32898 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4112,8540,8203,4096,10281,1025,8541,2097152,4194304,17,3,8193,65,4204925,2098512,2098512,2421,1365,6296913,257,2102641,2098448,513]

theorem envBound32898 : H12AffineFastState.Bounded env32898 := by
  intro p hp
  have h : env32898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32897_32898 : H12AffineEnvironment.transform 13 4112 env32897 = env32898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env32897 == env32898) = true)

theorem identity32898 : scanCanonicalize (H12AffineFastState.compose env32898 (packedSelected [4,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 2100577) := by decide +kernel

theorem selectedBound32898 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env32899 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4112,8540,8203,4096,10281,1025,8541,2097152,2100577,17,3,8193,65,2106396,2098512,2098512,2421,1365,6192,257,2102641,2098448,513]

theorem envBound32899 : H12AffineFastState.Bounded env32899 := by
  intro p hp
  have h : env32899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32898_32899 : H12AffineEnvironment.transform 21 2100577 env32898 = env32899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2100577 env32898 == env32899) = true)

theorem identity32899 : scanCanonicalize (H12AffineFastState.compose env32899 (packedSelected [0,7,14,18] rootPS)) = affineNative (2^(20+1) ^^^ 12392) := by decide +kernel

theorem selectedBound32899 : packedSelected [0,7,14,18] rootPS < 2^1333 := by decide +kernel

def env32900 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4112,8540,8203,4096,10281,1025,8541,12392,15625,17,3,8193,65,5236,13624,13624,2421,1365,6192,257,9497,13688,513]

theorem envBound32900 : H12AffineFastState.Bounded env32900 := by
  intro p hp
  have h : env32900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32899_32900 : H12AffineEnvironment.transform 20 12392 env32899 = env32900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12392 env32899 == env32900) = true)

theorem identity32900 : scanCanonicalize (H12AffineFastState.compose env32900 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound32900 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env32901 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1336,4112,1124,1331,4096,3345,1025,1125,5456,6193,17,3,1337,65,5236,4096,4096,2421,1365,6192,257,33,4160,513]

theorem envBound32901 : H12AffineFastState.Bounded env32901 := by
  intro p hp
  have h : env32901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32900_32901 : H12AffineEnvironment.transform 12 1336 env32900 = env32901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env32900 == env32901) = true)

theorem identity32901 : scanCanonicalize (H12AffineFastState.compose env32901 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound32901 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32902 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2113,1336,2129,1124,1331,2113,3345,1025,1125,3345,112,17,3,1337,65,3125,2113,2113,2421,1365,113,257,33,2049,513]

theorem envBound32902 : H12AffineFastState.Bounded env32902 := by
  intro p hp
  have h : env32902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32901_32902 : H12AffineEnvironment.transform 11 2113 env32901 = env32902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env32901 == env32902) = true)

theorem identity32902 : scanCanonicalize (H12AffineFastState.compose env32902 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound32902 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env32903 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,2113,349,2129,1,342,2113,2420,100,0,2420,112,17,3,348,65,2128,2113,2113,2421,304,113,257,33,2049,513]

theorem envBound32903 : H12AffineFastState.Bounded env32903 := by
  intro p hp
  have h : env32903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32902_32903 : H12AffineEnvironment.transform 9 101 env32902 = env32903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env32902 == env32903) = true)

theorem identity32903 : scanCanonicalize (H12AffineFastState.compose env32903 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32903 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env32904 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,2064,268,2048,1,263,2064,2341,53,0,2341,33,17,3,269,16,2049,2064,2064,2340,304,32,257,33,2049,513]

theorem envBound32904 : H12AffineFastState.Bounded env32904 := by
  intro p hp
  have h : env32904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32903_32904 : H12AffineEnvironment.transform 5 17 env32903 = env32904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32903 == env32904) = true)

theorem identity32904 : scanCanonicalize (H12AffineFastState.compose env32904 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound32904 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env32905 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2064,41,2048,1,34,2064,2048,53,0,2048,33,17,3,40,16,2049,2064,2064,2049,21,32,36,33,2049,513]

theorem envBound32905 : H12AffineFastState.Bounded env32905 := by
  intro p hp
  have h : env32905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32904_32905 : H12AffineEnvironment.transform 7 37 env32904 = env32905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env32904 == env32905) = true)

theorem identity32905 : scanCanonicalize (H12AffineFastState.compose env32905 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound32905 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32906 : List Nat := [2,4,8,16,32,17,9,37,512,52,48,32,41,48,1,34,32,48,53,0,48,33,17,3,40,16,49,32,32,49,21,32,36,33,49,513]

theorem envBound32906 : H12AffineFastState.Bounded env32906 := by
  intro p hp
  have h : env32906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32905_32906 : H12AffineEnvironment.transform 10 48 env32905 = env32906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env32905 == env32906) = true)

def leafEnv32906 : List Nat := [2,4,8,16,32,17,9,37,512,52,48,32,41,48,1,34,32,48,53,0,48,33,17,3,20,40,1,16,49,32,32,49,21,32,36,33,5,35,49,513,1,49,0]

def active32906 : List Nat := [0,1,2,3,4,8]

def tree32906 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood32906 : H12WitnessSearch.Good tree32906 := H12GlobalWitnessIndex.good

theorem leafIdentity32906 : H12AffineFastState.composeSystem env32906 rootObs = leafEnv32906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env32906 rootObs == leafEnv32906) = true)

theorem terminalChecked32906 : H12PackedTerminal.terminalCheckFast leafEnv32906 active32906 tree32906 = true := by decide +kernel

def env32907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,153,272426,8328,65,4303011,2469031,2119112,295049,371875,6639082,257,2485278,2428346,297845]

theorem envBound32907 : H12AffineFastState.Bounded env32907 := by
  intro p hp
  have h : env32907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32880_32907 : H12AffineEnvironment.transform 16 16401 env32880 = env32907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env32880 == env32907) = true)

theorem identity32907 : scanCanonicalize (H12AffineFastState.compose env32907 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32907 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env32908 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,17,272426,8192,65,4302891,2468911,2118976,294913,371755,6638946,257,2485278,2428210,297845]

theorem envBound32908 : H12AffineFastState.Bounded env32908 := by
  intro p hp
  have h : env32908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32907_32908 : H12AffineEnvironment.transform 6 8 env32907 = env32908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32907 == env32908) = true)

theorem identity32908 : scanCanonicalize (H12AffineFastState.compose env32908 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound32908 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env32909 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,4194304,17,41310,8192,65,4302891,2172251,2118976,2421,75103,6407190,257,2188650,2196550,513]

theorem envBound32909 : H12AffineFastState.Bounded env32909 := by
  intro p hp
  have h : env32909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32908_32909 : H12AffineEnvironment.transform 17 35188 env32908 = env32909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env32908 == env32909) = true)

theorem identity32909 : scanCanonicalize (H12AffineFastState.compose env32909 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound32909 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env32910 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,115734,4194304,17,41310,8192,65,4302891,57677,102742,2421,75103,4194304,257,41340,16464,513]

theorem envBound32910 : H12AffineFastState.Bounded env32910 := by
  intro p hp
  have h : env32910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32909_32910 : H12AffineEnvironment.transform 20 115734 env32909 = env32910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env32909 == env32910) = true)

theorem identity32910 : scanCanonicalize (H12AffineFastState.compose env32910 (packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound32910 : packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS < 2^1333 := by decide +kernel

def env32911 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10280,1025,8541,91466,4194304,17,2,8192,65,4262263,16401,77834,2421,75103,4194304,257,32,16464,513]

theorem envBound32911 : H12AffineFastState.Bounded env32911 := by
  intro p hp
  have h : env32911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32910_32911 : H12AffineEnvironment.transform 14 8540 env32910 = env32911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env32910 == env32911) = true)

theorem identity32911 : scanCanonicalize (H12AffineFastState.compose env32911 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound32911 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env32912 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8203,16401,10280,1025,8541,17729,4194304,17,2,8192,65,4204924,16401,4097,2421,1364,4194304,257,32,16464,513]

theorem envBound32912 : H12AffineFastState.Bounded env32912 := by
  intro p hp
  have h : env32912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32911_32912 : H12AffineEnvironment.transform 15 8203 env32911 = env32912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env32911 == env32912) = true)

theorem identity32912 : scanCanonicalize (H12AffineFastState.compose env32912 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32912 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32913 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,8203,16401,10280,1025,8460,17680,4194304,17,2,8192,16,4204845,16401,4097,2340,1285,4194304,257,32,16385,513]

theorem envBound32913 : H12AffineFastState.Bounded env32913 := by
  intro p hp
  have h : env32913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32912_32913 : H12AffineEnvironment.transform 5 17 env32912 = env32913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32912 == env32913) = true)

theorem identity32913 : scanCanonicalize (H12AffineFastState.compose env32913 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 15366) := by decide +kernel

theorem selectedBound32913 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env32914 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,15366,8461,8203,15383,10280,1025,8460,14614,4194304,17,2,8192,16,4204845,15383,4097,2340,1285,4194304,257,32,15367,513]

theorem envBound32914 : H12AffineFastState.Bounded env32914 := by
  intro p hp
  have h : env32914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32913_32914 : H12AffineEnvironment.transform 13 15366 env32913 = env32914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15366 env32913 == env32914) = true)

theorem identity32914 : scanCanonicalize (H12AffineFastState.compose env32914 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound32914 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32915 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,7435,0,262,7450,2341,1025,1,6171,4194304,17,2,269,16,4196384,7450,4097,2340,1285,4194304,257,32,7434,513]

theorem envBound32915 : H12AffineFastState.Bounded env32915 := by
  intro p hp
  have h : env32915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32914_32915 : H12AffineEnvironment.transform 12 269 env32914 = env32915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env32914 == env32915) = true)

theorem identity32915 : scanCanonicalize (H12AffineFastState.compose env32915 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 5141) := by decide +kernel

theorem selectedBound32915 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env32916 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,7435,0,262,7450,2341,1025,1,6171,5141,17,2,269,16,7221,7450,4097,2340,1285,5141,257,32,7434,513]

theorem envBound32916 : H12AffineFastState.Bounded env32916 := by
  intro p hp
  have h : env32916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32915_32916 : H12AffineEnvironment.transform 21 5141 env32915 = env32916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 5141 env32915 == env32916) = true)

theorem identity32916 : scanCanonicalize (H12AffineFastState.compose env32916 (packedSelected [1,3,12] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound32916 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env32917 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1077,269,2366,0,262,2351,2341,1025,1,3118,32,17,2,269,16,2048,2351,1076,2340,1285,32,257,32,2367,513]

theorem envBound32917 : H12AffineFastState.Bounded env32917 := by
  intro p hp
  have h : env32917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32916_32917 : H12AffineEnvironment.transform 11 1077 env32916 = env32917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env32916 == env32917) = true)

theorem identity32917 : scanCanonicalize (H12AffineFastState.compose env32917 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 270) := by decide +kernel

theorem selectedBound32917 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32918 : List Nat := [2,4,8,16,32,17,8,256,512,1024,270,1077,269,48,0,262,33,43,1025,1,1312,32,17,2,269,16,270,33,1076,42,1285,32,257,32,49,513]

theorem envBound32918 : H12AffineFastState.Bounded env32918 := by
  intro p hp
  have h : env32918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32917_32918 : H12AffineEnvironment.transform 10 270 env32917 = env32918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 270 env32917 == env32918) = true)

theorem identity32918 : scanCanonicalize (H12AffineFastState.compose env32918 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound32918 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32919 : List Nat := [2,4,8,16,32,17,8,20,512,1024,26,1077,25,48,0,18,33,43,1025,1,1076,32,17,2,25,16,26,33,1076,42,1041,32,21,32,49,513]

theorem envBound32919 : H12AffineFastState.Bounded env32919 := by
  intro p hp
  have h : env32919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32918_32919 : H12AffineEnvironment.transform 7 20 env32918 = env32919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env32918 == env32919) = true)

theorem identity32919 : scanCanonicalize (H12AffineFastState.compose env32919 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound32919 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env32920 : List Nat := [2,4,8,16,32,17,8,20,11,1024,26,1077,25,48,0,18,33,43,1025,1,1076,32,17,2,25,16,26,33,1076,42,1041,32,21,32,49,10]

theorem envBound32920 : H12AffineFastState.Bounded env32920 := by
  intro p hp
  have h : env32920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32919_32920 : H12AffineEnvironment.transform 8 11 env32919 = env32920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env32919 == env32920) = true)

theorem identity32920 : scanCanonicalize (H12AffineFastState.compose env32920 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound32920 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env32921 : List Nat := [2,4,8,12,32,13,8,8,11,1024,6,1065,5,44,0,14,33,43,1025,1,1064,32,13,2,5,12,6,33,1064,42,1037,32,9,32,45,10]

theorem envBound32921 : H12AffineFastState.Bounded env32921 := by
  intro p hp
  have h : env32921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32920_32921 : H12AffineEnvironment.transform 3 12 env32920 = env32921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env32920 == env32921) = true)

theorem identity32921 : scanCanonicalize (H12AffineFastState.compose env32921 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 2) := by decide +kernel

theorem selectedBound32921 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32922 : List Nat := [2,4,8,12,32,13,8,8,11,2,6,43,5,44,0,14,33,43,3,1,42,32,13,2,5,12,6,33,42,42,15,32,9,32,45,10]

theorem envBound32922 : H12AffineFastState.Bounded env32922 := by
  intro p hp
  have h : env32922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32921_32922 : H12AffineEnvironment.transform 9 2 env32921 = env32922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 2 env32921 == env32922) = true)

def env32923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,147593,272426,8328,65,4303010,2469031,2233816,295048,519347,6639082,257,2599950,2575786,445285]

theorem envBound32923 : H12AffineFastState.Bounded env32923 := by
  intro p hp
  have h : env32923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32879_32923 : H12AffineEnvironment.transform 22 147593 env32879 = env32923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147593 env32879 == env32923) = true)

def env32924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,153,272426,8328,65,4303010,2469031,2119112,295048,371875,6639082,257,2485278,2428346,297845]

theorem envBound32924 : H12AffineFastState.Bounded env32924 := by
  intro p hp
  have h : env32924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32923_32924 : H12AffineEnvironment.transform 16 16400 env32923 = env32924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env32923 == env32924) = true)

theorem identity32924 : scanCanonicalize (H12AffineFastState.compose env32924 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35324) := by decide +kernel

theorem selectedBound32924 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env32925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35324,1025,32769,2097152,4194304,153,41430,8328,65,4303010,2172251,2119112,2420,75103,6407190,257,2188770,2196550,649]

theorem envBound32925 : H12AffineFastState.Bounded env32925 := by
  intro p hp
  have h : env32925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32924_32925 : H12AffineEnvironment.transform 17 35324 env32924 = env32925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35324 env32924 == env32925) = true)

def env32926 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,2097152,4194304,17,41310,8192,65,4302890,2172251,2118976,2420,75103,6407190,257,2188650,2196550,513]

theorem envBound32926 : H12AffineFastState.Bounded env32926 := by
  intro p hp
  have h : env32926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32925_32926 : H12AffineEnvironment.transform 6 8 env32925 = env32926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32925 == env32926) = true)

theorem identity32926 : scanCanonicalize (H12AffineFastState.compose env32926 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound32926 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env32927 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,115734,4194304,17,41310,8192,65,4302890,57677,102742,2420,75103,4194304,257,41340,16464,513]

theorem envBound32927 : H12AffineFastState.Bounded env32927 := by
  intro p hp
  have h : env32927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32926_32927 : H12AffineEnvironment.transform 20 115734 env32926 = env32927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env32926 == env32927) = true)

def env32928 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,65536,16400,10588,1025,8233,91198,4194304,17,374,8192,65,4261890,16741,78206,2420,75103,4194304,257,340,16464,513]

theorem envBound32928 : H12AffineFastState.Bounded env32928 := by
  intro p hp
  have h : env32928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32927_32928 : H12AffineEnvironment.transform 14 8232 env32927 = env32928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env32927 == env32928) = true)

theorem identity32928 : scanCanonicalize (H12AffineFastState.compose env32928 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound32928 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env32929 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,343,16400,10588,1025,8233,25961,4194304,17,374,8192,65,4196693,16741,12329,2420,9224,4194304,257,340,16464,513]

theorem envBound32929 : H12AffineFastState.Bounded env32929 := by
  intro p hp
  have h : env32929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32928_32929 : H12AffineEnvironment.transform 15 343 env32928 = env32929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env32928 == env32929) = true)

theorem identity32929 : scanCanonicalize (H12AffineFastState.compose env32929 (packedSelected [1,3,5,8,10,11,18,19] rootPS)) = affineNative (2^(21+1) ^^^ 8201) := by decide +kernel

theorem selectedBound32929 : packedSelected [1,3,5,8,10,11,18,19] rootPS < 2^1333 := by decide +kernel

def env32930 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,343,16400,10588,1025,8233,25961,8201,17,374,8192,65,10588,16741,12329,2420,9224,8201,257,340,16464,513]

theorem envBound32930 : H12AffineFastState.Bounded env32930 := by
  intro p hp
  have h : env32930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32929_32930 : H12AffineEnvironment.transform 21 8201 env32929 = env32930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8201 env32929 == env32930) = true)

theorem identity32930 : scanCanonicalize (H12AffineFastState.compose env32930 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound32930 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env32931 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,372,343,16400,2048,1025,373,17461,341,17,374,348,65,2048,16741,4469,2420,1364,341,257,340,16464,513]

theorem envBound32931 : H12AffineFastState.Bounded env32931 := by
  intro p hp
  have h : env32931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32930_32931 : H12AffineEnvironment.transform 12 348 env32930 = env32931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env32930 == env32931) = true)

theorem identity32931 : scanCanonicalize (H12AffineFastState.compose env32931 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32931 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32932 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,292,263,16400,2048,1025,293,17461,261,17,294,268,17,2048,16693,4389,2340,1284,261,257,260,16384,513]

theorem envBound32932 : H12AffineFastState.Bounded env32932 := by
  intro p hp
  have h : env32932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32931_32932 : H12AffineEnvironment.transform 5 16 env32931 = env32932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32931 == env32932) = true)

theorem identity32932 : scanCanonicalize (H12AffineFastState.compose env32932 (packedSelected [2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound32932 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env32933 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,16384,0,35,16400,2048,1025,1,17461,33,17,2,40,17,2048,16401,4097,2048,1056,33,37,32,16384,513]

theorem envBound32933 : H12AffineFastState.Bounded env32933 := by
  intro p hp
  have h : env32933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32932_32933 : H12AffineEnvironment.transform 7 36 env32932 = env32933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env32932 == env32933) = true)

theorem identity32933 : scanCanonicalize (H12AffineFastState.compose env32933 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound32933 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32934 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5156,0,35,5172,2048,1025,1,4113,33,17,2,40,17,2048,5173,4097,2048,1056,33,37,32,5156,513]

theorem envBound32934 : H12AffineFastState.Bounded env32934 := by
  intro p hp
  have h : env32934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32933_32934 : H12AffineEnvironment.transform 13 5156 env32933 = env32934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env32933 == env32934) = true)

def env32935 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,40,1044,0,35,1028,2048,1025,1,33,33,17,2,40,17,2048,1029,49,2048,1056,33,37,32,1044,513]

theorem envBound32935 : H12AffineFastState.Bounded env32935 := by
  intro p hp
  have h : env32935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32934_32935 : H12AffineEnvironment.transform 11 48 env32934 = env32935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env32934 == env32935) = true)

theorem identity32935 : scanCanonicalize (H12AffineFastState.compose env32935 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound32935 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32936 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1044,48,40,1044,0,35,1028,1044,1025,1,33,33,17,2,40,17,1044,1029,49,1044,1056,33,37,32,1044,513]

theorem envBound32936 : H12AffineFastState.Bounded env32936 := by
  intro p hp
  have h : env32936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32935_32936 : H12AffineEnvironment.transform 10 1044 env32935 = env32936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env32935 == env32936) = true)

def env32937 : List Nat := [2,4,8,16,32,16,8,36,512,52,32,48,40,32,0,35,48,32,53,1,33,33,17,2,40,17,32,49,49,32,20,33,37,32,32,513]

theorem envBound32937 : H12AffineFastState.Bounded env32937 := by
  intro p hp
  have h : env32937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32936_32937 : H12AffineEnvironment.transform 9 52 env32936 = env32937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env32936 == env32937) = true)

def env32938 : List Nat := [2,4,8,16,32,16,8,36,512,53,33,48,40,33,0,35,49,33,52,1,33,33,17,2,40,17,33,48,49,33,21,33,37,32,33,513]

theorem envBound32938 : H12AffineFastState.Bounded env32938 := by
  intro p hp
  have h : env32938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32936_32938 : H12AffineEnvironment.transform 9 53 env32936 = env32938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env32936 == env32938) = true)

theorem identity32938 : scanCanonicalize (H12AffineFastState.compose env32938 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound32938 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32939 : List Nat := [2,4,8,16,32,16,8,36,43,53,33,48,40,33,0,35,49,33,52,1,33,33,17,2,40,17,33,48,49,33,21,33,37,32,33,42]

theorem envBound32939 : H12AffineFastState.Bounded env32939 := by
  intro p hp
  have h : env32939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32938_32939 : H12AffineEnvironment.transform 8 43 env32938 = env32939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env32938 == env32939) = true)

def leafEnv32939 : List Nat := [2,4,8,16,32,16,8,36,43,53,33,48,40,33,0,35,49,33,52,1,33,33,17,2,20,40,1,17,33,48,49,33,21,33,37,32,5,35,33,42,1,33,0]

def active32939 : List Nat := [0,1,2,3,4]

def tree32939 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood32939 : H12WitnessSearch.Good tree32939 := H12GlobalWitnessIndex.good

theorem leafIdentity32939 : H12AffineFastState.composeSystem env32939 rootObs = leafEnv32939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env32939 rootObs == leafEnv32939) = true)

theorem terminalChecked32939 : H12PackedTerminal.terminalCheckFast leafEnv32939 active32939 tree32939 = true := by decide +kernel

def env32940 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,40,1045,0,35,1029,2048,1025,1,32,33,17,2,40,17,2048,1028,48,2048,1056,33,37,32,1045,513]

theorem envBound32940 : H12AffineFastState.Bounded env32940 := by
  intro p hp
  have h : env32940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32934_32940 : H12AffineEnvironment.transform 11 49 env32934 = env32940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env32934 == env32940) = true)

theorem identity32940 : scanCanonicalize (H12AffineFastState.compose env32940 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound32940 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32941 : List Nat := [2,4,8,16,32,16,8,36,512,1024,32,49,40,1045,0,35,1029,32,1025,1,32,33,17,2,40,17,32,1028,48,32,1056,33,37,32,1045,513]

theorem envBound32941 : H12AffineFastState.Bounded env32941 := by
  intro p hp
  have h : env32941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32940_32941 : H12AffineEnvironment.transform 10 32 env32940 = env32941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env32940 == env32941) = true)

def env32942 : List Nat := [2,4,8,16,32,16,8,36,512,52,32,49,40,33,0,35,49,32,53,1,32,33,17,2,40,17,32,48,48,32,20,33,37,32,33,513]

theorem envBound32942 : H12AffineFastState.Bounded env32942 := by
  intro p hp
  have h : env32942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32941_32942 : H12AffineEnvironment.transform 9 52 env32941 = env32942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env32941 == env32942) = true)

def env32943 : List Nat := [2,4,8,16,32,16,8,36,512,53,32,49,40,32,0,35,48,32,52,1,32,33,17,2,40,17,32,49,48,32,21,33,37,32,32,513]

theorem envBound32943 : H12AffineFastState.Bounded env32943 := by
  intro p hp
  have h : env32943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32941_32943 : H12AffineEnvironment.transform 9 53 env32941 = env32943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env32941 == env32943) = true)

theorem identity32943 : scanCanonicalize (H12AffineFastState.compose env32943 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound32943 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32944 : List Nat := [2,4,8,16,32,16,8,36,42,53,32,49,40,32,0,35,48,32,52,1,32,33,17,2,40,17,32,49,48,32,21,33,37,32,32,43]

theorem envBound32944 : H12AffineFastState.Bounded env32944 := by
  intro p hp
  have h : env32944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32943_32944 : H12AffineEnvironment.transform 8 42 env32943 = env32944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env32943 == env32944) = true)

def leafEnv32944 : List Nat := [2,4,8,16,32,16,8,36,42,53,32,49,40,32,0,35,48,32,52,1,32,33,17,2,20,40,1,17,32,49,48,32,21,33,37,32,5,35,32,43,1,32,0]

def active32944 : List Nat := [0,1,2,3,4]

def tree32944 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood32944 : H12WitnessSearch.Good tree32944 := H12GlobalWitnessIndex.good

theorem leafIdentity32944 : H12AffineFastState.composeSystem env32944 rootObs = leafEnv32944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env32944 rootObs == leafEnv32944) = true)

theorem terminalChecked32944 : H12PackedTerminal.terminalCheckFast leafEnv32944 active32944 tree32944 = true := by decide +kernel

def env32945 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,65536,16400,10589,1025,8232,91199,4194304,17,375,8192,65,4261891,16740,78207,2420,75103,4194304,257,341,16464,513]

theorem envBound32945 : H12AffineFastState.Bounded env32945 := by
  intro p hp
  have h : env32945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32927_32945 : H12AffineEnvironment.transform 14 8233 env32927 = env32945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env32927 == env32945) = true)

theorem identity32945 : scanCanonicalize (H12AffineFastState.compose env32945 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound32945 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env32946 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,34,16400,10589,1025,8232,25629,4194304,17,375,8192,65,4196385,16740,12637,2420,9597,4194304,257,341,16464,513]

theorem envBound32946 : H12AffineFastState.Bounded env32946 := by
  intro p hp
  have h : env32946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32945_32946 : H12AffineEnvironment.transform 15 34 env32945 = env32946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env32945 == env32946) = true)

theorem identity32946 : scanCanonicalize (H12AffineFastState.compose env32946 (packedSelected [1,2,5,6,8,24] rootPS)) = affineNative (2^(21+1) ^^^ 8280) := by decide +kernel

theorem selectedBound32946 : packedSelected [1,2,5,6,8,24] rootPS < 2^1333 := by decide +kernel

def env32947 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,34,16400,10589,1025,8232,25629,8280,17,375,8192,65,10361,16740,12637,2420,9597,8280,257,341,16464,513]

theorem envBound32947 : H12AffineFastState.Bounded env32947 := by
  intro p hp
  have h : env32947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32946_32947 : H12AffineEnvironment.transform 21 8280 env32946 = env32947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8280 env32946 == env32947) = true)

theorem identity32947 : scanCanonicalize (H12AffineFastState.compose env32947 (packedSelected [4,7,9,27] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound32947 : packedSelected [4,7,9,27] rootPS < 2^1333 := by decide +kernel

def env32948 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8233,34,16400,10280,1025,8232,25629,8280,17,2,8192,65,10361,16401,12328,2049,9224,8280,116,32,16464,513]

theorem envBound32948 : H12AffineFastState.Bounded env32948 := by
  intro p hp
  have h : env32948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32947_32948 : H12AffineEnvironment.transform 7 117 env32947 = env32948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env32947 == env32948) = true)

theorem identity32948 : scanCanonicalize (H12AffineFastState.compose env32948 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32948 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32949 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,16384,8233,34,16400,10280,1025,8232,25629,8200,17,2,8192,17,10281,16401,12328,2049,9224,8200,36,32,16384,513]

theorem envBound32949 : H12AffineFastState.Bounded env32949 := by
  intro p hp
  have h : env32949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32948_32949 : H12AffineEnvironment.transform 5 16 env32948 = env32949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32948 == env32949) = true)

theorem identity32949 : scanCanonicalize (H12AffineFastState.compose env32949 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound32949 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32950 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,13325,8233,34,13341,10280,1025,8232,4112,8200,17,2,8192,17,10281,13340,12328,2049,9224,8200,36,32,13325,513]

theorem envBound32950 : H12AffineFastState.Bounded env32950 := by
  intro p hp
  have h : env32950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32949_32950 : H12AffineEnvironment.transform 13 13325 env32949 = env32950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env32949 == env32950) = true)

theorem identity32950 : scanCanonicalize (H12AffineFastState.compose env32950 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound32950 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32951 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,41,5156,0,34,5172,2049,1025,1,4112,33,17,2,41,17,2048,5173,4097,2049,1057,33,36,32,5156,513]

theorem envBound32951 : H12AffineFastState.Bounded env32951 := by
  intro p hp
  have h : env32951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32950_32951 : H12AffineEnvironment.transform 12 41 env32950 = env32951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env32950 == env32951) = true)

def env32952 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,48,41,1044,0,34,1028,2049,1025,1,32,33,17,2,41,17,2048,1029,49,2049,1057,33,36,32,1044,513]

theorem envBound32952 : H12AffineFastState.Bounded env32952 := by
  intro p hp
  have h : env32952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32951_32952 : H12AffineEnvironment.transform 11 48 env32951 = env32952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env32951 == env32952) = true)

theorem identity32952 : scanCanonicalize (H12AffineFastState.compose env32952 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound32952 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32953 : List Nat := [2,4,8,16,32,16,8,37,49,1024,2048,48,41,1044,0,34,1028,2049,1025,1,32,33,17,2,41,17,2048,1029,49,2049,1057,33,36,32,1044,48]

theorem envBound32953 : H12AffineFastState.Bounded env32953 := by
  intro p hp
  have h : env32953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32952_32953 : H12AffineEnvironment.transform 8 49 env32952 = env32953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env32952 == env32953) = true)

def env32954 : List Nat := [2,4,8,16,32,16,8,37,49,52,2048,48,41,32,0,34,48,2049,53,1,32,33,17,2,41,17,2048,49,49,2049,21,33,36,32,32,48]

theorem envBound32954 : H12AffineFastState.Bounded env32954 := by
  intro p hp
  have h : env32954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32953_32954 : H12AffineEnvironment.transform 9 52 env32953 = env32954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env32953 == env32954) = true)

def env32955 : List Nat := [2,4,8,16,32,16,8,37,49,53,2048,48,41,33,0,34,49,2049,52,1,32,33,17,2,41,17,2048,48,49,2049,20,33,36,32,33,48]

theorem envBound32955 : H12AffineFastState.Bounded env32955 := by
  intro p hp
  have h : env32955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32953_32955 : H12AffineEnvironment.transform 9 53 env32953 = env32955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env32953 == env32955) = true)

theorem identity32955 : scanCanonicalize (H12AffineFastState.compose env32955 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound32955 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32956 : List Nat := [2,4,8,11,32,11,8,37,42,46,2048,43,41,33,0,34,42,2049,47,1,32,33,10,2,41,10,2048,43,42,2049,15,33,36,32,33,43]

theorem envBound32956 : H12AffineFastState.Bounded env32956 := by
  intro p hp
  have h : env32956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32955_32956 : H12AffineEnvironment.transform 3 11 env32955 = env32956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env32955 == env32956) = true)

def leafEnv32956 : List Nat := [2,4,8,11,32,11,8,37,42,46,2048,43,41,33,0,34,42,2049,47,1,32,33,10,2,14,41,1,10,2048,43,42,2049,15,33,36,32,5,34,33,43,1,32,0]

def active32956 : List Nat := [0,1,2,4,10]

def tree32956 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood32956 : H12WitnessSearch.Good tree32956 := H12GlobalWitnessIndex.good

theorem leafIdentity32956 : H12AffineFastState.composeSystem env32956 rootObs = leafEnv32956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env32956 rootObs == leafEnv32956) = true)

theorem terminalChecked32956 : H12PackedTerminal.terminalCheckFast leafEnv32956 active32956 tree32956 = true := by decide +kernel

def env32957 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,49,41,1045,0,34,1029,2049,1025,1,33,33,17,2,41,17,2048,1028,48,2049,1057,33,36,32,1045,513]

theorem envBound32957 : H12AffineFastState.Bounded env32957 := by
  intro p hp
  have h : env32957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32951_32957 : H12AffineEnvironment.transform 11 49 env32951 = env32957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env32951 == env32957) = true)

theorem identity32957 : scanCanonicalize (H12AffineFastState.compose env32957 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound32957 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32958 : List Nat := [2,4,8,16,32,16,8,37,512,517,2048,49,41,528,0,34,512,2049,516,1,33,33,17,2,41,17,2048,513,48,2049,548,33,36,32,528,513]

theorem envBound32958 : H12AffineFastState.Bounded env32958 := by
  intro p hp
  have h : env32958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32957_32958 : H12AffineEnvironment.transform 9 517 env32957 = env32958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env32957 == env32958) = true)

def env32959 : List Nat := [2,4,8,16,32,16,8,37,48,53,2048,49,41,32,0,34,48,2049,52,1,33,33,17,2,41,17,2048,49,48,2049,20,33,36,32,32,49]

theorem envBound32959 : H12AffineFastState.Bounded env32959 := by
  intro p hp
  have h : env32959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32958_32959 : H12AffineEnvironment.transform 8 48 env32958 = env32959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env32958 == env32959) = true)

theorem identity32959 : scanCanonicalize (H12AffineFastState.compose env32959 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound32959 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32960 : List Nat := [2,4,8,11,32,11,8,37,43,46,2048,42,41,32,0,34,43,2049,47,1,33,33,10,2,41,10,2048,42,43,2049,15,33,36,32,32,42]

theorem envBound32960 : H12AffineFastState.Bounded env32960 := by
  intro p hp
  have h : env32960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32959_32960 : H12AffineEnvironment.transform 3 11 env32959 = env32960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env32959 == env32960) = true)

def leafEnv32960 : List Nat := [2,4,8,11,32,11,8,37,43,46,2048,42,41,32,0,34,43,2049,47,1,33,33,10,2,14,41,1,10,2048,42,43,2049,15,33,36,32,5,34,32,42,1,33,0]

def active32960 : List Nat := [0,1,2,4,10]

def tree32960 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood32960 : H12WitnessSearch.Good tree32960 := H12GlobalWitnessIndex.good

theorem leafIdentity32960 : H12AffineFastState.composeSystem env32960 rootObs = leafEnv32960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env32960 rootObs == leafEnv32960) = true)

theorem terminalChecked32960 : H12PackedTerminal.terminalCheckFast leafEnv32960 active32960 tree32960 = true := by decide +kernel

def env32961 : List Nat := [2,4,8,16,32,16,8,37,49,52,2048,49,41,33,0,34,49,2049,53,1,33,33,17,2,41,17,2048,48,48,2049,21,33,36,32,33,48]

theorem envBound32961 : H12AffineFastState.Bounded env32961 := by
  intro p hp
  have h : env32961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32958_32961 : H12AffineEnvironment.transform 8 49 env32958 = env32961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env32958 == env32961) = true)

def env32962 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,2097152,4194304,16,41311,8193,65,4302891,2172251,2118977,2420,75103,6407190,257,2188651,2196550,512]

theorem envBound32962 : H12AffineFastState.Bounded env32962 := by
  intro p hp
  have h : env32962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32925_32962 : H12AffineEnvironment.transform 6 9 env32925 = env32962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32925 == env32962) = true)

theorem identity32962 : scanCanonicalize (H12AffineFastState.compose env32962 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 17461) := by decide +kernel

theorem selectedBound32962 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env32963 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,17461,4194304,16,41311,8193,65,4302891,90478,4468,2420,75103,4292643,257,74078,114803,512]

theorem envBound32963 : H12AffineFastState.Bounded env32963 := by
  intro p hp
  have h : env32963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32962_32963 : H12AffineEnvironment.transform 20 17461 env32962 = env32963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17461 env32962 == env32963) = true)

theorem identity32963 : scanCanonicalize (H12AffineFastState.compose env32963 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8572) := by decide +kernel

theorem selectedBound32963 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env32964 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8572,65536,16400,10249,1025,8573,17461,4194304,16,35,8193,65,4262231,90478,4468,2420,75103,4268383,257,74078,90383,512]

theorem envBound32964 : H12AffineFastState.Bounded env32964 := by
  intro p hp
  have h : env32964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32963_32964 : H12AffineEnvironment.transform 14 8572 env32963 = env32964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8572 env32963 == env32964) = true)

theorem identity32964 : scanCanonicalize (H12AffineFastState.compose env32964 (packedSelected [1,3,5,8,9,10,14,17,19,22] rootPS)) = affineNative (2^(21+1) ^^^ 0) := by decide +kernel

theorem selectedBound32964 : packedSelected [1,3,5,8,9,10,14,17,19,22] rootPS < 2^1333 := by decide +kernel

def env32965 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8572,65536,16400,10249,1025,8573,17461,0,16,35,8193,65,67927,90478,4468,2420,75103,74079,257,74078,90383,512]

theorem envBound32965 : H12AffineFastState.Bounded env32965 := by
  intro p hp
  have h : env32965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32964_32965 : H12AffineEnvironment.transform 21 0 env32964 = env32965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 0 env32964 == env32965) = true)

theorem identity32965 : scanCanonicalize (H12AffineFastState.compose env32965 (packedSelected [3,5,6,10,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound32965 : packedSelected [3,5,6,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env32966 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8572,262,16400,10249,1025,8573,17461,0,16,35,8193,65,2129,24680,4468,2420,9305,8281,257,8280,24585,512]

theorem envBound32966 : H12AffineFastState.Bounded env32966 := by
  intro p hp
  have h : env32966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32965_32966 : H12AffineEnvironment.transform 15 262 env32965 = env32966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env32965 == env32966) = true)

theorem identity32966 : scanCanonicalize (H12AffineFastState.compose env32966 (packedSelected [0,2,4,6,7,9,14,17] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound32966 : packedSelected [0,2,4,6,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env32967 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,8572,262,5220,10249,1025,8573,4161,0,16,35,8193,65,2129,13340,4468,2420,9305,8281,257,8280,13437,512]

theorem envBound32967 : H12AffineFastState.Bounded env32967 := by
  intro p hp
  have h : env32967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32966_32967 : H12AffineEnvironment.transform 13 5236 env32966 = env32967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env32966 == env32967) = true)

theorem identity32967 : scanCanonicalize (H12AffineFastState.compose env32967 (packedSelected [1,3,5,6,8,10,14,19] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound32967 : packedSelected [1,3,5,6,8,10,14,19] rootPS < 2^1333 := by decide +kernel

def env32968 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,301,5236,81,262,5220,2340,1025,80,4161,0,16,35,300,65,2129,5425,4468,2420,1396,372,257,373,5456,512]

theorem envBound32968 : H12AffineFastState.Bounded env32968 := by
  intro p hp
  have h : env32968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32967_32968 : H12AffineEnvironment.transform 12 301 env32967 = env32968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env32967 == env32968) = true)

theorem identity32968 : scanCanonicalize (H12AffineFastState.compose env32968 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound32968 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env32969 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,268,5205,81,262,5189,2309,1025,80,4161,0,16,2,269,65,2129,5392,4437,2389,1365,341,257,340,5456,512]

theorem envBound32969 : H12AffineFastState.Bounded env32969 := by
  intro p hp
  have h : env32969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32968_32969 : H12AffineEnvironment.transform 4 1 env32968 = env32969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env32968 == env32969) = true)

theorem identity32969 : scanCanonicalize (H12AffineFastState.compose env32969 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound32969 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32970 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,4096,88,5205,81,82,5189,2129,1025,80,4161,0,16,2,89,65,2129,5188,4097,2049,1025,1,85,0,5124,512]

theorem envBound32970 : H12AffineFastState.Bounded env32970 := by
  intro p hp
  have h : env32970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32969_32970 : H12AffineEnvironment.transform 7 84 env32969 = env32970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env32969 == env32970) = true)

theorem identity32970 : scanCanonicalize (H12AffineFastState.compose env32970 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound32970 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env32971 : List Nat := [2,4,8,16,1,64,9,84,512,20,2048,4096,88,4161,81,82,4177,2129,21,80,4161,0,16,2,89,65,2129,4176,4097,2049,21,1,85,0,4112,512]

theorem envBound32971 : H12AffineFastState.Bounded env32971 := by
  intro p hp
  have h : env32971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32970_32971 : H12AffineEnvironment.transform 9 20 env32970 = env32971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env32970 == env32971) = true)

theorem identity32971 : scanCanonicalize (H12AffineFastState.compose env32971 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound32971 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32972 : List Nat := [2,4,8,16,1,64,9,84,64,20,2048,4096,88,4161,81,82,4177,2129,21,80,4161,0,16,2,89,65,2129,4176,4097,2049,21,1,85,0,4112,64]

theorem envBound32972 : H12AffineFastState.Bounded env32972 := by
  intro p hp
  have h : env32972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32971_32972 : H12AffineEnvironment.transform 8 64 env32971 = env32972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env32971 == env32972) = true)

theorem identity32972 : scanCanonicalize (H12AffineFastState.compose env32972 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound32972 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32973 : List Nat := [2,4,8,16,1,64,9,84,64,20,2048,65,88,0,81,82,16,2129,21,80,0,0,16,2,89,65,2129,17,64,2049,21,1,85,0,81,64]

theorem envBound32973 : H12AffineFastState.Bounded env32973 := by
  intro p hp
  have h : env32973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32972_32973 : H12AffineEnvironment.transform 11 65 env32972 = env32973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env32972 == env32973) = true)

theorem identity32973 : scanCanonicalize (H12AffineFastState.compose env32973 (packedSelected [1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound32973 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env32974 : List Nat := [2,4,8,16,1,64,9,84,64,20,81,65,88,0,81,82,16,0,21,80,0,0,16,2,89,65,0,17,64,80,21,1,85,0,81,64]

theorem envBound32974 : H12AffineFastState.Bounded env32974 := by
  intro p hp
  have h : env32974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32973_32974 : H12AffineEnvironment.transform 10 81 env32973 = env32974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env32973 == env32974) = true)

theorem identity32974 : scanCanonicalize (H12AffineFastState.compose env32974 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32974 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env32975 : List Nat := [2,4,8,16,1,17,9,5,17,20,0,16,9,0,0,3,16,0,21,1,0,0,16,2,8,16,0,17,17,1,21,1,4,0,0,17]

theorem envBound32975 : H12AffineFastState.Bounded env32975 := by
  intro p hp
  have h : env32975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32974_32975 : H12AffineEnvironment.transform 5 17 env32974 = env32975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32974 == env32975) = true)

theorem identity32975 : scanCanonicalize (H12AffineFastState.compose env32975 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound32975 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32976 : List Nat := [2,4,7,16,1,17,6,5,17,20,0,16,6,0,0,3,16,0,21,1,0,0,16,2,7,16,0,17,17,1,21,1,4,0,0,17]

theorem envBound32976 : H12AffineFastState.Bounded env32976 := by
  intro p hp
  have h : env32976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32975_32976 : H12AffineEnvironment.transform 2 7 env32975 = env32976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env32975 == env32976) = true)

def env32977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,152,272426,8328,65,4303010,2469031,2119113,295048,371874,6639082,257,2485279,2428347,297844]

theorem envBound32977 : H12AffineFastState.Bounded env32977 := by
  intro p hp
  have h : env32977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32923_32977 : H12AffineEnvironment.transform 16 16401 env32923 = env32977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env32923 == env32977) = true)

theorem identity32977 : scanCanonicalize (H12AffineFastState.compose env32977 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound32977 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env32978 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,16401,262144,1025,8660,2097152,4194304,152,272426,8328,65,4262263,2428274,2119113,270685,331127,6639082,257,2444746,2428347,273057]

theorem envBound32978 : H12AffineFastState.Bounded env32978 := by
  intro p hp
  have h : env32978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32977_32978 : H12AffineEnvironment.transform 14 8661 env32977 = env32978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env32977 == env32978) = true)

def env32979 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,16401,10400,1025,8660,2097152,4194304,152,138,8328,65,4262263,2172370,2119113,2557,75223,6382922,257,2188650,2172187,513]

theorem envBound32979 : H12AffineFastState.Bounded env32979 := by
  intro p hp
  have h : env32979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32978_32979 : H12AffineEnvironment.transform 17 10400 env32978 = env32979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env32978 == env32979) = true)

theorem identity32979 : scanCanonicalize (H12AffineFastState.compose env32979 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound32979 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env32980 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8202,16401,10400,1025,8660,2097152,4194304,152,138,8328,65,4204925,2098648,2119113,2557,1501,6309184,257,2114912,2098449,513]

theorem envBound32980 : H12AffineFastState.Bounded env32980 := by
  intro p hp
  have h : env32980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32979_32980 : H12AffineEnvironment.transform 15 8202 env32979 = env32980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env32979 == env32980) = true)

theorem identity32980 : scanCanonicalize (H12AffineFastState.compose env32980 (packedSelected [0,3,5,10,14,17,27] rootPS)) = affineNative (2^(21+1) ^^^ 2114912) := by decide +kernel

theorem selectedBound32980 : packedSelected [0,3,5,10,14,17,27] rootPS < 2^1333 := by decide +kernel

def env32981 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8202,16401,10400,1025,8660,2097152,2114912,152,138,8328,65,2124829,2098648,2119113,2557,1501,32,257,2114912,2098449,513]

theorem envBound32981 : H12AffineFastState.Bounded env32981 := by
  intro p hp
  have h : env32981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32980_32981 : H12AffineEnvironment.transform 21 2114912 env32980 = env32981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114912 env32980 == env32981) = true)

theorem identity32981 : scanCanonicalize (H12AffineFastState.compose env32981 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 17864) := by decide +kernel

theorem selectedBound32981 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32982 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8202,16401,10400,1025,8660,17864,168,152,138,8328,65,10709,16400,4097,2557,1501,32,257,168,16601,513]

theorem envBound32982 : H12AffineFastState.Bounded env32982 := by
  intro p hp
  have h : env32982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32981_32982 : H12AffineEnvironment.transform 20 17864 env32981 = env32982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17864 env32981 == env32982) = true)

theorem identity32982 : scanCanonicalize (H12AffineFastState.compose env32982 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound32982 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env32983 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,136,343,16401,2557,1025,137,17864,168,152,138,469,65,2184,16400,4097,2557,1501,32,257,168,16601,513]

theorem envBound32983 : H12AffineFastState.Bounded env32983 := by
  intro p hp
  have h : env32983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32982_32983 : H12AffineEnvironment.transform 12 349 env32982 = env32983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env32982 == env32983) = true)

theorem identity32983 : scanCanonicalize (H12AffineFastState.compose env32983 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound32983 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env32984 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,1,343,16401,2420,1025,0,17729,33,17,3,348,65,2049,16400,4097,2420,1364,32,257,33,16464,513]

theorem envBound32984 : H12AffineFastState.Bounded env32984 := by
  intro p hp
  have h : env32984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32983_32984 : H12AffineEnvironment.transform 6 9 env32983 = env32984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32983 == env32984) = true)

theorem identity32984 : scanCanonicalize (H12AffineFastState.compose env32984 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 820) := by decide +kernel

theorem selectedBound32984 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32985 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,820,349,16384,1,343,16401,2420,1025,0,17729,33,17,3,348,65,2049,16400,821,2420,1364,32,257,33,16464,513]

theorem envBound32985 : H12AffineFastState.Bounded env32985 := by
  intro p hp
  have h : env32985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32984_32985 : H12AffineEnvironment.transform 11 820 env32984 = env32985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 820 env32984 == env32985) = true)

theorem identity32985 : scanCanonicalize (H12AffineFastState.compose env32985 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 3328) := by decide +kernel

theorem selectedBound32985 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32986 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,820,349,3328,1,343,3345,2420,1025,0,2113,33,17,3,348,65,2049,3344,821,2420,1364,32,257,33,3408,513]

theorem envBound32986 : H12AffineFastState.Bounded env32986 := by
  intro p hp
  have h : env32986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32985_32986 : H12AffineEnvironment.transform 13 3328 env32985 = env32986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3328 env32985 == env32986) = true)

theorem identity32986 : scanCanonicalize (H12AffineFastState.compose env32986 (packedSelected [2,4,9] rootPS)) = affineNative (2^(10+1) ^^^ 608) := by decide +kernel

theorem selectedBound32986 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env32987 : List Nat := [2,4,8,16,32,64,9,256,512,1024,608,820,349,1888,1,343,1905,788,1025,0,545,33,17,3,348,65,609,1904,821,788,1364,32,257,33,1840,513]

theorem envBound32987 : H12AffineFastState.Bounded env32987 := by
  intro p hp
  have h : env32987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32986_32987 : H12AffineEnvironment.transform 10 608 env32986 = env32987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 608 env32986 == env32987) = true)

theorem identity32987 : scanCanonicalize (H12AffineFastState.compose env32987 (packedSelected [1,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound32987 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env32988 : List Nat := [2,4,8,16,32,64,9,256,512,69,608,820,349,805,1,343,820,788,68,0,545,33,17,3,348,65,609,821,821,788,273,32,257,33,885,513]

theorem envBound32988 : H12AffineFastState.Bounded env32988 := by
  intro p hp
  have h : env32988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32987_32988 : H12AffineEnvironment.transform 9 69 env32987 = env32988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env32987 == env32988) = true)

theorem identity32988 : scanCanonicalize (H12AffineFastState.compose env32988 (packedSelected [2,4,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound32988 : packedSelected [2,4,8] rootPS < 2^1333 := by decide +kernel

def env32989 : List Nat := [2,4,8,0,32,64,9,256,512,69,608,804,333,805,1,327,804,772,68,0,545,33,1,3,332,65,609,805,805,772,257,32,257,33,869,513]

theorem envBound32989 : H12AffineFastState.Bounded env32989 := by
  intro p hp
  have h : env32989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32988_32989 : H12AffineEnvironment.transform 3 0 env32988 = env32989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env32988 == env32989) = true)

theorem identity32989 : scanCanonicalize (H12AffineFastState.compose env32989 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound32989 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env32990 : List Nat := [2,4,8,0,32,64,9,100,512,69,608,576,41,577,1,35,576,608,68,0,545,33,1,3,40,65,609,577,577,608,101,32,101,33,513,513]

theorem envBound32990 : H12AffineFastState.Bounded env32990 := by
  intro p hp
  have h : env32990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32989_32990 : H12AffineEnvironment.transform 7 100 env32989 = env32990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env32989 == env32990) = true)

theorem identity32990 : scanCanonicalize (H12AffineFastState.compose env32990 (packedSelected [0,1,2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound32990 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env32991 : List Nat := [2,4,8,0,32,0,9,36,512,5,544,512,41,513,1,35,512,544,4,0,545,33,1,3,40,1,545,513,513,544,37,32,37,33,513,513]

theorem envBound32991 : H12AffineFastState.Bounded env32991 := by
  intro p hp
  have h : env32991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32990_32991 : H12AffineEnvironment.transform 5 0 env32990 = env32991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env32990 == env32991) = true)

theorem identity32991 : scanCanonicalize (H12AffineFastState.compose env32991 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound32991 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32992 : List Nat := [2,4,8,0,32,0,9,36,0,5,32,0,41,1,1,35,0,32,4,0,33,33,1,3,40,1,33,1,1,32,37,32,37,33,1,1]

theorem envBound32992 : H12AffineFastState.Bounded env32992 := by
  intro p hp
  have h : env32992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32991_32992 : H12AffineEnvironment.transform 8 0 env32991 = env32992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env32991 == env32992) = true)

theorem identity32992 : scanCanonicalize (H12AffineFastState.compose env32992 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

end H12CloudChart0