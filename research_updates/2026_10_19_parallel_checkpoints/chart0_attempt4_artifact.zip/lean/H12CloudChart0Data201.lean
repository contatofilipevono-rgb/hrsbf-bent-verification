import H12CloudChart0Data200

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans50897_50898 : H12AffineEnvironment.transform 4 0 env50897 = env50898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50897 == env50898) = true)

theorem identity50898 : scanCanonicalize (H12AffineFastState.compose env50898 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound50898 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50899 : List Nat := [2,4,8,16,0,16,9,4,512,21,523,16,9,1,0,3,16,522,21,1,0,1,17,3,8,17,523,17,17,522,20,1,4,0,1,513]

theorem envBound50899 : H12AffineFastState.Bounded env50899 := by
  intro p hp
  have h : env50899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50898_50899 : H12AffineEnvironment.transform 10 523 env50898 = env50899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env50898 == env50899) = true)

def leafEnv50899 : List Nat := [2,4,8,16,0,16,9,4,512,21,523,16,9,1,0,3,16,522,21,1,0,1,17,3,20,8,1,17,523,17,17,522,20,1,4,0,4,2,1,513,1,0,0]

def active50899 : List Nat := [0,1,2,3,8]

def tree50899 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50899 : H12WitnessSearch.Good tree50899 := H12GlobalWitnessIndex.good

theorem leafIdentity50899 : H12AffineFastState.composeSystem env50899 rootObs = leafEnv50899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50899 rootObs == leafEnv50899) = true)

theorem terminalChecked50899 : H12PackedTerminal.terminalCheckFast leafEnv50899 active50899 tree50899 = true := by decide +kernel

def env50900 : List Nat := [2,4,8,16,1,16,9,5,512,21,2048,17,8,1,0,2,16,2049,21,1,1,0,17,3,9,17,2048,17,16,2049,21,0,5,1,1,513]

theorem envBound50900 : H12AffineFastState.Bounded env50900 := by
  intro p hp
  have h : env50900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50897_50900 : H12AffineEnvironment.transform 4 1 env50897 = env50900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50897 == env50900) = true)

theorem identity50900 : scanCanonicalize (H12AffineFastState.compose env50900 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound50900 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50901 : List Nat := [2,4,8,16,1,16,9,5,512,21,1,17,8,1,0,2,16,0,21,1,1,0,17,3,9,17,1,17,16,0,21,0,5,1,1,513]

theorem envBound50901 : H12AffineFastState.Bounded env50901 := by
  intro p hp
  have h : env50901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50900_50901 : H12AffineEnvironment.transform 10 1 env50900 = env50901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env50900 == env50901) = true)

def leafEnv50901 : List Nat := [2,4,8,16,1,16,9,5,512,21,1,17,8,1,0,2,16,0,21,1,1,0,17,3,21,9,1,17,1,17,16,0,21,0,5,1,4,3,1,513,1,1,0]

def active50901 : List Nat := [0,1,2,3,8]

def tree50901 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50901 : H12WitnessSearch.Good tree50901 := H12GlobalWitnessIndex.good

theorem leafIdentity50901 : H12AffineFastState.composeSystem env50901 rootObs = leafEnv50901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50901 rootObs == leafEnv50901) = true)

theorem terminalChecked50901 : H12PackedTerminal.terminalCheckFast leafEnv50901 active50901 tree50901 = true := by decide +kernel

def env50902 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,49,41,1045,0,35,1028,2049,1024,1,33,33,17,3,40,17,2048,1029,48,2049,1057,33,36,32,1045,513]

theorem envBound50902 : H12AffineFastState.Bounded env50902 := by
  intro p hp
  have h : env50902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50895_50902 : H12AffineEnvironment.transform 11 49 env50895 = env50902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env50895 == env50902) = true)

theorem identity50902 : scanCanonicalize (H12AffineFastState.compose env50902 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound50902 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50903 : List Nat := [2,4,8,16,1,16,9,5,512,1024,2048,16,8,1045,0,2,1028,2049,1024,1,0,0,17,3,9,17,2048,1029,17,2049,1024,0,5,1,1045,513]

theorem envBound50903 : H12AffineFastState.Bounded env50903 := by
  intro p hp
  have h : env50903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50902_50903 : H12AffineEnvironment.transform 4 1 env50902 = env50903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50902 == env50903) = true)

def env50904 : List Nat := [2,4,8,16,1,16,9,5,512,20,2048,16,8,1,0,2,16,2049,20,1,0,0,17,3,9,17,2048,17,17,2049,20,0,5,1,1,513]

theorem envBound50904 : H12AffineFastState.Bounded env50904 := by
  intro p hp
  have h : env50904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50903_50904 : H12AffineEnvironment.transform 9 20 env50903 = env50904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env50903 == env50904) = true)

theorem identity50904 : scanCanonicalize (H12AffineFastState.compose env50904 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound50904 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50905 : List Nat := [2,4,8,16,1,16,9,5,512,20,523,16,8,1,0,2,16,522,20,1,0,0,17,3,9,17,523,17,17,522,20,0,5,1,1,513]

theorem envBound50905 : H12AffineFastState.Bounded env50905 := by
  intro p hp
  have h : env50905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50904_50905 : H12AffineEnvironment.transform 10 523 env50904 = env50905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env50904 == env50905) = true)

def leafEnv50905 : List Nat := [2,4,8,16,1,16,9,5,512,20,523,16,8,1,0,2,16,522,20,1,0,0,17,3,20,9,1,17,523,17,17,522,20,0,5,1,4,3,1,513,1,0,0]

def active50905 : List Nat := [0,1,2,3,8]

def tree50905 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50905 : H12WitnessSearch.Good tree50905 := H12GlobalWitnessIndex.good

theorem leafIdentity50905 : H12AffineFastState.composeSystem env50905 rootObs = leafEnv50905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50905 rootObs == leafEnv50905) = true)

theorem terminalChecked50905 : H12PackedTerminal.terminalCheckFast leafEnv50905 active50905 tree50905 = true := by decide +kernel

def env50906 : List Nat := [2,4,8,16,1,16,9,5,512,21,2048,16,8,0,0,2,17,2049,21,1,0,0,17,3,9,17,2048,16,17,2049,21,0,5,1,0,513]

theorem envBound50906 : H12AffineFastState.Bounded env50906 := by
  intro p hp
  have h : env50906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50903_50906 : H12AffineEnvironment.transform 9 21 env50903 = env50906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env50903 == env50906) = true)

theorem identity50906 : scanCanonicalize (H12AffineFastState.compose env50906 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound50906 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50907 : List Nat := [2,4,8,16,1,16,9,5,512,21,0,16,8,0,0,2,17,1,21,1,0,0,17,3,9,17,0,16,17,1,21,0,5,1,0,513]

theorem envBound50907 : H12AffineFastState.Bounded env50907 := by
  intro p hp
  have h : env50907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50906_50907 : H12AffineEnvironment.transform 10 0 env50906 = env50907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env50906 == env50907) = true)

def leafEnv50907 : List Nat := [2,4,8,16,1,16,9,5,512,21,0,16,8,0,0,2,17,1,21,1,0,0,17,3,21,9,1,17,0,16,17,1,21,0,5,1,4,3,0,513,1,0,0]

def active50907 : List Nat := [0,1,2,3,8]

def tree50907 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50907 : H12WitnessSearch.Good tree50907 := H12GlobalWitnessIndex.good

theorem leafIdentity50907 : H12AffineFastState.composeSystem env50907 rootObs = leafEnv50907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50907 rootObs == leafEnv50907) = true)

theorem terminalChecked50907 : H12PackedTerminal.terminalCheckFast leafEnv50907 active50907 tree50907 = true := by decide +kernel

def env50908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,4194304,16,98781,8328,65,4259060,5393,17665,32041,1501,4256860,256,21792,46212,74250]

theorem envBound50908 : H12AffineFastState.Bounded env50908 := by
  intro p hp
  have h : env50908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50885_50908 : H12AffineEnvironment.transform 20 4161 env50885 = env50908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env50885 == env50908) = true)

def env50909 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,4194304,16,98645,8192,65,4258940,5393,17665,32041,1365,4256860,256,21792,46092,74250]

theorem envBound50909 : H12AffineFastState.Bounded env50909 := by
  intro p hp
  have h : env50909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50908_50909 : H12AffineEnvironment.transform 6 8 env50908 = env50909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50908 == env50909) = true)

theorem identity50909 : scanCanonicalize (H12AffineFastState.compose env50909 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound50909 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50910 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13389,35188,1024,32769,4161,4194304,16,98645,8192,65,4258940,5393,17665,32041,1365,4256860,256,21792,46092,74250]

theorem envBound50910 : H12AffineFastState.Bounded env50910 := by
  intro p hp
  have h : env50910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50909_50910 : H12AffineEnvironment.transform 16 13389 env50909 = env50910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env50909 == env50910) = true)

theorem identity50910 : scanCanonicalize (H12AffineFastState.compose env50910 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound50910 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env50911 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,65536,13389,35188,1024,32769,4161,4194304,16,98645,8192,65,4229153,5393,12636,2420,1365,4227073,256,8573,46092,74250]

theorem envBound50911 : H12AffineFastState.Bounded env50911 := by
  intro p hp
  have h : env50911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50910_50911 : H12AffineEnvironment.transform 13 13405 env50910 = env50911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env50910 == env50911) = true)

theorem identity50911 : scanCanonicalize (H12AffineFastState.compose env50911 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound50911 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env50912 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,8203,13389,35188,1024,32769,4161,4194304,16,41310,8192,65,4229153,5393,12636,2420,1365,4227073,256,8573,46092,513]

theorem envBound50912 : H12AffineFastState.Bounded env50912 := by
  intro p hp
  have h : env50912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50911_50912 : H12AffineEnvironment.transform 15 8203 env50911 = env50912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env50911 == env50912) = true)

theorem identity50912 : scanCanonicalize (H12AffineFastState.compose env50912 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound50912 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env50913 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,9292,8203,13389,11576,1024,9293,4161,4194304,16,1298,8192,65,4205677,5393,12636,2420,1365,4203597,256,8573,4160,513]

theorem envBound50913 : H12AffineFastState.Bounded env50913 := by
  intro p hp
  have h : env50913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50912_50913 : H12AffineEnvironment.transform 14 9292 env50912 = env50913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env50912 == env50913) = true)

theorem identity50913 : scanCanonicalize (H12AffineFastState.compose env50913 (packedSelected [14] rootPS)) = affineNative (2^(12+1) ^^^ 5416) := by decide +kernel

theorem selectedBound50913 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env50914 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,5416,373,4452,5411,357,6160,1024,4453,4161,4194304,16,1298,5416,65,4200773,5393,1140,2420,1365,4198757,256,5205,4160,513]

theorem envBound50914 : H12AffineFastState.Bounded env50914 := by
  intro p hp
  have h : env50914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50913_50914 : H12AffineEnvironment.transform 12 5416 env50913 = env50914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5416 env50913 == env50914) = true)

theorem identity50914 : scanCanonicalize (H12AffineFastState.compose env50914 (packedSelected [0,27] rootPS)) = affineNative (2^(21+1) ^^^ 1328) := by decide +kernel

theorem selectedBound50914 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env50915 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,5416,373,4452,5411,357,6160,1024,4453,4161,1328,16,1298,5416,65,7285,5393,1140,2420,1365,5205,256,5205,4160,513]

theorem envBound50915 : H12AffineFastState.Bounded env50915 := by
  intro p hp
  have h : env50915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50914_50915 : H12AffineEnvironment.transform 21 1328 env50914 = env50915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1328 env50914 == env50915) = true)

theorem identity50915 : scanCanonicalize (H12AffineFastState.compose env50915 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound50915 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env50916 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,4153,373,4452,4146,357,6160,273,4453,4161,33,16,3,4153,65,6500,4096,357,2420,68,4420,256,4420,4160,513]

theorem envBound50916 : H12AffineFastState.Bounded env50916 := by
  intro p hp
  have h : env50916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50915_50916 : H12AffineEnvironment.transform 9 273 env50915 = env50916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env50915 == env50916) = true)

theorem identity50916 : scanCanonicalize (H12AffineFastState.compose env50916 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound50916 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50917 : List Nat := [2,4,8,16,1,64,8,256,512,273,2048,4096,4120,340,4421,4115,324,6160,273,4420,4161,0,16,3,4120,65,6469,4096,324,2389,68,4420,256,4420,4160,513]

theorem envBound50917 : H12AffineFastState.Bounded env50917 := by
  intro p hp
  have h : env50917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50916_50917 : H12AffineEnvironment.transform 4 1 env50916 = env50917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50916 == env50917) = true)

theorem identity50917 : scanCanonicalize (H12AffineFastState.compose env50917 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound50917 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50918 : List Nat := [2,4,8,16,1,64,8,256,512,273,2048,324,348,340,1,343,324,2388,273,0,261,0,16,3,348,65,2049,324,324,2389,68,0,256,0,260,513]

theorem envBound50918 : H12AffineFastState.Bounded env50918 := by
  intro p hp
  have h : env50918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50917_50918 : H12AffineEnvironment.transform 11 324 env50917 = env50918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env50917 == env50918) = true)

theorem identity50918 : scanCanonicalize (H12AffineFastState.compose env50918 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound50918 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50919 : List Nat := [2,4,8,16,1,64,8,5,512,20,2048,65,89,81,1,82,65,2129,20,0,0,0,16,3,89,65,2049,65,65,2128,68,0,5,0,1,513]

theorem envBound50919 : H12AffineFastState.Bounded env50919 := by
  intro p hp
  have h : env50919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50918_50919 : H12AffineEnvironment.transform 7 5 env50918 = env50919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env50918 == env50919) = true)

theorem identity50919 : scanCanonicalize (H12AffineFastState.compose env50919 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 593) := by decide +kernel

theorem selectedBound50919 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50920 : List Nat := [2,4,8,16,1,64,8,5,512,20,593,65,89,81,1,82,65,512,20,0,0,0,16,3,89,65,592,65,65,513,68,0,5,0,1,513]

theorem envBound50920 : H12AffineFastState.Bounded env50920 := by
  intro p hp
  have h : env50920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50919_50920 : H12AffineEnvironment.transform 10 593 env50919 = env50920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 593 env50919 == env50920) = true)

theorem identity50920 : scanCanonicalize (H12AffineFastState.compose env50920 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound50920 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50921 : List Nat := [2,4,8,16,1,64,8,5,81,20,0,65,89,81,1,82,65,81,20,0,0,0,16,3,89,65,1,65,65,80,68,0,5,0,1,80]

theorem envBound50921 : H12AffineFastState.Bounded env50921 := by
  intro p hp
  have h : env50921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50920_50921 : H12AffineEnvironment.transform 8 81 env50920 = env50921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env50920 == env50921) = true)

theorem identity50921 : scanCanonicalize (H12AffineFastState.compose env50921 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound50921 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env50922 : List Nat := [2,4,8,16,1,0,8,5,17,20,0,1,25,17,1,18,1,17,20,0,0,0,16,3,25,1,1,1,1,16,4,0,5,0,1,16]

theorem envBound50922 : H12AffineFastState.Bounded env50922 := by
  intro p hp
  have h : env50922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50921_50922 : H12AffineEnvironment.transform 5 0 env50921 = env50922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env50921 == env50922) = true)

def env50923 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,4194304,16,98644,8193,65,4258941,5393,17665,32041,1364,4256860,256,21792,46093,74250]

theorem envBound50923 : H12AffineFastState.Bounded env50923 := by
  intro p hp
  have h : env50923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50908_50923 : H12AffineEnvironment.transform 6 9 env50908 = env50923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50908 == env50923) = true)

theorem identity50923 : scanCanonicalize (H12AffineFastState.compose env50923 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound50923 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50924 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1024,32769,4161,4194304,16,98644,8193,65,4258941,5393,17665,32041,1364,4256860,256,21792,46093,74250]

theorem envBound50924 : H12AffineFastState.Bounded env50924 := by
  intro p hp
  have h : env50924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50923_50924 : H12AffineEnvironment.transform 16 38161 env50923 = env50924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env50923 == env50924) = true)

theorem identity50924 : scanCanonicalize (H12AffineFastState.compose env50924 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound50924 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env50925 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1024,32769,4161,33,16,98644,8193,65,64604,5393,17665,32041,1364,62589,256,21792,46093,74250]

theorem envBound50925 : H12AffineFastState.Bounded env50925 := by
  intro p hp
  have h : env50925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50924_50925 : H12AffineEnvironment.transform 21 33 env50924 = env50925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env50924 == env50925) = true)

theorem identity50925 : scanCanonicalize (H12AffineFastState.compose env50925 (packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound50925 : packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env50926 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,38161,10280,1024,32769,4161,33,16,98644,8193,65,43356,5393,4097,10281,1364,41341,256,32,46093,74250]

theorem envBound50926 : H12AffineFastState.Bounded env50926 := by
  intro p hp
  have h : env50926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50925_50926 : H12AffineEnvironment.transform 13 5376 env50925 = env50926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env50925 == env50926) = true)

theorem identity50926 : scanCanonicalize (H12AffineFastState.compose env50926 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound50926 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env50927 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,40970,38161,10280,1024,32769,4161,33,16,8542,8193,65,43356,5393,4097,10281,1364,41341,256,32,46093,33280]

theorem envBound50927 : H12AffineFastState.Bounded env50927 := by
  intro p hp
  have h : env50927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50926_50927 : H12AffineEnvironment.transform 15 40970 env50926 = env50927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env50926 == env50927) = true)

theorem identity50927 : scanCanonicalize (H12AffineFastState.compose env50927 (packedSelected [0,1,2,5,6,7,8,11,16,18,24] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound50927 : packedSelected [0,1,2,5,6,7,8,11,16,18,24] rootPS < 2^1333 := by decide +kernel

def env50928 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,81,8283,5440,10280,1024,80,4161,33,16,8542,8193,65,10509,5393,4097,10281,1364,8492,256,32,13404,593]

theorem envBound50928 : H12AffineFastState.Bounded env50928 := by
  intro p hp
  have h : env50928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50927_50928 : H12AffineEnvironment.transform 14 81 env50927 = env50928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env50927 == env50928) = true)

theorem identity50928 : scanCanonicalize (H12AffineFastState.compose env50928 (packedSelected [4,9,11,14] rootPS)) = affineNative (2^(12+1) ^^^ 5416) := by decide +kernel

theorem selectedBound50928 : packedSelected [4,9,11,14] rootPS < 2^1333 := by decide +kernel

def env50929 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5416,5376,81,5491,5440,7424,1024,80,4161,33,16,5238,5417,65,7205,5393,4097,7425,1364,5124,256,32,372,593]

theorem envBound50929 : H12AffineFastState.Bounded env50929 := by
  intro p hp
  have h : env50929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50928_50929 : H12AffineEnvironment.transform 12 5416 env50928 = env50929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5416 env50928 == env50929) = true)

theorem identity50929 : scanCanonicalize (H12AffineFastState.compose env50929 (packedSelected [12] rootPS)) = affineNative (2^(11+1) ^^^ 3189) := by decide +kernel

theorem selectedBound50929 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env50930 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3189,2397,2421,81,2310,2357,373,1024,80,3124,33,16,2051,2396,65,80,2404,3188,372,1364,2161,256,32,372,593]

theorem envBound50930 : H12AffineFastState.Bounded env50930 := by
  intro p hp
  have h : env50930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50929_50930 : H12AffineEnvironment.transform 11 3189 env50929 = env50930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3189 env50929 == env50930) = true)

def env50931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2534760,474341,8328,65,6705549,2537576,456760,2125160,2102685,6707493,256,21793,46213,2175562]

theorem envBound50931 : H12AffineFastState.Bounded env50931 := by
  intro p hp
  have h : env50931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50839_50931 : H12AffineEnvironment.transform 23 474341 env50839 = env50931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 474341 env50839 == env50931) = true)

def env50932 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,2097152,4194304,2101328,98781,8328,65,6352053,2098512,17664,2125160,2102685,6349853,256,21793,46213,2175562]

theorem envBound50932 : H12AffineFastState.Bounded env50932 := by
  intro p hp
  have h : env50932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50931_50932 : H12AffineEnvironment.transform 17 179512 env50931 = env50932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env50931 == env50932) = true)

def env50933 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,4194304,16,98781,8328,65,4259061,5392,17664,32040,1501,4256861,256,21793,46213,74250]

theorem envBound50933 : H12AffineFastState.Bounded env50933 := by
  intro p hp
  have h : env50933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50932_50933 : H12AffineEnvironment.transform 20 4160 env50932 = env50933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env50932 == env50933) = true)

theorem identity50933 : scanCanonicalize (H12AffineFastState.compose env50933 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound50933 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50934 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179512,1024,32769,4160,4194304,16,41430,8328,65,4259061,5392,17664,32040,1501,4256861,256,21793,46213,513]

theorem envBound50934 : H12AffineFastState.Bounded env50934 := by
  intro p hp
  have h : env50934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50933_50934 : H12AffineEnvironment.transform 15 8203 env50933 = env50934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env50933 == env50934) = true)

theorem identity50934 : scanCanonicalize (H12AffineFastState.compose env50934 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 169400) := by decide +kernel

theorem selectedBound50934 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env50935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179512,1024,32769,4160,169400,16,41430,8328,65,158029,5392,17664,32040,1501,156133,256,21793,46213,513]

theorem envBound50935 : H12AffineFastState.Bounded env50935 := by
  intro p hp
  have h : env50935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50934_50935 : H12AffineEnvironment.transform 21 169400 env50934 = env50935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169400 env50934 == env50935) = true)

theorem identity50935 : scanCanonicalize (H12AffineFastState.compose env50935 (packedSelected [12,15,17,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound50935 : packedSelected [12,15,17,38,41] rootPS < 2^1333 := by decide +kernel

def env50936 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179512,1024,32769,4160,169265,16,41311,8193,65,158029,5392,17664,32040,1364,156012,256,21793,46092,513]

theorem envBound50936 : H12AffineFastState.Bounded env50936 := by
  intro p hp
  have h : env50936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50935_50936 : H12AffineEnvironment.transform 6 9 env50935 = env50936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50935 == env50936) = true)

theorem identity50936 : scanCanonicalize (H12AffineFastState.compose env50936 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound50936 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50937 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,38160,10280,1024,32769,4160,33,16,41311,8193,65,64605,5392,17664,32040,1364,62588,256,21793,46092,513]

theorem envBound50937 : H12AffineFastState.Bounded env50937 := by
  intro p hp
  have h : env50937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50936_50937 : H12AffineEnvironment.transform 16 38160 env50936 = env50937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env50936 == env50937) = true)

theorem identity50937 : scanCanonicalize (H12AffineFastState.compose env50937 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound50937 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env50938 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,8203,5392,10280,1024,1,4160,33,16,8543,8193,65,31837,5392,17664,32040,1364,29820,256,21793,13324,513]

theorem envBound50938 : H12AffineFastState.Bounded env50938 := by
  intro p hp
  have h : env50938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50937_50938 : H12AffineEnvironment.transform 14 0 env50937 = env50938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env50937 == env50938) = true)

theorem identity50938 : scanCanonicalize (H12AffineFastState.compose env50938 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound50938 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50939 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,0,343,5392,2420,1024,1,4160,33,16,3,349,65,23809,5392,17664,23668,1364,21792,256,21793,5456,513]

theorem envBound50939 : H12AffineFastState.Bounded env50939 := by
  intro p hp
  have h : env50939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50938_50939 : H12AffineEnvironment.transform 12 348 env50938 = env50939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env50938 == env50939) = true)

theorem identity50939 : scanCanonicalize (H12AffineFastState.compose env50939 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5408) := by decide +kernel

theorem selectedBound50939 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env50940 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5408,0,343,5392,2420,1024,1,4160,33,16,3,349,65,2081,5392,4128,2388,1364,0,256,1,5456,513]

theorem envBound50940 : H12AffineFastState.Bounded env50940 := by
  intro p hp
  have h : env50940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50939_50940 : H12AffineEnvironment.transform 13 5408 env50939 = env50940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5408 env50939 == env50940) = true)

theorem identity50940 : scanCanonicalize (H12AffineFastState.compose env50940 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound50940 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50941 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,348,5376,0,343,5392,2388,1024,1,4160,1,16,3,349,65,2049,5392,4096,2388,1364,0,256,1,5456,513]

theorem envBound50941 : H12AffineFastState.Bounded env50941 := by
  intro p hp
  have h : env50941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50940_50941 : H12AffineEnvironment.transform 4 0 env50940 = env50941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50940 == env50941) = true)

theorem identity50941 : scanCanonicalize (H12AffineFastState.compose env50941 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound50941 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50942 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,1028,348,260,0,343,276,2388,1024,1,1092,1,16,3,349,65,2049,276,1028,2388,1364,0,256,1,340,513]

theorem envBound50942 : H12AffineFastState.Bounded env50942 := by
  intro p hp
  have h : env50942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50941_50942 : H12AffineEnvironment.transform 11 1028 env50941 = env50942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env50941 == env50942) = true)

theorem identity50942 : scanCanonicalize (H12AffineFastState.compose env50942 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound50942 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env50943 : List Nat := [2,4,8,16,0,64,9,256,512,1024,0,1028,348,260,0,343,276,340,1024,1,1092,1,16,3,349,65,1,276,1028,340,1364,0,256,1,340,513]

theorem envBound50943 : H12AffineFastState.Bounded env50943 := by
  intro p hp
  have h : env50943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50942_50943 : H12AffineEnvironment.transform 10 0 env50942 = env50943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env50942 == env50943) = true)

theorem identity50943 : scanCanonicalize (H12AffineFastState.compose env50943 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound50943 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env50944 : List Nat := [2,4,8,16,0,64,9,256,512,257,0,261,348,260,0,343,276,340,257,1,325,1,16,3,349,65,1,276,261,340,85,0,256,1,340,513]

theorem envBound50944 : H12AffineFastState.Bounded env50944 := by
  intro p hp
  have h : env50944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50943_50944 : H12AffineEnvironment.transform 9 257 env50943 = env50944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env50943 == env50944) = true)

theorem identity50944 : scanCanonicalize (H12AffineFastState.compose env50944 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 340) := by decide +kernel

theorem selectedBound50944 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env50945 : List Nat := [2,4,8,16,0,64,9,256,340,257,0,261,348,260,0,343,276,340,257,1,325,1,16,3,349,65,1,276,261,340,85,0,256,1,340,341]

theorem envBound50945 : H12AffineFastState.Bounded env50945 := by
  intro p hp
  have h : env50945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50944_50945 : H12AffineEnvironment.transform 8 340 env50944 = env50945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env50944 == env50945) = true)

theorem identity50945 : scanCanonicalize (H12AffineFastState.compose env50945 (packedSelected [2,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound50945 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env50946 : List Nat := [2,4,8,1,0,64,9,256,325,257,0,261,333,260,0,326,261,325,257,1,325,1,1,3,332,65,1,261,261,325,68,0,256,1,325,324]

theorem envBound50946 : H12AffineFastState.Bounded env50946 := by
  intro p hp
  have h : env50946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50945_50946 : H12AffineEnvironment.transform 3 1 env50945 = env50946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50945 == env50946) = true)

theorem identity50946 : scanCanonicalize (H12AffineFastState.compose env50946 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound50946 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50947 : List Nat := [2,4,8,1,0,64,9,5,64,4,0,0,72,1,0,67,0,64,4,1,64,1,1,3,73,65,1,0,0,64,68,0,5,1,64,65]

theorem envBound50947 : H12AffineFastState.Bounded env50947 := by
  intro p hp
  have h : env50947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50946_50947 : H12AffineEnvironment.transform 7 5 env50946 = env50947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env50946 == env50947) = true)

theorem identity50947 : scanCanonicalize (H12AffineFastState.compose env50947 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound50947 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50948 : List Nat := [2,4,8,1,0,1,9,5,1,4,0,0,9,1,0,2,0,1,4,1,1,1,1,3,8,0,1,0,0,1,5,0,5,1,1,0]

theorem envBound50948 : H12AffineFastState.Bounded env50948 := by
  intro p hp
  have h : env50948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50947_50948 : H12AffineEnvironment.transform 5 1 env50947 = env50948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env50947 == env50948) = true)

def env50949 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,4194304,17,98781,8328,65,4259060,5393,17664,32041,1500,4256860,256,21793,46213,74251]

theorem envBound50949 : H12AffineFastState.Bounded env50949 := by
  intro p hp
  have h : env50949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50932_50949 : H12AffineEnvironment.transform 20 4161 env50932 = env50949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env50932 == env50949) = true)

theorem identity50949 : scanCanonicalize (H12AffineFastState.compose env50949 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 243122) := by decide +kernel

theorem selectedBound50949 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50950 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,243122,17,98781,8328,65,215366,5393,17664,32041,1500,213486,256,21793,46213,74251]

theorem envBound50950 : H12AffineFastState.Bounded env50950 := by
  intro p hp
  have h : env50950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50949_50950 : H12AffineEnvironment.transform 21 243122 env50949 = env50950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 243122 env50949 == env50950) = true)

def env50951 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,243002,17,98645,8192,65,215366,5393,17664,32041,1364,213350,256,21793,46093,74251]

theorem envBound50951 : H12AffineFastState.Bounded env50951 := by
  intro p hp
  have h : env50951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50950_50951 : H12AffineEnvironment.transform 6 8 env50950 = env50951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50950 == env50951) = true)

theorem identity50951 : scanCanonicalize (H12AffineFastState.compose env50951 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound50951 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50952 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,138341,1024,8540,4161,201831,17,73736,8192,65,215366,5393,17664,32041,1364,213350,256,21793,5456,74251]

theorem envBound50952 : H12AffineFastState.Bounded env50952 := by
  intro p hp
  have h : env50952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50951_50952 : H12AffineEnvironment.transform 14 8541 env50951 = env50952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env50951 == env50952) = true)

theorem identity50952 : scanCanonicalize (H12AffineFastState.compose env50952 (packedSelected [0,1,6,7,10,14,20,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 8495) := by decide +kernel

theorem selectedBound50952 : packedSelected [0,1,6,7,10,14,20,26,28] rootPS < 2^1333 := by decide +kernel

def env50953 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8495,131072,138341,1024,8540,4161,144712,17,295,8192,65,157801,5393,17664,32041,1364,155721,256,21793,5456,804]

theorem envBound50953 : H12AffineFastState.Bounded env50953 := by
  intro p hp
  have h : env50953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50952_50953 : H12AffineEnvironment.transform 15 8495 env50952 = env50953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8495 env50952 == env50953) = true)

theorem identity50953 : scanCanonicalize (H12AffineFastState.compose env50953 (packedSelected [0,2,3,4,5,10,11,12,15,20,22,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound50953 : packedSelected [0,2,3,4,5,10,11,12,15,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env50954 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8495,5221,2048,1024,8540,4161,8493,17,295,8192,65,31756,5393,17664,32041,1364,29740,256,21793,5456,804]

theorem envBound50954 : H12AffineFastState.Bounded env50954 := by
  intro p hp
  have h : env50954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50953_50954 : H12AffineEnvironment.transform 16 5221 env50953 = env50954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env50953 == env50954) = true)

theorem identity50954 : scanCanonicalize (H12AffineFastState.compose env50954 (packedSelected [4,6,14,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound50954 : packedSelected [4,6,14,20,22] rootPS < 2^1333 := by decide +kernel

def env50955 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8232,8282,5221,2048,1024,8233,4161,8280,17,82,8192,65,31756,5220,17525,31836,1057,29740,117,21588,5157,593]

theorem envBound50955 : H12AffineFastState.Bounded env50955 := by
  intro p hp
  have h : env50955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50954_50955 : H12AffineEnvironment.transform 7 117 env50954 = env50955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env50954 == env50955) = true)

theorem identity50955 : scanCanonicalize (H12AffineFastState.compose env50955 (packedSelected [0,1,3,4,5,6,7,8,9,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound50955 : packedSelected [0,1,3,4,5,6,7,8,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env50956 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,1101,16384,1125,1047,5221,2048,1024,1124,4161,1045,17,82,1101,65,22593,5220,17525,22545,1057,20577,117,21588,5157,593]

theorem envBound50956 : H12AffineFastState.Bounded env50956 := by
  intro p hp
  have h : env50956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50955_50956 : H12AffineEnvironment.transform 12 1101 env50955 = env50956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env50955 == env50956) = true)

def env50957 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,243003,17,98644,8193,65,215366,5393,17664,32041,1365,213351,256,21793,46092,74251]

theorem envBound50957 : H12AffineFastState.Bounded env50957 := by
  intro p hp
  have h : env50957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50950_50957 : H12AffineEnvironment.transform 6 9 env50950 = env50957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50950 == env50957) = true)

theorem identity50957 : scanCanonicalize (H12AffineFastState.compose env50957 (packedSelected [1,3,4,8,9,10,12,14,16,18,19,23,24,26,38] rootPS)) = affineNative (2^(16+1) ^^^ 114966) := by decide +kernel

theorem selectedBound50957 : packedSelected [1,3,4,8,9,10,12,14,16,18,19,23,24,26,38] rootPS < 2^1333 := by decide +kernel

def env50958 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,114966,97326,1024,32769,4161,29741,17,98644,8193,65,34896,5393,17664,32041,1365,32881,256,21793,46092,74251]

theorem envBound50958 : H12AffineFastState.Bounded env50958 := by
  intro p hp
  have h : env50958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50957_50958 : H12AffineEnvironment.transform 16 114966 env50957 = env50958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114966 env50957 == env50958) = true)

theorem identity50958 : scanCanonicalize (H12AffineFastState.compose env50958 (packedSelected [3,5,7,12,14,15,16,19,26,27,31] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound50958 : packedSelected [3,5,7,12,14,15,16,19,26,27,31] rootPS < 2^1333 := by decide +kernel

def env50959 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,57628,23588,1024,32769,4161,29741,17,41310,8193,65,34896,5393,17664,32041,1365,32881,256,21793,46092,513]

theorem envBound50959 : H12AffineFastState.Bounded env50959 := by
  intro p hp
  have h : env50959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50958_50959 : H12AffineEnvironment.transform 15 8202 env50958 = env50959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env50958 == env50959) = true)

theorem identity50959 : scanCanonicalize (H12AffineFastState.compose env50959 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound50959 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env50960 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8461,8202,16401,23588,1024,8460,4161,29741,17,83,8193,65,10589,5393,17664,32041,1365,8572,256,21793,5377,513]

theorem envBound50960 : H12AffineFastState.Bounded env50960 := by
  intro p hp
  have h : env50960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50959_50960 : H12AffineEnvironment.transform 14 8461 env50959 = env50960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env50959 == env50960) = true)

theorem identity50960 : scanCanonicalize (H12AffineFastState.compose env50960 (packedSelected [0,2,9,10,12,18] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound50960 : packedSelected [0,2,9,10,12,18] rootPS < 2^1333 := by decide +kernel

def env50961 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5156,8461,8202,5173,2048,1024,8460,4161,8201,17,83,8193,65,10589,5393,4388,10509,1365,8572,256,261,5377,513]

theorem envBound50961 : H12AffineFastState.Bounded env50961 := by
  intro p hp
  have h : env50961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50960_50961 : H12AffineEnvironment.transform 13 5156 env50960 = env50961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env50960 == env50961) = true)

theorem identity50961 : scanCanonicalize (H12AffineFastState.compose env50961 (packedSelected [3,4,5,7,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound50961 : packedSelected [3,4,5,7,11,15] rootPS < 2^1333 := by decide +kernel

def env50962 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5156,373,114,5173,2048,1024,372,4161,113,17,83,121,65,2341,5393,4388,2421,1365,260,256,261,5377,513]

theorem envBound50962 : H12AffineFastState.Bounded env50962 := by
  intro p hp
  have h : env50962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50961_50962 : H12AffineEnvironment.transform 12 120 env50961 = env50962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env50961 == env50962) = true)

theorem identity50962 : scanCanonicalize (H12AffineFastState.compose env50962 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50962 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env50963 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,40,5156,293,34,5173,2048,1024,292,4113,33,17,3,41,17,2341,5393,4388,2341,1285,260,256,261,5377,513]

theorem envBound50963 : H12AffineFastState.Bounded env50963 := by
  intro p hp
  have h : env50963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50962_50963 : H12AffineEnvironment.transform 5 16 env50962 = env50963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50962 == env50963) = true)

theorem identity50963 : scanCanonicalize (H12AffineFastState.compose env50963 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound50963 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env50964 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5156,0,34,5173,2048,1024,1,4113,33,17,3,41,17,2048,5172,4097,2048,1056,33,37,32,5156,513]

theorem envBound50964 : H12AffineFastState.Bounded env50964 := by
  intro p hp
  have h : env50964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50963_50964 : H12AffineEnvironment.transform 7 37 env50963 = env50964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env50963 == env50964) = true)

def env50965 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,40,1044,0,34,1029,2048,1024,1,33,33,17,3,41,17,2048,1028,49,2048,1056,33,37,32,1044,513]

theorem envBound50965 : H12AffineFastState.Bounded env50965 := by
  intro p hp
  have h : env50965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50964_50965 : H12AffineEnvironment.transform 11 48 env50964 = env50965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env50964 == env50965) = true)

theorem identity50965 : scanCanonicalize (H12AffineFastState.compose env50965 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound50965 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50966 : List Nat := [2,4,8,16,32,16,9,37,512,1024,561,48,40,1044,0,34,1029,561,1024,1,33,33,17,3,41,17,561,1028,49,561,1056,33,37,32,1044,513]

theorem envBound50966 : H12AffineFastState.Bounded env50966 := by
  intro p hp
  have h : env50966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50965_50966 : H12AffineEnvironment.transform 10 561 env50965 = env50966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env50965 == env50966) = true)

def env50967 : List Nat := [2,4,8,16,32,16,9,37,512,52,561,48,40,32,0,34,49,561,52,1,33,33,17,3,41,17,561,48,49,561,20,33,37,32,32,513]

theorem envBound50967 : H12AffineFastState.Bounded env50967 := by
  intro p hp
  have h : env50967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50966_50967 : H12AffineEnvironment.transform 9 52 env50966 = env50967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env50966 == env50967) = true)

theorem identity50967 : scanCanonicalize (H12AffineFastState.compose env50967 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound50967 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50968 : List Nat := [2,4,8,16,32,16,9,37,17,52,32,48,40,32,0,34,49,32,52,1,33,33,17,3,41,17,32,48,49,32,20,33,37,32,32,16]

theorem envBound50968 : H12AffineFastState.Bounded env50968 := by
  intro p hp
  have h : env50968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50967_50968 : H12AffineEnvironment.transform 8 17 env50967 = env50968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env50967 == env50968) = true)

def leafEnv50968 : List Nat := [2,4,8,16,32,16,9,37,17,52,32,48,40,32,0,34,49,32,52,1,33,33,17,3,20,41,1,17,32,48,49,32,20,33,37,32,4,35,32,16,1,33,0]

def active50968 : List Nat := [0,1,2,3,4]

def tree50968 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50968 : H12WitnessSearch.Good tree50968 := H12GlobalWitnessIndex.good

theorem leafIdentity50968 : H12AffineFastState.composeSystem env50968 rootObs = leafEnv50968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50968 rootObs == leafEnv50968) = true)

theorem terminalChecked50968 : H12PackedTerminal.terminalCheckFast leafEnv50968 active50968 tree50968 = true := by decide +kernel

def env50969 : List Nat := [2,4,8,16,32,16,9,37,512,53,561,48,40,33,0,34,48,561,53,1,33,33,17,3,41,17,561,49,49,561,21,33,37,32,33,513]

theorem envBound50969 : H12AffineFastState.Bounded env50969 := by
  intro p hp
  have h : env50969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50966_50969 : H12AffineEnvironment.transform 9 53 env50966 = env50969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env50966 == env50969) = true)

theorem identity50969 : scanCanonicalize (H12AffineFastState.compose env50969 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound50969 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50970 : List Nat := [2,4,8,16,27,16,9,30,512,14,522,11,19,26,0,25,11,522,14,1,26,26,17,3,18,17,522,10,10,522,21,26,30,27,26,513]

theorem envBound50970 : H12AffineFastState.Bounded env50970 := by
  intro p hp
  have h : env50970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50969_50970 : H12AffineEnvironment.transform 4 27 env50969 = env50970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env50969 == env50970) = true)

def leafEnv50970 : List Nat := [2,4,8,16,27,16,9,30,512,14,522,11,19,26,0,25,11,522,14,1,26,26,17,3,21,18,1,17,522,10,10,522,21,26,30,27,4,24,26,513,1,26,0]

def active50970 : List Nat := [0,1,2,3,8]

def tree50970 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50970 : H12WitnessSearch.Good tree50970 := H12GlobalWitnessIndex.good

theorem leafIdentity50970 : H12AffineFastState.composeSystem env50970 rootObs = leafEnv50970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50970 rootObs == leafEnv50970) = true)

theorem terminalChecked50970 : H12PackedTerminal.terminalCheckFast leafEnv50970 active50970 tree50970 = true := by decide +kernel

def env50971 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,40,1045,0,34,1028,2048,1024,1,32,33,17,3,41,17,2048,1029,48,2048,1056,33,37,32,1045,513]

theorem envBound50971 : H12AffineFastState.Bounded env50971 := by
  intro p hp
  have h : env50971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50964_50971 : H12AffineEnvironment.transform 11 49 env50964 = env50971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env50964 == env50971) = true)

theorem identity50971 : scanCanonicalize (H12AffineFastState.compose env50971 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound50971 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50972 : List Nat := [2,4,8,16,32,16,9,37,512,1024,1541,49,40,1045,0,34,1028,1541,1024,1,32,33,17,3,41,17,1541,1029,48,1541,1056,33,37,32,1045,513]

theorem envBound50972 : H12AffineFastState.Bounded env50972 := by
  intro p hp
  have h : env50972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50971_50972 : H12AffineEnvironment.transform 10 1541 env50971 = env50972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env50971 == env50972) = true)

def env50973 : List Nat := [2,4,8,16,32,16,9,37,512,52,561,49,40,33,0,34,48,561,52,1,32,33,17,3,41,17,561,49,48,561,20,33,37,32,33,513]

theorem envBound50973 : H12AffineFastState.Bounded env50973 := by
  intro p hp
  have h : env50973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50972_50973 : H12AffineEnvironment.transform 9 52 env50972 = env50973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env50972 == env50973) = true)

theorem identity50973 : scanCanonicalize (H12AffineFastState.compose env50973 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound50973 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50974 : List Nat := [2,4,8,16,32,16,9,37,16,52,33,49,40,33,0,34,48,33,52,1,32,33,17,3,41,17,33,49,48,33,20,33,37,32,33,17]

theorem envBound50974 : H12AffineFastState.Bounded env50974 := by
  intro p hp
  have h : env50974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50973_50974 : H12AffineEnvironment.transform 8 16 env50973 = env50974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env50973 == env50974) = true)

def leafEnv50974 : List Nat := [2,4,8,16,32,16,9,37,16,52,33,49,40,33,0,34,48,33,52,1,32,33,17,3,20,41,1,17,33,49,48,33,20,33,37,32,4,35,33,17,1,32,0]

def active50974 : List Nat := [0,1,2,3,4]

def tree50974 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50974 : H12WitnessSearch.Good tree50974 := H12GlobalWitnessIndex.good

theorem leafIdentity50974 : H12AffineFastState.composeSystem env50974 rootObs = leafEnv50974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50974 rootObs == leafEnv50974) = true)

theorem terminalChecked50974 : H12PackedTerminal.terminalCheckFast leafEnv50974 active50974 tree50974 = true := by decide +kernel

def env50975 : List Nat := [2,4,8,16,32,16,9,37,512,53,560,49,40,32,0,34,49,560,53,1,32,33,17,3,41,17,560,48,48,560,21,33,37,32,32,513]

theorem envBound50975 : H12AffineFastState.Bounded env50975 := by
  intro p hp
  have h : env50975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50972_50975 : H12AffineEnvironment.transform 9 53 env50972 = env50975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env50972 == env50975) = true)

theorem identity50975 : scanCanonicalize (H12AffineFastState.compose env50975 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound50975 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50976 : List Nat := [2,4,8,16,26,16,9,31,512,15,522,11,18,26,0,24,11,522,15,1,26,27,17,3,19,17,522,10,10,522,21,27,31,26,26,513]

theorem envBound50976 : H12AffineFastState.Bounded env50976 := by
  intro p hp
  have h : env50976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50975_50976 : H12AffineEnvironment.transform 4 26 env50975 = env50976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env50975 == env50976) = true)

def leafEnv50976 : List Nat := [2,4,8,16,26,16,9,31,512,15,522,11,18,26,0,24,11,522,15,1,26,27,17,3,21,19,1,17,522,10,10,522,21,27,31,26,4,25,26,513,1,26,0]

def active50976 : List Nat := [0,1,2,3,8]

def tree50976 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50976 : H12WitnessSearch.Good tree50976 := H12GlobalWitnessIndex.good

theorem leafIdentity50976 : H12AffineFastState.composeSystem env50976 rootObs = leafEnv50976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50976 rootObs == leafEnv50976) = true)

theorem terminalChecked50976 : H12PackedTerminal.terminalCheckFast leafEnv50976 active50976 tree50976 = true := by decide +kernel

def env50977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,2097152,4194304,2101329,98780,8328,65,6352052,2098513,17665,2125160,2102685,6349852,256,21793,46213,2175562]

theorem envBound50977 : H12AffineFastState.Bounded env50977 := by
  intro p hp
  have h : env50977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50931_50977 : H12AffineEnvironment.transform 17 179513 env50931 = env50977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env50931 == env50977) = true)

def env50978 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,4194304,17,98780,8328,65,4259060,5393,17665,32040,1501,4256860,256,21793,46213,74250]

theorem envBound50978 : H12AffineFastState.Bounded env50978 := by
  intro p hp
  have h : env50978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50977_50978 : H12AffineEnvironment.transform 20 4160 env50977 = env50978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env50977 == env50978) = true)

theorem identity50978 : scanCanonicalize (H12AffineFastState.compose env50978 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 213351) := by decide +kernel

theorem selectedBound50978 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50979 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,213351,17,98780,8328,65,245139,5393,17665,32040,1501,243003,256,21793,46213,74250]

theorem envBound50979 : H12AffineFastState.Bounded env50979 := by
  intro p hp
  have h : env50979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50978_50979 : H12AffineEnvironment.transform 21 213351 env50978 = env50979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 213351 env50978 == env50979) = true)

def env50980 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,213351,17,98644,8192,65,245019,5393,17665,32040,1365,243003,256,21793,46093,74250]

theorem envBound50980 : H12AffineFastState.Bounded env50980 := by
  intro p hp
  have h : env50980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50979_50980 : H12AffineEnvironment.transform 6 8 env50979 = env50980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50979 == env50980) = true)

theorem identity50980 : scanCanonicalize (H12AffineFastState.compose env50980 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound50980 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50981 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,138340,1024,8540,4160,213351,17,73737,8192,65,203846,5393,17665,32040,1365,201830,256,21793,5456,74250]

theorem envBound50981 : H12AffineFastState.Bounded env50981 := by
  intro p hp
  have h : env50981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50980_50981 : H12AffineEnvironment.transform 14 8541 env50980 = env50981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env50980 == env50981) = true)

theorem identity50981 : scanCanonicalize (H12AffineFastState.compose env50981 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound50981 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env50982 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,80,65536,131072,138340,1024,81,4160,213351,17,65796,269,65,203846,5393,17665,23589,1365,201830,256,21793,5456,66311]

theorem envBound50982 : H12AffineFastState.Bounded env50982 := by
  intro p hp
  have h : env50982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50981_50982 : H12AffineEnvironment.transform 12 269 env50981 = env50982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env50981 == env50982) = true)

theorem identity50982 : scanCanonicalize (H12AffineFastState.compose env50982 (packedSelected [1,5,8,16,18,20,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound50982 : packedSelected [1,5,8,16,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env50983 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5456,80,65536,131072,138340,1024,81,4160,201783,17,65796,269,65,203846,5393,4177,2421,1365,201830,256,113,5456,66311]

theorem envBound50983 : H12AffineFastState.Bounded env50983 := by
  intro p hp
  have h : env50983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50982_50983 : H12AffineEnvironment.transform 13 5456 env50982 = env50983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env50982 == env50983) = true)

theorem identity50983 : scanCanonicalize (H12AffineFastState.compose env50983 (packedSelected [1,4,8,9,12,14,15,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound50983 : packedSelected [1,4,8,9,12,14,15,19,20] rootPS < 2^1333 := by decide +kernel

def env50984 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5456,80,35,131072,138340,1024,81,4160,136212,17,295,269,65,138341,5393,4177,2421,1365,136261,256,113,5456,804]

theorem envBound50984 : H12AffineFastState.Bounded env50984 := by
  intro p hp
  have h : env50984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50983_50984 : H12AffineEnvironment.transform 15 35 env50983 = env50984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env50983 == env50984) = true)

theorem identity50984 : scanCanonicalize (H12AffineFastState.compose env50984 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound50984 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env50985 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5456,80,35,5440,2340,1024,81,4160,340,17,295,269,65,2341,5393,4177,2421,1365,261,256,113,5456,804]

theorem envBound50985 : H12AffineFastState.Bounded env50985 := by
  intro p hp
  have h : env50985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50984_50985 : H12AffineEnvironment.transform 16 5440 env50984 = env50985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env50984 == env50985) = true)

theorem identity50985 : scanCanonicalize (H12AffineFastState.compose env50985 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound50985 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env50986 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,120,5157,80,35,5173,2129,1024,81,4160,33,17,82,120,65,2128,5220,4177,2048,1056,112,117,113,5157,593]

theorem envBound50986 : H12AffineFastState.Bounded env50986 := by
  intro p hp
  have h : env50986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50985_50986 : H12AffineEnvironment.transform 7 117 env50985 = env50986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env50985 == env50986) = true)

theorem identity50986 : scanCanonicalize (H12AffineFastState.compose env50986 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound50986 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env50987 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,3188,120,2129,80,35,2113,2129,1024,81,3124,33,17,82,120,65,2128,2064,3109,2048,1056,112,117,113,2129,593]

theorem envBound50987 : H12AffineFastState.Bounded env50987 := by
  intro p hp
  have h : env50987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50986_50987 : H12AffineEnvironment.transform 11 3188 env50986 = env50987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env50986 == env50987) = true)

theorem identity50987 : scanCanonicalize (H12AffineFastState.compose env50987 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50987 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env50988 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,3108,40,2049,0,35,2065,2049,1024,1,3124,33,17,2,40,17,2048,2064,3109,2048,1056,32,37,33,2049,513]

theorem envBound50988 : H12AffineFastState.Bounded env50988 := by
  intro p hp
  have h : env50988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50987_50988 : H12AffineEnvironment.transform 5 16 env50987 = env50988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50987 == env50988) = true)

theorem identity50988 : scanCanonicalize (H12AffineFastState.compose env50988 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound50988 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50989 : List Nat := [2,4,8,16,32,16,8,37,512,5,2048,2081,40,2049,0,35,2065,2049,5,1,2097,33,17,2,40,17,2048,2064,2080,2048,37,32,37,33,2049,513]

theorem envBound50989 : H12AffineFastState.Bounded env50989 := by
  intro p hp
  have h : env50989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50988_50989 : H12AffineEnvironment.transform 9 5 env50988 = env50989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env50988 == env50989) = true)

theorem identity50989 : scanCanonicalize (H12AffineFastState.compose env50989 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound50989 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50990 : List Nat := [2,4,8,16,32,16,8,37,512,5,512,545,40,513,0,35,529,513,5,1,561,33,17,2,40,17,512,528,544,512,37,32,37,33,513,513]

theorem envBound50990 : H12AffineFastState.Bounded env50990 := by
  intro p hp
  have h : env50990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50989_50990 : H12AffineEnvironment.transform 10 512 env50989 = env50990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env50989 == env50990) = true)

theorem identity50990 : scanCanonicalize (H12AffineFastState.compose env50990 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound50990 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env50991 : List Nat := [2,4,8,16,0,16,8,5,512,5,512,513,8,513,0,3,529,513,5,1,529,1,17,2,8,17,512,528,512,512,5,0,5,1,513,513]

theorem envBound50991 : H12AffineFastState.Bounded env50991 := by
  intro p hp
  have h : env50991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50990_50991 : H12AffineEnvironment.transform 4 0 env50990 = env50991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50990 == env50991) = true)

theorem identity50991 : scanCanonicalize (H12AffineFastState.compose env50991 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound50991 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env50992 : List Nat := [2,4,8,0,0,0,8,5,512,5,512,513,8,513,0,3,513,513,5,1,513,1,1,2,8,1,512,512,512,512,5,0,5,1,513,513]

theorem envBound50992 : H12AffineFastState.Bounded env50992 := by
  intro p hp
  have h : env50992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50991_50992 : H12AffineEnvironment.transform 3 0 env50991 = env50992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env50991 == env50992) = true)

theorem identity50992 : scanCanonicalize (H12AffineFastState.compose env50992 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound50992 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50993 : List Nat := [2,4,8,0,0,0,8,5,1,5,1,0,8,0,0,3,0,0,5,1,0,1,1,2,8,1,1,1,1,1,5,0,5,1,0,0]

theorem envBound50993 : H12AffineFastState.Bounded env50993 := by
  intro p hp
  have h : env50993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50992_50993 : H12AffineEnvironment.transform 8 1 env50992 = env50993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env50992 == env50993) = true)

theorem identity50993 : scanCanonicalize (H12AffineFastState.compose env50993 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound50993 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50994 : List Nat := [2,4,2,0,0,0,2,5,1,5,1,0,2,0,0,3,0,0,5,1,0,1,1,2,2,1,1,1,1,1,5,0,5,1,0,0]

theorem envBound50994 : H12AffineFastState.Bounded env50994 := by
  intro p hp
  have h : env50994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50993_50994 : H12AffineEnvironment.transform 2 2 env50993 = env50994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env50993 == env50994) = true)

def env50995 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,213351,17,98645,8193,65,245018,5393,17665,32040,1364,243003,256,21793,46092,74250]

theorem envBound50995 : H12AffineFastState.Bounded env50995 := by
  intro p hp
  have h : env50995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50979_50995 : H12AffineEnvironment.transform 6 9 env50979 = env50995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50979 == env50995) = true)

theorem identity50995 : scanCanonicalize (H12AffineFastState.compose env50995 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound50995 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env50996 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,179513,1024,32769,4160,201830,17,98645,8193,65,245018,5393,4096,10281,1364,243003,256,32,46092,74250]

theorem envBound50996 : H12AffineFastState.Bounded env50996 := by
  intro p hp
  have h : env50996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50995_50996 : H12AffineEnvironment.transform 13 5377 env50995 = env50996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env50995 == env50996) = true)

theorem identity50996 : scanCanonicalize (H12AffineFastState.compose env50996 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound50996 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env50997 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,32768,65536,131072,171108,1024,32769,4160,201830,17,98645,348,65,236615,5393,4096,2420,1364,234598,256,32,38225,66391]

theorem envBound50997 : H12AffineFastState.Bounded env50997 := by
  intro p hp
  have h : env50997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50996_50997 : H12AffineEnvironment.transform 12 349 env50996 = env50997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env50996 == env50997) = true)

theorem identity50997 : scanCanonicalize (H12AffineFastState.compose env50997 (packedSelected [1,3,4,8,9,10,12,14,15,16,24] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound50997 : packedSelected [1,3,4,8,9,10,12,14,15,16,24] rootPS < 2^1333 := by decide +kernel

def env50998 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,65536,131072,138341,1024,0,4160,201830,17,65876,348,65,203846,5393,4096,2420,1364,201831,256,32,5456,66391]

theorem envBound50998 : H12AffineFastState.Bounded env50998 := by
  intro p hp
  have h : env50998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50997_50998 : H12AffineEnvironment.transform 14 1 env50997 = env50998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env50997 == env50998) = true)

theorem identity50998 : scanCanonicalize (H12AffineFastState.compose env50998 (packedSelected [0,4,6,9,14,16,27] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound50998 : packedSelected [0,4,6,9,14,16,27] rootPS < 2^1333 := by decide +kernel

def env50999 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,65536,70726,67619,1024,0,4160,32,17,65876,348,65,2048,5393,4096,2420,1364,33,256,32,5456,66391]

theorem envBound50999 : H12AffineFastState.Bounded env50999 := by
  intro p hp
  have h : env50999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50998_50999 : H12AffineEnvironment.transform 16 70726 env50998 = env50999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env50998 == env50999) = true)

def env51000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,4194304,16,98780,8328,65,4259061,5392,17665,32041,1500,4256861,256,21793,46213,74251]

theorem envBound51000 : H12AffineFastState.Bounded env51000 := by
  intro p hp
  have h : env51000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50977_51000 : H12AffineEnvironment.transform 20 4161 env50977 = env51000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env50977 == env51000) = true)

theorem identity51000 : scanCanonicalize (H12AffineFastState.compose env51000 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound51000 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,179513,1024,32769,4161,4194304,16,21763,8328,65,4259061,5392,17665,32041,1500,4256861,256,21793,46213,63188]

theorem envBound51001 : H12AffineFastState.Bounded env51001 := by
  intro p hp
  have h : env51001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51000_51001 : H12AffineEnvironment.transform 15 54495 env51000 = env51001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env51000 == env51001) = true)

def env51002 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,179513,1024,32769,4161,4194304,16,21763,8192,65,4258941,5392,17665,32041,1364,4256861,256,21793,46093,63068]

theorem envBound51002 : H12AffineFastState.Bounded env51002 := by
  intro p hp
  have h : env51002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51001_51002 : H12AffineEnvironment.transform 6 8 env51001 = env51002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51001 == env51002) = true)

theorem identity51002 : scanCanonicalize (H12AffineFastState.compose env51002 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound51002 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51003 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,13389,35188,1024,32769,4161,4194304,16,21763,8192,65,4258941,5392,17665,32041,1364,4256861,256,21793,46093,63068]

theorem envBound51003 : H12AffineFastState.Bounded env51003 := by
  intro p hp
  have h : env51003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51002_51003 : H12AffineEnvironment.transform 16 13389 env51002 = env51003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env51002 == env51003) = true)

theorem identity51003 : scanCanonicalize (H12AffineFastState.compose env51003 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 62589) := by decide +kernel

theorem selectedBound51003 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env51004 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,13389,35188,1024,32769,4161,62589,16,21763,8192,65,2048,5392,17665,32041,1364,32,256,21793,46093,63068]

theorem envBound51004 : H12AffineFastState.Bounded env51004 := by
  intro p hp
  have h : env51004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51003_51004 : H12AffineEnvironment.transform 21 62589 env51003 = env51004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62589 env51003 == env51004) = true)

theorem identity51004 : scanCanonicalize (H12AffineFastState.compose env51004 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound51004 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env51005 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,54359,5392,35188,1024,32769,4161,54560,16,21763,349,65,2048,5392,17665,23668,1364,32,256,21793,38224,55041]

theorem envBound51005 : H12AffineFastState.Bounded env51005 := by
  intro p hp
  have h : env51005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51004_51005 : H12AffineEnvironment.transform 12 349 env51004 = env51005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env51004 == env51005) = true)

theorem identity51005 : scanCanonicalize (H12AffineFastState.compose env51005 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound51005 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51006 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1,21590,5392,2421,1024,0,4161,21793,16,21763,349,65,2048,5392,17665,23668,1364,32,256,21793,5457,22272]

theorem envBound51006 : H12AffineFastState.Bounded env51006 := by
  intro p hp
  have h : env51006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51005_51006 : H12AffineEnvironment.transform 14 1 env51005 = env51006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env51005 == env51006) = true)

theorem identity51006 : scanCanonicalize (H12AffineFastState.compose env51006 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound51006 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51007 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1,343,5392,2421,1024,0,4161,32,16,2,349,65,2048,5392,4096,2421,1364,32,256,32,5457,513]

theorem envBound51007 : H12AffineFastState.Bounded env51007 := by
  intro p hp
  have h : env51007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51006_51007 : H12AffineEnvironment.transform 13 5377 env51006 = env51007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env51006 == env51007) = true)

theorem identity51007 : scanCanonicalize (H12AffineFastState.compose env51007 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 612) := by decide +kernel

theorem selectedBound51007 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51008 : List Nat := [2,4,8,16,32,64,8,256,512,612,2048,4096,349,4965,1,343,4980,2421,612,0,4161,32,16,2,349,65,2048,4980,4096,2421,816,32,256,32,4917,513]

theorem envBound51008 : H12AffineFastState.Bounded env51008 := by
  intro p hp
  have h : env51008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51007_51008 : H12AffineEnvironment.transform 9 612 env51007 = env51008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 612 env51007 == env51008) = true)

theorem identity51008 : scanCanonicalize (H12AffineFastState.compose env51008 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51008 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51009 : List Nat := [2,4,8,16,32,17,8,256,512,565,2048,4096,268,4916,1,262,4901,2340,565,0,4112,32,16,2,268,16,2048,4901,4096,2340,816,32,256,32,4917,513]

theorem envBound51009 : H12AffineFastState.Bounded env51009 := by
  intro p hp
  have h : env51009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51008_51009 : H12AffineEnvironment.transform 5 17 env51008 = env51009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51008 == env51009) = true)

theorem identity51009 : scanCanonicalize (H12AffineFastState.compose env51009 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound51009 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51010 : List Nat := [2,4,8,16,32,17,8,256,512,565,2048,0,268,820,1,262,805,2340,565,0,16,32,16,2,268,16,2048,805,0,2340,816,32,256,32,821,513]

theorem envBound51010 : H12AffineFastState.Bounded env51010 := by
  intro p hp
  have h : env51010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51009_51010 : H12AffineEnvironment.transform 11 0 env51009 = env51010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env51009 == env51010) = true)

theorem identity51010 : scanCanonicalize (H12AffineFastState.compose env51010 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound51010 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51011 : List Nat := [2,4,8,16,32,17,8,52,512,565,2048,0,56,512,1,50,529,2064,565,0,16,32,16,2,56,16,2048,529,0,2064,516,32,52,32,513,513]

theorem envBound51011 : H12AffineFastState.Bounded env51011 := by
  intro p hp
  have h : env51011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51010_51011 : H12AffineEnvironment.transform 7 52 env51010 = env51011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env51010 == env51011) = true)

theorem identity51011 : scanCanonicalize (H12AffineFastState.compose env51011 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound51011 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env51012 : List Nat := [2,4,8,16,32,17,8,52,512,565,528,0,56,512,1,50,529,512,565,0,16,32,16,2,56,16,528,529,0,512,516,32,52,32,513,513]

theorem envBound51012 : H12AffineFastState.Bounded env51012 := by
  intro p hp
  have h : env51012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51011_51012 : H12AffineEnvironment.transform 10 528 env51011 = env51012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env51011 == env51012) = true)

theorem identity51012 : scanCanonicalize (H12AffineFastState.compose env51012 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound51012 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env51013 : List Nat := [2,4,8,0,32,1,8,36,512,549,512,0,40,512,1,34,513,512,549,0,0,32,0,2,40,0,512,513,0,512,516,32,36,32,513,513]

theorem envBound51013 : H12AffineFastState.Bounded env51013 := by
  intro p hp
  have h : env51013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51012_51013 : H12AffineEnvironment.transform 3 0 env51012 = env51013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env51012 == env51013) = true)

def env51014 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,179513,1024,32769,4161,4194304,16,21763,8193,65,4258940,5392,17665,32041,1365,4256861,256,21793,46092,63069]

theorem envBound51014 : H12AffineFastState.Bounded env51014 := by
  intro p hp
  have h : env51014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51001_51014 : H12AffineEnvironment.transform 6 9 env51001 = env51014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51001 == env51014) = true)

theorem identity51014 : scanCanonicalize (H12AffineFastState.compose env51014 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound51014 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51015 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38161,10280,1024,32769,4161,4194304,16,21763,8193,65,4258940,5392,17665,32041,1365,4256861,256,21793,46092,63069]

theorem envBound51015 : H12AffineFastState.Bounded env51015 := by
  intro p hp
  have h : env51015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51014_51015 : H12AffineEnvironment.transform 16 38161 env51014 = env51015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env51014 == env51015) = true)

theorem identity51015 : scanCanonicalize (H12AffineFastState.compose env51015 (packedSelected [0,3,4,5,7,10,18,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 29741) := by decide +kernel

theorem selectedBound51015 : packedSelected [0,3,4,5,7,10,18,22,23] rootPS < 2^1333 := by decide +kernel

def env51016 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38161,10280,1024,32769,4161,29741,16,21763,8193,65,34897,5392,17665,32041,1365,32880,256,21793,46092,63069]

theorem envBound51016 : H12AffineFastState.Bounded env51016 := by
  intro p hp
  have h : env51016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51015_51016 : H12AffineEnvironment.transform 21 29741 env51015 = env51016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29741 env51015 == env51016) = true)

theorem identity51016 : scanCanonicalize (H12AffineFastState.compose env51016 (packedSelected [1,2,3,4,5,6,8,10,11,18,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound51016 : packedSelected [1,2,3,4,5,6,8,10,11,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env51017 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,21590,5393,10280,1024,1,4161,29741,16,21763,8193,65,2129,5392,17665,32041,1365,112,256,21793,13324,30301]

theorem envBound51017 : H12AffineFastState.Bounded env51017 := by
  intro p hp
  have h : env51017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51016_51017 : H12AffineEnvironment.transform 14 0 env51016 = env51017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env51016 == env51017) = true)

theorem identity51017 : scanCanonicalize (H12AffineFastState.compose env51017 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound51017 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env51018 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,0,342,5393,10280,1024,1,4161,8493,16,3,8193,65,2129,5392,4097,10281,1365,112,256,33,13324,9053]

theorem envBound51018 : H12AffineFastState.Bounded env51018 := by
  intro p hp
  have h : env51018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51017_51018 : H12AffineEnvironment.transform 13 5376 env51017 = env51018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env51017 == env51018) = true)

theorem identity51018 : scanCanonicalize (H12AffineFastState.compose env51018 (packedSelected [4,9,12,14,15,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51018 : packedSelected [4,9,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env51019 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,0,263,5393,10280,1024,1,4112,8493,16,3,8193,16,2048,5392,4097,10281,1284,33,256,33,13324,8972]

theorem envBound51019 : H12AffineFastState.Bounded env51019 := by
  intro p hp
  have h : env51019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51018_51019 : H12AffineEnvironment.transform 5 17 env51018 = env51019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51018 == env51019) = true)

theorem identity51019 : scanCanonicalize (H12AffineFastState.compose env51019 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound51019 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env51020 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,4096,8192,5124,0,3,5141,10280,1024,1,4112,8233,16,3,8193,16,2048,5140,4097,10281,1024,33,4,33,13324,8712]

theorem envBound51020 : H12AffineFastState.Bounded env51020 := by
  intro p hp
  have h : env51020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51019_51020 : H12AffineEnvironment.transform 7 4 env51019 = env51020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env51019 == env51020) = true)

theorem identity51020 : scanCanonicalize (H12AffineFastState.compose env51020 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(12+1) ^^^ 5693) := by decide +kernel

theorem selectedBound51020 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env51021 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,4096,5693,5124,0,3,5141,7701,1024,1,4112,5652,16,3,5692,16,2048,5140,4097,7700,1024,33,4,33,561,5173]

theorem envBound51021 : H12AffineFastState.Bounded env51021 := by
  intro p hp
  have h : env51021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51020_51021 : H12AffineEnvironment.transform 12 5693 env51020 = env51021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5693 env51020 == env51021) = true)

theorem identity51021 : scanCanonicalize (H12AffineFastState.compose env51021 (packedSelected [1,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1029) := by decide +kernel

theorem selectedBound51021 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env51022 : List Nat := [2,4,8,16,32,17,9,4,512,1024,1029,4096,5693,5124,0,3,5141,4624,1024,1,4112,5652,16,3,5692,16,1029,5140,4097,4625,1024,33,4,33,561,5173]

theorem envBound51022 : H12AffineFastState.Bounded env51022 := by
  intro p hp
  have h : env51022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51021_51022 : H12AffineEnvironment.transform 10 1029 env51021 = env51022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1029 env51021 == env51022) = true)

theorem identity51022 : scanCanonicalize (H12AffineFastState.compose env51022 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound51022 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env51023 : List Nat := [2,4,8,16,32,17,9,4,512,1024,1029,17,1580,1045,0,3,1028,513,1024,1,1,1541,16,3,1581,16,1029,1029,16,512,1024,33,4,33,561,1060]

theorem envBound51023 : H12AffineFastState.Bounded env51023 := by
  intro p hp
  have h : env51023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51022_51023 : H12AffineEnvironment.transform 11 17 env51022 = env51023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env51022 == env51023) = true)

theorem identity51023 : scanCanonicalize (H12AffineFastState.compose env51023 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound51023 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51024 : List Nat := [2,4,8,16,32,17,9,4,0,1024,1029,17,1068,1045,0,3,1028,1,1024,1,1,1029,16,3,1069,16,1029,1029,16,0,1024,33,4,33,49,1060]

theorem envBound51024 : H12AffineFastState.Bounded env51024 := by
  intro p hp
  have h : env51024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51023_51024 : H12AffineEnvironment.transform 8 0 env51023 = env51024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env51023 == env51024) = true)

theorem identity51024 : scanCanonicalize (H12AffineFastState.compose env51024 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound51024 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env51025 : List Nat := [2,4,8,16,32,17,9,4,0,52,49,17,24,33,0,3,48,1,52,1,1,49,16,3,25,16,49,49,16,0,52,33,4,33,49,16]

theorem envBound51025 : H12AffineFastState.Bounded env51025 := by
  intro p hp
  have h : env51025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51024_51025 : H12AffineEnvironment.transform 9 52 env51024 = env51025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env51024 == env51025) = true)

theorem identity51025 : scanCanonicalize (H12AffineFastState.compose env51025 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound51025 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env51026 : List Nat := [2,4,8,1,32,0,9,4,0,37,32,0,9,33,0,3,33,1,37,1,1,32,1,3,8,1,32,32,1,0,37,33,4,33,32,1]

theorem envBound51026 : H12AffineFastState.Bounded env51026 := by
  intro p hp
  have h : env51026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51025_51026 : H12AffineEnvironment.transform 3 1 env51025 = env51026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env51025 == env51026) = true)

theorem identity51026 : scanCanonicalize (H12AffineFastState.compose env51026 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51026 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51027 : List Nat := [2,4,8,1,0,0,9,4,0,5,0,0,9,1,0,3,1,1,5,1,1,0,1,3,8,1,0,0,1,0,5,1,4,1,0,1]

theorem envBound51027 : H12AffineFastState.Bounded env51027 := by
  intro p hp
  have h : env51027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51026_51027 : H12AffineEnvironment.transform 4 0 env51026 = env51027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51026 == env51027) = true)

theorem identity51027 : scanCanonicalize (H12AffineFastState.compose env51027 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound51027 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51028 : List Nat := [2,4,3,1,0,0,2,4,0,5,0,0,2,1,0,3,1,1,5,1,1,0,1,3,3,1,0,0,1,0,5,1,4,1,0,1]

theorem envBound51028 : H12AffineFastState.Bounded env51028 := by
  intro p hp
  have h : env51028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51027_51028 : H12AffineEnvironment.transform 2 3 env51027 = env51028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env51027 == env51028) = true)

def env51029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830977,25265168,23160256,257,27378861,27337992,25207750]

theorem envBound51029 : H12AffineFastState.Bounded env51029 := by
  intro p hp
  have h : env51029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50837_51029 : H12AffineEnvironment.transform 18 1025 env50837 = env51029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env50837 == env51029) = true)

theorem identity51029 : scanCanonicalize (H12AffineFastState.compose env51029 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2444776) := by decide +kernel

theorem selectedBound51029 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env51030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2444776,8328,65,14847465,313700,10507600,8830977,10799608,4466728,257,8685893,8677600,10874414]

theorem envBound51030 : H12AffineFastState.Bounded env51030 := by
  intro p hp
  have h : env51030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51029_51030 : H12AffineEnvironment.transform 23 2444776 env51029 = env51030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2444776 env51029 == env51030) = true)

def env51031 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318564,2444776,8328,65,6705549,313700,2394420,138341,2102684,4466728,257,21793,46212,2175562]

theorem envBound51031 : H12AffineFastState.Bounded env51031 := by
  intro p hp
  have h : env51031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51030_51031 : H12AffineEnvironment.transform 22 318564 env51030 = env51031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 318564 env51030 == env51031) = true)

def env51032 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318564,2444640,8192,65,6705413,313700,2394420,138341,2102548,4466728,257,21793,46092,2175562]

theorem envBound51032 : H12AffineFastState.Bounded env51032 := by
  intro p hp
  have h : env51032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51031_51032 : H12AffineEnvironment.transform 6 8 env51031 = env51032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51031 == env51032) = true)

theorem identity51032 : scanCanonicalize (H12AffineFastState.compose env51032 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound51032 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env51033 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,77899,4194304,318564,294187,8192,65,4677966,313700,375167,138341,75103,4466728,257,21793,46092,513]

theorem envBound51033 : H12AffineFastState.Bounded env51033 := by
  intro p hp
  have h : env51033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51032_51033 : H12AffineEnvironment.transform 20 77899 env51032 = env51033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env51032 == env51033) = true)

def env51034 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,77899,4194304,62540,21763,8192,65,4409702,57676,102743,138341,75103,4194304,257,21793,46092,513]

theorem envBound51034 : H12AffineFastState.Bounded env51034 := by
  intro p hp
  have h : env51034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51033_51034 : H12AffineEnvironment.transform 17 10280 env51033 = env51034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env51033 == env51034) = true)

def env51035 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10280,1025,29789,77899,4194304,16,21763,8192,65,4409702,5392,91403,138341,75103,4194304,257,21793,16464,513]

theorem envBound51035 : H12AffineFastState.Bounded env51035 := by
  intro p hp
  have h : env51035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51034_51035 : H12AffineEnvironment.transform 14 29788 env51034 = env51035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env51034 == env51035) = true)

theorem identity51035 : scanCanonicalize (H12AffineFastState.compose env51035 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound51035 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env51036 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90139,10280,1025,29789,77899,4194304,16,21763,8192,65,4204925,5392,91403,97406,75103,4194304,257,21793,16464,513]

theorem envBound51036 : H12AffineFastState.Bounded env51036 := by
  intro p hp
  have h : env51036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51035_51036 : H12AffineEnvironment.transform 16 90139 env51035 = env51036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env51035 == env51036) = true)

theorem identity51036 : scanCanonicalize (H12AffineFastState.compose env51036 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 73771) := by decide +kernel

theorem selectedBound51036 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51037 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90139,10280,1025,29789,77899,73771,16,21763,8192,65,67926,5392,91403,97406,75103,73771,257,21793,16464,513]

theorem envBound51037 : H12AffineFastState.Bounded env51037 := by
  intro p hp
  have h : env51037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51036_51037 : H12AffineEnvironment.transform 21 73771 env51036 = env51037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73771 env51036 == env51037) = true)

theorem identity51037 : scanCanonicalize (H12AffineFastState.compose env51037 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound51037 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env51038 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,16401,10280,1025,29789,4161,33,16,21763,8192,65,10588,5392,17665,23668,1365,33,257,21793,16464,513]

theorem envBound51038 : H12AffineFastState.Bounded env51038 := by
  intro p hp
  have h : env51038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51037_51038 : H12AffineEnvironment.transform 15 8202 env51037 = env51038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env51037 == env51038) = true)

theorem identity51038 : scanCanonicalize (H12AffineFastState.compose env51038 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound51038 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env51039 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8461,8202,5440,10280,1025,8460,4161,33,16,82,8192,65,10588,5392,4176,2341,1365,33,257,112,5377,513]

theorem envBound51039 : H12AffineFastState.Bounded env51039 := by
  intro p hp
  have h : env51039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51038_51039 : H12AffineEnvironment.transform 13 5457 env51038 = env51039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env51038 == env51039) = true)

theorem identity51039 : scanCanonicalize (H12AffineFastState.compose env51039 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound51039 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env51040 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,356,8192,1077,8461,8202,1060,10280,1025,8460,293,33,16,82,8192,65,10588,1140,308,2341,1365,33,257,112,1125,513]

theorem envBound51040 : H12AffineFastState.Bounded env51040 := by
  intro p hp
  have h : env51040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51039_51040 : H12AffineEnvironment.transform 11 356 env51039 = env51040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env51039 == env51040) = true)

theorem identity51040 : scanCanonicalize (H12AffineFastState.compose env51040 (packedSelected [0,1,5,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound51040 : packedSelected [0,1,5,6,7] rootPS < 2^1333 := by decide +kernel

def env51041 : List Nat := [2,4,8,16,32,32,8,256,512,1024,2048,260,8192,1077,8461,8202,1060,10280,1025,8460,293,33,16,50,8192,33,10556,1044,308,2341,1333,33,257,16,1029,513]

theorem envBound51041 : H12AffineFastState.Bounded env51041 := by
  intro p hp
  have h : env51041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51040_51041 : H12AffineEnvironment.transform 5 32 env51040 = env51041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env51040 == env51041) = true)

theorem identity51041 : scanCanonicalize (H12AffineFastState.compose env51041 (packedSelected [1,5,6,11] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound51041 : packedSelected [1,5,6,11] rootPS < 2^1333 := by decide +kernel

def env51042 : List Nat := [2,4,8,16,17,17,8,256,512,1024,2048,260,8192,1028,8461,8202,1045,10265,1025,8460,276,16,16,3,8192,16,10509,1044,261,2324,1284,16,257,16,1029,513]

theorem envBound51042 : H12AffineFastState.Bounded env51042 := by
  intro p hp
  have h : env51042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51041_51042 : H12AffineEnvironment.transform 4 17 env51041 = env51042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env51041 == env51042) = true)

theorem identity51042 : scanCanonicalize (H12AffineFastState.compose env51042 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound51042 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51043 : List Nat := [2,4,8,16,17,17,8,5,512,1024,2048,1,8192,1028,8200,8202,1045,10265,1025,8201,17,16,16,3,8192,16,10248,1044,0,2065,1025,16,4,16,1029,513]

theorem envBound51043 : H12AffineFastState.Bounded env51043 := by
  intro p hp
  have h : env51043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51042_51043 : H12AffineEnvironment.transform 7 5 env51042 = env51043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env51042 == env51043) = true)

theorem identity51043 : scanCanonicalize (H12AffineFastState.compose env51043 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound51043 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env51044 : List Nat := [2,4,8,16,17,17,8,5,512,1024,2048,1,9,1028,1,3,1045,2064,1025,0,17,16,16,3,9,16,2049,1044,0,2065,1025,16,4,16,1029,513]

theorem envBound51044 : H12AffineFastState.Bounded env51044 := by
  intro p hp
  have h : env51044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51043_51044 : H12AffineEnvironment.transform 12 9 env51043 = env51044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env51043 == env51044) = true)

def env51045 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10280,1025,29788,77899,4194304,17,21763,8192,65,4409702,5393,91402,138341,75103,4194304,257,21793,16465,513]

theorem envBound51045 : H12AffineFastState.Bounded env51045 := by
  intro p hp
  have h : env51045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51034_51045 : H12AffineEnvironment.transform 14 29789 env51034 = env51045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env51034 == env51045) = true)

def env51046 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10280,1025,29788,77899,21792,17,21763,8192,65,203846,5393,91402,138341,75103,21792,257,21793,16465,513]

theorem envBound51046 : H12AffineFastState.Bounded env51046 := by
  intro p hp
  have h : env51046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51045_51046 : H12AffineEnvironment.transform 21 21792 env51045 = env51046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env51045 == env51046) = true)

theorem identity51046 : scanCanonicalize (H12AffineFastState.compose env51046 (packedSelected [0,7,11,12,15,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound51046 : packedSelected [0,7,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env51047 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,81,65536,131072,10280,1025,80,77899,8492,17,8463,8192,65,203846,5393,69894,138341,75103,8492,257,8493,13405,513]

theorem envBound51047 : H12AffineFastState.Bounded env51047 := by
  intro p hp
  have h : env51047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51046_51047 : H12AffineEnvironment.transform 13 13324 env51046 = env51047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env51046 == env51047) = true)

theorem identity51047 : scanCanonicalize (H12AffineFastState.compose env51047 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound51047 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env51048 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,81,343,131072,10280,1025,80,12572,8492,17,8463,8192,65,138513,5393,4177,138341,9224,8492,257,8493,13405,513]

theorem envBound51048 : H12AffineFastState.Bounded env51048 := by
  intro p hp
  have h : env51048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51047_51048 : H12AffineEnvironment.transform 15 343 env51047 = env51048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env51047 == env51048) = true)

theorem identity51048 : scanCanonicalize (H12AffineFastState.compose env51048 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound51048 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env51049 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,81,343,131072,2341,1025,80,4113,33,17,2,269,65,138513,5393,4177,138341,1285,33,257,32,5456,513]

theorem envBound51049 : H12AffineFastState.Bounded env51049 := by
  intro p hp
  have h : env51049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51048_51049 : H12AffineEnvironment.transform 12 269 env51048 = env51049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env51048 == env51049) = true)

theorem identity51049 : scanCanonicalize (H12AffineFastState.compose env51049 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound51049 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env51050 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,81,343,5393,2341,1025,80,4113,33,17,2,269,65,2048,5393,4177,2420,1285,33,257,32,5456,513]

theorem envBound51050 : H12AffineFastState.Bounded env51050 := by
  intro p hp
  have h : env51050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51049_51050 : H12AffineEnvironment.transform 16 5393 env51049 = env51050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env51049 == env51050) = true)

theorem identity51050 : scanCanonicalize (H12AffineFastState.compose env51050 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51050 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51051 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,0,262,5393,2341,1025,1,4113,33,17,2,269,16,2048,5393,4096,2341,1285,33,257,32,5377,513]

theorem envBound51051 : H12AffineFastState.Bounded env51051 := by
  intro p hp
  have h : env51051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51050_51051 : H12AffineEnvironment.transform 5 17 env51050 = env51051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51050 == env51051) = true)

theorem identity51051 : scanCanonicalize (H12AffineFastState.compose env51051 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound51051 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51052 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,5156,0,35,5172,2048,1025,1,4113,33,17,2,40,16,2048,5172,4096,2048,1056,33,36,32,5156,513]

theorem envBound51052 : H12AffineFastState.Bounded env51052 := by
  intro p hp
  have h : env51052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51051_51052 : H12AffineEnvironment.transform 7 37 env51051 = env51052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env51051 == env51052) = true)

def env51053 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,40,1044,0,35,1028,2048,1025,1,33,33,17,2,40,16,2048,1028,48,2048,1056,33,36,32,1044,513]

theorem envBound51053 : H12AffineFastState.Bounded env51053 := by
  intro p hp
  have h : env51053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51052_51053 : H12AffineEnvironment.transform 11 48 env51052 = env51053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env51052 == env51053) = true)

theorem identity51053 : scanCanonicalize (H12AffineFastState.compose env51053 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound51053 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51054 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1044,48,40,1044,0,35,1028,1044,1025,1,33,33,17,2,40,16,1044,1028,48,1044,1056,33,36,32,1044,513]

theorem envBound51054 : H12AffineFastState.Bounded env51054 := by
  intro p hp
  have h : env51054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51053_51054 : H12AffineEnvironment.transform 10 1044 env51053 = env51054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env51053 == env51054) = true)

def env51055 : List Nat := [2,4,8,16,32,17,8,37,512,52,32,48,40,32,0,35,48,32,53,1,33,33,17,2,40,16,32,48,48,32,20,33,36,32,32,513]

theorem envBound51055 : H12AffineFastState.Bounded env51055 := by
  intro p hp
  have h : env51055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51054_51055 : H12AffineEnvironment.transform 9 52 env51054 = env51055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env51054 == env51055) = true)

theorem identity51055 : scanCanonicalize (H12AffineFastState.compose env51055 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51055 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51056 : List Nat := [2,4,8,16,1,17,8,4,512,21,1,17,9,1,0,2,17,1,20,1,0,0,17,2,9,16,1,17,17,1,20,0,5,1,1,513]

theorem envBound51056 : H12AffineFastState.Bounded env51056 := by
  intro p hp
  have h : env51056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51055_51056 : H12AffineEnvironment.transform 4 1 env51055 = env51056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51055 == env51056) = true)

def leafEnv51056 : List Nat := [2,4,8,16,1,17,8,4,512,21,1,17,9,1,0,2,17,1,20,1,0,0,17,2,21,9,1,16,1,17,17,1,20,0,5,1,5,2,1,513,1,0,0]

def active51056 : List Nat := [0,1,2,3,8]

def tree51056 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51056 : H12WitnessSearch.Good tree51056 := H12GlobalWitnessIndex.good

theorem leafIdentity51056 : H12AffineFastState.composeSystem env51056 rootObs = leafEnv51056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51056 rootObs == leafEnv51056) = true)

theorem terminalChecked51056 : H12PackedTerminal.terminalCheckFast leafEnv51056 active51056 tree51056 = true := by decide +kernel

def env51057 : List Nat := [2,4,8,16,32,17,8,37,512,53,33,48,40,33,0,35,49,33,52,1,33,33,17,2,40,16,33,49,48,33,21,33,36,32,33,513]

theorem envBound51057 : H12AffineFastState.Bounded env51057 := by
  intro p hp
  have h : env51057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51054_51057 : H12AffineEnvironment.transform 9 53 env51054 = env51057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env51054 == env51057) = true)

theorem identity51057 : scanCanonicalize (H12AffineFastState.compose env51057 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound51057 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51058 : List Nat := [2,4,8,16,32,17,8,37,11,53,33,48,40,33,0,35,49,33,52,1,33,33,17,2,40,16,33,49,48,33,21,33,36,32,33,10]

theorem envBound51058 : H12AffineFastState.Bounded env51058 := by
  intro p hp
  have h : env51058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51057_51058 : H12AffineEnvironment.transform 8 11 env51057 = env51058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env51057 == env51058) = true)

def leafEnv51058 : List Nat := [2,4,8,16,32,17,8,37,11,53,33,48,40,33,0,35,49,33,52,1,33,33,17,2,20,40,1,16,33,49,48,33,21,33,36,32,5,35,33,10,1,33,0]

def active51058 : List Nat := [0,1,2,3,4]

def tree51058 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51058 : H12WitnessSearch.Good tree51058 := H12GlobalWitnessIndex.good

theorem leafIdentity51058 : H12AffineFastState.composeSystem env51058 rootObs = leafEnv51058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51058 rootObs == leafEnv51058) = true)

theorem terminalChecked51058 : H12PackedTerminal.terminalCheckFast leafEnv51058 active51058 tree51058 = true := by decide +kernel

def env51059 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,49,40,1045,0,35,1029,2048,1025,1,32,33,17,2,40,16,2048,1029,49,2048,1056,33,36,32,1045,513]

theorem envBound51059 : H12AffineFastState.Bounded env51059 := by
  intro p hp
  have h : env51059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51052_51059 : H12AffineEnvironment.transform 11 49 env51052 = env51059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env51052 == env51059) = true)

theorem identity51059 : scanCanonicalize (H12AffineFastState.compose env51059 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound51059 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51060 : List Nat := [2,4,8,16,32,17,8,37,512,1024,32,49,40,1045,0,35,1029,32,1025,1,32,33,17,2,40,16,32,1029,49,32,1056,33,36,32,1045,513]

theorem envBound51060 : H12AffineFastState.Bounded env51060 := by
  intro p hp
  have h : env51060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51059_51060 : H12AffineEnvironment.transform 10 32 env51059 = env51060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env51059 == env51060) = true)

def env51061 : List Nat := [2,4,8,16,32,17,8,37,512,52,32,49,40,33,0,35,49,32,53,1,32,33,17,2,40,16,32,49,49,32,20,33,36,32,33,513]

theorem envBound51061 : H12AffineFastState.Bounded env51061 := by
  intro p hp
  have h : env51061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51060_51061 : H12AffineEnvironment.transform 9 52 env51060 = env51061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env51060 == env51061) = true)

theorem identity51061 : scanCanonicalize (H12AffineFastState.compose env51061 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51061 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51062 : List Nat := [2,4,8,16,1,17,8,4,512,21,1,16,9,0,0,2,16,1,20,1,1,0,17,2,9,16,1,16,16,1,20,0,5,1,0,513]

theorem envBound51062 : H12AffineFastState.Bounded env51062 := by
  intro p hp
  have h : env51062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51061_51062 : H12AffineEnvironment.transform 4 1 env51061 = env51062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51061 == env51062) = true)

def leafEnv51062 : List Nat := [2,4,8,16,1,17,8,4,512,21,1,16,9,0,0,2,16,1,20,1,1,0,17,2,21,9,1,16,1,16,16,1,20,0,5,1,5,2,0,513,1,1,0]

def active51062 : List Nat := [0,1,2,3,8]

def tree51062 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51062 : H12WitnessSearch.Good tree51062 := H12GlobalWitnessIndex.good

theorem leafIdentity51062 : H12AffineFastState.composeSystem env51062 rootObs = leafEnv51062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51062 rootObs == leafEnv51062) = true)

theorem terminalChecked51062 : H12PackedTerminal.terminalCheckFast leafEnv51062 active51062 tree51062 = true := by decide +kernel

def env51063 : List Nat := [2,4,8,16,32,17,8,37,512,53,32,49,40,32,0,35,48,32,52,1,32,33,17,2,40,16,32,48,49,32,21,33,36,32,32,513]

theorem envBound51063 : H12AffineFastState.Bounded env51063 := by
  intro p hp
  have h : env51063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51060_51063 : H12AffineEnvironment.transform 9 53 env51060 = env51063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env51060 == env51063) = true)

theorem identity51063 : scanCanonicalize (H12AffineFastState.compose env51063 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound51063 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51064 : List Nat := [2,4,8,16,32,17,8,37,10,53,32,49,40,32,0,35,48,32,52,1,32,33,17,2,40,16,32,48,49,32,21,33,36,32,32,11]

theorem envBound51064 : H12AffineFastState.Bounded env51064 := by
  intro p hp
  have h : env51064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51063_51064 : H12AffineEnvironment.transform 8 10 env51063 = env51064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env51063 == env51064) = true)

def leafEnv51064 : List Nat := [2,4,8,16,32,17,8,37,10,53,32,49,40,32,0,35,48,32,52,1,32,33,17,2,20,40,1,16,32,48,49,32,21,33,36,32,5,35,32,11,1,32,0]

def active51064 : List Nat := [0,1,2,3,4]

def tree51064 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51064 : H12WitnessSearch.Good tree51064 := H12GlobalWitnessIndex.good

theorem leafIdentity51064 : H12AffineFastState.composeSystem env51064 rootObs = leafEnv51064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51064 rootObs == leafEnv51064) = true)

theorem terminalChecked51064 : H12PackedTerminal.terminalCheckFast leafEnv51064 active51064 tree51064 = true := by decide +kernel

def env51065 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10280,1025,29788,77899,21793,17,21763,8192,65,203847,5393,91402,138341,75103,21793,257,21793,16465,513]

theorem envBound51065 : H12AffineFastState.Bounded env51065 := by
  intro p hp
  have h : env51065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51045_51065 : H12AffineEnvironment.transform 21 21793 env51045 = env51065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env51045 == env51065) = true)

theorem identity51065 : scanCanonicalize (H12AffineFastState.compose env51065 (packedSelected [0,7,11,12,15,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound51065 : packedSelected [0,7,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env51066 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,1,65536,131072,10280,1025,0,77899,8573,17,8543,8192,65,203847,5393,69974,138341,75103,8573,257,8573,13325,513]

theorem envBound51066 : H12AffineFastState.Bounded env51066 := by
  intro p hp
  have h : env51066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51065_51066 : H12AffineEnvironment.transform 13 13404 env51065 = env51066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env51065 == env51066) = true)

theorem identity51066 : scanCanonicalize (H12AffineFastState.compose env51066 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound51066 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env51067 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,1,8283,131072,10280,1025,0,4112,8573,17,8543,8192,65,146460,5393,12557,138341,1284,8573,257,8573,13325,513]

theorem envBound51067 : H12AffineFastState.Bounded env51067 := by
  intro p hp
  have h : env51067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51066_51067 : H12AffineEnvironment.transform 15 8283 env51066 = env51067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env51066 == env51067) = true)

theorem identity51067 : scanCanonicalize (H12AffineFastState.compose env51067 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound51067 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env51068 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,1,8283,5441,10280,1025,0,4112,8573,17,8543,8192,65,10589,5393,12557,2340,1284,8573,257,8573,13325,513]

theorem envBound51068 : H12AffineFastState.Bounded env51068 := by
  intro p hp
  have h : env51068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51067_51068 : H12AffineEnvironment.transform 16 5441 env51067 = env51068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env51067 == env51068) = true)

theorem identity51068 : scanCanonicalize (H12AffineFastState.compose env51068 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound51068 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env51069 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,1,263,5441,2420,1025,0,4112,33,17,3,348,65,2049,5393,4177,2340,1284,33,257,33,5457,513]

theorem envBound51069 : H12AffineFastState.Bounded env51069 := by
  intro p hp
  have h : env51069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51068_51069 : H12AffineEnvironment.transform 12 348 env51068 = env51069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env51068 == env51069) = true)

theorem identity51069 : scanCanonicalize (H12AffineFastState.compose env51069 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51069 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51070 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,1,263,5393,2340,1025,0,4112,33,17,3,268,17,2049,5393,4097,2340,1284,33,257,33,5377,513]

theorem envBound51070 : H12AffineFastState.Bounded env51070 := by
  intro p hp
  have h : env51070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51069_51070 : H12AffineEnvironment.transform 5 16 env51069 = env51070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51069 == env51070) = true)

theorem identity51070 : scanCanonicalize (H12AffineFastState.compose env51070 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound51070 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51071 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1,268,1281,1,263,1296,2340,1025,0,17,33,17,3,268,17,2049,1296,0,2340,1284,33,257,33,1280,513]

theorem envBound51071 : H12AffineFastState.Bounded env51071 := by
  intro p hp
  have h : env51071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51070_51071 : H12AffineEnvironment.transform 11 1 env51070 = env51071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env51070 == env51071) = true)

theorem identity51071 : scanCanonicalize (H12AffineFastState.compose env51071 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 319) := by decide +kernel

theorem selectedBound51071 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51072 : List Nat := [2,4,8,16,32,16,8,256,512,1024,319,1,268,1281,1,263,1296,27,1025,0,17,33,17,3,268,17,318,1296,0,27,1284,33,257,33,1280,513]

theorem envBound51072 : H12AffineFastState.Bounded env51072 := by
  intro p hp
  have h : env51072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51071_51072 : H12AffineEnvironment.transform 10 319 env51071 = env51072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 319 env51071 == env51072) = true)

theorem identity51072 : scanCanonicalize (H12AffineFastState.compose env51072 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound51072 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51073 : List Nat := [2,4,8,16,32,16,8,256,512,21,319,1,268,276,1,263,261,27,20,0,17,33,17,3,268,17,318,261,0,27,273,33,257,33,277,513]

theorem envBound51073 : H12AffineFastState.Bounded env51073 := by
  intro p hp
  have h : env51073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51072_51073 : H12AffineEnvironment.transform 9 21 env51072 = env51073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env51072 == env51073) = true)

theorem identity51073 : scanCanonicalize (H12AffineFastState.compose env51073 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound51073 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env51074 : List Nat := [2,4,8,16,32,16,8,52,512,21,11,1,56,32,1,51,49,27,20,0,17,33,17,3,56,17,10,49,0,27,37,33,53,33,33,513]

theorem envBound51074 : H12AffineFastState.Bounded env51074 := by
  intro p hp
  have h : env51074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51073_51074 : H12AffineEnvironment.transform 7 52 env51073 = env51074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env51073 == env51074) = true)

theorem identity51074 : scanCanonicalize (H12AffineFastState.compose env51074 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound51074 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env51075 : List Nat := [2,4,8,16,26,16,8,14,512,21,11,1,2,26,1,9,11,27,20,0,17,27,17,3,2,17,10,11,0,27,31,27,15,27,27,513]

theorem envBound51075 : H12AffineFastState.Bounded env51075 := by
  intro p hp
  have h : env51075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51074_51075 : H12AffineEnvironment.transform 4 26 env51074 = env51075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env51074 == env51075) = true)

theorem identity51075 : scanCanonicalize (H12AffineFastState.compose env51075 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound51075 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env51076 : List Nat := [2,4,2,16,16,16,2,4,512,21,1,1,2,16,1,3,1,17,20,0,17,17,17,3,2,17,0,1,0,17,21,17,5,17,17,513]

theorem envBound51076 : H12AffineFastState.Bounded env51076 := by
  intro p hp
  have h : env51076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51075_51076 : H12AffineEnvironment.transform 2 2 env51075 = env51076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env51075 == env51076) = true)

theorem identity51076 : scanCanonicalize (H12AffineFastState.compose env51076 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 18) := by decide +kernel

theorem selectedBound51076 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51077 : List Nat := [2,4,2,16,16,16,2,4,18,21,1,1,2,16,1,3,1,17,20,0,17,17,17,3,2,17,0,1,0,17,21,17,5,17,17,19]

theorem envBound51077 : H12AffineFastState.Bounded env51077 := by
  intro p hp
  have h : env51077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51076_51077 : H12AffineEnvironment.transform 8 18 env51076 = env51077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 18 env51076 == env51077) = true)

theorem identity51077 : scanCanonicalize (H12AffineFastState.compose env51077 (packedSelected [0,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound51077 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env51078 : List Nat := [2,4,2,0,0,0,2,4,2,5,1,1,2,0,1,3,1,1,4,0,1,1,1,3,2,1,0,1,0,1,5,1,5,1,1,3]

theorem envBound51078 : H12AffineFastState.Bounded env51078 := by
  intro p hp
  have h : env51078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51077_51078 : H12AffineEnvironment.transform 3 0 env51077 = env51078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env51077 == env51078) = true)

theorem identity51078 : scanCanonicalize (H12AffineFastState.compose env51078 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound51078 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51079 : List Nat := [2,3,2,0,0,0,2,3,2,2,1,1,2,0,1,3,1,1,3,0,1,1,1,3,2,1,0,1,0,1,2,1,2,1,1,3]

theorem envBound51079 : H12AffineFastState.Bounded env51079 := by
  intro p hp
  have h : env51079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51078_51079 : H12AffineEnvironment.transform 1 3 env51078 = env51079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env51078 == env51079) = true)

def env51080 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,77899,4194304,62541,21762,8192,65,4409703,57677,102742,138341,75103,4194305,257,21793,46092,513]

theorem envBound51080 : H12AffineFastState.Bounded env51080 := by
  intro p hp
  have h : env51080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51033_51080 : H12AffineEnvironment.transform 17 10281 env51033 = env51080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env51033 == env51080) = true)

theorem identity51080 : scanCanonicalize (H12AffineFastState.compose env51080 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound51080 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env51081 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10281,1025,29789,77899,4194304,17,21762,8192,65,4409703,5393,91402,138341,75103,4194305,257,21793,16464,513]

theorem envBound51081 : H12AffineFastState.Bounded env51081 := by
  intro p hp
  have h : env51081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51080_51081 : H12AffineEnvironment.transform 14 29788 env51080 = env51081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env51080 == env51081) = true)

theorem identity51081 : scanCanonicalize (H12AffineFastState.compose env51081 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound51081 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51082 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,131072,10281,1025,29789,4160,4194304,17,21762,8192,65,4352364,5393,17665,138341,1364,4194305,257,21793,16464,513]

theorem envBound51082 : H12AffineFastState.Bounded env51082 := by
  intro p hp
  have h : env51082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51081_51082 : H12AffineEnvironment.transform 15 8203 env51081 = env51082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env51081 == env51082) = true)

theorem identity51082 : scanCanonicalize (H12AffineFastState.compose env51082 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 29741) := by decide +kernel

theorem selectedBound51082 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env51083 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,131072,10281,1025,29789,4160,29741,17,21762,8192,65,138561,5393,17665,138341,1364,29740,257,21793,16464,513]

theorem envBound51083 : H12AffineFastState.Bounded env51083 := by
  intro p hp
  have h : env51083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51082_51083 : H12AffineEnvironment.transform 21 29741 env51082 = env51083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29741 env51082 == env51083) = true)

theorem identity51083 : scanCanonicalize (H12AffineFastState.compose env51083 (packedSelected [1,4,8,9,10,12,18] rootPS)) = affineNative (2^(16+1) ^^^ 23605) := by decide +kernel

theorem selectedBound51083 : packedSelected [1,4,8,9,10,12,18] rootPS < 2^1333 := by decide +kernel

def env51084 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,23605,10281,1025,29789,4160,29741,17,21762,8192,65,16756,5393,17665,16464,1364,29740,257,21793,16464,513]

theorem envBound51084 : H12AffineFastState.Bounded env51084 := by
  intro p hp
  have h : env51084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51083_51084 : H12AffineEnvironment.transform 16 23605 env51083 = env51084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 23605 env51083 == env51084) = true)

theorem identity51084 : scanCanonicalize (H12AffineFastState.compose env51084 (packedSelected [0,4,7,9,11,20] rootPS)) = affineNative (2^(13+1) ^^^ 15453) := by decide +kernel

theorem selectedBound51084 : packedSelected [0,4,7,9,11,20] rootPS < 2^1333 := by decide +kernel

def env51085 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,15453,2049,8203,8296,10281,1025,2048,4160,2160,17,10591,8192,65,15657,5393,14684,15373,1364,2161,257,10620,15373,513]

theorem envBound51085 : H12AffineFastState.Bounded env51085 := by
  intro p hp
  have h : env51085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51084_51085 : H12AffineEnvironment.transform 13 15453 env51084 = env51085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15453 env51084 == env51085) = true)

theorem identity51085 : scanCanonicalize (H12AffineFastState.compose env51085 (packedSelected [1,2,5,6,8,12,15,24] rootPS)) = affineNative (2^(12+1) ^^^ 6201) := by decide +kernel

theorem selectedBound51085 : packedSelected [1,2,5,6,8,12,15,24] rootPS < 2^1333 := by decide +kernel

def env51086 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,6201,1124,2049,6194,6225,4112,1025,2048,4160,2160,17,4454,6201,65,1296,5393,357,1076,1364,2161,257,4421,1076,513]

theorem envBound51086 : H12AffineFastState.Bounded env51086 := by
  intro p hp
  have h : env51086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51085_51086 : H12AffineEnvironment.transform 12 6201 env51085 = env51086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6201 env51085 == env51086) = true)

theorem identity51086 : scanCanonicalize (H12AffineFastState.compose env51086 (packedSelected [1,2,3,5,6,8,10,12,15,26] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound51086 : packedSelected [1,2,3,5,6,8,10,12,15,26] rootPS < 2^1333 := by decide +kernel

def env51087 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3109,1052,1124,2049,1047,1140,3125,1025,2048,3173,2160,17,3395,1052,65,1296,2356,357,1076,1364,2161,257,3424,1076,513]

theorem envBound51087 : H12AffineFastState.Bounded env51087 := by
  intro p hp
  have h : env51087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51086_51087 : H12AffineEnvironment.transform 11 3109 env51086 = env51087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env51086 == env51087) = true)

theorem identity51087 : scanCanonicalize (H12AffineFastState.compose env51087 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound51087 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env51088 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,3109,1052,1124,2049,1047,1140,3125,1025,2048,3173,2160,17,3126,1052,65,1125,2113,16,1076,1057,2161,116,3093,1076,513]

theorem envBound51088 : H12AffineFastState.Bounded env51088 := by
  intro p hp
  have h : env51088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51087_51088 : H12AffineEnvironment.transform 7 117 env51087 = env51088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env51087 == env51088) = true)

theorem identity51088 : scanCanonicalize (H12AffineFastState.compose env51088 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51088 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env51089 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,3109,1052,1076,2049,1047,1060,3125,1025,2048,3125,2080,17,3126,1052,17,1077,2065,16,1076,1057,2081,36,3093,1076,513]

theorem envBound51089 : H12AffineFastState.Bounded env51089 := by
  intro p hp
  have h : env51089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51088_51089 : H12AffineEnvironment.transform 5 16 env51088 = env51089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51088 == env51089) = true)

theorem identity51089 : scanCanonicalize (H12AffineFastState.compose env51089 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound51089 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51090 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1,1060,1052,1076,0,1047,1060,1076,1025,1,1076,33,17,1079,1052,17,1077,16,16,1076,1057,32,36,1044,1076,513]

theorem envBound51090 : H12AffineFastState.Bounded env51090 := by
  intro p hp
  have h : env51090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51089_51090 : H12AffineEnvironment.transform 10 1 env51089 = env51090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env51089 == env51090) = true)

theorem identity51090 : scanCanonicalize (H12AffineFastState.compose env51090 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51090 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51091 : List Nat := [2,4,8,16,1,16,8,4,512,1024,1,1029,1052,1045,0,1047,1029,1045,1025,1,1045,0,17,1046,1052,17,1044,16,16,1045,1024,1,5,1044,1045,513]

theorem envBound51091 : H12AffineFastState.Bounded env51091 := by
  intro p hp
  have h : env51091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51090_51091 : H12AffineEnvironment.transform 4 1 env51090 = env51091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51090 == env51091) = true)

theorem identity51091 : scanCanonicalize (H12AffineFastState.compose env51091 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound51091 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env51092 : List Nat := [2,4,8,16,1,16,8,4,512,4,1,1,24,17,0,19,1,17,5,1,17,0,17,18,24,17,16,16,16,17,4,1,5,16,17,513]

theorem envBound51092 : H12AffineFastState.Bounded env51092 := by
  intro p hp
  have h : env51092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51091_51092 : H12AffineEnvironment.transform 9 4 env51091 = env51092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env51091 == env51092) = true)

theorem identity51092 : scanCanonicalize (H12AffineFastState.compose env51092 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound51092 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51093 : List Nat := [2,4,8,16,1,16,8,4,0,4,1,1,24,17,0,19,1,17,5,1,17,0,17,18,24,17,16,16,16,17,4,1,5,16,17,1]

theorem envBound51093 : H12AffineFastState.Bounded env51093 := by
  intro p hp
  have h : env51093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51092_51093 : H12AffineEnvironment.transform 8 0 env51092 = env51093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env51092 == env51093) = true)

theorem identity51093 : scanCanonicalize (H12AffineFastState.compose env51093 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound51093 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env51094 : List Nat := [2,4,8,0,1,0,8,4,0,4,1,1,8,1,0,3,1,1,5,1,1,0,1,2,8,1,0,0,0,1,4,1,5,0,1,1]

theorem envBound51094 : H12AffineFastState.Bounded env51094 := by
  intro p hp
  have h : env51094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51093_51094 : H12AffineEnvironment.transform 3 0 env51093 = env51094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env51093 == env51094) = true)

def env51095 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318564,2444641,8193,65,6705412,313700,2394420,138341,2102549,4466728,257,21793,46093,2175562]

theorem envBound51095 : H12AffineFastState.Bounded env51095 := by
  intro p hp
  have h : env51095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51031_51095 : H12AffineEnvironment.transform 6 9 env51031 = env51095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51031 == env51095) = true)

def env51096 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2373704,318564,2444641,8193,65,158028,313700,2394420,138341,2102549,2101344,257,21793,46093,2175562]

theorem envBound51096 : H12AffineFastState.Bounded env51096 := by
  intro p hp
  have h : env51096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51095_51096 : H12AffineEnvironment.transform 21 2373704 env51095 = env51096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2373704 env51095 == env51096) = true)

theorem identity51096 : scanCanonicalize (H12AffineFastState.compose env51096 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound51096 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env51097 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,77899,329731,318564,294186,8193,65,158028,313700,375167,138341,75102,73771,257,21793,46093,513]

theorem envBound51097 : H12AffineFastState.Bounded env51097 := by
  intro p hp
  have h : env51097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51096_51097 : H12AffineEnvironment.transform 20 77899 env51096 = env51097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env51096 == env51097) = true)

theorem identity51097 : scanCanonicalize (H12AffineFastState.compose env51097 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound51097 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51098 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1025,32769,77899,329731,318564,294186,8193,65,67927,313700,375167,97406,75102,73771,257,21793,46093,513]

theorem envBound51098 : H12AffineFastState.Bounded env51098 := by
  intro p hp
  have h : env51098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51097_51098 : H12AffineEnvironment.transform 16 90139 env51097 = env51098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env51097 == env51098) = true)

theorem identity51098 : scanCanonicalize (H12AffineFastState.compose env51098 (packedSelected [12,15,17,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 130174) := by decide +kernel

theorem selectedBound51098 : packedSelected [12,15,17,38,41] rootPS < 2^1333 := by decide +kernel

def env51099 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,130174,1025,32769,77899,62589,73754,98644,8193,65,67927,79130,17665,97406,75102,73771,257,21793,46093,513]

theorem envBound51099 : H12AffineFastState.Bounded env51099 := by
  intro p hp
  have h : env51099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51098_51099 : H12AffineEnvironment.transform 17 130174 env51098 = env51099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130174 env51098 == env51099) = true)

theorem identity51099 : scanCanonicalize (H12AffineFastState.compose env51099 (packedSelected [2,4,6,9,11,14,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound51099 : packedSelected [2,4,6,9,11,14,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env51100 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,262,24861,64888,1025,32769,12621,62589,8476,32850,8193,65,2129,13340,17665,32120,9304,8493,257,21793,46093,513]

theorem envBound51100 : H12AffineFastState.Bounded env51100 := by
  intro p hp
  have h : env51100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51099_51100 : H12AffineEnvironment.transform 15 262 env51099 = env51100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env51099 == env51100) = true)

theorem identity51100 : scanCanonicalize (H12AffineFastState.compose env51100 (packedSelected [2,3,4,5,6,9,10,12,14,15,18,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound51100 : packedSelected [2,3,4,5,6,9,10,12,14,15,18,20,23] rootPS < 2^1333 := by decide +kernel

def env51101 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,32768,262,13673,43276,1025,32769,12621,40969,8476,32850,8193,65,2129,13340,4469,10508,9304,8493,257,341,46093,513]

theorem envBound51101 : H12AffineFastState.Bounded env51101 := by
  intro p hp
  have h : env51101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51100_51101 : H12AffineEnvironment.transform 13 5236 env51100 = env51101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env51100 == env51101) = true)

theorem identity51101 : scanCanonicalize (H12AffineFastState.compose env51101 (packedSelected [0,2,7,11,14,17,18,20] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound51101 : packedSelected [0,2,7,11,14,17,18,20] rootPS < 2^1333 := by decide +kernel

def env51102 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,8192,4112,32768,262,12557,43276,101,32769,12621,40969,8476,32850,8193,65,2129,12408,4469,10508,8252,8493,257,341,45161,513]

theorem envBound51102 : H12AffineFastState.Bounded env51102 := by
  intro p hp
  have h : env51102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51101_51102 : H12AffineEnvironment.transform 9 100 env51101 = env51102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env51101 == env51102) = true)

theorem identity51102 : scanCanonicalize (H12AffineFastState.compose env51102 (packedSelected [1,2,6,7,8,9,11,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound51102 : packedSelected [1,2,6,7,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env51103 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,8192,4112,8461,262,12557,2049,101,8460,12621,260,8476,8543,8193,65,2129,12408,4469,10508,8252,8493,257,341,4452,513]

theorem envBound51103 : H12AffineFastState.Bounded env51103 := by
  intro p hp
  have h : env51103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51102_51103 : H12AffineEnvironment.transform 14 8461 env51102 = env51103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env51102 == env51103) = true)

theorem identity51103 : scanCanonicalize (H12AffineFastState.compose env51103 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound51103 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env51104 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,121,4112,372,262,4468,2049,101,373,4404,260,357,294,120,65,2129,4097,4469,2421,69,340,257,341,4452,513]

theorem envBound51104 : H12AffineFastState.Bounded env51104 := by
  intro p hp
  have h : env51104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51103_51104 : H12AffineEnvironment.transform 12 121 env51103 = env51104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env51103 == env51104) = true)

theorem identity51104 : scanCanonicalize (H12AffineFastState.compose env51104 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound51104 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env51105 : List Nat := [2,4,8,16,32,64,9,116,512,100,2048,4096,121,4112,0,114,4096,2049,101,1,4160,112,17,82,120,65,2129,4097,4097,2049,69,32,117,33,4112,513]

theorem envBound51105 : H12AffineFastState.Bounded env51105 := by
  intro p hp
  have h : env51105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51104_51105 : H12AffineEnvironment.transform 7 116 env51104 = env51105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env51104 == env51105) = true)

def env51106 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2373705,318564,2444641,8193,65,158029,313700,2394420,138341,2102549,2101345,257,21793,46093,2175562]

theorem envBound51106 : H12AffineFastState.Bounded env51106 := by
  intro p hp
  have h : env51106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51095_51106 : H12AffineEnvironment.transform 21 2373705 env51095 = env51106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2373705 env51095 == env51106) = true)

def env51107 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,272393,318564,351521,8193,65,158029,313700,301428,138341,1365,33,257,21793,46093,74250]

theorem envBound51107 : H12AffineFastState.Bounded env51107 := by
  intro p hp
  have h : env51107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51106_51107 : H12AffineEnvironment.transform 20 4160 env51106 = env51107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env51106 == env51107) = true)

theorem identity51107 : scanCanonicalize (H12AffineFastState.compose env51107 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound51107 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51108 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,21792,41293,73736,8193,65,158029,46157,58461,138341,1365,33,257,21793,46093,74250]

theorem envBound51108 : H12AffineFastState.Bounded env51108 := by
  intro p hp
  have h : env51108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51107_51108 : H12AffineEnvironment.transform 17 32041 env51107 = env51108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env51107 == env51108) = true)

theorem identity51108 : scanCanonicalize (H12AffineFastState.compose env51108 (packedSelected [1,5,8,16,19,20,21,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound51108 : packedSelected [1,5,8,16,19,20,21,24,26] rootPS < 2^1333 := by decide +kernel

def env51109 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,46157,32041,1025,32769,4160,21792,41293,73736,8193,65,56576,46157,58461,43048,1365,33,257,21793,46093,74250]

theorem envBound51109 : H12AffineFastState.Bounded env51109 := by
  intro p hp
  have h : env51109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51108_51109 : H12AffineEnvironment.transform 16 46157 env51108 = env51109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env51108 == env51109) = true)

theorem identity51109 : scanCanonicalize (H12AffineFastState.compose env51109 (packedSelected [3,5,8,10,21,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound51109 : packedSelected [3,5,8,10,21,28,31] rootPS < 2^1333 := by decide +kernel

def env51110 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,46157,10280,1025,32769,4160,33,41293,73736,8193,65,34817,46157,45404,43048,1365,33,257,32,46093,74250]

theorem envBound51110 : H12AffineFastState.Bounded env51110 := by
  intro p hp
  have h : env51110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51109_51110 : H12AffineEnvironment.transform 13 5377 env51109 = env51110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env51109 == env51110) = true)

theorem identity51110 : scanCanonicalize (H12AffineFastState.compose env51110 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound51110 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env51111 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8203,46157,10280,1025,32769,4160,33,41293,3,8193,65,34817,46157,45404,43048,1365,33,257,32,46093,513]

theorem envBound51111 : H12AffineFastState.Bounded env51111 := by
  intro p hp
  have h : env51111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51110_51111 : H12AffineEnvironment.transform 15 8203 env51110 = env51111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env51110 == env51111) = true)

theorem identity51111 : scanCanonicalize (H12AffineFastState.compose env51111 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound51111 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env51112 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,301,5377,32768,294,38240,2309,1025,32769,4160,33,32864,3,300,65,34817,38240,36977,35077,1365,33,257,32,38176,513]

theorem envBound51112 : H12AffineFastState.Bounded env51112 := by
  intro p hp
  have h : env51112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51111_51112 : H12AffineEnvironment.transform 12 301 env51111 = env51112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env51111 == env51112) = true)

theorem identity51112 : scanCanonicalize (H12AffineFastState.compose env51112 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound51112 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env51113 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1281,301,0,32768,294,32865,2309,1025,32769,1345,33,32864,3,300,65,34817,32865,34160,35077,1365,33,257,32,32801,513]

theorem envBound51113 : H12AffineFastState.Bounded env51113 := by
  intro p hp
  have h : env51113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51112_51113 : H12AffineEnvironment.transform 11 1281 env51112 = env51113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env51112 == env51113) = true)

theorem identity51113 : scanCanonicalize (H12AffineFastState.compose env51113 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 2309) := by decide +kernel

theorem selectedBound51113 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env51114 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1281,301,0,2309,294,2404,2309,1025,2308,1345,33,2405,3,300,65,260,2404,3189,0,1365,33,257,32,2340,513]

theorem envBound51114 : H12AffineFastState.Bounded env51114 := by
  intro p hp
  have h : env51114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51113_51114 : H12AffineEnvironment.transform 14 2309 env51113 = env51114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2309 env51113 == env51114) = true)

theorem identity51114 : scanCanonicalize (H12AffineFastState.compose env51114 (packedSelected [6,14] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound51114 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env51115 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,1281,301,0,1377,294,1280,1377,1025,1376,1345,33,1281,3,300,65,260,1280,17,0,1365,33,257,32,1344,513]

theorem envBound51115 : H12AffineFastState.Bounded env51115 := by
  intro p hp
  have h : env51115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51114_51115 : H12AffineEnvironment.transform 10 1124 env51114 = env51115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env51114 == env51115) = true)

theorem identity51115 : scanCanonicalize (H12AffineFastState.compose env51115 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound51115 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51116 : List Nat := [2,4,8,16,32,64,9,36,512,1024,1124,1061,9,0,1093,2,1060,1093,1025,1092,1125,33,1061,3,8,65,32,1060,17,0,1137,33,37,32,1124,513]

theorem envBound51116 : H12AffineFastState.Bounded env51116 := by
  intro p hp
  have h : env51116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51115_51116 : H12AffineEnvironment.transform 7 36 env51115 = env51116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env51115 == env51116) = true)

theorem identity51116 : scanCanonicalize (H12AffineFastState.compose env51116 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound51116 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env51117 : List Nat := [2,4,8,16,32,64,9,36,17,1024,1124,1061,9,0,1093,2,1060,1093,1025,1092,1125,33,1061,3,8,65,32,1060,17,0,1137,33,37,32,1124,16]

theorem envBound51117 : H12AffineFastState.Bounded env51117 := by
  intro p hp
  have h : env51117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51116_51117 : H12AffineEnvironment.transform 8 17 env51116 = env51117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env51116 == env51117) = true)

theorem identity51117 : scanCanonicalize (H12AffineFastState.compose env51117 (packedSelected [1,6,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound51117 : packedSelected [1,6,8] rootPS < 2^1333 := by decide +kernel

def env51118 : List Nat := [2,4,8,1,32,64,9,36,0,1024,1124,1061,9,0,1093,2,1060,1093,1025,1092,1125,33,1061,3,8,65,32,1060,0,0,1120,33,37,32,1124,1]

theorem envBound51118 : H12AffineFastState.Bounded env51118 := by
  intro p hp
  have h : env51118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51117_51118 : H12AffineEnvironment.transform 3 1 env51117 = env51118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env51117 == env51118) = true)

theorem identity51118 : scanCanonicalize (H12AffineFastState.compose env51118 (packedSelected [0,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound51118 : packedSelected [0,7,10] rootPS < 2^1333 := by decide +kernel

def env51119 : List Nat := [2,4,8,1,32,64,9,36,0,68,32,97,9,0,1,2,96,1,69,0,33,33,97,3,8,65,32,96,0,0,36,33,37,32,32,1]

theorem envBound51119 : H12AffineFastState.Bounded env51119 := by
  intro p hp
  have h : env51119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51118_51119 : H12AffineEnvironment.transform 9 68 env51118 = env51119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env51118 == env51119) = true)

theorem identity51119 : scanCanonicalize (H12AffineFastState.compose env51119 (packedSelected [0,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51119 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env51120 : List Nat := [2,4,8,1,1,64,9,5,0,68,1,64,9,0,1,2,65,1,69,0,0,0,64,3,8,65,1,65,0,0,5,0,4,1,1,1]

theorem envBound51120 : H12AffineFastState.Bounded env51120 := by
  intro p hp
  have h : env51120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51119_51120 : H12AffineEnvironment.transform 4 1 env51119 = env51120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51119 == env51120) = true)

def env51121 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,272392,318564,351520,8193,65,158029,313700,301429,138341,1364,32,257,21793,46093,74251]

theorem envBound51121 : H12AffineFastState.Bounded env51121 := by
  intro p hp
  have h : env51121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51106_51121 : H12AffineEnvironment.transform 20 4161 env51106 = env51121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env51106 == env51121) = true)

theorem identity51121 : scanCanonicalize (H12AffineFastState.compose env51121 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound51121 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51122 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1025,32769,4161,272392,297316,329760,8193,65,146509,302180,301429,138341,1364,32,257,33,46093,74251]

theorem envBound51122 : H12AffineFastState.Bounded env51122 := by
  intro p hp
  have h : env51122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51121_51122 : H12AffineEnvironment.transform 13 5376 env51121 = env51122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env51121 == env51122) = true)

theorem identity51122 : scanCanonicalize (H12AffineFastState.compose env51122 (packedSelected [11,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound51122 : packedSelected [11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env51123 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,67619,1025,32769,4161,73771,98631,3,8193,65,146509,103495,102742,138341,1364,32,257,33,46093,74251]

theorem envBound51123 : H12AffineFastState.Bounded env51123 := by
  intro p hp
  have h : env51123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51122_51123 : H12AffineEnvironment.transform 17 67619 env51122 = env51123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env51122 == env51123) = true)

theorem identity51123 : scanCanonicalize (H12AffineFastState.compose env51123 (packedSelected [0,1,6,7,8,10,15,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 70759) := by decide +kernel

theorem selectedBound51123 : packedSelected [0,1,6,7,8,10,15,21,23] rootPS < 2^1333 := by decide +kernel

def env51124 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,70759,67619,1025,32769,4161,73771,98631,3,8193,65,75818,103495,102742,67586,1364,32,257,33,46093,74251]

theorem envBound51124 : H12AffineFastState.Bounded env51124 := by
  intro p hp
  have h : env51124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51123_51124 : H12AffineEnvironment.transform 16 70759 env51123 = env51124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70759 env51123 == env51124) = true)

theorem identity51124 : scanCanonicalize (H12AffineFastState.compose env51124 (packedSelected [2,4,9,11,18,20,21] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound51124 : packedSelected [2,4,9,11,18,20,21] rootPS < 2^1333 := by decide +kernel

def env51125 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1,65536,70759,67619,1025,0,4161,73771,65862,3,8193,65,75818,70726,69975,67586,1364,32,257,33,13324,74251]

theorem envBound51125 : H12AffineFastState.Bounded env51125 := by
  intro p hp
  have h : env51125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51124_51125 : H12AffineEnvironment.transform 14 1 env51124 = env51125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env51124 == env51125) = true)

theorem identity51125 : scanCanonicalize (H12AffineFastState.compose env51125 (packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound51125 : packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env51126 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1,114,5141,2129,1025,0,4161,8281,308,3,8193,65,10328,5172,4389,2160,1364,32,257,33,13324,8825]

theorem envBound51126 : H12AffineFastState.Bounded env51126 := by
  intro p hp
  have h : env51126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51125_51126 : H12AffineEnvironment.transform 15 114 env51125 = env51126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env51125 == env51126) = true)

theorem identity51126 : scanCanonicalize (H12AffineFastState.compose env51126 (packedSelected [0,1,2,3,5,7,8,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound51126 : packedSelected [0,1,2,3,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env51127 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,4096,8192,5125,1,114,5141,2129,1025,0,4161,8281,49,3,8193,65,10328,5172,4128,2160,1105,32,4,33,13324,8825]

theorem envBound51127 : H12AffineFastState.Bounded env51127 := by
  intro p hp
  have h : env51127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51126_51127 : H12AffineEnvironment.transform 7 5 env51126 = env51127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env51126 == env51127) = true)

theorem identity51127 : scanCanonicalize (H12AffineFastState.compose env51127 (packedSelected [3,4,5,6,9,10,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51127 : packedSelected [3,4,5,6,9,10,16] rootPS < 2^1333 := by decide +kernel

def env51128 : List Nat := [2,4,8,16,32,17,9,5,512,1024,2048,4096,8192,5125,1,35,5141,2048,1025,0,4112,8200,49,3,8193,16,10249,5172,4128,2081,1024,32,4,33,13324,8744]

theorem envBound51128 : H12AffineFastState.Bounded env51128 := by
  intro p hp
  have h : env51128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51127_51128 : H12AffineEnvironment.transform 5 17 env51127 = env51128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51127 == env51128) = true)

theorem identity51128 : scanCanonicalize (H12AffineFastState.compose env51128 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound51128 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env51129 : List Nat := [2,4,8,16,32,17,9,5,512,1024,2048,4096,40,5125,1,35,5141,2048,1025,0,4112,32,49,3,41,16,2081,5172,4128,2081,1024,32,4,33,5156,512]

theorem envBound51129 : H12AffineFastState.Bounded env51129 := by
  intro p hp
  have h : env51129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51128_51129 : H12AffineEnvironment.transform 12 40 env51128 = env51129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env51128 == env51129) = true)

theorem identity51129 : scanCanonicalize (H12AffineFastState.compose env51129 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound51129 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env51130 : List Nat := [2,4,8,16,32,17,9,5,512,52,2048,4096,40,4145,1,35,4129,2048,53,0,4112,32,49,3,41,16,2081,4096,4128,2081,52,32,4,33,4112,512]

theorem envBound51130 : H12AffineFastState.Bounded env51130 := by
  intro p hp
  have h : env51130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51129_51130 : H12AffineEnvironment.transform 9 52 env51129 = env51130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env51129 == env51130) = true)

theorem identity51130 : scanCanonicalize (H12AffineFastState.compose env51130 (packedSelected [1,2] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound51130 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env51131 : List Nat := [2,4,8,16,32,17,9,5,7,52,2048,4096,40,4145,1,35,4129,2048,53,0,4112,32,49,3,41,16,2081,4096,4128,2081,52,32,4,33,4112,7]

theorem envBound51131 : H12AffineFastState.Bounded env51131 := by
  intro p hp
  have h : env51131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51130_51131 : H12AffineEnvironment.transform 8 7 env51130 = env51131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env51130 == env51131) = true)

def env51132 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318565,2444776,8328,65,6705548,313700,2394421,138340,2102685,4466728,257,21792,46213,2175563]

theorem envBound51132 : H12AffineFastState.Bounded env51132 := by
  intro p hp
  have h : env51132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51030_51132 : H12AffineEnvironment.transform 22 318565 env51030 = env51132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 318565 env51030 == env51132) = true)

def env51133 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318565,2444640,8192,65,6705412,313700,2394421,138340,2102549,4466728,257,21792,46093,2175563]

theorem envBound51133 : H12AffineFastState.Bounded env51133 := by
  intro p hp
  have h : env51133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51132_51133 : H12AffineEnvironment.transform 6 8 env51132 = env51133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51132 == env51133) = true)

def env51134 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2373704,318565,2444640,8192,65,158028,313700,2394421,138340,2102549,2101344,257,21792,46093,2175563]

theorem envBound51134 : H12AffineFastState.Bounded env51134 := by
  intro p hp
  have h : env51134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51133_51134 : H12AffineEnvironment.transform 21 2373704 env51133 = env51134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2373704 env51133 == env51134) = true)

theorem identity51134 : scanCanonicalize (H12AffineFastState.compose env51134 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound51134 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env51135 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,77898,329730,318565,294186,8192,65,158028,313700,375167,138340,75103,73770,257,21792,46093,513]

theorem envBound51135 : H12AffineFastState.Bounded env51135 := by
  intro p hp
  have h : env51135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51134_51135 : H12AffineEnvironment.transform 20 77898 env51134 = env51135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env51134 == env51135) = true)

def env51136 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,77898,73770,62541,21762,8192,65,158028,57676,102743,138340,75103,73770,257,21792,46093,513]

theorem envBound51136 : H12AffineFastState.Bounded env51136 := by
  intro p hp
  have h : env51136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51135_51136 : H12AffineEnvironment.transform 17 10280 env51135 = env51136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env51135 == env51136) = true)

def env51137 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,77850,73770,62493,21762,8192,17,157980,57628,102663,138292,75023,73770,257,21792,46093,513]

theorem envBound51137 : H12AffineFastState.Bounded env51137 := by
  intro p hp
  have h : env51137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51136_51137 : H12AffineEnvironment.transform 5 16 env51136 = env51137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51136 == env51137) = true)

theorem identity51137 : scanCanonicalize (H12AffineFastState.compose env51137 (packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound51137 : packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env51138 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10280,1025,32769,77850,73770,62493,21762,8192,17,67846,57628,102663,97326,75023,73770,257,21792,46093,513]

theorem envBound51138 : H12AffineFastState.Bounded env51138 := by
  intro p hp
  have h : env51138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51137_51138 : H12AffineEnvironment.transform 16 90138 env51137 = env51138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env51137 == env51138) = true)

theorem identity51138 : scanCanonicalize (H12AffineFastState.compose env51138 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound51138 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51139 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,21760,65536,90138,10280,1025,21761,77850,73770,8477,21762,8192,17,67846,13340,82951,97326,75023,73770,257,21792,24845,513]

theorem envBound51139 : H12AffineFastState.Bounded env51139 := by
  intro p hp
  have h : env51139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51138_51139 : H12AffineEnvironment.transform 14 21760 env51138 = env51139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env51138 == env51139) = true)

theorem identity51139 : scanCanonicalize (H12AffineFastState.compose env51139 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound51139 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51140 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,21760,29962,5392,10280,1025,21761,17680,21792,8477,21762,8192,17,31756,13340,12557,2340,20485,21792,257,21792,24845,513]

theorem envBound51140 : H12AffineFastState.Bounded env51140 := by
  intro p hp
  have h : env51140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51139_51140 : H12AffineEnvironment.transform 15 29962 env51139 = env51140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env51139 == env51140) = true)

theorem identity51140 : scanCanonicalize (H12AffineFastState.compose env51140 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound51140 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env51141 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,40,16384,21760,21794,5392,2048,1025,21761,17680,21792,309,21762,40,17,23588,5172,4389,2340,20485,21792,257,21792,16677,513]

theorem envBound51141 : H12AffineFastState.Bounded env51141 := by
  intro p hp
  have h : env51141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51140_51141 : H12AffineEnvironment.transform 12 40 env51140 = env51141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env51140 == env51141) = true)

theorem identity51141 : scanCanonicalize (H12AffineFastState.compose env51141 (packedSelected [0,1,2,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound51141 : packedSelected [0,1,2,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env51142 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,40,5377,1,35,5392,2048,1025,0,4113,33,309,3,40,17,2341,5172,4389,2340,1284,33,257,33,5156,513]

theorem envBound51142 : H12AffineFastState.Bounded env51142 := by
  intro p hp
  have h : env51142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51141_51142 : H12AffineEnvironment.transform 13 5377 env51141 = env51142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env51141 == env51142) = true)

theorem identity51142 : scanCanonicalize (H12AffineFastState.compose env51142 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound51142 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env51143 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,308,40,1077,1,35,1060,2048,1025,0,293,33,309,3,40,17,2341,1280,17,2340,1284,33,257,33,1296,513]

theorem envBound51143 : H12AffineFastState.Bounded env51143 := by
  intro p hp
  have h : env51143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51142_51143 : H12AffineEnvironment.transform 11 308 env51142 = env51143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env51142 == env51143) = true)

theorem identity51143 : scanCanonicalize (H12AffineFastState.compose env51143 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound51143 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env51144 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1076,308,40,1077,1,35,1060,1076,1025,0,293,33,309,3,40,17,1297,1280,17,1296,1284,33,257,33,1296,513]

theorem envBound51144 : H12AffineFastState.Bounded env51144 := by
  intro p hp
  have h : env51144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0